#
# TABLE STRUCTURE FOR: m_admin
#

DROP TABLE IF EXISTS `m_admin`;

CREATE TABLE `m_admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` enum('admin','guru','siswa') NOT NULL,
  `konid` varchar(10) NOT NULL,
  `aktif` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES (1, 'admin', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'admin', '0', 'Y');
INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES (63, 'syarif', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '12', 'Y');
INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES (64, 'rinifa', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '13', 'Y');
INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES (65, 'sharfi', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '14', 'Y');
INSERT INTO `m_admin` (`id`, `username`, `password`, `level`, `konid`, `aktif`) VALUES (67, 'jokopu', 'fefdd621d35d14c299aef2fcae34d3dfe9b2f12b', 'guru', '15', 'Y');


#
# TABLE STRUCTURE FOR: m_ekstra
#

DROP TABLE IF EXISTS `m_ekstra`;

CREATE TABLE `m_ekstra` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `m_ekstra` (`id`, `nama`) VALUES (10, 'Mengaji');


#
# TABLE STRUCTURE FOR: m_guru
#

DROP TABLE IF EXISTS `m_guru`;

CREATE TABLE `m_guru` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(20) DEFAULT NULL,
  `jk` enum('L','P') DEFAULT NULL,
  `is_bk` enum('2','1') DEFAULT NULL,
  `stat_data` enum('A','P','M') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `m_guru` (`id`, `nama`, `nip`, `jk`, `is_bk`, `stat_data`) VALUES (12, 'Syarifudin, M.Pd', '-', NULL, '2', 'A');
INSERT INTO `m_guru` (`id`, `nama`, `nip`, `jk`, `is_bk`, `stat_data`) VALUES (13, 'Rini Fath Marsya, M.Pd', '-', NULL, '2', 'A');
INSERT INTO `m_guru` (`id`, `nama`, `nip`, `jk`, `is_bk`, `stat_data`) VALUES (14, 'sharfina', '-', NULL, '2', 'A');
INSERT INTO `m_guru` (`id`, `nama`, `nip`, `jk`, `is_bk`, `stat_data`) VALUES (15, 'Joko Purnomo', '-', NULL, '2', 'A');


#
# TABLE STRUCTURE FOR: m_kelas
#

DROP TABLE IF EXISTS `m_kelas`;

CREATE TABLE `m_kelas` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tingkat` int(11) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (1, 1, 'I');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (2, 2, 'II');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (3, 3, 'III');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (4, 4, 'IV');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (6, 5, 'V');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (7, 6, 'VI');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (8, 8, '8B');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (9, 0, 'Emerald Class');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (10, 1, '1A');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (11, 1, 'KGA 1');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (12, 1, 'KGA 2');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (13, 2, 'PG 1');
INSERT INTO `m_kelas` (`id`, `tingkat`, `nama`) VALUES (14, 2, 'PG 2');


#
# TABLE STRUCTURE FOR: m_mapel
#

DROP TABLE IF EXISTS `m_mapel`;

CREATE TABLE `m_mapel` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `kelompok` enum('A','B','MULOK','PUS','ICB','LA','PSS','NNA','BI','KOG','FIMO','SEK') NOT NULL,
  `tambahan_sub` enum('NO','PAI','MULOK','mid','final') NOT NULL,
  `kd_singkat` varchar(5) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `kkm` int(2) NOT NULL,
  `is_sikap` enum('0','1') NOT NULL,
  `lang` enum('id','eng') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (20, 'A', 'NO', 'PAI', 'Pendidikan Agama Islam dan Budi Pekerti', 79, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (21, 'PUS', 'NO', 'ICT', 'Information and Communication Technology', 70, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (22, 'A', 'NO', 'PE', 'Physical Education', 79, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (23, 'A', 'NO', 'Math', 'Mathematics', 79, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (24, 'A', 'NO', 'PPK', 'Pendidikan Pancasila dan Kewarganegaraan', 79, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (29, 'A', 'NO', 'ENG', 'English', 79, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (30, 'ICB', 'final', 'ICB', 'ISLAMIC CHARACTER BUILDING (Final)', 3, '0', 'eng');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (31, 'ICB', 'mid', 'ICB', 'ISLAMIC CHARACTER BUILDING (Mid)', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (32, 'PSS', 'mid', 'PSS', 'PERSONAL AND SOCIAL SKILLS (Mid)', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (33, 'PSS', 'final', 'PSS', 'PERSONAL AND SOCIAL SKILLS (Final)', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (34, 'LA', 'mid', 'LA', 'LEARNING ATTITUDES (Mid)', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (35, 'LA', 'final', 'LA', 'LEARNING ATTITUDES (Final)', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (36, 'KOG', 'NO', 'KOG-1', 'Berpikir simbolis', 3, '0', 'id');
INSERT INTO `m_mapel` (`id`, `kelompok`, `tambahan_sub`, `kd_singkat`, `nama`, `kkm`, `is_sikap`, `lang`) VALUES (37, 'NNA', 'NO', 'NNA-1', 'Mengenal ajaran agama yang dianut', 3, '0', 'id');


#
# TABLE STRUCTURE FOR: m_siswa
#

DROP TABLE IF EXISTS `m_siswa`;

CREATE TABLE `m_siswa` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nis` varchar(10) NOT NULL DEFAULT '0',
  `xendit` varchar(11) NOT NULL,
  `nisn` varchar(10) NOT NULL DEFAULT '0',
  `nama` varchar(100) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `tmp_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status` varchar(2) NOT NULL,
  `anakke` int(2) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `notelp` varchar(13) NOT NULL,
  `sek_asal` varchar(30) NOT NULL,
  `sek_asal_alamat` varchar(50) NOT NULL,
  `diterima_kelas` varchar(5) NOT NULL,
  `diterima_tgl` date NOT NULL,
  `diterima_smt` varchar(2) NOT NULL,
  `ijazah_no` varchar(50) NOT NULL,
  `ijazah_thn` varchar(4) NOT NULL,
  `skhun_no` varchar(50) NOT NULL,
  `skhun_thn` varchar(4) NOT NULL,
  `ortu_ayah` varchar(50) NOT NULL,
  `ortu_ibu` varchar(50) NOT NULL,
  `ortu_alamat` varchar(50) NOT NULL,
  `ortu_notelp` varchar(13) NOT NULL,
  `ortu_ayah_pkj` varchar(30) NOT NULL,
  `ortu_ibu_pkj` varchar(30) NOT NULL,
  `wali` varchar(20) NOT NULL,
  `wali_alamat` varchar(50) NOT NULL,
  `notelp_rumah` varchar(13) NOT NULL,
  `wali_pkj` varchar(13) NOT NULL,
  `inputID` int(2) NOT NULL,
  `tgl_input` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tgl_update` timestamp NOT NULL DEFAULT current_timestamp(),
  `stat_data` enum('A','K','M','L') NOT NULL,
  `foto` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=539 DEFAULT CHARSET=latin1;

INSERT INTO `m_siswa` (`id`, `nis`, `xendit`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES (531, ' 2021.7.02', '', '-', 'SHIFA MISYA FIANDIA', 'P', '-', '2023-01-09', 'Islam', 'AK', 0, '', '', '', '', '8B', '2023-01-09', '8B', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '2023-01-09 13:01:27', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `xendit`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES (532, ' 2021.7.03', '', '-', 'Salludin Gozali', 'L', '-', '2023-01-09', 'Islam', 'AK', 0, '', '', '', '', '8B', '2023-01-09', '8B', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '2023-01-09 13:01:57', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `xendit`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES (536, '22', '', '22', 'Nadya', 'P', 'tangerang', '2023-07-06', 'Islam', 'AK', 1, '', '', '', '', 'Emera', '2023-01-09', 'Em', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '2023-07-10 11:58:53', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `xendit`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES (537, '33', '', '-', 'nanda', 'P', 'tangerang', '2023-07-11', 'Islam', 'AK', 1, '', '', '', '', 'Emera', '2023-07-11', 'Em', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '2023-07-11 14:35:11', '0000-00-00 00:00:00', 'A', '');
INSERT INTO `m_siswa` (`id`, `nis`, `xendit`, `nisn`, `nama`, `jk`, `tmp_lahir`, `tgl_lahir`, `agama`, `status`, `anakke`, `alamat`, `notelp`, `sek_asal`, `sek_asal_alamat`, `diterima_kelas`, `diterima_tgl`, `diterima_smt`, `ijazah_no`, `ijazah_thn`, `skhun_no`, `skhun_thn`, `ortu_ayah`, `ortu_ibu`, `ortu_alamat`, `ortu_notelp`, `ortu_ayah_pkj`, `ortu_ibu_pkj`, `wali`, `wali_alamat`, `notelp_rumah`, `wali_pkj`, `inputID`, `tgl_input`, `tgl_update`, `stat_data`, `foto`) VALUES (538, '-', '', '-', '-', 'L', '-', '2023-07-21', 'Islam', 'AK', 1, '', '', '', '', 'I', '0000-00-00', 'I', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '2023-07-21 13:34:43', '2023-07-21 13:34:43', 'A', '');


#
# TABLE STRUCTURE FOR: t_backupdb
#

DROP TABLE IF EXISTS `t_backupdb`;

CREATE TABLE `t_backupdb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tahun_akademik` varchar(6) NOT NULL,
  `nama_file` varchar(128) NOT NULL,
  `tgl_simpan` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_catatan_bi
#

DROP TABLE IF EXISTS `t_catatan_bi`;

CREATE TABLE `t_catatan_bi` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_bi` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (5, 531, '20232', 'sudah bagus', 'bagus');
INSERT INTO `t_catatan_bi` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (6, 532, '20232', 'sudah bagus', 'bagus');


#
# TABLE STRUCTURE FOR: t_catatan_fimo
#

DROP TABLE IF EXISTS `t_catatan_fimo`;

CREATE TABLE `t_catatan_fimo` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_fimo` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (1, 531, '20232', '-', '-');
INSERT INTO `t_catatan_fimo` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (2, 532, '20232', '-', '-');


#
# TABLE STRUCTURE FOR: t_catatan_homeroom
#

DROP TABLE IF EXISTS `t_catatan_homeroom`;

CREATE TABLE `t_catatan_homeroom` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_homeroom` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (1, 531, '20232', '-', '-');
INSERT INTO `t_catatan_homeroom` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (2, 532, '20232', 'salludin', '-');


#
# TABLE STRUCTURE FOR: t_catatan_kl1
#

DROP TABLE IF EXISTS `t_catatan_kl1`;

CREATE TABLE `t_catatan_kl1` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `capaian_mid` varchar(5) NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  `capaian_final` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_kl1` (`id`, `id_siswa`, `ta`, `catatan_mid`, `capaian_mid`, `catatan_final`, `capaian_final`) VALUES (3, 531, '20232', '-', '-', '-', 'SB');
INSERT INTO `t_catatan_kl1` (`id`, `id_siswa`, `ta`, `catatan_mid`, `capaian_mid`, `catatan_final`, `capaian_final`) VALUES (4, 532, '20232', 'Kamu mengikuti kegiatan pembelajaran keagamaan di sekolah dengan sangat baik. Melaksanakan salat 5 (lima) waktu dengan baik. Kamu selalu hadir mengikuti BTQ dan tahfiz. Kamu telah menyelesaikan hafalan seluruh surat di juz 29. Kamu sudah melaksanakan sholat dhuha, tetaplah konsisten. Cobalah untuk mulai menjalani ibadah sunnah lainnya seperti, sholat tahajud dan puasa sunnah.', 'SB', 'Kamu mengikuti kegiatan pembelajaran keagamaan di sekolah dengan sangat baik. Melaksanakan salat 5 (lima) waktu dengan baik. Kamu selalu hadir mengikuti BTQ dan tahfiz. Kamu telah menyelesaikan hafalan seluruh surat di juz 29. Kamu sudah melaksanakan sholat dhuha, tetaplah konsisten. Cobalah untuk mulai menjalani ibadah sunnah lainnya seperti, sholat tahajud dan puasa sunnah.', 'SB');


#
# TABLE STRUCTURE FOR: t_catatan_kl2
#

DROP TABLE IF EXISTS `t_catatan_kl2`;

CREATE TABLE `t_catatan_kl2` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `capaian_mid` varchar(5) NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  `capaian_final` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_kl2` (`id`, `id_siswa`, `ta`, `catatan_mid`, `capaian_mid`, `catatan_final`, `capaian_final`) VALUES (5, 531, '20232', '-', '-', '-', '-');
INSERT INTO `t_catatan_kl2` (`id`, `id_siswa`, `ta`, `catatan_mid`, `capaian_mid`, `catatan_final`, `capaian_final`) VALUES (6, 532, '20232', '-', '-', 'Kamu adalah pribadi yang mudah bergaul, bisa bekerjasama dengan baik, dan aktif berorganisasi. Kamu memiliki jiwa sosial yang baik dan sering membantu teman-temanmu. Teruslah berinisiatif dalam membangun hubungan sosial yang positif dengan teman-temanmu.', 'SB');


#
# TABLE STRUCTURE FOR: t_catatan_kog
#

DROP TABLE IF EXISTS `t_catatan_kog`;

CREATE TABLE `t_catatan_kog` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_kog` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (1, 531, '20232', 'test', 't-');
INSERT INTO `t_catatan_kog` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (2, 532, '20232', 'testest', '-');


#
# TABLE STRUCTURE FOR: t_catatan_nna
#

DROP TABLE IF EXISTS `t_catatan_nna`;

CREATE TABLE `t_catatan_nna` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext NOT NULL,
  `catatan_final` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_nna` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (1, 531, '20232', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1\npage 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha\') . She is also\nable to recite ta\'awwuz before reading iqra and recite shodaqallahul adzim after\nending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah\n, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa\nkedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She\nis also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat\nadalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she\nis able to mention the name of the god of Muslims, namely Allah SWT and the name\nof the Prophet, namely Prophet Muhammad SAW. She is also able to mention the\nsequence of wudhu while playing games. She has learned of some names of Nabi\nand malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS\nand Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman\nuntil al-qahhar by singing and started to be able to memorize it until al- qahhar with\nteacher’s guidance. ', 'Akila needs encouragement in\r\nparticipating daily dua in the\r\nclassroom also for murojaah time.\r\nShe still needs to be more focused\r\non reading iqra when btq. She also\r\nneed more practice in memorizing\r\ndoa masuk kamar mandi, doa keluar\r\nkamar mandi, doa bangun tidur. Akila\r\nneeds practice to memorize hijaiyah\r\nletters. She needs more practice to\r\nrecognize halal and haram food.\r\nAkila also needs more practice to tidy\r\nup her prayer set. ');
INSERT INTO `t_catatan_nna` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (2, 532, '20232', 'Alhamdulillah Aldevaro&rsquo;s Islamic values have improved as expected. Alhamdulillah,\nAldevaro is in iqra 1 page 12. Aldevaro is able to recognize hijaiyah letters ا until ذ , . د\nHe is also able to recite ta`awwuz before reading iqra and recite shodaqallahul adzim\nafter ending. He is able to follow kalimat thayyibah such as : alhamdulillah,\nastaghfirullah, subhanallah, allahu akbar. Aldevaro is also able to recite some du&rsquo;a,\nthey are : doa kedua orang tua, doa pembuka hati, doa before study , doa sebelum\ntidur, doa sebelum makan dan doa setelah makan. He is also able to recite hadith\nkasih sayang, hadith adab makan, and hadith sholat adalah cahaya independently.\nFrom Imtaq Center, he is able to mention the name of the god of Muslims, namely\nAllah SWT and the name of the Prophet, namely Prophet Muhammad SAW. He is\nalso able to mention the sequence of wudhu while playing games. He is also aware\nof some names of Nabi and malaikat Allah from the stories like Nabi Muhammad\nSAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Aldevaro has learned about Asmaul\nHusna which are ar-rahman until al-qahhar by singing and start to be able to\nmemorize it until al qahhar He is able to mention table manners in Islam. Aldevaro is\nable to recognize halal and haram food. ', '-');


#
# TABLE STRUCTURE FOR: t_catatan_sek
#

DROP TABLE IF EXISTS `t_catatan_sek`;

CREATE TABLE `t_catatan_sek` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) CHARACTER SET latin1 NOT NULL,
  `catatan_mid` longtext CHARACTER SET latin1 NOT NULL,
  `catatan_final` longtext CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `t_catatan_sek` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (1, 531, '20232', '-', '-');
INSERT INTO `t_catatan_sek` (`id`, `id_siswa`, `ta`, `catatan_mid`, `catatan_final`) VALUES (2, 532, '20232', '-', '-');


#
# TABLE STRUCTURE FOR: t_guru_mapel
#

DROP TABLE IF EXISTS `t_guru_mapel`;

CREATE TABLE `t_guru_mapel` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) DEFAULT NULL,
  `id_guru` int(3) NOT NULL,
  `id_kelas` int(3) NOT NULL,
  `id_mapel` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_guru` (`id_guru`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_mapel` (`id_mapel`),
  CONSTRAINT `FK_t_guru_mapel_m_guru` FOREIGN KEY (`id_guru`) REFERENCES `m_guru` (`id`),
  CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`),
  CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (1, '20232', 12, 8, 20);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (3, '20232', 12, 8, 21);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (4, '20232', 13, 8, 30);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (5, '20232', 13, 8, 31);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (6, '20232', 13, 8, 32);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (7, '20232', 13, 8, 33);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (8, '20232', 13, 8, 34);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (9, '20232', 13, 8, 35);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (14, '20232', 12, 8, 37);
INSERT INTO `t_guru_mapel` (`id`, `tasm`, `id_guru`, `id_kelas`, `id_mapel`) VALUES (15, '20232', 12, 8, 36);


#
# TABLE STRUCTURE FOR: t_kelas_siswa
#

DROP TABLE IF EXISTS `t_kelas_siswa`;

CREATE TABLE `t_kelas_siswa` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_kelas` int(5) NOT NULL,
  `id_siswa` int(5) NOT NULL,
  `ta` year(4) NOT NULL,
  PRIMARY KEY (`id_kelas`,`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`),
  CONSTRAINT `t_kelas_siswa_ibfk_2` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `t_kelas_siswa` (`id`, `id_kelas`, `id_siswa`, `ta`) VALUES (6, 8, 531, '2023');
INSERT INTO `t_kelas_siswa` (`id`, `id_kelas`, `id_siswa`, `ta`) VALUES (7, 8, 532, '2023');


#
# TABLE STRUCTURE FOR: t_kkm
#

DROP TABLE IF EXISTS `t_kkm`;

CREATE TABLE `t_kkm` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ta` int(4) NOT NULL,
  `jenis` enum('np','nk') NOT NULL,
  `kelas` int(2) NOT NULL,
  `kkm` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_mapel_kd
#

DROP TABLE IF EXISTS `t_mapel_kd`;

CREATE TABLE `t_mapel_kd` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `id_guru` int(6) unsigned NOT NULL DEFAULT 0,
  `id_mapel` int(6) NOT NULL,
  `tingkat` int(2) NOT NULL,
  `semester` enum('0','1','2') NOT NULL,
  `mid_final` int(2) DEFAULT NULL,
  `no_kd` varchar(5) NOT NULL,
  `jenis` enum('P','K','SSp','SSo') NOT NULL,
  `bobot` int(2) NOT NULL,
  `nama_kd` text NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_guru` (`id_guru`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=latin1;

INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'jujur');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (2, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'disiplin');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (3, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'tanggung jawab');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (4, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'toleransi');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (5, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'gotong royong');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (6, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'santun');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (7, 0, 0, 0, '0', NULL, '', 'SSo', 0, 'percaya diri');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (8, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'berdoa sebelum dan sesudah melakukan kegiatan		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (9, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'menjalankan ibadah sesuai dengan agamanya');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (10, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'memberi salam pada saat awal dan akhir kegiatan		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (11, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'bersyukur atas nikmat dan karunia Tuhan Yang Maha Esa		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (12, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'mensyukuri kemampuan manusia dalam mengendalikan diri		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (13, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'bersyukur ketika berhasil mengerjakan sesuatu		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (14, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'berserah diri (tawakal) kepada Tuhan setelah berikhtiar atau melakukan usaha		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (15, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'memelihara hubungan baik dengan sesama umat		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (16, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'bersyukur sebagai bangsa Indonesia		');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (17, 0, 0, 0, '0', NULL, '', 'SSp', 0, 'menghormati orang lain yang menjalankan ibadah sesuai dengan agamanya		\r\n');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (20, 0, 0, 0, '0', NULL, '0', 'P', 0, 'Semester');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (99, 12, 20, 8, '2', 1, '3.1', 'P', 0, 'Memahami dan menganalisis makna kontrol diri, prasangka baik, dan persaudaraan berdasarkan surah Al-Hujurat/49:10-12');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (100, 12, 20, 8, '2', 1, '3.2', 'P', 0, 'Menganalisis Q.S. Al-Isra’/17:32, dan Q.S. An-Nur/24:2 tentang menjauhi pergaulan bebas dan larangan mendekati zina');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (101, 12, 20, 8, '2', NULL, '3.3', 'P', 0, 'Menganalisis dan menyajikan hubungan beriman kepada malaikat dengan Asmaul Husna');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (102, 12, 20, 8, '2', NULL, '3.4', 'P', 0, 'Menganalisis dan menjelaskan tata cara berpakaian sesuai syariat Islam dan contoh perilaku jujur dalam kehidupan sehari-hari');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (103, 12, 20, 8, '2', NULL, '3.5', 'P', 0, 'Menganalisis keterkaitan antara kewajiban menuntut ilmu dengan kewajiban membela agama serta menganalisis macam-macam sumber hukum Islam');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (104, 12, 20, 8, '2', 1, '4.1', 'K', 0, 'Menganalisis keterkaitan antara kewajiban menuntut ilmu dengan kewajiban membela agama serta menganalisis macam-macam sumber hukum Islam');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (105, 12, 21, 8, '2', NULL, '3.1', 'P', 0, 'test');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (114, 13, 30, 8, '2', NULL, '1', 'P', 0, 'Performs Zuhr and Asr prayers on time and jamaah');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (115, 13, 30, 8, '2', NULL, '2', 'P', 0, 'Performs 5 times daily prayers');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (116, 13, 33, 8, '2', NULL, '1', 'P', 0, 'Demonstrates self-confidence and independence');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (117, 13, 33, 8, '2', NULL, '2', 'P', 0, 'Appreciates other\'s opinion ');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (118, 13, 34, 8, '2', NULL, '1', 'P', 0, 'Cooperative in class activities');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (119, 13, 34, 8, '2', NULL, '2', 'P', 0, 'Shows enthusiasm and curiosity during the lesson');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (120, 13, 35, 8, '2', NULL, '1', 'P', 0, 'Cooperative in class activities');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (121, 13, 35, 8, '2', NULL, '2', 'P', 0, 'Shows enthusiasm and curiosity during the lesson');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (126, 13, 31, 8, '2', NULL, '1', 'P', 0, 'Performs Zuhr and Asr prayers on time and jamaah');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (127, 13, 32, 8, '2', NULL, '1', 'P', 0, 'Demonstrates self-confidence and independence');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (128, 12, 36, 8, '2', 1, '1.1', 'P', 0, 'Membilang 1 - 20');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (129, 12, 36, 8, '2', 1, '1.2', 'P', 0, 'Mencocokkan bilangan dengan lambang bilangan');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (130, 12, 37, 8, '2', 1, '3.1', 'P', 0, 'Menyebutkan lafadz Allah, Muhammad SAW dan Al Qur\'an');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (131, 12, 37, 8, '2', 1, '3.2', 'P', 0, 'Melafalkan syahadat dengan baik');
INSERT INTO `t_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `mid_final`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (132, 12, 37, 8, '2', 1, '3.3', 'P', 0, 'Mengenal kalimah thayyibah dan maknanya: takbir (allahuakbar), tahmid (alhamdulillah), tasbih (subhanallah), tahlil (laa ilaaha illallahu) dan istighfar (astaghfirullahal ‘adzim)');


#
# TABLE STRUCTURE FOR: t_naikkelas
#

DROP TABLE IF EXISTS `t_naikkelas`;

CREATE TABLE `t_naikkelas` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `naik` enum('Y','N') NOT NULL,
  `catatan_wali` longtext NOT NULL,
  `catatan_wali_final` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_naikkelas` (`id`, `id_siswa`, `ta`, `naik`, `catatan_wali`, `catatan_wali_final`) VALUES (1, 531, '20232', 'Y', '-', '-');
INSERT INTO `t_naikkelas` (`id`, `id_siswa`, `ta`, `naik`, `catatan_wali`, `catatan_wali_final`) VALUES (2, 532, '20232', 'Y', 'Karakteristik siswa dalam menggali memahami pengetahuan masih memerlukan peningkatan konsentrasi dan motivasi sehingga masih diperlukan bimbingan dari orang tua untuk meningkakan motivasi,', 'salludin gozali');


#
# TABLE STRUCTURE FOR: t_nilai
#

DROP TABLE IF EXISTS `t_nilai`;

CREATE TABLE `t_nilai` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL DEFAULT '0',
  `jenis` enum('h','t','a','c') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` int(6) NOT NULL,
  `catatan` text DEFAULT NULL,
  `catatan_mid` text DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=497 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (350, '20232', '', 1, 20, 0, 90, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (352, '20232', 'h', 1, 0, 0, 90, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (484, '20232', 'h', 1, 99, 531, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (492, '20232', 'h', 1, 99, 532, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (485, '20232', 'h', 1, 100, 531, 90, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (493, '20232', 'h', 1, 100, 532, 90, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (486, '20232', 'h', 1, 101, 531, 70, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (494, '20232', 'h', 1, 101, 532, 70, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (487, '20232', 'h', 1, 102, 531, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (495, '20232', 'h', 1, 102, 532, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (488, '20232', 'h', 1, 103, 531, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (496, '20232', 'h', 1, 103, 532, 80, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (410, '20232', 'h', 12, 128, 531, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (413, '20232', 'h', 12, 128, 532, 3, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (411, '20232', 'h', 12, 129, 531, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (414, '20232', 'h', 12, 129, 532, 2, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (416, '20232', 'h', 14, 130, 531, 3, NULL, NULL);
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (415, '20232', 'h', 14, 130, 532, 4, NULL, NULL);
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (348, '20232', 't', 1, 20, 0, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (481, '20232', 't', 1, 20, 531, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (489, '20232', 't', 1, 20, 532, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (349, '20232', 'a', 1, 20, 0, 90, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (482, '20232', 'a', 1, 20, 531, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (490, '20232', 'a', 1, 20, 532, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (351, '20232', 'c', 1, 20, 0, 0, 'Kamu telah a', 'Kamu telah b');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (483, '20232', 'c', 1, 20, 531, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (491, '20232', 'c', 1, 20, 532, 0, '', '');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (409, '20232', 'c', 12, 36, 531, 0, 'h-128', '531');
INSERT INTO `t_nilai` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (412, '20232', 'c', 12, 36, 532, 0, 'h-128', '532');


#
# TABLE STRUCTURE FOR: t_nilai_absensi
#

DROP TABLE IF EXISTS `t_nilai_absensi`;

CREATE TABLE `t_nilai_absensi` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `s` int(3) NOT NULL,
  `i` int(3) NOT NULL,
  `a` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_siswa` (`id_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_absensi` (`id`, `tasm`, `id_siswa`, `s`, `i`, `a`) VALUES (1, '20232', 531, 0, 0, 0);
INSERT INTO `t_nilai_absensi` (`id`, `tasm`, `id_siswa`, `s`, `i`, `a`) VALUES (2, '20232', 532, 0, 0, 0);


#
# TABLE STRUCTURE FOR: t_nilai_cat
#

DROP TABLE IF EXISTS `t_nilai_cat`;

CREATE TABLE `t_nilai_cat` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `jenis` enum('c') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` text CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci DEFAULT NULL,
  `nilai_mid` text CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`) USING BTREE,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (26, '20232', 'c', 1, 20, 531, 'Syifa', 'dfdfgdfgf');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (24, '20232', 'c', 1, 20, 532, 'Salludin Gozali', 'gfdgfdg');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (38, '20232', 'c', 3, 21, 531, '-', '-');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (37, '20232', 'c', 3, 21, 532, '-', '-');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (36, '20232', 'c', 12, 36, 531, '-', '-');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (34, '20232', 'c', 12, 36, 532, '-', 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1 page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha’) . She is also able to recite ta’awwuz before reading iqra and recite shodaqallahul adzim after ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah , subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she is able to mention the name of the god of Muslims, namely Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the sequence of wudhu while playing games. She has learned of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman until al-qahhar by singing and started to be able to memorize it until al- qahhar with teacher’s guidance.');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (40, '20232', 'c', 14, 37, 531, 'alhamdulillah', 'alhamdulillah');
INSERT INTO `t_nilai_cat` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `nilai_mid`) VALUES (39, '20232', 'c', 14, 37, 532, 'test', 'test');


#
# TABLE STRUCTURE FOR: t_nilai_ekstra
#

DROP TABLE IF EXISTS `t_nilai_ekstra`;

CREATE TABLE `t_nilai_ekstra` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) DEFAULT NULL,
  `id_ekstra` int(3) DEFAULT NULL,
  `id_siswa` int(6) DEFAULT NULL,
  `nilai` char(2) DEFAULT NULL,
  `desk` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ekstra` (`id_ekstra`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`),
  CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`id_ekstra`) REFERENCES `m_ekstra` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_ekstra` (`id`, `tasm`, `id_ekstra`, `id_siswa`, `nilai`, `desk`) VALUES (1, '20232', 10, 531, '-', '-');
INSERT INTO `t_nilai_ekstra` (`id`, `tasm`, `id_ekstra`, `id_siswa`, `nilai`, `desk`) VALUES (2, '20232', 10, 532, 'A', 'sangat rajin sangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsangat rajinsa');


#
# TABLE STRUCTURE FOR: t_nilai_icb
#

DROP TABLE IF EXISTS `t_nilai_icb`;

CREATE TABLE `t_nilai_icb` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `jenis` enum('h') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` text DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`) USING BTREE,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (169, '20232', 'h', 4, 114, 531, '1');
INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (171, '20232', 'h', 4, 114, 532, '1');
INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (170, '20232', 'h', 4, 115, 531, '1');
INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (172, '20232', 'h', 4, 115, 532, '3');
INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (174, '20232', 'h', 5, 126, 531, '2');
INSERT INTO `t_nilai_icb` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (173, '20232', 'h', 5, 126, 532, '2');


#
# TABLE STRUCTURE FOR: t_nilai_ket
#

DROP TABLE IF EXISTS `t_nilai_ket`;

CREATE TABLE `t_nilai_ket` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `jenis` enum('h','t','a','p','c') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` int(6) NOT NULL,
  `catatan` text DEFAULT NULL,
  `catatan_mid` text DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`) USING BTREE,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (48, '20232', 'h', 1, 104, 531, 90, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (53, '20232', 'h', 1, 104, 532, 90, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (44, '20232', 't', 1, 20, 531, 90, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (49, '20232', 't', 1, 20, 532, 0, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (45, '20232', 'a', 1, 20, 531, 0, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (50, '20232', 'a', 1, 20, 532, 90, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (46, '20232', 'p', 1, 20, 531, 0, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (51, '20232', 'p', 1, 20, 532, 90, '', '');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (47, '20232', 'c', 1, 20, 531, 0, 'Kamu telah a', 'Kamu telah bb');
INSERT INTO `t_nilai_ket` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`, `catatan`, `catatan_mid`) VALUES (52, '20232', 'c', 1, 20, 532, 0, 'Kamu telah a', 'Kamu telah b');


#
# TABLE STRUCTURE FOR: t_nilai_la
#

DROP TABLE IF EXISTS `t_nilai_la`;

CREATE TABLE `t_nilai_la` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `jenis` enum('h') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` text DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`) USING BTREE,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (13, '20232', 'h', 8, 118, 531, '3');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (15, '20232', 'h', 8, 118, 532, '1');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (14, '20232', 'h', 8, 119, 531, '2');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (16, '20232', 'h', 8, 119, 532, '3');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (18, '20232', 'h', 9, 120, 531, '3');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (17, '20232', 'h', 9, 120, 532, '3');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (20, '20232', 'h', 9, 121, 531, '3');
INSERT INTO `t_nilai_la` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (19, '20232', 'h', 9, 121, 532, '3');


#
# TABLE STRUCTURE FOR: t_nilai_pss
#

DROP TABLE IF EXISTS `t_nilai_pss`;

CREATE TABLE `t_nilai_pss` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) NOT NULL,
  `jenis` enum('h') NOT NULL,
  `id_guru_mapel` int(6) NOT NULL,
  `id_mapel_kd` int(6) NOT NULL,
  `id_siswa` int(6) NOT NULL,
  `nilai` text DEFAULT NULL,
  PRIMARY KEY (`tasm`,`jenis`,`id_guru_mapel`,`id_mapel_kd`,`id_siswa`) USING BTREE,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (10, '20232', 'h', 6, 127, 531, '2');
INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (9, '20232', 'h', 6, 127, 532, '2');
INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (5, '20232', 'h', 7, 116, 531, '2');
INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (7, '20232', 'h', 7, 116, 532, '3');
INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (6, '20232', 'h', 7, 117, 531, '3');
INSERT INTO `t_nilai_pss` (`id`, `tasm`, `jenis`, `id_guru_mapel`, `id_mapel_kd`, `id_siswa`, `nilai`) VALUES (8, '20232', 'h', 7, 117, 532, '1');


#
# TABLE STRUCTURE FOR: t_nilai_sikap_so
#

DROP TABLE IF EXISTS `t_nilai_sikap_so`;

CREATE TABLE `t_nilai_sikap_so` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) DEFAULT NULL,
  `id_kelas` int(6) DEFAULT NULL,
  `id_siswa` int(6) DEFAULT NULL,
  `is_wali` enum('Y','N') DEFAULT NULL,
  `selalu` varchar(50) DEFAULT NULL,
  `mulai_meningkat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_guru_mapel` (`id_kelas`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `FK_t_nilai_sikap_so_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_sikap_so` (`id`, `tasm`, `id_kelas`, `id_siswa`, `is_wali`, `selalu`, `mulai_meningkat`) VALUES (1, '20232', 8, 531, 'Y', '1,2,3', '4');
INSERT INTO `t_nilai_sikap_so` (`id`, `tasm`, `id_kelas`, `id_siswa`, `is_wali`, `selalu`, `mulai_meningkat`) VALUES (2, '20232', 8, 532, 'Y', '1,2,3', '4');


#
# TABLE STRUCTURE FOR: t_nilai_sikap_sp
#

DROP TABLE IF EXISTS `t_nilai_sikap_sp`;

CREATE TABLE `t_nilai_sikap_sp` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) DEFAULT NULL,
  `id_kelas` int(6) DEFAULT NULL,
  `id_siswa` int(6) DEFAULT NULL,
  `is_wali` enum('Y','N') DEFAULT NULL,
  `selalu` varchar(50) DEFAULT NULL,
  `mulai_meningkat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_guru_mapel` (`id_kelas`),
  KEY `id_siswa` (`id_siswa`),
  CONSTRAINT `FK_t_nilai_sikap_sp_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_nilai_sikap_sp` (`id`, `tasm`, `id_kelas`, `id_siswa`, `is_wali`, `selalu`, `mulai_meningkat`) VALUES (1, '20232', 8, 531, 'Y', '8-9', '10');
INSERT INTO `t_nilai_sikap_sp` (`id`, `tasm`, `id_kelas`, `id_siswa`, `is_wali`, `selalu`, `mulai_meningkat`) VALUES (2, '20232', 8, 532, 'Y', '8-9', '10');


#
# TABLE STRUCTURE FOR: t_prestasi
#

DROP TABLE IF EXISTS `t_prestasi`;

CREATE TABLE `t_prestasi` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `t_prestasi` (`id`, `id_siswa`, `ta`, `jenis`, `keterangan`) VALUES (2, 532, '20232', 'Siswa terbaik', 'ananda menjadi siswa terbaik dan tercerdas ananda menjadi siswa terbaik dan tercerdas ananda menjadi');


#
# TABLE STRUCTURE FOR: t_walikelas
#

DROP TABLE IF EXISTS `t_walikelas`;

CREATE TABLE `t_walikelas` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tasm` varchar(5) DEFAULT NULL,
  `id_guru` int(2) DEFAULT NULL,
  `id_kelas` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_guru` (`id_guru`),
  KEY `id_kelas` (`id_kelas`),
  CONSTRAINT `FK_t_walikelas_m_guru` FOREIGN KEY (`id_guru`) REFERENCES `m_guru` (`id`),
  CONSTRAINT `FK_t_walikelas_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `t_walikelas` (`id`, `tasm`, `id_guru`, `id_kelas`) VALUES (3, '2023', 13, 8);


#
# TABLE STRUCTURE FOR: tahun
#

DROP TABLE IF EXISTS `tahun`;

CREATE TABLE `tahun` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(5) NOT NULL,
  `aktif` enum('Y','N') NOT NULL,
  `nama_kepsek` varchar(50) NOT NULL,
  `nip_kepsek` varchar(30) NOT NULL,
  `tgl_raport` date NOT NULL,
  `tgl_raport_kelas3` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tahun` (`id`, `tahun`, `aktif`, `nama_kepsek`, `nip_kepsek`, `tgl_raport`, `tgl_raport_kelas3`) VALUES (1, '20232', 'Y', 'Alvianica Nanda', '-', '2023-06-15', '2023-06-15');
INSERT INTO `tahun` (`id`, `tahun`, `aktif`, `nama_kepsek`, `nip_kepsek`, `tgl_raport`, `tgl_raport_kelas3`) VALUES (2, '20231', 'N', 'Muhammad Irzal', '-', '2023-01-13', '2023-01-13');


