<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-22 08:51:33 --> Config Class Initialized
INFO - 2023-10-22 08:51:33 --> Hooks Class Initialized
DEBUG - 2023-10-22 08:51:33 --> UTF-8 Support Enabled
INFO - 2023-10-22 08:51:33 --> Utf8 Class Initialized
INFO - 2023-10-22 08:51:33 --> URI Class Initialized
INFO - 2023-10-22 08:51:33 --> Router Class Initialized
INFO - 2023-10-22 08:51:33 --> Output Class Initialized
INFO - 2023-10-22 08:51:33 --> Security Class Initialized
DEBUG - 2023-10-22 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 08:51:33 --> Input Class Initialized
INFO - 2023-10-22 08:51:33 --> Language Class Initialized
INFO - 2023-10-22 08:51:33 --> Language Class Initialized
INFO - 2023-10-22 08:51:33 --> Config Class Initialized
INFO - 2023-10-22 08:51:33 --> Loader Class Initialized
INFO - 2023-10-22 08:51:33 --> Helper loaded: url_helper
INFO - 2023-10-22 08:51:33 --> Helper loaded: file_helper
INFO - 2023-10-22 08:51:33 --> Helper loaded: form_helper
INFO - 2023-10-22 08:51:33 --> Helper loaded: my_helper
INFO - 2023-10-22 08:51:33 --> Database Driver Class Initialized
INFO - 2023-10-22 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 08:51:33 --> Controller Class Initialized
DEBUG - 2023-10-22 08:51:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-22 08:51:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-22 08:51:33 --> Final output sent to browser
DEBUG - 2023-10-22 08:51:33 --> Total execution time: 0.1414
INFO - 2023-10-22 08:52:05 --> Config Class Initialized
INFO - 2023-10-22 08:52:05 --> Hooks Class Initialized
DEBUG - 2023-10-22 08:52:05 --> UTF-8 Support Enabled
INFO - 2023-10-22 08:52:05 --> Utf8 Class Initialized
INFO - 2023-10-22 08:52:05 --> URI Class Initialized
DEBUG - 2023-10-22 08:52:05 --> No URI present. Default controller set.
INFO - 2023-10-22 08:52:05 --> Router Class Initialized
INFO - 2023-10-22 08:52:05 --> Output Class Initialized
INFO - 2023-10-22 08:52:05 --> Security Class Initialized
DEBUG - 2023-10-22 08:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 08:52:05 --> Input Class Initialized
INFO - 2023-10-22 08:52:05 --> Language Class Initialized
INFO - 2023-10-22 08:52:05 --> Language Class Initialized
INFO - 2023-10-22 08:52:05 --> Config Class Initialized
INFO - 2023-10-22 08:52:05 --> Loader Class Initialized
INFO - 2023-10-22 08:52:05 --> Helper loaded: url_helper
INFO - 2023-10-22 08:52:05 --> Helper loaded: file_helper
INFO - 2023-10-22 08:52:05 --> Helper loaded: form_helper
INFO - 2023-10-22 08:52:05 --> Helper loaded: my_helper
INFO - 2023-10-22 08:52:05 --> Database Driver Class Initialized
INFO - 2023-10-22 08:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 08:52:05 --> Controller Class Initialized
INFO - 2023-10-22 08:52:08 --> Config Class Initialized
INFO - 2023-10-22 08:52:08 --> Hooks Class Initialized
DEBUG - 2023-10-22 08:52:08 --> UTF-8 Support Enabled
INFO - 2023-10-22 08:52:08 --> Utf8 Class Initialized
INFO - 2023-10-22 08:52:08 --> URI Class Initialized
INFO - 2023-10-22 08:52:08 --> Router Class Initialized
INFO - 2023-10-22 08:52:08 --> Output Class Initialized
INFO - 2023-10-22 08:52:08 --> Security Class Initialized
DEBUG - 2023-10-22 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 08:52:08 --> Input Class Initialized
INFO - 2023-10-22 08:52:08 --> Language Class Initialized
INFO - 2023-10-22 08:52:08 --> Language Class Initialized
INFO - 2023-10-22 08:52:08 --> Config Class Initialized
INFO - 2023-10-22 08:52:08 --> Loader Class Initialized
INFO - 2023-10-22 08:52:08 --> Helper loaded: url_helper
INFO - 2023-10-22 08:52:08 --> Helper loaded: file_helper
INFO - 2023-10-22 08:52:08 --> Helper loaded: form_helper
INFO - 2023-10-22 08:52:08 --> Helper loaded: my_helper
INFO - 2023-10-22 08:52:08 --> Database Driver Class Initialized
INFO - 2023-10-22 08:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 08:52:08 --> Controller Class Initialized
DEBUG - 2023-10-22 08:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-22 08:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-22 08:52:08 --> Final output sent to browser
DEBUG - 2023-10-22 08:52:08 --> Total execution time: 0.0758
INFO - 2023-10-22 08:52:19 --> Config Class Initialized
INFO - 2023-10-22 08:52:19 --> Hooks Class Initialized
DEBUG - 2023-10-22 08:52:19 --> UTF-8 Support Enabled
INFO - 2023-10-22 08:52:19 --> Utf8 Class Initialized
INFO - 2023-10-22 08:52:19 --> URI Class Initialized
DEBUG - 2023-10-22 08:52:19 --> No URI present. Default controller set.
INFO - 2023-10-22 08:52:19 --> Router Class Initialized
INFO - 2023-10-22 08:52:19 --> Output Class Initialized
INFO - 2023-10-22 08:52:19 --> Security Class Initialized
DEBUG - 2023-10-22 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 08:52:19 --> Input Class Initialized
INFO - 2023-10-22 08:52:19 --> Language Class Initialized
INFO - 2023-10-22 08:52:19 --> Language Class Initialized
INFO - 2023-10-22 08:52:19 --> Config Class Initialized
INFO - 2023-10-22 08:52:19 --> Loader Class Initialized
INFO - 2023-10-22 08:52:19 --> Helper loaded: url_helper
INFO - 2023-10-22 08:52:19 --> Helper loaded: file_helper
INFO - 2023-10-22 08:52:19 --> Helper loaded: form_helper
INFO - 2023-10-22 08:52:19 --> Helper loaded: my_helper
INFO - 2023-10-22 08:52:19 --> Database Driver Class Initialized
INFO - 2023-10-22 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 08:52:19 --> Controller Class Initialized
INFO - 2023-10-22 08:52:32 --> Config Class Initialized
INFO - 2023-10-22 08:52:32 --> Hooks Class Initialized
DEBUG - 2023-10-22 08:52:32 --> UTF-8 Support Enabled
INFO - 2023-10-22 08:52:32 --> Utf8 Class Initialized
INFO - 2023-10-22 08:52:32 --> URI Class Initialized
INFO - 2023-10-22 08:52:32 --> Router Class Initialized
INFO - 2023-10-22 08:52:32 --> Output Class Initialized
INFO - 2023-10-22 08:52:32 --> Security Class Initialized
DEBUG - 2023-10-22 08:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-22 08:52:32 --> Input Class Initialized
INFO - 2023-10-22 08:52:32 --> Language Class Initialized
INFO - 2023-10-22 08:52:32 --> Language Class Initialized
INFO - 2023-10-22 08:52:32 --> Config Class Initialized
INFO - 2023-10-22 08:52:32 --> Loader Class Initialized
INFO - 2023-10-22 08:52:32 --> Helper loaded: url_helper
INFO - 2023-10-22 08:52:32 --> Helper loaded: file_helper
INFO - 2023-10-22 08:52:32 --> Helper loaded: form_helper
INFO - 2023-10-22 08:52:32 --> Helper loaded: my_helper
INFO - 2023-10-22 08:52:32 --> Database Driver Class Initialized
INFO - 2023-10-22 08:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-22 08:52:32 --> Controller Class Initialized
DEBUG - 2023-10-22 08:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-22 08:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-22 08:52:32 --> Final output sent to browser
DEBUG - 2023-10-22 08:52:32 --> Total execution time: 0.0483
