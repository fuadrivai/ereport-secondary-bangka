<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-02 16:42:19 --> Config Class Initialized
INFO - 2024-12-02 16:42:19 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:19 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:19 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:19 --> URI Class Initialized
INFO - 2024-12-02 16:42:19 --> Router Class Initialized
INFO - 2024-12-02 16:42:19 --> Output Class Initialized
INFO - 2024-12-02 16:42:19 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:19 --> Input Class Initialized
INFO - 2024-12-02 16:42:19 --> Language Class Initialized
INFO - 2024-12-02 16:42:19 --> Language Class Initialized
INFO - 2024-12-02 16:42:19 --> Config Class Initialized
INFO - 2024-12-02 16:42:19 --> Loader Class Initialized
INFO - 2024-12-02 16:42:19 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:19 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:19 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:19 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:19 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:19 --> Controller Class Initialized
INFO - 2024-12-02 16:42:19 --> Helper loaded: cookie_helper
INFO - 2024-12-02 16:42:19 --> Final output sent to browser
DEBUG - 2024-12-02 16:42:19 --> Total execution time: 0.2276
INFO - 2024-12-02 16:42:20 --> Config Class Initialized
INFO - 2024-12-02 16:42:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:20 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:20 --> URI Class Initialized
INFO - 2024-12-02 16:42:20 --> Router Class Initialized
INFO - 2024-12-02 16:42:20 --> Output Class Initialized
INFO - 2024-12-02 16:42:20 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:20 --> Input Class Initialized
INFO - 2024-12-02 16:42:20 --> Language Class Initialized
INFO - 2024-12-02 16:42:20 --> Language Class Initialized
INFO - 2024-12-02 16:42:20 --> Config Class Initialized
INFO - 2024-12-02 16:42:20 --> Loader Class Initialized
INFO - 2024-12-02 16:42:20 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:20 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:20 --> Controller Class Initialized
INFO - 2024-12-02 16:42:20 --> Helper loaded: cookie_helper
INFO - 2024-12-02 16:42:20 --> Config Class Initialized
INFO - 2024-12-02 16:42:20 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:20 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:20 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:20 --> URI Class Initialized
INFO - 2024-12-02 16:42:20 --> Router Class Initialized
INFO - 2024-12-02 16:42:20 --> Output Class Initialized
INFO - 2024-12-02 16:42:20 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:20 --> Input Class Initialized
INFO - 2024-12-02 16:42:20 --> Language Class Initialized
INFO - 2024-12-02 16:42:20 --> Language Class Initialized
INFO - 2024-12-02 16:42:20 --> Config Class Initialized
INFO - 2024-12-02 16:42:20 --> Loader Class Initialized
INFO - 2024-12-02 16:42:20 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:20 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:20 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:20 --> Controller Class Initialized
DEBUG - 2024-12-02 16:42:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-02 16:42:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-02 16:42:20 --> Final output sent to browser
DEBUG - 2024-12-02 16:42:20 --> Total execution time: 0.0493
INFO - 2024-12-02 16:42:27 --> Config Class Initialized
INFO - 2024-12-02 16:42:27 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:27 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:27 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:27 --> URI Class Initialized
INFO - 2024-12-02 16:42:27 --> Router Class Initialized
INFO - 2024-12-02 16:42:27 --> Output Class Initialized
INFO - 2024-12-02 16:42:27 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:27 --> Input Class Initialized
INFO - 2024-12-02 16:42:27 --> Language Class Initialized
INFO - 2024-12-02 16:42:27 --> Language Class Initialized
INFO - 2024-12-02 16:42:27 --> Config Class Initialized
INFO - 2024-12-02 16:42:27 --> Loader Class Initialized
INFO - 2024-12-02 16:42:27 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:27 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:27 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:27 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:27 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:27 --> Controller Class Initialized
INFO - 2024-12-02 16:42:27 --> Helper loaded: cookie_helper
INFO - 2024-12-02 16:42:27 --> Final output sent to browser
DEBUG - 2024-12-02 16:42:27 --> Total execution time: 0.0368
INFO - 2024-12-02 16:42:28 --> Config Class Initialized
INFO - 2024-12-02 16:42:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:28 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:28 --> URI Class Initialized
INFO - 2024-12-02 16:42:28 --> Router Class Initialized
INFO - 2024-12-02 16:42:28 --> Output Class Initialized
INFO - 2024-12-02 16:42:28 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:28 --> Input Class Initialized
INFO - 2024-12-02 16:42:28 --> Language Class Initialized
INFO - 2024-12-02 16:42:28 --> Language Class Initialized
INFO - 2024-12-02 16:42:28 --> Config Class Initialized
INFO - 2024-12-02 16:42:28 --> Loader Class Initialized
INFO - 2024-12-02 16:42:28 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:28 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:28 --> Controller Class Initialized
INFO - 2024-12-02 16:42:28 --> Helper loaded: cookie_helper
INFO - 2024-12-02 16:42:28 --> Config Class Initialized
INFO - 2024-12-02 16:42:28 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:28 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:28 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:28 --> URI Class Initialized
INFO - 2024-12-02 16:42:28 --> Router Class Initialized
INFO - 2024-12-02 16:42:28 --> Output Class Initialized
INFO - 2024-12-02 16:42:28 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:28 --> Input Class Initialized
INFO - 2024-12-02 16:42:28 --> Language Class Initialized
INFO - 2024-12-02 16:42:28 --> Language Class Initialized
INFO - 2024-12-02 16:42:28 --> Config Class Initialized
INFO - 2024-12-02 16:42:28 --> Loader Class Initialized
INFO - 2024-12-02 16:42:28 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:28 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:28 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:28 --> Controller Class Initialized
DEBUG - 2024-12-02 16:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-02 16:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-02 16:42:28 --> Final output sent to browser
DEBUG - 2024-12-02 16:42:28 --> Total execution time: 0.0369
INFO - 2024-12-02 16:42:29 --> Config Class Initialized
INFO - 2024-12-02 16:42:29 --> Hooks Class Initialized
DEBUG - 2024-12-02 16:42:29 --> UTF-8 Support Enabled
INFO - 2024-12-02 16:42:29 --> Utf8 Class Initialized
INFO - 2024-12-02 16:42:29 --> URI Class Initialized
INFO - 2024-12-02 16:42:29 --> Router Class Initialized
INFO - 2024-12-02 16:42:29 --> Output Class Initialized
INFO - 2024-12-02 16:42:29 --> Security Class Initialized
DEBUG - 2024-12-02 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 16:42:29 --> Input Class Initialized
INFO - 2024-12-02 16:42:29 --> Language Class Initialized
INFO - 2024-12-02 16:42:29 --> Language Class Initialized
INFO - 2024-12-02 16:42:29 --> Config Class Initialized
INFO - 2024-12-02 16:42:29 --> Loader Class Initialized
INFO - 2024-12-02 16:42:29 --> Helper loaded: url_helper
INFO - 2024-12-02 16:42:29 --> Helper loaded: file_helper
INFO - 2024-12-02 16:42:29 --> Helper loaded: form_helper
INFO - 2024-12-02 16:42:29 --> Helper loaded: my_helper
INFO - 2024-12-02 16:42:29 --> Database Driver Class Initialized
INFO - 2024-12-02 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 16:42:29 --> Controller Class Initialized
DEBUG - 2024-12-02 16:42:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 16:42:32 --> Final output sent to browser
DEBUG - 2024-12-02 16:42:32 --> Total execution time: 3.0380
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:51 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:51 --> URI Class Initialized
INFO - 2024-12-02 20:54:51 --> Router Class Initialized
INFO - 2024-12-02 20:54:51 --> Output Class Initialized
INFO - 2024-12-02 20:54:51 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:51 --> Input Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Loader Class Initialized
INFO - 2024-12-02 20:54:51 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:51 --> Database Driver Class Initialized
INFO - 2024-12-02 20:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:54:51 --> Controller Class Initialized
INFO - 2024-12-02 20:54:51 --> Helper loaded: cookie_helper
INFO - 2024-12-02 20:54:51 --> Final output sent to browser
DEBUG - 2024-12-02 20:54:51 --> Total execution time: 0.0730
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:51 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:51 --> URI Class Initialized
INFO - 2024-12-02 20:54:51 --> Router Class Initialized
INFO - 2024-12-02 20:54:51 --> Output Class Initialized
INFO - 2024-12-02 20:54:51 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:51 --> Input Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Loader Class Initialized
INFO - 2024-12-02 20:54:51 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:51 --> Database Driver Class Initialized
INFO - 2024-12-02 20:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:54:51 --> Controller Class Initialized
INFO - 2024-12-02 20:54:51 --> Helper loaded: cookie_helper
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:51 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:51 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:51 --> URI Class Initialized
INFO - 2024-12-02 20:54:51 --> Router Class Initialized
INFO - 2024-12-02 20:54:51 --> Output Class Initialized
INFO - 2024-12-02 20:54:51 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:51 --> Input Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Language Class Initialized
INFO - 2024-12-02 20:54:51 --> Config Class Initialized
INFO - 2024-12-02 20:54:51 --> Loader Class Initialized
INFO - 2024-12-02 20:54:51 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:51 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:51 --> Database Driver Class Initialized
INFO - 2024-12-02 20:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:54:51 --> Controller Class Initialized
DEBUG - 2024-12-02 20:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-02 20:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-02 20:54:51 --> Final output sent to browser
DEBUG - 2024-12-02 20:54:51 --> Total execution time: 0.0440
INFO - 2024-12-02 20:54:54 --> Config Class Initialized
INFO - 2024-12-02 20:54:54 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:54 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:54 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:54 --> URI Class Initialized
INFO - 2024-12-02 20:54:54 --> Router Class Initialized
INFO - 2024-12-02 20:54:54 --> Output Class Initialized
INFO - 2024-12-02 20:54:54 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:54 --> Input Class Initialized
INFO - 2024-12-02 20:54:54 --> Language Class Initialized
INFO - 2024-12-02 20:54:54 --> Language Class Initialized
INFO - 2024-12-02 20:54:54 --> Config Class Initialized
INFO - 2024-12-02 20:54:54 --> Loader Class Initialized
INFO - 2024-12-02 20:54:54 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:54 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:54 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:54 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:54 --> Database Driver Class Initialized
INFO - 2024-12-02 20:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:54:54 --> Controller Class Initialized
DEBUG - 2024-12-02 20:54:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:54:57 --> Final output sent to browser
DEBUG - 2024-12-02 20:54:57 --> Total execution time: 2.8691
INFO - 2024-12-02 20:54:57 --> Config Class Initialized
INFO - 2024-12-02 20:54:57 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:57 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:57 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:57 --> URI Class Initialized
INFO - 2024-12-02 20:54:57 --> Router Class Initialized
INFO - 2024-12-02 20:54:57 --> Output Class Initialized
INFO - 2024-12-02 20:54:57 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:57 --> Input Class Initialized
INFO - 2024-12-02 20:54:57 --> Language Class Initialized
INFO - 2024-12-02 20:54:57 --> Language Class Initialized
INFO - 2024-12-02 20:54:57 --> Config Class Initialized
INFO - 2024-12-02 20:54:57 --> Loader Class Initialized
INFO - 2024-12-02 20:54:57 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:57 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:57 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:57 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:57 --> Database Driver Class Initialized
INFO - 2024-12-02 20:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:54:57 --> Controller Class Initialized
DEBUG - 2024-12-02 20:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:54:58 --> Config Class Initialized
INFO - 2024-12-02 20:54:58 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:54:58 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:54:58 --> Utf8 Class Initialized
INFO - 2024-12-02 20:54:58 --> URI Class Initialized
INFO - 2024-12-02 20:54:58 --> Router Class Initialized
INFO - 2024-12-02 20:54:58 --> Output Class Initialized
INFO - 2024-12-02 20:54:58 --> Security Class Initialized
DEBUG - 2024-12-02 20:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:54:58 --> Input Class Initialized
INFO - 2024-12-02 20:54:58 --> Language Class Initialized
INFO - 2024-12-02 20:54:58 --> Language Class Initialized
INFO - 2024-12-02 20:54:58 --> Config Class Initialized
INFO - 2024-12-02 20:54:58 --> Loader Class Initialized
INFO - 2024-12-02 20:54:58 --> Helper loaded: url_helper
INFO - 2024-12-02 20:54:58 --> Helper loaded: file_helper
INFO - 2024-12-02 20:54:58 --> Helper loaded: form_helper
INFO - 2024-12-02 20:54:58 --> Helper loaded: my_helper
INFO - 2024-12-02 20:54:58 --> Database Driver Class Initialized
INFO - 2024-12-02 20:55:00 --> Config Class Initialized
INFO - 2024-12-02 20:55:00 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:55:00 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:55:00 --> Utf8 Class Initialized
INFO - 2024-12-02 20:55:00 --> URI Class Initialized
INFO - 2024-12-02 20:55:00 --> Router Class Initialized
INFO - 2024-12-02 20:55:00 --> Output Class Initialized
INFO - 2024-12-02 20:55:00 --> Security Class Initialized
DEBUG - 2024-12-02 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:55:00 --> Input Class Initialized
INFO - 2024-12-02 20:55:00 --> Language Class Initialized
INFO - 2024-12-02 20:55:00 --> Language Class Initialized
INFO - 2024-12-02 20:55:00 --> Config Class Initialized
INFO - 2024-12-02 20:55:00 --> Loader Class Initialized
INFO - 2024-12-02 20:55:00 --> Helper loaded: url_helper
INFO - 2024-12-02 20:55:00 --> Helper loaded: file_helper
INFO - 2024-12-02 20:55:00 --> Helper loaded: form_helper
INFO - 2024-12-02 20:55:00 --> Helper loaded: my_helper
INFO - 2024-12-02 20:55:00 --> Database Driver Class Initialized
INFO - 2024-12-02 20:55:00 --> Final output sent to browser
DEBUG - 2024-12-02 20:55:00 --> Total execution time: 2.9712
INFO - 2024-12-02 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:55:00 --> Controller Class Initialized
DEBUG - 2024-12-02 20:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:55:01 --> Config Class Initialized
INFO - 2024-12-02 20:55:01 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:55:01 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:55:01 --> Utf8 Class Initialized
INFO - 2024-12-02 20:55:01 --> URI Class Initialized
INFO - 2024-12-02 20:55:01 --> Router Class Initialized
INFO - 2024-12-02 20:55:01 --> Output Class Initialized
INFO - 2024-12-02 20:55:01 --> Security Class Initialized
DEBUG - 2024-12-02 20:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:55:01 --> Input Class Initialized
INFO - 2024-12-02 20:55:01 --> Language Class Initialized
INFO - 2024-12-02 20:55:01 --> Language Class Initialized
INFO - 2024-12-02 20:55:01 --> Config Class Initialized
INFO - 2024-12-02 20:55:01 --> Loader Class Initialized
INFO - 2024-12-02 20:55:01 --> Helper loaded: url_helper
INFO - 2024-12-02 20:55:01 --> Helper loaded: file_helper
INFO - 2024-12-02 20:55:01 --> Helper loaded: form_helper
INFO - 2024-12-02 20:55:01 --> Helper loaded: my_helper
INFO - 2024-12-02 20:55:01 --> Database Driver Class Initialized
INFO - 2024-12-02 20:55:03 --> Final output sent to browser
DEBUG - 2024-12-02 20:55:03 --> Total execution time: 4.9583
INFO - 2024-12-02 20:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:55:03 --> Controller Class Initialized
DEBUG - 2024-12-02 20:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:55:07 --> Final output sent to browser
DEBUG - 2024-12-02 20:55:07 --> Total execution time: 7.0956
INFO - 2024-12-02 20:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:55:07 --> Controller Class Initialized
INFO - 2024-12-02 20:55:07 --> Config Class Initialized
INFO - 2024-12-02 20:55:07 --> Hooks Class Initialized
DEBUG - 2024-12-02 20:55:07 --> UTF-8 Support Enabled
INFO - 2024-12-02 20:55:07 --> Utf8 Class Initialized
INFO - 2024-12-02 20:55:07 --> URI Class Initialized
INFO - 2024-12-02 20:55:07 --> Router Class Initialized
DEBUG - 2024-12-02 20:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:55:07 --> Output Class Initialized
INFO - 2024-12-02 20:55:07 --> Security Class Initialized
DEBUG - 2024-12-02 20:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 20:55:07 --> Input Class Initialized
INFO - 2024-12-02 20:55:07 --> Language Class Initialized
INFO - 2024-12-02 20:55:07 --> Language Class Initialized
INFO - 2024-12-02 20:55:07 --> Config Class Initialized
INFO - 2024-12-02 20:55:07 --> Loader Class Initialized
INFO - 2024-12-02 20:55:07 --> Helper loaded: url_helper
INFO - 2024-12-02 20:55:07 --> Helper loaded: file_helper
INFO - 2024-12-02 20:55:07 --> Helper loaded: form_helper
INFO - 2024-12-02 20:55:07 --> Helper loaded: my_helper
INFO - 2024-12-02 20:55:07 --> Database Driver Class Initialized
INFO - 2024-12-02 20:55:10 --> Final output sent to browser
DEBUG - 2024-12-02 20:55:10 --> Total execution time: 9.1208
INFO - 2024-12-02 20:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-02 20:55:10 --> Controller Class Initialized
DEBUG - 2024-12-02 20:55:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-02 20:55:13 --> Final output sent to browser
DEBUG - 2024-12-02 20:55:13 --> Total execution time: 6.0599
