<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-05 02:23:10 --> Config Class Initialized
INFO - 2020-03-05 02:23:10 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:23:10 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:23:10 --> Utf8 Class Initialized
INFO - 2020-03-05 02:23:10 --> URI Class Initialized
DEBUG - 2020-03-05 02:23:10 --> No URI present. Default controller set.
INFO - 2020-03-05 02:23:10 --> Router Class Initialized
INFO - 2020-03-05 02:23:10 --> Output Class Initialized
INFO - 2020-03-05 02:23:10 --> Security Class Initialized
DEBUG - 2020-03-05 02:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:23:10 --> Input Class Initialized
INFO - 2020-03-05 02:23:10 --> Language Class Initialized
INFO - 2020-03-05 02:23:10 --> Language Class Initialized
INFO - 2020-03-05 02:23:10 --> Config Class Initialized
INFO - 2020-03-05 02:23:10 --> Loader Class Initialized
INFO - 2020-03-05 02:23:10 --> Helper loaded: url_helper
INFO - 2020-03-05 02:23:10 --> Helper loaded: file_helper
INFO - 2020-03-05 02:23:10 --> Helper loaded: form_helper
INFO - 2020-03-05 02:23:10 --> Helper loaded: my_helper
INFO - 2020-03-05 02:23:11 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:23:11 --> Controller Class Initialized
INFO - 2020-03-05 02:23:11 --> Config Class Initialized
INFO - 2020-03-05 02:23:11 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:23:11 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:23:11 --> Utf8 Class Initialized
INFO - 2020-03-05 02:23:11 --> URI Class Initialized
INFO - 2020-03-05 02:23:11 --> Router Class Initialized
INFO - 2020-03-05 02:23:11 --> Output Class Initialized
INFO - 2020-03-05 02:23:11 --> Security Class Initialized
DEBUG - 2020-03-05 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:23:11 --> Input Class Initialized
INFO - 2020-03-05 02:23:11 --> Language Class Initialized
INFO - 2020-03-05 02:23:11 --> Language Class Initialized
INFO - 2020-03-05 02:23:11 --> Config Class Initialized
INFO - 2020-03-05 02:23:11 --> Loader Class Initialized
INFO - 2020-03-05 02:23:11 --> Helper loaded: url_helper
INFO - 2020-03-05 02:23:11 --> Helper loaded: file_helper
INFO - 2020-03-05 02:23:11 --> Helper loaded: form_helper
INFO - 2020-03-05 02:23:11 --> Helper loaded: my_helper
INFO - 2020-03-05 02:23:11 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:23:11 --> Controller Class Initialized
DEBUG - 2020-03-05 02:23:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-05 02:23:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:23:11 --> Final output sent to browser
DEBUG - 2020-03-05 02:23:11 --> Total execution time: 0.3007
INFO - 2020-03-05 02:31:34 --> Config Class Initialized
INFO - 2020-03-05 02:31:34 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:31:34 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:31:34 --> Utf8 Class Initialized
INFO - 2020-03-05 02:31:34 --> URI Class Initialized
INFO - 2020-03-05 02:31:34 --> Router Class Initialized
INFO - 2020-03-05 02:31:34 --> Output Class Initialized
INFO - 2020-03-05 02:31:34 --> Security Class Initialized
DEBUG - 2020-03-05 02:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:31:34 --> Input Class Initialized
INFO - 2020-03-05 02:31:34 --> Language Class Initialized
INFO - 2020-03-05 02:31:34 --> Language Class Initialized
INFO - 2020-03-05 02:31:34 --> Config Class Initialized
INFO - 2020-03-05 02:31:34 --> Loader Class Initialized
INFO - 2020-03-05 02:31:34 --> Helper loaded: url_helper
INFO - 2020-03-05 02:31:34 --> Helper loaded: file_helper
INFO - 2020-03-05 02:31:34 --> Helper loaded: form_helper
INFO - 2020-03-05 02:31:34 --> Helper loaded: my_helper
INFO - 2020-03-05 02:31:34 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:31:34 --> Controller Class Initialized
DEBUG - 2020-03-05 02:31:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-05 02:31:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:31:35 --> Final output sent to browser
DEBUG - 2020-03-05 02:31:35 --> Total execution time: 1.0719
INFO - 2020-03-05 02:31:51 --> Config Class Initialized
INFO - 2020-03-05 02:31:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:31:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:31:51 --> Utf8 Class Initialized
INFO - 2020-03-05 02:31:51 --> URI Class Initialized
INFO - 2020-03-05 02:31:51 --> Router Class Initialized
INFO - 2020-03-05 02:31:51 --> Output Class Initialized
INFO - 2020-03-05 02:31:51 --> Security Class Initialized
DEBUG - 2020-03-05 02:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:31:51 --> Input Class Initialized
INFO - 2020-03-05 02:31:51 --> Language Class Initialized
INFO - 2020-03-05 02:31:51 --> Language Class Initialized
INFO - 2020-03-05 02:31:51 --> Config Class Initialized
INFO - 2020-03-05 02:31:51 --> Loader Class Initialized
INFO - 2020-03-05 02:31:51 --> Helper loaded: url_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: file_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: form_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: my_helper
INFO - 2020-03-05 02:31:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:31:51 --> Controller Class Initialized
INFO - 2020-03-05 02:31:51 --> Helper loaded: cookie_helper
INFO - 2020-03-05 02:31:51 --> Final output sent to browser
DEBUG - 2020-03-05 02:31:51 --> Total execution time: 0.3573
INFO - 2020-03-05 02:31:51 --> Config Class Initialized
INFO - 2020-03-05 02:31:51 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:31:51 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:31:51 --> Utf8 Class Initialized
INFO - 2020-03-05 02:31:51 --> URI Class Initialized
INFO - 2020-03-05 02:31:51 --> Router Class Initialized
INFO - 2020-03-05 02:31:51 --> Output Class Initialized
INFO - 2020-03-05 02:31:51 --> Security Class Initialized
DEBUG - 2020-03-05 02:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:31:51 --> Input Class Initialized
INFO - 2020-03-05 02:31:51 --> Language Class Initialized
INFO - 2020-03-05 02:31:51 --> Language Class Initialized
INFO - 2020-03-05 02:31:51 --> Config Class Initialized
INFO - 2020-03-05 02:31:51 --> Loader Class Initialized
INFO - 2020-03-05 02:31:51 --> Helper loaded: url_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: file_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: form_helper
INFO - 2020-03-05 02:31:51 --> Helper loaded: my_helper
INFO - 2020-03-05 02:31:51 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:31:51 --> Controller Class Initialized
DEBUG - 2020-03-05 02:31:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-05 02:31:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:31:51 --> Final output sent to browser
DEBUG - 2020-03-05 02:31:51 --> Total execution time: 0.3631
INFO - 2020-03-05 02:32:13 --> Config Class Initialized
INFO - 2020-03-05 02:32:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:32:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:32:13 --> Utf8 Class Initialized
INFO - 2020-03-05 02:32:13 --> URI Class Initialized
INFO - 2020-03-05 02:32:13 --> Router Class Initialized
INFO - 2020-03-05 02:32:13 --> Output Class Initialized
INFO - 2020-03-05 02:32:13 --> Security Class Initialized
DEBUG - 2020-03-05 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:32:13 --> Input Class Initialized
INFO - 2020-03-05 02:32:13 --> Language Class Initialized
INFO - 2020-03-05 02:32:13 --> Language Class Initialized
INFO - 2020-03-05 02:32:13 --> Config Class Initialized
INFO - 2020-03-05 02:32:13 --> Loader Class Initialized
INFO - 2020-03-05 02:32:13 --> Helper loaded: url_helper
INFO - 2020-03-05 02:32:13 --> Helper loaded: file_helper
INFO - 2020-03-05 02:32:13 --> Helper loaded: form_helper
INFO - 2020-03-05 02:32:13 --> Helper loaded: my_helper
INFO - 2020-03-05 02:32:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:32:13 --> Controller Class Initialized
DEBUG - 2020-03-05 02:32:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-05 02:32:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:32:13 --> Final output sent to browser
DEBUG - 2020-03-05 02:32:13 --> Total execution time: 0.3184
INFO - 2020-03-05 02:32:15 --> Config Class Initialized
INFO - 2020-03-05 02:32:15 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:32:15 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:32:15 --> Utf8 Class Initialized
INFO - 2020-03-05 02:32:15 --> URI Class Initialized
INFO - 2020-03-05 02:32:15 --> Router Class Initialized
INFO - 2020-03-05 02:32:15 --> Output Class Initialized
INFO - 2020-03-05 02:32:15 --> Security Class Initialized
DEBUG - 2020-03-05 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:32:15 --> Input Class Initialized
INFO - 2020-03-05 02:32:15 --> Language Class Initialized
INFO - 2020-03-05 02:32:15 --> Language Class Initialized
INFO - 2020-03-05 02:32:15 --> Config Class Initialized
INFO - 2020-03-05 02:32:15 --> Loader Class Initialized
INFO - 2020-03-05 02:32:15 --> Helper loaded: url_helper
INFO - 2020-03-05 02:32:15 --> Helper loaded: file_helper
INFO - 2020-03-05 02:32:15 --> Helper loaded: form_helper
INFO - 2020-03-05 02:32:15 --> Helper loaded: my_helper
INFO - 2020-03-05 02:32:15 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:32:15 --> Controller Class Initialized
DEBUG - 2020-03-05 02:32:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:32:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:32:15 --> Final output sent to browser
DEBUG - 2020-03-05 02:32:15 --> Total execution time: 0.3267
INFO - 2020-03-05 02:34:27 --> Config Class Initialized
INFO - 2020-03-05 02:34:27 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:34:27 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:34:27 --> Utf8 Class Initialized
INFO - 2020-03-05 02:34:27 --> URI Class Initialized
INFO - 2020-03-05 02:34:27 --> Router Class Initialized
INFO - 2020-03-05 02:34:27 --> Output Class Initialized
INFO - 2020-03-05 02:34:27 --> Security Class Initialized
DEBUG - 2020-03-05 02:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:34:27 --> Input Class Initialized
INFO - 2020-03-05 02:34:27 --> Language Class Initialized
INFO - 2020-03-05 02:34:27 --> Language Class Initialized
INFO - 2020-03-05 02:34:27 --> Config Class Initialized
INFO - 2020-03-05 02:34:27 --> Loader Class Initialized
INFO - 2020-03-05 02:34:27 --> Helper loaded: url_helper
INFO - 2020-03-05 02:34:27 --> Helper loaded: file_helper
INFO - 2020-03-05 02:34:27 --> Helper loaded: form_helper
INFO - 2020-03-05 02:34:27 --> Helper loaded: my_helper
INFO - 2020-03-05 02:34:27 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:34:27 --> Controller Class Initialized
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:27 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:34:28 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
DEBUG - 2020-03-05 02:34:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:34:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:34:28 --> Final output sent to browser
DEBUG - 2020-03-05 02:34:28 --> Total execution time: 1.0652
INFO - 2020-03-05 02:35:00 --> Config Class Initialized
INFO - 2020-03-05 02:35:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:35:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:35:00 --> Utf8 Class Initialized
INFO - 2020-03-05 02:35:00 --> URI Class Initialized
INFO - 2020-03-05 02:35:00 --> Router Class Initialized
INFO - 2020-03-05 02:35:00 --> Output Class Initialized
INFO - 2020-03-05 02:35:01 --> Security Class Initialized
DEBUG - 2020-03-05 02:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:35:01 --> Input Class Initialized
INFO - 2020-03-05 02:35:01 --> Language Class Initialized
INFO - 2020-03-05 02:35:01 --> Language Class Initialized
INFO - 2020-03-05 02:35:01 --> Config Class Initialized
INFO - 2020-03-05 02:35:01 --> Loader Class Initialized
INFO - 2020-03-05 02:35:01 --> Helper loaded: url_helper
INFO - 2020-03-05 02:35:01 --> Helper loaded: file_helper
INFO - 2020-03-05 02:35:01 --> Helper loaded: form_helper
INFO - 2020-03-05 02:35:01 --> Helper loaded: my_helper
INFO - 2020-03-05 02:35:01 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:35:01 --> Controller Class Initialized
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
ERROR - 2020-03-05 02:35:01 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 57
DEBUG - 2020-03-05 02:35:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:35:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:35:02 --> Final output sent to browser
DEBUG - 2020-03-05 02:35:02 --> Total execution time: 1.1051
INFO - 2020-03-05 02:35:41 --> Config Class Initialized
INFO - 2020-03-05 02:35:41 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:35:41 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:35:41 --> Utf8 Class Initialized
INFO - 2020-03-05 02:35:41 --> URI Class Initialized
INFO - 2020-03-05 02:35:41 --> Router Class Initialized
INFO - 2020-03-05 02:35:41 --> Output Class Initialized
INFO - 2020-03-05 02:35:41 --> Security Class Initialized
DEBUG - 2020-03-05 02:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:35:41 --> Input Class Initialized
INFO - 2020-03-05 02:35:41 --> Language Class Initialized
INFO - 2020-03-05 02:35:41 --> Language Class Initialized
INFO - 2020-03-05 02:35:41 --> Config Class Initialized
INFO - 2020-03-05 02:35:41 --> Loader Class Initialized
INFO - 2020-03-05 02:35:41 --> Helper loaded: url_helper
INFO - 2020-03-05 02:35:41 --> Helper loaded: file_helper
INFO - 2020-03-05 02:35:41 --> Helper loaded: form_helper
INFO - 2020-03-05 02:35:41 --> Helper loaded: my_helper
INFO - 2020-03-05 02:35:41 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:35:41 --> Controller Class Initialized
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:41 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
ERROR - 2020-03-05 02:35:42 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 58
DEBUG - 2020-03-05 02:35:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:35:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:35:42 --> Final output sent to browser
DEBUG - 2020-03-05 02:35:42 --> Total execution time: 1.1417
INFO - 2020-03-05 02:35:54 --> Config Class Initialized
INFO - 2020-03-05 02:35:54 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:35:54 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:35:54 --> Utf8 Class Initialized
INFO - 2020-03-05 02:35:54 --> URI Class Initialized
INFO - 2020-03-05 02:35:54 --> Router Class Initialized
INFO - 2020-03-05 02:35:54 --> Output Class Initialized
INFO - 2020-03-05 02:35:54 --> Security Class Initialized
DEBUG - 2020-03-05 02:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:35:54 --> Input Class Initialized
INFO - 2020-03-05 02:35:54 --> Language Class Initialized
INFO - 2020-03-05 02:35:54 --> Language Class Initialized
INFO - 2020-03-05 02:35:54 --> Config Class Initialized
INFO - 2020-03-05 02:35:54 --> Loader Class Initialized
INFO - 2020-03-05 02:35:54 --> Helper loaded: url_helper
INFO - 2020-03-05 02:35:54 --> Helper loaded: file_helper
INFO - 2020-03-05 02:35:54 --> Helper loaded: form_helper
INFO - 2020-03-05 02:35:54 --> Helper loaded: my_helper
INFO - 2020-03-05 02:35:54 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:35:54 --> Controller Class Initialized
INFO - 2020-03-05 02:35:57 --> Config Class Initialized
INFO - 2020-03-05 02:35:57 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:35:57 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:35:57 --> Utf8 Class Initialized
INFO - 2020-03-05 02:35:57 --> URI Class Initialized
INFO - 2020-03-05 02:35:57 --> Router Class Initialized
INFO - 2020-03-05 02:35:57 --> Output Class Initialized
INFO - 2020-03-05 02:35:57 --> Security Class Initialized
DEBUG - 2020-03-05 02:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:35:57 --> Input Class Initialized
INFO - 2020-03-05 02:35:57 --> Language Class Initialized
INFO - 2020-03-05 02:35:57 --> Language Class Initialized
INFO - 2020-03-05 02:35:57 --> Config Class Initialized
INFO - 2020-03-05 02:35:57 --> Loader Class Initialized
INFO - 2020-03-05 02:35:57 --> Helper loaded: url_helper
INFO - 2020-03-05 02:35:57 --> Helper loaded: file_helper
INFO - 2020-03-05 02:35:57 --> Helper loaded: form_helper
INFO - 2020-03-05 02:35:57 --> Helper loaded: my_helper
INFO - 2020-03-05 02:35:57 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:35:57 --> Controller Class Initialized
INFO - 2020-03-05 02:36:38 --> Config Class Initialized
INFO - 2020-03-05 02:36:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:36:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:36:38 --> Utf8 Class Initialized
INFO - 2020-03-05 02:36:38 --> URI Class Initialized
INFO - 2020-03-05 02:36:38 --> Router Class Initialized
INFO - 2020-03-05 02:36:38 --> Output Class Initialized
INFO - 2020-03-05 02:36:38 --> Security Class Initialized
DEBUG - 2020-03-05 02:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:36:38 --> Input Class Initialized
INFO - 2020-03-05 02:36:38 --> Language Class Initialized
INFO - 2020-03-05 02:36:38 --> Language Class Initialized
INFO - 2020-03-05 02:36:38 --> Config Class Initialized
INFO - 2020-03-05 02:36:38 --> Loader Class Initialized
INFO - 2020-03-05 02:36:38 --> Helper loaded: url_helper
INFO - 2020-03-05 02:36:38 --> Helper loaded: file_helper
INFO - 2020-03-05 02:36:38 --> Helper loaded: form_helper
INFO - 2020-03-05 02:36:38 --> Helper loaded: my_helper
INFO - 2020-03-05 02:36:38 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:36:38 --> Controller Class Initialized
INFO - 2020-03-05 02:36:58 --> Config Class Initialized
INFO - 2020-03-05 02:36:58 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:36:58 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:36:58 --> Utf8 Class Initialized
INFO - 2020-03-05 02:36:58 --> URI Class Initialized
INFO - 2020-03-05 02:36:58 --> Router Class Initialized
INFO - 2020-03-05 02:36:58 --> Output Class Initialized
INFO - 2020-03-05 02:36:58 --> Security Class Initialized
DEBUG - 2020-03-05 02:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:36:58 --> Input Class Initialized
INFO - 2020-03-05 02:36:58 --> Language Class Initialized
INFO - 2020-03-05 02:36:58 --> Language Class Initialized
INFO - 2020-03-05 02:36:58 --> Config Class Initialized
INFO - 2020-03-05 02:36:58 --> Loader Class Initialized
INFO - 2020-03-05 02:36:58 --> Helper loaded: url_helper
INFO - 2020-03-05 02:36:58 --> Helper loaded: file_helper
INFO - 2020-03-05 02:36:58 --> Helper loaded: form_helper
INFO - 2020-03-05 02:36:58 --> Helper loaded: my_helper
INFO - 2020-03-05 02:36:58 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:36:58 --> Controller Class Initialized
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:58 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:36:59 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
DEBUG - 2020-03-05 02:36:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:36:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:36:59 --> Final output sent to browser
DEBUG - 2020-03-05 02:36:59 --> Total execution time: 1.0549
INFO - 2020-03-05 02:37:38 --> Config Class Initialized
INFO - 2020-03-05 02:37:38 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:37:38 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:37:38 --> Utf8 Class Initialized
INFO - 2020-03-05 02:37:38 --> URI Class Initialized
INFO - 2020-03-05 02:37:38 --> Router Class Initialized
INFO - 2020-03-05 02:37:38 --> Output Class Initialized
INFO - 2020-03-05 02:37:38 --> Security Class Initialized
DEBUG - 2020-03-05 02:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:37:38 --> Input Class Initialized
INFO - 2020-03-05 02:37:38 --> Language Class Initialized
INFO - 2020-03-05 02:37:38 --> Language Class Initialized
INFO - 2020-03-05 02:37:38 --> Config Class Initialized
INFO - 2020-03-05 02:37:38 --> Loader Class Initialized
INFO - 2020-03-05 02:37:38 --> Helper loaded: url_helper
INFO - 2020-03-05 02:37:38 --> Helper loaded: file_helper
INFO - 2020-03-05 02:37:38 --> Helper loaded: form_helper
INFO - 2020-03-05 02:37:38 --> Helper loaded: my_helper
INFO - 2020-03-05 02:37:38 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:37:38 --> Controller Class Initialized
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
ERROR - 2020-03-05 02:37:39 --> Severity: Notice --> Undefined index: kelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 59
DEBUG - 2020-03-05 02:37:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:37:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:37:39 --> Final output sent to browser
DEBUG - 2020-03-05 02:37:39 --> Total execution time: 0.7787
INFO - 2020-03-05 02:38:12 --> Config Class Initialized
INFO - 2020-03-05 02:38:12 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:38:12 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:38:12 --> Utf8 Class Initialized
INFO - 2020-03-05 02:38:12 --> URI Class Initialized
INFO - 2020-03-05 02:38:12 --> Router Class Initialized
INFO - 2020-03-05 02:38:12 --> Output Class Initialized
INFO - 2020-03-05 02:38:12 --> Security Class Initialized
DEBUG - 2020-03-05 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:38:12 --> Input Class Initialized
INFO - 2020-03-05 02:38:12 --> Language Class Initialized
INFO - 2020-03-05 02:38:12 --> Language Class Initialized
INFO - 2020-03-05 02:38:12 --> Config Class Initialized
INFO - 2020-03-05 02:38:12 --> Loader Class Initialized
INFO - 2020-03-05 02:38:12 --> Helper loaded: url_helper
INFO - 2020-03-05 02:38:12 --> Helper loaded: file_helper
INFO - 2020-03-05 02:38:12 --> Helper loaded: form_helper
INFO - 2020-03-05 02:38:12 --> Helper loaded: my_helper
INFO - 2020-03-05 02:38:12 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:38:13 --> Controller Class Initialized
INFO - 2020-03-05 02:38:13 --> Config Class Initialized
INFO - 2020-03-05 02:38:13 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:38:13 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:38:13 --> Utf8 Class Initialized
INFO - 2020-03-05 02:38:13 --> URI Class Initialized
INFO - 2020-03-05 02:38:13 --> Router Class Initialized
INFO - 2020-03-05 02:38:13 --> Output Class Initialized
INFO - 2020-03-05 02:38:13 --> Security Class Initialized
DEBUG - 2020-03-05 02:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:38:13 --> Input Class Initialized
INFO - 2020-03-05 02:38:13 --> Language Class Initialized
INFO - 2020-03-05 02:38:13 --> Language Class Initialized
INFO - 2020-03-05 02:38:13 --> Config Class Initialized
INFO - 2020-03-05 02:38:13 --> Loader Class Initialized
INFO - 2020-03-05 02:38:13 --> Helper loaded: url_helper
INFO - 2020-03-05 02:38:13 --> Helper loaded: file_helper
INFO - 2020-03-05 02:38:13 --> Helper loaded: form_helper
INFO - 2020-03-05 02:38:13 --> Helper loaded: my_helper
INFO - 2020-03-05 02:38:13 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:38:13 --> Controller Class Initialized
DEBUG - 2020-03-05 02:38:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-05 02:38:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:38:13 --> Final output sent to browser
DEBUG - 2020-03-05 02:38:13 --> Total execution time: 0.4050
INFO - 2020-03-05 02:40:00 --> Config Class Initialized
INFO - 2020-03-05 02:40:00 --> Hooks Class Initialized
DEBUG - 2020-03-05 02:40:00 --> UTF-8 Support Enabled
INFO - 2020-03-05 02:40:00 --> Utf8 Class Initialized
INFO - 2020-03-05 02:40:00 --> URI Class Initialized
INFO - 2020-03-05 02:40:00 --> Router Class Initialized
INFO - 2020-03-05 02:40:00 --> Output Class Initialized
INFO - 2020-03-05 02:40:00 --> Security Class Initialized
DEBUG - 2020-03-05 02:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-05 02:40:00 --> Input Class Initialized
INFO - 2020-03-05 02:40:00 --> Language Class Initialized
INFO - 2020-03-05 02:40:00 --> Language Class Initialized
INFO - 2020-03-05 02:40:00 --> Config Class Initialized
INFO - 2020-03-05 02:40:00 --> Loader Class Initialized
INFO - 2020-03-05 02:40:00 --> Helper loaded: url_helper
INFO - 2020-03-05 02:40:00 --> Helper loaded: file_helper
INFO - 2020-03-05 02:40:00 --> Helper loaded: form_helper
INFO - 2020-03-05 02:40:00 --> Helper loaded: my_helper
INFO - 2020-03-05 02:40:00 --> Database Driver Class Initialized
DEBUG - 2020-03-05 02:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-05 02:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-05 02:40:00 --> Controller Class Initialized
DEBUG - 2020-03-05 02:40:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-05 02:40:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-05 02:40:00 --> Final output sent to browser
DEBUG - 2020-03-05 02:40:00 --> Total execution time: 0.3745
