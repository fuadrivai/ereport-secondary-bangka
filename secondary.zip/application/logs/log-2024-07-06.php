<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-06 00:48:30 --> Config Class Initialized
INFO - 2024-07-06 00:48:30 --> Hooks Class Initialized
DEBUG - 2024-07-06 00:48:30 --> UTF-8 Support Enabled
INFO - 2024-07-06 00:48:30 --> Utf8 Class Initialized
INFO - 2024-07-06 00:48:30 --> URI Class Initialized
INFO - 2024-07-06 00:48:30 --> Router Class Initialized
INFO - 2024-07-06 00:48:30 --> Output Class Initialized
INFO - 2024-07-06 00:48:30 --> Security Class Initialized
DEBUG - 2024-07-06 00:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 00:48:30 --> Input Class Initialized
INFO - 2024-07-06 00:48:30 --> Language Class Initialized
INFO - 2024-07-06 00:48:30 --> Language Class Initialized
INFO - 2024-07-06 00:48:30 --> Config Class Initialized
INFO - 2024-07-06 00:48:30 --> Loader Class Initialized
INFO - 2024-07-06 00:48:30 --> Helper loaded: url_helper
INFO - 2024-07-06 00:48:30 --> Helper loaded: file_helper
INFO - 2024-07-06 00:48:30 --> Helper loaded: form_helper
INFO - 2024-07-06 00:48:30 --> Helper loaded: my_helper
INFO - 2024-07-06 00:48:30 --> Database Driver Class Initialized
INFO - 2024-07-06 00:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 00:48:30 --> Controller Class Initialized
INFO - 2024-07-06 00:48:31 --> Config Class Initialized
INFO - 2024-07-06 00:48:31 --> Hooks Class Initialized
DEBUG - 2024-07-06 00:48:31 --> UTF-8 Support Enabled
INFO - 2024-07-06 00:48:31 --> Utf8 Class Initialized
INFO - 2024-07-06 00:48:31 --> URI Class Initialized
INFO - 2024-07-06 00:48:31 --> Router Class Initialized
INFO - 2024-07-06 00:48:31 --> Output Class Initialized
INFO - 2024-07-06 00:48:31 --> Security Class Initialized
DEBUG - 2024-07-06 00:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 00:48:31 --> Input Class Initialized
INFO - 2024-07-06 00:48:31 --> Language Class Initialized
INFO - 2024-07-06 00:48:31 --> Language Class Initialized
INFO - 2024-07-06 00:48:31 --> Config Class Initialized
INFO - 2024-07-06 00:48:31 --> Loader Class Initialized
INFO - 2024-07-06 00:48:31 --> Helper loaded: url_helper
INFO - 2024-07-06 00:48:31 --> Helper loaded: file_helper
INFO - 2024-07-06 00:48:31 --> Helper loaded: form_helper
INFO - 2024-07-06 00:48:31 --> Helper loaded: my_helper
INFO - 2024-07-06 00:48:31 --> Database Driver Class Initialized
INFO - 2024-07-06 00:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 00:48:31 --> Controller Class Initialized
DEBUG - 2024-07-06 00:48:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/unauthorized_access/views/no_akses.php
DEBUG - 2024-07-06 00:48:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-06 00:48:31 --> Final output sent to browser
DEBUG - 2024-07-06 00:48:31 --> Total execution time: 0.0285
INFO - 2024-07-06 00:54:18 --> Config Class Initialized
INFO - 2024-07-06 00:54:18 --> Hooks Class Initialized
DEBUG - 2024-07-06 00:54:18 --> UTF-8 Support Enabled
INFO - 2024-07-06 00:54:18 --> Utf8 Class Initialized
INFO - 2024-07-06 00:54:18 --> URI Class Initialized
INFO - 2024-07-06 00:54:18 --> Router Class Initialized
INFO - 2024-07-06 00:54:18 --> Output Class Initialized
INFO - 2024-07-06 00:54:18 --> Security Class Initialized
DEBUG - 2024-07-06 00:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 00:54:18 --> Input Class Initialized
INFO - 2024-07-06 00:54:18 --> Language Class Initialized
INFO - 2024-07-06 00:54:18 --> Language Class Initialized
INFO - 2024-07-06 00:54:18 --> Config Class Initialized
INFO - 2024-07-06 00:54:18 --> Loader Class Initialized
INFO - 2024-07-06 00:54:18 --> Helper loaded: url_helper
INFO - 2024-07-06 00:54:18 --> Helper loaded: file_helper
INFO - 2024-07-06 00:54:18 --> Helper loaded: form_helper
INFO - 2024-07-06 00:54:18 --> Helper loaded: my_helper
INFO - 2024-07-06 00:54:18 --> Database Driver Class Initialized
INFO - 2024-07-06 00:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 00:54:18 --> Controller Class Initialized
DEBUG - 2024-07-06 00:54:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-06 00:54:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-06 00:54:18 --> Final output sent to browser
DEBUG - 2024-07-06 00:54:18 --> Total execution time: 0.0719
INFO - 2024-07-06 00:54:33 --> Config Class Initialized
INFO - 2024-07-06 00:54:33 --> Hooks Class Initialized
DEBUG - 2024-07-06 00:54:33 --> UTF-8 Support Enabled
INFO - 2024-07-06 00:54:33 --> Utf8 Class Initialized
INFO - 2024-07-06 00:54:33 --> URI Class Initialized
DEBUG - 2024-07-06 00:54:33 --> No URI present. Default controller set.
INFO - 2024-07-06 00:54:33 --> Router Class Initialized
INFO - 2024-07-06 00:54:33 --> Output Class Initialized
INFO - 2024-07-06 00:54:33 --> Security Class Initialized
DEBUG - 2024-07-06 00:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 00:54:33 --> Input Class Initialized
INFO - 2024-07-06 00:54:33 --> Language Class Initialized
INFO - 2024-07-06 00:54:33 --> Language Class Initialized
INFO - 2024-07-06 00:54:33 --> Config Class Initialized
INFO - 2024-07-06 00:54:33 --> Loader Class Initialized
INFO - 2024-07-06 00:54:33 --> Helper loaded: url_helper
INFO - 2024-07-06 00:54:33 --> Helper loaded: file_helper
INFO - 2024-07-06 00:54:33 --> Helper loaded: form_helper
INFO - 2024-07-06 00:54:33 --> Helper loaded: my_helper
INFO - 2024-07-06 00:54:33 --> Database Driver Class Initialized
INFO - 2024-07-06 00:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 00:54:33 --> Controller Class Initialized
INFO - 2024-07-06 00:54:34 --> Config Class Initialized
INFO - 2024-07-06 00:54:34 --> Hooks Class Initialized
DEBUG - 2024-07-06 00:54:34 --> UTF-8 Support Enabled
INFO - 2024-07-06 00:54:34 --> Utf8 Class Initialized
INFO - 2024-07-06 00:54:34 --> URI Class Initialized
INFO - 2024-07-06 00:54:34 --> Router Class Initialized
INFO - 2024-07-06 00:54:34 --> Output Class Initialized
INFO - 2024-07-06 00:54:34 --> Security Class Initialized
DEBUG - 2024-07-06 00:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 00:54:34 --> Input Class Initialized
INFO - 2024-07-06 00:54:34 --> Language Class Initialized
INFO - 2024-07-06 00:54:34 --> Language Class Initialized
INFO - 2024-07-06 00:54:34 --> Config Class Initialized
INFO - 2024-07-06 00:54:34 --> Loader Class Initialized
INFO - 2024-07-06 00:54:34 --> Helper loaded: url_helper
INFO - 2024-07-06 00:54:34 --> Helper loaded: file_helper
INFO - 2024-07-06 00:54:34 --> Helper loaded: form_helper
INFO - 2024-07-06 00:54:34 --> Helper loaded: my_helper
INFO - 2024-07-06 00:54:34 --> Database Driver Class Initialized
INFO - 2024-07-06 00:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 00:54:34 --> Controller Class Initialized
DEBUG - 2024-07-06 00:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-06 00:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-06 00:54:34 --> Final output sent to browser
DEBUG - 2024-07-06 00:54:34 --> Total execution time: 0.0300
INFO - 2024-07-06 01:06:41 --> Config Class Initialized
INFO - 2024-07-06 01:06:41 --> Hooks Class Initialized
DEBUG - 2024-07-06 01:06:41 --> UTF-8 Support Enabled
INFO - 2024-07-06 01:06:41 --> Utf8 Class Initialized
INFO - 2024-07-06 01:06:41 --> URI Class Initialized
INFO - 2024-07-06 01:06:41 --> Router Class Initialized
INFO - 2024-07-06 01:06:41 --> Output Class Initialized
INFO - 2024-07-06 01:06:41 --> Security Class Initialized
DEBUG - 2024-07-06 01:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 01:06:41 --> Input Class Initialized
INFO - 2024-07-06 01:06:41 --> Language Class Initialized
INFO - 2024-07-06 01:06:41 --> Language Class Initialized
INFO - 2024-07-06 01:06:41 --> Config Class Initialized
INFO - 2024-07-06 01:06:41 --> Loader Class Initialized
INFO - 2024-07-06 01:06:41 --> Helper loaded: url_helper
INFO - 2024-07-06 01:06:41 --> Helper loaded: file_helper
INFO - 2024-07-06 01:06:41 --> Helper loaded: form_helper
INFO - 2024-07-06 01:06:41 --> Helper loaded: my_helper
INFO - 2024-07-06 01:06:41 --> Database Driver Class Initialized
INFO - 2024-07-06 01:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 01:06:41 --> Controller Class Initialized
DEBUG - 2024-07-06 01:06:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-06 01:06:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-06 01:06:41 --> Final output sent to browser
DEBUG - 2024-07-06 01:06:41 --> Total execution time: 0.0400
INFO - 2024-07-06 03:09:20 --> Config Class Initialized
INFO - 2024-07-06 03:09:20 --> Hooks Class Initialized
DEBUG - 2024-07-06 03:09:20 --> UTF-8 Support Enabled
INFO - 2024-07-06 03:09:20 --> Utf8 Class Initialized
INFO - 2024-07-06 03:09:20 --> URI Class Initialized
INFO - 2024-07-06 03:09:20 --> Router Class Initialized
INFO - 2024-07-06 03:09:20 --> Output Class Initialized
INFO - 2024-07-06 03:09:20 --> Security Class Initialized
DEBUG - 2024-07-06 03:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-06 03:09:20 --> Input Class Initialized
INFO - 2024-07-06 03:09:20 --> Language Class Initialized
INFO - 2024-07-06 03:09:20 --> Language Class Initialized
INFO - 2024-07-06 03:09:20 --> Config Class Initialized
INFO - 2024-07-06 03:09:20 --> Loader Class Initialized
INFO - 2024-07-06 03:09:20 --> Helper loaded: url_helper
INFO - 2024-07-06 03:09:20 --> Helper loaded: file_helper
INFO - 2024-07-06 03:09:20 --> Helper loaded: form_helper
INFO - 2024-07-06 03:09:20 --> Helper loaded: my_helper
INFO - 2024-07-06 03:09:20 --> Database Driver Class Initialized
INFO - 2024-07-06 03:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-06 03:09:20 --> Controller Class Initialized
DEBUG - 2024-07-06 03:09:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-06 03:09:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-06 03:09:20 --> Final output sent to browser
DEBUG - 2024-07-06 03:09:20 --> Total execution time: 0.0756
