<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-25 07:23:51 --> Config Class Initialized
INFO - 2023-09-25 07:23:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 07:23:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 07:23:51 --> Utf8 Class Initialized
INFO - 2023-09-25 07:23:51 --> URI Class Initialized
INFO - 2023-09-25 07:23:51 --> Router Class Initialized
INFO - 2023-09-25 07:23:51 --> Output Class Initialized
INFO - 2023-09-25 07:23:51 --> Security Class Initialized
DEBUG - 2023-09-25 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 07:23:51 --> Input Class Initialized
INFO - 2023-09-25 07:23:51 --> Language Class Initialized
INFO - 2023-09-25 07:23:51 --> Language Class Initialized
INFO - 2023-09-25 07:23:51 --> Config Class Initialized
INFO - 2023-09-25 07:23:51 --> Loader Class Initialized
INFO - 2023-09-25 07:23:51 --> Helper loaded: url_helper
INFO - 2023-09-25 07:23:51 --> Helper loaded: file_helper
INFO - 2023-09-25 07:23:51 --> Helper loaded: form_helper
INFO - 2023-09-25 07:23:51 --> Helper loaded: my_helper
INFO - 2023-09-25 07:23:51 --> Database Driver Class Initialized
INFO - 2023-09-25 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 07:23:51 --> Controller Class Initialized
DEBUG - 2023-09-25 07:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-25 07:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 07:23:52 --> Final output sent to browser
DEBUG - 2023-09-25 07:23:52 --> Total execution time: 0.4187
INFO - 2023-09-25 08:14:06 --> Config Class Initialized
INFO - 2023-09-25 08:14:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:14:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:14:06 --> Utf8 Class Initialized
INFO - 2023-09-25 08:14:06 --> URI Class Initialized
DEBUG - 2023-09-25 08:14:06 --> No URI present. Default controller set.
INFO - 2023-09-25 08:14:06 --> Router Class Initialized
INFO - 2023-09-25 08:14:06 --> Output Class Initialized
INFO - 2023-09-25 08:14:06 --> Security Class Initialized
DEBUG - 2023-09-25 08:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:14:06 --> Input Class Initialized
INFO - 2023-09-25 08:14:06 --> Language Class Initialized
INFO - 2023-09-25 08:14:06 --> Language Class Initialized
INFO - 2023-09-25 08:14:06 --> Config Class Initialized
INFO - 2023-09-25 08:14:06 --> Loader Class Initialized
INFO - 2023-09-25 08:14:06 --> Helper loaded: url_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: file_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: form_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: my_helper
INFO - 2023-09-25 08:14:06 --> Database Driver Class Initialized
INFO - 2023-09-25 08:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:14:06 --> Controller Class Initialized
INFO - 2023-09-25 08:14:06 --> Config Class Initialized
INFO - 2023-09-25 08:14:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:14:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:14:06 --> Utf8 Class Initialized
INFO - 2023-09-25 08:14:06 --> URI Class Initialized
INFO - 2023-09-25 08:14:06 --> Router Class Initialized
INFO - 2023-09-25 08:14:06 --> Output Class Initialized
INFO - 2023-09-25 08:14:06 --> Security Class Initialized
DEBUG - 2023-09-25 08:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:14:06 --> Input Class Initialized
INFO - 2023-09-25 08:14:06 --> Language Class Initialized
INFO - 2023-09-25 08:14:06 --> Language Class Initialized
INFO - 2023-09-25 08:14:06 --> Config Class Initialized
INFO - 2023-09-25 08:14:06 --> Loader Class Initialized
INFO - 2023-09-25 08:14:06 --> Helper loaded: url_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: file_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: form_helper
INFO - 2023-09-25 08:14:06 --> Helper loaded: my_helper
INFO - 2023-09-25 08:14:06 --> Database Driver Class Initialized
INFO - 2023-09-25 08:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:14:06 --> Controller Class Initialized
DEBUG - 2023-09-25 08:14:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 08:14:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:14:06 --> Final output sent to browser
DEBUG - 2023-09-25 08:14:06 --> Total execution time: 0.0372
INFO - 2023-09-25 08:14:10 --> Config Class Initialized
INFO - 2023-09-25 08:14:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:14:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:14:10 --> Utf8 Class Initialized
INFO - 2023-09-25 08:14:10 --> URI Class Initialized
INFO - 2023-09-25 08:14:10 --> Router Class Initialized
INFO - 2023-09-25 08:14:10 --> Output Class Initialized
INFO - 2023-09-25 08:14:10 --> Security Class Initialized
DEBUG - 2023-09-25 08:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:14:10 --> Input Class Initialized
INFO - 2023-09-25 08:14:10 --> Language Class Initialized
INFO - 2023-09-25 08:14:10 --> Language Class Initialized
INFO - 2023-09-25 08:14:10 --> Config Class Initialized
INFO - 2023-09-25 08:14:10 --> Loader Class Initialized
INFO - 2023-09-25 08:14:10 --> Helper loaded: url_helper
INFO - 2023-09-25 08:14:10 --> Helper loaded: file_helper
INFO - 2023-09-25 08:14:10 --> Helper loaded: form_helper
INFO - 2023-09-25 08:14:10 --> Helper loaded: my_helper
INFO - 2023-09-25 08:14:10 --> Database Driver Class Initialized
INFO - 2023-09-25 08:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:14:10 --> Controller Class Initialized
INFO - 2023-09-25 08:14:10 --> Final output sent to browser
DEBUG - 2023-09-25 08:14:10 --> Total execution time: 0.0353
INFO - 2023-09-25 08:14:21 --> Config Class Initialized
INFO - 2023-09-25 08:14:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:14:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:14:21 --> Utf8 Class Initialized
INFO - 2023-09-25 08:14:21 --> URI Class Initialized
INFO - 2023-09-25 08:14:21 --> Router Class Initialized
INFO - 2023-09-25 08:14:21 --> Output Class Initialized
INFO - 2023-09-25 08:14:21 --> Security Class Initialized
DEBUG - 2023-09-25 08:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:14:21 --> Input Class Initialized
INFO - 2023-09-25 08:14:21 --> Language Class Initialized
INFO - 2023-09-25 08:14:21 --> Language Class Initialized
INFO - 2023-09-25 08:14:21 --> Config Class Initialized
INFO - 2023-09-25 08:14:21 --> Loader Class Initialized
INFO - 2023-09-25 08:14:21 --> Helper loaded: url_helper
INFO - 2023-09-25 08:14:21 --> Helper loaded: file_helper
INFO - 2023-09-25 08:14:21 --> Helper loaded: form_helper
INFO - 2023-09-25 08:14:21 --> Helper loaded: my_helper
INFO - 2023-09-25 08:14:21 --> Database Driver Class Initialized
INFO - 2023-09-25 08:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:14:21 --> Controller Class Initialized
INFO - 2023-09-25 08:14:21 --> Final output sent to browser
DEBUG - 2023-09-25 08:14:21 --> Total execution time: 0.0356
INFO - 2023-09-25 08:14:38 --> Config Class Initialized
INFO - 2023-09-25 08:14:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:14:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:14:38 --> Utf8 Class Initialized
INFO - 2023-09-25 08:14:38 --> URI Class Initialized
INFO - 2023-09-25 08:14:38 --> Router Class Initialized
INFO - 2023-09-25 08:14:38 --> Output Class Initialized
INFO - 2023-09-25 08:14:38 --> Security Class Initialized
DEBUG - 2023-09-25 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:14:38 --> Input Class Initialized
INFO - 2023-09-25 08:14:38 --> Language Class Initialized
INFO - 2023-09-25 08:14:38 --> Language Class Initialized
INFO - 2023-09-25 08:14:38 --> Config Class Initialized
INFO - 2023-09-25 08:14:38 --> Loader Class Initialized
INFO - 2023-09-25 08:14:38 --> Helper loaded: url_helper
INFO - 2023-09-25 08:14:38 --> Helper loaded: file_helper
INFO - 2023-09-25 08:14:38 --> Helper loaded: form_helper
INFO - 2023-09-25 08:14:38 --> Helper loaded: my_helper
INFO - 2023-09-25 08:14:38 --> Database Driver Class Initialized
INFO - 2023-09-25 08:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:14:38 --> Controller Class Initialized
INFO - 2023-09-25 08:14:38 --> Final output sent to browser
DEBUG - 2023-09-25 08:14:38 --> Total execution time: 0.0492
INFO - 2023-09-25 08:16:30 --> Config Class Initialized
INFO - 2023-09-25 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:30 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:30 --> URI Class Initialized
INFO - 2023-09-25 08:16:30 --> Router Class Initialized
INFO - 2023-09-25 08:16:30 --> Output Class Initialized
INFO - 2023-09-25 08:16:30 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:30 --> Input Class Initialized
INFO - 2023-09-25 08:16:30 --> Language Class Initialized
INFO - 2023-09-25 08:16:30 --> Language Class Initialized
INFO - 2023-09-25 08:16:30 --> Config Class Initialized
INFO - 2023-09-25 08:16:30 --> Loader Class Initialized
INFO - 2023-09-25 08:16:30 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:30 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:30 --> Controller Class Initialized
INFO - 2023-09-25 08:16:30 --> Helper loaded: cookie_helper
INFO - 2023-09-25 08:16:30 --> Final output sent to browser
DEBUG - 2023-09-25 08:16:30 --> Total execution time: 0.0404
INFO - 2023-09-25 08:16:30 --> Config Class Initialized
INFO - 2023-09-25 08:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:30 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:30 --> URI Class Initialized
INFO - 2023-09-25 08:16:30 --> Router Class Initialized
INFO - 2023-09-25 08:16:30 --> Output Class Initialized
INFO - 2023-09-25 08:16:30 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:30 --> Input Class Initialized
INFO - 2023-09-25 08:16:30 --> Language Class Initialized
INFO - 2023-09-25 08:16:30 --> Language Class Initialized
INFO - 2023-09-25 08:16:30 --> Config Class Initialized
INFO - 2023-09-25 08:16:30 --> Loader Class Initialized
INFO - 2023-09-25 08:16:30 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:30 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:30 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:30 --> Controller Class Initialized
DEBUG - 2023-09-25 08:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 08:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:16:30 --> Final output sent to browser
DEBUG - 2023-09-25 08:16:30 --> Total execution time: 0.0314
INFO - 2023-09-25 08:16:36 --> Config Class Initialized
INFO - 2023-09-25 08:16:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:36 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:36 --> URI Class Initialized
INFO - 2023-09-25 08:16:36 --> Router Class Initialized
INFO - 2023-09-25 08:16:36 --> Output Class Initialized
INFO - 2023-09-25 08:16:36 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:36 --> Input Class Initialized
INFO - 2023-09-25 08:16:36 --> Language Class Initialized
INFO - 2023-09-25 08:16:36 --> Language Class Initialized
INFO - 2023-09-25 08:16:36 --> Config Class Initialized
INFO - 2023-09-25 08:16:36 --> Loader Class Initialized
INFO - 2023-09-25 08:16:36 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:36 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:36 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:36 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:36 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:36 --> Controller Class Initialized
DEBUG - 2023-09-25 08:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 08:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:16:36 --> Final output sent to browser
DEBUG - 2023-09-25 08:16:36 --> Total execution time: 0.0339
INFO - 2023-09-25 08:16:39 --> Config Class Initialized
INFO - 2023-09-25 08:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:39 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:39 --> URI Class Initialized
INFO - 2023-09-25 08:16:39 --> Router Class Initialized
INFO - 2023-09-25 08:16:39 --> Output Class Initialized
INFO - 2023-09-25 08:16:39 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:39 --> Input Class Initialized
INFO - 2023-09-25 08:16:39 --> Language Class Initialized
INFO - 2023-09-25 08:16:39 --> Language Class Initialized
INFO - 2023-09-25 08:16:39 --> Config Class Initialized
INFO - 2023-09-25 08:16:39 --> Loader Class Initialized
INFO - 2023-09-25 08:16:39 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:39 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:39 --> Controller Class Initialized
DEBUG - 2023-09-25 08:16:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 08:16:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:16:39 --> Final output sent to browser
DEBUG - 2023-09-25 08:16:39 --> Total execution time: 0.0396
INFO - 2023-09-25 08:16:39 --> Config Class Initialized
INFO - 2023-09-25 08:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:39 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:39 --> URI Class Initialized
INFO - 2023-09-25 08:16:39 --> Router Class Initialized
INFO - 2023-09-25 08:16:39 --> Output Class Initialized
INFO - 2023-09-25 08:16:39 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:39 --> Input Class Initialized
INFO - 2023-09-25 08:16:39 --> Language Class Initialized
INFO - 2023-09-25 08:16:39 --> Language Class Initialized
INFO - 2023-09-25 08:16:39 --> Config Class Initialized
INFO - 2023-09-25 08:16:39 --> Loader Class Initialized
INFO - 2023-09-25 08:16:39 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:39 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:39 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:39 --> Controller Class Initialized
INFO - 2023-09-25 08:16:41 --> Config Class Initialized
INFO - 2023-09-25 08:16:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:16:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:16:41 --> Utf8 Class Initialized
INFO - 2023-09-25 08:16:41 --> URI Class Initialized
INFO - 2023-09-25 08:16:41 --> Router Class Initialized
INFO - 2023-09-25 08:16:41 --> Output Class Initialized
INFO - 2023-09-25 08:16:41 --> Security Class Initialized
DEBUG - 2023-09-25 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:16:41 --> Input Class Initialized
INFO - 2023-09-25 08:16:41 --> Language Class Initialized
INFO - 2023-09-25 08:16:41 --> Language Class Initialized
INFO - 2023-09-25 08:16:41 --> Config Class Initialized
INFO - 2023-09-25 08:16:41 --> Loader Class Initialized
INFO - 2023-09-25 08:16:41 --> Helper loaded: url_helper
INFO - 2023-09-25 08:16:41 --> Helper loaded: file_helper
INFO - 2023-09-25 08:16:41 --> Helper loaded: form_helper
INFO - 2023-09-25 08:16:41 --> Helper loaded: my_helper
INFO - 2023-09-25 08:16:41 --> Database Driver Class Initialized
INFO - 2023-09-25 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:16:41 --> Controller Class Initialized
INFO - 2023-09-25 08:16:41 --> Final output sent to browser
DEBUG - 2023-09-25 08:16:41 --> Total execution time: 0.0337
INFO - 2023-09-25 08:17:56 --> Config Class Initialized
INFO - 2023-09-25 08:17:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:17:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:17:56 --> Utf8 Class Initialized
INFO - 2023-09-25 08:17:56 --> URI Class Initialized
INFO - 2023-09-25 08:17:56 --> Router Class Initialized
INFO - 2023-09-25 08:17:56 --> Output Class Initialized
INFO - 2023-09-25 08:17:56 --> Security Class Initialized
DEBUG - 2023-09-25 08:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:17:56 --> Input Class Initialized
INFO - 2023-09-25 08:17:56 --> Language Class Initialized
INFO - 2023-09-25 08:17:56 --> Language Class Initialized
INFO - 2023-09-25 08:17:56 --> Config Class Initialized
INFO - 2023-09-25 08:17:56 --> Loader Class Initialized
INFO - 2023-09-25 08:17:56 --> Helper loaded: url_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: file_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: form_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: my_helper
INFO - 2023-09-25 08:17:56 --> Database Driver Class Initialized
INFO - 2023-09-25 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:17:56 --> Controller Class Initialized
INFO - 2023-09-25 08:17:56 --> Final output sent to browser
DEBUG - 2023-09-25 08:17:56 --> Total execution time: 0.1655
INFO - 2023-09-25 08:17:56 --> Config Class Initialized
INFO - 2023-09-25 08:17:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:17:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:17:56 --> Utf8 Class Initialized
INFO - 2023-09-25 08:17:56 --> URI Class Initialized
INFO - 2023-09-25 08:17:56 --> Router Class Initialized
INFO - 2023-09-25 08:17:56 --> Output Class Initialized
INFO - 2023-09-25 08:17:56 --> Security Class Initialized
DEBUG - 2023-09-25 08:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:17:56 --> Input Class Initialized
INFO - 2023-09-25 08:17:56 --> Language Class Initialized
INFO - 2023-09-25 08:17:56 --> Language Class Initialized
INFO - 2023-09-25 08:17:56 --> Config Class Initialized
INFO - 2023-09-25 08:17:56 --> Loader Class Initialized
INFO - 2023-09-25 08:17:56 --> Helper loaded: url_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: file_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: form_helper
INFO - 2023-09-25 08:17:56 --> Helper loaded: my_helper
INFO - 2023-09-25 08:17:56 --> Database Driver Class Initialized
INFO - 2023-09-25 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:17:56 --> Controller Class Initialized
INFO - 2023-09-25 08:18:03 --> Config Class Initialized
INFO - 2023-09-25 08:18:03 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:18:03 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:18:03 --> Utf8 Class Initialized
INFO - 2023-09-25 08:18:03 --> URI Class Initialized
INFO - 2023-09-25 08:18:03 --> Router Class Initialized
INFO - 2023-09-25 08:18:03 --> Output Class Initialized
INFO - 2023-09-25 08:18:03 --> Security Class Initialized
DEBUG - 2023-09-25 08:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:18:03 --> Input Class Initialized
INFO - 2023-09-25 08:18:03 --> Language Class Initialized
INFO - 2023-09-25 08:18:03 --> Language Class Initialized
INFO - 2023-09-25 08:18:03 --> Config Class Initialized
INFO - 2023-09-25 08:18:03 --> Loader Class Initialized
INFO - 2023-09-25 08:18:03 --> Helper loaded: url_helper
INFO - 2023-09-25 08:18:03 --> Helper loaded: file_helper
INFO - 2023-09-25 08:18:03 --> Helper loaded: form_helper
INFO - 2023-09-25 08:18:03 --> Helper loaded: my_helper
INFO - 2023-09-25 08:18:03 --> Database Driver Class Initialized
INFO - 2023-09-25 08:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:18:03 --> Controller Class Initialized
INFO - 2023-09-25 08:18:03 --> Final output sent to browser
DEBUG - 2023-09-25 08:18:03 --> Total execution time: 0.0828
INFO - 2023-09-25 08:18:06 --> Config Class Initialized
INFO - 2023-09-25 08:18:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:18:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:18:06 --> Utf8 Class Initialized
INFO - 2023-09-25 08:18:06 --> URI Class Initialized
INFO - 2023-09-25 08:18:06 --> Router Class Initialized
INFO - 2023-09-25 08:18:06 --> Output Class Initialized
INFO - 2023-09-25 08:18:06 --> Security Class Initialized
DEBUG - 2023-09-25 08:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:18:06 --> Input Class Initialized
INFO - 2023-09-25 08:18:06 --> Language Class Initialized
INFO - 2023-09-25 08:18:06 --> Language Class Initialized
INFO - 2023-09-25 08:18:06 --> Config Class Initialized
INFO - 2023-09-25 08:18:06 --> Loader Class Initialized
INFO - 2023-09-25 08:18:06 --> Helper loaded: url_helper
INFO - 2023-09-25 08:18:06 --> Helper loaded: file_helper
INFO - 2023-09-25 08:18:06 --> Helper loaded: form_helper
INFO - 2023-09-25 08:18:06 --> Helper loaded: my_helper
INFO - 2023-09-25 08:18:06 --> Database Driver Class Initialized
INFO - 2023-09-25 08:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:18:06 --> Controller Class Initialized
INFO - 2023-09-25 08:18:07 --> Final output sent to browser
DEBUG - 2023-09-25 08:18:07 --> Total execution time: 0.1689
INFO - 2023-09-25 08:18:07 --> Config Class Initialized
INFO - 2023-09-25 08:18:07 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:18:07 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:18:07 --> Utf8 Class Initialized
INFO - 2023-09-25 08:18:07 --> URI Class Initialized
INFO - 2023-09-25 08:18:07 --> Router Class Initialized
INFO - 2023-09-25 08:18:07 --> Output Class Initialized
INFO - 2023-09-25 08:18:07 --> Security Class Initialized
DEBUG - 2023-09-25 08:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:18:07 --> Input Class Initialized
INFO - 2023-09-25 08:18:07 --> Language Class Initialized
INFO - 2023-09-25 08:18:07 --> Language Class Initialized
INFO - 2023-09-25 08:18:07 --> Config Class Initialized
INFO - 2023-09-25 08:18:07 --> Loader Class Initialized
INFO - 2023-09-25 08:18:07 --> Helper loaded: url_helper
INFO - 2023-09-25 08:18:07 --> Helper loaded: file_helper
INFO - 2023-09-25 08:18:07 --> Helper loaded: form_helper
INFO - 2023-09-25 08:18:07 --> Helper loaded: my_helper
INFO - 2023-09-25 08:18:07 --> Database Driver Class Initialized
INFO - 2023-09-25 08:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:18:07 --> Controller Class Initialized
INFO - 2023-09-25 08:18:07 --> Final output sent to browser
DEBUG - 2023-09-25 08:18:07 --> Total execution time: 0.0584
INFO - 2023-09-25 08:23:56 --> Config Class Initialized
INFO - 2023-09-25 08:23:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:23:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:23:56 --> Utf8 Class Initialized
INFO - 2023-09-25 08:23:56 --> URI Class Initialized
INFO - 2023-09-25 08:23:56 --> Router Class Initialized
INFO - 2023-09-25 08:23:56 --> Output Class Initialized
INFO - 2023-09-25 08:23:56 --> Security Class Initialized
DEBUG - 2023-09-25 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:23:56 --> Input Class Initialized
INFO - 2023-09-25 08:23:56 --> Language Class Initialized
INFO - 2023-09-25 08:23:56 --> Language Class Initialized
INFO - 2023-09-25 08:23:56 --> Config Class Initialized
INFO - 2023-09-25 08:23:56 --> Loader Class Initialized
INFO - 2023-09-25 08:23:56 --> Helper loaded: url_helper
INFO - 2023-09-25 08:23:56 --> Helper loaded: file_helper
INFO - 2023-09-25 08:23:56 --> Helper loaded: form_helper
INFO - 2023-09-25 08:23:56 --> Helper loaded: my_helper
INFO - 2023-09-25 08:23:57 --> Database Driver Class Initialized
INFO - 2023-09-25 08:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:23:57 --> Controller Class Initialized
INFO - 2023-09-25 08:32:55 --> Config Class Initialized
INFO - 2023-09-25 08:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:32:55 --> Utf8 Class Initialized
INFO - 2023-09-25 08:32:55 --> URI Class Initialized
INFO - 2023-09-25 08:32:55 --> Router Class Initialized
INFO - 2023-09-25 08:32:55 --> Output Class Initialized
INFO - 2023-09-25 08:32:55 --> Security Class Initialized
DEBUG - 2023-09-25 08:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:32:55 --> Input Class Initialized
INFO - 2023-09-25 08:32:55 --> Language Class Initialized
INFO - 2023-09-25 08:32:55 --> Language Class Initialized
INFO - 2023-09-25 08:32:55 --> Config Class Initialized
INFO - 2023-09-25 08:32:55 --> Loader Class Initialized
INFO - 2023-09-25 08:32:55 --> Helper loaded: url_helper
INFO - 2023-09-25 08:32:55 --> Helper loaded: file_helper
INFO - 2023-09-25 08:32:55 --> Helper loaded: form_helper
INFO - 2023-09-25 08:32:55 --> Helper loaded: my_helper
INFO - 2023-09-25 08:32:55 --> Database Driver Class Initialized
INFO - 2023-09-25 08:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:32:55 --> Controller Class Initialized
DEBUG - 2023-09-25 08:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-25 08:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:32:55 --> Final output sent to browser
DEBUG - 2023-09-25 08:32:55 --> Total execution time: 0.0868
INFO - 2023-09-25 08:33:19 --> Config Class Initialized
INFO - 2023-09-25 08:33:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:33:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:33:19 --> Utf8 Class Initialized
INFO - 2023-09-25 08:33:19 --> URI Class Initialized
INFO - 2023-09-25 08:33:19 --> Router Class Initialized
INFO - 2023-09-25 08:33:19 --> Output Class Initialized
INFO - 2023-09-25 08:33:19 --> Security Class Initialized
DEBUG - 2023-09-25 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:33:19 --> Input Class Initialized
INFO - 2023-09-25 08:33:19 --> Language Class Initialized
INFO - 2023-09-25 08:33:19 --> Language Class Initialized
INFO - 2023-09-25 08:33:19 --> Config Class Initialized
INFO - 2023-09-25 08:33:19 --> Loader Class Initialized
INFO - 2023-09-25 08:33:19 --> Helper loaded: url_helper
INFO - 2023-09-25 08:33:19 --> Helper loaded: file_helper
INFO - 2023-09-25 08:33:19 --> Helper loaded: form_helper
INFO - 2023-09-25 08:33:19 --> Helper loaded: my_helper
INFO - 2023-09-25 08:33:19 --> Database Driver Class Initialized
INFO - 2023-09-25 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:33:19 --> Controller Class Initialized
INFO - 2023-09-25 08:33:20 --> Config Class Initialized
INFO - 2023-09-25 08:33:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:33:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:33:20 --> Utf8 Class Initialized
INFO - 2023-09-25 08:33:20 --> URI Class Initialized
INFO - 2023-09-25 08:33:20 --> Router Class Initialized
INFO - 2023-09-25 08:33:20 --> Output Class Initialized
INFO - 2023-09-25 08:33:20 --> Security Class Initialized
DEBUG - 2023-09-25 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:33:20 --> Input Class Initialized
INFO - 2023-09-25 08:33:20 --> Language Class Initialized
INFO - 2023-09-25 08:33:20 --> Language Class Initialized
INFO - 2023-09-25 08:33:20 --> Config Class Initialized
INFO - 2023-09-25 08:33:20 --> Loader Class Initialized
INFO - 2023-09-25 08:33:20 --> Helper loaded: url_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: file_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: form_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: my_helper
INFO - 2023-09-25 08:33:20 --> Database Driver Class Initialized
INFO - 2023-09-25 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:33:20 --> Controller Class Initialized
DEBUG - 2023-09-25 08:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 08:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:33:20 --> Final output sent to browser
DEBUG - 2023-09-25 08:33:20 --> Total execution time: 0.0459
INFO - 2023-09-25 08:33:20 --> Config Class Initialized
INFO - 2023-09-25 08:33:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:33:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:33:20 --> Utf8 Class Initialized
INFO - 2023-09-25 08:33:20 --> URI Class Initialized
INFO - 2023-09-25 08:33:20 --> Router Class Initialized
INFO - 2023-09-25 08:33:20 --> Output Class Initialized
INFO - 2023-09-25 08:33:20 --> Security Class Initialized
DEBUG - 2023-09-25 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:33:20 --> Input Class Initialized
INFO - 2023-09-25 08:33:20 --> Language Class Initialized
INFO - 2023-09-25 08:33:20 --> Language Class Initialized
INFO - 2023-09-25 08:33:20 --> Config Class Initialized
INFO - 2023-09-25 08:33:20 --> Loader Class Initialized
INFO - 2023-09-25 08:33:20 --> Helper loaded: url_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: file_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: form_helper
INFO - 2023-09-25 08:33:20 --> Helper loaded: my_helper
INFO - 2023-09-25 08:33:20 --> Database Driver Class Initialized
INFO - 2023-09-25 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:33:20 --> Controller Class Initialized
INFO - 2023-09-25 08:33:23 --> Config Class Initialized
INFO - 2023-09-25 08:33:23 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:33:23 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:33:23 --> Utf8 Class Initialized
INFO - 2023-09-25 08:33:23 --> URI Class Initialized
INFO - 2023-09-25 08:33:23 --> Router Class Initialized
INFO - 2023-09-25 08:33:23 --> Output Class Initialized
INFO - 2023-09-25 08:33:23 --> Security Class Initialized
DEBUG - 2023-09-25 08:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:33:23 --> Input Class Initialized
INFO - 2023-09-25 08:33:23 --> Language Class Initialized
INFO - 2023-09-25 08:33:23 --> Language Class Initialized
INFO - 2023-09-25 08:33:23 --> Config Class Initialized
INFO - 2023-09-25 08:33:23 --> Loader Class Initialized
INFO - 2023-09-25 08:33:23 --> Helper loaded: url_helper
INFO - 2023-09-25 08:33:23 --> Helper loaded: file_helper
INFO - 2023-09-25 08:33:23 --> Helper loaded: form_helper
INFO - 2023-09-25 08:33:23 --> Helper loaded: my_helper
INFO - 2023-09-25 08:33:23 --> Database Driver Class Initialized
INFO - 2023-09-25 08:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:33:23 --> Controller Class Initialized
INFO - 2023-09-25 08:33:23 --> Final output sent to browser
DEBUG - 2023-09-25 08:33:23 --> Total execution time: 0.1276
INFO - 2023-09-25 08:33:30 --> Config Class Initialized
INFO - 2023-09-25 08:33:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:33:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:33:30 --> Utf8 Class Initialized
INFO - 2023-09-25 08:33:30 --> URI Class Initialized
INFO - 2023-09-25 08:33:30 --> Router Class Initialized
INFO - 2023-09-25 08:33:30 --> Output Class Initialized
INFO - 2023-09-25 08:33:30 --> Security Class Initialized
DEBUG - 2023-09-25 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:33:30 --> Input Class Initialized
INFO - 2023-09-25 08:33:30 --> Language Class Initialized
INFO - 2023-09-25 08:33:30 --> Language Class Initialized
INFO - 2023-09-25 08:33:30 --> Config Class Initialized
INFO - 2023-09-25 08:33:30 --> Loader Class Initialized
INFO - 2023-09-25 08:33:30 --> Helper loaded: url_helper
INFO - 2023-09-25 08:33:30 --> Helper loaded: file_helper
INFO - 2023-09-25 08:33:30 --> Helper loaded: form_helper
INFO - 2023-09-25 08:33:30 --> Helper loaded: my_helper
INFO - 2023-09-25 08:33:30 --> Database Driver Class Initialized
INFO - 2023-09-25 08:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:33:30 --> Controller Class Initialized
INFO - 2023-09-25 08:33:30 --> Final output sent to browser
DEBUG - 2023-09-25 08:33:30 --> Total execution time: 0.0315
INFO - 2023-09-25 08:34:10 --> Config Class Initialized
INFO - 2023-09-25 08:34:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:10 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:10 --> URI Class Initialized
INFO - 2023-09-25 08:34:10 --> Router Class Initialized
INFO - 2023-09-25 08:34:10 --> Output Class Initialized
INFO - 2023-09-25 08:34:10 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:10 --> Input Class Initialized
INFO - 2023-09-25 08:34:10 --> Language Class Initialized
INFO - 2023-09-25 08:34:10 --> Language Class Initialized
INFO - 2023-09-25 08:34:10 --> Config Class Initialized
INFO - 2023-09-25 08:34:10 --> Loader Class Initialized
INFO - 2023-09-25 08:34:10 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:10 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:10 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:10 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:10 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:10 --> Controller Class Initialized
DEBUG - 2023-09-25 08:34:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-25 08:34:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:34:10 --> Final output sent to browser
DEBUG - 2023-09-25 08:34:10 --> Total execution time: 0.0865
INFO - 2023-09-25 08:34:12 --> Config Class Initialized
INFO - 2023-09-25 08:34:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:12 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:12 --> URI Class Initialized
INFO - 2023-09-25 08:34:12 --> Router Class Initialized
INFO - 2023-09-25 08:34:12 --> Output Class Initialized
INFO - 2023-09-25 08:34:12 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:12 --> Input Class Initialized
INFO - 2023-09-25 08:34:12 --> Language Class Initialized
INFO - 2023-09-25 08:34:12 --> Language Class Initialized
INFO - 2023-09-25 08:34:12 --> Config Class Initialized
INFO - 2023-09-25 08:34:12 --> Loader Class Initialized
INFO - 2023-09-25 08:34:12 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:12 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:12 --> Controller Class Initialized
DEBUG - 2023-09-25 08:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 08:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:34:12 --> Final output sent to browser
DEBUG - 2023-09-25 08:34:12 --> Total execution time: 0.0627
INFO - 2023-09-25 08:34:12 --> Config Class Initialized
INFO - 2023-09-25 08:34:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:12 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:12 --> URI Class Initialized
INFO - 2023-09-25 08:34:12 --> Router Class Initialized
INFO - 2023-09-25 08:34:12 --> Output Class Initialized
INFO - 2023-09-25 08:34:12 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:12 --> Input Class Initialized
INFO - 2023-09-25 08:34:12 --> Language Class Initialized
INFO - 2023-09-25 08:34:12 --> Language Class Initialized
INFO - 2023-09-25 08:34:12 --> Config Class Initialized
INFO - 2023-09-25 08:34:12 --> Loader Class Initialized
INFO - 2023-09-25 08:34:12 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:12 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:12 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:12 --> Controller Class Initialized
INFO - 2023-09-25 08:34:14 --> Config Class Initialized
INFO - 2023-09-25 08:34:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:14 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:14 --> URI Class Initialized
INFO - 2023-09-25 08:34:14 --> Router Class Initialized
INFO - 2023-09-25 08:34:14 --> Output Class Initialized
INFO - 2023-09-25 08:34:14 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:14 --> Input Class Initialized
INFO - 2023-09-25 08:34:14 --> Language Class Initialized
INFO - 2023-09-25 08:34:14 --> Language Class Initialized
INFO - 2023-09-25 08:34:14 --> Config Class Initialized
INFO - 2023-09-25 08:34:14 --> Loader Class Initialized
INFO - 2023-09-25 08:34:14 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:14 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:14 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:14 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:14 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:14 --> Controller Class Initialized
DEBUG - 2023-09-25 08:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 08:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:34:14 --> Final output sent to browser
DEBUG - 2023-09-25 08:34:14 --> Total execution time: 0.0386
INFO - 2023-09-25 08:34:15 --> Config Class Initialized
INFO - 2023-09-25 08:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:15 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:15 --> URI Class Initialized
INFO - 2023-09-25 08:34:15 --> Router Class Initialized
INFO - 2023-09-25 08:34:15 --> Output Class Initialized
INFO - 2023-09-25 08:34:15 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:15 --> Input Class Initialized
INFO - 2023-09-25 08:34:15 --> Language Class Initialized
INFO - 2023-09-25 08:34:15 --> Language Class Initialized
INFO - 2023-09-25 08:34:15 --> Config Class Initialized
INFO - 2023-09-25 08:34:15 --> Loader Class Initialized
INFO - 2023-09-25 08:34:15 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:15 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:15 --> Controller Class Initialized
DEBUG - 2023-09-25 08:34:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 08:34:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:34:15 --> Final output sent to browser
DEBUG - 2023-09-25 08:34:15 --> Total execution time: 0.0364
INFO - 2023-09-25 08:34:15 --> Config Class Initialized
INFO - 2023-09-25 08:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 08:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 08:34:15 --> Utf8 Class Initialized
INFO - 2023-09-25 08:34:15 --> URI Class Initialized
INFO - 2023-09-25 08:34:15 --> Router Class Initialized
INFO - 2023-09-25 08:34:15 --> Output Class Initialized
INFO - 2023-09-25 08:34:15 --> Security Class Initialized
DEBUG - 2023-09-25 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 08:34:15 --> Input Class Initialized
INFO - 2023-09-25 08:34:15 --> Language Class Initialized
INFO - 2023-09-25 08:34:15 --> Language Class Initialized
INFO - 2023-09-25 08:34:15 --> Config Class Initialized
INFO - 2023-09-25 08:34:15 --> Loader Class Initialized
INFO - 2023-09-25 08:34:15 --> Helper loaded: url_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: file_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: form_helper
INFO - 2023-09-25 08:34:15 --> Helper loaded: my_helper
INFO - 2023-09-25 08:34:15 --> Database Driver Class Initialized
INFO - 2023-09-25 08:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 08:34:15 --> Controller Class Initialized
DEBUG - 2023-09-25 08:34:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 08:34:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 08:34:15 --> Final output sent to browser
DEBUG - 2023-09-25 08:34:15 --> Total execution time: 0.0499
INFO - 2023-09-25 10:05:50 --> Config Class Initialized
INFO - 2023-09-25 10:05:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:50 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:50 --> URI Class Initialized
INFO - 2023-09-25 10:05:50 --> Router Class Initialized
INFO - 2023-09-25 10:05:50 --> Output Class Initialized
INFO - 2023-09-25 10:05:50 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:50 --> Input Class Initialized
INFO - 2023-09-25 10:05:50 --> Language Class Initialized
INFO - 2023-09-25 10:05:50 --> Language Class Initialized
INFO - 2023-09-25 10:05:50 --> Config Class Initialized
INFO - 2023-09-25 10:05:50 --> Loader Class Initialized
INFO - 2023-09-25 10:05:50 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:50 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:50 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:50 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:50 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:50 --> Controller Class Initialized
DEBUG - 2023-09-25 10:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 10:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:05:50 --> Final output sent to browser
DEBUG - 2023-09-25 10:05:50 --> Total execution time: 0.0664
INFO - 2023-09-25 10:05:53 --> Config Class Initialized
INFO - 2023-09-25 10:05:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:53 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:53 --> URI Class Initialized
INFO - 2023-09-25 10:05:53 --> Router Class Initialized
INFO - 2023-09-25 10:05:53 --> Output Class Initialized
INFO - 2023-09-25 10:05:53 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:53 --> Input Class Initialized
INFO - 2023-09-25 10:05:53 --> Language Class Initialized
INFO - 2023-09-25 10:05:53 --> Language Class Initialized
INFO - 2023-09-25 10:05:53 --> Config Class Initialized
INFO - 2023-09-25 10:05:53 --> Loader Class Initialized
INFO - 2023-09-25 10:05:53 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:53 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:53 --> Controller Class Initialized
INFO - 2023-09-25 10:05:53 --> Helper loaded: cookie_helper
INFO - 2023-09-25 10:05:53 --> Final output sent to browser
DEBUG - 2023-09-25 10:05:53 --> Total execution time: 0.1438
INFO - 2023-09-25 10:05:53 --> Config Class Initialized
INFO - 2023-09-25 10:05:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:53 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:53 --> URI Class Initialized
INFO - 2023-09-25 10:05:53 --> Router Class Initialized
INFO - 2023-09-25 10:05:53 --> Output Class Initialized
INFO - 2023-09-25 10:05:53 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:53 --> Input Class Initialized
INFO - 2023-09-25 10:05:53 --> Language Class Initialized
INFO - 2023-09-25 10:05:53 --> Language Class Initialized
INFO - 2023-09-25 10:05:53 --> Config Class Initialized
INFO - 2023-09-25 10:05:53 --> Loader Class Initialized
INFO - 2023-09-25 10:05:53 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:53 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:53 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:53 --> Controller Class Initialized
DEBUG - 2023-09-25 10:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 10:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:05:53 --> Final output sent to browser
DEBUG - 2023-09-25 10:05:53 --> Total execution time: 0.0379
INFO - 2023-09-25 10:05:55 --> Config Class Initialized
INFO - 2023-09-25 10:05:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:55 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:55 --> URI Class Initialized
INFO - 2023-09-25 10:05:55 --> Router Class Initialized
INFO - 2023-09-25 10:05:55 --> Output Class Initialized
INFO - 2023-09-25 10:05:55 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:55 --> Input Class Initialized
INFO - 2023-09-25 10:05:55 --> Language Class Initialized
INFO - 2023-09-25 10:05:55 --> Language Class Initialized
INFO - 2023-09-25 10:05:55 --> Config Class Initialized
INFO - 2023-09-25 10:05:55 --> Loader Class Initialized
INFO - 2023-09-25 10:05:55 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:55 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:55 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:55 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:55 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:55 --> Controller Class Initialized
DEBUG - 2023-09-25 10:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 10:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:05:55 --> Final output sent to browser
DEBUG - 2023-09-25 10:05:55 --> Total execution time: 0.1111
INFO - 2023-09-25 10:05:58 --> Config Class Initialized
INFO - 2023-09-25 10:05:58 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:58 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:58 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:58 --> URI Class Initialized
INFO - 2023-09-25 10:05:58 --> Router Class Initialized
INFO - 2023-09-25 10:05:58 --> Output Class Initialized
INFO - 2023-09-25 10:05:58 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:58 --> Input Class Initialized
INFO - 2023-09-25 10:05:58 --> Language Class Initialized
INFO - 2023-09-25 10:05:58 --> Language Class Initialized
INFO - 2023-09-25 10:05:58 --> Config Class Initialized
INFO - 2023-09-25 10:05:58 --> Loader Class Initialized
INFO - 2023-09-25 10:05:58 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:58 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:58 --> Controller Class Initialized
DEBUG - 2023-09-25 10:05:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 10:05:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:05:58 --> Final output sent to browser
DEBUG - 2023-09-25 10:05:58 --> Total execution time: 0.2016
INFO - 2023-09-25 10:05:58 --> Config Class Initialized
INFO - 2023-09-25 10:05:58 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:05:58 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:05:58 --> Utf8 Class Initialized
INFO - 2023-09-25 10:05:58 --> URI Class Initialized
INFO - 2023-09-25 10:05:58 --> Router Class Initialized
INFO - 2023-09-25 10:05:58 --> Output Class Initialized
INFO - 2023-09-25 10:05:58 --> Security Class Initialized
DEBUG - 2023-09-25 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:05:58 --> Input Class Initialized
INFO - 2023-09-25 10:05:58 --> Language Class Initialized
INFO - 2023-09-25 10:05:58 --> Language Class Initialized
INFO - 2023-09-25 10:05:58 --> Config Class Initialized
INFO - 2023-09-25 10:05:58 --> Loader Class Initialized
INFO - 2023-09-25 10:05:58 --> Helper loaded: url_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: file_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: form_helper
INFO - 2023-09-25 10:05:58 --> Helper loaded: my_helper
INFO - 2023-09-25 10:05:58 --> Database Driver Class Initialized
INFO - 2023-09-25 10:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:05:58 --> Controller Class Initialized
INFO - 2023-09-25 10:06:04 --> Config Class Initialized
INFO - 2023-09-25 10:06:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:06:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:06:04 --> Utf8 Class Initialized
INFO - 2023-09-25 10:06:04 --> URI Class Initialized
INFO - 2023-09-25 10:06:04 --> Router Class Initialized
INFO - 2023-09-25 10:06:04 --> Output Class Initialized
INFO - 2023-09-25 10:06:04 --> Security Class Initialized
DEBUG - 2023-09-25 10:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:06:04 --> Input Class Initialized
INFO - 2023-09-25 10:06:04 --> Language Class Initialized
INFO - 2023-09-25 10:06:04 --> Language Class Initialized
INFO - 2023-09-25 10:06:04 --> Config Class Initialized
INFO - 2023-09-25 10:06:04 --> Loader Class Initialized
INFO - 2023-09-25 10:06:04 --> Helper loaded: url_helper
INFO - 2023-09-25 10:06:04 --> Helper loaded: file_helper
INFO - 2023-09-25 10:06:04 --> Helper loaded: form_helper
INFO - 2023-09-25 10:06:04 --> Helper loaded: my_helper
INFO - 2023-09-25 10:06:04 --> Database Driver Class Initialized
INFO - 2023-09-25 10:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:06:04 --> Controller Class Initialized
INFO - 2023-09-25 10:06:04 --> Final output sent to browser
DEBUG - 2023-09-25 10:06:04 --> Total execution time: 0.0787
INFO - 2023-09-25 10:06:16 --> Config Class Initialized
INFO - 2023-09-25 10:06:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:06:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:06:16 --> Utf8 Class Initialized
INFO - 2023-09-25 10:06:16 --> URI Class Initialized
INFO - 2023-09-25 10:06:16 --> Router Class Initialized
INFO - 2023-09-25 10:06:16 --> Output Class Initialized
INFO - 2023-09-25 10:06:16 --> Security Class Initialized
DEBUG - 2023-09-25 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:06:16 --> Input Class Initialized
INFO - 2023-09-25 10:06:16 --> Language Class Initialized
INFO - 2023-09-25 10:06:16 --> Language Class Initialized
INFO - 2023-09-25 10:06:16 --> Config Class Initialized
INFO - 2023-09-25 10:06:16 --> Loader Class Initialized
INFO - 2023-09-25 10:06:16 --> Helper loaded: url_helper
INFO - 2023-09-25 10:06:16 --> Helper loaded: file_helper
INFO - 2023-09-25 10:06:16 --> Helper loaded: form_helper
INFO - 2023-09-25 10:06:16 --> Helper loaded: my_helper
INFO - 2023-09-25 10:06:16 --> Database Driver Class Initialized
INFO - 2023-09-25 10:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:06:16 --> Controller Class Initialized
INFO - 2023-09-25 10:06:17 --> Final output sent to browser
DEBUG - 2023-09-25 10:06:17 --> Total execution time: 0.2975
INFO - 2023-09-25 10:06:18 --> Config Class Initialized
INFO - 2023-09-25 10:06:18 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:06:18 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:06:18 --> Utf8 Class Initialized
INFO - 2023-09-25 10:06:18 --> URI Class Initialized
INFO - 2023-09-25 10:06:18 --> Router Class Initialized
INFO - 2023-09-25 10:06:18 --> Output Class Initialized
INFO - 2023-09-25 10:06:18 --> Security Class Initialized
DEBUG - 2023-09-25 10:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:06:18 --> Input Class Initialized
INFO - 2023-09-25 10:06:18 --> Language Class Initialized
INFO - 2023-09-25 10:06:18 --> Language Class Initialized
INFO - 2023-09-25 10:06:18 --> Config Class Initialized
INFO - 2023-09-25 10:06:18 --> Loader Class Initialized
INFO - 2023-09-25 10:06:18 --> Helper loaded: url_helper
INFO - 2023-09-25 10:06:18 --> Helper loaded: file_helper
INFO - 2023-09-25 10:06:18 --> Helper loaded: form_helper
INFO - 2023-09-25 10:06:18 --> Helper loaded: my_helper
INFO - 2023-09-25 10:06:18 --> Database Driver Class Initialized
INFO - 2023-09-25 10:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:06:18 --> Controller Class Initialized
INFO - 2023-09-25 10:06:18 --> Final output sent to browser
DEBUG - 2023-09-25 10:06:18 --> Total execution time: 0.0354
INFO - 2023-09-25 10:07:06 --> Config Class Initialized
INFO - 2023-09-25 10:07:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:06 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:06 --> URI Class Initialized
INFO - 2023-09-25 10:07:06 --> Router Class Initialized
INFO - 2023-09-25 10:07:06 --> Output Class Initialized
INFO - 2023-09-25 10:07:06 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:06 --> Input Class Initialized
INFO - 2023-09-25 10:07:06 --> Language Class Initialized
INFO - 2023-09-25 10:07:06 --> Language Class Initialized
INFO - 2023-09-25 10:07:06 --> Config Class Initialized
INFO - 2023-09-25 10:07:06 --> Loader Class Initialized
INFO - 2023-09-25 10:07:06 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:06 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:06 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:06 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:06 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:06 --> Controller Class Initialized
DEBUG - 2023-09-25 10:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 10:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:07:06 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:06 --> Total execution time: 0.1754
INFO - 2023-09-25 10:07:20 --> Config Class Initialized
INFO - 2023-09-25 10:07:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:20 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:20 --> URI Class Initialized
INFO - 2023-09-25 10:07:20 --> Router Class Initialized
INFO - 2023-09-25 10:07:20 --> Output Class Initialized
INFO - 2023-09-25 10:07:20 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:20 --> Input Class Initialized
INFO - 2023-09-25 10:07:20 --> Language Class Initialized
INFO - 2023-09-25 10:07:20 --> Language Class Initialized
INFO - 2023-09-25 10:07:20 --> Config Class Initialized
INFO - 2023-09-25 10:07:20 --> Loader Class Initialized
INFO - 2023-09-25 10:07:20 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:20 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:20 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:20 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:20 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:20 --> Controller Class Initialized
INFO - 2023-09-25 10:07:20 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:20 --> Total execution time: 0.0475
INFO - 2023-09-25 10:07:28 --> Config Class Initialized
INFO - 2023-09-25 10:07:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:28 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:28 --> URI Class Initialized
INFO - 2023-09-25 10:07:28 --> Router Class Initialized
INFO - 2023-09-25 10:07:28 --> Output Class Initialized
INFO - 2023-09-25 10:07:28 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:28 --> Input Class Initialized
INFO - 2023-09-25 10:07:28 --> Language Class Initialized
INFO - 2023-09-25 10:07:28 --> Language Class Initialized
INFO - 2023-09-25 10:07:28 --> Config Class Initialized
INFO - 2023-09-25 10:07:28 --> Loader Class Initialized
INFO - 2023-09-25 10:07:28 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:28 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:28 --> Controller Class Initialized
INFO - 2023-09-25 10:07:28 --> Helper loaded: cookie_helper
INFO - 2023-09-25 10:07:28 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:28 --> Total execution time: 0.0807
INFO - 2023-09-25 10:07:28 --> Config Class Initialized
INFO - 2023-09-25 10:07:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:28 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:28 --> URI Class Initialized
INFO - 2023-09-25 10:07:28 --> Router Class Initialized
INFO - 2023-09-25 10:07:28 --> Output Class Initialized
INFO - 2023-09-25 10:07:28 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:28 --> Input Class Initialized
INFO - 2023-09-25 10:07:28 --> Language Class Initialized
INFO - 2023-09-25 10:07:28 --> Language Class Initialized
INFO - 2023-09-25 10:07:28 --> Config Class Initialized
INFO - 2023-09-25 10:07:28 --> Loader Class Initialized
INFO - 2023-09-25 10:07:28 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:28 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:28 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:28 --> Controller Class Initialized
DEBUG - 2023-09-25 10:07:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 10:07:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:07:28 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:28 --> Total execution time: 0.0686
INFO - 2023-09-25 10:07:38 --> Config Class Initialized
INFO - 2023-09-25 10:07:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:38 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:38 --> URI Class Initialized
INFO - 2023-09-25 10:07:38 --> Router Class Initialized
INFO - 2023-09-25 10:07:38 --> Output Class Initialized
INFO - 2023-09-25 10:07:38 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:38 --> Input Class Initialized
INFO - 2023-09-25 10:07:38 --> Language Class Initialized
INFO - 2023-09-25 10:07:38 --> Language Class Initialized
INFO - 2023-09-25 10:07:38 --> Config Class Initialized
INFO - 2023-09-25 10:07:38 --> Loader Class Initialized
INFO - 2023-09-25 10:07:38 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:38 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:38 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:38 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:38 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:38 --> Controller Class Initialized
DEBUG - 2023-09-25 10:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 10:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:07:38 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:38 --> Total execution time: 0.0406
INFO - 2023-09-25 10:07:42 --> Config Class Initialized
INFO - 2023-09-25 10:07:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:42 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:42 --> URI Class Initialized
INFO - 2023-09-25 10:07:42 --> Router Class Initialized
INFO - 2023-09-25 10:07:42 --> Output Class Initialized
INFO - 2023-09-25 10:07:42 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:42 --> Input Class Initialized
INFO - 2023-09-25 10:07:42 --> Language Class Initialized
INFO - 2023-09-25 10:07:42 --> Language Class Initialized
INFO - 2023-09-25 10:07:42 --> Config Class Initialized
INFO - 2023-09-25 10:07:42 --> Loader Class Initialized
INFO - 2023-09-25 10:07:42 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:42 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:42 --> Controller Class Initialized
DEBUG - 2023-09-25 10:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 10:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:07:42 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:42 --> Total execution time: 0.0471
INFO - 2023-09-25 10:07:42 --> Config Class Initialized
INFO - 2023-09-25 10:07:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:42 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:42 --> URI Class Initialized
INFO - 2023-09-25 10:07:42 --> Router Class Initialized
INFO - 2023-09-25 10:07:42 --> Output Class Initialized
INFO - 2023-09-25 10:07:42 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:42 --> Input Class Initialized
INFO - 2023-09-25 10:07:42 --> Language Class Initialized
INFO - 2023-09-25 10:07:42 --> Language Class Initialized
INFO - 2023-09-25 10:07:42 --> Config Class Initialized
INFO - 2023-09-25 10:07:42 --> Loader Class Initialized
INFO - 2023-09-25 10:07:42 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:42 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:42 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:42 --> Controller Class Initialized
INFO - 2023-09-25 10:07:47 --> Config Class Initialized
INFO - 2023-09-25 10:07:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:47 --> URI Class Initialized
INFO - 2023-09-25 10:07:47 --> Router Class Initialized
INFO - 2023-09-25 10:07:47 --> Output Class Initialized
INFO - 2023-09-25 10:07:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:47 --> Input Class Initialized
INFO - 2023-09-25 10:07:47 --> Language Class Initialized
INFO - 2023-09-25 10:07:47 --> Language Class Initialized
INFO - 2023-09-25 10:07:47 --> Config Class Initialized
INFO - 2023-09-25 10:07:47 --> Loader Class Initialized
INFO - 2023-09-25 10:07:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:47 --> Controller Class Initialized
INFO - 2023-09-25 10:07:47 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:47 --> Total execution time: 0.0928
INFO - 2023-09-25 10:07:50 --> Config Class Initialized
INFO - 2023-09-25 10:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:50 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:50 --> URI Class Initialized
INFO - 2023-09-25 10:07:50 --> Router Class Initialized
INFO - 2023-09-25 10:07:50 --> Output Class Initialized
INFO - 2023-09-25 10:07:50 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:50 --> Input Class Initialized
INFO - 2023-09-25 10:07:50 --> Language Class Initialized
INFO - 2023-09-25 10:07:50 --> Language Class Initialized
INFO - 2023-09-25 10:07:50 --> Config Class Initialized
INFO - 2023-09-25 10:07:50 --> Loader Class Initialized
INFO - 2023-09-25 10:07:50 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:50 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:50 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:50 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:50 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:50 --> Controller Class Initialized
INFO - 2023-09-25 10:07:50 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:50 --> Total execution time: 0.0409
INFO - 2023-09-25 10:07:53 --> Config Class Initialized
INFO - 2023-09-25 10:07:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:53 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:53 --> URI Class Initialized
INFO - 2023-09-25 10:07:53 --> Router Class Initialized
INFO - 2023-09-25 10:07:53 --> Output Class Initialized
INFO - 2023-09-25 10:07:53 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:53 --> Input Class Initialized
INFO - 2023-09-25 10:07:53 --> Language Class Initialized
INFO - 2023-09-25 10:07:53 --> Language Class Initialized
INFO - 2023-09-25 10:07:53 --> Config Class Initialized
INFO - 2023-09-25 10:07:53 --> Loader Class Initialized
INFO - 2023-09-25 10:07:53 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:53 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:53 --> Controller Class Initialized
INFO - 2023-09-25 10:07:53 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:53 --> Total execution time: 0.0388
INFO - 2023-09-25 10:07:53 --> Config Class Initialized
INFO - 2023-09-25 10:07:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:07:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:07:53 --> Utf8 Class Initialized
INFO - 2023-09-25 10:07:53 --> URI Class Initialized
INFO - 2023-09-25 10:07:53 --> Router Class Initialized
INFO - 2023-09-25 10:07:53 --> Output Class Initialized
INFO - 2023-09-25 10:07:53 --> Security Class Initialized
DEBUG - 2023-09-25 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:07:53 --> Input Class Initialized
INFO - 2023-09-25 10:07:53 --> Language Class Initialized
INFO - 2023-09-25 10:07:53 --> Language Class Initialized
INFO - 2023-09-25 10:07:53 --> Config Class Initialized
INFO - 2023-09-25 10:07:53 --> Loader Class Initialized
INFO - 2023-09-25 10:07:53 --> Helper loaded: url_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: file_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: form_helper
INFO - 2023-09-25 10:07:53 --> Helper loaded: my_helper
INFO - 2023-09-25 10:07:53 --> Database Driver Class Initialized
INFO - 2023-09-25 10:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:07:53 --> Controller Class Initialized
INFO - 2023-09-25 10:07:53 --> Final output sent to browser
DEBUG - 2023-09-25 10:07:53 --> Total execution time: 0.0553
INFO - 2023-09-25 10:18:54 --> Config Class Initialized
INFO - 2023-09-25 10:18:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:18:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:18:54 --> Utf8 Class Initialized
INFO - 2023-09-25 10:18:54 --> URI Class Initialized
INFO - 2023-09-25 10:18:54 --> Router Class Initialized
INFO - 2023-09-25 10:18:54 --> Output Class Initialized
INFO - 2023-09-25 10:18:54 --> Security Class Initialized
DEBUG - 2023-09-25 10:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:18:54 --> Input Class Initialized
INFO - 2023-09-25 10:18:54 --> Language Class Initialized
INFO - 2023-09-25 10:18:54 --> Language Class Initialized
INFO - 2023-09-25 10:18:54 --> Config Class Initialized
INFO - 2023-09-25 10:18:54 --> Loader Class Initialized
INFO - 2023-09-25 10:18:54 --> Helper loaded: url_helper
INFO - 2023-09-25 10:18:54 --> Helper loaded: file_helper
INFO - 2023-09-25 10:18:54 --> Helper loaded: form_helper
INFO - 2023-09-25 10:18:54 --> Helper loaded: my_helper
INFO - 2023-09-25 10:18:54 --> Database Driver Class Initialized
INFO - 2023-09-25 10:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:18:54 --> Controller Class Initialized
INFO - 2023-09-25 10:18:55 --> Final output sent to browser
DEBUG - 2023-09-25 10:18:55 --> Total execution time: 0.5127
INFO - 2023-09-25 10:19:24 --> Config Class Initialized
INFO - 2023-09-25 10:19:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:19:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:19:24 --> Utf8 Class Initialized
INFO - 2023-09-25 10:19:24 --> URI Class Initialized
INFO - 2023-09-25 10:19:24 --> Router Class Initialized
INFO - 2023-09-25 10:19:24 --> Output Class Initialized
INFO - 2023-09-25 10:19:24 --> Security Class Initialized
DEBUG - 2023-09-25 10:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:19:24 --> Input Class Initialized
INFO - 2023-09-25 10:19:24 --> Language Class Initialized
INFO - 2023-09-25 10:19:24 --> Language Class Initialized
INFO - 2023-09-25 10:19:24 --> Config Class Initialized
INFO - 2023-09-25 10:19:24 --> Loader Class Initialized
INFO - 2023-09-25 10:19:24 --> Helper loaded: url_helper
INFO - 2023-09-25 10:19:24 --> Helper loaded: file_helper
INFO - 2023-09-25 10:19:24 --> Helper loaded: form_helper
INFO - 2023-09-25 10:19:24 --> Helper loaded: my_helper
INFO - 2023-09-25 10:19:24 --> Database Driver Class Initialized
INFO - 2023-09-25 10:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:19:24 --> Controller Class Initialized
INFO - 2023-09-25 10:19:24 --> Final output sent to browser
DEBUG - 2023-09-25 10:19:24 --> Total execution time: 0.0346
INFO - 2023-09-25 10:19:47 --> Config Class Initialized
INFO - 2023-09-25 10:19:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:19:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:19:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:19:47 --> URI Class Initialized
INFO - 2023-09-25 10:19:47 --> Router Class Initialized
INFO - 2023-09-25 10:19:47 --> Output Class Initialized
INFO - 2023-09-25 10:19:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:19:47 --> Input Class Initialized
INFO - 2023-09-25 10:19:47 --> Language Class Initialized
INFO - 2023-09-25 10:19:47 --> Language Class Initialized
INFO - 2023-09-25 10:19:47 --> Config Class Initialized
INFO - 2023-09-25 10:19:47 --> Loader Class Initialized
INFO - 2023-09-25 10:19:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:19:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:19:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:19:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:19:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:19:47 --> Controller Class Initialized
INFO - 2023-09-25 10:19:47 --> Final output sent to browser
DEBUG - 2023-09-25 10:19:47 --> Total execution time: 0.0541
INFO - 2023-09-25 10:20:55 --> Config Class Initialized
INFO - 2023-09-25 10:20:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:20:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:20:55 --> Utf8 Class Initialized
INFO - 2023-09-25 10:20:55 --> URI Class Initialized
INFO - 2023-09-25 10:20:55 --> Router Class Initialized
INFO - 2023-09-25 10:20:55 --> Output Class Initialized
INFO - 2023-09-25 10:20:55 --> Security Class Initialized
DEBUG - 2023-09-25 10:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:20:55 --> Input Class Initialized
INFO - 2023-09-25 10:20:55 --> Language Class Initialized
INFO - 2023-09-25 10:20:55 --> Language Class Initialized
INFO - 2023-09-25 10:20:55 --> Config Class Initialized
INFO - 2023-09-25 10:20:55 --> Loader Class Initialized
INFO - 2023-09-25 10:20:55 --> Helper loaded: url_helper
INFO - 2023-09-25 10:20:55 --> Helper loaded: file_helper
INFO - 2023-09-25 10:20:55 --> Helper loaded: form_helper
INFO - 2023-09-25 10:20:55 --> Helper loaded: my_helper
INFO - 2023-09-25 10:20:55 --> Database Driver Class Initialized
INFO - 2023-09-25 10:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:20:55 --> Controller Class Initialized
INFO - 2023-09-25 10:20:55 --> Final output sent to browser
DEBUG - 2023-09-25 10:20:55 --> Total execution time: 0.0792
INFO - 2023-09-25 10:21:51 --> Config Class Initialized
INFO - 2023-09-25 10:21:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:21:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:21:51 --> Utf8 Class Initialized
INFO - 2023-09-25 10:21:51 --> URI Class Initialized
INFO - 2023-09-25 10:21:51 --> Router Class Initialized
INFO - 2023-09-25 10:21:51 --> Output Class Initialized
INFO - 2023-09-25 10:21:51 --> Security Class Initialized
DEBUG - 2023-09-25 10:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:21:51 --> Input Class Initialized
INFO - 2023-09-25 10:21:51 --> Language Class Initialized
INFO - 2023-09-25 10:21:51 --> Language Class Initialized
INFO - 2023-09-25 10:21:51 --> Config Class Initialized
INFO - 2023-09-25 10:21:51 --> Loader Class Initialized
INFO - 2023-09-25 10:21:51 --> Helper loaded: url_helper
INFO - 2023-09-25 10:21:51 --> Helper loaded: file_helper
INFO - 2023-09-25 10:21:51 --> Helper loaded: form_helper
INFO - 2023-09-25 10:21:51 --> Helper loaded: my_helper
INFO - 2023-09-25 10:21:51 --> Database Driver Class Initialized
INFO - 2023-09-25 10:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:21:51 --> Controller Class Initialized
INFO - 2023-09-25 10:21:51 --> Final output sent to browser
DEBUG - 2023-09-25 10:21:51 --> Total execution time: 0.0401
INFO - 2023-09-25 10:25:34 --> Config Class Initialized
INFO - 2023-09-25 10:25:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:25:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:25:34 --> Utf8 Class Initialized
INFO - 2023-09-25 10:25:34 --> URI Class Initialized
INFO - 2023-09-25 10:25:34 --> Router Class Initialized
INFO - 2023-09-25 10:25:34 --> Output Class Initialized
INFO - 2023-09-25 10:25:34 --> Security Class Initialized
DEBUG - 2023-09-25 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:25:34 --> Input Class Initialized
INFO - 2023-09-25 10:25:34 --> Language Class Initialized
INFO - 2023-09-25 10:25:34 --> Language Class Initialized
INFO - 2023-09-25 10:25:34 --> Config Class Initialized
INFO - 2023-09-25 10:25:34 --> Loader Class Initialized
INFO - 2023-09-25 10:25:34 --> Helper loaded: url_helper
INFO - 2023-09-25 10:25:34 --> Helper loaded: file_helper
INFO - 2023-09-25 10:25:34 --> Helper loaded: form_helper
INFO - 2023-09-25 10:25:34 --> Helper loaded: my_helper
INFO - 2023-09-25 10:25:34 --> Database Driver Class Initialized
INFO - 2023-09-25 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:25:34 --> Controller Class Initialized
INFO - 2023-09-25 10:25:34 --> Final output sent to browser
DEBUG - 2023-09-25 10:25:34 --> Total execution time: 0.0846
INFO - 2023-09-25 10:26:47 --> Config Class Initialized
INFO - 2023-09-25 10:26:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:26:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:26:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:26:47 --> URI Class Initialized
INFO - 2023-09-25 10:26:47 --> Router Class Initialized
INFO - 2023-09-25 10:26:47 --> Output Class Initialized
INFO - 2023-09-25 10:26:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:26:47 --> Input Class Initialized
INFO - 2023-09-25 10:26:47 --> Language Class Initialized
INFO - 2023-09-25 10:26:47 --> Language Class Initialized
INFO - 2023-09-25 10:26:47 --> Config Class Initialized
INFO - 2023-09-25 10:26:47 --> Loader Class Initialized
INFO - 2023-09-25 10:26:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:26:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:26:47 --> Controller Class Initialized
INFO - 2023-09-25 10:26:47 --> Final output sent to browser
DEBUG - 2023-09-25 10:26:47 --> Total execution time: 0.0349
INFO - 2023-09-25 10:26:47 --> Config Class Initialized
INFO - 2023-09-25 10:26:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:26:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:26:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:26:47 --> URI Class Initialized
INFO - 2023-09-25 10:26:47 --> Router Class Initialized
INFO - 2023-09-25 10:26:47 --> Output Class Initialized
INFO - 2023-09-25 10:26:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:26:47 --> Input Class Initialized
INFO - 2023-09-25 10:26:47 --> Language Class Initialized
INFO - 2023-09-25 10:26:47 --> Language Class Initialized
INFO - 2023-09-25 10:26:47 --> Config Class Initialized
INFO - 2023-09-25 10:26:47 --> Loader Class Initialized
INFO - 2023-09-25 10:26:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:26:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:26:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:26:47 --> Controller Class Initialized
INFO - 2023-09-25 10:26:54 --> Config Class Initialized
INFO - 2023-09-25 10:26:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:26:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:26:54 --> Utf8 Class Initialized
INFO - 2023-09-25 10:26:54 --> URI Class Initialized
INFO - 2023-09-25 10:26:54 --> Router Class Initialized
INFO - 2023-09-25 10:26:54 --> Output Class Initialized
INFO - 2023-09-25 10:26:54 --> Security Class Initialized
DEBUG - 2023-09-25 10:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:26:54 --> Input Class Initialized
INFO - 2023-09-25 10:26:54 --> Language Class Initialized
INFO - 2023-09-25 10:26:54 --> Language Class Initialized
INFO - 2023-09-25 10:26:54 --> Config Class Initialized
INFO - 2023-09-25 10:26:54 --> Loader Class Initialized
INFO - 2023-09-25 10:26:54 --> Helper loaded: url_helper
INFO - 2023-09-25 10:26:54 --> Helper loaded: file_helper
INFO - 2023-09-25 10:26:54 --> Helper loaded: form_helper
INFO - 2023-09-25 10:26:54 --> Helper loaded: my_helper
INFO - 2023-09-25 10:26:54 --> Database Driver Class Initialized
INFO - 2023-09-25 10:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:26:54 --> Controller Class Initialized
INFO - 2023-09-25 10:26:54 --> Final output sent to browser
DEBUG - 2023-09-25 10:26:54 --> Total execution time: 0.0414
INFO - 2023-09-25 10:27:06 --> Config Class Initialized
INFO - 2023-09-25 10:27:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:27:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:27:06 --> Utf8 Class Initialized
INFO - 2023-09-25 10:27:06 --> URI Class Initialized
INFO - 2023-09-25 10:27:06 --> Router Class Initialized
INFO - 2023-09-25 10:27:06 --> Output Class Initialized
INFO - 2023-09-25 10:27:06 --> Security Class Initialized
DEBUG - 2023-09-25 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:27:06 --> Input Class Initialized
INFO - 2023-09-25 10:27:06 --> Language Class Initialized
INFO - 2023-09-25 10:27:06 --> Language Class Initialized
INFO - 2023-09-25 10:27:06 --> Config Class Initialized
INFO - 2023-09-25 10:27:06 --> Loader Class Initialized
INFO - 2023-09-25 10:27:06 --> Helper loaded: url_helper
INFO - 2023-09-25 10:27:06 --> Helper loaded: file_helper
INFO - 2023-09-25 10:27:06 --> Helper loaded: form_helper
INFO - 2023-09-25 10:27:06 --> Helper loaded: my_helper
INFO - 2023-09-25 10:27:06 --> Database Driver Class Initialized
INFO - 2023-09-25 10:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:27:06 --> Controller Class Initialized
INFO - 2023-09-25 10:27:06 --> Final output sent to browser
DEBUG - 2023-09-25 10:27:06 --> Total execution time: 0.0617
INFO - 2023-09-25 10:29:32 --> Config Class Initialized
INFO - 2023-09-25 10:29:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:29:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:29:32 --> Utf8 Class Initialized
INFO - 2023-09-25 10:29:32 --> URI Class Initialized
INFO - 2023-09-25 10:29:32 --> Router Class Initialized
INFO - 2023-09-25 10:29:32 --> Output Class Initialized
INFO - 2023-09-25 10:29:32 --> Security Class Initialized
DEBUG - 2023-09-25 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:29:32 --> Input Class Initialized
INFO - 2023-09-25 10:29:32 --> Language Class Initialized
INFO - 2023-09-25 10:29:32 --> Language Class Initialized
INFO - 2023-09-25 10:29:32 --> Config Class Initialized
INFO - 2023-09-25 10:29:32 --> Loader Class Initialized
INFO - 2023-09-25 10:29:32 --> Helper loaded: url_helper
INFO - 2023-09-25 10:29:32 --> Helper loaded: file_helper
INFO - 2023-09-25 10:29:32 --> Helper loaded: form_helper
INFO - 2023-09-25 10:29:32 --> Helper loaded: my_helper
INFO - 2023-09-25 10:29:32 --> Database Driver Class Initialized
INFO - 2023-09-25 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:29:32 --> Controller Class Initialized
INFO - 2023-09-25 10:29:32 --> Final output sent to browser
DEBUG - 2023-09-25 10:29:32 --> Total execution time: 0.0693
INFO - 2023-09-25 10:29:59 --> Config Class Initialized
INFO - 2023-09-25 10:29:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:29:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:29:59 --> Utf8 Class Initialized
INFO - 2023-09-25 10:29:59 --> URI Class Initialized
INFO - 2023-09-25 10:29:59 --> Router Class Initialized
INFO - 2023-09-25 10:29:59 --> Output Class Initialized
INFO - 2023-09-25 10:29:59 --> Security Class Initialized
DEBUG - 2023-09-25 10:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:29:59 --> Input Class Initialized
INFO - 2023-09-25 10:29:59 --> Language Class Initialized
INFO - 2023-09-25 10:29:59 --> Language Class Initialized
INFO - 2023-09-25 10:29:59 --> Config Class Initialized
INFO - 2023-09-25 10:29:59 --> Loader Class Initialized
INFO - 2023-09-25 10:29:59 --> Helper loaded: url_helper
INFO - 2023-09-25 10:29:59 --> Helper loaded: file_helper
INFO - 2023-09-25 10:29:59 --> Helper loaded: form_helper
INFO - 2023-09-25 10:29:59 --> Helper loaded: my_helper
INFO - 2023-09-25 10:29:59 --> Database Driver Class Initialized
INFO - 2023-09-25 10:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:29:59 --> Controller Class Initialized
INFO - 2023-09-25 10:29:59 --> Final output sent to browser
DEBUG - 2023-09-25 10:29:59 --> Total execution time: 0.0416
INFO - 2023-09-25 10:30:00 --> Config Class Initialized
INFO - 2023-09-25 10:30:00 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:30:00 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:30:00 --> Utf8 Class Initialized
INFO - 2023-09-25 10:30:00 --> URI Class Initialized
INFO - 2023-09-25 10:30:00 --> Router Class Initialized
INFO - 2023-09-25 10:30:00 --> Output Class Initialized
INFO - 2023-09-25 10:30:00 --> Security Class Initialized
DEBUG - 2023-09-25 10:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:30:00 --> Input Class Initialized
INFO - 2023-09-25 10:30:00 --> Language Class Initialized
INFO - 2023-09-25 10:30:00 --> Language Class Initialized
INFO - 2023-09-25 10:30:00 --> Config Class Initialized
INFO - 2023-09-25 10:30:00 --> Loader Class Initialized
INFO - 2023-09-25 10:30:00 --> Helper loaded: url_helper
INFO - 2023-09-25 10:30:00 --> Helper loaded: file_helper
INFO - 2023-09-25 10:30:00 --> Helper loaded: form_helper
INFO - 2023-09-25 10:30:00 --> Helper loaded: my_helper
INFO - 2023-09-25 10:30:00 --> Database Driver Class Initialized
INFO - 2023-09-25 10:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:30:00 --> Controller Class Initialized
INFO - 2023-09-25 10:34:30 --> Config Class Initialized
INFO - 2023-09-25 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:34:30 --> Utf8 Class Initialized
INFO - 2023-09-25 10:34:30 --> URI Class Initialized
INFO - 2023-09-25 10:34:30 --> Router Class Initialized
INFO - 2023-09-25 10:34:30 --> Output Class Initialized
INFO - 2023-09-25 10:34:30 --> Security Class Initialized
DEBUG - 2023-09-25 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:34:30 --> Input Class Initialized
INFO - 2023-09-25 10:34:30 --> Language Class Initialized
INFO - 2023-09-25 10:34:30 --> Language Class Initialized
INFO - 2023-09-25 10:34:30 --> Config Class Initialized
INFO - 2023-09-25 10:34:30 --> Loader Class Initialized
INFO - 2023-09-25 10:34:30 --> Helper loaded: url_helper
INFO - 2023-09-25 10:34:30 --> Helper loaded: file_helper
INFO - 2023-09-25 10:34:30 --> Helper loaded: form_helper
INFO - 2023-09-25 10:34:30 --> Helper loaded: my_helper
INFO - 2023-09-25 10:34:30 --> Database Driver Class Initialized
INFO - 2023-09-25 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:34:30 --> Controller Class Initialized
INFO - 2023-09-25 10:34:30 --> Final output sent to browser
DEBUG - 2023-09-25 10:34:30 --> Total execution time: 0.0482
INFO - 2023-09-25 10:34:47 --> Config Class Initialized
INFO - 2023-09-25 10:34:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:34:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:34:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:34:47 --> URI Class Initialized
INFO - 2023-09-25 10:34:47 --> Router Class Initialized
INFO - 2023-09-25 10:34:47 --> Output Class Initialized
INFO - 2023-09-25 10:34:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:34:47 --> Input Class Initialized
INFO - 2023-09-25 10:34:47 --> Language Class Initialized
INFO - 2023-09-25 10:34:47 --> Language Class Initialized
INFO - 2023-09-25 10:34:47 --> Config Class Initialized
INFO - 2023-09-25 10:34:47 --> Loader Class Initialized
INFO - 2023-09-25 10:34:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:34:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:34:47 --> Controller Class Initialized
INFO - 2023-09-25 10:34:47 --> Final output sent to browser
DEBUG - 2023-09-25 10:34:47 --> Total execution time: 0.0412
INFO - 2023-09-25 10:34:47 --> Config Class Initialized
INFO - 2023-09-25 10:34:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:34:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:34:47 --> Utf8 Class Initialized
INFO - 2023-09-25 10:34:47 --> URI Class Initialized
INFO - 2023-09-25 10:34:47 --> Router Class Initialized
INFO - 2023-09-25 10:34:47 --> Output Class Initialized
INFO - 2023-09-25 10:34:47 --> Security Class Initialized
DEBUG - 2023-09-25 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:34:47 --> Input Class Initialized
INFO - 2023-09-25 10:34:47 --> Language Class Initialized
INFO - 2023-09-25 10:34:47 --> Language Class Initialized
INFO - 2023-09-25 10:34:47 --> Config Class Initialized
INFO - 2023-09-25 10:34:47 --> Loader Class Initialized
INFO - 2023-09-25 10:34:47 --> Helper loaded: url_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: file_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: form_helper
INFO - 2023-09-25 10:34:47 --> Helper loaded: my_helper
INFO - 2023-09-25 10:34:47 --> Database Driver Class Initialized
INFO - 2023-09-25 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:34:47 --> Controller Class Initialized
INFO - 2023-09-25 10:35:19 --> Config Class Initialized
INFO - 2023-09-25 10:35:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:35:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:35:19 --> Utf8 Class Initialized
INFO - 2023-09-25 10:35:19 --> URI Class Initialized
INFO - 2023-09-25 10:35:19 --> Router Class Initialized
INFO - 2023-09-25 10:35:19 --> Output Class Initialized
INFO - 2023-09-25 10:35:19 --> Security Class Initialized
DEBUG - 2023-09-25 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:35:19 --> Input Class Initialized
INFO - 2023-09-25 10:35:19 --> Language Class Initialized
INFO - 2023-09-25 10:35:19 --> Language Class Initialized
INFO - 2023-09-25 10:35:19 --> Config Class Initialized
INFO - 2023-09-25 10:35:19 --> Loader Class Initialized
INFO - 2023-09-25 10:35:19 --> Helper loaded: url_helper
INFO - 2023-09-25 10:35:19 --> Helper loaded: file_helper
INFO - 2023-09-25 10:35:19 --> Helper loaded: form_helper
INFO - 2023-09-25 10:35:19 --> Helper loaded: my_helper
INFO - 2023-09-25 10:35:19 --> Database Driver Class Initialized
INFO - 2023-09-25 10:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:35:19 --> Controller Class Initialized
INFO - 2023-09-25 10:35:19 --> Final output sent to browser
DEBUG - 2023-09-25 10:35:19 --> Total execution time: 0.0621
INFO - 2023-09-25 10:48:12 --> Config Class Initialized
INFO - 2023-09-25 10:48:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:12 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:12 --> URI Class Initialized
INFO - 2023-09-25 10:48:12 --> Router Class Initialized
INFO - 2023-09-25 10:48:12 --> Output Class Initialized
INFO - 2023-09-25 10:48:12 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:12 --> Input Class Initialized
INFO - 2023-09-25 10:48:12 --> Language Class Initialized
INFO - 2023-09-25 10:48:12 --> Language Class Initialized
INFO - 2023-09-25 10:48:12 --> Config Class Initialized
INFO - 2023-09-25 10:48:12 --> Loader Class Initialized
INFO - 2023-09-25 10:48:12 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:12 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:12 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:12 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:13 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:13 --> Controller Class Initialized
INFO - 2023-09-25 10:48:13 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:13 --> Total execution time: 0.4124
INFO - 2023-09-25 10:48:19 --> Config Class Initialized
INFO - 2023-09-25 10:48:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:19 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:19 --> URI Class Initialized
INFO - 2023-09-25 10:48:19 --> Router Class Initialized
INFO - 2023-09-25 10:48:19 --> Output Class Initialized
INFO - 2023-09-25 10:48:19 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:19 --> Input Class Initialized
INFO - 2023-09-25 10:48:19 --> Language Class Initialized
INFO - 2023-09-25 10:48:19 --> Language Class Initialized
INFO - 2023-09-25 10:48:19 --> Config Class Initialized
INFO - 2023-09-25 10:48:19 --> Loader Class Initialized
INFO - 2023-09-25 10:48:19 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:19 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:19 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:19 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:19 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:19 --> Controller Class Initialized
INFO - 2023-09-25 10:48:19 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:19 --> Total execution time: 0.0553
INFO - 2023-09-25 10:48:21 --> Config Class Initialized
INFO - 2023-09-25 10:48:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:21 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:21 --> URI Class Initialized
INFO - 2023-09-25 10:48:21 --> Router Class Initialized
INFO - 2023-09-25 10:48:21 --> Output Class Initialized
INFO - 2023-09-25 10:48:21 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:21 --> Input Class Initialized
INFO - 2023-09-25 10:48:21 --> Language Class Initialized
INFO - 2023-09-25 10:48:21 --> Language Class Initialized
INFO - 2023-09-25 10:48:21 --> Config Class Initialized
INFO - 2023-09-25 10:48:21 --> Loader Class Initialized
INFO - 2023-09-25 10:48:21 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:21 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:21 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:21 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:21 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:21 --> Controller Class Initialized
INFO - 2023-09-25 10:48:21 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:21 --> Total execution time: 0.0602
INFO - 2023-09-25 10:48:48 --> Config Class Initialized
INFO - 2023-09-25 10:48:48 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:48 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:48 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:48 --> URI Class Initialized
INFO - 2023-09-25 10:48:48 --> Router Class Initialized
INFO - 2023-09-25 10:48:48 --> Output Class Initialized
INFO - 2023-09-25 10:48:48 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:48 --> Input Class Initialized
INFO - 2023-09-25 10:48:48 --> Language Class Initialized
INFO - 2023-09-25 10:48:48 --> Language Class Initialized
INFO - 2023-09-25 10:48:48 --> Config Class Initialized
INFO - 2023-09-25 10:48:48 --> Loader Class Initialized
INFO - 2023-09-25 10:48:48 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:48 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:48 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:48 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:48 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:48 --> Controller Class Initialized
INFO - 2023-09-25 10:48:48 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:48 --> Total execution time: 0.0404
INFO - 2023-09-25 10:48:49 --> Config Class Initialized
INFO - 2023-09-25 10:48:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:49 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:49 --> URI Class Initialized
INFO - 2023-09-25 10:48:49 --> Router Class Initialized
INFO - 2023-09-25 10:48:49 --> Output Class Initialized
INFO - 2023-09-25 10:48:49 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:49 --> Input Class Initialized
INFO - 2023-09-25 10:48:49 --> Language Class Initialized
INFO - 2023-09-25 10:48:49 --> Language Class Initialized
INFO - 2023-09-25 10:48:49 --> Config Class Initialized
INFO - 2023-09-25 10:48:49 --> Loader Class Initialized
INFO - 2023-09-25 10:48:49 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:49 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:49 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:49 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:49 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:49 --> Controller Class Initialized
INFO - 2023-09-25 10:48:49 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:49 --> Total execution time: 0.0823
INFO - 2023-09-25 10:48:55 --> Config Class Initialized
INFO - 2023-09-25 10:48:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:55 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:55 --> URI Class Initialized
INFO - 2023-09-25 10:48:55 --> Router Class Initialized
INFO - 2023-09-25 10:48:55 --> Output Class Initialized
INFO - 2023-09-25 10:48:55 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:55 --> Input Class Initialized
INFO - 2023-09-25 10:48:55 --> Language Class Initialized
INFO - 2023-09-25 10:48:55 --> Language Class Initialized
INFO - 2023-09-25 10:48:55 --> Config Class Initialized
INFO - 2023-09-25 10:48:55 --> Loader Class Initialized
INFO - 2023-09-25 10:48:55 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:55 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:55 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:55 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:55 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:55 --> Controller Class Initialized
INFO - 2023-09-25 10:48:55 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:55 --> Total execution time: 0.0699
INFO - 2023-09-25 10:48:58 --> Config Class Initialized
INFO - 2023-09-25 10:48:58 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:48:58 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:48:58 --> Utf8 Class Initialized
INFO - 2023-09-25 10:48:58 --> URI Class Initialized
INFO - 2023-09-25 10:48:58 --> Router Class Initialized
INFO - 2023-09-25 10:48:58 --> Output Class Initialized
INFO - 2023-09-25 10:48:58 --> Security Class Initialized
DEBUG - 2023-09-25 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:48:58 --> Input Class Initialized
INFO - 2023-09-25 10:48:58 --> Language Class Initialized
INFO - 2023-09-25 10:48:58 --> Language Class Initialized
INFO - 2023-09-25 10:48:58 --> Config Class Initialized
INFO - 2023-09-25 10:48:58 --> Loader Class Initialized
INFO - 2023-09-25 10:48:58 --> Helper loaded: url_helper
INFO - 2023-09-25 10:48:58 --> Helper loaded: file_helper
INFO - 2023-09-25 10:48:58 --> Helper loaded: form_helper
INFO - 2023-09-25 10:48:58 --> Helper loaded: my_helper
INFO - 2023-09-25 10:48:58 --> Database Driver Class Initialized
INFO - 2023-09-25 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:48:58 --> Controller Class Initialized
INFO - 2023-09-25 10:48:58 --> Final output sent to browser
DEBUG - 2023-09-25 10:48:58 --> Total execution time: 0.0935
INFO - 2023-09-25 10:49:01 --> Config Class Initialized
INFO - 2023-09-25 10:49:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:49:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:49:01 --> Utf8 Class Initialized
INFO - 2023-09-25 10:49:01 --> URI Class Initialized
INFO - 2023-09-25 10:49:01 --> Router Class Initialized
INFO - 2023-09-25 10:49:01 --> Output Class Initialized
INFO - 2023-09-25 10:49:01 --> Security Class Initialized
DEBUG - 2023-09-25 10:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:49:01 --> Input Class Initialized
INFO - 2023-09-25 10:49:01 --> Language Class Initialized
INFO - 2023-09-25 10:49:02 --> Language Class Initialized
INFO - 2023-09-25 10:49:02 --> Config Class Initialized
INFO - 2023-09-25 10:49:02 --> Loader Class Initialized
INFO - 2023-09-25 10:49:02 --> Helper loaded: url_helper
INFO - 2023-09-25 10:49:02 --> Helper loaded: file_helper
INFO - 2023-09-25 10:49:02 --> Helper loaded: form_helper
INFO - 2023-09-25 10:49:02 --> Helper loaded: my_helper
INFO - 2023-09-25 10:49:02 --> Database Driver Class Initialized
INFO - 2023-09-25 10:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:49:02 --> Controller Class Initialized
INFO - 2023-09-25 10:49:02 --> Final output sent to browser
DEBUG - 2023-09-25 10:49:02 --> Total execution time: 0.1149
INFO - 2023-09-25 10:49:03 --> Config Class Initialized
INFO - 2023-09-25 10:49:03 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:49:03 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:49:03 --> Utf8 Class Initialized
INFO - 2023-09-25 10:49:03 --> URI Class Initialized
INFO - 2023-09-25 10:49:03 --> Router Class Initialized
INFO - 2023-09-25 10:49:03 --> Output Class Initialized
INFO - 2023-09-25 10:49:03 --> Security Class Initialized
DEBUG - 2023-09-25 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:49:03 --> Input Class Initialized
INFO - 2023-09-25 10:49:03 --> Language Class Initialized
INFO - 2023-09-25 10:49:03 --> Language Class Initialized
INFO - 2023-09-25 10:49:03 --> Config Class Initialized
INFO - 2023-09-25 10:49:03 --> Loader Class Initialized
INFO - 2023-09-25 10:49:03 --> Helper loaded: url_helper
INFO - 2023-09-25 10:49:03 --> Helper loaded: file_helper
INFO - 2023-09-25 10:49:03 --> Helper loaded: form_helper
INFO - 2023-09-25 10:49:03 --> Helper loaded: my_helper
INFO - 2023-09-25 10:49:03 --> Database Driver Class Initialized
INFO - 2023-09-25 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:49:03 --> Controller Class Initialized
INFO - 2023-09-25 10:49:03 --> Final output sent to browser
DEBUG - 2023-09-25 10:49:03 --> Total execution time: 0.0609
INFO - 2023-09-25 10:51:41 --> Config Class Initialized
INFO - 2023-09-25 10:51:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:51:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:51:41 --> Utf8 Class Initialized
INFO - 2023-09-25 10:51:41 --> URI Class Initialized
INFO - 2023-09-25 10:51:41 --> Router Class Initialized
INFO - 2023-09-25 10:51:41 --> Output Class Initialized
INFO - 2023-09-25 10:51:41 --> Security Class Initialized
DEBUG - 2023-09-25 10:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:51:41 --> Input Class Initialized
INFO - 2023-09-25 10:51:41 --> Language Class Initialized
INFO - 2023-09-25 10:51:41 --> Language Class Initialized
INFO - 2023-09-25 10:51:41 --> Config Class Initialized
INFO - 2023-09-25 10:51:41 --> Loader Class Initialized
INFO - 2023-09-25 10:51:41 --> Helper loaded: url_helper
INFO - 2023-09-25 10:51:41 --> Helper loaded: file_helper
INFO - 2023-09-25 10:51:41 --> Helper loaded: form_helper
INFO - 2023-09-25 10:51:41 --> Helper loaded: my_helper
INFO - 2023-09-25 10:51:41 --> Database Driver Class Initialized
INFO - 2023-09-25 10:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:51:41 --> Controller Class Initialized
INFO - 2023-09-25 10:51:41 --> Final output sent to browser
DEBUG - 2023-09-25 10:51:41 --> Total execution time: 0.0690
INFO - 2023-09-25 10:51:50 --> Config Class Initialized
INFO - 2023-09-25 10:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:51:50 --> Utf8 Class Initialized
INFO - 2023-09-25 10:51:50 --> URI Class Initialized
INFO - 2023-09-25 10:51:50 --> Router Class Initialized
INFO - 2023-09-25 10:51:50 --> Output Class Initialized
INFO - 2023-09-25 10:51:50 --> Security Class Initialized
DEBUG - 2023-09-25 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:51:50 --> Input Class Initialized
INFO - 2023-09-25 10:51:50 --> Language Class Initialized
INFO - 2023-09-25 10:51:50 --> Language Class Initialized
INFO - 2023-09-25 10:51:50 --> Config Class Initialized
INFO - 2023-09-25 10:51:50 --> Loader Class Initialized
INFO - 2023-09-25 10:51:50 --> Helper loaded: url_helper
INFO - 2023-09-25 10:51:50 --> Helper loaded: file_helper
INFO - 2023-09-25 10:51:50 --> Helper loaded: form_helper
INFO - 2023-09-25 10:51:50 --> Helper loaded: my_helper
INFO - 2023-09-25 10:51:50 --> Database Driver Class Initialized
INFO - 2023-09-25 10:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:51:50 --> Controller Class Initialized
INFO - 2023-09-25 10:51:50 --> Final output sent to browser
DEBUG - 2023-09-25 10:51:50 --> Total execution time: 0.1173
INFO - 2023-09-25 10:54:51 --> Config Class Initialized
INFO - 2023-09-25 10:54:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:54:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:54:51 --> Utf8 Class Initialized
INFO - 2023-09-25 10:54:51 --> URI Class Initialized
INFO - 2023-09-25 10:54:51 --> Router Class Initialized
INFO - 2023-09-25 10:54:51 --> Output Class Initialized
INFO - 2023-09-25 10:54:51 --> Security Class Initialized
DEBUG - 2023-09-25 10:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:54:51 --> Input Class Initialized
INFO - 2023-09-25 10:54:51 --> Language Class Initialized
INFO - 2023-09-25 10:54:51 --> Language Class Initialized
INFO - 2023-09-25 10:54:51 --> Config Class Initialized
INFO - 2023-09-25 10:54:51 --> Loader Class Initialized
INFO - 2023-09-25 10:54:51 --> Helper loaded: url_helper
INFO - 2023-09-25 10:54:51 --> Helper loaded: file_helper
INFO - 2023-09-25 10:54:51 --> Helper loaded: form_helper
INFO - 2023-09-25 10:54:51 --> Helper loaded: my_helper
INFO - 2023-09-25 10:54:51 --> Database Driver Class Initialized
INFO - 2023-09-25 10:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:54:51 --> Controller Class Initialized
INFO - 2023-09-25 10:54:51 --> Final output sent to browser
DEBUG - 2023-09-25 10:54:51 --> Total execution time: 0.0630
INFO - 2023-09-25 10:54:58 --> Config Class Initialized
INFO - 2023-09-25 10:54:58 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:54:58 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:54:58 --> Utf8 Class Initialized
INFO - 2023-09-25 10:54:58 --> URI Class Initialized
INFO - 2023-09-25 10:54:58 --> Router Class Initialized
INFO - 2023-09-25 10:54:58 --> Output Class Initialized
INFO - 2023-09-25 10:54:58 --> Security Class Initialized
DEBUG - 2023-09-25 10:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:54:58 --> Input Class Initialized
INFO - 2023-09-25 10:54:58 --> Language Class Initialized
INFO - 2023-09-25 10:54:58 --> Language Class Initialized
INFO - 2023-09-25 10:54:58 --> Config Class Initialized
INFO - 2023-09-25 10:54:58 --> Loader Class Initialized
INFO - 2023-09-25 10:54:58 --> Helper loaded: url_helper
INFO - 2023-09-25 10:54:58 --> Helper loaded: file_helper
INFO - 2023-09-25 10:54:58 --> Helper loaded: form_helper
INFO - 2023-09-25 10:54:58 --> Helper loaded: my_helper
INFO - 2023-09-25 10:54:58 --> Database Driver Class Initialized
INFO - 2023-09-25 10:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:54:58 --> Controller Class Initialized
INFO - 2023-09-25 10:54:58 --> Final output sent to browser
DEBUG - 2023-09-25 10:54:58 --> Total execution time: 0.1073
INFO - 2023-09-25 10:55:02 --> Config Class Initialized
INFO - 2023-09-25 10:55:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:55:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:55:02 --> Utf8 Class Initialized
INFO - 2023-09-25 10:55:02 --> URI Class Initialized
INFO - 2023-09-25 10:55:02 --> Router Class Initialized
INFO - 2023-09-25 10:55:02 --> Output Class Initialized
INFO - 2023-09-25 10:55:02 --> Security Class Initialized
DEBUG - 2023-09-25 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:55:02 --> Input Class Initialized
INFO - 2023-09-25 10:55:02 --> Language Class Initialized
INFO - 2023-09-25 10:55:02 --> Language Class Initialized
INFO - 2023-09-25 10:55:02 --> Config Class Initialized
INFO - 2023-09-25 10:55:02 --> Loader Class Initialized
INFO - 2023-09-25 10:55:02 --> Helper loaded: url_helper
INFO - 2023-09-25 10:55:02 --> Helper loaded: file_helper
INFO - 2023-09-25 10:55:02 --> Helper loaded: form_helper
INFO - 2023-09-25 10:55:02 --> Helper loaded: my_helper
INFO - 2023-09-25 10:55:02 --> Database Driver Class Initialized
INFO - 2023-09-25 10:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:55:02 --> Controller Class Initialized
INFO - 2023-09-25 10:55:02 --> Final output sent to browser
DEBUG - 2023-09-25 10:55:02 --> Total execution time: 0.1254
INFO - 2023-09-25 10:55:04 --> Config Class Initialized
INFO - 2023-09-25 10:55:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:55:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:55:04 --> Utf8 Class Initialized
INFO - 2023-09-25 10:55:04 --> URI Class Initialized
INFO - 2023-09-25 10:55:04 --> Router Class Initialized
INFO - 2023-09-25 10:55:04 --> Output Class Initialized
INFO - 2023-09-25 10:55:04 --> Security Class Initialized
DEBUG - 2023-09-25 10:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:55:04 --> Input Class Initialized
INFO - 2023-09-25 10:55:04 --> Language Class Initialized
INFO - 2023-09-25 10:55:04 --> Language Class Initialized
INFO - 2023-09-25 10:55:04 --> Config Class Initialized
INFO - 2023-09-25 10:55:04 --> Loader Class Initialized
INFO - 2023-09-25 10:55:04 --> Helper loaded: url_helper
INFO - 2023-09-25 10:55:04 --> Helper loaded: file_helper
INFO - 2023-09-25 10:55:04 --> Helper loaded: form_helper
INFO - 2023-09-25 10:55:04 --> Helper loaded: my_helper
INFO - 2023-09-25 10:55:04 --> Database Driver Class Initialized
INFO - 2023-09-25 10:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:55:04 --> Controller Class Initialized
INFO - 2023-09-25 10:55:04 --> Final output sent to browser
DEBUG - 2023-09-25 10:55:04 --> Total execution time: 0.0445
INFO - 2023-09-25 10:57:22 --> Config Class Initialized
INFO - 2023-09-25 10:57:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:57:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:57:22 --> Utf8 Class Initialized
INFO - 2023-09-25 10:57:22 --> URI Class Initialized
INFO - 2023-09-25 10:57:22 --> Router Class Initialized
INFO - 2023-09-25 10:57:22 --> Output Class Initialized
INFO - 2023-09-25 10:57:22 --> Security Class Initialized
DEBUG - 2023-09-25 10:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:57:22 --> Input Class Initialized
INFO - 2023-09-25 10:57:22 --> Language Class Initialized
INFO - 2023-09-25 10:57:22 --> Language Class Initialized
INFO - 2023-09-25 10:57:22 --> Config Class Initialized
INFO - 2023-09-25 10:57:22 --> Loader Class Initialized
INFO - 2023-09-25 10:57:22 --> Helper loaded: url_helper
INFO - 2023-09-25 10:57:22 --> Helper loaded: file_helper
INFO - 2023-09-25 10:57:22 --> Helper loaded: form_helper
INFO - 2023-09-25 10:57:22 --> Helper loaded: my_helper
INFO - 2023-09-25 10:57:22 --> Database Driver Class Initialized
INFO - 2023-09-25 10:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:57:22 --> Controller Class Initialized
INFO - 2023-09-25 10:57:22 --> Final output sent to browser
DEBUG - 2023-09-25 10:57:22 --> Total execution time: 0.3773
INFO - 2023-09-25 10:58:12 --> Config Class Initialized
INFO - 2023-09-25 10:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:58:12 --> Utf8 Class Initialized
INFO - 2023-09-25 10:58:12 --> URI Class Initialized
INFO - 2023-09-25 10:58:12 --> Router Class Initialized
INFO - 2023-09-25 10:58:12 --> Output Class Initialized
INFO - 2023-09-25 10:58:12 --> Security Class Initialized
DEBUG - 2023-09-25 10:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:58:12 --> Input Class Initialized
INFO - 2023-09-25 10:58:12 --> Language Class Initialized
INFO - 2023-09-25 10:58:12 --> Language Class Initialized
INFO - 2023-09-25 10:58:12 --> Config Class Initialized
INFO - 2023-09-25 10:58:12 --> Loader Class Initialized
INFO - 2023-09-25 10:58:12 --> Helper loaded: url_helper
INFO - 2023-09-25 10:58:12 --> Helper loaded: file_helper
INFO - 2023-09-25 10:58:12 --> Helper loaded: form_helper
INFO - 2023-09-25 10:58:12 --> Helper loaded: my_helper
INFO - 2023-09-25 10:58:12 --> Database Driver Class Initialized
INFO - 2023-09-25 10:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:58:12 --> Controller Class Initialized
INFO - 2023-09-25 10:58:12 --> Final output sent to browser
DEBUG - 2023-09-25 10:58:12 --> Total execution time: 0.0839
INFO - 2023-09-25 10:58:27 --> Config Class Initialized
INFO - 2023-09-25 10:58:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 10:58:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 10:58:27 --> Utf8 Class Initialized
INFO - 2023-09-25 10:58:27 --> URI Class Initialized
INFO - 2023-09-25 10:58:27 --> Router Class Initialized
INFO - 2023-09-25 10:58:27 --> Output Class Initialized
INFO - 2023-09-25 10:58:27 --> Security Class Initialized
DEBUG - 2023-09-25 10:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 10:58:27 --> Input Class Initialized
INFO - 2023-09-25 10:58:27 --> Language Class Initialized
INFO - 2023-09-25 10:58:27 --> Language Class Initialized
INFO - 2023-09-25 10:58:27 --> Config Class Initialized
INFO - 2023-09-25 10:58:27 --> Loader Class Initialized
INFO - 2023-09-25 10:58:27 --> Helper loaded: url_helper
INFO - 2023-09-25 10:58:27 --> Helper loaded: file_helper
INFO - 2023-09-25 10:58:27 --> Helper loaded: form_helper
INFO - 2023-09-25 10:58:27 --> Helper loaded: my_helper
INFO - 2023-09-25 10:58:27 --> Database Driver Class Initialized
INFO - 2023-09-25 10:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 10:58:27 --> Controller Class Initialized
DEBUG - 2023-09-25 10:58:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 10:58:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 10:58:27 --> Final output sent to browser
DEBUG - 2023-09-25 10:58:27 --> Total execution time: 0.0808
INFO - 2023-09-25 11:00:12 --> Config Class Initialized
INFO - 2023-09-25 11:00:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:00:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:00:12 --> Utf8 Class Initialized
INFO - 2023-09-25 11:00:12 --> URI Class Initialized
INFO - 2023-09-25 11:00:12 --> Router Class Initialized
INFO - 2023-09-25 11:00:12 --> Output Class Initialized
INFO - 2023-09-25 11:00:12 --> Security Class Initialized
DEBUG - 2023-09-25 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:00:12 --> Input Class Initialized
INFO - 2023-09-25 11:00:12 --> Language Class Initialized
INFO - 2023-09-25 11:00:12 --> Language Class Initialized
INFO - 2023-09-25 11:00:12 --> Config Class Initialized
INFO - 2023-09-25 11:00:12 --> Loader Class Initialized
INFO - 2023-09-25 11:00:12 --> Helper loaded: url_helper
INFO - 2023-09-25 11:00:12 --> Helper loaded: file_helper
INFO - 2023-09-25 11:00:12 --> Helper loaded: form_helper
INFO - 2023-09-25 11:00:12 --> Helper loaded: my_helper
INFO - 2023-09-25 11:00:12 --> Database Driver Class Initialized
INFO - 2023-09-25 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:00:12 --> Controller Class Initialized
DEBUG - 2023-09-25 11:00:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-25 11:00:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:00:12 --> Final output sent to browser
DEBUG - 2023-09-25 11:00:12 --> Total execution time: 0.2029
INFO - 2023-09-25 11:00:24 --> Config Class Initialized
INFO - 2023-09-25 11:00:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:00:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:00:24 --> Utf8 Class Initialized
INFO - 2023-09-25 11:00:24 --> URI Class Initialized
INFO - 2023-09-25 11:00:24 --> Router Class Initialized
INFO - 2023-09-25 11:00:24 --> Output Class Initialized
INFO - 2023-09-25 11:00:24 --> Security Class Initialized
DEBUG - 2023-09-25 11:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:00:24 --> Input Class Initialized
INFO - 2023-09-25 11:00:24 --> Language Class Initialized
INFO - 2023-09-25 11:00:24 --> Language Class Initialized
INFO - 2023-09-25 11:00:24 --> Config Class Initialized
INFO - 2023-09-25 11:00:24 --> Loader Class Initialized
INFO - 2023-09-25 11:00:24 --> Helper loaded: url_helper
INFO - 2023-09-25 11:00:24 --> Helper loaded: file_helper
INFO - 2023-09-25 11:00:24 --> Helper loaded: form_helper
INFO - 2023-09-25 11:00:24 --> Helper loaded: my_helper
INFO - 2023-09-25 11:00:24 --> Database Driver Class Initialized
INFO - 2023-09-25 11:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:00:24 --> Controller Class Initialized
DEBUG - 2023-09-25 11:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 11:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:00:24 --> Final output sent to browser
DEBUG - 2023-09-25 11:00:24 --> Total execution time: 0.0348
INFO - 2023-09-25 11:00:26 --> Config Class Initialized
INFO - 2023-09-25 11:00:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:00:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:00:26 --> Utf8 Class Initialized
INFO - 2023-09-25 11:00:26 --> URI Class Initialized
INFO - 2023-09-25 11:00:26 --> Router Class Initialized
INFO - 2023-09-25 11:00:26 --> Output Class Initialized
INFO - 2023-09-25 11:00:26 --> Security Class Initialized
DEBUG - 2023-09-25 11:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:00:26 --> Input Class Initialized
INFO - 2023-09-25 11:00:26 --> Language Class Initialized
INFO - 2023-09-25 11:00:26 --> Language Class Initialized
INFO - 2023-09-25 11:00:26 --> Config Class Initialized
INFO - 2023-09-25 11:00:26 --> Loader Class Initialized
INFO - 2023-09-25 11:00:26 --> Helper loaded: url_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: file_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: form_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: my_helper
INFO - 2023-09-25 11:00:26 --> Database Driver Class Initialized
INFO - 2023-09-25 11:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:00:26 --> Controller Class Initialized
DEBUG - 2023-09-25 11:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 11:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:00:26 --> Final output sent to browser
DEBUG - 2023-09-25 11:00:26 --> Total execution time: 0.0424
INFO - 2023-09-25 11:00:26 --> Config Class Initialized
INFO - 2023-09-25 11:00:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:00:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:00:26 --> Utf8 Class Initialized
INFO - 2023-09-25 11:00:26 --> URI Class Initialized
INFO - 2023-09-25 11:00:26 --> Router Class Initialized
INFO - 2023-09-25 11:00:26 --> Output Class Initialized
INFO - 2023-09-25 11:00:26 --> Security Class Initialized
DEBUG - 2023-09-25 11:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:00:26 --> Input Class Initialized
INFO - 2023-09-25 11:00:26 --> Language Class Initialized
INFO - 2023-09-25 11:00:26 --> Language Class Initialized
INFO - 2023-09-25 11:00:26 --> Config Class Initialized
INFO - 2023-09-25 11:00:26 --> Loader Class Initialized
INFO - 2023-09-25 11:00:26 --> Helper loaded: url_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: file_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: form_helper
INFO - 2023-09-25 11:00:26 --> Helper loaded: my_helper
INFO - 2023-09-25 11:00:26 --> Database Driver Class Initialized
INFO - 2023-09-25 11:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:00:26 --> Controller Class Initialized
INFO - 2023-09-25 11:00:42 --> Config Class Initialized
INFO - 2023-09-25 11:00:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:00:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:00:42 --> Utf8 Class Initialized
INFO - 2023-09-25 11:00:42 --> URI Class Initialized
INFO - 2023-09-25 11:00:42 --> Router Class Initialized
INFO - 2023-09-25 11:00:42 --> Output Class Initialized
INFO - 2023-09-25 11:00:42 --> Security Class Initialized
DEBUG - 2023-09-25 11:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:00:42 --> Input Class Initialized
INFO - 2023-09-25 11:00:42 --> Language Class Initialized
INFO - 2023-09-25 11:00:42 --> Language Class Initialized
INFO - 2023-09-25 11:00:42 --> Config Class Initialized
INFO - 2023-09-25 11:00:42 --> Loader Class Initialized
INFO - 2023-09-25 11:00:42 --> Helper loaded: url_helper
INFO - 2023-09-25 11:00:42 --> Helper loaded: file_helper
INFO - 2023-09-25 11:00:42 --> Helper loaded: form_helper
INFO - 2023-09-25 11:00:42 --> Helper loaded: my_helper
INFO - 2023-09-25 11:00:42 --> Database Driver Class Initialized
INFO - 2023-09-25 11:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:00:42 --> Controller Class Initialized
INFO - 2023-09-25 11:00:42 --> Final output sent to browser
DEBUG - 2023-09-25 11:00:42 --> Total execution time: 0.0449
INFO - 2023-09-25 11:05:38 --> Config Class Initialized
INFO - 2023-09-25 11:05:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:05:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:05:38 --> Utf8 Class Initialized
INFO - 2023-09-25 11:05:38 --> URI Class Initialized
INFO - 2023-09-25 11:05:38 --> Router Class Initialized
INFO - 2023-09-25 11:05:38 --> Output Class Initialized
INFO - 2023-09-25 11:05:38 --> Security Class Initialized
DEBUG - 2023-09-25 11:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:05:38 --> Input Class Initialized
INFO - 2023-09-25 11:05:38 --> Language Class Initialized
INFO - 2023-09-25 11:05:38 --> Language Class Initialized
INFO - 2023-09-25 11:05:38 --> Config Class Initialized
INFO - 2023-09-25 11:05:38 --> Loader Class Initialized
INFO - 2023-09-25 11:05:38 --> Helper loaded: url_helper
INFO - 2023-09-25 11:05:38 --> Helper loaded: file_helper
INFO - 2023-09-25 11:05:38 --> Helper loaded: form_helper
INFO - 2023-09-25 11:05:38 --> Helper loaded: my_helper
INFO - 2023-09-25 11:05:38 --> Database Driver Class Initialized
INFO - 2023-09-25 11:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:05:38 --> Controller Class Initialized
DEBUG - 2023-09-25 11:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 11:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:05:38 --> Final output sent to browser
DEBUG - 2023-09-25 11:05:38 --> Total execution time: 0.0388
INFO - 2023-09-25 11:05:45 --> Config Class Initialized
INFO - 2023-09-25 11:05:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:05:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:05:45 --> Utf8 Class Initialized
INFO - 2023-09-25 11:05:45 --> URI Class Initialized
INFO - 2023-09-25 11:05:45 --> Router Class Initialized
INFO - 2023-09-25 11:05:45 --> Output Class Initialized
INFO - 2023-09-25 11:05:45 --> Security Class Initialized
DEBUG - 2023-09-25 11:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:05:45 --> Input Class Initialized
INFO - 2023-09-25 11:05:45 --> Language Class Initialized
INFO - 2023-09-25 11:05:45 --> Language Class Initialized
INFO - 2023-09-25 11:05:45 --> Config Class Initialized
INFO - 2023-09-25 11:05:45 --> Loader Class Initialized
INFO - 2023-09-25 11:05:45 --> Helper loaded: url_helper
INFO - 2023-09-25 11:05:45 --> Helper loaded: file_helper
INFO - 2023-09-25 11:05:45 --> Helper loaded: form_helper
INFO - 2023-09-25 11:05:45 --> Helper loaded: my_helper
INFO - 2023-09-25 11:05:45 --> Database Driver Class Initialized
INFO - 2023-09-25 11:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:05:45 --> Controller Class Initialized
DEBUG - 2023-09-25 11:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2023-09-25 11:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:05:45 --> Final output sent to browser
DEBUG - 2023-09-25 11:05:45 --> Total execution time: 0.0658
INFO - 2023-09-25 11:06:10 --> Config Class Initialized
INFO - 2023-09-25 11:06:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:06:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:06:10 --> Utf8 Class Initialized
INFO - 2023-09-25 11:06:10 --> URI Class Initialized
INFO - 2023-09-25 11:06:10 --> Router Class Initialized
INFO - 2023-09-25 11:06:10 --> Output Class Initialized
INFO - 2023-09-25 11:06:10 --> Security Class Initialized
DEBUG - 2023-09-25 11:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:06:10 --> Input Class Initialized
INFO - 2023-09-25 11:06:10 --> Language Class Initialized
INFO - 2023-09-25 11:06:10 --> Language Class Initialized
INFO - 2023-09-25 11:06:10 --> Config Class Initialized
INFO - 2023-09-25 11:06:10 --> Loader Class Initialized
INFO - 2023-09-25 11:06:10 --> Helper loaded: url_helper
INFO - 2023-09-25 11:06:10 --> Helper loaded: file_helper
INFO - 2023-09-25 11:06:10 --> Helper loaded: form_helper
INFO - 2023-09-25 11:06:10 --> Helper loaded: my_helper
INFO - 2023-09-25 11:06:10 --> Database Driver Class Initialized
INFO - 2023-09-25 11:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:06:11 --> Controller Class Initialized
INFO - 2023-09-25 11:06:18 --> Config Class Initialized
INFO - 2023-09-25 11:06:18 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:06:18 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:06:18 --> Utf8 Class Initialized
INFO - 2023-09-25 11:06:18 --> URI Class Initialized
INFO - 2023-09-25 11:06:18 --> Router Class Initialized
INFO - 2023-09-25 11:06:18 --> Output Class Initialized
INFO - 2023-09-25 11:06:18 --> Security Class Initialized
DEBUG - 2023-09-25 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:06:18 --> Input Class Initialized
INFO - 2023-09-25 11:06:18 --> Language Class Initialized
INFO - 2023-09-25 11:06:18 --> Language Class Initialized
INFO - 2023-09-25 11:06:18 --> Config Class Initialized
INFO - 2023-09-25 11:06:18 --> Loader Class Initialized
INFO - 2023-09-25 11:06:18 --> Helper loaded: url_helper
INFO - 2023-09-25 11:06:18 --> Helper loaded: file_helper
INFO - 2023-09-25 11:06:18 --> Helper loaded: form_helper
INFO - 2023-09-25 11:06:18 --> Helper loaded: my_helper
INFO - 2023-09-25 11:06:18 --> Database Driver Class Initialized
INFO - 2023-09-25 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:06:18 --> Controller Class Initialized
INFO - 2023-09-25 11:06:32 --> Config Class Initialized
INFO - 2023-09-25 11:06:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:06:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:06:32 --> Utf8 Class Initialized
INFO - 2023-09-25 11:06:32 --> URI Class Initialized
INFO - 2023-09-25 11:06:32 --> Router Class Initialized
INFO - 2023-09-25 11:06:32 --> Output Class Initialized
INFO - 2023-09-25 11:06:32 --> Security Class Initialized
DEBUG - 2023-09-25 11:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:06:32 --> Input Class Initialized
INFO - 2023-09-25 11:06:32 --> Language Class Initialized
INFO - 2023-09-25 11:06:32 --> Language Class Initialized
INFO - 2023-09-25 11:06:32 --> Config Class Initialized
INFO - 2023-09-25 11:06:32 --> Loader Class Initialized
INFO - 2023-09-25 11:06:32 --> Helper loaded: url_helper
INFO - 2023-09-25 11:06:32 --> Helper loaded: file_helper
INFO - 2023-09-25 11:06:32 --> Helper loaded: form_helper
INFO - 2023-09-25 11:06:32 --> Helper loaded: my_helper
INFO - 2023-09-25 11:06:32 --> Database Driver Class Initialized
INFO - 2023-09-25 11:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:06:32 --> Controller Class Initialized
DEBUG - 2023-09-25 11:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 11:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:06:32 --> Final output sent to browser
DEBUG - 2023-09-25 11:06:32 --> Total execution time: 0.0386
INFO - 2023-09-25 11:20:07 --> Config Class Initialized
INFO - 2023-09-25 11:20:07 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:07 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:07 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:07 --> URI Class Initialized
DEBUG - 2023-09-25 11:20:07 --> No URI present. Default controller set.
INFO - 2023-09-25 11:20:07 --> Router Class Initialized
INFO - 2023-09-25 11:20:07 --> Output Class Initialized
INFO - 2023-09-25 11:20:07 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:07 --> Input Class Initialized
INFO - 2023-09-25 11:20:07 --> Language Class Initialized
INFO - 2023-09-25 11:20:07 --> Language Class Initialized
INFO - 2023-09-25 11:20:07 --> Config Class Initialized
INFO - 2023-09-25 11:20:07 --> Loader Class Initialized
INFO - 2023-09-25 11:20:07 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:07 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:07 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:07 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:07 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:07 --> Controller Class Initialized
DEBUG - 2023-09-25 11:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 11:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:20:07 --> Final output sent to browser
DEBUG - 2023-09-25 11:20:07 --> Total execution time: 0.3750
INFO - 2023-09-25 11:20:09 --> Config Class Initialized
INFO - 2023-09-25 11:20:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:09 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:09 --> URI Class Initialized
INFO - 2023-09-25 11:20:09 --> Router Class Initialized
INFO - 2023-09-25 11:20:09 --> Output Class Initialized
INFO - 2023-09-25 11:20:09 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:09 --> Input Class Initialized
INFO - 2023-09-25 11:20:09 --> Language Class Initialized
INFO - 2023-09-25 11:20:09 --> Language Class Initialized
INFO - 2023-09-25 11:20:09 --> Config Class Initialized
INFO - 2023-09-25 11:20:09 --> Loader Class Initialized
INFO - 2023-09-25 11:20:09 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:09 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:09 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:09 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:09 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:09 --> Controller Class Initialized
DEBUG - 2023-09-25 11:20:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 11:20:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:20:09 --> Final output sent to browser
DEBUG - 2023-09-25 11:20:09 --> Total execution time: 0.0716
INFO - 2023-09-25 11:20:11 --> Config Class Initialized
INFO - 2023-09-25 11:20:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:11 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:11 --> URI Class Initialized
INFO - 2023-09-25 11:20:11 --> Router Class Initialized
INFO - 2023-09-25 11:20:11 --> Output Class Initialized
INFO - 2023-09-25 11:20:11 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:11 --> Input Class Initialized
INFO - 2023-09-25 11:20:11 --> Language Class Initialized
INFO - 2023-09-25 11:20:11 --> Language Class Initialized
INFO - 2023-09-25 11:20:11 --> Config Class Initialized
INFO - 2023-09-25 11:20:11 --> Loader Class Initialized
INFO - 2023-09-25 11:20:11 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:11 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:11 --> Controller Class Initialized
DEBUG - 2023-09-25 11:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 11:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:20:11 --> Final output sent to browser
DEBUG - 2023-09-25 11:20:11 --> Total execution time: 0.0707
INFO - 2023-09-25 11:20:11 --> Config Class Initialized
INFO - 2023-09-25 11:20:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:11 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:11 --> URI Class Initialized
INFO - 2023-09-25 11:20:11 --> Router Class Initialized
INFO - 2023-09-25 11:20:11 --> Output Class Initialized
INFO - 2023-09-25 11:20:11 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:11 --> Input Class Initialized
INFO - 2023-09-25 11:20:11 --> Language Class Initialized
INFO - 2023-09-25 11:20:11 --> Language Class Initialized
INFO - 2023-09-25 11:20:11 --> Config Class Initialized
INFO - 2023-09-25 11:20:11 --> Loader Class Initialized
INFO - 2023-09-25 11:20:11 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:11 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:11 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:11 --> Controller Class Initialized
INFO - 2023-09-25 11:20:15 --> Config Class Initialized
INFO - 2023-09-25 11:20:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:15 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:15 --> URI Class Initialized
INFO - 2023-09-25 11:20:15 --> Router Class Initialized
INFO - 2023-09-25 11:20:15 --> Output Class Initialized
INFO - 2023-09-25 11:20:15 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:15 --> Input Class Initialized
INFO - 2023-09-25 11:20:15 --> Language Class Initialized
INFO - 2023-09-25 11:20:15 --> Language Class Initialized
INFO - 2023-09-25 11:20:15 --> Config Class Initialized
INFO - 2023-09-25 11:20:15 --> Loader Class Initialized
INFO - 2023-09-25 11:20:15 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:15 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:15 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:15 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:15 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:15 --> Controller Class Initialized
INFO - 2023-09-25 11:20:15 --> Final output sent to browser
DEBUG - 2023-09-25 11:20:15 --> Total execution time: 0.0387
INFO - 2023-09-25 11:20:19 --> Config Class Initialized
INFO - 2023-09-25 11:20:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:20:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:20:19 --> Utf8 Class Initialized
INFO - 2023-09-25 11:20:19 --> URI Class Initialized
INFO - 2023-09-25 11:20:19 --> Router Class Initialized
INFO - 2023-09-25 11:20:19 --> Output Class Initialized
INFO - 2023-09-25 11:20:19 --> Security Class Initialized
DEBUG - 2023-09-25 11:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:20:19 --> Input Class Initialized
INFO - 2023-09-25 11:20:19 --> Language Class Initialized
INFO - 2023-09-25 11:20:19 --> Language Class Initialized
INFO - 2023-09-25 11:20:19 --> Config Class Initialized
INFO - 2023-09-25 11:20:19 --> Loader Class Initialized
INFO - 2023-09-25 11:20:19 --> Helper loaded: url_helper
INFO - 2023-09-25 11:20:19 --> Helper loaded: file_helper
INFO - 2023-09-25 11:20:19 --> Helper loaded: form_helper
INFO - 2023-09-25 11:20:19 --> Helper loaded: my_helper
INFO - 2023-09-25 11:20:19 --> Database Driver Class Initialized
INFO - 2023-09-25 11:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:20:19 --> Controller Class Initialized
INFO - 2023-09-25 11:20:19 --> Final output sent to browser
DEBUG - 2023-09-25 11:20:19 --> Total execution time: 0.0746
INFO - 2023-09-25 11:48:32 --> Config Class Initialized
INFO - 2023-09-25 11:48:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:48:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:48:32 --> Utf8 Class Initialized
INFO - 2023-09-25 11:48:32 --> URI Class Initialized
INFO - 2023-09-25 11:48:32 --> Router Class Initialized
INFO - 2023-09-25 11:48:32 --> Output Class Initialized
INFO - 2023-09-25 11:48:32 --> Security Class Initialized
DEBUG - 2023-09-25 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:48:32 --> Input Class Initialized
INFO - 2023-09-25 11:48:32 --> Language Class Initialized
INFO - 2023-09-25 11:48:32 --> Language Class Initialized
INFO - 2023-09-25 11:48:32 --> Config Class Initialized
INFO - 2023-09-25 11:48:32 --> Loader Class Initialized
INFO - 2023-09-25 11:48:32 --> Helper loaded: url_helper
INFO - 2023-09-25 11:48:32 --> Helper loaded: file_helper
INFO - 2023-09-25 11:48:32 --> Helper loaded: form_helper
INFO - 2023-09-25 11:48:32 --> Helper loaded: my_helper
INFO - 2023-09-25 11:48:32 --> Database Driver Class Initialized
INFO - 2023-09-25 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:48:32 --> Controller Class Initialized
DEBUG - 2023-09-25 11:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 11:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:48:32 --> Final output sent to browser
DEBUG - 2023-09-25 11:48:32 --> Total execution time: 0.0838
INFO - 2023-09-25 11:48:46 --> Config Class Initialized
INFO - 2023-09-25 11:48:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:48:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:48:46 --> Utf8 Class Initialized
INFO - 2023-09-25 11:48:46 --> URI Class Initialized
INFO - 2023-09-25 11:48:46 --> Router Class Initialized
INFO - 2023-09-25 11:48:46 --> Output Class Initialized
INFO - 2023-09-25 11:48:46 --> Security Class Initialized
DEBUG - 2023-09-25 11:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:48:46 --> Input Class Initialized
INFO - 2023-09-25 11:48:46 --> Language Class Initialized
INFO - 2023-09-25 11:48:46 --> Language Class Initialized
INFO - 2023-09-25 11:48:46 --> Config Class Initialized
INFO - 2023-09-25 11:48:46 --> Loader Class Initialized
INFO - 2023-09-25 11:48:46 --> Helper loaded: url_helper
INFO - 2023-09-25 11:48:46 --> Helper loaded: file_helper
INFO - 2023-09-25 11:48:46 --> Helper loaded: form_helper
INFO - 2023-09-25 11:48:46 --> Helper loaded: my_helper
INFO - 2023-09-25 11:48:46 --> Database Driver Class Initialized
INFO - 2023-09-25 11:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:48:46 --> Controller Class Initialized
INFO - 2023-09-25 11:48:46 --> Helper loaded: cookie_helper
INFO - 2023-09-25 11:48:46 --> Final output sent to browser
DEBUG - 2023-09-25 11:48:46 --> Total execution time: 0.0515
INFO - 2023-09-25 11:48:47 --> Config Class Initialized
INFO - 2023-09-25 11:48:47 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:48:47 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:48:47 --> Utf8 Class Initialized
INFO - 2023-09-25 11:48:47 --> URI Class Initialized
INFO - 2023-09-25 11:48:47 --> Router Class Initialized
INFO - 2023-09-25 11:48:47 --> Output Class Initialized
INFO - 2023-09-25 11:48:47 --> Security Class Initialized
DEBUG - 2023-09-25 11:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:48:47 --> Input Class Initialized
INFO - 2023-09-25 11:48:47 --> Language Class Initialized
INFO - 2023-09-25 11:48:47 --> Language Class Initialized
INFO - 2023-09-25 11:48:47 --> Config Class Initialized
INFO - 2023-09-25 11:48:47 --> Loader Class Initialized
INFO - 2023-09-25 11:48:47 --> Helper loaded: url_helper
INFO - 2023-09-25 11:48:47 --> Helper loaded: file_helper
INFO - 2023-09-25 11:48:47 --> Helper loaded: form_helper
INFO - 2023-09-25 11:48:47 --> Helper loaded: my_helper
INFO - 2023-09-25 11:48:47 --> Database Driver Class Initialized
INFO - 2023-09-25 11:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:48:47 --> Controller Class Initialized
DEBUG - 2023-09-25 11:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 11:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:48:47 --> Final output sent to browser
DEBUG - 2023-09-25 11:48:47 --> Total execution time: 0.0486
INFO - 2023-09-25 11:48:53 --> Config Class Initialized
INFO - 2023-09-25 11:48:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:48:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:48:53 --> Utf8 Class Initialized
INFO - 2023-09-25 11:48:53 --> URI Class Initialized
DEBUG - 2023-09-25 11:48:53 --> No URI present. Default controller set.
INFO - 2023-09-25 11:48:53 --> Router Class Initialized
INFO - 2023-09-25 11:48:53 --> Output Class Initialized
INFO - 2023-09-25 11:48:53 --> Security Class Initialized
DEBUG - 2023-09-25 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:48:53 --> Input Class Initialized
INFO - 2023-09-25 11:48:53 --> Language Class Initialized
INFO - 2023-09-25 11:48:53 --> Language Class Initialized
INFO - 2023-09-25 11:48:53 --> Config Class Initialized
INFO - 2023-09-25 11:48:53 --> Loader Class Initialized
INFO - 2023-09-25 11:48:53 --> Helper loaded: url_helper
INFO - 2023-09-25 11:48:53 --> Helper loaded: file_helper
INFO - 2023-09-25 11:48:53 --> Helper loaded: form_helper
INFO - 2023-09-25 11:48:53 --> Helper loaded: my_helper
INFO - 2023-09-25 11:48:53 --> Database Driver Class Initialized
INFO - 2023-09-25 11:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:48:53 --> Controller Class Initialized
DEBUG - 2023-09-25 11:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 11:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:48:53 --> Final output sent to browser
DEBUG - 2023-09-25 11:48:53 --> Total execution time: 0.0392
INFO - 2023-09-25 11:49:12 --> Config Class Initialized
INFO - 2023-09-25 11:49:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:12 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:12 --> URI Class Initialized
DEBUG - 2023-09-25 11:49:12 --> No URI present. Default controller set.
INFO - 2023-09-25 11:49:12 --> Router Class Initialized
INFO - 2023-09-25 11:49:12 --> Output Class Initialized
INFO - 2023-09-25 11:49:12 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:12 --> Input Class Initialized
INFO - 2023-09-25 11:49:12 --> Language Class Initialized
INFO - 2023-09-25 11:49:12 --> Language Class Initialized
INFO - 2023-09-25 11:49:12 --> Config Class Initialized
INFO - 2023-09-25 11:49:12 --> Loader Class Initialized
INFO - 2023-09-25 11:49:12 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:12 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:12 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:12 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:12 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:13 --> Controller Class Initialized
DEBUG - 2023-09-25 11:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 11:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:49:13 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:13 --> Total execution time: 0.0381
INFO - 2023-09-25 11:49:14 --> Config Class Initialized
INFO - 2023-09-25 11:49:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:14 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:14 --> URI Class Initialized
INFO - 2023-09-25 11:49:14 --> Router Class Initialized
INFO - 2023-09-25 11:49:14 --> Output Class Initialized
INFO - 2023-09-25 11:49:14 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:14 --> Input Class Initialized
INFO - 2023-09-25 11:49:14 --> Language Class Initialized
INFO - 2023-09-25 11:49:14 --> Language Class Initialized
INFO - 2023-09-25 11:49:14 --> Config Class Initialized
INFO - 2023-09-25 11:49:14 --> Loader Class Initialized
INFO - 2023-09-25 11:49:14 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:14 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:14 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:14 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:14 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:14 --> Controller Class Initialized
DEBUG - 2023-09-25 11:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 11:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:49:14 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:14 --> Total execution time: 0.0397
INFO - 2023-09-25 11:49:17 --> Config Class Initialized
INFO - 2023-09-25 11:49:17 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:17 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:17 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:17 --> URI Class Initialized
INFO - 2023-09-25 11:49:17 --> Router Class Initialized
INFO - 2023-09-25 11:49:17 --> Output Class Initialized
INFO - 2023-09-25 11:49:17 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:17 --> Input Class Initialized
INFO - 2023-09-25 11:49:17 --> Language Class Initialized
INFO - 2023-09-25 11:49:17 --> Language Class Initialized
INFO - 2023-09-25 11:49:17 --> Config Class Initialized
INFO - 2023-09-25 11:49:17 --> Loader Class Initialized
INFO - 2023-09-25 11:49:17 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:17 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:17 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:17 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:17 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:17 --> Controller Class Initialized
DEBUG - 2023-09-25 11:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-25 11:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:49:17 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:17 --> Total execution time: 0.0608
INFO - 2023-09-25 11:49:19 --> Config Class Initialized
INFO - 2023-09-25 11:49:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:19 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:19 --> URI Class Initialized
INFO - 2023-09-25 11:49:19 --> Router Class Initialized
INFO - 2023-09-25 11:49:19 --> Output Class Initialized
INFO - 2023-09-25 11:49:19 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:19 --> Input Class Initialized
INFO - 2023-09-25 11:49:19 --> Language Class Initialized
INFO - 2023-09-25 11:49:19 --> Language Class Initialized
INFO - 2023-09-25 11:49:19 --> Config Class Initialized
INFO - 2023-09-25 11:49:19 --> Loader Class Initialized
INFO - 2023-09-25 11:49:19 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:19 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:19 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:19 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:19 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:19 --> Controller Class Initialized
DEBUG - 2023-09-25 11:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 11:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:49:19 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:19 --> Total execution time: 0.1189
INFO - 2023-09-25 11:49:22 --> Config Class Initialized
INFO - 2023-09-25 11:49:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:22 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:22 --> URI Class Initialized
INFO - 2023-09-25 11:49:22 --> Router Class Initialized
INFO - 2023-09-25 11:49:22 --> Output Class Initialized
INFO - 2023-09-25 11:49:22 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:22 --> Input Class Initialized
INFO - 2023-09-25 11:49:22 --> Language Class Initialized
INFO - 2023-09-25 11:49:22 --> Language Class Initialized
INFO - 2023-09-25 11:49:22 --> Config Class Initialized
INFO - 2023-09-25 11:49:22 --> Loader Class Initialized
INFO - 2023-09-25 11:49:22 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:22 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:22 --> Controller Class Initialized
DEBUG - 2023-09-25 11:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 11:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 11:49:22 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:22 --> Total execution time: 0.0551
INFO - 2023-09-25 11:49:22 --> Config Class Initialized
INFO - 2023-09-25 11:49:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:22 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:22 --> URI Class Initialized
INFO - 2023-09-25 11:49:22 --> Router Class Initialized
INFO - 2023-09-25 11:49:22 --> Output Class Initialized
INFO - 2023-09-25 11:49:22 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:22 --> Input Class Initialized
INFO - 2023-09-25 11:49:22 --> Language Class Initialized
INFO - 2023-09-25 11:49:22 --> Language Class Initialized
INFO - 2023-09-25 11:49:22 --> Config Class Initialized
INFO - 2023-09-25 11:49:22 --> Loader Class Initialized
INFO - 2023-09-25 11:49:22 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:22 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:22 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:22 --> Controller Class Initialized
INFO - 2023-09-25 11:49:24 --> Config Class Initialized
INFO - 2023-09-25 11:49:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:24 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:24 --> URI Class Initialized
INFO - 2023-09-25 11:49:24 --> Router Class Initialized
INFO - 2023-09-25 11:49:24 --> Output Class Initialized
INFO - 2023-09-25 11:49:24 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:24 --> Input Class Initialized
INFO - 2023-09-25 11:49:24 --> Language Class Initialized
INFO - 2023-09-25 11:49:24 --> Language Class Initialized
INFO - 2023-09-25 11:49:24 --> Config Class Initialized
INFO - 2023-09-25 11:49:24 --> Loader Class Initialized
INFO - 2023-09-25 11:49:24 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:24 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:24 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:24 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:24 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:24 --> Controller Class Initialized
INFO - 2023-09-25 11:49:24 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:24 --> Total execution time: 0.0660
INFO - 2023-09-25 11:49:25 --> Config Class Initialized
INFO - 2023-09-25 11:49:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:25 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:25 --> URI Class Initialized
INFO - 2023-09-25 11:49:25 --> Router Class Initialized
INFO - 2023-09-25 11:49:25 --> Output Class Initialized
INFO - 2023-09-25 11:49:25 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:25 --> Input Class Initialized
INFO - 2023-09-25 11:49:25 --> Language Class Initialized
INFO - 2023-09-25 11:49:25 --> Language Class Initialized
INFO - 2023-09-25 11:49:25 --> Config Class Initialized
INFO - 2023-09-25 11:49:25 --> Loader Class Initialized
INFO - 2023-09-25 11:49:25 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:25 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:25 --> Controller Class Initialized
INFO - 2023-09-25 11:49:25 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:25 --> Total execution time: 0.0519
INFO - 2023-09-25 11:49:25 --> Config Class Initialized
INFO - 2023-09-25 11:49:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:25 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:25 --> URI Class Initialized
INFO - 2023-09-25 11:49:25 --> Router Class Initialized
INFO - 2023-09-25 11:49:25 --> Output Class Initialized
INFO - 2023-09-25 11:49:25 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:25 --> Input Class Initialized
INFO - 2023-09-25 11:49:25 --> Language Class Initialized
INFO - 2023-09-25 11:49:25 --> Language Class Initialized
INFO - 2023-09-25 11:49:25 --> Config Class Initialized
INFO - 2023-09-25 11:49:25 --> Loader Class Initialized
INFO - 2023-09-25 11:49:25 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:25 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:25 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:25 --> Controller Class Initialized
INFO - 2023-09-25 11:49:25 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:25 --> Total execution time: 0.0607
INFO - 2023-09-25 11:49:33 --> Config Class Initialized
INFO - 2023-09-25 11:49:33 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:33 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:33 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:33 --> URI Class Initialized
INFO - 2023-09-25 11:49:33 --> Router Class Initialized
INFO - 2023-09-25 11:49:33 --> Output Class Initialized
INFO - 2023-09-25 11:49:33 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:33 --> Input Class Initialized
INFO - 2023-09-25 11:49:33 --> Language Class Initialized
INFO - 2023-09-25 11:49:33 --> Language Class Initialized
INFO - 2023-09-25 11:49:33 --> Config Class Initialized
INFO - 2023-09-25 11:49:33 --> Loader Class Initialized
INFO - 2023-09-25 11:49:33 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:33 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:33 --> Config Class Initialized
INFO - 2023-09-25 11:49:33 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:49:33 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:49:33 --> Utf8 Class Initialized
INFO - 2023-09-25 11:49:33 --> URI Class Initialized
INFO - 2023-09-25 11:49:33 --> Router Class Initialized
INFO - 2023-09-25 11:49:33 --> Output Class Initialized
INFO - 2023-09-25 11:49:33 --> Security Class Initialized
DEBUG - 2023-09-25 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:49:33 --> Input Class Initialized
INFO - 2023-09-25 11:49:33 --> Language Class Initialized
INFO - 2023-09-25 11:49:33 --> Language Class Initialized
INFO - 2023-09-25 11:49:33 --> Config Class Initialized
INFO - 2023-09-25 11:49:33 --> Loader Class Initialized
INFO - 2023-09-25 11:49:33 --> Helper loaded: url_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: file_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: form_helper
INFO - 2023-09-25 11:49:33 --> Helper loaded: my_helper
INFO - 2023-09-25 11:49:33 --> Database Driver Class Initialized
INFO - 2023-09-25 11:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:33 --> Controller Class Initialized
INFO - 2023-09-25 11:49:33 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:33 --> Total execution time: 0.3737
INFO - 2023-09-25 11:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:49:33 --> Controller Class Initialized
INFO - 2023-09-25 11:49:33 --> Final output sent to browser
DEBUG - 2023-09-25 11:49:33 --> Total execution time: 0.2252
INFO - 2023-09-25 11:52:11 --> Config Class Initialized
INFO - 2023-09-25 11:52:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:52:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:52:11 --> Utf8 Class Initialized
INFO - 2023-09-25 11:52:11 --> URI Class Initialized
INFO - 2023-09-25 11:52:11 --> Router Class Initialized
INFO - 2023-09-25 11:52:11 --> Output Class Initialized
INFO - 2023-09-25 11:52:11 --> Security Class Initialized
DEBUG - 2023-09-25 11:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:52:11 --> Input Class Initialized
INFO - 2023-09-25 11:52:11 --> Language Class Initialized
INFO - 2023-09-25 11:52:11 --> Language Class Initialized
INFO - 2023-09-25 11:52:11 --> Config Class Initialized
INFO - 2023-09-25 11:52:11 --> Loader Class Initialized
INFO - 2023-09-25 11:52:11 --> Helper loaded: url_helper
INFO - 2023-09-25 11:52:11 --> Helper loaded: file_helper
INFO - 2023-09-25 11:52:11 --> Helper loaded: form_helper
INFO - 2023-09-25 11:52:11 --> Helper loaded: my_helper
INFO - 2023-09-25 11:52:11 --> Database Driver Class Initialized
INFO - 2023-09-25 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:52:11 --> Controller Class Initialized
INFO - 2023-09-25 11:52:11 --> Final output sent to browser
DEBUG - 2023-09-25 11:52:11 --> Total execution time: 0.0439
INFO - 2023-09-25 11:52:59 --> Config Class Initialized
INFO - 2023-09-25 11:52:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:52:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:52:59 --> Utf8 Class Initialized
INFO - 2023-09-25 11:52:59 --> URI Class Initialized
INFO - 2023-09-25 11:52:59 --> Router Class Initialized
INFO - 2023-09-25 11:52:59 --> Output Class Initialized
INFO - 2023-09-25 11:52:59 --> Security Class Initialized
DEBUG - 2023-09-25 11:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:52:59 --> Input Class Initialized
INFO - 2023-09-25 11:52:59 --> Language Class Initialized
INFO - 2023-09-25 11:52:59 --> Language Class Initialized
INFO - 2023-09-25 11:52:59 --> Config Class Initialized
INFO - 2023-09-25 11:52:59 --> Loader Class Initialized
INFO - 2023-09-25 11:52:59 --> Helper loaded: url_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: file_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: form_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: my_helper
INFO - 2023-09-25 11:52:59 --> Database Driver Class Initialized
INFO - 2023-09-25 11:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:52:59 --> Controller Class Initialized
INFO - 2023-09-25 11:52:59 --> Final output sent to browser
DEBUG - 2023-09-25 11:52:59 --> Total execution time: 0.2213
INFO - 2023-09-25 11:52:59 --> Config Class Initialized
INFO - 2023-09-25 11:52:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:52:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:52:59 --> Utf8 Class Initialized
INFO - 2023-09-25 11:52:59 --> URI Class Initialized
INFO - 2023-09-25 11:52:59 --> Router Class Initialized
INFO - 2023-09-25 11:52:59 --> Output Class Initialized
INFO - 2023-09-25 11:52:59 --> Security Class Initialized
DEBUG - 2023-09-25 11:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:52:59 --> Input Class Initialized
INFO - 2023-09-25 11:52:59 --> Language Class Initialized
INFO - 2023-09-25 11:52:59 --> Language Class Initialized
INFO - 2023-09-25 11:52:59 --> Config Class Initialized
INFO - 2023-09-25 11:52:59 --> Loader Class Initialized
INFO - 2023-09-25 11:52:59 --> Helper loaded: url_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: file_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: form_helper
INFO - 2023-09-25 11:52:59 --> Helper loaded: my_helper
INFO - 2023-09-25 11:52:59 --> Database Driver Class Initialized
INFO - 2023-09-25 11:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:52:59 --> Controller Class Initialized
INFO - 2023-09-25 11:53:05 --> Config Class Initialized
INFO - 2023-09-25 11:53:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:53:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:53:05 --> Utf8 Class Initialized
INFO - 2023-09-25 11:53:05 --> URI Class Initialized
INFO - 2023-09-25 11:53:05 --> Router Class Initialized
INFO - 2023-09-25 11:53:05 --> Output Class Initialized
INFO - 2023-09-25 11:53:05 --> Security Class Initialized
DEBUG - 2023-09-25 11:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:53:05 --> Input Class Initialized
INFO - 2023-09-25 11:53:05 --> Language Class Initialized
INFO - 2023-09-25 11:53:05 --> Language Class Initialized
INFO - 2023-09-25 11:53:05 --> Config Class Initialized
INFO - 2023-09-25 11:53:05 --> Loader Class Initialized
INFO - 2023-09-25 11:53:05 --> Helper loaded: url_helper
INFO - 2023-09-25 11:53:05 --> Helper loaded: file_helper
INFO - 2023-09-25 11:53:05 --> Helper loaded: form_helper
INFO - 2023-09-25 11:53:05 --> Helper loaded: my_helper
INFO - 2023-09-25 11:53:05 --> Database Driver Class Initialized
INFO - 2023-09-25 11:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:53:05 --> Controller Class Initialized
INFO - 2023-09-25 11:53:05 --> Final output sent to browser
DEBUG - 2023-09-25 11:53:05 --> Total execution time: 0.0880
INFO - 2023-09-25 11:54:42 --> Config Class Initialized
INFO - 2023-09-25 11:54:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:54:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:54:42 --> Utf8 Class Initialized
INFO - 2023-09-25 11:54:42 --> URI Class Initialized
INFO - 2023-09-25 11:54:42 --> Router Class Initialized
INFO - 2023-09-25 11:54:42 --> Output Class Initialized
INFO - 2023-09-25 11:54:42 --> Security Class Initialized
DEBUG - 2023-09-25 11:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:54:42 --> Input Class Initialized
INFO - 2023-09-25 11:54:42 --> Language Class Initialized
INFO - 2023-09-25 11:54:42 --> Language Class Initialized
INFO - 2023-09-25 11:54:42 --> Config Class Initialized
INFO - 2023-09-25 11:54:42 --> Loader Class Initialized
INFO - 2023-09-25 11:54:42 --> Helper loaded: url_helper
INFO - 2023-09-25 11:54:42 --> Helper loaded: file_helper
INFO - 2023-09-25 11:54:42 --> Helper loaded: form_helper
INFO - 2023-09-25 11:54:42 --> Helper loaded: my_helper
INFO - 2023-09-25 11:54:42 --> Database Driver Class Initialized
INFO - 2023-09-25 11:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:54:42 --> Controller Class Initialized
INFO - 2023-09-25 11:54:42 --> Final output sent to browser
DEBUG - 2023-09-25 11:54:42 --> Total execution time: 0.1506
INFO - 2023-09-25 11:54:45 --> Config Class Initialized
INFO - 2023-09-25 11:54:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:54:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:54:45 --> Utf8 Class Initialized
INFO - 2023-09-25 11:54:45 --> URI Class Initialized
INFO - 2023-09-25 11:54:45 --> Router Class Initialized
INFO - 2023-09-25 11:54:45 --> Output Class Initialized
INFO - 2023-09-25 11:54:45 --> Security Class Initialized
DEBUG - 2023-09-25 11:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:54:45 --> Input Class Initialized
INFO - 2023-09-25 11:54:45 --> Language Class Initialized
INFO - 2023-09-25 11:54:45 --> Language Class Initialized
INFO - 2023-09-25 11:54:45 --> Config Class Initialized
INFO - 2023-09-25 11:54:45 --> Loader Class Initialized
INFO - 2023-09-25 11:54:45 --> Helper loaded: url_helper
INFO - 2023-09-25 11:54:45 --> Helper loaded: file_helper
INFO - 2023-09-25 11:54:45 --> Helper loaded: form_helper
INFO - 2023-09-25 11:54:45 --> Helper loaded: my_helper
INFO - 2023-09-25 11:54:45 --> Database Driver Class Initialized
INFO - 2023-09-25 11:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:54:45 --> Controller Class Initialized
INFO - 2023-09-25 11:54:45 --> Final output sent to browser
DEBUG - 2023-09-25 11:54:45 --> Total execution time: 0.0445
INFO - 2023-09-25 11:54:54 --> Config Class Initialized
INFO - 2023-09-25 11:54:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:54:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:54:54 --> Utf8 Class Initialized
INFO - 2023-09-25 11:54:54 --> URI Class Initialized
INFO - 2023-09-25 11:54:54 --> Router Class Initialized
INFO - 2023-09-25 11:54:54 --> Output Class Initialized
INFO - 2023-09-25 11:54:54 --> Security Class Initialized
DEBUG - 2023-09-25 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:54:54 --> Input Class Initialized
INFO - 2023-09-25 11:54:54 --> Language Class Initialized
INFO - 2023-09-25 11:54:54 --> Language Class Initialized
INFO - 2023-09-25 11:54:54 --> Config Class Initialized
INFO - 2023-09-25 11:54:54 --> Loader Class Initialized
INFO - 2023-09-25 11:54:54 --> Helper loaded: url_helper
INFO - 2023-09-25 11:54:54 --> Helper loaded: file_helper
INFO - 2023-09-25 11:54:54 --> Helper loaded: form_helper
INFO - 2023-09-25 11:54:54 --> Helper loaded: my_helper
INFO - 2023-09-25 11:54:54 --> Database Driver Class Initialized
INFO - 2023-09-25 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:54:54 --> Controller Class Initialized
INFO - 2023-09-25 11:54:54 --> Final output sent to browser
DEBUG - 2023-09-25 11:54:54 --> Total execution time: 0.0543
INFO - 2023-09-25 11:54:56 --> Config Class Initialized
INFO - 2023-09-25 11:54:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:54:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:54:56 --> Utf8 Class Initialized
INFO - 2023-09-25 11:54:56 --> URI Class Initialized
INFO - 2023-09-25 11:54:56 --> Router Class Initialized
INFO - 2023-09-25 11:54:56 --> Output Class Initialized
INFO - 2023-09-25 11:54:56 --> Security Class Initialized
DEBUG - 2023-09-25 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:54:56 --> Input Class Initialized
INFO - 2023-09-25 11:54:56 --> Language Class Initialized
INFO - 2023-09-25 11:54:56 --> Language Class Initialized
INFO - 2023-09-25 11:54:56 --> Config Class Initialized
INFO - 2023-09-25 11:54:56 --> Loader Class Initialized
INFO - 2023-09-25 11:54:56 --> Helper loaded: url_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: file_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: form_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: my_helper
INFO - 2023-09-25 11:54:56 --> Database Driver Class Initialized
INFO - 2023-09-25 11:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:54:56 --> Controller Class Initialized
INFO - 2023-09-25 11:54:56 --> Final output sent to browser
DEBUG - 2023-09-25 11:54:56 --> Total execution time: 0.0392
INFO - 2023-09-25 11:54:56 --> Config Class Initialized
INFO - 2023-09-25 11:54:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:54:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:54:56 --> Utf8 Class Initialized
INFO - 2023-09-25 11:54:56 --> URI Class Initialized
INFO - 2023-09-25 11:54:56 --> Router Class Initialized
INFO - 2023-09-25 11:54:56 --> Output Class Initialized
INFO - 2023-09-25 11:54:56 --> Security Class Initialized
DEBUG - 2023-09-25 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:54:56 --> Input Class Initialized
INFO - 2023-09-25 11:54:56 --> Language Class Initialized
INFO - 2023-09-25 11:54:56 --> Language Class Initialized
INFO - 2023-09-25 11:54:56 --> Config Class Initialized
INFO - 2023-09-25 11:54:56 --> Loader Class Initialized
INFO - 2023-09-25 11:54:56 --> Helper loaded: url_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: file_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: form_helper
INFO - 2023-09-25 11:54:56 --> Helper loaded: my_helper
INFO - 2023-09-25 11:54:56 --> Database Driver Class Initialized
INFO - 2023-09-25 11:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:54:56 --> Controller Class Initialized
INFO - 2023-09-25 11:54:56 --> Final output sent to browser
DEBUG - 2023-09-25 11:54:56 --> Total execution time: 0.0364
INFO - 2023-09-25 11:59:06 --> Config Class Initialized
INFO - 2023-09-25 11:59:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:06 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:06 --> URI Class Initialized
INFO - 2023-09-25 11:59:06 --> Router Class Initialized
INFO - 2023-09-25 11:59:06 --> Output Class Initialized
INFO - 2023-09-25 11:59:06 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:06 --> Input Class Initialized
INFO - 2023-09-25 11:59:06 --> Language Class Initialized
INFO - 2023-09-25 11:59:06 --> Language Class Initialized
INFO - 2023-09-25 11:59:06 --> Config Class Initialized
INFO - 2023-09-25 11:59:06 --> Loader Class Initialized
INFO - 2023-09-25 11:59:06 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:06 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:06 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:06 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:06 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:06 --> Controller Class Initialized
INFO - 2023-09-25 11:59:06 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:06 --> Total execution time: 0.0903
INFO - 2023-09-25 11:59:08 --> Config Class Initialized
INFO - 2023-09-25 11:59:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:08 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:08 --> URI Class Initialized
INFO - 2023-09-25 11:59:08 --> Router Class Initialized
INFO - 2023-09-25 11:59:08 --> Output Class Initialized
INFO - 2023-09-25 11:59:08 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:08 --> Input Class Initialized
INFO - 2023-09-25 11:59:08 --> Language Class Initialized
INFO - 2023-09-25 11:59:08 --> Language Class Initialized
INFO - 2023-09-25 11:59:08 --> Config Class Initialized
INFO - 2023-09-25 11:59:08 --> Loader Class Initialized
INFO - 2023-09-25 11:59:08 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:08 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:08 --> Controller Class Initialized
INFO - 2023-09-25 11:59:08 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:08 --> Total execution time: 0.1142
INFO - 2023-09-25 11:59:08 --> Config Class Initialized
INFO - 2023-09-25 11:59:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:08 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:08 --> URI Class Initialized
INFO - 2023-09-25 11:59:08 --> Router Class Initialized
INFO - 2023-09-25 11:59:08 --> Output Class Initialized
INFO - 2023-09-25 11:59:08 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:08 --> Input Class Initialized
INFO - 2023-09-25 11:59:08 --> Language Class Initialized
INFO - 2023-09-25 11:59:08 --> Language Class Initialized
INFO - 2023-09-25 11:59:08 --> Config Class Initialized
INFO - 2023-09-25 11:59:08 --> Loader Class Initialized
INFO - 2023-09-25 11:59:08 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:08 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:08 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:08 --> Controller Class Initialized
INFO - 2023-09-25 11:59:08 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:08 --> Total execution time: 0.1233
INFO - 2023-09-25 11:59:09 --> Config Class Initialized
INFO - 2023-09-25 11:59:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:09 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:09 --> URI Class Initialized
INFO - 2023-09-25 11:59:09 --> Router Class Initialized
INFO - 2023-09-25 11:59:09 --> Output Class Initialized
INFO - 2023-09-25 11:59:09 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:09 --> Input Class Initialized
INFO - 2023-09-25 11:59:09 --> Language Class Initialized
INFO - 2023-09-25 11:59:09 --> Language Class Initialized
INFO - 2023-09-25 11:59:09 --> Config Class Initialized
INFO - 2023-09-25 11:59:09 --> Loader Class Initialized
INFO - 2023-09-25 11:59:09 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:09 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:09 --> Controller Class Initialized
INFO - 2023-09-25 11:59:09 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:09 --> Total execution time: 0.0817
INFO - 2023-09-25 11:59:09 --> Config Class Initialized
INFO - 2023-09-25 11:59:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:09 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:09 --> URI Class Initialized
INFO - 2023-09-25 11:59:09 --> Router Class Initialized
INFO - 2023-09-25 11:59:09 --> Output Class Initialized
INFO - 2023-09-25 11:59:09 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:09 --> Input Class Initialized
INFO - 2023-09-25 11:59:09 --> Language Class Initialized
INFO - 2023-09-25 11:59:09 --> Language Class Initialized
INFO - 2023-09-25 11:59:09 --> Config Class Initialized
INFO - 2023-09-25 11:59:09 --> Loader Class Initialized
INFO - 2023-09-25 11:59:09 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:09 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:09 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:09 --> Controller Class Initialized
INFO - 2023-09-25 11:59:09 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:09 --> Total execution time: 0.0762
INFO - 2023-09-25 11:59:12 --> Config Class Initialized
INFO - 2023-09-25 11:59:12 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:12 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:12 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:12 --> URI Class Initialized
INFO - 2023-09-25 11:59:12 --> Router Class Initialized
INFO - 2023-09-25 11:59:12 --> Output Class Initialized
INFO - 2023-09-25 11:59:12 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:12 --> Input Class Initialized
INFO - 2023-09-25 11:59:12 --> Language Class Initialized
INFO - 2023-09-25 11:59:12 --> Language Class Initialized
INFO - 2023-09-25 11:59:12 --> Config Class Initialized
INFO - 2023-09-25 11:59:12 --> Loader Class Initialized
INFO - 2023-09-25 11:59:12 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:12 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:12 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:12 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:12 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:12 --> Controller Class Initialized
INFO - 2023-09-25 11:59:12 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:12 --> Total execution time: 0.0373
INFO - 2023-09-25 11:59:16 --> Config Class Initialized
INFO - 2023-09-25 11:59:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:16 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:16 --> URI Class Initialized
INFO - 2023-09-25 11:59:16 --> Router Class Initialized
INFO - 2023-09-25 11:59:16 --> Output Class Initialized
INFO - 2023-09-25 11:59:16 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:16 --> Input Class Initialized
INFO - 2023-09-25 11:59:16 --> Language Class Initialized
INFO - 2023-09-25 11:59:16 --> Language Class Initialized
INFO - 2023-09-25 11:59:16 --> Config Class Initialized
INFO - 2023-09-25 11:59:16 --> Loader Class Initialized
INFO - 2023-09-25 11:59:16 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:16 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:16 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:16 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:16 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:16 --> Controller Class Initialized
INFO - 2023-09-25 11:59:16 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:16 --> Total execution time: 0.0508
INFO - 2023-09-25 11:59:21 --> Config Class Initialized
INFO - 2023-09-25 11:59:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 11:59:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 11:59:21 --> Utf8 Class Initialized
INFO - 2023-09-25 11:59:21 --> URI Class Initialized
INFO - 2023-09-25 11:59:21 --> Router Class Initialized
INFO - 2023-09-25 11:59:21 --> Output Class Initialized
INFO - 2023-09-25 11:59:21 --> Security Class Initialized
DEBUG - 2023-09-25 11:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 11:59:21 --> Input Class Initialized
INFO - 2023-09-25 11:59:21 --> Language Class Initialized
INFO - 2023-09-25 11:59:21 --> Language Class Initialized
INFO - 2023-09-25 11:59:21 --> Config Class Initialized
INFO - 2023-09-25 11:59:21 --> Loader Class Initialized
INFO - 2023-09-25 11:59:21 --> Helper loaded: url_helper
INFO - 2023-09-25 11:59:21 --> Helper loaded: file_helper
INFO - 2023-09-25 11:59:21 --> Helper loaded: form_helper
INFO - 2023-09-25 11:59:21 --> Helper loaded: my_helper
INFO - 2023-09-25 11:59:21 --> Database Driver Class Initialized
INFO - 2023-09-25 11:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 11:59:21 --> Controller Class Initialized
INFO - 2023-09-25 11:59:21 --> Final output sent to browser
DEBUG - 2023-09-25 11:59:21 --> Total execution time: 0.0435
INFO - 2023-09-25 12:03:01 --> Config Class Initialized
INFO - 2023-09-25 12:03:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:03:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:03:01 --> Utf8 Class Initialized
INFO - 2023-09-25 12:03:02 --> URI Class Initialized
INFO - 2023-09-25 12:03:02 --> Router Class Initialized
INFO - 2023-09-25 12:03:02 --> Output Class Initialized
INFO - 2023-09-25 12:03:02 --> Security Class Initialized
DEBUG - 2023-09-25 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:03:02 --> Input Class Initialized
INFO - 2023-09-25 12:03:02 --> Language Class Initialized
INFO - 2023-09-25 12:03:02 --> Language Class Initialized
INFO - 2023-09-25 12:03:02 --> Config Class Initialized
INFO - 2023-09-25 12:03:02 --> Loader Class Initialized
INFO - 2023-09-25 12:03:02 --> Helper loaded: url_helper
INFO - 2023-09-25 12:03:02 --> Helper loaded: file_helper
INFO - 2023-09-25 12:03:02 --> Helper loaded: form_helper
INFO - 2023-09-25 12:03:02 --> Helper loaded: my_helper
INFO - 2023-09-25 12:03:02 --> Database Driver Class Initialized
INFO - 2023-09-25 12:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:03:02 --> Controller Class Initialized
INFO - 2023-09-25 12:03:02 --> Final output sent to browser
DEBUG - 2023-09-25 12:03:02 --> Total execution time: 0.1465
INFO - 2023-09-25 12:03:18 --> Config Class Initialized
INFO - 2023-09-25 12:03:18 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:03:18 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:03:18 --> Utf8 Class Initialized
INFO - 2023-09-25 12:03:18 --> URI Class Initialized
INFO - 2023-09-25 12:03:18 --> Router Class Initialized
INFO - 2023-09-25 12:03:18 --> Output Class Initialized
INFO - 2023-09-25 12:03:18 --> Security Class Initialized
DEBUG - 2023-09-25 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:03:18 --> Input Class Initialized
INFO - 2023-09-25 12:03:18 --> Language Class Initialized
INFO - 2023-09-25 12:03:18 --> Language Class Initialized
INFO - 2023-09-25 12:03:18 --> Config Class Initialized
INFO - 2023-09-25 12:03:18 --> Loader Class Initialized
INFO - 2023-09-25 12:03:18 --> Helper loaded: url_helper
INFO - 2023-09-25 12:03:18 --> Helper loaded: file_helper
INFO - 2023-09-25 12:03:18 --> Helper loaded: form_helper
INFO - 2023-09-25 12:03:18 --> Helper loaded: my_helper
INFO - 2023-09-25 12:03:18 --> Database Driver Class Initialized
INFO - 2023-09-25 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:03:18 --> Controller Class Initialized
INFO - 2023-09-25 12:07:25 --> Config Class Initialized
INFO - 2023-09-25 12:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:07:25 --> Utf8 Class Initialized
INFO - 2023-09-25 12:07:25 --> URI Class Initialized
INFO - 2023-09-25 12:07:25 --> Router Class Initialized
INFO - 2023-09-25 12:07:25 --> Output Class Initialized
INFO - 2023-09-25 12:07:25 --> Security Class Initialized
DEBUG - 2023-09-25 12:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:07:25 --> Input Class Initialized
INFO - 2023-09-25 12:07:25 --> Language Class Initialized
INFO - 2023-09-25 12:07:25 --> Language Class Initialized
INFO - 2023-09-25 12:07:25 --> Config Class Initialized
INFO - 2023-09-25 12:07:25 --> Loader Class Initialized
INFO - 2023-09-25 12:07:25 --> Helper loaded: url_helper
INFO - 2023-09-25 12:07:25 --> Helper loaded: file_helper
INFO - 2023-09-25 12:07:25 --> Helper loaded: form_helper
INFO - 2023-09-25 12:07:25 --> Helper loaded: my_helper
INFO - 2023-09-25 12:07:25 --> Database Driver Class Initialized
INFO - 2023-09-25 12:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:07:25 --> Controller Class Initialized
INFO - 2023-09-25 12:07:25 --> Final output sent to browser
DEBUG - 2023-09-25 12:07:25 --> Total execution time: 0.0707
INFO - 2023-09-25 12:07:25 --> Config Class Initialized
INFO - 2023-09-25 12:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:07:25 --> Utf8 Class Initialized
INFO - 2023-09-25 12:07:25 --> URI Class Initialized
INFO - 2023-09-25 12:07:25 --> Router Class Initialized
INFO - 2023-09-25 12:07:25 --> Output Class Initialized
INFO - 2023-09-25 12:07:25 --> Security Class Initialized
DEBUG - 2023-09-25 12:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:07:25 --> Input Class Initialized
INFO - 2023-09-25 12:07:25 --> Language Class Initialized
INFO - 2023-09-25 12:07:26 --> Language Class Initialized
INFO - 2023-09-25 12:07:26 --> Config Class Initialized
INFO - 2023-09-25 12:07:26 --> Loader Class Initialized
INFO - 2023-09-25 12:07:26 --> Helper loaded: url_helper
INFO - 2023-09-25 12:07:26 --> Helper loaded: file_helper
INFO - 2023-09-25 12:07:26 --> Helper loaded: form_helper
INFO - 2023-09-25 12:07:26 --> Helper loaded: my_helper
INFO - 2023-09-25 12:07:26 --> Database Driver Class Initialized
INFO - 2023-09-25 12:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:07:26 --> Controller Class Initialized
INFO - 2023-09-25 12:07:50 --> Config Class Initialized
INFO - 2023-09-25 12:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:07:50 --> Utf8 Class Initialized
INFO - 2023-09-25 12:07:50 --> URI Class Initialized
INFO - 2023-09-25 12:07:50 --> Router Class Initialized
INFO - 2023-09-25 12:07:50 --> Output Class Initialized
INFO - 2023-09-25 12:07:50 --> Security Class Initialized
DEBUG - 2023-09-25 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:07:50 --> Input Class Initialized
INFO - 2023-09-25 12:07:50 --> Language Class Initialized
INFO - 2023-09-25 12:07:50 --> Language Class Initialized
INFO - 2023-09-25 12:07:50 --> Config Class Initialized
INFO - 2023-09-25 12:07:50 --> Loader Class Initialized
INFO - 2023-09-25 12:07:50 --> Helper loaded: url_helper
INFO - 2023-09-25 12:07:50 --> Helper loaded: file_helper
INFO - 2023-09-25 12:07:50 --> Helper loaded: form_helper
INFO - 2023-09-25 12:07:50 --> Helper loaded: my_helper
INFO - 2023-09-25 12:07:50 --> Database Driver Class Initialized
INFO - 2023-09-25 12:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:07:50 --> Controller Class Initialized
INFO - 2023-09-25 12:07:50 --> Final output sent to browser
DEBUG - 2023-09-25 12:07:50 --> Total execution time: 0.1043
INFO - 2023-09-25 12:07:55 --> Config Class Initialized
INFO - 2023-09-25 12:07:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:07:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:07:55 --> Utf8 Class Initialized
INFO - 2023-09-25 12:07:55 --> URI Class Initialized
INFO - 2023-09-25 12:07:55 --> Router Class Initialized
INFO - 2023-09-25 12:07:55 --> Output Class Initialized
INFO - 2023-09-25 12:07:55 --> Security Class Initialized
DEBUG - 2023-09-25 12:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:07:55 --> Input Class Initialized
INFO - 2023-09-25 12:07:55 --> Language Class Initialized
INFO - 2023-09-25 12:07:55 --> Language Class Initialized
INFO - 2023-09-25 12:07:55 --> Config Class Initialized
INFO - 2023-09-25 12:07:55 --> Loader Class Initialized
INFO - 2023-09-25 12:07:55 --> Helper loaded: url_helper
INFO - 2023-09-25 12:07:55 --> Helper loaded: file_helper
INFO - 2023-09-25 12:07:55 --> Helper loaded: form_helper
INFO - 2023-09-25 12:07:55 --> Helper loaded: my_helper
INFO - 2023-09-25 12:07:55 --> Database Driver Class Initialized
INFO - 2023-09-25 12:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:07:55 --> Controller Class Initialized
INFO - 2023-09-25 12:07:56 --> Final output sent to browser
DEBUG - 2023-09-25 12:07:56 --> Total execution time: 0.4448
INFO - 2023-09-25 12:08:14 --> Config Class Initialized
INFO - 2023-09-25 12:08:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:08:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:08:14 --> Utf8 Class Initialized
INFO - 2023-09-25 12:08:14 --> URI Class Initialized
INFO - 2023-09-25 12:08:14 --> Router Class Initialized
INFO - 2023-09-25 12:08:14 --> Output Class Initialized
INFO - 2023-09-25 12:08:14 --> Security Class Initialized
DEBUG - 2023-09-25 12:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:08:14 --> Input Class Initialized
INFO - 2023-09-25 12:08:14 --> Language Class Initialized
INFO - 2023-09-25 12:08:14 --> Language Class Initialized
INFO - 2023-09-25 12:08:14 --> Config Class Initialized
INFO - 2023-09-25 12:08:14 --> Loader Class Initialized
INFO - 2023-09-25 12:08:14 --> Helper loaded: url_helper
INFO - 2023-09-25 12:08:14 --> Helper loaded: file_helper
INFO - 2023-09-25 12:08:14 --> Helper loaded: form_helper
INFO - 2023-09-25 12:08:14 --> Helper loaded: my_helper
INFO - 2023-09-25 12:08:14 --> Database Driver Class Initialized
INFO - 2023-09-25 12:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:08:14 --> Controller Class Initialized
INFO - 2023-09-25 12:14:59 --> Config Class Initialized
INFO - 2023-09-25 12:14:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:14:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:14:59 --> Utf8 Class Initialized
INFO - 2023-09-25 12:14:59 --> URI Class Initialized
INFO - 2023-09-25 12:14:59 --> Router Class Initialized
INFO - 2023-09-25 12:14:59 --> Output Class Initialized
INFO - 2023-09-25 12:14:59 --> Security Class Initialized
DEBUG - 2023-09-25 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:14:59 --> Input Class Initialized
INFO - 2023-09-25 12:14:59 --> Language Class Initialized
INFO - 2023-09-25 12:14:59 --> Language Class Initialized
INFO - 2023-09-25 12:14:59 --> Config Class Initialized
INFO - 2023-09-25 12:14:59 --> Loader Class Initialized
INFO - 2023-09-25 12:14:59 --> Helper loaded: url_helper
INFO - 2023-09-25 12:14:59 --> Helper loaded: file_helper
INFO - 2023-09-25 12:14:59 --> Helper loaded: form_helper
INFO - 2023-09-25 12:14:59 --> Helper loaded: my_helper
INFO - 2023-09-25 12:14:59 --> Database Driver Class Initialized
INFO - 2023-09-25 12:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:14:59 --> Controller Class Initialized
DEBUG - 2023-09-25 12:14:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-25 12:14:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:14:59 --> Final output sent to browser
DEBUG - 2023-09-25 12:14:59 --> Total execution time: 0.0909
INFO - 2023-09-25 12:15:45 --> Config Class Initialized
INFO - 2023-09-25 12:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:15:45 --> Utf8 Class Initialized
INFO - 2023-09-25 12:15:45 --> URI Class Initialized
INFO - 2023-09-25 12:15:45 --> Router Class Initialized
INFO - 2023-09-25 12:15:45 --> Output Class Initialized
INFO - 2023-09-25 12:15:45 --> Security Class Initialized
DEBUG - 2023-09-25 12:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:15:45 --> Input Class Initialized
INFO - 2023-09-25 12:15:45 --> Language Class Initialized
INFO - 2023-09-25 12:15:45 --> Language Class Initialized
INFO - 2023-09-25 12:15:45 --> Config Class Initialized
INFO - 2023-09-25 12:15:45 --> Loader Class Initialized
INFO - 2023-09-25 12:15:45 --> Helper loaded: url_helper
INFO - 2023-09-25 12:15:45 --> Helper loaded: file_helper
INFO - 2023-09-25 12:15:45 --> Helper loaded: form_helper
INFO - 2023-09-25 12:15:45 --> Helper loaded: my_helper
INFO - 2023-09-25 12:15:45 --> Database Driver Class Initialized
INFO - 2023-09-25 12:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:15:45 --> Controller Class Initialized
INFO - 2023-09-25 12:15:46 --> Config Class Initialized
INFO - 2023-09-25 12:15:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:15:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:15:46 --> Utf8 Class Initialized
INFO - 2023-09-25 12:15:46 --> URI Class Initialized
INFO - 2023-09-25 12:15:46 --> Router Class Initialized
INFO - 2023-09-25 12:15:46 --> Output Class Initialized
INFO - 2023-09-25 12:15:46 --> Security Class Initialized
DEBUG - 2023-09-25 12:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:15:46 --> Input Class Initialized
INFO - 2023-09-25 12:15:46 --> Language Class Initialized
INFO - 2023-09-25 12:15:46 --> Language Class Initialized
INFO - 2023-09-25 12:15:46 --> Config Class Initialized
INFO - 2023-09-25 12:15:46 --> Loader Class Initialized
INFO - 2023-09-25 12:15:46 --> Helper loaded: url_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: file_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: form_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: my_helper
INFO - 2023-09-25 12:15:46 --> Database Driver Class Initialized
INFO - 2023-09-25 12:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:15:46 --> Controller Class Initialized
DEBUG - 2023-09-25 12:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 12:15:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:15:46 --> Final output sent to browser
DEBUG - 2023-09-25 12:15:46 --> Total execution time: 0.0412
INFO - 2023-09-25 12:15:46 --> Config Class Initialized
INFO - 2023-09-25 12:15:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:15:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:15:46 --> Utf8 Class Initialized
INFO - 2023-09-25 12:15:46 --> URI Class Initialized
INFO - 2023-09-25 12:15:46 --> Router Class Initialized
INFO - 2023-09-25 12:15:46 --> Output Class Initialized
INFO - 2023-09-25 12:15:46 --> Security Class Initialized
DEBUG - 2023-09-25 12:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:15:46 --> Input Class Initialized
INFO - 2023-09-25 12:15:46 --> Language Class Initialized
INFO - 2023-09-25 12:15:46 --> Language Class Initialized
INFO - 2023-09-25 12:15:46 --> Config Class Initialized
INFO - 2023-09-25 12:15:46 --> Loader Class Initialized
INFO - 2023-09-25 12:15:46 --> Helper loaded: url_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: file_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: form_helper
INFO - 2023-09-25 12:15:46 --> Helper loaded: my_helper
INFO - 2023-09-25 12:15:46 --> Database Driver Class Initialized
INFO - 2023-09-25 12:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:15:46 --> Controller Class Initialized
INFO - 2023-09-25 12:15:55 --> Config Class Initialized
INFO - 2023-09-25 12:15:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:15:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:15:55 --> Utf8 Class Initialized
INFO - 2023-09-25 12:15:55 --> URI Class Initialized
INFO - 2023-09-25 12:15:55 --> Router Class Initialized
INFO - 2023-09-25 12:15:55 --> Output Class Initialized
INFO - 2023-09-25 12:15:55 --> Security Class Initialized
DEBUG - 2023-09-25 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:15:55 --> Input Class Initialized
INFO - 2023-09-25 12:15:55 --> Language Class Initialized
INFO - 2023-09-25 12:15:55 --> Language Class Initialized
INFO - 2023-09-25 12:15:55 --> Config Class Initialized
INFO - 2023-09-25 12:15:55 --> Loader Class Initialized
INFO - 2023-09-25 12:15:55 --> Helper loaded: url_helper
INFO - 2023-09-25 12:15:55 --> Helper loaded: file_helper
INFO - 2023-09-25 12:15:55 --> Helper loaded: form_helper
INFO - 2023-09-25 12:15:55 --> Helper loaded: my_helper
INFO - 2023-09-25 12:15:55 --> Database Driver Class Initialized
INFO - 2023-09-25 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:15:55 --> Controller Class Initialized
INFO - 2023-09-25 12:15:55 --> Final output sent to browser
DEBUG - 2023-09-25 12:15:55 --> Total execution time: 0.0554
INFO - 2023-09-25 12:16:08 --> Config Class Initialized
INFO - 2023-09-25 12:16:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:16:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:16:08 --> Utf8 Class Initialized
INFO - 2023-09-25 12:16:08 --> URI Class Initialized
INFO - 2023-09-25 12:16:08 --> Router Class Initialized
INFO - 2023-09-25 12:16:08 --> Output Class Initialized
INFO - 2023-09-25 12:16:08 --> Security Class Initialized
DEBUG - 2023-09-25 12:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:16:08 --> Input Class Initialized
INFO - 2023-09-25 12:16:08 --> Language Class Initialized
INFO - 2023-09-25 12:16:08 --> Language Class Initialized
INFO - 2023-09-25 12:16:08 --> Config Class Initialized
INFO - 2023-09-25 12:16:08 --> Loader Class Initialized
INFO - 2023-09-25 12:16:08 --> Helper loaded: url_helper
INFO - 2023-09-25 12:16:08 --> Helper loaded: file_helper
INFO - 2023-09-25 12:16:08 --> Helper loaded: form_helper
INFO - 2023-09-25 12:16:08 --> Helper loaded: my_helper
INFO - 2023-09-25 12:16:08 --> Database Driver Class Initialized
INFO - 2023-09-25 12:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:16:08 --> Controller Class Initialized
INFO - 2023-09-25 12:16:08 --> Final output sent to browser
DEBUG - 2023-09-25 12:16:08 --> Total execution time: 0.0892
INFO - 2023-09-25 12:17:10 --> Config Class Initialized
INFO - 2023-09-25 12:17:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:10 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:10 --> URI Class Initialized
INFO - 2023-09-25 12:17:10 --> Router Class Initialized
INFO - 2023-09-25 12:17:10 --> Output Class Initialized
INFO - 2023-09-25 12:17:10 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:10 --> Input Class Initialized
INFO - 2023-09-25 12:17:10 --> Language Class Initialized
INFO - 2023-09-25 12:17:10 --> Language Class Initialized
INFO - 2023-09-25 12:17:10 --> Config Class Initialized
INFO - 2023-09-25 12:17:10 --> Loader Class Initialized
INFO - 2023-09-25 12:17:10 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:10 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:11 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:11 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:11 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:11 --> Controller Class Initialized
DEBUG - 2023-09-25 12:17:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 12:17:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:17:11 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:11 --> Total execution time: 0.0982
INFO - 2023-09-25 12:17:19 --> Config Class Initialized
INFO - 2023-09-25 12:17:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:19 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:19 --> URI Class Initialized
INFO - 2023-09-25 12:17:19 --> Router Class Initialized
INFO - 2023-09-25 12:17:19 --> Output Class Initialized
INFO - 2023-09-25 12:17:19 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:19 --> Input Class Initialized
INFO - 2023-09-25 12:17:19 --> Language Class Initialized
INFO - 2023-09-25 12:17:19 --> Language Class Initialized
INFO - 2023-09-25 12:17:19 --> Config Class Initialized
INFO - 2023-09-25 12:17:19 --> Loader Class Initialized
INFO - 2023-09-25 12:17:19 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:19 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:19 --> Controller Class Initialized
INFO - 2023-09-25 12:17:19 --> Helper loaded: cookie_helper
INFO - 2023-09-25 12:17:19 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:19 --> Total execution time: 0.2126
INFO - 2023-09-25 12:17:19 --> Config Class Initialized
INFO - 2023-09-25 12:17:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:19 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:19 --> URI Class Initialized
INFO - 2023-09-25 12:17:19 --> Router Class Initialized
INFO - 2023-09-25 12:17:19 --> Output Class Initialized
INFO - 2023-09-25 12:17:19 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:19 --> Input Class Initialized
INFO - 2023-09-25 12:17:19 --> Language Class Initialized
INFO - 2023-09-25 12:17:19 --> Language Class Initialized
INFO - 2023-09-25 12:17:19 --> Config Class Initialized
INFO - 2023-09-25 12:17:19 --> Loader Class Initialized
INFO - 2023-09-25 12:17:19 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:19 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:19 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:19 --> Controller Class Initialized
DEBUG - 2023-09-25 12:17:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 12:17:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:17:19 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:19 --> Total execution time: 0.0609
INFO - 2023-09-25 12:17:23 --> Config Class Initialized
INFO - 2023-09-25 12:17:23 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:23 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:23 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:23 --> URI Class Initialized
INFO - 2023-09-25 12:17:23 --> Router Class Initialized
INFO - 2023-09-25 12:17:23 --> Output Class Initialized
INFO - 2023-09-25 12:17:23 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:23 --> Input Class Initialized
INFO - 2023-09-25 12:17:23 --> Language Class Initialized
INFO - 2023-09-25 12:17:23 --> Language Class Initialized
INFO - 2023-09-25 12:17:23 --> Config Class Initialized
INFO - 2023-09-25 12:17:23 --> Loader Class Initialized
INFO - 2023-09-25 12:17:23 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:23 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:23 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:23 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:23 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:23 --> Controller Class Initialized
DEBUG - 2023-09-25 12:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 12:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:17:23 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:23 --> Total execution time: 0.0945
INFO - 2023-09-25 12:17:28 --> Config Class Initialized
INFO - 2023-09-25 12:17:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:28 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:28 --> URI Class Initialized
INFO - 2023-09-25 12:17:28 --> Router Class Initialized
INFO - 2023-09-25 12:17:28 --> Output Class Initialized
INFO - 2023-09-25 12:17:28 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:28 --> Input Class Initialized
INFO - 2023-09-25 12:17:28 --> Language Class Initialized
INFO - 2023-09-25 12:17:28 --> Language Class Initialized
INFO - 2023-09-25 12:17:28 --> Config Class Initialized
INFO - 2023-09-25 12:17:28 --> Loader Class Initialized
INFO - 2023-09-25 12:17:28 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:28 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:28 --> Controller Class Initialized
DEBUG - 2023-09-25 12:17:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 12:17:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:17:28 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:28 --> Total execution time: 0.0620
INFO - 2023-09-25 12:17:28 --> Config Class Initialized
INFO - 2023-09-25 12:17:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:28 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:28 --> URI Class Initialized
INFO - 2023-09-25 12:17:28 --> Router Class Initialized
INFO - 2023-09-25 12:17:28 --> Output Class Initialized
INFO - 2023-09-25 12:17:28 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:28 --> Input Class Initialized
INFO - 2023-09-25 12:17:28 --> Language Class Initialized
INFO - 2023-09-25 12:17:28 --> Language Class Initialized
INFO - 2023-09-25 12:17:28 --> Config Class Initialized
INFO - 2023-09-25 12:17:28 --> Loader Class Initialized
INFO - 2023-09-25 12:17:28 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:28 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:28 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:28 --> Controller Class Initialized
INFO - 2023-09-25 12:17:30 --> Config Class Initialized
INFO - 2023-09-25 12:17:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:30 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:30 --> URI Class Initialized
INFO - 2023-09-25 12:17:30 --> Router Class Initialized
INFO - 2023-09-25 12:17:30 --> Output Class Initialized
INFO - 2023-09-25 12:17:30 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:30 --> Input Class Initialized
INFO - 2023-09-25 12:17:30 --> Language Class Initialized
INFO - 2023-09-25 12:17:30 --> Language Class Initialized
INFO - 2023-09-25 12:17:30 --> Config Class Initialized
INFO - 2023-09-25 12:17:30 --> Loader Class Initialized
INFO - 2023-09-25 12:17:30 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:30 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:30 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:30 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:30 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:31 --> Controller Class Initialized
INFO - 2023-09-25 12:17:31 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:31 --> Total execution time: 0.5275
INFO - 2023-09-25 12:17:38 --> Config Class Initialized
INFO - 2023-09-25 12:17:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:17:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:17:38 --> Utf8 Class Initialized
INFO - 2023-09-25 12:17:38 --> URI Class Initialized
INFO - 2023-09-25 12:17:38 --> Router Class Initialized
INFO - 2023-09-25 12:17:38 --> Output Class Initialized
INFO - 2023-09-25 12:17:38 --> Security Class Initialized
DEBUG - 2023-09-25 12:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:17:38 --> Input Class Initialized
INFO - 2023-09-25 12:17:38 --> Language Class Initialized
INFO - 2023-09-25 12:17:38 --> Language Class Initialized
INFO - 2023-09-25 12:17:38 --> Config Class Initialized
INFO - 2023-09-25 12:17:38 --> Loader Class Initialized
INFO - 2023-09-25 12:17:38 --> Helper loaded: url_helper
INFO - 2023-09-25 12:17:38 --> Helper loaded: file_helper
INFO - 2023-09-25 12:17:38 --> Helper loaded: form_helper
INFO - 2023-09-25 12:17:38 --> Helper loaded: my_helper
INFO - 2023-09-25 12:17:38 --> Database Driver Class Initialized
INFO - 2023-09-25 12:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:17:38 --> Controller Class Initialized
INFO - 2023-09-25 12:17:38 --> Final output sent to browser
DEBUG - 2023-09-25 12:17:38 --> Total execution time: 0.0895
INFO - 2023-09-25 12:24:56 --> Config Class Initialized
INFO - 2023-09-25 12:24:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:24:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:24:56 --> Utf8 Class Initialized
INFO - 2023-09-25 12:24:56 --> URI Class Initialized
INFO - 2023-09-25 12:24:56 --> Router Class Initialized
INFO - 2023-09-25 12:24:56 --> Output Class Initialized
INFO - 2023-09-25 12:24:56 --> Security Class Initialized
DEBUG - 2023-09-25 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:24:56 --> Input Class Initialized
INFO - 2023-09-25 12:24:56 --> Language Class Initialized
INFO - 2023-09-25 12:24:56 --> Language Class Initialized
INFO - 2023-09-25 12:24:56 --> Config Class Initialized
INFO - 2023-09-25 12:24:56 --> Loader Class Initialized
INFO - 2023-09-25 12:24:56 --> Helper loaded: url_helper
INFO - 2023-09-25 12:24:56 --> Helper loaded: file_helper
INFO - 2023-09-25 12:24:56 --> Helper loaded: form_helper
INFO - 2023-09-25 12:24:56 --> Helper loaded: my_helper
INFO - 2023-09-25 12:24:56 --> Database Driver Class Initialized
INFO - 2023-09-25 12:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:24:56 --> Controller Class Initialized
DEBUG - 2023-09-25 12:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 12:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:24:56 --> Final output sent to browser
DEBUG - 2023-09-25 12:24:56 --> Total execution time: 0.0655
INFO - 2023-09-25 12:25:04 --> Config Class Initialized
INFO - 2023-09-25 12:25:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:04 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:04 --> URI Class Initialized
INFO - 2023-09-25 12:25:04 --> Router Class Initialized
INFO - 2023-09-25 12:25:04 --> Output Class Initialized
INFO - 2023-09-25 12:25:04 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:04 --> Input Class Initialized
INFO - 2023-09-25 12:25:04 --> Language Class Initialized
INFO - 2023-09-25 12:25:04 --> Language Class Initialized
INFO - 2023-09-25 12:25:04 --> Config Class Initialized
INFO - 2023-09-25 12:25:04 --> Loader Class Initialized
INFO - 2023-09-25 12:25:04 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:04 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:04 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:04 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:04 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:04 --> Controller Class Initialized
INFO - 2023-09-25 12:25:04 --> Helper loaded: cookie_helper
INFO - 2023-09-25 12:25:04 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:04 --> Total execution time: 0.1362
INFO - 2023-09-25 12:25:05 --> Config Class Initialized
INFO - 2023-09-25 12:25:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:05 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:05 --> URI Class Initialized
INFO - 2023-09-25 12:25:05 --> Router Class Initialized
INFO - 2023-09-25 12:25:05 --> Output Class Initialized
INFO - 2023-09-25 12:25:05 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:05 --> Input Class Initialized
INFO - 2023-09-25 12:25:05 --> Language Class Initialized
INFO - 2023-09-25 12:25:05 --> Language Class Initialized
INFO - 2023-09-25 12:25:05 --> Config Class Initialized
INFO - 2023-09-25 12:25:05 --> Loader Class Initialized
INFO - 2023-09-25 12:25:05 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:05 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:05 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:05 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:05 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:05 --> Controller Class Initialized
DEBUG - 2023-09-25 12:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 12:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:25:05 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:05 --> Total execution time: 0.0402
INFO - 2023-09-25 12:25:08 --> Config Class Initialized
INFO - 2023-09-25 12:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:08 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:08 --> URI Class Initialized
INFO - 2023-09-25 12:25:08 --> Router Class Initialized
INFO - 2023-09-25 12:25:08 --> Output Class Initialized
INFO - 2023-09-25 12:25:08 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:08 --> Input Class Initialized
INFO - 2023-09-25 12:25:08 --> Language Class Initialized
INFO - 2023-09-25 12:25:08 --> Language Class Initialized
INFO - 2023-09-25 12:25:08 --> Config Class Initialized
INFO - 2023-09-25 12:25:08 --> Loader Class Initialized
INFO - 2023-09-25 12:25:08 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:08 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:08 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:08 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:08 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:08 --> Controller Class Initialized
DEBUG - 2023-09-25 12:25:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-25 12:25:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:25:08 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:08 --> Total execution time: 0.0361
INFO - 2023-09-25 12:25:11 --> Config Class Initialized
INFO - 2023-09-25 12:25:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:11 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:11 --> URI Class Initialized
INFO - 2023-09-25 12:25:11 --> Router Class Initialized
INFO - 2023-09-25 12:25:11 --> Output Class Initialized
INFO - 2023-09-25 12:25:11 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:11 --> Input Class Initialized
INFO - 2023-09-25 12:25:11 --> Language Class Initialized
INFO - 2023-09-25 12:25:11 --> Language Class Initialized
INFO - 2023-09-25 12:25:11 --> Config Class Initialized
INFO - 2023-09-25 12:25:11 --> Loader Class Initialized
INFO - 2023-09-25 12:25:11 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:11 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:11 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:11 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:11 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:11 --> Controller Class Initialized
DEBUG - 2023-09-25 12:25:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 12:25:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:25:11 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:11 --> Total execution time: 0.0358
INFO - 2023-09-25 12:25:15 --> Config Class Initialized
INFO - 2023-09-25 12:25:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:15 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:15 --> URI Class Initialized
INFO - 2023-09-25 12:25:15 --> Router Class Initialized
INFO - 2023-09-25 12:25:15 --> Output Class Initialized
INFO - 2023-09-25 12:25:15 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:15 --> Input Class Initialized
INFO - 2023-09-25 12:25:15 --> Language Class Initialized
INFO - 2023-09-25 12:25:15 --> Language Class Initialized
INFO - 2023-09-25 12:25:15 --> Config Class Initialized
INFO - 2023-09-25 12:25:15 --> Loader Class Initialized
INFO - 2023-09-25 12:25:15 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:15 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:15 --> Controller Class Initialized
DEBUG - 2023-09-25 12:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 12:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:25:15 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:15 --> Total execution time: 0.0368
INFO - 2023-09-25 12:25:15 --> Config Class Initialized
INFO - 2023-09-25 12:25:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:15 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:15 --> URI Class Initialized
INFO - 2023-09-25 12:25:15 --> Router Class Initialized
INFO - 2023-09-25 12:25:15 --> Output Class Initialized
INFO - 2023-09-25 12:25:15 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:15 --> Input Class Initialized
INFO - 2023-09-25 12:25:15 --> Language Class Initialized
INFO - 2023-09-25 12:25:15 --> Language Class Initialized
INFO - 2023-09-25 12:25:15 --> Config Class Initialized
INFO - 2023-09-25 12:25:15 --> Loader Class Initialized
INFO - 2023-09-25 12:25:15 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:15 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:15 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:16 --> Controller Class Initialized
INFO - 2023-09-25 12:25:21 --> Config Class Initialized
INFO - 2023-09-25 12:25:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:25:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:25:21 --> Utf8 Class Initialized
INFO - 2023-09-25 12:25:21 --> URI Class Initialized
INFO - 2023-09-25 12:25:21 --> Router Class Initialized
INFO - 2023-09-25 12:25:21 --> Output Class Initialized
INFO - 2023-09-25 12:25:21 --> Security Class Initialized
DEBUG - 2023-09-25 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:25:21 --> Input Class Initialized
INFO - 2023-09-25 12:25:21 --> Language Class Initialized
INFO - 2023-09-25 12:25:21 --> Language Class Initialized
INFO - 2023-09-25 12:25:21 --> Config Class Initialized
INFO - 2023-09-25 12:25:21 --> Loader Class Initialized
INFO - 2023-09-25 12:25:21 --> Helper loaded: url_helper
INFO - 2023-09-25 12:25:21 --> Helper loaded: file_helper
INFO - 2023-09-25 12:25:21 --> Helper loaded: form_helper
INFO - 2023-09-25 12:25:21 --> Helper loaded: my_helper
INFO - 2023-09-25 12:25:21 --> Database Driver Class Initialized
INFO - 2023-09-25 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:25:21 --> Controller Class Initialized
INFO - 2023-09-25 12:25:21 --> Final output sent to browser
DEBUG - 2023-09-25 12:25:21 --> Total execution time: 0.0380
INFO - 2023-09-25 12:26:55 --> Config Class Initialized
INFO - 2023-09-25 12:26:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 12:26:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 12:26:55 --> Utf8 Class Initialized
INFO - 2023-09-25 12:26:55 --> URI Class Initialized
INFO - 2023-09-25 12:26:55 --> Router Class Initialized
INFO - 2023-09-25 12:26:55 --> Output Class Initialized
INFO - 2023-09-25 12:26:55 --> Security Class Initialized
DEBUG - 2023-09-25 12:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 12:26:55 --> Input Class Initialized
INFO - 2023-09-25 12:26:55 --> Language Class Initialized
INFO - 2023-09-25 12:26:55 --> Language Class Initialized
INFO - 2023-09-25 12:26:55 --> Config Class Initialized
INFO - 2023-09-25 12:26:55 --> Loader Class Initialized
INFO - 2023-09-25 12:26:55 --> Helper loaded: url_helper
INFO - 2023-09-25 12:26:55 --> Helper loaded: file_helper
INFO - 2023-09-25 12:26:55 --> Helper loaded: form_helper
INFO - 2023-09-25 12:26:55 --> Helper loaded: my_helper
INFO - 2023-09-25 12:26:55 --> Database Driver Class Initialized
INFO - 2023-09-25 12:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 12:26:55 --> Controller Class Initialized
DEBUG - 2023-09-25 12:26:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-25 12:26:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 12:26:55 --> Final output sent to browser
DEBUG - 2023-09-25 12:26:55 --> Total execution time: 0.1925
INFO - 2023-09-25 13:31:55 --> Config Class Initialized
INFO - 2023-09-25 13:31:55 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:31:55 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:31:55 --> Utf8 Class Initialized
INFO - 2023-09-25 13:31:55 --> URI Class Initialized
INFO - 2023-09-25 13:31:55 --> Router Class Initialized
INFO - 2023-09-25 13:31:55 --> Output Class Initialized
INFO - 2023-09-25 13:31:55 --> Security Class Initialized
DEBUG - 2023-09-25 13:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:31:55 --> Input Class Initialized
INFO - 2023-09-25 13:31:55 --> Language Class Initialized
INFO - 2023-09-25 13:31:55 --> Language Class Initialized
INFO - 2023-09-25 13:31:55 --> Config Class Initialized
INFO - 2023-09-25 13:31:55 --> Loader Class Initialized
INFO - 2023-09-25 13:31:55 --> Helper loaded: url_helper
INFO - 2023-09-25 13:31:55 --> Helper loaded: file_helper
INFO - 2023-09-25 13:31:55 --> Helper loaded: form_helper
INFO - 2023-09-25 13:31:55 --> Helper loaded: my_helper
INFO - 2023-09-25 13:31:55 --> Database Driver Class Initialized
INFO - 2023-09-25 13:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:31:55 --> Controller Class Initialized
DEBUG - 2023-09-25 13:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 13:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 13:31:55 --> Final output sent to browser
DEBUG - 2023-09-25 13:31:55 --> Total execution time: 0.1357
INFO - 2023-09-25 13:31:56 --> Config Class Initialized
INFO - 2023-09-25 13:31:56 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:31:56 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:31:56 --> Utf8 Class Initialized
INFO - 2023-09-25 13:31:56 --> URI Class Initialized
INFO - 2023-09-25 13:31:56 --> Router Class Initialized
INFO - 2023-09-25 13:31:56 --> Output Class Initialized
INFO - 2023-09-25 13:31:56 --> Security Class Initialized
DEBUG - 2023-09-25 13:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:31:56 --> Input Class Initialized
INFO - 2023-09-25 13:31:56 --> Language Class Initialized
INFO - 2023-09-25 13:31:56 --> Language Class Initialized
INFO - 2023-09-25 13:31:56 --> Config Class Initialized
INFO - 2023-09-25 13:31:56 --> Loader Class Initialized
INFO - 2023-09-25 13:31:56 --> Helper loaded: url_helper
INFO - 2023-09-25 13:31:56 --> Helper loaded: file_helper
INFO - 2023-09-25 13:31:56 --> Helper loaded: form_helper
INFO - 2023-09-25 13:31:56 --> Helper loaded: my_helper
INFO - 2023-09-25 13:31:56 --> Database Driver Class Initialized
INFO - 2023-09-25 13:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:31:56 --> Controller Class Initialized
INFO - 2023-09-25 13:31:59 --> Config Class Initialized
INFO - 2023-09-25 13:31:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:31:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:31:59 --> Utf8 Class Initialized
INFO - 2023-09-25 13:31:59 --> URI Class Initialized
INFO - 2023-09-25 13:31:59 --> Router Class Initialized
INFO - 2023-09-25 13:31:59 --> Output Class Initialized
INFO - 2023-09-25 13:31:59 --> Security Class Initialized
DEBUG - 2023-09-25 13:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:31:59 --> Input Class Initialized
INFO - 2023-09-25 13:31:59 --> Language Class Initialized
INFO - 2023-09-25 13:31:59 --> Language Class Initialized
INFO - 2023-09-25 13:31:59 --> Config Class Initialized
INFO - 2023-09-25 13:31:59 --> Loader Class Initialized
INFO - 2023-09-25 13:31:59 --> Helper loaded: url_helper
INFO - 2023-09-25 13:31:59 --> Helper loaded: file_helper
INFO - 2023-09-25 13:31:59 --> Helper loaded: form_helper
INFO - 2023-09-25 13:31:59 --> Helper loaded: my_helper
INFO - 2023-09-25 13:31:59 --> Database Driver Class Initialized
INFO - 2023-09-25 13:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:31:59 --> Controller Class Initialized
INFO - 2023-09-25 13:31:59 --> Final output sent to browser
DEBUG - 2023-09-25 13:31:59 --> Total execution time: 0.0933
INFO - 2023-09-25 13:37:30 --> Config Class Initialized
INFO - 2023-09-25 13:37:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:37:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:37:31 --> Utf8 Class Initialized
INFO - 2023-09-25 13:37:31 --> URI Class Initialized
INFO - 2023-09-25 13:37:31 --> Router Class Initialized
INFO - 2023-09-25 13:37:31 --> Output Class Initialized
INFO - 2023-09-25 13:37:31 --> Security Class Initialized
DEBUG - 2023-09-25 13:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:37:31 --> Input Class Initialized
INFO - 2023-09-25 13:37:31 --> Language Class Initialized
INFO - 2023-09-25 13:37:31 --> Language Class Initialized
INFO - 2023-09-25 13:37:31 --> Config Class Initialized
INFO - 2023-09-25 13:37:31 --> Loader Class Initialized
INFO - 2023-09-25 13:37:31 --> Helper loaded: url_helper
INFO - 2023-09-25 13:37:31 --> Helper loaded: file_helper
INFO - 2023-09-25 13:37:31 --> Helper loaded: form_helper
INFO - 2023-09-25 13:37:31 --> Helper loaded: my_helper
INFO - 2023-09-25 13:37:31 --> Database Driver Class Initialized
INFO - 2023-09-25 13:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:37:31 --> Controller Class Initialized
DEBUG - 2023-09-25 13:37:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 13:37:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 13:37:31 --> Final output sent to browser
DEBUG - 2023-09-25 13:37:31 --> Total execution time: 0.6930
INFO - 2023-09-25 13:58:08 --> Config Class Initialized
INFO - 2023-09-25 13:58:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:58:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:58:08 --> Utf8 Class Initialized
INFO - 2023-09-25 13:58:08 --> URI Class Initialized
INFO - 2023-09-25 13:58:08 --> Router Class Initialized
INFO - 2023-09-25 13:58:08 --> Output Class Initialized
INFO - 2023-09-25 13:58:08 --> Security Class Initialized
DEBUG - 2023-09-25 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:58:08 --> Input Class Initialized
INFO - 2023-09-25 13:58:08 --> Language Class Initialized
INFO - 2023-09-25 13:58:08 --> Language Class Initialized
INFO - 2023-09-25 13:58:08 --> Config Class Initialized
INFO - 2023-09-25 13:58:08 --> Loader Class Initialized
INFO - 2023-09-25 13:58:08 --> Helper loaded: url_helper
INFO - 2023-09-25 13:58:08 --> Helper loaded: file_helper
INFO - 2023-09-25 13:58:08 --> Helper loaded: form_helper
INFO - 2023-09-25 13:58:08 --> Helper loaded: my_helper
INFO - 2023-09-25 13:58:08 --> Database Driver Class Initialized
INFO - 2023-09-25 13:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:58:08 --> Controller Class Initialized
DEBUG - 2023-09-25 13:58:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 13:58:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 13:58:08 --> Final output sent to browser
DEBUG - 2023-09-25 13:58:08 --> Total execution time: 0.0779
INFO - 2023-09-25 13:58:14 --> Config Class Initialized
INFO - 2023-09-25 13:58:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:58:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:58:14 --> Utf8 Class Initialized
INFO - 2023-09-25 13:58:14 --> URI Class Initialized
INFO - 2023-09-25 13:58:14 --> Router Class Initialized
INFO - 2023-09-25 13:58:14 --> Output Class Initialized
INFO - 2023-09-25 13:58:14 --> Security Class Initialized
DEBUG - 2023-09-25 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:58:14 --> Input Class Initialized
INFO - 2023-09-25 13:58:14 --> Language Class Initialized
INFO - 2023-09-25 13:58:14 --> Language Class Initialized
INFO - 2023-09-25 13:58:14 --> Config Class Initialized
INFO - 2023-09-25 13:58:14 --> Loader Class Initialized
INFO - 2023-09-25 13:58:14 --> Helper loaded: url_helper
INFO - 2023-09-25 13:58:14 --> Helper loaded: file_helper
INFO - 2023-09-25 13:58:14 --> Helper loaded: form_helper
INFO - 2023-09-25 13:58:14 --> Helper loaded: my_helper
INFO - 2023-09-25 13:58:14 --> Database Driver Class Initialized
INFO - 2023-09-25 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:58:14 --> Controller Class Initialized
INFO - 2023-09-25 13:58:14 --> Helper loaded: cookie_helper
INFO - 2023-09-25 13:58:14 --> Final output sent to browser
DEBUG - 2023-09-25 13:58:14 --> Total execution time: 0.0514
INFO - 2023-09-25 13:58:15 --> Config Class Initialized
INFO - 2023-09-25 13:58:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:58:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:58:15 --> Utf8 Class Initialized
INFO - 2023-09-25 13:58:15 --> URI Class Initialized
INFO - 2023-09-25 13:58:15 --> Router Class Initialized
INFO - 2023-09-25 13:58:15 --> Output Class Initialized
INFO - 2023-09-25 13:58:15 --> Security Class Initialized
DEBUG - 2023-09-25 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:58:15 --> Input Class Initialized
INFO - 2023-09-25 13:58:15 --> Language Class Initialized
INFO - 2023-09-25 13:58:15 --> Language Class Initialized
INFO - 2023-09-25 13:58:15 --> Config Class Initialized
INFO - 2023-09-25 13:58:15 --> Loader Class Initialized
INFO - 2023-09-25 13:58:15 --> Helper loaded: url_helper
INFO - 2023-09-25 13:58:15 --> Helper loaded: file_helper
INFO - 2023-09-25 13:58:15 --> Helper loaded: form_helper
INFO - 2023-09-25 13:58:15 --> Helper loaded: my_helper
INFO - 2023-09-25 13:58:15 --> Database Driver Class Initialized
INFO - 2023-09-25 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:58:15 --> Controller Class Initialized
DEBUG - 2023-09-25 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 13:58:15 --> Final output sent to browser
DEBUG - 2023-09-25 13:58:15 --> Total execution time: 0.0648
INFO - 2023-09-25 13:59:52 --> Config Class Initialized
INFO - 2023-09-25 13:59:52 --> Hooks Class Initialized
DEBUG - 2023-09-25 13:59:52 --> UTF-8 Support Enabled
INFO - 2023-09-25 13:59:52 --> Utf8 Class Initialized
INFO - 2023-09-25 13:59:52 --> URI Class Initialized
INFO - 2023-09-25 13:59:52 --> Router Class Initialized
INFO - 2023-09-25 13:59:52 --> Output Class Initialized
INFO - 2023-09-25 13:59:52 --> Security Class Initialized
DEBUG - 2023-09-25 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 13:59:52 --> Input Class Initialized
INFO - 2023-09-25 13:59:52 --> Language Class Initialized
INFO - 2023-09-25 13:59:52 --> Language Class Initialized
INFO - 2023-09-25 13:59:52 --> Config Class Initialized
INFO - 2023-09-25 13:59:52 --> Loader Class Initialized
INFO - 2023-09-25 13:59:52 --> Helper loaded: url_helper
INFO - 2023-09-25 13:59:52 --> Helper loaded: file_helper
INFO - 2023-09-25 13:59:52 --> Helper loaded: form_helper
INFO - 2023-09-25 13:59:52 --> Helper loaded: my_helper
INFO - 2023-09-25 13:59:52 --> Database Driver Class Initialized
INFO - 2023-09-25 13:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 13:59:52 --> Controller Class Initialized
DEBUG - 2023-09-25 13:59:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 13:59:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 13:59:52 --> Final output sent to browser
DEBUG - 2023-09-25 13:59:52 --> Total execution time: 0.2387
INFO - 2023-09-25 14:01:09 --> Config Class Initialized
INFO - 2023-09-25 14:01:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:09 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:09 --> URI Class Initialized
INFO - 2023-09-25 14:01:09 --> Router Class Initialized
INFO - 2023-09-25 14:01:09 --> Output Class Initialized
INFO - 2023-09-25 14:01:09 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:09 --> Input Class Initialized
INFO - 2023-09-25 14:01:09 --> Language Class Initialized
INFO - 2023-09-25 14:01:09 --> Language Class Initialized
INFO - 2023-09-25 14:01:09 --> Config Class Initialized
INFO - 2023-09-25 14:01:09 --> Loader Class Initialized
INFO - 2023-09-25 14:01:09 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:09 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:09 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:09 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:09 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:09 --> Controller Class Initialized
DEBUG - 2023-09-25 14:01:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 14:01:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:01:09 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:09 --> Total execution time: 0.1160
INFO - 2023-09-25 14:01:15 --> Config Class Initialized
INFO - 2023-09-25 14:01:15 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:15 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:15 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:15 --> URI Class Initialized
INFO - 2023-09-25 14:01:15 --> Router Class Initialized
INFO - 2023-09-25 14:01:15 --> Output Class Initialized
INFO - 2023-09-25 14:01:15 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:15 --> Input Class Initialized
INFO - 2023-09-25 14:01:15 --> Language Class Initialized
INFO - 2023-09-25 14:01:15 --> Language Class Initialized
INFO - 2023-09-25 14:01:15 --> Config Class Initialized
INFO - 2023-09-25 14:01:15 --> Loader Class Initialized
INFO - 2023-09-25 14:01:15 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:15 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:15 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:15 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:15 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:15 --> Controller Class Initialized
INFO - 2023-09-25 14:01:15 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:15 --> Total execution time: 0.0636
INFO - 2023-09-25 14:01:24 --> Config Class Initialized
INFO - 2023-09-25 14:01:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:24 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:24 --> URI Class Initialized
INFO - 2023-09-25 14:01:24 --> Router Class Initialized
INFO - 2023-09-25 14:01:24 --> Output Class Initialized
INFO - 2023-09-25 14:01:24 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:24 --> Input Class Initialized
INFO - 2023-09-25 14:01:24 --> Language Class Initialized
INFO - 2023-09-25 14:01:24 --> Language Class Initialized
INFO - 2023-09-25 14:01:24 --> Config Class Initialized
INFO - 2023-09-25 14:01:24 --> Loader Class Initialized
INFO - 2023-09-25 14:01:24 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:24 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:24 --> Controller Class Initialized
INFO - 2023-09-25 14:01:24 --> Helper loaded: cookie_helper
INFO - 2023-09-25 14:01:24 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:24 --> Total execution time: 0.2679
INFO - 2023-09-25 14:01:24 --> Config Class Initialized
INFO - 2023-09-25 14:01:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:24 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:24 --> URI Class Initialized
INFO - 2023-09-25 14:01:24 --> Router Class Initialized
INFO - 2023-09-25 14:01:24 --> Output Class Initialized
INFO - 2023-09-25 14:01:24 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:24 --> Input Class Initialized
INFO - 2023-09-25 14:01:24 --> Language Class Initialized
INFO - 2023-09-25 14:01:24 --> Language Class Initialized
INFO - 2023-09-25 14:01:24 --> Config Class Initialized
INFO - 2023-09-25 14:01:24 --> Loader Class Initialized
INFO - 2023-09-25 14:01:24 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:24 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:24 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:24 --> Controller Class Initialized
DEBUG - 2023-09-25 14:01:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 14:01:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:01:24 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:24 --> Total execution time: 0.0405
INFO - 2023-09-25 14:01:31 --> Config Class Initialized
INFO - 2023-09-25 14:01:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:31 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:31 --> URI Class Initialized
INFO - 2023-09-25 14:01:31 --> Router Class Initialized
INFO - 2023-09-25 14:01:31 --> Output Class Initialized
INFO - 2023-09-25 14:01:31 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:31 --> Input Class Initialized
INFO - 2023-09-25 14:01:31 --> Language Class Initialized
INFO - 2023-09-25 14:01:31 --> Language Class Initialized
INFO - 2023-09-25 14:01:31 --> Config Class Initialized
INFO - 2023-09-25 14:01:31 --> Loader Class Initialized
INFO - 2023-09-25 14:01:31 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:31 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:31 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:31 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:31 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:31 --> Controller Class Initialized
DEBUG - 2023-09-25 14:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 14:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:01:31 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:31 --> Total execution time: 0.0431
INFO - 2023-09-25 14:01:38 --> Config Class Initialized
INFO - 2023-09-25 14:01:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:38 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:38 --> URI Class Initialized
INFO - 2023-09-25 14:01:38 --> Router Class Initialized
INFO - 2023-09-25 14:01:38 --> Output Class Initialized
INFO - 2023-09-25 14:01:38 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:38 --> Input Class Initialized
INFO - 2023-09-25 14:01:38 --> Language Class Initialized
INFO - 2023-09-25 14:01:38 --> Language Class Initialized
INFO - 2023-09-25 14:01:38 --> Config Class Initialized
INFO - 2023-09-25 14:01:38 --> Loader Class Initialized
INFO - 2023-09-25 14:01:38 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:38 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:38 --> Controller Class Initialized
DEBUG - 2023-09-25 14:01:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 14:01:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:01:38 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:38 --> Total execution time: 0.0526
INFO - 2023-09-25 14:01:38 --> Config Class Initialized
INFO - 2023-09-25 14:01:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:38 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:38 --> URI Class Initialized
INFO - 2023-09-25 14:01:38 --> Router Class Initialized
INFO - 2023-09-25 14:01:38 --> Output Class Initialized
INFO - 2023-09-25 14:01:38 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:38 --> Input Class Initialized
INFO - 2023-09-25 14:01:38 --> Language Class Initialized
INFO - 2023-09-25 14:01:38 --> Language Class Initialized
INFO - 2023-09-25 14:01:38 --> Config Class Initialized
INFO - 2023-09-25 14:01:38 --> Loader Class Initialized
INFO - 2023-09-25 14:01:38 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:38 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:38 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:38 --> Controller Class Initialized
INFO - 2023-09-25 14:01:44 --> Config Class Initialized
INFO - 2023-09-25 14:01:44 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:01:44 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:01:44 --> Utf8 Class Initialized
INFO - 2023-09-25 14:01:44 --> URI Class Initialized
INFO - 2023-09-25 14:01:44 --> Router Class Initialized
INFO - 2023-09-25 14:01:44 --> Output Class Initialized
INFO - 2023-09-25 14:01:44 --> Security Class Initialized
DEBUG - 2023-09-25 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:01:44 --> Input Class Initialized
INFO - 2023-09-25 14:01:44 --> Language Class Initialized
INFO - 2023-09-25 14:01:44 --> Language Class Initialized
INFO - 2023-09-25 14:01:44 --> Config Class Initialized
INFO - 2023-09-25 14:01:44 --> Loader Class Initialized
INFO - 2023-09-25 14:01:44 --> Helper loaded: url_helper
INFO - 2023-09-25 14:01:44 --> Helper loaded: file_helper
INFO - 2023-09-25 14:01:44 --> Helper loaded: form_helper
INFO - 2023-09-25 14:01:44 --> Helper loaded: my_helper
INFO - 2023-09-25 14:01:44 --> Database Driver Class Initialized
INFO - 2023-09-25 14:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:01:44 --> Controller Class Initialized
INFO - 2023-09-25 14:01:44 --> Final output sent to browser
DEBUG - 2023-09-25 14:01:44 --> Total execution time: 0.1610
INFO - 2023-09-25 14:03:35 --> Config Class Initialized
INFO - 2023-09-25 14:03:35 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:03:35 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:03:35 --> Utf8 Class Initialized
INFO - 2023-09-25 14:03:35 --> URI Class Initialized
INFO - 2023-09-25 14:03:35 --> Router Class Initialized
INFO - 2023-09-25 14:03:35 --> Output Class Initialized
INFO - 2023-09-25 14:03:35 --> Security Class Initialized
DEBUG - 2023-09-25 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:03:35 --> Input Class Initialized
INFO - 2023-09-25 14:03:35 --> Language Class Initialized
INFO - 2023-09-25 14:03:35 --> Language Class Initialized
INFO - 2023-09-25 14:03:35 --> Config Class Initialized
INFO - 2023-09-25 14:03:35 --> Loader Class Initialized
INFO - 2023-09-25 14:03:35 --> Helper loaded: url_helper
INFO - 2023-09-25 14:03:35 --> Helper loaded: file_helper
INFO - 2023-09-25 14:03:35 --> Helper loaded: form_helper
INFO - 2023-09-25 14:03:35 --> Helper loaded: my_helper
INFO - 2023-09-25 14:03:35 --> Database Driver Class Initialized
INFO - 2023-09-25 14:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:03:35 --> Controller Class Initialized
DEBUG - 2023-09-25 14:03:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-25 14:03:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:03:35 --> Final output sent to browser
DEBUG - 2023-09-25 14:03:35 --> Total execution time: 0.0511
INFO - 2023-09-25 14:27:59 --> Config Class Initialized
INFO - 2023-09-25 14:27:59 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:27:59 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:27:59 --> Utf8 Class Initialized
INFO - 2023-09-25 14:27:59 --> URI Class Initialized
INFO - 2023-09-25 14:27:59 --> Router Class Initialized
INFO - 2023-09-25 14:27:59 --> Output Class Initialized
INFO - 2023-09-25 14:27:59 --> Security Class Initialized
DEBUG - 2023-09-25 14:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:27:59 --> Input Class Initialized
INFO - 2023-09-25 14:27:59 --> Language Class Initialized
INFO - 2023-09-25 14:27:59 --> Language Class Initialized
INFO - 2023-09-25 14:27:59 --> Config Class Initialized
INFO - 2023-09-25 14:27:59 --> Loader Class Initialized
INFO - 2023-09-25 14:27:59 --> Helper loaded: url_helper
INFO - 2023-09-25 14:27:59 --> Helper loaded: file_helper
INFO - 2023-09-25 14:27:59 --> Helper loaded: form_helper
INFO - 2023-09-25 14:27:59 --> Helper loaded: my_helper
INFO - 2023-09-25 14:27:59 --> Database Driver Class Initialized
INFO - 2023-09-25 14:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:27:59 --> Controller Class Initialized
DEBUG - 2023-09-25 14:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 14:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:27:59 --> Final output sent to browser
DEBUG - 2023-09-25 14:27:59 --> Total execution time: 0.0798
INFO - 2023-09-25 14:28:02 --> Config Class Initialized
INFO - 2023-09-25 14:28:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:28:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:28:02 --> Utf8 Class Initialized
INFO - 2023-09-25 14:28:02 --> URI Class Initialized
INFO - 2023-09-25 14:28:02 --> Router Class Initialized
INFO - 2023-09-25 14:28:02 --> Output Class Initialized
INFO - 2023-09-25 14:28:02 --> Security Class Initialized
DEBUG - 2023-09-25 14:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:28:02 --> Input Class Initialized
INFO - 2023-09-25 14:28:02 --> Language Class Initialized
INFO - 2023-09-25 14:28:02 --> Language Class Initialized
INFO - 2023-09-25 14:28:02 --> Config Class Initialized
INFO - 2023-09-25 14:28:02 --> Loader Class Initialized
INFO - 2023-09-25 14:28:02 --> Helper loaded: url_helper
INFO - 2023-09-25 14:28:02 --> Helper loaded: file_helper
INFO - 2023-09-25 14:28:02 --> Helper loaded: form_helper
INFO - 2023-09-25 14:28:02 --> Helper loaded: my_helper
INFO - 2023-09-25 14:28:02 --> Database Driver Class Initialized
INFO - 2023-09-25 14:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:28:02 --> Controller Class Initialized
INFO - 2023-09-25 14:38:30 --> Config Class Initialized
INFO - 2023-09-25 14:38:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:31 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:31 --> URI Class Initialized
INFO - 2023-09-25 14:38:31 --> Router Class Initialized
INFO - 2023-09-25 14:38:31 --> Output Class Initialized
INFO - 2023-09-25 14:38:31 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:31 --> Input Class Initialized
INFO - 2023-09-25 14:38:31 --> Language Class Initialized
INFO - 2023-09-25 14:38:31 --> Language Class Initialized
INFO - 2023-09-25 14:38:31 --> Config Class Initialized
INFO - 2023-09-25 14:38:31 --> Loader Class Initialized
INFO - 2023-09-25 14:38:31 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:31 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:31 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:31 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:31 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:31 --> Controller Class Initialized
DEBUG - 2023-09-25 14:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-09-25 14:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:38:31 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:31 --> Total execution time: 0.4457
INFO - 2023-09-25 14:38:39 --> Config Class Initialized
INFO - 2023-09-25 14:38:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:39 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:39 --> URI Class Initialized
INFO - 2023-09-25 14:38:39 --> Router Class Initialized
INFO - 2023-09-25 14:38:39 --> Output Class Initialized
INFO - 2023-09-25 14:38:39 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:39 --> Input Class Initialized
INFO - 2023-09-25 14:38:39 --> Language Class Initialized
INFO - 2023-09-25 14:38:39 --> Language Class Initialized
INFO - 2023-09-25 14:38:39 --> Config Class Initialized
INFO - 2023-09-25 14:38:39 --> Loader Class Initialized
INFO - 2023-09-25 14:38:39 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:39 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:39 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:39 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:39 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:39 --> Controller Class Initialized
INFO - 2023-09-25 14:38:39 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:39 --> Total execution time: 0.0392
INFO - 2023-09-25 14:38:41 --> Config Class Initialized
INFO - 2023-09-25 14:38:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:41 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:41 --> URI Class Initialized
INFO - 2023-09-25 14:38:41 --> Router Class Initialized
INFO - 2023-09-25 14:38:41 --> Output Class Initialized
INFO - 2023-09-25 14:38:41 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:41 --> Input Class Initialized
INFO - 2023-09-25 14:38:41 --> Language Class Initialized
INFO - 2023-09-25 14:38:41 --> Language Class Initialized
INFO - 2023-09-25 14:38:41 --> Config Class Initialized
INFO - 2023-09-25 14:38:41 --> Loader Class Initialized
INFO - 2023-09-25 14:38:41 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:41 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:41 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:41 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:41 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:41 --> Controller Class Initialized
INFO - 2023-09-25 14:38:41 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:41 --> Total execution time: 0.0401
INFO - 2023-09-25 14:38:42 --> Config Class Initialized
INFO - 2023-09-25 14:38:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:42 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:42 --> URI Class Initialized
INFO - 2023-09-25 14:38:42 --> Router Class Initialized
INFO - 2023-09-25 14:38:42 --> Output Class Initialized
INFO - 2023-09-25 14:38:42 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:42 --> Input Class Initialized
INFO - 2023-09-25 14:38:42 --> Language Class Initialized
INFO - 2023-09-25 14:38:42 --> Language Class Initialized
INFO - 2023-09-25 14:38:42 --> Config Class Initialized
INFO - 2023-09-25 14:38:42 --> Loader Class Initialized
INFO - 2023-09-25 14:38:42 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:42 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:42 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:42 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:42 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:42 --> Controller Class Initialized
INFO - 2023-09-25 14:38:42 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:42 --> Total execution time: 0.0340
INFO - 2023-09-25 14:38:43 --> Config Class Initialized
INFO - 2023-09-25 14:38:43 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:43 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:43 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:43 --> URI Class Initialized
INFO - 2023-09-25 14:38:43 --> Router Class Initialized
INFO - 2023-09-25 14:38:43 --> Output Class Initialized
INFO - 2023-09-25 14:38:43 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:43 --> Input Class Initialized
INFO - 2023-09-25 14:38:43 --> Language Class Initialized
INFO - 2023-09-25 14:38:43 --> Language Class Initialized
INFO - 2023-09-25 14:38:43 --> Config Class Initialized
INFO - 2023-09-25 14:38:43 --> Loader Class Initialized
INFO - 2023-09-25 14:38:43 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:43 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:43 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:43 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:43 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:43 --> Controller Class Initialized
INFO - 2023-09-25 14:38:43 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:43 --> Total execution time: 0.0662
INFO - 2023-09-25 14:38:44 --> Config Class Initialized
INFO - 2023-09-25 14:38:44 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:44 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:44 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:44 --> URI Class Initialized
INFO - 2023-09-25 14:38:44 --> Router Class Initialized
INFO - 2023-09-25 14:38:44 --> Output Class Initialized
INFO - 2023-09-25 14:38:44 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:44 --> Input Class Initialized
INFO - 2023-09-25 14:38:44 --> Language Class Initialized
INFO - 2023-09-25 14:38:44 --> Language Class Initialized
INFO - 2023-09-25 14:38:44 --> Config Class Initialized
INFO - 2023-09-25 14:38:44 --> Loader Class Initialized
INFO - 2023-09-25 14:38:44 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:44 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:44 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:44 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:44 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:44 --> Controller Class Initialized
INFO - 2023-09-25 14:38:44 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:44 --> Total execution time: 0.0737
INFO - 2023-09-25 14:38:45 --> Config Class Initialized
INFO - 2023-09-25 14:38:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:45 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:45 --> URI Class Initialized
INFO - 2023-09-25 14:38:45 --> Router Class Initialized
INFO - 2023-09-25 14:38:45 --> Output Class Initialized
INFO - 2023-09-25 14:38:45 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:45 --> Input Class Initialized
INFO - 2023-09-25 14:38:45 --> Language Class Initialized
INFO - 2023-09-25 14:38:45 --> Language Class Initialized
INFO - 2023-09-25 14:38:45 --> Config Class Initialized
INFO - 2023-09-25 14:38:45 --> Loader Class Initialized
INFO - 2023-09-25 14:38:45 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:45 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:45 --> Controller Class Initialized
INFO - 2023-09-25 14:38:45 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:45 --> Total execution time: 0.1091
INFO - 2023-09-25 14:38:45 --> Config Class Initialized
INFO - 2023-09-25 14:38:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:45 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:45 --> URI Class Initialized
INFO - 2023-09-25 14:38:45 --> Router Class Initialized
INFO - 2023-09-25 14:38:45 --> Output Class Initialized
INFO - 2023-09-25 14:38:45 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:45 --> Input Class Initialized
INFO - 2023-09-25 14:38:45 --> Language Class Initialized
INFO - 2023-09-25 14:38:45 --> Language Class Initialized
INFO - 2023-09-25 14:38:45 --> Config Class Initialized
INFO - 2023-09-25 14:38:45 --> Loader Class Initialized
INFO - 2023-09-25 14:38:45 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:45 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:45 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:45 --> Controller Class Initialized
INFO - 2023-09-25 14:38:45 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:45 --> Total execution time: 0.1183
INFO - 2023-09-25 14:38:46 --> Config Class Initialized
INFO - 2023-09-25 14:38:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:46 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:46 --> URI Class Initialized
INFO - 2023-09-25 14:38:46 --> Router Class Initialized
INFO - 2023-09-25 14:38:46 --> Output Class Initialized
INFO - 2023-09-25 14:38:46 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:46 --> Input Class Initialized
INFO - 2023-09-25 14:38:46 --> Language Class Initialized
INFO - 2023-09-25 14:38:46 --> Language Class Initialized
INFO - 2023-09-25 14:38:46 --> Config Class Initialized
INFO - 2023-09-25 14:38:46 --> Loader Class Initialized
INFO - 2023-09-25 14:38:46 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:46 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:46 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:46 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:46 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:46 --> Controller Class Initialized
INFO - 2023-09-25 14:38:46 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:46 --> Total execution time: 0.0772
INFO - 2023-09-25 14:38:49 --> Config Class Initialized
INFO - 2023-09-25 14:38:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:49 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:49 --> URI Class Initialized
INFO - 2023-09-25 14:38:49 --> Router Class Initialized
INFO - 2023-09-25 14:38:49 --> Output Class Initialized
INFO - 2023-09-25 14:38:49 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:49 --> Input Class Initialized
INFO - 2023-09-25 14:38:49 --> Language Class Initialized
INFO - 2023-09-25 14:38:49 --> Language Class Initialized
INFO - 2023-09-25 14:38:49 --> Config Class Initialized
INFO - 2023-09-25 14:38:49 --> Loader Class Initialized
INFO - 2023-09-25 14:38:49 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:49 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:49 --> Controller Class Initialized
DEBUG - 2023-09-25 14:38:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 14:38:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 14:38:49 --> Final output sent to browser
DEBUG - 2023-09-25 14:38:49 --> Total execution time: 0.0905
INFO - 2023-09-25 14:38:49 --> Config Class Initialized
INFO - 2023-09-25 14:38:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 14:38:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 14:38:49 --> Utf8 Class Initialized
INFO - 2023-09-25 14:38:49 --> URI Class Initialized
INFO - 2023-09-25 14:38:49 --> Router Class Initialized
INFO - 2023-09-25 14:38:49 --> Output Class Initialized
INFO - 2023-09-25 14:38:49 --> Security Class Initialized
DEBUG - 2023-09-25 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 14:38:49 --> Input Class Initialized
INFO - 2023-09-25 14:38:49 --> Language Class Initialized
INFO - 2023-09-25 14:38:49 --> Language Class Initialized
INFO - 2023-09-25 14:38:49 --> Config Class Initialized
INFO - 2023-09-25 14:38:49 --> Loader Class Initialized
INFO - 2023-09-25 14:38:49 --> Helper loaded: url_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: file_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: form_helper
INFO - 2023-09-25 14:38:49 --> Helper loaded: my_helper
INFO - 2023-09-25 14:38:49 --> Database Driver Class Initialized
INFO - 2023-09-25 14:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 14:38:49 --> Controller Class Initialized
INFO - 2023-09-25 15:00:32 --> Config Class Initialized
INFO - 2023-09-25 15:00:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 15:00:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 15:00:32 --> Utf8 Class Initialized
INFO - 2023-09-25 15:00:32 --> URI Class Initialized
INFO - 2023-09-25 15:00:32 --> Router Class Initialized
INFO - 2023-09-25 15:00:32 --> Output Class Initialized
INFO - 2023-09-25 15:00:32 --> Security Class Initialized
DEBUG - 2023-09-25 15:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 15:00:32 --> Input Class Initialized
INFO - 2023-09-25 15:00:32 --> Language Class Initialized
INFO - 2023-09-25 15:00:32 --> Language Class Initialized
INFO - 2023-09-25 15:00:32 --> Config Class Initialized
INFO - 2023-09-25 15:00:32 --> Loader Class Initialized
INFO - 2023-09-25 15:00:32 --> Helper loaded: url_helper
INFO - 2023-09-25 15:00:32 --> Helper loaded: file_helper
INFO - 2023-09-25 15:00:32 --> Helper loaded: form_helper
INFO - 2023-09-25 15:00:32 --> Helper loaded: my_helper
INFO - 2023-09-25 15:00:32 --> Database Driver Class Initialized
INFO - 2023-09-25 15:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 15:00:32 --> Controller Class Initialized
DEBUG - 2023-09-25 15:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-25 15:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 15:00:32 --> Final output sent to browser
DEBUG - 2023-09-25 15:00:32 --> Total execution time: 0.2598
INFO - 2023-09-25 20:41:20 --> Config Class Initialized
INFO - 2023-09-25 20:41:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:20 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:20 --> URI Class Initialized
INFO - 2023-09-25 20:41:20 --> Router Class Initialized
INFO - 2023-09-25 20:41:20 --> Output Class Initialized
INFO - 2023-09-25 20:41:20 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:20 --> Input Class Initialized
INFO - 2023-09-25 20:41:20 --> Language Class Initialized
INFO - 2023-09-25 20:41:20 --> Language Class Initialized
INFO - 2023-09-25 20:41:20 --> Config Class Initialized
INFO - 2023-09-25 20:41:20 --> Loader Class Initialized
INFO - 2023-09-25 20:41:20 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:20 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:20 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:20 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:20 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:20 --> Controller Class Initialized
INFO - 2023-09-25 20:41:21 --> Config Class Initialized
INFO - 2023-09-25 20:41:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:21 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:21 --> URI Class Initialized
INFO - 2023-09-25 20:41:21 --> Router Class Initialized
INFO - 2023-09-25 20:41:21 --> Output Class Initialized
INFO - 2023-09-25 20:41:21 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:21 --> Input Class Initialized
INFO - 2023-09-25 20:41:21 --> Language Class Initialized
INFO - 2023-09-25 20:41:21 --> Language Class Initialized
INFO - 2023-09-25 20:41:21 --> Config Class Initialized
INFO - 2023-09-25 20:41:21 --> Loader Class Initialized
INFO - 2023-09-25 20:41:21 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:21 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:21 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:21 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:21 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:21 --> Controller Class Initialized
DEBUG - 2023-09-25 20:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 20:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:41:21 --> Final output sent to browser
DEBUG - 2023-09-25 20:41:21 --> Total execution time: 0.0432
INFO - 2023-09-25 20:41:28 --> Config Class Initialized
INFO - 2023-09-25 20:41:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:28 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:28 --> URI Class Initialized
INFO - 2023-09-25 20:41:28 --> Router Class Initialized
INFO - 2023-09-25 20:41:28 --> Output Class Initialized
INFO - 2023-09-25 20:41:28 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:28 --> Input Class Initialized
INFO - 2023-09-25 20:41:28 --> Language Class Initialized
INFO - 2023-09-25 20:41:28 --> Language Class Initialized
INFO - 2023-09-25 20:41:28 --> Config Class Initialized
INFO - 2023-09-25 20:41:28 --> Loader Class Initialized
INFO - 2023-09-25 20:41:28 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:28 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:28 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:28 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:28 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:28 --> Controller Class Initialized
INFO - 2023-09-25 20:41:28 --> Helper loaded: cookie_helper
INFO - 2023-09-25 20:41:28 --> Final output sent to browser
DEBUG - 2023-09-25 20:41:28 --> Total execution time: 0.1150
INFO - 2023-09-25 20:41:29 --> Config Class Initialized
INFO - 2023-09-25 20:41:29 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:29 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:29 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:29 --> URI Class Initialized
INFO - 2023-09-25 20:41:29 --> Router Class Initialized
INFO - 2023-09-25 20:41:29 --> Output Class Initialized
INFO - 2023-09-25 20:41:29 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:29 --> Input Class Initialized
INFO - 2023-09-25 20:41:29 --> Language Class Initialized
INFO - 2023-09-25 20:41:29 --> Language Class Initialized
INFO - 2023-09-25 20:41:29 --> Config Class Initialized
INFO - 2023-09-25 20:41:29 --> Loader Class Initialized
INFO - 2023-09-25 20:41:29 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:29 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:29 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:29 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:29 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:29 --> Controller Class Initialized
DEBUG - 2023-09-25 20:41:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:41:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:41:29 --> Final output sent to browser
DEBUG - 2023-09-25 20:41:29 --> Total execution time: 0.0468
INFO - 2023-09-25 20:41:36 --> Config Class Initialized
INFO - 2023-09-25 20:41:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:36 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:36 --> URI Class Initialized
INFO - 2023-09-25 20:41:36 --> Router Class Initialized
INFO - 2023-09-25 20:41:36 --> Output Class Initialized
INFO - 2023-09-25 20:41:36 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:36 --> Input Class Initialized
INFO - 2023-09-25 20:41:36 --> Language Class Initialized
INFO - 2023-09-25 20:41:36 --> Language Class Initialized
INFO - 2023-09-25 20:41:36 --> Config Class Initialized
INFO - 2023-09-25 20:41:36 --> Loader Class Initialized
INFO - 2023-09-25 20:41:36 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:36 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:36 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:36 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:36 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:36 --> Controller Class Initialized
DEBUG - 2023-09-25 20:41:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 20:41:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:41:36 --> Final output sent to browser
DEBUG - 2023-09-25 20:41:36 --> Total execution time: 0.0954
INFO - 2023-09-25 20:41:40 --> Config Class Initialized
INFO - 2023-09-25 20:41:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:40 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:40 --> URI Class Initialized
INFO - 2023-09-25 20:41:40 --> Router Class Initialized
INFO - 2023-09-25 20:41:40 --> Output Class Initialized
INFO - 2023-09-25 20:41:40 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:40 --> Input Class Initialized
INFO - 2023-09-25 20:41:40 --> Language Class Initialized
INFO - 2023-09-25 20:41:40 --> Language Class Initialized
INFO - 2023-09-25 20:41:40 --> Config Class Initialized
INFO - 2023-09-25 20:41:40 --> Loader Class Initialized
INFO - 2023-09-25 20:41:40 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:40 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:40 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:40 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:41 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:41 --> Controller Class Initialized
DEBUG - 2023-09-25 20:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:41:41 --> Final output sent to browser
DEBUG - 2023-09-25 20:41:41 --> Total execution time: 0.1566
INFO - 2023-09-25 20:41:41 --> Config Class Initialized
INFO - 2023-09-25 20:41:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:41:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:41:41 --> Utf8 Class Initialized
INFO - 2023-09-25 20:41:41 --> URI Class Initialized
INFO - 2023-09-25 20:41:41 --> Router Class Initialized
INFO - 2023-09-25 20:41:41 --> Output Class Initialized
INFO - 2023-09-25 20:41:41 --> Security Class Initialized
DEBUG - 2023-09-25 20:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:41:41 --> Input Class Initialized
INFO - 2023-09-25 20:41:41 --> Language Class Initialized
INFO - 2023-09-25 20:41:41 --> Language Class Initialized
INFO - 2023-09-25 20:41:41 --> Config Class Initialized
INFO - 2023-09-25 20:41:41 --> Loader Class Initialized
INFO - 2023-09-25 20:41:41 --> Helper loaded: url_helper
INFO - 2023-09-25 20:41:41 --> Helper loaded: file_helper
INFO - 2023-09-25 20:41:41 --> Helper loaded: form_helper
INFO - 2023-09-25 20:41:41 --> Helper loaded: my_helper
INFO - 2023-09-25 20:41:41 --> Database Driver Class Initialized
INFO - 2023-09-25 20:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:41:41 --> Controller Class Initialized
INFO - 2023-09-25 20:45:05 --> Config Class Initialized
INFO - 2023-09-25 20:45:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:45:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:45:05 --> Utf8 Class Initialized
INFO - 2023-09-25 20:45:05 --> URI Class Initialized
INFO - 2023-09-25 20:45:05 --> Router Class Initialized
INFO - 2023-09-25 20:45:05 --> Output Class Initialized
INFO - 2023-09-25 20:45:05 --> Security Class Initialized
DEBUG - 2023-09-25 20:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:45:05 --> Input Class Initialized
INFO - 2023-09-25 20:45:05 --> Language Class Initialized
INFO - 2023-09-25 20:45:05 --> Language Class Initialized
INFO - 2023-09-25 20:45:05 --> Config Class Initialized
INFO - 2023-09-25 20:45:05 --> Loader Class Initialized
INFO - 2023-09-25 20:45:05 --> Helper loaded: url_helper
INFO - 2023-09-25 20:45:05 --> Helper loaded: file_helper
INFO - 2023-09-25 20:45:05 --> Helper loaded: form_helper
INFO - 2023-09-25 20:45:05 --> Helper loaded: my_helper
INFO - 2023-09-25 20:45:05 --> Database Driver Class Initialized
INFO - 2023-09-25 20:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:45:05 --> Controller Class Initialized
INFO - 2023-09-25 20:45:05 --> Final output sent to browser
DEBUG - 2023-09-25 20:45:05 --> Total execution time: 0.0500
INFO - 2023-09-25 20:45:06 --> Config Class Initialized
INFO - 2023-09-25 20:45:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:45:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:45:06 --> Utf8 Class Initialized
INFO - 2023-09-25 20:45:06 --> URI Class Initialized
INFO - 2023-09-25 20:45:06 --> Router Class Initialized
INFO - 2023-09-25 20:45:06 --> Output Class Initialized
INFO - 2023-09-25 20:45:06 --> Security Class Initialized
DEBUG - 2023-09-25 20:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:45:06 --> Input Class Initialized
INFO - 2023-09-25 20:45:06 --> Language Class Initialized
INFO - 2023-09-25 20:45:06 --> Language Class Initialized
INFO - 2023-09-25 20:45:06 --> Config Class Initialized
INFO - 2023-09-25 20:45:06 --> Loader Class Initialized
INFO - 2023-09-25 20:45:06 --> Helper loaded: url_helper
INFO - 2023-09-25 20:45:07 --> Helper loaded: file_helper
INFO - 2023-09-25 20:45:07 --> Helper loaded: form_helper
INFO - 2023-09-25 20:45:07 --> Helper loaded: my_helper
INFO - 2023-09-25 20:45:07 --> Database Driver Class Initialized
INFO - 2023-09-25 20:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:45:07 --> Controller Class Initialized
INFO - 2023-09-25 20:45:07 --> Final output sent to browser
DEBUG - 2023-09-25 20:45:07 --> Total execution time: 0.0774
INFO - 2023-09-25 20:45:36 --> Config Class Initialized
INFO - 2023-09-25 20:45:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:45:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:45:36 --> Utf8 Class Initialized
INFO - 2023-09-25 20:45:36 --> URI Class Initialized
INFO - 2023-09-25 20:45:36 --> Router Class Initialized
INFO - 2023-09-25 20:45:36 --> Output Class Initialized
INFO - 2023-09-25 20:45:36 --> Security Class Initialized
DEBUG - 2023-09-25 20:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:45:36 --> Input Class Initialized
INFO - 2023-09-25 20:45:36 --> Language Class Initialized
INFO - 2023-09-25 20:45:36 --> Language Class Initialized
INFO - 2023-09-25 20:45:36 --> Config Class Initialized
INFO - 2023-09-25 20:45:36 --> Loader Class Initialized
INFO - 2023-09-25 20:45:36 --> Helper loaded: url_helper
INFO - 2023-09-25 20:45:36 --> Helper loaded: file_helper
INFO - 2023-09-25 20:45:36 --> Helper loaded: form_helper
INFO - 2023-09-25 20:45:36 --> Helper loaded: my_helper
INFO - 2023-09-25 20:45:36 --> Database Driver Class Initialized
INFO - 2023-09-25 20:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:45:36 --> Controller Class Initialized
INFO - 2023-09-25 20:45:36 --> Final output sent to browser
DEBUG - 2023-09-25 20:45:36 --> Total execution time: 0.1167
INFO - 2023-09-25 20:45:37 --> Config Class Initialized
INFO - 2023-09-25 20:45:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:45:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:45:37 --> Utf8 Class Initialized
INFO - 2023-09-25 20:45:37 --> URI Class Initialized
INFO - 2023-09-25 20:45:37 --> Router Class Initialized
INFO - 2023-09-25 20:45:37 --> Output Class Initialized
INFO - 2023-09-25 20:45:37 --> Security Class Initialized
DEBUG - 2023-09-25 20:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:45:37 --> Input Class Initialized
INFO - 2023-09-25 20:45:37 --> Language Class Initialized
INFO - 2023-09-25 20:45:37 --> Language Class Initialized
INFO - 2023-09-25 20:45:37 --> Config Class Initialized
INFO - 2023-09-25 20:45:37 --> Loader Class Initialized
INFO - 2023-09-25 20:45:37 --> Helper loaded: url_helper
INFO - 2023-09-25 20:45:37 --> Helper loaded: file_helper
INFO - 2023-09-25 20:45:37 --> Helper loaded: form_helper
INFO - 2023-09-25 20:45:37 --> Helper loaded: my_helper
INFO - 2023-09-25 20:45:37 --> Database Driver Class Initialized
INFO - 2023-09-25 20:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:45:37 --> Controller Class Initialized
INFO - 2023-09-25 20:47:09 --> Config Class Initialized
INFO - 2023-09-25 20:47:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:09 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:09 --> URI Class Initialized
INFO - 2023-09-25 20:47:09 --> Router Class Initialized
INFO - 2023-09-25 20:47:09 --> Output Class Initialized
INFO - 2023-09-25 20:47:09 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:09 --> Input Class Initialized
INFO - 2023-09-25 20:47:09 --> Language Class Initialized
INFO - 2023-09-25 20:47:09 --> Language Class Initialized
INFO - 2023-09-25 20:47:09 --> Config Class Initialized
INFO - 2023-09-25 20:47:09 --> Loader Class Initialized
INFO - 2023-09-25 20:47:09 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:09 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:09 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:09 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:09 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:09 --> Controller Class Initialized
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:47:16 --> Config Class Initialized
INFO - 2023-09-25 20:47:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:16 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:16 --> URI Class Initialized
INFO - 2023-09-25 20:47:16 --> Router Class Initialized
INFO - 2023-09-25 20:47:16 --> Output Class Initialized
INFO - 2023-09-25 20:47:16 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:16 --> Input Class Initialized
INFO - 2023-09-25 20:47:16 --> Language Class Initialized
INFO - 2023-09-25 20:47:16 --> Language Class Initialized
INFO - 2023-09-25 20:47:16 --> Config Class Initialized
INFO - 2023-09-25 20:47:16 --> Loader Class Initialized
INFO - 2023-09-25 20:47:16 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:16 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:16 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:16 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:16 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:16 --> Controller Class Initialized
DEBUG - 2023-09-25 20:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:47:16 --> Final output sent to browser
DEBUG - 2023-09-25 20:47:16 --> Total execution time: 0.0341
INFO - 2023-09-25 20:47:17 --> Config Class Initialized
INFO - 2023-09-25 20:47:17 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:17 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:17 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:17 --> URI Class Initialized
INFO - 2023-09-25 20:47:17 --> Router Class Initialized
INFO - 2023-09-25 20:47:17 --> Output Class Initialized
INFO - 2023-09-25 20:47:17 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:17 --> Input Class Initialized
INFO - 2023-09-25 20:47:17 --> Language Class Initialized
INFO - 2023-09-25 20:47:17 --> Language Class Initialized
INFO - 2023-09-25 20:47:17 --> Config Class Initialized
INFO - 2023-09-25 20:47:17 --> Loader Class Initialized
INFO - 2023-09-25 20:47:17 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:17 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:17 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:17 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:17 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:17 --> Controller Class Initialized
INFO - 2023-09-25 20:47:25 --> Config Class Initialized
INFO - 2023-09-25 20:47:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:25 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:25 --> URI Class Initialized
INFO - 2023-09-25 20:47:25 --> Router Class Initialized
INFO - 2023-09-25 20:47:25 --> Output Class Initialized
INFO - 2023-09-25 20:47:25 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:25 --> Input Class Initialized
INFO - 2023-09-25 20:47:25 --> Language Class Initialized
INFO - 2023-09-25 20:47:25 --> Language Class Initialized
INFO - 2023-09-25 20:47:25 --> Config Class Initialized
INFO - 2023-09-25 20:47:25 --> Loader Class Initialized
INFO - 2023-09-25 20:47:25 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:25 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:25 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:25 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:25 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:25 --> Controller Class Initialized
INFO - 2023-09-25 20:47:25 --> Final output sent to browser
DEBUG - 2023-09-25 20:47:25 --> Total execution time: 0.0443
INFO - 2023-09-25 20:47:26 --> Config Class Initialized
INFO - 2023-09-25 20:47:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:26 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:26 --> URI Class Initialized
INFO - 2023-09-25 20:47:26 --> Router Class Initialized
INFO - 2023-09-25 20:47:26 --> Output Class Initialized
INFO - 2023-09-25 20:47:26 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:26 --> Input Class Initialized
INFO - 2023-09-25 20:47:26 --> Language Class Initialized
INFO - 2023-09-25 20:47:26 --> Language Class Initialized
INFO - 2023-09-25 20:47:26 --> Config Class Initialized
INFO - 2023-09-25 20:47:26 --> Loader Class Initialized
INFO - 2023-09-25 20:47:26 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:26 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:26 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:26 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:26 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:26 --> Controller Class Initialized
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:47:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:47:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:47:39 --> Config Class Initialized
INFO - 2023-09-25 20:47:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:39 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:39 --> URI Class Initialized
INFO - 2023-09-25 20:47:39 --> Router Class Initialized
INFO - 2023-09-25 20:47:39 --> Output Class Initialized
INFO - 2023-09-25 20:47:39 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:39 --> Input Class Initialized
INFO - 2023-09-25 20:47:39 --> Language Class Initialized
INFO - 2023-09-25 20:47:39 --> Language Class Initialized
INFO - 2023-09-25 20:47:39 --> Config Class Initialized
INFO - 2023-09-25 20:47:39 --> Loader Class Initialized
INFO - 2023-09-25 20:47:39 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:39 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:39 --> Controller Class Initialized
DEBUG - 2023-09-25 20:47:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:47:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:47:39 --> Final output sent to browser
DEBUG - 2023-09-25 20:47:39 --> Total execution time: 0.0704
INFO - 2023-09-25 20:47:39 --> Config Class Initialized
INFO - 2023-09-25 20:47:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:39 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:39 --> URI Class Initialized
INFO - 2023-09-25 20:47:39 --> Router Class Initialized
INFO - 2023-09-25 20:47:39 --> Output Class Initialized
INFO - 2023-09-25 20:47:39 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:39 --> Input Class Initialized
INFO - 2023-09-25 20:47:39 --> Language Class Initialized
INFO - 2023-09-25 20:47:39 --> Language Class Initialized
INFO - 2023-09-25 20:47:39 --> Config Class Initialized
INFO - 2023-09-25 20:47:39 --> Loader Class Initialized
INFO - 2023-09-25 20:47:39 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:39 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:39 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:39 --> Controller Class Initialized
INFO - 2023-09-25 20:47:51 --> Config Class Initialized
INFO - 2023-09-25 20:47:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:47:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:47:51 --> Utf8 Class Initialized
INFO - 2023-09-25 20:47:51 --> URI Class Initialized
INFO - 2023-09-25 20:47:51 --> Router Class Initialized
INFO - 2023-09-25 20:47:51 --> Output Class Initialized
INFO - 2023-09-25 20:47:51 --> Security Class Initialized
DEBUG - 2023-09-25 20:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:47:51 --> Input Class Initialized
INFO - 2023-09-25 20:47:51 --> Language Class Initialized
INFO - 2023-09-25 20:47:51 --> Language Class Initialized
INFO - 2023-09-25 20:47:51 --> Config Class Initialized
INFO - 2023-09-25 20:47:51 --> Loader Class Initialized
INFO - 2023-09-25 20:47:51 --> Helper loaded: url_helper
INFO - 2023-09-25 20:47:51 --> Helper loaded: file_helper
INFO - 2023-09-25 20:47:51 --> Helper loaded: form_helper
INFO - 2023-09-25 20:47:51 --> Helper loaded: my_helper
INFO - 2023-09-25 20:47:51 --> Database Driver Class Initialized
INFO - 2023-09-25 20:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:47:51 --> Controller Class Initialized
INFO - 2023-09-25 20:47:51 --> Final output sent to browser
DEBUG - 2023-09-25 20:47:51 --> Total execution time: 0.0744
INFO - 2023-09-25 20:48:02 --> Config Class Initialized
INFO - 2023-09-25 20:48:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:02 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:03 --> URI Class Initialized
INFO - 2023-09-25 20:48:03 --> Router Class Initialized
INFO - 2023-09-25 20:48:03 --> Output Class Initialized
INFO - 2023-09-25 20:48:03 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:03 --> Input Class Initialized
INFO - 2023-09-25 20:48:03 --> Language Class Initialized
INFO - 2023-09-25 20:48:03 --> Language Class Initialized
INFO - 2023-09-25 20:48:03 --> Config Class Initialized
INFO - 2023-09-25 20:48:03 --> Loader Class Initialized
INFO - 2023-09-25 20:48:03 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:03 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:03 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:03 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:03 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:03 --> Controller Class Initialized
INFO - 2023-09-25 20:48:03 --> Final output sent to browser
DEBUG - 2023-09-25 20:48:03 --> Total execution time: 0.0617
INFO - 2023-09-25 20:48:38 --> Config Class Initialized
INFO - 2023-09-25 20:48:38 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:38 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:38 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:38 --> URI Class Initialized
INFO - 2023-09-25 20:48:38 --> Router Class Initialized
INFO - 2023-09-25 20:48:38 --> Output Class Initialized
INFO - 2023-09-25 20:48:38 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:38 --> Input Class Initialized
INFO - 2023-09-25 20:48:38 --> Language Class Initialized
INFO - 2023-09-25 20:48:38 --> Language Class Initialized
INFO - 2023-09-25 20:48:38 --> Config Class Initialized
INFO - 2023-09-25 20:48:38 --> Loader Class Initialized
INFO - 2023-09-25 20:48:38 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:38 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:38 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:38 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:38 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:38 --> Controller Class Initialized
INFO - 2023-09-25 20:48:38 --> Final output sent to browser
DEBUG - 2023-09-25 20:48:38 --> Total execution time: 0.0382
INFO - 2023-09-25 20:48:39 --> Config Class Initialized
INFO - 2023-09-25 20:48:39 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:39 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:39 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:39 --> URI Class Initialized
INFO - 2023-09-25 20:48:39 --> Router Class Initialized
INFO - 2023-09-25 20:48:39 --> Output Class Initialized
INFO - 2023-09-25 20:48:39 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:39 --> Input Class Initialized
INFO - 2023-09-25 20:48:39 --> Language Class Initialized
INFO - 2023-09-25 20:48:39 --> Language Class Initialized
INFO - 2023-09-25 20:48:39 --> Config Class Initialized
INFO - 2023-09-25 20:48:39 --> Loader Class Initialized
INFO - 2023-09-25 20:48:39 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:39 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:39 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:39 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:39 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:39 --> Controller Class Initialized
INFO - 2023-09-25 20:48:42 --> Config Class Initialized
INFO - 2023-09-25 20:48:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:42 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:42 --> URI Class Initialized
INFO - 2023-09-25 20:48:42 --> Router Class Initialized
INFO - 2023-09-25 20:48:42 --> Output Class Initialized
INFO - 2023-09-25 20:48:42 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:42 --> Input Class Initialized
INFO - 2023-09-25 20:48:42 --> Language Class Initialized
INFO - 2023-09-25 20:48:42 --> Language Class Initialized
INFO - 2023-09-25 20:48:42 --> Config Class Initialized
INFO - 2023-09-25 20:48:42 --> Loader Class Initialized
INFO - 2023-09-25 20:48:42 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:42 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:42 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:42 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:42 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:42 --> Controller Class Initialized
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:48:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:48:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:48:51 --> Config Class Initialized
INFO - 2023-09-25 20:48:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:51 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:51 --> URI Class Initialized
INFO - 2023-09-25 20:48:51 --> Router Class Initialized
INFO - 2023-09-25 20:48:51 --> Output Class Initialized
INFO - 2023-09-25 20:48:51 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:51 --> Input Class Initialized
INFO - 2023-09-25 20:48:51 --> Language Class Initialized
INFO - 2023-09-25 20:48:51 --> Language Class Initialized
INFO - 2023-09-25 20:48:51 --> Config Class Initialized
INFO - 2023-09-25 20:48:51 --> Loader Class Initialized
INFO - 2023-09-25 20:48:51 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:51 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:51 --> Controller Class Initialized
DEBUG - 2023-09-25 20:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:48:51 --> Final output sent to browser
DEBUG - 2023-09-25 20:48:51 --> Total execution time: 0.0523
INFO - 2023-09-25 20:48:51 --> Config Class Initialized
INFO - 2023-09-25 20:48:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:48:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:48:51 --> Utf8 Class Initialized
INFO - 2023-09-25 20:48:51 --> URI Class Initialized
INFO - 2023-09-25 20:48:51 --> Router Class Initialized
INFO - 2023-09-25 20:48:51 --> Output Class Initialized
INFO - 2023-09-25 20:48:51 --> Security Class Initialized
DEBUG - 2023-09-25 20:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:48:51 --> Input Class Initialized
INFO - 2023-09-25 20:48:51 --> Language Class Initialized
INFO - 2023-09-25 20:48:51 --> Language Class Initialized
INFO - 2023-09-25 20:48:51 --> Config Class Initialized
INFO - 2023-09-25 20:48:51 --> Loader Class Initialized
INFO - 2023-09-25 20:48:51 --> Helper loaded: url_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: file_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: form_helper
INFO - 2023-09-25 20:48:51 --> Helper loaded: my_helper
INFO - 2023-09-25 20:48:51 --> Database Driver Class Initialized
INFO - 2023-09-25 20:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:48:51 --> Controller Class Initialized
INFO - 2023-09-25 20:49:01 --> Config Class Initialized
INFO - 2023-09-25 20:49:01 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:01 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:01 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:01 --> URI Class Initialized
INFO - 2023-09-25 20:49:01 --> Router Class Initialized
INFO - 2023-09-25 20:49:01 --> Output Class Initialized
INFO - 2023-09-25 20:49:01 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:01 --> Input Class Initialized
INFO - 2023-09-25 20:49:01 --> Language Class Initialized
INFO - 2023-09-25 20:49:01 --> Language Class Initialized
INFO - 2023-09-25 20:49:01 --> Config Class Initialized
INFO - 2023-09-25 20:49:01 --> Loader Class Initialized
INFO - 2023-09-25 20:49:01 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:01 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:01 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:01 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:01 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:01 --> Controller Class Initialized
INFO - 2023-09-25 20:49:01 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:01 --> Total execution time: 0.0474
INFO - 2023-09-25 20:49:04 --> Config Class Initialized
INFO - 2023-09-25 20:49:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:04 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:04 --> URI Class Initialized
INFO - 2023-09-25 20:49:04 --> Router Class Initialized
INFO - 2023-09-25 20:49:04 --> Output Class Initialized
INFO - 2023-09-25 20:49:04 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:04 --> Input Class Initialized
INFO - 2023-09-25 20:49:04 --> Language Class Initialized
INFO - 2023-09-25 20:49:04 --> Language Class Initialized
INFO - 2023-09-25 20:49:04 --> Config Class Initialized
INFO - 2023-09-25 20:49:04 --> Loader Class Initialized
INFO - 2023-09-25 20:49:04 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:04 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:04 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:04 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:04 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:04 --> Controller Class Initialized
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:49:06 --> Config Class Initialized
INFO - 2023-09-25 20:49:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:06 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:06 --> URI Class Initialized
INFO - 2023-09-25 20:49:06 --> Router Class Initialized
INFO - 2023-09-25 20:49:06 --> Output Class Initialized
INFO - 2023-09-25 20:49:06 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:06 --> Input Class Initialized
INFO - 2023-09-25 20:49:06 --> Language Class Initialized
INFO - 2023-09-25 20:49:06 --> Language Class Initialized
INFO - 2023-09-25 20:49:06 --> Config Class Initialized
INFO - 2023-09-25 20:49:06 --> Loader Class Initialized
INFO - 2023-09-25 20:49:06 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:06 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:06 --> Controller Class Initialized
DEBUG - 2023-09-25 20:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:49:06 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:06 --> Total execution time: 0.0395
INFO - 2023-09-25 20:49:06 --> Config Class Initialized
INFO - 2023-09-25 20:49:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:06 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:06 --> URI Class Initialized
INFO - 2023-09-25 20:49:06 --> Router Class Initialized
INFO - 2023-09-25 20:49:06 --> Output Class Initialized
INFO - 2023-09-25 20:49:06 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:06 --> Input Class Initialized
INFO - 2023-09-25 20:49:06 --> Language Class Initialized
INFO - 2023-09-25 20:49:06 --> Language Class Initialized
INFO - 2023-09-25 20:49:06 --> Config Class Initialized
INFO - 2023-09-25 20:49:06 --> Loader Class Initialized
INFO - 2023-09-25 20:49:06 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:06 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:06 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:06 --> Controller Class Initialized
INFO - 2023-09-25 20:49:08 --> Config Class Initialized
INFO - 2023-09-25 20:49:08 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:08 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:08 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:08 --> URI Class Initialized
INFO - 2023-09-25 20:49:08 --> Router Class Initialized
INFO - 2023-09-25 20:49:08 --> Output Class Initialized
INFO - 2023-09-25 20:49:08 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:08 --> Input Class Initialized
INFO - 2023-09-25 20:49:08 --> Language Class Initialized
INFO - 2023-09-25 20:49:08 --> Language Class Initialized
INFO - 2023-09-25 20:49:08 --> Config Class Initialized
INFO - 2023-09-25 20:49:08 --> Loader Class Initialized
INFO - 2023-09-25 20:49:08 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:08 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:08 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:08 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:08 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:08 --> Controller Class Initialized
INFO - 2023-09-25 20:49:08 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:08 --> Total execution time: 0.0339
INFO - 2023-09-25 20:49:09 --> Config Class Initialized
INFO - 2023-09-25 20:49:09 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:09 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:09 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:09 --> URI Class Initialized
INFO - 2023-09-25 20:49:09 --> Router Class Initialized
INFO - 2023-09-25 20:49:09 --> Output Class Initialized
INFO - 2023-09-25 20:49:09 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:09 --> Input Class Initialized
INFO - 2023-09-25 20:49:09 --> Language Class Initialized
INFO - 2023-09-25 20:49:09 --> Language Class Initialized
INFO - 2023-09-25 20:49:09 --> Config Class Initialized
INFO - 2023-09-25 20:49:09 --> Loader Class Initialized
INFO - 2023-09-25 20:49:09 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:09 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:09 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:09 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:09 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:09 --> Controller Class Initialized
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:09 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:49:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:49:13 --> Config Class Initialized
INFO - 2023-09-25 20:49:13 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:13 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:13 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:13 --> URI Class Initialized
INFO - 2023-09-25 20:49:13 --> Router Class Initialized
INFO - 2023-09-25 20:49:13 --> Output Class Initialized
INFO - 2023-09-25 20:49:13 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:13 --> Input Class Initialized
INFO - 2023-09-25 20:49:13 --> Language Class Initialized
INFO - 2023-09-25 20:49:13 --> Language Class Initialized
INFO - 2023-09-25 20:49:13 --> Config Class Initialized
INFO - 2023-09-25 20:49:13 --> Loader Class Initialized
INFO - 2023-09-25 20:49:13 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:13 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:13 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:13 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:13 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:13 --> Controller Class Initialized
DEBUG - 2023-09-25 20:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:49:13 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:13 --> Total execution time: 0.0714
INFO - 2023-09-25 20:49:14 --> Config Class Initialized
INFO - 2023-09-25 20:49:14 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:14 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:14 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:14 --> URI Class Initialized
INFO - 2023-09-25 20:49:14 --> Router Class Initialized
INFO - 2023-09-25 20:49:14 --> Output Class Initialized
INFO - 2023-09-25 20:49:14 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:14 --> Input Class Initialized
INFO - 2023-09-25 20:49:14 --> Language Class Initialized
INFO - 2023-09-25 20:49:14 --> Language Class Initialized
INFO - 2023-09-25 20:49:14 --> Config Class Initialized
INFO - 2023-09-25 20:49:14 --> Loader Class Initialized
INFO - 2023-09-25 20:49:14 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:14 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:14 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:14 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:14 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:14 --> Controller Class Initialized
INFO - 2023-09-25 20:49:16 --> Config Class Initialized
INFO - 2023-09-25 20:49:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:16 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:16 --> URI Class Initialized
INFO - 2023-09-25 20:49:16 --> Router Class Initialized
INFO - 2023-09-25 20:49:16 --> Output Class Initialized
INFO - 2023-09-25 20:49:16 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:16 --> Input Class Initialized
INFO - 2023-09-25 20:49:16 --> Language Class Initialized
INFO - 2023-09-25 20:49:16 --> Language Class Initialized
INFO - 2023-09-25 20:49:16 --> Config Class Initialized
INFO - 2023-09-25 20:49:16 --> Loader Class Initialized
INFO - 2023-09-25 20:49:16 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:16 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:16 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:16 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:16 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:16 --> Controller Class Initialized
INFO - 2023-09-25 20:49:16 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:16 --> Total execution time: 0.0685
INFO - 2023-09-25 20:49:31 --> Config Class Initialized
INFO - 2023-09-25 20:49:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:31 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:31 --> URI Class Initialized
INFO - 2023-09-25 20:49:31 --> Router Class Initialized
INFO - 2023-09-25 20:49:31 --> Output Class Initialized
INFO - 2023-09-25 20:49:31 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:31 --> Input Class Initialized
INFO - 2023-09-25 20:49:31 --> Language Class Initialized
INFO - 2023-09-25 20:49:31 --> Language Class Initialized
INFO - 2023-09-25 20:49:31 --> Config Class Initialized
INFO - 2023-09-25 20:49:31 --> Loader Class Initialized
INFO - 2023-09-25 20:49:31 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:31 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:31 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:31 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:31 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:31 --> Controller Class Initialized
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:49:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:49:34 --> Config Class Initialized
INFO - 2023-09-25 20:49:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:34 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:34 --> URI Class Initialized
INFO - 2023-09-25 20:49:34 --> Router Class Initialized
INFO - 2023-09-25 20:49:34 --> Output Class Initialized
INFO - 2023-09-25 20:49:34 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:34 --> Input Class Initialized
INFO - 2023-09-25 20:49:34 --> Language Class Initialized
INFO - 2023-09-25 20:49:34 --> Language Class Initialized
INFO - 2023-09-25 20:49:34 --> Config Class Initialized
INFO - 2023-09-25 20:49:34 --> Loader Class Initialized
INFO - 2023-09-25 20:49:34 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:34 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:34 --> Controller Class Initialized
DEBUG - 2023-09-25 20:49:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:49:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:49:34 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:34 --> Total execution time: 0.0385
INFO - 2023-09-25 20:49:34 --> Config Class Initialized
INFO - 2023-09-25 20:49:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:34 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:34 --> URI Class Initialized
INFO - 2023-09-25 20:49:34 --> Router Class Initialized
INFO - 2023-09-25 20:49:34 --> Output Class Initialized
INFO - 2023-09-25 20:49:34 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:34 --> Input Class Initialized
INFO - 2023-09-25 20:49:34 --> Language Class Initialized
INFO - 2023-09-25 20:49:34 --> Language Class Initialized
INFO - 2023-09-25 20:49:34 --> Config Class Initialized
INFO - 2023-09-25 20:49:34 --> Loader Class Initialized
INFO - 2023-09-25 20:49:34 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:34 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:34 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:34 --> Controller Class Initialized
INFO - 2023-09-25 20:49:51 --> Config Class Initialized
INFO - 2023-09-25 20:49:51 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:51 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:51 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:51 --> URI Class Initialized
INFO - 2023-09-25 20:49:51 --> Router Class Initialized
INFO - 2023-09-25 20:49:51 --> Output Class Initialized
INFO - 2023-09-25 20:49:51 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:51 --> Input Class Initialized
INFO - 2023-09-25 20:49:51 --> Language Class Initialized
INFO - 2023-09-25 20:49:51 --> Language Class Initialized
INFO - 2023-09-25 20:49:51 --> Config Class Initialized
INFO - 2023-09-25 20:49:51 --> Loader Class Initialized
INFO - 2023-09-25 20:49:51 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:51 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:51 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:51 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:51 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:51 --> Controller Class Initialized
INFO - 2023-09-25 20:49:51 --> Final output sent to browser
DEBUG - 2023-09-25 20:49:51 --> Total execution time: 0.0448
INFO - 2023-09-25 20:49:54 --> Config Class Initialized
INFO - 2023-09-25 20:49:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:49:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:49:54 --> Utf8 Class Initialized
INFO - 2023-09-25 20:49:54 --> URI Class Initialized
INFO - 2023-09-25 20:49:54 --> Router Class Initialized
INFO - 2023-09-25 20:49:54 --> Output Class Initialized
INFO - 2023-09-25 20:49:54 --> Security Class Initialized
DEBUG - 2023-09-25 20:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:49:54 --> Input Class Initialized
INFO - 2023-09-25 20:49:54 --> Language Class Initialized
INFO - 2023-09-25 20:49:54 --> Language Class Initialized
INFO - 2023-09-25 20:49:54 --> Config Class Initialized
INFO - 2023-09-25 20:49:54 --> Loader Class Initialized
INFO - 2023-09-25 20:49:54 --> Helper loaded: url_helper
INFO - 2023-09-25 20:49:54 --> Helper loaded: file_helper
INFO - 2023-09-25 20:49:54 --> Helper loaded: form_helper
INFO - 2023-09-25 20:49:54 --> Helper loaded: my_helper
INFO - 2023-09-25 20:49:54 --> Database Driver Class Initialized
INFO - 2023-09-25 20:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:49:54 --> Controller Class Initialized
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:49:54 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:49:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:50:27 --> Config Class Initialized
INFO - 2023-09-25 20:50:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:50:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:50:27 --> Utf8 Class Initialized
INFO - 2023-09-25 20:50:27 --> URI Class Initialized
INFO - 2023-09-25 20:50:27 --> Router Class Initialized
INFO - 2023-09-25 20:50:27 --> Output Class Initialized
INFO - 2023-09-25 20:50:27 --> Security Class Initialized
DEBUG - 2023-09-25 20:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:50:27 --> Input Class Initialized
INFO - 2023-09-25 20:50:27 --> Language Class Initialized
INFO - 2023-09-25 20:50:27 --> Language Class Initialized
INFO - 2023-09-25 20:50:27 --> Config Class Initialized
INFO - 2023-09-25 20:50:27 --> Loader Class Initialized
INFO - 2023-09-25 20:50:27 --> Helper loaded: url_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: file_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: form_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: my_helper
INFO - 2023-09-25 20:50:27 --> Database Driver Class Initialized
INFO - 2023-09-25 20:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:50:27 --> Controller Class Initialized
DEBUG - 2023-09-25 20:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:50:27 --> Final output sent to browser
DEBUG - 2023-09-25 20:50:27 --> Total execution time: 0.0849
INFO - 2023-09-25 20:50:27 --> Config Class Initialized
INFO - 2023-09-25 20:50:27 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:50:27 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:50:27 --> Utf8 Class Initialized
INFO - 2023-09-25 20:50:27 --> URI Class Initialized
INFO - 2023-09-25 20:50:27 --> Router Class Initialized
INFO - 2023-09-25 20:50:27 --> Output Class Initialized
INFO - 2023-09-25 20:50:27 --> Security Class Initialized
DEBUG - 2023-09-25 20:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:50:27 --> Input Class Initialized
INFO - 2023-09-25 20:50:27 --> Language Class Initialized
INFO - 2023-09-25 20:50:27 --> Language Class Initialized
INFO - 2023-09-25 20:50:27 --> Config Class Initialized
INFO - 2023-09-25 20:50:27 --> Loader Class Initialized
INFO - 2023-09-25 20:50:27 --> Helper loaded: url_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: file_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: form_helper
INFO - 2023-09-25 20:50:27 --> Helper loaded: my_helper
INFO - 2023-09-25 20:50:27 --> Database Driver Class Initialized
INFO - 2023-09-25 20:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:50:27 --> Controller Class Initialized
INFO - 2023-09-25 20:51:34 --> Config Class Initialized
INFO - 2023-09-25 20:51:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:34 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:34 --> URI Class Initialized
INFO - 2023-09-25 20:51:34 --> Router Class Initialized
INFO - 2023-09-25 20:51:34 --> Output Class Initialized
INFO - 2023-09-25 20:51:34 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:34 --> Input Class Initialized
INFO - 2023-09-25 20:51:34 --> Language Class Initialized
INFO - 2023-09-25 20:51:34 --> Language Class Initialized
INFO - 2023-09-25 20:51:34 --> Config Class Initialized
INFO - 2023-09-25 20:51:34 --> Loader Class Initialized
INFO - 2023-09-25 20:51:34 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:34 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:34 --> Controller Class Initialized
INFO - 2023-09-25 20:51:34 --> Final output sent to browser
DEBUG - 2023-09-25 20:51:34 --> Total execution time: 0.0849
INFO - 2023-09-25 20:51:34 --> Config Class Initialized
INFO - 2023-09-25 20:51:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:34 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:34 --> URI Class Initialized
INFO - 2023-09-25 20:51:34 --> Router Class Initialized
INFO - 2023-09-25 20:51:34 --> Output Class Initialized
INFO - 2023-09-25 20:51:34 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:34 --> Input Class Initialized
INFO - 2023-09-25 20:51:34 --> Language Class Initialized
INFO - 2023-09-25 20:51:34 --> Language Class Initialized
INFO - 2023-09-25 20:51:34 --> Config Class Initialized
INFO - 2023-09-25 20:51:34 --> Loader Class Initialized
INFO - 2023-09-25 20:51:34 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:34 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:34 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:34 --> Controller Class Initialized
INFO - 2023-09-25 20:51:34 --> Final output sent to browser
DEBUG - 2023-09-25 20:51:34 --> Total execution time: 0.0380
INFO - 2023-09-25 20:51:36 --> Config Class Initialized
INFO - 2023-09-25 20:51:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:36 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:36 --> URI Class Initialized
INFO - 2023-09-25 20:51:36 --> Router Class Initialized
INFO - 2023-09-25 20:51:36 --> Output Class Initialized
INFO - 2023-09-25 20:51:36 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:36 --> Input Class Initialized
INFO - 2023-09-25 20:51:36 --> Language Class Initialized
INFO - 2023-09-25 20:51:36 --> Language Class Initialized
INFO - 2023-09-25 20:51:36 --> Config Class Initialized
INFO - 2023-09-25 20:51:36 --> Loader Class Initialized
INFO - 2023-09-25 20:51:36 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:36 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:36 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:36 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:36 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:36 --> Controller Class Initialized
INFO - 2023-09-25 20:51:36 --> Final output sent to browser
DEBUG - 2023-09-25 20:51:36 --> Total execution time: 0.0380
INFO - 2023-09-25 20:51:37 --> Config Class Initialized
INFO - 2023-09-25 20:51:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:37 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:37 --> URI Class Initialized
INFO - 2023-09-25 20:51:37 --> Router Class Initialized
INFO - 2023-09-25 20:51:37 --> Output Class Initialized
INFO - 2023-09-25 20:51:37 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:37 --> Input Class Initialized
INFO - 2023-09-25 20:51:37 --> Language Class Initialized
INFO - 2023-09-25 20:51:37 --> Language Class Initialized
INFO - 2023-09-25 20:51:37 --> Config Class Initialized
INFO - 2023-09-25 20:51:37 --> Loader Class Initialized
INFO - 2023-09-25 20:51:37 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:37 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:37 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:37 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:37 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:37 --> Controller Class Initialized
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:51:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:51:40 --> Config Class Initialized
INFO - 2023-09-25 20:51:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:40 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:40 --> URI Class Initialized
INFO - 2023-09-25 20:51:40 --> Router Class Initialized
INFO - 2023-09-25 20:51:40 --> Output Class Initialized
INFO - 2023-09-25 20:51:40 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:40 --> Input Class Initialized
INFO - 2023-09-25 20:51:40 --> Language Class Initialized
INFO - 2023-09-25 20:51:40 --> Language Class Initialized
INFO - 2023-09-25 20:51:40 --> Config Class Initialized
INFO - 2023-09-25 20:51:40 --> Loader Class Initialized
INFO - 2023-09-25 20:51:40 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:40 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:40 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:40 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:40 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:40 --> Controller Class Initialized
DEBUG - 2023-09-25 20:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:51:40 --> Final output sent to browser
DEBUG - 2023-09-25 20:51:40 --> Total execution time: 0.0407
INFO - 2023-09-25 20:51:41 --> Config Class Initialized
INFO - 2023-09-25 20:51:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:41 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:41 --> URI Class Initialized
INFO - 2023-09-25 20:51:41 --> Router Class Initialized
INFO - 2023-09-25 20:51:41 --> Output Class Initialized
INFO - 2023-09-25 20:51:41 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:41 --> Input Class Initialized
INFO - 2023-09-25 20:51:41 --> Language Class Initialized
INFO - 2023-09-25 20:51:41 --> Language Class Initialized
INFO - 2023-09-25 20:51:41 --> Config Class Initialized
INFO - 2023-09-25 20:51:41 --> Loader Class Initialized
INFO - 2023-09-25 20:51:41 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:41 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:41 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:41 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:41 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:41 --> Controller Class Initialized
INFO - 2023-09-25 20:51:50 --> Config Class Initialized
INFO - 2023-09-25 20:51:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:51:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:51:50 --> Utf8 Class Initialized
INFO - 2023-09-25 20:51:50 --> URI Class Initialized
INFO - 2023-09-25 20:51:50 --> Router Class Initialized
INFO - 2023-09-25 20:51:50 --> Output Class Initialized
INFO - 2023-09-25 20:51:50 --> Security Class Initialized
DEBUG - 2023-09-25 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:51:50 --> Input Class Initialized
INFO - 2023-09-25 20:51:50 --> Language Class Initialized
INFO - 2023-09-25 20:51:50 --> Language Class Initialized
INFO - 2023-09-25 20:51:50 --> Config Class Initialized
INFO - 2023-09-25 20:51:50 --> Loader Class Initialized
INFO - 2023-09-25 20:51:50 --> Helper loaded: url_helper
INFO - 2023-09-25 20:51:50 --> Helper loaded: file_helper
INFO - 2023-09-25 20:51:50 --> Helper loaded: form_helper
INFO - 2023-09-25 20:51:50 --> Helper loaded: my_helper
INFO - 2023-09-25 20:51:50 --> Database Driver Class Initialized
INFO - 2023-09-25 20:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:51:50 --> Controller Class Initialized
INFO - 2023-09-25 20:51:50 --> Final output sent to browser
DEBUG - 2023-09-25 20:51:50 --> Total execution time: 0.0817
INFO - 2023-09-25 20:52:20 --> Config Class Initialized
INFO - 2023-09-25 20:52:20 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:20 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:20 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:20 --> URI Class Initialized
DEBUG - 2023-09-25 20:52:20 --> No URI present. Default controller set.
INFO - 2023-09-25 20:52:20 --> Router Class Initialized
INFO - 2023-09-25 20:52:20 --> Output Class Initialized
INFO - 2023-09-25 20:52:20 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:20 --> Input Class Initialized
INFO - 2023-09-25 20:52:20 --> Language Class Initialized
INFO - 2023-09-25 20:52:20 --> Language Class Initialized
INFO - 2023-09-25 20:52:20 --> Config Class Initialized
INFO - 2023-09-25 20:52:20 --> Loader Class Initialized
INFO - 2023-09-25 20:52:20 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:20 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:20 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:20 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:20 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:20 --> Controller Class Initialized
DEBUG - 2023-09-25 20:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:52:20 --> Final output sent to browser
DEBUG - 2023-09-25 20:52:20 --> Total execution time: 0.0420
INFO - 2023-09-25 20:52:24 --> Config Class Initialized
INFO - 2023-09-25 20:52:24 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:24 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:24 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:24 --> URI Class Initialized
DEBUG - 2023-09-25 20:52:24 --> No URI present. Default controller set.
INFO - 2023-09-25 20:52:24 --> Router Class Initialized
INFO - 2023-09-25 20:52:24 --> Output Class Initialized
INFO - 2023-09-25 20:52:24 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:24 --> Input Class Initialized
INFO - 2023-09-25 20:52:24 --> Language Class Initialized
INFO - 2023-09-25 20:52:24 --> Language Class Initialized
INFO - 2023-09-25 20:52:24 --> Config Class Initialized
INFO - 2023-09-25 20:52:24 --> Loader Class Initialized
INFO - 2023-09-25 20:52:24 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:24 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:24 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:24 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:24 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:24 --> Controller Class Initialized
DEBUG - 2023-09-25 20:52:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:52:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:52:24 --> Final output sent to browser
DEBUG - 2023-09-25 20:52:24 --> Total execution time: 0.0451
INFO - 2023-09-25 20:52:32 --> Config Class Initialized
INFO - 2023-09-25 20:52:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:32 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:32 --> URI Class Initialized
INFO - 2023-09-25 20:52:32 --> Router Class Initialized
INFO - 2023-09-25 20:52:32 --> Output Class Initialized
INFO - 2023-09-25 20:52:32 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:32 --> Input Class Initialized
INFO - 2023-09-25 20:52:32 --> Language Class Initialized
INFO - 2023-09-25 20:52:32 --> Language Class Initialized
INFO - 2023-09-25 20:52:32 --> Config Class Initialized
INFO - 2023-09-25 20:52:32 --> Loader Class Initialized
INFO - 2023-09-25 20:52:32 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:32 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:32 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:32 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:32 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:32 --> Controller Class Initialized
DEBUG - 2023-09-25 20:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:52:32 --> Final output sent to browser
DEBUG - 2023-09-25 20:52:32 --> Total execution time: 0.0367
INFO - 2023-09-25 20:52:37 --> Config Class Initialized
INFO - 2023-09-25 20:52:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:37 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:37 --> URI Class Initialized
INFO - 2023-09-25 20:52:37 --> Router Class Initialized
INFO - 2023-09-25 20:52:37 --> Output Class Initialized
INFO - 2023-09-25 20:52:37 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:37 --> Input Class Initialized
INFO - 2023-09-25 20:52:37 --> Language Class Initialized
INFO - 2023-09-25 20:52:37 --> Language Class Initialized
INFO - 2023-09-25 20:52:37 --> Config Class Initialized
INFO - 2023-09-25 20:52:37 --> Loader Class Initialized
INFO - 2023-09-25 20:52:37 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:37 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:37 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:37 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:37 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:37 --> Controller Class Initialized
DEBUG - 2023-09-25 20:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 20:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:52:37 --> Final output sent to browser
DEBUG - 2023-09-25 20:52:37 --> Total execution time: 0.0342
INFO - 2023-09-25 20:52:43 --> Config Class Initialized
INFO - 2023-09-25 20:52:43 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:43 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:43 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:43 --> URI Class Initialized
INFO - 2023-09-25 20:52:43 --> Router Class Initialized
INFO - 2023-09-25 20:52:43 --> Output Class Initialized
INFO - 2023-09-25 20:52:43 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:43 --> Input Class Initialized
INFO - 2023-09-25 20:52:43 --> Language Class Initialized
INFO - 2023-09-25 20:52:43 --> Language Class Initialized
INFO - 2023-09-25 20:52:43 --> Config Class Initialized
INFO - 2023-09-25 20:52:43 --> Loader Class Initialized
INFO - 2023-09-25 20:52:43 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:43 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:43 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:43 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:43 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:43 --> Controller Class Initialized
DEBUG - 2023-09-25 20:52:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:52:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:52:43 --> Final output sent to browser
DEBUG - 2023-09-25 20:52:43 --> Total execution time: 0.0375
INFO - 2023-09-25 20:52:44 --> Config Class Initialized
INFO - 2023-09-25 20:52:44 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:44 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:44 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:44 --> URI Class Initialized
INFO - 2023-09-25 20:52:44 --> Router Class Initialized
INFO - 2023-09-25 20:52:44 --> Output Class Initialized
INFO - 2023-09-25 20:52:44 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:44 --> Input Class Initialized
INFO - 2023-09-25 20:52:44 --> Language Class Initialized
INFO - 2023-09-25 20:52:44 --> Language Class Initialized
INFO - 2023-09-25 20:52:44 --> Config Class Initialized
INFO - 2023-09-25 20:52:44 --> Loader Class Initialized
INFO - 2023-09-25 20:52:44 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:44 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:44 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:44 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:44 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:44 --> Controller Class Initialized
INFO - 2023-09-25 20:52:45 --> Config Class Initialized
INFO - 2023-09-25 20:52:45 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:52:45 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:52:45 --> Utf8 Class Initialized
INFO - 2023-09-25 20:52:45 --> URI Class Initialized
INFO - 2023-09-25 20:52:45 --> Router Class Initialized
INFO - 2023-09-25 20:52:45 --> Output Class Initialized
INFO - 2023-09-25 20:52:45 --> Security Class Initialized
DEBUG - 2023-09-25 20:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:52:45 --> Input Class Initialized
INFO - 2023-09-25 20:52:45 --> Language Class Initialized
INFO - 2023-09-25 20:52:45 --> Language Class Initialized
INFO - 2023-09-25 20:52:45 --> Config Class Initialized
INFO - 2023-09-25 20:52:45 --> Loader Class Initialized
INFO - 2023-09-25 20:52:45 --> Helper loaded: url_helper
INFO - 2023-09-25 20:52:45 --> Helper loaded: file_helper
INFO - 2023-09-25 20:52:45 --> Helper loaded: form_helper
INFO - 2023-09-25 20:52:45 --> Helper loaded: my_helper
INFO - 2023-09-25 20:52:45 --> Database Driver Class Initialized
INFO - 2023-09-25 20:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:52:45 --> Controller Class Initialized
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:52:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:52:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 20:54:06 --> Config Class Initialized
INFO - 2023-09-25 20:54:06 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:06 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:06 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:06 --> URI Class Initialized
INFO - 2023-09-25 20:54:06 --> Router Class Initialized
INFO - 2023-09-25 20:54:06 --> Output Class Initialized
INFO - 2023-09-25 20:54:06 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:06 --> Input Class Initialized
INFO - 2023-09-25 20:54:06 --> Language Class Initialized
INFO - 2023-09-25 20:54:06 --> Language Class Initialized
INFO - 2023-09-25 20:54:06 --> Config Class Initialized
INFO - 2023-09-25 20:54:06 --> Loader Class Initialized
INFO - 2023-09-25 20:54:06 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:06 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:06 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:06 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:06 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:06 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:06 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:06 --> Total execution time: 0.0408
INFO - 2023-09-25 20:54:07 --> Config Class Initialized
INFO - 2023-09-25 20:54:07 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:07 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:07 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:07 --> URI Class Initialized
INFO - 2023-09-25 20:54:07 --> Router Class Initialized
INFO - 2023-09-25 20:54:07 --> Output Class Initialized
INFO - 2023-09-25 20:54:07 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:07 --> Input Class Initialized
INFO - 2023-09-25 20:54:07 --> Language Class Initialized
INFO - 2023-09-25 20:54:07 --> Language Class Initialized
INFO - 2023-09-25 20:54:07 --> Config Class Initialized
INFO - 2023-09-25 20:54:07 --> Loader Class Initialized
INFO - 2023-09-25 20:54:07 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:07 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:07 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:07 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:07 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:07 --> Controller Class Initialized
INFO - 2023-09-25 20:54:10 --> Config Class Initialized
INFO - 2023-09-25 20:54:10 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:10 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:10 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:10 --> URI Class Initialized
INFO - 2023-09-25 20:54:10 --> Router Class Initialized
INFO - 2023-09-25 20:54:10 --> Output Class Initialized
INFO - 2023-09-25 20:54:10 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:10 --> Input Class Initialized
INFO - 2023-09-25 20:54:10 --> Language Class Initialized
INFO - 2023-09-25 20:54:10 --> Language Class Initialized
INFO - 2023-09-25 20:54:10 --> Config Class Initialized
INFO - 2023-09-25 20:54:10 --> Loader Class Initialized
INFO - 2023-09-25 20:54:10 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:10 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:10 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:10 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:10 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:10 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:54:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:10 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:10 --> Total execution time: 0.0333
INFO - 2023-09-25 20:54:23 --> Config Class Initialized
INFO - 2023-09-25 20:54:23 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:23 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:23 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:23 --> URI Class Initialized
INFO - 2023-09-25 20:54:23 --> Router Class Initialized
INFO - 2023-09-25 20:54:23 --> Output Class Initialized
INFO - 2023-09-25 20:54:23 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:23 --> Input Class Initialized
INFO - 2023-09-25 20:54:23 --> Language Class Initialized
INFO - 2023-09-25 20:54:23 --> Language Class Initialized
INFO - 2023-09-25 20:54:23 --> Config Class Initialized
INFO - 2023-09-25 20:54:23 --> Loader Class Initialized
INFO - 2023-09-25 20:54:23 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:23 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:23 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:23 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:23 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:23 --> Controller Class Initialized
INFO - 2023-09-25 20:54:23 --> Helper loaded: cookie_helper
INFO - 2023-09-25 20:54:25 --> Config Class Initialized
INFO - 2023-09-25 20:54:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:25 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:25 --> URI Class Initialized
INFO - 2023-09-25 20:54:25 --> Router Class Initialized
INFO - 2023-09-25 20:54:25 --> Output Class Initialized
INFO - 2023-09-25 20:54:25 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:25 --> Input Class Initialized
INFO - 2023-09-25 20:54:25 --> Language Class Initialized
INFO - 2023-09-25 20:54:25 --> Language Class Initialized
INFO - 2023-09-25 20:54:25 --> Config Class Initialized
INFO - 2023-09-25 20:54:25 --> Loader Class Initialized
INFO - 2023-09-25 20:54:25 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:25 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:25 --> Controller Class Initialized
INFO - 2023-09-25 20:54:25 --> Config Class Initialized
INFO - 2023-09-25 20:54:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:25 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:25 --> URI Class Initialized
INFO - 2023-09-25 20:54:25 --> Router Class Initialized
INFO - 2023-09-25 20:54:25 --> Output Class Initialized
INFO - 2023-09-25 20:54:25 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:25 --> Input Class Initialized
INFO - 2023-09-25 20:54:25 --> Language Class Initialized
INFO - 2023-09-25 20:54:25 --> Language Class Initialized
INFO - 2023-09-25 20:54:25 --> Config Class Initialized
INFO - 2023-09-25 20:54:25 --> Loader Class Initialized
INFO - 2023-09-25 20:54:25 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:25 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:25 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:25 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-25 20:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:25 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:25 --> Total execution time: 0.0354
INFO - 2023-09-25 20:54:30 --> Config Class Initialized
INFO - 2023-09-25 20:54:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:30 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:30 --> URI Class Initialized
INFO - 2023-09-25 20:54:30 --> Router Class Initialized
INFO - 2023-09-25 20:54:30 --> Output Class Initialized
INFO - 2023-09-25 20:54:30 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:30 --> Input Class Initialized
INFO - 2023-09-25 20:54:30 --> Language Class Initialized
INFO - 2023-09-25 20:54:30 --> Language Class Initialized
INFO - 2023-09-25 20:54:30 --> Config Class Initialized
INFO - 2023-09-25 20:54:30 --> Loader Class Initialized
INFO - 2023-09-25 20:54:30 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:30 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:30 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:30 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:30 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:30 --> Controller Class Initialized
INFO - 2023-09-25 20:54:30 --> Helper loaded: cookie_helper
INFO - 2023-09-25 20:54:30 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:30 --> Total execution time: 0.0667
INFO - 2023-09-25 20:54:31 --> Config Class Initialized
INFO - 2023-09-25 20:54:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:31 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:31 --> URI Class Initialized
INFO - 2023-09-25 20:54:31 --> Router Class Initialized
INFO - 2023-09-25 20:54:31 --> Output Class Initialized
INFO - 2023-09-25 20:54:31 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:31 --> Input Class Initialized
INFO - 2023-09-25 20:54:31 --> Language Class Initialized
INFO - 2023-09-25 20:54:31 --> Language Class Initialized
INFO - 2023-09-25 20:54:31 --> Config Class Initialized
INFO - 2023-09-25 20:54:31 --> Loader Class Initialized
INFO - 2023-09-25 20:54:31 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:31 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:31 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:31 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:31 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:31 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 20:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:31 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:31 --> Total execution time: 0.0395
INFO - 2023-09-25 20:54:34 --> Config Class Initialized
INFO - 2023-09-25 20:54:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:34 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:34 --> URI Class Initialized
INFO - 2023-09-25 20:54:34 --> Router Class Initialized
INFO - 2023-09-25 20:54:34 --> Output Class Initialized
INFO - 2023-09-25 20:54:34 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:34 --> Input Class Initialized
INFO - 2023-09-25 20:54:34 --> Language Class Initialized
INFO - 2023-09-25 20:54:34 --> Language Class Initialized
INFO - 2023-09-25 20:54:34 --> Config Class Initialized
INFO - 2023-09-25 20:54:34 --> Loader Class Initialized
INFO - 2023-09-25 20:54:34 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:34 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:34 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:34 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:34 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:34 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 20:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:34 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:34 --> Total execution time: 0.0351
INFO - 2023-09-25 20:54:36 --> Config Class Initialized
INFO - 2023-09-25 20:54:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:36 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:36 --> URI Class Initialized
INFO - 2023-09-25 20:54:36 --> Router Class Initialized
INFO - 2023-09-25 20:54:36 --> Output Class Initialized
INFO - 2023-09-25 20:54:36 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:36 --> Input Class Initialized
INFO - 2023-09-25 20:54:36 --> Language Class Initialized
INFO - 2023-09-25 20:54:36 --> Language Class Initialized
INFO - 2023-09-25 20:54:36 --> Config Class Initialized
INFO - 2023-09-25 20:54:36 --> Loader Class Initialized
INFO - 2023-09-25 20:54:36 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:36 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:36 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:36 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:36 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:36 --> Controller Class Initialized
DEBUG - 2023-09-25 20:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 20:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 20:54:36 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:36 --> Total execution time: 0.0380
INFO - 2023-09-25 20:54:37 --> Config Class Initialized
INFO - 2023-09-25 20:54:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:37 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:37 --> URI Class Initialized
INFO - 2023-09-25 20:54:37 --> Router Class Initialized
INFO - 2023-09-25 20:54:37 --> Output Class Initialized
INFO - 2023-09-25 20:54:37 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:37 --> Input Class Initialized
INFO - 2023-09-25 20:54:37 --> Language Class Initialized
INFO - 2023-09-25 20:54:37 --> Language Class Initialized
INFO - 2023-09-25 20:54:37 --> Config Class Initialized
INFO - 2023-09-25 20:54:37 --> Loader Class Initialized
INFO - 2023-09-25 20:54:37 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:37 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:37 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:37 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:37 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:37 --> Controller Class Initialized
INFO - 2023-09-25 20:54:40 --> Config Class Initialized
INFO - 2023-09-25 20:54:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:40 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:40 --> URI Class Initialized
INFO - 2023-09-25 20:54:40 --> Router Class Initialized
INFO - 2023-09-25 20:54:40 --> Output Class Initialized
INFO - 2023-09-25 20:54:40 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:40 --> Input Class Initialized
INFO - 2023-09-25 20:54:40 --> Language Class Initialized
INFO - 2023-09-25 20:54:40 --> Language Class Initialized
INFO - 2023-09-25 20:54:40 --> Config Class Initialized
INFO - 2023-09-25 20:54:40 --> Loader Class Initialized
INFO - 2023-09-25 20:54:40 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:40 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:40 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:40 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:40 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:40 --> Controller Class Initialized
INFO - 2023-09-25 20:54:40 --> Final output sent to browser
DEBUG - 2023-09-25 20:54:40 --> Total execution time: 0.0714
INFO - 2023-09-25 20:54:41 --> Config Class Initialized
INFO - 2023-09-25 20:54:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 20:54:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 20:54:41 --> Utf8 Class Initialized
INFO - 2023-09-25 20:54:41 --> URI Class Initialized
INFO - 2023-09-25 20:54:41 --> Router Class Initialized
INFO - 2023-09-25 20:54:41 --> Output Class Initialized
INFO - 2023-09-25 20:54:41 --> Security Class Initialized
DEBUG - 2023-09-25 20:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 20:54:41 --> Input Class Initialized
INFO - 2023-09-25 20:54:41 --> Language Class Initialized
INFO - 2023-09-25 20:54:41 --> Language Class Initialized
INFO - 2023-09-25 20:54:41 --> Config Class Initialized
INFO - 2023-09-25 20:54:41 --> Loader Class Initialized
INFO - 2023-09-25 20:54:41 --> Helper loaded: url_helper
INFO - 2023-09-25 20:54:41 --> Helper loaded: file_helper
INFO - 2023-09-25 20:54:41 --> Helper loaded: form_helper
INFO - 2023-09-25 20:54:41 --> Helper loaded: my_helper
INFO - 2023-09-25 20:54:41 --> Database Driver Class Initialized
INFO - 2023-09-25 20:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 20:54:41 --> Controller Class Initialized
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 20:54:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 20:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:07:16 --> Config Class Initialized
INFO - 2023-09-25 21:07:16 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:16 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:16 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:16 --> URI Class Initialized
INFO - 2023-09-25 21:07:16 --> Router Class Initialized
INFO - 2023-09-25 21:07:16 --> Output Class Initialized
INFO - 2023-09-25 21:07:16 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:16 --> Input Class Initialized
INFO - 2023-09-25 21:07:16 --> Language Class Initialized
INFO - 2023-09-25 21:07:16 --> Language Class Initialized
INFO - 2023-09-25 21:07:16 --> Config Class Initialized
INFO - 2023-09-25 21:07:16 --> Loader Class Initialized
INFO - 2023-09-25 21:07:16 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:16 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:16 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:16 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:16 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:16 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-25 21:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:16 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:16 --> Total execution time: 0.0750
INFO - 2023-09-25 21:07:19 --> Config Class Initialized
INFO - 2023-09-25 21:07:19 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:19 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:19 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:19 --> URI Class Initialized
INFO - 2023-09-25 21:07:19 --> Router Class Initialized
INFO - 2023-09-25 21:07:19 --> Output Class Initialized
INFO - 2023-09-25 21:07:19 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:19 --> Input Class Initialized
INFO - 2023-09-25 21:07:19 --> Language Class Initialized
INFO - 2023-09-25 21:07:19 --> Language Class Initialized
INFO - 2023-09-25 21:07:19 --> Config Class Initialized
INFO - 2023-09-25 21:07:19 --> Loader Class Initialized
INFO - 2023-09-25 21:07:19 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:19 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:19 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:19 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:19 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:19 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-25 21:07:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:19 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:19 --> Total execution time: 0.0521
INFO - 2023-09-25 21:07:22 --> Config Class Initialized
INFO - 2023-09-25 21:07:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:22 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:22 --> URI Class Initialized
INFO - 2023-09-25 21:07:22 --> Router Class Initialized
INFO - 2023-09-25 21:07:22 --> Output Class Initialized
INFO - 2023-09-25 21:07:22 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:22 --> Input Class Initialized
INFO - 2023-09-25 21:07:22 --> Language Class Initialized
INFO - 2023-09-25 21:07:22 --> Language Class Initialized
INFO - 2023-09-25 21:07:22 --> Config Class Initialized
INFO - 2023-09-25 21:07:22 --> Loader Class Initialized
INFO - 2023-09-25 21:07:22 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:22 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:22 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:07:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:22 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:22 --> Total execution time: 0.0473
INFO - 2023-09-25 21:07:22 --> Config Class Initialized
INFO - 2023-09-25 21:07:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:22 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:22 --> URI Class Initialized
INFO - 2023-09-25 21:07:22 --> Router Class Initialized
INFO - 2023-09-25 21:07:22 --> Output Class Initialized
INFO - 2023-09-25 21:07:22 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:22 --> Input Class Initialized
INFO - 2023-09-25 21:07:22 --> Language Class Initialized
INFO - 2023-09-25 21:07:22 --> Language Class Initialized
INFO - 2023-09-25 21:07:22 --> Config Class Initialized
INFO - 2023-09-25 21:07:22 --> Loader Class Initialized
INFO - 2023-09-25 21:07:22 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:22 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:22 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:22 --> Controller Class Initialized
INFO - 2023-09-25 21:07:25 --> Config Class Initialized
INFO - 2023-09-25 21:07:25 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:25 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:25 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:25 --> URI Class Initialized
INFO - 2023-09-25 21:07:25 --> Router Class Initialized
INFO - 2023-09-25 21:07:25 --> Output Class Initialized
INFO - 2023-09-25 21:07:25 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:25 --> Input Class Initialized
INFO - 2023-09-25 21:07:25 --> Language Class Initialized
INFO - 2023-09-25 21:07:25 --> Language Class Initialized
INFO - 2023-09-25 21:07:25 --> Config Class Initialized
INFO - 2023-09-25 21:07:25 --> Loader Class Initialized
INFO - 2023-09-25 21:07:25 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:25 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:25 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:25 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:25 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:25 --> Controller Class Initialized
INFO - 2023-09-25 21:07:25 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:25 --> Total execution time: 0.0371
INFO - 2023-09-25 21:07:26 --> Config Class Initialized
INFO - 2023-09-25 21:07:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:26 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:26 --> URI Class Initialized
INFO - 2023-09-25 21:07:26 --> Router Class Initialized
INFO - 2023-09-25 21:07:26 --> Output Class Initialized
INFO - 2023-09-25 21:07:26 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:26 --> Input Class Initialized
INFO - 2023-09-25 21:07:26 --> Language Class Initialized
INFO - 2023-09-25 21:07:26 --> Language Class Initialized
INFO - 2023-09-25 21:07:26 --> Config Class Initialized
INFO - 2023-09-25 21:07:26 --> Loader Class Initialized
INFO - 2023-09-25 21:07:26 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:26 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:26 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:26 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:27 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:27 --> Controller Class Initialized
INFO - 2023-09-25 21:07:27 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:27 --> Total execution time: 0.0385
INFO - 2023-09-25 21:07:28 --> Config Class Initialized
INFO - 2023-09-25 21:07:28 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:28 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:28 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:28 --> URI Class Initialized
INFO - 2023-09-25 21:07:28 --> Router Class Initialized
INFO - 2023-09-25 21:07:28 --> Output Class Initialized
INFO - 2023-09-25 21:07:28 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:28 --> Input Class Initialized
INFO - 2023-09-25 21:07:28 --> Language Class Initialized
INFO - 2023-09-25 21:07:28 --> Language Class Initialized
INFO - 2023-09-25 21:07:28 --> Config Class Initialized
INFO - 2023-09-25 21:07:28 --> Loader Class Initialized
INFO - 2023-09-25 21:07:28 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:28 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:28 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:28 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:28 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:28 --> Controller Class Initialized
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:28 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:07:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:07:31 --> Config Class Initialized
INFO - 2023-09-25 21:07:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:31 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:31 --> URI Class Initialized
INFO - 2023-09-25 21:07:31 --> Router Class Initialized
INFO - 2023-09-25 21:07:31 --> Output Class Initialized
INFO - 2023-09-25 21:07:31 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:31 --> Input Class Initialized
INFO - 2023-09-25 21:07:31 --> Language Class Initialized
INFO - 2023-09-25 21:07:31 --> Language Class Initialized
INFO - 2023-09-25 21:07:31 --> Config Class Initialized
INFO - 2023-09-25 21:07:31 --> Loader Class Initialized
INFO - 2023-09-25 21:07:31 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:31 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:31 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:31 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:31 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:31 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:31 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:31 --> Total execution time: 0.0442
INFO - 2023-09-25 21:07:32 --> Config Class Initialized
INFO - 2023-09-25 21:07:32 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:32 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:32 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:32 --> URI Class Initialized
INFO - 2023-09-25 21:07:32 --> Router Class Initialized
INFO - 2023-09-25 21:07:32 --> Output Class Initialized
INFO - 2023-09-25 21:07:32 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:32 --> Input Class Initialized
INFO - 2023-09-25 21:07:32 --> Language Class Initialized
INFO - 2023-09-25 21:07:32 --> Language Class Initialized
INFO - 2023-09-25 21:07:32 --> Config Class Initialized
INFO - 2023-09-25 21:07:32 --> Loader Class Initialized
INFO - 2023-09-25 21:07:32 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:32 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:32 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:32 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:32 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:32 --> Controller Class Initialized
INFO - 2023-09-25 21:07:34 --> Config Class Initialized
INFO - 2023-09-25 21:07:34 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:34 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:34 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:34 --> URI Class Initialized
INFO - 2023-09-25 21:07:34 --> Router Class Initialized
INFO - 2023-09-25 21:07:34 --> Output Class Initialized
INFO - 2023-09-25 21:07:34 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:34 --> Input Class Initialized
INFO - 2023-09-25 21:07:34 --> Language Class Initialized
INFO - 2023-09-25 21:07:34 --> Language Class Initialized
INFO - 2023-09-25 21:07:34 --> Config Class Initialized
INFO - 2023-09-25 21:07:34 --> Loader Class Initialized
INFO - 2023-09-25 21:07:34 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:34 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:34 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:34 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:34 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:34 --> Controller Class Initialized
INFO - 2023-09-25 21:07:34 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:34 --> Total execution time: 0.0435
INFO - 2023-09-25 21:07:36 --> Config Class Initialized
INFO - 2023-09-25 21:07:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:36 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:36 --> URI Class Initialized
INFO - 2023-09-25 21:07:36 --> Router Class Initialized
INFO - 2023-09-25 21:07:36 --> Output Class Initialized
INFO - 2023-09-25 21:07:36 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:36 --> Input Class Initialized
INFO - 2023-09-25 21:07:36 --> Language Class Initialized
INFO - 2023-09-25 21:07:36 --> Language Class Initialized
INFO - 2023-09-25 21:07:36 --> Config Class Initialized
INFO - 2023-09-25 21:07:36 --> Loader Class Initialized
INFO - 2023-09-25 21:07:36 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:36 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:36 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:36 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:36 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:36 --> Controller Class Initialized
INFO - 2023-09-25 21:07:36 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:36 --> Total execution time: 0.0419
INFO - 2023-09-25 21:07:37 --> Config Class Initialized
INFO - 2023-09-25 21:07:37 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:37 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:37 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:37 --> URI Class Initialized
INFO - 2023-09-25 21:07:37 --> Router Class Initialized
INFO - 2023-09-25 21:07:37 --> Output Class Initialized
INFO - 2023-09-25 21:07:37 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:37 --> Input Class Initialized
INFO - 2023-09-25 21:07:37 --> Language Class Initialized
INFO - 2023-09-25 21:07:37 --> Language Class Initialized
INFO - 2023-09-25 21:07:37 --> Config Class Initialized
INFO - 2023-09-25 21:07:37 --> Loader Class Initialized
INFO - 2023-09-25 21:07:37 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:37 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:37 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:37 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:37 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:37 --> Controller Class Initialized
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:37 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:07:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:07:40 --> Config Class Initialized
INFO - 2023-09-25 21:07:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:40 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:40 --> URI Class Initialized
INFO - 2023-09-25 21:07:40 --> Router Class Initialized
INFO - 2023-09-25 21:07:40 --> Output Class Initialized
INFO - 2023-09-25 21:07:40 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:40 --> Input Class Initialized
INFO - 2023-09-25 21:07:40 --> Language Class Initialized
INFO - 2023-09-25 21:07:40 --> Language Class Initialized
INFO - 2023-09-25 21:07:40 --> Config Class Initialized
INFO - 2023-09-25 21:07:40 --> Loader Class Initialized
INFO - 2023-09-25 21:07:40 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:40 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:40 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:40 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:40 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:40 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:40 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:40 --> Total execution time: 0.0474
INFO - 2023-09-25 21:07:41 --> Config Class Initialized
INFO - 2023-09-25 21:07:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:41 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:41 --> URI Class Initialized
INFO - 2023-09-25 21:07:41 --> Router Class Initialized
INFO - 2023-09-25 21:07:41 --> Output Class Initialized
INFO - 2023-09-25 21:07:41 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:41 --> Input Class Initialized
INFO - 2023-09-25 21:07:41 --> Language Class Initialized
INFO - 2023-09-25 21:07:41 --> Language Class Initialized
INFO - 2023-09-25 21:07:41 --> Config Class Initialized
INFO - 2023-09-25 21:07:41 --> Loader Class Initialized
INFO - 2023-09-25 21:07:41 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:41 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:41 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:41 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:41 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:41 --> Controller Class Initialized
INFO - 2023-09-25 21:07:42 --> Config Class Initialized
INFO - 2023-09-25 21:07:42 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:42 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:42 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:42 --> URI Class Initialized
INFO - 2023-09-25 21:07:42 --> Router Class Initialized
INFO - 2023-09-25 21:07:42 --> Output Class Initialized
INFO - 2023-09-25 21:07:42 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:42 --> Input Class Initialized
INFO - 2023-09-25 21:07:42 --> Language Class Initialized
INFO - 2023-09-25 21:07:42 --> Language Class Initialized
INFO - 2023-09-25 21:07:42 --> Config Class Initialized
INFO - 2023-09-25 21:07:42 --> Loader Class Initialized
INFO - 2023-09-25 21:07:42 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:42 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:42 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:42 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:42 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:42 --> Controller Class Initialized
INFO - 2023-09-25 21:07:42 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:42 --> Total execution time: 0.0424
INFO - 2023-09-25 21:07:43 --> Config Class Initialized
INFO - 2023-09-25 21:07:43 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:43 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:43 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:43 --> URI Class Initialized
INFO - 2023-09-25 21:07:43 --> Router Class Initialized
INFO - 2023-09-25 21:07:43 --> Output Class Initialized
INFO - 2023-09-25 21:07:43 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:43 --> Input Class Initialized
INFO - 2023-09-25 21:07:43 --> Language Class Initialized
INFO - 2023-09-25 21:07:43 --> Language Class Initialized
INFO - 2023-09-25 21:07:43 --> Config Class Initialized
INFO - 2023-09-25 21:07:43 --> Loader Class Initialized
INFO - 2023-09-25 21:07:43 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:43 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:43 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:43 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:43 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:43 --> Controller Class Initialized
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:43 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:07:46 --> Config Class Initialized
INFO - 2023-09-25 21:07:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:46 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:46 --> URI Class Initialized
INFO - 2023-09-25 21:07:46 --> Router Class Initialized
INFO - 2023-09-25 21:07:46 --> Output Class Initialized
INFO - 2023-09-25 21:07:46 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:46 --> Input Class Initialized
INFO - 2023-09-25 21:07:46 --> Language Class Initialized
INFO - 2023-09-25 21:07:46 --> Language Class Initialized
INFO - 2023-09-25 21:07:46 --> Config Class Initialized
INFO - 2023-09-25 21:07:46 --> Loader Class Initialized
INFO - 2023-09-25 21:07:46 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:46 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:46 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:46 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:46 --> Total execution time: 0.0393
INFO - 2023-09-25 21:07:46 --> Config Class Initialized
INFO - 2023-09-25 21:07:46 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:46 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:46 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:46 --> URI Class Initialized
INFO - 2023-09-25 21:07:46 --> Router Class Initialized
INFO - 2023-09-25 21:07:46 --> Output Class Initialized
INFO - 2023-09-25 21:07:46 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:46 --> Input Class Initialized
INFO - 2023-09-25 21:07:46 --> Language Class Initialized
INFO - 2023-09-25 21:07:46 --> Language Class Initialized
INFO - 2023-09-25 21:07:46 --> Config Class Initialized
INFO - 2023-09-25 21:07:46 --> Loader Class Initialized
INFO - 2023-09-25 21:07:46 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:46 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:46 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:46 --> Controller Class Initialized
INFO - 2023-09-25 21:07:49 --> Config Class Initialized
INFO - 2023-09-25 21:07:49 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:49 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:49 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:49 --> URI Class Initialized
INFO - 2023-09-25 21:07:49 --> Router Class Initialized
INFO - 2023-09-25 21:07:49 --> Output Class Initialized
INFO - 2023-09-25 21:07:49 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:49 --> Input Class Initialized
INFO - 2023-09-25 21:07:49 --> Language Class Initialized
INFO - 2023-09-25 21:07:49 --> Language Class Initialized
INFO - 2023-09-25 21:07:49 --> Config Class Initialized
INFO - 2023-09-25 21:07:49 --> Loader Class Initialized
INFO - 2023-09-25 21:07:49 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:49 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:49 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:49 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:49 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:49 --> Controller Class Initialized
INFO - 2023-09-25 21:07:49 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:49 --> Total execution time: 0.0457
INFO - 2023-09-25 21:07:50 --> Config Class Initialized
INFO - 2023-09-25 21:07:50 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:50 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:50 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:50 --> URI Class Initialized
INFO - 2023-09-25 21:07:50 --> Router Class Initialized
INFO - 2023-09-25 21:07:50 --> Output Class Initialized
INFO - 2023-09-25 21:07:50 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:50 --> Input Class Initialized
INFO - 2023-09-25 21:07:50 --> Language Class Initialized
INFO - 2023-09-25 21:07:50 --> Language Class Initialized
INFO - 2023-09-25 21:07:50 --> Config Class Initialized
INFO - 2023-09-25 21:07:50 --> Loader Class Initialized
INFO - 2023-09-25 21:07:50 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:50 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:50 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:50 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:50 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:50 --> Controller Class Initialized
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:07:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:07:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:07:53 --> Config Class Initialized
INFO - 2023-09-25 21:07:53 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:53 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:53 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:53 --> URI Class Initialized
INFO - 2023-09-25 21:07:53 --> Router Class Initialized
INFO - 2023-09-25 21:07:53 --> Output Class Initialized
INFO - 2023-09-25 21:07:53 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:53 --> Input Class Initialized
INFO - 2023-09-25 21:07:53 --> Language Class Initialized
INFO - 2023-09-25 21:07:53 --> Language Class Initialized
INFO - 2023-09-25 21:07:53 --> Config Class Initialized
INFO - 2023-09-25 21:07:53 --> Loader Class Initialized
INFO - 2023-09-25 21:07:53 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:53 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:53 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:53 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:53 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:53 --> Controller Class Initialized
DEBUG - 2023-09-25 21:07:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:07:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:07:53 --> Final output sent to browser
DEBUG - 2023-09-25 21:07:53 --> Total execution time: 0.0484
INFO - 2023-09-25 21:07:54 --> Config Class Initialized
INFO - 2023-09-25 21:07:54 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:07:54 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:07:54 --> Utf8 Class Initialized
INFO - 2023-09-25 21:07:54 --> URI Class Initialized
INFO - 2023-09-25 21:07:54 --> Router Class Initialized
INFO - 2023-09-25 21:07:54 --> Output Class Initialized
INFO - 2023-09-25 21:07:54 --> Security Class Initialized
DEBUG - 2023-09-25 21:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:07:54 --> Input Class Initialized
INFO - 2023-09-25 21:07:54 --> Language Class Initialized
INFO - 2023-09-25 21:07:54 --> Language Class Initialized
INFO - 2023-09-25 21:07:54 --> Config Class Initialized
INFO - 2023-09-25 21:07:54 --> Loader Class Initialized
INFO - 2023-09-25 21:07:54 --> Helper loaded: url_helper
INFO - 2023-09-25 21:07:54 --> Helper loaded: file_helper
INFO - 2023-09-25 21:07:54 --> Helper loaded: form_helper
INFO - 2023-09-25 21:07:54 --> Helper loaded: my_helper
INFO - 2023-09-25 21:07:54 --> Database Driver Class Initialized
INFO - 2023-09-25 21:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:07:54 --> Controller Class Initialized
INFO - 2023-09-25 21:08:00 --> Config Class Initialized
INFO - 2023-09-25 21:08:00 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:00 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:00 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:00 --> URI Class Initialized
INFO - 2023-09-25 21:08:00 --> Router Class Initialized
INFO - 2023-09-25 21:08:00 --> Output Class Initialized
INFO - 2023-09-25 21:08:00 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:00 --> Input Class Initialized
INFO - 2023-09-25 21:08:00 --> Language Class Initialized
INFO - 2023-09-25 21:08:00 --> Language Class Initialized
INFO - 2023-09-25 21:08:00 --> Config Class Initialized
INFO - 2023-09-25 21:08:00 --> Loader Class Initialized
INFO - 2023-09-25 21:08:00 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:00 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:00 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:00 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:00 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:00 --> Controller Class Initialized
INFO - 2023-09-25 21:08:00 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:00 --> Total execution time: 0.0392
INFO - 2023-09-25 21:08:02 --> Config Class Initialized
INFO - 2023-09-25 21:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:02 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:02 --> URI Class Initialized
INFO - 2023-09-25 21:08:02 --> Router Class Initialized
INFO - 2023-09-25 21:08:02 --> Output Class Initialized
INFO - 2023-09-25 21:08:02 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:02 --> Input Class Initialized
INFO - 2023-09-25 21:08:02 --> Language Class Initialized
INFO - 2023-09-25 21:08:02 --> Language Class Initialized
INFO - 2023-09-25 21:08:02 --> Config Class Initialized
INFO - 2023-09-25 21:08:02 --> Loader Class Initialized
INFO - 2023-09-25 21:08:02 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:02 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:02 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:02 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:02 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:02 --> Controller Class Initialized
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:02 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:08:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:08:04 --> Config Class Initialized
INFO - 2023-09-25 21:08:04 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:04 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:04 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:04 --> URI Class Initialized
INFO - 2023-09-25 21:08:04 --> Router Class Initialized
INFO - 2023-09-25 21:08:04 --> Output Class Initialized
INFO - 2023-09-25 21:08:04 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:04 --> Input Class Initialized
INFO - 2023-09-25 21:08:04 --> Language Class Initialized
INFO - 2023-09-25 21:08:04 --> Language Class Initialized
INFO - 2023-09-25 21:08:04 --> Config Class Initialized
INFO - 2023-09-25 21:08:04 --> Loader Class Initialized
INFO - 2023-09-25 21:08:04 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:04 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:04 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:04 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:04 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:04 --> Controller Class Initialized
DEBUG - 2023-09-25 21:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:08:04 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:04 --> Total execution time: 0.0407
INFO - 2023-09-25 21:08:05 --> Config Class Initialized
INFO - 2023-09-25 21:08:05 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:05 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:05 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:05 --> URI Class Initialized
INFO - 2023-09-25 21:08:05 --> Router Class Initialized
INFO - 2023-09-25 21:08:05 --> Output Class Initialized
INFO - 2023-09-25 21:08:05 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:05 --> Input Class Initialized
INFO - 2023-09-25 21:08:05 --> Language Class Initialized
INFO - 2023-09-25 21:08:05 --> Language Class Initialized
INFO - 2023-09-25 21:08:05 --> Config Class Initialized
INFO - 2023-09-25 21:08:05 --> Loader Class Initialized
INFO - 2023-09-25 21:08:05 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:05 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:05 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:05 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:05 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:05 --> Controller Class Initialized
INFO - 2023-09-25 21:08:11 --> Config Class Initialized
INFO - 2023-09-25 21:08:11 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:11 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:11 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:11 --> URI Class Initialized
INFO - 2023-09-25 21:08:11 --> Router Class Initialized
INFO - 2023-09-25 21:08:11 --> Output Class Initialized
INFO - 2023-09-25 21:08:11 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:11 --> Input Class Initialized
INFO - 2023-09-25 21:08:11 --> Language Class Initialized
INFO - 2023-09-25 21:08:11 --> Language Class Initialized
INFO - 2023-09-25 21:08:11 --> Config Class Initialized
INFO - 2023-09-25 21:08:11 --> Loader Class Initialized
INFO - 2023-09-25 21:08:11 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:11 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:11 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:11 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:11 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:11 --> Controller Class Initialized
INFO - 2023-09-25 21:08:11 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:11 --> Total execution time: 0.1120
INFO - 2023-09-25 21:08:21 --> Config Class Initialized
INFO - 2023-09-25 21:08:21 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:21 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:21 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:21 --> URI Class Initialized
INFO - 2023-09-25 21:08:21 --> Router Class Initialized
INFO - 2023-09-25 21:08:21 --> Output Class Initialized
INFO - 2023-09-25 21:08:21 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:21 --> Input Class Initialized
INFO - 2023-09-25 21:08:21 --> Language Class Initialized
INFO - 2023-09-25 21:08:21 --> Language Class Initialized
INFO - 2023-09-25 21:08:21 --> Config Class Initialized
INFO - 2023-09-25 21:08:21 --> Loader Class Initialized
INFO - 2023-09-25 21:08:21 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:21 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:21 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:21 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:21 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:21 --> Controller Class Initialized
INFO - 2023-09-25 21:08:21 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:21 --> Total execution time: 0.0771
INFO - 2023-09-25 21:08:22 --> Config Class Initialized
INFO - 2023-09-25 21:08:22 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:22 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:22 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:22 --> URI Class Initialized
INFO - 2023-09-25 21:08:22 --> Router Class Initialized
INFO - 2023-09-25 21:08:22 --> Output Class Initialized
INFO - 2023-09-25 21:08:22 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:22 --> Input Class Initialized
INFO - 2023-09-25 21:08:22 --> Language Class Initialized
INFO - 2023-09-25 21:08:22 --> Language Class Initialized
INFO - 2023-09-25 21:08:22 --> Config Class Initialized
INFO - 2023-09-25 21:08:22 --> Loader Class Initialized
INFO - 2023-09-25 21:08:22 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:22 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:22 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:22 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:22 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:22 --> Controller Class Initialized
INFO - 2023-09-25 21:08:23 --> Config Class Initialized
INFO - 2023-09-25 21:08:23 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:23 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:23 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:23 --> URI Class Initialized
INFO - 2023-09-25 21:08:23 --> Router Class Initialized
INFO - 2023-09-25 21:08:23 --> Output Class Initialized
INFO - 2023-09-25 21:08:23 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:23 --> Input Class Initialized
INFO - 2023-09-25 21:08:23 --> Language Class Initialized
INFO - 2023-09-25 21:08:23 --> Language Class Initialized
INFO - 2023-09-25 21:08:23 --> Config Class Initialized
INFO - 2023-09-25 21:08:23 --> Loader Class Initialized
INFO - 2023-09-25 21:08:23 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:23 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:23 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:23 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:23 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:23 --> Controller Class Initialized
INFO - 2023-09-25 21:08:24 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:24 --> Total execution time: 0.0901
INFO - 2023-09-25 21:08:26 --> Config Class Initialized
INFO - 2023-09-25 21:08:26 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:26 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:26 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:26 --> URI Class Initialized
INFO - 2023-09-25 21:08:26 --> Router Class Initialized
INFO - 2023-09-25 21:08:26 --> Output Class Initialized
INFO - 2023-09-25 21:08:26 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:26 --> Input Class Initialized
INFO - 2023-09-25 21:08:26 --> Language Class Initialized
INFO - 2023-09-25 21:08:26 --> Language Class Initialized
INFO - 2023-09-25 21:08:26 --> Config Class Initialized
INFO - 2023-09-25 21:08:26 --> Loader Class Initialized
INFO - 2023-09-25 21:08:26 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:26 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:26 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:26 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:26 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:26 --> Controller Class Initialized
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:26 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:08:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:08:29 --> Config Class Initialized
INFO - 2023-09-25 21:08:29 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:29 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:29 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:29 --> URI Class Initialized
INFO - 2023-09-25 21:08:29 --> Router Class Initialized
INFO - 2023-09-25 21:08:29 --> Output Class Initialized
INFO - 2023-09-25 21:08:29 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:29 --> Input Class Initialized
INFO - 2023-09-25 21:08:29 --> Language Class Initialized
INFO - 2023-09-25 21:08:29 --> Language Class Initialized
INFO - 2023-09-25 21:08:29 --> Config Class Initialized
INFO - 2023-09-25 21:08:29 --> Loader Class Initialized
INFO - 2023-09-25 21:08:29 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:29 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:29 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:29 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:29 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:29 --> Controller Class Initialized
DEBUG - 2023-09-25 21:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:08:29 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:29 --> Total execution time: 0.0512
INFO - 2023-09-25 21:08:30 --> Config Class Initialized
INFO - 2023-09-25 21:08:30 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:30 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:30 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:30 --> URI Class Initialized
INFO - 2023-09-25 21:08:30 --> Router Class Initialized
INFO - 2023-09-25 21:08:30 --> Output Class Initialized
INFO - 2023-09-25 21:08:30 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:30 --> Input Class Initialized
INFO - 2023-09-25 21:08:30 --> Language Class Initialized
INFO - 2023-09-25 21:08:30 --> Language Class Initialized
INFO - 2023-09-25 21:08:30 --> Config Class Initialized
INFO - 2023-09-25 21:08:30 --> Loader Class Initialized
INFO - 2023-09-25 21:08:30 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:30 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:30 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:30 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:30 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:30 --> Controller Class Initialized
INFO - 2023-09-25 21:08:31 --> Config Class Initialized
INFO - 2023-09-25 21:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:31 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:31 --> URI Class Initialized
INFO - 2023-09-25 21:08:31 --> Router Class Initialized
INFO - 2023-09-25 21:08:31 --> Output Class Initialized
INFO - 2023-09-25 21:08:31 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:31 --> Input Class Initialized
INFO - 2023-09-25 21:08:31 --> Language Class Initialized
INFO - 2023-09-25 21:08:31 --> Language Class Initialized
INFO - 2023-09-25 21:08:31 --> Config Class Initialized
INFO - 2023-09-25 21:08:31 --> Loader Class Initialized
INFO - 2023-09-25 21:08:31 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:31 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:31 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:31 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:31 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:31 --> Controller Class Initialized
INFO - 2023-09-25 21:08:31 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:31 --> Total execution time: 0.0351
INFO - 2023-09-25 21:08:33 --> Config Class Initialized
INFO - 2023-09-25 21:08:33 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:33 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:33 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:33 --> URI Class Initialized
INFO - 2023-09-25 21:08:33 --> Router Class Initialized
INFO - 2023-09-25 21:08:33 --> Output Class Initialized
INFO - 2023-09-25 21:08:33 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:33 --> Input Class Initialized
INFO - 2023-09-25 21:08:33 --> Language Class Initialized
INFO - 2023-09-25 21:08:33 --> Language Class Initialized
INFO - 2023-09-25 21:08:33 --> Config Class Initialized
INFO - 2023-09-25 21:08:33 --> Loader Class Initialized
INFO - 2023-09-25 21:08:33 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:33 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:33 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:33 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:33 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:33 --> Controller Class Initialized
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-25 21:08:33 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-25 21:08:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-25 21:08:35 --> Config Class Initialized
INFO - 2023-09-25 21:08:35 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:35 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:35 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:35 --> URI Class Initialized
INFO - 2023-09-25 21:08:35 --> Router Class Initialized
INFO - 2023-09-25 21:08:35 --> Output Class Initialized
INFO - 2023-09-25 21:08:35 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:35 --> Input Class Initialized
INFO - 2023-09-25 21:08:35 --> Language Class Initialized
INFO - 2023-09-25 21:08:35 --> Language Class Initialized
INFO - 2023-09-25 21:08:35 --> Config Class Initialized
INFO - 2023-09-25 21:08:35 --> Loader Class Initialized
INFO - 2023-09-25 21:08:35 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:35 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:35 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:35 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:35 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:35 --> Controller Class Initialized
DEBUG - 2023-09-25 21:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-25 21:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-25 21:08:35 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:35 --> Total execution time: 0.0746
INFO - 2023-09-25 21:08:36 --> Config Class Initialized
INFO - 2023-09-25 21:08:36 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:36 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:36 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:36 --> URI Class Initialized
INFO - 2023-09-25 21:08:36 --> Router Class Initialized
INFO - 2023-09-25 21:08:36 --> Output Class Initialized
INFO - 2023-09-25 21:08:36 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:36 --> Input Class Initialized
INFO - 2023-09-25 21:08:36 --> Language Class Initialized
INFO - 2023-09-25 21:08:36 --> Language Class Initialized
INFO - 2023-09-25 21:08:36 --> Config Class Initialized
INFO - 2023-09-25 21:08:36 --> Loader Class Initialized
INFO - 2023-09-25 21:08:36 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:36 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:36 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:36 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:36 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:36 --> Controller Class Initialized
INFO - 2023-09-25 21:08:40 --> Config Class Initialized
INFO - 2023-09-25 21:08:40 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:40 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:40 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:40 --> URI Class Initialized
INFO - 2023-09-25 21:08:40 --> Router Class Initialized
INFO - 2023-09-25 21:08:40 --> Output Class Initialized
INFO - 2023-09-25 21:08:40 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:40 --> Input Class Initialized
INFO - 2023-09-25 21:08:40 --> Language Class Initialized
INFO - 2023-09-25 21:08:40 --> Language Class Initialized
INFO - 2023-09-25 21:08:40 --> Config Class Initialized
INFO - 2023-09-25 21:08:40 --> Loader Class Initialized
INFO - 2023-09-25 21:08:40 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:40 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:40 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:40 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:40 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:40 --> Controller Class Initialized
INFO - 2023-09-25 21:08:40 --> Final output sent to browser
DEBUG - 2023-09-25 21:08:40 --> Total execution time: 0.1255
INFO - 2023-09-25 21:08:41 --> Config Class Initialized
INFO - 2023-09-25 21:08:41 --> Hooks Class Initialized
DEBUG - 2023-09-25 21:08:41 --> UTF-8 Support Enabled
INFO - 2023-09-25 21:08:41 --> Utf8 Class Initialized
INFO - 2023-09-25 21:08:41 --> URI Class Initialized
INFO - 2023-09-25 21:08:41 --> Router Class Initialized
INFO - 2023-09-25 21:08:41 --> Output Class Initialized
INFO - 2023-09-25 21:08:41 --> Security Class Initialized
DEBUG - 2023-09-25 21:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-25 21:08:41 --> Input Class Initialized
INFO - 2023-09-25 21:08:41 --> Language Class Initialized
INFO - 2023-09-25 21:08:41 --> Language Class Initialized
INFO - 2023-09-25 21:08:41 --> Config Class Initialized
INFO - 2023-09-25 21:08:41 --> Loader Class Initialized
INFO - 2023-09-25 21:08:41 --> Helper loaded: url_helper
INFO - 2023-09-25 21:08:41 --> Helper loaded: file_helper
INFO - 2023-09-25 21:08:41 --> Helper loaded: form_helper
INFO - 2023-09-25 21:08:41 --> Helper loaded: my_helper
INFO - 2023-09-25 21:08:41 --> Database Driver Class Initialized
INFO - 2023-09-25 21:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-25 21:08:41 --> Controller Class Initialized
