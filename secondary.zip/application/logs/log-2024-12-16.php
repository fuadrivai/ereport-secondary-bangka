<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-16 04:57:01 --> Config Class Initialized
INFO - 2024-12-16 04:57:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 04:57:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 04:57:01 --> Utf8 Class Initialized
INFO - 2024-12-16 04:57:01 --> URI Class Initialized
INFO - 2024-12-16 04:57:01 --> Router Class Initialized
INFO - 2024-12-16 04:57:01 --> Output Class Initialized
INFO - 2024-12-16 04:57:01 --> Security Class Initialized
DEBUG - 2024-12-16 04:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 04:57:01 --> Input Class Initialized
INFO - 2024-12-16 04:57:01 --> Language Class Initialized
INFO - 2024-12-16 04:57:01 --> Language Class Initialized
INFO - 2024-12-16 04:57:01 --> Config Class Initialized
INFO - 2024-12-16 04:57:01 --> Loader Class Initialized
INFO - 2024-12-16 04:57:01 --> Helper loaded: url_helper
INFO - 2024-12-16 04:57:01 --> Helper loaded: file_helper
INFO - 2024-12-16 04:57:01 --> Helper loaded: form_helper
INFO - 2024-12-16 04:57:01 --> Helper loaded: my_helper
INFO - 2024-12-16 04:57:01 --> Database Driver Class Initialized
INFO - 2024-12-16 04:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 04:57:01 --> Controller Class Initialized
INFO - 2024-12-16 04:57:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 04:57:01 --> Final output sent to browser
DEBUG - 2024-12-16 04:57:01 --> Total execution time: 0.3813
INFO - 2024-12-16 04:57:01 --> Config Class Initialized
INFO - 2024-12-16 04:57:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 04:57:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 04:57:01 --> Utf8 Class Initialized
INFO - 2024-12-16 04:57:01 --> URI Class Initialized
INFO - 2024-12-16 04:57:01 --> Router Class Initialized
INFO - 2024-12-16 04:57:01 --> Output Class Initialized
INFO - 2024-12-16 04:57:01 --> Security Class Initialized
DEBUG - 2024-12-16 04:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 04:57:01 --> Input Class Initialized
INFO - 2024-12-16 04:57:02 --> Language Class Initialized
INFO - 2024-12-16 04:57:02 --> Language Class Initialized
INFO - 2024-12-16 04:57:02 --> Config Class Initialized
INFO - 2024-12-16 04:57:02 --> Loader Class Initialized
INFO - 2024-12-16 04:57:02 --> Helper loaded: url_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: file_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: form_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: my_helper
INFO - 2024-12-16 04:57:02 --> Database Driver Class Initialized
INFO - 2024-12-16 04:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 04:57:02 --> Controller Class Initialized
INFO - 2024-12-16 04:57:02 --> Helper loaded: cookie_helper
INFO - 2024-12-16 04:57:02 --> Config Class Initialized
INFO - 2024-12-16 04:57:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 04:57:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 04:57:02 --> Utf8 Class Initialized
INFO - 2024-12-16 04:57:02 --> URI Class Initialized
INFO - 2024-12-16 04:57:02 --> Router Class Initialized
INFO - 2024-12-16 04:57:02 --> Output Class Initialized
INFO - 2024-12-16 04:57:02 --> Security Class Initialized
DEBUG - 2024-12-16 04:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 04:57:02 --> Input Class Initialized
INFO - 2024-12-16 04:57:02 --> Language Class Initialized
INFO - 2024-12-16 04:57:02 --> Language Class Initialized
INFO - 2024-12-16 04:57:02 --> Config Class Initialized
INFO - 2024-12-16 04:57:02 --> Loader Class Initialized
INFO - 2024-12-16 04:57:02 --> Helper loaded: url_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: file_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: form_helper
INFO - 2024-12-16 04:57:02 --> Helper loaded: my_helper
INFO - 2024-12-16 04:57:02 --> Database Driver Class Initialized
INFO - 2024-12-16 04:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 04:57:02 --> Controller Class Initialized
DEBUG - 2024-12-16 04:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 04:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 04:57:02 --> Final output sent to browser
DEBUG - 2024-12-16 04:57:02 --> Total execution time: 0.2154
INFO - 2024-12-16 04:57:14 --> Config Class Initialized
INFO - 2024-12-16 04:57:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 04:57:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 04:57:14 --> Utf8 Class Initialized
INFO - 2024-12-16 04:57:14 --> URI Class Initialized
INFO - 2024-12-16 04:57:14 --> Router Class Initialized
INFO - 2024-12-16 04:57:14 --> Output Class Initialized
INFO - 2024-12-16 04:57:14 --> Security Class Initialized
DEBUG - 2024-12-16 04:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 04:57:14 --> Input Class Initialized
INFO - 2024-12-16 04:57:14 --> Language Class Initialized
INFO - 2024-12-16 04:57:14 --> Language Class Initialized
INFO - 2024-12-16 04:57:14 --> Config Class Initialized
INFO - 2024-12-16 04:57:14 --> Loader Class Initialized
INFO - 2024-12-16 04:57:14 --> Helper loaded: url_helper
INFO - 2024-12-16 04:57:14 --> Helper loaded: file_helper
INFO - 2024-12-16 04:57:14 --> Helper loaded: form_helper
INFO - 2024-12-16 04:57:14 --> Helper loaded: my_helper
INFO - 2024-12-16 04:57:14 --> Database Driver Class Initialized
INFO - 2024-12-16 04:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 04:57:14 --> Controller Class Initialized
DEBUG - 2024-12-16 04:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 04:57:19 --> Final output sent to browser
DEBUG - 2024-12-16 04:57:19 --> Total execution time: 4.4313
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:24:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:24:19 --> Utf8 Class Initialized
INFO - 2024-12-16 07:24:19 --> URI Class Initialized
INFO - 2024-12-16 07:24:19 --> Router Class Initialized
INFO - 2024-12-16 07:24:19 --> Output Class Initialized
INFO - 2024-12-16 07:24:19 --> Security Class Initialized
DEBUG - 2024-12-16 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:24:19 --> Input Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Loader Class Initialized
INFO - 2024-12-16 07:24:19 --> Helper loaded: url_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: file_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: form_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: my_helper
INFO - 2024-12-16 07:24:19 --> Database Driver Class Initialized
INFO - 2024-12-16 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:24:19 --> Controller Class Initialized
INFO - 2024-12-16 07:24:19 --> Helper loaded: cookie_helper
INFO - 2024-12-16 07:24:19 --> Final output sent to browser
DEBUG - 2024-12-16 07:24:19 --> Total execution time: 0.0911
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:24:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:24:19 --> Utf8 Class Initialized
INFO - 2024-12-16 07:24:19 --> URI Class Initialized
INFO - 2024-12-16 07:24:19 --> Router Class Initialized
INFO - 2024-12-16 07:24:19 --> Output Class Initialized
INFO - 2024-12-16 07:24:19 --> Security Class Initialized
DEBUG - 2024-12-16 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:24:19 --> Input Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Loader Class Initialized
INFO - 2024-12-16 07:24:19 --> Helper loaded: url_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: file_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: form_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: my_helper
INFO - 2024-12-16 07:24:19 --> Database Driver Class Initialized
INFO - 2024-12-16 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:24:19 --> Controller Class Initialized
INFO - 2024-12-16 07:24:19 --> Helper loaded: cookie_helper
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:24:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:24:19 --> Utf8 Class Initialized
INFO - 2024-12-16 07:24:19 --> URI Class Initialized
INFO - 2024-12-16 07:24:19 --> Router Class Initialized
INFO - 2024-12-16 07:24:19 --> Output Class Initialized
INFO - 2024-12-16 07:24:19 --> Security Class Initialized
DEBUG - 2024-12-16 07:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:24:19 --> Input Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Language Class Initialized
INFO - 2024-12-16 07:24:19 --> Config Class Initialized
INFO - 2024-12-16 07:24:19 --> Loader Class Initialized
INFO - 2024-12-16 07:24:19 --> Helper loaded: url_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: file_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: form_helper
INFO - 2024-12-16 07:24:19 --> Helper loaded: my_helper
INFO - 2024-12-16 07:24:19 --> Database Driver Class Initialized
INFO - 2024-12-16 07:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:24:19 --> Controller Class Initialized
DEBUG - 2024-12-16 07:24:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 07:24:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 07:24:19 --> Final output sent to browser
DEBUG - 2024-12-16 07:24:19 --> Total execution time: 0.0349
INFO - 2024-12-16 07:24:29 --> Config Class Initialized
INFO - 2024-12-16 07:24:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:24:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:24:29 --> Utf8 Class Initialized
INFO - 2024-12-16 07:24:29 --> URI Class Initialized
INFO - 2024-12-16 07:24:29 --> Router Class Initialized
INFO - 2024-12-16 07:24:29 --> Output Class Initialized
INFO - 2024-12-16 07:24:29 --> Security Class Initialized
DEBUG - 2024-12-16 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:24:29 --> Input Class Initialized
INFO - 2024-12-16 07:24:29 --> Language Class Initialized
INFO - 2024-12-16 07:24:29 --> Language Class Initialized
INFO - 2024-12-16 07:24:29 --> Config Class Initialized
INFO - 2024-12-16 07:24:29 --> Loader Class Initialized
INFO - 2024-12-16 07:24:29 --> Helper loaded: url_helper
INFO - 2024-12-16 07:24:29 --> Helper loaded: file_helper
INFO - 2024-12-16 07:24:29 --> Helper loaded: form_helper
INFO - 2024-12-16 07:24:29 --> Helper loaded: my_helper
INFO - 2024-12-16 07:24:29 --> Database Driver Class Initialized
INFO - 2024-12-16 07:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:24:29 --> Controller Class Initialized
ERROR - 2024-12-16 07:24:29 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 07:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 07:24:32 --> Final output sent to browser
DEBUG - 2024-12-16 07:24:32 --> Total execution time: 3.5539
INFO - 2024-12-16 07:25:12 --> Config Class Initialized
INFO - 2024-12-16 07:25:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:25:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:25:12 --> Utf8 Class Initialized
INFO - 2024-12-16 07:25:12 --> URI Class Initialized
INFO - 2024-12-16 07:25:12 --> Router Class Initialized
INFO - 2024-12-16 07:25:12 --> Output Class Initialized
INFO - 2024-12-16 07:25:12 --> Security Class Initialized
DEBUG - 2024-12-16 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:25:12 --> Input Class Initialized
INFO - 2024-12-16 07:25:12 --> Language Class Initialized
INFO - 2024-12-16 07:25:12 --> Language Class Initialized
INFO - 2024-12-16 07:25:12 --> Config Class Initialized
INFO - 2024-12-16 07:25:12 --> Loader Class Initialized
INFO - 2024-12-16 07:25:12 --> Helper loaded: url_helper
INFO - 2024-12-16 07:25:12 --> Helper loaded: file_helper
INFO - 2024-12-16 07:25:12 --> Helper loaded: form_helper
INFO - 2024-12-16 07:25:12 --> Helper loaded: my_helper
INFO - 2024-12-16 07:25:12 --> Database Driver Class Initialized
INFO - 2024-12-16 07:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:25:12 --> Controller Class Initialized
DEBUG - 2024-12-16 07:25:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 07:25:16 --> Final output sent to browser
DEBUG - 2024-12-16 07:25:16 --> Total execution time: 3.5843
INFO - 2024-12-16 07:25:39 --> Config Class Initialized
INFO - 2024-12-16 07:25:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:25:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:25:39 --> Utf8 Class Initialized
INFO - 2024-12-16 07:25:39 --> URI Class Initialized
INFO - 2024-12-16 07:25:39 --> Router Class Initialized
INFO - 2024-12-16 07:25:39 --> Output Class Initialized
INFO - 2024-12-16 07:25:39 --> Security Class Initialized
DEBUG - 2024-12-16 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:25:39 --> Input Class Initialized
INFO - 2024-12-16 07:25:39 --> Language Class Initialized
INFO - 2024-12-16 07:25:39 --> Language Class Initialized
INFO - 2024-12-16 07:25:39 --> Config Class Initialized
INFO - 2024-12-16 07:25:39 --> Loader Class Initialized
INFO - 2024-12-16 07:25:39 --> Helper loaded: url_helper
INFO - 2024-12-16 07:25:39 --> Helper loaded: file_helper
INFO - 2024-12-16 07:25:39 --> Helper loaded: form_helper
INFO - 2024-12-16 07:25:39 --> Helper loaded: my_helper
INFO - 2024-12-16 07:25:39 --> Database Driver Class Initialized
INFO - 2024-12-16 07:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:25:39 --> Controller Class Initialized
DEBUG - 2024-12-16 07:25:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 07:25:43 --> Final output sent to browser
DEBUG - 2024-12-16 07:25:43 --> Total execution time: 4.3057
INFO - 2024-12-16 07:27:30 --> Config Class Initialized
INFO - 2024-12-16 07:27:30 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:27:30 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:27:30 --> Utf8 Class Initialized
INFO - 2024-12-16 07:27:30 --> URI Class Initialized
INFO - 2024-12-16 07:27:30 --> Router Class Initialized
INFO - 2024-12-16 07:27:30 --> Output Class Initialized
INFO - 2024-12-16 07:27:30 --> Security Class Initialized
DEBUG - 2024-12-16 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:27:30 --> Input Class Initialized
INFO - 2024-12-16 07:27:30 --> Language Class Initialized
INFO - 2024-12-16 07:27:30 --> Language Class Initialized
INFO - 2024-12-16 07:27:30 --> Config Class Initialized
INFO - 2024-12-16 07:27:30 --> Loader Class Initialized
INFO - 2024-12-16 07:27:30 --> Helper loaded: url_helper
INFO - 2024-12-16 07:27:30 --> Helper loaded: file_helper
INFO - 2024-12-16 07:27:30 --> Helper loaded: form_helper
INFO - 2024-12-16 07:27:30 --> Helper loaded: my_helper
INFO - 2024-12-16 07:27:30 --> Database Driver Class Initialized
INFO - 2024-12-16 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:27:30 --> Controller Class Initialized
DEBUG - 2024-12-16 07:27:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 07:27:31 --> Final output sent to browser
DEBUG - 2024-12-16 07:27:31 --> Total execution time: 1.7742
INFO - 2024-12-16 07:29:07 --> Config Class Initialized
INFO - 2024-12-16 07:29:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 07:29:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 07:29:07 --> Utf8 Class Initialized
INFO - 2024-12-16 07:29:07 --> URI Class Initialized
INFO - 2024-12-16 07:29:07 --> Router Class Initialized
INFO - 2024-12-16 07:29:07 --> Output Class Initialized
INFO - 2024-12-16 07:29:07 --> Security Class Initialized
DEBUG - 2024-12-16 07:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 07:29:07 --> Input Class Initialized
INFO - 2024-12-16 07:29:07 --> Language Class Initialized
INFO - 2024-12-16 07:29:07 --> Language Class Initialized
INFO - 2024-12-16 07:29:07 --> Config Class Initialized
INFO - 2024-12-16 07:29:07 --> Loader Class Initialized
INFO - 2024-12-16 07:29:07 --> Helper loaded: url_helper
INFO - 2024-12-16 07:29:07 --> Helper loaded: file_helper
INFO - 2024-12-16 07:29:07 --> Helper loaded: form_helper
INFO - 2024-12-16 07:29:07 --> Helper loaded: my_helper
INFO - 2024-12-16 07:29:07 --> Database Driver Class Initialized
INFO - 2024-12-16 07:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 07:29:07 --> Controller Class Initialized
DEBUG - 2024-12-16 07:29:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 07:29:11 --> Final output sent to browser
DEBUG - 2024-12-16 07:29:11 --> Total execution time: 3.8439
INFO - 2024-12-16 09:07:00 --> Config Class Initialized
INFO - 2024-12-16 09:07:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:00 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:00 --> URI Class Initialized
INFO - 2024-12-16 09:07:00 --> Router Class Initialized
INFO - 2024-12-16 09:07:00 --> Output Class Initialized
INFO - 2024-12-16 09:07:00 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:00 --> Input Class Initialized
INFO - 2024-12-16 09:07:00 --> Language Class Initialized
INFO - 2024-12-16 09:07:01 --> Language Class Initialized
INFO - 2024-12-16 09:07:01 --> Config Class Initialized
INFO - 2024-12-16 09:07:01 --> Loader Class Initialized
INFO - 2024-12-16 09:07:01 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:01 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:01 --> Controller Class Initialized
INFO - 2024-12-16 09:07:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:07:01 --> Final output sent to browser
DEBUG - 2024-12-16 09:07:01 --> Total execution time: 0.0600
INFO - 2024-12-16 09:07:01 --> Config Class Initialized
INFO - 2024-12-16 09:07:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:01 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:01 --> URI Class Initialized
INFO - 2024-12-16 09:07:01 --> Router Class Initialized
INFO - 2024-12-16 09:07:01 --> Output Class Initialized
INFO - 2024-12-16 09:07:01 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:01 --> Input Class Initialized
INFO - 2024-12-16 09:07:01 --> Language Class Initialized
INFO - 2024-12-16 09:07:01 --> Language Class Initialized
INFO - 2024-12-16 09:07:01 --> Config Class Initialized
INFO - 2024-12-16 09:07:01 --> Loader Class Initialized
INFO - 2024-12-16 09:07:01 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:01 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:01 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:01 --> Controller Class Initialized
INFO - 2024-12-16 09:07:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:07:02 --> Config Class Initialized
INFO - 2024-12-16 09:07:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:02 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:02 --> URI Class Initialized
INFO - 2024-12-16 09:07:02 --> Router Class Initialized
INFO - 2024-12-16 09:07:02 --> Output Class Initialized
INFO - 2024-12-16 09:07:02 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:02 --> Input Class Initialized
INFO - 2024-12-16 09:07:02 --> Language Class Initialized
INFO - 2024-12-16 09:07:02 --> Language Class Initialized
INFO - 2024-12-16 09:07:02 --> Config Class Initialized
INFO - 2024-12-16 09:07:02 --> Loader Class Initialized
INFO - 2024-12-16 09:07:02 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:02 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:02 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:02 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:02 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:02 --> Controller Class Initialized
DEBUG - 2024-12-16 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:07:02 --> Final output sent to browser
DEBUG - 2024-12-16 09:07:02 --> Total execution time: 0.1103
INFO - 2024-12-16 09:07:18 --> Config Class Initialized
INFO - 2024-12-16 09:07:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:18 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:18 --> URI Class Initialized
INFO - 2024-12-16 09:07:18 --> Router Class Initialized
INFO - 2024-12-16 09:07:18 --> Output Class Initialized
INFO - 2024-12-16 09:07:18 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:18 --> Input Class Initialized
INFO - 2024-12-16 09:07:18 --> Language Class Initialized
INFO - 2024-12-16 09:07:18 --> Language Class Initialized
INFO - 2024-12-16 09:07:18 --> Config Class Initialized
INFO - 2024-12-16 09:07:18 --> Loader Class Initialized
INFO - 2024-12-16 09:07:18 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:18 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:18 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:18 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:18 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:18 --> Controller Class Initialized
DEBUG - 2024-12-16 09:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:07:23 --> Final output sent to browser
DEBUG - 2024-12-16 09:07:23 --> Total execution time: 5.0041
INFO - 2024-12-16 09:07:48 --> Config Class Initialized
INFO - 2024-12-16 09:07:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:48 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:48 --> URI Class Initialized
INFO - 2024-12-16 09:07:48 --> Router Class Initialized
INFO - 2024-12-16 09:07:48 --> Output Class Initialized
INFO - 2024-12-16 09:07:48 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:48 --> Input Class Initialized
INFO - 2024-12-16 09:07:48 --> Language Class Initialized
INFO - 2024-12-16 09:07:48 --> Language Class Initialized
INFO - 2024-12-16 09:07:48 --> Config Class Initialized
INFO - 2024-12-16 09:07:48 --> Loader Class Initialized
INFO - 2024-12-16 09:07:48 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:48 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:48 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:48 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:48 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:48 --> Controller Class Initialized
INFO - 2024-12-16 09:07:48 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:07:48 --> Final output sent to browser
DEBUG - 2024-12-16 09:07:48 --> Total execution time: 0.2797
INFO - 2024-12-16 09:07:49 --> Config Class Initialized
INFO - 2024-12-16 09:07:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:49 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:49 --> URI Class Initialized
INFO - 2024-12-16 09:07:49 --> Router Class Initialized
INFO - 2024-12-16 09:07:49 --> Output Class Initialized
INFO - 2024-12-16 09:07:49 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:49 --> Input Class Initialized
INFO - 2024-12-16 09:07:49 --> Language Class Initialized
INFO - 2024-12-16 09:07:49 --> Language Class Initialized
INFO - 2024-12-16 09:07:49 --> Config Class Initialized
INFO - 2024-12-16 09:07:49 --> Loader Class Initialized
INFO - 2024-12-16 09:07:49 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:49 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:49 --> Controller Class Initialized
INFO - 2024-12-16 09:07:49 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:07:49 --> Config Class Initialized
INFO - 2024-12-16 09:07:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:07:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:07:49 --> Utf8 Class Initialized
INFO - 2024-12-16 09:07:49 --> URI Class Initialized
INFO - 2024-12-16 09:07:49 --> Router Class Initialized
INFO - 2024-12-16 09:07:49 --> Output Class Initialized
INFO - 2024-12-16 09:07:49 --> Security Class Initialized
DEBUG - 2024-12-16 09:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:07:49 --> Input Class Initialized
INFO - 2024-12-16 09:07:49 --> Language Class Initialized
INFO - 2024-12-16 09:07:49 --> Language Class Initialized
INFO - 2024-12-16 09:07:49 --> Config Class Initialized
INFO - 2024-12-16 09:07:49 --> Loader Class Initialized
INFO - 2024-12-16 09:07:49 --> Helper loaded: url_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: file_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: form_helper
INFO - 2024-12-16 09:07:49 --> Helper loaded: my_helper
INFO - 2024-12-16 09:07:49 --> Database Driver Class Initialized
INFO - 2024-12-16 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:07:49 --> Controller Class Initialized
DEBUG - 2024-12-16 09:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:07:49 --> Final output sent to browser
DEBUG - 2024-12-16 09:07:49 --> Total execution time: 0.1814
INFO - 2024-12-16 09:08:00 --> Config Class Initialized
INFO - 2024-12-16 09:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:08:00 --> Utf8 Class Initialized
INFO - 2024-12-16 09:08:00 --> URI Class Initialized
INFO - 2024-12-16 09:08:00 --> Router Class Initialized
INFO - 2024-12-16 09:08:00 --> Output Class Initialized
INFO - 2024-12-16 09:08:00 --> Security Class Initialized
DEBUG - 2024-12-16 09:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:08:00 --> Input Class Initialized
INFO - 2024-12-16 09:08:00 --> Language Class Initialized
INFO - 2024-12-16 09:08:00 --> Language Class Initialized
INFO - 2024-12-16 09:08:00 --> Config Class Initialized
INFO - 2024-12-16 09:08:00 --> Loader Class Initialized
INFO - 2024-12-16 09:08:00 --> Helper loaded: url_helper
INFO - 2024-12-16 09:08:00 --> Helper loaded: file_helper
INFO - 2024-12-16 09:08:00 --> Helper loaded: form_helper
INFO - 2024-12-16 09:08:00 --> Helper loaded: my_helper
INFO - 2024-12-16 09:08:00 --> Database Driver Class Initialized
INFO - 2024-12-16 09:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:08:00 --> Controller Class Initialized
DEBUG - 2024-12-16 09:08:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 09:08:05 --> Final output sent to browser
DEBUG - 2024-12-16 09:08:05 --> Total execution time: 5.2512
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:18:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:18:46 --> Utf8 Class Initialized
INFO - 2024-12-16 09:18:46 --> URI Class Initialized
INFO - 2024-12-16 09:18:46 --> Router Class Initialized
INFO - 2024-12-16 09:18:46 --> Output Class Initialized
INFO - 2024-12-16 09:18:46 --> Security Class Initialized
DEBUG - 2024-12-16 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:18:46 --> Input Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Loader Class Initialized
INFO - 2024-12-16 09:18:46 --> Helper loaded: url_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: file_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: form_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: my_helper
INFO - 2024-12-16 09:18:46 --> Database Driver Class Initialized
INFO - 2024-12-16 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:18:46 --> Controller Class Initialized
INFO - 2024-12-16 09:18:46 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:18:46 --> Final output sent to browser
DEBUG - 2024-12-16 09:18:46 --> Total execution time: 0.0697
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:18:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:18:46 --> Utf8 Class Initialized
INFO - 2024-12-16 09:18:46 --> URI Class Initialized
INFO - 2024-12-16 09:18:46 --> Router Class Initialized
INFO - 2024-12-16 09:18:46 --> Output Class Initialized
INFO - 2024-12-16 09:18:46 --> Security Class Initialized
DEBUG - 2024-12-16 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:18:46 --> Input Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Loader Class Initialized
INFO - 2024-12-16 09:18:46 --> Helper loaded: url_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: file_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: form_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: my_helper
INFO - 2024-12-16 09:18:46 --> Database Driver Class Initialized
INFO - 2024-12-16 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:18:46 --> Controller Class Initialized
INFO - 2024-12-16 09:18:46 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:18:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:18:46 --> Utf8 Class Initialized
INFO - 2024-12-16 09:18:46 --> URI Class Initialized
INFO - 2024-12-16 09:18:46 --> Router Class Initialized
INFO - 2024-12-16 09:18:46 --> Output Class Initialized
INFO - 2024-12-16 09:18:46 --> Security Class Initialized
DEBUG - 2024-12-16 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:18:46 --> Input Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Language Class Initialized
INFO - 2024-12-16 09:18:46 --> Config Class Initialized
INFO - 2024-12-16 09:18:46 --> Loader Class Initialized
INFO - 2024-12-16 09:18:46 --> Helper loaded: url_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: file_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: form_helper
INFO - 2024-12-16 09:18:46 --> Helper loaded: my_helper
INFO - 2024-12-16 09:18:46 --> Database Driver Class Initialized
INFO - 2024-12-16 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:18:46 --> Controller Class Initialized
DEBUG - 2024-12-16 09:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:18:46 --> Final output sent to browser
DEBUG - 2024-12-16 09:18:46 --> Total execution time: 0.0651
INFO - 2024-12-16 09:18:50 --> Config Class Initialized
INFO - 2024-12-16 09:18:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:18:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:18:50 --> Utf8 Class Initialized
INFO - 2024-12-16 09:18:50 --> URI Class Initialized
INFO - 2024-12-16 09:18:50 --> Router Class Initialized
INFO - 2024-12-16 09:18:50 --> Output Class Initialized
INFO - 2024-12-16 09:18:50 --> Security Class Initialized
DEBUG - 2024-12-16 09:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:18:50 --> Input Class Initialized
INFO - 2024-12-16 09:18:50 --> Language Class Initialized
INFO - 2024-12-16 09:18:52 --> Language Class Initialized
INFO - 2024-12-16 09:18:52 --> Config Class Initialized
INFO - 2024-12-16 09:18:52 --> Loader Class Initialized
INFO - 2024-12-16 09:18:52 --> Helper loaded: url_helper
INFO - 2024-12-16 09:18:52 --> Helper loaded: file_helper
INFO - 2024-12-16 09:18:52 --> Helper loaded: form_helper
INFO - 2024-12-16 09:18:52 --> Helper loaded: my_helper
INFO - 2024-12-16 09:18:52 --> Database Driver Class Initialized
INFO - 2024-12-16 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:18:52 --> Controller Class Initialized
DEBUG - 2024-12-16 09:18:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 09:19:01 --> Final output sent to browser
DEBUG - 2024-12-16 09:19:01 --> Total execution time: 10.6446
INFO - 2024-12-16 09:19:41 --> Config Class Initialized
INFO - 2024-12-16 09:19:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:19:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:19:41 --> Utf8 Class Initialized
INFO - 2024-12-16 09:19:41 --> URI Class Initialized
INFO - 2024-12-16 09:19:41 --> Router Class Initialized
INFO - 2024-12-16 09:19:41 --> Output Class Initialized
INFO - 2024-12-16 09:19:41 --> Security Class Initialized
DEBUG - 2024-12-16 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:19:41 --> Input Class Initialized
INFO - 2024-12-16 09:19:41 --> Language Class Initialized
INFO - 2024-12-16 09:19:41 --> Language Class Initialized
INFO - 2024-12-16 09:19:41 --> Config Class Initialized
INFO - 2024-12-16 09:19:41 --> Loader Class Initialized
INFO - 2024-12-16 09:19:41 --> Helper loaded: url_helper
INFO - 2024-12-16 09:19:41 --> Helper loaded: file_helper
INFO - 2024-12-16 09:19:41 --> Helper loaded: form_helper
INFO - 2024-12-16 09:19:41 --> Helper loaded: my_helper
INFO - 2024-12-16 09:19:41 --> Database Driver Class Initialized
INFO - 2024-12-16 09:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:19:41 --> Controller Class Initialized
INFO - 2024-12-16 09:19:41 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:19:41 --> Final output sent to browser
DEBUG - 2024-12-16 09:19:41 --> Total execution time: 0.0703
INFO - 2024-12-16 09:19:42 --> Config Class Initialized
INFO - 2024-12-16 09:19:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:19:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:19:42 --> Utf8 Class Initialized
INFO - 2024-12-16 09:19:42 --> URI Class Initialized
INFO - 2024-12-16 09:19:42 --> Router Class Initialized
INFO - 2024-12-16 09:19:42 --> Output Class Initialized
INFO - 2024-12-16 09:19:42 --> Security Class Initialized
DEBUG - 2024-12-16 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:19:42 --> Input Class Initialized
INFO - 2024-12-16 09:19:42 --> Language Class Initialized
INFO - 2024-12-16 09:19:42 --> Language Class Initialized
INFO - 2024-12-16 09:19:42 --> Config Class Initialized
INFO - 2024-12-16 09:19:42 --> Loader Class Initialized
INFO - 2024-12-16 09:19:42 --> Helper loaded: url_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: file_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: form_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: my_helper
INFO - 2024-12-16 09:19:42 --> Database Driver Class Initialized
INFO - 2024-12-16 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:19:42 --> Controller Class Initialized
INFO - 2024-12-16 09:19:42 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:19:42 --> Config Class Initialized
INFO - 2024-12-16 09:19:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:19:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:19:42 --> Utf8 Class Initialized
INFO - 2024-12-16 09:19:42 --> URI Class Initialized
INFO - 2024-12-16 09:19:42 --> Router Class Initialized
INFO - 2024-12-16 09:19:42 --> Output Class Initialized
INFO - 2024-12-16 09:19:42 --> Security Class Initialized
DEBUG - 2024-12-16 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:19:42 --> Input Class Initialized
INFO - 2024-12-16 09:19:42 --> Language Class Initialized
INFO - 2024-12-16 09:19:42 --> Language Class Initialized
INFO - 2024-12-16 09:19:42 --> Config Class Initialized
INFO - 2024-12-16 09:19:42 --> Loader Class Initialized
INFO - 2024-12-16 09:19:42 --> Helper loaded: url_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: file_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: form_helper
INFO - 2024-12-16 09:19:42 --> Helper loaded: my_helper
INFO - 2024-12-16 09:19:42 --> Database Driver Class Initialized
INFO - 2024-12-16 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:19:42 --> Controller Class Initialized
DEBUG - 2024-12-16 09:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:19:42 --> Final output sent to browser
DEBUG - 2024-12-16 09:19:42 --> Total execution time: 0.0470
INFO - 2024-12-16 09:19:58 --> Config Class Initialized
INFO - 2024-12-16 09:19:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:19:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:19:58 --> Utf8 Class Initialized
INFO - 2024-12-16 09:19:58 --> URI Class Initialized
INFO - 2024-12-16 09:19:58 --> Router Class Initialized
INFO - 2024-12-16 09:19:58 --> Output Class Initialized
INFO - 2024-12-16 09:19:58 --> Security Class Initialized
DEBUG - 2024-12-16 09:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:19:58 --> Input Class Initialized
INFO - 2024-12-16 09:19:58 --> Language Class Initialized
INFO - 2024-12-16 09:19:58 --> Language Class Initialized
INFO - 2024-12-16 09:19:58 --> Config Class Initialized
INFO - 2024-12-16 09:19:58 --> Loader Class Initialized
INFO - 2024-12-16 09:19:58 --> Helper loaded: url_helper
INFO - 2024-12-16 09:19:58 --> Helper loaded: file_helper
INFO - 2024-12-16 09:19:58 --> Helper loaded: form_helper
INFO - 2024-12-16 09:19:58 --> Helper loaded: my_helper
INFO - 2024-12-16 09:19:58 --> Database Driver Class Initialized
INFO - 2024-12-16 09:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:19:58 --> Controller Class Initialized
DEBUG - 2024-12-16 09:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:20:07 --> Final output sent to browser
DEBUG - 2024-12-16 09:20:07 --> Total execution time: 9.0494
INFO - 2024-12-16 09:20:24 --> Config Class Initialized
INFO - 2024-12-16 09:20:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:20:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:20:24 --> Utf8 Class Initialized
INFO - 2024-12-16 09:20:24 --> URI Class Initialized
INFO - 2024-12-16 09:20:24 --> Router Class Initialized
INFO - 2024-12-16 09:20:24 --> Output Class Initialized
INFO - 2024-12-16 09:20:24 --> Security Class Initialized
DEBUG - 2024-12-16 09:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:20:24 --> Input Class Initialized
INFO - 2024-12-16 09:20:24 --> Language Class Initialized
INFO - 2024-12-16 09:20:24 --> Language Class Initialized
INFO - 2024-12-16 09:20:24 --> Config Class Initialized
INFO - 2024-12-16 09:20:24 --> Loader Class Initialized
INFO - 2024-12-16 09:20:24 --> Helper loaded: url_helper
INFO - 2024-12-16 09:20:24 --> Helper loaded: file_helper
INFO - 2024-12-16 09:20:24 --> Helper loaded: form_helper
INFO - 2024-12-16 09:20:24 --> Helper loaded: my_helper
INFO - 2024-12-16 09:20:24 --> Database Driver Class Initialized
INFO - 2024-12-16 09:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:20:24 --> Controller Class Initialized
DEBUG - 2024-12-16 09:20:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:20:30 --> Final output sent to browser
DEBUG - 2024-12-16 09:20:30 --> Total execution time: 6.2128
INFO - 2024-12-16 09:21:40 --> Config Class Initialized
INFO - 2024-12-16 09:21:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:21:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:21:40 --> Utf8 Class Initialized
INFO - 2024-12-16 09:21:40 --> URI Class Initialized
INFO - 2024-12-16 09:21:40 --> Router Class Initialized
INFO - 2024-12-16 09:21:40 --> Output Class Initialized
INFO - 2024-12-16 09:21:40 --> Security Class Initialized
DEBUG - 2024-12-16 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:21:40 --> Input Class Initialized
INFO - 2024-12-16 09:21:40 --> Language Class Initialized
INFO - 2024-12-16 09:21:40 --> Language Class Initialized
INFO - 2024-12-16 09:21:40 --> Config Class Initialized
INFO - 2024-12-16 09:21:40 --> Loader Class Initialized
INFO - 2024-12-16 09:21:40 --> Helper loaded: url_helper
INFO - 2024-12-16 09:21:40 --> Helper loaded: file_helper
INFO - 2024-12-16 09:21:40 --> Helper loaded: form_helper
INFO - 2024-12-16 09:21:40 --> Helper loaded: my_helper
INFO - 2024-12-16 09:21:40 --> Database Driver Class Initialized
INFO - 2024-12-16 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:21:40 --> Controller Class Initialized
DEBUG - 2024-12-16 09:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 09:21:42 --> Final output sent to browser
DEBUG - 2024-12-16 09:21:42 --> Total execution time: 1.9154
INFO - 2024-12-16 09:21:58 --> Config Class Initialized
INFO - 2024-12-16 09:21:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:21:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:21:58 --> Utf8 Class Initialized
INFO - 2024-12-16 09:21:58 --> URI Class Initialized
INFO - 2024-12-16 09:21:58 --> Router Class Initialized
INFO - 2024-12-16 09:21:58 --> Output Class Initialized
INFO - 2024-12-16 09:21:58 --> Security Class Initialized
DEBUG - 2024-12-16 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:21:58 --> Input Class Initialized
INFO - 2024-12-16 09:21:58 --> Language Class Initialized
INFO - 2024-12-16 09:21:58 --> Language Class Initialized
INFO - 2024-12-16 09:21:58 --> Config Class Initialized
INFO - 2024-12-16 09:21:58 --> Loader Class Initialized
INFO - 2024-12-16 09:21:58 --> Helper loaded: url_helper
INFO - 2024-12-16 09:21:58 --> Helper loaded: file_helper
INFO - 2024-12-16 09:21:58 --> Helper loaded: form_helper
INFO - 2024-12-16 09:21:58 --> Helper loaded: my_helper
INFO - 2024-12-16 09:21:58 --> Database Driver Class Initialized
INFO - 2024-12-16 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:21:58 --> Controller Class Initialized
ERROR - 2024-12-16 09:21:58 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 09:21:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 09:22:07 --> Config Class Initialized
INFO - 2024-12-16 09:22:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:07 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:07 --> URI Class Initialized
INFO - 2024-12-16 09:22:07 --> Router Class Initialized
INFO - 2024-12-16 09:22:07 --> Output Class Initialized
INFO - 2024-12-16 09:22:07 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:07 --> Input Class Initialized
INFO - 2024-12-16 09:22:07 --> Language Class Initialized
INFO - 2024-12-16 09:22:08 --> Language Class Initialized
INFO - 2024-12-16 09:22:08 --> Config Class Initialized
INFO - 2024-12-16 09:22:08 --> Loader Class Initialized
INFO - 2024-12-16 09:22:08 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:08 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:08 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:08 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:08 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:08 --> Controller Class Initialized
DEBUG - 2024-12-16 09:22:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:22:10 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:10 --> Total execution time: 12.6198
INFO - 2024-12-16 09:22:17 --> Config Class Initialized
INFO - 2024-12-16 09:22:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:17 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:17 --> URI Class Initialized
INFO - 2024-12-16 09:22:17 --> Router Class Initialized
INFO - 2024-12-16 09:22:17 --> Output Class Initialized
INFO - 2024-12-16 09:22:17 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:17 --> Input Class Initialized
INFO - 2024-12-16 09:22:17 --> Language Class Initialized
INFO - 2024-12-16 09:22:17 --> Language Class Initialized
INFO - 2024-12-16 09:22:17 --> Config Class Initialized
INFO - 2024-12-16 09:22:17 --> Loader Class Initialized
INFO - 2024-12-16 09:22:17 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:17 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:17 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:17 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:17 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:17 --> Controller Class Initialized
DEBUG - 2024-12-16 09:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:22:25 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:25 --> Total execution time: 17.2751
INFO - 2024-12-16 09:22:26 --> Config Class Initialized
INFO - 2024-12-16 09:22:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:26 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:26 --> URI Class Initialized
INFO - 2024-12-16 09:22:26 --> Router Class Initialized
INFO - 2024-12-16 09:22:26 --> Output Class Initialized
INFO - 2024-12-16 09:22:26 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:26 --> Input Class Initialized
INFO - 2024-12-16 09:22:26 --> Language Class Initialized
INFO - 2024-12-16 09:22:26 --> Language Class Initialized
INFO - 2024-12-16 09:22:26 --> Config Class Initialized
INFO - 2024-12-16 09:22:26 --> Loader Class Initialized
INFO - 2024-12-16 09:22:26 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:26 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:26 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:26 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:26 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:26 --> Controller Class Initialized
INFO - 2024-12-16 09:22:27 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:22:27 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:27 --> Total execution time: 0.6952
INFO - 2024-12-16 09:22:28 --> Config Class Initialized
INFO - 2024-12-16 09:22:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:28 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:28 --> URI Class Initialized
INFO - 2024-12-16 09:22:28 --> Router Class Initialized
INFO - 2024-12-16 09:22:28 --> Output Class Initialized
INFO - 2024-12-16 09:22:28 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:28 --> Input Class Initialized
INFO - 2024-12-16 09:22:28 --> Language Class Initialized
INFO - 2024-12-16 09:22:28 --> Language Class Initialized
INFO - 2024-12-16 09:22:28 --> Config Class Initialized
INFO - 2024-12-16 09:22:28 --> Loader Class Initialized
INFO - 2024-12-16 09:22:28 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:28 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:28 --> Controller Class Initialized
INFO - 2024-12-16 09:22:28 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:22:28 --> Config Class Initialized
INFO - 2024-12-16 09:22:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:28 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:28 --> URI Class Initialized
INFO - 2024-12-16 09:22:28 --> Router Class Initialized
INFO - 2024-12-16 09:22:28 --> Output Class Initialized
INFO - 2024-12-16 09:22:28 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:28 --> Input Class Initialized
INFO - 2024-12-16 09:22:28 --> Language Class Initialized
INFO - 2024-12-16 09:22:28 --> Language Class Initialized
INFO - 2024-12-16 09:22:28 --> Config Class Initialized
INFO - 2024-12-16 09:22:28 --> Loader Class Initialized
INFO - 2024-12-16 09:22:28 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:28 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:29 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:29 --> Controller Class Initialized
DEBUG - 2024-12-16 09:22:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:22:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:22:29 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:29 --> Total execution time: 0.1613
INFO - 2024-12-16 09:22:33 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:33 --> Total execution time: 16.6703
INFO - 2024-12-16 09:22:36 --> Config Class Initialized
INFO - 2024-12-16 09:22:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:36 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:36 --> URI Class Initialized
INFO - 2024-12-16 09:22:36 --> Router Class Initialized
INFO - 2024-12-16 09:22:36 --> Output Class Initialized
INFO - 2024-12-16 09:22:36 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:36 --> Input Class Initialized
INFO - 2024-12-16 09:22:36 --> Language Class Initialized
INFO - 2024-12-16 09:22:36 --> Language Class Initialized
INFO - 2024-12-16 09:22:36 --> Config Class Initialized
INFO - 2024-12-16 09:22:36 --> Loader Class Initialized
INFO - 2024-12-16 09:22:36 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:36 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:36 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:36 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:36 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:36 --> Controller Class Initialized
DEBUG - 2024-12-16 09:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:22:39 --> Config Class Initialized
INFO - 2024-12-16 09:22:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:22:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:22:39 --> Utf8 Class Initialized
INFO - 2024-12-16 09:22:39 --> URI Class Initialized
INFO - 2024-12-16 09:22:39 --> Router Class Initialized
INFO - 2024-12-16 09:22:39 --> Output Class Initialized
INFO - 2024-12-16 09:22:39 --> Security Class Initialized
DEBUG - 2024-12-16 09:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:22:39 --> Input Class Initialized
INFO - 2024-12-16 09:22:39 --> Language Class Initialized
INFO - 2024-12-16 09:22:39 --> Language Class Initialized
INFO - 2024-12-16 09:22:39 --> Config Class Initialized
INFO - 2024-12-16 09:22:39 --> Loader Class Initialized
INFO - 2024-12-16 09:22:39 --> Helper loaded: url_helper
INFO - 2024-12-16 09:22:39 --> Helper loaded: file_helper
INFO - 2024-12-16 09:22:39 --> Helper loaded: form_helper
INFO - 2024-12-16 09:22:39 --> Helper loaded: my_helper
INFO - 2024-12-16 09:22:39 --> Database Driver Class Initialized
INFO - 2024-12-16 09:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:22:40 --> Controller Class Initialized
ERROR - 2024-12-16 09:22:40 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 09:22:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 09:22:50 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:50 --> Total execution time: 13.8939
INFO - 2024-12-16 09:22:51 --> Final output sent to browser
DEBUG - 2024-12-16 09:22:51 --> Total execution time: 11.6215
INFO - 2024-12-16 09:23:13 --> Config Class Initialized
INFO - 2024-12-16 09:23:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:23:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:23:13 --> Utf8 Class Initialized
INFO - 2024-12-16 09:23:13 --> URI Class Initialized
INFO - 2024-12-16 09:23:13 --> Router Class Initialized
INFO - 2024-12-16 09:23:13 --> Output Class Initialized
INFO - 2024-12-16 09:23:13 --> Security Class Initialized
DEBUG - 2024-12-16 09:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:23:13 --> Input Class Initialized
INFO - 2024-12-16 09:23:13 --> Language Class Initialized
INFO - 2024-12-16 09:23:13 --> Language Class Initialized
INFO - 2024-12-16 09:23:13 --> Config Class Initialized
INFO - 2024-12-16 09:23:13 --> Loader Class Initialized
INFO - 2024-12-16 09:23:13 --> Helper loaded: url_helper
INFO - 2024-12-16 09:23:13 --> Helper loaded: file_helper
INFO - 2024-12-16 09:23:13 --> Helper loaded: form_helper
INFO - 2024-12-16 09:23:13 --> Helper loaded: my_helper
INFO - 2024-12-16 09:23:13 --> Database Driver Class Initialized
INFO - 2024-12-16 09:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:23:13 --> Controller Class Initialized
DEBUG - 2024-12-16 09:23:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:23:19 --> Final output sent to browser
DEBUG - 2024-12-16 09:23:19 --> Total execution time: 5.7172
INFO - 2024-12-16 09:25:33 --> Config Class Initialized
INFO - 2024-12-16 09:25:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:25:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:25:33 --> Utf8 Class Initialized
INFO - 2024-12-16 09:25:33 --> URI Class Initialized
INFO - 2024-12-16 09:25:33 --> Router Class Initialized
INFO - 2024-12-16 09:25:33 --> Output Class Initialized
INFO - 2024-12-16 09:25:33 --> Security Class Initialized
DEBUG - 2024-12-16 09:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:25:33 --> Input Class Initialized
INFO - 2024-12-16 09:25:33 --> Language Class Initialized
INFO - 2024-12-16 09:25:33 --> Language Class Initialized
INFO - 2024-12-16 09:25:33 --> Config Class Initialized
INFO - 2024-12-16 09:25:33 --> Loader Class Initialized
INFO - 2024-12-16 09:25:33 --> Helper loaded: url_helper
INFO - 2024-12-16 09:25:33 --> Helper loaded: file_helper
INFO - 2024-12-16 09:25:33 --> Helper loaded: form_helper
INFO - 2024-12-16 09:25:33 --> Helper loaded: my_helper
INFO - 2024-12-16 09:25:33 --> Database Driver Class Initialized
INFO - 2024-12-16 09:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:25:33 --> Controller Class Initialized
DEBUG - 2024-12-16 09:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 09:25:38 --> Final output sent to browser
DEBUG - 2024-12-16 09:25:38 --> Total execution time: 4.9654
INFO - 2024-12-16 09:31:02 --> Config Class Initialized
INFO - 2024-12-16 09:31:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:31:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:31:03 --> Utf8 Class Initialized
INFO - 2024-12-16 09:31:03 --> URI Class Initialized
INFO - 2024-12-16 09:31:03 --> Router Class Initialized
INFO - 2024-12-16 09:31:03 --> Output Class Initialized
INFO - 2024-12-16 09:31:03 --> Security Class Initialized
DEBUG - 2024-12-16 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:31:03 --> Input Class Initialized
INFO - 2024-12-16 09:31:03 --> Language Class Initialized
INFO - 2024-12-16 09:31:04 --> Language Class Initialized
INFO - 2024-12-16 09:31:04 --> Config Class Initialized
INFO - 2024-12-16 09:31:04 --> Loader Class Initialized
INFO - 2024-12-16 09:31:04 --> Helper loaded: url_helper
INFO - 2024-12-16 09:31:04 --> Helper loaded: file_helper
INFO - 2024-12-16 09:31:04 --> Helper loaded: form_helper
INFO - 2024-12-16 09:31:04 --> Helper loaded: my_helper
INFO - 2024-12-16 09:31:04 --> Database Driver Class Initialized
INFO - 2024-12-16 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:31:04 --> Controller Class Initialized
DEBUG - 2024-12-16 09:31:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 09:31:12 --> Final output sent to browser
DEBUG - 2024-12-16 09:31:12 --> Total execution time: 9.9812
INFO - 2024-12-16 09:46:43 --> Config Class Initialized
INFO - 2024-12-16 09:46:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:46:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:46:43 --> Utf8 Class Initialized
INFO - 2024-12-16 09:46:43 --> URI Class Initialized
INFO - 2024-12-16 09:46:43 --> Router Class Initialized
INFO - 2024-12-16 09:46:43 --> Output Class Initialized
INFO - 2024-12-16 09:46:43 --> Security Class Initialized
DEBUG - 2024-12-16 09:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:46:43 --> Input Class Initialized
INFO - 2024-12-16 09:46:43 --> Language Class Initialized
INFO - 2024-12-16 09:46:43 --> Language Class Initialized
INFO - 2024-12-16 09:46:43 --> Config Class Initialized
INFO - 2024-12-16 09:46:43 --> Loader Class Initialized
INFO - 2024-12-16 09:46:43 --> Helper loaded: url_helper
INFO - 2024-12-16 09:46:43 --> Helper loaded: file_helper
INFO - 2024-12-16 09:46:43 --> Helper loaded: form_helper
INFO - 2024-12-16 09:46:43 --> Helper loaded: my_helper
INFO - 2024-12-16 09:46:43 --> Database Driver Class Initialized
INFO - 2024-12-16 09:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:46:43 --> Controller Class Initialized
INFO - 2024-12-16 09:46:43 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:46:43 --> Final output sent to browser
DEBUG - 2024-12-16 09:46:43 --> Total execution time: 0.0649
INFO - 2024-12-16 09:46:43 --> Config Class Initialized
INFO - 2024-12-16 09:46:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:46:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:46:43 --> Utf8 Class Initialized
INFO - 2024-12-16 09:46:44 --> URI Class Initialized
INFO - 2024-12-16 09:46:44 --> Router Class Initialized
INFO - 2024-12-16 09:46:44 --> Output Class Initialized
INFO - 2024-12-16 09:46:44 --> Security Class Initialized
DEBUG - 2024-12-16 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:46:44 --> Input Class Initialized
INFO - 2024-12-16 09:46:44 --> Language Class Initialized
INFO - 2024-12-16 09:46:44 --> Language Class Initialized
INFO - 2024-12-16 09:46:44 --> Config Class Initialized
INFO - 2024-12-16 09:46:44 --> Loader Class Initialized
INFO - 2024-12-16 09:46:44 --> Helper loaded: url_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: file_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: form_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: my_helper
INFO - 2024-12-16 09:46:44 --> Database Driver Class Initialized
INFO - 2024-12-16 09:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:46:44 --> Controller Class Initialized
INFO - 2024-12-16 09:46:44 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:46:44 --> Config Class Initialized
INFO - 2024-12-16 09:46:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:46:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:46:44 --> Utf8 Class Initialized
INFO - 2024-12-16 09:46:44 --> URI Class Initialized
INFO - 2024-12-16 09:46:44 --> Router Class Initialized
INFO - 2024-12-16 09:46:44 --> Output Class Initialized
INFO - 2024-12-16 09:46:44 --> Security Class Initialized
DEBUG - 2024-12-16 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:46:44 --> Input Class Initialized
INFO - 2024-12-16 09:46:44 --> Language Class Initialized
INFO - 2024-12-16 09:46:44 --> Language Class Initialized
INFO - 2024-12-16 09:46:44 --> Config Class Initialized
INFO - 2024-12-16 09:46:44 --> Loader Class Initialized
INFO - 2024-12-16 09:46:44 --> Helper loaded: url_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: file_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: form_helper
INFO - 2024-12-16 09:46:44 --> Helper loaded: my_helper
INFO - 2024-12-16 09:46:44 --> Database Driver Class Initialized
INFO - 2024-12-16 09:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:46:44 --> Controller Class Initialized
DEBUG - 2024-12-16 09:46:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:46:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:46:44 --> Final output sent to browser
DEBUG - 2024-12-16 09:46:44 --> Total execution time: 0.1034
INFO - 2024-12-16 09:46:50 --> Config Class Initialized
INFO - 2024-12-16 09:46:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:46:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:46:50 --> Utf8 Class Initialized
INFO - 2024-12-16 09:46:50 --> URI Class Initialized
INFO - 2024-12-16 09:46:50 --> Router Class Initialized
INFO - 2024-12-16 09:46:50 --> Output Class Initialized
INFO - 2024-12-16 09:46:50 --> Security Class Initialized
DEBUG - 2024-12-16 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:46:50 --> Input Class Initialized
INFO - 2024-12-16 09:46:50 --> Language Class Initialized
INFO - 2024-12-16 09:46:50 --> Language Class Initialized
INFO - 2024-12-16 09:46:50 --> Config Class Initialized
INFO - 2024-12-16 09:46:50 --> Loader Class Initialized
INFO - 2024-12-16 09:46:50 --> Helper loaded: url_helper
INFO - 2024-12-16 09:46:50 --> Helper loaded: file_helper
INFO - 2024-12-16 09:46:50 --> Helper loaded: form_helper
INFO - 2024-12-16 09:46:50 --> Helper loaded: my_helper
INFO - 2024-12-16 09:46:50 --> Database Driver Class Initialized
INFO - 2024-12-16 09:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:46:50 --> Controller Class Initialized
DEBUG - 2024-12-16 09:46:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 09:46:52 --> Final output sent to browser
DEBUG - 2024-12-16 09:46:52 --> Total execution time: 2.0203
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:52:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:52:17 --> Utf8 Class Initialized
INFO - 2024-12-16 09:52:17 --> URI Class Initialized
INFO - 2024-12-16 09:52:17 --> Router Class Initialized
INFO - 2024-12-16 09:52:17 --> Output Class Initialized
INFO - 2024-12-16 09:52:17 --> Security Class Initialized
DEBUG - 2024-12-16 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:52:17 --> Input Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Loader Class Initialized
INFO - 2024-12-16 09:52:17 --> Helper loaded: url_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: file_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: form_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: my_helper
INFO - 2024-12-16 09:52:17 --> Database Driver Class Initialized
INFO - 2024-12-16 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:52:17 --> Controller Class Initialized
INFO - 2024-12-16 09:52:17 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:52:17 --> Final output sent to browser
DEBUG - 2024-12-16 09:52:17 --> Total execution time: 0.0590
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:52:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:52:17 --> Utf8 Class Initialized
INFO - 2024-12-16 09:52:17 --> URI Class Initialized
INFO - 2024-12-16 09:52:17 --> Router Class Initialized
INFO - 2024-12-16 09:52:17 --> Output Class Initialized
INFO - 2024-12-16 09:52:17 --> Security Class Initialized
DEBUG - 2024-12-16 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:52:17 --> Input Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Loader Class Initialized
INFO - 2024-12-16 09:52:17 --> Helper loaded: url_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: file_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: form_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: my_helper
INFO - 2024-12-16 09:52:17 --> Database Driver Class Initialized
INFO - 2024-12-16 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:52:17 --> Controller Class Initialized
INFO - 2024-12-16 09:52:17 --> Helper loaded: cookie_helper
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:52:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:52:17 --> Utf8 Class Initialized
INFO - 2024-12-16 09:52:17 --> URI Class Initialized
INFO - 2024-12-16 09:52:17 --> Router Class Initialized
INFO - 2024-12-16 09:52:17 --> Output Class Initialized
INFO - 2024-12-16 09:52:17 --> Security Class Initialized
DEBUG - 2024-12-16 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:52:17 --> Input Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Language Class Initialized
INFO - 2024-12-16 09:52:17 --> Config Class Initialized
INFO - 2024-12-16 09:52:17 --> Loader Class Initialized
INFO - 2024-12-16 09:52:17 --> Helper loaded: url_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: file_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: form_helper
INFO - 2024-12-16 09:52:17 --> Helper loaded: my_helper
INFO - 2024-12-16 09:52:17 --> Database Driver Class Initialized
INFO - 2024-12-16 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:52:17 --> Controller Class Initialized
DEBUG - 2024-12-16 09:52:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 09:52:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 09:52:17 --> Final output sent to browser
DEBUG - 2024-12-16 09:52:17 --> Total execution time: 0.0378
INFO - 2024-12-16 09:52:20 --> Config Class Initialized
INFO - 2024-12-16 09:52:20 --> Hooks Class Initialized
DEBUG - 2024-12-16 09:52:20 --> UTF-8 Support Enabled
INFO - 2024-12-16 09:52:20 --> Utf8 Class Initialized
INFO - 2024-12-16 09:52:20 --> URI Class Initialized
INFO - 2024-12-16 09:52:20 --> Router Class Initialized
INFO - 2024-12-16 09:52:20 --> Output Class Initialized
INFO - 2024-12-16 09:52:20 --> Security Class Initialized
DEBUG - 2024-12-16 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 09:52:20 --> Input Class Initialized
INFO - 2024-12-16 09:52:20 --> Language Class Initialized
INFO - 2024-12-16 09:52:20 --> Language Class Initialized
INFO - 2024-12-16 09:52:20 --> Config Class Initialized
INFO - 2024-12-16 09:52:20 --> Loader Class Initialized
INFO - 2024-12-16 09:52:20 --> Helper loaded: url_helper
INFO - 2024-12-16 09:52:20 --> Helper loaded: file_helper
INFO - 2024-12-16 09:52:20 --> Helper loaded: form_helper
INFO - 2024-12-16 09:52:20 --> Helper loaded: my_helper
INFO - 2024-12-16 09:52:20 --> Database Driver Class Initialized
INFO - 2024-12-16 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 09:52:20 --> Controller Class Initialized
DEBUG - 2024-12-16 09:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 09:52:22 --> Final output sent to browser
DEBUG - 2024-12-16 09:52:22 --> Total execution time: 1.9863
INFO - 2024-12-16 10:02:38 --> Config Class Initialized
INFO - 2024-12-16 10:02:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:02:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:02:38 --> Utf8 Class Initialized
INFO - 2024-12-16 10:02:38 --> URI Class Initialized
INFO - 2024-12-16 10:02:38 --> Router Class Initialized
INFO - 2024-12-16 10:02:38 --> Output Class Initialized
INFO - 2024-12-16 10:02:38 --> Security Class Initialized
DEBUG - 2024-12-16 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:02:38 --> Input Class Initialized
INFO - 2024-12-16 10:02:38 --> Language Class Initialized
INFO - 2024-12-16 10:02:38 --> Language Class Initialized
INFO - 2024-12-16 10:02:38 --> Config Class Initialized
INFO - 2024-12-16 10:02:38 --> Loader Class Initialized
INFO - 2024-12-16 10:02:38 --> Helper loaded: url_helper
INFO - 2024-12-16 10:02:38 --> Helper loaded: file_helper
INFO - 2024-12-16 10:02:38 --> Helper loaded: form_helper
INFO - 2024-12-16 10:02:38 --> Helper loaded: my_helper
INFO - 2024-12-16 10:02:38 --> Database Driver Class Initialized
INFO - 2024-12-16 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:02:38 --> Controller Class Initialized
INFO - 2024-12-16 10:02:38 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:02:38 --> Final output sent to browser
DEBUG - 2024-12-16 10:02:38 --> Total execution time: 0.0705
INFO - 2024-12-16 10:02:39 --> Config Class Initialized
INFO - 2024-12-16 10:02:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:02:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:02:39 --> Utf8 Class Initialized
INFO - 2024-12-16 10:02:39 --> URI Class Initialized
INFO - 2024-12-16 10:02:39 --> Router Class Initialized
INFO - 2024-12-16 10:02:39 --> Output Class Initialized
INFO - 2024-12-16 10:02:39 --> Security Class Initialized
DEBUG - 2024-12-16 10:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:02:39 --> Input Class Initialized
INFO - 2024-12-16 10:02:39 --> Language Class Initialized
INFO - 2024-12-16 10:02:39 --> Language Class Initialized
INFO - 2024-12-16 10:02:39 --> Config Class Initialized
INFO - 2024-12-16 10:02:39 --> Loader Class Initialized
INFO - 2024-12-16 10:02:39 --> Helper loaded: url_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: file_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: form_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: my_helper
INFO - 2024-12-16 10:02:39 --> Database Driver Class Initialized
INFO - 2024-12-16 10:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:02:39 --> Controller Class Initialized
INFO - 2024-12-16 10:02:39 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:02:39 --> Config Class Initialized
INFO - 2024-12-16 10:02:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:02:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:02:39 --> Utf8 Class Initialized
INFO - 2024-12-16 10:02:39 --> URI Class Initialized
INFO - 2024-12-16 10:02:39 --> Router Class Initialized
INFO - 2024-12-16 10:02:39 --> Output Class Initialized
INFO - 2024-12-16 10:02:39 --> Security Class Initialized
DEBUG - 2024-12-16 10:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:02:39 --> Input Class Initialized
INFO - 2024-12-16 10:02:39 --> Language Class Initialized
INFO - 2024-12-16 10:02:39 --> Language Class Initialized
INFO - 2024-12-16 10:02:39 --> Config Class Initialized
INFO - 2024-12-16 10:02:39 --> Loader Class Initialized
INFO - 2024-12-16 10:02:39 --> Helper loaded: url_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: file_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: form_helper
INFO - 2024-12-16 10:02:39 --> Helper loaded: my_helper
INFO - 2024-12-16 10:02:39 --> Database Driver Class Initialized
INFO - 2024-12-16 10:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:02:39 --> Controller Class Initialized
DEBUG - 2024-12-16 10:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 10:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:02:39 --> Final output sent to browser
DEBUG - 2024-12-16 10:02:39 --> Total execution time: 0.0488
INFO - 2024-12-16 10:02:50 --> Config Class Initialized
INFO - 2024-12-16 10:02:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:02:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:02:50 --> Utf8 Class Initialized
INFO - 2024-12-16 10:02:50 --> URI Class Initialized
INFO - 2024-12-16 10:02:50 --> Router Class Initialized
INFO - 2024-12-16 10:02:50 --> Output Class Initialized
INFO - 2024-12-16 10:02:50 --> Security Class Initialized
DEBUG - 2024-12-16 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:02:50 --> Input Class Initialized
INFO - 2024-12-16 10:02:50 --> Language Class Initialized
INFO - 2024-12-16 10:02:50 --> Language Class Initialized
INFO - 2024-12-16 10:02:50 --> Config Class Initialized
INFO - 2024-12-16 10:02:50 --> Loader Class Initialized
INFO - 2024-12-16 10:02:50 --> Helper loaded: url_helper
INFO - 2024-12-16 10:02:50 --> Helper loaded: file_helper
INFO - 2024-12-16 10:02:50 --> Helper loaded: form_helper
INFO - 2024-12-16 10:02:50 --> Helper loaded: my_helper
INFO - 2024-12-16 10:02:50 --> Database Driver Class Initialized
INFO - 2024-12-16 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:02:50 --> Controller Class Initialized
DEBUG - 2024-12-16 10:02:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 10:03:04 --> Final output sent to browser
DEBUG - 2024-12-16 10:03:04 --> Total execution time: 14.0374
INFO - 2024-12-16 10:04:27 --> Config Class Initialized
INFO - 2024-12-16 10:04:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:04:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:04:27 --> Utf8 Class Initialized
INFO - 2024-12-16 10:04:27 --> URI Class Initialized
INFO - 2024-12-16 10:04:27 --> Router Class Initialized
INFO - 2024-12-16 10:04:27 --> Output Class Initialized
INFO - 2024-12-16 10:04:27 --> Security Class Initialized
DEBUG - 2024-12-16 10:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:04:27 --> Input Class Initialized
INFO - 2024-12-16 10:04:27 --> Language Class Initialized
INFO - 2024-12-16 10:04:27 --> Language Class Initialized
INFO - 2024-12-16 10:04:27 --> Config Class Initialized
INFO - 2024-12-16 10:04:27 --> Loader Class Initialized
INFO - 2024-12-16 10:04:27 --> Helper loaded: url_helper
INFO - 2024-12-16 10:04:27 --> Helper loaded: file_helper
INFO - 2024-12-16 10:04:27 --> Helper loaded: form_helper
INFO - 2024-12-16 10:04:27 --> Helper loaded: my_helper
INFO - 2024-12-16 10:04:27 --> Database Driver Class Initialized
INFO - 2024-12-16 10:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:04:28 --> Controller Class Initialized
ERROR - 2024-12-16 10:04:28 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 10:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 10:04:31 --> Final output sent to browser
DEBUG - 2024-12-16 10:04:31 --> Total execution time: 4.0299
INFO - 2024-12-16 10:05:34 --> Config Class Initialized
INFO - 2024-12-16 10:05:34 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:05:34 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:05:34 --> Utf8 Class Initialized
INFO - 2024-12-16 10:05:34 --> URI Class Initialized
INFO - 2024-12-16 10:05:34 --> Router Class Initialized
INFO - 2024-12-16 10:05:34 --> Output Class Initialized
INFO - 2024-12-16 10:05:34 --> Security Class Initialized
DEBUG - 2024-12-16 10:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:05:34 --> Input Class Initialized
INFO - 2024-12-16 10:05:34 --> Language Class Initialized
INFO - 2024-12-16 10:05:34 --> Language Class Initialized
INFO - 2024-12-16 10:05:34 --> Config Class Initialized
INFO - 2024-12-16 10:05:34 --> Loader Class Initialized
INFO - 2024-12-16 10:05:34 --> Helper loaded: url_helper
INFO - 2024-12-16 10:05:34 --> Helper loaded: file_helper
INFO - 2024-12-16 10:05:34 --> Helper loaded: form_helper
INFO - 2024-12-16 10:05:34 --> Helper loaded: my_helper
INFO - 2024-12-16 10:05:34 --> Database Driver Class Initialized
INFO - 2024-12-16 10:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:05:34 --> Controller Class Initialized
DEBUG - 2024-12-16 10:05:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 10:05:38 --> Final output sent to browser
DEBUG - 2024-12-16 10:05:38 --> Total execution time: 3.8132
INFO - 2024-12-16 10:06:22 --> Config Class Initialized
INFO - 2024-12-16 10:06:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:06:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:06:22 --> Utf8 Class Initialized
INFO - 2024-12-16 10:06:22 --> URI Class Initialized
INFO - 2024-12-16 10:06:22 --> Router Class Initialized
INFO - 2024-12-16 10:06:22 --> Output Class Initialized
INFO - 2024-12-16 10:06:22 --> Security Class Initialized
DEBUG - 2024-12-16 10:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:06:22 --> Input Class Initialized
INFO - 2024-12-16 10:06:22 --> Language Class Initialized
INFO - 2024-12-16 10:06:22 --> Language Class Initialized
INFO - 2024-12-16 10:06:22 --> Config Class Initialized
INFO - 2024-12-16 10:06:22 --> Loader Class Initialized
INFO - 2024-12-16 10:06:22 --> Helper loaded: url_helper
INFO - 2024-12-16 10:06:22 --> Helper loaded: file_helper
INFO - 2024-12-16 10:06:22 --> Helper loaded: form_helper
INFO - 2024-12-16 10:06:22 --> Helper loaded: my_helper
INFO - 2024-12-16 10:06:22 --> Database Driver Class Initialized
INFO - 2024-12-16 10:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:06:22 --> Controller Class Initialized
DEBUG - 2024-12-16 10:06:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 10:06:25 --> Final output sent to browser
DEBUG - 2024-12-16 10:06:25 --> Total execution time: 3.5062
INFO - 2024-12-16 10:06:32 --> Config Class Initialized
INFO - 2024-12-16 10:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:06:32 --> Utf8 Class Initialized
INFO - 2024-12-16 10:06:32 --> URI Class Initialized
INFO - 2024-12-16 10:06:32 --> Router Class Initialized
INFO - 2024-12-16 10:06:32 --> Output Class Initialized
INFO - 2024-12-16 10:06:32 --> Security Class Initialized
DEBUG - 2024-12-16 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:06:32 --> Input Class Initialized
INFO - 2024-12-16 10:06:32 --> Language Class Initialized
INFO - 2024-12-16 10:06:32 --> Language Class Initialized
INFO - 2024-12-16 10:06:32 --> Config Class Initialized
INFO - 2024-12-16 10:06:32 --> Loader Class Initialized
INFO - 2024-12-16 10:06:32 --> Helper loaded: url_helper
INFO - 2024-12-16 10:06:32 --> Helper loaded: file_helper
INFO - 2024-12-16 10:06:32 --> Helper loaded: form_helper
INFO - 2024-12-16 10:06:32 --> Helper loaded: my_helper
INFO - 2024-12-16 10:06:32 --> Database Driver Class Initialized
INFO - 2024-12-16 10:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:06:33 --> Controller Class Initialized
DEBUG - 2024-12-16 10:06:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 10:06:38 --> Final output sent to browser
DEBUG - 2024-12-16 10:06:38 --> Total execution time: 6.2094
INFO - 2024-12-16 10:07:01 --> Config Class Initialized
INFO - 2024-12-16 10:07:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:07:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:07:01 --> Utf8 Class Initialized
INFO - 2024-12-16 10:07:01 --> URI Class Initialized
INFO - 2024-12-16 10:07:01 --> Router Class Initialized
INFO - 2024-12-16 10:07:01 --> Output Class Initialized
INFO - 2024-12-16 10:07:01 --> Security Class Initialized
DEBUG - 2024-12-16 10:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:07:01 --> Input Class Initialized
INFO - 2024-12-16 10:07:01 --> Language Class Initialized
INFO - 2024-12-16 10:07:02 --> Language Class Initialized
INFO - 2024-12-16 10:07:02 --> Config Class Initialized
INFO - 2024-12-16 10:07:02 --> Loader Class Initialized
INFO - 2024-12-16 10:07:02 --> Helper loaded: url_helper
INFO - 2024-12-16 10:07:02 --> Helper loaded: file_helper
INFO - 2024-12-16 10:07:02 --> Helper loaded: form_helper
INFO - 2024-12-16 10:07:02 --> Helper loaded: my_helper
INFO - 2024-12-16 10:07:02 --> Database Driver Class Initialized
INFO - 2024-12-16 10:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:07:02 --> Controller Class Initialized
DEBUG - 2024-12-16 10:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 10:07:14 --> Final output sent to browser
DEBUG - 2024-12-16 10:07:14 --> Total execution time: 12.3522
INFO - 2024-12-16 10:07:36 --> Config Class Initialized
INFO - 2024-12-16 10:07:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:07:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:07:36 --> Utf8 Class Initialized
INFO - 2024-12-16 10:07:36 --> URI Class Initialized
INFO - 2024-12-16 10:07:36 --> Router Class Initialized
INFO - 2024-12-16 10:07:36 --> Output Class Initialized
INFO - 2024-12-16 10:07:36 --> Security Class Initialized
DEBUG - 2024-12-16 10:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:07:36 --> Input Class Initialized
INFO - 2024-12-16 10:07:36 --> Language Class Initialized
INFO - 2024-12-16 10:07:36 --> Language Class Initialized
INFO - 2024-12-16 10:07:36 --> Config Class Initialized
INFO - 2024-12-16 10:07:36 --> Loader Class Initialized
INFO - 2024-12-16 10:07:36 --> Helper loaded: url_helper
INFO - 2024-12-16 10:07:36 --> Helper loaded: file_helper
INFO - 2024-12-16 10:07:36 --> Helper loaded: form_helper
INFO - 2024-12-16 10:07:36 --> Helper loaded: my_helper
INFO - 2024-12-16 10:07:36 --> Database Driver Class Initialized
INFO - 2024-12-16 10:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:07:36 --> Controller Class Initialized
DEBUG - 2024-12-16 10:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 10:07:38 --> Final output sent to browser
DEBUG - 2024-12-16 10:07:38 --> Total execution time: 2.3499
INFO - 2024-12-16 10:15:52 --> Config Class Initialized
INFO - 2024-12-16 10:15:52 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:15:52 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:15:52 --> Utf8 Class Initialized
INFO - 2024-12-16 10:15:52 --> URI Class Initialized
INFO - 2024-12-16 10:15:52 --> Router Class Initialized
INFO - 2024-12-16 10:15:52 --> Output Class Initialized
INFO - 2024-12-16 10:15:52 --> Security Class Initialized
DEBUG - 2024-12-16 10:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:15:52 --> Input Class Initialized
INFO - 2024-12-16 10:15:52 --> Language Class Initialized
INFO - 2024-12-16 10:15:52 --> Language Class Initialized
INFO - 2024-12-16 10:15:52 --> Config Class Initialized
INFO - 2024-12-16 10:15:52 --> Loader Class Initialized
INFO - 2024-12-16 10:15:52 --> Helper loaded: url_helper
INFO - 2024-12-16 10:15:52 --> Helper loaded: file_helper
INFO - 2024-12-16 10:15:52 --> Helper loaded: form_helper
INFO - 2024-12-16 10:15:52 --> Helper loaded: my_helper
INFO - 2024-12-16 10:15:52 --> Database Driver Class Initialized
INFO - 2024-12-16 10:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:15:52 --> Controller Class Initialized
DEBUG - 2024-12-16 10:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 10:15:55 --> Final output sent to browser
DEBUG - 2024-12-16 10:15:55 --> Total execution time: 3.2802
INFO - 2024-12-16 10:17:56 --> Config Class Initialized
INFO - 2024-12-16 10:17:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:17:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:17:56 --> Utf8 Class Initialized
INFO - 2024-12-16 10:17:56 --> URI Class Initialized
DEBUG - 2024-12-16 10:17:56 --> No URI present. Default controller set.
INFO - 2024-12-16 10:17:56 --> Router Class Initialized
INFO - 2024-12-16 10:17:56 --> Output Class Initialized
INFO - 2024-12-16 10:17:56 --> Security Class Initialized
DEBUG - 2024-12-16 10:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:17:56 --> Input Class Initialized
INFO - 2024-12-16 10:17:56 --> Language Class Initialized
INFO - 2024-12-16 10:17:56 --> Language Class Initialized
INFO - 2024-12-16 10:17:56 --> Config Class Initialized
INFO - 2024-12-16 10:17:56 --> Loader Class Initialized
INFO - 2024-12-16 10:17:56 --> Helper loaded: url_helper
INFO - 2024-12-16 10:17:56 --> Helper loaded: file_helper
INFO - 2024-12-16 10:17:57 --> Helper loaded: form_helper
INFO - 2024-12-16 10:17:57 --> Helper loaded: my_helper
INFO - 2024-12-16 10:17:57 --> Database Driver Class Initialized
INFO - 2024-12-16 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:17:57 --> Controller Class Initialized
INFO - 2024-12-16 10:17:57 --> Config Class Initialized
INFO - 2024-12-16 10:17:57 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:17:57 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:17:57 --> Utf8 Class Initialized
INFO - 2024-12-16 10:17:57 --> URI Class Initialized
INFO - 2024-12-16 10:17:57 --> Router Class Initialized
INFO - 2024-12-16 10:17:57 --> Output Class Initialized
INFO - 2024-12-16 10:17:57 --> Security Class Initialized
DEBUG - 2024-12-16 10:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:17:57 --> Input Class Initialized
INFO - 2024-12-16 10:17:57 --> Language Class Initialized
INFO - 2024-12-16 10:17:57 --> Language Class Initialized
INFO - 2024-12-16 10:17:57 --> Config Class Initialized
INFO - 2024-12-16 10:17:57 --> Loader Class Initialized
INFO - 2024-12-16 10:17:57 --> Helper loaded: url_helper
INFO - 2024-12-16 10:17:57 --> Helper loaded: file_helper
INFO - 2024-12-16 10:17:57 --> Helper loaded: form_helper
INFO - 2024-12-16 10:17:57 --> Helper loaded: my_helper
INFO - 2024-12-16 10:17:57 --> Database Driver Class Initialized
INFO - 2024-12-16 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:17:57 --> Controller Class Initialized
DEBUG - 2024-12-16 10:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 10:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:17:57 --> Final output sent to browser
DEBUG - 2024-12-16 10:17:57 --> Total execution time: 0.2143
INFO - 2024-12-16 10:18:05 --> Config Class Initialized
INFO - 2024-12-16 10:18:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:05 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:05 --> URI Class Initialized
INFO - 2024-12-16 10:18:06 --> Router Class Initialized
INFO - 2024-12-16 10:18:06 --> Output Class Initialized
INFO - 2024-12-16 10:18:06 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:06 --> Input Class Initialized
INFO - 2024-12-16 10:18:06 --> Language Class Initialized
INFO - 2024-12-16 10:18:06 --> Language Class Initialized
INFO - 2024-12-16 10:18:06 --> Config Class Initialized
INFO - 2024-12-16 10:18:06 --> Loader Class Initialized
INFO - 2024-12-16 10:18:06 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:06 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:06 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:06 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:07 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:07 --> Controller Class Initialized
INFO - 2024-12-16 10:18:08 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:18:08 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:08 --> Total execution time: 2.7089
INFO - 2024-12-16 10:18:08 --> Config Class Initialized
INFO - 2024-12-16 10:18:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:09 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:09 --> URI Class Initialized
INFO - 2024-12-16 10:18:09 --> Router Class Initialized
INFO - 2024-12-16 10:18:09 --> Output Class Initialized
INFO - 2024-12-16 10:18:09 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:09 --> Input Class Initialized
INFO - 2024-12-16 10:18:09 --> Language Class Initialized
INFO - 2024-12-16 10:18:09 --> Language Class Initialized
INFO - 2024-12-16 10:18:09 --> Config Class Initialized
INFO - 2024-12-16 10:18:09 --> Loader Class Initialized
INFO - 2024-12-16 10:18:09 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:09 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:09 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:09 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:09 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:09 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 10:18:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:09 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:09 --> Total execution time: 0.8854
INFO - 2024-12-16 10:18:11 --> Config Class Initialized
INFO - 2024-12-16 10:18:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:11 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:11 --> URI Class Initialized
INFO - 2024-12-16 10:18:12 --> Router Class Initialized
INFO - 2024-12-16 10:18:12 --> Output Class Initialized
INFO - 2024-12-16 10:18:12 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:12 --> Input Class Initialized
INFO - 2024-12-16 10:18:12 --> Language Class Initialized
INFO - 2024-12-16 10:18:12 --> Language Class Initialized
INFO - 2024-12-16 10:18:12 --> Config Class Initialized
INFO - 2024-12-16 10:18:12 --> Loader Class Initialized
INFO - 2024-12-16 10:18:12 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:12 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:12 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:12 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:13 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:13 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-16 10:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:13 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:13 --> Total execution time: 1.3047
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:14 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:14 --> URI Class Initialized
INFO - 2024-12-16 10:18:14 --> Router Class Initialized
INFO - 2024-12-16 10:18:14 --> Output Class Initialized
INFO - 2024-12-16 10:18:14 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:14 --> Input Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Loader Class Initialized
INFO - 2024-12-16 10:18:14 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:14 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:14 --> Controller Class Initialized
INFO - 2024-12-16 10:18:14 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:14 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:14 --> URI Class Initialized
INFO - 2024-12-16 10:18:14 --> Router Class Initialized
INFO - 2024-12-16 10:18:14 --> Output Class Initialized
INFO - 2024-12-16 10:18:14 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:14 --> Input Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Loader Class Initialized
INFO - 2024-12-16 10:18:14 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:14 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:14 --> Controller Class Initialized
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:14 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:14 --> URI Class Initialized
INFO - 2024-12-16 10:18:14 --> Router Class Initialized
INFO - 2024-12-16 10:18:14 --> Output Class Initialized
INFO - 2024-12-16 10:18:14 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:14 --> Input Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Language Class Initialized
INFO - 2024-12-16 10:18:14 --> Config Class Initialized
INFO - 2024-12-16 10:18:14 --> Loader Class Initialized
INFO - 2024-12-16 10:18:14 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:14 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:14 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:14 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 10:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:14 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:14 --> Total execution time: 0.0885
INFO - 2024-12-16 10:18:17 --> Config Class Initialized
INFO - 2024-12-16 10:18:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:17 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:17 --> URI Class Initialized
INFO - 2024-12-16 10:18:17 --> Router Class Initialized
INFO - 2024-12-16 10:18:17 --> Output Class Initialized
INFO - 2024-12-16 10:18:17 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:17 --> Input Class Initialized
INFO - 2024-12-16 10:18:17 --> Language Class Initialized
INFO - 2024-12-16 10:18:17 --> Language Class Initialized
INFO - 2024-12-16 10:18:17 --> Config Class Initialized
INFO - 2024-12-16 10:18:17 --> Loader Class Initialized
INFO - 2024-12-16 10:18:17 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:17 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:17 --> Controller Class Initialized
INFO - 2024-12-16 10:18:17 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:18:17 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:17 --> Total execution time: 0.3604
INFO - 2024-12-16 10:18:17 --> Config Class Initialized
INFO - 2024-12-16 10:18:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:17 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:17 --> URI Class Initialized
INFO - 2024-12-16 10:18:17 --> Router Class Initialized
INFO - 2024-12-16 10:18:17 --> Output Class Initialized
INFO - 2024-12-16 10:18:17 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:17 --> Input Class Initialized
INFO - 2024-12-16 10:18:17 --> Language Class Initialized
INFO - 2024-12-16 10:18:17 --> Language Class Initialized
INFO - 2024-12-16 10:18:17 --> Config Class Initialized
INFO - 2024-12-16 10:18:17 --> Loader Class Initialized
INFO - 2024-12-16 10:18:17 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:17 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:17 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:17 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 10:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:17 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:17 --> Total execution time: 0.0906
INFO - 2024-12-16 10:18:36 --> Config Class Initialized
INFO - 2024-12-16 10:18:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:36 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:36 --> URI Class Initialized
INFO - 2024-12-16 10:18:36 --> Router Class Initialized
INFO - 2024-12-16 10:18:36 --> Output Class Initialized
INFO - 2024-12-16 10:18:36 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:36 --> Input Class Initialized
INFO - 2024-12-16 10:18:36 --> Language Class Initialized
INFO - 2024-12-16 10:18:36 --> Language Class Initialized
INFO - 2024-12-16 10:18:36 --> Config Class Initialized
INFO - 2024-12-16 10:18:36 --> Loader Class Initialized
INFO - 2024-12-16 10:18:36 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:36 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:36 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:36 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:37 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:37 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-16 10:18:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:37 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:37 --> Total execution time: 0.4795
INFO - 2024-12-16 10:18:47 --> Config Class Initialized
INFO - 2024-12-16 10:18:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:47 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:47 --> URI Class Initialized
INFO - 2024-12-16 10:18:47 --> Router Class Initialized
INFO - 2024-12-16 10:18:47 --> Output Class Initialized
INFO - 2024-12-16 10:18:47 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:47 --> Input Class Initialized
INFO - 2024-12-16 10:18:47 --> Language Class Initialized
INFO - 2024-12-16 10:18:47 --> Language Class Initialized
INFO - 2024-12-16 10:18:47 --> Config Class Initialized
INFO - 2024-12-16 10:18:47 --> Loader Class Initialized
INFO - 2024-12-16 10:18:47 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:47 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:47 --> Controller Class Initialized
DEBUG - 2024-12-16 10:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-16 10:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:18:47 --> Final output sent to browser
DEBUG - 2024-12-16 10:18:47 --> Total execution time: 0.2070
INFO - 2024-12-16 10:18:47 --> Config Class Initialized
INFO - 2024-12-16 10:18:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:18:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:18:47 --> Utf8 Class Initialized
INFO - 2024-12-16 10:18:47 --> URI Class Initialized
INFO - 2024-12-16 10:18:47 --> Router Class Initialized
INFO - 2024-12-16 10:18:47 --> Output Class Initialized
INFO - 2024-12-16 10:18:47 --> Security Class Initialized
DEBUG - 2024-12-16 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:18:47 --> Input Class Initialized
INFO - 2024-12-16 10:18:47 --> Language Class Initialized
INFO - 2024-12-16 10:18:47 --> Language Class Initialized
INFO - 2024-12-16 10:18:47 --> Config Class Initialized
INFO - 2024-12-16 10:18:47 --> Loader Class Initialized
INFO - 2024-12-16 10:18:47 --> Helper loaded: url_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: file_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: form_helper
INFO - 2024-12-16 10:18:47 --> Helper loaded: my_helper
INFO - 2024-12-16 10:18:47 --> Database Driver Class Initialized
INFO - 2024-12-16 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:18:47 --> Controller Class Initialized
INFO - 2024-12-16 10:19:43 --> Config Class Initialized
INFO - 2024-12-16 10:19:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:19:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:19:44 --> Utf8 Class Initialized
INFO - 2024-12-16 10:19:44 --> URI Class Initialized
INFO - 2024-12-16 10:19:44 --> Router Class Initialized
INFO - 2024-12-16 10:19:44 --> Output Class Initialized
INFO - 2024-12-16 10:19:44 --> Security Class Initialized
DEBUG - 2024-12-16 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:19:44 --> Input Class Initialized
INFO - 2024-12-16 10:19:44 --> Language Class Initialized
INFO - 2024-12-16 10:19:44 --> Language Class Initialized
INFO - 2024-12-16 10:19:44 --> Config Class Initialized
INFO - 2024-12-16 10:19:44 --> Loader Class Initialized
INFO - 2024-12-16 10:19:44 --> Helper loaded: url_helper
INFO - 2024-12-16 10:19:44 --> Helper loaded: file_helper
INFO - 2024-12-16 10:19:44 --> Helper loaded: form_helper
INFO - 2024-12-16 10:19:44 --> Helper loaded: my_helper
INFO - 2024-12-16 10:19:44 --> Database Driver Class Initialized
INFO - 2024-12-16 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:19:44 --> Controller Class Initialized
DEBUG - 2024-12-16 10:19:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 10:19:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:19:44 --> Final output sent to browser
DEBUG - 2024-12-16 10:19:44 --> Total execution time: 0.2270
INFO - 2024-12-16 10:20:00 --> Config Class Initialized
INFO - 2024-12-16 10:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:00 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:00 --> URI Class Initialized
INFO - 2024-12-16 10:20:00 --> Router Class Initialized
INFO - 2024-12-16 10:20:00 --> Output Class Initialized
INFO - 2024-12-16 10:20:00 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:00 --> Input Class Initialized
INFO - 2024-12-16 10:20:00 --> Language Class Initialized
INFO - 2024-12-16 10:20:00 --> Language Class Initialized
INFO - 2024-12-16 10:20:00 --> Config Class Initialized
INFO - 2024-12-16 10:20:00 --> Loader Class Initialized
INFO - 2024-12-16 10:20:00 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:00 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:00 --> Controller Class Initialized
INFO - 2024-12-16 10:20:00 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:20:00 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:00 --> Total execution time: 0.0809
INFO - 2024-12-16 10:20:00 --> Config Class Initialized
INFO - 2024-12-16 10:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:00 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:00 --> URI Class Initialized
INFO - 2024-12-16 10:20:00 --> Router Class Initialized
INFO - 2024-12-16 10:20:00 --> Output Class Initialized
INFO - 2024-12-16 10:20:00 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:00 --> Input Class Initialized
INFO - 2024-12-16 10:20:00 --> Language Class Initialized
INFO - 2024-12-16 10:20:00 --> Language Class Initialized
INFO - 2024-12-16 10:20:00 --> Config Class Initialized
INFO - 2024-12-16 10:20:00 --> Loader Class Initialized
INFO - 2024-12-16 10:20:00 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:00 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:00 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:00 --> Controller Class Initialized
DEBUG - 2024-12-16 10:20:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 10:20:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:20:00 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:00 --> Total execution time: 0.0404
INFO - 2024-12-16 10:20:03 --> Config Class Initialized
INFO - 2024-12-16 10:20:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:03 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:03 --> URI Class Initialized
INFO - 2024-12-16 10:20:03 --> Router Class Initialized
INFO - 2024-12-16 10:20:03 --> Output Class Initialized
INFO - 2024-12-16 10:20:03 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:03 --> Input Class Initialized
INFO - 2024-12-16 10:20:03 --> Language Class Initialized
INFO - 2024-12-16 10:20:04 --> Language Class Initialized
INFO - 2024-12-16 10:20:04 --> Config Class Initialized
INFO - 2024-12-16 10:20:04 --> Loader Class Initialized
INFO - 2024-12-16 10:20:04 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:04 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:04 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:04 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:04 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:04 --> Controller Class Initialized
DEBUG - 2024-12-16 10:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-16 10:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:20:04 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:04 --> Total execution time: 0.2480
INFO - 2024-12-16 10:20:05 --> Config Class Initialized
INFO - 2024-12-16 10:20:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:05 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:05 --> URI Class Initialized
INFO - 2024-12-16 10:20:05 --> Router Class Initialized
INFO - 2024-12-16 10:20:05 --> Output Class Initialized
INFO - 2024-12-16 10:20:05 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:05 --> Input Class Initialized
INFO - 2024-12-16 10:20:05 --> Language Class Initialized
INFO - 2024-12-16 10:20:05 --> Language Class Initialized
INFO - 2024-12-16 10:20:05 --> Config Class Initialized
INFO - 2024-12-16 10:20:05 --> Loader Class Initialized
INFO - 2024-12-16 10:20:05 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:05 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:05 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:05 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:05 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:05 --> Controller Class Initialized
DEBUG - 2024-12-16 10:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-12-16 10:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:20:06 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:06 --> Total execution time: 0.5116
INFO - 2024-12-16 10:20:08 --> Config Class Initialized
INFO - 2024-12-16 10:20:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:08 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:08 --> URI Class Initialized
INFO - 2024-12-16 10:20:08 --> Router Class Initialized
INFO - 2024-12-16 10:20:08 --> Output Class Initialized
INFO - 2024-12-16 10:20:08 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:08 --> Input Class Initialized
INFO - 2024-12-16 10:20:08 --> Language Class Initialized
INFO - 2024-12-16 10:20:08 --> Language Class Initialized
INFO - 2024-12-16 10:20:08 --> Config Class Initialized
INFO - 2024-12-16 10:20:08 --> Loader Class Initialized
INFO - 2024-12-16 10:20:08 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:08 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:08 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:08 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:08 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:08 --> Controller Class Initialized
INFO - 2024-12-16 10:20:08 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:08 --> Total execution time: 0.0677
INFO - 2024-12-16 10:20:27 --> Config Class Initialized
INFO - 2024-12-16 10:20:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:27 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:27 --> URI Class Initialized
INFO - 2024-12-16 10:20:27 --> Router Class Initialized
INFO - 2024-12-16 10:20:27 --> Output Class Initialized
INFO - 2024-12-16 10:20:27 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:27 --> Input Class Initialized
INFO - 2024-12-16 10:20:27 --> Language Class Initialized
INFO - 2024-12-16 10:20:27 --> Language Class Initialized
INFO - 2024-12-16 10:20:27 --> Config Class Initialized
INFO - 2024-12-16 10:20:27 --> Loader Class Initialized
INFO - 2024-12-16 10:20:27 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:27 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:27 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:27 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:27 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:27 --> Controller Class Initialized
INFO - 2024-12-16 10:20:27 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:27 --> Total execution time: 0.2753
INFO - 2024-12-16 10:20:31 --> Config Class Initialized
INFO - 2024-12-16 10:20:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:20:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:20:31 --> Utf8 Class Initialized
INFO - 2024-12-16 10:20:31 --> URI Class Initialized
INFO - 2024-12-16 10:20:31 --> Router Class Initialized
INFO - 2024-12-16 10:20:31 --> Output Class Initialized
INFO - 2024-12-16 10:20:31 --> Security Class Initialized
DEBUG - 2024-12-16 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:20:31 --> Input Class Initialized
INFO - 2024-12-16 10:20:31 --> Language Class Initialized
INFO - 2024-12-16 10:20:31 --> Language Class Initialized
INFO - 2024-12-16 10:20:31 --> Config Class Initialized
INFO - 2024-12-16 10:20:31 --> Loader Class Initialized
INFO - 2024-12-16 10:20:31 --> Helper loaded: url_helper
INFO - 2024-12-16 10:20:31 --> Helper loaded: file_helper
INFO - 2024-12-16 10:20:31 --> Helper loaded: form_helper
INFO - 2024-12-16 10:20:31 --> Helper loaded: my_helper
INFO - 2024-12-16 10:20:31 --> Database Driver Class Initialized
INFO - 2024-12-16 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:20:31 --> Controller Class Initialized
INFO - 2024-12-16 10:20:31 --> Final output sent to browser
DEBUG - 2024-12-16 10:20:31 --> Total execution time: 0.1772
INFO - 2024-12-16 10:33:43 --> Config Class Initialized
INFO - 2024-12-16 10:33:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:33:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:33:43 --> Utf8 Class Initialized
INFO - 2024-12-16 10:33:43 --> URI Class Initialized
INFO - 2024-12-16 10:33:43 --> Router Class Initialized
INFO - 2024-12-16 10:33:43 --> Output Class Initialized
INFO - 2024-12-16 10:33:43 --> Security Class Initialized
DEBUG - 2024-12-16 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:33:43 --> Input Class Initialized
INFO - 2024-12-16 10:33:43 --> Language Class Initialized
INFO - 2024-12-16 10:33:43 --> Language Class Initialized
INFO - 2024-12-16 10:33:43 --> Config Class Initialized
INFO - 2024-12-16 10:33:43 --> Loader Class Initialized
INFO - 2024-12-16 10:33:43 --> Helper loaded: url_helper
INFO - 2024-12-16 10:33:43 --> Helper loaded: file_helper
INFO - 2024-12-16 10:33:43 --> Helper loaded: form_helper
INFO - 2024-12-16 10:33:43 --> Helper loaded: my_helper
INFO - 2024-12-16 10:33:43 --> Database Driver Class Initialized
INFO - 2024-12-16 10:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:33:43 --> Controller Class Initialized
INFO - 2024-12-16 10:33:44 --> Final output sent to browser
DEBUG - 2024-12-16 10:33:44 --> Total execution time: 1.0838
INFO - 2024-12-16 10:33:45 --> Config Class Initialized
INFO - 2024-12-16 10:33:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:33:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:33:45 --> Utf8 Class Initialized
INFO - 2024-12-16 10:33:45 --> URI Class Initialized
INFO - 2024-12-16 10:33:45 --> Router Class Initialized
INFO - 2024-12-16 10:33:45 --> Output Class Initialized
INFO - 2024-12-16 10:33:45 --> Security Class Initialized
DEBUG - 2024-12-16 10:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:33:45 --> Input Class Initialized
INFO - 2024-12-16 10:33:45 --> Language Class Initialized
INFO - 2024-12-16 10:33:45 --> Language Class Initialized
INFO - 2024-12-16 10:33:45 --> Config Class Initialized
INFO - 2024-12-16 10:33:45 --> Loader Class Initialized
INFO - 2024-12-16 10:33:45 --> Helper loaded: url_helper
INFO - 2024-12-16 10:33:45 --> Helper loaded: file_helper
INFO - 2024-12-16 10:33:45 --> Helper loaded: form_helper
INFO - 2024-12-16 10:33:45 --> Helper loaded: my_helper
INFO - 2024-12-16 10:33:45 --> Database Driver Class Initialized
INFO - 2024-12-16 10:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:33:45 --> Controller Class Initialized
INFO - 2024-12-16 10:33:45 --> Final output sent to browser
DEBUG - 2024-12-16 10:33:45 --> Total execution time: 0.4916
INFO - 2024-12-16 10:33:46 --> Config Class Initialized
INFO - 2024-12-16 10:33:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:33:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:33:46 --> Utf8 Class Initialized
INFO - 2024-12-16 10:33:46 --> URI Class Initialized
INFO - 2024-12-16 10:33:46 --> Router Class Initialized
INFO - 2024-12-16 10:33:46 --> Output Class Initialized
INFO - 2024-12-16 10:33:46 --> Security Class Initialized
DEBUG - 2024-12-16 10:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:33:47 --> Input Class Initialized
INFO - 2024-12-16 10:33:47 --> Language Class Initialized
INFO - 2024-12-16 10:33:47 --> Language Class Initialized
INFO - 2024-12-16 10:33:47 --> Config Class Initialized
INFO - 2024-12-16 10:33:47 --> Loader Class Initialized
INFO - 2024-12-16 10:33:47 --> Helper loaded: url_helper
INFO - 2024-12-16 10:33:47 --> Helper loaded: file_helper
INFO - 2024-12-16 10:33:47 --> Helper loaded: form_helper
INFO - 2024-12-16 10:33:47 --> Helper loaded: my_helper
INFO - 2024-12-16 10:33:47 --> Database Driver Class Initialized
INFO - 2024-12-16 10:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:33:48 --> Controller Class Initialized
INFO - 2024-12-16 10:33:48 --> Final output sent to browser
DEBUG - 2024-12-16 10:33:48 --> Total execution time: 1.8523
INFO - 2024-12-16 10:33:58 --> Config Class Initialized
INFO - 2024-12-16 10:33:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:33:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:33:58 --> Utf8 Class Initialized
INFO - 2024-12-16 10:33:58 --> URI Class Initialized
INFO - 2024-12-16 10:33:58 --> Router Class Initialized
INFO - 2024-12-16 10:33:58 --> Output Class Initialized
INFO - 2024-12-16 10:33:58 --> Security Class Initialized
DEBUG - 2024-12-16 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:33:58 --> Input Class Initialized
INFO - 2024-12-16 10:33:58 --> Language Class Initialized
INFO - 2024-12-16 10:33:58 --> Language Class Initialized
INFO - 2024-12-16 10:33:58 --> Config Class Initialized
INFO - 2024-12-16 10:33:58 --> Loader Class Initialized
INFO - 2024-12-16 10:33:58 --> Helper loaded: url_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: file_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: form_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: my_helper
INFO - 2024-12-16 10:33:58 --> Database Driver Class Initialized
INFO - 2024-12-16 10:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:33:58 --> Controller Class Initialized
INFO - 2024-12-16 10:33:58 --> Final output sent to browser
DEBUG - 2024-12-16 10:33:58 --> Total execution time: 0.3990
INFO - 2024-12-16 10:33:58 --> Config Class Initialized
INFO - 2024-12-16 10:33:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:33:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:33:58 --> Utf8 Class Initialized
INFO - 2024-12-16 10:33:58 --> URI Class Initialized
INFO - 2024-12-16 10:33:58 --> Router Class Initialized
INFO - 2024-12-16 10:33:58 --> Output Class Initialized
INFO - 2024-12-16 10:33:58 --> Security Class Initialized
DEBUG - 2024-12-16 10:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:33:58 --> Input Class Initialized
INFO - 2024-12-16 10:33:58 --> Language Class Initialized
INFO - 2024-12-16 10:33:58 --> Language Class Initialized
INFO - 2024-12-16 10:33:58 --> Config Class Initialized
INFO - 2024-12-16 10:33:58 --> Loader Class Initialized
INFO - 2024-12-16 10:33:58 --> Helper loaded: url_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: file_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: form_helper
INFO - 2024-12-16 10:33:58 --> Helper loaded: my_helper
INFO - 2024-12-16 10:33:58 --> Database Driver Class Initialized
INFO - 2024-12-16 10:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:33:58 --> Controller Class Initialized
INFO - 2024-12-16 10:33:59 --> Final output sent to browser
DEBUG - 2024-12-16 10:33:59 --> Total execution time: 0.4741
INFO - 2024-12-16 10:39:50 --> Config Class Initialized
INFO - 2024-12-16 10:39:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:39:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:39:50 --> Utf8 Class Initialized
INFO - 2024-12-16 10:39:50 --> URI Class Initialized
INFO - 2024-12-16 10:39:50 --> Router Class Initialized
INFO - 2024-12-16 10:39:50 --> Output Class Initialized
INFO - 2024-12-16 10:39:50 --> Security Class Initialized
DEBUG - 2024-12-16 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:39:50 --> Input Class Initialized
INFO - 2024-12-16 10:39:50 --> Language Class Initialized
INFO - 2024-12-16 10:39:50 --> Language Class Initialized
INFO - 2024-12-16 10:39:50 --> Config Class Initialized
INFO - 2024-12-16 10:39:50 --> Loader Class Initialized
INFO - 2024-12-16 10:39:50 --> Helper loaded: url_helper
INFO - 2024-12-16 10:39:50 --> Helper loaded: file_helper
INFO - 2024-12-16 10:39:50 --> Helper loaded: form_helper
INFO - 2024-12-16 10:39:50 --> Helper loaded: my_helper
INFO - 2024-12-16 10:39:50 --> Database Driver Class Initialized
INFO - 2024-12-16 10:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:39:50 --> Controller Class Initialized
DEBUG - 2024-12-16 10:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 10:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:39:50 --> Final output sent to browser
DEBUG - 2024-12-16 10:39:50 --> Total execution time: 0.0553
INFO - 2024-12-16 10:45:56 --> Config Class Initialized
INFO - 2024-12-16 10:45:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:45:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:45:56 --> Utf8 Class Initialized
INFO - 2024-12-16 10:45:56 --> URI Class Initialized
INFO - 2024-12-16 10:45:56 --> Router Class Initialized
INFO - 2024-12-16 10:45:56 --> Output Class Initialized
INFO - 2024-12-16 10:45:56 --> Security Class Initialized
DEBUG - 2024-12-16 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:45:56 --> Input Class Initialized
INFO - 2024-12-16 10:45:56 --> Language Class Initialized
INFO - 2024-12-16 10:45:56 --> Language Class Initialized
INFO - 2024-12-16 10:45:56 --> Config Class Initialized
INFO - 2024-12-16 10:45:56 --> Loader Class Initialized
INFO - 2024-12-16 10:45:56 --> Helper loaded: url_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: file_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: form_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: my_helper
INFO - 2024-12-16 10:45:56 --> Database Driver Class Initialized
INFO - 2024-12-16 10:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:45:56 --> Controller Class Initialized
INFO - 2024-12-16 10:45:56 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:45:56 --> Final output sent to browser
DEBUG - 2024-12-16 10:45:56 --> Total execution time: 0.0707
INFO - 2024-12-16 10:45:56 --> Config Class Initialized
INFO - 2024-12-16 10:45:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:45:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:45:56 --> Utf8 Class Initialized
INFO - 2024-12-16 10:45:56 --> URI Class Initialized
INFO - 2024-12-16 10:45:56 --> Router Class Initialized
INFO - 2024-12-16 10:45:56 --> Output Class Initialized
INFO - 2024-12-16 10:45:56 --> Security Class Initialized
DEBUG - 2024-12-16 10:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:45:56 --> Input Class Initialized
INFO - 2024-12-16 10:45:56 --> Language Class Initialized
INFO - 2024-12-16 10:45:56 --> Language Class Initialized
INFO - 2024-12-16 10:45:56 --> Config Class Initialized
INFO - 2024-12-16 10:45:56 --> Loader Class Initialized
INFO - 2024-12-16 10:45:56 --> Helper loaded: url_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: file_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: form_helper
INFO - 2024-12-16 10:45:56 --> Helper loaded: my_helper
INFO - 2024-12-16 10:45:56 --> Database Driver Class Initialized
INFO - 2024-12-16 10:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:45:56 --> Controller Class Initialized
DEBUG - 2024-12-16 10:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 10:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:45:56 --> Final output sent to browser
DEBUG - 2024-12-16 10:45:56 --> Total execution time: 0.0558
INFO - 2024-12-16 10:46:01 --> Config Class Initialized
INFO - 2024-12-16 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:46:01 --> Utf8 Class Initialized
INFO - 2024-12-16 10:46:01 --> URI Class Initialized
INFO - 2024-12-16 10:46:01 --> Router Class Initialized
INFO - 2024-12-16 10:46:01 --> Output Class Initialized
INFO - 2024-12-16 10:46:01 --> Security Class Initialized
DEBUG - 2024-12-16 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:46:01 --> Input Class Initialized
INFO - 2024-12-16 10:46:01 --> Language Class Initialized
INFO - 2024-12-16 10:46:01 --> Language Class Initialized
INFO - 2024-12-16 10:46:01 --> Config Class Initialized
INFO - 2024-12-16 10:46:01 --> Loader Class Initialized
INFO - 2024-12-16 10:46:01 --> Helper loaded: url_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: file_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: form_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: my_helper
INFO - 2024-12-16 10:46:01 --> Database Driver Class Initialized
INFO - 2024-12-16 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:46:01 --> Controller Class Initialized
DEBUG - 2024-12-16 10:46:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 10:46:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:46:01 --> Final output sent to browser
DEBUG - 2024-12-16 10:46:01 --> Total execution time: 0.0597
INFO - 2024-12-16 10:46:01 --> Config Class Initialized
INFO - 2024-12-16 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:46:01 --> Utf8 Class Initialized
INFO - 2024-12-16 10:46:01 --> URI Class Initialized
INFO - 2024-12-16 10:46:01 --> Router Class Initialized
INFO - 2024-12-16 10:46:01 --> Output Class Initialized
INFO - 2024-12-16 10:46:01 --> Security Class Initialized
DEBUG - 2024-12-16 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:46:01 --> Input Class Initialized
INFO - 2024-12-16 10:46:01 --> Language Class Initialized
ERROR - 2024-12-16 10:46:01 --> 404 Page Not Found: /index
INFO - 2024-12-16 10:46:01 --> Config Class Initialized
INFO - 2024-12-16 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:46:01 --> Utf8 Class Initialized
INFO - 2024-12-16 10:46:01 --> URI Class Initialized
INFO - 2024-12-16 10:46:01 --> Router Class Initialized
INFO - 2024-12-16 10:46:01 --> Output Class Initialized
INFO - 2024-12-16 10:46:01 --> Security Class Initialized
DEBUG - 2024-12-16 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:46:01 --> Input Class Initialized
INFO - 2024-12-16 10:46:01 --> Language Class Initialized
INFO - 2024-12-16 10:46:01 --> Language Class Initialized
INFO - 2024-12-16 10:46:01 --> Config Class Initialized
INFO - 2024-12-16 10:46:01 --> Loader Class Initialized
INFO - 2024-12-16 10:46:01 --> Helper loaded: url_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: file_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: form_helper
INFO - 2024-12-16 10:46:01 --> Helper loaded: my_helper
INFO - 2024-12-16 10:46:01 --> Database Driver Class Initialized
INFO - 2024-12-16 10:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:46:02 --> Controller Class Initialized
INFO - 2024-12-16 10:46:10 --> Config Class Initialized
INFO - 2024-12-16 10:46:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:46:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:46:10 --> Utf8 Class Initialized
INFO - 2024-12-16 10:46:10 --> URI Class Initialized
INFO - 2024-12-16 10:46:10 --> Router Class Initialized
INFO - 2024-12-16 10:46:10 --> Output Class Initialized
INFO - 2024-12-16 10:46:10 --> Security Class Initialized
DEBUG - 2024-12-16 10:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:46:10 --> Input Class Initialized
INFO - 2024-12-16 10:46:10 --> Language Class Initialized
INFO - 2024-12-16 10:46:10 --> Language Class Initialized
INFO - 2024-12-16 10:46:10 --> Config Class Initialized
INFO - 2024-12-16 10:46:10 --> Loader Class Initialized
INFO - 2024-12-16 10:46:10 --> Helper loaded: url_helper
INFO - 2024-12-16 10:46:10 --> Helper loaded: file_helper
INFO - 2024-12-16 10:46:10 --> Helper loaded: form_helper
INFO - 2024-12-16 10:46:10 --> Helper loaded: my_helper
INFO - 2024-12-16 10:46:10 --> Database Driver Class Initialized
INFO - 2024-12-16 10:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:46:10 --> Controller Class Initialized
INFO - 2024-12-16 10:46:25 --> Config Class Initialized
INFO - 2024-12-16 10:46:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:46:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:46:25 --> Utf8 Class Initialized
INFO - 2024-12-16 10:46:25 --> URI Class Initialized
INFO - 2024-12-16 10:46:25 --> Router Class Initialized
INFO - 2024-12-16 10:46:25 --> Output Class Initialized
INFO - 2024-12-16 10:46:25 --> Security Class Initialized
DEBUG - 2024-12-16 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:46:25 --> Input Class Initialized
INFO - 2024-12-16 10:46:25 --> Language Class Initialized
INFO - 2024-12-16 10:46:25 --> Language Class Initialized
INFO - 2024-12-16 10:46:25 --> Config Class Initialized
INFO - 2024-12-16 10:46:25 --> Loader Class Initialized
INFO - 2024-12-16 10:46:25 --> Helper loaded: url_helper
INFO - 2024-12-16 10:46:25 --> Helper loaded: file_helper
INFO - 2024-12-16 10:46:25 --> Helper loaded: form_helper
INFO - 2024-12-16 10:46:25 --> Helper loaded: my_helper
INFO - 2024-12-16 10:46:25 --> Database Driver Class Initialized
INFO - 2024-12-16 10:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:46:25 --> Controller Class Initialized
DEBUG - 2024-12-16 10:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-16 10:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:46:25 --> Final output sent to browser
DEBUG - 2024-12-16 10:46:25 --> Total execution time: 0.1130
INFO - 2024-12-16 10:53:04 --> Config Class Initialized
INFO - 2024-12-16 10:53:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:53:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:53:04 --> Utf8 Class Initialized
INFO - 2024-12-16 10:53:04 --> URI Class Initialized
INFO - 2024-12-16 10:53:04 --> Router Class Initialized
INFO - 2024-12-16 10:53:04 --> Output Class Initialized
INFO - 2024-12-16 10:53:05 --> Security Class Initialized
DEBUG - 2024-12-16 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:53:05 --> Input Class Initialized
INFO - 2024-12-16 10:53:05 --> Language Class Initialized
INFO - 2024-12-16 10:53:05 --> Language Class Initialized
INFO - 2024-12-16 10:53:05 --> Config Class Initialized
INFO - 2024-12-16 10:53:05 --> Loader Class Initialized
INFO - 2024-12-16 10:53:05 --> Helper loaded: url_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: file_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: form_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: my_helper
INFO - 2024-12-16 10:53:05 --> Database Driver Class Initialized
INFO - 2024-12-16 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:53:05 --> Controller Class Initialized
INFO - 2024-12-16 10:53:05 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:53:05 --> Final output sent to browser
DEBUG - 2024-12-16 10:53:05 --> Total execution time: 0.6374
INFO - 2024-12-16 10:53:05 --> Config Class Initialized
INFO - 2024-12-16 10:53:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:53:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:53:05 --> Utf8 Class Initialized
INFO - 2024-12-16 10:53:05 --> URI Class Initialized
INFO - 2024-12-16 10:53:05 --> Router Class Initialized
INFO - 2024-12-16 10:53:05 --> Output Class Initialized
INFO - 2024-12-16 10:53:05 --> Security Class Initialized
DEBUG - 2024-12-16 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:53:05 --> Input Class Initialized
INFO - 2024-12-16 10:53:05 --> Language Class Initialized
INFO - 2024-12-16 10:53:05 --> Language Class Initialized
INFO - 2024-12-16 10:53:05 --> Config Class Initialized
INFO - 2024-12-16 10:53:05 --> Loader Class Initialized
INFO - 2024-12-16 10:53:05 --> Helper loaded: url_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: file_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: form_helper
INFO - 2024-12-16 10:53:05 --> Helper loaded: my_helper
INFO - 2024-12-16 10:53:05 --> Database Driver Class Initialized
INFO - 2024-12-16 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:53:05 --> Controller Class Initialized
INFO - 2024-12-16 10:53:05 --> Helper loaded: cookie_helper
INFO - 2024-12-16 10:53:05 --> Config Class Initialized
INFO - 2024-12-16 10:53:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:53:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:53:05 --> Utf8 Class Initialized
INFO - 2024-12-16 10:53:05 --> URI Class Initialized
INFO - 2024-12-16 10:53:05 --> Router Class Initialized
INFO - 2024-12-16 10:53:06 --> Output Class Initialized
INFO - 2024-12-16 10:53:06 --> Security Class Initialized
DEBUG - 2024-12-16 10:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:53:06 --> Input Class Initialized
INFO - 2024-12-16 10:53:06 --> Language Class Initialized
INFO - 2024-12-16 10:53:06 --> Language Class Initialized
INFO - 2024-12-16 10:53:06 --> Config Class Initialized
INFO - 2024-12-16 10:53:06 --> Loader Class Initialized
INFO - 2024-12-16 10:53:06 --> Helper loaded: url_helper
INFO - 2024-12-16 10:53:06 --> Helper loaded: file_helper
INFO - 2024-12-16 10:53:07 --> Helper loaded: form_helper
INFO - 2024-12-16 10:53:07 --> Helper loaded: my_helper
INFO - 2024-12-16 10:53:07 --> Database Driver Class Initialized
INFO - 2024-12-16 10:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:53:07 --> Controller Class Initialized
DEBUG - 2024-12-16 10:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 10:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:53:07 --> Final output sent to browser
DEBUG - 2024-12-16 10:53:07 --> Total execution time: 1.9125
INFO - 2024-12-16 10:53:29 --> Config Class Initialized
INFO - 2024-12-16 10:53:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:53:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:53:29 --> Utf8 Class Initialized
INFO - 2024-12-16 10:53:29 --> URI Class Initialized
INFO - 2024-12-16 10:53:29 --> Router Class Initialized
INFO - 2024-12-16 10:53:29 --> Output Class Initialized
INFO - 2024-12-16 10:53:29 --> Security Class Initialized
DEBUG - 2024-12-16 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:53:29 --> Input Class Initialized
INFO - 2024-12-16 10:53:29 --> Language Class Initialized
INFO - 2024-12-16 10:53:29 --> Language Class Initialized
INFO - 2024-12-16 10:53:29 --> Config Class Initialized
INFO - 2024-12-16 10:53:29 --> Loader Class Initialized
INFO - 2024-12-16 10:53:29 --> Helper loaded: url_helper
INFO - 2024-12-16 10:53:29 --> Helper loaded: file_helper
INFO - 2024-12-16 10:53:29 --> Helper loaded: form_helper
INFO - 2024-12-16 10:53:29 --> Helper loaded: my_helper
INFO - 2024-12-16 10:53:29 --> Database Driver Class Initialized
INFO - 2024-12-16 10:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:53:29 --> Controller Class Initialized
DEBUG - 2024-12-16 10:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 10:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 10:53:29 --> Final output sent to browser
DEBUG - 2024-12-16 10:53:29 --> Total execution time: 0.0993
INFO - 2024-12-16 10:53:40 --> Config Class Initialized
INFO - 2024-12-16 10:53:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:53:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:53:40 --> Utf8 Class Initialized
INFO - 2024-12-16 10:53:40 --> URI Class Initialized
INFO - 2024-12-16 10:53:40 --> Router Class Initialized
INFO - 2024-12-16 10:53:40 --> Output Class Initialized
INFO - 2024-12-16 10:53:40 --> Security Class Initialized
DEBUG - 2024-12-16 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:53:40 --> Input Class Initialized
INFO - 2024-12-16 10:53:40 --> Language Class Initialized
INFO - 2024-12-16 10:53:40 --> Language Class Initialized
INFO - 2024-12-16 10:53:40 --> Config Class Initialized
INFO - 2024-12-16 10:53:40 --> Loader Class Initialized
INFO - 2024-12-16 10:53:40 --> Helper loaded: url_helper
INFO - 2024-12-16 10:53:40 --> Helper loaded: file_helper
INFO - 2024-12-16 10:53:40 --> Helper loaded: form_helper
INFO - 2024-12-16 10:53:40 --> Helper loaded: my_helper
INFO - 2024-12-16 10:53:40 --> Database Driver Class Initialized
INFO - 2024-12-16 10:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:53:40 --> Controller Class Initialized
DEBUG - 2024-12-16 10:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 10:53:50 --> Final output sent to browser
DEBUG - 2024-12-16 10:53:50 --> Total execution time: 9.9158
INFO - 2024-12-16 10:54:31 --> Config Class Initialized
INFO - 2024-12-16 10:54:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:54:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:54:31 --> Utf8 Class Initialized
INFO - 2024-12-16 10:54:31 --> URI Class Initialized
INFO - 2024-12-16 10:54:31 --> Router Class Initialized
INFO - 2024-12-16 10:54:31 --> Output Class Initialized
INFO - 2024-12-16 10:54:31 --> Security Class Initialized
DEBUG - 2024-12-16 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:54:31 --> Input Class Initialized
INFO - 2024-12-16 10:54:31 --> Language Class Initialized
INFO - 2024-12-16 10:54:31 --> Language Class Initialized
INFO - 2024-12-16 10:54:31 --> Config Class Initialized
INFO - 2024-12-16 10:54:31 --> Loader Class Initialized
INFO - 2024-12-16 10:54:31 --> Helper loaded: url_helper
INFO - 2024-12-16 10:54:31 --> Helper loaded: file_helper
INFO - 2024-12-16 10:54:31 --> Helper loaded: form_helper
INFO - 2024-12-16 10:54:31 --> Helper loaded: my_helper
INFO - 2024-12-16 10:54:31 --> Database Driver Class Initialized
INFO - 2024-12-16 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:54:31 --> Controller Class Initialized
ERROR - 2024-12-16 10:54:31 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 10:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 10:54:34 --> Final output sent to browser
DEBUG - 2024-12-16 10:54:34 --> Total execution time: 3.4285
INFO - 2024-12-16 10:55:36 --> Config Class Initialized
INFO - 2024-12-16 10:55:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:55:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:55:36 --> Utf8 Class Initialized
INFO - 2024-12-16 10:55:36 --> URI Class Initialized
INFO - 2024-12-16 10:55:36 --> Router Class Initialized
INFO - 2024-12-16 10:55:36 --> Output Class Initialized
INFO - 2024-12-16 10:55:36 --> Security Class Initialized
DEBUG - 2024-12-16 10:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:55:36 --> Input Class Initialized
INFO - 2024-12-16 10:55:36 --> Language Class Initialized
INFO - 2024-12-16 10:55:36 --> Language Class Initialized
INFO - 2024-12-16 10:55:36 --> Config Class Initialized
INFO - 2024-12-16 10:55:36 --> Loader Class Initialized
INFO - 2024-12-16 10:55:36 --> Helper loaded: url_helper
INFO - 2024-12-16 10:55:36 --> Helper loaded: file_helper
INFO - 2024-12-16 10:55:36 --> Helper loaded: form_helper
INFO - 2024-12-16 10:55:36 --> Helper loaded: my_helper
INFO - 2024-12-16 10:55:36 --> Database Driver Class Initialized
INFO - 2024-12-16 10:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:55:36 --> Controller Class Initialized
DEBUG - 2024-12-16 10:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 10:55:41 --> Final output sent to browser
DEBUG - 2024-12-16 10:55:41 --> Total execution time: 5.0707
INFO - 2024-12-16 10:58:16 --> Config Class Initialized
INFO - 2024-12-16 10:58:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:58:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:58:16 --> Utf8 Class Initialized
INFO - 2024-12-16 10:58:16 --> URI Class Initialized
INFO - 2024-12-16 10:58:16 --> Router Class Initialized
INFO - 2024-12-16 10:58:16 --> Output Class Initialized
INFO - 2024-12-16 10:58:16 --> Security Class Initialized
DEBUG - 2024-12-16 10:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:58:16 --> Input Class Initialized
INFO - 2024-12-16 10:58:16 --> Language Class Initialized
INFO - 2024-12-16 10:58:16 --> Language Class Initialized
INFO - 2024-12-16 10:58:16 --> Config Class Initialized
INFO - 2024-12-16 10:58:16 --> Loader Class Initialized
INFO - 2024-12-16 10:58:16 --> Helper loaded: url_helper
INFO - 2024-12-16 10:58:16 --> Helper loaded: file_helper
INFO - 2024-12-16 10:58:16 --> Helper loaded: form_helper
INFO - 2024-12-16 10:58:16 --> Helper loaded: my_helper
INFO - 2024-12-16 10:58:16 --> Database Driver Class Initialized
INFO - 2024-12-16 10:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:58:16 --> Controller Class Initialized
DEBUG - 2024-12-16 10:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 10:58:21 --> Final output sent to browser
DEBUG - 2024-12-16 10:58:21 --> Total execution time: 4.7045
INFO - 2024-12-16 10:59:38 --> Config Class Initialized
INFO - 2024-12-16 10:59:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 10:59:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 10:59:38 --> Utf8 Class Initialized
INFO - 2024-12-16 10:59:38 --> URI Class Initialized
INFO - 2024-12-16 10:59:38 --> Router Class Initialized
INFO - 2024-12-16 10:59:38 --> Output Class Initialized
INFO - 2024-12-16 10:59:38 --> Security Class Initialized
DEBUG - 2024-12-16 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 10:59:38 --> Input Class Initialized
INFO - 2024-12-16 10:59:38 --> Language Class Initialized
INFO - 2024-12-16 10:59:38 --> Language Class Initialized
INFO - 2024-12-16 10:59:38 --> Config Class Initialized
INFO - 2024-12-16 10:59:38 --> Loader Class Initialized
INFO - 2024-12-16 10:59:38 --> Helper loaded: url_helper
INFO - 2024-12-16 10:59:38 --> Helper loaded: file_helper
INFO - 2024-12-16 10:59:38 --> Helper loaded: form_helper
INFO - 2024-12-16 10:59:38 --> Helper loaded: my_helper
INFO - 2024-12-16 10:59:38 --> Database Driver Class Initialized
INFO - 2024-12-16 10:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 10:59:38 --> Controller Class Initialized
DEBUG - 2024-12-16 10:59:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 10:59:41 --> Final output sent to browser
DEBUG - 2024-12-16 10:59:41 --> Total execution time: 2.9273
INFO - 2024-12-16 11:01:47 --> Config Class Initialized
INFO - 2024-12-16 11:01:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:01:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:01:47 --> Utf8 Class Initialized
INFO - 2024-12-16 11:01:47 --> URI Class Initialized
INFO - 2024-12-16 11:01:47 --> Router Class Initialized
INFO - 2024-12-16 11:01:47 --> Output Class Initialized
INFO - 2024-12-16 11:01:47 --> Security Class Initialized
DEBUG - 2024-12-16 11:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:01:47 --> Input Class Initialized
INFO - 2024-12-16 11:01:47 --> Language Class Initialized
INFO - 2024-12-16 11:01:47 --> Language Class Initialized
INFO - 2024-12-16 11:01:47 --> Config Class Initialized
INFO - 2024-12-16 11:01:47 --> Loader Class Initialized
INFO - 2024-12-16 11:01:47 --> Helper loaded: url_helper
INFO - 2024-12-16 11:01:47 --> Helper loaded: file_helper
INFO - 2024-12-16 11:01:47 --> Helper loaded: form_helper
INFO - 2024-12-16 11:01:47 --> Helper loaded: my_helper
INFO - 2024-12-16 11:01:47 --> Database Driver Class Initialized
INFO - 2024-12-16 11:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:01:47 --> Controller Class Initialized
INFO - 2024-12-16 11:01:47 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:01:47 --> Final output sent to browser
DEBUG - 2024-12-16 11:01:47 --> Total execution time: 0.0585
INFO - 2024-12-16 11:01:48 --> Config Class Initialized
INFO - 2024-12-16 11:01:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:01:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:01:48 --> Utf8 Class Initialized
INFO - 2024-12-16 11:01:48 --> URI Class Initialized
INFO - 2024-12-16 11:01:48 --> Router Class Initialized
INFO - 2024-12-16 11:01:48 --> Output Class Initialized
INFO - 2024-12-16 11:01:48 --> Security Class Initialized
DEBUG - 2024-12-16 11:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:01:48 --> Input Class Initialized
INFO - 2024-12-16 11:01:48 --> Language Class Initialized
INFO - 2024-12-16 11:01:48 --> Language Class Initialized
INFO - 2024-12-16 11:01:48 --> Config Class Initialized
INFO - 2024-12-16 11:01:48 --> Loader Class Initialized
INFO - 2024-12-16 11:01:48 --> Helper loaded: url_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: file_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: form_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: my_helper
INFO - 2024-12-16 11:01:48 --> Database Driver Class Initialized
INFO - 2024-12-16 11:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:01:48 --> Controller Class Initialized
INFO - 2024-12-16 11:01:48 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:01:48 --> Config Class Initialized
INFO - 2024-12-16 11:01:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:01:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:01:48 --> Utf8 Class Initialized
INFO - 2024-12-16 11:01:48 --> URI Class Initialized
INFO - 2024-12-16 11:01:48 --> Router Class Initialized
INFO - 2024-12-16 11:01:48 --> Output Class Initialized
INFO - 2024-12-16 11:01:48 --> Security Class Initialized
DEBUG - 2024-12-16 11:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:01:48 --> Input Class Initialized
INFO - 2024-12-16 11:01:48 --> Language Class Initialized
INFO - 2024-12-16 11:01:48 --> Language Class Initialized
INFO - 2024-12-16 11:01:48 --> Config Class Initialized
INFO - 2024-12-16 11:01:48 --> Loader Class Initialized
INFO - 2024-12-16 11:01:48 --> Helper loaded: url_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: file_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: form_helper
INFO - 2024-12-16 11:01:48 --> Helper loaded: my_helper
INFO - 2024-12-16 11:01:48 --> Database Driver Class Initialized
INFO - 2024-12-16 11:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:01:48 --> Controller Class Initialized
DEBUG - 2024-12-16 11:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 11:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:01:48 --> Final output sent to browser
DEBUG - 2024-12-16 11:01:48 --> Total execution time: 0.0532
INFO - 2024-12-16 11:02:07 --> Config Class Initialized
INFO - 2024-12-16 11:02:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:02:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:02:07 --> Utf8 Class Initialized
INFO - 2024-12-16 11:02:07 --> URI Class Initialized
INFO - 2024-12-16 11:02:07 --> Router Class Initialized
INFO - 2024-12-16 11:02:07 --> Output Class Initialized
INFO - 2024-12-16 11:02:07 --> Security Class Initialized
DEBUG - 2024-12-16 11:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:02:07 --> Input Class Initialized
INFO - 2024-12-16 11:02:07 --> Language Class Initialized
INFO - 2024-12-16 11:02:07 --> Language Class Initialized
INFO - 2024-12-16 11:02:07 --> Config Class Initialized
INFO - 2024-12-16 11:02:07 --> Loader Class Initialized
INFO - 2024-12-16 11:02:07 --> Helper loaded: url_helper
INFO - 2024-12-16 11:02:07 --> Helper loaded: file_helper
INFO - 2024-12-16 11:02:07 --> Helper loaded: form_helper
INFO - 2024-12-16 11:02:07 --> Helper loaded: my_helper
INFO - 2024-12-16 11:02:07 --> Database Driver Class Initialized
INFO - 2024-12-16 11:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:02:07 --> Controller Class Initialized
DEBUG - 2024-12-16 11:02:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:02:13 --> Final output sent to browser
DEBUG - 2024-12-16 11:02:13 --> Total execution time: 5.6558
INFO - 2024-12-16 11:08:22 --> Config Class Initialized
INFO - 2024-12-16 11:08:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:08:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:08:22 --> Utf8 Class Initialized
INFO - 2024-12-16 11:08:22 --> URI Class Initialized
INFO - 2024-12-16 11:08:22 --> Router Class Initialized
INFO - 2024-12-16 11:08:22 --> Output Class Initialized
INFO - 2024-12-16 11:08:22 --> Security Class Initialized
DEBUG - 2024-12-16 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:08:22 --> Input Class Initialized
INFO - 2024-12-16 11:08:22 --> Language Class Initialized
INFO - 2024-12-16 11:08:22 --> Language Class Initialized
INFO - 2024-12-16 11:08:22 --> Config Class Initialized
INFO - 2024-12-16 11:08:22 --> Loader Class Initialized
INFO - 2024-12-16 11:08:22 --> Helper loaded: url_helper
INFO - 2024-12-16 11:08:22 --> Helper loaded: file_helper
INFO - 2024-12-16 11:08:22 --> Helper loaded: form_helper
INFO - 2024-12-16 11:08:22 --> Helper loaded: my_helper
INFO - 2024-12-16 11:08:22 --> Database Driver Class Initialized
INFO - 2024-12-16 11:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:08:22 --> Controller Class Initialized
DEBUG - 2024-12-16 11:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 11:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:08:22 --> Final output sent to browser
DEBUG - 2024-12-16 11:08:22 --> Total execution time: 0.0642
INFO - 2024-12-16 11:09:19 --> Config Class Initialized
INFO - 2024-12-16 11:09:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:09:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:09:19 --> Utf8 Class Initialized
INFO - 2024-12-16 11:09:19 --> URI Class Initialized
INFO - 2024-12-16 11:09:19 --> Router Class Initialized
INFO - 2024-12-16 11:09:19 --> Output Class Initialized
INFO - 2024-12-16 11:09:19 --> Security Class Initialized
DEBUG - 2024-12-16 11:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:09:19 --> Input Class Initialized
INFO - 2024-12-16 11:09:19 --> Language Class Initialized
INFO - 2024-12-16 11:09:19 --> Language Class Initialized
INFO - 2024-12-16 11:09:19 --> Config Class Initialized
INFO - 2024-12-16 11:09:19 --> Loader Class Initialized
INFO - 2024-12-16 11:09:19 --> Helper loaded: url_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: file_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: form_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: my_helper
INFO - 2024-12-16 11:09:19 --> Database Driver Class Initialized
INFO - 2024-12-16 11:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:09:19 --> Controller Class Initialized
INFO - 2024-12-16 11:09:19 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:09:19 --> Final output sent to browser
DEBUG - 2024-12-16 11:09:19 --> Total execution time: 0.3701
INFO - 2024-12-16 11:09:19 --> Config Class Initialized
INFO - 2024-12-16 11:09:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:09:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:09:19 --> Utf8 Class Initialized
INFO - 2024-12-16 11:09:19 --> URI Class Initialized
INFO - 2024-12-16 11:09:19 --> Router Class Initialized
INFO - 2024-12-16 11:09:19 --> Output Class Initialized
INFO - 2024-12-16 11:09:19 --> Security Class Initialized
DEBUG - 2024-12-16 11:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:09:19 --> Input Class Initialized
INFO - 2024-12-16 11:09:19 --> Language Class Initialized
INFO - 2024-12-16 11:09:19 --> Language Class Initialized
INFO - 2024-12-16 11:09:19 --> Config Class Initialized
INFO - 2024-12-16 11:09:19 --> Loader Class Initialized
INFO - 2024-12-16 11:09:19 --> Helper loaded: url_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: file_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: form_helper
INFO - 2024-12-16 11:09:19 --> Helper loaded: my_helper
INFO - 2024-12-16 11:09:19 --> Database Driver Class Initialized
INFO - 2024-12-16 11:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:09:19 --> Controller Class Initialized
DEBUG - 2024-12-16 11:09:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 11:09:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:09:19 --> Final output sent to browser
DEBUG - 2024-12-16 11:09:19 --> Total execution time: 0.1159
INFO - 2024-12-16 11:09:28 --> Config Class Initialized
INFO - 2024-12-16 11:09:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:09:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:09:28 --> Utf8 Class Initialized
INFO - 2024-12-16 11:09:28 --> URI Class Initialized
INFO - 2024-12-16 11:09:28 --> Router Class Initialized
INFO - 2024-12-16 11:09:28 --> Output Class Initialized
INFO - 2024-12-16 11:09:28 --> Security Class Initialized
DEBUG - 2024-12-16 11:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:09:28 --> Input Class Initialized
INFO - 2024-12-16 11:09:28 --> Language Class Initialized
INFO - 2024-12-16 11:09:28 --> Language Class Initialized
INFO - 2024-12-16 11:09:28 --> Config Class Initialized
INFO - 2024-12-16 11:09:28 --> Loader Class Initialized
INFO - 2024-12-16 11:09:28 --> Helper loaded: url_helper
INFO - 2024-12-16 11:09:28 --> Helper loaded: file_helper
INFO - 2024-12-16 11:09:28 --> Helper loaded: form_helper
INFO - 2024-12-16 11:09:28 --> Helper loaded: my_helper
INFO - 2024-12-16 11:09:28 --> Database Driver Class Initialized
INFO - 2024-12-16 11:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:09:28 --> Controller Class Initialized
DEBUG - 2024-12-16 11:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 11:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:09:28 --> Final output sent to browser
DEBUG - 2024-12-16 11:09:28 --> Total execution time: 0.0446
INFO - 2024-12-16 11:11:02 --> Config Class Initialized
INFO - 2024-12-16 11:11:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:11:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:11:02 --> Utf8 Class Initialized
INFO - 2024-12-16 11:11:02 --> URI Class Initialized
INFO - 2024-12-16 11:11:02 --> Router Class Initialized
INFO - 2024-12-16 11:11:02 --> Output Class Initialized
INFO - 2024-12-16 11:11:02 --> Security Class Initialized
DEBUG - 2024-12-16 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:11:02 --> Input Class Initialized
INFO - 2024-12-16 11:11:02 --> Language Class Initialized
INFO - 2024-12-16 11:11:02 --> Language Class Initialized
INFO - 2024-12-16 11:11:02 --> Config Class Initialized
INFO - 2024-12-16 11:11:02 --> Loader Class Initialized
INFO - 2024-12-16 11:11:02 --> Helper loaded: url_helper
INFO - 2024-12-16 11:11:02 --> Helper loaded: file_helper
INFO - 2024-12-16 11:11:02 --> Helper loaded: form_helper
INFO - 2024-12-16 11:11:02 --> Helper loaded: my_helper
INFO - 2024-12-16 11:11:02 --> Database Driver Class Initialized
INFO - 2024-12-16 11:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:11:02 --> Controller Class Initialized
INFO - 2024-12-16 11:11:02 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:11:02 --> Final output sent to browser
DEBUG - 2024-12-16 11:11:02 --> Total execution time: 0.0793
INFO - 2024-12-16 11:11:03 --> Config Class Initialized
INFO - 2024-12-16 11:11:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:11:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:11:03 --> Utf8 Class Initialized
INFO - 2024-12-16 11:11:03 --> URI Class Initialized
INFO - 2024-12-16 11:11:03 --> Router Class Initialized
INFO - 2024-12-16 11:11:03 --> Output Class Initialized
INFO - 2024-12-16 11:11:03 --> Security Class Initialized
DEBUG - 2024-12-16 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:11:03 --> Input Class Initialized
INFO - 2024-12-16 11:11:03 --> Language Class Initialized
INFO - 2024-12-16 11:11:03 --> Language Class Initialized
INFO - 2024-12-16 11:11:03 --> Config Class Initialized
INFO - 2024-12-16 11:11:03 --> Loader Class Initialized
INFO - 2024-12-16 11:11:03 --> Helper loaded: url_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: file_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: form_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: my_helper
INFO - 2024-12-16 11:11:03 --> Database Driver Class Initialized
INFO - 2024-12-16 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:11:03 --> Controller Class Initialized
INFO - 2024-12-16 11:11:03 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:11:03 --> Config Class Initialized
INFO - 2024-12-16 11:11:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:11:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:11:03 --> Utf8 Class Initialized
INFO - 2024-12-16 11:11:03 --> URI Class Initialized
INFO - 2024-12-16 11:11:03 --> Router Class Initialized
INFO - 2024-12-16 11:11:03 --> Output Class Initialized
INFO - 2024-12-16 11:11:03 --> Security Class Initialized
DEBUG - 2024-12-16 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:11:03 --> Input Class Initialized
INFO - 2024-12-16 11:11:03 --> Language Class Initialized
INFO - 2024-12-16 11:11:03 --> Language Class Initialized
INFO - 2024-12-16 11:11:03 --> Config Class Initialized
INFO - 2024-12-16 11:11:03 --> Loader Class Initialized
INFO - 2024-12-16 11:11:03 --> Helper loaded: url_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: file_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: form_helper
INFO - 2024-12-16 11:11:03 --> Helper loaded: my_helper
INFO - 2024-12-16 11:11:03 --> Database Driver Class Initialized
INFO - 2024-12-16 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:11:03 --> Controller Class Initialized
DEBUG - 2024-12-16 11:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 11:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:11:03 --> Final output sent to browser
DEBUG - 2024-12-16 11:11:03 --> Total execution time: 0.0572
INFO - 2024-12-16 11:11:10 --> Config Class Initialized
INFO - 2024-12-16 11:11:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:11:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:11:10 --> Utf8 Class Initialized
INFO - 2024-12-16 11:11:10 --> URI Class Initialized
INFO - 2024-12-16 11:11:10 --> Router Class Initialized
INFO - 2024-12-16 11:11:10 --> Output Class Initialized
INFO - 2024-12-16 11:11:10 --> Security Class Initialized
DEBUG - 2024-12-16 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:11:10 --> Input Class Initialized
INFO - 2024-12-16 11:11:10 --> Language Class Initialized
INFO - 2024-12-16 11:11:10 --> Language Class Initialized
INFO - 2024-12-16 11:11:10 --> Config Class Initialized
INFO - 2024-12-16 11:11:10 --> Loader Class Initialized
INFO - 2024-12-16 11:11:10 --> Helper loaded: url_helper
INFO - 2024-12-16 11:11:10 --> Helper loaded: file_helper
INFO - 2024-12-16 11:11:10 --> Helper loaded: form_helper
INFO - 2024-12-16 11:11:10 --> Helper loaded: my_helper
INFO - 2024-12-16 11:11:10 --> Database Driver Class Initialized
INFO - 2024-12-16 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:11:10 --> Controller Class Initialized
DEBUG - 2024-12-16 11:11:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:11:15 --> Final output sent to browser
DEBUG - 2024-12-16 11:11:15 --> Total execution time: 5.1869
INFO - 2024-12-16 11:12:14 --> Config Class Initialized
INFO - 2024-12-16 11:12:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:12:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:12:14 --> Utf8 Class Initialized
INFO - 2024-12-16 11:12:14 --> URI Class Initialized
INFO - 2024-12-16 11:12:14 --> Router Class Initialized
INFO - 2024-12-16 11:12:14 --> Output Class Initialized
INFO - 2024-12-16 11:12:14 --> Security Class Initialized
DEBUG - 2024-12-16 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:12:14 --> Input Class Initialized
INFO - 2024-12-16 11:12:14 --> Language Class Initialized
INFO - 2024-12-16 11:12:14 --> Language Class Initialized
INFO - 2024-12-16 11:12:14 --> Config Class Initialized
INFO - 2024-12-16 11:12:14 --> Loader Class Initialized
INFO - 2024-12-16 11:12:14 --> Helper loaded: url_helper
INFO - 2024-12-16 11:12:14 --> Helper loaded: file_helper
INFO - 2024-12-16 11:12:14 --> Helper loaded: form_helper
INFO - 2024-12-16 11:12:14 --> Helper loaded: my_helper
INFO - 2024-12-16 11:12:14 --> Database Driver Class Initialized
INFO - 2024-12-16 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:12:14 --> Controller Class Initialized
DEBUG - 2024-12-16 11:12:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:12:18 --> Final output sent to browser
DEBUG - 2024-12-16 11:12:18 --> Total execution time: 4.2308
INFO - 2024-12-16 11:18:10 --> Config Class Initialized
INFO - 2024-12-16 11:18:10 --> Hooks Class Initialized
INFO - 2024-12-16 11:18:10 --> Config Class Initialized
INFO - 2024-12-16 11:18:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:10 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:10 --> URI Class Initialized
DEBUG - 2024-12-16 11:18:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:10 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:10 --> Router Class Initialized
INFO - 2024-12-16 11:18:10 --> Output Class Initialized
INFO - 2024-12-16 11:18:10 --> URI Class Initialized
INFO - 2024-12-16 11:18:10 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:10 --> Input Class Initialized
INFO - 2024-12-16 11:18:10 --> Language Class Initialized
INFO - 2024-12-16 11:18:11 --> Language Class Initialized
INFO - 2024-12-16 11:18:11 --> Config Class Initialized
INFO - 2024-12-16 11:18:11 --> Loader Class Initialized
INFO - 2024-12-16 11:18:11 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:11 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:11 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:11 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:11 --> Router Class Initialized
INFO - 2024-12-16 11:18:11 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:11 --> Controller Class Initialized
INFO - 2024-12-16 11:18:11 --> Output Class Initialized
INFO - 2024-12-16 11:18:11 --> Config Class Initialized
INFO - 2024-12-16 11:18:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:11 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:11 --> Security Class Initialized
INFO - 2024-12-16 11:18:11 --> URI Class Initialized
DEBUG - 2024-12-16 11:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:11 --> Input Class Initialized
INFO - 2024-12-16 11:18:11 --> Router Class Initialized
INFO - 2024-12-16 11:18:11 --> Language Class Initialized
INFO - 2024-12-16 11:18:11 --> Output Class Initialized
INFO - 2024-12-16 11:18:11 --> Language Class Initialized
INFO - 2024-12-16 11:18:11 --> Config Class Initialized
INFO - 2024-12-16 11:18:11 --> Loader Class Initialized
INFO - 2024-12-16 11:18:11 --> Security Class Initialized
INFO - 2024-12-16 11:18:12 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:12 --> Helper loaded: file_helper
DEBUG - 2024-12-16 11:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:12 --> Input Class Initialized
INFO - 2024-12-16 11:18:12 --> Language Class Initialized
INFO - 2024-12-16 11:18:12 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:12 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:12 --> Language Class Initialized
INFO - 2024-12-16 11:18:12 --> Config Class Initialized
INFO - 2024-12-16 11:18:12 --> Loader Class Initialized
INFO - 2024-12-16 11:18:12 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:12 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:12 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:12 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:12 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:12 --> Controller Class Initialized
INFO - 2024-12-16 11:18:12 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:13 --> Controller Class Initialized
DEBUG - 2024-12-16 11:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 11:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:18:13 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:13 --> Total execution time: 1.7049
INFO - 2024-12-16 11:18:14 --> Config Class Initialized
INFO - 2024-12-16 11:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:14 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:14 --> URI Class Initialized
INFO - 2024-12-16 11:18:14 --> Router Class Initialized
INFO - 2024-12-16 11:18:14 --> Output Class Initialized
INFO - 2024-12-16 11:18:14 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:14 --> Input Class Initialized
INFO - 2024-12-16 11:18:14 --> Language Class Initialized
INFO - 2024-12-16 11:18:14 --> Language Class Initialized
INFO - 2024-12-16 11:18:14 --> Config Class Initialized
INFO - 2024-12-16 11:18:14 --> Loader Class Initialized
INFO - 2024-12-16 11:18:14 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:14 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:14 --> Controller Class Initialized
INFO - 2024-12-16 11:18:14 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:18:14 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:14 --> Total execution time: 0.1493
INFO - 2024-12-16 11:18:14 --> Config Class Initialized
INFO - 2024-12-16 11:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:14 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:14 --> URI Class Initialized
INFO - 2024-12-16 11:18:14 --> Router Class Initialized
INFO - 2024-12-16 11:18:14 --> Output Class Initialized
INFO - 2024-12-16 11:18:14 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:14 --> Input Class Initialized
INFO - 2024-12-16 11:18:14 --> Language Class Initialized
INFO - 2024-12-16 11:18:14 --> Language Class Initialized
INFO - 2024-12-16 11:18:14 --> Config Class Initialized
INFO - 2024-12-16 11:18:14 --> Loader Class Initialized
INFO - 2024-12-16 11:18:14 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:14 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:14 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:14 --> Controller Class Initialized
DEBUG - 2024-12-16 11:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 11:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:18:14 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:14 --> Total execution time: 0.0776
INFO - 2024-12-16 11:18:19 --> Config Class Initialized
INFO - 2024-12-16 11:18:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:19 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:19 --> URI Class Initialized
INFO - 2024-12-16 11:18:19 --> Router Class Initialized
INFO - 2024-12-16 11:18:19 --> Output Class Initialized
INFO - 2024-12-16 11:18:19 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:19 --> Input Class Initialized
INFO - 2024-12-16 11:18:19 --> Language Class Initialized
INFO - 2024-12-16 11:18:20 --> Language Class Initialized
INFO - 2024-12-16 11:18:20 --> Config Class Initialized
INFO - 2024-12-16 11:18:20 --> Loader Class Initialized
INFO - 2024-12-16 11:18:20 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:20 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:20 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:20 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:20 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:20 --> Controller Class Initialized
DEBUG - 2024-12-16 11:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 11:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:18:20 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:20 --> Total execution time: 1.3232
INFO - 2024-12-16 11:18:27 --> Config Class Initialized
INFO - 2024-12-16 11:18:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:27 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:27 --> URI Class Initialized
INFO - 2024-12-16 11:18:27 --> Router Class Initialized
INFO - 2024-12-16 11:18:27 --> Output Class Initialized
INFO - 2024-12-16 11:18:27 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:27 --> Input Class Initialized
INFO - 2024-12-16 11:18:27 --> Language Class Initialized
INFO - 2024-12-16 11:18:27 --> Language Class Initialized
INFO - 2024-12-16 11:18:27 --> Config Class Initialized
INFO - 2024-12-16 11:18:27 --> Loader Class Initialized
INFO - 2024-12-16 11:18:27 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:27 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:27 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:27 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:27 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:27 --> Controller Class Initialized
INFO - 2024-12-16 11:18:29 --> Config Class Initialized
INFO - 2024-12-16 11:18:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:29 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:29 --> URI Class Initialized
INFO - 2024-12-16 11:18:29 --> Router Class Initialized
INFO - 2024-12-16 11:18:29 --> Output Class Initialized
DEBUG - 2024-12-16 11:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:18:29 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:29 --> Input Class Initialized
INFO - 2024-12-16 11:18:29 --> Language Class Initialized
INFO - 2024-12-16 11:18:29 --> Language Class Initialized
INFO - 2024-12-16 11:18:29 --> Config Class Initialized
INFO - 2024-12-16 11:18:29 --> Loader Class Initialized
INFO - 2024-12-16 11:18:29 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:29 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:29 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:29 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:29 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:40 --> Controller Class Initialized
DEBUG - 2024-12-16 11:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:18:48 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:48 --> Total execution time: 19.0858
INFO - 2024-12-16 11:18:58 --> Config Class Initialized
INFO - 2024-12-16 11:18:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:18:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:18:58 --> Utf8 Class Initialized
INFO - 2024-12-16 11:18:58 --> URI Class Initialized
INFO - 2024-12-16 11:18:58 --> Router Class Initialized
INFO - 2024-12-16 11:18:58 --> Output Class Initialized
INFO - 2024-12-16 11:18:58 --> Security Class Initialized
DEBUG - 2024-12-16 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:18:58 --> Input Class Initialized
INFO - 2024-12-16 11:18:58 --> Language Class Initialized
INFO - 2024-12-16 11:18:59 --> Language Class Initialized
INFO - 2024-12-16 11:18:59 --> Config Class Initialized
INFO - 2024-12-16 11:18:59 --> Loader Class Initialized
INFO - 2024-12-16 11:18:59 --> Helper loaded: url_helper
INFO - 2024-12-16 11:18:59 --> Helper loaded: file_helper
INFO - 2024-12-16 11:18:59 --> Helper loaded: form_helper
INFO - 2024-12-16 11:18:59 --> Helper loaded: my_helper
INFO - 2024-12-16 11:18:59 --> Database Driver Class Initialized
INFO - 2024-12-16 11:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:18:59 --> Controller Class Initialized
DEBUG - 2024-12-16 11:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 11:18:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:18:59 --> Final output sent to browser
DEBUG - 2024-12-16 11:18:59 --> Total execution time: 0.0816
INFO - 2024-12-16 11:19:02 --> Config Class Initialized
INFO - 2024-12-16 11:19:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:19:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:19:02 --> Utf8 Class Initialized
INFO - 2024-12-16 11:19:02 --> URI Class Initialized
INFO - 2024-12-16 11:19:02 --> Router Class Initialized
INFO - 2024-12-16 11:19:02 --> Output Class Initialized
INFO - 2024-12-16 11:19:02 --> Security Class Initialized
DEBUG - 2024-12-16 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:19:02 --> Input Class Initialized
INFO - 2024-12-16 11:19:02 --> Language Class Initialized
INFO - 2024-12-16 11:19:02 --> Language Class Initialized
INFO - 2024-12-16 11:19:02 --> Config Class Initialized
INFO - 2024-12-16 11:19:02 --> Loader Class Initialized
INFO - 2024-12-16 11:19:02 --> Helper loaded: url_helper
INFO - 2024-12-16 11:19:02 --> Helper loaded: file_helper
INFO - 2024-12-16 11:19:02 --> Helper loaded: form_helper
INFO - 2024-12-16 11:19:02 --> Helper loaded: my_helper
INFO - 2024-12-16 11:19:02 --> Database Driver Class Initialized
INFO - 2024-12-16 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:19:02 --> Controller Class Initialized
DEBUG - 2024-12-16 11:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 11:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:19:02 --> Final output sent to browser
DEBUG - 2024-12-16 11:19:02 --> Total execution time: 0.0591
INFO - 2024-12-16 11:19:06 --> Config Class Initialized
INFO - 2024-12-16 11:19:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:19:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:19:06 --> Utf8 Class Initialized
INFO - 2024-12-16 11:19:06 --> URI Class Initialized
INFO - 2024-12-16 11:19:06 --> Router Class Initialized
INFO - 2024-12-16 11:19:06 --> Output Class Initialized
INFO - 2024-12-16 11:19:06 --> Security Class Initialized
DEBUG - 2024-12-16 11:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:19:06 --> Input Class Initialized
INFO - 2024-12-16 11:19:06 --> Language Class Initialized
INFO - 2024-12-16 11:19:06 --> Language Class Initialized
INFO - 2024-12-16 11:19:06 --> Config Class Initialized
INFO - 2024-12-16 11:19:06 --> Loader Class Initialized
INFO - 2024-12-16 11:19:06 --> Helper loaded: url_helper
INFO - 2024-12-16 11:19:06 --> Helper loaded: file_helper
INFO - 2024-12-16 11:19:06 --> Helper loaded: form_helper
INFO - 2024-12-16 11:19:06 --> Helper loaded: my_helper
INFO - 2024-12-16 11:19:06 --> Database Driver Class Initialized
INFO - 2024-12-16 11:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:19:06 --> Controller Class Initialized
DEBUG - 2024-12-16 11:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:19:11 --> Final output sent to browser
DEBUG - 2024-12-16 11:19:11 --> Total execution time: 5.3136
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:20:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:20:59 --> Utf8 Class Initialized
INFO - 2024-12-16 11:20:59 --> URI Class Initialized
INFO - 2024-12-16 11:20:59 --> Router Class Initialized
INFO - 2024-12-16 11:20:59 --> Output Class Initialized
INFO - 2024-12-16 11:20:59 --> Security Class Initialized
DEBUG - 2024-12-16 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:20:59 --> Input Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Loader Class Initialized
INFO - 2024-12-16 11:20:59 --> Helper loaded: url_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: file_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: form_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: my_helper
INFO - 2024-12-16 11:20:59 --> Database Driver Class Initialized
INFO - 2024-12-16 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:20:59 --> Controller Class Initialized
INFO - 2024-12-16 11:20:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:20:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:20:59 --> Utf8 Class Initialized
INFO - 2024-12-16 11:20:59 --> URI Class Initialized
INFO - 2024-12-16 11:20:59 --> Router Class Initialized
INFO - 2024-12-16 11:20:59 --> Output Class Initialized
INFO - 2024-12-16 11:20:59 --> Security Class Initialized
DEBUG - 2024-12-16 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:20:59 --> Input Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Loader Class Initialized
INFO - 2024-12-16 11:20:59 --> Helper loaded: url_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: file_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: form_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: my_helper
INFO - 2024-12-16 11:20:59 --> Database Driver Class Initialized
INFO - 2024-12-16 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:20:59 --> Controller Class Initialized
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:20:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:20:59 --> Utf8 Class Initialized
INFO - 2024-12-16 11:20:59 --> URI Class Initialized
INFO - 2024-12-16 11:20:59 --> Router Class Initialized
INFO - 2024-12-16 11:20:59 --> Output Class Initialized
INFO - 2024-12-16 11:20:59 --> Security Class Initialized
DEBUG - 2024-12-16 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:20:59 --> Input Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Language Class Initialized
INFO - 2024-12-16 11:20:59 --> Config Class Initialized
INFO - 2024-12-16 11:20:59 --> Loader Class Initialized
INFO - 2024-12-16 11:20:59 --> Helper loaded: url_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: file_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: form_helper
INFO - 2024-12-16 11:20:59 --> Helper loaded: my_helper
INFO - 2024-12-16 11:20:59 --> Database Driver Class Initialized
INFO - 2024-12-16 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:20:59 --> Controller Class Initialized
DEBUG - 2024-12-16 11:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 11:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:20:59 --> Final output sent to browser
DEBUG - 2024-12-16 11:20:59 --> Total execution time: 0.1474
INFO - 2024-12-16 11:21:07 --> Config Class Initialized
INFO - 2024-12-16 11:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:21:07 --> Utf8 Class Initialized
INFO - 2024-12-16 11:21:07 --> URI Class Initialized
INFO - 2024-12-16 11:21:07 --> Router Class Initialized
INFO - 2024-12-16 11:21:07 --> Output Class Initialized
INFO - 2024-12-16 11:21:07 --> Security Class Initialized
DEBUG - 2024-12-16 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:21:07 --> Input Class Initialized
INFO - 2024-12-16 11:21:07 --> Language Class Initialized
INFO - 2024-12-16 11:21:07 --> Language Class Initialized
INFO - 2024-12-16 11:21:07 --> Config Class Initialized
INFO - 2024-12-16 11:21:07 --> Loader Class Initialized
INFO - 2024-12-16 11:21:07 --> Helper loaded: url_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: file_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: form_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: my_helper
INFO - 2024-12-16 11:21:07 --> Database Driver Class Initialized
INFO - 2024-12-16 11:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:21:07 --> Controller Class Initialized
INFO - 2024-12-16 11:21:07 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:21:07 --> Final output sent to browser
DEBUG - 2024-12-16 11:21:07 --> Total execution time: 0.2128
INFO - 2024-12-16 11:21:07 --> Config Class Initialized
INFO - 2024-12-16 11:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:21:07 --> Utf8 Class Initialized
INFO - 2024-12-16 11:21:07 --> URI Class Initialized
INFO - 2024-12-16 11:21:07 --> Router Class Initialized
INFO - 2024-12-16 11:21:07 --> Output Class Initialized
INFO - 2024-12-16 11:21:07 --> Security Class Initialized
DEBUG - 2024-12-16 11:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:21:07 --> Input Class Initialized
INFO - 2024-12-16 11:21:07 --> Language Class Initialized
INFO - 2024-12-16 11:21:07 --> Language Class Initialized
INFO - 2024-12-16 11:21:07 --> Config Class Initialized
INFO - 2024-12-16 11:21:07 --> Loader Class Initialized
INFO - 2024-12-16 11:21:07 --> Helper loaded: url_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: file_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: form_helper
INFO - 2024-12-16 11:21:07 --> Helper loaded: my_helper
INFO - 2024-12-16 11:21:07 --> Database Driver Class Initialized
INFO - 2024-12-16 11:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:21:08 --> Controller Class Initialized
DEBUG - 2024-12-16 11:21:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 11:21:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:21:08 --> Final output sent to browser
DEBUG - 2024-12-16 11:21:08 --> Total execution time: 0.0765
INFO - 2024-12-16 11:21:22 --> Config Class Initialized
INFO - 2024-12-16 11:21:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:21:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:21:22 --> Utf8 Class Initialized
INFO - 2024-12-16 11:21:22 --> URI Class Initialized
INFO - 2024-12-16 11:21:22 --> Router Class Initialized
INFO - 2024-12-16 11:21:22 --> Output Class Initialized
INFO - 2024-12-16 11:21:22 --> Security Class Initialized
DEBUG - 2024-12-16 11:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:21:22 --> Input Class Initialized
INFO - 2024-12-16 11:21:22 --> Language Class Initialized
INFO - 2024-12-16 11:21:22 --> Language Class Initialized
INFO - 2024-12-16 11:21:22 --> Config Class Initialized
INFO - 2024-12-16 11:21:22 --> Loader Class Initialized
INFO - 2024-12-16 11:21:22 --> Helper loaded: url_helper
INFO - 2024-12-16 11:21:22 --> Helper loaded: file_helper
INFO - 2024-12-16 11:21:22 --> Helper loaded: form_helper
INFO - 2024-12-16 11:21:22 --> Helper loaded: my_helper
INFO - 2024-12-16 11:21:22 --> Database Driver Class Initialized
INFO - 2024-12-16 11:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:21:22 --> Controller Class Initialized
DEBUG - 2024-12-16 11:21:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 11:21:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:21:22 --> Final output sent to browser
DEBUG - 2024-12-16 11:21:22 --> Total execution time: 0.0708
INFO - 2024-12-16 11:22:03 --> Config Class Initialized
INFO - 2024-12-16 11:22:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:22:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:22:03 --> Utf8 Class Initialized
INFO - 2024-12-16 11:22:03 --> URI Class Initialized
INFO - 2024-12-16 11:22:03 --> Router Class Initialized
INFO - 2024-12-16 11:22:03 --> Output Class Initialized
INFO - 2024-12-16 11:22:03 --> Security Class Initialized
DEBUG - 2024-12-16 11:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:22:03 --> Input Class Initialized
INFO - 2024-12-16 11:22:03 --> Language Class Initialized
INFO - 2024-12-16 11:22:03 --> Language Class Initialized
INFO - 2024-12-16 11:22:03 --> Config Class Initialized
INFO - 2024-12-16 11:22:03 --> Loader Class Initialized
INFO - 2024-12-16 11:22:03 --> Helper loaded: url_helper
INFO - 2024-12-16 11:22:03 --> Helper loaded: file_helper
INFO - 2024-12-16 11:22:03 --> Helper loaded: form_helper
INFO - 2024-12-16 11:22:03 --> Helper loaded: my_helper
INFO - 2024-12-16 11:22:03 --> Database Driver Class Initialized
INFO - 2024-12-16 11:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:22:03 --> Controller Class Initialized
DEBUG - 2024-12-16 11:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 11:22:05 --> Final output sent to browser
DEBUG - 2024-12-16 11:22:05 --> Total execution time: 2.3574
INFO - 2024-12-16 11:25:13 --> Config Class Initialized
INFO - 2024-12-16 11:25:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:25:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:25:13 --> Utf8 Class Initialized
INFO - 2024-12-16 11:25:13 --> URI Class Initialized
INFO - 2024-12-16 11:25:13 --> Router Class Initialized
INFO - 2024-12-16 11:25:13 --> Output Class Initialized
INFO - 2024-12-16 11:25:13 --> Security Class Initialized
DEBUG - 2024-12-16 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:25:13 --> Input Class Initialized
INFO - 2024-12-16 11:25:13 --> Language Class Initialized
INFO - 2024-12-16 11:25:13 --> Language Class Initialized
INFO - 2024-12-16 11:25:13 --> Config Class Initialized
INFO - 2024-12-16 11:25:13 --> Loader Class Initialized
INFO - 2024-12-16 11:25:13 --> Helper loaded: url_helper
INFO - 2024-12-16 11:25:13 --> Helper loaded: file_helper
INFO - 2024-12-16 11:25:13 --> Helper loaded: form_helper
INFO - 2024-12-16 11:25:13 --> Helper loaded: my_helper
INFO - 2024-12-16 11:25:13 --> Database Driver Class Initialized
INFO - 2024-12-16 11:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:25:13 --> Controller Class Initialized
DEBUG - 2024-12-16 11:25:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:25:19 --> Final output sent to browser
DEBUG - 2024-12-16 11:25:19 --> Total execution time: 6.0502
INFO - 2024-12-16 11:27:19 --> Config Class Initialized
INFO - 2024-12-16 11:27:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:27:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:27:19 --> Utf8 Class Initialized
INFO - 2024-12-16 11:27:19 --> URI Class Initialized
INFO - 2024-12-16 11:27:19 --> Router Class Initialized
INFO - 2024-12-16 11:27:19 --> Output Class Initialized
INFO - 2024-12-16 11:27:19 --> Security Class Initialized
DEBUG - 2024-12-16 11:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:27:19 --> Input Class Initialized
INFO - 2024-12-16 11:27:19 --> Language Class Initialized
INFO - 2024-12-16 11:27:19 --> Language Class Initialized
INFO - 2024-12-16 11:27:19 --> Config Class Initialized
INFO - 2024-12-16 11:27:19 --> Loader Class Initialized
INFO - 2024-12-16 11:27:19 --> Helper loaded: url_helper
INFO - 2024-12-16 11:27:19 --> Helper loaded: file_helper
INFO - 2024-12-16 11:27:19 --> Helper loaded: form_helper
INFO - 2024-12-16 11:27:19 --> Helper loaded: my_helper
INFO - 2024-12-16 11:27:19 --> Database Driver Class Initialized
INFO - 2024-12-16 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:27:19 --> Controller Class Initialized
DEBUG - 2024-12-16 11:27:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:27:23 --> Config Class Initialized
INFO - 2024-12-16 11:27:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:27:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:27:23 --> Utf8 Class Initialized
INFO - 2024-12-16 11:27:23 --> URI Class Initialized
INFO - 2024-12-16 11:27:23 --> Router Class Initialized
INFO - 2024-12-16 11:27:23 --> Output Class Initialized
INFO - 2024-12-16 11:27:23 --> Security Class Initialized
DEBUG - 2024-12-16 11:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:27:23 --> Input Class Initialized
INFO - 2024-12-16 11:27:23 --> Language Class Initialized
INFO - 2024-12-16 11:27:23 --> Language Class Initialized
INFO - 2024-12-16 11:27:23 --> Config Class Initialized
INFO - 2024-12-16 11:27:23 --> Loader Class Initialized
INFO - 2024-12-16 11:27:23 --> Helper loaded: url_helper
INFO - 2024-12-16 11:27:23 --> Helper loaded: file_helper
INFO - 2024-12-16 11:27:23 --> Helper loaded: form_helper
INFO - 2024-12-16 11:27:23 --> Helper loaded: my_helper
INFO - 2024-12-16 11:27:23 --> Database Driver Class Initialized
INFO - 2024-12-16 11:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:27:23 --> Controller Class Initialized
DEBUG - 2024-12-16 11:27:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:27:24 --> Final output sent to browser
DEBUG - 2024-12-16 11:27:24 --> Total execution time: 5.2658
INFO - 2024-12-16 11:27:29 --> Final output sent to browser
DEBUG - 2024-12-16 11:27:29 --> Total execution time: 6.2810
INFO - 2024-12-16 11:38:42 --> Config Class Initialized
INFO - 2024-12-16 11:38:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:38:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:38:42 --> Utf8 Class Initialized
INFO - 2024-12-16 11:38:42 --> URI Class Initialized
INFO - 2024-12-16 11:38:42 --> Router Class Initialized
INFO - 2024-12-16 11:38:42 --> Output Class Initialized
INFO - 2024-12-16 11:38:42 --> Security Class Initialized
DEBUG - 2024-12-16 11:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:38:42 --> Input Class Initialized
INFO - 2024-12-16 11:38:42 --> Language Class Initialized
INFO - 2024-12-16 11:38:42 --> Language Class Initialized
INFO - 2024-12-16 11:38:42 --> Config Class Initialized
INFO - 2024-12-16 11:38:42 --> Loader Class Initialized
INFO - 2024-12-16 11:38:42 --> Helper loaded: url_helper
INFO - 2024-12-16 11:38:42 --> Helper loaded: file_helper
INFO - 2024-12-16 11:38:42 --> Helper loaded: form_helper
INFO - 2024-12-16 11:38:42 --> Helper loaded: my_helper
INFO - 2024-12-16 11:38:42 --> Database Driver Class Initialized
INFO - 2024-12-16 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:38:42 --> Controller Class Initialized
DEBUG - 2024-12-16 11:38:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 11:38:54 --> Final output sent to browser
DEBUG - 2024-12-16 11:38:54 --> Total execution time: 11.7911
INFO - 2024-12-16 11:39:53 --> Config Class Initialized
INFO - 2024-12-16 11:39:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:39:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:39:53 --> Utf8 Class Initialized
INFO - 2024-12-16 11:39:53 --> URI Class Initialized
INFO - 2024-12-16 11:39:53 --> Router Class Initialized
INFO - 2024-12-16 11:39:53 --> Output Class Initialized
INFO - 2024-12-16 11:39:53 --> Security Class Initialized
DEBUG - 2024-12-16 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:39:53 --> Input Class Initialized
INFO - 2024-12-16 11:39:53 --> Language Class Initialized
INFO - 2024-12-16 11:39:53 --> Language Class Initialized
INFO - 2024-12-16 11:39:53 --> Config Class Initialized
INFO - 2024-12-16 11:39:53 --> Loader Class Initialized
INFO - 2024-12-16 11:39:53 --> Helper loaded: url_helper
INFO - 2024-12-16 11:39:53 --> Helper loaded: file_helper
INFO - 2024-12-16 11:39:53 --> Helper loaded: form_helper
INFO - 2024-12-16 11:39:53 --> Helper loaded: my_helper
INFO - 2024-12-16 11:39:53 --> Database Driver Class Initialized
INFO - 2024-12-16 11:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:39:53 --> Controller Class Initialized
DEBUG - 2024-12-16 11:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:39:57 --> Final output sent to browser
DEBUG - 2024-12-16 11:39:57 --> Total execution time: 3.9721
INFO - 2024-12-16 11:40:41 --> Config Class Initialized
INFO - 2024-12-16 11:40:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:40:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:40:41 --> Utf8 Class Initialized
INFO - 2024-12-16 11:40:41 --> URI Class Initialized
INFO - 2024-12-16 11:40:41 --> Router Class Initialized
INFO - 2024-12-16 11:40:41 --> Output Class Initialized
INFO - 2024-12-16 11:40:41 --> Security Class Initialized
DEBUG - 2024-12-16 11:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:40:41 --> Input Class Initialized
INFO - 2024-12-16 11:40:41 --> Language Class Initialized
INFO - 2024-12-16 11:40:41 --> Language Class Initialized
INFO - 2024-12-16 11:40:41 --> Config Class Initialized
INFO - 2024-12-16 11:40:41 --> Loader Class Initialized
INFO - 2024-12-16 11:40:41 --> Helper loaded: url_helper
INFO - 2024-12-16 11:40:41 --> Helper loaded: file_helper
INFO - 2024-12-16 11:40:41 --> Helper loaded: form_helper
INFO - 2024-12-16 11:40:41 --> Helper loaded: my_helper
INFO - 2024-12-16 11:40:41 --> Database Driver Class Initialized
INFO - 2024-12-16 11:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:40:41 --> Controller Class Initialized
DEBUG - 2024-12-16 11:40:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 11:40:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:40:41 --> Final output sent to browser
DEBUG - 2024-12-16 11:40:41 --> Total execution time: 0.2607
INFO - 2024-12-16 11:41:42 --> Config Class Initialized
INFO - 2024-12-16 11:41:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:41:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:41:42 --> Utf8 Class Initialized
INFO - 2024-12-16 11:41:42 --> URI Class Initialized
INFO - 2024-12-16 11:41:42 --> Router Class Initialized
INFO - 2024-12-16 11:41:42 --> Output Class Initialized
INFO - 2024-12-16 11:41:42 --> Security Class Initialized
DEBUG - 2024-12-16 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:41:42 --> Input Class Initialized
INFO - 2024-12-16 11:41:42 --> Language Class Initialized
INFO - 2024-12-16 11:41:42 --> Language Class Initialized
INFO - 2024-12-16 11:41:42 --> Config Class Initialized
INFO - 2024-12-16 11:41:42 --> Loader Class Initialized
INFO - 2024-12-16 11:41:42 --> Helper loaded: url_helper
INFO - 2024-12-16 11:41:42 --> Helper loaded: file_helper
INFO - 2024-12-16 11:41:42 --> Helper loaded: form_helper
INFO - 2024-12-16 11:41:42 --> Helper loaded: my_helper
INFO - 2024-12-16 11:41:42 --> Database Driver Class Initialized
INFO - 2024-12-16 11:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:41:42 --> Controller Class Initialized
DEBUG - 2024-12-16 11:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:41:48 --> Final output sent to browser
DEBUG - 2024-12-16 11:41:48 --> Total execution time: 5.2418
INFO - 2024-12-16 11:43:13 --> Config Class Initialized
INFO - 2024-12-16 11:43:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:43:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:43:13 --> Utf8 Class Initialized
INFO - 2024-12-16 11:43:13 --> URI Class Initialized
INFO - 2024-12-16 11:43:13 --> Router Class Initialized
INFO - 2024-12-16 11:43:13 --> Output Class Initialized
INFO - 2024-12-16 11:43:13 --> Security Class Initialized
DEBUG - 2024-12-16 11:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:43:13 --> Input Class Initialized
INFO - 2024-12-16 11:43:13 --> Language Class Initialized
INFO - 2024-12-16 11:43:13 --> Language Class Initialized
INFO - 2024-12-16 11:43:13 --> Config Class Initialized
INFO - 2024-12-16 11:43:13 --> Loader Class Initialized
INFO - 2024-12-16 11:43:13 --> Helper loaded: url_helper
INFO - 2024-12-16 11:43:13 --> Helper loaded: file_helper
INFO - 2024-12-16 11:43:13 --> Helper loaded: form_helper
INFO - 2024-12-16 11:43:13 --> Helper loaded: my_helper
INFO - 2024-12-16 11:43:13 --> Database Driver Class Initialized
INFO - 2024-12-16 11:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:43:13 --> Controller Class Initialized
DEBUG - 2024-12-16 11:43:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:43:17 --> Final output sent to browser
DEBUG - 2024-12-16 11:43:17 --> Total execution time: 3.7890
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:48:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:48:09 --> Utf8 Class Initialized
INFO - 2024-12-16 11:48:09 --> URI Class Initialized
INFO - 2024-12-16 11:48:09 --> Router Class Initialized
INFO - 2024-12-16 11:48:09 --> Output Class Initialized
INFO - 2024-12-16 11:48:09 --> Security Class Initialized
DEBUG - 2024-12-16 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:48:09 --> Input Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Loader Class Initialized
INFO - 2024-12-16 11:48:09 --> Helper loaded: url_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: file_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: form_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: my_helper
INFO - 2024-12-16 11:48:09 --> Database Driver Class Initialized
INFO - 2024-12-16 11:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:48:09 --> Controller Class Initialized
INFO - 2024-12-16 11:48:09 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:48:09 --> Final output sent to browser
DEBUG - 2024-12-16 11:48:09 --> Total execution time: 0.0647
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:48:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:48:09 --> Utf8 Class Initialized
INFO - 2024-12-16 11:48:09 --> URI Class Initialized
INFO - 2024-12-16 11:48:09 --> Router Class Initialized
INFO - 2024-12-16 11:48:09 --> Output Class Initialized
INFO - 2024-12-16 11:48:09 --> Security Class Initialized
DEBUG - 2024-12-16 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:48:09 --> Input Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Loader Class Initialized
INFO - 2024-12-16 11:48:09 --> Helper loaded: url_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: file_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: form_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: my_helper
INFO - 2024-12-16 11:48:09 --> Database Driver Class Initialized
INFO - 2024-12-16 11:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:48:09 --> Controller Class Initialized
INFO - 2024-12-16 11:48:09 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:48:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:48:09 --> Utf8 Class Initialized
INFO - 2024-12-16 11:48:09 --> URI Class Initialized
INFO - 2024-12-16 11:48:09 --> Router Class Initialized
INFO - 2024-12-16 11:48:09 --> Output Class Initialized
INFO - 2024-12-16 11:48:09 --> Security Class Initialized
DEBUG - 2024-12-16 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:48:09 --> Input Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Language Class Initialized
INFO - 2024-12-16 11:48:09 --> Config Class Initialized
INFO - 2024-12-16 11:48:09 --> Loader Class Initialized
INFO - 2024-12-16 11:48:09 --> Helper loaded: url_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: file_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: form_helper
INFO - 2024-12-16 11:48:09 --> Helper loaded: my_helper
INFO - 2024-12-16 11:48:09 --> Database Driver Class Initialized
INFO - 2024-12-16 11:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:48:09 --> Controller Class Initialized
DEBUG - 2024-12-16 11:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 11:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:48:09 --> Final output sent to browser
DEBUG - 2024-12-16 11:48:09 --> Total execution time: 0.0382
INFO - 2024-12-16 11:48:17 --> Config Class Initialized
INFO - 2024-12-16 11:48:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:48:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:48:17 --> Utf8 Class Initialized
INFO - 2024-12-16 11:48:17 --> URI Class Initialized
INFO - 2024-12-16 11:48:17 --> Router Class Initialized
INFO - 2024-12-16 11:48:17 --> Output Class Initialized
INFO - 2024-12-16 11:48:17 --> Security Class Initialized
DEBUG - 2024-12-16 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:48:17 --> Input Class Initialized
INFO - 2024-12-16 11:48:17 --> Language Class Initialized
INFO - 2024-12-16 11:48:17 --> Language Class Initialized
INFO - 2024-12-16 11:48:17 --> Config Class Initialized
INFO - 2024-12-16 11:48:17 --> Loader Class Initialized
INFO - 2024-12-16 11:48:17 --> Helper loaded: url_helper
INFO - 2024-12-16 11:48:17 --> Helper loaded: file_helper
INFO - 2024-12-16 11:48:17 --> Helper loaded: form_helper
INFO - 2024-12-16 11:48:17 --> Helper loaded: my_helper
INFO - 2024-12-16 11:48:17 --> Database Driver Class Initialized
INFO - 2024-12-16 11:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:48:17 --> Controller Class Initialized
DEBUG - 2024-12-16 11:48:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:48:23 --> Final output sent to browser
DEBUG - 2024-12-16 11:48:23 --> Total execution time: 5.2301
INFO - 2024-12-16 11:49:02 --> Config Class Initialized
INFO - 2024-12-16 11:49:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:49:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:49:02 --> Utf8 Class Initialized
INFO - 2024-12-16 11:49:02 --> URI Class Initialized
INFO - 2024-12-16 11:49:02 --> Router Class Initialized
INFO - 2024-12-16 11:49:02 --> Output Class Initialized
INFO - 2024-12-16 11:49:02 --> Security Class Initialized
DEBUG - 2024-12-16 11:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:49:02 --> Input Class Initialized
INFO - 2024-12-16 11:49:02 --> Language Class Initialized
INFO - 2024-12-16 11:49:02 --> Language Class Initialized
INFO - 2024-12-16 11:49:02 --> Config Class Initialized
INFO - 2024-12-16 11:49:02 --> Loader Class Initialized
INFO - 2024-12-16 11:49:02 --> Helper loaded: url_helper
INFO - 2024-12-16 11:49:02 --> Helper loaded: file_helper
INFO - 2024-12-16 11:49:02 --> Helper loaded: form_helper
INFO - 2024-12-16 11:49:02 --> Helper loaded: my_helper
INFO - 2024-12-16 11:49:02 --> Database Driver Class Initialized
INFO - 2024-12-16 11:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:49:02 --> Controller Class Initialized
DEBUG - 2024-12-16 11:49:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 11:49:05 --> Final output sent to browser
DEBUG - 2024-12-16 11:49:05 --> Total execution time: 2.9147
INFO - 2024-12-16 11:49:16 --> Config Class Initialized
INFO - 2024-12-16 11:49:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:49:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:49:16 --> Utf8 Class Initialized
INFO - 2024-12-16 11:49:16 --> URI Class Initialized
INFO - 2024-12-16 11:49:16 --> Router Class Initialized
INFO - 2024-12-16 11:49:16 --> Output Class Initialized
INFO - 2024-12-16 11:49:16 --> Security Class Initialized
DEBUG - 2024-12-16 11:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:49:16 --> Input Class Initialized
INFO - 2024-12-16 11:49:16 --> Language Class Initialized
INFO - 2024-12-16 11:49:16 --> Language Class Initialized
INFO - 2024-12-16 11:49:16 --> Config Class Initialized
INFO - 2024-12-16 11:49:16 --> Loader Class Initialized
INFO - 2024-12-16 11:49:16 --> Helper loaded: url_helper
INFO - 2024-12-16 11:49:16 --> Helper loaded: file_helper
INFO - 2024-12-16 11:49:16 --> Helper loaded: form_helper
INFO - 2024-12-16 11:49:16 --> Helper loaded: my_helper
INFO - 2024-12-16 11:49:16 --> Database Driver Class Initialized
INFO - 2024-12-16 11:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:49:16 --> Controller Class Initialized
DEBUG - 2024-12-16 11:49:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:49:21 --> Final output sent to browser
DEBUG - 2024-12-16 11:49:21 --> Total execution time: 4.9831
INFO - 2024-12-16 11:51:46 --> Config Class Initialized
INFO - 2024-12-16 11:51:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:51:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:51:46 --> Utf8 Class Initialized
INFO - 2024-12-16 11:51:46 --> URI Class Initialized
INFO - 2024-12-16 11:51:46 --> Router Class Initialized
INFO - 2024-12-16 11:51:46 --> Output Class Initialized
INFO - 2024-12-16 11:51:46 --> Security Class Initialized
DEBUG - 2024-12-16 11:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:51:46 --> Input Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Config Class Initialized
INFO - 2024-12-16 11:51:47 --> Loader Class Initialized
INFO - 2024-12-16 11:51:47 --> Helper loaded: url_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: file_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: form_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: my_helper
INFO - 2024-12-16 11:51:47 --> Database Driver Class Initialized
INFO - 2024-12-16 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:51:47 --> Controller Class Initialized
INFO - 2024-12-16 11:51:47 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:51:47 --> Final output sent to browser
DEBUG - 2024-12-16 11:51:47 --> Total execution time: 0.5880
INFO - 2024-12-16 11:51:47 --> Config Class Initialized
INFO - 2024-12-16 11:51:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:51:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:51:47 --> Utf8 Class Initialized
INFO - 2024-12-16 11:51:47 --> URI Class Initialized
INFO - 2024-12-16 11:51:47 --> Router Class Initialized
INFO - 2024-12-16 11:51:47 --> Output Class Initialized
INFO - 2024-12-16 11:51:47 --> Security Class Initialized
DEBUG - 2024-12-16 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:51:47 --> Input Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Config Class Initialized
INFO - 2024-12-16 11:51:47 --> Loader Class Initialized
INFO - 2024-12-16 11:51:47 --> Helper loaded: url_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: file_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: form_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: my_helper
INFO - 2024-12-16 11:51:47 --> Database Driver Class Initialized
INFO - 2024-12-16 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:51:47 --> Controller Class Initialized
INFO - 2024-12-16 11:51:47 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:51:47 --> Config Class Initialized
INFO - 2024-12-16 11:51:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:51:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:51:47 --> Utf8 Class Initialized
INFO - 2024-12-16 11:51:47 --> URI Class Initialized
INFO - 2024-12-16 11:51:47 --> Router Class Initialized
INFO - 2024-12-16 11:51:47 --> Output Class Initialized
INFO - 2024-12-16 11:51:47 --> Security Class Initialized
DEBUG - 2024-12-16 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:51:47 --> Input Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Language Class Initialized
INFO - 2024-12-16 11:51:47 --> Config Class Initialized
INFO - 2024-12-16 11:51:47 --> Loader Class Initialized
INFO - 2024-12-16 11:51:47 --> Helper loaded: url_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: file_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: form_helper
INFO - 2024-12-16 11:51:47 --> Helper loaded: my_helper
INFO - 2024-12-16 11:51:47 --> Database Driver Class Initialized
INFO - 2024-12-16 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:51:47 --> Controller Class Initialized
DEBUG - 2024-12-16 11:51:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 11:51:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:51:48 --> Final output sent to browser
DEBUG - 2024-12-16 11:51:48 --> Total execution time: 0.2533
INFO - 2024-12-16 11:51:49 --> Config Class Initialized
INFO - 2024-12-16 11:51:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:51:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:51:49 --> Utf8 Class Initialized
INFO - 2024-12-16 11:51:49 --> URI Class Initialized
INFO - 2024-12-16 11:51:49 --> Router Class Initialized
INFO - 2024-12-16 11:51:49 --> Output Class Initialized
INFO - 2024-12-16 11:51:49 --> Security Class Initialized
DEBUG - 2024-12-16 11:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:51:49 --> Input Class Initialized
INFO - 2024-12-16 11:51:49 --> Language Class Initialized
INFO - 2024-12-16 11:51:49 --> Language Class Initialized
INFO - 2024-12-16 11:51:49 --> Config Class Initialized
INFO - 2024-12-16 11:51:49 --> Loader Class Initialized
INFO - 2024-12-16 11:51:49 --> Helper loaded: url_helper
INFO - 2024-12-16 11:51:49 --> Helper loaded: file_helper
INFO - 2024-12-16 11:51:49 --> Helper loaded: form_helper
INFO - 2024-12-16 11:51:49 --> Helper loaded: my_helper
INFO - 2024-12-16 11:51:49 --> Database Driver Class Initialized
INFO - 2024-12-16 11:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:51:49 --> Controller Class Initialized
DEBUG - 2024-12-16 11:51:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:51:55 --> Final output sent to browser
DEBUG - 2024-12-16 11:51:55 --> Total execution time: 6.0830
INFO - 2024-12-16 11:52:00 --> Config Class Initialized
INFO - 2024-12-16 11:52:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:52:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:52:00 --> Utf8 Class Initialized
INFO - 2024-12-16 11:52:00 --> URI Class Initialized
INFO - 2024-12-16 11:52:00 --> Router Class Initialized
INFO - 2024-12-16 11:52:00 --> Output Class Initialized
INFO - 2024-12-16 11:52:00 --> Security Class Initialized
DEBUG - 2024-12-16 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:52:00 --> Input Class Initialized
INFO - 2024-12-16 11:52:00 --> Language Class Initialized
INFO - 2024-12-16 11:52:00 --> Language Class Initialized
INFO - 2024-12-16 11:52:00 --> Config Class Initialized
INFO - 2024-12-16 11:52:00 --> Loader Class Initialized
INFO - 2024-12-16 11:52:00 --> Helper loaded: url_helper
INFO - 2024-12-16 11:52:00 --> Helper loaded: file_helper
INFO - 2024-12-16 11:52:00 --> Helper loaded: form_helper
INFO - 2024-12-16 11:52:00 --> Helper loaded: my_helper
INFO - 2024-12-16 11:52:00 --> Database Driver Class Initialized
INFO - 2024-12-16 11:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:52:00 --> Controller Class Initialized
DEBUG - 2024-12-16 11:52:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 11:52:02 --> Final output sent to browser
DEBUG - 2024-12-16 11:52:02 --> Total execution time: 2.3238
INFO - 2024-12-16 11:53:44 --> Config Class Initialized
INFO - 2024-12-16 11:53:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:53:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:53:44 --> Utf8 Class Initialized
INFO - 2024-12-16 11:53:44 --> URI Class Initialized
INFO - 2024-12-16 11:53:44 --> Router Class Initialized
INFO - 2024-12-16 11:53:44 --> Output Class Initialized
INFO - 2024-12-16 11:53:44 --> Security Class Initialized
DEBUG - 2024-12-16 11:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:53:44 --> Input Class Initialized
INFO - 2024-12-16 11:53:44 --> Language Class Initialized
INFO - 2024-12-16 11:53:44 --> Language Class Initialized
INFO - 2024-12-16 11:53:44 --> Config Class Initialized
INFO - 2024-12-16 11:53:44 --> Loader Class Initialized
INFO - 2024-12-16 11:53:44 --> Helper loaded: url_helper
INFO - 2024-12-16 11:53:44 --> Helper loaded: file_helper
INFO - 2024-12-16 11:53:44 --> Helper loaded: form_helper
INFO - 2024-12-16 11:53:44 --> Helper loaded: my_helper
INFO - 2024-12-16 11:53:44 --> Database Driver Class Initialized
INFO - 2024-12-16 11:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:53:44 --> Controller Class Initialized
DEBUG - 2024-12-16 11:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:53:49 --> Final output sent to browser
DEBUG - 2024-12-16 11:53:49 --> Total execution time: 5.4763
INFO - 2024-12-16 11:54:38 --> Config Class Initialized
INFO - 2024-12-16 11:54:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:54:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:54:38 --> Utf8 Class Initialized
INFO - 2024-12-16 11:54:38 --> URI Class Initialized
INFO - 2024-12-16 11:54:38 --> Router Class Initialized
INFO - 2024-12-16 11:54:38 --> Output Class Initialized
INFO - 2024-12-16 11:54:38 --> Security Class Initialized
DEBUG - 2024-12-16 11:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:54:38 --> Input Class Initialized
INFO - 2024-12-16 11:54:38 --> Language Class Initialized
INFO - 2024-12-16 11:54:38 --> Language Class Initialized
INFO - 2024-12-16 11:54:38 --> Config Class Initialized
INFO - 2024-12-16 11:54:38 --> Loader Class Initialized
INFO - 2024-12-16 11:54:38 --> Helper loaded: url_helper
INFO - 2024-12-16 11:54:38 --> Helper loaded: file_helper
INFO - 2024-12-16 11:54:38 --> Helper loaded: form_helper
INFO - 2024-12-16 11:54:38 --> Helper loaded: my_helper
INFO - 2024-12-16 11:54:38 --> Database Driver Class Initialized
INFO - 2024-12-16 11:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:54:38 --> Controller Class Initialized
DEBUG - 2024-12-16 11:54:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 11:54:42 --> Final output sent to browser
DEBUG - 2024-12-16 11:54:42 --> Total execution time: 3.8621
INFO - 2024-12-16 11:56:42 --> Config Class Initialized
INFO - 2024-12-16 11:56:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:56:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:56:42 --> Utf8 Class Initialized
INFO - 2024-12-16 11:56:42 --> URI Class Initialized
INFO - 2024-12-16 11:56:42 --> Router Class Initialized
INFO - 2024-12-16 11:56:42 --> Output Class Initialized
INFO - 2024-12-16 11:56:42 --> Security Class Initialized
DEBUG - 2024-12-16 11:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:56:42 --> Input Class Initialized
INFO - 2024-12-16 11:56:42 --> Language Class Initialized
INFO - 2024-12-16 11:56:42 --> Language Class Initialized
INFO - 2024-12-16 11:56:42 --> Config Class Initialized
INFO - 2024-12-16 11:56:42 --> Loader Class Initialized
INFO - 2024-12-16 11:56:42 --> Helper loaded: url_helper
INFO - 2024-12-16 11:56:42 --> Helper loaded: file_helper
INFO - 2024-12-16 11:56:42 --> Helper loaded: form_helper
INFO - 2024-12-16 11:56:42 --> Helper loaded: my_helper
INFO - 2024-12-16 11:56:42 --> Database Driver Class Initialized
INFO - 2024-12-16 11:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:56:42 --> Controller Class Initialized
DEBUG - 2024-12-16 11:56:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 11:56:44 --> Final output sent to browser
DEBUG - 2024-12-16 11:56:44 --> Total execution time: 1.8571
INFO - 2024-12-16 11:57:37 --> Config Class Initialized
INFO - 2024-12-16 11:57:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:57:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:57:37 --> Utf8 Class Initialized
INFO - 2024-12-16 11:57:37 --> URI Class Initialized
INFO - 2024-12-16 11:57:37 --> Router Class Initialized
INFO - 2024-12-16 11:57:37 --> Output Class Initialized
INFO - 2024-12-16 11:57:37 --> Security Class Initialized
DEBUG - 2024-12-16 11:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:57:37 --> Input Class Initialized
INFO - 2024-12-16 11:57:37 --> Language Class Initialized
INFO - 2024-12-16 11:57:37 --> Language Class Initialized
INFO - 2024-12-16 11:57:37 --> Config Class Initialized
INFO - 2024-12-16 11:57:37 --> Loader Class Initialized
INFO - 2024-12-16 11:57:37 --> Helper loaded: url_helper
INFO - 2024-12-16 11:57:37 --> Helper loaded: file_helper
INFO - 2024-12-16 11:57:37 --> Helper loaded: form_helper
INFO - 2024-12-16 11:57:37 --> Helper loaded: my_helper
INFO - 2024-12-16 11:57:37 --> Database Driver Class Initialized
INFO - 2024-12-16 11:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:57:37 --> Controller Class Initialized
DEBUG - 2024-12-16 11:57:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 11:57:43 --> Final output sent to browser
DEBUG - 2024-12-16 11:57:43 --> Total execution time: 5.3214
INFO - 2024-12-16 11:59:38 --> Config Class Initialized
INFO - 2024-12-16 11:59:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:59:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:59:38 --> Utf8 Class Initialized
INFO - 2024-12-16 11:59:38 --> URI Class Initialized
INFO - 2024-12-16 11:59:38 --> Router Class Initialized
INFO - 2024-12-16 11:59:38 --> Output Class Initialized
INFO - 2024-12-16 11:59:38 --> Security Class Initialized
DEBUG - 2024-12-16 11:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:59:38 --> Input Class Initialized
INFO - 2024-12-16 11:59:38 --> Language Class Initialized
INFO - 2024-12-16 11:59:38 --> Language Class Initialized
INFO - 2024-12-16 11:59:38 --> Config Class Initialized
INFO - 2024-12-16 11:59:38 --> Loader Class Initialized
INFO - 2024-12-16 11:59:38 --> Helper loaded: url_helper
INFO - 2024-12-16 11:59:38 --> Helper loaded: file_helper
INFO - 2024-12-16 11:59:38 --> Helper loaded: form_helper
INFO - 2024-12-16 11:59:38 --> Helper loaded: my_helper
INFO - 2024-12-16 11:59:38 --> Database Driver Class Initialized
INFO - 2024-12-16 11:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:59:38 --> Controller Class Initialized
INFO - 2024-12-16 11:59:38 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:59:38 --> Final output sent to browser
DEBUG - 2024-12-16 11:59:38 --> Total execution time: 0.0863
INFO - 2024-12-16 11:59:40 --> Config Class Initialized
INFO - 2024-12-16 11:59:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:59:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:59:40 --> Utf8 Class Initialized
INFO - 2024-12-16 11:59:40 --> URI Class Initialized
INFO - 2024-12-16 11:59:40 --> Router Class Initialized
INFO - 2024-12-16 11:59:40 --> Output Class Initialized
INFO - 2024-12-16 11:59:40 --> Security Class Initialized
DEBUG - 2024-12-16 11:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:59:40 --> Input Class Initialized
INFO - 2024-12-16 11:59:40 --> Language Class Initialized
INFO - 2024-12-16 11:59:40 --> Language Class Initialized
INFO - 2024-12-16 11:59:40 --> Config Class Initialized
INFO - 2024-12-16 11:59:40 --> Loader Class Initialized
INFO - 2024-12-16 11:59:40 --> Helper loaded: url_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: file_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: form_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: my_helper
INFO - 2024-12-16 11:59:40 --> Database Driver Class Initialized
INFO - 2024-12-16 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:59:40 --> Controller Class Initialized
INFO - 2024-12-16 11:59:40 --> Helper loaded: cookie_helper
INFO - 2024-12-16 11:59:40 --> Config Class Initialized
INFO - 2024-12-16 11:59:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 11:59:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 11:59:40 --> Utf8 Class Initialized
INFO - 2024-12-16 11:59:40 --> URI Class Initialized
INFO - 2024-12-16 11:59:40 --> Router Class Initialized
INFO - 2024-12-16 11:59:40 --> Output Class Initialized
INFO - 2024-12-16 11:59:40 --> Security Class Initialized
DEBUG - 2024-12-16 11:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 11:59:40 --> Input Class Initialized
INFO - 2024-12-16 11:59:40 --> Language Class Initialized
INFO - 2024-12-16 11:59:40 --> Language Class Initialized
INFO - 2024-12-16 11:59:40 --> Config Class Initialized
INFO - 2024-12-16 11:59:40 --> Loader Class Initialized
INFO - 2024-12-16 11:59:40 --> Helper loaded: url_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: file_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: form_helper
INFO - 2024-12-16 11:59:40 --> Helper loaded: my_helper
INFO - 2024-12-16 11:59:40 --> Database Driver Class Initialized
INFO - 2024-12-16 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 11:59:40 --> Controller Class Initialized
DEBUG - 2024-12-16 11:59:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 11:59:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 11:59:40 --> Final output sent to browser
DEBUG - 2024-12-16 11:59:40 --> Total execution time: 0.0437
INFO - 2024-12-16 12:00:16 --> Config Class Initialized
INFO - 2024-12-16 12:00:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:00:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:00:16 --> Utf8 Class Initialized
INFO - 2024-12-16 12:00:16 --> URI Class Initialized
INFO - 2024-12-16 12:00:16 --> Router Class Initialized
INFO - 2024-12-16 12:00:16 --> Output Class Initialized
INFO - 2024-12-16 12:00:16 --> Security Class Initialized
DEBUG - 2024-12-16 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:00:16 --> Input Class Initialized
INFO - 2024-12-16 12:00:16 --> Language Class Initialized
INFO - 2024-12-16 12:00:16 --> Language Class Initialized
INFO - 2024-12-16 12:00:16 --> Config Class Initialized
INFO - 2024-12-16 12:00:16 --> Loader Class Initialized
INFO - 2024-12-16 12:00:16 --> Helper loaded: url_helper
INFO - 2024-12-16 12:00:16 --> Helper loaded: file_helper
INFO - 2024-12-16 12:00:16 --> Helper loaded: form_helper
INFO - 2024-12-16 12:00:16 --> Helper loaded: my_helper
INFO - 2024-12-16 12:00:16 --> Database Driver Class Initialized
INFO - 2024-12-16 12:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:00:16 --> Controller Class Initialized
DEBUG - 2024-12-16 12:00:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:00:21 --> Final output sent to browser
DEBUG - 2024-12-16 12:00:21 --> Total execution time: 4.5254
INFO - 2024-12-16 12:02:15 --> Config Class Initialized
INFO - 2024-12-16 12:02:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:02:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:02:15 --> Utf8 Class Initialized
INFO - 2024-12-16 12:02:15 --> URI Class Initialized
INFO - 2024-12-16 12:02:15 --> Router Class Initialized
INFO - 2024-12-16 12:02:15 --> Output Class Initialized
INFO - 2024-12-16 12:02:15 --> Security Class Initialized
DEBUG - 2024-12-16 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:02:15 --> Input Class Initialized
INFO - 2024-12-16 12:02:15 --> Language Class Initialized
INFO - 2024-12-16 12:02:15 --> Language Class Initialized
INFO - 2024-12-16 12:02:15 --> Config Class Initialized
INFO - 2024-12-16 12:02:15 --> Loader Class Initialized
INFO - 2024-12-16 12:02:15 --> Helper loaded: url_helper
INFO - 2024-12-16 12:02:15 --> Helper loaded: file_helper
INFO - 2024-12-16 12:02:15 --> Helper loaded: form_helper
INFO - 2024-12-16 12:02:15 --> Helper loaded: my_helper
INFO - 2024-12-16 12:02:15 --> Database Driver Class Initialized
INFO - 2024-12-16 12:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:02:15 --> Controller Class Initialized
DEBUG - 2024-12-16 12:02:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:02:19 --> Final output sent to browser
DEBUG - 2024-12-16 12:02:19 --> Total execution time: 3.4654
INFO - 2024-12-16 12:03:01 --> Config Class Initialized
INFO - 2024-12-16 12:03:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:03:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:03:01 --> Utf8 Class Initialized
INFO - 2024-12-16 12:03:01 --> URI Class Initialized
INFO - 2024-12-16 12:03:01 --> Router Class Initialized
INFO - 2024-12-16 12:03:01 --> Output Class Initialized
INFO - 2024-12-16 12:03:01 --> Security Class Initialized
DEBUG - 2024-12-16 12:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:03:01 --> Input Class Initialized
INFO - 2024-12-16 12:03:01 --> Language Class Initialized
INFO - 2024-12-16 12:03:01 --> Language Class Initialized
INFO - 2024-12-16 12:03:01 --> Config Class Initialized
INFO - 2024-12-16 12:03:01 --> Loader Class Initialized
INFO - 2024-12-16 12:03:01 --> Helper loaded: url_helper
INFO - 2024-12-16 12:03:01 --> Helper loaded: file_helper
INFO - 2024-12-16 12:03:01 --> Helper loaded: form_helper
INFO - 2024-12-16 12:03:01 --> Helper loaded: my_helper
INFO - 2024-12-16 12:03:01 --> Database Driver Class Initialized
INFO - 2024-12-16 12:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:03:02 --> Controller Class Initialized
DEBUG - 2024-12-16 12:03:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:03:08 --> Final output sent to browser
DEBUG - 2024-12-16 12:03:08 --> Total execution time: 6.4537
INFO - 2024-12-16 12:07:18 --> Config Class Initialized
INFO - 2024-12-16 12:07:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:18 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:18 --> URI Class Initialized
INFO - 2024-12-16 12:07:18 --> Router Class Initialized
INFO - 2024-12-16 12:07:18 --> Output Class Initialized
INFO - 2024-12-16 12:07:18 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:18 --> Input Class Initialized
INFO - 2024-12-16 12:07:18 --> Language Class Initialized
INFO - 2024-12-16 12:07:18 --> Language Class Initialized
INFO - 2024-12-16 12:07:18 --> Config Class Initialized
INFO - 2024-12-16 12:07:18 --> Loader Class Initialized
INFO - 2024-12-16 12:07:18 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:18 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:18 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:18 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:18 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:18 --> Controller Class Initialized
DEBUG - 2024-12-16 12:07:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 12:07:20 --> Final output sent to browser
DEBUG - 2024-12-16 12:07:20 --> Total execution time: 2.3263
INFO - 2024-12-16 12:07:29 --> Config Class Initialized
INFO - 2024-12-16 12:07:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:29 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:29 --> URI Class Initialized
INFO - 2024-12-16 12:07:29 --> Router Class Initialized
INFO - 2024-12-16 12:07:29 --> Output Class Initialized
INFO - 2024-12-16 12:07:29 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:29 --> Input Class Initialized
INFO - 2024-12-16 12:07:29 --> Language Class Initialized
INFO - 2024-12-16 12:07:30 --> Language Class Initialized
INFO - 2024-12-16 12:07:30 --> Config Class Initialized
INFO - 2024-12-16 12:07:30 --> Loader Class Initialized
INFO - 2024-12-16 12:07:30 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:30 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:30 --> Controller Class Initialized
INFO - 2024-12-16 12:07:30 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:07:30 --> Final output sent to browser
DEBUG - 2024-12-16 12:07:30 --> Total execution time: 0.0514
INFO - 2024-12-16 12:07:30 --> Config Class Initialized
INFO - 2024-12-16 12:07:30 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:30 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:30 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:30 --> URI Class Initialized
INFO - 2024-12-16 12:07:30 --> Router Class Initialized
INFO - 2024-12-16 12:07:30 --> Output Class Initialized
INFO - 2024-12-16 12:07:30 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:30 --> Input Class Initialized
INFO - 2024-12-16 12:07:30 --> Language Class Initialized
INFO - 2024-12-16 12:07:30 --> Language Class Initialized
INFO - 2024-12-16 12:07:30 --> Config Class Initialized
INFO - 2024-12-16 12:07:30 --> Loader Class Initialized
INFO - 2024-12-16 12:07:30 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:30 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:30 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:30 --> Controller Class Initialized
INFO - 2024-12-16 12:07:30 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:07:31 --> Config Class Initialized
INFO - 2024-12-16 12:07:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:31 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:31 --> URI Class Initialized
INFO - 2024-12-16 12:07:31 --> Router Class Initialized
INFO - 2024-12-16 12:07:31 --> Output Class Initialized
INFO - 2024-12-16 12:07:31 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:31 --> Input Class Initialized
INFO - 2024-12-16 12:07:31 --> Language Class Initialized
INFO - 2024-12-16 12:07:31 --> Language Class Initialized
INFO - 2024-12-16 12:07:31 --> Config Class Initialized
INFO - 2024-12-16 12:07:31 --> Loader Class Initialized
INFO - 2024-12-16 12:07:31 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:31 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:31 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:31 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:31 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:31 --> Controller Class Initialized
DEBUG - 2024-12-16 12:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 12:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:07:31 --> Final output sent to browser
DEBUG - 2024-12-16 12:07:31 --> Total execution time: 0.0367
INFO - 2024-12-16 12:07:48 --> Config Class Initialized
INFO - 2024-12-16 12:07:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:48 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:48 --> URI Class Initialized
INFO - 2024-12-16 12:07:48 --> Router Class Initialized
INFO - 2024-12-16 12:07:48 --> Output Class Initialized
INFO - 2024-12-16 12:07:48 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:48 --> Input Class Initialized
INFO - 2024-12-16 12:07:48 --> Language Class Initialized
INFO - 2024-12-16 12:07:48 --> Language Class Initialized
INFO - 2024-12-16 12:07:48 --> Config Class Initialized
INFO - 2024-12-16 12:07:48 --> Loader Class Initialized
INFO - 2024-12-16 12:07:48 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:48 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:48 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:48 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:48 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:48 --> Controller Class Initialized
INFO - 2024-12-16 12:07:48 --> Final output sent to browser
DEBUG - 2024-12-16 12:07:48 --> Total execution time: 0.0283
INFO - 2024-12-16 12:07:53 --> Config Class Initialized
INFO - 2024-12-16 12:07:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:07:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:07:53 --> Utf8 Class Initialized
INFO - 2024-12-16 12:07:53 --> URI Class Initialized
INFO - 2024-12-16 12:07:53 --> Router Class Initialized
INFO - 2024-12-16 12:07:53 --> Output Class Initialized
INFO - 2024-12-16 12:07:53 --> Security Class Initialized
DEBUG - 2024-12-16 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:07:53 --> Input Class Initialized
INFO - 2024-12-16 12:07:53 --> Language Class Initialized
INFO - 2024-12-16 12:07:53 --> Language Class Initialized
INFO - 2024-12-16 12:07:53 --> Config Class Initialized
INFO - 2024-12-16 12:07:53 --> Loader Class Initialized
INFO - 2024-12-16 12:07:53 --> Helper loaded: url_helper
INFO - 2024-12-16 12:07:53 --> Helper loaded: file_helper
INFO - 2024-12-16 12:07:53 --> Helper loaded: form_helper
INFO - 2024-12-16 12:07:53 --> Helper loaded: my_helper
INFO - 2024-12-16 12:07:53 --> Database Driver Class Initialized
INFO - 2024-12-16 12:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:07:53 --> Controller Class Initialized
DEBUG - 2024-12-16 12:07:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:07:56 --> Final output sent to browser
DEBUG - 2024-12-16 12:07:56 --> Total execution time: 3.3274
INFO - 2024-12-16 12:08:15 --> Config Class Initialized
INFO - 2024-12-16 12:08:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:08:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:08:15 --> Utf8 Class Initialized
INFO - 2024-12-16 12:08:15 --> URI Class Initialized
INFO - 2024-12-16 12:08:15 --> Router Class Initialized
INFO - 2024-12-16 12:08:15 --> Output Class Initialized
INFO - 2024-12-16 12:08:15 --> Security Class Initialized
DEBUG - 2024-12-16 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:08:15 --> Input Class Initialized
INFO - 2024-12-16 12:08:15 --> Language Class Initialized
INFO - 2024-12-16 12:08:15 --> Language Class Initialized
INFO - 2024-12-16 12:08:15 --> Config Class Initialized
INFO - 2024-12-16 12:08:15 --> Loader Class Initialized
INFO - 2024-12-16 12:08:15 --> Helper loaded: url_helper
INFO - 2024-12-16 12:08:15 --> Helper loaded: file_helper
INFO - 2024-12-16 12:08:15 --> Helper loaded: form_helper
INFO - 2024-12-16 12:08:15 --> Helper loaded: my_helper
INFO - 2024-12-16 12:08:15 --> Database Driver Class Initialized
INFO - 2024-12-16 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:08:15 --> Controller Class Initialized
DEBUG - 2024-12-16 12:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:08:20 --> Final output sent to browser
DEBUG - 2024-12-16 12:08:20 --> Total execution time: 5.2707
INFO - 2024-12-16 12:09:46 --> Config Class Initialized
INFO - 2024-12-16 12:09:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:09:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:09:46 --> Utf8 Class Initialized
INFO - 2024-12-16 12:09:46 --> URI Class Initialized
INFO - 2024-12-16 12:09:46 --> Router Class Initialized
INFO - 2024-12-16 12:09:46 --> Output Class Initialized
INFO - 2024-12-16 12:09:46 --> Security Class Initialized
DEBUG - 2024-12-16 12:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:09:46 --> Input Class Initialized
INFO - 2024-12-16 12:09:46 --> Language Class Initialized
INFO - 2024-12-16 12:09:46 --> Language Class Initialized
INFO - 2024-12-16 12:09:46 --> Config Class Initialized
INFO - 2024-12-16 12:09:46 --> Loader Class Initialized
INFO - 2024-12-16 12:09:46 --> Helper loaded: url_helper
INFO - 2024-12-16 12:09:46 --> Helper loaded: file_helper
INFO - 2024-12-16 12:09:46 --> Helper loaded: form_helper
INFO - 2024-12-16 12:09:46 --> Helper loaded: my_helper
INFO - 2024-12-16 12:09:46 --> Database Driver Class Initialized
INFO - 2024-12-16 12:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:09:46 --> Controller Class Initialized
DEBUG - 2024-12-16 12:09:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 12:09:50 --> Final output sent to browser
DEBUG - 2024-12-16 12:09:50 --> Total execution time: 4.6278
INFO - 2024-12-16 12:09:56 --> Config Class Initialized
INFO - 2024-12-16 12:09:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:09:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:09:56 --> Utf8 Class Initialized
INFO - 2024-12-16 12:09:56 --> URI Class Initialized
INFO - 2024-12-16 12:09:56 --> Router Class Initialized
INFO - 2024-12-16 12:09:56 --> Output Class Initialized
INFO - 2024-12-16 12:09:56 --> Security Class Initialized
DEBUG - 2024-12-16 12:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:09:56 --> Input Class Initialized
INFO - 2024-12-16 12:09:56 --> Language Class Initialized
INFO - 2024-12-16 12:09:56 --> Language Class Initialized
INFO - 2024-12-16 12:09:56 --> Config Class Initialized
INFO - 2024-12-16 12:09:56 --> Loader Class Initialized
INFO - 2024-12-16 12:09:56 --> Helper loaded: url_helper
INFO - 2024-12-16 12:09:56 --> Helper loaded: file_helper
INFO - 2024-12-16 12:09:56 --> Helper loaded: form_helper
INFO - 2024-12-16 12:09:56 --> Helper loaded: my_helper
INFO - 2024-12-16 12:09:56 --> Database Driver Class Initialized
INFO - 2024-12-16 12:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:09:56 --> Controller Class Initialized
DEBUG - 2024-12-16 12:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:10:01 --> Final output sent to browser
DEBUG - 2024-12-16 12:10:01 --> Total execution time: 5.0558
INFO - 2024-12-16 12:10:05 --> Config Class Initialized
INFO - 2024-12-16 12:10:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:10:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:10:05 --> Utf8 Class Initialized
INFO - 2024-12-16 12:10:05 --> URI Class Initialized
INFO - 2024-12-16 12:10:05 --> Router Class Initialized
INFO - 2024-12-16 12:10:05 --> Output Class Initialized
INFO - 2024-12-16 12:10:05 --> Security Class Initialized
DEBUG - 2024-12-16 12:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:10:05 --> Input Class Initialized
INFO - 2024-12-16 12:10:05 --> Language Class Initialized
INFO - 2024-12-16 12:10:05 --> Language Class Initialized
INFO - 2024-12-16 12:10:05 --> Config Class Initialized
INFO - 2024-12-16 12:10:05 --> Loader Class Initialized
INFO - 2024-12-16 12:10:05 --> Helper loaded: url_helper
INFO - 2024-12-16 12:10:05 --> Helper loaded: file_helper
INFO - 2024-12-16 12:10:05 --> Helper loaded: form_helper
INFO - 2024-12-16 12:10:05 --> Helper loaded: my_helper
INFO - 2024-12-16 12:10:05 --> Database Driver Class Initialized
INFO - 2024-12-16 12:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:10:05 --> Controller Class Initialized
DEBUG - 2024-12-16 12:10:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 12:10:08 --> Final output sent to browser
DEBUG - 2024-12-16 12:10:08 --> Total execution time: 2.2403
INFO - 2024-12-16 12:10:31 --> Config Class Initialized
INFO - 2024-12-16 12:10:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:10:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:10:31 --> Utf8 Class Initialized
INFO - 2024-12-16 12:10:31 --> URI Class Initialized
INFO - 2024-12-16 12:10:31 --> Router Class Initialized
INFO - 2024-12-16 12:10:31 --> Output Class Initialized
INFO - 2024-12-16 12:10:31 --> Security Class Initialized
DEBUG - 2024-12-16 12:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:10:31 --> Input Class Initialized
INFO - 2024-12-16 12:10:31 --> Language Class Initialized
INFO - 2024-12-16 12:10:31 --> Language Class Initialized
INFO - 2024-12-16 12:10:31 --> Config Class Initialized
INFO - 2024-12-16 12:10:31 --> Loader Class Initialized
INFO - 2024-12-16 12:10:31 --> Helper loaded: url_helper
INFO - 2024-12-16 12:10:31 --> Helper loaded: file_helper
INFO - 2024-12-16 12:10:31 --> Helper loaded: form_helper
INFO - 2024-12-16 12:10:31 --> Helper loaded: my_helper
INFO - 2024-12-16 12:10:31 --> Database Driver Class Initialized
INFO - 2024-12-16 12:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:10:31 --> Controller Class Initialized
DEBUG - 2024-12-16 12:10:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:10:36 --> Final output sent to browser
DEBUG - 2024-12-16 12:10:36 --> Total execution time: 5.2829
INFO - 2024-12-16 12:10:49 --> Config Class Initialized
INFO - 2024-12-16 12:10:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:10:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:10:49 --> Utf8 Class Initialized
INFO - 2024-12-16 12:10:49 --> URI Class Initialized
INFO - 2024-12-16 12:10:49 --> Router Class Initialized
INFO - 2024-12-16 12:10:49 --> Output Class Initialized
INFO - 2024-12-16 12:10:49 --> Security Class Initialized
DEBUG - 2024-12-16 12:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:10:49 --> Input Class Initialized
INFO - 2024-12-16 12:10:49 --> Language Class Initialized
INFO - 2024-12-16 12:10:49 --> Language Class Initialized
INFO - 2024-12-16 12:10:49 --> Config Class Initialized
INFO - 2024-12-16 12:10:49 --> Loader Class Initialized
INFO - 2024-12-16 12:10:49 --> Helper loaded: url_helper
INFO - 2024-12-16 12:10:49 --> Helper loaded: file_helper
INFO - 2024-12-16 12:10:49 --> Helper loaded: form_helper
INFO - 2024-12-16 12:10:49 --> Helper loaded: my_helper
INFO - 2024-12-16 12:10:49 --> Database Driver Class Initialized
INFO - 2024-12-16 12:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:10:49 --> Controller Class Initialized
INFO - 2024-12-16 12:10:49 --> Final output sent to browser
DEBUG - 2024-12-16 12:10:49 --> Total execution time: 0.5390
INFO - 2024-12-16 12:11:01 --> Config Class Initialized
INFO - 2024-12-16 12:11:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:11:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:11:01 --> Utf8 Class Initialized
INFO - 2024-12-16 12:11:01 --> URI Class Initialized
INFO - 2024-12-16 12:11:01 --> Router Class Initialized
INFO - 2024-12-16 12:11:01 --> Output Class Initialized
INFO - 2024-12-16 12:11:01 --> Security Class Initialized
DEBUG - 2024-12-16 12:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:11:01 --> Input Class Initialized
INFO - 2024-12-16 12:11:01 --> Language Class Initialized
INFO - 2024-12-16 12:11:02 --> Language Class Initialized
INFO - 2024-12-16 12:11:02 --> Config Class Initialized
INFO - 2024-12-16 12:11:02 --> Loader Class Initialized
INFO - 2024-12-16 12:11:02 --> Helper loaded: url_helper
INFO - 2024-12-16 12:11:02 --> Helper loaded: file_helper
INFO - 2024-12-16 12:11:02 --> Helper loaded: form_helper
INFO - 2024-12-16 12:11:02 --> Helper loaded: my_helper
INFO - 2024-12-16 12:11:02 --> Database Driver Class Initialized
INFO - 2024-12-16 12:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:11:02 --> Controller Class Initialized
DEBUG - 2024-12-16 12:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:11:27 --> Final output sent to browser
DEBUG - 2024-12-16 12:11:27 --> Total execution time: 25.9171
INFO - 2024-12-16 12:12:53 --> Config Class Initialized
INFO - 2024-12-16 12:12:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:12:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:12:53 --> Utf8 Class Initialized
INFO - 2024-12-16 12:12:53 --> URI Class Initialized
INFO - 2024-12-16 12:12:53 --> Router Class Initialized
INFO - 2024-12-16 12:12:53 --> Output Class Initialized
INFO - 2024-12-16 12:12:53 --> Security Class Initialized
DEBUG - 2024-12-16 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:12:53 --> Input Class Initialized
INFO - 2024-12-16 12:12:53 --> Language Class Initialized
INFO - 2024-12-16 12:12:53 --> Language Class Initialized
INFO - 2024-12-16 12:12:53 --> Config Class Initialized
INFO - 2024-12-16 12:12:53 --> Loader Class Initialized
INFO - 2024-12-16 12:12:53 --> Helper loaded: url_helper
INFO - 2024-12-16 12:12:53 --> Helper loaded: file_helper
INFO - 2024-12-16 12:12:53 --> Helper loaded: form_helper
INFO - 2024-12-16 12:12:53 --> Helper loaded: my_helper
INFO - 2024-12-16 12:12:53 --> Database Driver Class Initialized
INFO - 2024-12-16 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:12:53 --> Controller Class Initialized
DEBUG - 2024-12-16 12:12:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:12:56 --> Final output sent to browser
DEBUG - 2024-12-16 12:12:56 --> Total execution time: 3.2968
INFO - 2024-12-16 12:13:13 --> Config Class Initialized
INFO - 2024-12-16 12:13:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:13:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:13:13 --> Utf8 Class Initialized
INFO - 2024-12-16 12:13:13 --> URI Class Initialized
INFO - 2024-12-16 12:13:13 --> Router Class Initialized
INFO - 2024-12-16 12:13:13 --> Output Class Initialized
INFO - 2024-12-16 12:13:13 --> Security Class Initialized
DEBUG - 2024-12-16 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:13:13 --> Input Class Initialized
INFO - 2024-12-16 12:13:13 --> Language Class Initialized
INFO - 2024-12-16 12:13:13 --> Language Class Initialized
INFO - 2024-12-16 12:13:13 --> Config Class Initialized
INFO - 2024-12-16 12:13:13 --> Loader Class Initialized
INFO - 2024-12-16 12:13:13 --> Helper loaded: url_helper
INFO - 2024-12-16 12:13:13 --> Helper loaded: file_helper
INFO - 2024-12-16 12:13:13 --> Helper loaded: form_helper
INFO - 2024-12-16 12:13:13 --> Helper loaded: my_helper
INFO - 2024-12-16 12:13:13 --> Database Driver Class Initialized
INFO - 2024-12-16 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:13:13 --> Controller Class Initialized
DEBUG - 2024-12-16 12:13:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 12:13:15 --> Final output sent to browser
DEBUG - 2024-12-16 12:13:15 --> Total execution time: 2.1862
INFO - 2024-12-16 12:14:01 --> Config Class Initialized
INFO - 2024-12-16 12:14:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:14:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:14:01 --> Utf8 Class Initialized
INFO - 2024-12-16 12:14:01 --> URI Class Initialized
INFO - 2024-12-16 12:14:01 --> Router Class Initialized
INFO - 2024-12-16 12:14:01 --> Output Class Initialized
INFO - 2024-12-16 12:14:01 --> Security Class Initialized
DEBUG - 2024-12-16 12:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:14:01 --> Input Class Initialized
INFO - 2024-12-16 12:14:01 --> Language Class Initialized
INFO - 2024-12-16 12:14:01 --> Language Class Initialized
INFO - 2024-12-16 12:14:01 --> Config Class Initialized
INFO - 2024-12-16 12:14:01 --> Loader Class Initialized
INFO - 2024-12-16 12:14:01 --> Helper loaded: url_helper
INFO - 2024-12-16 12:14:01 --> Helper loaded: file_helper
INFO - 2024-12-16 12:14:01 --> Helper loaded: form_helper
INFO - 2024-12-16 12:14:01 --> Helper loaded: my_helper
INFO - 2024-12-16 12:14:01 --> Database Driver Class Initialized
INFO - 2024-12-16 12:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:14:01 --> Controller Class Initialized
DEBUG - 2024-12-16 12:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:14:09 --> Final output sent to browser
DEBUG - 2024-12-16 12:14:09 --> Total execution time: 7.9137
INFO - 2024-12-16 12:16:18 --> Config Class Initialized
INFO - 2024-12-16 12:16:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:16:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:16:18 --> Utf8 Class Initialized
INFO - 2024-12-16 12:16:19 --> URI Class Initialized
INFO - 2024-12-16 12:16:19 --> Router Class Initialized
INFO - 2024-12-16 12:16:19 --> Output Class Initialized
INFO - 2024-12-16 12:16:19 --> Security Class Initialized
DEBUG - 2024-12-16 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:16:19 --> Input Class Initialized
INFO - 2024-12-16 12:16:19 --> Language Class Initialized
INFO - 2024-12-16 12:16:20 --> Language Class Initialized
INFO - 2024-12-16 12:16:20 --> Config Class Initialized
INFO - 2024-12-16 12:16:20 --> Loader Class Initialized
INFO - 2024-12-16 12:16:20 --> Helper loaded: url_helper
INFO - 2024-12-16 12:16:20 --> Helper loaded: file_helper
INFO - 2024-12-16 12:16:20 --> Helper loaded: form_helper
INFO - 2024-12-16 12:16:20 --> Helper loaded: my_helper
INFO - 2024-12-16 12:16:20 --> Database Driver Class Initialized
INFO - 2024-12-16 12:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:16:21 --> Controller Class Initialized
DEBUG - 2024-12-16 12:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:16:23 --> Config Class Initialized
INFO - 2024-12-16 12:16:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:16:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:16:23 --> Utf8 Class Initialized
INFO - 2024-12-16 12:16:23 --> URI Class Initialized
INFO - 2024-12-16 12:16:24 --> Router Class Initialized
INFO - 2024-12-16 12:16:24 --> Output Class Initialized
INFO - 2024-12-16 12:16:24 --> Security Class Initialized
DEBUG - 2024-12-16 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:16:24 --> Input Class Initialized
INFO - 2024-12-16 12:16:24 --> Language Class Initialized
INFO - 2024-12-16 12:16:24 --> Language Class Initialized
INFO - 2024-12-16 12:16:24 --> Config Class Initialized
INFO - 2024-12-16 12:16:24 --> Loader Class Initialized
INFO - 2024-12-16 12:16:24 --> Helper loaded: url_helper
INFO - 2024-12-16 12:16:24 --> Helper loaded: file_helper
INFO - 2024-12-16 12:16:24 --> Helper loaded: form_helper
INFO - 2024-12-16 12:16:24 --> Helper loaded: my_helper
INFO - 2024-12-16 12:16:24 --> Database Driver Class Initialized
INFO - 2024-12-16 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:16:24 --> Controller Class Initialized
INFO - 2024-12-16 12:16:24 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:16:24 --> Final output sent to browser
DEBUG - 2024-12-16 12:16:24 --> Total execution time: 0.4622
INFO - 2024-12-16 12:16:25 --> Config Class Initialized
INFO - 2024-12-16 12:16:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:16:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:16:25 --> Utf8 Class Initialized
INFO - 2024-12-16 12:16:25 --> URI Class Initialized
INFO - 2024-12-16 12:16:25 --> Router Class Initialized
INFO - 2024-12-16 12:16:25 --> Output Class Initialized
INFO - 2024-12-16 12:16:25 --> Security Class Initialized
DEBUG - 2024-12-16 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:16:25 --> Input Class Initialized
INFO - 2024-12-16 12:16:25 --> Language Class Initialized
INFO - 2024-12-16 12:16:25 --> Language Class Initialized
INFO - 2024-12-16 12:16:25 --> Config Class Initialized
INFO - 2024-12-16 12:16:25 --> Loader Class Initialized
INFO - 2024-12-16 12:16:25 --> Helper loaded: url_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: file_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: form_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: my_helper
INFO - 2024-12-16 12:16:25 --> Database Driver Class Initialized
INFO - 2024-12-16 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:16:25 --> Controller Class Initialized
INFO - 2024-12-16 12:16:25 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:16:25 --> Config Class Initialized
INFO - 2024-12-16 12:16:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:16:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:16:25 --> Utf8 Class Initialized
INFO - 2024-12-16 12:16:25 --> URI Class Initialized
INFO - 2024-12-16 12:16:25 --> Router Class Initialized
INFO - 2024-12-16 12:16:25 --> Output Class Initialized
INFO - 2024-12-16 12:16:25 --> Security Class Initialized
DEBUG - 2024-12-16 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:16:25 --> Input Class Initialized
INFO - 2024-12-16 12:16:25 --> Language Class Initialized
INFO - 2024-12-16 12:16:25 --> Language Class Initialized
INFO - 2024-12-16 12:16:25 --> Config Class Initialized
INFO - 2024-12-16 12:16:25 --> Loader Class Initialized
INFO - 2024-12-16 12:16:25 --> Helper loaded: url_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: file_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: form_helper
INFO - 2024-12-16 12:16:25 --> Helper loaded: my_helper
INFO - 2024-12-16 12:16:26 --> Database Driver Class Initialized
INFO - 2024-12-16 12:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:16:26 --> Controller Class Initialized
DEBUG - 2024-12-16 12:16:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 12:16:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:16:26 --> Final output sent to browser
DEBUG - 2024-12-16 12:16:26 --> Total execution time: 0.2383
INFO - 2024-12-16 12:16:28 --> Final output sent to browser
DEBUG - 2024-12-16 12:16:28 --> Total execution time: 9.9322
INFO - 2024-12-16 12:17:17 --> Config Class Initialized
INFO - 2024-12-16 12:17:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:17:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:17:17 --> Utf8 Class Initialized
INFO - 2024-12-16 12:17:17 --> URI Class Initialized
INFO - 2024-12-16 12:17:17 --> Router Class Initialized
INFO - 2024-12-16 12:17:17 --> Output Class Initialized
INFO - 2024-12-16 12:17:17 --> Security Class Initialized
DEBUG - 2024-12-16 12:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:17:17 --> Input Class Initialized
INFO - 2024-12-16 12:17:17 --> Language Class Initialized
INFO - 2024-12-16 12:17:17 --> Language Class Initialized
INFO - 2024-12-16 12:17:17 --> Config Class Initialized
INFO - 2024-12-16 12:17:17 --> Loader Class Initialized
INFO - 2024-12-16 12:17:17 --> Helper loaded: url_helper
INFO - 2024-12-16 12:17:17 --> Helper loaded: file_helper
INFO - 2024-12-16 12:17:17 --> Helper loaded: form_helper
INFO - 2024-12-16 12:17:17 --> Helper loaded: my_helper
INFO - 2024-12-16 12:17:17 --> Database Driver Class Initialized
INFO - 2024-12-16 12:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:17:17 --> Controller Class Initialized
DEBUG - 2024-12-16 12:17:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 12:17:21 --> Final output sent to browser
DEBUG - 2024-12-16 12:17:21 --> Total execution time: 4.2181
INFO - 2024-12-16 12:20:41 --> Config Class Initialized
INFO - 2024-12-16 12:20:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:20:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:20:41 --> Utf8 Class Initialized
INFO - 2024-12-16 12:20:41 --> URI Class Initialized
INFO - 2024-12-16 12:20:41 --> Router Class Initialized
INFO - 2024-12-16 12:20:41 --> Output Class Initialized
INFO - 2024-12-16 12:20:41 --> Security Class Initialized
DEBUG - 2024-12-16 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:20:41 --> Input Class Initialized
INFO - 2024-12-16 12:20:41 --> Language Class Initialized
INFO - 2024-12-16 12:20:41 --> Language Class Initialized
INFO - 2024-12-16 12:20:41 --> Config Class Initialized
INFO - 2024-12-16 12:20:41 --> Loader Class Initialized
INFO - 2024-12-16 12:20:41 --> Helper loaded: url_helper
INFO - 2024-12-16 12:20:41 --> Helper loaded: file_helper
INFO - 2024-12-16 12:20:41 --> Helper loaded: form_helper
INFO - 2024-12-16 12:20:41 --> Helper loaded: my_helper
INFO - 2024-12-16 12:20:41 --> Database Driver Class Initialized
INFO - 2024-12-16 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:20:41 --> Controller Class Initialized
DEBUG - 2024-12-16 12:20:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 12:20:43 --> Final output sent to browser
DEBUG - 2024-12-16 12:20:43 --> Total execution time: 2.4757
INFO - 2024-12-16 12:21:07 --> Config Class Initialized
INFO - 2024-12-16 12:21:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:21:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:21:07 --> Utf8 Class Initialized
INFO - 2024-12-16 12:21:07 --> URI Class Initialized
INFO - 2024-12-16 12:21:07 --> Router Class Initialized
INFO - 2024-12-16 12:21:07 --> Output Class Initialized
INFO - 2024-12-16 12:21:07 --> Security Class Initialized
DEBUG - 2024-12-16 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:21:07 --> Input Class Initialized
INFO - 2024-12-16 12:21:07 --> Language Class Initialized
INFO - 2024-12-16 12:21:07 --> Language Class Initialized
INFO - 2024-12-16 12:21:07 --> Config Class Initialized
INFO - 2024-12-16 12:21:07 --> Loader Class Initialized
INFO - 2024-12-16 12:21:07 --> Helper loaded: url_helper
INFO - 2024-12-16 12:21:07 --> Helper loaded: file_helper
INFO - 2024-12-16 12:21:07 --> Helper loaded: form_helper
INFO - 2024-12-16 12:21:07 --> Helper loaded: my_helper
INFO - 2024-12-16 12:21:07 --> Database Driver Class Initialized
INFO - 2024-12-16 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:21:07 --> Controller Class Initialized
INFO - 2024-12-16 12:21:07 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:21:07 --> Final output sent to browser
DEBUG - 2024-12-16 12:21:07 --> Total execution time: 0.1005
INFO - 2024-12-16 12:21:08 --> Config Class Initialized
INFO - 2024-12-16 12:21:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:21:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:21:08 --> Utf8 Class Initialized
INFO - 2024-12-16 12:21:08 --> URI Class Initialized
INFO - 2024-12-16 12:21:08 --> Router Class Initialized
INFO - 2024-12-16 12:21:08 --> Output Class Initialized
INFO - 2024-12-16 12:21:08 --> Security Class Initialized
DEBUG - 2024-12-16 12:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:21:08 --> Input Class Initialized
INFO - 2024-12-16 12:21:08 --> Language Class Initialized
INFO - 2024-12-16 12:21:08 --> Language Class Initialized
INFO - 2024-12-16 12:21:08 --> Config Class Initialized
INFO - 2024-12-16 12:21:08 --> Loader Class Initialized
INFO - 2024-12-16 12:21:08 --> Helper loaded: url_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: file_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: form_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: my_helper
INFO - 2024-12-16 12:21:08 --> Database Driver Class Initialized
INFO - 2024-12-16 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:21:08 --> Controller Class Initialized
INFO - 2024-12-16 12:21:08 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:21:08 --> Config Class Initialized
INFO - 2024-12-16 12:21:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:21:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:21:08 --> Utf8 Class Initialized
INFO - 2024-12-16 12:21:08 --> URI Class Initialized
INFO - 2024-12-16 12:21:08 --> Router Class Initialized
INFO - 2024-12-16 12:21:08 --> Output Class Initialized
INFO - 2024-12-16 12:21:08 --> Security Class Initialized
DEBUG - 2024-12-16 12:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:21:08 --> Input Class Initialized
INFO - 2024-12-16 12:21:08 --> Language Class Initialized
INFO - 2024-12-16 12:21:08 --> Language Class Initialized
INFO - 2024-12-16 12:21:08 --> Config Class Initialized
INFO - 2024-12-16 12:21:08 --> Loader Class Initialized
INFO - 2024-12-16 12:21:08 --> Helper loaded: url_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: file_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: form_helper
INFO - 2024-12-16 12:21:08 --> Helper loaded: my_helper
INFO - 2024-12-16 12:21:08 --> Database Driver Class Initialized
INFO - 2024-12-16 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:21:08 --> Controller Class Initialized
DEBUG - 2024-12-16 12:21:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 12:21:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:21:08 --> Final output sent to browser
DEBUG - 2024-12-16 12:21:08 --> Total execution time: 0.0405
INFO - 2024-12-16 12:24:11 --> Config Class Initialized
INFO - 2024-12-16 12:24:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:24:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:24:11 --> Utf8 Class Initialized
INFO - 2024-12-16 12:24:11 --> URI Class Initialized
INFO - 2024-12-16 12:24:11 --> Router Class Initialized
INFO - 2024-12-16 12:24:11 --> Output Class Initialized
INFO - 2024-12-16 12:24:11 --> Security Class Initialized
DEBUG - 2024-12-16 12:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:24:11 --> Input Class Initialized
INFO - 2024-12-16 12:24:11 --> Language Class Initialized
INFO - 2024-12-16 12:24:11 --> Language Class Initialized
INFO - 2024-12-16 12:24:11 --> Config Class Initialized
INFO - 2024-12-16 12:24:11 --> Loader Class Initialized
INFO - 2024-12-16 12:24:11 --> Helper loaded: url_helper
INFO - 2024-12-16 12:24:11 --> Helper loaded: file_helper
INFO - 2024-12-16 12:24:11 --> Helper loaded: form_helper
INFO - 2024-12-16 12:24:11 --> Helper loaded: my_helper
INFO - 2024-12-16 12:24:11 --> Database Driver Class Initialized
INFO - 2024-12-16 12:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:24:11 --> Controller Class Initialized
DEBUG - 2024-12-16 12:24:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:24:16 --> Final output sent to browser
DEBUG - 2024-12-16 12:24:16 --> Total execution time: 5.2205
INFO - 2024-12-16 12:24:58 --> Config Class Initialized
INFO - 2024-12-16 12:24:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:24:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:24:58 --> Utf8 Class Initialized
INFO - 2024-12-16 12:24:59 --> URI Class Initialized
INFO - 2024-12-16 12:24:59 --> Router Class Initialized
INFO - 2024-12-16 12:24:59 --> Output Class Initialized
INFO - 2024-12-16 12:24:59 --> Security Class Initialized
DEBUG - 2024-12-16 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:24:59 --> Input Class Initialized
INFO - 2024-12-16 12:24:59 --> Language Class Initialized
INFO - 2024-12-16 12:24:59 --> Language Class Initialized
INFO - 2024-12-16 12:24:59 --> Config Class Initialized
INFO - 2024-12-16 12:24:59 --> Loader Class Initialized
INFO - 2024-12-16 12:24:59 --> Helper loaded: url_helper
INFO - 2024-12-16 12:24:59 --> Helper loaded: file_helper
INFO - 2024-12-16 12:24:59 --> Helper loaded: form_helper
INFO - 2024-12-16 12:24:59 --> Helper loaded: my_helper
INFO - 2024-12-16 12:24:59 --> Database Driver Class Initialized
INFO - 2024-12-16 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:24:59 --> Controller Class Initialized
DEBUG - 2024-12-16 12:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 12:25:11 --> Final output sent to browser
DEBUG - 2024-12-16 12:25:11 --> Total execution time: 12.8768
INFO - 2024-12-16 12:27:54 --> Config Class Initialized
INFO - 2024-12-16 12:27:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:27:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:27:54 --> Utf8 Class Initialized
INFO - 2024-12-16 12:27:54 --> URI Class Initialized
INFO - 2024-12-16 12:27:54 --> Router Class Initialized
INFO - 2024-12-16 12:27:54 --> Output Class Initialized
INFO - 2024-12-16 12:27:54 --> Security Class Initialized
DEBUG - 2024-12-16 12:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:27:54 --> Input Class Initialized
INFO - 2024-12-16 12:27:54 --> Language Class Initialized
INFO - 2024-12-16 12:27:54 --> Language Class Initialized
INFO - 2024-12-16 12:27:54 --> Config Class Initialized
INFO - 2024-12-16 12:27:54 --> Loader Class Initialized
INFO - 2024-12-16 12:27:54 --> Helper loaded: url_helper
INFO - 2024-12-16 12:27:54 --> Helper loaded: file_helper
INFO - 2024-12-16 12:27:54 --> Helper loaded: form_helper
INFO - 2024-12-16 12:27:54 --> Helper loaded: my_helper
INFO - 2024-12-16 12:27:54 --> Database Driver Class Initialized
INFO - 2024-12-16 12:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:27:54 --> Controller Class Initialized
DEBUG - 2024-12-16 12:27:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:28:00 --> Final output sent to browser
DEBUG - 2024-12-16 12:28:00 --> Total execution time: 5.7131
INFO - 2024-12-16 12:29:58 --> Config Class Initialized
INFO - 2024-12-16 12:29:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:29:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:29:58 --> Utf8 Class Initialized
INFO - 2024-12-16 12:29:58 --> URI Class Initialized
INFO - 2024-12-16 12:29:58 --> Router Class Initialized
INFO - 2024-12-16 12:29:58 --> Output Class Initialized
INFO - 2024-12-16 12:29:58 --> Security Class Initialized
DEBUG - 2024-12-16 12:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:29:58 --> Input Class Initialized
INFO - 2024-12-16 12:29:58 --> Language Class Initialized
INFO - 2024-12-16 12:29:58 --> Language Class Initialized
INFO - 2024-12-16 12:29:58 --> Config Class Initialized
INFO - 2024-12-16 12:29:58 --> Loader Class Initialized
INFO - 2024-12-16 12:29:58 --> Helper loaded: url_helper
INFO - 2024-12-16 12:29:58 --> Helper loaded: file_helper
INFO - 2024-12-16 12:29:58 --> Helper loaded: form_helper
INFO - 2024-12-16 12:29:58 --> Helper loaded: my_helper
INFO - 2024-12-16 12:29:58 --> Database Driver Class Initialized
INFO - 2024-12-16 12:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:29:58 --> Controller Class Initialized
DEBUG - 2024-12-16 12:29:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:30:07 --> Final output sent to browser
DEBUG - 2024-12-16 12:30:07 --> Total execution time: 8.6734
INFO - 2024-12-16 12:30:24 --> Config Class Initialized
INFO - 2024-12-16 12:30:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:30:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:30:24 --> Utf8 Class Initialized
INFO - 2024-12-16 12:30:24 --> URI Class Initialized
INFO - 2024-12-16 12:30:24 --> Router Class Initialized
INFO - 2024-12-16 12:30:24 --> Output Class Initialized
INFO - 2024-12-16 12:30:24 --> Security Class Initialized
DEBUG - 2024-12-16 12:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:30:24 --> Input Class Initialized
INFO - 2024-12-16 12:30:24 --> Language Class Initialized
INFO - 2024-12-16 12:30:24 --> Language Class Initialized
INFO - 2024-12-16 12:30:24 --> Config Class Initialized
INFO - 2024-12-16 12:30:24 --> Loader Class Initialized
INFO - 2024-12-16 12:30:24 --> Helper loaded: url_helper
INFO - 2024-12-16 12:30:24 --> Helper loaded: file_helper
INFO - 2024-12-16 12:30:24 --> Helper loaded: form_helper
INFO - 2024-12-16 12:30:24 --> Helper loaded: my_helper
INFO - 2024-12-16 12:30:24 --> Database Driver Class Initialized
INFO - 2024-12-16 12:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:30:24 --> Controller Class Initialized
DEBUG - 2024-12-16 12:30:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 12:30:30 --> Final output sent to browser
DEBUG - 2024-12-16 12:30:30 --> Total execution time: 5.9625
INFO - 2024-12-16 12:33:33 --> Config Class Initialized
INFO - 2024-12-16 12:33:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:33:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:33:33 --> Utf8 Class Initialized
INFO - 2024-12-16 12:33:33 --> URI Class Initialized
INFO - 2024-12-16 12:33:33 --> Router Class Initialized
INFO - 2024-12-16 12:33:33 --> Output Class Initialized
INFO - 2024-12-16 12:33:33 --> Security Class Initialized
DEBUG - 2024-12-16 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:33:33 --> Input Class Initialized
INFO - 2024-12-16 12:33:33 --> Language Class Initialized
INFO - 2024-12-16 12:33:33 --> Language Class Initialized
INFO - 2024-12-16 12:33:33 --> Config Class Initialized
INFO - 2024-12-16 12:33:33 --> Loader Class Initialized
INFO - 2024-12-16 12:33:33 --> Helper loaded: url_helper
INFO - 2024-12-16 12:33:33 --> Helper loaded: file_helper
INFO - 2024-12-16 12:33:33 --> Helper loaded: form_helper
INFO - 2024-12-16 12:33:33 --> Helper loaded: my_helper
INFO - 2024-12-16 12:33:33 --> Database Driver Class Initialized
INFO - 2024-12-16 12:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:33:33 --> Controller Class Initialized
DEBUG - 2024-12-16 12:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 12:33:36 --> Final output sent to browser
DEBUG - 2024-12-16 12:33:36 --> Total execution time: 2.2168
INFO - 2024-12-16 12:36:19 --> Config Class Initialized
INFO - 2024-12-16 12:36:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:36:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:36:19 --> Utf8 Class Initialized
INFO - 2024-12-16 12:36:19 --> URI Class Initialized
INFO - 2024-12-16 12:36:19 --> Router Class Initialized
INFO - 2024-12-16 12:36:19 --> Output Class Initialized
INFO - 2024-12-16 12:36:19 --> Security Class Initialized
DEBUG - 2024-12-16 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:36:19 --> Input Class Initialized
INFO - 2024-12-16 12:36:19 --> Language Class Initialized
INFO - 2024-12-16 12:36:20 --> Language Class Initialized
INFO - 2024-12-16 12:36:20 --> Config Class Initialized
INFO - 2024-12-16 12:36:20 --> Loader Class Initialized
INFO - 2024-12-16 12:36:20 --> Helper loaded: url_helper
INFO - 2024-12-16 12:36:20 --> Helper loaded: file_helper
INFO - 2024-12-16 12:36:20 --> Helper loaded: form_helper
INFO - 2024-12-16 12:36:20 --> Helper loaded: my_helper
INFO - 2024-12-16 12:36:20 --> Database Driver Class Initialized
INFO - 2024-12-16 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:36:20 --> Controller Class Initialized
DEBUG - 2024-12-16 12:36:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:36:46 --> Final output sent to browser
DEBUG - 2024-12-16 12:36:46 --> Total execution time: 27.5087
INFO - 2024-12-16 12:38:25 --> Config Class Initialized
INFO - 2024-12-16 12:38:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:38:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:38:25 --> Utf8 Class Initialized
INFO - 2024-12-16 12:38:25 --> URI Class Initialized
INFO - 2024-12-16 12:38:25 --> Router Class Initialized
INFO - 2024-12-16 12:38:25 --> Output Class Initialized
INFO - 2024-12-16 12:38:25 --> Security Class Initialized
DEBUG - 2024-12-16 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:38:25 --> Input Class Initialized
INFO - 2024-12-16 12:38:25 --> Language Class Initialized
INFO - 2024-12-16 12:38:25 --> Language Class Initialized
INFO - 2024-12-16 12:38:25 --> Config Class Initialized
INFO - 2024-12-16 12:38:25 --> Loader Class Initialized
INFO - 2024-12-16 12:38:25 --> Helper loaded: url_helper
INFO - 2024-12-16 12:38:25 --> Helper loaded: file_helper
INFO - 2024-12-16 12:38:25 --> Helper loaded: form_helper
INFO - 2024-12-16 12:38:25 --> Helper loaded: my_helper
INFO - 2024-12-16 12:38:25 --> Database Driver Class Initialized
INFO - 2024-12-16 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:38:25 --> Controller Class Initialized
INFO - 2024-12-16 12:38:25 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:38:25 --> Final output sent to browser
DEBUG - 2024-12-16 12:38:25 --> Total execution time: 0.0960
INFO - 2024-12-16 12:38:26 --> Config Class Initialized
INFO - 2024-12-16 12:38:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:38:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:38:26 --> Utf8 Class Initialized
INFO - 2024-12-16 12:38:26 --> URI Class Initialized
INFO - 2024-12-16 12:38:26 --> Router Class Initialized
INFO - 2024-12-16 12:38:26 --> Output Class Initialized
INFO - 2024-12-16 12:38:26 --> Security Class Initialized
DEBUG - 2024-12-16 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:38:26 --> Input Class Initialized
INFO - 2024-12-16 12:38:26 --> Language Class Initialized
INFO - 2024-12-16 12:38:26 --> Language Class Initialized
INFO - 2024-12-16 12:38:26 --> Config Class Initialized
INFO - 2024-12-16 12:38:26 --> Loader Class Initialized
INFO - 2024-12-16 12:38:26 --> Helper loaded: url_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: file_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: form_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: my_helper
INFO - 2024-12-16 12:38:26 --> Database Driver Class Initialized
INFO - 2024-12-16 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:38:26 --> Controller Class Initialized
INFO - 2024-12-16 12:38:26 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:38:26 --> Config Class Initialized
INFO - 2024-12-16 12:38:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:38:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:38:26 --> Utf8 Class Initialized
INFO - 2024-12-16 12:38:26 --> URI Class Initialized
INFO - 2024-12-16 12:38:26 --> Router Class Initialized
INFO - 2024-12-16 12:38:26 --> Output Class Initialized
INFO - 2024-12-16 12:38:26 --> Security Class Initialized
DEBUG - 2024-12-16 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:38:26 --> Input Class Initialized
INFO - 2024-12-16 12:38:26 --> Language Class Initialized
INFO - 2024-12-16 12:38:26 --> Language Class Initialized
INFO - 2024-12-16 12:38:26 --> Config Class Initialized
INFO - 2024-12-16 12:38:26 --> Loader Class Initialized
INFO - 2024-12-16 12:38:26 --> Helper loaded: url_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: file_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: form_helper
INFO - 2024-12-16 12:38:26 --> Helper loaded: my_helper
INFO - 2024-12-16 12:38:26 --> Database Driver Class Initialized
INFO - 2024-12-16 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:38:26 --> Controller Class Initialized
DEBUG - 2024-12-16 12:38:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 12:38:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:38:26 --> Final output sent to browser
DEBUG - 2024-12-16 12:38:26 --> Total execution time: 0.0489
INFO - 2024-12-16 12:38:30 --> Config Class Initialized
INFO - 2024-12-16 12:38:30 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:38:30 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:38:30 --> Utf8 Class Initialized
INFO - 2024-12-16 12:38:30 --> URI Class Initialized
INFO - 2024-12-16 12:38:30 --> Router Class Initialized
INFO - 2024-12-16 12:38:30 --> Output Class Initialized
INFO - 2024-12-16 12:38:30 --> Security Class Initialized
DEBUG - 2024-12-16 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:38:30 --> Input Class Initialized
INFO - 2024-12-16 12:38:30 --> Language Class Initialized
INFO - 2024-12-16 12:38:30 --> Language Class Initialized
INFO - 2024-12-16 12:38:30 --> Config Class Initialized
INFO - 2024-12-16 12:38:30 --> Loader Class Initialized
INFO - 2024-12-16 12:38:30 --> Helper loaded: url_helper
INFO - 2024-12-16 12:38:30 --> Helper loaded: file_helper
INFO - 2024-12-16 12:38:30 --> Helper loaded: form_helper
INFO - 2024-12-16 12:38:30 --> Helper loaded: my_helper
INFO - 2024-12-16 12:38:30 --> Database Driver Class Initialized
INFO - 2024-12-16 12:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:38:30 --> Controller Class Initialized
DEBUG - 2024-12-16 12:38:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:38:37 --> Final output sent to browser
DEBUG - 2024-12-16 12:38:37 --> Total execution time: 6.5450
INFO - 2024-12-16 12:38:47 --> Config Class Initialized
INFO - 2024-12-16 12:38:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:38:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:38:47 --> Utf8 Class Initialized
INFO - 2024-12-16 12:38:47 --> URI Class Initialized
INFO - 2024-12-16 12:38:47 --> Router Class Initialized
INFO - 2024-12-16 12:38:47 --> Output Class Initialized
INFO - 2024-12-16 12:38:47 --> Security Class Initialized
DEBUG - 2024-12-16 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:38:47 --> Input Class Initialized
INFO - 2024-12-16 12:38:47 --> Language Class Initialized
INFO - 2024-12-16 12:38:47 --> Language Class Initialized
INFO - 2024-12-16 12:38:47 --> Config Class Initialized
INFO - 2024-12-16 12:38:47 --> Loader Class Initialized
INFO - 2024-12-16 12:38:47 --> Helper loaded: url_helper
INFO - 2024-12-16 12:38:47 --> Helper loaded: file_helper
INFO - 2024-12-16 12:38:47 --> Helper loaded: form_helper
INFO - 2024-12-16 12:38:47 --> Helper loaded: my_helper
INFO - 2024-12-16 12:38:47 --> Database Driver Class Initialized
INFO - 2024-12-16 12:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:38:47 --> Controller Class Initialized
DEBUG - 2024-12-16 12:38:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 12:38:52 --> Final output sent to browser
DEBUG - 2024-12-16 12:38:52 --> Total execution time: 4.9309
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:27 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:27 --> URI Class Initialized
INFO - 2024-12-16 12:43:27 --> Router Class Initialized
INFO - 2024-12-16 12:43:27 --> Output Class Initialized
INFO - 2024-12-16 12:43:27 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:27 --> Input Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Loader Class Initialized
INFO - 2024-12-16 12:43:27 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:27 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:27 --> Controller Class Initialized
INFO - 2024-12-16 12:43:27 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:27 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:27 --> URI Class Initialized
INFO - 2024-12-16 12:43:27 --> Router Class Initialized
INFO - 2024-12-16 12:43:27 --> Output Class Initialized
INFO - 2024-12-16 12:43:27 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:27 --> Input Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Loader Class Initialized
INFO - 2024-12-16 12:43:27 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:27 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:27 --> Controller Class Initialized
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:27 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:27 --> URI Class Initialized
INFO - 2024-12-16 12:43:27 --> Router Class Initialized
INFO - 2024-12-16 12:43:27 --> Output Class Initialized
INFO - 2024-12-16 12:43:27 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:27 --> Input Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Language Class Initialized
INFO - 2024-12-16 12:43:27 --> Config Class Initialized
INFO - 2024-12-16 12:43:27 --> Loader Class Initialized
INFO - 2024-12-16 12:43:27 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:27 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:27 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:27 --> Controller Class Initialized
DEBUG - 2024-12-16 12:43:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 12:43:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:43:27 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:27 --> Total execution time: 0.0368
INFO - 2024-12-16 12:43:33 --> Config Class Initialized
INFO - 2024-12-16 12:43:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:33 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:33 --> URI Class Initialized
INFO - 2024-12-16 12:43:33 --> Router Class Initialized
INFO - 2024-12-16 12:43:33 --> Output Class Initialized
INFO - 2024-12-16 12:43:33 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:33 --> Input Class Initialized
INFO - 2024-12-16 12:43:33 --> Language Class Initialized
INFO - 2024-12-16 12:43:33 --> Language Class Initialized
INFO - 2024-12-16 12:43:33 --> Config Class Initialized
INFO - 2024-12-16 12:43:33 --> Loader Class Initialized
INFO - 2024-12-16 12:43:33 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:33 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:33 --> Controller Class Initialized
INFO - 2024-12-16 12:43:33 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:43:33 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:33 --> Total execution time: 0.0479
INFO - 2024-12-16 12:43:33 --> Config Class Initialized
INFO - 2024-12-16 12:43:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:33 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:33 --> URI Class Initialized
INFO - 2024-12-16 12:43:33 --> Router Class Initialized
INFO - 2024-12-16 12:43:33 --> Output Class Initialized
INFO - 2024-12-16 12:43:33 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:33 --> Input Class Initialized
INFO - 2024-12-16 12:43:33 --> Language Class Initialized
INFO - 2024-12-16 12:43:33 --> Language Class Initialized
INFO - 2024-12-16 12:43:33 --> Config Class Initialized
INFO - 2024-12-16 12:43:33 --> Loader Class Initialized
INFO - 2024-12-16 12:43:33 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:33 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:33 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:33 --> Controller Class Initialized
DEBUG - 2024-12-16 12:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 12:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:43:33 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:33 --> Total execution time: 0.0535
INFO - 2024-12-16 12:43:35 --> Config Class Initialized
INFO - 2024-12-16 12:43:35 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:35 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:35 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:35 --> URI Class Initialized
INFO - 2024-12-16 12:43:35 --> Router Class Initialized
INFO - 2024-12-16 12:43:35 --> Output Class Initialized
INFO - 2024-12-16 12:43:35 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:35 --> Input Class Initialized
INFO - 2024-12-16 12:43:35 --> Language Class Initialized
INFO - 2024-12-16 12:43:35 --> Language Class Initialized
INFO - 2024-12-16 12:43:35 --> Config Class Initialized
INFO - 2024-12-16 12:43:35 --> Loader Class Initialized
INFO - 2024-12-16 12:43:35 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:35 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:35 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:35 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:35 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:35 --> Controller Class Initialized
DEBUG - 2024-12-16 12:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-16 12:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:43:35 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:35 --> Total execution time: 0.0939
INFO - 2024-12-16 12:43:38 --> Config Class Initialized
INFO - 2024-12-16 12:43:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:38 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:38 --> URI Class Initialized
INFO - 2024-12-16 12:43:38 --> Router Class Initialized
INFO - 2024-12-16 12:43:38 --> Output Class Initialized
INFO - 2024-12-16 12:43:38 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:38 --> Input Class Initialized
INFO - 2024-12-16 12:43:38 --> Language Class Initialized
INFO - 2024-12-16 12:43:38 --> Language Class Initialized
INFO - 2024-12-16 12:43:38 --> Config Class Initialized
INFO - 2024-12-16 12:43:38 --> Loader Class Initialized
INFO - 2024-12-16 12:43:38 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:38 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:38 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:38 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:38 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:38 --> Controller Class Initialized
DEBUG - 2024-12-16 12:43:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-12-16 12:43:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:43:38 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:38 --> Total execution time: 0.1002
INFO - 2024-12-16 12:43:40 --> Config Class Initialized
INFO - 2024-12-16 12:43:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:43:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:43:40 --> Utf8 Class Initialized
INFO - 2024-12-16 12:43:40 --> URI Class Initialized
INFO - 2024-12-16 12:43:40 --> Router Class Initialized
INFO - 2024-12-16 12:43:40 --> Output Class Initialized
INFO - 2024-12-16 12:43:40 --> Security Class Initialized
DEBUG - 2024-12-16 12:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:43:40 --> Input Class Initialized
INFO - 2024-12-16 12:43:40 --> Language Class Initialized
INFO - 2024-12-16 12:43:40 --> Language Class Initialized
INFO - 2024-12-16 12:43:40 --> Config Class Initialized
INFO - 2024-12-16 12:43:40 --> Loader Class Initialized
INFO - 2024-12-16 12:43:40 --> Helper loaded: url_helper
INFO - 2024-12-16 12:43:40 --> Helper loaded: file_helper
INFO - 2024-12-16 12:43:40 --> Helper loaded: form_helper
INFO - 2024-12-16 12:43:40 --> Helper loaded: my_helper
INFO - 2024-12-16 12:43:40 --> Database Driver Class Initialized
INFO - 2024-12-16 12:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:43:40 --> Controller Class Initialized
INFO - 2024-12-16 12:43:40 --> Final output sent to browser
DEBUG - 2024-12-16 12:43:40 --> Total execution time: 0.4661
INFO - 2024-12-16 12:44:37 --> Config Class Initialized
INFO - 2024-12-16 12:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:44:37 --> Utf8 Class Initialized
INFO - 2024-12-16 12:44:37 --> URI Class Initialized
INFO - 2024-12-16 12:44:37 --> Router Class Initialized
INFO - 2024-12-16 12:44:37 --> Output Class Initialized
INFO - 2024-12-16 12:44:37 --> Security Class Initialized
DEBUG - 2024-12-16 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:44:37 --> Input Class Initialized
INFO - 2024-12-16 12:44:37 --> Language Class Initialized
INFO - 2024-12-16 12:44:37 --> Language Class Initialized
INFO - 2024-12-16 12:44:37 --> Config Class Initialized
INFO - 2024-12-16 12:44:37 --> Loader Class Initialized
INFO - 2024-12-16 12:44:37 --> Helper loaded: url_helper
INFO - 2024-12-16 12:44:37 --> Helper loaded: file_helper
INFO - 2024-12-16 12:44:37 --> Helper loaded: form_helper
INFO - 2024-12-16 12:44:37 --> Helper loaded: my_helper
INFO - 2024-12-16 12:44:37 --> Database Driver Class Initialized
INFO - 2024-12-16 12:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:44:37 --> Controller Class Initialized
DEBUG - 2024-12-16 12:44:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:44:41 --> Final output sent to browser
DEBUG - 2024-12-16 12:44:41 --> Total execution time: 3.6945
INFO - 2024-12-16 12:44:51 --> Config Class Initialized
INFO - 2024-12-16 12:44:51 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:44:51 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:44:51 --> Utf8 Class Initialized
INFO - 2024-12-16 12:44:51 --> URI Class Initialized
INFO - 2024-12-16 12:44:51 --> Router Class Initialized
INFO - 2024-12-16 12:44:51 --> Output Class Initialized
INFO - 2024-12-16 12:44:51 --> Security Class Initialized
DEBUG - 2024-12-16 12:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:44:51 --> Input Class Initialized
INFO - 2024-12-16 12:44:51 --> Language Class Initialized
INFO - 2024-12-16 12:44:51 --> Language Class Initialized
INFO - 2024-12-16 12:44:51 --> Config Class Initialized
INFO - 2024-12-16 12:44:51 --> Loader Class Initialized
INFO - 2024-12-16 12:44:51 --> Helper loaded: url_helper
INFO - 2024-12-16 12:44:51 --> Helper loaded: file_helper
INFO - 2024-12-16 12:44:51 --> Helper loaded: form_helper
INFO - 2024-12-16 12:44:51 --> Helper loaded: my_helper
INFO - 2024-12-16 12:44:51 --> Database Driver Class Initialized
INFO - 2024-12-16 12:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:44:51 --> Controller Class Initialized
INFO - 2024-12-16 12:44:51 --> Final output sent to browser
DEBUG - 2024-12-16 12:44:51 --> Total execution time: 0.6229
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:45:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:45:02 --> Utf8 Class Initialized
INFO - 2024-12-16 12:45:02 --> URI Class Initialized
INFO - 2024-12-16 12:45:02 --> Router Class Initialized
INFO - 2024-12-16 12:45:02 --> Output Class Initialized
INFO - 2024-12-16 12:45:02 --> Security Class Initialized
DEBUG - 2024-12-16 12:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:45:02 --> Input Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Loader Class Initialized
INFO - 2024-12-16 12:45:02 --> Helper loaded: url_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: file_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: form_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: my_helper
INFO - 2024-12-16 12:45:02 --> Database Driver Class Initialized
INFO - 2024-12-16 12:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:45:02 --> Controller Class Initialized
INFO - 2024-12-16 12:45:02 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:45:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:45:02 --> Utf8 Class Initialized
INFO - 2024-12-16 12:45:02 --> URI Class Initialized
INFO - 2024-12-16 12:45:02 --> Router Class Initialized
INFO - 2024-12-16 12:45:02 --> Output Class Initialized
INFO - 2024-12-16 12:45:02 --> Security Class Initialized
DEBUG - 2024-12-16 12:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:45:02 --> Input Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Loader Class Initialized
INFO - 2024-12-16 12:45:02 --> Helper loaded: url_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: file_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: form_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: my_helper
INFO - 2024-12-16 12:45:02 --> Database Driver Class Initialized
INFO - 2024-12-16 12:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:45:02 --> Controller Class Initialized
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:45:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:45:02 --> Utf8 Class Initialized
INFO - 2024-12-16 12:45:02 --> URI Class Initialized
INFO - 2024-12-16 12:45:02 --> Router Class Initialized
INFO - 2024-12-16 12:45:02 --> Output Class Initialized
INFO - 2024-12-16 12:45:02 --> Security Class Initialized
DEBUG - 2024-12-16 12:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:45:02 --> Input Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Language Class Initialized
INFO - 2024-12-16 12:45:02 --> Config Class Initialized
INFO - 2024-12-16 12:45:02 --> Loader Class Initialized
INFO - 2024-12-16 12:45:02 --> Helper loaded: url_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: file_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: form_helper
INFO - 2024-12-16 12:45:02 --> Helper loaded: my_helper
INFO - 2024-12-16 12:45:02 --> Database Driver Class Initialized
INFO - 2024-12-16 12:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:45:02 --> Controller Class Initialized
DEBUG - 2024-12-16 12:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 12:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:45:02 --> Final output sent to browser
DEBUG - 2024-12-16 12:45:02 --> Total execution time: 0.0461
INFO - 2024-12-16 12:50:22 --> Config Class Initialized
INFO - 2024-12-16 12:50:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:50:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:50:22 --> Utf8 Class Initialized
INFO - 2024-12-16 12:50:22 --> URI Class Initialized
INFO - 2024-12-16 12:50:22 --> Router Class Initialized
INFO - 2024-12-16 12:50:22 --> Output Class Initialized
INFO - 2024-12-16 12:50:22 --> Security Class Initialized
DEBUG - 2024-12-16 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:50:22 --> Input Class Initialized
INFO - 2024-12-16 12:50:22 --> Language Class Initialized
INFO - 2024-12-16 12:50:22 --> Language Class Initialized
INFO - 2024-12-16 12:50:22 --> Config Class Initialized
INFO - 2024-12-16 12:50:22 --> Loader Class Initialized
INFO - 2024-12-16 12:50:22 --> Helper loaded: url_helper
INFO - 2024-12-16 12:50:22 --> Helper loaded: file_helper
INFO - 2024-12-16 12:50:22 --> Helper loaded: form_helper
INFO - 2024-12-16 12:50:22 --> Helper loaded: my_helper
INFO - 2024-12-16 12:50:22 --> Database Driver Class Initialized
INFO - 2024-12-16 12:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:50:22 --> Controller Class Initialized
INFO - 2024-12-16 12:50:22 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:50:22 --> Final output sent to browser
DEBUG - 2024-12-16 12:50:22 --> Total execution time: 0.0706
INFO - 2024-12-16 12:50:25 --> Config Class Initialized
INFO - 2024-12-16 12:50:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:50:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:50:25 --> Utf8 Class Initialized
INFO - 2024-12-16 12:50:25 --> URI Class Initialized
INFO - 2024-12-16 12:50:25 --> Router Class Initialized
INFO - 2024-12-16 12:50:25 --> Output Class Initialized
INFO - 2024-12-16 12:50:25 --> Security Class Initialized
DEBUG - 2024-12-16 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:50:25 --> Input Class Initialized
INFO - 2024-12-16 12:50:25 --> Language Class Initialized
INFO - 2024-12-16 12:50:25 --> Language Class Initialized
INFO - 2024-12-16 12:50:25 --> Config Class Initialized
INFO - 2024-12-16 12:50:25 --> Loader Class Initialized
INFO - 2024-12-16 12:50:25 --> Helper loaded: url_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: file_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: form_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: my_helper
INFO - 2024-12-16 12:50:25 --> Database Driver Class Initialized
INFO - 2024-12-16 12:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:50:25 --> Controller Class Initialized
INFO - 2024-12-16 12:50:25 --> Helper loaded: cookie_helper
INFO - 2024-12-16 12:50:25 --> Config Class Initialized
INFO - 2024-12-16 12:50:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:50:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:50:25 --> Utf8 Class Initialized
INFO - 2024-12-16 12:50:25 --> URI Class Initialized
INFO - 2024-12-16 12:50:25 --> Router Class Initialized
INFO - 2024-12-16 12:50:25 --> Output Class Initialized
INFO - 2024-12-16 12:50:25 --> Security Class Initialized
DEBUG - 2024-12-16 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:50:25 --> Input Class Initialized
INFO - 2024-12-16 12:50:25 --> Language Class Initialized
INFO - 2024-12-16 12:50:25 --> Language Class Initialized
INFO - 2024-12-16 12:50:25 --> Config Class Initialized
INFO - 2024-12-16 12:50:25 --> Loader Class Initialized
INFO - 2024-12-16 12:50:25 --> Helper loaded: url_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: file_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: form_helper
INFO - 2024-12-16 12:50:25 --> Helper loaded: my_helper
INFO - 2024-12-16 12:50:25 --> Database Driver Class Initialized
INFO - 2024-12-16 12:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:50:25 --> Controller Class Initialized
DEBUG - 2024-12-16 12:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 12:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 12:50:25 --> Final output sent to browser
DEBUG - 2024-12-16 12:50:25 --> Total execution time: 0.0405
INFO - 2024-12-16 12:50:28 --> Config Class Initialized
INFO - 2024-12-16 12:50:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 12:50:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 12:50:28 --> Utf8 Class Initialized
INFO - 2024-12-16 12:50:28 --> URI Class Initialized
INFO - 2024-12-16 12:50:28 --> Router Class Initialized
INFO - 2024-12-16 12:50:28 --> Output Class Initialized
INFO - 2024-12-16 12:50:28 --> Security Class Initialized
DEBUG - 2024-12-16 12:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 12:50:28 --> Input Class Initialized
INFO - 2024-12-16 12:50:28 --> Language Class Initialized
INFO - 2024-12-16 12:50:28 --> Language Class Initialized
INFO - 2024-12-16 12:50:28 --> Config Class Initialized
INFO - 2024-12-16 12:50:28 --> Loader Class Initialized
INFO - 2024-12-16 12:50:28 --> Helper loaded: url_helper
INFO - 2024-12-16 12:50:28 --> Helper loaded: file_helper
INFO - 2024-12-16 12:50:28 --> Helper loaded: form_helper
INFO - 2024-12-16 12:50:28 --> Helper loaded: my_helper
INFO - 2024-12-16 12:50:28 --> Database Driver Class Initialized
INFO - 2024-12-16 12:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 12:50:28 --> Controller Class Initialized
DEBUG - 2024-12-16 12:50:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 12:50:32 --> Final output sent to browser
DEBUG - 2024-12-16 12:50:32 --> Total execution time: 3.7489
INFO - 2024-12-16 13:25:46 --> Config Class Initialized
INFO - 2024-12-16 13:25:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:25:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:25:46 --> Utf8 Class Initialized
INFO - 2024-12-16 13:25:46 --> URI Class Initialized
INFO - 2024-12-16 13:25:46 --> Router Class Initialized
INFO - 2024-12-16 13:25:46 --> Output Class Initialized
INFO - 2024-12-16 13:25:46 --> Security Class Initialized
DEBUG - 2024-12-16 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:25:46 --> Input Class Initialized
INFO - 2024-12-16 13:25:46 --> Language Class Initialized
INFO - 2024-12-16 13:25:46 --> Language Class Initialized
INFO - 2024-12-16 13:25:46 --> Config Class Initialized
INFO - 2024-12-16 13:25:46 --> Loader Class Initialized
INFO - 2024-12-16 13:25:46 --> Helper loaded: url_helper
INFO - 2024-12-16 13:25:46 --> Helper loaded: file_helper
INFO - 2024-12-16 13:25:46 --> Helper loaded: form_helper
INFO - 2024-12-16 13:25:46 --> Helper loaded: my_helper
INFO - 2024-12-16 13:25:46 --> Database Driver Class Initialized
INFO - 2024-12-16 13:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:25:46 --> Controller Class Initialized
DEBUG - 2024-12-16 13:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 13:25:48 --> Final output sent to browser
DEBUG - 2024-12-16 13:25:48 --> Total execution time: 1.9603
INFO - 2024-12-16 13:26:38 --> Config Class Initialized
INFO - 2024-12-16 13:26:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:26:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:26:38 --> Utf8 Class Initialized
INFO - 2024-12-16 13:26:38 --> URI Class Initialized
INFO - 2024-12-16 13:26:38 --> Router Class Initialized
INFO - 2024-12-16 13:26:38 --> Output Class Initialized
INFO - 2024-12-16 13:26:38 --> Security Class Initialized
DEBUG - 2024-12-16 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:26:38 --> Input Class Initialized
INFO - 2024-12-16 13:26:38 --> Language Class Initialized
INFO - 2024-12-16 13:26:38 --> Language Class Initialized
INFO - 2024-12-16 13:26:38 --> Config Class Initialized
INFO - 2024-12-16 13:26:38 --> Loader Class Initialized
INFO - 2024-12-16 13:26:38 --> Helper loaded: url_helper
INFO - 2024-12-16 13:26:38 --> Helper loaded: file_helper
INFO - 2024-12-16 13:26:38 --> Helper loaded: form_helper
INFO - 2024-12-16 13:26:38 --> Helper loaded: my_helper
INFO - 2024-12-16 13:26:38 --> Database Driver Class Initialized
INFO - 2024-12-16 13:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:26:38 --> Controller Class Initialized
DEBUG - 2024-12-16 13:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 13:26:43 --> Final output sent to browser
DEBUG - 2024-12-16 13:26:43 --> Total execution time: 4.8597
INFO - 2024-12-16 13:28:01 --> Config Class Initialized
INFO - 2024-12-16 13:28:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:28:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:28:01 --> Utf8 Class Initialized
INFO - 2024-12-16 13:28:01 --> URI Class Initialized
INFO - 2024-12-16 13:28:01 --> Router Class Initialized
INFO - 2024-12-16 13:28:01 --> Output Class Initialized
INFO - 2024-12-16 13:28:01 --> Security Class Initialized
DEBUG - 2024-12-16 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:28:02 --> Input Class Initialized
INFO - 2024-12-16 13:28:02 --> Language Class Initialized
INFO - 2024-12-16 13:28:02 --> Language Class Initialized
INFO - 2024-12-16 13:28:02 --> Config Class Initialized
INFO - 2024-12-16 13:28:02 --> Loader Class Initialized
INFO - 2024-12-16 13:28:02 --> Helper loaded: url_helper
INFO - 2024-12-16 13:28:02 --> Helper loaded: file_helper
INFO - 2024-12-16 13:28:02 --> Helper loaded: form_helper
INFO - 2024-12-16 13:28:02 --> Helper loaded: my_helper
INFO - 2024-12-16 13:28:02 --> Database Driver Class Initialized
INFO - 2024-12-16 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:28:02 --> Controller Class Initialized
DEBUG - 2024-12-16 13:28:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 13:28:05 --> Final output sent to browser
DEBUG - 2024-12-16 13:28:05 --> Total execution time: 4.0463
INFO - 2024-12-16 13:45:04 --> Config Class Initialized
INFO - 2024-12-16 13:45:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:45:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:45:04 --> Utf8 Class Initialized
INFO - 2024-12-16 13:45:04 --> URI Class Initialized
INFO - 2024-12-16 13:45:04 --> Router Class Initialized
INFO - 2024-12-16 13:45:04 --> Output Class Initialized
INFO - 2024-12-16 13:45:04 --> Security Class Initialized
DEBUG - 2024-12-16 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:45:04 --> Input Class Initialized
INFO - 2024-12-16 13:45:04 --> Language Class Initialized
INFO - 2024-12-16 13:45:04 --> Language Class Initialized
INFO - 2024-12-16 13:45:04 --> Config Class Initialized
INFO - 2024-12-16 13:45:04 --> Loader Class Initialized
INFO - 2024-12-16 13:45:04 --> Helper loaded: url_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: file_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: form_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: my_helper
INFO - 2024-12-16 13:45:04 --> Database Driver Class Initialized
INFO - 2024-12-16 13:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:45:04 --> Controller Class Initialized
DEBUG - 2024-12-16 13:45:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-16 13:45:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 13:45:04 --> Final output sent to browser
DEBUG - 2024-12-16 13:45:04 --> Total execution time: 0.2299
INFO - 2024-12-16 13:45:04 --> Config Class Initialized
INFO - 2024-12-16 13:45:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:45:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:45:04 --> Utf8 Class Initialized
INFO - 2024-12-16 13:45:04 --> URI Class Initialized
INFO - 2024-12-16 13:45:04 --> Router Class Initialized
INFO - 2024-12-16 13:45:04 --> Output Class Initialized
INFO - 2024-12-16 13:45:04 --> Security Class Initialized
DEBUG - 2024-12-16 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:45:04 --> Input Class Initialized
INFO - 2024-12-16 13:45:04 --> Language Class Initialized
INFO - 2024-12-16 13:45:04 --> Language Class Initialized
INFO - 2024-12-16 13:45:04 --> Config Class Initialized
INFO - 2024-12-16 13:45:04 --> Loader Class Initialized
INFO - 2024-12-16 13:45:04 --> Helper loaded: url_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: file_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: form_helper
INFO - 2024-12-16 13:45:04 --> Helper loaded: my_helper
INFO - 2024-12-16 13:45:04 --> Database Driver Class Initialized
INFO - 2024-12-16 13:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:45:04 --> Controller Class Initialized
INFO - 2024-12-16 13:45:07 --> Config Class Initialized
INFO - 2024-12-16 13:45:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:45:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:45:07 --> Utf8 Class Initialized
INFO - 2024-12-16 13:45:07 --> URI Class Initialized
INFO - 2024-12-16 13:45:07 --> Router Class Initialized
INFO - 2024-12-16 13:45:07 --> Output Class Initialized
INFO - 2024-12-16 13:45:07 --> Security Class Initialized
DEBUG - 2024-12-16 13:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:45:07 --> Input Class Initialized
INFO - 2024-12-16 13:45:07 --> Language Class Initialized
INFO - 2024-12-16 13:45:07 --> Language Class Initialized
INFO - 2024-12-16 13:45:07 --> Config Class Initialized
INFO - 2024-12-16 13:45:07 --> Loader Class Initialized
INFO - 2024-12-16 13:45:07 --> Helper loaded: url_helper
INFO - 2024-12-16 13:45:07 --> Helper loaded: file_helper
INFO - 2024-12-16 13:45:07 --> Helper loaded: form_helper
INFO - 2024-12-16 13:45:07 --> Helper loaded: my_helper
INFO - 2024-12-16 13:45:07 --> Database Driver Class Initialized
INFO - 2024-12-16 13:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:45:07 --> Controller Class Initialized
DEBUG - 2024-12-16 13:45:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-16 13:45:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 13:45:07 --> Final output sent to browser
DEBUG - 2024-12-16 13:45:07 --> Total execution time: 0.0711
INFO - 2024-12-16 13:45:08 --> Config Class Initialized
INFO - 2024-12-16 13:45:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:45:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:45:08 --> Utf8 Class Initialized
INFO - 2024-12-16 13:45:08 --> URI Class Initialized
INFO - 2024-12-16 13:45:08 --> Router Class Initialized
INFO - 2024-12-16 13:45:08 --> Output Class Initialized
INFO - 2024-12-16 13:45:08 --> Security Class Initialized
DEBUG - 2024-12-16 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:45:08 --> Input Class Initialized
INFO - 2024-12-16 13:45:08 --> Language Class Initialized
INFO - 2024-12-16 13:45:08 --> Language Class Initialized
INFO - 2024-12-16 13:45:08 --> Config Class Initialized
INFO - 2024-12-16 13:45:08 --> Loader Class Initialized
INFO - 2024-12-16 13:45:08 --> Helper loaded: url_helper
INFO - 2024-12-16 13:45:08 --> Helper loaded: file_helper
INFO - 2024-12-16 13:45:08 --> Helper loaded: form_helper
INFO - 2024-12-16 13:45:08 --> Helper loaded: my_helper
INFO - 2024-12-16 13:45:08 --> Database Driver Class Initialized
INFO - 2024-12-16 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:45:08 --> Controller Class Initialized
INFO - 2024-12-16 13:47:10 --> Config Class Initialized
INFO - 2024-12-16 13:47:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:47:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:47:10 --> Utf8 Class Initialized
INFO - 2024-12-16 13:47:10 --> URI Class Initialized
INFO - 2024-12-16 13:47:10 --> Router Class Initialized
INFO - 2024-12-16 13:47:10 --> Output Class Initialized
INFO - 2024-12-16 13:47:10 --> Security Class Initialized
DEBUG - 2024-12-16 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:47:10 --> Input Class Initialized
INFO - 2024-12-16 13:47:10 --> Language Class Initialized
INFO - 2024-12-16 13:47:10 --> Language Class Initialized
INFO - 2024-12-16 13:47:10 --> Config Class Initialized
INFO - 2024-12-16 13:47:10 --> Loader Class Initialized
INFO - 2024-12-16 13:47:10 --> Helper loaded: url_helper
INFO - 2024-12-16 13:47:10 --> Helper loaded: file_helper
INFO - 2024-12-16 13:47:10 --> Helper loaded: form_helper
INFO - 2024-12-16 13:47:10 --> Helper loaded: my_helper
INFO - 2024-12-16 13:47:10 --> Database Driver Class Initialized
INFO - 2024-12-16 13:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:47:10 --> Controller Class Initialized
INFO - 2024-12-16 13:47:10 --> Helper loaded: cookie_helper
INFO - 2024-12-16 13:47:10 --> Final output sent to browser
DEBUG - 2024-12-16 13:47:10 --> Total execution time: 0.0772
INFO - 2024-12-16 13:47:11 --> Config Class Initialized
INFO - 2024-12-16 13:47:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:47:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:47:11 --> Utf8 Class Initialized
INFO - 2024-12-16 13:47:11 --> URI Class Initialized
INFO - 2024-12-16 13:47:11 --> Router Class Initialized
INFO - 2024-12-16 13:47:11 --> Output Class Initialized
INFO - 2024-12-16 13:47:11 --> Security Class Initialized
DEBUG - 2024-12-16 13:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:47:11 --> Input Class Initialized
INFO - 2024-12-16 13:47:11 --> Language Class Initialized
INFO - 2024-12-16 13:47:11 --> Language Class Initialized
INFO - 2024-12-16 13:47:11 --> Config Class Initialized
INFO - 2024-12-16 13:47:11 --> Loader Class Initialized
INFO - 2024-12-16 13:47:11 --> Helper loaded: url_helper
INFO - 2024-12-16 13:47:11 --> Helper loaded: file_helper
INFO - 2024-12-16 13:47:11 --> Helper loaded: form_helper
INFO - 2024-12-16 13:47:11 --> Helper loaded: my_helper
INFO - 2024-12-16 13:47:11 --> Database Driver Class Initialized
INFO - 2024-12-16 13:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:47:11 --> Controller Class Initialized
INFO - 2024-12-16 13:47:11 --> Helper loaded: cookie_helper
INFO - 2024-12-16 13:47:12 --> Config Class Initialized
INFO - 2024-12-16 13:47:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:47:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:47:12 --> Utf8 Class Initialized
INFO - 2024-12-16 13:47:12 --> URI Class Initialized
INFO - 2024-12-16 13:47:12 --> Router Class Initialized
INFO - 2024-12-16 13:47:12 --> Output Class Initialized
INFO - 2024-12-16 13:47:12 --> Security Class Initialized
DEBUG - 2024-12-16 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:47:12 --> Input Class Initialized
INFO - 2024-12-16 13:47:12 --> Language Class Initialized
INFO - 2024-12-16 13:47:12 --> Language Class Initialized
INFO - 2024-12-16 13:47:12 --> Config Class Initialized
INFO - 2024-12-16 13:47:12 --> Loader Class Initialized
INFO - 2024-12-16 13:47:12 --> Helper loaded: url_helper
INFO - 2024-12-16 13:47:12 --> Helper loaded: file_helper
INFO - 2024-12-16 13:47:12 --> Helper loaded: form_helper
INFO - 2024-12-16 13:47:12 --> Helper loaded: my_helper
INFO - 2024-12-16 13:47:12 --> Database Driver Class Initialized
INFO - 2024-12-16 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:47:12 --> Controller Class Initialized
DEBUG - 2024-12-16 13:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 13:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 13:47:12 --> Final output sent to browser
DEBUG - 2024-12-16 13:47:12 --> Total execution time: 0.4687
INFO - 2024-12-16 13:53:54 --> Config Class Initialized
INFO - 2024-12-16 13:53:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:53:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:53:54 --> Utf8 Class Initialized
INFO - 2024-12-16 13:53:54 --> URI Class Initialized
INFO - 2024-12-16 13:53:54 --> Router Class Initialized
INFO - 2024-12-16 13:53:54 --> Output Class Initialized
INFO - 2024-12-16 13:53:54 --> Security Class Initialized
DEBUG - 2024-12-16 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:53:54 --> Input Class Initialized
INFO - 2024-12-16 13:53:54 --> Language Class Initialized
INFO - 2024-12-16 13:53:54 --> Language Class Initialized
INFO - 2024-12-16 13:53:54 --> Config Class Initialized
INFO - 2024-12-16 13:53:54 --> Loader Class Initialized
INFO - 2024-12-16 13:53:54 --> Helper loaded: url_helper
INFO - 2024-12-16 13:53:54 --> Helper loaded: file_helper
INFO - 2024-12-16 13:53:54 --> Helper loaded: form_helper
INFO - 2024-12-16 13:53:54 --> Helper loaded: my_helper
INFO - 2024-12-16 13:53:54 --> Database Driver Class Initialized
INFO - 2024-12-16 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:53:54 --> Controller Class Initialized
DEBUG - 2024-12-16 13:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 13:54:00 --> Final output sent to browser
DEBUG - 2024-12-16 13:54:00 --> Total execution time: 5.1391
INFO - 2024-12-16 13:56:43 --> Config Class Initialized
INFO - 2024-12-16 13:56:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:56:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:56:43 --> Utf8 Class Initialized
INFO - 2024-12-16 13:56:43 --> URI Class Initialized
INFO - 2024-12-16 13:56:43 --> Router Class Initialized
INFO - 2024-12-16 13:56:43 --> Output Class Initialized
INFO - 2024-12-16 13:56:43 --> Security Class Initialized
DEBUG - 2024-12-16 13:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:56:43 --> Input Class Initialized
INFO - 2024-12-16 13:56:43 --> Language Class Initialized
INFO - 2024-12-16 13:56:43 --> Language Class Initialized
INFO - 2024-12-16 13:56:43 --> Config Class Initialized
INFO - 2024-12-16 13:56:43 --> Loader Class Initialized
INFO - 2024-12-16 13:56:43 --> Helper loaded: url_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: file_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: form_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: my_helper
INFO - 2024-12-16 13:56:43 --> Database Driver Class Initialized
INFO - 2024-12-16 13:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:56:43 --> Controller Class Initialized
INFO - 2024-12-16 13:56:43 --> Helper loaded: cookie_helper
INFO - 2024-12-16 13:56:43 --> Final output sent to browser
DEBUG - 2024-12-16 13:56:43 --> Total execution time: 0.0348
INFO - 2024-12-16 13:56:43 --> Config Class Initialized
INFO - 2024-12-16 13:56:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:56:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:56:43 --> Utf8 Class Initialized
INFO - 2024-12-16 13:56:43 --> URI Class Initialized
INFO - 2024-12-16 13:56:43 --> Router Class Initialized
INFO - 2024-12-16 13:56:43 --> Output Class Initialized
INFO - 2024-12-16 13:56:43 --> Security Class Initialized
DEBUG - 2024-12-16 13:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:56:43 --> Input Class Initialized
INFO - 2024-12-16 13:56:43 --> Language Class Initialized
INFO - 2024-12-16 13:56:43 --> Language Class Initialized
INFO - 2024-12-16 13:56:43 --> Config Class Initialized
INFO - 2024-12-16 13:56:43 --> Loader Class Initialized
INFO - 2024-12-16 13:56:43 --> Helper loaded: url_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: file_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: form_helper
INFO - 2024-12-16 13:56:43 --> Helper loaded: my_helper
INFO - 2024-12-16 13:56:43 --> Database Driver Class Initialized
INFO - 2024-12-16 13:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:56:43 --> Controller Class Initialized
DEBUG - 2024-12-16 13:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 13:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 13:56:43 --> Final output sent to browser
DEBUG - 2024-12-16 13:56:43 --> Total execution time: 0.0323
INFO - 2024-12-16 13:56:53 --> Config Class Initialized
INFO - 2024-12-16 13:56:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 13:56:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 13:56:53 --> Utf8 Class Initialized
INFO - 2024-12-16 13:56:53 --> URI Class Initialized
INFO - 2024-12-16 13:56:53 --> Router Class Initialized
INFO - 2024-12-16 13:56:53 --> Output Class Initialized
INFO - 2024-12-16 13:56:53 --> Security Class Initialized
DEBUG - 2024-12-16 13:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 13:56:53 --> Input Class Initialized
INFO - 2024-12-16 13:56:53 --> Language Class Initialized
INFO - 2024-12-16 13:56:53 --> Language Class Initialized
INFO - 2024-12-16 13:56:53 --> Config Class Initialized
INFO - 2024-12-16 13:56:53 --> Loader Class Initialized
INFO - 2024-12-16 13:56:53 --> Helper loaded: url_helper
INFO - 2024-12-16 13:56:53 --> Helper loaded: file_helper
INFO - 2024-12-16 13:56:53 --> Helper loaded: form_helper
INFO - 2024-12-16 13:56:53 --> Helper loaded: my_helper
INFO - 2024-12-16 13:56:53 --> Database Driver Class Initialized
INFO - 2024-12-16 13:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 13:56:53 --> Controller Class Initialized
DEBUG - 2024-12-16 13:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 13:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 13:56:53 --> Final output sent to browser
DEBUG - 2024-12-16 13:56:53 --> Total execution time: 0.0935
INFO - 2024-12-16 14:02:27 --> Config Class Initialized
INFO - 2024-12-16 14:02:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:02:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:02:27 --> Utf8 Class Initialized
INFO - 2024-12-16 14:02:27 --> URI Class Initialized
INFO - 2024-12-16 14:02:27 --> Router Class Initialized
INFO - 2024-12-16 14:02:27 --> Output Class Initialized
INFO - 2024-12-16 14:02:27 --> Security Class Initialized
DEBUG - 2024-12-16 14:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:02:27 --> Input Class Initialized
INFO - 2024-12-16 14:02:27 --> Language Class Initialized
INFO - 2024-12-16 14:02:27 --> Language Class Initialized
INFO - 2024-12-16 14:02:27 --> Config Class Initialized
INFO - 2024-12-16 14:02:27 --> Loader Class Initialized
INFO - 2024-12-16 14:02:27 --> Helper loaded: url_helper
INFO - 2024-12-16 14:02:27 --> Helper loaded: file_helper
INFO - 2024-12-16 14:02:27 --> Helper loaded: form_helper
INFO - 2024-12-16 14:02:27 --> Helper loaded: my_helper
INFO - 2024-12-16 14:02:27 --> Database Driver Class Initialized
INFO - 2024-12-16 14:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:02:27 --> Controller Class Initialized
INFO - 2024-12-16 14:02:27 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:02:27 --> Final output sent to browser
DEBUG - 2024-12-16 14:02:27 --> Total execution time: 0.0472
INFO - 2024-12-16 14:02:28 --> Config Class Initialized
INFO - 2024-12-16 14:02:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:02:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:02:28 --> Utf8 Class Initialized
INFO - 2024-12-16 14:02:28 --> URI Class Initialized
INFO - 2024-12-16 14:02:28 --> Router Class Initialized
INFO - 2024-12-16 14:02:28 --> Output Class Initialized
INFO - 2024-12-16 14:02:28 --> Security Class Initialized
DEBUG - 2024-12-16 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:02:28 --> Input Class Initialized
INFO - 2024-12-16 14:02:28 --> Language Class Initialized
INFO - 2024-12-16 14:02:28 --> Language Class Initialized
INFO - 2024-12-16 14:02:28 --> Config Class Initialized
INFO - 2024-12-16 14:02:28 --> Loader Class Initialized
INFO - 2024-12-16 14:02:28 --> Helper loaded: url_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: file_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: form_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: my_helper
INFO - 2024-12-16 14:02:28 --> Database Driver Class Initialized
INFO - 2024-12-16 14:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:02:28 --> Controller Class Initialized
INFO - 2024-12-16 14:02:28 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:02:28 --> Config Class Initialized
INFO - 2024-12-16 14:02:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:02:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:02:28 --> Utf8 Class Initialized
INFO - 2024-12-16 14:02:28 --> URI Class Initialized
INFO - 2024-12-16 14:02:28 --> Router Class Initialized
INFO - 2024-12-16 14:02:28 --> Output Class Initialized
INFO - 2024-12-16 14:02:28 --> Security Class Initialized
DEBUG - 2024-12-16 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:02:28 --> Input Class Initialized
INFO - 2024-12-16 14:02:28 --> Language Class Initialized
INFO - 2024-12-16 14:02:28 --> Language Class Initialized
INFO - 2024-12-16 14:02:28 --> Config Class Initialized
INFO - 2024-12-16 14:02:28 --> Loader Class Initialized
INFO - 2024-12-16 14:02:28 --> Helper loaded: url_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: file_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: form_helper
INFO - 2024-12-16 14:02:28 --> Helper loaded: my_helper
INFO - 2024-12-16 14:02:28 --> Database Driver Class Initialized
INFO - 2024-12-16 14:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:02:28 --> Controller Class Initialized
DEBUG - 2024-12-16 14:02:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:02:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:02:28 --> Final output sent to browser
DEBUG - 2024-12-16 14:02:28 --> Total execution time: 0.0304
INFO - 2024-12-16 14:02:31 --> Config Class Initialized
INFO - 2024-12-16 14:02:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:02:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:02:31 --> Utf8 Class Initialized
INFO - 2024-12-16 14:02:31 --> URI Class Initialized
INFO - 2024-12-16 14:02:31 --> Router Class Initialized
INFO - 2024-12-16 14:02:31 --> Output Class Initialized
INFO - 2024-12-16 14:02:31 --> Security Class Initialized
DEBUG - 2024-12-16 14:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:02:31 --> Input Class Initialized
INFO - 2024-12-16 14:02:31 --> Language Class Initialized
INFO - 2024-12-16 14:02:31 --> Language Class Initialized
INFO - 2024-12-16 14:02:31 --> Config Class Initialized
INFO - 2024-12-16 14:02:31 --> Loader Class Initialized
INFO - 2024-12-16 14:02:31 --> Helper loaded: url_helper
INFO - 2024-12-16 14:02:31 --> Helper loaded: file_helper
INFO - 2024-12-16 14:02:31 --> Helper loaded: form_helper
INFO - 2024-12-16 14:02:31 --> Helper loaded: my_helper
INFO - 2024-12-16 14:02:31 --> Database Driver Class Initialized
INFO - 2024-12-16 14:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:02:31 --> Controller Class Initialized
DEBUG - 2024-12-16 14:02:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:02:34 --> Final output sent to browser
DEBUG - 2024-12-16 14:02:34 --> Total execution time: 3.2015
INFO - 2024-12-16 14:03:12 --> Config Class Initialized
INFO - 2024-12-16 14:03:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:03:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:03:12 --> Utf8 Class Initialized
INFO - 2024-12-16 14:03:12 --> URI Class Initialized
INFO - 2024-12-16 14:03:12 --> Router Class Initialized
INFO - 2024-12-16 14:03:12 --> Output Class Initialized
INFO - 2024-12-16 14:03:12 --> Security Class Initialized
DEBUG - 2024-12-16 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:03:12 --> Input Class Initialized
INFO - 2024-12-16 14:03:12 --> Language Class Initialized
INFO - 2024-12-16 14:03:12 --> Language Class Initialized
INFO - 2024-12-16 14:03:12 --> Config Class Initialized
INFO - 2024-12-16 14:03:12 --> Loader Class Initialized
INFO - 2024-12-16 14:03:12 --> Helper loaded: url_helper
INFO - 2024-12-16 14:03:12 --> Helper loaded: file_helper
INFO - 2024-12-16 14:03:12 --> Helper loaded: form_helper
INFO - 2024-12-16 14:03:12 --> Helper loaded: my_helper
INFO - 2024-12-16 14:03:12 --> Database Driver Class Initialized
INFO - 2024-12-16 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:03:12 --> Controller Class Initialized
DEBUG - 2024-12-16 14:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:03:15 --> Final output sent to browser
DEBUG - 2024-12-16 14:03:15 --> Total execution time: 3.0779
INFO - 2024-12-16 14:03:55 --> Config Class Initialized
INFO - 2024-12-16 14:03:55 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:03:55 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:03:55 --> Utf8 Class Initialized
INFO - 2024-12-16 14:03:55 --> URI Class Initialized
INFO - 2024-12-16 14:03:55 --> Router Class Initialized
INFO - 2024-12-16 14:03:55 --> Output Class Initialized
INFO - 2024-12-16 14:03:55 --> Security Class Initialized
DEBUG - 2024-12-16 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:03:55 --> Input Class Initialized
INFO - 2024-12-16 14:03:55 --> Language Class Initialized
INFO - 2024-12-16 14:03:55 --> Language Class Initialized
INFO - 2024-12-16 14:03:55 --> Config Class Initialized
INFO - 2024-12-16 14:03:55 --> Loader Class Initialized
INFO - 2024-12-16 14:03:55 --> Helper loaded: url_helper
INFO - 2024-12-16 14:03:55 --> Helper loaded: file_helper
INFO - 2024-12-16 14:03:55 --> Helper loaded: form_helper
INFO - 2024-12-16 14:03:55 --> Helper loaded: my_helper
INFO - 2024-12-16 14:03:55 --> Database Driver Class Initialized
INFO - 2024-12-16 14:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:03:55 --> Controller Class Initialized
DEBUG - 2024-12-16 14:03:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:03:59 --> Final output sent to browser
DEBUG - 2024-12-16 14:03:59 --> Total execution time: 4.6312
INFO - 2024-12-16 14:04:30 --> Config Class Initialized
INFO - 2024-12-16 14:04:30 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:04:30 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:04:30 --> Utf8 Class Initialized
INFO - 2024-12-16 14:04:30 --> URI Class Initialized
INFO - 2024-12-16 14:04:30 --> Router Class Initialized
INFO - 2024-12-16 14:04:30 --> Output Class Initialized
INFO - 2024-12-16 14:04:30 --> Security Class Initialized
DEBUG - 2024-12-16 14:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:04:30 --> Input Class Initialized
INFO - 2024-12-16 14:04:30 --> Language Class Initialized
INFO - 2024-12-16 14:04:30 --> Language Class Initialized
INFO - 2024-12-16 14:04:30 --> Config Class Initialized
INFO - 2024-12-16 14:04:30 --> Loader Class Initialized
INFO - 2024-12-16 14:04:30 --> Helper loaded: url_helper
INFO - 2024-12-16 14:04:30 --> Helper loaded: file_helper
INFO - 2024-12-16 14:04:30 --> Helper loaded: form_helper
INFO - 2024-12-16 14:04:30 --> Helper loaded: my_helper
INFO - 2024-12-16 14:04:30 --> Database Driver Class Initialized
INFO - 2024-12-16 14:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:04:30 --> Controller Class Initialized
DEBUG - 2024-12-16 14:04:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 14:04:35 --> Final output sent to browser
DEBUG - 2024-12-16 14:04:35 --> Total execution time: 4.5660
INFO - 2024-12-16 14:05:22 --> Config Class Initialized
INFO - 2024-12-16 14:05:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:05:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:05:22 --> Utf8 Class Initialized
INFO - 2024-12-16 14:05:22 --> URI Class Initialized
INFO - 2024-12-16 14:05:22 --> Router Class Initialized
INFO - 2024-12-16 14:05:22 --> Output Class Initialized
INFO - 2024-12-16 14:05:22 --> Security Class Initialized
DEBUG - 2024-12-16 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:05:22 --> Input Class Initialized
INFO - 2024-12-16 14:05:22 --> Language Class Initialized
INFO - 2024-12-16 14:05:22 --> Language Class Initialized
INFO - 2024-12-16 14:05:22 --> Config Class Initialized
INFO - 2024-12-16 14:05:22 --> Loader Class Initialized
INFO - 2024-12-16 14:05:22 --> Helper loaded: url_helper
INFO - 2024-12-16 14:05:22 --> Helper loaded: file_helper
INFO - 2024-12-16 14:05:22 --> Helper loaded: form_helper
INFO - 2024-12-16 14:05:22 --> Helper loaded: my_helper
INFO - 2024-12-16 14:05:22 --> Database Driver Class Initialized
INFO - 2024-12-16 14:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:05:22 --> Controller Class Initialized
INFO - 2024-12-16 14:05:22 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:05:22 --> Final output sent to browser
DEBUG - 2024-12-16 14:05:22 --> Total execution time: 0.1135
INFO - 2024-12-16 14:05:23 --> Config Class Initialized
INFO - 2024-12-16 14:05:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:05:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:05:23 --> Utf8 Class Initialized
INFO - 2024-12-16 14:05:23 --> URI Class Initialized
INFO - 2024-12-16 14:05:23 --> Router Class Initialized
INFO - 2024-12-16 14:05:23 --> Output Class Initialized
INFO - 2024-12-16 14:05:23 --> Security Class Initialized
DEBUG - 2024-12-16 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:05:23 --> Input Class Initialized
INFO - 2024-12-16 14:05:23 --> Language Class Initialized
INFO - 2024-12-16 14:05:23 --> Language Class Initialized
INFO - 2024-12-16 14:05:23 --> Config Class Initialized
INFO - 2024-12-16 14:05:23 --> Loader Class Initialized
INFO - 2024-12-16 14:05:23 --> Helper loaded: url_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: file_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: form_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: my_helper
INFO - 2024-12-16 14:05:23 --> Database Driver Class Initialized
INFO - 2024-12-16 14:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:05:23 --> Controller Class Initialized
INFO - 2024-12-16 14:05:23 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:05:23 --> Config Class Initialized
INFO - 2024-12-16 14:05:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:05:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:05:23 --> Utf8 Class Initialized
INFO - 2024-12-16 14:05:23 --> URI Class Initialized
INFO - 2024-12-16 14:05:23 --> Router Class Initialized
INFO - 2024-12-16 14:05:23 --> Output Class Initialized
INFO - 2024-12-16 14:05:23 --> Security Class Initialized
DEBUG - 2024-12-16 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:05:23 --> Input Class Initialized
INFO - 2024-12-16 14:05:23 --> Language Class Initialized
INFO - 2024-12-16 14:05:23 --> Language Class Initialized
INFO - 2024-12-16 14:05:23 --> Config Class Initialized
INFO - 2024-12-16 14:05:23 --> Loader Class Initialized
INFO - 2024-12-16 14:05:23 --> Helper loaded: url_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: file_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: form_helper
INFO - 2024-12-16 14:05:23 --> Helper loaded: my_helper
INFO - 2024-12-16 14:05:23 --> Database Driver Class Initialized
INFO - 2024-12-16 14:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:05:23 --> Controller Class Initialized
DEBUG - 2024-12-16 14:05:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:05:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:05:23 --> Final output sent to browser
DEBUG - 2024-12-16 14:05:23 --> Total execution time: 0.0404
INFO - 2024-12-16 14:05:47 --> Config Class Initialized
INFO - 2024-12-16 14:05:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:05:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:05:47 --> Utf8 Class Initialized
INFO - 2024-12-16 14:05:47 --> URI Class Initialized
INFO - 2024-12-16 14:05:47 --> Router Class Initialized
INFO - 2024-12-16 14:05:47 --> Output Class Initialized
INFO - 2024-12-16 14:05:47 --> Security Class Initialized
DEBUG - 2024-12-16 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:05:47 --> Input Class Initialized
INFO - 2024-12-16 14:05:47 --> Language Class Initialized
INFO - 2024-12-16 14:05:47 --> Language Class Initialized
INFO - 2024-12-16 14:05:47 --> Config Class Initialized
INFO - 2024-12-16 14:05:47 --> Loader Class Initialized
INFO - 2024-12-16 14:05:47 --> Helper loaded: url_helper
INFO - 2024-12-16 14:05:47 --> Helper loaded: file_helper
INFO - 2024-12-16 14:05:47 --> Helper loaded: form_helper
INFO - 2024-12-16 14:05:47 --> Helper loaded: my_helper
INFO - 2024-12-16 14:05:47 --> Database Driver Class Initialized
INFO - 2024-12-16 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:05:47 --> Controller Class Initialized
DEBUG - 2024-12-16 14:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:05:51 --> Final output sent to browser
DEBUG - 2024-12-16 14:05:51 --> Total execution time: 3.7686
INFO - 2024-12-16 14:06:41 --> Config Class Initialized
INFO - 2024-12-16 14:06:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:06:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:06:41 --> Utf8 Class Initialized
INFO - 2024-12-16 14:06:41 --> URI Class Initialized
INFO - 2024-12-16 14:06:41 --> Router Class Initialized
INFO - 2024-12-16 14:06:41 --> Output Class Initialized
INFO - 2024-12-16 14:06:41 --> Security Class Initialized
DEBUG - 2024-12-16 14:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:06:41 --> Input Class Initialized
INFO - 2024-12-16 14:06:41 --> Language Class Initialized
INFO - 2024-12-16 14:06:41 --> Language Class Initialized
INFO - 2024-12-16 14:06:41 --> Config Class Initialized
INFO - 2024-12-16 14:06:41 --> Loader Class Initialized
INFO - 2024-12-16 14:06:41 --> Helper loaded: url_helper
INFO - 2024-12-16 14:06:41 --> Helper loaded: file_helper
INFO - 2024-12-16 14:06:41 --> Helper loaded: form_helper
INFO - 2024-12-16 14:06:41 --> Helper loaded: my_helper
INFO - 2024-12-16 14:06:41 --> Database Driver Class Initialized
INFO - 2024-12-16 14:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:06:41 --> Controller Class Initialized
DEBUG - 2024-12-16 14:06:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:06:45 --> Final output sent to browser
DEBUG - 2024-12-16 14:06:45 --> Total execution time: 4.5348
INFO - 2024-12-16 14:06:56 --> Config Class Initialized
INFO - 2024-12-16 14:06:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:06:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:06:56 --> Utf8 Class Initialized
INFO - 2024-12-16 14:06:56 --> URI Class Initialized
INFO - 2024-12-16 14:06:56 --> Router Class Initialized
INFO - 2024-12-16 14:06:56 --> Output Class Initialized
INFO - 2024-12-16 14:06:56 --> Security Class Initialized
DEBUG - 2024-12-16 14:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:06:56 --> Input Class Initialized
INFO - 2024-12-16 14:06:56 --> Language Class Initialized
INFO - 2024-12-16 14:06:56 --> Language Class Initialized
INFO - 2024-12-16 14:06:56 --> Config Class Initialized
INFO - 2024-12-16 14:06:56 --> Loader Class Initialized
INFO - 2024-12-16 14:06:56 --> Helper loaded: url_helper
INFO - 2024-12-16 14:06:56 --> Helper loaded: file_helper
INFO - 2024-12-16 14:06:56 --> Helper loaded: form_helper
INFO - 2024-12-16 14:06:56 --> Helper loaded: my_helper
INFO - 2024-12-16 14:06:56 --> Database Driver Class Initialized
INFO - 2024-12-16 14:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:06:56 --> Controller Class Initialized
DEBUG - 2024-12-16 14:06:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:07:00 --> Final output sent to browser
DEBUG - 2024-12-16 14:07:00 --> Total execution time: 4.5592
INFO - 2024-12-16 14:07:21 --> Config Class Initialized
INFO - 2024-12-16 14:07:21 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:07:21 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:07:21 --> Utf8 Class Initialized
INFO - 2024-12-16 14:07:21 --> URI Class Initialized
INFO - 2024-12-16 14:07:21 --> Router Class Initialized
INFO - 2024-12-16 14:07:21 --> Output Class Initialized
INFO - 2024-12-16 14:07:21 --> Security Class Initialized
DEBUG - 2024-12-16 14:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:07:21 --> Input Class Initialized
INFO - 2024-12-16 14:07:21 --> Language Class Initialized
INFO - 2024-12-16 14:07:21 --> Language Class Initialized
INFO - 2024-12-16 14:07:21 --> Config Class Initialized
INFO - 2024-12-16 14:07:21 --> Loader Class Initialized
INFO - 2024-12-16 14:07:21 --> Helper loaded: url_helper
INFO - 2024-12-16 14:07:21 --> Helper loaded: file_helper
INFO - 2024-12-16 14:07:21 --> Helper loaded: form_helper
INFO - 2024-12-16 14:07:21 --> Helper loaded: my_helper
INFO - 2024-12-16 14:07:21 --> Database Driver Class Initialized
INFO - 2024-12-16 14:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:07:21 --> Controller Class Initialized
DEBUG - 2024-12-16 14:07:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:07:25 --> Final output sent to browser
DEBUG - 2024-12-16 14:07:25 --> Total execution time: 4.1944
INFO - 2024-12-16 14:07:48 --> Config Class Initialized
INFO - 2024-12-16 14:07:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:07:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:07:48 --> Utf8 Class Initialized
INFO - 2024-12-16 14:07:48 --> URI Class Initialized
INFO - 2024-12-16 14:07:48 --> Router Class Initialized
INFO - 2024-12-16 14:07:48 --> Output Class Initialized
INFO - 2024-12-16 14:07:48 --> Security Class Initialized
DEBUG - 2024-12-16 14:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:07:48 --> Input Class Initialized
INFO - 2024-12-16 14:07:48 --> Language Class Initialized
INFO - 2024-12-16 14:07:48 --> Language Class Initialized
INFO - 2024-12-16 14:07:48 --> Config Class Initialized
INFO - 2024-12-16 14:07:48 --> Loader Class Initialized
INFO - 2024-12-16 14:07:48 --> Helper loaded: url_helper
INFO - 2024-12-16 14:07:48 --> Helper loaded: file_helper
INFO - 2024-12-16 14:07:48 --> Helper loaded: form_helper
INFO - 2024-12-16 14:07:48 --> Helper loaded: my_helper
INFO - 2024-12-16 14:07:48 --> Database Driver Class Initialized
INFO - 2024-12-16 14:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:07:48 --> Controller Class Initialized
DEBUG - 2024-12-16 14:07:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:07:51 --> Final output sent to browser
DEBUG - 2024-12-16 14:07:51 --> Total execution time: 3.1307
INFO - 2024-12-16 14:08:01 --> Config Class Initialized
INFO - 2024-12-16 14:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:08:01 --> Utf8 Class Initialized
INFO - 2024-12-16 14:08:01 --> URI Class Initialized
INFO - 2024-12-16 14:08:01 --> Router Class Initialized
INFO - 2024-12-16 14:08:01 --> Output Class Initialized
INFO - 2024-12-16 14:08:01 --> Security Class Initialized
DEBUG - 2024-12-16 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:08:01 --> Input Class Initialized
INFO - 2024-12-16 14:08:01 --> Language Class Initialized
INFO - 2024-12-16 14:08:01 --> Language Class Initialized
INFO - 2024-12-16 14:08:01 --> Config Class Initialized
INFO - 2024-12-16 14:08:01 --> Loader Class Initialized
INFO - 2024-12-16 14:08:01 --> Helper loaded: url_helper
INFO - 2024-12-16 14:08:01 --> Helper loaded: file_helper
INFO - 2024-12-16 14:08:01 --> Helper loaded: form_helper
INFO - 2024-12-16 14:08:01 --> Helper loaded: my_helper
INFO - 2024-12-16 14:08:01 --> Database Driver Class Initialized
INFO - 2024-12-16 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:08:01 --> Controller Class Initialized
DEBUG - 2024-12-16 14:08:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 14:08:08 --> Final output sent to browser
DEBUG - 2024-12-16 14:08:08 --> Total execution time: 7.0965
INFO - 2024-12-16 14:09:07 --> Config Class Initialized
INFO - 2024-12-16 14:09:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:09:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:09:07 --> Utf8 Class Initialized
INFO - 2024-12-16 14:09:07 --> URI Class Initialized
INFO - 2024-12-16 14:09:07 --> Router Class Initialized
INFO - 2024-12-16 14:09:07 --> Output Class Initialized
INFO - 2024-12-16 14:09:07 --> Security Class Initialized
DEBUG - 2024-12-16 14:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:09:07 --> Input Class Initialized
INFO - 2024-12-16 14:09:07 --> Language Class Initialized
INFO - 2024-12-16 14:09:07 --> Language Class Initialized
INFO - 2024-12-16 14:09:07 --> Config Class Initialized
INFO - 2024-12-16 14:09:07 --> Loader Class Initialized
INFO - 2024-12-16 14:09:07 --> Helper loaded: url_helper
INFO - 2024-12-16 14:09:07 --> Helper loaded: file_helper
INFO - 2024-12-16 14:09:07 --> Helper loaded: form_helper
INFO - 2024-12-16 14:09:07 --> Helper loaded: my_helper
INFO - 2024-12-16 14:09:07 --> Database Driver Class Initialized
INFO - 2024-12-16 14:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:09:07 --> Controller Class Initialized
DEBUG - 2024-12-16 14:09:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 14:09:09 --> Final output sent to browser
DEBUG - 2024-12-16 14:09:09 --> Total execution time: 2.3114
INFO - 2024-12-16 14:09:28 --> Config Class Initialized
INFO - 2024-12-16 14:09:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:09:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:09:28 --> Utf8 Class Initialized
INFO - 2024-12-16 14:09:28 --> URI Class Initialized
INFO - 2024-12-16 14:09:28 --> Router Class Initialized
INFO - 2024-12-16 14:09:28 --> Output Class Initialized
INFO - 2024-12-16 14:09:28 --> Security Class Initialized
DEBUG - 2024-12-16 14:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:09:28 --> Input Class Initialized
INFO - 2024-12-16 14:09:28 --> Language Class Initialized
INFO - 2024-12-16 14:09:28 --> Language Class Initialized
INFO - 2024-12-16 14:09:28 --> Config Class Initialized
INFO - 2024-12-16 14:09:28 --> Loader Class Initialized
INFO - 2024-12-16 14:09:28 --> Helper loaded: url_helper
INFO - 2024-12-16 14:09:28 --> Helper loaded: file_helper
INFO - 2024-12-16 14:09:28 --> Helper loaded: form_helper
INFO - 2024-12-16 14:09:28 --> Helper loaded: my_helper
INFO - 2024-12-16 14:09:28 --> Database Driver Class Initialized
INFO - 2024-12-16 14:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:09:28 --> Controller Class Initialized
DEBUG - 2024-12-16 14:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 14:09:30 --> Final output sent to browser
DEBUG - 2024-12-16 14:09:30 --> Total execution time: 1.9864
INFO - 2024-12-16 14:13:19 --> Config Class Initialized
INFO - 2024-12-16 14:13:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:13:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:13:19 --> Utf8 Class Initialized
INFO - 2024-12-16 14:13:19 --> URI Class Initialized
INFO - 2024-12-16 14:13:19 --> Router Class Initialized
INFO - 2024-12-16 14:13:19 --> Output Class Initialized
INFO - 2024-12-16 14:13:19 --> Security Class Initialized
DEBUG - 2024-12-16 14:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:13:19 --> Input Class Initialized
INFO - 2024-12-16 14:13:19 --> Language Class Initialized
INFO - 2024-12-16 14:13:19 --> Language Class Initialized
INFO - 2024-12-16 14:13:19 --> Config Class Initialized
INFO - 2024-12-16 14:13:19 --> Loader Class Initialized
INFO - 2024-12-16 14:13:19 --> Helper loaded: url_helper
INFO - 2024-12-16 14:13:19 --> Helper loaded: file_helper
INFO - 2024-12-16 14:13:19 --> Helper loaded: form_helper
INFO - 2024-12-16 14:13:19 --> Helper loaded: my_helper
INFO - 2024-12-16 14:13:19 --> Database Driver Class Initialized
INFO - 2024-12-16 14:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:13:19 --> Controller Class Initialized
INFO - 2024-12-16 14:13:19 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:13:19 --> Final output sent to browser
DEBUG - 2024-12-16 14:13:19 --> Total execution time: 0.1927
INFO - 2024-12-16 14:13:20 --> Config Class Initialized
INFO - 2024-12-16 14:13:20 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:13:20 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:13:20 --> Utf8 Class Initialized
INFO - 2024-12-16 14:13:20 --> URI Class Initialized
INFO - 2024-12-16 14:13:20 --> Router Class Initialized
INFO - 2024-12-16 14:13:20 --> Output Class Initialized
INFO - 2024-12-16 14:13:20 --> Security Class Initialized
DEBUG - 2024-12-16 14:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:13:20 --> Input Class Initialized
INFO - 2024-12-16 14:13:20 --> Language Class Initialized
INFO - 2024-12-16 14:13:20 --> Language Class Initialized
INFO - 2024-12-16 14:13:20 --> Config Class Initialized
INFO - 2024-12-16 14:13:20 --> Loader Class Initialized
INFO - 2024-12-16 14:13:20 --> Helper loaded: url_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: file_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: form_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: my_helper
INFO - 2024-12-16 14:13:20 --> Database Driver Class Initialized
INFO - 2024-12-16 14:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:13:20 --> Controller Class Initialized
INFO - 2024-12-16 14:13:20 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:13:20 --> Config Class Initialized
INFO - 2024-12-16 14:13:20 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:13:20 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:13:20 --> Utf8 Class Initialized
INFO - 2024-12-16 14:13:20 --> URI Class Initialized
INFO - 2024-12-16 14:13:20 --> Router Class Initialized
INFO - 2024-12-16 14:13:20 --> Output Class Initialized
INFO - 2024-12-16 14:13:20 --> Security Class Initialized
DEBUG - 2024-12-16 14:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:13:20 --> Input Class Initialized
INFO - 2024-12-16 14:13:20 --> Language Class Initialized
INFO - 2024-12-16 14:13:20 --> Language Class Initialized
INFO - 2024-12-16 14:13:20 --> Config Class Initialized
INFO - 2024-12-16 14:13:20 --> Loader Class Initialized
INFO - 2024-12-16 14:13:20 --> Helper loaded: url_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: file_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: form_helper
INFO - 2024-12-16 14:13:20 --> Helper loaded: my_helper
INFO - 2024-12-16 14:13:20 --> Database Driver Class Initialized
INFO - 2024-12-16 14:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:13:20 --> Controller Class Initialized
DEBUG - 2024-12-16 14:13:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:13:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:13:20 --> Final output sent to browser
DEBUG - 2024-12-16 14:13:20 --> Total execution time: 0.1630
INFO - 2024-12-16 14:13:24 --> Config Class Initialized
INFO - 2024-12-16 14:13:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:13:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:13:24 --> Utf8 Class Initialized
INFO - 2024-12-16 14:13:24 --> URI Class Initialized
INFO - 2024-12-16 14:13:24 --> Router Class Initialized
INFO - 2024-12-16 14:13:24 --> Output Class Initialized
INFO - 2024-12-16 14:13:24 --> Security Class Initialized
DEBUG - 2024-12-16 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:13:24 --> Input Class Initialized
INFO - 2024-12-16 14:13:24 --> Language Class Initialized
INFO - 2024-12-16 14:13:24 --> Language Class Initialized
INFO - 2024-12-16 14:13:24 --> Config Class Initialized
INFO - 2024-12-16 14:13:24 --> Loader Class Initialized
INFO - 2024-12-16 14:13:24 --> Helper loaded: url_helper
INFO - 2024-12-16 14:13:24 --> Helper loaded: file_helper
INFO - 2024-12-16 14:13:24 --> Helper loaded: form_helper
INFO - 2024-12-16 14:13:24 --> Helper loaded: my_helper
INFO - 2024-12-16 14:13:24 --> Database Driver Class Initialized
INFO - 2024-12-16 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:13:24 --> Controller Class Initialized
DEBUG - 2024-12-16 14:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:13:31 --> Final output sent to browser
DEBUG - 2024-12-16 14:13:31 --> Total execution time: 6.5607
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:15:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:15:45 --> Utf8 Class Initialized
INFO - 2024-12-16 14:15:45 --> URI Class Initialized
INFO - 2024-12-16 14:15:45 --> Router Class Initialized
INFO - 2024-12-16 14:15:45 --> Output Class Initialized
INFO - 2024-12-16 14:15:45 --> Security Class Initialized
DEBUG - 2024-12-16 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:15:45 --> Input Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Loader Class Initialized
INFO - 2024-12-16 14:15:45 --> Helper loaded: url_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: file_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: form_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: my_helper
INFO - 2024-12-16 14:15:45 --> Database Driver Class Initialized
INFO - 2024-12-16 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:15:45 --> Controller Class Initialized
INFO - 2024-12-16 14:15:45 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:15:45 --> Final output sent to browser
DEBUG - 2024-12-16 14:15:45 --> Total execution time: 0.0661
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:15:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:15:45 --> Utf8 Class Initialized
INFO - 2024-12-16 14:15:45 --> URI Class Initialized
INFO - 2024-12-16 14:15:45 --> Router Class Initialized
INFO - 2024-12-16 14:15:45 --> Output Class Initialized
INFO - 2024-12-16 14:15:45 --> Security Class Initialized
DEBUG - 2024-12-16 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:15:45 --> Input Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Loader Class Initialized
INFO - 2024-12-16 14:15:45 --> Helper loaded: url_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: file_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: form_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: my_helper
INFO - 2024-12-16 14:15:45 --> Database Driver Class Initialized
INFO - 2024-12-16 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:15:45 --> Controller Class Initialized
INFO - 2024-12-16 14:15:45 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:15:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:15:45 --> Utf8 Class Initialized
INFO - 2024-12-16 14:15:45 --> URI Class Initialized
INFO - 2024-12-16 14:15:45 --> Router Class Initialized
INFO - 2024-12-16 14:15:45 --> Output Class Initialized
INFO - 2024-12-16 14:15:45 --> Security Class Initialized
DEBUG - 2024-12-16 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:15:45 --> Input Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Language Class Initialized
INFO - 2024-12-16 14:15:45 --> Config Class Initialized
INFO - 2024-12-16 14:15:45 --> Loader Class Initialized
INFO - 2024-12-16 14:15:45 --> Helper loaded: url_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: file_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: form_helper
INFO - 2024-12-16 14:15:45 --> Helper loaded: my_helper
INFO - 2024-12-16 14:15:45 --> Database Driver Class Initialized
INFO - 2024-12-16 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:15:45 --> Controller Class Initialized
DEBUG - 2024-12-16 14:15:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:15:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:15:45 --> Final output sent to browser
DEBUG - 2024-12-16 14:15:45 --> Total execution time: 0.0296
INFO - 2024-12-16 14:15:48 --> Config Class Initialized
INFO - 2024-12-16 14:15:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:15:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:15:48 --> Utf8 Class Initialized
INFO - 2024-12-16 14:15:48 --> URI Class Initialized
INFO - 2024-12-16 14:15:48 --> Router Class Initialized
INFO - 2024-12-16 14:15:48 --> Output Class Initialized
INFO - 2024-12-16 14:15:48 --> Security Class Initialized
DEBUG - 2024-12-16 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:15:48 --> Input Class Initialized
INFO - 2024-12-16 14:15:48 --> Language Class Initialized
INFO - 2024-12-16 14:15:48 --> Language Class Initialized
INFO - 2024-12-16 14:15:48 --> Config Class Initialized
INFO - 2024-12-16 14:15:48 --> Loader Class Initialized
INFO - 2024-12-16 14:15:48 --> Helper loaded: url_helper
INFO - 2024-12-16 14:15:48 --> Helper loaded: file_helper
INFO - 2024-12-16 14:15:48 --> Helper loaded: form_helper
INFO - 2024-12-16 14:15:48 --> Helper loaded: my_helper
INFO - 2024-12-16 14:15:48 --> Database Driver Class Initialized
INFO - 2024-12-16 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:15:48 --> Controller Class Initialized
ERROR - 2024-12-16 14:15:48 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 14:15:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 14:15:54 --> Final output sent to browser
DEBUG - 2024-12-16 14:15:54 --> Total execution time: 6.2932
INFO - 2024-12-16 14:16:58 --> Config Class Initialized
INFO - 2024-12-16 14:16:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:16:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:16:58 --> Utf8 Class Initialized
INFO - 2024-12-16 14:16:58 --> URI Class Initialized
INFO - 2024-12-16 14:16:58 --> Router Class Initialized
INFO - 2024-12-16 14:16:58 --> Output Class Initialized
INFO - 2024-12-16 14:16:58 --> Security Class Initialized
DEBUG - 2024-12-16 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:16:58 --> Input Class Initialized
INFO - 2024-12-16 14:16:58 --> Language Class Initialized
INFO - 2024-12-16 14:16:58 --> Language Class Initialized
INFO - 2024-12-16 14:16:58 --> Config Class Initialized
INFO - 2024-12-16 14:16:58 --> Loader Class Initialized
INFO - 2024-12-16 14:16:58 --> Helper loaded: url_helper
INFO - 2024-12-16 14:16:58 --> Helper loaded: file_helper
INFO - 2024-12-16 14:16:58 --> Helper loaded: form_helper
INFO - 2024-12-16 14:16:58 --> Helper loaded: my_helper
INFO - 2024-12-16 14:16:58 --> Database Driver Class Initialized
INFO - 2024-12-16 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:16:58 --> Controller Class Initialized
INFO - 2024-12-16 14:16:58 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:16:58 --> Final output sent to browser
DEBUG - 2024-12-16 14:16:58 --> Total execution time: 0.0291
INFO - 2024-12-16 14:16:59 --> Config Class Initialized
INFO - 2024-12-16 14:16:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:16:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:16:59 --> Utf8 Class Initialized
INFO - 2024-12-16 14:16:59 --> URI Class Initialized
INFO - 2024-12-16 14:16:59 --> Router Class Initialized
INFO - 2024-12-16 14:16:59 --> Output Class Initialized
INFO - 2024-12-16 14:16:59 --> Security Class Initialized
DEBUG - 2024-12-16 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:16:59 --> Input Class Initialized
INFO - 2024-12-16 14:16:59 --> Language Class Initialized
INFO - 2024-12-16 14:16:59 --> Language Class Initialized
INFO - 2024-12-16 14:16:59 --> Config Class Initialized
INFO - 2024-12-16 14:16:59 --> Loader Class Initialized
INFO - 2024-12-16 14:16:59 --> Helper loaded: url_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: file_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: form_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: my_helper
INFO - 2024-12-16 14:16:59 --> Database Driver Class Initialized
INFO - 2024-12-16 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:16:59 --> Controller Class Initialized
INFO - 2024-12-16 14:16:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:16:59 --> Config Class Initialized
INFO - 2024-12-16 14:16:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:16:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:16:59 --> Utf8 Class Initialized
INFO - 2024-12-16 14:16:59 --> URI Class Initialized
INFO - 2024-12-16 14:16:59 --> Router Class Initialized
INFO - 2024-12-16 14:16:59 --> Output Class Initialized
INFO - 2024-12-16 14:16:59 --> Security Class Initialized
DEBUG - 2024-12-16 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:16:59 --> Input Class Initialized
INFO - 2024-12-16 14:16:59 --> Language Class Initialized
INFO - 2024-12-16 14:16:59 --> Language Class Initialized
INFO - 2024-12-16 14:16:59 --> Config Class Initialized
INFO - 2024-12-16 14:16:59 --> Loader Class Initialized
INFO - 2024-12-16 14:16:59 --> Helper loaded: url_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: file_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: form_helper
INFO - 2024-12-16 14:16:59 --> Helper loaded: my_helper
INFO - 2024-12-16 14:16:59 --> Database Driver Class Initialized
INFO - 2024-12-16 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:16:59 --> Controller Class Initialized
DEBUG - 2024-12-16 14:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:16:59 --> Final output sent to browser
DEBUG - 2024-12-16 14:16:59 --> Total execution time: 0.0312
INFO - 2024-12-16 14:17:00 --> Config Class Initialized
INFO - 2024-12-16 14:17:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:17:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:17:00 --> Utf8 Class Initialized
INFO - 2024-12-16 14:17:00 --> URI Class Initialized
INFO - 2024-12-16 14:17:00 --> Router Class Initialized
INFO - 2024-12-16 14:17:00 --> Output Class Initialized
INFO - 2024-12-16 14:17:00 --> Security Class Initialized
DEBUG - 2024-12-16 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:17:00 --> Input Class Initialized
INFO - 2024-12-16 14:17:00 --> Language Class Initialized
INFO - 2024-12-16 14:17:00 --> Language Class Initialized
INFO - 2024-12-16 14:17:00 --> Config Class Initialized
INFO - 2024-12-16 14:17:00 --> Loader Class Initialized
INFO - 2024-12-16 14:17:00 --> Helper loaded: url_helper
INFO - 2024-12-16 14:17:00 --> Helper loaded: file_helper
INFO - 2024-12-16 14:17:00 --> Helper loaded: form_helper
INFO - 2024-12-16 14:17:00 --> Helper loaded: my_helper
INFO - 2024-12-16 14:17:00 --> Database Driver Class Initialized
INFO - 2024-12-16 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:17:00 --> Controller Class Initialized
DEBUG - 2024-12-16 14:17:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 14:17:04 --> Final output sent to browser
DEBUG - 2024-12-16 14:17:04 --> Total execution time: 4.2667
INFO - 2024-12-16 14:39:55 --> Config Class Initialized
INFO - 2024-12-16 14:39:55 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:39:55 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:39:55 --> Utf8 Class Initialized
INFO - 2024-12-16 14:39:55 --> URI Class Initialized
INFO - 2024-12-16 14:39:55 --> Router Class Initialized
INFO - 2024-12-16 14:39:55 --> Output Class Initialized
INFO - 2024-12-16 14:39:55 --> Security Class Initialized
DEBUG - 2024-12-16 14:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:39:55 --> Input Class Initialized
INFO - 2024-12-16 14:39:55 --> Language Class Initialized
INFO - 2024-12-16 14:39:55 --> Language Class Initialized
INFO - 2024-12-16 14:39:55 --> Config Class Initialized
INFO - 2024-12-16 14:39:55 --> Loader Class Initialized
INFO - 2024-12-16 14:39:55 --> Helper loaded: url_helper
INFO - 2024-12-16 14:39:55 --> Helper loaded: file_helper
INFO - 2024-12-16 14:39:55 --> Helper loaded: form_helper
INFO - 2024-12-16 14:39:55 --> Helper loaded: my_helper
INFO - 2024-12-16 14:39:55 --> Database Driver Class Initialized
INFO - 2024-12-16 14:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:39:55 --> Controller Class Initialized
INFO - 2024-12-16 14:39:55 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:39:55 --> Final output sent to browser
DEBUG - 2024-12-16 14:39:55 --> Total execution time: 0.0578
INFO - 2024-12-16 14:39:55 --> Config Class Initialized
INFO - 2024-12-16 14:39:55 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:39:55 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:39:55 --> Utf8 Class Initialized
INFO - 2024-12-16 14:39:55 --> URI Class Initialized
INFO - 2024-12-16 14:39:56 --> Router Class Initialized
INFO - 2024-12-16 14:39:56 --> Output Class Initialized
INFO - 2024-12-16 14:39:56 --> Security Class Initialized
DEBUG - 2024-12-16 14:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:39:56 --> Input Class Initialized
INFO - 2024-12-16 14:39:56 --> Language Class Initialized
INFO - 2024-12-16 14:39:56 --> Language Class Initialized
INFO - 2024-12-16 14:39:56 --> Config Class Initialized
INFO - 2024-12-16 14:39:56 --> Loader Class Initialized
INFO - 2024-12-16 14:39:56 --> Helper loaded: url_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: file_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: form_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: my_helper
INFO - 2024-12-16 14:39:56 --> Database Driver Class Initialized
INFO - 2024-12-16 14:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:39:56 --> Controller Class Initialized
INFO - 2024-12-16 14:39:56 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:39:56 --> Config Class Initialized
INFO - 2024-12-16 14:39:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:39:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:39:56 --> Utf8 Class Initialized
INFO - 2024-12-16 14:39:56 --> URI Class Initialized
INFO - 2024-12-16 14:39:56 --> Router Class Initialized
INFO - 2024-12-16 14:39:56 --> Output Class Initialized
INFO - 2024-12-16 14:39:56 --> Security Class Initialized
DEBUG - 2024-12-16 14:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:39:56 --> Input Class Initialized
INFO - 2024-12-16 14:39:56 --> Language Class Initialized
INFO - 2024-12-16 14:39:56 --> Language Class Initialized
INFO - 2024-12-16 14:39:56 --> Config Class Initialized
INFO - 2024-12-16 14:39:56 --> Loader Class Initialized
INFO - 2024-12-16 14:39:56 --> Helper loaded: url_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: file_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: form_helper
INFO - 2024-12-16 14:39:56 --> Helper loaded: my_helper
INFO - 2024-12-16 14:39:56 --> Database Driver Class Initialized
INFO - 2024-12-16 14:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:39:56 --> Controller Class Initialized
DEBUG - 2024-12-16 14:39:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 14:39:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:39:56 --> Final output sent to browser
DEBUG - 2024-12-16 14:39:56 --> Total execution time: 0.0349
INFO - 2024-12-16 14:40:02 --> Config Class Initialized
INFO - 2024-12-16 14:40:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:40:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:40:02 --> Utf8 Class Initialized
INFO - 2024-12-16 14:40:02 --> URI Class Initialized
INFO - 2024-12-16 14:40:02 --> Router Class Initialized
INFO - 2024-12-16 14:40:02 --> Output Class Initialized
INFO - 2024-12-16 14:40:02 --> Security Class Initialized
DEBUG - 2024-12-16 14:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:40:02 --> Input Class Initialized
INFO - 2024-12-16 14:40:02 --> Language Class Initialized
INFO - 2024-12-16 14:40:02 --> Language Class Initialized
INFO - 2024-12-16 14:40:02 --> Config Class Initialized
INFO - 2024-12-16 14:40:02 --> Loader Class Initialized
INFO - 2024-12-16 14:40:02 --> Helper loaded: url_helper
INFO - 2024-12-16 14:40:02 --> Helper loaded: file_helper
INFO - 2024-12-16 14:40:02 --> Helper loaded: form_helper
INFO - 2024-12-16 14:40:02 --> Helper loaded: my_helper
INFO - 2024-12-16 14:40:02 --> Database Driver Class Initialized
INFO - 2024-12-16 14:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:40:02 --> Controller Class Initialized
DEBUG - 2024-12-16 14:40:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:40:11 --> Final output sent to browser
DEBUG - 2024-12-16 14:40:11 --> Total execution time: 8.7293
INFO - 2024-12-16 14:41:16 --> Config Class Initialized
INFO - 2024-12-16 14:41:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:41:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:41:16 --> Utf8 Class Initialized
INFO - 2024-12-16 14:41:16 --> URI Class Initialized
INFO - 2024-12-16 14:41:16 --> Router Class Initialized
INFO - 2024-12-16 14:41:16 --> Output Class Initialized
INFO - 2024-12-16 14:41:16 --> Security Class Initialized
DEBUG - 2024-12-16 14:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:41:16 --> Input Class Initialized
INFO - 2024-12-16 14:41:16 --> Language Class Initialized
INFO - 2024-12-16 14:41:16 --> Language Class Initialized
INFO - 2024-12-16 14:41:16 --> Config Class Initialized
INFO - 2024-12-16 14:41:16 --> Loader Class Initialized
INFO - 2024-12-16 14:41:16 --> Helper loaded: url_helper
INFO - 2024-12-16 14:41:16 --> Helper loaded: file_helper
INFO - 2024-12-16 14:41:16 --> Helper loaded: form_helper
INFO - 2024-12-16 14:41:16 --> Helper loaded: my_helper
INFO - 2024-12-16 14:41:16 --> Database Driver Class Initialized
INFO - 2024-12-16 14:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:41:16 --> Controller Class Initialized
DEBUG - 2024-12-16 14:41:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 14:41:18 --> Final output sent to browser
DEBUG - 2024-12-16 14:41:18 --> Total execution time: 1.6599
INFO - 2024-12-16 14:51:12 --> Config Class Initialized
INFO - 2024-12-16 14:51:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:51:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:51:12 --> Utf8 Class Initialized
INFO - 2024-12-16 14:51:12 --> URI Class Initialized
INFO - 2024-12-16 14:51:12 --> Router Class Initialized
INFO - 2024-12-16 14:51:12 --> Output Class Initialized
INFO - 2024-12-16 14:51:12 --> Security Class Initialized
DEBUG - 2024-12-16 14:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:51:12 --> Input Class Initialized
INFO - 2024-12-16 14:51:12 --> Language Class Initialized
INFO - 2024-12-16 14:51:12 --> Language Class Initialized
INFO - 2024-12-16 14:51:12 --> Config Class Initialized
INFO - 2024-12-16 14:51:12 --> Loader Class Initialized
INFO - 2024-12-16 14:51:12 --> Helper loaded: url_helper
INFO - 2024-12-16 14:51:12 --> Helper loaded: file_helper
INFO - 2024-12-16 14:51:12 --> Helper loaded: form_helper
INFO - 2024-12-16 14:51:12 --> Helper loaded: my_helper
INFO - 2024-12-16 14:51:12 --> Database Driver Class Initialized
INFO - 2024-12-16 14:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:51:12 --> Controller Class Initialized
DEBUG - 2024-12-16 14:51:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 14:51:16 --> Final output sent to browser
DEBUG - 2024-12-16 14:51:16 --> Total execution time: 3.8826
INFO - 2024-12-16 14:51:59 --> Config Class Initialized
INFO - 2024-12-16 14:51:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:51:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:51:59 --> Utf8 Class Initialized
INFO - 2024-12-16 14:51:59 --> URI Class Initialized
INFO - 2024-12-16 14:51:59 --> Router Class Initialized
INFO - 2024-12-16 14:51:59 --> Output Class Initialized
INFO - 2024-12-16 14:51:59 --> Security Class Initialized
DEBUG - 2024-12-16 14:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:51:59 --> Input Class Initialized
INFO - 2024-12-16 14:51:59 --> Language Class Initialized
INFO - 2024-12-16 14:51:59 --> Language Class Initialized
INFO - 2024-12-16 14:51:59 --> Config Class Initialized
INFO - 2024-12-16 14:51:59 --> Loader Class Initialized
INFO - 2024-12-16 14:51:59 --> Helper loaded: url_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: file_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: form_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: my_helper
INFO - 2024-12-16 14:51:59 --> Database Driver Class Initialized
INFO - 2024-12-16 14:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:51:59 --> Controller Class Initialized
INFO - 2024-12-16 14:51:59 --> Config Class Initialized
INFO - 2024-12-16 14:51:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:51:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:51:59 --> Utf8 Class Initialized
INFO - 2024-12-16 14:51:59 --> URI Class Initialized
INFO - 2024-12-16 14:51:59 --> Router Class Initialized
INFO - 2024-12-16 14:51:59 --> Output Class Initialized
INFO - 2024-12-16 14:51:59 --> Security Class Initialized
DEBUG - 2024-12-16 14:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:51:59 --> Input Class Initialized
INFO - 2024-12-16 14:51:59 --> Language Class Initialized
INFO - 2024-12-16 14:51:59 --> Language Class Initialized
INFO - 2024-12-16 14:51:59 --> Config Class Initialized
INFO - 2024-12-16 14:51:59 --> Loader Class Initialized
INFO - 2024-12-16 14:51:59 --> Helper loaded: url_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: file_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: form_helper
INFO - 2024-12-16 14:51:59 --> Helper loaded: my_helper
INFO - 2024-12-16 14:51:59 --> Database Driver Class Initialized
INFO - 2024-12-16 14:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:51:59 --> Controller Class Initialized
DEBUG - 2024-12-16 14:51:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 14:51:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:51:59 --> Final output sent to browser
DEBUG - 2024-12-16 14:51:59 --> Total execution time: 0.0316
INFO - 2024-12-16 14:52:01 --> Config Class Initialized
INFO - 2024-12-16 14:52:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:52:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:52:01 --> Utf8 Class Initialized
INFO - 2024-12-16 14:52:01 --> URI Class Initialized
INFO - 2024-12-16 14:52:01 --> Router Class Initialized
INFO - 2024-12-16 14:52:01 --> Output Class Initialized
INFO - 2024-12-16 14:52:01 --> Security Class Initialized
DEBUG - 2024-12-16 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:52:01 --> Input Class Initialized
INFO - 2024-12-16 14:52:01 --> Language Class Initialized
INFO - 2024-12-16 14:52:01 --> Language Class Initialized
INFO - 2024-12-16 14:52:01 --> Config Class Initialized
INFO - 2024-12-16 14:52:01 --> Loader Class Initialized
INFO - 2024-12-16 14:52:01 --> Helper loaded: url_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: file_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: form_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: my_helper
INFO - 2024-12-16 14:52:01 --> Database Driver Class Initialized
INFO - 2024-12-16 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:52:01 --> Controller Class Initialized
INFO - 2024-12-16 14:52:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 14:52:01 --> Final output sent to browser
DEBUG - 2024-12-16 14:52:01 --> Total execution time: 0.1720
INFO - 2024-12-16 14:52:01 --> Config Class Initialized
INFO - 2024-12-16 14:52:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:52:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:52:01 --> Utf8 Class Initialized
INFO - 2024-12-16 14:52:01 --> URI Class Initialized
INFO - 2024-12-16 14:52:01 --> Router Class Initialized
INFO - 2024-12-16 14:52:01 --> Output Class Initialized
INFO - 2024-12-16 14:52:01 --> Security Class Initialized
DEBUG - 2024-12-16 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:52:01 --> Input Class Initialized
INFO - 2024-12-16 14:52:01 --> Language Class Initialized
INFO - 2024-12-16 14:52:01 --> Language Class Initialized
INFO - 2024-12-16 14:52:01 --> Config Class Initialized
INFO - 2024-12-16 14:52:01 --> Loader Class Initialized
INFO - 2024-12-16 14:52:01 --> Helper loaded: url_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: file_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: form_helper
INFO - 2024-12-16 14:52:01 --> Helper loaded: my_helper
INFO - 2024-12-16 14:52:01 --> Database Driver Class Initialized
INFO - 2024-12-16 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:52:01 --> Controller Class Initialized
DEBUG - 2024-12-16 14:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 14:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:52:01 --> Final output sent to browser
DEBUG - 2024-12-16 14:52:01 --> Total execution time: 0.0476
INFO - 2024-12-16 14:52:08 --> Config Class Initialized
INFO - 2024-12-16 14:52:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:52:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:52:08 --> Utf8 Class Initialized
INFO - 2024-12-16 14:52:08 --> URI Class Initialized
INFO - 2024-12-16 14:52:08 --> Router Class Initialized
INFO - 2024-12-16 14:52:08 --> Output Class Initialized
INFO - 2024-12-16 14:52:08 --> Security Class Initialized
DEBUG - 2024-12-16 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:52:08 --> Input Class Initialized
INFO - 2024-12-16 14:52:08 --> Language Class Initialized
INFO - 2024-12-16 14:52:08 --> Language Class Initialized
INFO - 2024-12-16 14:52:08 --> Config Class Initialized
INFO - 2024-12-16 14:52:08 --> Loader Class Initialized
INFO - 2024-12-16 14:52:08 --> Helper loaded: url_helper
INFO - 2024-12-16 14:52:08 --> Helper loaded: file_helper
INFO - 2024-12-16 14:52:08 --> Helper loaded: form_helper
INFO - 2024-12-16 14:52:08 --> Helper loaded: my_helper
INFO - 2024-12-16 14:52:08 --> Database Driver Class Initialized
INFO - 2024-12-16 14:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:52:08 --> Controller Class Initialized
DEBUG - 2024-12-16 14:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 14:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 14:52:08 --> Final output sent to browser
DEBUG - 2024-12-16 14:52:08 --> Total execution time: 0.0354
INFO - 2024-12-16 14:52:12 --> Config Class Initialized
INFO - 2024-12-16 14:52:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:52:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:52:12 --> Utf8 Class Initialized
INFO - 2024-12-16 14:52:12 --> URI Class Initialized
INFO - 2024-12-16 14:52:12 --> Router Class Initialized
INFO - 2024-12-16 14:52:12 --> Output Class Initialized
INFO - 2024-12-16 14:52:12 --> Security Class Initialized
DEBUG - 2024-12-16 14:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:52:12 --> Input Class Initialized
INFO - 2024-12-16 14:52:12 --> Language Class Initialized
INFO - 2024-12-16 14:52:12 --> Language Class Initialized
INFO - 2024-12-16 14:52:12 --> Config Class Initialized
INFO - 2024-12-16 14:52:12 --> Loader Class Initialized
INFO - 2024-12-16 14:52:12 --> Helper loaded: url_helper
INFO - 2024-12-16 14:52:12 --> Helper loaded: file_helper
INFO - 2024-12-16 14:52:12 --> Helper loaded: form_helper
INFO - 2024-12-16 14:52:12 --> Helper loaded: my_helper
INFO - 2024-12-16 14:52:12 --> Database Driver Class Initialized
INFO - 2024-12-16 14:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:52:12 --> Controller Class Initialized
DEBUG - 2024-12-16 14:52:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:52:21 --> Final output sent to browser
DEBUG - 2024-12-16 14:52:21 --> Total execution time: 8.8098
INFO - 2024-12-16 14:53:44 --> Config Class Initialized
INFO - 2024-12-16 14:53:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:53:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:53:44 --> Utf8 Class Initialized
INFO - 2024-12-16 14:53:44 --> URI Class Initialized
INFO - 2024-12-16 14:53:44 --> Router Class Initialized
INFO - 2024-12-16 14:53:44 --> Output Class Initialized
INFO - 2024-12-16 14:53:44 --> Security Class Initialized
DEBUG - 2024-12-16 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:53:44 --> Input Class Initialized
INFO - 2024-12-16 14:53:44 --> Language Class Initialized
INFO - 2024-12-16 14:53:44 --> Language Class Initialized
INFO - 2024-12-16 14:53:44 --> Config Class Initialized
INFO - 2024-12-16 14:53:44 --> Loader Class Initialized
INFO - 2024-12-16 14:53:44 --> Helper loaded: url_helper
INFO - 2024-12-16 14:53:44 --> Helper loaded: file_helper
INFO - 2024-12-16 14:53:44 --> Helper loaded: form_helper
INFO - 2024-12-16 14:53:44 --> Helper loaded: my_helper
INFO - 2024-12-16 14:53:44 --> Database Driver Class Initialized
INFO - 2024-12-16 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:53:44 --> Controller Class Initialized
DEBUG - 2024-12-16 14:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 14:53:46 --> Final output sent to browser
DEBUG - 2024-12-16 14:53:46 --> Total execution time: 1.9431
INFO - 2024-12-16 14:56:49 --> Config Class Initialized
INFO - 2024-12-16 14:56:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:56:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:56:49 --> Utf8 Class Initialized
INFO - 2024-12-16 14:56:49 --> URI Class Initialized
INFO - 2024-12-16 14:56:49 --> Router Class Initialized
INFO - 2024-12-16 14:56:49 --> Output Class Initialized
INFO - 2024-12-16 14:56:49 --> Security Class Initialized
DEBUG - 2024-12-16 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:56:49 --> Input Class Initialized
INFO - 2024-12-16 14:56:49 --> Language Class Initialized
INFO - 2024-12-16 14:56:49 --> Language Class Initialized
INFO - 2024-12-16 14:56:49 --> Config Class Initialized
INFO - 2024-12-16 14:56:49 --> Loader Class Initialized
INFO - 2024-12-16 14:56:49 --> Helper loaded: url_helper
INFO - 2024-12-16 14:56:49 --> Helper loaded: file_helper
INFO - 2024-12-16 14:56:49 --> Helper loaded: form_helper
INFO - 2024-12-16 14:56:49 --> Helper loaded: my_helper
INFO - 2024-12-16 14:56:49 --> Database Driver Class Initialized
INFO - 2024-12-16 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:56:49 --> Controller Class Initialized
DEBUG - 2024-12-16 14:56:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 14:56:57 --> Final output sent to browser
DEBUG - 2024-12-16 14:56:57 --> Total execution time: 8.3205
INFO - 2024-12-16 14:57:33 --> Config Class Initialized
INFO - 2024-12-16 14:57:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:57:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:57:33 --> Utf8 Class Initialized
INFO - 2024-12-16 14:57:33 --> URI Class Initialized
INFO - 2024-12-16 14:57:33 --> Router Class Initialized
INFO - 2024-12-16 14:57:33 --> Output Class Initialized
INFO - 2024-12-16 14:57:33 --> Security Class Initialized
DEBUG - 2024-12-16 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:57:33 --> Input Class Initialized
INFO - 2024-12-16 14:57:33 --> Language Class Initialized
INFO - 2024-12-16 14:57:33 --> Language Class Initialized
INFO - 2024-12-16 14:57:33 --> Config Class Initialized
INFO - 2024-12-16 14:57:33 --> Loader Class Initialized
INFO - 2024-12-16 14:57:33 --> Helper loaded: url_helper
INFO - 2024-12-16 14:57:33 --> Helper loaded: file_helper
INFO - 2024-12-16 14:57:33 --> Helper loaded: form_helper
INFO - 2024-12-16 14:57:33 --> Helper loaded: my_helper
INFO - 2024-12-16 14:57:33 --> Database Driver Class Initialized
INFO - 2024-12-16 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:57:33 --> Controller Class Initialized
DEBUG - 2024-12-16 14:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 14:57:37 --> Final output sent to browser
DEBUG - 2024-12-16 14:57:37 --> Total execution time: 4.1153
INFO - 2024-12-16 14:59:57 --> Config Class Initialized
INFO - 2024-12-16 14:59:57 --> Hooks Class Initialized
DEBUG - 2024-12-16 14:59:57 --> UTF-8 Support Enabled
INFO - 2024-12-16 14:59:57 --> Utf8 Class Initialized
INFO - 2024-12-16 14:59:57 --> URI Class Initialized
INFO - 2024-12-16 14:59:57 --> Router Class Initialized
INFO - 2024-12-16 14:59:57 --> Output Class Initialized
INFO - 2024-12-16 14:59:57 --> Security Class Initialized
DEBUG - 2024-12-16 14:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 14:59:57 --> Input Class Initialized
INFO - 2024-12-16 14:59:57 --> Language Class Initialized
INFO - 2024-12-16 14:59:57 --> Language Class Initialized
INFO - 2024-12-16 14:59:57 --> Config Class Initialized
INFO - 2024-12-16 14:59:57 --> Loader Class Initialized
INFO - 2024-12-16 14:59:57 --> Helper loaded: url_helper
INFO - 2024-12-16 14:59:57 --> Helper loaded: file_helper
INFO - 2024-12-16 14:59:57 --> Helper loaded: form_helper
INFO - 2024-12-16 14:59:57 --> Helper loaded: my_helper
INFO - 2024-12-16 14:59:57 --> Database Driver Class Initialized
INFO - 2024-12-16 14:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 14:59:57 --> Controller Class Initialized
DEBUG - 2024-12-16 14:59:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 15:00:01 --> Final output sent to browser
DEBUG - 2024-12-16 15:00:01 --> Total execution time: 3.8175
INFO - 2024-12-16 15:00:36 --> Config Class Initialized
INFO - 2024-12-16 15:00:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:00:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:00:36 --> Utf8 Class Initialized
INFO - 2024-12-16 15:00:36 --> URI Class Initialized
INFO - 2024-12-16 15:00:36 --> Router Class Initialized
INFO - 2024-12-16 15:00:36 --> Output Class Initialized
INFO - 2024-12-16 15:00:36 --> Security Class Initialized
DEBUG - 2024-12-16 15:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:00:36 --> Input Class Initialized
INFO - 2024-12-16 15:00:36 --> Language Class Initialized
INFO - 2024-12-16 15:00:36 --> Language Class Initialized
INFO - 2024-12-16 15:00:36 --> Config Class Initialized
INFO - 2024-12-16 15:00:36 --> Loader Class Initialized
INFO - 2024-12-16 15:00:36 --> Helper loaded: url_helper
INFO - 2024-12-16 15:00:36 --> Helper loaded: file_helper
INFO - 2024-12-16 15:00:36 --> Helper loaded: form_helper
INFO - 2024-12-16 15:00:36 --> Helper loaded: my_helper
INFO - 2024-12-16 15:00:36 --> Database Driver Class Initialized
INFO - 2024-12-16 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:00:36 --> Controller Class Initialized
DEBUG - 2024-12-16 15:00:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 15:00:41 --> Final output sent to browser
DEBUG - 2024-12-16 15:00:41 --> Total execution time: 5.0259
INFO - 2024-12-16 15:01:08 --> Config Class Initialized
INFO - 2024-12-16 15:01:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:01:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:01:08 --> Utf8 Class Initialized
INFO - 2024-12-16 15:01:08 --> URI Class Initialized
INFO - 2024-12-16 15:01:08 --> Router Class Initialized
INFO - 2024-12-16 15:01:08 --> Output Class Initialized
INFO - 2024-12-16 15:01:08 --> Security Class Initialized
DEBUG - 2024-12-16 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:01:08 --> Input Class Initialized
INFO - 2024-12-16 15:01:08 --> Language Class Initialized
INFO - 2024-12-16 15:01:08 --> Language Class Initialized
INFO - 2024-12-16 15:01:08 --> Config Class Initialized
INFO - 2024-12-16 15:01:08 --> Loader Class Initialized
INFO - 2024-12-16 15:01:08 --> Helper loaded: url_helper
INFO - 2024-12-16 15:01:08 --> Helper loaded: file_helper
INFO - 2024-12-16 15:01:08 --> Helper loaded: form_helper
INFO - 2024-12-16 15:01:08 --> Helper loaded: my_helper
INFO - 2024-12-16 15:01:08 --> Database Driver Class Initialized
INFO - 2024-12-16 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:01:08 --> Controller Class Initialized
DEBUG - 2024-12-16 15:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 15:01:12 --> Final output sent to browser
DEBUG - 2024-12-16 15:01:12 --> Total execution time: 4.2401
INFO - 2024-12-16 15:03:20 --> Config Class Initialized
INFO - 2024-12-16 15:03:20 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:03:20 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:03:20 --> Utf8 Class Initialized
INFO - 2024-12-16 15:03:20 --> URI Class Initialized
INFO - 2024-12-16 15:03:20 --> Router Class Initialized
INFO - 2024-12-16 15:03:20 --> Output Class Initialized
INFO - 2024-12-16 15:03:20 --> Security Class Initialized
DEBUG - 2024-12-16 15:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:03:20 --> Input Class Initialized
INFO - 2024-12-16 15:03:20 --> Language Class Initialized
INFO - 2024-12-16 15:03:20 --> Language Class Initialized
INFO - 2024-12-16 15:03:20 --> Config Class Initialized
INFO - 2024-12-16 15:03:20 --> Loader Class Initialized
INFO - 2024-12-16 15:03:20 --> Helper loaded: url_helper
INFO - 2024-12-16 15:03:20 --> Helper loaded: file_helper
INFO - 2024-12-16 15:03:20 --> Helper loaded: form_helper
INFO - 2024-12-16 15:03:20 --> Helper loaded: my_helper
INFO - 2024-12-16 15:03:20 --> Database Driver Class Initialized
INFO - 2024-12-16 15:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:03:20 --> Controller Class Initialized
DEBUG - 2024-12-16 15:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 15:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:03:20 --> Final output sent to browser
DEBUG - 2024-12-16 15:03:20 --> Total execution time: 0.0349
INFO - 2024-12-16 15:15:42 --> Config Class Initialized
INFO - 2024-12-16 15:15:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:15:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:15:42 --> Utf8 Class Initialized
INFO - 2024-12-16 15:15:42 --> URI Class Initialized
INFO - 2024-12-16 15:15:42 --> Router Class Initialized
INFO - 2024-12-16 15:15:42 --> Output Class Initialized
INFO - 2024-12-16 15:15:42 --> Security Class Initialized
DEBUG - 2024-12-16 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:15:42 --> Input Class Initialized
INFO - 2024-12-16 15:15:42 --> Language Class Initialized
INFO - 2024-12-16 15:15:42 --> Language Class Initialized
INFO - 2024-12-16 15:15:42 --> Config Class Initialized
INFO - 2024-12-16 15:15:42 --> Loader Class Initialized
INFO - 2024-12-16 15:15:42 --> Helper loaded: url_helper
INFO - 2024-12-16 15:15:42 --> Helper loaded: file_helper
INFO - 2024-12-16 15:15:42 --> Helper loaded: form_helper
INFO - 2024-12-16 15:15:42 --> Helper loaded: my_helper
INFO - 2024-12-16 15:15:42 --> Database Driver Class Initialized
INFO - 2024-12-16 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:15:42 --> Controller Class Initialized
INFO - 2024-12-16 15:15:42 --> Final output sent to browser
DEBUG - 2024-12-16 15:15:42 --> Total execution time: 0.0448
INFO - 2024-12-16 15:15:53 --> Config Class Initialized
INFO - 2024-12-16 15:15:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:15:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:15:53 --> Utf8 Class Initialized
INFO - 2024-12-16 15:15:53 --> URI Class Initialized
INFO - 2024-12-16 15:15:53 --> Router Class Initialized
INFO - 2024-12-16 15:15:53 --> Output Class Initialized
INFO - 2024-12-16 15:15:53 --> Security Class Initialized
DEBUG - 2024-12-16 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:15:53 --> Input Class Initialized
INFO - 2024-12-16 15:15:53 --> Language Class Initialized
INFO - 2024-12-16 15:15:53 --> Language Class Initialized
INFO - 2024-12-16 15:15:53 --> Config Class Initialized
INFO - 2024-12-16 15:15:53 --> Loader Class Initialized
INFO - 2024-12-16 15:15:53 --> Helper loaded: url_helper
INFO - 2024-12-16 15:15:53 --> Helper loaded: file_helper
INFO - 2024-12-16 15:15:53 --> Helper loaded: form_helper
INFO - 2024-12-16 15:15:53 --> Helper loaded: my_helper
INFO - 2024-12-16 15:15:53 --> Database Driver Class Initialized
INFO - 2024-12-16 15:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:15:53 --> Controller Class Initialized
INFO - 2024-12-16 15:15:53 --> Final output sent to browser
DEBUG - 2024-12-16 15:15:53 --> Total execution time: 0.0308
INFO - 2024-12-16 15:17:12 --> Config Class Initialized
INFO - 2024-12-16 15:17:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:17:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:17:12 --> Utf8 Class Initialized
INFO - 2024-12-16 15:17:12 --> URI Class Initialized
INFO - 2024-12-16 15:17:12 --> Router Class Initialized
INFO - 2024-12-16 15:17:12 --> Output Class Initialized
INFO - 2024-12-16 15:17:12 --> Security Class Initialized
DEBUG - 2024-12-16 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:17:12 --> Input Class Initialized
INFO - 2024-12-16 15:17:12 --> Language Class Initialized
INFO - 2024-12-16 15:17:12 --> Language Class Initialized
INFO - 2024-12-16 15:17:12 --> Config Class Initialized
INFO - 2024-12-16 15:17:12 --> Loader Class Initialized
INFO - 2024-12-16 15:17:12 --> Helper loaded: url_helper
INFO - 2024-12-16 15:17:12 --> Helper loaded: file_helper
INFO - 2024-12-16 15:17:12 --> Helper loaded: form_helper
INFO - 2024-12-16 15:17:12 --> Helper loaded: my_helper
INFO - 2024-12-16 15:17:12 --> Database Driver Class Initialized
INFO - 2024-12-16 15:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:17:12 --> Controller Class Initialized
INFO - 2024-12-16 15:17:12 --> Final output sent to browser
DEBUG - 2024-12-16 15:17:12 --> Total execution time: 0.0656
INFO - 2024-12-16 15:17:40 --> Config Class Initialized
INFO - 2024-12-16 15:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:17:40 --> Utf8 Class Initialized
INFO - 2024-12-16 15:17:40 --> URI Class Initialized
INFO - 2024-12-16 15:17:40 --> Router Class Initialized
INFO - 2024-12-16 15:17:40 --> Output Class Initialized
INFO - 2024-12-16 15:17:40 --> Security Class Initialized
DEBUG - 2024-12-16 15:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:17:40 --> Input Class Initialized
INFO - 2024-12-16 15:17:40 --> Language Class Initialized
INFO - 2024-12-16 15:17:40 --> Language Class Initialized
INFO - 2024-12-16 15:17:40 --> Config Class Initialized
INFO - 2024-12-16 15:17:40 --> Loader Class Initialized
INFO - 2024-12-16 15:17:40 --> Helper loaded: url_helper
INFO - 2024-12-16 15:17:40 --> Helper loaded: file_helper
INFO - 2024-12-16 15:17:40 --> Helper loaded: form_helper
INFO - 2024-12-16 15:17:40 --> Helper loaded: my_helper
INFO - 2024-12-16 15:17:40 --> Database Driver Class Initialized
INFO - 2024-12-16 15:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:17:40 --> Controller Class Initialized
INFO - 2024-12-16 15:17:40 --> Final output sent to browser
DEBUG - 2024-12-16 15:17:40 --> Total execution time: 0.0313
INFO - 2024-12-16 15:20:13 --> Config Class Initialized
INFO - 2024-12-16 15:20:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:20:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:20:13 --> Utf8 Class Initialized
INFO - 2024-12-16 15:20:13 --> URI Class Initialized
INFO - 2024-12-16 15:20:13 --> Router Class Initialized
INFO - 2024-12-16 15:20:13 --> Output Class Initialized
INFO - 2024-12-16 15:20:13 --> Security Class Initialized
DEBUG - 2024-12-16 15:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:20:13 --> Input Class Initialized
INFO - 2024-12-16 15:20:13 --> Language Class Initialized
INFO - 2024-12-16 15:20:13 --> Language Class Initialized
INFO - 2024-12-16 15:20:13 --> Config Class Initialized
INFO - 2024-12-16 15:20:13 --> Loader Class Initialized
INFO - 2024-12-16 15:20:13 --> Helper loaded: url_helper
INFO - 2024-12-16 15:20:13 --> Helper loaded: file_helper
INFO - 2024-12-16 15:20:13 --> Helper loaded: form_helper
INFO - 2024-12-16 15:20:13 --> Helper loaded: my_helper
INFO - 2024-12-16 15:20:13 --> Database Driver Class Initialized
INFO - 2024-12-16 15:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:20:13 --> Controller Class Initialized
DEBUG - 2024-12-16 15:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 15:20:16 --> Final output sent to browser
DEBUG - 2024-12-16 15:20:16 --> Total execution time: 2.5989
INFO - 2024-12-16 15:21:05 --> Config Class Initialized
INFO - 2024-12-16 15:21:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:21:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:21:05 --> Utf8 Class Initialized
INFO - 2024-12-16 15:21:05 --> URI Class Initialized
INFO - 2024-12-16 15:21:05 --> Router Class Initialized
INFO - 2024-12-16 15:21:05 --> Output Class Initialized
INFO - 2024-12-16 15:21:05 --> Security Class Initialized
DEBUG - 2024-12-16 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:21:05 --> Input Class Initialized
INFO - 2024-12-16 15:21:05 --> Language Class Initialized
INFO - 2024-12-16 15:21:05 --> Language Class Initialized
INFO - 2024-12-16 15:21:05 --> Config Class Initialized
INFO - 2024-12-16 15:21:05 --> Loader Class Initialized
INFO - 2024-12-16 15:21:05 --> Helper loaded: url_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: file_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: form_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: my_helper
INFO - 2024-12-16 15:21:05 --> Database Driver Class Initialized
INFO - 2024-12-16 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:21:05 --> Controller Class Initialized
INFO - 2024-12-16 15:21:05 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:21:05 --> Final output sent to browser
DEBUG - 2024-12-16 15:21:05 --> Total execution time: 0.3056
INFO - 2024-12-16 15:21:05 --> Config Class Initialized
INFO - 2024-12-16 15:21:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:21:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:21:05 --> Utf8 Class Initialized
INFO - 2024-12-16 15:21:05 --> URI Class Initialized
INFO - 2024-12-16 15:21:05 --> Router Class Initialized
INFO - 2024-12-16 15:21:05 --> Output Class Initialized
INFO - 2024-12-16 15:21:05 --> Security Class Initialized
DEBUG - 2024-12-16 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:21:05 --> Input Class Initialized
INFO - 2024-12-16 15:21:05 --> Language Class Initialized
INFO - 2024-12-16 15:21:05 --> Language Class Initialized
INFO - 2024-12-16 15:21:05 --> Config Class Initialized
INFO - 2024-12-16 15:21:05 --> Loader Class Initialized
INFO - 2024-12-16 15:21:05 --> Helper loaded: url_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: file_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: form_helper
INFO - 2024-12-16 15:21:05 --> Helper loaded: my_helper
INFO - 2024-12-16 15:21:05 --> Database Driver Class Initialized
INFO - 2024-12-16 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:21:05 --> Controller Class Initialized
INFO - 2024-12-16 15:21:05 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:21:06 --> Config Class Initialized
INFO - 2024-12-16 15:21:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:21:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:21:06 --> Utf8 Class Initialized
INFO - 2024-12-16 15:21:06 --> URI Class Initialized
INFO - 2024-12-16 15:21:06 --> Router Class Initialized
INFO - 2024-12-16 15:21:06 --> Output Class Initialized
INFO - 2024-12-16 15:21:06 --> Security Class Initialized
DEBUG - 2024-12-16 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:21:06 --> Input Class Initialized
INFO - 2024-12-16 15:21:06 --> Language Class Initialized
INFO - 2024-12-16 15:21:06 --> Language Class Initialized
INFO - 2024-12-16 15:21:06 --> Config Class Initialized
INFO - 2024-12-16 15:21:06 --> Loader Class Initialized
INFO - 2024-12-16 15:21:06 --> Helper loaded: url_helper
INFO - 2024-12-16 15:21:06 --> Helper loaded: file_helper
INFO - 2024-12-16 15:21:06 --> Helper loaded: form_helper
INFO - 2024-12-16 15:21:06 --> Helper loaded: my_helper
INFO - 2024-12-16 15:21:06 --> Database Driver Class Initialized
INFO - 2024-12-16 15:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:21:06 --> Controller Class Initialized
DEBUG - 2024-12-16 15:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 15:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:21:06 --> Final output sent to browser
DEBUG - 2024-12-16 15:21:06 --> Total execution time: 0.1107
INFO - 2024-12-16 15:21:08 --> Config Class Initialized
INFO - 2024-12-16 15:21:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:21:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:21:08 --> Utf8 Class Initialized
INFO - 2024-12-16 15:21:08 --> URI Class Initialized
INFO - 2024-12-16 15:21:08 --> Router Class Initialized
INFO - 2024-12-16 15:21:08 --> Output Class Initialized
INFO - 2024-12-16 15:21:08 --> Security Class Initialized
DEBUG - 2024-12-16 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:21:08 --> Input Class Initialized
INFO - 2024-12-16 15:21:08 --> Language Class Initialized
INFO - 2024-12-16 15:21:08 --> Language Class Initialized
INFO - 2024-12-16 15:21:08 --> Config Class Initialized
INFO - 2024-12-16 15:21:08 --> Loader Class Initialized
INFO - 2024-12-16 15:21:08 --> Helper loaded: url_helper
INFO - 2024-12-16 15:21:08 --> Helper loaded: file_helper
INFO - 2024-12-16 15:21:08 --> Helper loaded: form_helper
INFO - 2024-12-16 15:21:08 --> Helper loaded: my_helper
INFO - 2024-12-16 15:21:08 --> Database Driver Class Initialized
INFO - 2024-12-16 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:21:08 --> Controller Class Initialized
DEBUG - 2024-12-16 15:21:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 15:21:13 --> Final output sent to browser
DEBUG - 2024-12-16 15:21:13 --> Total execution time: 4.8632
INFO - 2024-12-16 15:22:03 --> Config Class Initialized
INFO - 2024-12-16 15:22:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:22:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:22:03 --> Utf8 Class Initialized
INFO - 2024-12-16 15:22:03 --> URI Class Initialized
INFO - 2024-12-16 15:22:03 --> Router Class Initialized
INFO - 2024-12-16 15:22:03 --> Output Class Initialized
INFO - 2024-12-16 15:22:03 --> Security Class Initialized
DEBUG - 2024-12-16 15:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:22:03 --> Input Class Initialized
INFO - 2024-12-16 15:22:03 --> Language Class Initialized
INFO - 2024-12-16 15:22:03 --> Language Class Initialized
INFO - 2024-12-16 15:22:03 --> Config Class Initialized
INFO - 2024-12-16 15:22:03 --> Loader Class Initialized
INFO - 2024-12-16 15:22:03 --> Helper loaded: url_helper
INFO - 2024-12-16 15:22:03 --> Helper loaded: file_helper
INFO - 2024-12-16 15:22:03 --> Helper loaded: form_helper
INFO - 2024-12-16 15:22:03 --> Helper loaded: my_helper
INFO - 2024-12-16 15:22:03 --> Database Driver Class Initialized
INFO - 2024-12-16 15:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:22:03 --> Controller Class Initialized
DEBUG - 2024-12-16 15:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 15:22:05 --> Final output sent to browser
DEBUG - 2024-12-16 15:22:05 --> Total execution time: 1.8755
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:37:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:37:32 --> Utf8 Class Initialized
INFO - 2024-12-16 15:37:32 --> URI Class Initialized
INFO - 2024-12-16 15:37:32 --> Router Class Initialized
INFO - 2024-12-16 15:37:32 --> Output Class Initialized
INFO - 2024-12-16 15:37:32 --> Security Class Initialized
DEBUG - 2024-12-16 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:37:32 --> Input Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Loader Class Initialized
INFO - 2024-12-16 15:37:32 --> Helper loaded: url_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: file_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: form_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: my_helper
INFO - 2024-12-16 15:37:32 --> Database Driver Class Initialized
INFO - 2024-12-16 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:37:32 --> Controller Class Initialized
INFO - 2024-12-16 15:37:32 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:37:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:37:32 --> Utf8 Class Initialized
INFO - 2024-12-16 15:37:32 --> URI Class Initialized
INFO - 2024-12-16 15:37:32 --> Router Class Initialized
INFO - 2024-12-16 15:37:32 --> Output Class Initialized
INFO - 2024-12-16 15:37:32 --> Security Class Initialized
DEBUG - 2024-12-16 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:37:32 --> Input Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Loader Class Initialized
INFO - 2024-12-16 15:37:32 --> Helper loaded: url_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: file_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: form_helper
INFO - 2024-12-16 15:37:32 --> Helper loaded: my_helper
INFO - 2024-12-16 15:37:32 --> Database Driver Class Initialized
INFO - 2024-12-16 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:37:32 --> Controller Class Initialized
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:37:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:37:32 --> Utf8 Class Initialized
INFO - 2024-12-16 15:37:32 --> URI Class Initialized
INFO - 2024-12-16 15:37:32 --> Router Class Initialized
INFO - 2024-12-16 15:37:32 --> Output Class Initialized
INFO - 2024-12-16 15:37:32 --> Security Class Initialized
DEBUG - 2024-12-16 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:37:32 --> Input Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Language Class Initialized
INFO - 2024-12-16 15:37:32 --> Config Class Initialized
INFO - 2024-12-16 15:37:32 --> Loader Class Initialized
INFO - 2024-12-16 15:37:33 --> Helper loaded: url_helper
INFO - 2024-12-16 15:37:33 --> Helper loaded: file_helper
INFO - 2024-12-16 15:37:33 --> Helper loaded: form_helper
INFO - 2024-12-16 15:37:33 --> Helper loaded: my_helper
INFO - 2024-12-16 15:37:33 --> Database Driver Class Initialized
INFO - 2024-12-16 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:37:33 --> Controller Class Initialized
DEBUG - 2024-12-16 15:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 15:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:37:33 --> Final output sent to browser
DEBUG - 2024-12-16 15:37:33 --> Total execution time: 0.0329
INFO - 2024-12-16 15:37:56 --> Config Class Initialized
INFO - 2024-12-16 15:37:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:37:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:37:56 --> Utf8 Class Initialized
INFO - 2024-12-16 15:37:56 --> URI Class Initialized
INFO - 2024-12-16 15:37:56 --> Router Class Initialized
INFO - 2024-12-16 15:37:56 --> Output Class Initialized
INFO - 2024-12-16 15:37:56 --> Security Class Initialized
DEBUG - 2024-12-16 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:37:56 --> Input Class Initialized
INFO - 2024-12-16 15:37:56 --> Language Class Initialized
INFO - 2024-12-16 15:37:56 --> Language Class Initialized
INFO - 2024-12-16 15:37:56 --> Config Class Initialized
INFO - 2024-12-16 15:37:56 --> Loader Class Initialized
INFO - 2024-12-16 15:37:56 --> Helper loaded: url_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: file_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: form_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: my_helper
INFO - 2024-12-16 15:37:56 --> Database Driver Class Initialized
INFO - 2024-12-16 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:37:56 --> Controller Class Initialized
INFO - 2024-12-16 15:37:56 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:37:56 --> Final output sent to browser
DEBUG - 2024-12-16 15:37:56 --> Total execution time: 0.0286
INFO - 2024-12-16 15:37:56 --> Config Class Initialized
INFO - 2024-12-16 15:37:56 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:37:56 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:37:56 --> Utf8 Class Initialized
INFO - 2024-12-16 15:37:56 --> URI Class Initialized
INFO - 2024-12-16 15:37:56 --> Router Class Initialized
INFO - 2024-12-16 15:37:56 --> Output Class Initialized
INFO - 2024-12-16 15:37:56 --> Security Class Initialized
DEBUG - 2024-12-16 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:37:56 --> Input Class Initialized
INFO - 2024-12-16 15:37:56 --> Language Class Initialized
INFO - 2024-12-16 15:37:56 --> Language Class Initialized
INFO - 2024-12-16 15:37:56 --> Config Class Initialized
INFO - 2024-12-16 15:37:56 --> Loader Class Initialized
INFO - 2024-12-16 15:37:56 --> Helper loaded: url_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: file_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: form_helper
INFO - 2024-12-16 15:37:56 --> Helper loaded: my_helper
INFO - 2024-12-16 15:37:56 --> Database Driver Class Initialized
INFO - 2024-12-16 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:37:56 --> Controller Class Initialized
DEBUG - 2024-12-16 15:37:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 15:37:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:37:56 --> Final output sent to browser
DEBUG - 2024-12-16 15:37:56 --> Total execution time: 0.0381
INFO - 2024-12-16 15:38:23 --> Config Class Initialized
INFO - 2024-12-16 15:38:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:23 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:23 --> URI Class Initialized
INFO - 2024-12-16 15:38:23 --> Router Class Initialized
INFO - 2024-12-16 15:38:23 --> Output Class Initialized
INFO - 2024-12-16 15:38:23 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:23 --> Input Class Initialized
INFO - 2024-12-16 15:38:23 --> Language Class Initialized
INFO - 2024-12-16 15:38:23 --> Language Class Initialized
INFO - 2024-12-16 15:38:23 --> Config Class Initialized
INFO - 2024-12-16 15:38:23 --> Loader Class Initialized
INFO - 2024-12-16 15:38:23 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:23 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:23 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:23 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:23 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:23 --> Controller Class Initialized
DEBUG - 2024-12-16 15:38:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 15:38:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:38:23 --> Final output sent to browser
DEBUG - 2024-12-16 15:38:23 --> Total execution time: 0.0375
INFO - 2024-12-16 15:38:26 --> Config Class Initialized
INFO - 2024-12-16 15:38:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:26 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:26 --> URI Class Initialized
INFO - 2024-12-16 15:38:26 --> Router Class Initialized
INFO - 2024-12-16 15:38:26 --> Output Class Initialized
INFO - 2024-12-16 15:38:26 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:26 --> Input Class Initialized
INFO - 2024-12-16 15:38:26 --> Language Class Initialized
INFO - 2024-12-16 15:38:26 --> Language Class Initialized
INFO - 2024-12-16 15:38:26 --> Config Class Initialized
INFO - 2024-12-16 15:38:26 --> Loader Class Initialized
INFO - 2024-12-16 15:38:26 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:26 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:26 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:26 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:26 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:26 --> Controller Class Initialized
DEBUG - 2024-12-16 15:38:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 15:38:28 --> Final output sent to browser
DEBUG - 2024-12-16 15:38:28 --> Total execution time: 1.9407
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:38 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:38 --> URI Class Initialized
INFO - 2024-12-16 15:38:38 --> Router Class Initialized
INFO - 2024-12-16 15:38:38 --> Output Class Initialized
INFO - 2024-12-16 15:38:38 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:38 --> Input Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Loader Class Initialized
INFO - 2024-12-16 15:38:38 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:38 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:38 --> Controller Class Initialized
INFO - 2024-12-16 15:38:38 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:38:38 --> Final output sent to browser
DEBUG - 2024-12-16 15:38:38 --> Total execution time: 0.0324
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:38 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:38 --> URI Class Initialized
INFO - 2024-12-16 15:38:38 --> Router Class Initialized
INFO - 2024-12-16 15:38:38 --> Output Class Initialized
INFO - 2024-12-16 15:38:38 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:38 --> Input Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Loader Class Initialized
INFO - 2024-12-16 15:38:38 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:38 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:38 --> Controller Class Initialized
INFO - 2024-12-16 15:38:38 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:38 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:38 --> URI Class Initialized
INFO - 2024-12-16 15:38:38 --> Router Class Initialized
INFO - 2024-12-16 15:38:38 --> Output Class Initialized
INFO - 2024-12-16 15:38:38 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:38 --> Input Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Language Class Initialized
INFO - 2024-12-16 15:38:38 --> Config Class Initialized
INFO - 2024-12-16 15:38:38 --> Loader Class Initialized
INFO - 2024-12-16 15:38:38 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:38 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:38 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:38 --> Controller Class Initialized
DEBUG - 2024-12-16 15:38:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 15:38:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:38:38 --> Final output sent to browser
DEBUG - 2024-12-16 15:38:38 --> Total execution time: 0.0428
INFO - 2024-12-16 15:38:44 --> Config Class Initialized
INFO - 2024-12-16 15:38:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:38:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:38:44 --> Utf8 Class Initialized
INFO - 2024-12-16 15:38:44 --> URI Class Initialized
INFO - 2024-12-16 15:38:44 --> Router Class Initialized
INFO - 2024-12-16 15:38:44 --> Output Class Initialized
INFO - 2024-12-16 15:38:44 --> Security Class Initialized
DEBUG - 2024-12-16 15:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:38:44 --> Input Class Initialized
INFO - 2024-12-16 15:38:44 --> Language Class Initialized
INFO - 2024-12-16 15:38:44 --> Language Class Initialized
INFO - 2024-12-16 15:38:44 --> Config Class Initialized
INFO - 2024-12-16 15:38:44 --> Loader Class Initialized
INFO - 2024-12-16 15:38:44 --> Helper loaded: url_helper
INFO - 2024-12-16 15:38:44 --> Helper loaded: file_helper
INFO - 2024-12-16 15:38:44 --> Helper loaded: form_helper
INFO - 2024-12-16 15:38:44 --> Helper loaded: my_helper
INFO - 2024-12-16 15:38:44 --> Database Driver Class Initialized
INFO - 2024-12-16 15:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:38:44 --> Controller Class Initialized
DEBUG - 2024-12-16 15:38:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 15:38:46 --> Final output sent to browser
DEBUG - 2024-12-16 15:38:46 --> Total execution time: 2.0388
INFO - 2024-12-16 15:39:15 --> Config Class Initialized
INFO - 2024-12-16 15:39:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:39:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:39:15 --> Utf8 Class Initialized
INFO - 2024-12-16 15:39:15 --> URI Class Initialized
INFO - 2024-12-16 15:39:15 --> Router Class Initialized
INFO - 2024-12-16 15:39:15 --> Output Class Initialized
INFO - 2024-12-16 15:39:15 --> Security Class Initialized
DEBUG - 2024-12-16 15:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:39:15 --> Input Class Initialized
INFO - 2024-12-16 15:39:15 --> Language Class Initialized
INFO - 2024-12-16 15:39:15 --> Language Class Initialized
INFO - 2024-12-16 15:39:15 --> Config Class Initialized
INFO - 2024-12-16 15:39:15 --> Loader Class Initialized
INFO - 2024-12-16 15:39:15 --> Helper loaded: url_helper
INFO - 2024-12-16 15:39:15 --> Helper loaded: file_helper
INFO - 2024-12-16 15:39:15 --> Helper loaded: form_helper
INFO - 2024-12-16 15:39:15 --> Helper loaded: my_helper
INFO - 2024-12-16 15:39:15 --> Database Driver Class Initialized
INFO - 2024-12-16 15:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:39:15 --> Controller Class Initialized
DEBUG - 2024-12-16 15:39:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 15:39:19 --> Final output sent to browser
DEBUG - 2024-12-16 15:39:19 --> Total execution time: 4.6735
INFO - 2024-12-16 15:39:47 --> Config Class Initialized
INFO - 2024-12-16 15:39:47 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:39:47 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:39:47 --> Utf8 Class Initialized
INFO - 2024-12-16 15:39:47 --> URI Class Initialized
INFO - 2024-12-16 15:39:47 --> Router Class Initialized
INFO - 2024-12-16 15:39:47 --> Output Class Initialized
INFO - 2024-12-16 15:39:47 --> Security Class Initialized
DEBUG - 2024-12-16 15:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:39:47 --> Input Class Initialized
INFO - 2024-12-16 15:39:47 --> Language Class Initialized
INFO - 2024-12-16 15:39:47 --> Language Class Initialized
INFO - 2024-12-16 15:39:47 --> Config Class Initialized
INFO - 2024-12-16 15:39:47 --> Loader Class Initialized
INFO - 2024-12-16 15:39:47 --> Helper loaded: url_helper
INFO - 2024-12-16 15:39:47 --> Helper loaded: file_helper
INFO - 2024-12-16 15:39:47 --> Helper loaded: form_helper
INFO - 2024-12-16 15:39:47 --> Helper loaded: my_helper
INFO - 2024-12-16 15:39:47 --> Database Driver Class Initialized
INFO - 2024-12-16 15:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:39:47 --> Controller Class Initialized
ERROR - 2024-12-16 15:39:47 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 15:39:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 15:39:51 --> Final output sent to browser
DEBUG - 2024-12-16 15:39:51 --> Total execution time: 3.6237
INFO - 2024-12-16 15:40:17 --> Config Class Initialized
INFO - 2024-12-16 15:40:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:40:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:40:17 --> Utf8 Class Initialized
INFO - 2024-12-16 15:40:17 --> URI Class Initialized
INFO - 2024-12-16 15:40:17 --> Router Class Initialized
INFO - 2024-12-16 15:40:17 --> Output Class Initialized
INFO - 2024-12-16 15:40:17 --> Security Class Initialized
DEBUG - 2024-12-16 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:40:17 --> Input Class Initialized
INFO - 2024-12-16 15:40:17 --> Language Class Initialized
INFO - 2024-12-16 15:40:17 --> Language Class Initialized
INFO - 2024-12-16 15:40:17 --> Config Class Initialized
INFO - 2024-12-16 15:40:17 --> Loader Class Initialized
INFO - 2024-12-16 15:40:17 --> Helper loaded: url_helper
INFO - 2024-12-16 15:40:17 --> Helper loaded: file_helper
INFO - 2024-12-16 15:40:17 --> Helper loaded: form_helper
INFO - 2024-12-16 15:40:17 --> Helper loaded: my_helper
INFO - 2024-12-16 15:40:17 --> Database Driver Class Initialized
INFO - 2024-12-16 15:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:40:17 --> Controller Class Initialized
DEBUG - 2024-12-16 15:40:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 15:40:19 --> Config Class Initialized
INFO - 2024-12-16 15:40:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:40:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:40:19 --> Utf8 Class Initialized
INFO - 2024-12-16 15:40:19 --> URI Class Initialized
INFO - 2024-12-16 15:40:19 --> Router Class Initialized
INFO - 2024-12-16 15:40:19 --> Output Class Initialized
INFO - 2024-12-16 15:40:19 --> Security Class Initialized
DEBUG - 2024-12-16 15:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:40:19 --> Input Class Initialized
INFO - 2024-12-16 15:40:19 --> Language Class Initialized
INFO - 2024-12-16 15:40:20 --> Language Class Initialized
INFO - 2024-12-16 15:40:20 --> Config Class Initialized
INFO - 2024-12-16 15:40:20 --> Loader Class Initialized
INFO - 2024-12-16 15:40:20 --> Helper loaded: url_helper
INFO - 2024-12-16 15:40:20 --> Helper loaded: file_helper
INFO - 2024-12-16 15:40:20 --> Helper loaded: form_helper
INFO - 2024-12-16 15:40:20 --> Helper loaded: my_helper
INFO - 2024-12-16 15:40:20 --> Database Driver Class Initialized
INFO - 2024-12-16 15:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:40:20 --> Controller Class Initialized
DEBUG - 2024-12-16 15:40:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 15:40:22 --> Final output sent to browser
DEBUG - 2024-12-16 15:40:22 --> Total execution time: 5.4020
INFO - 2024-12-16 15:40:26 --> Final output sent to browser
DEBUG - 2024-12-16 15:40:26 --> Total execution time: 6.4931
INFO - 2024-12-16 15:41:13 --> Config Class Initialized
INFO - 2024-12-16 15:41:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:13 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:13 --> URI Class Initialized
INFO - 2024-12-16 15:41:13 --> Router Class Initialized
INFO - 2024-12-16 15:41:13 --> Output Class Initialized
INFO - 2024-12-16 15:41:13 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:13 --> Input Class Initialized
INFO - 2024-12-16 15:41:13 --> Language Class Initialized
INFO - 2024-12-16 15:41:13 --> Language Class Initialized
INFO - 2024-12-16 15:41:13 --> Config Class Initialized
INFO - 2024-12-16 15:41:13 --> Loader Class Initialized
INFO - 2024-12-16 15:41:13 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:13 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:13 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:13 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:13 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:13 --> Controller Class Initialized
DEBUG - 2024-12-16 15:41:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 15:41:15 --> Final output sent to browser
DEBUG - 2024-12-16 15:41:15 --> Total execution time: 2.8760
INFO - 2024-12-16 15:41:37 --> Config Class Initialized
INFO - 2024-12-16 15:41:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:37 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:37 --> URI Class Initialized
INFO - 2024-12-16 15:41:37 --> Router Class Initialized
INFO - 2024-12-16 15:41:37 --> Output Class Initialized
INFO - 2024-12-16 15:41:37 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:37 --> Input Class Initialized
INFO - 2024-12-16 15:41:37 --> Language Class Initialized
INFO - 2024-12-16 15:41:37 --> Language Class Initialized
INFO - 2024-12-16 15:41:37 --> Config Class Initialized
INFO - 2024-12-16 15:41:37 --> Loader Class Initialized
INFO - 2024-12-16 15:41:37 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:37 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:37 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:37 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:37 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:37 --> Controller Class Initialized
INFO - 2024-12-16 15:41:37 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:41:37 --> Final output sent to browser
DEBUG - 2024-12-16 15:41:37 --> Total execution time: 0.0546
INFO - 2024-12-16 15:41:38 --> Config Class Initialized
INFO - 2024-12-16 15:41:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:38 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:38 --> URI Class Initialized
INFO - 2024-12-16 15:41:38 --> Router Class Initialized
INFO - 2024-12-16 15:41:38 --> Output Class Initialized
INFO - 2024-12-16 15:41:38 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:38 --> Input Class Initialized
INFO - 2024-12-16 15:41:38 --> Language Class Initialized
INFO - 2024-12-16 15:41:38 --> Language Class Initialized
INFO - 2024-12-16 15:41:38 --> Config Class Initialized
INFO - 2024-12-16 15:41:38 --> Loader Class Initialized
INFO - 2024-12-16 15:41:38 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:38 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:38 --> Controller Class Initialized
INFO - 2024-12-16 15:41:38 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:41:38 --> Config Class Initialized
INFO - 2024-12-16 15:41:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:38 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:38 --> URI Class Initialized
INFO - 2024-12-16 15:41:38 --> Router Class Initialized
INFO - 2024-12-16 15:41:38 --> Output Class Initialized
INFO - 2024-12-16 15:41:38 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:38 --> Input Class Initialized
INFO - 2024-12-16 15:41:38 --> Language Class Initialized
INFO - 2024-12-16 15:41:38 --> Language Class Initialized
INFO - 2024-12-16 15:41:38 --> Config Class Initialized
INFO - 2024-12-16 15:41:38 --> Loader Class Initialized
INFO - 2024-12-16 15:41:38 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:38 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:38 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:38 --> Controller Class Initialized
DEBUG - 2024-12-16 15:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 15:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:41:38 --> Final output sent to browser
DEBUG - 2024-12-16 15:41:38 --> Total execution time: 0.0396
INFO - 2024-12-16 15:41:45 --> Config Class Initialized
INFO - 2024-12-16 15:41:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:45 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:45 --> URI Class Initialized
INFO - 2024-12-16 15:41:45 --> Router Class Initialized
INFO - 2024-12-16 15:41:45 --> Output Class Initialized
INFO - 2024-12-16 15:41:45 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:45 --> Input Class Initialized
INFO - 2024-12-16 15:41:45 --> Language Class Initialized
INFO - 2024-12-16 15:41:45 --> Language Class Initialized
INFO - 2024-12-16 15:41:45 --> Config Class Initialized
INFO - 2024-12-16 15:41:45 --> Loader Class Initialized
INFO - 2024-12-16 15:41:45 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:45 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:45 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:45 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:45 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:45 --> Controller Class Initialized
DEBUG - 2024-12-16 15:41:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 15:41:49 --> Final output sent to browser
DEBUG - 2024-12-16 15:41:49 --> Total execution time: 4.3872
INFO - 2024-12-16 15:41:57 --> Config Class Initialized
INFO - 2024-12-16 15:41:57 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:41:57 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:41:57 --> Utf8 Class Initialized
INFO - 2024-12-16 15:41:57 --> URI Class Initialized
INFO - 2024-12-16 15:41:57 --> Router Class Initialized
INFO - 2024-12-16 15:41:57 --> Output Class Initialized
INFO - 2024-12-16 15:41:57 --> Security Class Initialized
DEBUG - 2024-12-16 15:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:41:57 --> Input Class Initialized
INFO - 2024-12-16 15:41:57 --> Language Class Initialized
INFO - 2024-12-16 15:41:57 --> Language Class Initialized
INFO - 2024-12-16 15:41:57 --> Config Class Initialized
INFO - 2024-12-16 15:41:57 --> Loader Class Initialized
INFO - 2024-12-16 15:41:57 --> Helper loaded: url_helper
INFO - 2024-12-16 15:41:57 --> Helper loaded: file_helper
INFO - 2024-12-16 15:41:57 --> Helper loaded: form_helper
INFO - 2024-12-16 15:41:57 --> Helper loaded: my_helper
INFO - 2024-12-16 15:41:57 --> Database Driver Class Initialized
INFO - 2024-12-16 15:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:41:57 --> Controller Class Initialized
DEBUG - 2024-12-16 15:41:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 15:42:00 --> Final output sent to browser
DEBUG - 2024-12-16 15:42:00 --> Total execution time: 3.6271
INFO - 2024-12-16 15:59:46 --> Config Class Initialized
INFO - 2024-12-16 15:59:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:59:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:59:46 --> Utf8 Class Initialized
INFO - 2024-12-16 15:59:46 --> URI Class Initialized
INFO - 2024-12-16 15:59:46 --> Router Class Initialized
INFO - 2024-12-16 15:59:46 --> Output Class Initialized
INFO - 2024-12-16 15:59:46 --> Security Class Initialized
DEBUG - 2024-12-16 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:59:46 --> Input Class Initialized
INFO - 2024-12-16 15:59:46 --> Language Class Initialized
INFO - 2024-12-16 15:59:46 --> Language Class Initialized
INFO - 2024-12-16 15:59:46 --> Config Class Initialized
INFO - 2024-12-16 15:59:46 --> Loader Class Initialized
INFO - 2024-12-16 15:59:46 --> Helper loaded: url_helper
INFO - 2024-12-16 15:59:46 --> Helper loaded: file_helper
INFO - 2024-12-16 15:59:46 --> Helper loaded: form_helper
INFO - 2024-12-16 15:59:46 --> Helper loaded: my_helper
INFO - 2024-12-16 15:59:46 --> Database Driver Class Initialized
INFO - 2024-12-16 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:59:46 --> Controller Class Initialized
INFO - 2024-12-16 15:59:46 --> Final output sent to browser
DEBUG - 2024-12-16 15:59:46 --> Total execution time: 0.0548
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:59:59 --> Utf8 Class Initialized
INFO - 2024-12-16 15:59:59 --> URI Class Initialized
INFO - 2024-12-16 15:59:59 --> Router Class Initialized
INFO - 2024-12-16 15:59:59 --> Output Class Initialized
INFO - 2024-12-16 15:59:59 --> Security Class Initialized
DEBUG - 2024-12-16 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:59:59 --> Input Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Loader Class Initialized
INFO - 2024-12-16 15:59:59 --> Helper loaded: url_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: file_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: form_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: my_helper
INFO - 2024-12-16 15:59:59 --> Database Driver Class Initialized
INFO - 2024-12-16 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:59:59 --> Controller Class Initialized
INFO - 2024-12-16 15:59:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:59:59 --> Final output sent to browser
DEBUG - 2024-12-16 15:59:59 --> Total execution time: 0.0297
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:59:59 --> Utf8 Class Initialized
INFO - 2024-12-16 15:59:59 --> URI Class Initialized
INFO - 2024-12-16 15:59:59 --> Router Class Initialized
INFO - 2024-12-16 15:59:59 --> Output Class Initialized
INFO - 2024-12-16 15:59:59 --> Security Class Initialized
DEBUG - 2024-12-16 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:59:59 --> Input Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Loader Class Initialized
INFO - 2024-12-16 15:59:59 --> Helper loaded: url_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: file_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: form_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: my_helper
INFO - 2024-12-16 15:59:59 --> Database Driver Class Initialized
INFO - 2024-12-16 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:59:59 --> Controller Class Initialized
INFO - 2024-12-16 15:59:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 15:59:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 15:59:59 --> Utf8 Class Initialized
INFO - 2024-12-16 15:59:59 --> URI Class Initialized
INFO - 2024-12-16 15:59:59 --> Router Class Initialized
INFO - 2024-12-16 15:59:59 --> Output Class Initialized
INFO - 2024-12-16 15:59:59 --> Security Class Initialized
DEBUG - 2024-12-16 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 15:59:59 --> Input Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Language Class Initialized
INFO - 2024-12-16 15:59:59 --> Config Class Initialized
INFO - 2024-12-16 15:59:59 --> Loader Class Initialized
INFO - 2024-12-16 15:59:59 --> Helper loaded: url_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: file_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: form_helper
INFO - 2024-12-16 15:59:59 --> Helper loaded: my_helper
INFO - 2024-12-16 15:59:59 --> Database Driver Class Initialized
INFO - 2024-12-16 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 15:59:59 --> Controller Class Initialized
DEBUG - 2024-12-16 15:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 15:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 15:59:59 --> Final output sent to browser
DEBUG - 2024-12-16 15:59:59 --> Total execution time: 0.0288
INFO - 2024-12-16 16:00:07 --> Config Class Initialized
INFO - 2024-12-16 16:00:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:00:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:00:07 --> Utf8 Class Initialized
INFO - 2024-12-16 16:00:07 --> URI Class Initialized
INFO - 2024-12-16 16:00:07 --> Router Class Initialized
INFO - 2024-12-16 16:00:07 --> Output Class Initialized
INFO - 2024-12-16 16:00:07 --> Security Class Initialized
DEBUG - 2024-12-16 16:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:00:07 --> Input Class Initialized
INFO - 2024-12-16 16:00:07 --> Language Class Initialized
INFO - 2024-12-16 16:00:07 --> Language Class Initialized
INFO - 2024-12-16 16:00:07 --> Config Class Initialized
INFO - 2024-12-16 16:00:07 --> Loader Class Initialized
INFO - 2024-12-16 16:00:07 --> Helper loaded: url_helper
INFO - 2024-12-16 16:00:07 --> Helper loaded: file_helper
INFO - 2024-12-16 16:00:07 --> Helper loaded: form_helper
INFO - 2024-12-16 16:00:07 --> Helper loaded: my_helper
INFO - 2024-12-16 16:00:07 --> Database Driver Class Initialized
INFO - 2024-12-16 16:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:00:07 --> Controller Class Initialized
DEBUG - 2024-12-16 16:00:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:00:13 --> Final output sent to browser
DEBUG - 2024-12-16 16:00:13 --> Total execution time: 5.9157
INFO - 2024-12-16 16:00:50 --> Config Class Initialized
INFO - 2024-12-16 16:00:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:00:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:00:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:00:50 --> URI Class Initialized
INFO - 2024-12-16 16:00:50 --> Router Class Initialized
INFO - 2024-12-16 16:00:50 --> Output Class Initialized
INFO - 2024-12-16 16:00:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:00:50 --> Input Class Initialized
INFO - 2024-12-16 16:00:50 --> Language Class Initialized
INFO - 2024-12-16 16:00:50 --> Language Class Initialized
INFO - 2024-12-16 16:00:50 --> Config Class Initialized
INFO - 2024-12-16 16:00:50 --> Loader Class Initialized
INFO - 2024-12-16 16:00:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:00:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:00:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:00:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:00:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:00:50 --> Controller Class Initialized
INFO - 2024-12-16 16:00:50 --> Final output sent to browser
DEBUG - 2024-12-16 16:00:50 --> Total execution time: 0.0338
INFO - 2024-12-16 16:05:08 --> Config Class Initialized
INFO - 2024-12-16 16:05:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:08 --> URI Class Initialized
INFO - 2024-12-16 16:05:08 --> Router Class Initialized
INFO - 2024-12-16 16:05:08 --> Output Class Initialized
INFO - 2024-12-16 16:05:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:08 --> Input Class Initialized
INFO - 2024-12-16 16:05:08 --> Language Class Initialized
INFO - 2024-12-16 16:05:08 --> Language Class Initialized
INFO - 2024-12-16 16:05:08 --> Config Class Initialized
INFO - 2024-12-16 16:05:08 --> Loader Class Initialized
INFO - 2024-12-16 16:05:08 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:08 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:08 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:08 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:08 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:08 --> Controller Class Initialized
INFO - 2024-12-16 16:05:08 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:05:08 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:08 --> Total execution time: 0.0311
INFO - 2024-12-16 16:05:09 --> Config Class Initialized
INFO - 2024-12-16 16:05:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:09 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:09 --> URI Class Initialized
INFO - 2024-12-16 16:05:09 --> Router Class Initialized
INFO - 2024-12-16 16:05:09 --> Output Class Initialized
INFO - 2024-12-16 16:05:09 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:09 --> Input Class Initialized
INFO - 2024-12-16 16:05:09 --> Language Class Initialized
INFO - 2024-12-16 16:05:09 --> Language Class Initialized
INFO - 2024-12-16 16:05:09 --> Config Class Initialized
INFO - 2024-12-16 16:05:09 --> Loader Class Initialized
INFO - 2024-12-16 16:05:09 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:09 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:09 --> Controller Class Initialized
INFO - 2024-12-16 16:05:09 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:05:09 --> Config Class Initialized
INFO - 2024-12-16 16:05:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:09 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:09 --> URI Class Initialized
INFO - 2024-12-16 16:05:09 --> Router Class Initialized
INFO - 2024-12-16 16:05:09 --> Output Class Initialized
INFO - 2024-12-16 16:05:09 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:09 --> Input Class Initialized
INFO - 2024-12-16 16:05:09 --> Language Class Initialized
INFO - 2024-12-16 16:05:09 --> Language Class Initialized
INFO - 2024-12-16 16:05:09 --> Config Class Initialized
INFO - 2024-12-16 16:05:09 --> Loader Class Initialized
INFO - 2024-12-16 16:05:09 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:09 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:09 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:09 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 16:05:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:05:09 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:09 --> Total execution time: 0.0774
INFO - 2024-12-16 16:05:12 --> Config Class Initialized
INFO - 2024-12-16 16:05:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:12 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:12 --> URI Class Initialized
INFO - 2024-12-16 16:05:12 --> Router Class Initialized
INFO - 2024-12-16 16:05:12 --> Output Class Initialized
INFO - 2024-12-16 16:05:12 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:12 --> Input Class Initialized
INFO - 2024-12-16 16:05:12 --> Language Class Initialized
INFO - 2024-12-16 16:05:12 --> Language Class Initialized
INFO - 2024-12-16 16:05:12 --> Config Class Initialized
INFO - 2024-12-16 16:05:12 --> Loader Class Initialized
INFO - 2024-12-16 16:05:12 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:12 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:12 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:12 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:12 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:12 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:05:17 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:17 --> Total execution time: 5.2267
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:37 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:37 --> URI Class Initialized
INFO - 2024-12-16 16:05:37 --> Router Class Initialized
INFO - 2024-12-16 16:05:37 --> Output Class Initialized
INFO - 2024-12-16 16:05:37 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:37 --> Input Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Loader Class Initialized
INFO - 2024-12-16 16:05:37 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:37 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:37 --> Controller Class Initialized
INFO - 2024-12-16 16:05:37 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:05:37 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:37 --> Total execution time: 0.0414
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:37 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:37 --> URI Class Initialized
INFO - 2024-12-16 16:05:37 --> Router Class Initialized
INFO - 2024-12-16 16:05:37 --> Output Class Initialized
INFO - 2024-12-16 16:05:37 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:37 --> Input Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Loader Class Initialized
INFO - 2024-12-16 16:05:37 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:37 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:37 --> Controller Class Initialized
INFO - 2024-12-16 16:05:37 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:37 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:37 --> URI Class Initialized
INFO - 2024-12-16 16:05:37 --> Router Class Initialized
INFO - 2024-12-16 16:05:37 --> Output Class Initialized
INFO - 2024-12-16 16:05:37 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:37 --> Input Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Language Class Initialized
INFO - 2024-12-16 16:05:37 --> Config Class Initialized
INFO - 2024-12-16 16:05:37 --> Loader Class Initialized
INFO - 2024-12-16 16:05:37 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:37 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:37 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:37 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 16:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:05:37 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:37 --> Total execution time: 0.0372
INFO - 2024-12-16 16:05:38 --> Config Class Initialized
INFO - 2024-12-16 16:05:38 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:38 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:38 --> URI Class Initialized
INFO - 2024-12-16 16:05:38 --> Router Class Initialized
INFO - 2024-12-16 16:05:38 --> Output Class Initialized
INFO - 2024-12-16 16:05:38 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:38 --> Input Class Initialized
INFO - 2024-12-16 16:05:38 --> Language Class Initialized
INFO - 2024-12-16 16:05:38 --> Language Class Initialized
INFO - 2024-12-16 16:05:38 --> Config Class Initialized
INFO - 2024-12-16 16:05:38 --> Loader Class Initialized
INFO - 2024-12-16 16:05:38 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:38 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:38 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:38 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:38 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:38 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:05:40 --> Config Class Initialized
INFO - 2024-12-16 16:05:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:40 --> URI Class Initialized
INFO - 2024-12-16 16:05:40 --> Router Class Initialized
INFO - 2024-12-16 16:05:40 --> Output Class Initialized
INFO - 2024-12-16 16:05:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:40 --> Input Class Initialized
INFO - 2024-12-16 16:05:40 --> Language Class Initialized
INFO - 2024-12-16 16:05:40 --> Language Class Initialized
INFO - 2024-12-16 16:05:40 --> Config Class Initialized
INFO - 2024-12-16 16:05:40 --> Loader Class Initialized
INFO - 2024-12-16 16:05:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:40 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:05:44 --> Config Class Initialized
INFO - 2024-12-16 16:05:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:44 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:44 --> URI Class Initialized
INFO - 2024-12-16 16:05:44 --> Router Class Initialized
INFO - 2024-12-16 16:05:44 --> Output Class Initialized
INFO - 2024-12-16 16:05:44 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:44 --> Input Class Initialized
INFO - 2024-12-16 16:05:44 --> Language Class Initialized
INFO - 2024-12-16 16:05:44 --> Language Class Initialized
INFO - 2024-12-16 16:05:44 --> Config Class Initialized
INFO - 2024-12-16 16:05:44 --> Loader Class Initialized
INFO - 2024-12-16 16:05:44 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:44 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:44 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:44 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:44 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:44 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:05:48 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:48 --> Total execution time: 9.7178
INFO - 2024-12-16 16:05:51 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:51 --> Total execution time: 11.2496
INFO - 2024-12-16 16:05:53 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:53 --> Total execution time: 8.9652
INFO - 2024-12-16 16:05:53 --> Config Class Initialized
INFO - 2024-12-16 16:05:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:05:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:05:53 --> Utf8 Class Initialized
INFO - 2024-12-16 16:05:53 --> URI Class Initialized
INFO - 2024-12-16 16:05:53 --> Router Class Initialized
INFO - 2024-12-16 16:05:53 --> Output Class Initialized
INFO - 2024-12-16 16:05:53 --> Security Class Initialized
DEBUG - 2024-12-16 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:05:53 --> Input Class Initialized
INFO - 2024-12-16 16:05:53 --> Language Class Initialized
INFO - 2024-12-16 16:05:53 --> Language Class Initialized
INFO - 2024-12-16 16:05:53 --> Config Class Initialized
INFO - 2024-12-16 16:05:53 --> Loader Class Initialized
INFO - 2024-12-16 16:05:53 --> Helper loaded: url_helper
INFO - 2024-12-16 16:05:53 --> Helper loaded: file_helper
INFO - 2024-12-16 16:05:53 --> Helper loaded: form_helper
INFO - 2024-12-16 16:05:53 --> Helper loaded: my_helper
INFO - 2024-12-16 16:05:53 --> Database Driver Class Initialized
INFO - 2024-12-16 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:05:53 --> Controller Class Initialized
DEBUG - 2024-12-16 16:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:05:57 --> Final output sent to browser
DEBUG - 2024-12-16 16:05:57 --> Total execution time: 4.5024
INFO - 2024-12-16 16:06:35 --> Config Class Initialized
INFO - 2024-12-16 16:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:06:35 --> Utf8 Class Initialized
INFO - 2024-12-16 16:06:35 --> URI Class Initialized
INFO - 2024-12-16 16:06:35 --> Router Class Initialized
INFO - 2024-12-16 16:06:35 --> Output Class Initialized
INFO - 2024-12-16 16:06:35 --> Security Class Initialized
DEBUG - 2024-12-16 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:06:35 --> Input Class Initialized
INFO - 2024-12-16 16:06:35 --> Language Class Initialized
INFO - 2024-12-16 16:06:35 --> Language Class Initialized
INFO - 2024-12-16 16:06:35 --> Config Class Initialized
INFO - 2024-12-16 16:06:35 --> Loader Class Initialized
INFO - 2024-12-16 16:06:35 --> Helper loaded: url_helper
INFO - 2024-12-16 16:06:35 --> Helper loaded: file_helper
INFO - 2024-12-16 16:06:35 --> Helper loaded: form_helper
INFO - 2024-12-16 16:06:35 --> Helper loaded: my_helper
INFO - 2024-12-16 16:06:35 --> Database Driver Class Initialized
INFO - 2024-12-16 16:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:06:35 --> Controller Class Initialized
DEBUG - 2024-12-16 16:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 16:06:37 --> Final output sent to browser
DEBUG - 2024-12-16 16:06:37 --> Total execution time: 1.9646
INFO - 2024-12-16 16:10:13 --> Config Class Initialized
INFO - 2024-12-16 16:10:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:10:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:10:13 --> Utf8 Class Initialized
INFO - 2024-12-16 16:10:13 --> URI Class Initialized
INFO - 2024-12-16 16:10:13 --> Router Class Initialized
INFO - 2024-12-16 16:10:13 --> Output Class Initialized
INFO - 2024-12-16 16:10:13 --> Security Class Initialized
DEBUG - 2024-12-16 16:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:10:13 --> Input Class Initialized
INFO - 2024-12-16 16:10:13 --> Language Class Initialized
INFO - 2024-12-16 16:10:13 --> Language Class Initialized
INFO - 2024-12-16 16:10:13 --> Config Class Initialized
INFO - 2024-12-16 16:10:13 --> Loader Class Initialized
INFO - 2024-12-16 16:10:13 --> Helper loaded: url_helper
INFO - 2024-12-16 16:10:13 --> Helper loaded: file_helper
INFO - 2024-12-16 16:10:13 --> Helper loaded: form_helper
INFO - 2024-12-16 16:10:13 --> Helper loaded: my_helper
INFO - 2024-12-16 16:10:13 --> Database Driver Class Initialized
INFO - 2024-12-16 16:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:10:13 --> Controller Class Initialized
ERROR - 2024-12-16 16:10:13 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 16:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 16:10:17 --> Final output sent to browser
DEBUG - 2024-12-16 16:10:17 --> Total execution time: 3.9352
INFO - 2024-12-16 16:10:37 --> Config Class Initialized
INFO - 2024-12-16 16:10:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:10:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:10:37 --> Utf8 Class Initialized
INFO - 2024-12-16 16:10:37 --> URI Class Initialized
INFO - 2024-12-16 16:10:37 --> Router Class Initialized
INFO - 2024-12-16 16:10:37 --> Output Class Initialized
INFO - 2024-12-16 16:10:37 --> Security Class Initialized
DEBUG - 2024-12-16 16:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:10:37 --> Input Class Initialized
INFO - 2024-12-16 16:10:37 --> Language Class Initialized
INFO - 2024-12-16 16:10:37 --> Language Class Initialized
INFO - 2024-12-16 16:10:37 --> Config Class Initialized
INFO - 2024-12-16 16:10:37 --> Loader Class Initialized
INFO - 2024-12-16 16:10:37 --> Helper loaded: url_helper
INFO - 2024-12-16 16:10:37 --> Helper loaded: file_helper
INFO - 2024-12-16 16:10:37 --> Helper loaded: form_helper
INFO - 2024-12-16 16:10:37 --> Helper loaded: my_helper
INFO - 2024-12-16 16:10:37 --> Database Driver Class Initialized
INFO - 2024-12-16 16:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:10:37 --> Controller Class Initialized
DEBUG - 2024-12-16 16:10:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 16:10:43 --> Final output sent to browser
DEBUG - 2024-12-16 16:10:43 --> Total execution time: 5.7727
INFO - 2024-12-16 16:12:11 --> Config Class Initialized
INFO - 2024-12-16 16:12:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:12:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:12:11 --> Utf8 Class Initialized
INFO - 2024-12-16 16:12:11 --> URI Class Initialized
INFO - 2024-12-16 16:12:11 --> Router Class Initialized
INFO - 2024-12-16 16:12:11 --> Output Class Initialized
INFO - 2024-12-16 16:12:11 --> Security Class Initialized
DEBUG - 2024-12-16 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:12:11 --> Input Class Initialized
INFO - 2024-12-16 16:12:11 --> Language Class Initialized
INFO - 2024-12-16 16:12:11 --> Language Class Initialized
INFO - 2024-12-16 16:12:11 --> Config Class Initialized
INFO - 2024-12-16 16:12:11 --> Loader Class Initialized
INFO - 2024-12-16 16:12:11 --> Helper loaded: url_helper
INFO - 2024-12-16 16:12:11 --> Helper loaded: file_helper
INFO - 2024-12-16 16:12:11 --> Helper loaded: form_helper
INFO - 2024-12-16 16:12:11 --> Helper loaded: my_helper
INFO - 2024-12-16 16:12:11 --> Database Driver Class Initialized
INFO - 2024-12-16 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:12:11 --> Controller Class Initialized
DEBUG - 2024-12-16 16:12:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 16:12:15 --> Final output sent to browser
DEBUG - 2024-12-16 16:12:15 --> Total execution time: 4.6006
INFO - 2024-12-16 16:12:51 --> Config Class Initialized
INFO - 2024-12-16 16:12:51 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:12:51 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:12:51 --> Utf8 Class Initialized
INFO - 2024-12-16 16:12:51 --> URI Class Initialized
INFO - 2024-12-16 16:12:51 --> Router Class Initialized
INFO - 2024-12-16 16:12:51 --> Output Class Initialized
INFO - 2024-12-16 16:12:51 --> Security Class Initialized
DEBUG - 2024-12-16 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:12:51 --> Input Class Initialized
INFO - 2024-12-16 16:12:51 --> Language Class Initialized
INFO - 2024-12-16 16:12:51 --> Language Class Initialized
INFO - 2024-12-16 16:12:51 --> Config Class Initialized
INFO - 2024-12-16 16:12:51 --> Loader Class Initialized
INFO - 2024-12-16 16:12:51 --> Helper loaded: url_helper
INFO - 2024-12-16 16:12:51 --> Helper loaded: file_helper
INFO - 2024-12-16 16:12:51 --> Helper loaded: form_helper
INFO - 2024-12-16 16:12:51 --> Helper loaded: my_helper
INFO - 2024-12-16 16:12:51 --> Database Driver Class Initialized
INFO - 2024-12-16 16:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:12:51 --> Controller Class Initialized
INFO - 2024-12-16 16:12:51 --> Final output sent to browser
DEBUG - 2024-12-16 16:12:51 --> Total execution time: 0.0340
INFO - 2024-12-16 16:13:42 --> Config Class Initialized
INFO - 2024-12-16 16:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:13:42 --> Utf8 Class Initialized
INFO - 2024-12-16 16:13:42 --> URI Class Initialized
INFO - 2024-12-16 16:13:42 --> Router Class Initialized
INFO - 2024-12-16 16:13:42 --> Output Class Initialized
INFO - 2024-12-16 16:13:42 --> Security Class Initialized
DEBUG - 2024-12-16 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:13:42 --> Input Class Initialized
INFO - 2024-12-16 16:13:42 --> Language Class Initialized
INFO - 2024-12-16 16:13:42 --> Language Class Initialized
INFO - 2024-12-16 16:13:42 --> Config Class Initialized
INFO - 2024-12-16 16:13:42 --> Loader Class Initialized
INFO - 2024-12-16 16:13:42 --> Helper loaded: url_helper
INFO - 2024-12-16 16:13:42 --> Helper loaded: file_helper
INFO - 2024-12-16 16:13:42 --> Helper loaded: form_helper
INFO - 2024-12-16 16:13:42 --> Helper loaded: my_helper
INFO - 2024-12-16 16:13:42 --> Database Driver Class Initialized
INFO - 2024-12-16 16:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:13:42 --> Controller Class Initialized
INFO - 2024-12-16 16:13:42 --> Final output sent to browser
DEBUG - 2024-12-16 16:13:42 --> Total execution time: 0.0298
INFO - 2024-12-16 16:13:53 --> Config Class Initialized
INFO - 2024-12-16 16:13:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:13:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:13:53 --> Utf8 Class Initialized
INFO - 2024-12-16 16:13:53 --> URI Class Initialized
INFO - 2024-12-16 16:13:53 --> Router Class Initialized
INFO - 2024-12-16 16:13:53 --> Output Class Initialized
INFO - 2024-12-16 16:13:53 --> Security Class Initialized
DEBUG - 2024-12-16 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:13:53 --> Input Class Initialized
INFO - 2024-12-16 16:13:53 --> Language Class Initialized
INFO - 2024-12-16 16:13:53 --> Language Class Initialized
INFO - 2024-12-16 16:13:53 --> Config Class Initialized
INFO - 2024-12-16 16:13:53 --> Loader Class Initialized
INFO - 2024-12-16 16:13:53 --> Helper loaded: url_helper
INFO - 2024-12-16 16:13:53 --> Helper loaded: file_helper
INFO - 2024-12-16 16:13:53 --> Helper loaded: form_helper
INFO - 2024-12-16 16:13:53 --> Helper loaded: my_helper
INFO - 2024-12-16 16:13:53 --> Database Driver Class Initialized
INFO - 2024-12-16 16:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:13:53 --> Controller Class Initialized
DEBUG - 2024-12-16 16:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:13:53 --> Final output sent to browser
DEBUG - 2024-12-16 16:13:53 --> Total execution time: 0.0304
INFO - 2024-12-16 16:13:58 --> Config Class Initialized
INFO - 2024-12-16 16:13:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:13:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:13:58 --> Utf8 Class Initialized
INFO - 2024-12-16 16:13:58 --> URI Class Initialized
INFO - 2024-12-16 16:13:58 --> Router Class Initialized
INFO - 2024-12-16 16:13:58 --> Output Class Initialized
INFO - 2024-12-16 16:13:58 --> Security Class Initialized
DEBUG - 2024-12-16 16:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:13:58 --> Input Class Initialized
INFO - 2024-12-16 16:13:58 --> Language Class Initialized
INFO - 2024-12-16 16:13:58 --> Language Class Initialized
INFO - 2024-12-16 16:13:58 --> Config Class Initialized
INFO - 2024-12-16 16:13:58 --> Loader Class Initialized
INFO - 2024-12-16 16:13:58 --> Helper loaded: url_helper
INFO - 2024-12-16 16:13:58 --> Helper loaded: file_helper
INFO - 2024-12-16 16:13:58 --> Helper loaded: form_helper
INFO - 2024-12-16 16:13:58 --> Helper loaded: my_helper
INFO - 2024-12-16 16:13:58 --> Database Driver Class Initialized
INFO - 2024-12-16 16:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:13:58 --> Controller Class Initialized
INFO - 2024-12-16 16:13:58 --> Final output sent to browser
DEBUG - 2024-12-16 16:13:58 --> Total execution time: 0.0366
INFO - 2024-12-16 16:14:07 --> Config Class Initialized
INFO - 2024-12-16 16:14:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:07 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:07 --> URI Class Initialized
INFO - 2024-12-16 16:14:07 --> Router Class Initialized
INFO - 2024-12-16 16:14:07 --> Output Class Initialized
INFO - 2024-12-16 16:14:07 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:07 --> Input Class Initialized
INFO - 2024-12-16 16:14:07 --> Language Class Initialized
INFO - 2024-12-16 16:14:07 --> Language Class Initialized
INFO - 2024-12-16 16:14:07 --> Config Class Initialized
INFO - 2024-12-16 16:14:07 --> Loader Class Initialized
INFO - 2024-12-16 16:14:07 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:07 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:07 --> Controller Class Initialized
INFO - 2024-12-16 16:14:07 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:14:07 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:07 --> Total execution time: 0.0283
INFO - 2024-12-16 16:14:07 --> Config Class Initialized
INFO - 2024-12-16 16:14:07 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:07 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:07 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:07 --> URI Class Initialized
INFO - 2024-12-16 16:14:07 --> Router Class Initialized
INFO - 2024-12-16 16:14:07 --> Output Class Initialized
INFO - 2024-12-16 16:14:07 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:07 --> Input Class Initialized
INFO - 2024-12-16 16:14:07 --> Language Class Initialized
INFO - 2024-12-16 16:14:07 --> Language Class Initialized
INFO - 2024-12-16 16:14:07 --> Config Class Initialized
INFO - 2024-12-16 16:14:07 --> Loader Class Initialized
INFO - 2024-12-16 16:14:07 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:07 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:07 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:07 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 16:14:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:07 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:07 --> Total execution time: 0.0305
INFO - 2024-12-16 16:14:15 --> Config Class Initialized
INFO - 2024-12-16 16:14:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:15 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:15 --> URI Class Initialized
INFO - 2024-12-16 16:14:15 --> Router Class Initialized
INFO - 2024-12-16 16:14:15 --> Output Class Initialized
INFO - 2024-12-16 16:14:15 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:15 --> Input Class Initialized
INFO - 2024-12-16 16:14:15 --> Language Class Initialized
INFO - 2024-12-16 16:14:15 --> Language Class Initialized
INFO - 2024-12-16 16:14:15 --> Config Class Initialized
INFO - 2024-12-16 16:14:15 --> Loader Class Initialized
INFO - 2024-12-16 16:14:15 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:15 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:15 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:15 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:15 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:15 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-12-16 16:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:16 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:16 --> Total execution time: 0.1397
INFO - 2024-12-16 16:14:23 --> Config Class Initialized
INFO - 2024-12-16 16:14:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:23 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:23 --> URI Class Initialized
INFO - 2024-12-16 16:14:23 --> Router Class Initialized
INFO - 2024-12-16 16:14:23 --> Output Class Initialized
INFO - 2024-12-16 16:14:23 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:23 --> Input Class Initialized
INFO - 2024-12-16 16:14:23 --> Language Class Initialized
INFO - 2024-12-16 16:14:24 --> Language Class Initialized
INFO - 2024-12-16 16:14:24 --> Config Class Initialized
INFO - 2024-12-16 16:14:24 --> Loader Class Initialized
INFO - 2024-12-16 16:14:24 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:24 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:24 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:24 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:24 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:24 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 16:14:30 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:30 --> Total execution time: 6.1677
INFO - 2024-12-16 16:14:30 --> Config Class Initialized
INFO - 2024-12-16 16:14:30 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:30 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:30 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:30 --> URI Class Initialized
INFO - 2024-12-16 16:14:30 --> Router Class Initialized
INFO - 2024-12-16 16:14:30 --> Output Class Initialized
INFO - 2024-12-16 16:14:30 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:30 --> Input Class Initialized
INFO - 2024-12-16 16:14:30 --> Language Class Initialized
INFO - 2024-12-16 16:14:30 --> Language Class Initialized
INFO - 2024-12-16 16:14:30 --> Config Class Initialized
INFO - 2024-12-16 16:14:30 --> Loader Class Initialized
INFO - 2024-12-16 16:14:30 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:30 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:30 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:30 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:30 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:30 --> Controller Class Initialized
INFO - 2024-12-16 16:14:30 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:14:30 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:30 --> Total execution time: 0.0349
INFO - 2024-12-16 16:14:31 --> Config Class Initialized
INFO - 2024-12-16 16:14:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:31 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:31 --> URI Class Initialized
INFO - 2024-12-16 16:14:31 --> Router Class Initialized
INFO - 2024-12-16 16:14:31 --> Output Class Initialized
INFO - 2024-12-16 16:14:31 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:31 --> Input Class Initialized
INFO - 2024-12-16 16:14:31 --> Language Class Initialized
INFO - 2024-12-16 16:14:31 --> Language Class Initialized
INFO - 2024-12-16 16:14:31 --> Config Class Initialized
INFO - 2024-12-16 16:14:31 --> Loader Class Initialized
INFO - 2024-12-16 16:14:31 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:31 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:31 --> Controller Class Initialized
INFO - 2024-12-16 16:14:31 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:14:31 --> Config Class Initialized
INFO - 2024-12-16 16:14:31 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:31 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:31 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:31 --> URI Class Initialized
INFO - 2024-12-16 16:14:31 --> Router Class Initialized
INFO - 2024-12-16 16:14:31 --> Output Class Initialized
INFO - 2024-12-16 16:14:31 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:31 --> Input Class Initialized
INFO - 2024-12-16 16:14:31 --> Language Class Initialized
INFO - 2024-12-16 16:14:31 --> Language Class Initialized
INFO - 2024-12-16 16:14:31 --> Config Class Initialized
INFO - 2024-12-16 16:14:31 --> Loader Class Initialized
INFO - 2024-12-16 16:14:31 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:31 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:31 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:31 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 16:14:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:31 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:31 --> Total execution time: 0.0308
INFO - 2024-12-16 16:14:32 --> Config Class Initialized
INFO - 2024-12-16 16:14:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:32 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:32 --> URI Class Initialized
INFO - 2024-12-16 16:14:32 --> Router Class Initialized
INFO - 2024-12-16 16:14:32 --> Output Class Initialized
INFO - 2024-12-16 16:14:32 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:32 --> Input Class Initialized
INFO - 2024-12-16 16:14:32 --> Language Class Initialized
INFO - 2024-12-16 16:14:32 --> Language Class Initialized
INFO - 2024-12-16 16:14:32 --> Config Class Initialized
INFO - 2024-12-16 16:14:32 --> Loader Class Initialized
INFO - 2024-12-16 16:14:32 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:32 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:32 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-12-16 16:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:32 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:32 --> Total execution time: 0.0277
INFO - 2024-12-16 16:14:32 --> Config Class Initialized
INFO - 2024-12-16 16:14:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:32 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:32 --> URI Class Initialized
INFO - 2024-12-16 16:14:32 --> Router Class Initialized
INFO - 2024-12-16 16:14:32 --> Output Class Initialized
INFO - 2024-12-16 16:14:32 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:32 --> Input Class Initialized
INFO - 2024-12-16 16:14:32 --> Language Class Initialized
ERROR - 2024-12-16 16:14:32 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:14:32 --> Config Class Initialized
INFO - 2024-12-16 16:14:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:32 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:32 --> URI Class Initialized
INFO - 2024-12-16 16:14:32 --> Router Class Initialized
INFO - 2024-12-16 16:14:32 --> Output Class Initialized
INFO - 2024-12-16 16:14:32 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:32 --> Input Class Initialized
INFO - 2024-12-16 16:14:32 --> Language Class Initialized
INFO - 2024-12-16 16:14:32 --> Language Class Initialized
INFO - 2024-12-16 16:14:32 --> Config Class Initialized
INFO - 2024-12-16 16:14:32 --> Loader Class Initialized
INFO - 2024-12-16 16:14:32 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:32 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:32 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:32 --> Controller Class Initialized
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:50 --> URI Class Initialized
INFO - 2024-12-16 16:14:50 --> Router Class Initialized
INFO - 2024-12-16 16:14:50 --> Output Class Initialized
INFO - 2024-12-16 16:14:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:50 --> Input Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Loader Class Initialized
INFO - 2024-12-16 16:14:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:50 --> Controller Class Initialized
INFO - 2024-12-16 16:14:50 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:50 --> URI Class Initialized
INFO - 2024-12-16 16:14:50 --> Router Class Initialized
INFO - 2024-12-16 16:14:50 --> Output Class Initialized
INFO - 2024-12-16 16:14:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:50 --> Input Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Loader Class Initialized
INFO - 2024-12-16 16:14:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:50 --> Controller Class Initialized
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:50 --> URI Class Initialized
INFO - 2024-12-16 16:14:50 --> Router Class Initialized
INFO - 2024-12-16 16:14:50 --> Output Class Initialized
INFO - 2024-12-16 16:14:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:50 --> Input Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Language Class Initialized
INFO - 2024-12-16 16:14:50 --> Config Class Initialized
INFO - 2024-12-16 16:14:50 --> Loader Class Initialized
INFO - 2024-12-16 16:14:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:50 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:14:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:50 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:50 --> Total execution time: 0.0320
INFO - 2024-12-16 16:14:54 --> Config Class Initialized
INFO - 2024-12-16 16:14:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:54 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:54 --> URI Class Initialized
INFO - 2024-12-16 16:14:54 --> Router Class Initialized
INFO - 2024-12-16 16:14:54 --> Output Class Initialized
INFO - 2024-12-16 16:14:54 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:54 --> Input Class Initialized
INFO - 2024-12-16 16:14:54 --> Language Class Initialized
INFO - 2024-12-16 16:14:54 --> Language Class Initialized
INFO - 2024-12-16 16:14:54 --> Config Class Initialized
INFO - 2024-12-16 16:14:54 --> Loader Class Initialized
INFO - 2024-12-16 16:14:54 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:54 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:54 --> Controller Class Initialized
INFO - 2024-12-16 16:14:54 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:14:54 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:54 --> Total execution time: 0.0324
INFO - 2024-12-16 16:14:54 --> Config Class Initialized
INFO - 2024-12-16 16:14:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:14:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:14:54 --> Utf8 Class Initialized
INFO - 2024-12-16 16:14:54 --> URI Class Initialized
INFO - 2024-12-16 16:14:54 --> Router Class Initialized
INFO - 2024-12-16 16:14:54 --> Output Class Initialized
INFO - 2024-12-16 16:14:54 --> Security Class Initialized
DEBUG - 2024-12-16 16:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:14:54 --> Input Class Initialized
INFO - 2024-12-16 16:14:54 --> Language Class Initialized
INFO - 2024-12-16 16:14:54 --> Language Class Initialized
INFO - 2024-12-16 16:14:54 --> Config Class Initialized
INFO - 2024-12-16 16:14:54 --> Loader Class Initialized
INFO - 2024-12-16 16:14:54 --> Helper loaded: url_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: file_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: form_helper
INFO - 2024-12-16 16:14:54 --> Helper loaded: my_helper
INFO - 2024-12-16 16:14:54 --> Database Driver Class Initialized
INFO - 2024-12-16 16:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:14:54 --> Controller Class Initialized
DEBUG - 2024-12-16 16:14:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 16:14:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:14:54 --> Final output sent to browser
DEBUG - 2024-12-16 16:14:54 --> Total execution time: 0.0289
INFO - 2024-12-16 16:15:01 --> Config Class Initialized
INFO - 2024-12-16 16:15:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:15:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:15:01 --> Utf8 Class Initialized
INFO - 2024-12-16 16:15:01 --> URI Class Initialized
INFO - 2024-12-16 16:15:01 --> Router Class Initialized
INFO - 2024-12-16 16:15:01 --> Output Class Initialized
INFO - 2024-12-16 16:15:01 --> Security Class Initialized
DEBUG - 2024-12-16 16:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:15:01 --> Input Class Initialized
INFO - 2024-12-16 16:15:01 --> Language Class Initialized
INFO - 2024-12-16 16:15:01 --> Language Class Initialized
INFO - 2024-12-16 16:15:01 --> Config Class Initialized
INFO - 2024-12-16 16:15:01 --> Loader Class Initialized
INFO - 2024-12-16 16:15:01 --> Helper loaded: url_helper
INFO - 2024-12-16 16:15:01 --> Helper loaded: file_helper
INFO - 2024-12-16 16:15:01 --> Helper loaded: form_helper
INFO - 2024-12-16 16:15:01 --> Helper loaded: my_helper
INFO - 2024-12-16 16:15:01 --> Database Driver Class Initialized
INFO - 2024-12-16 16:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:15:01 --> Controller Class Initialized
DEBUG - 2024-12-16 16:15:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 16:15:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:15:01 --> Final output sent to browser
DEBUG - 2024-12-16 16:15:01 --> Total execution time: 0.1785
INFO - 2024-12-16 16:15:08 --> Config Class Initialized
INFO - 2024-12-16 16:15:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:15:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:15:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:15:08 --> URI Class Initialized
INFO - 2024-12-16 16:15:08 --> Router Class Initialized
INFO - 2024-12-16 16:15:08 --> Output Class Initialized
INFO - 2024-12-16 16:15:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:15:08 --> Input Class Initialized
INFO - 2024-12-16 16:15:08 --> Language Class Initialized
INFO - 2024-12-16 16:15:08 --> Language Class Initialized
INFO - 2024-12-16 16:15:08 --> Config Class Initialized
INFO - 2024-12-16 16:15:08 --> Loader Class Initialized
INFO - 2024-12-16 16:15:08 --> Helper loaded: url_helper
INFO - 2024-12-16 16:15:08 --> Helper loaded: file_helper
INFO - 2024-12-16 16:15:08 --> Helper loaded: form_helper
INFO - 2024-12-16 16:15:08 --> Helper loaded: my_helper
INFO - 2024-12-16 16:15:08 --> Database Driver Class Initialized
INFO - 2024-12-16 16:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:15:08 --> Controller Class Initialized
DEBUG - 2024-12-16 16:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:15:13 --> Final output sent to browser
DEBUG - 2024-12-16 16:15:13 --> Total execution time: 4.9091
INFO - 2024-12-16 16:15:14 --> Config Class Initialized
INFO - 2024-12-16 16:15:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:15:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:15:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:15:14 --> URI Class Initialized
INFO - 2024-12-16 16:15:14 --> Router Class Initialized
INFO - 2024-12-16 16:15:14 --> Output Class Initialized
INFO - 2024-12-16 16:15:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:15:14 --> Input Class Initialized
INFO - 2024-12-16 16:15:14 --> Language Class Initialized
INFO - 2024-12-16 16:15:14 --> Language Class Initialized
INFO - 2024-12-16 16:15:14 --> Config Class Initialized
INFO - 2024-12-16 16:15:14 --> Loader Class Initialized
INFO - 2024-12-16 16:15:14 --> Helper loaded: url_helper
INFO - 2024-12-16 16:15:14 --> Helper loaded: file_helper
INFO - 2024-12-16 16:15:14 --> Helper loaded: form_helper
INFO - 2024-12-16 16:15:14 --> Helper loaded: my_helper
INFO - 2024-12-16 16:15:14 --> Database Driver Class Initialized
INFO - 2024-12-16 16:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:15:14 --> Controller Class Initialized
DEBUG - 2024-12-16 16:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:15:18 --> Final output sent to browser
DEBUG - 2024-12-16 16:15:18 --> Total execution time: 4.8337
INFO - 2024-12-16 16:17:08 --> Config Class Initialized
INFO - 2024-12-16 16:17:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:17:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:17:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:17:08 --> URI Class Initialized
INFO - 2024-12-16 16:17:08 --> Router Class Initialized
INFO - 2024-12-16 16:17:08 --> Output Class Initialized
INFO - 2024-12-16 16:17:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:17:08 --> Input Class Initialized
INFO - 2024-12-16 16:17:08 --> Language Class Initialized
INFO - 2024-12-16 16:17:08 --> Language Class Initialized
INFO - 2024-12-16 16:17:08 --> Config Class Initialized
INFO - 2024-12-16 16:17:08 --> Loader Class Initialized
INFO - 2024-12-16 16:17:08 --> Helper loaded: url_helper
INFO - 2024-12-16 16:17:08 --> Helper loaded: file_helper
INFO - 2024-12-16 16:17:08 --> Helper loaded: form_helper
INFO - 2024-12-16 16:17:08 --> Helper loaded: my_helper
INFO - 2024-12-16 16:17:08 --> Database Driver Class Initialized
INFO - 2024-12-16 16:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:17:08 --> Controller Class Initialized
DEBUG - 2024-12-16 16:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-16 16:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:17:08 --> Final output sent to browser
DEBUG - 2024-12-16 16:17:08 --> Total execution time: 0.0335
INFO - 2024-12-16 16:17:40 --> Config Class Initialized
INFO - 2024-12-16 16:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:17:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:17:40 --> URI Class Initialized
INFO - 2024-12-16 16:17:40 --> Router Class Initialized
INFO - 2024-12-16 16:17:40 --> Output Class Initialized
INFO - 2024-12-16 16:17:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:17:40 --> Input Class Initialized
INFO - 2024-12-16 16:17:40 --> Language Class Initialized
INFO - 2024-12-16 16:17:40 --> Language Class Initialized
INFO - 2024-12-16 16:17:40 --> Config Class Initialized
INFO - 2024-12-16 16:17:40 --> Loader Class Initialized
INFO - 2024-12-16 16:17:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:17:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:17:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:17:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:17:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:17:40 --> Controller Class Initialized
INFO - 2024-12-16 16:17:40 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:17:40 --> Final output sent to browser
DEBUG - 2024-12-16 16:17:40 --> Total execution time: 0.0390
INFO - 2024-12-16 16:17:40 --> Config Class Initialized
INFO - 2024-12-16 16:17:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:17:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:17:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:17:40 --> URI Class Initialized
INFO - 2024-12-16 16:17:41 --> Router Class Initialized
INFO - 2024-12-16 16:17:41 --> Output Class Initialized
INFO - 2024-12-16 16:17:41 --> Security Class Initialized
DEBUG - 2024-12-16 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:17:41 --> Input Class Initialized
INFO - 2024-12-16 16:17:41 --> Language Class Initialized
INFO - 2024-12-16 16:17:41 --> Language Class Initialized
INFO - 2024-12-16 16:17:41 --> Config Class Initialized
INFO - 2024-12-16 16:17:41 --> Loader Class Initialized
INFO - 2024-12-16 16:17:41 --> Helper loaded: url_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: file_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: form_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: my_helper
INFO - 2024-12-16 16:17:41 --> Database Driver Class Initialized
INFO - 2024-12-16 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:17:41 --> Controller Class Initialized
INFO - 2024-12-16 16:17:41 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:17:41 --> Config Class Initialized
INFO - 2024-12-16 16:17:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:17:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:17:41 --> Utf8 Class Initialized
INFO - 2024-12-16 16:17:41 --> URI Class Initialized
INFO - 2024-12-16 16:17:41 --> Router Class Initialized
INFO - 2024-12-16 16:17:41 --> Output Class Initialized
INFO - 2024-12-16 16:17:41 --> Security Class Initialized
DEBUG - 2024-12-16 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:17:41 --> Input Class Initialized
INFO - 2024-12-16 16:17:41 --> Language Class Initialized
INFO - 2024-12-16 16:17:41 --> Language Class Initialized
INFO - 2024-12-16 16:17:41 --> Config Class Initialized
INFO - 2024-12-16 16:17:41 --> Loader Class Initialized
INFO - 2024-12-16 16:17:41 --> Helper loaded: url_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: file_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: form_helper
INFO - 2024-12-16 16:17:41 --> Helper loaded: my_helper
INFO - 2024-12-16 16:17:41 --> Database Driver Class Initialized
INFO - 2024-12-16 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:17:41 --> Controller Class Initialized
DEBUG - 2024-12-16 16:17:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 16:17:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:17:41 --> Final output sent to browser
DEBUG - 2024-12-16 16:17:41 --> Total execution time: 0.0320
INFO - 2024-12-16 16:18:02 --> Config Class Initialized
INFO - 2024-12-16 16:18:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:02 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:02 --> URI Class Initialized
INFO - 2024-12-16 16:18:02 --> Router Class Initialized
INFO - 2024-12-16 16:18:02 --> Output Class Initialized
INFO - 2024-12-16 16:18:02 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:02 --> Input Class Initialized
INFO - 2024-12-16 16:18:02 --> Language Class Initialized
INFO - 2024-12-16 16:18:03 --> Language Class Initialized
INFO - 2024-12-16 16:18:03 --> Config Class Initialized
INFO - 2024-12-16 16:18:03 --> Loader Class Initialized
INFO - 2024-12-16 16:18:03 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:03 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:03 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:03 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:03 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:03 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 16:18:06 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:06 --> Total execution time: 3.2037
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:09 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:09 --> URI Class Initialized
INFO - 2024-12-16 16:18:09 --> Router Class Initialized
INFO - 2024-12-16 16:18:09 --> Output Class Initialized
INFO - 2024-12-16 16:18:09 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:09 --> Input Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Loader Class Initialized
INFO - 2024-12-16 16:18:09 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:09 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:09 --> Controller Class Initialized
INFO - 2024-12-16 16:18:09 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:09 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:09 --> URI Class Initialized
INFO - 2024-12-16 16:18:09 --> Router Class Initialized
INFO - 2024-12-16 16:18:09 --> Output Class Initialized
INFO - 2024-12-16 16:18:09 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:09 --> Input Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Loader Class Initialized
INFO - 2024-12-16 16:18:09 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:09 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:09 --> Controller Class Initialized
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:09 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:09 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:09 --> URI Class Initialized
INFO - 2024-12-16 16:18:09 --> Router Class Initialized
INFO - 2024-12-16 16:18:09 --> Output Class Initialized
INFO - 2024-12-16 16:18:09 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:09 --> Input Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Language Class Initialized
INFO - 2024-12-16 16:18:09 --> Config Class Initialized
INFO - 2024-12-16 16:18:09 --> Loader Class Initialized
INFO - 2024-12-16 16:18:09 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:09 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:09 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:09 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:18:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:18:09 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:09 --> Total execution time: 0.0291
INFO - 2024-12-16 16:18:19 --> Config Class Initialized
INFO - 2024-12-16 16:18:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:19 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:19 --> URI Class Initialized
INFO - 2024-12-16 16:18:19 --> Router Class Initialized
INFO - 2024-12-16 16:18:19 --> Output Class Initialized
INFO - 2024-12-16 16:18:19 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:19 --> Input Class Initialized
INFO - 2024-12-16 16:18:19 --> Language Class Initialized
INFO - 2024-12-16 16:18:19 --> Language Class Initialized
INFO - 2024-12-16 16:18:19 --> Config Class Initialized
INFO - 2024-12-16 16:18:19 --> Loader Class Initialized
INFO - 2024-12-16 16:18:19 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:19 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:19 --> Controller Class Initialized
INFO - 2024-12-16 16:18:19 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:18:19 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:19 --> Total execution time: 0.0297
INFO - 2024-12-16 16:18:19 --> Config Class Initialized
INFO - 2024-12-16 16:18:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:19 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:19 --> URI Class Initialized
INFO - 2024-12-16 16:18:19 --> Router Class Initialized
INFO - 2024-12-16 16:18:19 --> Output Class Initialized
INFO - 2024-12-16 16:18:19 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:19 --> Input Class Initialized
INFO - 2024-12-16 16:18:19 --> Language Class Initialized
INFO - 2024-12-16 16:18:19 --> Language Class Initialized
INFO - 2024-12-16 16:18:19 --> Config Class Initialized
INFO - 2024-12-16 16:18:19 --> Loader Class Initialized
INFO - 2024-12-16 16:18:19 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:19 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:19 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:19 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:18:19 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:19 --> Total execution time: 0.0284
INFO - 2024-12-16 16:18:36 --> Config Class Initialized
INFO - 2024-12-16 16:18:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:36 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:36 --> URI Class Initialized
INFO - 2024-12-16 16:18:36 --> Router Class Initialized
INFO - 2024-12-16 16:18:36 --> Output Class Initialized
INFO - 2024-12-16 16:18:36 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:36 --> Input Class Initialized
INFO - 2024-12-16 16:18:36 --> Language Class Initialized
INFO - 2024-12-16 16:18:36 --> Language Class Initialized
INFO - 2024-12-16 16:18:36 --> Config Class Initialized
INFO - 2024-12-16 16:18:36 --> Loader Class Initialized
INFO - 2024-12-16 16:18:36 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:36 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:36 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:18:36 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:36 --> Total execution time: 0.0415
INFO - 2024-12-16 16:18:36 --> Config Class Initialized
INFO - 2024-12-16 16:18:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:36 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:36 --> URI Class Initialized
INFO - 2024-12-16 16:18:36 --> Router Class Initialized
INFO - 2024-12-16 16:18:36 --> Output Class Initialized
INFO - 2024-12-16 16:18:36 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:36 --> Input Class Initialized
INFO - 2024-12-16 16:18:36 --> Language Class Initialized
ERROR - 2024-12-16 16:18:36 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:18:36 --> Config Class Initialized
INFO - 2024-12-16 16:18:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:36 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:36 --> URI Class Initialized
INFO - 2024-12-16 16:18:36 --> Router Class Initialized
INFO - 2024-12-16 16:18:36 --> Output Class Initialized
INFO - 2024-12-16 16:18:36 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:36 --> Input Class Initialized
INFO - 2024-12-16 16:18:36 --> Language Class Initialized
INFO - 2024-12-16 16:18:36 --> Language Class Initialized
INFO - 2024-12-16 16:18:36 --> Config Class Initialized
INFO - 2024-12-16 16:18:36 --> Loader Class Initialized
INFO - 2024-12-16 16:18:36 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:36 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:36 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:36 --> Controller Class Initialized
INFO - 2024-12-16 16:18:39 --> Config Class Initialized
INFO - 2024-12-16 16:18:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:39 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:39 --> URI Class Initialized
INFO - 2024-12-16 16:18:39 --> Router Class Initialized
INFO - 2024-12-16 16:18:39 --> Output Class Initialized
INFO - 2024-12-16 16:18:39 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:39 --> Input Class Initialized
INFO - 2024-12-16 16:18:39 --> Language Class Initialized
INFO - 2024-12-16 16:18:39 --> Language Class Initialized
INFO - 2024-12-16 16:18:39 --> Config Class Initialized
INFO - 2024-12-16 16:18:39 --> Loader Class Initialized
INFO - 2024-12-16 16:18:39 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:39 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:39 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:39 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:39 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:39 --> Controller Class Initialized
INFO - 2024-12-16 16:18:40 --> Config Class Initialized
INFO - 2024-12-16 16:18:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:40 --> URI Class Initialized
INFO - 2024-12-16 16:18:40 --> Router Class Initialized
INFO - 2024-12-16 16:18:40 --> Output Class Initialized
INFO - 2024-12-16 16:18:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:40 --> Input Class Initialized
INFO - 2024-12-16 16:18:40 --> Language Class Initialized
INFO - 2024-12-16 16:18:40 --> Language Class Initialized
INFO - 2024-12-16 16:18:40 --> Config Class Initialized
INFO - 2024-12-16 16:18:40 --> Loader Class Initialized
INFO - 2024-12-16 16:18:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:40 --> Controller Class Initialized
INFO - 2024-12-16 16:18:40 --> Config Class Initialized
INFO - 2024-12-16 16:18:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:40 --> URI Class Initialized
INFO - 2024-12-16 16:18:40 --> Router Class Initialized
INFO - 2024-12-16 16:18:40 --> Output Class Initialized
INFO - 2024-12-16 16:18:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:40 --> Input Class Initialized
INFO - 2024-12-16 16:18:40 --> Language Class Initialized
INFO - 2024-12-16 16:18:40 --> Language Class Initialized
INFO - 2024-12-16 16:18:40 --> Config Class Initialized
INFO - 2024-12-16 16:18:40 --> Loader Class Initialized
INFO - 2024-12-16 16:18:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:40 --> Controller Class Initialized
INFO - 2024-12-16 16:18:42 --> Config Class Initialized
INFO - 2024-12-16 16:18:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:42 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:42 --> URI Class Initialized
INFO - 2024-12-16 16:18:42 --> Router Class Initialized
INFO - 2024-12-16 16:18:42 --> Output Class Initialized
INFO - 2024-12-16 16:18:42 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:42 --> Input Class Initialized
INFO - 2024-12-16 16:18:42 --> Language Class Initialized
INFO - 2024-12-16 16:18:42 --> Language Class Initialized
INFO - 2024-12-16 16:18:42 --> Config Class Initialized
INFO - 2024-12-16 16:18:42 --> Loader Class Initialized
INFO - 2024-12-16 16:18:42 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:42 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:42 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:42 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:42 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:42 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-16 16:18:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:18:42 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:42 --> Total execution time: 0.0354
INFO - 2024-12-16 16:18:50 --> Config Class Initialized
INFO - 2024-12-16 16:18:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:50 --> URI Class Initialized
INFO - 2024-12-16 16:18:50 --> Router Class Initialized
INFO - 2024-12-16 16:18:50 --> Output Class Initialized
INFO - 2024-12-16 16:18:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:50 --> Input Class Initialized
INFO - 2024-12-16 16:18:50 --> Language Class Initialized
INFO - 2024-12-16 16:18:50 --> Language Class Initialized
INFO - 2024-12-16 16:18:50 --> Config Class Initialized
INFO - 2024-12-16 16:18:50 --> Loader Class Initialized
INFO - 2024-12-16 16:18:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:50 --> Controller Class Initialized
DEBUG - 2024-12-16 16:18:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-12-16 16:18:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:18:50 --> Final output sent to browser
DEBUG - 2024-12-16 16:18:50 --> Total execution time: 0.0577
INFO - 2024-12-16 16:18:50 --> Config Class Initialized
INFO - 2024-12-16 16:18:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:50 --> URI Class Initialized
INFO - 2024-12-16 16:18:50 --> Router Class Initialized
INFO - 2024-12-16 16:18:50 --> Output Class Initialized
INFO - 2024-12-16 16:18:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:50 --> Input Class Initialized
INFO - 2024-12-16 16:18:50 --> Language Class Initialized
ERROR - 2024-12-16 16:18:50 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:18:50 --> Config Class Initialized
INFO - 2024-12-16 16:18:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:18:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:18:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:18:50 --> URI Class Initialized
INFO - 2024-12-16 16:18:50 --> Router Class Initialized
INFO - 2024-12-16 16:18:50 --> Output Class Initialized
INFO - 2024-12-16 16:18:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:18:50 --> Input Class Initialized
INFO - 2024-12-16 16:18:50 --> Language Class Initialized
INFO - 2024-12-16 16:18:50 --> Language Class Initialized
INFO - 2024-12-16 16:18:50 --> Config Class Initialized
INFO - 2024-12-16 16:18:50 --> Loader Class Initialized
INFO - 2024-12-16 16:18:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:18:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:18:51 --> Database Driver Class Initialized
INFO - 2024-12-16 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:18:51 --> Controller Class Initialized
INFO - 2024-12-16 16:19:58 --> Config Class Initialized
INFO - 2024-12-16 16:19:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:19:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:19:58 --> Utf8 Class Initialized
INFO - 2024-12-16 16:19:58 --> URI Class Initialized
DEBUG - 2024-12-16 16:19:58 --> No URI present. Default controller set.
INFO - 2024-12-16 16:19:58 --> Router Class Initialized
INFO - 2024-12-16 16:19:58 --> Output Class Initialized
INFO - 2024-12-16 16:19:58 --> Security Class Initialized
DEBUG - 2024-12-16 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:19:58 --> Input Class Initialized
INFO - 2024-12-16 16:19:58 --> Language Class Initialized
INFO - 2024-12-16 16:19:58 --> Language Class Initialized
INFO - 2024-12-16 16:19:58 --> Config Class Initialized
INFO - 2024-12-16 16:19:58 --> Loader Class Initialized
INFO - 2024-12-16 16:19:58 --> Helper loaded: url_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: file_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: form_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: my_helper
INFO - 2024-12-16 16:19:58 --> Database Driver Class Initialized
INFO - 2024-12-16 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:19:58 --> Controller Class Initialized
INFO - 2024-12-16 16:19:58 --> Config Class Initialized
INFO - 2024-12-16 16:19:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:19:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:19:58 --> Utf8 Class Initialized
INFO - 2024-12-16 16:19:58 --> URI Class Initialized
INFO - 2024-12-16 16:19:58 --> Router Class Initialized
INFO - 2024-12-16 16:19:58 --> Output Class Initialized
INFO - 2024-12-16 16:19:58 --> Security Class Initialized
DEBUG - 2024-12-16 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:19:58 --> Input Class Initialized
INFO - 2024-12-16 16:19:58 --> Language Class Initialized
INFO - 2024-12-16 16:19:58 --> Language Class Initialized
INFO - 2024-12-16 16:19:58 --> Config Class Initialized
INFO - 2024-12-16 16:19:58 --> Loader Class Initialized
INFO - 2024-12-16 16:19:58 --> Helper loaded: url_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: file_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: form_helper
INFO - 2024-12-16 16:19:58 --> Helper loaded: my_helper
INFO - 2024-12-16 16:19:58 --> Database Driver Class Initialized
INFO - 2024-12-16 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:19:58 --> Controller Class Initialized
DEBUG - 2024-12-16 16:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:19:58 --> Final output sent to browser
DEBUG - 2024-12-16 16:19:58 --> Total execution time: 0.0372
INFO - 2024-12-16 16:20:04 --> Config Class Initialized
INFO - 2024-12-16 16:20:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:04 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:04 --> URI Class Initialized
INFO - 2024-12-16 16:20:04 --> Router Class Initialized
INFO - 2024-12-16 16:20:04 --> Output Class Initialized
INFO - 2024-12-16 16:20:04 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:04 --> Input Class Initialized
INFO - 2024-12-16 16:20:04 --> Language Class Initialized
INFO - 2024-12-16 16:20:04 --> Language Class Initialized
INFO - 2024-12-16 16:20:04 --> Config Class Initialized
INFO - 2024-12-16 16:20:04 --> Loader Class Initialized
INFO - 2024-12-16 16:20:04 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:04 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:04 --> Controller Class Initialized
INFO - 2024-12-16 16:20:04 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:20:04 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:04 --> Total execution time: 0.0332
INFO - 2024-12-16 16:20:04 --> Config Class Initialized
INFO - 2024-12-16 16:20:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:04 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:04 --> URI Class Initialized
INFO - 2024-12-16 16:20:04 --> Router Class Initialized
INFO - 2024-12-16 16:20:04 --> Output Class Initialized
INFO - 2024-12-16 16:20:04 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:04 --> Input Class Initialized
INFO - 2024-12-16 16:20:04 --> Language Class Initialized
INFO - 2024-12-16 16:20:04 --> Language Class Initialized
INFO - 2024-12-16 16:20:04 --> Config Class Initialized
INFO - 2024-12-16 16:20:04 --> Loader Class Initialized
INFO - 2024-12-16 16:20:04 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:04 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:04 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:04 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 16:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:04 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:04 --> Total execution time: 0.0403
INFO - 2024-12-16 16:20:08 --> Config Class Initialized
INFO - 2024-12-16 16:20:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:08 --> URI Class Initialized
INFO - 2024-12-16 16:20:08 --> Router Class Initialized
INFO - 2024-12-16 16:20:08 --> Output Class Initialized
INFO - 2024-12-16 16:20:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:08 --> Input Class Initialized
INFO - 2024-12-16 16:20:08 --> Language Class Initialized
INFO - 2024-12-16 16:20:08 --> Language Class Initialized
INFO - 2024-12-16 16:20:08 --> Config Class Initialized
INFO - 2024-12-16 16:20:08 --> Loader Class Initialized
INFO - 2024-12-16 16:20:08 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:08 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:08 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:08 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:08 --> Total execution time: 0.0786
INFO - 2024-12-16 16:20:08 --> Config Class Initialized
INFO - 2024-12-16 16:20:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:08 --> URI Class Initialized
INFO - 2024-12-16 16:20:08 --> Router Class Initialized
INFO - 2024-12-16 16:20:08 --> Output Class Initialized
INFO - 2024-12-16 16:20:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:08 --> Input Class Initialized
INFO - 2024-12-16 16:20:08 --> Language Class Initialized
ERROR - 2024-12-16 16:20:08 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:20:08 --> Config Class Initialized
INFO - 2024-12-16 16:20:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:08 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:08 --> URI Class Initialized
INFO - 2024-12-16 16:20:08 --> Router Class Initialized
INFO - 2024-12-16 16:20:08 --> Output Class Initialized
INFO - 2024-12-16 16:20:08 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:08 --> Input Class Initialized
INFO - 2024-12-16 16:20:08 --> Language Class Initialized
INFO - 2024-12-16 16:20:08 --> Language Class Initialized
INFO - 2024-12-16 16:20:08 --> Config Class Initialized
INFO - 2024-12-16 16:20:08 --> Loader Class Initialized
INFO - 2024-12-16 16:20:08 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:08 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:08 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:08 --> Controller Class Initialized
INFO - 2024-12-16 16:20:12 --> Config Class Initialized
INFO - 2024-12-16 16:20:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:12 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:12 --> URI Class Initialized
INFO - 2024-12-16 16:20:12 --> Router Class Initialized
INFO - 2024-12-16 16:20:12 --> Output Class Initialized
INFO - 2024-12-16 16:20:12 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:12 --> Input Class Initialized
INFO - 2024-12-16 16:20:12 --> Language Class Initialized
INFO - 2024-12-16 16:20:12 --> Language Class Initialized
INFO - 2024-12-16 16:20:12 --> Config Class Initialized
INFO - 2024-12-16 16:20:12 --> Loader Class Initialized
INFO - 2024-12-16 16:20:12 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:12 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:12 --> Controller Class Initialized
INFO - 2024-12-16 16:20:12 --> Config Class Initialized
INFO - 2024-12-16 16:20:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:12 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:12 --> URI Class Initialized
INFO - 2024-12-16 16:20:12 --> Router Class Initialized
INFO - 2024-12-16 16:20:12 --> Output Class Initialized
INFO - 2024-12-16 16:20:12 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:12 --> Input Class Initialized
INFO - 2024-12-16 16:20:12 --> Language Class Initialized
INFO - 2024-12-16 16:20:12 --> Language Class Initialized
INFO - 2024-12-16 16:20:12 --> Config Class Initialized
INFO - 2024-12-16 16:20:12 --> Loader Class Initialized
INFO - 2024-12-16 16:20:12 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:12 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:12 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:12 --> Controller Class Initialized
INFO - 2024-12-16 16:20:12 --> Config Class Initialized
INFO - 2024-12-16 16:20:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:12 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:12 --> URI Class Initialized
INFO - 2024-12-16 16:20:12 --> Router Class Initialized
INFO - 2024-12-16 16:20:12 --> Output Class Initialized
INFO - 2024-12-16 16:20:12 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:12 --> Input Class Initialized
INFO - 2024-12-16 16:20:12 --> Language Class Initialized
INFO - 2024-12-16 16:20:13 --> Language Class Initialized
INFO - 2024-12-16 16:20:13 --> Config Class Initialized
INFO - 2024-12-16 16:20:13 --> Loader Class Initialized
INFO - 2024-12-16 16:20:13 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:13 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:13 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:13 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:13 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:13 --> Controller Class Initialized
INFO - 2024-12-16 16:20:14 --> Config Class Initialized
INFO - 2024-12-16 16:20:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:14 --> URI Class Initialized
INFO - 2024-12-16 16:20:14 --> Router Class Initialized
INFO - 2024-12-16 16:20:14 --> Output Class Initialized
INFO - 2024-12-16 16:20:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:14 --> Input Class Initialized
INFO - 2024-12-16 16:20:14 --> Language Class Initialized
INFO - 2024-12-16 16:20:14 --> Language Class Initialized
INFO - 2024-12-16 16:20:14 --> Config Class Initialized
INFO - 2024-12-16 16:20:14 --> Loader Class Initialized
INFO - 2024-12-16 16:20:14 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:14 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:14 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:14 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:14 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:14 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:14 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:14 --> Total execution time: 0.0315
INFO - 2024-12-16 16:20:14 --> Config Class Initialized
INFO - 2024-12-16 16:20:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:14 --> URI Class Initialized
INFO - 2024-12-16 16:20:14 --> Router Class Initialized
INFO - 2024-12-16 16:20:14 --> Output Class Initialized
INFO - 2024-12-16 16:20:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:14 --> Input Class Initialized
INFO - 2024-12-16 16:20:14 --> Language Class Initialized
ERROR - 2024-12-16 16:20:14 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:20:15 --> Config Class Initialized
INFO - 2024-12-16 16:20:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:15 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:15 --> URI Class Initialized
INFO - 2024-12-16 16:20:15 --> Router Class Initialized
INFO - 2024-12-16 16:20:15 --> Output Class Initialized
INFO - 2024-12-16 16:20:15 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:15 --> Input Class Initialized
INFO - 2024-12-16 16:20:15 --> Language Class Initialized
INFO - 2024-12-16 16:20:15 --> Language Class Initialized
INFO - 2024-12-16 16:20:15 --> Config Class Initialized
INFO - 2024-12-16 16:20:15 --> Loader Class Initialized
INFO - 2024-12-16 16:20:15 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:15 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:15 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:15 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:15 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:15 --> Controller Class Initialized
INFO - 2024-12-16 16:20:16 --> Config Class Initialized
INFO - 2024-12-16 16:20:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:16 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:16 --> URI Class Initialized
INFO - 2024-12-16 16:20:16 --> Router Class Initialized
INFO - 2024-12-16 16:20:16 --> Output Class Initialized
INFO - 2024-12-16 16:20:16 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:16 --> Input Class Initialized
INFO - 2024-12-16 16:20:16 --> Language Class Initialized
INFO - 2024-12-16 16:20:16 --> Language Class Initialized
INFO - 2024-12-16 16:20:16 --> Config Class Initialized
INFO - 2024-12-16 16:20:16 --> Loader Class Initialized
INFO - 2024-12-16 16:20:16 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:16 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:16 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:16 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:16 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:16 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-16 16:20:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:16 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:16 --> Total execution time: 0.0324
INFO - 2024-12-16 16:20:27 --> Config Class Initialized
INFO - 2024-12-16 16:20:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:27 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:27 --> URI Class Initialized
INFO - 2024-12-16 16:20:27 --> Router Class Initialized
INFO - 2024-12-16 16:20:27 --> Output Class Initialized
INFO - 2024-12-16 16:20:27 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:27 --> Input Class Initialized
INFO - 2024-12-16 16:20:27 --> Language Class Initialized
INFO - 2024-12-16 16:20:27 --> Language Class Initialized
INFO - 2024-12-16 16:20:27 --> Config Class Initialized
INFO - 2024-12-16 16:20:27 --> Loader Class Initialized
INFO - 2024-12-16 16:20:27 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:27 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:27 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:27 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:27 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:27 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-12-16 16:20:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:27 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:27 --> Total execution time: 0.0925
INFO - 2024-12-16 16:20:28 --> Config Class Initialized
INFO - 2024-12-16 16:20:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:28 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:28 --> URI Class Initialized
INFO - 2024-12-16 16:20:28 --> Router Class Initialized
INFO - 2024-12-16 16:20:28 --> Output Class Initialized
INFO - 2024-12-16 16:20:28 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:28 --> Input Class Initialized
INFO - 2024-12-16 16:20:28 --> Language Class Initialized
ERROR - 2024-12-16 16:20:28 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:20:28 --> Config Class Initialized
INFO - 2024-12-16 16:20:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:28 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:28 --> URI Class Initialized
INFO - 2024-12-16 16:20:28 --> Router Class Initialized
INFO - 2024-12-16 16:20:28 --> Output Class Initialized
INFO - 2024-12-16 16:20:28 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:28 --> Input Class Initialized
INFO - 2024-12-16 16:20:28 --> Language Class Initialized
INFO - 2024-12-16 16:20:28 --> Language Class Initialized
INFO - 2024-12-16 16:20:28 --> Config Class Initialized
INFO - 2024-12-16 16:20:28 --> Loader Class Initialized
INFO - 2024-12-16 16:20:28 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:28 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:28 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:28 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:28 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:28 --> Controller Class Initialized
INFO - 2024-12-16 16:20:34 --> Config Class Initialized
INFO - 2024-12-16 16:20:34 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:34 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:34 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:34 --> URI Class Initialized
INFO - 2024-12-16 16:20:34 --> Router Class Initialized
INFO - 2024-12-16 16:20:34 --> Output Class Initialized
INFO - 2024-12-16 16:20:34 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:34 --> Input Class Initialized
INFO - 2024-12-16 16:20:34 --> Language Class Initialized
INFO - 2024-12-16 16:20:34 --> Language Class Initialized
INFO - 2024-12-16 16:20:34 --> Config Class Initialized
INFO - 2024-12-16 16:20:34 --> Loader Class Initialized
INFO - 2024-12-16 16:20:34 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:34 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:34 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:34 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:34 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:34 --> Controller Class Initialized
INFO - 2024-12-16 16:20:34 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:34 --> Total execution time: 0.0291
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:40 --> URI Class Initialized
INFO - 2024-12-16 16:20:40 --> Router Class Initialized
INFO - 2024-12-16 16:20:40 --> Output Class Initialized
INFO - 2024-12-16 16:20:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:40 --> Input Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Loader Class Initialized
INFO - 2024-12-16 16:20:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:40 --> Controller Class Initialized
INFO - 2024-12-16 16:20:40 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:40 --> URI Class Initialized
INFO - 2024-12-16 16:20:40 --> Router Class Initialized
INFO - 2024-12-16 16:20:40 --> Output Class Initialized
INFO - 2024-12-16 16:20:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:40 --> Input Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Loader Class Initialized
INFO - 2024-12-16 16:20:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:40 --> Controller Class Initialized
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:40 --> URI Class Initialized
INFO - 2024-12-16 16:20:40 --> Router Class Initialized
INFO - 2024-12-16 16:20:40 --> Output Class Initialized
INFO - 2024-12-16 16:20:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:40 --> Input Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Language Class Initialized
INFO - 2024-12-16 16:20:40 --> Config Class Initialized
INFO - 2024-12-16 16:20:40 --> Loader Class Initialized
INFO - 2024-12-16 16:20:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:40 --> Controller Class Initialized
DEBUG - 2024-12-16 16:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:20:40 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:40 --> Total execution time: 0.0868
INFO - 2024-12-16 16:20:52 --> Config Class Initialized
INFO - 2024-12-16 16:20:52 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:52 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:52 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:52 --> URI Class Initialized
INFO - 2024-12-16 16:20:52 --> Router Class Initialized
INFO - 2024-12-16 16:20:52 --> Output Class Initialized
INFO - 2024-12-16 16:20:52 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:52 --> Input Class Initialized
INFO - 2024-12-16 16:20:52 --> Language Class Initialized
INFO - 2024-12-16 16:20:52 --> Language Class Initialized
INFO - 2024-12-16 16:20:52 --> Config Class Initialized
INFO - 2024-12-16 16:20:52 --> Loader Class Initialized
INFO - 2024-12-16 16:20:52 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:52 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:52 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:52 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:52 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:52 --> Controller Class Initialized
INFO - 2024-12-16 16:20:52 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:52 --> Total execution time: 0.0647
INFO - 2024-12-16 16:20:57 --> Config Class Initialized
INFO - 2024-12-16 16:20:57 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:20:57 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:20:57 --> Utf8 Class Initialized
INFO - 2024-12-16 16:20:57 --> URI Class Initialized
INFO - 2024-12-16 16:20:57 --> Router Class Initialized
INFO - 2024-12-16 16:20:57 --> Output Class Initialized
INFO - 2024-12-16 16:20:57 --> Security Class Initialized
DEBUG - 2024-12-16 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:20:57 --> Input Class Initialized
INFO - 2024-12-16 16:20:57 --> Language Class Initialized
INFO - 2024-12-16 16:20:57 --> Language Class Initialized
INFO - 2024-12-16 16:20:57 --> Config Class Initialized
INFO - 2024-12-16 16:20:57 --> Loader Class Initialized
INFO - 2024-12-16 16:20:57 --> Helper loaded: url_helper
INFO - 2024-12-16 16:20:57 --> Helper loaded: file_helper
INFO - 2024-12-16 16:20:57 --> Helper loaded: form_helper
INFO - 2024-12-16 16:20:57 --> Helper loaded: my_helper
INFO - 2024-12-16 16:20:57 --> Database Driver Class Initialized
INFO - 2024-12-16 16:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:20:57 --> Controller Class Initialized
INFO - 2024-12-16 16:20:57 --> Final output sent to browser
DEBUG - 2024-12-16 16:20:57 --> Total execution time: 0.0301
INFO - 2024-12-16 16:21:02 --> Config Class Initialized
INFO - 2024-12-16 16:21:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:02 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:02 --> URI Class Initialized
INFO - 2024-12-16 16:21:02 --> Router Class Initialized
INFO - 2024-12-16 16:21:02 --> Output Class Initialized
INFO - 2024-12-16 16:21:02 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:02 --> Input Class Initialized
INFO - 2024-12-16 16:21:02 --> Language Class Initialized
INFO - 2024-12-16 16:21:02 --> Language Class Initialized
INFO - 2024-12-16 16:21:02 --> Config Class Initialized
INFO - 2024-12-16 16:21:02 --> Loader Class Initialized
INFO - 2024-12-16 16:21:02 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:02 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:02 --> Controller Class Initialized
INFO - 2024-12-16 16:21:02 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:21:02 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:02 --> Total execution time: 0.0293
INFO - 2024-12-16 16:21:02 --> Config Class Initialized
INFO - 2024-12-16 16:21:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:02 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:02 --> URI Class Initialized
INFO - 2024-12-16 16:21:02 --> Router Class Initialized
INFO - 2024-12-16 16:21:02 --> Output Class Initialized
INFO - 2024-12-16 16:21:02 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:02 --> Input Class Initialized
INFO - 2024-12-16 16:21:02 --> Language Class Initialized
INFO - 2024-12-16 16:21:02 --> Language Class Initialized
INFO - 2024-12-16 16:21:02 --> Config Class Initialized
INFO - 2024-12-16 16:21:02 --> Loader Class Initialized
INFO - 2024-12-16 16:21:02 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:02 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:02 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:02 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 16:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:02 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:02 --> Total execution time: 0.0309
INFO - 2024-12-16 16:21:11 --> Config Class Initialized
INFO - 2024-12-16 16:21:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:11 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:11 --> URI Class Initialized
INFO - 2024-12-16 16:21:11 --> Router Class Initialized
INFO - 2024-12-16 16:21:11 --> Output Class Initialized
INFO - 2024-12-16 16:21:11 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:11 --> Input Class Initialized
INFO - 2024-12-16 16:21:11 --> Language Class Initialized
INFO - 2024-12-16 16:21:11 --> Language Class Initialized
INFO - 2024-12-16 16:21:11 --> Config Class Initialized
INFO - 2024-12-16 16:21:11 --> Loader Class Initialized
INFO - 2024-12-16 16:21:11 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:11 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:11 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:11 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:11 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:11 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-12-16 16:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:11 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:11 --> Total execution time: 0.0295
INFO - 2024-12-16 16:21:11 --> Config Class Initialized
INFO - 2024-12-16 16:21:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:11 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:11 --> URI Class Initialized
INFO - 2024-12-16 16:21:11 --> Router Class Initialized
INFO - 2024-12-16 16:21:11 --> Output Class Initialized
INFO - 2024-12-16 16:21:11 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:11 --> Input Class Initialized
INFO - 2024-12-16 16:21:11 --> Language Class Initialized
ERROR - 2024-12-16 16:21:11 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:21:12 --> Config Class Initialized
INFO - 2024-12-16 16:21:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:12 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:12 --> URI Class Initialized
INFO - 2024-12-16 16:21:12 --> Router Class Initialized
INFO - 2024-12-16 16:21:12 --> Output Class Initialized
INFO - 2024-12-16 16:21:12 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:12 --> Input Class Initialized
INFO - 2024-12-16 16:21:12 --> Language Class Initialized
INFO - 2024-12-16 16:21:12 --> Language Class Initialized
INFO - 2024-12-16 16:21:12 --> Config Class Initialized
INFO - 2024-12-16 16:21:12 --> Loader Class Initialized
INFO - 2024-12-16 16:21:12 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:12 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:12 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:12 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:12 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:12 --> Controller Class Initialized
INFO - 2024-12-16 16:21:25 --> Config Class Initialized
INFO - 2024-12-16 16:21:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:25 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:25 --> URI Class Initialized
INFO - 2024-12-16 16:21:25 --> Router Class Initialized
INFO - 2024-12-16 16:21:25 --> Output Class Initialized
INFO - 2024-12-16 16:21:25 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:25 --> Input Class Initialized
INFO - 2024-12-16 16:21:25 --> Language Class Initialized
INFO - 2024-12-16 16:21:25 --> Language Class Initialized
INFO - 2024-12-16 16:21:25 --> Config Class Initialized
INFO - 2024-12-16 16:21:25 --> Loader Class Initialized
INFO - 2024-12-16 16:21:25 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:25 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:25 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:25 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:25 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:25 --> Controller Class Initialized
INFO - 2024-12-16 16:21:25 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:21:26 --> Config Class Initialized
INFO - 2024-12-16 16:21:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:26 --> URI Class Initialized
INFO - 2024-12-16 16:21:26 --> Router Class Initialized
INFO - 2024-12-16 16:21:26 --> Output Class Initialized
INFO - 2024-12-16 16:21:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:26 --> Input Class Initialized
INFO - 2024-12-16 16:21:26 --> Language Class Initialized
INFO - 2024-12-16 16:21:26 --> Language Class Initialized
INFO - 2024-12-16 16:21:26 --> Config Class Initialized
INFO - 2024-12-16 16:21:26 --> Loader Class Initialized
INFO - 2024-12-16 16:21:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:26 --> Controller Class Initialized
INFO - 2024-12-16 16:21:26 --> Config Class Initialized
INFO - 2024-12-16 16:21:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:26 --> URI Class Initialized
INFO - 2024-12-16 16:21:26 --> Router Class Initialized
INFO - 2024-12-16 16:21:26 --> Output Class Initialized
INFO - 2024-12-16 16:21:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:26 --> Input Class Initialized
INFO - 2024-12-16 16:21:26 --> Language Class Initialized
INFO - 2024-12-16 16:21:26 --> Language Class Initialized
INFO - 2024-12-16 16:21:26 --> Config Class Initialized
INFO - 2024-12-16 16:21:26 --> Loader Class Initialized
INFO - 2024-12-16 16:21:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:26 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:26 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:26 --> Total execution time: 0.0348
INFO - 2024-12-16 16:21:36 --> Config Class Initialized
INFO - 2024-12-16 16:21:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:36 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:36 --> URI Class Initialized
INFO - 2024-12-16 16:21:36 --> Router Class Initialized
INFO - 2024-12-16 16:21:36 --> Output Class Initialized
INFO - 2024-12-16 16:21:36 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:36 --> Input Class Initialized
INFO - 2024-12-16 16:21:36 --> Language Class Initialized
INFO - 2024-12-16 16:21:36 --> Language Class Initialized
INFO - 2024-12-16 16:21:36 --> Config Class Initialized
INFO - 2024-12-16 16:21:36 --> Loader Class Initialized
INFO - 2024-12-16 16:21:36 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:36 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:36 --> Controller Class Initialized
INFO - 2024-12-16 16:21:36 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:21:36 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:36 --> Total execution time: 0.0303
INFO - 2024-12-16 16:21:36 --> Config Class Initialized
INFO - 2024-12-16 16:21:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:36 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:36 --> URI Class Initialized
INFO - 2024-12-16 16:21:36 --> Router Class Initialized
INFO - 2024-12-16 16:21:36 --> Output Class Initialized
INFO - 2024-12-16 16:21:36 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:36 --> Input Class Initialized
INFO - 2024-12-16 16:21:36 --> Language Class Initialized
INFO - 2024-12-16 16:21:36 --> Language Class Initialized
INFO - 2024-12-16 16:21:36 --> Config Class Initialized
INFO - 2024-12-16 16:21:36 --> Loader Class Initialized
INFO - 2024-12-16 16:21:36 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:36 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:36 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:36 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-16 16:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:36 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:36 --> Total execution time: 0.0386
INFO - 2024-12-16 16:21:50 --> Config Class Initialized
INFO - 2024-12-16 16:21:50 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:50 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:50 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:50 --> URI Class Initialized
INFO - 2024-12-16 16:21:50 --> Router Class Initialized
INFO - 2024-12-16 16:21:50 --> Output Class Initialized
INFO - 2024-12-16 16:21:50 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:50 --> Input Class Initialized
INFO - 2024-12-16 16:21:50 --> Language Class Initialized
INFO - 2024-12-16 16:21:50 --> Language Class Initialized
INFO - 2024-12-16 16:21:50 --> Config Class Initialized
INFO - 2024-12-16 16:21:50 --> Loader Class Initialized
INFO - 2024-12-16 16:21:50 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:50 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:50 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:50 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:50 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:50 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-16 16:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:50 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:50 --> Total execution time: 0.0918
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:59 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:59 --> URI Class Initialized
INFO - 2024-12-16 16:21:59 --> Router Class Initialized
INFO - 2024-12-16 16:21:59 --> Output Class Initialized
INFO - 2024-12-16 16:21:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:59 --> Input Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Loader Class Initialized
INFO - 2024-12-16 16:21:59 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:59 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:59 --> Controller Class Initialized
INFO - 2024-12-16 16:21:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:59 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:59 --> URI Class Initialized
INFO - 2024-12-16 16:21:59 --> Router Class Initialized
INFO - 2024-12-16 16:21:59 --> Output Class Initialized
INFO - 2024-12-16 16:21:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:59 --> Input Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Loader Class Initialized
INFO - 2024-12-16 16:21:59 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:59 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:59 --> Controller Class Initialized
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:21:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:21:59 --> Utf8 Class Initialized
INFO - 2024-12-16 16:21:59 --> URI Class Initialized
INFO - 2024-12-16 16:21:59 --> Router Class Initialized
INFO - 2024-12-16 16:21:59 --> Output Class Initialized
INFO - 2024-12-16 16:21:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:21:59 --> Input Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Language Class Initialized
INFO - 2024-12-16 16:21:59 --> Config Class Initialized
INFO - 2024-12-16 16:21:59 --> Loader Class Initialized
INFO - 2024-12-16 16:21:59 --> Helper loaded: url_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: file_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: form_helper
INFO - 2024-12-16 16:21:59 --> Helper loaded: my_helper
INFO - 2024-12-16 16:21:59 --> Database Driver Class Initialized
INFO - 2024-12-16 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:21:59 --> Controller Class Initialized
DEBUG - 2024-12-16 16:21:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-16 16:21:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:21:59 --> Final output sent to browser
DEBUG - 2024-12-16 16:21:59 --> Total execution time: 0.0645
INFO - 2024-12-16 16:22:05 --> Config Class Initialized
INFO - 2024-12-16 16:22:05 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:05 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:05 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:05 --> URI Class Initialized
INFO - 2024-12-16 16:22:05 --> Router Class Initialized
INFO - 2024-12-16 16:22:05 --> Output Class Initialized
INFO - 2024-12-16 16:22:05 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:05 --> Input Class Initialized
INFO - 2024-12-16 16:22:05 --> Language Class Initialized
INFO - 2024-12-16 16:22:05 --> Language Class Initialized
INFO - 2024-12-16 16:22:05 --> Config Class Initialized
INFO - 2024-12-16 16:22:05 --> Loader Class Initialized
INFO - 2024-12-16 16:22:05 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:05 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:05 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:05 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:05 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:05 --> Controller Class Initialized
INFO - 2024-12-16 16:22:05 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:05 --> Total execution time: 0.0510
INFO - 2024-12-16 16:22:10 --> Config Class Initialized
INFO - 2024-12-16 16:22:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:10 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:10 --> URI Class Initialized
INFO - 2024-12-16 16:22:10 --> Router Class Initialized
INFO - 2024-12-16 16:22:10 --> Output Class Initialized
INFO - 2024-12-16 16:22:10 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:10 --> Input Class Initialized
INFO - 2024-12-16 16:22:10 --> Language Class Initialized
INFO - 2024-12-16 16:22:10 --> Language Class Initialized
INFO - 2024-12-16 16:22:10 --> Config Class Initialized
INFO - 2024-12-16 16:22:10 --> Loader Class Initialized
INFO - 2024-12-16 16:22:10 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:10 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:10 --> Controller Class Initialized
INFO - 2024-12-16 16:22:10 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:22:10 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:10 --> Total execution time: 0.1320
INFO - 2024-12-16 16:22:10 --> Config Class Initialized
INFO - 2024-12-16 16:22:10 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:10 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:10 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:10 --> URI Class Initialized
INFO - 2024-12-16 16:22:10 --> Router Class Initialized
INFO - 2024-12-16 16:22:10 --> Output Class Initialized
INFO - 2024-12-16 16:22:10 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:10 --> Input Class Initialized
INFO - 2024-12-16 16:22:10 --> Language Class Initialized
INFO - 2024-12-16 16:22:10 --> Language Class Initialized
INFO - 2024-12-16 16:22:10 --> Config Class Initialized
INFO - 2024-12-16 16:22:10 --> Loader Class Initialized
INFO - 2024-12-16 16:22:10 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:10 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:10 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:10 --> Controller Class Initialized
DEBUG - 2024-12-16 16:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-16 16:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:22:10 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:10 --> Total execution time: 0.0908
INFO - 2024-12-16 16:22:13 --> Config Class Initialized
INFO - 2024-12-16 16:22:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:13 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:13 --> URI Class Initialized
INFO - 2024-12-16 16:22:13 --> Router Class Initialized
INFO - 2024-12-16 16:22:13 --> Output Class Initialized
INFO - 2024-12-16 16:22:13 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:13 --> Input Class Initialized
INFO - 2024-12-16 16:22:13 --> Language Class Initialized
INFO - 2024-12-16 16:22:13 --> Language Class Initialized
INFO - 2024-12-16 16:22:13 --> Config Class Initialized
INFO - 2024-12-16 16:22:13 --> Loader Class Initialized
INFO - 2024-12-16 16:22:13 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:13 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:13 --> Controller Class Initialized
DEBUG - 2024-12-16 16:22:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-12-16 16:22:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:22:13 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:13 --> Total execution time: 0.0291
INFO - 2024-12-16 16:22:13 --> Config Class Initialized
INFO - 2024-12-16 16:22:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:13 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:13 --> URI Class Initialized
INFO - 2024-12-16 16:22:13 --> Router Class Initialized
INFO - 2024-12-16 16:22:13 --> Output Class Initialized
INFO - 2024-12-16 16:22:13 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:13 --> Input Class Initialized
INFO - 2024-12-16 16:22:13 --> Language Class Initialized
ERROR - 2024-12-16 16:22:13 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:22:13 --> Config Class Initialized
INFO - 2024-12-16 16:22:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:13 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:13 --> URI Class Initialized
INFO - 2024-12-16 16:22:13 --> Router Class Initialized
INFO - 2024-12-16 16:22:13 --> Output Class Initialized
INFO - 2024-12-16 16:22:13 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:13 --> Input Class Initialized
INFO - 2024-12-16 16:22:13 --> Language Class Initialized
INFO - 2024-12-16 16:22:13 --> Language Class Initialized
INFO - 2024-12-16 16:22:13 --> Config Class Initialized
INFO - 2024-12-16 16:22:13 --> Loader Class Initialized
INFO - 2024-12-16 16:22:13 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:13 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:13 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:13 --> Controller Class Initialized
INFO - 2024-12-16 16:22:14 --> Config Class Initialized
INFO - 2024-12-16 16:22:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:14 --> URI Class Initialized
INFO - 2024-12-16 16:22:14 --> Router Class Initialized
INFO - 2024-12-16 16:22:14 --> Output Class Initialized
INFO - 2024-12-16 16:22:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:14 --> Input Class Initialized
INFO - 2024-12-16 16:22:14 --> Language Class Initialized
INFO - 2024-12-16 16:22:14 --> Language Class Initialized
INFO - 2024-12-16 16:22:14 --> Config Class Initialized
INFO - 2024-12-16 16:22:14 --> Loader Class Initialized
INFO - 2024-12-16 16:22:14 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:14 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:14 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:14 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:14 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:14 --> Controller Class Initialized
DEBUG - 2024-12-16 16:22:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:22:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:22:14 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:14 --> Total execution time: 0.0672
INFO - 2024-12-16 16:22:14 --> Config Class Initialized
INFO - 2024-12-16 16:22:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:14 --> URI Class Initialized
INFO - 2024-12-16 16:22:14 --> Router Class Initialized
INFO - 2024-12-16 16:22:14 --> Output Class Initialized
INFO - 2024-12-16 16:22:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:14 --> Input Class Initialized
INFO - 2024-12-16 16:22:14 --> Language Class Initialized
ERROR - 2024-12-16 16:22:14 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:22:15 --> Config Class Initialized
INFO - 2024-12-16 16:22:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:15 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:15 --> URI Class Initialized
INFO - 2024-12-16 16:22:15 --> Router Class Initialized
INFO - 2024-12-16 16:22:15 --> Output Class Initialized
INFO - 2024-12-16 16:22:15 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:15 --> Input Class Initialized
INFO - 2024-12-16 16:22:15 --> Language Class Initialized
INFO - 2024-12-16 16:22:15 --> Language Class Initialized
INFO - 2024-12-16 16:22:15 --> Config Class Initialized
INFO - 2024-12-16 16:22:15 --> Loader Class Initialized
INFO - 2024-12-16 16:22:15 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:15 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:15 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:15 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:15 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:15 --> Controller Class Initialized
INFO - 2024-12-16 16:22:18 --> Config Class Initialized
INFO - 2024-12-16 16:22:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:18 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:18 --> URI Class Initialized
INFO - 2024-12-16 16:22:18 --> Router Class Initialized
INFO - 2024-12-16 16:22:18 --> Output Class Initialized
INFO - 2024-12-16 16:22:18 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:18 --> Input Class Initialized
INFO - 2024-12-16 16:22:18 --> Language Class Initialized
INFO - 2024-12-16 16:22:18 --> Language Class Initialized
INFO - 2024-12-16 16:22:18 --> Config Class Initialized
INFO - 2024-12-16 16:22:18 --> Loader Class Initialized
INFO - 2024-12-16 16:22:18 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:18 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:18 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:18 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:18 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:18 --> Controller Class Initialized
INFO - 2024-12-16 16:22:19 --> Config Class Initialized
INFO - 2024-12-16 16:22:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:19 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:19 --> URI Class Initialized
INFO - 2024-12-16 16:22:19 --> Router Class Initialized
INFO - 2024-12-16 16:22:19 --> Output Class Initialized
INFO - 2024-12-16 16:22:19 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:19 --> Input Class Initialized
INFO - 2024-12-16 16:22:19 --> Language Class Initialized
INFO - 2024-12-16 16:22:19 --> Language Class Initialized
INFO - 2024-12-16 16:22:19 --> Config Class Initialized
INFO - 2024-12-16 16:22:19 --> Loader Class Initialized
INFO - 2024-12-16 16:22:19 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:19 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:19 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:19 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:19 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:19 --> Controller Class Initialized
INFO - 2024-12-16 16:22:26 --> Config Class Initialized
INFO - 2024-12-16 16:22:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:22:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:22:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:22:26 --> URI Class Initialized
INFO - 2024-12-16 16:22:26 --> Router Class Initialized
INFO - 2024-12-16 16:22:26 --> Output Class Initialized
INFO - 2024-12-16 16:22:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:22:26 --> Input Class Initialized
INFO - 2024-12-16 16:22:26 --> Language Class Initialized
INFO - 2024-12-16 16:22:26 --> Language Class Initialized
INFO - 2024-12-16 16:22:26 --> Config Class Initialized
INFO - 2024-12-16 16:22:26 --> Loader Class Initialized
INFO - 2024-12-16 16:22:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:22:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:22:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:22:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:22:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:22:26 --> Controller Class Initialized
INFO - 2024-12-16 16:22:26 --> Final output sent to browser
DEBUG - 2024-12-16 16:22:26 --> Total execution time: 0.0274
INFO - 2024-12-16 16:26:39 --> Config Class Initialized
INFO - 2024-12-16 16:26:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:39 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:39 --> URI Class Initialized
INFO - 2024-12-16 16:26:39 --> Router Class Initialized
INFO - 2024-12-16 16:26:39 --> Output Class Initialized
INFO - 2024-12-16 16:26:39 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:39 --> Input Class Initialized
INFO - 2024-12-16 16:26:39 --> Language Class Initialized
INFO - 2024-12-16 16:26:39 --> Language Class Initialized
INFO - 2024-12-16 16:26:39 --> Config Class Initialized
INFO - 2024-12-16 16:26:39 --> Loader Class Initialized
INFO - 2024-12-16 16:26:39 --> Helper loaded: url_helper
INFO - 2024-12-16 16:26:39 --> Helper loaded: file_helper
INFO - 2024-12-16 16:26:39 --> Helper loaded: form_helper
INFO - 2024-12-16 16:26:39 --> Helper loaded: my_helper
INFO - 2024-12-16 16:26:39 --> Database Driver Class Initialized
INFO - 2024-12-16 16:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:26:39 --> Controller Class Initialized
DEBUG - 2024-12-16 16:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:26:39 --> Final output sent to browser
DEBUG - 2024-12-16 16:26:39 --> Total execution time: 0.0300
INFO - 2024-12-16 16:26:40 --> Config Class Initialized
INFO - 2024-12-16 16:26:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:40 --> URI Class Initialized
INFO - 2024-12-16 16:26:40 --> Router Class Initialized
INFO - 2024-12-16 16:26:40 --> Output Class Initialized
INFO - 2024-12-16 16:26:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:40 --> Input Class Initialized
INFO - 2024-12-16 16:26:40 --> Language Class Initialized
ERROR - 2024-12-16 16:26:40 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:26:40 --> Config Class Initialized
INFO - 2024-12-16 16:26:40 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:40 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:40 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:40 --> URI Class Initialized
INFO - 2024-12-16 16:26:40 --> Router Class Initialized
INFO - 2024-12-16 16:26:40 --> Output Class Initialized
INFO - 2024-12-16 16:26:40 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:40 --> Input Class Initialized
INFO - 2024-12-16 16:26:40 --> Language Class Initialized
INFO - 2024-12-16 16:26:40 --> Language Class Initialized
INFO - 2024-12-16 16:26:40 --> Config Class Initialized
INFO - 2024-12-16 16:26:40 --> Loader Class Initialized
INFO - 2024-12-16 16:26:40 --> Helper loaded: url_helper
INFO - 2024-12-16 16:26:40 --> Helper loaded: file_helper
INFO - 2024-12-16 16:26:40 --> Helper loaded: form_helper
INFO - 2024-12-16 16:26:40 --> Helper loaded: my_helper
INFO - 2024-12-16 16:26:40 --> Database Driver Class Initialized
INFO - 2024-12-16 16:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:26:40 --> Controller Class Initialized
INFO - 2024-12-16 16:26:49 --> Config Class Initialized
INFO - 2024-12-16 16:26:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:49 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:49 --> URI Class Initialized
INFO - 2024-12-16 16:26:49 --> Router Class Initialized
INFO - 2024-12-16 16:26:49 --> Output Class Initialized
INFO - 2024-12-16 16:26:49 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:49 --> Input Class Initialized
INFO - 2024-12-16 16:26:49 --> Language Class Initialized
INFO - 2024-12-16 16:26:49 --> Language Class Initialized
INFO - 2024-12-16 16:26:49 --> Config Class Initialized
INFO - 2024-12-16 16:26:49 --> Loader Class Initialized
INFO - 2024-12-16 16:26:49 --> Helper loaded: url_helper
INFO - 2024-12-16 16:26:49 --> Helper loaded: file_helper
INFO - 2024-12-16 16:26:49 --> Helper loaded: form_helper
INFO - 2024-12-16 16:26:49 --> Helper loaded: my_helper
INFO - 2024-12-16 16:26:49 --> Database Driver Class Initialized
INFO - 2024-12-16 16:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:26:49 --> Controller Class Initialized
DEBUG - 2024-12-16 16:26:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-12-16 16:26:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:26:49 --> Final output sent to browser
DEBUG - 2024-12-16 16:26:49 --> Total execution time: 0.0324
INFO - 2024-12-16 16:26:58 --> Config Class Initialized
INFO - 2024-12-16 16:26:58 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:58 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:58 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:58 --> URI Class Initialized
INFO - 2024-12-16 16:26:58 --> Router Class Initialized
INFO - 2024-12-16 16:26:59 --> Output Class Initialized
INFO - 2024-12-16 16:26:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:59 --> Input Class Initialized
INFO - 2024-12-16 16:26:59 --> Language Class Initialized
INFO - 2024-12-16 16:26:59 --> Language Class Initialized
INFO - 2024-12-16 16:26:59 --> Config Class Initialized
INFO - 2024-12-16 16:26:59 --> Loader Class Initialized
INFO - 2024-12-16 16:26:59 --> Helper loaded: url_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: file_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: form_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: my_helper
INFO - 2024-12-16 16:26:59 --> Database Driver Class Initialized
INFO - 2024-12-16 16:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:26:59 --> Controller Class Initialized
DEBUG - 2024-12-16 16:26:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-16 16:26:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:26:59 --> Final output sent to browser
DEBUG - 2024-12-16 16:26:59 --> Total execution time: 0.0619
INFO - 2024-12-16 16:26:59 --> Config Class Initialized
INFO - 2024-12-16 16:26:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:59 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:59 --> URI Class Initialized
INFO - 2024-12-16 16:26:59 --> Router Class Initialized
INFO - 2024-12-16 16:26:59 --> Output Class Initialized
INFO - 2024-12-16 16:26:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:59 --> Input Class Initialized
INFO - 2024-12-16 16:26:59 --> Language Class Initialized
ERROR - 2024-12-16 16:26:59 --> 404 Page Not Found: /index
INFO - 2024-12-16 16:26:59 --> Config Class Initialized
INFO - 2024-12-16 16:26:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:26:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:26:59 --> Utf8 Class Initialized
INFO - 2024-12-16 16:26:59 --> URI Class Initialized
INFO - 2024-12-16 16:26:59 --> Router Class Initialized
INFO - 2024-12-16 16:26:59 --> Output Class Initialized
INFO - 2024-12-16 16:26:59 --> Security Class Initialized
DEBUG - 2024-12-16 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:26:59 --> Input Class Initialized
INFO - 2024-12-16 16:26:59 --> Language Class Initialized
INFO - 2024-12-16 16:26:59 --> Language Class Initialized
INFO - 2024-12-16 16:26:59 --> Config Class Initialized
INFO - 2024-12-16 16:26:59 --> Loader Class Initialized
INFO - 2024-12-16 16:26:59 --> Helper loaded: url_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: file_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: form_helper
INFO - 2024-12-16 16:26:59 --> Helper loaded: my_helper
INFO - 2024-12-16 16:26:59 --> Database Driver Class Initialized
INFO - 2024-12-16 16:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:26:59 --> Controller Class Initialized
INFO - 2024-12-16 16:27:02 --> Config Class Initialized
INFO - 2024-12-16 16:27:02 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:27:02 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:27:02 --> Utf8 Class Initialized
INFO - 2024-12-16 16:27:02 --> URI Class Initialized
INFO - 2024-12-16 16:27:02 --> Router Class Initialized
INFO - 2024-12-16 16:27:02 --> Output Class Initialized
INFO - 2024-12-16 16:27:02 --> Security Class Initialized
DEBUG - 2024-12-16 16:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:27:02 --> Input Class Initialized
INFO - 2024-12-16 16:27:02 --> Language Class Initialized
INFO - 2024-12-16 16:27:02 --> Language Class Initialized
INFO - 2024-12-16 16:27:02 --> Config Class Initialized
INFO - 2024-12-16 16:27:02 --> Loader Class Initialized
INFO - 2024-12-16 16:27:02 --> Helper loaded: url_helper
INFO - 2024-12-16 16:27:02 --> Helper loaded: file_helper
INFO - 2024-12-16 16:27:02 --> Helper loaded: form_helper
INFO - 2024-12-16 16:27:02 --> Helper loaded: my_helper
INFO - 2024-12-16 16:27:02 --> Database Driver Class Initialized
INFO - 2024-12-16 16:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:27:02 --> Controller Class Initialized
DEBUG - 2024-12-16 16:27:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-16 16:27:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:27:02 --> Final output sent to browser
DEBUG - 2024-12-16 16:27:02 --> Total execution time: 0.0373
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:27:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:27:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:27:26 --> URI Class Initialized
INFO - 2024-12-16 16:27:26 --> Router Class Initialized
INFO - 2024-12-16 16:27:26 --> Output Class Initialized
INFO - 2024-12-16 16:27:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:27:26 --> Input Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Loader Class Initialized
INFO - 2024-12-16 16:27:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:27:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:27:26 --> Controller Class Initialized
INFO - 2024-12-16 16:27:26 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:27:26 --> Final output sent to browser
DEBUG - 2024-12-16 16:27:26 --> Total execution time: 0.0614
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:27:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:27:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:27:26 --> URI Class Initialized
INFO - 2024-12-16 16:27:26 --> Router Class Initialized
INFO - 2024-12-16 16:27:26 --> Output Class Initialized
INFO - 2024-12-16 16:27:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:27:26 --> Input Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Loader Class Initialized
INFO - 2024-12-16 16:27:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:27:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:27:26 --> Controller Class Initialized
INFO - 2024-12-16 16:27:26 --> Helper loaded: cookie_helper
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:27:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:27:26 --> Utf8 Class Initialized
INFO - 2024-12-16 16:27:26 --> URI Class Initialized
INFO - 2024-12-16 16:27:26 --> Router Class Initialized
INFO - 2024-12-16 16:27:26 --> Output Class Initialized
INFO - 2024-12-16 16:27:26 --> Security Class Initialized
DEBUG - 2024-12-16 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:27:26 --> Input Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Language Class Initialized
INFO - 2024-12-16 16:27:26 --> Config Class Initialized
INFO - 2024-12-16 16:27:26 --> Loader Class Initialized
INFO - 2024-12-16 16:27:26 --> Helper loaded: url_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: file_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: form_helper
INFO - 2024-12-16 16:27:26 --> Helper loaded: my_helper
INFO - 2024-12-16 16:27:26 --> Database Driver Class Initialized
INFO - 2024-12-16 16:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:27:26 --> Controller Class Initialized
DEBUG - 2024-12-16 16:27:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 16:27:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 16:27:26 --> Final output sent to browser
DEBUG - 2024-12-16 16:27:26 --> Total execution time: 0.0675
INFO - 2024-12-16 16:27:35 --> Config Class Initialized
INFO - 2024-12-16 16:27:35 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:27:35 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:27:35 --> Utf8 Class Initialized
INFO - 2024-12-16 16:27:35 --> URI Class Initialized
INFO - 2024-12-16 16:27:35 --> Router Class Initialized
INFO - 2024-12-16 16:27:35 --> Output Class Initialized
INFO - 2024-12-16 16:27:35 --> Security Class Initialized
DEBUG - 2024-12-16 16:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:27:35 --> Input Class Initialized
INFO - 2024-12-16 16:27:35 --> Language Class Initialized
INFO - 2024-12-16 16:27:35 --> Language Class Initialized
INFO - 2024-12-16 16:27:35 --> Config Class Initialized
INFO - 2024-12-16 16:27:35 --> Loader Class Initialized
INFO - 2024-12-16 16:27:35 --> Helper loaded: url_helper
INFO - 2024-12-16 16:27:35 --> Helper loaded: file_helper
INFO - 2024-12-16 16:27:35 --> Helper loaded: form_helper
INFO - 2024-12-16 16:27:35 --> Helper loaded: my_helper
INFO - 2024-12-16 16:27:35 --> Database Driver Class Initialized
INFO - 2024-12-16 16:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:27:35 --> Controller Class Initialized
DEBUG - 2024-12-16 16:27:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 16:27:38 --> Final output sent to browser
DEBUG - 2024-12-16 16:27:38 --> Total execution time: 3.0750
INFO - 2024-12-16 16:28:13 --> Config Class Initialized
INFO - 2024-12-16 16:28:13 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:28:13 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:28:13 --> Utf8 Class Initialized
INFO - 2024-12-16 16:28:13 --> URI Class Initialized
INFO - 2024-12-16 16:28:13 --> Router Class Initialized
INFO - 2024-12-16 16:28:13 --> Output Class Initialized
INFO - 2024-12-16 16:28:13 --> Security Class Initialized
DEBUG - 2024-12-16 16:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:28:13 --> Input Class Initialized
INFO - 2024-12-16 16:28:13 --> Language Class Initialized
INFO - 2024-12-16 16:28:13 --> Language Class Initialized
INFO - 2024-12-16 16:28:13 --> Config Class Initialized
INFO - 2024-12-16 16:28:13 --> Loader Class Initialized
INFO - 2024-12-16 16:28:13 --> Helper loaded: url_helper
INFO - 2024-12-16 16:28:13 --> Helper loaded: file_helper
INFO - 2024-12-16 16:28:13 --> Helper loaded: form_helper
INFO - 2024-12-16 16:28:13 --> Helper loaded: my_helper
INFO - 2024-12-16 16:28:13 --> Database Driver Class Initialized
INFO - 2024-12-16 16:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:28:13 --> Controller Class Initialized
DEBUG - 2024-12-16 16:28:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:28:19 --> Final output sent to browser
DEBUG - 2024-12-16 16:28:19 --> Total execution time: 5.2202
INFO - 2024-12-16 16:28:37 --> Config Class Initialized
INFO - 2024-12-16 16:28:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:28:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:28:37 --> Utf8 Class Initialized
INFO - 2024-12-16 16:28:37 --> URI Class Initialized
INFO - 2024-12-16 16:28:37 --> Router Class Initialized
INFO - 2024-12-16 16:28:37 --> Output Class Initialized
INFO - 2024-12-16 16:28:37 --> Security Class Initialized
DEBUG - 2024-12-16 16:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:28:37 --> Input Class Initialized
INFO - 2024-12-16 16:28:37 --> Language Class Initialized
INFO - 2024-12-16 16:28:37 --> Language Class Initialized
INFO - 2024-12-16 16:28:37 --> Config Class Initialized
INFO - 2024-12-16 16:28:37 --> Loader Class Initialized
INFO - 2024-12-16 16:28:37 --> Helper loaded: url_helper
INFO - 2024-12-16 16:28:37 --> Helper loaded: file_helper
INFO - 2024-12-16 16:28:37 --> Helper loaded: form_helper
INFO - 2024-12-16 16:28:37 --> Helper loaded: my_helper
INFO - 2024-12-16 16:28:37 --> Database Driver Class Initialized
INFO - 2024-12-16 16:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:28:37 --> Controller Class Initialized
DEBUG - 2024-12-16 16:28:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 16:28:40 --> Final output sent to browser
DEBUG - 2024-12-16 16:28:40 --> Total execution time: 2.9896
INFO - 2024-12-16 16:29:06 --> Config Class Initialized
INFO - 2024-12-16 16:29:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:29:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:29:06 --> Utf8 Class Initialized
INFO - 2024-12-16 16:29:06 --> URI Class Initialized
INFO - 2024-12-16 16:29:06 --> Router Class Initialized
INFO - 2024-12-16 16:29:06 --> Output Class Initialized
INFO - 2024-12-16 16:29:06 --> Security Class Initialized
DEBUG - 2024-12-16 16:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:29:06 --> Input Class Initialized
INFO - 2024-12-16 16:29:06 --> Language Class Initialized
INFO - 2024-12-16 16:29:06 --> Language Class Initialized
INFO - 2024-12-16 16:29:06 --> Config Class Initialized
INFO - 2024-12-16 16:29:06 --> Loader Class Initialized
INFO - 2024-12-16 16:29:06 --> Helper loaded: url_helper
INFO - 2024-12-16 16:29:06 --> Helper loaded: file_helper
INFO - 2024-12-16 16:29:06 --> Helper loaded: form_helper
INFO - 2024-12-16 16:29:06 --> Helper loaded: my_helper
INFO - 2024-12-16 16:29:06 --> Database Driver Class Initialized
INFO - 2024-12-16 16:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:29:06 --> Controller Class Initialized
DEBUG - 2024-12-16 16:29:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 16:29:12 --> Final output sent to browser
DEBUG - 2024-12-16 16:29:12 --> Total execution time: 5.5064
INFO - 2024-12-16 16:29:23 --> Config Class Initialized
INFO - 2024-12-16 16:29:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:29:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:29:23 --> Utf8 Class Initialized
INFO - 2024-12-16 16:29:23 --> URI Class Initialized
INFO - 2024-12-16 16:29:23 --> Router Class Initialized
INFO - 2024-12-16 16:29:23 --> Output Class Initialized
INFO - 2024-12-16 16:29:23 --> Security Class Initialized
DEBUG - 2024-12-16 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:29:23 --> Input Class Initialized
INFO - 2024-12-16 16:29:23 --> Language Class Initialized
INFO - 2024-12-16 16:29:23 --> Language Class Initialized
INFO - 2024-12-16 16:29:23 --> Config Class Initialized
INFO - 2024-12-16 16:29:23 --> Loader Class Initialized
INFO - 2024-12-16 16:29:23 --> Helper loaded: url_helper
INFO - 2024-12-16 16:29:23 --> Helper loaded: file_helper
INFO - 2024-12-16 16:29:23 --> Helper loaded: form_helper
INFO - 2024-12-16 16:29:23 --> Helper loaded: my_helper
INFO - 2024-12-16 16:29:23 --> Database Driver Class Initialized
INFO - 2024-12-16 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:29:23 --> Controller Class Initialized
DEBUG - 2024-12-16 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 16:29:26 --> Final output sent to browser
DEBUG - 2024-12-16 16:29:26 --> Total execution time: 3.0200
INFO - 2024-12-16 16:41:55 --> Config Class Initialized
INFO - 2024-12-16 16:41:55 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:41:55 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:41:55 --> Utf8 Class Initialized
INFO - 2024-12-16 16:41:55 --> URI Class Initialized
INFO - 2024-12-16 16:41:55 --> Router Class Initialized
INFO - 2024-12-16 16:41:55 --> Output Class Initialized
INFO - 2024-12-16 16:41:55 --> Security Class Initialized
DEBUG - 2024-12-16 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:41:55 --> Input Class Initialized
INFO - 2024-12-16 16:41:55 --> Language Class Initialized
INFO - 2024-12-16 16:41:55 --> Language Class Initialized
INFO - 2024-12-16 16:41:55 --> Config Class Initialized
INFO - 2024-12-16 16:41:55 --> Loader Class Initialized
INFO - 2024-12-16 16:41:55 --> Helper loaded: url_helper
INFO - 2024-12-16 16:41:55 --> Helper loaded: file_helper
INFO - 2024-12-16 16:41:55 --> Helper loaded: form_helper
INFO - 2024-12-16 16:41:55 --> Helper loaded: my_helper
INFO - 2024-12-16 16:41:55 --> Database Driver Class Initialized
INFO - 2024-12-16 16:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:41:55 --> Controller Class Initialized
DEBUG - 2024-12-16 16:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 16:41:57 --> Final output sent to browser
DEBUG - 2024-12-16 16:41:57 --> Total execution time: 1.7414
INFO - 2024-12-16 16:42:39 --> Config Class Initialized
INFO - 2024-12-16 16:42:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:42:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:42:39 --> Utf8 Class Initialized
INFO - 2024-12-16 16:42:39 --> URI Class Initialized
INFO - 2024-12-16 16:42:39 --> Router Class Initialized
INFO - 2024-12-16 16:42:39 --> Output Class Initialized
INFO - 2024-12-16 16:42:39 --> Security Class Initialized
DEBUG - 2024-12-16 16:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:42:39 --> Input Class Initialized
INFO - 2024-12-16 16:42:39 --> Language Class Initialized
INFO - 2024-12-16 16:42:39 --> Language Class Initialized
INFO - 2024-12-16 16:42:39 --> Config Class Initialized
INFO - 2024-12-16 16:42:39 --> Loader Class Initialized
INFO - 2024-12-16 16:42:39 --> Helper loaded: url_helper
INFO - 2024-12-16 16:42:39 --> Helper loaded: file_helper
INFO - 2024-12-16 16:42:39 --> Helper loaded: form_helper
INFO - 2024-12-16 16:42:39 --> Helper loaded: my_helper
INFO - 2024-12-16 16:42:39 --> Database Driver Class Initialized
INFO - 2024-12-16 16:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:42:39 --> Controller Class Initialized
ERROR - 2024-12-16 16:42:39 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 16:42:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 16:42:43 --> Final output sent to browser
DEBUG - 2024-12-16 16:42:43 --> Total execution time: 4.0425
INFO - 2024-12-16 16:43:14 --> Config Class Initialized
INFO - 2024-12-16 16:43:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:43:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:43:14 --> Utf8 Class Initialized
INFO - 2024-12-16 16:43:14 --> URI Class Initialized
INFO - 2024-12-16 16:43:14 --> Router Class Initialized
INFO - 2024-12-16 16:43:14 --> Output Class Initialized
INFO - 2024-12-16 16:43:14 --> Security Class Initialized
DEBUG - 2024-12-16 16:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:43:14 --> Input Class Initialized
INFO - 2024-12-16 16:43:14 --> Language Class Initialized
INFO - 2024-12-16 16:43:14 --> Language Class Initialized
INFO - 2024-12-16 16:43:14 --> Config Class Initialized
INFO - 2024-12-16 16:43:14 --> Loader Class Initialized
INFO - 2024-12-16 16:43:14 --> Helper loaded: url_helper
INFO - 2024-12-16 16:43:14 --> Helper loaded: file_helper
INFO - 2024-12-16 16:43:14 --> Helper loaded: form_helper
INFO - 2024-12-16 16:43:14 --> Helper loaded: my_helper
INFO - 2024-12-16 16:43:14 --> Database Driver Class Initialized
INFO - 2024-12-16 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:43:14 --> Controller Class Initialized
DEBUG - 2024-12-16 16:43:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 16:43:18 --> Final output sent to browser
DEBUG - 2024-12-16 16:43:18 --> Total execution time: 3.9458
INFO - 2024-12-16 16:43:29 --> Config Class Initialized
INFO - 2024-12-16 16:43:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:43:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:43:29 --> Utf8 Class Initialized
INFO - 2024-12-16 16:43:29 --> URI Class Initialized
INFO - 2024-12-16 16:43:29 --> Router Class Initialized
INFO - 2024-12-16 16:43:29 --> Output Class Initialized
INFO - 2024-12-16 16:43:29 --> Security Class Initialized
DEBUG - 2024-12-16 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:43:29 --> Input Class Initialized
INFO - 2024-12-16 16:43:29 --> Language Class Initialized
INFO - 2024-12-16 16:43:29 --> Language Class Initialized
INFO - 2024-12-16 16:43:29 --> Config Class Initialized
INFO - 2024-12-16 16:43:29 --> Loader Class Initialized
INFO - 2024-12-16 16:43:29 --> Helper loaded: url_helper
INFO - 2024-12-16 16:43:29 --> Helper loaded: file_helper
INFO - 2024-12-16 16:43:29 --> Helper loaded: form_helper
INFO - 2024-12-16 16:43:29 --> Helper loaded: my_helper
INFO - 2024-12-16 16:43:29 --> Database Driver Class Initialized
INFO - 2024-12-16 16:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:43:29 --> Controller Class Initialized
ERROR - 2024-12-16 16:43:29 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 16:43:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 16:43:33 --> Final output sent to browser
DEBUG - 2024-12-16 16:43:33 --> Total execution time: 3.7176
INFO - 2024-12-16 16:44:06 --> Config Class Initialized
INFO - 2024-12-16 16:44:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:44:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:44:06 --> Utf8 Class Initialized
INFO - 2024-12-16 16:44:06 --> URI Class Initialized
INFO - 2024-12-16 16:44:06 --> Router Class Initialized
INFO - 2024-12-16 16:44:06 --> Output Class Initialized
INFO - 2024-12-16 16:44:06 --> Security Class Initialized
DEBUG - 2024-12-16 16:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:44:06 --> Input Class Initialized
INFO - 2024-12-16 16:44:06 --> Language Class Initialized
INFO - 2024-12-16 16:44:06 --> Language Class Initialized
INFO - 2024-12-16 16:44:06 --> Config Class Initialized
INFO - 2024-12-16 16:44:06 --> Loader Class Initialized
INFO - 2024-12-16 16:44:06 --> Helper loaded: url_helper
INFO - 2024-12-16 16:44:06 --> Helper loaded: file_helper
INFO - 2024-12-16 16:44:06 --> Helper loaded: form_helper
INFO - 2024-12-16 16:44:06 --> Helper loaded: my_helper
INFO - 2024-12-16 16:44:06 --> Database Driver Class Initialized
INFO - 2024-12-16 16:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:44:06 --> Controller Class Initialized
DEBUG - 2024-12-16 16:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 16:44:10 --> Final output sent to browser
DEBUG - 2024-12-16 16:44:10 --> Total execution time: 4.0517
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:27:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:27:45 --> Utf8 Class Initialized
INFO - 2024-12-16 17:27:45 --> URI Class Initialized
INFO - 2024-12-16 17:27:45 --> Router Class Initialized
INFO - 2024-12-16 17:27:45 --> Output Class Initialized
INFO - 2024-12-16 17:27:45 --> Security Class Initialized
DEBUG - 2024-12-16 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:27:45 --> Input Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Loader Class Initialized
INFO - 2024-12-16 17:27:45 --> Helper loaded: url_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: file_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: form_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: my_helper
INFO - 2024-12-16 17:27:45 --> Database Driver Class Initialized
INFO - 2024-12-16 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:27:45 --> Controller Class Initialized
INFO - 2024-12-16 17:27:45 --> Helper loaded: cookie_helper
INFO - 2024-12-16 17:27:45 --> Final output sent to browser
DEBUG - 2024-12-16 17:27:45 --> Total execution time: 0.0538
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:27:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:27:45 --> Utf8 Class Initialized
INFO - 2024-12-16 17:27:45 --> URI Class Initialized
INFO - 2024-12-16 17:27:45 --> Router Class Initialized
INFO - 2024-12-16 17:27:45 --> Output Class Initialized
INFO - 2024-12-16 17:27:45 --> Security Class Initialized
DEBUG - 2024-12-16 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:27:45 --> Input Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Loader Class Initialized
INFO - 2024-12-16 17:27:45 --> Helper loaded: url_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: file_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: form_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: my_helper
INFO - 2024-12-16 17:27:45 --> Database Driver Class Initialized
INFO - 2024-12-16 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:27:45 --> Controller Class Initialized
INFO - 2024-12-16 17:27:45 --> Helper loaded: cookie_helper
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:27:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:27:45 --> Utf8 Class Initialized
INFO - 2024-12-16 17:27:45 --> URI Class Initialized
INFO - 2024-12-16 17:27:45 --> Router Class Initialized
INFO - 2024-12-16 17:27:45 --> Output Class Initialized
INFO - 2024-12-16 17:27:45 --> Security Class Initialized
DEBUG - 2024-12-16 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:27:45 --> Input Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Language Class Initialized
INFO - 2024-12-16 17:27:45 --> Config Class Initialized
INFO - 2024-12-16 17:27:45 --> Loader Class Initialized
INFO - 2024-12-16 17:27:45 --> Helper loaded: url_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: file_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: form_helper
INFO - 2024-12-16 17:27:45 --> Helper loaded: my_helper
INFO - 2024-12-16 17:27:45 --> Database Driver Class Initialized
INFO - 2024-12-16 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:27:45 --> Controller Class Initialized
DEBUG - 2024-12-16 17:27:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 17:27:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 17:27:45 --> Final output sent to browser
DEBUG - 2024-12-16 17:27:45 --> Total execution time: 0.0373
INFO - 2024-12-16 17:27:52 --> Config Class Initialized
INFO - 2024-12-16 17:27:52 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:27:52 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:27:52 --> Utf8 Class Initialized
INFO - 2024-12-16 17:27:52 --> URI Class Initialized
INFO - 2024-12-16 17:27:52 --> Router Class Initialized
INFO - 2024-12-16 17:27:52 --> Output Class Initialized
INFO - 2024-12-16 17:27:52 --> Security Class Initialized
DEBUG - 2024-12-16 17:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:27:52 --> Input Class Initialized
INFO - 2024-12-16 17:27:52 --> Language Class Initialized
INFO - 2024-12-16 17:27:52 --> Language Class Initialized
INFO - 2024-12-16 17:27:52 --> Config Class Initialized
INFO - 2024-12-16 17:27:52 --> Loader Class Initialized
INFO - 2024-12-16 17:27:52 --> Helper loaded: url_helper
INFO - 2024-12-16 17:27:52 --> Helper loaded: file_helper
INFO - 2024-12-16 17:27:52 --> Helper loaded: form_helper
INFO - 2024-12-16 17:27:52 --> Helper loaded: my_helper
INFO - 2024-12-16 17:27:52 --> Database Driver Class Initialized
INFO - 2024-12-16 17:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:27:52 --> Controller Class Initialized
DEBUG - 2024-12-16 17:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:27:57 --> Final output sent to browser
DEBUG - 2024-12-16 17:27:57 --> Total execution time: 4.9236
INFO - 2024-12-16 17:28:06 --> Config Class Initialized
INFO - 2024-12-16 17:28:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:28:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:28:06 --> Utf8 Class Initialized
INFO - 2024-12-16 17:28:06 --> URI Class Initialized
INFO - 2024-12-16 17:28:06 --> Router Class Initialized
INFO - 2024-12-16 17:28:06 --> Output Class Initialized
INFO - 2024-12-16 17:28:06 --> Security Class Initialized
DEBUG - 2024-12-16 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:28:06 --> Input Class Initialized
INFO - 2024-12-16 17:28:06 --> Language Class Initialized
INFO - 2024-12-16 17:28:07 --> Language Class Initialized
INFO - 2024-12-16 17:28:07 --> Config Class Initialized
INFO - 2024-12-16 17:28:07 --> Loader Class Initialized
INFO - 2024-12-16 17:28:07 --> Helper loaded: url_helper
INFO - 2024-12-16 17:28:07 --> Helper loaded: file_helper
INFO - 2024-12-16 17:28:07 --> Helper loaded: form_helper
INFO - 2024-12-16 17:28:07 --> Helper loaded: my_helper
INFO - 2024-12-16 17:28:07 --> Database Driver Class Initialized
INFO - 2024-12-16 17:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:28:07 --> Controller Class Initialized
DEBUG - 2024-12-16 17:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:28:08 --> Config Class Initialized
INFO - 2024-12-16 17:28:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:28:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:28:08 --> Utf8 Class Initialized
INFO - 2024-12-16 17:28:08 --> URI Class Initialized
INFO - 2024-12-16 17:28:08 --> Router Class Initialized
INFO - 2024-12-16 17:28:08 --> Output Class Initialized
INFO - 2024-12-16 17:28:08 --> Security Class Initialized
DEBUG - 2024-12-16 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:28:08 --> Input Class Initialized
INFO - 2024-12-16 17:28:08 --> Language Class Initialized
INFO - 2024-12-16 17:28:08 --> Language Class Initialized
INFO - 2024-12-16 17:28:08 --> Config Class Initialized
INFO - 2024-12-16 17:28:08 --> Loader Class Initialized
INFO - 2024-12-16 17:28:08 --> Helper loaded: url_helper
INFO - 2024-12-16 17:28:08 --> Helper loaded: file_helper
INFO - 2024-12-16 17:28:08 --> Helper loaded: form_helper
INFO - 2024-12-16 17:28:08 --> Helper loaded: my_helper
INFO - 2024-12-16 17:28:08 --> Database Driver Class Initialized
INFO - 2024-12-16 17:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:28:08 --> Controller Class Initialized
DEBUG - 2024-12-16 17:28:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:28:15 --> Final output sent to browser
DEBUG - 2024-12-16 17:28:15 --> Total execution time: 8.4643
INFO - 2024-12-16 17:28:17 --> Final output sent to browser
DEBUG - 2024-12-16 17:28:17 --> Total execution time: 8.3998
INFO - 2024-12-16 17:28:17 --> Config Class Initialized
INFO - 2024-12-16 17:28:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:28:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:28:17 --> Utf8 Class Initialized
INFO - 2024-12-16 17:28:17 --> URI Class Initialized
INFO - 2024-12-16 17:28:17 --> Router Class Initialized
INFO - 2024-12-16 17:28:17 --> Output Class Initialized
INFO - 2024-12-16 17:28:17 --> Security Class Initialized
DEBUG - 2024-12-16 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:28:17 --> Input Class Initialized
INFO - 2024-12-16 17:28:17 --> Language Class Initialized
INFO - 2024-12-16 17:28:17 --> Language Class Initialized
INFO - 2024-12-16 17:28:17 --> Config Class Initialized
INFO - 2024-12-16 17:28:17 --> Loader Class Initialized
INFO - 2024-12-16 17:28:17 --> Helper loaded: url_helper
INFO - 2024-12-16 17:28:17 --> Helper loaded: file_helper
INFO - 2024-12-16 17:28:17 --> Helper loaded: form_helper
INFO - 2024-12-16 17:28:17 --> Helper loaded: my_helper
INFO - 2024-12-16 17:28:17 --> Database Driver Class Initialized
INFO - 2024-12-16 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:28:17 --> Controller Class Initialized
DEBUG - 2024-12-16 17:28:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:28:22 --> Final output sent to browser
DEBUG - 2024-12-16 17:28:22 --> Total execution time: 5.1624
INFO - 2024-12-16 17:28:24 --> Config Class Initialized
INFO - 2024-12-16 17:28:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:28:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:28:24 --> Utf8 Class Initialized
INFO - 2024-12-16 17:28:24 --> URI Class Initialized
INFO - 2024-12-16 17:28:24 --> Router Class Initialized
INFO - 2024-12-16 17:28:24 --> Output Class Initialized
INFO - 2024-12-16 17:28:24 --> Security Class Initialized
DEBUG - 2024-12-16 17:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:28:24 --> Input Class Initialized
INFO - 2024-12-16 17:28:24 --> Language Class Initialized
INFO - 2024-12-16 17:28:24 --> Language Class Initialized
INFO - 2024-12-16 17:28:24 --> Config Class Initialized
INFO - 2024-12-16 17:28:24 --> Loader Class Initialized
INFO - 2024-12-16 17:28:24 --> Helper loaded: url_helper
INFO - 2024-12-16 17:28:24 --> Helper loaded: file_helper
INFO - 2024-12-16 17:28:24 --> Helper loaded: form_helper
INFO - 2024-12-16 17:28:24 --> Helper loaded: my_helper
INFO - 2024-12-16 17:28:24 --> Database Driver Class Initialized
INFO - 2024-12-16 17:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:28:24 --> Controller Class Initialized
DEBUG - 2024-12-16 17:28:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:28:29 --> Final output sent to browser
DEBUG - 2024-12-16 17:28:29 --> Total execution time: 4.7488
INFO - 2024-12-16 17:36:14 --> Config Class Initialized
INFO - 2024-12-16 17:36:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 17:36:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 17:36:14 --> Utf8 Class Initialized
INFO - 2024-12-16 17:36:14 --> URI Class Initialized
INFO - 2024-12-16 17:36:14 --> Router Class Initialized
INFO - 2024-12-16 17:36:14 --> Output Class Initialized
INFO - 2024-12-16 17:36:14 --> Security Class Initialized
DEBUG - 2024-12-16 17:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 17:36:14 --> Input Class Initialized
INFO - 2024-12-16 17:36:14 --> Language Class Initialized
INFO - 2024-12-16 17:36:14 --> Language Class Initialized
INFO - 2024-12-16 17:36:14 --> Config Class Initialized
INFO - 2024-12-16 17:36:14 --> Loader Class Initialized
INFO - 2024-12-16 17:36:14 --> Helper loaded: url_helper
INFO - 2024-12-16 17:36:14 --> Helper loaded: file_helper
INFO - 2024-12-16 17:36:14 --> Helper loaded: form_helper
INFO - 2024-12-16 17:36:14 --> Helper loaded: my_helper
INFO - 2024-12-16 17:36:14 --> Database Driver Class Initialized
INFO - 2024-12-16 17:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 17:36:14 --> Controller Class Initialized
DEBUG - 2024-12-16 17:36:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 17:36:18 --> Final output sent to browser
DEBUG - 2024-12-16 17:36:18 --> Total execution time: 4.4935
INFO - 2024-12-16 18:09:46 --> Config Class Initialized
INFO - 2024-12-16 18:09:46 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:09:46 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:09:46 --> Utf8 Class Initialized
INFO - 2024-12-16 18:09:46 --> URI Class Initialized
INFO - 2024-12-16 18:09:46 --> Router Class Initialized
INFO - 2024-12-16 18:09:46 --> Output Class Initialized
INFO - 2024-12-16 18:09:46 --> Security Class Initialized
DEBUG - 2024-12-16 18:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:09:46 --> Input Class Initialized
INFO - 2024-12-16 18:09:46 --> Language Class Initialized
INFO - 2024-12-16 18:09:46 --> Language Class Initialized
INFO - 2024-12-16 18:09:46 --> Config Class Initialized
INFO - 2024-12-16 18:09:46 --> Loader Class Initialized
INFO - 2024-12-16 18:09:46 --> Helper loaded: url_helper
INFO - 2024-12-16 18:09:46 --> Helper loaded: file_helper
INFO - 2024-12-16 18:09:46 --> Helper loaded: form_helper
INFO - 2024-12-16 18:09:46 --> Helper loaded: my_helper
INFO - 2024-12-16 18:09:46 --> Database Driver Class Initialized
INFO - 2024-12-16 18:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:09:46 --> Controller Class Initialized
INFO - 2024-12-16 18:09:46 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:09:46 --> Final output sent to browser
DEBUG - 2024-12-16 18:09:46 --> Total execution time: 0.0694
INFO - 2024-12-16 18:09:48 --> Config Class Initialized
INFO - 2024-12-16 18:09:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:09:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:09:48 --> Utf8 Class Initialized
INFO - 2024-12-16 18:09:48 --> URI Class Initialized
INFO - 2024-12-16 18:09:48 --> Router Class Initialized
INFO - 2024-12-16 18:09:48 --> Output Class Initialized
INFO - 2024-12-16 18:09:48 --> Security Class Initialized
DEBUG - 2024-12-16 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:09:48 --> Input Class Initialized
INFO - 2024-12-16 18:09:48 --> Language Class Initialized
INFO - 2024-12-16 18:09:48 --> Language Class Initialized
INFO - 2024-12-16 18:09:48 --> Config Class Initialized
INFO - 2024-12-16 18:09:48 --> Loader Class Initialized
INFO - 2024-12-16 18:09:48 --> Helper loaded: url_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: file_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: form_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: my_helper
INFO - 2024-12-16 18:09:48 --> Database Driver Class Initialized
INFO - 2024-12-16 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:09:48 --> Controller Class Initialized
INFO - 2024-12-16 18:09:48 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:09:48 --> Config Class Initialized
INFO - 2024-12-16 18:09:48 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:09:48 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:09:48 --> Utf8 Class Initialized
INFO - 2024-12-16 18:09:48 --> URI Class Initialized
INFO - 2024-12-16 18:09:48 --> Router Class Initialized
INFO - 2024-12-16 18:09:48 --> Output Class Initialized
INFO - 2024-12-16 18:09:48 --> Security Class Initialized
DEBUG - 2024-12-16 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:09:48 --> Input Class Initialized
INFO - 2024-12-16 18:09:48 --> Language Class Initialized
INFO - 2024-12-16 18:09:48 --> Language Class Initialized
INFO - 2024-12-16 18:09:48 --> Config Class Initialized
INFO - 2024-12-16 18:09:48 --> Loader Class Initialized
INFO - 2024-12-16 18:09:48 --> Helper loaded: url_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: file_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: form_helper
INFO - 2024-12-16 18:09:48 --> Helper loaded: my_helper
INFO - 2024-12-16 18:09:48 --> Database Driver Class Initialized
INFO - 2024-12-16 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:09:48 --> Controller Class Initialized
DEBUG - 2024-12-16 18:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:09:48 --> Final output sent to browser
DEBUG - 2024-12-16 18:09:48 --> Total execution time: 0.0380
INFO - 2024-12-16 18:10:01 --> Config Class Initialized
INFO - 2024-12-16 18:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:10:01 --> Utf8 Class Initialized
INFO - 2024-12-16 18:10:01 --> URI Class Initialized
INFO - 2024-12-16 18:10:01 --> Router Class Initialized
INFO - 2024-12-16 18:10:01 --> Output Class Initialized
INFO - 2024-12-16 18:10:01 --> Security Class Initialized
DEBUG - 2024-12-16 18:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:10:01 --> Input Class Initialized
INFO - 2024-12-16 18:10:01 --> Language Class Initialized
INFO - 2024-12-16 18:10:01 --> Language Class Initialized
INFO - 2024-12-16 18:10:01 --> Config Class Initialized
INFO - 2024-12-16 18:10:01 --> Loader Class Initialized
INFO - 2024-12-16 18:10:01 --> Helper loaded: url_helper
INFO - 2024-12-16 18:10:01 --> Helper loaded: file_helper
INFO - 2024-12-16 18:10:01 --> Helper loaded: form_helper
INFO - 2024-12-16 18:10:01 --> Helper loaded: my_helper
INFO - 2024-12-16 18:10:01 --> Database Driver Class Initialized
INFO - 2024-12-16 18:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:10:01 --> Controller Class Initialized
DEBUG - 2024-12-16 18:10:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:10:07 --> Final output sent to browser
DEBUG - 2024-12-16 18:10:07 --> Total execution time: 6.2216
INFO - 2024-12-16 18:12:20 --> Config Class Initialized
INFO - 2024-12-16 18:12:20 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:12:20 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:12:20 --> Utf8 Class Initialized
INFO - 2024-12-16 18:12:20 --> URI Class Initialized
INFO - 2024-12-16 18:12:20 --> Router Class Initialized
INFO - 2024-12-16 18:12:20 --> Output Class Initialized
INFO - 2024-12-16 18:12:20 --> Security Class Initialized
DEBUG - 2024-12-16 18:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:12:20 --> Input Class Initialized
INFO - 2024-12-16 18:12:20 --> Language Class Initialized
INFO - 2024-12-16 18:12:20 --> Language Class Initialized
INFO - 2024-12-16 18:12:20 --> Config Class Initialized
INFO - 2024-12-16 18:12:20 --> Loader Class Initialized
INFO - 2024-12-16 18:12:20 --> Helper loaded: url_helper
INFO - 2024-12-16 18:12:20 --> Helper loaded: file_helper
INFO - 2024-12-16 18:12:20 --> Helper loaded: form_helper
INFO - 2024-12-16 18:12:20 --> Helper loaded: my_helper
INFO - 2024-12-16 18:12:20 --> Database Driver Class Initialized
INFO - 2024-12-16 18:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:12:20 --> Controller Class Initialized
DEBUG - 2024-12-16 18:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 18:12:22 --> Final output sent to browser
DEBUG - 2024-12-16 18:12:22 --> Total execution time: 1.8785
INFO - 2024-12-16 18:12:37 --> Config Class Initialized
INFO - 2024-12-16 18:12:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:12:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:12:37 --> Utf8 Class Initialized
INFO - 2024-12-16 18:12:37 --> URI Class Initialized
INFO - 2024-12-16 18:12:37 --> Router Class Initialized
INFO - 2024-12-16 18:12:37 --> Output Class Initialized
INFO - 2024-12-16 18:12:37 --> Security Class Initialized
DEBUG - 2024-12-16 18:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:12:37 --> Input Class Initialized
INFO - 2024-12-16 18:12:37 --> Language Class Initialized
INFO - 2024-12-16 18:12:37 --> Language Class Initialized
INFO - 2024-12-16 18:12:37 --> Config Class Initialized
INFO - 2024-12-16 18:12:37 --> Loader Class Initialized
INFO - 2024-12-16 18:12:37 --> Helper loaded: url_helper
INFO - 2024-12-16 18:12:37 --> Helper loaded: file_helper
INFO - 2024-12-16 18:12:37 --> Helper loaded: form_helper
INFO - 2024-12-16 18:12:37 --> Helper loaded: my_helper
INFO - 2024-12-16 18:12:37 --> Database Driver Class Initialized
INFO - 2024-12-16 18:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:12:37 --> Controller Class Initialized
DEBUG - 2024-12-16 18:12:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 18:12:40 --> Final output sent to browser
DEBUG - 2024-12-16 18:12:40 --> Total execution time: 3.5427
INFO - 2024-12-16 18:20:06 --> Config Class Initialized
INFO - 2024-12-16 18:20:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:20:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:20:06 --> Utf8 Class Initialized
INFO - 2024-12-16 18:20:06 --> URI Class Initialized
INFO - 2024-12-16 18:20:06 --> Router Class Initialized
INFO - 2024-12-16 18:20:06 --> Output Class Initialized
INFO - 2024-12-16 18:20:06 --> Security Class Initialized
DEBUG - 2024-12-16 18:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:20:06 --> Input Class Initialized
INFO - 2024-12-16 18:20:06 --> Language Class Initialized
INFO - 2024-12-16 18:20:06 --> Language Class Initialized
INFO - 2024-12-16 18:20:06 --> Config Class Initialized
INFO - 2024-12-16 18:20:06 --> Loader Class Initialized
INFO - 2024-12-16 18:20:06 --> Helper loaded: url_helper
INFO - 2024-12-16 18:20:06 --> Helper loaded: file_helper
INFO - 2024-12-16 18:20:06 --> Helper loaded: form_helper
INFO - 2024-12-16 18:20:06 --> Helper loaded: my_helper
INFO - 2024-12-16 18:20:06 --> Database Driver Class Initialized
INFO - 2024-12-16 18:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:20:06 --> Controller Class Initialized
DEBUG - 2024-12-16 18:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:20:12 --> Final output sent to browser
DEBUG - 2024-12-16 18:20:12 --> Total execution time: 5.6965
INFO - 2024-12-16 18:20:59 --> Config Class Initialized
INFO - 2024-12-16 18:20:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:20:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:20:59 --> Utf8 Class Initialized
INFO - 2024-12-16 18:20:59 --> URI Class Initialized
INFO - 2024-12-16 18:20:59 --> Router Class Initialized
INFO - 2024-12-16 18:20:59 --> Output Class Initialized
INFO - 2024-12-16 18:20:59 --> Security Class Initialized
DEBUG - 2024-12-16 18:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:20:59 --> Input Class Initialized
INFO - 2024-12-16 18:20:59 --> Language Class Initialized
INFO - 2024-12-16 18:20:59 --> Language Class Initialized
INFO - 2024-12-16 18:20:59 --> Config Class Initialized
INFO - 2024-12-16 18:20:59 --> Loader Class Initialized
INFO - 2024-12-16 18:20:59 --> Helper loaded: url_helper
INFO - 2024-12-16 18:20:59 --> Helper loaded: file_helper
INFO - 2024-12-16 18:20:59 --> Helper loaded: form_helper
INFO - 2024-12-16 18:20:59 --> Helper loaded: my_helper
INFO - 2024-12-16 18:20:59 --> Database Driver Class Initialized
INFO - 2024-12-16 18:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:20:59 --> Controller Class Initialized
INFO - 2024-12-16 18:20:59 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:20:59 --> Final output sent to browser
DEBUG - 2024-12-16 18:20:59 --> Total execution time: 0.0350
INFO - 2024-12-16 18:21:00 --> Config Class Initialized
INFO - 2024-12-16 18:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:00 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:00 --> URI Class Initialized
INFO - 2024-12-16 18:21:00 --> Router Class Initialized
INFO - 2024-12-16 18:21:00 --> Output Class Initialized
INFO - 2024-12-16 18:21:00 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:00 --> Input Class Initialized
INFO - 2024-12-16 18:21:00 --> Language Class Initialized
INFO - 2024-12-16 18:21:00 --> Language Class Initialized
INFO - 2024-12-16 18:21:00 --> Config Class Initialized
INFO - 2024-12-16 18:21:00 --> Loader Class Initialized
INFO - 2024-12-16 18:21:00 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:00 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:00 --> Controller Class Initialized
INFO - 2024-12-16 18:21:00 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:21:00 --> Config Class Initialized
INFO - 2024-12-16 18:21:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:00 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:00 --> URI Class Initialized
INFO - 2024-12-16 18:21:00 --> Router Class Initialized
INFO - 2024-12-16 18:21:00 --> Output Class Initialized
INFO - 2024-12-16 18:21:00 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:00 --> Input Class Initialized
INFO - 2024-12-16 18:21:00 --> Language Class Initialized
INFO - 2024-12-16 18:21:00 --> Language Class Initialized
INFO - 2024-12-16 18:21:00 --> Config Class Initialized
INFO - 2024-12-16 18:21:00 --> Loader Class Initialized
INFO - 2024-12-16 18:21:00 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:00 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:00 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:00 --> Controller Class Initialized
DEBUG - 2024-12-16 18:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:21:00 --> Final output sent to browser
DEBUG - 2024-12-16 18:21:00 --> Total execution time: 0.0323
INFO - 2024-12-16 18:21:08 --> Config Class Initialized
INFO - 2024-12-16 18:21:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:08 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:08 --> URI Class Initialized
INFO - 2024-12-16 18:21:08 --> Router Class Initialized
INFO - 2024-12-16 18:21:08 --> Output Class Initialized
INFO - 2024-12-16 18:21:08 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:08 --> Input Class Initialized
INFO - 2024-12-16 18:21:08 --> Language Class Initialized
INFO - 2024-12-16 18:21:08 --> Language Class Initialized
INFO - 2024-12-16 18:21:08 --> Config Class Initialized
INFO - 2024-12-16 18:21:08 --> Loader Class Initialized
INFO - 2024-12-16 18:21:08 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:08 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:09 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:09 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:09 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:09 --> Controller Class Initialized
DEBUG - 2024-12-16 18:21:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:21:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:21:09 --> Final output sent to browser
DEBUG - 2024-12-16 18:21:09 --> Total execution time: 0.0686
INFO - 2024-12-16 18:21:18 --> Config Class Initialized
INFO - 2024-12-16 18:21:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:18 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:18 --> URI Class Initialized
DEBUG - 2024-12-16 18:21:18 --> No URI present. Default controller set.
INFO - 2024-12-16 18:21:18 --> Router Class Initialized
INFO - 2024-12-16 18:21:18 --> Output Class Initialized
INFO - 2024-12-16 18:21:18 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:18 --> Input Class Initialized
INFO - 2024-12-16 18:21:18 --> Language Class Initialized
INFO - 2024-12-16 18:21:18 --> Language Class Initialized
INFO - 2024-12-16 18:21:18 --> Config Class Initialized
INFO - 2024-12-16 18:21:18 --> Loader Class Initialized
INFO - 2024-12-16 18:21:18 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:18 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:18 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:18 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:18 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:18 --> Controller Class Initialized
DEBUG - 2024-12-16 18:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-12-16 18:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:21:18 --> Final output sent to browser
DEBUG - 2024-12-16 18:21:18 --> Total execution time: 0.0396
INFO - 2024-12-16 18:21:45 --> Config Class Initialized
INFO - 2024-12-16 18:21:45 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:45 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:45 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:45 --> URI Class Initialized
INFO - 2024-12-16 18:21:45 --> Router Class Initialized
INFO - 2024-12-16 18:21:45 --> Output Class Initialized
INFO - 2024-12-16 18:21:45 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:45 --> Input Class Initialized
INFO - 2024-12-16 18:21:45 --> Language Class Initialized
INFO - 2024-12-16 18:21:45 --> Language Class Initialized
INFO - 2024-12-16 18:21:45 --> Config Class Initialized
INFO - 2024-12-16 18:21:45 --> Loader Class Initialized
INFO - 2024-12-16 18:21:45 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:45 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:45 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:45 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:45 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:45 --> Controller Class Initialized
DEBUG - 2024-12-16 18:21:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:21:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:21:45 --> Final output sent to browser
DEBUG - 2024-12-16 18:21:45 --> Total execution time: 0.0428
INFO - 2024-12-16 18:21:54 --> Config Class Initialized
INFO - 2024-12-16 18:21:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:21:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:21:54 --> Utf8 Class Initialized
INFO - 2024-12-16 18:21:54 --> URI Class Initialized
INFO - 2024-12-16 18:21:54 --> Router Class Initialized
INFO - 2024-12-16 18:21:54 --> Output Class Initialized
INFO - 2024-12-16 18:21:54 --> Security Class Initialized
DEBUG - 2024-12-16 18:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:21:54 --> Input Class Initialized
INFO - 2024-12-16 18:21:54 --> Language Class Initialized
INFO - 2024-12-16 18:21:54 --> Language Class Initialized
INFO - 2024-12-16 18:21:54 --> Config Class Initialized
INFO - 2024-12-16 18:21:54 --> Loader Class Initialized
INFO - 2024-12-16 18:21:54 --> Helper loaded: url_helper
INFO - 2024-12-16 18:21:54 --> Helper loaded: file_helper
INFO - 2024-12-16 18:21:54 --> Helper loaded: form_helper
INFO - 2024-12-16 18:21:54 --> Helper loaded: my_helper
INFO - 2024-12-16 18:21:54 --> Database Driver Class Initialized
INFO - 2024-12-16 18:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:21:54 --> Controller Class Initialized
DEBUG - 2024-12-16 18:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 18:21:58 --> Final output sent to browser
DEBUG - 2024-12-16 18:21:58 --> Total execution time: 3.2615
INFO - 2024-12-16 18:22:59 --> Config Class Initialized
INFO - 2024-12-16 18:22:59 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:22:59 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:22:59 --> Utf8 Class Initialized
INFO - 2024-12-16 18:22:59 --> URI Class Initialized
INFO - 2024-12-16 18:22:59 --> Router Class Initialized
INFO - 2024-12-16 18:22:59 --> Output Class Initialized
INFO - 2024-12-16 18:22:59 --> Security Class Initialized
DEBUG - 2024-12-16 18:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:22:59 --> Input Class Initialized
INFO - 2024-12-16 18:22:59 --> Language Class Initialized
INFO - 2024-12-16 18:22:59 --> Language Class Initialized
INFO - 2024-12-16 18:22:59 --> Config Class Initialized
INFO - 2024-12-16 18:22:59 --> Loader Class Initialized
INFO - 2024-12-16 18:22:59 --> Helper loaded: url_helper
INFO - 2024-12-16 18:22:59 --> Helper loaded: file_helper
INFO - 2024-12-16 18:22:59 --> Helper loaded: form_helper
INFO - 2024-12-16 18:22:59 --> Helper loaded: my_helper
INFO - 2024-12-16 18:22:59 --> Database Driver Class Initialized
INFO - 2024-12-16 18:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:22:59 --> Controller Class Initialized
DEBUG - 2024-12-16 18:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 18:23:04 --> Final output sent to browser
DEBUG - 2024-12-16 18:23:04 --> Total execution time: 5.5531
INFO - 2024-12-16 18:23:11 --> Config Class Initialized
INFO - 2024-12-16 18:23:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:23:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:23:11 --> Utf8 Class Initialized
INFO - 2024-12-16 18:23:11 --> URI Class Initialized
INFO - 2024-12-16 18:23:11 --> Router Class Initialized
INFO - 2024-12-16 18:23:11 --> Output Class Initialized
INFO - 2024-12-16 18:23:11 --> Security Class Initialized
DEBUG - 2024-12-16 18:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:23:11 --> Input Class Initialized
INFO - 2024-12-16 18:23:11 --> Language Class Initialized
INFO - 2024-12-16 18:23:11 --> Language Class Initialized
INFO - 2024-12-16 18:23:11 --> Config Class Initialized
INFO - 2024-12-16 18:23:11 --> Loader Class Initialized
INFO - 2024-12-16 18:23:11 --> Helper loaded: url_helper
INFO - 2024-12-16 18:23:11 --> Helper loaded: file_helper
INFO - 2024-12-16 18:23:11 --> Helper loaded: form_helper
INFO - 2024-12-16 18:23:11 --> Helper loaded: my_helper
INFO - 2024-12-16 18:23:11 --> Database Driver Class Initialized
INFO - 2024-12-16 18:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:23:11 --> Controller Class Initialized
INFO - 2024-12-16 18:23:11 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:23:11 --> Final output sent to browser
DEBUG - 2024-12-16 18:23:11 --> Total execution time: 0.0401
INFO - 2024-12-16 18:23:12 --> Config Class Initialized
INFO - 2024-12-16 18:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:23:12 --> Utf8 Class Initialized
INFO - 2024-12-16 18:23:12 --> URI Class Initialized
INFO - 2024-12-16 18:23:12 --> Router Class Initialized
INFO - 2024-12-16 18:23:12 --> Output Class Initialized
INFO - 2024-12-16 18:23:12 --> Security Class Initialized
DEBUG - 2024-12-16 18:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:23:12 --> Input Class Initialized
INFO - 2024-12-16 18:23:12 --> Language Class Initialized
INFO - 2024-12-16 18:23:12 --> Language Class Initialized
INFO - 2024-12-16 18:23:12 --> Config Class Initialized
INFO - 2024-12-16 18:23:12 --> Loader Class Initialized
INFO - 2024-12-16 18:23:12 --> Helper loaded: url_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: file_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: form_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: my_helper
INFO - 2024-12-16 18:23:12 --> Database Driver Class Initialized
INFO - 2024-12-16 18:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:23:12 --> Controller Class Initialized
INFO - 2024-12-16 18:23:12 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:23:12 --> Config Class Initialized
INFO - 2024-12-16 18:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:23:12 --> Utf8 Class Initialized
INFO - 2024-12-16 18:23:12 --> URI Class Initialized
INFO - 2024-12-16 18:23:12 --> Router Class Initialized
INFO - 2024-12-16 18:23:12 --> Output Class Initialized
INFO - 2024-12-16 18:23:12 --> Security Class Initialized
DEBUG - 2024-12-16 18:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:23:12 --> Input Class Initialized
INFO - 2024-12-16 18:23:12 --> Language Class Initialized
INFO - 2024-12-16 18:23:12 --> Language Class Initialized
INFO - 2024-12-16 18:23:12 --> Config Class Initialized
INFO - 2024-12-16 18:23:12 --> Loader Class Initialized
INFO - 2024-12-16 18:23:12 --> Helper loaded: url_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: file_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: form_helper
INFO - 2024-12-16 18:23:12 --> Helper loaded: my_helper
INFO - 2024-12-16 18:23:12 --> Database Driver Class Initialized
INFO - 2024-12-16 18:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:23:12 --> Controller Class Initialized
DEBUG - 2024-12-16 18:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:23:12 --> Final output sent to browser
DEBUG - 2024-12-16 18:23:12 --> Total execution time: 0.0352
INFO - 2024-12-16 18:23:19 --> Config Class Initialized
INFO - 2024-12-16 18:23:19 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:23:19 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:23:19 --> Utf8 Class Initialized
INFO - 2024-12-16 18:23:19 --> URI Class Initialized
INFO - 2024-12-16 18:23:19 --> Router Class Initialized
INFO - 2024-12-16 18:23:19 --> Output Class Initialized
INFO - 2024-12-16 18:23:19 --> Security Class Initialized
DEBUG - 2024-12-16 18:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:23:19 --> Input Class Initialized
INFO - 2024-12-16 18:23:19 --> Language Class Initialized
INFO - 2024-12-16 18:23:19 --> Language Class Initialized
INFO - 2024-12-16 18:23:19 --> Config Class Initialized
INFO - 2024-12-16 18:23:19 --> Loader Class Initialized
INFO - 2024-12-16 18:23:19 --> Helper loaded: url_helper
INFO - 2024-12-16 18:23:19 --> Helper loaded: file_helper
INFO - 2024-12-16 18:23:19 --> Helper loaded: form_helper
INFO - 2024-12-16 18:23:19 --> Helper loaded: my_helper
INFO - 2024-12-16 18:23:19 --> Database Driver Class Initialized
INFO - 2024-12-16 18:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:23:19 --> Controller Class Initialized
DEBUG - 2024-12-16 18:23:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:23:24 --> Final output sent to browser
DEBUG - 2024-12-16 18:23:24 --> Total execution time: 5.0086
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:43:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:43:43 --> Utf8 Class Initialized
INFO - 2024-12-16 18:43:43 --> URI Class Initialized
INFO - 2024-12-16 18:43:43 --> Router Class Initialized
INFO - 2024-12-16 18:43:43 --> Output Class Initialized
INFO - 2024-12-16 18:43:43 --> Security Class Initialized
DEBUG - 2024-12-16 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:43:43 --> Input Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Loader Class Initialized
INFO - 2024-12-16 18:43:43 --> Helper loaded: url_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: file_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: form_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: my_helper
INFO - 2024-12-16 18:43:43 --> Database Driver Class Initialized
INFO - 2024-12-16 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:43:43 --> Controller Class Initialized
INFO - 2024-12-16 18:43:43 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:43:43 --> Final output sent to browser
DEBUG - 2024-12-16 18:43:43 --> Total execution time: 0.0642
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:43:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:43:43 --> Utf8 Class Initialized
INFO - 2024-12-16 18:43:43 --> URI Class Initialized
INFO - 2024-12-16 18:43:43 --> Router Class Initialized
INFO - 2024-12-16 18:43:43 --> Output Class Initialized
INFO - 2024-12-16 18:43:43 --> Security Class Initialized
DEBUG - 2024-12-16 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:43:43 --> Input Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Loader Class Initialized
INFO - 2024-12-16 18:43:43 --> Helper loaded: url_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: file_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: form_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: my_helper
INFO - 2024-12-16 18:43:43 --> Database Driver Class Initialized
INFO - 2024-12-16 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:43:43 --> Controller Class Initialized
INFO - 2024-12-16 18:43:43 --> Helper loaded: cookie_helper
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:43:43 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:43:43 --> Utf8 Class Initialized
INFO - 2024-12-16 18:43:43 --> URI Class Initialized
INFO - 2024-12-16 18:43:43 --> Router Class Initialized
INFO - 2024-12-16 18:43:43 --> Output Class Initialized
INFO - 2024-12-16 18:43:43 --> Security Class Initialized
DEBUG - 2024-12-16 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:43:43 --> Input Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Language Class Initialized
INFO - 2024-12-16 18:43:43 --> Config Class Initialized
INFO - 2024-12-16 18:43:43 --> Loader Class Initialized
INFO - 2024-12-16 18:43:43 --> Helper loaded: url_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: file_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: form_helper
INFO - 2024-12-16 18:43:43 --> Helper loaded: my_helper
INFO - 2024-12-16 18:43:43 --> Database Driver Class Initialized
INFO - 2024-12-16 18:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:43:44 --> Controller Class Initialized
DEBUG - 2024-12-16 18:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 18:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 18:43:44 --> Final output sent to browser
DEBUG - 2024-12-16 18:43:44 --> Total execution time: 0.3004
INFO - 2024-12-16 18:43:52 --> Config Class Initialized
INFO - 2024-12-16 18:43:52 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:43:52 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:43:52 --> Utf8 Class Initialized
INFO - 2024-12-16 18:43:52 --> URI Class Initialized
INFO - 2024-12-16 18:43:52 --> Router Class Initialized
INFO - 2024-12-16 18:43:52 --> Output Class Initialized
INFO - 2024-12-16 18:43:52 --> Security Class Initialized
DEBUG - 2024-12-16 18:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:43:52 --> Input Class Initialized
INFO - 2024-12-16 18:43:52 --> Language Class Initialized
INFO - 2024-12-16 18:43:52 --> Language Class Initialized
INFO - 2024-12-16 18:43:52 --> Config Class Initialized
INFO - 2024-12-16 18:43:52 --> Loader Class Initialized
INFO - 2024-12-16 18:43:52 --> Helper loaded: url_helper
INFO - 2024-12-16 18:43:52 --> Helper loaded: file_helper
INFO - 2024-12-16 18:43:52 --> Helper loaded: form_helper
INFO - 2024-12-16 18:43:52 --> Helper loaded: my_helper
INFO - 2024-12-16 18:43:52 --> Database Driver Class Initialized
INFO - 2024-12-16 18:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:43:52 --> Controller Class Initialized
ERROR - 2024-12-16 18:43:52 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 18:43:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 18:43:56 --> Final output sent to browser
DEBUG - 2024-12-16 18:43:56 --> Total execution time: 3.8666
INFO - 2024-12-16 18:44:28 --> Config Class Initialized
INFO - 2024-12-16 18:44:28 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:44:28 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:44:28 --> Utf8 Class Initialized
INFO - 2024-12-16 18:44:28 --> URI Class Initialized
INFO - 2024-12-16 18:44:28 --> Router Class Initialized
INFO - 2024-12-16 18:44:28 --> Output Class Initialized
INFO - 2024-12-16 18:44:28 --> Security Class Initialized
DEBUG - 2024-12-16 18:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:44:28 --> Input Class Initialized
INFO - 2024-12-16 18:44:28 --> Language Class Initialized
INFO - 2024-12-16 18:44:28 --> Language Class Initialized
INFO - 2024-12-16 18:44:28 --> Config Class Initialized
INFO - 2024-12-16 18:44:28 --> Loader Class Initialized
INFO - 2024-12-16 18:44:28 --> Helper loaded: url_helper
INFO - 2024-12-16 18:44:28 --> Helper loaded: file_helper
INFO - 2024-12-16 18:44:28 --> Helper loaded: form_helper
INFO - 2024-12-16 18:44:28 --> Helper loaded: my_helper
INFO - 2024-12-16 18:44:28 --> Database Driver Class Initialized
INFO - 2024-12-16 18:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:44:28 --> Controller Class Initialized
DEBUG - 2024-12-16 18:44:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 18:44:30 --> Final output sent to browser
DEBUG - 2024-12-16 18:44:30 --> Total execution time: 1.8134
INFO - 2024-12-16 18:57:23 --> Config Class Initialized
INFO - 2024-12-16 18:57:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:57:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:57:23 --> Utf8 Class Initialized
INFO - 2024-12-16 18:57:23 --> URI Class Initialized
INFO - 2024-12-16 18:57:23 --> Router Class Initialized
INFO - 2024-12-16 18:57:23 --> Output Class Initialized
INFO - 2024-12-16 18:57:23 --> Security Class Initialized
DEBUG - 2024-12-16 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:57:23 --> Input Class Initialized
INFO - 2024-12-16 18:57:23 --> Language Class Initialized
INFO - 2024-12-16 18:57:23 --> Language Class Initialized
INFO - 2024-12-16 18:57:23 --> Config Class Initialized
INFO - 2024-12-16 18:57:23 --> Loader Class Initialized
INFO - 2024-12-16 18:57:23 --> Helper loaded: url_helper
INFO - 2024-12-16 18:57:23 --> Helper loaded: file_helper
INFO - 2024-12-16 18:57:23 --> Helper loaded: form_helper
INFO - 2024-12-16 18:57:23 --> Helper loaded: my_helper
INFO - 2024-12-16 18:57:23 --> Database Driver Class Initialized
INFO - 2024-12-16 18:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:57:23 --> Controller Class Initialized
DEBUG - 2024-12-16 18:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:57:28 --> Final output sent to browser
DEBUG - 2024-12-16 18:57:28 --> Total execution time: 4.6990
INFO - 2024-12-16 18:57:57 --> Config Class Initialized
INFO - 2024-12-16 18:57:57 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:57:57 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:57:57 --> Utf8 Class Initialized
INFO - 2024-12-16 18:57:57 --> URI Class Initialized
INFO - 2024-12-16 18:57:57 --> Router Class Initialized
INFO - 2024-12-16 18:57:57 --> Output Class Initialized
INFO - 2024-12-16 18:57:57 --> Security Class Initialized
DEBUG - 2024-12-16 18:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:57:57 --> Input Class Initialized
INFO - 2024-12-16 18:57:57 --> Language Class Initialized
INFO - 2024-12-16 18:57:57 --> Language Class Initialized
INFO - 2024-12-16 18:57:57 --> Config Class Initialized
INFO - 2024-12-16 18:57:57 --> Loader Class Initialized
INFO - 2024-12-16 18:57:57 --> Helper loaded: url_helper
INFO - 2024-12-16 18:57:57 --> Helper loaded: file_helper
INFO - 2024-12-16 18:57:57 --> Helper loaded: form_helper
INFO - 2024-12-16 18:57:57 --> Helper loaded: my_helper
INFO - 2024-12-16 18:57:57 --> Database Driver Class Initialized
INFO - 2024-12-16 18:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:57:57 --> Controller Class Initialized
DEBUG - 2024-12-16 18:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:58:02 --> Final output sent to browser
DEBUG - 2024-12-16 18:58:02 --> Total execution time: 5.0888
INFO - 2024-12-16 18:58:04 --> Config Class Initialized
INFO - 2024-12-16 18:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:58:04 --> Utf8 Class Initialized
INFO - 2024-12-16 18:58:04 --> URI Class Initialized
INFO - 2024-12-16 18:58:04 --> Router Class Initialized
INFO - 2024-12-16 18:58:04 --> Output Class Initialized
INFO - 2024-12-16 18:58:04 --> Security Class Initialized
DEBUG - 2024-12-16 18:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:58:04 --> Input Class Initialized
INFO - 2024-12-16 18:58:04 --> Language Class Initialized
INFO - 2024-12-16 18:58:04 --> Language Class Initialized
INFO - 2024-12-16 18:58:04 --> Config Class Initialized
INFO - 2024-12-16 18:58:04 --> Loader Class Initialized
INFO - 2024-12-16 18:58:04 --> Helper loaded: url_helper
INFO - 2024-12-16 18:58:04 --> Helper loaded: file_helper
INFO - 2024-12-16 18:58:04 --> Helper loaded: form_helper
INFO - 2024-12-16 18:58:04 --> Helper loaded: my_helper
INFO - 2024-12-16 18:58:04 --> Database Driver Class Initialized
INFO - 2024-12-16 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:58:04 --> Controller Class Initialized
DEBUG - 2024-12-16 18:58:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:58:08 --> Final output sent to browser
DEBUG - 2024-12-16 18:58:08 --> Total execution time: 4.3472
INFO - 2024-12-16 18:58:33 --> Config Class Initialized
INFO - 2024-12-16 18:58:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:58:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:58:33 --> Utf8 Class Initialized
INFO - 2024-12-16 18:58:33 --> URI Class Initialized
INFO - 2024-12-16 18:58:33 --> Router Class Initialized
INFO - 2024-12-16 18:58:33 --> Output Class Initialized
INFO - 2024-12-16 18:58:33 --> Security Class Initialized
DEBUG - 2024-12-16 18:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:58:33 --> Input Class Initialized
INFO - 2024-12-16 18:58:33 --> Language Class Initialized
INFO - 2024-12-16 18:58:33 --> Language Class Initialized
INFO - 2024-12-16 18:58:33 --> Config Class Initialized
INFO - 2024-12-16 18:58:33 --> Loader Class Initialized
INFO - 2024-12-16 18:58:33 --> Helper loaded: url_helper
INFO - 2024-12-16 18:58:33 --> Helper loaded: file_helper
INFO - 2024-12-16 18:58:33 --> Helper loaded: form_helper
INFO - 2024-12-16 18:58:33 --> Helper loaded: my_helper
INFO - 2024-12-16 18:58:33 --> Database Driver Class Initialized
INFO - 2024-12-16 18:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:58:33 --> Controller Class Initialized
DEBUG - 2024-12-16 18:58:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:58:37 --> Final output sent to browser
DEBUG - 2024-12-16 18:58:37 --> Total execution time: 4.5153
INFO - 2024-12-16 18:59:00 --> Config Class Initialized
INFO - 2024-12-16 18:59:00 --> Hooks Class Initialized
DEBUG - 2024-12-16 18:59:00 --> UTF-8 Support Enabled
INFO - 2024-12-16 18:59:00 --> Utf8 Class Initialized
INFO - 2024-12-16 18:59:00 --> URI Class Initialized
INFO - 2024-12-16 18:59:00 --> Router Class Initialized
INFO - 2024-12-16 18:59:00 --> Output Class Initialized
INFO - 2024-12-16 18:59:00 --> Security Class Initialized
DEBUG - 2024-12-16 18:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 18:59:00 --> Input Class Initialized
INFO - 2024-12-16 18:59:00 --> Language Class Initialized
INFO - 2024-12-16 18:59:00 --> Language Class Initialized
INFO - 2024-12-16 18:59:00 --> Config Class Initialized
INFO - 2024-12-16 18:59:00 --> Loader Class Initialized
INFO - 2024-12-16 18:59:00 --> Helper loaded: url_helper
INFO - 2024-12-16 18:59:00 --> Helper loaded: file_helper
INFO - 2024-12-16 18:59:00 --> Helper loaded: form_helper
INFO - 2024-12-16 18:59:00 --> Helper loaded: my_helper
INFO - 2024-12-16 18:59:00 --> Database Driver Class Initialized
INFO - 2024-12-16 18:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 18:59:00 --> Controller Class Initialized
DEBUG - 2024-12-16 18:59:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 18:59:05 --> Final output sent to browser
DEBUG - 2024-12-16 18:59:05 --> Total execution time: 5.5710
INFO - 2024-12-16 19:00:36 --> Config Class Initialized
INFO - 2024-12-16 19:00:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:00:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:00:36 --> Utf8 Class Initialized
INFO - 2024-12-16 19:00:36 --> URI Class Initialized
INFO - 2024-12-16 19:00:36 --> Router Class Initialized
INFO - 2024-12-16 19:00:36 --> Output Class Initialized
INFO - 2024-12-16 19:00:36 --> Security Class Initialized
DEBUG - 2024-12-16 19:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:00:36 --> Input Class Initialized
INFO - 2024-12-16 19:00:36 --> Language Class Initialized
INFO - 2024-12-16 19:00:36 --> Language Class Initialized
INFO - 2024-12-16 19:00:36 --> Config Class Initialized
INFO - 2024-12-16 19:00:36 --> Loader Class Initialized
INFO - 2024-12-16 19:00:36 --> Helper loaded: url_helper
INFO - 2024-12-16 19:00:36 --> Helper loaded: file_helper
INFO - 2024-12-16 19:00:36 --> Helper loaded: form_helper
INFO - 2024-12-16 19:00:36 --> Helper loaded: my_helper
INFO - 2024-12-16 19:00:36 --> Database Driver Class Initialized
INFO - 2024-12-16 19:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:00:36 --> Controller Class Initialized
INFO - 2024-12-16 19:00:36 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:00:36 --> Final output sent to browser
DEBUG - 2024-12-16 19:00:36 --> Total execution time: 0.0537
INFO - 2024-12-16 19:00:37 --> Config Class Initialized
INFO - 2024-12-16 19:00:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:00:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:00:37 --> Utf8 Class Initialized
INFO - 2024-12-16 19:00:37 --> URI Class Initialized
INFO - 2024-12-16 19:00:37 --> Router Class Initialized
INFO - 2024-12-16 19:00:37 --> Output Class Initialized
INFO - 2024-12-16 19:00:37 --> Security Class Initialized
DEBUG - 2024-12-16 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:00:37 --> Input Class Initialized
INFO - 2024-12-16 19:00:37 --> Language Class Initialized
INFO - 2024-12-16 19:00:37 --> Language Class Initialized
INFO - 2024-12-16 19:00:37 --> Config Class Initialized
INFO - 2024-12-16 19:00:37 --> Loader Class Initialized
INFO - 2024-12-16 19:00:37 --> Helper loaded: url_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: file_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: form_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: my_helper
INFO - 2024-12-16 19:00:37 --> Database Driver Class Initialized
INFO - 2024-12-16 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:00:37 --> Controller Class Initialized
INFO - 2024-12-16 19:00:37 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:00:37 --> Config Class Initialized
INFO - 2024-12-16 19:00:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:00:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:00:37 --> Utf8 Class Initialized
INFO - 2024-12-16 19:00:37 --> URI Class Initialized
INFO - 2024-12-16 19:00:37 --> Router Class Initialized
INFO - 2024-12-16 19:00:37 --> Output Class Initialized
INFO - 2024-12-16 19:00:37 --> Security Class Initialized
DEBUG - 2024-12-16 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:00:37 --> Input Class Initialized
INFO - 2024-12-16 19:00:37 --> Language Class Initialized
INFO - 2024-12-16 19:00:37 --> Language Class Initialized
INFO - 2024-12-16 19:00:37 --> Config Class Initialized
INFO - 2024-12-16 19:00:37 --> Loader Class Initialized
INFO - 2024-12-16 19:00:37 --> Helper loaded: url_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: file_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: form_helper
INFO - 2024-12-16 19:00:37 --> Helper loaded: my_helper
INFO - 2024-12-16 19:00:37 --> Database Driver Class Initialized
INFO - 2024-12-16 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:00:37 --> Controller Class Initialized
DEBUG - 2024-12-16 19:00:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 19:00:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 19:00:37 --> Final output sent to browser
DEBUG - 2024-12-16 19:00:37 --> Total execution time: 0.0423
INFO - 2024-12-16 19:00:49 --> Config Class Initialized
INFO - 2024-12-16 19:00:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:00:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:00:49 --> Utf8 Class Initialized
INFO - 2024-12-16 19:00:49 --> URI Class Initialized
INFO - 2024-12-16 19:00:49 --> Router Class Initialized
INFO - 2024-12-16 19:00:49 --> Output Class Initialized
INFO - 2024-12-16 19:00:49 --> Security Class Initialized
DEBUG - 2024-12-16 19:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:00:49 --> Input Class Initialized
INFO - 2024-12-16 19:00:49 --> Language Class Initialized
INFO - 2024-12-16 19:00:49 --> Language Class Initialized
INFO - 2024-12-16 19:00:49 --> Config Class Initialized
INFO - 2024-12-16 19:00:49 --> Loader Class Initialized
INFO - 2024-12-16 19:00:49 --> Helper loaded: url_helper
INFO - 2024-12-16 19:00:49 --> Helper loaded: file_helper
INFO - 2024-12-16 19:00:49 --> Helper loaded: form_helper
INFO - 2024-12-16 19:00:49 --> Helper loaded: my_helper
INFO - 2024-12-16 19:00:49 --> Database Driver Class Initialized
INFO - 2024-12-16 19:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:00:49 --> Controller Class Initialized
DEBUG - 2024-12-16 19:00:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 19:00:54 --> Final output sent to browser
DEBUG - 2024-12-16 19:00:54 --> Total execution time: 5.1360
INFO - 2024-12-16 19:08:08 --> Config Class Initialized
INFO - 2024-12-16 19:08:08 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:08:08 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:08:08 --> Utf8 Class Initialized
INFO - 2024-12-16 19:08:08 --> URI Class Initialized
INFO - 2024-12-16 19:08:08 --> Router Class Initialized
INFO - 2024-12-16 19:08:08 --> Output Class Initialized
INFO - 2024-12-16 19:08:08 --> Security Class Initialized
DEBUG - 2024-12-16 19:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:08:08 --> Input Class Initialized
INFO - 2024-12-16 19:08:08 --> Language Class Initialized
INFO - 2024-12-16 19:08:08 --> Language Class Initialized
INFO - 2024-12-16 19:08:08 --> Config Class Initialized
INFO - 2024-12-16 19:08:08 --> Loader Class Initialized
INFO - 2024-12-16 19:08:08 --> Helper loaded: url_helper
INFO - 2024-12-16 19:08:08 --> Helper loaded: file_helper
INFO - 2024-12-16 19:08:08 --> Helper loaded: form_helper
INFO - 2024-12-16 19:08:08 --> Helper loaded: my_helper
INFO - 2024-12-16 19:08:08 --> Database Driver Class Initialized
INFO - 2024-12-16 19:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:08:08 --> Controller Class Initialized
INFO - 2024-12-16 19:08:08 --> Final output sent to browser
DEBUG - 2024-12-16 19:08:08 --> Total execution time: 0.0319
INFO - 2024-12-16 19:08:17 --> Config Class Initialized
INFO - 2024-12-16 19:08:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:08:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:08:17 --> Utf8 Class Initialized
INFO - 2024-12-16 19:08:17 --> URI Class Initialized
INFO - 2024-12-16 19:08:17 --> Router Class Initialized
INFO - 2024-12-16 19:08:17 --> Output Class Initialized
INFO - 2024-12-16 19:08:17 --> Security Class Initialized
DEBUG - 2024-12-16 19:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:08:17 --> Input Class Initialized
INFO - 2024-12-16 19:08:17 --> Language Class Initialized
INFO - 2024-12-16 19:08:17 --> Language Class Initialized
INFO - 2024-12-16 19:08:17 --> Config Class Initialized
INFO - 2024-12-16 19:08:17 --> Loader Class Initialized
INFO - 2024-12-16 19:08:17 --> Helper loaded: url_helper
INFO - 2024-12-16 19:08:17 --> Helper loaded: file_helper
INFO - 2024-12-16 19:08:17 --> Helper loaded: form_helper
INFO - 2024-12-16 19:08:17 --> Helper loaded: my_helper
INFO - 2024-12-16 19:08:17 --> Database Driver Class Initialized
INFO - 2024-12-16 19:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:08:17 --> Controller Class Initialized
INFO - 2024-12-16 19:08:17 --> Final output sent to browser
DEBUG - 2024-12-16 19:08:17 --> Total execution time: 0.0387
INFO - 2024-12-16 19:29:33 --> Config Class Initialized
INFO - 2024-12-16 19:29:33 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:29:33 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:29:33 --> Utf8 Class Initialized
INFO - 2024-12-16 19:29:33 --> URI Class Initialized
INFO - 2024-12-16 19:29:33 --> Router Class Initialized
INFO - 2024-12-16 19:29:33 --> Output Class Initialized
INFO - 2024-12-16 19:29:33 --> Security Class Initialized
DEBUG - 2024-12-16 19:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:29:33 --> Input Class Initialized
INFO - 2024-12-16 19:29:33 --> Language Class Initialized
INFO - 2024-12-16 19:29:33 --> Language Class Initialized
INFO - 2024-12-16 19:29:33 --> Config Class Initialized
INFO - 2024-12-16 19:29:33 --> Loader Class Initialized
INFO - 2024-12-16 19:29:33 --> Helper loaded: url_helper
INFO - 2024-12-16 19:29:33 --> Helper loaded: file_helper
INFO - 2024-12-16 19:29:33 --> Helper loaded: form_helper
INFO - 2024-12-16 19:29:33 --> Helper loaded: my_helper
INFO - 2024-12-16 19:29:33 --> Database Driver Class Initialized
INFO - 2024-12-16 19:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:29:33 --> Controller Class Initialized
INFO - 2024-12-16 19:29:33 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:29:33 --> Final output sent to browser
DEBUG - 2024-12-16 19:29:33 --> Total execution time: 0.0389
INFO - 2024-12-16 19:29:34 --> Config Class Initialized
INFO - 2024-12-16 19:29:34 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:29:34 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:29:34 --> Utf8 Class Initialized
INFO - 2024-12-16 19:29:34 --> URI Class Initialized
INFO - 2024-12-16 19:29:34 --> Router Class Initialized
INFO - 2024-12-16 19:29:34 --> Output Class Initialized
INFO - 2024-12-16 19:29:34 --> Security Class Initialized
DEBUG - 2024-12-16 19:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:29:34 --> Input Class Initialized
INFO - 2024-12-16 19:29:34 --> Language Class Initialized
INFO - 2024-12-16 19:29:34 --> Language Class Initialized
INFO - 2024-12-16 19:29:34 --> Config Class Initialized
INFO - 2024-12-16 19:29:34 --> Loader Class Initialized
INFO - 2024-12-16 19:29:34 --> Helper loaded: url_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: file_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: form_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: my_helper
INFO - 2024-12-16 19:29:34 --> Database Driver Class Initialized
INFO - 2024-12-16 19:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:29:34 --> Controller Class Initialized
INFO - 2024-12-16 19:29:34 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:29:34 --> Config Class Initialized
INFO - 2024-12-16 19:29:34 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:29:34 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:29:34 --> Utf8 Class Initialized
INFO - 2024-12-16 19:29:34 --> URI Class Initialized
INFO - 2024-12-16 19:29:34 --> Router Class Initialized
INFO - 2024-12-16 19:29:34 --> Output Class Initialized
INFO - 2024-12-16 19:29:34 --> Security Class Initialized
DEBUG - 2024-12-16 19:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:29:34 --> Input Class Initialized
INFO - 2024-12-16 19:29:34 --> Language Class Initialized
INFO - 2024-12-16 19:29:34 --> Language Class Initialized
INFO - 2024-12-16 19:29:34 --> Config Class Initialized
INFO - 2024-12-16 19:29:34 --> Loader Class Initialized
INFO - 2024-12-16 19:29:34 --> Helper loaded: url_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: file_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: form_helper
INFO - 2024-12-16 19:29:34 --> Helper loaded: my_helper
INFO - 2024-12-16 19:29:34 --> Database Driver Class Initialized
INFO - 2024-12-16 19:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:29:34 --> Controller Class Initialized
DEBUG - 2024-12-16 19:29:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 19:29:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 19:29:34 --> Final output sent to browser
DEBUG - 2024-12-16 19:29:34 --> Total execution time: 0.0310
INFO - 2024-12-16 19:29:37 --> Config Class Initialized
INFO - 2024-12-16 19:29:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:29:37 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:29:37 --> Utf8 Class Initialized
INFO - 2024-12-16 19:29:37 --> URI Class Initialized
INFO - 2024-12-16 19:29:37 --> Router Class Initialized
INFO - 2024-12-16 19:29:37 --> Output Class Initialized
INFO - 2024-12-16 19:29:37 --> Security Class Initialized
DEBUG - 2024-12-16 19:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:29:37 --> Input Class Initialized
INFO - 2024-12-16 19:29:37 --> Language Class Initialized
INFO - 2024-12-16 19:29:37 --> Language Class Initialized
INFO - 2024-12-16 19:29:37 --> Config Class Initialized
INFO - 2024-12-16 19:29:37 --> Loader Class Initialized
INFO - 2024-12-16 19:29:37 --> Helper loaded: url_helper
INFO - 2024-12-16 19:29:37 --> Helper loaded: file_helper
INFO - 2024-12-16 19:29:37 --> Helper loaded: form_helper
INFO - 2024-12-16 19:29:37 --> Helper loaded: my_helper
INFO - 2024-12-16 19:29:37 --> Database Driver Class Initialized
INFO - 2024-12-16 19:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:29:37 --> Controller Class Initialized
DEBUG - 2024-12-16 19:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 19:29:40 --> Final output sent to browser
DEBUG - 2024-12-16 19:29:40 --> Total execution time: 3.0648
INFO - 2024-12-16 19:32:34 --> Config Class Initialized
INFO - 2024-12-16 19:32:34 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:32:34 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:32:34 --> Utf8 Class Initialized
INFO - 2024-12-16 19:32:34 --> URI Class Initialized
INFO - 2024-12-16 19:32:34 --> Router Class Initialized
INFO - 2024-12-16 19:32:34 --> Output Class Initialized
INFO - 2024-12-16 19:32:34 --> Security Class Initialized
DEBUG - 2024-12-16 19:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:32:34 --> Input Class Initialized
INFO - 2024-12-16 19:32:34 --> Language Class Initialized
INFO - 2024-12-16 19:32:34 --> Language Class Initialized
INFO - 2024-12-16 19:32:34 --> Config Class Initialized
INFO - 2024-12-16 19:32:34 --> Loader Class Initialized
INFO - 2024-12-16 19:32:34 --> Helper loaded: url_helper
INFO - 2024-12-16 19:32:34 --> Helper loaded: file_helper
INFO - 2024-12-16 19:32:34 --> Helper loaded: form_helper
INFO - 2024-12-16 19:32:34 --> Helper loaded: my_helper
INFO - 2024-12-16 19:32:34 --> Database Driver Class Initialized
INFO - 2024-12-16 19:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:32:34 --> Controller Class Initialized
INFO - 2024-12-16 19:32:34 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:32:34 --> Final output sent to browser
DEBUG - 2024-12-16 19:32:34 --> Total execution time: 0.1323
INFO - 2024-12-16 19:32:35 --> Config Class Initialized
INFO - 2024-12-16 19:32:35 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:32:35 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:32:35 --> Utf8 Class Initialized
INFO - 2024-12-16 19:32:35 --> URI Class Initialized
INFO - 2024-12-16 19:32:35 --> Router Class Initialized
INFO - 2024-12-16 19:32:35 --> Output Class Initialized
INFO - 2024-12-16 19:32:35 --> Security Class Initialized
DEBUG - 2024-12-16 19:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:32:35 --> Input Class Initialized
INFO - 2024-12-16 19:32:35 --> Language Class Initialized
INFO - 2024-12-16 19:32:35 --> Language Class Initialized
INFO - 2024-12-16 19:32:35 --> Config Class Initialized
INFO - 2024-12-16 19:32:35 --> Loader Class Initialized
INFO - 2024-12-16 19:32:35 --> Helper loaded: url_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: file_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: form_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: my_helper
INFO - 2024-12-16 19:32:35 --> Database Driver Class Initialized
INFO - 2024-12-16 19:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:32:35 --> Controller Class Initialized
INFO - 2024-12-16 19:32:35 --> Helper loaded: cookie_helper
INFO - 2024-12-16 19:32:35 --> Config Class Initialized
INFO - 2024-12-16 19:32:35 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:32:35 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:32:35 --> Utf8 Class Initialized
INFO - 2024-12-16 19:32:35 --> URI Class Initialized
INFO - 2024-12-16 19:32:35 --> Router Class Initialized
INFO - 2024-12-16 19:32:35 --> Output Class Initialized
INFO - 2024-12-16 19:32:35 --> Security Class Initialized
DEBUG - 2024-12-16 19:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:32:35 --> Input Class Initialized
INFO - 2024-12-16 19:32:35 --> Language Class Initialized
INFO - 2024-12-16 19:32:35 --> Language Class Initialized
INFO - 2024-12-16 19:32:35 --> Config Class Initialized
INFO - 2024-12-16 19:32:35 --> Loader Class Initialized
INFO - 2024-12-16 19:32:35 --> Helper loaded: url_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: file_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: form_helper
INFO - 2024-12-16 19:32:35 --> Helper loaded: my_helper
INFO - 2024-12-16 19:32:35 --> Database Driver Class Initialized
INFO - 2024-12-16 19:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:32:35 --> Controller Class Initialized
DEBUG - 2024-12-16 19:32:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 19:32:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 19:32:35 --> Final output sent to browser
DEBUG - 2024-12-16 19:32:35 --> Total execution time: 0.0341
INFO - 2024-12-16 19:32:41 --> Config Class Initialized
INFO - 2024-12-16 19:32:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:32:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:32:41 --> Utf8 Class Initialized
INFO - 2024-12-16 19:32:41 --> URI Class Initialized
INFO - 2024-12-16 19:32:41 --> Router Class Initialized
INFO - 2024-12-16 19:32:41 --> Output Class Initialized
INFO - 2024-12-16 19:32:41 --> Security Class Initialized
DEBUG - 2024-12-16 19:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:32:41 --> Input Class Initialized
INFO - 2024-12-16 19:32:41 --> Language Class Initialized
INFO - 2024-12-16 19:32:41 --> Language Class Initialized
INFO - 2024-12-16 19:32:41 --> Config Class Initialized
INFO - 2024-12-16 19:32:41 --> Loader Class Initialized
INFO - 2024-12-16 19:32:41 --> Helper loaded: url_helper
INFO - 2024-12-16 19:32:41 --> Helper loaded: file_helper
INFO - 2024-12-16 19:32:41 --> Helper loaded: form_helper
INFO - 2024-12-16 19:32:41 --> Helper loaded: my_helper
INFO - 2024-12-16 19:32:41 --> Database Driver Class Initialized
INFO - 2024-12-16 19:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:32:41 --> Controller Class Initialized
DEBUG - 2024-12-16 19:32:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 19:32:44 --> Final output sent to browser
DEBUG - 2024-12-16 19:32:44 --> Total execution time: 3.0883
INFO - 2024-12-16 19:46:37 --> Config Class Initialized
INFO - 2024-12-16 19:46:37 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:46:38 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:46:38 --> Utf8 Class Initialized
INFO - 2024-12-16 19:46:38 --> URI Class Initialized
INFO - 2024-12-16 19:46:38 --> Router Class Initialized
INFO - 2024-12-16 19:46:38 --> Output Class Initialized
INFO - 2024-12-16 19:46:38 --> Security Class Initialized
DEBUG - 2024-12-16 19:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:46:38 --> Input Class Initialized
INFO - 2024-12-16 19:46:38 --> Language Class Initialized
INFO - 2024-12-16 19:46:38 --> Language Class Initialized
INFO - 2024-12-16 19:46:38 --> Config Class Initialized
INFO - 2024-12-16 19:46:38 --> Loader Class Initialized
INFO - 2024-12-16 19:46:38 --> Helper loaded: url_helper
INFO - 2024-12-16 19:46:38 --> Helper loaded: file_helper
INFO - 2024-12-16 19:46:38 --> Helper loaded: form_helper
INFO - 2024-12-16 19:46:38 --> Helper loaded: my_helper
INFO - 2024-12-16 19:46:38 --> Database Driver Class Initialized
INFO - 2024-12-16 19:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:46:38 --> Controller Class Initialized
ERROR - 2024-12-16 19:46:38 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 19:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 19:46:42 --> Final output sent to browser
DEBUG - 2024-12-16 19:46:42 --> Total execution time: 4.2248
INFO - 2024-12-16 19:48:39 --> Config Class Initialized
INFO - 2024-12-16 19:48:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:48:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:48:39 --> Utf8 Class Initialized
INFO - 2024-12-16 19:48:39 --> URI Class Initialized
INFO - 2024-12-16 19:48:39 --> Router Class Initialized
INFO - 2024-12-16 19:48:39 --> Output Class Initialized
INFO - 2024-12-16 19:48:39 --> Security Class Initialized
DEBUG - 2024-12-16 19:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:48:39 --> Input Class Initialized
INFO - 2024-12-16 19:48:39 --> Language Class Initialized
INFO - 2024-12-16 19:48:39 --> Language Class Initialized
INFO - 2024-12-16 19:48:39 --> Config Class Initialized
INFO - 2024-12-16 19:48:39 --> Loader Class Initialized
INFO - 2024-12-16 19:48:39 --> Helper loaded: url_helper
INFO - 2024-12-16 19:48:39 --> Helper loaded: file_helper
INFO - 2024-12-16 19:48:39 --> Helper loaded: form_helper
INFO - 2024-12-16 19:48:39 --> Helper loaded: my_helper
INFO - 2024-12-16 19:48:39 --> Database Driver Class Initialized
INFO - 2024-12-16 19:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:48:39 --> Controller Class Initialized
DEBUG - 2024-12-16 19:48:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-16 19:48:43 --> Final output sent to browser
DEBUG - 2024-12-16 19:48:43 --> Total execution time: 3.8260
INFO - 2024-12-16 19:49:06 --> Config Class Initialized
INFO - 2024-12-16 19:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:49:06 --> Utf8 Class Initialized
INFO - 2024-12-16 19:49:06 --> URI Class Initialized
INFO - 2024-12-16 19:49:06 --> Router Class Initialized
INFO - 2024-12-16 19:49:06 --> Output Class Initialized
INFO - 2024-12-16 19:49:06 --> Security Class Initialized
DEBUG - 2024-12-16 19:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:49:06 --> Input Class Initialized
INFO - 2024-12-16 19:49:06 --> Language Class Initialized
INFO - 2024-12-16 19:49:06 --> Language Class Initialized
INFO - 2024-12-16 19:49:06 --> Config Class Initialized
INFO - 2024-12-16 19:49:06 --> Loader Class Initialized
INFO - 2024-12-16 19:49:06 --> Helper loaded: url_helper
INFO - 2024-12-16 19:49:06 --> Helper loaded: file_helper
INFO - 2024-12-16 19:49:06 --> Helper loaded: form_helper
INFO - 2024-12-16 19:49:06 --> Helper loaded: my_helper
INFO - 2024-12-16 19:49:06 --> Database Driver Class Initialized
INFO - 2024-12-16 19:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:49:06 --> Controller Class Initialized
ERROR - 2024-12-16 19:49:06 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 19:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 19:49:10 --> Final output sent to browser
DEBUG - 2024-12-16 19:49:10 --> Total execution time: 3.2704
INFO - 2024-12-16 19:49:27 --> Config Class Initialized
INFO - 2024-12-16 19:49:27 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:49:27 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:49:27 --> Utf8 Class Initialized
INFO - 2024-12-16 19:49:27 --> URI Class Initialized
INFO - 2024-12-16 19:49:27 --> Router Class Initialized
INFO - 2024-12-16 19:49:27 --> Output Class Initialized
INFO - 2024-12-16 19:49:27 --> Security Class Initialized
DEBUG - 2024-12-16 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:49:27 --> Input Class Initialized
INFO - 2024-12-16 19:49:27 --> Language Class Initialized
INFO - 2024-12-16 19:49:27 --> Language Class Initialized
INFO - 2024-12-16 19:49:27 --> Config Class Initialized
INFO - 2024-12-16 19:49:27 --> Loader Class Initialized
INFO - 2024-12-16 19:49:27 --> Helper loaded: url_helper
INFO - 2024-12-16 19:49:27 --> Helper loaded: file_helper
INFO - 2024-12-16 19:49:27 --> Helper loaded: form_helper
INFO - 2024-12-16 19:49:27 --> Helper loaded: my_helper
INFO - 2024-12-16 19:49:27 --> Database Driver Class Initialized
INFO - 2024-12-16 19:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:49:27 --> Controller Class Initialized
DEBUG - 2024-12-16 19:49:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 19:49:30 --> Final output sent to browser
DEBUG - 2024-12-16 19:49:30 --> Total execution time: 2.7255
INFO - 2024-12-16 19:51:29 --> Config Class Initialized
INFO - 2024-12-16 19:51:29 --> Hooks Class Initialized
DEBUG - 2024-12-16 19:51:29 --> UTF-8 Support Enabled
INFO - 2024-12-16 19:51:29 --> Utf8 Class Initialized
INFO - 2024-12-16 19:51:29 --> URI Class Initialized
INFO - 2024-12-16 19:51:29 --> Router Class Initialized
INFO - 2024-12-16 19:51:29 --> Output Class Initialized
INFO - 2024-12-16 19:51:29 --> Security Class Initialized
DEBUG - 2024-12-16 19:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 19:51:29 --> Input Class Initialized
INFO - 2024-12-16 19:51:29 --> Language Class Initialized
INFO - 2024-12-16 19:51:29 --> Language Class Initialized
INFO - 2024-12-16 19:51:29 --> Config Class Initialized
INFO - 2024-12-16 19:51:29 --> Loader Class Initialized
INFO - 2024-12-16 19:51:29 --> Helper loaded: url_helper
INFO - 2024-12-16 19:51:29 --> Helper loaded: file_helper
INFO - 2024-12-16 19:51:29 --> Helper loaded: form_helper
INFO - 2024-12-16 19:51:29 --> Helper loaded: my_helper
INFO - 2024-12-16 19:51:29 --> Database Driver Class Initialized
INFO - 2024-12-16 19:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 19:51:29 --> Controller Class Initialized
DEBUG - 2024-12-16 19:51:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 19:51:30 --> Final output sent to browser
DEBUG - 2024-12-16 19:51:30 --> Total execution time: 1.8954
INFO - 2024-12-16 20:01:32 --> Config Class Initialized
INFO - 2024-12-16 20:01:32 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:01:32 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:01:32 --> Utf8 Class Initialized
INFO - 2024-12-16 20:01:32 --> URI Class Initialized
INFO - 2024-12-16 20:01:32 --> Router Class Initialized
INFO - 2024-12-16 20:01:32 --> Output Class Initialized
INFO - 2024-12-16 20:01:32 --> Security Class Initialized
DEBUG - 2024-12-16 20:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:01:32 --> Input Class Initialized
INFO - 2024-12-16 20:01:32 --> Language Class Initialized
INFO - 2024-12-16 20:01:32 --> Language Class Initialized
INFO - 2024-12-16 20:01:32 --> Config Class Initialized
INFO - 2024-12-16 20:01:32 --> Loader Class Initialized
INFO - 2024-12-16 20:01:32 --> Helper loaded: url_helper
INFO - 2024-12-16 20:01:32 --> Helper loaded: file_helper
INFO - 2024-12-16 20:01:32 --> Helper loaded: form_helper
INFO - 2024-12-16 20:01:32 --> Helper loaded: my_helper
INFO - 2024-12-16 20:01:32 --> Database Driver Class Initialized
INFO - 2024-12-16 20:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:01:32 --> Controller Class Initialized
DEBUG - 2024-12-16 20:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 20:01:37 --> Final output sent to browser
DEBUG - 2024-12-16 20:01:37 --> Total execution time: 5.0558
INFO - 2024-12-16 20:03:11 --> Config Class Initialized
INFO - 2024-12-16 20:03:11 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:03:11 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:03:11 --> Utf8 Class Initialized
INFO - 2024-12-16 20:03:11 --> URI Class Initialized
INFO - 2024-12-16 20:03:11 --> Router Class Initialized
INFO - 2024-12-16 20:03:11 --> Output Class Initialized
INFO - 2024-12-16 20:03:11 --> Security Class Initialized
DEBUG - 2024-12-16 20:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:03:11 --> Input Class Initialized
INFO - 2024-12-16 20:03:11 --> Language Class Initialized
INFO - 2024-12-16 20:03:11 --> Language Class Initialized
INFO - 2024-12-16 20:03:11 --> Config Class Initialized
INFO - 2024-12-16 20:03:11 --> Loader Class Initialized
INFO - 2024-12-16 20:03:11 --> Helper loaded: url_helper
INFO - 2024-12-16 20:03:11 --> Helper loaded: file_helper
INFO - 2024-12-16 20:03:11 --> Helper loaded: form_helper
INFO - 2024-12-16 20:03:11 --> Helper loaded: my_helper
INFO - 2024-12-16 20:03:11 --> Database Driver Class Initialized
INFO - 2024-12-16 20:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:03:11 --> Controller Class Initialized
DEBUG - 2024-12-16 20:03:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 20:03:13 --> Final output sent to browser
DEBUG - 2024-12-16 20:03:13 --> Total execution time: 1.8430
INFO - 2024-12-16 20:04:36 --> Config Class Initialized
INFO - 2024-12-16 20:04:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:04:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:04:36 --> Utf8 Class Initialized
INFO - 2024-12-16 20:04:36 --> URI Class Initialized
INFO - 2024-12-16 20:04:36 --> Router Class Initialized
INFO - 2024-12-16 20:04:36 --> Output Class Initialized
INFO - 2024-12-16 20:04:36 --> Security Class Initialized
DEBUG - 2024-12-16 20:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:04:36 --> Input Class Initialized
INFO - 2024-12-16 20:04:36 --> Language Class Initialized
INFO - 2024-12-16 20:04:36 --> Language Class Initialized
INFO - 2024-12-16 20:04:36 --> Config Class Initialized
INFO - 2024-12-16 20:04:36 --> Loader Class Initialized
INFO - 2024-12-16 20:04:36 --> Helper loaded: url_helper
INFO - 2024-12-16 20:04:36 --> Helper loaded: file_helper
INFO - 2024-12-16 20:04:36 --> Helper loaded: form_helper
INFO - 2024-12-16 20:04:36 --> Helper loaded: my_helper
INFO - 2024-12-16 20:04:36 --> Database Driver Class Initialized
INFO - 2024-12-16 20:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:04:36 --> Controller Class Initialized
INFO - 2024-12-16 20:04:36 --> Helper loaded: cookie_helper
INFO - 2024-12-16 20:04:36 --> Final output sent to browser
DEBUG - 2024-12-16 20:04:36 --> Total execution time: 0.0461
INFO - 2024-12-16 20:04:41 --> Config Class Initialized
INFO - 2024-12-16 20:04:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:04:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:04:41 --> Utf8 Class Initialized
INFO - 2024-12-16 20:04:41 --> URI Class Initialized
INFO - 2024-12-16 20:04:41 --> Router Class Initialized
INFO - 2024-12-16 20:04:41 --> Output Class Initialized
INFO - 2024-12-16 20:04:41 --> Security Class Initialized
DEBUG - 2024-12-16 20:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:04:41 --> Input Class Initialized
INFO - 2024-12-16 20:04:41 --> Language Class Initialized
INFO - 2024-12-16 20:04:41 --> Language Class Initialized
INFO - 2024-12-16 20:04:41 --> Config Class Initialized
INFO - 2024-12-16 20:04:41 --> Loader Class Initialized
INFO - 2024-12-16 20:04:41 --> Helper loaded: url_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: file_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: form_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: my_helper
INFO - 2024-12-16 20:04:41 --> Database Driver Class Initialized
INFO - 2024-12-16 20:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:04:41 --> Controller Class Initialized
INFO - 2024-12-16 20:04:41 --> Helper loaded: cookie_helper
INFO - 2024-12-16 20:04:41 --> Config Class Initialized
INFO - 2024-12-16 20:04:41 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:04:41 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:04:41 --> Utf8 Class Initialized
INFO - 2024-12-16 20:04:41 --> URI Class Initialized
INFO - 2024-12-16 20:04:41 --> Router Class Initialized
INFO - 2024-12-16 20:04:41 --> Output Class Initialized
INFO - 2024-12-16 20:04:41 --> Security Class Initialized
DEBUG - 2024-12-16 20:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:04:41 --> Input Class Initialized
INFO - 2024-12-16 20:04:41 --> Language Class Initialized
INFO - 2024-12-16 20:04:41 --> Language Class Initialized
INFO - 2024-12-16 20:04:41 --> Config Class Initialized
INFO - 2024-12-16 20:04:41 --> Loader Class Initialized
INFO - 2024-12-16 20:04:41 --> Helper loaded: url_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: file_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: form_helper
INFO - 2024-12-16 20:04:41 --> Helper loaded: my_helper
INFO - 2024-12-16 20:04:41 --> Database Driver Class Initialized
INFO - 2024-12-16 20:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:04:41 --> Controller Class Initialized
DEBUG - 2024-12-16 20:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 20:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 20:04:41 --> Final output sent to browser
DEBUG - 2024-12-16 20:04:41 --> Total execution time: 0.0329
INFO - 2024-12-16 20:04:49 --> Config Class Initialized
INFO - 2024-12-16 20:04:49 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:04:49 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:04:49 --> Utf8 Class Initialized
INFO - 2024-12-16 20:04:49 --> URI Class Initialized
INFO - 2024-12-16 20:04:49 --> Router Class Initialized
INFO - 2024-12-16 20:04:49 --> Output Class Initialized
INFO - 2024-12-16 20:04:49 --> Security Class Initialized
DEBUG - 2024-12-16 20:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:04:49 --> Input Class Initialized
INFO - 2024-12-16 20:04:49 --> Language Class Initialized
INFO - 2024-12-16 20:04:49 --> Language Class Initialized
INFO - 2024-12-16 20:04:49 --> Config Class Initialized
INFO - 2024-12-16 20:04:49 --> Loader Class Initialized
INFO - 2024-12-16 20:04:49 --> Helper loaded: url_helper
INFO - 2024-12-16 20:04:49 --> Helper loaded: file_helper
INFO - 2024-12-16 20:04:49 --> Helper loaded: form_helper
INFO - 2024-12-16 20:04:49 --> Helper loaded: my_helper
INFO - 2024-12-16 20:04:49 --> Database Driver Class Initialized
INFO - 2024-12-16 20:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:04:49 --> Controller Class Initialized
DEBUG - 2024-12-16 20:04:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 20:04:56 --> Final output sent to browser
DEBUG - 2024-12-16 20:04:56 --> Total execution time: 7.0370
INFO - 2024-12-16 20:05:16 --> Config Class Initialized
INFO - 2024-12-16 20:05:16 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:05:16 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:05:16 --> Utf8 Class Initialized
INFO - 2024-12-16 20:05:16 --> URI Class Initialized
INFO - 2024-12-16 20:05:16 --> Router Class Initialized
INFO - 2024-12-16 20:05:16 --> Output Class Initialized
INFO - 2024-12-16 20:05:16 --> Security Class Initialized
DEBUG - 2024-12-16 20:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:05:16 --> Input Class Initialized
INFO - 2024-12-16 20:05:16 --> Language Class Initialized
INFO - 2024-12-16 20:05:16 --> Language Class Initialized
INFO - 2024-12-16 20:05:16 --> Config Class Initialized
INFO - 2024-12-16 20:05:16 --> Loader Class Initialized
INFO - 2024-12-16 20:05:16 --> Helper loaded: url_helper
INFO - 2024-12-16 20:05:16 --> Helper loaded: file_helper
INFO - 2024-12-16 20:05:16 --> Helper loaded: form_helper
INFO - 2024-12-16 20:05:16 --> Helper loaded: my_helper
INFO - 2024-12-16 20:05:16 --> Database Driver Class Initialized
INFO - 2024-12-16 20:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:05:16 --> Controller Class Initialized
DEBUG - 2024-12-16 20:05:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-16 20:05:18 --> Final output sent to browser
DEBUG - 2024-12-16 20:05:18 --> Total execution time: 1.7493
INFO - 2024-12-16 20:05:36 --> Config Class Initialized
INFO - 2024-12-16 20:05:36 --> Hooks Class Initialized
DEBUG - 2024-12-16 20:05:36 --> UTF-8 Support Enabled
INFO - 2024-12-16 20:05:36 --> Utf8 Class Initialized
INFO - 2024-12-16 20:05:36 --> URI Class Initialized
INFO - 2024-12-16 20:05:36 --> Router Class Initialized
INFO - 2024-12-16 20:05:36 --> Output Class Initialized
INFO - 2024-12-16 20:05:36 --> Security Class Initialized
DEBUG - 2024-12-16 20:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 20:05:36 --> Input Class Initialized
INFO - 2024-12-16 20:05:36 --> Language Class Initialized
INFO - 2024-12-16 20:05:36 --> Language Class Initialized
INFO - 2024-12-16 20:05:36 --> Config Class Initialized
INFO - 2024-12-16 20:05:36 --> Loader Class Initialized
INFO - 2024-12-16 20:05:36 --> Helper loaded: url_helper
INFO - 2024-12-16 20:05:36 --> Helper loaded: file_helper
INFO - 2024-12-16 20:05:36 --> Helper loaded: form_helper
INFO - 2024-12-16 20:05:36 --> Helper loaded: my_helper
INFO - 2024-12-16 20:05:36 --> Database Driver Class Initialized
INFO - 2024-12-16 20:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 20:05:36 --> Controller Class Initialized
ERROR - 2024-12-16 20:05:36 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-12-16 20:05:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-12-16 20:05:40 --> Final output sent to browser
DEBUG - 2024-12-16 20:05:40 --> Total execution time: 3.3462
INFO - 2024-12-16 21:22:52 --> Config Class Initialized
INFO - 2024-12-16 21:22:52 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:52 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:52 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:52 --> URI Class Initialized
INFO - 2024-12-16 21:22:52 --> Router Class Initialized
INFO - 2024-12-16 21:22:52 --> Output Class Initialized
INFO - 2024-12-16 21:22:52 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:52 --> Input Class Initialized
INFO - 2024-12-16 21:22:52 --> Language Class Initialized
INFO - 2024-12-16 21:22:52 --> Language Class Initialized
INFO - 2024-12-16 21:22:52 --> Config Class Initialized
INFO - 2024-12-16 21:22:52 --> Loader Class Initialized
INFO - 2024-12-16 21:22:52 --> Helper loaded: url_helper
INFO - 2024-12-16 21:22:52 --> Helper loaded: file_helper
INFO - 2024-12-16 21:22:52 --> Helper loaded: form_helper
INFO - 2024-12-16 21:22:52 --> Helper loaded: my_helper
INFO - 2024-12-16 21:22:52 --> Database Driver Class Initialized
INFO - 2024-12-16 21:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:22:52 --> Controller Class Initialized
INFO - 2024-12-16 21:22:52 --> Helper loaded: cookie_helper
INFO - 2024-12-16 21:22:52 --> Final output sent to browser
DEBUG - 2024-12-16 21:22:52 --> Total execution time: 0.0658
INFO - 2024-12-16 21:22:53 --> Config Class Initialized
INFO - 2024-12-16 21:22:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:53 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:53 --> URI Class Initialized
INFO - 2024-12-16 21:22:53 --> Router Class Initialized
INFO - 2024-12-16 21:22:53 --> Output Class Initialized
INFO - 2024-12-16 21:22:53 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:53 --> Input Class Initialized
INFO - 2024-12-16 21:22:53 --> Language Class Initialized
INFO - 2024-12-16 21:22:53 --> Language Class Initialized
INFO - 2024-12-16 21:22:53 --> Config Class Initialized
INFO - 2024-12-16 21:22:53 --> Loader Class Initialized
INFO - 2024-12-16 21:22:53 --> Helper loaded: url_helper
INFO - 2024-12-16 21:22:53 --> Helper loaded: file_helper
INFO - 2024-12-16 21:22:53 --> Helper loaded: form_helper
INFO - 2024-12-16 21:22:53 --> Helper loaded: my_helper
INFO - 2024-12-16 21:22:53 --> Database Driver Class Initialized
INFO - 2024-12-16 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:22:54 --> Controller Class Initialized
INFO - 2024-12-16 21:22:54 --> Helper loaded: cookie_helper
INFO - 2024-12-16 21:22:54 --> Config Class Initialized
INFO - 2024-12-16 21:22:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:54 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:54 --> URI Class Initialized
INFO - 2024-12-16 21:22:54 --> Router Class Initialized
INFO - 2024-12-16 21:22:54 --> Output Class Initialized
INFO - 2024-12-16 21:22:54 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:54 --> Input Class Initialized
INFO - 2024-12-16 21:22:54 --> Language Class Initialized
INFO - 2024-12-16 21:22:54 --> Language Class Initialized
INFO - 2024-12-16 21:22:54 --> Config Class Initialized
INFO - 2024-12-16 21:22:54 --> Loader Class Initialized
INFO - 2024-12-16 21:22:54 --> Helper loaded: url_helper
INFO - 2024-12-16 21:22:54 --> Helper loaded: file_helper
INFO - 2024-12-16 21:22:54 --> Helper loaded: form_helper
INFO - 2024-12-16 21:22:54 --> Helper loaded: my_helper
INFO - 2024-12-16 21:22:54 --> Database Driver Class Initialized
INFO - 2024-12-16 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:22:54 --> Controller Class Initialized
DEBUG - 2024-12-16 21:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 21:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 21:22:54 --> Final output sent to browser
DEBUG - 2024-12-16 21:22:54 --> Total execution time: 0.0416
INFO - 2024-12-16 21:23:01 --> Config Class Initialized
INFO - 2024-12-16 21:23:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:23:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:23:01 --> Utf8 Class Initialized
INFO - 2024-12-16 21:23:01 --> URI Class Initialized
INFO - 2024-12-16 21:23:01 --> Router Class Initialized
INFO - 2024-12-16 21:23:01 --> Output Class Initialized
INFO - 2024-12-16 21:23:01 --> Security Class Initialized
DEBUG - 2024-12-16 21:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:23:01 --> Input Class Initialized
INFO - 2024-12-16 21:23:01 --> Language Class Initialized
INFO - 2024-12-16 21:23:01 --> Language Class Initialized
INFO - 2024-12-16 21:23:01 --> Config Class Initialized
INFO - 2024-12-16 21:23:01 --> Loader Class Initialized
INFO - 2024-12-16 21:23:01 --> Helper loaded: url_helper
INFO - 2024-12-16 21:23:01 --> Helper loaded: file_helper
INFO - 2024-12-16 21:23:01 --> Helper loaded: form_helper
INFO - 2024-12-16 21:23:01 --> Helper loaded: my_helper
INFO - 2024-12-16 21:23:01 --> Database Driver Class Initialized
INFO - 2024-12-16 21:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:23:01 --> Controller Class Initialized
DEBUG - 2024-12-16 21:23:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 21:23:05 --> Final output sent to browser
DEBUG - 2024-12-16 21:23:05 --> Total execution time: 4.2962
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:01 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:01 --> URI Class Initialized
INFO - 2024-12-16 22:10:01 --> Router Class Initialized
INFO - 2024-12-16 22:10:01 --> Output Class Initialized
INFO - 2024-12-16 22:10:01 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:01 --> Input Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Loader Class Initialized
INFO - 2024-12-16 22:10:01 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:01 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:01 --> Controller Class Initialized
INFO - 2024-12-16 22:10:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:10:01 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:01 --> Total execution time: 0.0661
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:01 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:01 --> URI Class Initialized
INFO - 2024-12-16 22:10:01 --> Router Class Initialized
INFO - 2024-12-16 22:10:01 --> Output Class Initialized
INFO - 2024-12-16 22:10:01 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:01 --> Input Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Loader Class Initialized
INFO - 2024-12-16 22:10:01 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:01 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:01 --> Controller Class Initialized
INFO - 2024-12-16 22:10:01 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:01 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:01 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:01 --> URI Class Initialized
INFO - 2024-12-16 22:10:01 --> Router Class Initialized
INFO - 2024-12-16 22:10:01 --> Output Class Initialized
INFO - 2024-12-16 22:10:01 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:01 --> Input Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Language Class Initialized
INFO - 2024-12-16 22:10:01 --> Config Class Initialized
INFO - 2024-12-16 22:10:01 --> Loader Class Initialized
INFO - 2024-12-16 22:10:01 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:01 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:02 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:02 --> Controller Class Initialized
DEBUG - 2024-12-16 22:10:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 22:10:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 22:10:02 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:02 --> Total execution time: 0.2823
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:15 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:15 --> URI Class Initialized
INFO - 2024-12-16 22:10:15 --> Router Class Initialized
INFO - 2024-12-16 22:10:15 --> Output Class Initialized
INFO - 2024-12-16 22:10:15 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:15 --> Input Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Loader Class Initialized
INFO - 2024-12-16 22:10:15 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:15 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:15 --> Controller Class Initialized
INFO - 2024-12-16 22:10:15 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:10:15 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:15 --> Total execution time: 0.0326
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:15 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:15 --> URI Class Initialized
INFO - 2024-12-16 22:10:15 --> Router Class Initialized
INFO - 2024-12-16 22:10:15 --> Output Class Initialized
INFO - 2024-12-16 22:10:15 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:15 --> Input Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Loader Class Initialized
INFO - 2024-12-16 22:10:15 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:15 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:15 --> Controller Class Initialized
INFO - 2024-12-16 22:10:15 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:15 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:15 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:15 --> URI Class Initialized
INFO - 2024-12-16 22:10:15 --> Router Class Initialized
INFO - 2024-12-16 22:10:15 --> Output Class Initialized
INFO - 2024-12-16 22:10:15 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:15 --> Input Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Language Class Initialized
INFO - 2024-12-16 22:10:15 --> Config Class Initialized
INFO - 2024-12-16 22:10:15 --> Loader Class Initialized
INFO - 2024-12-16 22:10:15 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:15 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:15 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:15 --> Controller Class Initialized
DEBUG - 2024-12-16 22:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 22:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 22:10:15 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:15 --> Total execution time: 0.0322
INFO - 2024-12-16 22:10:21 --> Config Class Initialized
INFO - 2024-12-16 22:10:21 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:21 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:21 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:21 --> URI Class Initialized
INFO - 2024-12-16 22:10:21 --> Router Class Initialized
INFO - 2024-12-16 22:10:21 --> Output Class Initialized
INFO - 2024-12-16 22:10:21 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:21 --> Input Class Initialized
INFO - 2024-12-16 22:10:21 --> Language Class Initialized
INFO - 2024-12-16 22:10:21 --> Language Class Initialized
INFO - 2024-12-16 22:10:21 --> Config Class Initialized
INFO - 2024-12-16 22:10:21 --> Loader Class Initialized
INFO - 2024-12-16 22:10:21 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:21 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:21 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:21 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:21 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:21 --> Controller Class Initialized
DEBUG - 2024-12-16 22:10:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 22:10:26 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:26 --> Total execution time: 4.5972
INFO - 2024-12-16 22:10:39 --> Config Class Initialized
INFO - 2024-12-16 22:10:39 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:10:39 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:10:39 --> Utf8 Class Initialized
INFO - 2024-12-16 22:10:39 --> URI Class Initialized
INFO - 2024-12-16 22:10:39 --> Router Class Initialized
INFO - 2024-12-16 22:10:39 --> Output Class Initialized
INFO - 2024-12-16 22:10:39 --> Security Class Initialized
DEBUG - 2024-12-16 22:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:10:39 --> Input Class Initialized
INFO - 2024-12-16 22:10:39 --> Language Class Initialized
INFO - 2024-12-16 22:10:39 --> Language Class Initialized
INFO - 2024-12-16 22:10:39 --> Config Class Initialized
INFO - 2024-12-16 22:10:39 --> Loader Class Initialized
INFO - 2024-12-16 22:10:39 --> Helper loaded: url_helper
INFO - 2024-12-16 22:10:39 --> Helper loaded: file_helper
INFO - 2024-12-16 22:10:39 --> Helper loaded: form_helper
INFO - 2024-12-16 22:10:39 --> Helper loaded: my_helper
INFO - 2024-12-16 22:10:39 --> Database Driver Class Initialized
INFO - 2024-12-16 22:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:10:39 --> Controller Class Initialized
DEBUG - 2024-12-16 22:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 22:10:44 --> Final output sent to browser
DEBUG - 2024-12-16 22:10:44 --> Total execution time: 4.6688
INFO - 2024-12-16 22:11:03 --> Config Class Initialized
INFO - 2024-12-16 22:11:03 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:11:03 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:11:03 --> Utf8 Class Initialized
INFO - 2024-12-16 22:11:03 --> URI Class Initialized
INFO - 2024-12-16 22:11:03 --> Router Class Initialized
INFO - 2024-12-16 22:11:03 --> Output Class Initialized
INFO - 2024-12-16 22:11:03 --> Security Class Initialized
DEBUG - 2024-12-16 22:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:11:03 --> Input Class Initialized
INFO - 2024-12-16 22:11:03 --> Language Class Initialized
INFO - 2024-12-16 22:11:03 --> Language Class Initialized
INFO - 2024-12-16 22:11:03 --> Config Class Initialized
INFO - 2024-12-16 22:11:03 --> Loader Class Initialized
INFO - 2024-12-16 22:11:03 --> Helper loaded: url_helper
INFO - 2024-12-16 22:11:03 --> Helper loaded: file_helper
INFO - 2024-12-16 22:11:03 --> Helper loaded: form_helper
INFO - 2024-12-16 22:11:03 --> Helper loaded: my_helper
INFO - 2024-12-16 22:11:03 --> Database Driver Class Initialized
INFO - 2024-12-16 22:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:11:03 --> Controller Class Initialized
DEBUG - 2024-12-16 22:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 22:11:08 --> Final output sent to browser
DEBUG - 2024-12-16 22:11:08 --> Total execution time: 4.8665
INFO - 2024-12-16 22:13:43 --> Config Class Initialized
INFO - 2024-12-16 22:13:43 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:44 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:44 --> URI Class Initialized
INFO - 2024-12-16 22:13:44 --> Router Class Initialized
INFO - 2024-12-16 22:13:44 --> Output Class Initialized
INFO - 2024-12-16 22:13:44 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:44 --> Input Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Loader Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:44 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:44 --> Controller Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:13:44 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:44 --> Total execution time: 0.0459
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:44 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:44 --> URI Class Initialized
INFO - 2024-12-16 22:13:44 --> Router Class Initialized
INFO - 2024-12-16 22:13:44 --> Output Class Initialized
INFO - 2024-12-16 22:13:44 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:44 --> Input Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Loader Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:44 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:44 --> Controller Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:44 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:44 --> URI Class Initialized
INFO - 2024-12-16 22:13:44 --> Router Class Initialized
INFO - 2024-12-16 22:13:44 --> Output Class Initialized
INFO - 2024-12-16 22:13:44 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:44 --> Input Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Loader Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:44 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:44 --> Controller Class Initialized
DEBUG - 2024-12-16 22:13:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 22:13:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 22:13:44 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:44 --> Total execution time: 0.0332
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:44 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:44 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:44 --> URI Class Initialized
INFO - 2024-12-16 22:13:44 --> Router Class Initialized
INFO - 2024-12-16 22:13:44 --> Output Class Initialized
INFO - 2024-12-16 22:13:44 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:44 --> Input Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Language Class Initialized
INFO - 2024-12-16 22:13:44 --> Config Class Initialized
INFO - 2024-12-16 22:13:44 --> Loader Class Initialized
INFO - 2024-12-16 22:13:44 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:44 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:44 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:44 --> Controller Class Initialized
DEBUG - 2024-12-16 22:13:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-16 22:13:47 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:47 --> Total execution time: 2.9337
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:53 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:53 --> URI Class Initialized
INFO - 2024-12-16 22:13:53 --> Router Class Initialized
INFO - 2024-12-16 22:13:53 --> Output Class Initialized
INFO - 2024-12-16 22:13:53 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:53 --> Input Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Loader Class Initialized
INFO - 2024-12-16 22:13:53 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:53 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:53 --> Controller Class Initialized
INFO - 2024-12-16 22:13:53 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:13:53 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:53 --> Total execution time: 0.0332
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:53 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:53 --> URI Class Initialized
INFO - 2024-12-16 22:13:53 --> Router Class Initialized
INFO - 2024-12-16 22:13:53 --> Output Class Initialized
INFO - 2024-12-16 22:13:53 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:53 --> Input Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Loader Class Initialized
INFO - 2024-12-16 22:13:53 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:53 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:53 --> Controller Class Initialized
INFO - 2024-12-16 22:13:53 --> Helper loaded: cookie_helper
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:53 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:53 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:53 --> URI Class Initialized
INFO - 2024-12-16 22:13:53 --> Router Class Initialized
INFO - 2024-12-16 22:13:53 --> Output Class Initialized
INFO - 2024-12-16 22:13:53 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:53 --> Input Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Language Class Initialized
INFO - 2024-12-16 22:13:53 --> Config Class Initialized
INFO - 2024-12-16 22:13:53 --> Loader Class Initialized
INFO - 2024-12-16 22:13:53 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:53 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:53 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:53 --> Controller Class Initialized
DEBUG - 2024-12-16 22:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-16 22:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-16 22:13:53 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:53 --> Total execution time: 0.0325
INFO - 2024-12-16 22:13:54 --> Config Class Initialized
INFO - 2024-12-16 22:13:54 --> Hooks Class Initialized
DEBUG - 2024-12-16 22:13:54 --> UTF-8 Support Enabled
INFO - 2024-12-16 22:13:54 --> Utf8 Class Initialized
INFO - 2024-12-16 22:13:54 --> URI Class Initialized
INFO - 2024-12-16 22:13:54 --> Router Class Initialized
INFO - 2024-12-16 22:13:54 --> Output Class Initialized
INFO - 2024-12-16 22:13:54 --> Security Class Initialized
DEBUG - 2024-12-16 22:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 22:13:54 --> Input Class Initialized
INFO - 2024-12-16 22:13:54 --> Language Class Initialized
INFO - 2024-12-16 22:13:54 --> Language Class Initialized
INFO - 2024-12-16 22:13:54 --> Config Class Initialized
INFO - 2024-12-16 22:13:54 --> Loader Class Initialized
INFO - 2024-12-16 22:13:54 --> Helper loaded: url_helper
INFO - 2024-12-16 22:13:54 --> Helper loaded: file_helper
INFO - 2024-12-16 22:13:54 --> Helper loaded: form_helper
INFO - 2024-12-16 22:13:54 --> Helper loaded: my_helper
INFO - 2024-12-16 22:13:54 --> Database Driver Class Initialized
INFO - 2024-12-16 22:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 22:13:54 --> Controller Class Initialized
DEBUG - 2024-12-16 22:13:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-16 22:13:59 --> Final output sent to browser
DEBUG - 2024-12-16 22:13:59 --> Total execution time: 4.8373
