<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-06 07:55:07 --> Config Class Initialized
INFO - 2023-10-06 07:55:07 --> Hooks Class Initialized
DEBUG - 2023-10-06 07:55:07 --> UTF-8 Support Enabled
INFO - 2023-10-06 07:55:07 --> Utf8 Class Initialized
INFO - 2023-10-06 07:55:07 --> URI Class Initialized
INFO - 2023-10-06 07:55:07 --> Router Class Initialized
INFO - 2023-10-06 07:55:07 --> Output Class Initialized
INFO - 2023-10-06 07:55:07 --> Security Class Initialized
DEBUG - 2023-10-06 07:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 07:55:07 --> Input Class Initialized
INFO - 2023-10-06 07:55:07 --> Language Class Initialized
INFO - 2023-10-06 07:55:07 --> Language Class Initialized
INFO - 2023-10-06 07:55:07 --> Config Class Initialized
INFO - 2023-10-06 07:55:07 --> Loader Class Initialized
INFO - 2023-10-06 07:55:07 --> Helper loaded: url_helper
INFO - 2023-10-06 07:55:07 --> Helper loaded: file_helper
INFO - 2023-10-06 07:55:07 --> Helper loaded: form_helper
INFO - 2023-10-06 07:55:07 --> Helper loaded: my_helper
INFO - 2023-10-06 07:55:07 --> Database Driver Class Initialized
INFO - 2023-10-06 07:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 07:55:07 --> Controller Class Initialized
ERROR - 2023-10-06 07:55:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2023-10-06 07:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 07:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 07:55:07 --> Final output sent to browser
DEBUG - 2023-10-06 07:55:07 --> Total execution time: 0.0832
INFO - 2023-10-06 11:10:38 --> Config Class Initialized
INFO - 2023-10-06 11:10:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:10:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:10:38 --> Utf8 Class Initialized
INFO - 2023-10-06 11:10:38 --> URI Class Initialized
INFO - 2023-10-06 11:10:39 --> Router Class Initialized
INFO - 2023-10-06 11:10:39 --> Output Class Initialized
INFO - 2023-10-06 11:10:39 --> Security Class Initialized
DEBUG - 2023-10-06 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:10:39 --> Input Class Initialized
INFO - 2023-10-06 11:10:39 --> Language Class Initialized
INFO - 2023-10-06 11:10:39 --> Language Class Initialized
INFO - 2023-10-06 11:10:39 --> Config Class Initialized
INFO - 2023-10-06 11:10:39 --> Loader Class Initialized
INFO - 2023-10-06 11:10:39 --> Helper loaded: url_helper
INFO - 2023-10-06 11:10:39 --> Helper loaded: file_helper
INFO - 2023-10-06 11:10:39 --> Helper loaded: form_helper
INFO - 2023-10-06 11:10:39 --> Helper loaded: my_helper
INFO - 2023-10-06 11:10:39 --> Database Driver Class Initialized
INFO - 2023-10-06 11:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:10:39 --> Controller Class Initialized
DEBUG - 2023-10-06 11:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 11:10:45 --> Final output sent to browser
DEBUG - 2023-10-06 11:10:45 --> Total execution time: 6.3122
INFO - 2023-10-06 11:35:46 --> Config Class Initialized
INFO - 2023-10-06 11:35:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:35:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:35:46 --> Utf8 Class Initialized
INFO - 2023-10-06 11:35:46 --> URI Class Initialized
INFO - 2023-10-06 11:35:46 --> Router Class Initialized
INFO - 2023-10-06 11:35:46 --> Output Class Initialized
INFO - 2023-10-06 11:35:46 --> Security Class Initialized
DEBUG - 2023-10-06 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:35:46 --> Input Class Initialized
INFO - 2023-10-06 11:35:46 --> Language Class Initialized
INFO - 2023-10-06 11:35:46 --> Language Class Initialized
INFO - 2023-10-06 11:35:46 --> Config Class Initialized
INFO - 2023-10-06 11:35:46 --> Loader Class Initialized
INFO - 2023-10-06 11:35:46 --> Helper loaded: url_helper
INFO - 2023-10-06 11:35:46 --> Helper loaded: file_helper
INFO - 2023-10-06 11:35:46 --> Helper loaded: form_helper
INFO - 2023-10-06 11:35:46 --> Helper loaded: my_helper
INFO - 2023-10-06 11:35:46 --> Database Driver Class Initialized
INFO - 2023-10-06 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:35:46 --> Controller Class Initialized
ERROR - 2023-10-06 11:35:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2023-10-06 11:35:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 11:35:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:35:46 --> Final output sent to browser
DEBUG - 2023-10-06 11:35:46 --> Total execution time: 0.3536
INFO - 2023-10-06 11:35:55 --> Config Class Initialized
INFO - 2023-10-06 11:35:55 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:35:55 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:35:55 --> Utf8 Class Initialized
INFO - 2023-10-06 11:35:55 --> URI Class Initialized
INFO - 2023-10-06 11:35:55 --> Router Class Initialized
INFO - 2023-10-06 11:35:55 --> Output Class Initialized
INFO - 2023-10-06 11:35:55 --> Security Class Initialized
DEBUG - 2023-10-06 11:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:35:55 --> Input Class Initialized
INFO - 2023-10-06 11:35:55 --> Language Class Initialized
INFO - 2023-10-06 11:35:55 --> Language Class Initialized
INFO - 2023-10-06 11:35:55 --> Config Class Initialized
INFO - 2023-10-06 11:35:55 --> Loader Class Initialized
INFO - 2023-10-06 11:35:55 --> Helper loaded: url_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: file_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: form_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: my_helper
INFO - 2023-10-06 11:35:55 --> Database Driver Class Initialized
INFO - 2023-10-06 11:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:35:55 --> Controller Class Initialized
INFO - 2023-10-06 11:35:55 --> Config Class Initialized
INFO - 2023-10-06 11:35:55 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:35:55 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:35:55 --> Utf8 Class Initialized
INFO - 2023-10-06 11:35:55 --> URI Class Initialized
INFO - 2023-10-06 11:35:55 --> Router Class Initialized
INFO - 2023-10-06 11:35:55 --> Output Class Initialized
INFO - 2023-10-06 11:35:55 --> Security Class Initialized
DEBUG - 2023-10-06 11:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:35:55 --> Input Class Initialized
INFO - 2023-10-06 11:35:55 --> Language Class Initialized
INFO - 2023-10-06 11:35:55 --> Language Class Initialized
INFO - 2023-10-06 11:35:55 --> Config Class Initialized
INFO - 2023-10-06 11:35:55 --> Loader Class Initialized
INFO - 2023-10-06 11:35:55 --> Helper loaded: url_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: file_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: form_helper
INFO - 2023-10-06 11:35:55 --> Helper loaded: my_helper
INFO - 2023-10-06 11:35:55 --> Database Driver Class Initialized
INFO - 2023-10-06 11:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:35:55 --> Controller Class Initialized
DEBUG - 2023-10-06 11:35:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 11:35:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:35:55 --> Final output sent to browser
DEBUG - 2023-10-06 11:35:55 --> Total execution time: 0.1192
INFO - 2023-10-06 11:36:06 --> Config Class Initialized
INFO - 2023-10-06 11:36:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:36:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:36:06 --> Utf8 Class Initialized
INFO - 2023-10-06 11:36:06 --> URI Class Initialized
INFO - 2023-10-06 11:36:06 --> Router Class Initialized
INFO - 2023-10-06 11:36:06 --> Output Class Initialized
INFO - 2023-10-06 11:36:06 --> Security Class Initialized
DEBUG - 2023-10-06 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:36:06 --> Input Class Initialized
INFO - 2023-10-06 11:36:06 --> Language Class Initialized
INFO - 2023-10-06 11:36:06 --> Language Class Initialized
INFO - 2023-10-06 11:36:06 --> Config Class Initialized
INFO - 2023-10-06 11:36:06 --> Loader Class Initialized
INFO - 2023-10-06 11:36:06 --> Helper loaded: url_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: file_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: form_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: my_helper
INFO - 2023-10-06 11:36:06 --> Database Driver Class Initialized
INFO - 2023-10-06 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:36:06 --> Controller Class Initialized
INFO - 2023-10-06 11:36:06 --> Helper loaded: cookie_helper
INFO - 2023-10-06 11:36:06 --> Final output sent to browser
DEBUG - 2023-10-06 11:36:06 --> Total execution time: 0.0347
INFO - 2023-10-06 11:36:06 --> Config Class Initialized
INFO - 2023-10-06 11:36:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:36:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:36:06 --> Utf8 Class Initialized
INFO - 2023-10-06 11:36:06 --> URI Class Initialized
INFO - 2023-10-06 11:36:06 --> Router Class Initialized
INFO - 2023-10-06 11:36:06 --> Output Class Initialized
INFO - 2023-10-06 11:36:06 --> Security Class Initialized
DEBUG - 2023-10-06 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:36:06 --> Input Class Initialized
INFO - 2023-10-06 11:36:06 --> Language Class Initialized
INFO - 2023-10-06 11:36:06 --> Language Class Initialized
INFO - 2023-10-06 11:36:06 --> Config Class Initialized
INFO - 2023-10-06 11:36:06 --> Loader Class Initialized
INFO - 2023-10-06 11:36:06 --> Helper loaded: url_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: file_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: form_helper
INFO - 2023-10-06 11:36:06 --> Helper loaded: my_helper
INFO - 2023-10-06 11:36:06 --> Database Driver Class Initialized
INFO - 2023-10-06 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:36:06 --> Controller Class Initialized
DEBUG - 2023-10-06 11:36:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 11:36:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:36:06 --> Final output sent to browser
DEBUG - 2023-10-06 11:36:06 --> Total execution time: 0.0449
INFO - 2023-10-06 11:36:12 --> Config Class Initialized
INFO - 2023-10-06 11:36:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:36:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:36:12 --> Utf8 Class Initialized
INFO - 2023-10-06 11:36:12 --> URI Class Initialized
INFO - 2023-10-06 11:36:12 --> Router Class Initialized
INFO - 2023-10-06 11:36:12 --> Output Class Initialized
INFO - 2023-10-06 11:36:12 --> Security Class Initialized
DEBUG - 2023-10-06 11:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:36:12 --> Input Class Initialized
INFO - 2023-10-06 11:36:12 --> Language Class Initialized
INFO - 2023-10-06 11:36:12 --> Language Class Initialized
INFO - 2023-10-06 11:36:12 --> Config Class Initialized
INFO - 2023-10-06 11:36:12 --> Loader Class Initialized
INFO - 2023-10-06 11:36:12 --> Helper loaded: url_helper
INFO - 2023-10-06 11:36:12 --> Helper loaded: file_helper
INFO - 2023-10-06 11:36:12 --> Helper loaded: form_helper
INFO - 2023-10-06 11:36:12 --> Helper loaded: my_helper
INFO - 2023-10-06 11:36:12 --> Database Driver Class Initialized
INFO - 2023-10-06 11:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:36:12 --> Controller Class Initialized
DEBUG - 2023-10-06 11:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 11:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:36:12 --> Final output sent to browser
DEBUG - 2023-10-06 11:36:12 --> Total execution time: 0.1179
INFO - 2023-10-06 11:57:08 --> Config Class Initialized
INFO - 2023-10-06 11:57:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:57:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:57:08 --> Utf8 Class Initialized
INFO - 2023-10-06 11:57:08 --> URI Class Initialized
INFO - 2023-10-06 11:57:08 --> Router Class Initialized
INFO - 2023-10-06 11:57:08 --> Output Class Initialized
INFO - 2023-10-06 11:57:08 --> Security Class Initialized
DEBUG - 2023-10-06 11:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:57:08 --> Input Class Initialized
INFO - 2023-10-06 11:57:08 --> Language Class Initialized
INFO - 2023-10-06 11:57:08 --> Language Class Initialized
INFO - 2023-10-06 11:57:08 --> Config Class Initialized
INFO - 2023-10-06 11:57:08 --> Loader Class Initialized
INFO - 2023-10-06 11:57:08 --> Helper loaded: url_helper
INFO - 2023-10-06 11:57:08 --> Helper loaded: file_helper
INFO - 2023-10-06 11:57:08 --> Helper loaded: form_helper
INFO - 2023-10-06 11:57:08 --> Helper loaded: my_helper
INFO - 2023-10-06 11:57:08 --> Database Driver Class Initialized
INFO - 2023-10-06 11:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:57:08 --> Controller Class Initialized
DEBUG - 2023-10-06 11:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 11:57:12 --> Final output sent to browser
DEBUG - 2023-10-06 11:57:12 --> Total execution time: 4.2431
INFO - 2023-10-06 11:57:12 --> Config Class Initialized
INFO - 2023-10-06 11:57:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:57:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:57:12 --> Utf8 Class Initialized
INFO - 2023-10-06 11:57:12 --> URI Class Initialized
INFO - 2023-10-06 11:57:12 --> Router Class Initialized
INFO - 2023-10-06 11:57:12 --> Output Class Initialized
INFO - 2023-10-06 11:57:12 --> Security Class Initialized
DEBUG - 2023-10-06 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:57:12 --> Input Class Initialized
INFO - 2023-10-06 11:57:12 --> Language Class Initialized
INFO - 2023-10-06 11:57:12 --> Language Class Initialized
INFO - 2023-10-06 11:57:12 --> Config Class Initialized
INFO - 2023-10-06 11:57:12 --> Loader Class Initialized
INFO - 2023-10-06 11:57:12 --> Helper loaded: url_helper
INFO - 2023-10-06 11:57:12 --> Helper loaded: file_helper
INFO - 2023-10-06 11:57:12 --> Helper loaded: form_helper
INFO - 2023-10-06 11:57:12 --> Helper loaded: my_helper
INFO - 2023-10-06 11:57:12 --> Database Driver Class Initialized
INFO - 2023-10-06 11:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:57:12 --> Controller Class Initialized
DEBUG - 2023-10-06 11:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 11:57:16 --> Final output sent to browser
DEBUG - 2023-10-06 11:57:16 --> Total execution time: 3.7385
INFO - 2023-10-06 11:59:06 --> Config Class Initialized
INFO - 2023-10-06 11:59:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:06 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:06 --> URI Class Initialized
INFO - 2023-10-06 11:59:06 --> Router Class Initialized
INFO - 2023-10-06 11:59:06 --> Output Class Initialized
INFO - 2023-10-06 11:59:06 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:06 --> Input Class Initialized
INFO - 2023-10-06 11:59:06 --> Language Class Initialized
INFO - 2023-10-06 11:59:06 --> Language Class Initialized
INFO - 2023-10-06 11:59:06 --> Config Class Initialized
INFO - 2023-10-06 11:59:06 --> Loader Class Initialized
INFO - 2023-10-06 11:59:06 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:06 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:06 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:06 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:06 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:06 --> Controller Class Initialized
DEBUG - 2023-10-06 11:59:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 11:59:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:59:06 --> Final output sent to browser
DEBUG - 2023-10-06 11:59:06 --> Total execution time: 0.0323
INFO - 2023-10-06 11:59:09 --> Config Class Initialized
INFO - 2023-10-06 11:59:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:09 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:09 --> URI Class Initialized
INFO - 2023-10-06 11:59:09 --> Router Class Initialized
INFO - 2023-10-06 11:59:09 --> Output Class Initialized
INFO - 2023-10-06 11:59:09 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:09 --> Input Class Initialized
INFO - 2023-10-06 11:59:09 --> Language Class Initialized
INFO - 2023-10-06 11:59:09 --> Language Class Initialized
INFO - 2023-10-06 11:59:09 --> Config Class Initialized
INFO - 2023-10-06 11:59:09 --> Loader Class Initialized
INFO - 2023-10-06 11:59:09 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:09 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:09 --> Controller Class Initialized
DEBUG - 2023-10-06 11:59:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-10-06 11:59:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:59:09 --> Final output sent to browser
DEBUG - 2023-10-06 11:59:09 --> Total execution time: 0.0646
INFO - 2023-10-06 11:59:09 --> Config Class Initialized
INFO - 2023-10-06 11:59:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:09 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:09 --> URI Class Initialized
INFO - 2023-10-06 11:59:09 --> Router Class Initialized
INFO - 2023-10-06 11:59:09 --> Output Class Initialized
INFO - 2023-10-06 11:59:09 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:09 --> Input Class Initialized
INFO - 2023-10-06 11:59:09 --> Language Class Initialized
INFO - 2023-10-06 11:59:09 --> Language Class Initialized
INFO - 2023-10-06 11:59:09 --> Config Class Initialized
INFO - 2023-10-06 11:59:09 --> Loader Class Initialized
INFO - 2023-10-06 11:59:09 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:09 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:09 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:09 --> Controller Class Initialized
INFO - 2023-10-06 11:59:12 --> Config Class Initialized
INFO - 2023-10-06 11:59:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:12 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:12 --> URI Class Initialized
INFO - 2023-10-06 11:59:12 --> Router Class Initialized
INFO - 2023-10-06 11:59:12 --> Output Class Initialized
INFO - 2023-10-06 11:59:12 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:12 --> Input Class Initialized
INFO - 2023-10-06 11:59:12 --> Language Class Initialized
INFO - 2023-10-06 11:59:12 --> Language Class Initialized
INFO - 2023-10-06 11:59:12 --> Config Class Initialized
INFO - 2023-10-06 11:59:12 --> Loader Class Initialized
INFO - 2023-10-06 11:59:12 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:12 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:12 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:12 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:12 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:12 --> Controller Class Initialized
INFO - 2023-10-06 11:59:12 --> Final output sent to browser
DEBUG - 2023-10-06 11:59:12 --> Total execution time: 0.0332
INFO - 2023-10-06 11:59:14 --> Config Class Initialized
INFO - 2023-10-06 11:59:14 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:14 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:14 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:14 --> URI Class Initialized
INFO - 2023-10-06 11:59:14 --> Router Class Initialized
INFO - 2023-10-06 11:59:14 --> Output Class Initialized
INFO - 2023-10-06 11:59:14 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:14 --> Input Class Initialized
INFO - 2023-10-06 11:59:14 --> Language Class Initialized
INFO - 2023-10-06 11:59:14 --> Language Class Initialized
INFO - 2023-10-06 11:59:14 --> Config Class Initialized
INFO - 2023-10-06 11:59:14 --> Loader Class Initialized
INFO - 2023-10-06 11:59:14 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:14 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:14 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:14 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:14 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:14 --> Controller Class Initialized
DEBUG - 2023-10-06 11:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 11:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 11:59:14 --> Final output sent to browser
DEBUG - 2023-10-06 11:59:14 --> Total execution time: 0.0427
INFO - 2023-10-06 11:59:16 --> Config Class Initialized
INFO - 2023-10-06 11:59:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:16 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:16 --> URI Class Initialized
INFO - 2023-10-06 11:59:16 --> Router Class Initialized
INFO - 2023-10-06 11:59:16 --> Output Class Initialized
INFO - 2023-10-06 11:59:16 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:16 --> Input Class Initialized
INFO - 2023-10-06 11:59:16 --> Language Class Initialized
INFO - 2023-10-06 11:59:16 --> Language Class Initialized
INFO - 2023-10-06 11:59:16 --> Config Class Initialized
INFO - 2023-10-06 11:59:16 --> Loader Class Initialized
INFO - 2023-10-06 11:59:16 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:16 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:16 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:16 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:16 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:16 --> Controller Class Initialized
INFO - 2023-10-06 11:59:17 --> Config Class Initialized
INFO - 2023-10-06 11:59:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 11:59:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 11:59:17 --> Utf8 Class Initialized
INFO - 2023-10-06 11:59:17 --> URI Class Initialized
INFO - 2023-10-06 11:59:17 --> Router Class Initialized
INFO - 2023-10-06 11:59:17 --> Output Class Initialized
INFO - 2023-10-06 11:59:17 --> Security Class Initialized
DEBUG - 2023-10-06 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 11:59:17 --> Input Class Initialized
INFO - 2023-10-06 11:59:17 --> Language Class Initialized
INFO - 2023-10-06 11:59:17 --> Language Class Initialized
INFO - 2023-10-06 11:59:17 --> Config Class Initialized
INFO - 2023-10-06 11:59:17 --> Loader Class Initialized
INFO - 2023-10-06 11:59:17 --> Helper loaded: url_helper
INFO - 2023-10-06 11:59:17 --> Helper loaded: file_helper
INFO - 2023-10-06 11:59:17 --> Helper loaded: form_helper
INFO - 2023-10-06 11:59:17 --> Helper loaded: my_helper
INFO - 2023-10-06 11:59:17 --> Database Driver Class Initialized
INFO - 2023-10-06 11:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 11:59:17 --> Controller Class Initialized
ERROR - 2023-10-06 11:59:17 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2023-10-06 11:59:17 --> Final output sent to browser
DEBUG - 2023-10-06 11:59:17 --> Total execution time: 0.0776
INFO - 2023-10-06 12:00:24 --> Config Class Initialized
INFO - 2023-10-06 12:00:24 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:24 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:24 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:24 --> URI Class Initialized
INFO - 2023-10-06 12:00:24 --> Router Class Initialized
INFO - 2023-10-06 12:00:24 --> Output Class Initialized
INFO - 2023-10-06 12:00:24 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:24 --> Input Class Initialized
INFO - 2023-10-06 12:00:24 --> Language Class Initialized
INFO - 2023-10-06 12:00:24 --> Language Class Initialized
INFO - 2023-10-06 12:00:24 --> Config Class Initialized
INFO - 2023-10-06 12:00:24 --> Loader Class Initialized
INFO - 2023-10-06 12:00:24 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:24 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:24 --> Controller Class Initialized
DEBUG - 2023-10-06 12:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:00:24 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:24 --> Total execution time: 0.0393
INFO - 2023-10-06 12:00:24 --> Config Class Initialized
INFO - 2023-10-06 12:00:24 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:24 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:24 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:24 --> URI Class Initialized
INFO - 2023-10-06 12:00:24 --> Router Class Initialized
INFO - 2023-10-06 12:00:24 --> Output Class Initialized
INFO - 2023-10-06 12:00:24 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:24 --> Input Class Initialized
INFO - 2023-10-06 12:00:24 --> Language Class Initialized
INFO - 2023-10-06 12:00:24 --> Language Class Initialized
INFO - 2023-10-06 12:00:24 --> Config Class Initialized
INFO - 2023-10-06 12:00:24 --> Loader Class Initialized
INFO - 2023-10-06 12:00:24 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:24 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:24 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:24 --> Controller Class Initialized
INFO - 2023-10-06 12:00:27 --> Config Class Initialized
INFO - 2023-10-06 12:00:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:27 --> URI Class Initialized
DEBUG - 2023-10-06 12:00:27 --> No URI present. Default controller set.
INFO - 2023-10-06 12:00:27 --> Router Class Initialized
INFO - 2023-10-06 12:00:27 --> Output Class Initialized
INFO - 2023-10-06 12:00:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:27 --> Input Class Initialized
INFO - 2023-10-06 12:00:27 --> Language Class Initialized
INFO - 2023-10-06 12:00:27 --> Language Class Initialized
INFO - 2023-10-06 12:00:27 --> Config Class Initialized
INFO - 2023-10-06 12:00:27 --> Loader Class Initialized
INFO - 2023-10-06 12:00:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:27 --> Controller Class Initialized
INFO - 2023-10-06 12:00:27 --> Config Class Initialized
INFO - 2023-10-06 12:00:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:27 --> URI Class Initialized
INFO - 2023-10-06 12:00:27 --> Router Class Initialized
INFO - 2023-10-06 12:00:27 --> Output Class Initialized
INFO - 2023-10-06 12:00:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:27 --> Input Class Initialized
INFO - 2023-10-06 12:00:27 --> Language Class Initialized
INFO - 2023-10-06 12:00:27 --> Language Class Initialized
INFO - 2023-10-06 12:00:27 --> Config Class Initialized
INFO - 2023-10-06 12:00:27 --> Loader Class Initialized
INFO - 2023-10-06 12:00:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:27 --> Controller Class Initialized
DEBUG - 2023-10-06 12:00:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:00:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:00:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:27 --> Total execution time: 0.0356
INFO - 2023-10-06 12:00:30 --> Config Class Initialized
INFO - 2023-10-06 12:00:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:30 --> URI Class Initialized
INFO - 2023-10-06 12:00:30 --> Router Class Initialized
INFO - 2023-10-06 12:00:30 --> Output Class Initialized
INFO - 2023-10-06 12:00:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:30 --> Input Class Initialized
INFO - 2023-10-06 12:00:30 --> Language Class Initialized
INFO - 2023-10-06 12:00:30 --> Language Class Initialized
INFO - 2023-10-06 12:00:30 --> Config Class Initialized
INFO - 2023-10-06 12:00:30 --> Loader Class Initialized
INFO - 2023-10-06 12:00:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:30 --> Controller Class Initialized
INFO - 2023-10-06 12:00:30 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:00:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:30 --> Total execution time: 0.0393
INFO - 2023-10-06 12:00:30 --> Config Class Initialized
INFO - 2023-10-06 12:00:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:30 --> URI Class Initialized
INFO - 2023-10-06 12:00:30 --> Router Class Initialized
INFO - 2023-10-06 12:00:30 --> Output Class Initialized
INFO - 2023-10-06 12:00:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:30 --> Input Class Initialized
INFO - 2023-10-06 12:00:30 --> Language Class Initialized
INFO - 2023-10-06 12:00:30 --> Language Class Initialized
INFO - 2023-10-06 12:00:30 --> Config Class Initialized
INFO - 2023-10-06 12:00:30 --> Loader Class Initialized
INFO - 2023-10-06 12:00:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:30 --> Controller Class Initialized
DEBUG - 2023-10-06 12:00:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:00:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:00:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:30 --> Total execution time: 0.0399
INFO - 2023-10-06 12:00:32 --> Config Class Initialized
INFO - 2023-10-06 12:00:32 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:32 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:32 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:32 --> URI Class Initialized
INFO - 2023-10-06 12:00:32 --> Router Class Initialized
INFO - 2023-10-06 12:00:32 --> Output Class Initialized
INFO - 2023-10-06 12:00:32 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:32 --> Input Class Initialized
INFO - 2023-10-06 12:00:32 --> Language Class Initialized
INFO - 2023-10-06 12:00:32 --> Language Class Initialized
INFO - 2023-10-06 12:00:32 --> Config Class Initialized
INFO - 2023-10-06 12:00:32 --> Loader Class Initialized
INFO - 2023-10-06 12:00:32 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:32 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:32 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:32 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:32 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:32 --> Controller Class Initialized
DEBUG - 2023-10-06 12:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:00:32 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:32 --> Total execution time: 0.0353
INFO - 2023-10-06 12:00:36 --> Config Class Initialized
INFO - 2023-10-06 12:00:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:36 --> URI Class Initialized
INFO - 2023-10-06 12:00:36 --> Router Class Initialized
INFO - 2023-10-06 12:00:36 --> Output Class Initialized
INFO - 2023-10-06 12:00:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:36 --> Input Class Initialized
INFO - 2023-10-06 12:00:36 --> Language Class Initialized
INFO - 2023-10-06 12:00:36 --> Language Class Initialized
INFO - 2023-10-06 12:00:36 --> Config Class Initialized
INFO - 2023-10-06 12:00:36 --> Loader Class Initialized
INFO - 2023-10-06 12:00:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:36 --> Controller Class Initialized
DEBUG - 2023-10-06 12:00:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:00:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:00:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:36 --> Total execution time: 0.0703
INFO - 2023-10-06 12:00:36 --> Config Class Initialized
INFO - 2023-10-06 12:00:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:36 --> URI Class Initialized
INFO - 2023-10-06 12:00:36 --> Router Class Initialized
INFO - 2023-10-06 12:00:36 --> Output Class Initialized
INFO - 2023-10-06 12:00:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:36 --> Input Class Initialized
INFO - 2023-10-06 12:00:36 --> Language Class Initialized
INFO - 2023-10-06 12:00:36 --> Language Class Initialized
INFO - 2023-10-06 12:00:36 --> Config Class Initialized
INFO - 2023-10-06 12:00:36 --> Loader Class Initialized
INFO - 2023-10-06 12:00:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:36 --> Controller Class Initialized
INFO - 2023-10-06 12:00:39 --> Config Class Initialized
INFO - 2023-10-06 12:00:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:39 --> URI Class Initialized
INFO - 2023-10-06 12:00:39 --> Router Class Initialized
INFO - 2023-10-06 12:00:39 --> Output Class Initialized
INFO - 2023-10-06 12:00:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:39 --> Input Class Initialized
INFO - 2023-10-06 12:00:39 --> Language Class Initialized
INFO - 2023-10-06 12:00:39 --> Language Class Initialized
INFO - 2023-10-06 12:00:39 --> Config Class Initialized
INFO - 2023-10-06 12:00:39 --> Loader Class Initialized
INFO - 2023-10-06 12:00:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:39 --> Controller Class Initialized
INFO - 2023-10-06 12:00:39 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:39 --> Total execution time: 0.0773
INFO - 2023-10-06 12:00:51 --> Config Class Initialized
INFO - 2023-10-06 12:00:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:00:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:00:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:00:51 --> URI Class Initialized
INFO - 2023-10-06 12:00:51 --> Router Class Initialized
INFO - 2023-10-06 12:00:51 --> Output Class Initialized
INFO - 2023-10-06 12:00:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:00:51 --> Input Class Initialized
INFO - 2023-10-06 12:00:51 --> Language Class Initialized
INFO - 2023-10-06 12:00:51 --> Language Class Initialized
INFO - 2023-10-06 12:00:51 --> Config Class Initialized
INFO - 2023-10-06 12:00:51 --> Loader Class Initialized
INFO - 2023-10-06 12:00:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:00:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:00:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:00:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:00:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:00:51 --> Controller Class Initialized
INFO - 2023-10-06 12:00:51 --> Final output sent to browser
DEBUG - 2023-10-06 12:00:51 --> Total execution time: 0.0444
INFO - 2023-10-06 12:01:01 --> Config Class Initialized
INFO - 2023-10-06 12:01:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:01 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:01 --> URI Class Initialized
INFO - 2023-10-06 12:01:01 --> Router Class Initialized
INFO - 2023-10-06 12:01:01 --> Output Class Initialized
INFO - 2023-10-06 12:01:01 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:01 --> Input Class Initialized
INFO - 2023-10-06 12:01:01 --> Language Class Initialized
INFO - 2023-10-06 12:01:01 --> Language Class Initialized
INFO - 2023-10-06 12:01:01 --> Config Class Initialized
INFO - 2023-10-06 12:01:01 --> Loader Class Initialized
INFO - 2023-10-06 12:01:01 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:01 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:01 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:01 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:01 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:01 --> Controller Class Initialized
INFO - 2023-10-06 12:01:01 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:01 --> Total execution time: 0.0477
INFO - 2023-10-06 12:01:10 --> Config Class Initialized
INFO - 2023-10-06 12:01:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:10 --> URI Class Initialized
INFO - 2023-10-06 12:01:10 --> Router Class Initialized
INFO - 2023-10-06 12:01:10 --> Output Class Initialized
INFO - 2023-10-06 12:01:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:10 --> Input Class Initialized
INFO - 2023-10-06 12:01:10 --> Language Class Initialized
INFO - 2023-10-06 12:01:10 --> Language Class Initialized
INFO - 2023-10-06 12:01:10 --> Config Class Initialized
INFO - 2023-10-06 12:01:10 --> Loader Class Initialized
INFO - 2023-10-06 12:01:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:10 --> Controller Class Initialized
INFO - 2023-10-06 12:01:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:10 --> Total execution time: 0.0432
INFO - 2023-10-06 12:01:18 --> Config Class Initialized
INFO - 2023-10-06 12:01:18 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:18 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:18 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:18 --> URI Class Initialized
INFO - 2023-10-06 12:01:18 --> Router Class Initialized
INFO - 2023-10-06 12:01:18 --> Output Class Initialized
INFO - 2023-10-06 12:01:18 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:18 --> Input Class Initialized
INFO - 2023-10-06 12:01:18 --> Language Class Initialized
INFO - 2023-10-06 12:01:18 --> Language Class Initialized
INFO - 2023-10-06 12:01:18 --> Config Class Initialized
INFO - 2023-10-06 12:01:18 --> Loader Class Initialized
INFO - 2023-10-06 12:01:18 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:18 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:18 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:18 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:18 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:18 --> Controller Class Initialized
DEBUG - 2023-10-06 12:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:01:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:18 --> Total execution time: 0.0366
INFO - 2023-10-06 12:01:22 --> Config Class Initialized
INFO - 2023-10-06 12:01:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:22 --> URI Class Initialized
INFO - 2023-10-06 12:01:22 --> Router Class Initialized
INFO - 2023-10-06 12:01:22 --> Output Class Initialized
INFO - 2023-10-06 12:01:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:22 --> Input Class Initialized
INFO - 2023-10-06 12:01:22 --> Language Class Initialized
INFO - 2023-10-06 12:01:22 --> Language Class Initialized
INFO - 2023-10-06 12:01:22 --> Config Class Initialized
INFO - 2023-10-06 12:01:22 --> Loader Class Initialized
INFO - 2023-10-06 12:01:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:22 --> Controller Class Initialized
DEBUG - 2023-10-06 12:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:01:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:22 --> Total execution time: 0.0455
INFO - 2023-10-06 12:01:22 --> Config Class Initialized
INFO - 2023-10-06 12:01:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:22 --> URI Class Initialized
INFO - 2023-10-06 12:01:22 --> Router Class Initialized
INFO - 2023-10-06 12:01:22 --> Output Class Initialized
INFO - 2023-10-06 12:01:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:22 --> Input Class Initialized
INFO - 2023-10-06 12:01:22 --> Language Class Initialized
INFO - 2023-10-06 12:01:22 --> Language Class Initialized
INFO - 2023-10-06 12:01:22 --> Config Class Initialized
INFO - 2023-10-06 12:01:22 --> Loader Class Initialized
INFO - 2023-10-06 12:01:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:22 --> Controller Class Initialized
INFO - 2023-10-06 12:01:26 --> Config Class Initialized
INFO - 2023-10-06 12:01:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:26 --> URI Class Initialized
INFO - 2023-10-06 12:01:26 --> Router Class Initialized
INFO - 2023-10-06 12:01:26 --> Output Class Initialized
INFO - 2023-10-06 12:01:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:26 --> Input Class Initialized
INFO - 2023-10-06 12:01:26 --> Language Class Initialized
INFO - 2023-10-06 12:01:26 --> Language Class Initialized
INFO - 2023-10-06 12:01:26 --> Config Class Initialized
INFO - 2023-10-06 12:01:26 --> Loader Class Initialized
INFO - 2023-10-06 12:01:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:26 --> Controller Class Initialized
INFO - 2023-10-06 12:01:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:26 --> Total execution time: 0.0368
INFO - 2023-10-06 12:01:51 --> Config Class Initialized
INFO - 2023-10-06 12:01:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:51 --> URI Class Initialized
INFO - 2023-10-06 12:01:51 --> Router Class Initialized
INFO - 2023-10-06 12:01:51 --> Output Class Initialized
INFO - 2023-10-06 12:01:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:51 --> Input Class Initialized
INFO - 2023-10-06 12:01:51 --> Language Class Initialized
INFO - 2023-10-06 12:01:51 --> Language Class Initialized
INFO - 2023-10-06 12:01:51 --> Config Class Initialized
INFO - 2023-10-06 12:01:51 --> Loader Class Initialized
INFO - 2023-10-06 12:01:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:51 --> Controller Class Initialized
DEBUG - 2023-10-06 12:01:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-10-06 12:01:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:01:51 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:51 --> Total execution time: 0.0390
INFO - 2023-10-06 12:01:51 --> Config Class Initialized
INFO - 2023-10-06 12:01:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:51 --> URI Class Initialized
INFO - 2023-10-06 12:01:51 --> Router Class Initialized
INFO - 2023-10-06 12:01:51 --> Output Class Initialized
INFO - 2023-10-06 12:01:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:51 --> Input Class Initialized
INFO - 2023-10-06 12:01:51 --> Language Class Initialized
INFO - 2023-10-06 12:01:51 --> Language Class Initialized
INFO - 2023-10-06 12:01:51 --> Config Class Initialized
INFO - 2023-10-06 12:01:51 --> Loader Class Initialized
INFO - 2023-10-06 12:01:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:51 --> Controller Class Initialized
INFO - 2023-10-06 12:01:59 --> Config Class Initialized
INFO - 2023-10-06 12:01:59 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:01:59 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:01:59 --> Utf8 Class Initialized
INFO - 2023-10-06 12:01:59 --> URI Class Initialized
INFO - 2023-10-06 12:01:59 --> Router Class Initialized
INFO - 2023-10-06 12:01:59 --> Output Class Initialized
INFO - 2023-10-06 12:01:59 --> Security Class Initialized
DEBUG - 2023-10-06 12:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:01:59 --> Input Class Initialized
INFO - 2023-10-06 12:01:59 --> Language Class Initialized
INFO - 2023-10-06 12:01:59 --> Language Class Initialized
INFO - 2023-10-06 12:01:59 --> Config Class Initialized
INFO - 2023-10-06 12:01:59 --> Loader Class Initialized
INFO - 2023-10-06 12:01:59 --> Helper loaded: url_helper
INFO - 2023-10-06 12:01:59 --> Helper loaded: file_helper
INFO - 2023-10-06 12:01:59 --> Helper loaded: form_helper
INFO - 2023-10-06 12:01:59 --> Helper loaded: my_helper
INFO - 2023-10-06 12:01:59 --> Database Driver Class Initialized
INFO - 2023-10-06 12:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:01:59 --> Controller Class Initialized
DEBUG - 2023-10-06 12:01:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:01:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:01:59 --> Final output sent to browser
DEBUG - 2023-10-06 12:01:59 --> Total execution time: 0.0874
INFO - 2023-10-06 12:02:01 --> Config Class Initialized
INFO - 2023-10-06 12:02:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:02:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:02:01 --> Utf8 Class Initialized
INFO - 2023-10-06 12:02:01 --> URI Class Initialized
INFO - 2023-10-06 12:02:01 --> Router Class Initialized
INFO - 2023-10-06 12:02:01 --> Output Class Initialized
INFO - 2023-10-06 12:02:01 --> Security Class Initialized
DEBUG - 2023-10-06 12:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:02:01 --> Input Class Initialized
INFO - 2023-10-06 12:02:01 --> Language Class Initialized
INFO - 2023-10-06 12:02:01 --> Language Class Initialized
INFO - 2023-10-06 12:02:01 --> Config Class Initialized
INFO - 2023-10-06 12:02:01 --> Loader Class Initialized
INFO - 2023-10-06 12:02:01 --> Helper loaded: url_helper
INFO - 2023-10-06 12:02:01 --> Helper loaded: file_helper
INFO - 2023-10-06 12:02:01 --> Helper loaded: form_helper
INFO - 2023-10-06 12:02:01 --> Helper loaded: my_helper
INFO - 2023-10-06 12:02:01 --> Database Driver Class Initialized
INFO - 2023-10-06 12:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:02:01 --> Controller Class Initialized
DEBUG - 2023-10-06 12:02:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:02:06 --> Final output sent to browser
DEBUG - 2023-10-06 12:02:06 --> Total execution time: 5.0919
INFO - 2023-10-06 12:05:13 --> Config Class Initialized
INFO - 2023-10-06 12:05:13 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:05:13 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:05:13 --> Utf8 Class Initialized
INFO - 2023-10-06 12:05:13 --> URI Class Initialized
INFO - 2023-10-06 12:05:13 --> Router Class Initialized
INFO - 2023-10-06 12:05:13 --> Output Class Initialized
INFO - 2023-10-06 12:05:13 --> Security Class Initialized
DEBUG - 2023-10-06 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:05:13 --> Input Class Initialized
INFO - 2023-10-06 12:05:13 --> Language Class Initialized
INFO - 2023-10-06 12:05:13 --> Language Class Initialized
INFO - 2023-10-06 12:05:13 --> Config Class Initialized
INFO - 2023-10-06 12:05:13 --> Loader Class Initialized
INFO - 2023-10-06 12:05:13 --> Helper loaded: url_helper
INFO - 2023-10-06 12:05:13 --> Helper loaded: file_helper
INFO - 2023-10-06 12:05:13 --> Helper loaded: form_helper
INFO - 2023-10-06 12:05:13 --> Helper loaded: my_helper
INFO - 2023-10-06 12:05:13 --> Database Driver Class Initialized
INFO - 2023-10-06 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:05:13 --> Controller Class Initialized
INFO - 2023-10-06 12:05:13 --> Final output sent to browser
DEBUG - 2023-10-06 12:05:13 --> Total execution time: 0.0387
INFO - 2023-10-06 12:05:16 --> Config Class Initialized
INFO - 2023-10-06 12:05:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:05:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:05:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:05:16 --> URI Class Initialized
INFO - 2023-10-06 12:05:16 --> Router Class Initialized
INFO - 2023-10-06 12:05:16 --> Output Class Initialized
INFO - 2023-10-06 12:05:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:05:16 --> Input Class Initialized
INFO - 2023-10-06 12:05:16 --> Language Class Initialized
INFO - 2023-10-06 12:05:16 --> Language Class Initialized
INFO - 2023-10-06 12:05:16 --> Config Class Initialized
INFO - 2023-10-06 12:05:16 --> Loader Class Initialized
INFO - 2023-10-06 12:05:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:05:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:05:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:05:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:05:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:05:16 --> Controller Class Initialized
INFO - 2023-10-06 12:05:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:05:16 --> Total execution time: 0.0501
INFO - 2023-10-06 12:05:22 --> Config Class Initialized
INFO - 2023-10-06 12:05:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:05:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:05:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:05:22 --> URI Class Initialized
INFO - 2023-10-06 12:05:22 --> Router Class Initialized
INFO - 2023-10-06 12:05:22 --> Output Class Initialized
INFO - 2023-10-06 12:05:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:05:22 --> Input Class Initialized
INFO - 2023-10-06 12:05:22 --> Language Class Initialized
INFO - 2023-10-06 12:05:22 --> Language Class Initialized
INFO - 2023-10-06 12:05:22 --> Config Class Initialized
INFO - 2023-10-06 12:05:22 --> Loader Class Initialized
INFO - 2023-10-06 12:05:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:05:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:05:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:05:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:05:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:05:22 --> Controller Class Initialized
INFO - 2023-10-06 12:05:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:05:22 --> Total execution time: 0.0418
INFO - 2023-10-06 12:05:26 --> Config Class Initialized
INFO - 2023-10-06 12:05:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:05:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:05:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:05:26 --> URI Class Initialized
INFO - 2023-10-06 12:05:26 --> Router Class Initialized
INFO - 2023-10-06 12:05:26 --> Output Class Initialized
INFO - 2023-10-06 12:05:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:05:26 --> Input Class Initialized
INFO - 2023-10-06 12:05:26 --> Language Class Initialized
INFO - 2023-10-06 12:05:26 --> Language Class Initialized
INFO - 2023-10-06 12:05:26 --> Config Class Initialized
INFO - 2023-10-06 12:05:26 --> Loader Class Initialized
INFO - 2023-10-06 12:05:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:05:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:05:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:05:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:05:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:05:26 --> Controller Class Initialized
INFO - 2023-10-06 12:05:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:05:26 --> Total execution time: 0.0310
INFO - 2023-10-06 12:08:06 --> Config Class Initialized
INFO - 2023-10-06 12:08:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:06 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:06 --> URI Class Initialized
INFO - 2023-10-06 12:08:06 --> Router Class Initialized
INFO - 2023-10-06 12:08:06 --> Output Class Initialized
INFO - 2023-10-06 12:08:06 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:06 --> Input Class Initialized
INFO - 2023-10-06 12:08:06 --> Language Class Initialized
INFO - 2023-10-06 12:08:06 --> Language Class Initialized
INFO - 2023-10-06 12:08:06 --> Config Class Initialized
INFO - 2023-10-06 12:08:06 --> Loader Class Initialized
INFO - 2023-10-06 12:08:06 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:06 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:06 --> Controller Class Initialized
INFO - 2023-10-06 12:08:06 --> Config Class Initialized
INFO - 2023-10-06 12:08:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:06 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:06 --> URI Class Initialized
INFO - 2023-10-06 12:08:06 --> Router Class Initialized
INFO - 2023-10-06 12:08:06 --> Output Class Initialized
INFO - 2023-10-06 12:08:06 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:06 --> Input Class Initialized
INFO - 2023-10-06 12:08:06 --> Language Class Initialized
INFO - 2023-10-06 12:08:06 --> Language Class Initialized
INFO - 2023-10-06 12:08:06 --> Config Class Initialized
INFO - 2023-10-06 12:08:06 --> Loader Class Initialized
INFO - 2023-10-06 12:08:06 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:06 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:06 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:06 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:06 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:06 --> Total execution time: 0.0648
INFO - 2023-10-06 12:08:15 --> Config Class Initialized
INFO - 2023-10-06 12:08:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:15 --> URI Class Initialized
INFO - 2023-10-06 12:08:15 --> Router Class Initialized
INFO - 2023-10-06 12:08:15 --> Output Class Initialized
INFO - 2023-10-06 12:08:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:15 --> Input Class Initialized
INFO - 2023-10-06 12:08:15 --> Language Class Initialized
INFO - 2023-10-06 12:08:15 --> Language Class Initialized
INFO - 2023-10-06 12:08:15 --> Config Class Initialized
INFO - 2023-10-06 12:08:15 --> Loader Class Initialized
INFO - 2023-10-06 12:08:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:15 --> Controller Class Initialized
INFO - 2023-10-06 12:08:15 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:08:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:15 --> Total execution time: 0.0800
INFO - 2023-10-06 12:08:15 --> Config Class Initialized
INFO - 2023-10-06 12:08:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:15 --> URI Class Initialized
INFO - 2023-10-06 12:08:15 --> Router Class Initialized
INFO - 2023-10-06 12:08:15 --> Output Class Initialized
INFO - 2023-10-06 12:08:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:15 --> Input Class Initialized
INFO - 2023-10-06 12:08:15 --> Language Class Initialized
INFO - 2023-10-06 12:08:15 --> Language Class Initialized
INFO - 2023-10-06 12:08:15 --> Config Class Initialized
INFO - 2023-10-06 12:08:15 --> Loader Class Initialized
INFO - 2023-10-06 12:08:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:15 --> Total execution time: 0.0560
INFO - 2023-10-06 12:08:19 --> Config Class Initialized
INFO - 2023-10-06 12:08:19 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:19 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:19 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:19 --> URI Class Initialized
INFO - 2023-10-06 12:08:19 --> Router Class Initialized
INFO - 2023-10-06 12:08:19 --> Output Class Initialized
INFO - 2023-10-06 12:08:19 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:19 --> Input Class Initialized
INFO - 2023-10-06 12:08:19 --> Language Class Initialized
INFO - 2023-10-06 12:08:19 --> Language Class Initialized
INFO - 2023-10-06 12:08:19 --> Config Class Initialized
INFO - 2023-10-06 12:08:19 --> Loader Class Initialized
INFO - 2023-10-06 12:08:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:19 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:19 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:19 --> Total execution time: 0.0368
INFO - 2023-10-06 12:08:22 --> Config Class Initialized
INFO - 2023-10-06 12:08:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:22 --> URI Class Initialized
INFO - 2023-10-06 12:08:22 --> Router Class Initialized
INFO - 2023-10-06 12:08:22 --> Output Class Initialized
INFO - 2023-10-06 12:08:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:22 --> Input Class Initialized
INFO - 2023-10-06 12:08:22 --> Language Class Initialized
INFO - 2023-10-06 12:08:22 --> Language Class Initialized
INFO - 2023-10-06 12:08:22 --> Config Class Initialized
INFO - 2023-10-06 12:08:22 --> Loader Class Initialized
INFO - 2023-10-06 12:08:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:22 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:08:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:22 --> Total execution time: 0.0316
INFO - 2023-10-06 12:08:22 --> Config Class Initialized
INFO - 2023-10-06 12:08:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:22 --> URI Class Initialized
INFO - 2023-10-06 12:08:22 --> Router Class Initialized
INFO - 2023-10-06 12:08:22 --> Output Class Initialized
INFO - 2023-10-06 12:08:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:22 --> Input Class Initialized
INFO - 2023-10-06 12:08:22 --> Language Class Initialized
INFO - 2023-10-06 12:08:22 --> Language Class Initialized
INFO - 2023-10-06 12:08:22 --> Config Class Initialized
INFO - 2023-10-06 12:08:22 --> Loader Class Initialized
INFO - 2023-10-06 12:08:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:22 --> Controller Class Initialized
INFO - 2023-10-06 12:08:23 --> Config Class Initialized
INFO - 2023-10-06 12:08:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:23 --> URI Class Initialized
INFO - 2023-10-06 12:08:23 --> Router Class Initialized
INFO - 2023-10-06 12:08:23 --> Output Class Initialized
INFO - 2023-10-06 12:08:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:23 --> Input Class Initialized
INFO - 2023-10-06 12:08:23 --> Language Class Initialized
INFO - 2023-10-06 12:08:23 --> Language Class Initialized
INFO - 2023-10-06 12:08:23 --> Config Class Initialized
INFO - 2023-10-06 12:08:23 --> Loader Class Initialized
INFO - 2023-10-06 12:08:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:23 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:08:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:23 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:23 --> Total execution time: 0.0455
INFO - 2023-10-06 12:08:23 --> Config Class Initialized
INFO - 2023-10-06 12:08:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:23 --> URI Class Initialized
INFO - 2023-10-06 12:08:23 --> Router Class Initialized
INFO - 2023-10-06 12:08:23 --> Output Class Initialized
INFO - 2023-10-06 12:08:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:23 --> Input Class Initialized
INFO - 2023-10-06 12:08:23 --> Language Class Initialized
INFO - 2023-10-06 12:08:23 --> Language Class Initialized
INFO - 2023-10-06 12:08:23 --> Config Class Initialized
INFO - 2023-10-06 12:08:23 --> Loader Class Initialized
INFO - 2023-10-06 12:08:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:23 --> Controller Class Initialized
INFO - 2023-10-06 12:08:23 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:23 --> Total execution time: 0.0425
INFO - 2023-10-06 12:08:39 --> Config Class Initialized
INFO - 2023-10-06 12:08:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:39 --> URI Class Initialized
INFO - 2023-10-06 12:08:39 --> Router Class Initialized
INFO - 2023-10-06 12:08:39 --> Output Class Initialized
INFO - 2023-10-06 12:08:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:39 --> Input Class Initialized
INFO - 2023-10-06 12:08:39 --> Language Class Initialized
INFO - 2023-10-06 12:08:39 --> Language Class Initialized
INFO - 2023-10-06 12:08:39 --> Config Class Initialized
INFO - 2023-10-06 12:08:39 --> Loader Class Initialized
INFO - 2023-10-06 12:08:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:39 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:39 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:39 --> Total execution time: 0.0721
INFO - 2023-10-06 12:08:42 --> Config Class Initialized
INFO - 2023-10-06 12:08:42 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:42 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:42 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:42 --> URI Class Initialized
INFO - 2023-10-06 12:08:42 --> Router Class Initialized
INFO - 2023-10-06 12:08:42 --> Output Class Initialized
INFO - 2023-10-06 12:08:42 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:42 --> Input Class Initialized
INFO - 2023-10-06 12:08:42 --> Language Class Initialized
INFO - 2023-10-06 12:08:42 --> Language Class Initialized
INFO - 2023-10-06 12:08:42 --> Config Class Initialized
INFO - 2023-10-06 12:08:42 --> Loader Class Initialized
INFO - 2023-10-06 12:08:42 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:42 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:42 --> Controller Class Initialized
INFO - 2023-10-06 12:08:42 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:08:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:42 --> Total execution time: 0.1161
INFO - 2023-10-06 12:08:42 --> Config Class Initialized
INFO - 2023-10-06 12:08:42 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:42 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:42 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:42 --> URI Class Initialized
INFO - 2023-10-06 12:08:42 --> Router Class Initialized
INFO - 2023-10-06 12:08:42 --> Output Class Initialized
INFO - 2023-10-06 12:08:42 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:42 --> Input Class Initialized
INFO - 2023-10-06 12:08:42 --> Language Class Initialized
INFO - 2023-10-06 12:08:42 --> Language Class Initialized
INFO - 2023-10-06 12:08:42 --> Config Class Initialized
INFO - 2023-10-06 12:08:42 --> Loader Class Initialized
INFO - 2023-10-06 12:08:42 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:42 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:42 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:42 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:42 --> Total execution time: 0.0808
INFO - 2023-10-06 12:08:50 --> Config Class Initialized
INFO - 2023-10-06 12:08:50 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:50 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:50 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:50 --> URI Class Initialized
INFO - 2023-10-06 12:08:50 --> Router Class Initialized
INFO - 2023-10-06 12:08:50 --> Output Class Initialized
INFO - 2023-10-06 12:08:50 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:50 --> Input Class Initialized
INFO - 2023-10-06 12:08:50 --> Language Class Initialized
INFO - 2023-10-06 12:08:50 --> Language Class Initialized
INFO - 2023-10-06 12:08:50 --> Config Class Initialized
INFO - 2023-10-06 12:08:50 --> Loader Class Initialized
INFO - 2023-10-06 12:08:50 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:50 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:50 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:50 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:50 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:50 --> Controller Class Initialized
INFO - 2023-10-06 12:08:50 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:50 --> Total execution time: 0.0811
INFO - 2023-10-06 12:08:51 --> Config Class Initialized
INFO - 2023-10-06 12:08:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:51 --> URI Class Initialized
INFO - 2023-10-06 12:08:51 --> Router Class Initialized
INFO - 2023-10-06 12:08:51 --> Output Class Initialized
INFO - 2023-10-06 12:08:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:51 --> Input Class Initialized
INFO - 2023-10-06 12:08:51 --> Language Class Initialized
INFO - 2023-10-06 12:08:51 --> Language Class Initialized
INFO - 2023-10-06 12:08:51 --> Config Class Initialized
INFO - 2023-10-06 12:08:51 --> Loader Class Initialized
INFO - 2023-10-06 12:08:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:51 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:08:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:08:51 --> Final output sent to browser
DEBUG - 2023-10-06 12:08:51 --> Total execution time: 0.0424
INFO - 2023-10-06 12:08:56 --> Config Class Initialized
INFO - 2023-10-06 12:08:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:08:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:08:56 --> Utf8 Class Initialized
INFO - 2023-10-06 12:08:56 --> URI Class Initialized
INFO - 2023-10-06 12:08:56 --> Router Class Initialized
INFO - 2023-10-06 12:08:56 --> Output Class Initialized
INFO - 2023-10-06 12:08:56 --> Security Class Initialized
DEBUG - 2023-10-06 12:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:08:56 --> Input Class Initialized
INFO - 2023-10-06 12:08:56 --> Language Class Initialized
INFO - 2023-10-06 12:08:56 --> Language Class Initialized
INFO - 2023-10-06 12:08:56 --> Config Class Initialized
INFO - 2023-10-06 12:08:56 --> Loader Class Initialized
INFO - 2023-10-06 12:08:56 --> Helper loaded: url_helper
INFO - 2023-10-06 12:08:56 --> Helper loaded: file_helper
INFO - 2023-10-06 12:08:56 --> Helper loaded: form_helper
INFO - 2023-10-06 12:08:56 --> Helper loaded: my_helper
INFO - 2023-10-06 12:08:56 --> Database Driver Class Initialized
INFO - 2023-10-06 12:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:08:56 --> Controller Class Initialized
DEBUG - 2023-10-06 12:08:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:09:00 --> Final output sent to browser
DEBUG - 2023-10-06 12:09:00 --> Total execution time: 4.1624
INFO - 2023-10-06 12:09:04 --> Config Class Initialized
INFO - 2023-10-06 12:09:04 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:04 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:04 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:04 --> URI Class Initialized
INFO - 2023-10-06 12:09:04 --> Router Class Initialized
INFO - 2023-10-06 12:09:04 --> Output Class Initialized
INFO - 2023-10-06 12:09:04 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:04 --> Input Class Initialized
INFO - 2023-10-06 12:09:04 --> Language Class Initialized
INFO - 2023-10-06 12:09:04 --> Language Class Initialized
INFO - 2023-10-06 12:09:04 --> Config Class Initialized
INFO - 2023-10-06 12:09:04 --> Loader Class Initialized
INFO - 2023-10-06 12:09:04 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:04 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:04 --> Controller Class Initialized
DEBUG - 2023-10-06 12:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:09:04 --> Final output sent to browser
DEBUG - 2023-10-06 12:09:04 --> Total execution time: 0.0359
INFO - 2023-10-06 12:09:04 --> Config Class Initialized
INFO - 2023-10-06 12:09:04 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:04 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:04 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:04 --> URI Class Initialized
INFO - 2023-10-06 12:09:04 --> Router Class Initialized
INFO - 2023-10-06 12:09:04 --> Output Class Initialized
INFO - 2023-10-06 12:09:04 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:04 --> Input Class Initialized
INFO - 2023-10-06 12:09:04 --> Language Class Initialized
INFO - 2023-10-06 12:09:04 --> Language Class Initialized
INFO - 2023-10-06 12:09:04 --> Config Class Initialized
INFO - 2023-10-06 12:09:04 --> Loader Class Initialized
INFO - 2023-10-06 12:09:04 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:04 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:04 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:04 --> Controller Class Initialized
INFO - 2023-10-06 12:09:10 --> Config Class Initialized
INFO - 2023-10-06 12:09:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:10 --> URI Class Initialized
INFO - 2023-10-06 12:09:10 --> Router Class Initialized
INFO - 2023-10-06 12:09:10 --> Output Class Initialized
INFO - 2023-10-06 12:09:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:10 --> Input Class Initialized
INFO - 2023-10-06 12:09:10 --> Language Class Initialized
INFO - 2023-10-06 12:09:10 --> Language Class Initialized
INFO - 2023-10-06 12:09:10 --> Config Class Initialized
INFO - 2023-10-06 12:09:10 --> Loader Class Initialized
INFO - 2023-10-06 12:09:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:10 --> Controller Class Initialized
INFO - 2023-10-06 12:09:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:09:10 --> Total execution time: 0.0670
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:53 --> URI Class Initialized
INFO - 2023-10-06 12:09:53 --> Router Class Initialized
INFO - 2023-10-06 12:09:53 --> Output Class Initialized
INFO - 2023-10-06 12:09:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:53 --> Input Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Loader Class Initialized
INFO - 2023-10-06 12:09:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:53 --> Controller Class Initialized
INFO - 2023-10-06 12:09:53 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:53 --> URI Class Initialized
INFO - 2023-10-06 12:09:53 --> Router Class Initialized
INFO - 2023-10-06 12:09:53 --> Output Class Initialized
INFO - 2023-10-06 12:09:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:53 --> Input Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Loader Class Initialized
INFO - 2023-10-06 12:09:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:53 --> Controller Class Initialized
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:09:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:09:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:09:53 --> URI Class Initialized
INFO - 2023-10-06 12:09:53 --> Router Class Initialized
INFO - 2023-10-06 12:09:53 --> Output Class Initialized
INFO - 2023-10-06 12:09:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:09:53 --> Input Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Language Class Initialized
INFO - 2023-10-06 12:09:53 --> Config Class Initialized
INFO - 2023-10-06 12:09:53 --> Loader Class Initialized
INFO - 2023-10-06 12:09:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:09:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:09:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:09:53 --> Controller Class Initialized
DEBUG - 2023-10-06 12:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:09:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:09:53 --> Total execution time: 0.0333
INFO - 2023-10-06 12:10:04 --> Config Class Initialized
INFO - 2023-10-06 12:10:04 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:04 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:04 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:04 --> URI Class Initialized
INFO - 2023-10-06 12:10:04 --> Router Class Initialized
INFO - 2023-10-06 12:10:04 --> Output Class Initialized
INFO - 2023-10-06 12:10:04 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:04 --> Input Class Initialized
INFO - 2023-10-06 12:10:04 --> Language Class Initialized
INFO - 2023-10-06 12:10:04 --> Language Class Initialized
INFO - 2023-10-06 12:10:04 --> Config Class Initialized
INFO - 2023-10-06 12:10:04 --> Loader Class Initialized
INFO - 2023-10-06 12:10:04 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:04 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:04 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:04 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:04 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:04 --> Controller Class Initialized
INFO - 2023-10-06 12:10:04 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:04 --> Total execution time: 0.0453
INFO - 2023-10-06 12:10:12 --> Config Class Initialized
INFO - 2023-10-06 12:10:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:12 --> URI Class Initialized
INFO - 2023-10-06 12:10:12 --> Router Class Initialized
INFO - 2023-10-06 12:10:12 --> Output Class Initialized
INFO - 2023-10-06 12:10:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:12 --> Input Class Initialized
INFO - 2023-10-06 12:10:12 --> Language Class Initialized
INFO - 2023-10-06 12:10:12 --> Language Class Initialized
INFO - 2023-10-06 12:10:12 --> Config Class Initialized
INFO - 2023-10-06 12:10:12 --> Loader Class Initialized
INFO - 2023-10-06 12:10:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:12 --> Controller Class Initialized
INFO - 2023-10-06 12:10:12 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:10:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:12 --> Total execution time: 0.0858
INFO - 2023-10-06 12:10:12 --> Config Class Initialized
INFO - 2023-10-06 12:10:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:12 --> URI Class Initialized
INFO - 2023-10-06 12:10:12 --> Router Class Initialized
INFO - 2023-10-06 12:10:12 --> Output Class Initialized
INFO - 2023-10-06 12:10:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:12 --> Input Class Initialized
INFO - 2023-10-06 12:10:12 --> Language Class Initialized
INFO - 2023-10-06 12:10:12 --> Language Class Initialized
INFO - 2023-10-06 12:10:12 --> Config Class Initialized
INFO - 2023-10-06 12:10:12 --> Loader Class Initialized
INFO - 2023-10-06 12:10:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:12 --> Controller Class Initialized
DEBUG - 2023-10-06 12:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:10:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:12 --> Total execution time: 0.0404
INFO - 2023-10-06 12:10:15 --> Config Class Initialized
INFO - 2023-10-06 12:10:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:15 --> URI Class Initialized
INFO - 2023-10-06 12:10:15 --> Router Class Initialized
INFO - 2023-10-06 12:10:15 --> Output Class Initialized
INFO - 2023-10-06 12:10:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:15 --> Input Class Initialized
INFO - 2023-10-06 12:10:15 --> Language Class Initialized
INFO - 2023-10-06 12:10:15 --> Language Class Initialized
INFO - 2023-10-06 12:10:15 --> Config Class Initialized
INFO - 2023-10-06 12:10:15 --> Loader Class Initialized
INFO - 2023-10-06 12:10:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:16 --> Controller Class Initialized
DEBUG - 2023-10-06 12:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:10:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:16 --> Total execution time: 0.0352
INFO - 2023-10-06 12:10:19 --> Config Class Initialized
INFO - 2023-10-06 12:10:19 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:19 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:19 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:19 --> URI Class Initialized
INFO - 2023-10-06 12:10:19 --> Router Class Initialized
INFO - 2023-10-06 12:10:19 --> Output Class Initialized
INFO - 2023-10-06 12:10:19 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:19 --> Input Class Initialized
INFO - 2023-10-06 12:10:19 --> Language Class Initialized
INFO - 2023-10-06 12:10:19 --> Language Class Initialized
INFO - 2023-10-06 12:10:19 --> Config Class Initialized
INFO - 2023-10-06 12:10:19 --> Loader Class Initialized
INFO - 2023-10-06 12:10:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:19 --> Controller Class Initialized
DEBUG - 2023-10-06 12:10:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:10:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:10:19 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:19 --> Total execution time: 0.1186
INFO - 2023-10-06 12:10:19 --> Config Class Initialized
INFO - 2023-10-06 12:10:19 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:19 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:19 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:19 --> URI Class Initialized
INFO - 2023-10-06 12:10:19 --> Router Class Initialized
INFO - 2023-10-06 12:10:19 --> Output Class Initialized
INFO - 2023-10-06 12:10:19 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:19 --> Input Class Initialized
INFO - 2023-10-06 12:10:19 --> Language Class Initialized
INFO - 2023-10-06 12:10:19 --> Language Class Initialized
INFO - 2023-10-06 12:10:19 --> Config Class Initialized
INFO - 2023-10-06 12:10:19 --> Loader Class Initialized
INFO - 2023-10-06 12:10:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:19 --> Controller Class Initialized
INFO - 2023-10-06 12:10:22 --> Config Class Initialized
INFO - 2023-10-06 12:10:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:22 --> URI Class Initialized
INFO - 2023-10-06 12:10:22 --> Router Class Initialized
INFO - 2023-10-06 12:10:22 --> Output Class Initialized
INFO - 2023-10-06 12:10:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:22 --> Input Class Initialized
INFO - 2023-10-06 12:10:22 --> Language Class Initialized
INFO - 2023-10-06 12:10:22 --> Language Class Initialized
INFO - 2023-10-06 12:10:22 --> Config Class Initialized
INFO - 2023-10-06 12:10:22 --> Loader Class Initialized
INFO - 2023-10-06 12:10:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:23 --> Controller Class Initialized
INFO - 2023-10-06 12:10:23 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:23 --> Total execution time: 0.0890
INFO - 2023-10-06 12:10:32 --> Config Class Initialized
INFO - 2023-10-06 12:10:32 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:10:32 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:10:32 --> Utf8 Class Initialized
INFO - 2023-10-06 12:10:32 --> URI Class Initialized
INFO - 2023-10-06 12:10:32 --> Router Class Initialized
INFO - 2023-10-06 12:10:32 --> Output Class Initialized
INFO - 2023-10-06 12:10:32 --> Security Class Initialized
DEBUG - 2023-10-06 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:10:32 --> Input Class Initialized
INFO - 2023-10-06 12:10:32 --> Language Class Initialized
INFO - 2023-10-06 12:10:32 --> Language Class Initialized
INFO - 2023-10-06 12:10:32 --> Config Class Initialized
INFO - 2023-10-06 12:10:32 --> Loader Class Initialized
INFO - 2023-10-06 12:10:32 --> Helper loaded: url_helper
INFO - 2023-10-06 12:10:32 --> Helper loaded: file_helper
INFO - 2023-10-06 12:10:32 --> Helper loaded: form_helper
INFO - 2023-10-06 12:10:32 --> Helper loaded: my_helper
INFO - 2023-10-06 12:10:32 --> Database Driver Class Initialized
INFO - 2023-10-06 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:10:32 --> Controller Class Initialized
INFO - 2023-10-06 12:10:32 --> Final output sent to browser
DEBUG - 2023-10-06 12:10:32 --> Total execution time: 0.0387
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:12 --> URI Class Initialized
INFO - 2023-10-06 12:11:12 --> Router Class Initialized
INFO - 2023-10-06 12:11:12 --> Output Class Initialized
INFO - 2023-10-06 12:11:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:12 --> Input Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Loader Class Initialized
INFO - 2023-10-06 12:11:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:12 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:12 --> Total execution time: 0.1043
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:12 --> URI Class Initialized
DEBUG - 2023-10-06 12:11:12 --> No URI present. Default controller set.
INFO - 2023-10-06 12:11:12 --> Router Class Initialized
INFO - 2023-10-06 12:11:12 --> Output Class Initialized
INFO - 2023-10-06 12:11:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:12 --> Input Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Loader Class Initialized
INFO - 2023-10-06 12:11:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:12 --> Controller Class Initialized
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:12 --> URI Class Initialized
INFO - 2023-10-06 12:11:12 --> Router Class Initialized
INFO - 2023-10-06 12:11:12 --> Output Class Initialized
INFO - 2023-10-06 12:11:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:12 --> Input Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Language Class Initialized
INFO - 2023-10-06 12:11:12 --> Config Class Initialized
INFO - 2023-10-06 12:11:12 --> Loader Class Initialized
INFO - 2023-10-06 12:11:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:12 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:12 --> Total execution time: 0.0384
INFO - 2023-10-06 12:11:14 --> Config Class Initialized
INFO - 2023-10-06 12:11:14 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:14 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:14 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:14 --> URI Class Initialized
INFO - 2023-10-06 12:11:14 --> Router Class Initialized
INFO - 2023-10-06 12:11:14 --> Output Class Initialized
INFO - 2023-10-06 12:11:14 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:14 --> Input Class Initialized
INFO - 2023-10-06 12:11:14 --> Language Class Initialized
INFO - 2023-10-06 12:11:14 --> Language Class Initialized
INFO - 2023-10-06 12:11:14 --> Config Class Initialized
INFO - 2023-10-06 12:11:14 --> Loader Class Initialized
INFO - 2023-10-06 12:11:14 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:14 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:14 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:14 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:14 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:14 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:17 --> URI Class Initialized
INFO - 2023-10-06 12:11:17 --> Router Class Initialized
INFO - 2023-10-06 12:11:17 --> Output Class Initialized
INFO - 2023-10-06 12:11:17 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:17 --> Input Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Loader Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:17 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:17 --> Controller Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:11:17 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:17 --> Total execution time: 0.2368
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:17 --> URI Class Initialized
INFO - 2023-10-06 12:11:17 --> Router Class Initialized
INFO - 2023-10-06 12:11:17 --> Output Class Initialized
INFO - 2023-10-06 12:11:17 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:17 --> Input Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Loader Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:17 --> URI Class Initialized
INFO - 2023-10-06 12:11:17 --> Router Class Initialized
INFO - 2023-10-06 12:11:17 --> Output Class Initialized
INFO - 2023-10-06 12:11:17 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:17 --> Input Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Language Class Initialized
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Loader Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:17 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:17 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:17 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:17 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:11:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:17 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:17 --> Total execution time: 0.1959
INFO - 2023-10-06 12:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:17 --> Controller Class Initialized
INFO - 2023-10-06 12:11:17 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:11:17 --> Config Class Initialized
INFO - 2023-10-06 12:11:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:17 --> URI Class Initialized
INFO - 2023-10-06 12:11:17 --> Router Class Initialized
INFO - 2023-10-06 12:11:18 --> Output Class Initialized
INFO - 2023-10-06 12:11:18 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:18 --> Input Class Initialized
INFO - 2023-10-06 12:11:18 --> Language Class Initialized
INFO - 2023-10-06 12:11:18 --> Language Class Initialized
INFO - 2023-10-06 12:11:18 --> Config Class Initialized
INFO - 2023-10-06 12:11:18 --> Loader Class Initialized
INFO - 2023-10-06 12:11:18 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:18 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:18 --> Controller Class Initialized
INFO - 2023-10-06 12:11:18 --> Config Class Initialized
INFO - 2023-10-06 12:11:18 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:18 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:18 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:18 --> URI Class Initialized
INFO - 2023-10-06 12:11:18 --> Router Class Initialized
INFO - 2023-10-06 12:11:18 --> Output Class Initialized
INFO - 2023-10-06 12:11:18 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:18 --> Input Class Initialized
INFO - 2023-10-06 12:11:18 --> Language Class Initialized
INFO - 2023-10-06 12:11:18 --> Language Class Initialized
INFO - 2023-10-06 12:11:18 --> Config Class Initialized
INFO - 2023-10-06 12:11:18 --> Loader Class Initialized
INFO - 2023-10-06 12:11:18 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:18 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:18 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:18 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:18 --> Total execution time: 0.1279
INFO - 2023-10-06 12:11:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:21 --> Total execution time: 6.1778
INFO - 2023-10-06 12:11:21 --> Config Class Initialized
INFO - 2023-10-06 12:11:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:21 --> URI Class Initialized
INFO - 2023-10-06 12:11:21 --> Router Class Initialized
INFO - 2023-10-06 12:11:21 --> Output Class Initialized
INFO - 2023-10-06 12:11:21 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:21 --> Input Class Initialized
INFO - 2023-10-06 12:11:21 --> Language Class Initialized
INFO - 2023-10-06 12:11:21 --> Language Class Initialized
INFO - 2023-10-06 12:11:21 --> Config Class Initialized
INFO - 2023-10-06 12:11:21 --> Loader Class Initialized
INFO - 2023-10-06 12:11:21 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:21 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:21 --> Controller Class Initialized
INFO - 2023-10-06 12:11:21 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:11:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:21 --> Total execution time: 0.0449
INFO - 2023-10-06 12:11:21 --> Config Class Initialized
INFO - 2023-10-06 12:11:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:21 --> URI Class Initialized
INFO - 2023-10-06 12:11:21 --> Router Class Initialized
INFO - 2023-10-06 12:11:21 --> Output Class Initialized
INFO - 2023-10-06 12:11:21 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:21 --> Input Class Initialized
INFO - 2023-10-06 12:11:21 --> Language Class Initialized
INFO - 2023-10-06 12:11:21 --> Language Class Initialized
INFO - 2023-10-06 12:11:21 --> Config Class Initialized
INFO - 2023-10-06 12:11:21 --> Loader Class Initialized
INFO - 2023-10-06 12:11:21 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:21 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:21 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:21 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:11:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:21 --> Total execution time: 0.0625
INFO - 2023-10-06 12:11:25 --> Config Class Initialized
INFO - 2023-10-06 12:11:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:25 --> URI Class Initialized
INFO - 2023-10-06 12:11:25 --> Router Class Initialized
INFO - 2023-10-06 12:11:25 --> Output Class Initialized
INFO - 2023-10-06 12:11:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:25 --> Input Class Initialized
INFO - 2023-10-06 12:11:25 --> Language Class Initialized
INFO - 2023-10-06 12:11:25 --> Language Class Initialized
INFO - 2023-10-06 12:11:25 --> Config Class Initialized
INFO - 2023-10-06 12:11:25 --> Loader Class Initialized
INFO - 2023-10-06 12:11:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:25 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:25 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:25 --> Total execution time: 0.0336
INFO - 2023-10-06 12:11:29 --> Config Class Initialized
INFO - 2023-10-06 12:11:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:29 --> URI Class Initialized
INFO - 2023-10-06 12:11:29 --> Router Class Initialized
INFO - 2023-10-06 12:11:29 --> Output Class Initialized
INFO - 2023-10-06 12:11:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:29 --> Input Class Initialized
INFO - 2023-10-06 12:11:29 --> Language Class Initialized
INFO - 2023-10-06 12:11:29 --> Language Class Initialized
INFO - 2023-10-06 12:11:29 --> Config Class Initialized
INFO - 2023-10-06 12:11:29 --> Loader Class Initialized
INFO - 2023-10-06 12:11:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:29 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:29 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:29 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:29 --> Total execution time: 0.0412
INFO - 2023-10-06 12:11:29 --> Config Class Initialized
INFO - 2023-10-06 12:11:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:29 --> URI Class Initialized
INFO - 2023-10-06 12:11:29 --> Router Class Initialized
INFO - 2023-10-06 12:11:29 --> Output Class Initialized
INFO - 2023-10-06 12:11:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:29 --> Input Class Initialized
INFO - 2023-10-06 12:11:29 --> Language Class Initialized
INFO - 2023-10-06 12:11:29 --> Language Class Initialized
INFO - 2023-10-06 12:11:29 --> Config Class Initialized
INFO - 2023-10-06 12:11:29 --> Loader Class Initialized
INFO - 2023-10-06 12:11:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:29 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:29 --> Controller Class Initialized
INFO - 2023-10-06 12:11:36 --> Config Class Initialized
INFO - 2023-10-06 12:11:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:36 --> URI Class Initialized
INFO - 2023-10-06 12:11:36 --> Router Class Initialized
INFO - 2023-10-06 12:11:36 --> Output Class Initialized
INFO - 2023-10-06 12:11:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:36 --> Input Class Initialized
INFO - 2023-10-06 12:11:36 --> Language Class Initialized
INFO - 2023-10-06 12:11:36 --> Language Class Initialized
INFO - 2023-10-06 12:11:36 --> Config Class Initialized
INFO - 2023-10-06 12:11:36 --> Loader Class Initialized
INFO - 2023-10-06 12:11:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:36 --> Controller Class Initialized
INFO - 2023-10-06 12:11:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:36 --> Total execution time: 0.0356
INFO - 2023-10-06 12:11:39 --> Config Class Initialized
INFO - 2023-10-06 12:11:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:39 --> URI Class Initialized
INFO - 2023-10-06 12:11:39 --> Router Class Initialized
INFO - 2023-10-06 12:11:39 --> Output Class Initialized
INFO - 2023-10-06 12:11:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:39 --> Input Class Initialized
INFO - 2023-10-06 12:11:39 --> Language Class Initialized
INFO - 2023-10-06 12:11:39 --> Language Class Initialized
INFO - 2023-10-06 12:11:39 --> Config Class Initialized
INFO - 2023-10-06 12:11:39 --> Loader Class Initialized
INFO - 2023-10-06 12:11:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:39 --> Controller Class Initialized
INFO - 2023-10-06 12:11:39 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:39 --> Total execution time: 0.0383
INFO - 2023-10-06 12:11:43 --> Config Class Initialized
INFO - 2023-10-06 12:11:43 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:43 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:43 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:43 --> URI Class Initialized
INFO - 2023-10-06 12:11:43 --> Router Class Initialized
INFO - 2023-10-06 12:11:43 --> Output Class Initialized
INFO - 2023-10-06 12:11:43 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:43 --> Input Class Initialized
INFO - 2023-10-06 12:11:43 --> Language Class Initialized
INFO - 2023-10-06 12:11:43 --> Language Class Initialized
INFO - 2023-10-06 12:11:43 --> Config Class Initialized
INFO - 2023-10-06 12:11:43 --> Loader Class Initialized
INFO - 2023-10-06 12:11:43 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:43 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:43 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:43 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:43 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:43 --> Controller Class Initialized
INFO - 2023-10-06 12:11:43 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:43 --> Total execution time: 0.0378
INFO - 2023-10-06 12:11:47 --> Config Class Initialized
INFO - 2023-10-06 12:11:47 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:47 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:47 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:47 --> URI Class Initialized
INFO - 2023-10-06 12:11:47 --> Router Class Initialized
INFO - 2023-10-06 12:11:47 --> Output Class Initialized
INFO - 2023-10-06 12:11:47 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:47 --> Input Class Initialized
INFO - 2023-10-06 12:11:47 --> Language Class Initialized
INFO - 2023-10-06 12:11:47 --> Language Class Initialized
INFO - 2023-10-06 12:11:47 --> Config Class Initialized
INFO - 2023-10-06 12:11:47 --> Loader Class Initialized
INFO - 2023-10-06 12:11:47 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:47 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:47 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:47 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:47 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:47 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:11:47 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:47 --> Total execution time: 0.0384
INFO - 2023-10-06 12:11:55 --> Config Class Initialized
INFO - 2023-10-06 12:11:55 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:11:55 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:11:55 --> Utf8 Class Initialized
INFO - 2023-10-06 12:11:55 --> URI Class Initialized
INFO - 2023-10-06 12:11:55 --> Router Class Initialized
INFO - 2023-10-06 12:11:55 --> Output Class Initialized
INFO - 2023-10-06 12:11:55 --> Security Class Initialized
DEBUG - 2023-10-06 12:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:11:55 --> Input Class Initialized
INFO - 2023-10-06 12:11:55 --> Language Class Initialized
INFO - 2023-10-06 12:11:55 --> Language Class Initialized
INFO - 2023-10-06 12:11:55 --> Config Class Initialized
INFO - 2023-10-06 12:11:55 --> Loader Class Initialized
INFO - 2023-10-06 12:11:55 --> Helper loaded: url_helper
INFO - 2023-10-06 12:11:55 --> Helper loaded: file_helper
INFO - 2023-10-06 12:11:55 --> Helper loaded: form_helper
INFO - 2023-10-06 12:11:55 --> Helper loaded: my_helper
INFO - 2023-10-06 12:11:55 --> Database Driver Class Initialized
INFO - 2023-10-06 12:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:11:55 --> Controller Class Initialized
DEBUG - 2023-10-06 12:11:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:11:59 --> Final output sent to browser
DEBUG - 2023-10-06 12:11:59 --> Total execution time: 4.3520
INFO - 2023-10-06 12:12:26 --> Config Class Initialized
INFO - 2023-10-06 12:12:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:12:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:12:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:12:26 --> URI Class Initialized
INFO - 2023-10-06 12:12:26 --> Router Class Initialized
INFO - 2023-10-06 12:12:26 --> Output Class Initialized
INFO - 2023-10-06 12:12:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:12:26 --> Input Class Initialized
INFO - 2023-10-06 12:12:26 --> Language Class Initialized
INFO - 2023-10-06 12:12:26 --> Language Class Initialized
INFO - 2023-10-06 12:12:26 --> Config Class Initialized
INFO - 2023-10-06 12:12:26 --> Loader Class Initialized
INFO - 2023-10-06 12:12:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:12:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:12:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:12:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:12:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:12:26 --> Controller Class Initialized
DEBUG - 2023-10-06 12:12:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:12:32 --> Final output sent to browser
DEBUG - 2023-10-06 12:12:32 --> Total execution time: 5.9597
INFO - 2023-10-06 12:13:26 --> Config Class Initialized
INFO - 2023-10-06 12:13:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:13:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:13:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:13:26 --> URI Class Initialized
INFO - 2023-10-06 12:13:26 --> Router Class Initialized
INFO - 2023-10-06 12:13:26 --> Output Class Initialized
INFO - 2023-10-06 12:13:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:13:26 --> Input Class Initialized
INFO - 2023-10-06 12:13:26 --> Language Class Initialized
INFO - 2023-10-06 12:13:26 --> Language Class Initialized
INFO - 2023-10-06 12:13:26 --> Config Class Initialized
INFO - 2023-10-06 12:13:26 --> Loader Class Initialized
INFO - 2023-10-06 12:13:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:13:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:13:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:13:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:13:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:13:26 --> Controller Class Initialized
INFO - 2023-10-06 12:13:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:13:26 --> Total execution time: 0.0909
INFO - 2023-10-06 12:13:50 --> Config Class Initialized
INFO - 2023-10-06 12:13:50 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:13:50 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:13:50 --> Utf8 Class Initialized
INFO - 2023-10-06 12:13:50 --> URI Class Initialized
INFO - 2023-10-06 12:13:50 --> Router Class Initialized
INFO - 2023-10-06 12:13:50 --> Output Class Initialized
INFO - 2023-10-06 12:13:50 --> Security Class Initialized
DEBUG - 2023-10-06 12:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:13:50 --> Input Class Initialized
INFO - 2023-10-06 12:13:50 --> Language Class Initialized
INFO - 2023-10-06 12:13:50 --> Language Class Initialized
INFO - 2023-10-06 12:13:50 --> Config Class Initialized
INFO - 2023-10-06 12:13:50 --> Loader Class Initialized
INFO - 2023-10-06 12:13:50 --> Helper loaded: url_helper
INFO - 2023-10-06 12:13:50 --> Helper loaded: file_helper
INFO - 2023-10-06 12:13:50 --> Helper loaded: form_helper
INFO - 2023-10-06 12:13:50 --> Helper loaded: my_helper
INFO - 2023-10-06 12:13:50 --> Database Driver Class Initialized
INFO - 2023-10-06 12:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:13:50 --> Controller Class Initialized
DEBUG - 2023-10-06 12:13:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:13:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:13:50 --> Final output sent to browser
DEBUG - 2023-10-06 12:13:50 --> Total execution time: 0.0584
INFO - 2023-10-06 12:13:52 --> Config Class Initialized
INFO - 2023-10-06 12:13:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:13:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:13:52 --> Utf8 Class Initialized
INFO - 2023-10-06 12:13:52 --> URI Class Initialized
INFO - 2023-10-06 12:13:52 --> Router Class Initialized
INFO - 2023-10-06 12:13:52 --> Output Class Initialized
INFO - 2023-10-06 12:13:52 --> Security Class Initialized
DEBUG - 2023-10-06 12:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:13:52 --> Input Class Initialized
INFO - 2023-10-06 12:13:52 --> Language Class Initialized
INFO - 2023-10-06 12:13:52 --> Language Class Initialized
INFO - 2023-10-06 12:13:52 --> Config Class Initialized
INFO - 2023-10-06 12:13:52 --> Loader Class Initialized
INFO - 2023-10-06 12:13:52 --> Helper loaded: url_helper
INFO - 2023-10-06 12:13:52 --> Helper loaded: file_helper
INFO - 2023-10-06 12:13:52 --> Helper loaded: form_helper
INFO - 2023-10-06 12:13:52 --> Helper loaded: my_helper
INFO - 2023-10-06 12:13:52 --> Database Driver Class Initialized
INFO - 2023-10-06 12:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:13:52 --> Controller Class Initialized
DEBUG - 2023-10-06 12:13:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:13:57 --> Final output sent to browser
DEBUG - 2023-10-06 12:13:57 --> Total execution time: 4.6027
INFO - 2023-10-06 12:14:08 --> Config Class Initialized
INFO - 2023-10-06 12:14:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:08 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:08 --> URI Class Initialized
INFO - 2023-10-06 12:14:08 --> Router Class Initialized
INFO - 2023-10-06 12:14:08 --> Output Class Initialized
INFO - 2023-10-06 12:14:08 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:08 --> Input Class Initialized
INFO - 2023-10-06 12:14:08 --> Language Class Initialized
INFO - 2023-10-06 12:14:08 --> Language Class Initialized
INFO - 2023-10-06 12:14:08 --> Config Class Initialized
INFO - 2023-10-06 12:14:08 --> Loader Class Initialized
INFO - 2023-10-06 12:14:08 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:08 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:08 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:08 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:08 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:08 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:14:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:12 --> Total execution time: 4.1951
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:16 --> URI Class Initialized
INFO - 2023-10-06 12:14:16 --> Router Class Initialized
INFO - 2023-10-06 12:14:16 --> Output Class Initialized
INFO - 2023-10-06 12:14:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:16 --> Input Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Loader Class Initialized
INFO - 2023-10-06 12:14:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:16 --> Controller Class Initialized
INFO - 2023-10-06 12:14:16 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:16 --> URI Class Initialized
INFO - 2023-10-06 12:14:16 --> Router Class Initialized
INFO - 2023-10-06 12:14:16 --> Output Class Initialized
INFO - 2023-10-06 12:14:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:16 --> Input Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Loader Class Initialized
INFO - 2023-10-06 12:14:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:16 --> Controller Class Initialized
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:16 --> URI Class Initialized
INFO - 2023-10-06 12:14:16 --> Router Class Initialized
INFO - 2023-10-06 12:14:16 --> Output Class Initialized
INFO - 2023-10-06 12:14:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:16 --> Input Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Language Class Initialized
INFO - 2023-10-06 12:14:16 --> Config Class Initialized
INFO - 2023-10-06 12:14:16 --> Loader Class Initialized
INFO - 2023-10-06 12:14:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:16 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:14:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:16 --> Total execution time: 0.0328
INFO - 2023-10-06 12:14:23 --> Config Class Initialized
INFO - 2023-10-06 12:14:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:23 --> URI Class Initialized
INFO - 2023-10-06 12:14:23 --> Router Class Initialized
INFO - 2023-10-06 12:14:23 --> Output Class Initialized
INFO - 2023-10-06 12:14:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:23 --> Input Class Initialized
INFO - 2023-10-06 12:14:23 --> Language Class Initialized
INFO - 2023-10-06 12:14:23 --> Language Class Initialized
INFO - 2023-10-06 12:14:23 --> Config Class Initialized
INFO - 2023-10-06 12:14:23 --> Loader Class Initialized
INFO - 2023-10-06 12:14:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:23 --> Controller Class Initialized
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:25 --> URI Class Initialized
INFO - 2023-10-06 12:14:25 --> Router Class Initialized
INFO - 2023-10-06 12:14:25 --> Output Class Initialized
INFO - 2023-10-06 12:14:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:25 --> Input Class Initialized
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Loader Class Initialized
INFO - 2023-10-06 12:14:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:25 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:14:25 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:25 --> Total execution time: 0.1320
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:25 --> URI Class Initialized
INFO - 2023-10-06 12:14:25 --> Router Class Initialized
INFO - 2023-10-06 12:14:25 --> Output Class Initialized
INFO - 2023-10-06 12:14:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:25 --> Input Class Initialized
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:25 --> URI Class Initialized
INFO - 2023-10-06 12:14:25 --> Router Class Initialized
INFO - 2023-10-06 12:14:25 --> Output Class Initialized
INFO - 2023-10-06 12:14:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:25 --> Input Class Initialized
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Loader Class Initialized
INFO - 2023-10-06 12:14:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:25 --> Language Class Initialized
INFO - 2023-10-06 12:14:25 --> Config Class Initialized
INFO - 2023-10-06 12:14:25 --> Loader Class Initialized
INFO - 2023-10-06 12:14:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:25 --> Controller Class Initialized
INFO - 2023-10-06 12:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:25 --> Controller Class Initialized
INFO - 2023-10-06 12:14:26 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:14:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:26 --> Total execution time: 0.1872
INFO - 2023-10-06 12:14:26 --> Config Class Initialized
INFO - 2023-10-06 12:14:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:26 --> URI Class Initialized
INFO - 2023-10-06 12:14:26 --> Router Class Initialized
INFO - 2023-10-06 12:14:26 --> Output Class Initialized
INFO - 2023-10-06 12:14:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:26 --> Input Class Initialized
INFO - 2023-10-06 12:14:26 --> Language Class Initialized
INFO - 2023-10-06 12:14:26 --> Language Class Initialized
INFO - 2023-10-06 12:14:26 --> Config Class Initialized
INFO - 2023-10-06 12:14:26 --> Loader Class Initialized
INFO - 2023-10-06 12:14:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:26 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:14:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:26 --> Total execution time: 0.0311
INFO - 2023-10-06 12:14:29 --> Config Class Initialized
INFO - 2023-10-06 12:14:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:29 --> URI Class Initialized
INFO - 2023-10-06 12:14:29 --> Router Class Initialized
INFO - 2023-10-06 12:14:29 --> Output Class Initialized
INFO - 2023-10-06 12:14:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:29 --> Input Class Initialized
INFO - 2023-10-06 12:14:29 --> Language Class Initialized
INFO - 2023-10-06 12:14:29 --> Language Class Initialized
INFO - 2023-10-06 12:14:29 --> Config Class Initialized
INFO - 2023-10-06 12:14:29 --> Loader Class Initialized
INFO - 2023-10-06 12:14:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:29 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:29 --> Controller Class Initialized
INFO - 2023-10-06 12:14:29 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:29 --> Total execution time: 0.0314
INFO - 2023-10-06 12:14:33 --> Config Class Initialized
INFO - 2023-10-06 12:14:33 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:33 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:33 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:33 --> URI Class Initialized
INFO - 2023-10-06 12:14:33 --> Router Class Initialized
INFO - 2023-10-06 12:14:33 --> Output Class Initialized
INFO - 2023-10-06 12:14:33 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:33 --> Input Class Initialized
INFO - 2023-10-06 12:14:33 --> Language Class Initialized
INFO - 2023-10-06 12:14:33 --> Language Class Initialized
INFO - 2023-10-06 12:14:33 --> Config Class Initialized
INFO - 2023-10-06 12:14:33 --> Loader Class Initialized
INFO - 2023-10-06 12:14:33 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:33 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:33 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:33 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:33 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:33 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:14:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:14:33 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:33 --> Total execution time: 0.0701
INFO - 2023-10-06 12:14:56 --> Config Class Initialized
INFO - 2023-10-06 12:14:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:56 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:56 --> URI Class Initialized
INFO - 2023-10-06 12:14:56 --> Router Class Initialized
INFO - 2023-10-06 12:14:56 --> Output Class Initialized
INFO - 2023-10-06 12:14:56 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:56 --> Input Class Initialized
INFO - 2023-10-06 12:14:56 --> Language Class Initialized
INFO - 2023-10-06 12:14:56 --> Language Class Initialized
INFO - 2023-10-06 12:14:56 --> Config Class Initialized
INFO - 2023-10-06 12:14:56 --> Loader Class Initialized
INFO - 2023-10-06 12:14:56 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:56 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:56 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:56 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:56 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:56 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:14:57 --> Config Class Initialized
INFO - 2023-10-06 12:14:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:57 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:57 --> URI Class Initialized
INFO - 2023-10-06 12:14:57 --> Router Class Initialized
INFO - 2023-10-06 12:14:57 --> Output Class Initialized
INFO - 2023-10-06 12:14:57 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:57 --> Input Class Initialized
INFO - 2023-10-06 12:14:57 --> Language Class Initialized
INFO - 2023-10-06 12:14:57 --> Language Class Initialized
INFO - 2023-10-06 12:14:57 --> Config Class Initialized
INFO - 2023-10-06 12:14:57 --> Loader Class Initialized
INFO - 2023-10-06 12:14:57 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:57 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:57 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:57 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:57 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:57 --> Controller Class Initialized
INFO - 2023-10-06 12:14:57 --> Final output sent to browser
DEBUG - 2023-10-06 12:14:57 --> Total execution time: 0.5537
INFO - 2023-10-06 12:14:59 --> Config Class Initialized
INFO - 2023-10-06 12:14:59 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:14:59 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:14:59 --> Utf8 Class Initialized
INFO - 2023-10-06 12:14:59 --> URI Class Initialized
INFO - 2023-10-06 12:14:59 --> Router Class Initialized
INFO - 2023-10-06 12:14:59 --> Output Class Initialized
INFO - 2023-10-06 12:14:59 --> Security Class Initialized
DEBUG - 2023-10-06 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:14:59 --> Input Class Initialized
INFO - 2023-10-06 12:14:59 --> Language Class Initialized
INFO - 2023-10-06 12:14:59 --> Language Class Initialized
INFO - 2023-10-06 12:14:59 --> Config Class Initialized
INFO - 2023-10-06 12:14:59 --> Loader Class Initialized
INFO - 2023-10-06 12:14:59 --> Helper loaded: url_helper
INFO - 2023-10-06 12:14:59 --> Helper loaded: file_helper
INFO - 2023-10-06 12:14:59 --> Helper loaded: form_helper
INFO - 2023-10-06 12:14:59 --> Helper loaded: my_helper
INFO - 2023-10-06 12:14:59 --> Database Driver Class Initialized
INFO - 2023-10-06 12:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:14:59 --> Controller Class Initialized
DEBUG - 2023-10-06 12:14:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:15:00 --> Config Class Initialized
INFO - 2023-10-06 12:15:00 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:15:00 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:15:00 --> Utf8 Class Initialized
INFO - 2023-10-06 12:15:00 --> URI Class Initialized
INFO - 2023-10-06 12:15:00 --> Router Class Initialized
INFO - 2023-10-06 12:15:00 --> Output Class Initialized
INFO - 2023-10-06 12:15:00 --> Security Class Initialized
DEBUG - 2023-10-06 12:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:15:00 --> Input Class Initialized
INFO - 2023-10-06 12:15:00 --> Language Class Initialized
INFO - 2023-10-06 12:15:00 --> Language Class Initialized
INFO - 2023-10-06 12:15:00 --> Config Class Initialized
INFO - 2023-10-06 12:15:00 --> Loader Class Initialized
INFO - 2023-10-06 12:15:00 --> Helper loaded: url_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: file_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: form_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: my_helper
INFO - 2023-10-06 12:15:00 --> Database Driver Class Initialized
INFO - 2023-10-06 12:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:15:00 --> Controller Class Initialized
DEBUG - 2023-10-06 12:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:15:00 --> Final output sent to browser
DEBUG - 2023-10-06 12:15:00 --> Total execution time: 0.1178
INFO - 2023-10-06 12:15:00 --> Config Class Initialized
INFO - 2023-10-06 12:15:00 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:15:00 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:15:00 --> Utf8 Class Initialized
INFO - 2023-10-06 12:15:00 --> URI Class Initialized
INFO - 2023-10-06 12:15:00 --> Router Class Initialized
INFO - 2023-10-06 12:15:00 --> Output Class Initialized
INFO - 2023-10-06 12:15:00 --> Security Class Initialized
DEBUG - 2023-10-06 12:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:15:00 --> Input Class Initialized
INFO - 2023-10-06 12:15:00 --> Language Class Initialized
INFO - 2023-10-06 12:15:00 --> Language Class Initialized
INFO - 2023-10-06 12:15:00 --> Config Class Initialized
INFO - 2023-10-06 12:15:00 --> Loader Class Initialized
INFO - 2023-10-06 12:15:00 --> Helper loaded: url_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: file_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: form_helper
INFO - 2023-10-06 12:15:00 --> Helper loaded: my_helper
INFO - 2023-10-06 12:15:00 --> Database Driver Class Initialized
INFO - 2023-10-06 12:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:15:00 --> Controller Class Initialized
INFO - 2023-10-06 12:15:04 --> Final output sent to browser
DEBUG - 2023-10-06 12:15:04 --> Total execution time: 7.3732
INFO - 2023-10-06 12:15:05 --> Final output sent to browser
DEBUG - 2023-10-06 12:15:05 --> Total execution time: 6.5044
INFO - 2023-10-06 12:15:47 --> Config Class Initialized
INFO - 2023-10-06 12:15:47 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:15:47 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:15:47 --> Utf8 Class Initialized
INFO - 2023-10-06 12:15:47 --> URI Class Initialized
INFO - 2023-10-06 12:15:47 --> Router Class Initialized
INFO - 2023-10-06 12:15:48 --> Output Class Initialized
INFO - 2023-10-06 12:15:48 --> Security Class Initialized
DEBUG - 2023-10-06 12:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:15:48 --> Input Class Initialized
INFO - 2023-10-06 12:15:48 --> Language Class Initialized
INFO - 2023-10-06 12:15:48 --> Language Class Initialized
INFO - 2023-10-06 12:15:48 --> Config Class Initialized
INFO - 2023-10-06 12:15:48 --> Loader Class Initialized
INFO - 2023-10-06 12:15:48 --> Helper loaded: url_helper
INFO - 2023-10-06 12:15:48 --> Helper loaded: file_helper
INFO - 2023-10-06 12:15:48 --> Helper loaded: form_helper
INFO - 2023-10-06 12:15:48 --> Helper loaded: my_helper
INFO - 2023-10-06 12:15:48 --> Database Driver Class Initialized
INFO - 2023-10-06 12:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:15:48 --> Controller Class Initialized
INFO - 2023-10-06 12:15:48 --> Final output sent to browser
DEBUG - 2023-10-06 12:15:48 --> Total execution time: 0.0629
INFO - 2023-10-06 12:15:57 --> Config Class Initialized
INFO - 2023-10-06 12:15:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:15:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:15:57 --> Utf8 Class Initialized
INFO - 2023-10-06 12:15:57 --> URI Class Initialized
INFO - 2023-10-06 12:15:57 --> Router Class Initialized
INFO - 2023-10-06 12:15:57 --> Output Class Initialized
INFO - 2023-10-06 12:15:57 --> Security Class Initialized
DEBUG - 2023-10-06 12:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:15:57 --> Input Class Initialized
INFO - 2023-10-06 12:15:57 --> Language Class Initialized
INFO - 2023-10-06 12:15:57 --> Language Class Initialized
INFO - 2023-10-06 12:15:57 --> Config Class Initialized
INFO - 2023-10-06 12:15:57 --> Loader Class Initialized
INFO - 2023-10-06 12:15:57 --> Helper loaded: url_helper
INFO - 2023-10-06 12:15:57 --> Helper loaded: file_helper
INFO - 2023-10-06 12:15:57 --> Helper loaded: form_helper
INFO - 2023-10-06 12:15:57 --> Helper loaded: my_helper
INFO - 2023-10-06 12:15:57 --> Database Driver Class Initialized
INFO - 2023-10-06 12:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:15:57 --> Controller Class Initialized
DEBUG - 2023-10-06 12:15:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:16:02 --> Final output sent to browser
DEBUG - 2023-10-06 12:16:02 --> Total execution time: 4.1814
INFO - 2023-10-06 12:16:05 --> Config Class Initialized
INFO - 2023-10-06 12:16:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:16:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:16:05 --> Utf8 Class Initialized
INFO - 2023-10-06 12:16:05 --> URI Class Initialized
INFO - 2023-10-06 12:16:05 --> Router Class Initialized
INFO - 2023-10-06 12:16:05 --> Output Class Initialized
INFO - 2023-10-06 12:16:05 --> Security Class Initialized
DEBUG - 2023-10-06 12:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:16:05 --> Input Class Initialized
INFO - 2023-10-06 12:16:05 --> Language Class Initialized
INFO - 2023-10-06 12:16:05 --> Language Class Initialized
INFO - 2023-10-06 12:16:05 --> Config Class Initialized
INFO - 2023-10-06 12:16:05 --> Loader Class Initialized
INFO - 2023-10-06 12:16:05 --> Helper loaded: url_helper
INFO - 2023-10-06 12:16:05 --> Helper loaded: file_helper
INFO - 2023-10-06 12:16:05 --> Helper loaded: form_helper
INFO - 2023-10-06 12:16:05 --> Helper loaded: my_helper
INFO - 2023-10-06 12:16:05 --> Database Driver Class Initialized
INFO - 2023-10-06 12:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:16:05 --> Controller Class Initialized
DEBUG - 2023-10-06 12:16:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:16:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:16:05 --> Final output sent to browser
DEBUG - 2023-10-06 12:16:05 --> Total execution time: 0.0709
INFO - 2023-10-06 12:16:06 --> Config Class Initialized
INFO - 2023-10-06 12:16:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:16:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:16:06 --> Utf8 Class Initialized
INFO - 2023-10-06 12:16:06 --> URI Class Initialized
INFO - 2023-10-06 12:16:06 --> Router Class Initialized
INFO - 2023-10-06 12:16:06 --> Output Class Initialized
INFO - 2023-10-06 12:16:06 --> Security Class Initialized
DEBUG - 2023-10-06 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:16:06 --> Input Class Initialized
INFO - 2023-10-06 12:16:06 --> Language Class Initialized
INFO - 2023-10-06 12:16:06 --> Language Class Initialized
INFO - 2023-10-06 12:16:06 --> Config Class Initialized
INFO - 2023-10-06 12:16:06 --> Loader Class Initialized
INFO - 2023-10-06 12:16:06 --> Helper loaded: url_helper
INFO - 2023-10-06 12:16:06 --> Helper loaded: file_helper
INFO - 2023-10-06 12:16:06 --> Helper loaded: form_helper
INFO - 2023-10-06 12:16:06 --> Helper loaded: my_helper
INFO - 2023-10-06 12:16:06 --> Database Driver Class Initialized
INFO - 2023-10-06 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:16:06 --> Controller Class Initialized
INFO - 2023-10-06 12:16:10 --> Config Class Initialized
INFO - 2023-10-06 12:16:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:16:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:16:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:16:10 --> URI Class Initialized
INFO - 2023-10-06 12:16:10 --> Router Class Initialized
INFO - 2023-10-06 12:16:10 --> Output Class Initialized
INFO - 2023-10-06 12:16:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:16:10 --> Input Class Initialized
INFO - 2023-10-06 12:16:10 --> Language Class Initialized
INFO - 2023-10-06 12:16:10 --> Language Class Initialized
INFO - 2023-10-06 12:16:10 --> Config Class Initialized
INFO - 2023-10-06 12:16:10 --> Loader Class Initialized
INFO - 2023-10-06 12:16:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:16:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:16:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:16:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:16:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:16:10 --> Controller Class Initialized
INFO - 2023-10-06 12:16:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:16:10 --> Total execution time: 0.0762
INFO - 2023-10-06 12:16:36 --> Config Class Initialized
INFO - 2023-10-06 12:16:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:16:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:16:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:16:36 --> URI Class Initialized
INFO - 2023-10-06 12:16:36 --> Router Class Initialized
INFO - 2023-10-06 12:16:36 --> Output Class Initialized
INFO - 2023-10-06 12:16:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:16:36 --> Input Class Initialized
INFO - 2023-10-06 12:16:36 --> Language Class Initialized
INFO - 2023-10-06 12:16:36 --> Language Class Initialized
INFO - 2023-10-06 12:16:36 --> Config Class Initialized
INFO - 2023-10-06 12:16:36 --> Loader Class Initialized
INFO - 2023-10-06 12:16:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:16:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:16:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:16:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:16:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:16:36 --> Controller Class Initialized
INFO - 2023-10-06 12:16:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:16:36 --> Total execution time: 0.1243
INFO - 2023-10-06 12:16:38 --> Config Class Initialized
INFO - 2023-10-06 12:16:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:16:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:16:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:16:38 --> URI Class Initialized
INFO - 2023-10-06 12:16:38 --> Router Class Initialized
INFO - 2023-10-06 12:16:38 --> Output Class Initialized
INFO - 2023-10-06 12:16:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:16:38 --> Input Class Initialized
INFO - 2023-10-06 12:16:38 --> Language Class Initialized
INFO - 2023-10-06 12:16:38 --> Language Class Initialized
INFO - 2023-10-06 12:16:38 --> Config Class Initialized
INFO - 2023-10-06 12:16:38 --> Loader Class Initialized
INFO - 2023-10-06 12:16:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:16:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:16:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:16:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:16:38 --> Database Driver Class Initialized
INFO - 2023-10-06 12:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:16:38 --> Controller Class Initialized
INFO - 2023-10-06 12:16:38 --> Final output sent to browser
DEBUG - 2023-10-06 12:16:38 --> Total execution time: 0.0711
INFO - 2023-10-06 12:17:06 --> Config Class Initialized
INFO - 2023-10-06 12:17:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:17:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:17:06 --> Utf8 Class Initialized
INFO - 2023-10-06 12:17:06 --> URI Class Initialized
INFO - 2023-10-06 12:17:06 --> Router Class Initialized
INFO - 2023-10-06 12:17:06 --> Output Class Initialized
INFO - 2023-10-06 12:17:06 --> Security Class Initialized
DEBUG - 2023-10-06 12:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:17:06 --> Input Class Initialized
INFO - 2023-10-06 12:17:06 --> Language Class Initialized
INFO - 2023-10-06 12:17:06 --> Language Class Initialized
INFO - 2023-10-06 12:17:06 --> Config Class Initialized
INFO - 2023-10-06 12:17:06 --> Loader Class Initialized
INFO - 2023-10-06 12:17:06 --> Helper loaded: url_helper
INFO - 2023-10-06 12:17:06 --> Helper loaded: file_helper
INFO - 2023-10-06 12:17:06 --> Helper loaded: form_helper
INFO - 2023-10-06 12:17:06 --> Helper loaded: my_helper
INFO - 2023-10-06 12:17:06 --> Database Driver Class Initialized
INFO - 2023-10-06 12:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:17:06 --> Controller Class Initialized
DEBUG - 2023-10-06 12:17:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:17:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:17:09 --> Total execution time: 3.5269
INFO - 2023-10-06 12:17:14 --> Config Class Initialized
INFO - 2023-10-06 12:17:14 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:17:14 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:17:14 --> Utf8 Class Initialized
INFO - 2023-10-06 12:17:14 --> URI Class Initialized
INFO - 2023-10-06 12:17:14 --> Router Class Initialized
INFO - 2023-10-06 12:17:14 --> Output Class Initialized
INFO - 2023-10-06 12:17:14 --> Security Class Initialized
DEBUG - 2023-10-06 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:17:14 --> Input Class Initialized
INFO - 2023-10-06 12:17:14 --> Language Class Initialized
INFO - 2023-10-06 12:17:14 --> Language Class Initialized
INFO - 2023-10-06 12:17:14 --> Config Class Initialized
INFO - 2023-10-06 12:17:14 --> Loader Class Initialized
INFO - 2023-10-06 12:17:14 --> Helper loaded: url_helper
INFO - 2023-10-06 12:17:14 --> Helper loaded: file_helper
INFO - 2023-10-06 12:17:14 --> Helper loaded: form_helper
INFO - 2023-10-06 12:17:14 --> Helper loaded: my_helper
INFO - 2023-10-06 12:17:14 --> Database Driver Class Initialized
INFO - 2023-10-06 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:17:14 --> Controller Class Initialized
DEBUG - 2023-10-06 12:17:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:17:16 --> Config Class Initialized
INFO - 2023-10-06 12:17:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:17:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:17:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:17:16 --> URI Class Initialized
INFO - 2023-10-06 12:17:16 --> Router Class Initialized
INFO - 2023-10-06 12:17:16 --> Output Class Initialized
INFO - 2023-10-06 12:17:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:17:16 --> Input Class Initialized
INFO - 2023-10-06 12:17:16 --> Language Class Initialized
INFO - 2023-10-06 12:17:16 --> Language Class Initialized
INFO - 2023-10-06 12:17:16 --> Config Class Initialized
INFO - 2023-10-06 12:17:16 --> Loader Class Initialized
INFO - 2023-10-06 12:17:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:17:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:17:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:17:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:17:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:17:16 --> Controller Class Initialized
INFO - 2023-10-06 12:17:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:17:16 --> Total execution time: 0.0722
INFO - 2023-10-06 12:17:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:17:18 --> Total execution time: 4.0262
INFO - 2023-10-06 12:17:22 --> Config Class Initialized
INFO - 2023-10-06 12:17:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:17:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:17:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:17:22 --> URI Class Initialized
INFO - 2023-10-06 12:17:22 --> Router Class Initialized
INFO - 2023-10-06 12:17:22 --> Output Class Initialized
INFO - 2023-10-06 12:17:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:17:22 --> Input Class Initialized
INFO - 2023-10-06 12:17:22 --> Language Class Initialized
INFO - 2023-10-06 12:17:22 --> Language Class Initialized
INFO - 2023-10-06 12:17:22 --> Config Class Initialized
INFO - 2023-10-06 12:17:22 --> Loader Class Initialized
INFO - 2023-10-06 12:17:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:17:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:17:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:17:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:17:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:17:22 --> Controller Class Initialized
INFO - 2023-10-06 12:17:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:17:22 --> Total execution time: 0.0370
INFO - 2023-10-06 12:18:18 --> Config Class Initialized
INFO - 2023-10-06 12:18:18 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:18:18 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:18:18 --> Utf8 Class Initialized
INFO - 2023-10-06 12:18:18 --> URI Class Initialized
INFO - 2023-10-06 12:18:18 --> Router Class Initialized
INFO - 2023-10-06 12:18:18 --> Output Class Initialized
INFO - 2023-10-06 12:18:18 --> Security Class Initialized
DEBUG - 2023-10-06 12:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:18:18 --> Input Class Initialized
INFO - 2023-10-06 12:18:18 --> Language Class Initialized
INFO - 2023-10-06 12:18:19 --> Language Class Initialized
INFO - 2023-10-06 12:18:19 --> Config Class Initialized
INFO - 2023-10-06 12:18:19 --> Loader Class Initialized
INFO - 2023-10-06 12:18:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:18:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:18:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:18:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:18:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:18:19 --> Controller Class Initialized
INFO - 2023-10-06 12:18:19 --> Final output sent to browser
DEBUG - 2023-10-06 12:18:19 --> Total execution time: 0.3951
INFO - 2023-10-06 12:18:23 --> Config Class Initialized
INFO - 2023-10-06 12:18:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:18:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:18:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:18:23 --> URI Class Initialized
INFO - 2023-10-06 12:18:23 --> Router Class Initialized
INFO - 2023-10-06 12:18:23 --> Output Class Initialized
INFO - 2023-10-06 12:18:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:18:23 --> Input Class Initialized
INFO - 2023-10-06 12:18:23 --> Language Class Initialized
INFO - 2023-10-06 12:18:23 --> Language Class Initialized
INFO - 2023-10-06 12:18:23 --> Config Class Initialized
INFO - 2023-10-06 12:18:23 --> Loader Class Initialized
INFO - 2023-10-06 12:18:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:18:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:18:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:18:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:18:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:18:23 --> Controller Class Initialized
INFO - 2023-10-06 12:18:23 --> Final output sent to browser
DEBUG - 2023-10-06 12:18:23 --> Total execution time: 0.0845
INFO - 2023-10-06 12:18:26 --> Config Class Initialized
INFO - 2023-10-06 12:18:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:18:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:18:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:18:26 --> URI Class Initialized
INFO - 2023-10-06 12:18:26 --> Router Class Initialized
INFO - 2023-10-06 12:18:26 --> Output Class Initialized
INFO - 2023-10-06 12:18:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:18:26 --> Input Class Initialized
INFO - 2023-10-06 12:18:26 --> Language Class Initialized
INFO - 2023-10-06 12:18:26 --> Language Class Initialized
INFO - 2023-10-06 12:18:26 --> Config Class Initialized
INFO - 2023-10-06 12:18:26 --> Loader Class Initialized
INFO - 2023-10-06 12:18:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:18:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:18:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:18:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:18:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:18:26 --> Controller Class Initialized
INFO - 2023-10-06 12:18:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:18:26 --> Total execution time: 0.0320
INFO - 2023-10-06 12:19:09 --> Config Class Initialized
INFO - 2023-10-06 12:19:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:19:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:19:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:19:09 --> URI Class Initialized
INFO - 2023-10-06 12:19:09 --> Router Class Initialized
INFO - 2023-10-06 12:19:09 --> Output Class Initialized
INFO - 2023-10-06 12:19:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:19:09 --> Input Class Initialized
INFO - 2023-10-06 12:19:09 --> Language Class Initialized
INFO - 2023-10-06 12:19:09 --> Language Class Initialized
INFO - 2023-10-06 12:19:09 --> Config Class Initialized
INFO - 2023-10-06 12:19:09 --> Loader Class Initialized
INFO - 2023-10-06 12:19:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:19:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:19:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:19:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:19:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:19:09 --> Controller Class Initialized
INFO - 2023-10-06 12:19:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:19:09 --> Total execution time: 0.0942
INFO - 2023-10-06 12:19:15 --> Config Class Initialized
INFO - 2023-10-06 12:19:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:19:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:19:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:19:15 --> URI Class Initialized
INFO - 2023-10-06 12:19:15 --> Router Class Initialized
INFO - 2023-10-06 12:19:15 --> Output Class Initialized
INFO - 2023-10-06 12:19:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:19:15 --> Input Class Initialized
INFO - 2023-10-06 12:19:15 --> Language Class Initialized
INFO - 2023-10-06 12:19:15 --> Language Class Initialized
INFO - 2023-10-06 12:19:15 --> Config Class Initialized
INFO - 2023-10-06 12:19:15 --> Loader Class Initialized
INFO - 2023-10-06 12:19:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:19:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:19:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:19:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:19:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:19:15 --> Controller Class Initialized
INFO - 2023-10-06 12:19:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:19:15 --> Total execution time: 0.0393
INFO - 2023-10-06 12:19:18 --> Config Class Initialized
INFO - 2023-10-06 12:19:18 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:19:18 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:19:18 --> Utf8 Class Initialized
INFO - 2023-10-06 12:19:18 --> URI Class Initialized
INFO - 2023-10-06 12:19:19 --> Router Class Initialized
INFO - 2023-10-06 12:19:19 --> Output Class Initialized
INFO - 2023-10-06 12:19:19 --> Security Class Initialized
DEBUG - 2023-10-06 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:19:19 --> Input Class Initialized
INFO - 2023-10-06 12:19:19 --> Language Class Initialized
INFO - 2023-10-06 12:19:19 --> Language Class Initialized
INFO - 2023-10-06 12:19:19 --> Config Class Initialized
INFO - 2023-10-06 12:19:19 --> Loader Class Initialized
INFO - 2023-10-06 12:19:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:19:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:19:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:19:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:19:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:19:19 --> Controller Class Initialized
INFO - 2023-10-06 12:19:19 --> Final output sent to browser
DEBUG - 2023-10-06 12:19:19 --> Total execution time: 0.0393
INFO - 2023-10-06 12:20:08 --> Config Class Initialized
INFO - 2023-10-06 12:20:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:08 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:08 --> URI Class Initialized
INFO - 2023-10-06 12:20:08 --> Router Class Initialized
INFO - 2023-10-06 12:20:08 --> Output Class Initialized
INFO - 2023-10-06 12:20:08 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:08 --> Input Class Initialized
INFO - 2023-10-06 12:20:08 --> Language Class Initialized
INFO - 2023-10-06 12:20:08 --> Language Class Initialized
INFO - 2023-10-06 12:20:08 --> Config Class Initialized
INFO - 2023-10-06 12:20:08 --> Loader Class Initialized
INFO - 2023-10-06 12:20:08 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:08 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:08 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:08 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:08 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:08 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:08 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:08 --> Total execution time: 0.0368
INFO - 2023-10-06 12:20:11 --> Config Class Initialized
INFO - 2023-10-06 12:20:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:11 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:11 --> URI Class Initialized
INFO - 2023-10-06 12:20:11 --> Router Class Initialized
INFO - 2023-10-06 12:20:11 --> Output Class Initialized
INFO - 2023-10-06 12:20:11 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:11 --> Input Class Initialized
INFO - 2023-10-06 12:20:11 --> Language Class Initialized
INFO - 2023-10-06 12:20:11 --> Language Class Initialized
INFO - 2023-10-06 12:20:11 --> Config Class Initialized
INFO - 2023-10-06 12:20:11 --> Loader Class Initialized
INFO - 2023-10-06 12:20:11 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:11 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:11 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:11 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:11 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:11 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:11 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:11 --> Total execution time: 0.0559
INFO - 2023-10-06 12:20:12 --> Config Class Initialized
INFO - 2023-10-06 12:20:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:12 --> URI Class Initialized
INFO - 2023-10-06 12:20:12 --> Router Class Initialized
INFO - 2023-10-06 12:20:12 --> Output Class Initialized
INFO - 2023-10-06 12:20:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:12 --> Input Class Initialized
INFO - 2023-10-06 12:20:12 --> Language Class Initialized
INFO - 2023-10-06 12:20:12 --> Language Class Initialized
INFO - 2023-10-06 12:20:12 --> Config Class Initialized
INFO - 2023-10-06 12:20:12 --> Loader Class Initialized
INFO - 2023-10-06 12:20:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:12 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:12 --> Total execution time: 0.0536
INFO - 2023-10-06 12:20:12 --> Config Class Initialized
INFO - 2023-10-06 12:20:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:12 --> URI Class Initialized
INFO - 2023-10-06 12:20:12 --> Router Class Initialized
INFO - 2023-10-06 12:20:12 --> Output Class Initialized
INFO - 2023-10-06 12:20:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:12 --> Input Class Initialized
INFO - 2023-10-06 12:20:12 --> Language Class Initialized
INFO - 2023-10-06 12:20:12 --> Language Class Initialized
INFO - 2023-10-06 12:20:12 --> Config Class Initialized
INFO - 2023-10-06 12:20:12 --> Loader Class Initialized
INFO - 2023-10-06 12:20:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:12 --> Controller Class Initialized
INFO - 2023-10-06 12:20:17 --> Config Class Initialized
INFO - 2023-10-06 12:20:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:17 --> URI Class Initialized
INFO - 2023-10-06 12:20:17 --> Router Class Initialized
INFO - 2023-10-06 12:20:17 --> Output Class Initialized
INFO - 2023-10-06 12:20:17 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:17 --> Input Class Initialized
INFO - 2023-10-06 12:20:17 --> Language Class Initialized
INFO - 2023-10-06 12:20:17 --> Language Class Initialized
INFO - 2023-10-06 12:20:17 --> Config Class Initialized
INFO - 2023-10-06 12:20:17 --> Loader Class Initialized
INFO - 2023-10-06 12:20:17 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:17 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:17 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:17 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:17 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:17 --> Controller Class Initialized
INFO - 2023-10-06 12:20:26 --> Config Class Initialized
INFO - 2023-10-06 12:20:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:26 --> URI Class Initialized
INFO - 2023-10-06 12:20:26 --> Router Class Initialized
INFO - 2023-10-06 12:20:26 --> Output Class Initialized
INFO - 2023-10-06 12:20:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:26 --> Input Class Initialized
INFO - 2023-10-06 12:20:26 --> Language Class Initialized
INFO - 2023-10-06 12:20:26 --> Language Class Initialized
INFO - 2023-10-06 12:20:26 --> Config Class Initialized
INFO - 2023-10-06 12:20:26 --> Loader Class Initialized
INFO - 2023-10-06 12:20:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:26 --> Controller Class Initialized
INFO - 2023-10-06 12:20:26 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:20:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:26 --> Total execution time: 0.0342
INFO - 2023-10-06 12:20:26 --> Config Class Initialized
INFO - 2023-10-06 12:20:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:26 --> URI Class Initialized
INFO - 2023-10-06 12:20:26 --> Router Class Initialized
INFO - 2023-10-06 12:20:26 --> Output Class Initialized
INFO - 2023-10-06 12:20:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:26 --> Input Class Initialized
INFO - 2023-10-06 12:20:26 --> Language Class Initialized
INFO - 2023-10-06 12:20:26 --> Language Class Initialized
INFO - 2023-10-06 12:20:26 --> Config Class Initialized
INFO - 2023-10-06 12:20:26 --> Loader Class Initialized
INFO - 2023-10-06 12:20:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:26 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:20:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:27 --> Total execution time: 0.0403
INFO - 2023-10-06 12:20:30 --> Config Class Initialized
INFO - 2023-10-06 12:20:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:30 --> URI Class Initialized
INFO - 2023-10-06 12:20:30 --> Router Class Initialized
INFO - 2023-10-06 12:20:30 --> Output Class Initialized
INFO - 2023-10-06 12:20:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:30 --> Input Class Initialized
INFO - 2023-10-06 12:20:30 --> Language Class Initialized
INFO - 2023-10-06 12:20:30 --> Language Class Initialized
INFO - 2023-10-06 12:20:30 --> Config Class Initialized
INFO - 2023-10-06 12:20:30 --> Loader Class Initialized
INFO - 2023-10-06 12:20:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:30 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:20:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:30 --> Total execution time: 0.1000
INFO - 2023-10-06 12:20:31 --> Config Class Initialized
INFO - 2023-10-06 12:20:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:31 --> URI Class Initialized
INFO - 2023-10-06 12:20:31 --> Router Class Initialized
INFO - 2023-10-06 12:20:31 --> Output Class Initialized
INFO - 2023-10-06 12:20:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:31 --> Input Class Initialized
INFO - 2023-10-06 12:20:31 --> Language Class Initialized
INFO - 2023-10-06 12:20:31 --> Language Class Initialized
INFO - 2023-10-06 12:20:31 --> Config Class Initialized
INFO - 2023-10-06 12:20:31 --> Loader Class Initialized
INFO - 2023-10-06 12:20:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:31 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:31 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:31 --> Total execution time: 0.0606
INFO - 2023-10-06 12:20:32 --> Config Class Initialized
INFO - 2023-10-06 12:20:32 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:32 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:32 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:32 --> URI Class Initialized
INFO - 2023-10-06 12:20:32 --> Router Class Initialized
INFO - 2023-10-06 12:20:32 --> Output Class Initialized
INFO - 2023-10-06 12:20:32 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:32 --> Input Class Initialized
INFO - 2023-10-06 12:20:32 --> Language Class Initialized
INFO - 2023-10-06 12:20:32 --> Language Class Initialized
INFO - 2023-10-06 12:20:32 --> Config Class Initialized
INFO - 2023-10-06 12:20:32 --> Loader Class Initialized
INFO - 2023-10-06 12:20:32 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:32 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:32 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:32 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:32 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:32 --> Controller Class Initialized
INFO - 2023-10-06 12:20:33 --> Config Class Initialized
INFO - 2023-10-06 12:20:33 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:33 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:33 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:33 --> URI Class Initialized
INFO - 2023-10-06 12:20:33 --> Router Class Initialized
INFO - 2023-10-06 12:20:33 --> Output Class Initialized
INFO - 2023-10-06 12:20:33 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:33 --> Input Class Initialized
INFO - 2023-10-06 12:20:33 --> Language Class Initialized
INFO - 2023-10-06 12:20:33 --> Language Class Initialized
INFO - 2023-10-06 12:20:33 --> Config Class Initialized
INFO - 2023-10-06 12:20:33 --> Loader Class Initialized
INFO - 2023-10-06 12:20:33 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:33 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:33 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:33 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:33 --> Total execution time: 0.0970
INFO - 2023-10-06 12:20:33 --> Config Class Initialized
INFO - 2023-10-06 12:20:33 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:33 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:33 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:33 --> URI Class Initialized
INFO - 2023-10-06 12:20:33 --> Router Class Initialized
INFO - 2023-10-06 12:20:33 --> Output Class Initialized
INFO - 2023-10-06 12:20:33 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:33 --> Input Class Initialized
INFO - 2023-10-06 12:20:33 --> Language Class Initialized
INFO - 2023-10-06 12:20:33 --> Language Class Initialized
INFO - 2023-10-06 12:20:33 --> Config Class Initialized
INFO - 2023-10-06 12:20:33 --> Loader Class Initialized
INFO - 2023-10-06 12:20:33 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:33 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:33 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:33 --> Controller Class Initialized
INFO - 2023-10-06 12:20:34 --> Config Class Initialized
INFO - 2023-10-06 12:20:34 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:34 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:34 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:34 --> URI Class Initialized
INFO - 2023-10-06 12:20:34 --> Router Class Initialized
INFO - 2023-10-06 12:20:34 --> Output Class Initialized
INFO - 2023-10-06 12:20:34 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:34 --> Input Class Initialized
INFO - 2023-10-06 12:20:34 --> Language Class Initialized
INFO - 2023-10-06 12:20:34 --> Language Class Initialized
INFO - 2023-10-06 12:20:34 --> Config Class Initialized
INFO - 2023-10-06 12:20:34 --> Loader Class Initialized
INFO - 2023-10-06 12:20:34 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:34 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:34 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:34 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:34 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:34 --> Controller Class Initialized
INFO - 2023-10-06 12:20:34 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:34 --> Total execution time: 0.0456
INFO - 2023-10-06 12:20:36 --> Config Class Initialized
INFO - 2023-10-06 12:20:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:36 --> URI Class Initialized
INFO - 2023-10-06 12:20:36 --> Router Class Initialized
INFO - 2023-10-06 12:20:36 --> Output Class Initialized
INFO - 2023-10-06 12:20:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:36 --> Input Class Initialized
INFO - 2023-10-06 12:20:36 --> Language Class Initialized
INFO - 2023-10-06 12:20:36 --> Language Class Initialized
INFO - 2023-10-06 12:20:36 --> Config Class Initialized
INFO - 2023-10-06 12:20:36 --> Loader Class Initialized
INFO - 2023-10-06 12:20:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:36 --> Controller Class Initialized
INFO - 2023-10-06 12:20:37 --> Config Class Initialized
INFO - 2023-10-06 12:20:37 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:37 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:37 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:37 --> URI Class Initialized
INFO - 2023-10-06 12:20:37 --> Router Class Initialized
INFO - 2023-10-06 12:20:37 --> Output Class Initialized
INFO - 2023-10-06 12:20:37 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:37 --> Input Class Initialized
INFO - 2023-10-06 12:20:37 --> Language Class Initialized
INFO - 2023-10-06 12:20:37 --> Language Class Initialized
INFO - 2023-10-06 12:20:37 --> Config Class Initialized
INFO - 2023-10-06 12:20:37 --> Loader Class Initialized
INFO - 2023-10-06 12:20:37 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:37 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:37 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:37 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:37 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:37 --> Controller Class Initialized
INFO - 2023-10-06 12:20:38 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:38 --> Total execution time: 0.3005
INFO - 2023-10-06 12:20:39 --> Config Class Initialized
INFO - 2023-10-06 12:20:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:39 --> URI Class Initialized
INFO - 2023-10-06 12:20:39 --> Router Class Initialized
INFO - 2023-10-06 12:20:39 --> Output Class Initialized
INFO - 2023-10-06 12:20:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:39 --> Input Class Initialized
INFO - 2023-10-06 12:20:39 --> Language Class Initialized
INFO - 2023-10-06 12:20:39 --> Language Class Initialized
INFO - 2023-10-06 12:20:39 --> Config Class Initialized
INFO - 2023-10-06 12:20:39 --> Loader Class Initialized
INFO - 2023-10-06 12:20:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:39 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:20:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:39 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:39 --> Total execution time: 0.0718
INFO - 2023-10-06 12:20:39 --> Config Class Initialized
INFO - 2023-10-06 12:20:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:39 --> URI Class Initialized
INFO - 2023-10-06 12:20:39 --> Router Class Initialized
INFO - 2023-10-06 12:20:39 --> Output Class Initialized
INFO - 2023-10-06 12:20:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:39 --> Input Class Initialized
INFO - 2023-10-06 12:20:39 --> Language Class Initialized
INFO - 2023-10-06 12:20:39 --> Language Class Initialized
INFO - 2023-10-06 12:20:39 --> Config Class Initialized
INFO - 2023-10-06 12:20:39 --> Loader Class Initialized
INFO - 2023-10-06 12:20:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:39 --> Controller Class Initialized
INFO - 2023-10-06 12:20:41 --> Config Class Initialized
INFO - 2023-10-06 12:20:41 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:41 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:41 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:41 --> URI Class Initialized
INFO - 2023-10-06 12:20:41 --> Router Class Initialized
INFO - 2023-10-06 12:20:41 --> Output Class Initialized
INFO - 2023-10-06 12:20:41 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:41 --> Input Class Initialized
INFO - 2023-10-06 12:20:41 --> Language Class Initialized
INFO - 2023-10-06 12:20:41 --> Language Class Initialized
INFO - 2023-10-06 12:20:41 --> Config Class Initialized
INFO - 2023-10-06 12:20:41 --> Loader Class Initialized
INFO - 2023-10-06 12:20:41 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:41 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:41 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:41 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:41 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:41 --> Controller Class Initialized
INFO - 2023-10-06 12:20:41 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:41 --> Total execution time: 0.0400
INFO - 2023-10-06 12:20:42 --> Config Class Initialized
INFO - 2023-10-06 12:20:42 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:42 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:42 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:42 --> URI Class Initialized
INFO - 2023-10-06 12:20:42 --> Router Class Initialized
INFO - 2023-10-06 12:20:42 --> Output Class Initialized
INFO - 2023-10-06 12:20:42 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:42 --> Input Class Initialized
INFO - 2023-10-06 12:20:42 --> Language Class Initialized
INFO - 2023-10-06 12:20:42 --> Config Class Initialized
INFO - 2023-10-06 12:20:42 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:42 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:42 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:42 --> URI Class Initialized
INFO - 2023-10-06 12:20:42 --> Router Class Initialized
INFO - 2023-10-06 12:20:42 --> Output Class Initialized
INFO - 2023-10-06 12:20:42 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:42 --> Input Class Initialized
INFO - 2023-10-06 12:20:42 --> Language Class Initialized
INFO - 2023-10-06 12:20:42 --> Language Class Initialized
INFO - 2023-10-06 12:20:42 --> Config Class Initialized
INFO - 2023-10-06 12:20:42 --> Loader Class Initialized
INFO - 2023-10-06 12:20:42 --> Language Class Initialized
INFO - 2023-10-06 12:20:42 --> Config Class Initialized
INFO - 2023-10-06 12:20:42 --> Loader Class Initialized
INFO - 2023-10-06 12:20:42 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:42 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:42 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:42 --> Controller Class Initialized
INFO - 2023-10-06 12:20:42 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:42 --> Controller Class Initialized
INFO - 2023-10-06 12:20:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:42 --> Total execution time: 0.0945
INFO - 2023-10-06 12:20:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:42 --> Total execution time: 0.0762
INFO - 2023-10-06 12:20:43 --> Config Class Initialized
INFO - 2023-10-06 12:20:43 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:43 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:43 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:43 --> URI Class Initialized
INFO - 2023-10-06 12:20:43 --> Router Class Initialized
INFO - 2023-10-06 12:20:43 --> Output Class Initialized
INFO - 2023-10-06 12:20:43 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:43 --> Input Class Initialized
INFO - 2023-10-06 12:20:43 --> Language Class Initialized
INFO - 2023-10-06 12:20:43 --> Language Class Initialized
INFO - 2023-10-06 12:20:43 --> Config Class Initialized
INFO - 2023-10-06 12:20:43 --> Loader Class Initialized
INFO - 2023-10-06 12:20:43 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:43 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:43 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:43 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:43 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:43 --> Controller Class Initialized
INFO - 2023-10-06 12:20:46 --> Config Class Initialized
INFO - 2023-10-06 12:20:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:46 --> URI Class Initialized
INFO - 2023-10-06 12:20:46 --> Router Class Initialized
INFO - 2023-10-06 12:20:46 --> Output Class Initialized
INFO - 2023-10-06 12:20:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:46 --> Input Class Initialized
INFO - 2023-10-06 12:20:46 --> Language Class Initialized
INFO - 2023-10-06 12:20:46 --> Language Class Initialized
INFO - 2023-10-06 12:20:46 --> Config Class Initialized
INFO - 2023-10-06 12:20:46 --> Loader Class Initialized
INFO - 2023-10-06 12:20:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:46 --> Controller Class Initialized
DEBUG - 2023-10-06 12:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:20:46 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:46 --> Total execution time: 0.0767
INFO - 2023-10-06 12:20:46 --> Config Class Initialized
INFO - 2023-10-06 12:20:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:46 --> URI Class Initialized
INFO - 2023-10-06 12:20:46 --> Router Class Initialized
INFO - 2023-10-06 12:20:46 --> Output Class Initialized
INFO - 2023-10-06 12:20:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:46 --> Input Class Initialized
INFO - 2023-10-06 12:20:46 --> Language Class Initialized
INFO - 2023-10-06 12:20:46 --> Language Class Initialized
INFO - 2023-10-06 12:20:46 --> Config Class Initialized
INFO - 2023-10-06 12:20:46 --> Loader Class Initialized
INFO - 2023-10-06 12:20:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:46 --> Controller Class Initialized
INFO - 2023-10-06 12:20:48 --> Config Class Initialized
INFO - 2023-10-06 12:20:48 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:48 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:48 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:48 --> URI Class Initialized
INFO - 2023-10-06 12:20:48 --> Router Class Initialized
INFO - 2023-10-06 12:20:48 --> Output Class Initialized
INFO - 2023-10-06 12:20:48 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:48 --> Input Class Initialized
INFO - 2023-10-06 12:20:48 --> Language Class Initialized
INFO - 2023-10-06 12:20:48 --> Language Class Initialized
INFO - 2023-10-06 12:20:48 --> Config Class Initialized
INFO - 2023-10-06 12:20:48 --> Loader Class Initialized
INFO - 2023-10-06 12:20:48 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:48 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:48 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:48 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:48 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:48 --> Controller Class Initialized
INFO - 2023-10-06 12:20:48 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:48 --> Total execution time: 0.1183
INFO - 2023-10-06 12:20:51 --> Config Class Initialized
INFO - 2023-10-06 12:20:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:20:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:20:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:20:51 --> URI Class Initialized
INFO - 2023-10-06 12:20:51 --> Router Class Initialized
INFO - 2023-10-06 12:20:51 --> Output Class Initialized
INFO - 2023-10-06 12:20:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:20:51 --> Input Class Initialized
INFO - 2023-10-06 12:20:51 --> Language Class Initialized
INFO - 2023-10-06 12:20:51 --> Language Class Initialized
INFO - 2023-10-06 12:20:51 --> Config Class Initialized
INFO - 2023-10-06 12:20:51 --> Loader Class Initialized
INFO - 2023-10-06 12:20:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:20:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:20:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:20:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:20:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:20:52 --> Controller Class Initialized
INFO - 2023-10-06 12:20:52 --> Final output sent to browser
DEBUG - 2023-10-06 12:20:52 --> Total execution time: 0.0901
INFO - 2023-10-06 12:21:05 --> Config Class Initialized
INFO - 2023-10-06 12:21:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:05 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:05 --> URI Class Initialized
INFO - 2023-10-06 12:21:05 --> Router Class Initialized
INFO - 2023-10-06 12:21:05 --> Output Class Initialized
INFO - 2023-10-06 12:21:05 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:05 --> Input Class Initialized
INFO - 2023-10-06 12:21:05 --> Language Class Initialized
INFO - 2023-10-06 12:21:05 --> Language Class Initialized
INFO - 2023-10-06 12:21:05 --> Config Class Initialized
INFO - 2023-10-06 12:21:05 --> Loader Class Initialized
INFO - 2023-10-06 12:21:05 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:05 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:05 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:05 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:05 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:05 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:21:05 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:05 --> Total execution time: 0.0356
INFO - 2023-10-06 12:21:15 --> Config Class Initialized
INFO - 2023-10-06 12:21:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:15 --> URI Class Initialized
INFO - 2023-10-06 12:21:15 --> Router Class Initialized
INFO - 2023-10-06 12:21:15 --> Output Class Initialized
INFO - 2023-10-06 12:21:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:15 --> Input Class Initialized
INFO - 2023-10-06 12:21:15 --> Language Class Initialized
INFO - 2023-10-06 12:21:15 --> Language Class Initialized
INFO - 2023-10-06 12:21:15 --> Config Class Initialized
INFO - 2023-10-06 12:21:15 --> Loader Class Initialized
INFO - 2023-10-06 12:21:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:16 --> URI Class Initialized
INFO - 2023-10-06 12:21:16 --> Router Class Initialized
INFO - 2023-10-06 12:21:16 --> Output Class Initialized
INFO - 2023-10-06 12:21:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:16 --> Input Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Loader Class Initialized
INFO - 2023-10-06 12:21:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:16 --> Controller Class Initialized
INFO - 2023-10-06 12:21:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:16 --> Total execution time: 0.1275
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:16 --> URI Class Initialized
DEBUG - 2023-10-06 12:21:16 --> No URI present. Default controller set.
INFO - 2023-10-06 12:21:16 --> Router Class Initialized
INFO - 2023-10-06 12:21:16 --> Output Class Initialized
INFO - 2023-10-06 12:21:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:16 --> Input Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Loader Class Initialized
INFO - 2023-10-06 12:21:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:16 --> Controller Class Initialized
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:16 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:16 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:16 --> URI Class Initialized
INFO - 2023-10-06 12:21:16 --> Router Class Initialized
INFO - 2023-10-06 12:21:16 --> Output Class Initialized
INFO - 2023-10-06 12:21:16 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:16 --> Input Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Language Class Initialized
INFO - 2023-10-06 12:21:16 --> Config Class Initialized
INFO - 2023-10-06 12:21:16 --> Loader Class Initialized
INFO - 2023-10-06 12:21:16 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:16 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:16 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:16 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:21:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:21:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:16 --> Total execution time: 0.1002
INFO - 2023-10-06 12:21:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:18 --> Total execution time: 3.8211
INFO - 2023-10-06 12:21:27 --> Config Class Initialized
INFO - 2023-10-06 12:21:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:27 --> URI Class Initialized
INFO - 2023-10-06 12:21:27 --> Router Class Initialized
INFO - 2023-10-06 12:21:27 --> Output Class Initialized
INFO - 2023-10-06 12:21:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:27 --> Input Class Initialized
INFO - 2023-10-06 12:21:27 --> Language Class Initialized
INFO - 2023-10-06 12:21:27 --> Language Class Initialized
INFO - 2023-10-06 12:21:27 --> Config Class Initialized
INFO - 2023-10-06 12:21:27 --> Loader Class Initialized
INFO - 2023-10-06 12:21:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:27 --> Controller Class Initialized
INFO - 2023-10-06 12:21:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:27 --> Total execution time: 0.0362
INFO - 2023-10-06 12:21:35 --> Config Class Initialized
INFO - 2023-10-06 12:21:35 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:35 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:35 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:35 --> URI Class Initialized
INFO - 2023-10-06 12:21:35 --> Router Class Initialized
INFO - 2023-10-06 12:21:35 --> Output Class Initialized
INFO - 2023-10-06 12:21:35 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:35 --> Input Class Initialized
INFO - 2023-10-06 12:21:35 --> Language Class Initialized
INFO - 2023-10-06 12:21:35 --> Language Class Initialized
INFO - 2023-10-06 12:21:35 --> Config Class Initialized
INFO - 2023-10-06 12:21:35 --> Loader Class Initialized
INFO - 2023-10-06 12:21:35 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:35 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:35 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:35 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:35 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:35 --> Controller Class Initialized
INFO - 2023-10-06 12:21:35 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:21:35 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:35 --> Total execution time: 0.0430
INFO - 2023-10-06 12:21:36 --> Config Class Initialized
INFO - 2023-10-06 12:21:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:36 --> URI Class Initialized
INFO - 2023-10-06 12:21:36 --> Router Class Initialized
INFO - 2023-10-06 12:21:36 --> Output Class Initialized
INFO - 2023-10-06 12:21:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:36 --> Input Class Initialized
INFO - 2023-10-06 12:21:36 --> Language Class Initialized
INFO - 2023-10-06 12:21:36 --> Language Class Initialized
INFO - 2023-10-06 12:21:36 --> Config Class Initialized
INFO - 2023-10-06 12:21:36 --> Loader Class Initialized
INFO - 2023-10-06 12:21:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:36 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:21:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:36 --> Total execution time: 0.0466
INFO - 2023-10-06 12:21:37 --> Config Class Initialized
INFO - 2023-10-06 12:21:37 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:37 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:37 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:37 --> URI Class Initialized
INFO - 2023-10-06 12:21:37 --> Router Class Initialized
INFO - 2023-10-06 12:21:37 --> Output Class Initialized
INFO - 2023-10-06 12:21:37 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:37 --> Input Class Initialized
INFO - 2023-10-06 12:21:37 --> Language Class Initialized
INFO - 2023-10-06 12:21:37 --> Language Class Initialized
INFO - 2023-10-06 12:21:37 --> Config Class Initialized
INFO - 2023-10-06 12:21:37 --> Loader Class Initialized
INFO - 2023-10-06 12:21:37 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:37 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:37 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:37 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:37 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:37 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:21:38 --> Config Class Initialized
INFO - 2023-10-06 12:21:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:38 --> URI Class Initialized
INFO - 2023-10-06 12:21:38 --> Router Class Initialized
INFO - 2023-10-06 12:21:38 --> Output Class Initialized
INFO - 2023-10-06 12:21:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:38 --> Input Class Initialized
INFO - 2023-10-06 12:21:38 --> Language Class Initialized
INFO - 2023-10-06 12:21:38 --> Language Class Initialized
INFO - 2023-10-06 12:21:38 --> Config Class Initialized
INFO - 2023-10-06 12:21:38 --> Loader Class Initialized
INFO - 2023-10-06 12:21:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:38 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:38 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:21:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:21:38 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:38 --> Total execution time: 0.0842
INFO - 2023-10-06 12:21:40 --> Config Class Initialized
INFO - 2023-10-06 12:21:40 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:40 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:40 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:40 --> URI Class Initialized
INFO - 2023-10-06 12:21:40 --> Router Class Initialized
INFO - 2023-10-06 12:21:40 --> Output Class Initialized
INFO - 2023-10-06 12:21:40 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:40 --> Input Class Initialized
INFO - 2023-10-06 12:21:40 --> Language Class Initialized
INFO - 2023-10-06 12:21:40 --> Language Class Initialized
INFO - 2023-10-06 12:21:40 --> Config Class Initialized
INFO - 2023-10-06 12:21:40 --> Loader Class Initialized
INFO - 2023-10-06 12:21:40 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:40 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:40 --> Controller Class Initialized
DEBUG - 2023-10-06 12:21:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:21:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:21:40 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:40 --> Total execution time: 0.0714
INFO - 2023-10-06 12:21:40 --> Config Class Initialized
INFO - 2023-10-06 12:21:40 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:40 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:40 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:40 --> URI Class Initialized
INFO - 2023-10-06 12:21:40 --> Router Class Initialized
INFO - 2023-10-06 12:21:40 --> Output Class Initialized
INFO - 2023-10-06 12:21:40 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:40 --> Input Class Initialized
INFO - 2023-10-06 12:21:40 --> Language Class Initialized
INFO - 2023-10-06 12:21:40 --> Language Class Initialized
INFO - 2023-10-06 12:21:40 --> Config Class Initialized
INFO - 2023-10-06 12:21:40 --> Loader Class Initialized
INFO - 2023-10-06 12:21:40 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:40 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:40 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:40 --> Controller Class Initialized
INFO - 2023-10-06 12:21:41 --> Config Class Initialized
INFO - 2023-10-06 12:21:41 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:41 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:41 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:41 --> URI Class Initialized
INFO - 2023-10-06 12:21:41 --> Router Class Initialized
INFO - 2023-10-06 12:21:41 --> Output Class Initialized
INFO - 2023-10-06 12:21:41 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:41 --> Input Class Initialized
INFO - 2023-10-06 12:21:41 --> Language Class Initialized
INFO - 2023-10-06 12:21:41 --> Language Class Initialized
INFO - 2023-10-06 12:21:41 --> Config Class Initialized
INFO - 2023-10-06 12:21:41 --> Loader Class Initialized
INFO - 2023-10-06 12:21:41 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:41 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:41 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:41 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:41 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:41 --> Controller Class Initialized
INFO - 2023-10-06 12:21:41 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:41 --> Total execution time: 0.0941
INFO - 2023-10-06 12:21:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:42 --> Total execution time: 5.1880
INFO - 2023-10-06 12:21:49 --> Config Class Initialized
INFO - 2023-10-06 12:21:49 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:49 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:49 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:49 --> URI Class Initialized
INFO - 2023-10-06 12:21:49 --> Router Class Initialized
INFO - 2023-10-06 12:21:49 --> Output Class Initialized
INFO - 2023-10-06 12:21:49 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:49 --> Input Class Initialized
INFO - 2023-10-06 12:21:49 --> Language Class Initialized
INFO - 2023-10-06 12:21:49 --> Language Class Initialized
INFO - 2023-10-06 12:21:49 --> Config Class Initialized
INFO - 2023-10-06 12:21:49 --> Loader Class Initialized
INFO - 2023-10-06 12:21:49 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:49 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:49 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:49 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:49 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:49 --> Controller Class Initialized
INFO - 2023-10-06 12:21:49 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:49 --> Total execution time: 0.0384
INFO - 2023-10-06 12:21:53 --> Config Class Initialized
INFO - 2023-10-06 12:21:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:53 --> URI Class Initialized
INFO - 2023-10-06 12:21:53 --> Router Class Initialized
INFO - 2023-10-06 12:21:53 --> Output Class Initialized
INFO - 2023-10-06 12:21:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:53 --> Input Class Initialized
INFO - 2023-10-06 12:21:53 --> Language Class Initialized
INFO - 2023-10-06 12:21:53 --> Language Class Initialized
INFO - 2023-10-06 12:21:53 --> Config Class Initialized
INFO - 2023-10-06 12:21:53 --> Loader Class Initialized
INFO - 2023-10-06 12:21:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:53 --> Controller Class Initialized
INFO - 2023-10-06 12:21:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:53 --> Total execution time: 0.0293
INFO - 2023-10-06 12:21:54 --> Config Class Initialized
INFO - 2023-10-06 12:21:54 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:54 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:54 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:54 --> URI Class Initialized
INFO - 2023-10-06 12:21:54 --> Router Class Initialized
INFO - 2023-10-06 12:21:54 --> Output Class Initialized
INFO - 2023-10-06 12:21:54 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:54 --> Input Class Initialized
INFO - 2023-10-06 12:21:54 --> Language Class Initialized
INFO - 2023-10-06 12:21:54 --> Language Class Initialized
INFO - 2023-10-06 12:21:54 --> Config Class Initialized
INFO - 2023-10-06 12:21:54 --> Loader Class Initialized
INFO - 2023-10-06 12:21:54 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:54 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:54 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:54 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:54 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:54 --> Controller Class Initialized
INFO - 2023-10-06 12:21:54 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:54 --> Total execution time: 0.0424
INFO - 2023-10-06 12:21:57 --> Config Class Initialized
INFO - 2023-10-06 12:21:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:57 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:57 --> URI Class Initialized
INFO - 2023-10-06 12:21:57 --> Router Class Initialized
INFO - 2023-10-06 12:21:57 --> Output Class Initialized
INFO - 2023-10-06 12:21:57 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:57 --> Input Class Initialized
INFO - 2023-10-06 12:21:57 --> Language Class Initialized
INFO - 2023-10-06 12:21:57 --> Language Class Initialized
INFO - 2023-10-06 12:21:57 --> Config Class Initialized
INFO - 2023-10-06 12:21:57 --> Loader Class Initialized
INFO - 2023-10-06 12:21:57 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:57 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:57 --> Controller Class Initialized
INFO - 2023-10-06 12:21:57 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:57 --> Total execution time: 0.0317
INFO - 2023-10-06 12:21:57 --> Config Class Initialized
INFO - 2023-10-06 12:21:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:21:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:21:57 --> Utf8 Class Initialized
INFO - 2023-10-06 12:21:57 --> URI Class Initialized
INFO - 2023-10-06 12:21:57 --> Router Class Initialized
INFO - 2023-10-06 12:21:57 --> Output Class Initialized
INFO - 2023-10-06 12:21:57 --> Security Class Initialized
DEBUG - 2023-10-06 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:21:57 --> Input Class Initialized
INFO - 2023-10-06 12:21:57 --> Language Class Initialized
INFO - 2023-10-06 12:21:57 --> Language Class Initialized
INFO - 2023-10-06 12:21:57 --> Config Class Initialized
INFO - 2023-10-06 12:21:57 --> Loader Class Initialized
INFO - 2023-10-06 12:21:57 --> Helper loaded: url_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: file_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: form_helper
INFO - 2023-10-06 12:21:57 --> Helper loaded: my_helper
INFO - 2023-10-06 12:21:57 --> Database Driver Class Initialized
INFO - 2023-10-06 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:21:57 --> Controller Class Initialized
INFO - 2023-10-06 12:21:57 --> Final output sent to browser
DEBUG - 2023-10-06 12:21:57 --> Total execution time: 0.0356
INFO - 2023-10-06 12:22:01 --> Config Class Initialized
INFO - 2023-10-06 12:22:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:22:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:22:01 --> Utf8 Class Initialized
INFO - 2023-10-06 12:22:01 --> URI Class Initialized
INFO - 2023-10-06 12:22:01 --> Router Class Initialized
INFO - 2023-10-06 12:22:01 --> Output Class Initialized
INFO - 2023-10-06 12:22:01 --> Security Class Initialized
DEBUG - 2023-10-06 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:22:01 --> Input Class Initialized
INFO - 2023-10-06 12:22:01 --> Language Class Initialized
INFO - 2023-10-06 12:22:01 --> Language Class Initialized
INFO - 2023-10-06 12:22:01 --> Config Class Initialized
INFO - 2023-10-06 12:22:01 --> Loader Class Initialized
INFO - 2023-10-06 12:22:01 --> Helper loaded: url_helper
INFO - 2023-10-06 12:22:01 --> Helper loaded: file_helper
INFO - 2023-10-06 12:22:01 --> Helper loaded: form_helper
INFO - 2023-10-06 12:22:01 --> Helper loaded: my_helper
INFO - 2023-10-06 12:22:01 --> Database Driver Class Initialized
INFO - 2023-10-06 12:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:22:01 --> Controller Class Initialized
INFO - 2023-10-06 12:22:01 --> Final output sent to browser
DEBUG - 2023-10-06 12:22:01 --> Total execution time: 0.0471
INFO - 2023-10-06 12:22:02 --> Config Class Initialized
INFO - 2023-10-06 12:22:02 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:22:02 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:22:02 --> Utf8 Class Initialized
INFO - 2023-10-06 12:22:02 --> URI Class Initialized
INFO - 2023-10-06 12:22:02 --> Router Class Initialized
INFO - 2023-10-06 12:22:02 --> Output Class Initialized
INFO - 2023-10-06 12:22:02 --> Security Class Initialized
DEBUG - 2023-10-06 12:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:22:02 --> Input Class Initialized
INFO - 2023-10-06 12:22:02 --> Language Class Initialized
INFO - 2023-10-06 12:22:02 --> Language Class Initialized
INFO - 2023-10-06 12:22:02 --> Config Class Initialized
INFO - 2023-10-06 12:22:02 --> Loader Class Initialized
INFO - 2023-10-06 12:22:02 --> Helper loaded: url_helper
INFO - 2023-10-06 12:22:02 --> Helper loaded: file_helper
INFO - 2023-10-06 12:22:02 --> Helper loaded: form_helper
INFO - 2023-10-06 12:22:02 --> Helper loaded: my_helper
INFO - 2023-10-06 12:22:02 --> Database Driver Class Initialized
INFO - 2023-10-06 12:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:22:02 --> Controller Class Initialized
INFO - 2023-10-06 12:22:12 --> Config Class Initialized
INFO - 2023-10-06 12:22:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:22:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:22:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:22:12 --> URI Class Initialized
INFO - 2023-10-06 12:22:12 --> Router Class Initialized
INFO - 2023-10-06 12:22:12 --> Output Class Initialized
INFO - 2023-10-06 12:22:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:22:12 --> Input Class Initialized
INFO - 2023-10-06 12:22:12 --> Language Class Initialized
INFO - 2023-10-06 12:22:12 --> Language Class Initialized
INFO - 2023-10-06 12:22:12 --> Config Class Initialized
INFO - 2023-10-06 12:22:12 --> Loader Class Initialized
INFO - 2023-10-06 12:22:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:22:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:22:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:22:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:22:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:22:12 --> Controller Class Initialized
DEBUG - 2023-10-06 12:22:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:22:15 --> Config Class Initialized
INFO - 2023-10-06 12:22:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:22:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:22:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:22:15 --> URI Class Initialized
INFO - 2023-10-06 12:22:15 --> Router Class Initialized
INFO - 2023-10-06 12:22:15 --> Output Class Initialized
INFO - 2023-10-06 12:22:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:22:15 --> Input Class Initialized
INFO - 2023-10-06 12:22:15 --> Language Class Initialized
INFO - 2023-10-06 12:22:15 --> Language Class Initialized
INFO - 2023-10-06 12:22:15 --> Config Class Initialized
INFO - 2023-10-06 12:22:15 --> Loader Class Initialized
INFO - 2023-10-06 12:22:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:22:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:22:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:22:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:22:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:22:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:22:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:22:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:22:18 --> Total execution time: 5.9606
INFO - 2023-10-06 12:22:20 --> Final output sent to browser
DEBUG - 2023-10-06 12:22:20 --> Total execution time: 4.7146
INFO - 2023-10-06 12:22:37 --> Config Class Initialized
INFO - 2023-10-06 12:22:37 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:22:37 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:22:37 --> Utf8 Class Initialized
INFO - 2023-10-06 12:22:37 --> URI Class Initialized
INFO - 2023-10-06 12:22:37 --> Router Class Initialized
INFO - 2023-10-06 12:22:37 --> Output Class Initialized
INFO - 2023-10-06 12:22:37 --> Security Class Initialized
DEBUG - 2023-10-06 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:22:37 --> Input Class Initialized
INFO - 2023-10-06 12:22:37 --> Language Class Initialized
INFO - 2023-10-06 12:22:37 --> Language Class Initialized
INFO - 2023-10-06 12:22:37 --> Config Class Initialized
INFO - 2023-10-06 12:22:37 --> Loader Class Initialized
INFO - 2023-10-06 12:22:37 --> Helper loaded: url_helper
INFO - 2023-10-06 12:22:37 --> Helper loaded: file_helper
INFO - 2023-10-06 12:22:37 --> Helper loaded: form_helper
INFO - 2023-10-06 12:22:37 --> Helper loaded: my_helper
INFO - 2023-10-06 12:22:37 --> Database Driver Class Initialized
INFO - 2023-10-06 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:22:37 --> Controller Class Initialized
DEBUG - 2023-10-06 12:22:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:22:41 --> Final output sent to browser
DEBUG - 2023-10-06 12:22:41 --> Total execution time: 4.5226
INFO - 2023-10-06 12:23:31 --> Config Class Initialized
INFO - 2023-10-06 12:23:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:23:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:23:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:23:31 --> URI Class Initialized
INFO - 2023-10-06 12:23:31 --> Router Class Initialized
INFO - 2023-10-06 12:23:31 --> Output Class Initialized
INFO - 2023-10-06 12:23:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:23:31 --> Input Class Initialized
INFO - 2023-10-06 12:23:31 --> Language Class Initialized
INFO - 2023-10-06 12:23:31 --> Language Class Initialized
INFO - 2023-10-06 12:23:31 --> Config Class Initialized
INFO - 2023-10-06 12:23:31 --> Loader Class Initialized
INFO - 2023-10-06 12:23:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:23:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:23:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:23:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:23:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:23:31 --> Controller Class Initialized
INFO - 2023-10-06 12:23:31 --> Final output sent to browser
DEBUG - 2023-10-06 12:23:31 --> Total execution time: 0.0671
INFO - 2023-10-06 12:23:33 --> Config Class Initialized
INFO - 2023-10-06 12:23:33 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:23:33 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:23:33 --> Utf8 Class Initialized
INFO - 2023-10-06 12:23:33 --> URI Class Initialized
INFO - 2023-10-06 12:23:33 --> Router Class Initialized
INFO - 2023-10-06 12:23:33 --> Output Class Initialized
INFO - 2023-10-06 12:23:33 --> Security Class Initialized
DEBUG - 2023-10-06 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:23:33 --> Input Class Initialized
INFO - 2023-10-06 12:23:33 --> Language Class Initialized
INFO - 2023-10-06 12:23:33 --> Language Class Initialized
INFO - 2023-10-06 12:23:33 --> Config Class Initialized
INFO - 2023-10-06 12:23:33 --> Loader Class Initialized
INFO - 2023-10-06 12:23:33 --> Helper loaded: url_helper
INFO - 2023-10-06 12:23:33 --> Helper loaded: file_helper
INFO - 2023-10-06 12:23:33 --> Helper loaded: form_helper
INFO - 2023-10-06 12:23:33 --> Helper loaded: my_helper
INFO - 2023-10-06 12:23:33 --> Database Driver Class Initialized
INFO - 2023-10-06 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:23:33 --> Controller Class Initialized
INFO - 2023-10-06 12:23:33 --> Final output sent to browser
DEBUG - 2023-10-06 12:23:33 --> Total execution time: 0.0334
INFO - 2023-10-06 12:23:43 --> Config Class Initialized
INFO - 2023-10-06 12:23:43 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:23:43 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:23:43 --> Utf8 Class Initialized
INFO - 2023-10-06 12:23:43 --> URI Class Initialized
INFO - 2023-10-06 12:23:43 --> Router Class Initialized
INFO - 2023-10-06 12:23:43 --> Output Class Initialized
INFO - 2023-10-06 12:23:43 --> Security Class Initialized
DEBUG - 2023-10-06 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:23:43 --> Input Class Initialized
INFO - 2023-10-06 12:23:43 --> Language Class Initialized
INFO - 2023-10-06 12:23:43 --> Language Class Initialized
INFO - 2023-10-06 12:23:43 --> Config Class Initialized
INFO - 2023-10-06 12:23:43 --> Loader Class Initialized
INFO - 2023-10-06 12:23:43 --> Helper loaded: url_helper
INFO - 2023-10-06 12:23:43 --> Helper loaded: file_helper
INFO - 2023-10-06 12:23:43 --> Helper loaded: form_helper
INFO - 2023-10-06 12:23:43 --> Helper loaded: my_helper
INFO - 2023-10-06 12:23:43 --> Database Driver Class Initialized
INFO - 2023-10-06 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:23:43 --> Controller Class Initialized
INFO - 2023-10-06 12:23:43 --> Final output sent to browser
DEBUG - 2023-10-06 12:23:43 --> Total execution time: 0.0368
INFO - 2023-10-06 12:24:20 --> Config Class Initialized
INFO - 2023-10-06 12:24:20 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:24:20 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:24:20 --> Utf8 Class Initialized
INFO - 2023-10-06 12:24:20 --> URI Class Initialized
INFO - 2023-10-06 12:24:20 --> Router Class Initialized
INFO - 2023-10-06 12:24:20 --> Output Class Initialized
INFO - 2023-10-06 12:24:20 --> Security Class Initialized
DEBUG - 2023-10-06 12:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:24:20 --> Input Class Initialized
INFO - 2023-10-06 12:24:20 --> Language Class Initialized
INFO - 2023-10-06 12:24:20 --> Language Class Initialized
INFO - 2023-10-06 12:24:20 --> Config Class Initialized
INFO - 2023-10-06 12:24:20 --> Loader Class Initialized
INFO - 2023-10-06 12:24:20 --> Helper loaded: url_helper
INFO - 2023-10-06 12:24:20 --> Helper loaded: file_helper
INFO - 2023-10-06 12:24:20 --> Helper loaded: form_helper
INFO - 2023-10-06 12:24:20 --> Helper loaded: my_helper
INFO - 2023-10-06 12:24:20 --> Database Driver Class Initialized
INFO - 2023-10-06 12:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:24:20 --> Controller Class Initialized
DEBUG - 2023-10-06 12:24:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:24:25 --> Final output sent to browser
DEBUG - 2023-10-06 12:24:25 --> Total execution time: 4.3739
INFO - 2023-10-06 12:24:54 --> Config Class Initialized
INFO - 2023-10-06 12:24:54 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:24:54 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:24:54 --> Utf8 Class Initialized
INFO - 2023-10-06 12:24:54 --> URI Class Initialized
INFO - 2023-10-06 12:24:54 --> Router Class Initialized
INFO - 2023-10-06 12:24:54 --> Output Class Initialized
INFO - 2023-10-06 12:24:54 --> Security Class Initialized
DEBUG - 2023-10-06 12:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:24:54 --> Input Class Initialized
INFO - 2023-10-06 12:24:54 --> Language Class Initialized
INFO - 2023-10-06 12:24:54 --> Language Class Initialized
INFO - 2023-10-06 12:24:54 --> Config Class Initialized
INFO - 2023-10-06 12:24:54 --> Loader Class Initialized
INFO - 2023-10-06 12:24:54 --> Helper loaded: url_helper
INFO - 2023-10-06 12:24:54 --> Helper loaded: file_helper
INFO - 2023-10-06 12:24:54 --> Helper loaded: form_helper
INFO - 2023-10-06 12:24:54 --> Helper loaded: my_helper
INFO - 2023-10-06 12:24:54 --> Database Driver Class Initialized
INFO - 2023-10-06 12:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:24:54 --> Controller Class Initialized
DEBUG - 2023-10-06 12:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:24:59 --> Final output sent to browser
DEBUG - 2023-10-06 12:24:59 --> Total execution time: 5.1681
INFO - 2023-10-06 12:29:05 --> Config Class Initialized
INFO - 2023-10-06 12:29:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:05 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:05 --> URI Class Initialized
INFO - 2023-10-06 12:29:05 --> Router Class Initialized
INFO - 2023-10-06 12:29:05 --> Output Class Initialized
INFO - 2023-10-06 12:29:06 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:06 --> Input Class Initialized
INFO - 2023-10-06 12:29:06 --> Language Class Initialized
INFO - 2023-10-06 12:29:06 --> Language Class Initialized
INFO - 2023-10-06 12:29:06 --> Config Class Initialized
INFO - 2023-10-06 12:29:06 --> Loader Class Initialized
INFO - 2023-10-06 12:29:06 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:06 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:06 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:06 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:06 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:06 --> Controller Class Initialized
INFO - 2023-10-06 12:29:06 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:06 --> Total execution time: 0.0418
INFO - 2023-10-06 12:29:09 --> Config Class Initialized
INFO - 2023-10-06 12:29:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:09 --> URI Class Initialized
INFO - 2023-10-06 12:29:09 --> Router Class Initialized
INFO - 2023-10-06 12:29:09 --> Output Class Initialized
INFO - 2023-10-06 12:29:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:09 --> Input Class Initialized
INFO - 2023-10-06 12:29:09 --> Language Class Initialized
INFO - 2023-10-06 12:29:09 --> Language Class Initialized
INFO - 2023-10-06 12:29:09 --> Config Class Initialized
INFO - 2023-10-06 12:29:09 --> Loader Class Initialized
INFO - 2023-10-06 12:29:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:09 --> Controller Class Initialized
INFO - 2023-10-06 12:29:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:09 --> Total execution time: 0.1195
INFO - 2023-10-06 12:29:10 --> Config Class Initialized
INFO - 2023-10-06 12:29:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:10 --> URI Class Initialized
INFO - 2023-10-06 12:29:10 --> Router Class Initialized
INFO - 2023-10-06 12:29:10 --> Output Class Initialized
INFO - 2023-10-06 12:29:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:10 --> Input Class Initialized
INFO - 2023-10-06 12:29:10 --> Language Class Initialized
INFO - 2023-10-06 12:29:10 --> Language Class Initialized
INFO - 2023-10-06 12:29:10 --> Config Class Initialized
INFO - 2023-10-06 12:29:10 --> Loader Class Initialized
INFO - 2023-10-06 12:29:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:10 --> Controller Class Initialized
INFO - 2023-10-06 12:29:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:10 --> Total execution time: 0.0815
INFO - 2023-10-06 12:29:36 --> Config Class Initialized
INFO - 2023-10-06 12:29:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:36 --> URI Class Initialized
INFO - 2023-10-06 12:29:36 --> Router Class Initialized
INFO - 2023-10-06 12:29:36 --> Output Class Initialized
INFO - 2023-10-06 12:29:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:36 --> Input Class Initialized
INFO - 2023-10-06 12:29:36 --> Language Class Initialized
INFO - 2023-10-06 12:29:36 --> Language Class Initialized
INFO - 2023-10-06 12:29:36 --> Config Class Initialized
INFO - 2023-10-06 12:29:36 --> Loader Class Initialized
INFO - 2023-10-06 12:29:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:36 --> Controller Class Initialized
INFO - 2023-10-06 12:29:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:36 --> Total execution time: 0.0392
INFO - 2023-10-06 12:29:44 --> Config Class Initialized
INFO - 2023-10-06 12:29:44 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:44 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:44 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:44 --> URI Class Initialized
INFO - 2023-10-06 12:29:44 --> Router Class Initialized
INFO - 2023-10-06 12:29:44 --> Output Class Initialized
INFO - 2023-10-06 12:29:44 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:44 --> Input Class Initialized
INFO - 2023-10-06 12:29:44 --> Language Class Initialized
INFO - 2023-10-06 12:29:44 --> Language Class Initialized
INFO - 2023-10-06 12:29:44 --> Config Class Initialized
INFO - 2023-10-06 12:29:44 --> Loader Class Initialized
INFO - 2023-10-06 12:29:44 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:44 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:44 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:44 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:44 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:44 --> Controller Class Initialized
INFO - 2023-10-06 12:29:44 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:44 --> Total execution time: 0.0327
INFO - 2023-10-06 12:29:53 --> Config Class Initialized
INFO - 2023-10-06 12:29:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:29:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:29:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:29:53 --> URI Class Initialized
INFO - 2023-10-06 12:29:53 --> Router Class Initialized
INFO - 2023-10-06 12:29:53 --> Output Class Initialized
INFO - 2023-10-06 12:29:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:29:53 --> Input Class Initialized
INFO - 2023-10-06 12:29:53 --> Language Class Initialized
INFO - 2023-10-06 12:29:53 --> Language Class Initialized
INFO - 2023-10-06 12:29:53 --> Config Class Initialized
INFO - 2023-10-06 12:29:53 --> Loader Class Initialized
INFO - 2023-10-06 12:29:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:29:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:29:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:29:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:29:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:29:53 --> Controller Class Initialized
DEBUG - 2023-10-06 12:29:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-10-06 12:29:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:29:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:29:53 --> Total execution time: 0.0450
INFO - 2023-10-06 12:30:02 --> Config Class Initialized
INFO - 2023-10-06 12:30:02 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:02 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:02 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:02 --> URI Class Initialized
INFO - 2023-10-06 12:30:02 --> Router Class Initialized
INFO - 2023-10-06 12:30:02 --> Output Class Initialized
INFO - 2023-10-06 12:30:02 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:02 --> Input Class Initialized
INFO - 2023-10-06 12:30:02 --> Language Class Initialized
INFO - 2023-10-06 12:30:02 --> Language Class Initialized
INFO - 2023-10-06 12:30:02 --> Config Class Initialized
INFO - 2023-10-06 12:30:02 --> Loader Class Initialized
INFO - 2023-10-06 12:30:02 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:02 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:02 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:02 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:02 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:02 --> Controller Class Initialized
DEBUG - 2023-10-06 12:30:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:30:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:30:02 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:02 --> Total execution time: 0.0487
INFO - 2023-10-06 12:30:04 --> Config Class Initialized
INFO - 2023-10-06 12:30:04 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:04 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:04 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:04 --> URI Class Initialized
INFO - 2023-10-06 12:30:04 --> Router Class Initialized
INFO - 2023-10-06 12:30:04 --> Output Class Initialized
INFO - 2023-10-06 12:30:04 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:04 --> Input Class Initialized
INFO - 2023-10-06 12:30:04 --> Language Class Initialized
INFO - 2023-10-06 12:30:04 --> Language Class Initialized
INFO - 2023-10-06 12:30:04 --> Config Class Initialized
INFO - 2023-10-06 12:30:04 --> Loader Class Initialized
INFO - 2023-10-06 12:30:04 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:04 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:04 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:04 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:04 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:04 --> Controller Class Initialized
DEBUG - 2023-10-06 12:30:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:30:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:30:04 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:04 --> Total execution time: 0.0563
INFO - 2023-10-06 12:30:05 --> Config Class Initialized
INFO - 2023-10-06 12:30:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:05 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:05 --> URI Class Initialized
INFO - 2023-10-06 12:30:05 --> Router Class Initialized
INFO - 2023-10-06 12:30:05 --> Output Class Initialized
INFO - 2023-10-06 12:30:05 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:05 --> Input Class Initialized
INFO - 2023-10-06 12:30:05 --> Language Class Initialized
INFO - 2023-10-06 12:30:05 --> Language Class Initialized
INFO - 2023-10-06 12:30:05 --> Config Class Initialized
INFO - 2023-10-06 12:30:05 --> Loader Class Initialized
INFO - 2023-10-06 12:30:05 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:05 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:05 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:05 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:05 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:05 --> Controller Class Initialized
INFO - 2023-10-06 12:30:05 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:05 --> Total execution time: 0.0474
INFO - 2023-10-06 12:30:09 --> Config Class Initialized
INFO - 2023-10-06 12:30:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:09 --> URI Class Initialized
INFO - 2023-10-06 12:30:09 --> Router Class Initialized
INFO - 2023-10-06 12:30:09 --> Output Class Initialized
INFO - 2023-10-06 12:30:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:09 --> Input Class Initialized
INFO - 2023-10-06 12:30:09 --> Language Class Initialized
INFO - 2023-10-06 12:30:09 --> Language Class Initialized
INFO - 2023-10-06 12:30:09 --> Config Class Initialized
INFO - 2023-10-06 12:30:09 --> Loader Class Initialized
INFO - 2023-10-06 12:30:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:09 --> Controller Class Initialized
DEBUG - 2023-10-06 12:30:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:30:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:30:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:09 --> Total execution time: 0.0346
INFO - 2023-10-06 12:30:10 --> Config Class Initialized
INFO - 2023-10-06 12:30:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:10 --> URI Class Initialized
INFO - 2023-10-06 12:30:10 --> Router Class Initialized
INFO - 2023-10-06 12:30:10 --> Output Class Initialized
INFO - 2023-10-06 12:30:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:10 --> Input Class Initialized
INFO - 2023-10-06 12:30:10 --> Language Class Initialized
INFO - 2023-10-06 12:30:10 --> Language Class Initialized
INFO - 2023-10-06 12:30:10 --> Config Class Initialized
INFO - 2023-10-06 12:30:10 --> Loader Class Initialized
INFO - 2023-10-06 12:30:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:10 --> Controller Class Initialized
DEBUG - 2023-10-06 12:30:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:30:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:30:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:10 --> Total execution time: 0.0805
INFO - 2023-10-06 12:30:10 --> Config Class Initialized
INFO - 2023-10-06 12:30:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:10 --> URI Class Initialized
INFO - 2023-10-06 12:30:10 --> Router Class Initialized
INFO - 2023-10-06 12:30:10 --> Output Class Initialized
INFO - 2023-10-06 12:30:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:10 --> Input Class Initialized
INFO - 2023-10-06 12:30:10 --> Language Class Initialized
INFO - 2023-10-06 12:30:10 --> Language Class Initialized
INFO - 2023-10-06 12:30:10 --> Config Class Initialized
INFO - 2023-10-06 12:30:10 --> Loader Class Initialized
INFO - 2023-10-06 12:30:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:10 --> Controller Class Initialized
INFO - 2023-10-06 12:30:11 --> Config Class Initialized
INFO - 2023-10-06 12:30:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:11 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:11 --> URI Class Initialized
INFO - 2023-10-06 12:30:11 --> Router Class Initialized
INFO - 2023-10-06 12:30:11 --> Output Class Initialized
INFO - 2023-10-06 12:30:11 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:11 --> Input Class Initialized
INFO - 2023-10-06 12:30:11 --> Language Class Initialized
INFO - 2023-10-06 12:30:11 --> Language Class Initialized
INFO - 2023-10-06 12:30:11 --> Config Class Initialized
INFO - 2023-10-06 12:30:11 --> Loader Class Initialized
INFO - 2023-10-06 12:30:11 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:11 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:11 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:11 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:11 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:11 --> Controller Class Initialized
INFO - 2023-10-06 12:30:11 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:11 --> Total execution time: 0.0396
INFO - 2023-10-06 12:30:18 --> Config Class Initialized
INFO - 2023-10-06 12:30:18 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:18 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:18 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:18 --> URI Class Initialized
INFO - 2023-10-06 12:30:18 --> Router Class Initialized
INFO - 2023-10-06 12:30:18 --> Output Class Initialized
INFO - 2023-10-06 12:30:18 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:18 --> Input Class Initialized
INFO - 2023-10-06 12:30:18 --> Language Class Initialized
INFO - 2023-10-06 12:30:18 --> Language Class Initialized
INFO - 2023-10-06 12:30:18 --> Config Class Initialized
INFO - 2023-10-06 12:30:18 --> Loader Class Initialized
INFO - 2023-10-06 12:30:18 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:18 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:18 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:18 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:18 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:18 --> Controller Class Initialized
INFO - 2023-10-06 12:30:18 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:18 --> Total execution time: 0.0337
INFO - 2023-10-06 12:30:22 --> Config Class Initialized
INFO - 2023-10-06 12:30:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:22 --> URI Class Initialized
INFO - 2023-10-06 12:30:22 --> Router Class Initialized
INFO - 2023-10-06 12:30:22 --> Output Class Initialized
INFO - 2023-10-06 12:30:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:22 --> Input Class Initialized
INFO - 2023-10-06 12:30:22 --> Language Class Initialized
INFO - 2023-10-06 12:30:22 --> Language Class Initialized
INFO - 2023-10-06 12:30:22 --> Config Class Initialized
INFO - 2023-10-06 12:30:22 --> Loader Class Initialized
INFO - 2023-10-06 12:30:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:22 --> Controller Class Initialized
INFO - 2023-10-06 12:30:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:22 --> Total execution time: 0.1196
INFO - 2023-10-06 12:30:41 --> Config Class Initialized
INFO - 2023-10-06 12:30:41 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:30:41 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:30:41 --> Utf8 Class Initialized
INFO - 2023-10-06 12:30:41 --> URI Class Initialized
INFO - 2023-10-06 12:30:41 --> Router Class Initialized
INFO - 2023-10-06 12:30:41 --> Output Class Initialized
INFO - 2023-10-06 12:30:41 --> Security Class Initialized
DEBUG - 2023-10-06 12:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:30:41 --> Input Class Initialized
INFO - 2023-10-06 12:30:41 --> Language Class Initialized
INFO - 2023-10-06 12:30:41 --> Language Class Initialized
INFO - 2023-10-06 12:30:41 --> Config Class Initialized
INFO - 2023-10-06 12:30:41 --> Loader Class Initialized
INFO - 2023-10-06 12:30:41 --> Helper loaded: url_helper
INFO - 2023-10-06 12:30:41 --> Helper loaded: file_helper
INFO - 2023-10-06 12:30:41 --> Helper loaded: form_helper
INFO - 2023-10-06 12:30:41 --> Helper loaded: my_helper
INFO - 2023-10-06 12:30:41 --> Database Driver Class Initialized
INFO - 2023-10-06 12:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:30:41 --> Controller Class Initialized
INFO - 2023-10-06 12:30:41 --> Final output sent to browser
DEBUG - 2023-10-06 12:30:41 --> Total execution time: 0.0321
INFO - 2023-10-06 12:31:12 --> Config Class Initialized
INFO - 2023-10-06 12:31:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:12 --> URI Class Initialized
INFO - 2023-10-06 12:31:12 --> Router Class Initialized
INFO - 2023-10-06 12:31:12 --> Output Class Initialized
INFO - 2023-10-06 12:31:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:12 --> Input Class Initialized
INFO - 2023-10-06 12:31:12 --> Language Class Initialized
INFO - 2023-10-06 12:31:12 --> Language Class Initialized
INFO - 2023-10-06 12:31:12 --> Config Class Initialized
INFO - 2023-10-06 12:31:12 --> Loader Class Initialized
INFO - 2023-10-06 12:31:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:12 --> Controller Class Initialized
INFO - 2023-10-06 12:31:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:31:12 --> Total execution time: 0.0405
INFO - 2023-10-06 12:31:37 --> Config Class Initialized
INFO - 2023-10-06 12:31:37 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:37 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:37 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:37 --> URI Class Initialized
INFO - 2023-10-06 12:31:37 --> Router Class Initialized
INFO - 2023-10-06 12:31:37 --> Output Class Initialized
INFO - 2023-10-06 12:31:37 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:37 --> Input Class Initialized
INFO - 2023-10-06 12:31:37 --> Language Class Initialized
INFO - 2023-10-06 12:31:37 --> Language Class Initialized
INFO - 2023-10-06 12:31:37 --> Config Class Initialized
INFO - 2023-10-06 12:31:37 --> Loader Class Initialized
INFO - 2023-10-06 12:31:37 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:37 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:37 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:37 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:37 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:37 --> Controller Class Initialized
INFO - 2023-10-06 12:31:37 --> Final output sent to browser
DEBUG - 2023-10-06 12:31:37 --> Total execution time: 0.0385
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:46 --> URI Class Initialized
INFO - 2023-10-06 12:31:46 --> Router Class Initialized
INFO - 2023-10-06 12:31:46 --> Output Class Initialized
INFO - 2023-10-06 12:31:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:46 --> Input Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Loader Class Initialized
INFO - 2023-10-06 12:31:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:46 --> Controller Class Initialized
INFO - 2023-10-06 12:31:46 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:46 --> URI Class Initialized
INFO - 2023-10-06 12:31:46 --> Router Class Initialized
INFO - 2023-10-06 12:31:46 --> Output Class Initialized
INFO - 2023-10-06 12:31:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:46 --> Input Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Loader Class Initialized
INFO - 2023-10-06 12:31:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:46 --> Controller Class Initialized
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:46 --> URI Class Initialized
INFO - 2023-10-06 12:31:46 --> Router Class Initialized
INFO - 2023-10-06 12:31:46 --> Output Class Initialized
INFO - 2023-10-06 12:31:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:46 --> Input Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Language Class Initialized
INFO - 2023-10-06 12:31:46 --> Config Class Initialized
INFO - 2023-10-06 12:31:46 --> Loader Class Initialized
INFO - 2023-10-06 12:31:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:46 --> Controller Class Initialized
DEBUG - 2023-10-06 12:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:31:46 --> Final output sent to browser
DEBUG - 2023-10-06 12:31:46 --> Total execution time: 0.0314
INFO - 2023-10-06 12:31:57 --> Config Class Initialized
INFO - 2023-10-06 12:31:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:57 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:57 --> URI Class Initialized
INFO - 2023-10-06 12:31:57 --> Router Class Initialized
INFO - 2023-10-06 12:31:57 --> Output Class Initialized
INFO - 2023-10-06 12:31:57 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:57 --> Input Class Initialized
INFO - 2023-10-06 12:31:57 --> Language Class Initialized
INFO - 2023-10-06 12:31:57 --> Language Class Initialized
INFO - 2023-10-06 12:31:57 --> Config Class Initialized
INFO - 2023-10-06 12:31:57 --> Loader Class Initialized
INFO - 2023-10-06 12:31:57 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:57 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:57 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:57 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:57 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:57 --> Controller Class Initialized
INFO - 2023-10-06 12:31:57 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:31:57 --> Final output sent to browser
DEBUG - 2023-10-06 12:31:57 --> Total execution time: 0.0546
INFO - 2023-10-06 12:31:58 --> Config Class Initialized
INFO - 2023-10-06 12:31:58 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:31:58 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:31:58 --> Utf8 Class Initialized
INFO - 2023-10-06 12:31:58 --> URI Class Initialized
INFO - 2023-10-06 12:31:58 --> Router Class Initialized
INFO - 2023-10-06 12:31:58 --> Output Class Initialized
INFO - 2023-10-06 12:31:58 --> Security Class Initialized
DEBUG - 2023-10-06 12:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:31:58 --> Input Class Initialized
INFO - 2023-10-06 12:31:58 --> Language Class Initialized
INFO - 2023-10-06 12:31:58 --> Language Class Initialized
INFO - 2023-10-06 12:31:58 --> Config Class Initialized
INFO - 2023-10-06 12:31:58 --> Loader Class Initialized
INFO - 2023-10-06 12:31:58 --> Helper loaded: url_helper
INFO - 2023-10-06 12:31:58 --> Helper loaded: file_helper
INFO - 2023-10-06 12:31:58 --> Helper loaded: form_helper
INFO - 2023-10-06 12:31:58 --> Helper loaded: my_helper
INFO - 2023-10-06 12:31:58 --> Database Driver Class Initialized
INFO - 2023-10-06 12:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:31:58 --> Controller Class Initialized
DEBUG - 2023-10-06 12:31:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:31:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:31:58 --> Final output sent to browser
DEBUG - 2023-10-06 12:31:58 --> Total execution time: 0.0351
INFO - 2023-10-06 12:32:00 --> Config Class Initialized
INFO - 2023-10-06 12:32:00 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:00 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:00 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:00 --> URI Class Initialized
INFO - 2023-10-06 12:32:00 --> Router Class Initialized
INFO - 2023-10-06 12:32:00 --> Output Class Initialized
INFO - 2023-10-06 12:32:00 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:00 --> Input Class Initialized
INFO - 2023-10-06 12:32:00 --> Language Class Initialized
INFO - 2023-10-06 12:32:00 --> Language Class Initialized
INFO - 2023-10-06 12:32:00 --> Config Class Initialized
INFO - 2023-10-06 12:32:00 --> Loader Class Initialized
INFO - 2023-10-06 12:32:00 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:00 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:00 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:00 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:00 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:00 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-06 12:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:32:00 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:00 --> Total execution time: 0.0960
INFO - 2023-10-06 12:32:01 --> Config Class Initialized
INFO - 2023-10-06 12:32:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:01 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:01 --> URI Class Initialized
INFO - 2023-10-06 12:32:01 --> Router Class Initialized
INFO - 2023-10-06 12:32:01 --> Output Class Initialized
INFO - 2023-10-06 12:32:01 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:01 --> Input Class Initialized
INFO - 2023-10-06 12:32:01 --> Language Class Initialized
INFO - 2023-10-06 12:32:02 --> Language Class Initialized
INFO - 2023-10-06 12:32:02 --> Config Class Initialized
INFO - 2023-10-06 12:32:02 --> Loader Class Initialized
INFO - 2023-10-06 12:32:02 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:02 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:02 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:02 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:02 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:02 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:03 --> Config Class Initialized
INFO - 2023-10-06 12:32:03 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:03 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:03 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:03 --> URI Class Initialized
INFO - 2023-10-06 12:32:03 --> Router Class Initialized
INFO - 2023-10-06 12:32:03 --> Output Class Initialized
INFO - 2023-10-06 12:32:03 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:03 --> Input Class Initialized
INFO - 2023-10-06 12:32:03 --> Language Class Initialized
INFO - 2023-10-06 12:32:03 --> Language Class Initialized
INFO - 2023-10-06 12:32:03 --> Config Class Initialized
INFO - 2023-10-06 12:32:03 --> Loader Class Initialized
INFO - 2023-10-06 12:32:03 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:03 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:03 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:03 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:03 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:04 --> Config Class Initialized
INFO - 2023-10-06 12:32:04 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:04 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:04 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:04 --> URI Class Initialized
INFO - 2023-10-06 12:32:04 --> Router Class Initialized
INFO - 2023-10-06 12:32:04 --> Output Class Initialized
INFO - 2023-10-06 12:32:04 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:04 --> Input Class Initialized
INFO - 2023-10-06 12:32:04 --> Language Class Initialized
INFO - 2023-10-06 12:32:04 --> Language Class Initialized
INFO - 2023-10-06 12:32:04 --> Config Class Initialized
INFO - 2023-10-06 12:32:04 --> Loader Class Initialized
INFO - 2023-10-06 12:32:04 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:04 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:04 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:04 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:04 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:05 --> Config Class Initialized
INFO - 2023-10-06 12:32:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:05 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:05 --> URI Class Initialized
INFO - 2023-10-06 12:32:05 --> Router Class Initialized
INFO - 2023-10-06 12:32:05 --> Output Class Initialized
INFO - 2023-10-06 12:32:05 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:05 --> Input Class Initialized
INFO - 2023-10-06 12:32:05 --> Language Class Initialized
INFO - 2023-10-06 12:32:05 --> Language Class Initialized
INFO - 2023-10-06 12:32:05 --> Config Class Initialized
INFO - 2023-10-06 12:32:05 --> Loader Class Initialized
INFO - 2023-10-06 12:32:05 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:05 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:05 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:05 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:05 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:07 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:07 --> Total execution time: 5.6403
INFO - 2023-10-06 12:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:07 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:08 --> Config Class Initialized
INFO - 2023-10-06 12:32:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:08 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:08 --> URI Class Initialized
INFO - 2023-10-06 12:32:08 --> Router Class Initialized
INFO - 2023-10-06 12:32:08 --> Output Class Initialized
INFO - 2023-10-06 12:32:08 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:08 --> Input Class Initialized
INFO - 2023-10-06 12:32:08 --> Language Class Initialized
INFO - 2023-10-06 12:32:08 --> Language Class Initialized
INFO - 2023-10-06 12:32:08 --> Config Class Initialized
INFO - 2023-10-06 12:32:08 --> Loader Class Initialized
INFO - 2023-10-06 12:32:08 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:08 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:08 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:08 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:10 --> Config Class Initialized
INFO - 2023-10-06 12:32:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:32:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:32:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:32:10 --> URI Class Initialized
INFO - 2023-10-06 12:32:10 --> Router Class Initialized
INFO - 2023-10-06 12:32:10 --> Output Class Initialized
INFO - 2023-10-06 12:32:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:32:10 --> Input Class Initialized
INFO - 2023-10-06 12:32:10 --> Language Class Initialized
INFO - 2023-10-06 12:32:10 --> Language Class Initialized
INFO - 2023-10-06 12:32:10 --> Config Class Initialized
INFO - 2023-10-06 12:32:10 --> Loader Class Initialized
INFO - 2023-10-06 12:32:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:32:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:32:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:32:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:32:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:32:11 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:11 --> Total execution time: 8.5587
INFO - 2023-10-06 12:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:11 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:15 --> Total execution time: 11.4694
INFO - 2023-10-06 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:20 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:20 --> Total execution time: 14.7461
INFO - 2023-10-06 12:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:20 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:24 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:24 --> Total execution time: 15.1184
INFO - 2023-10-06 12:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:32:24 --> Controller Class Initialized
DEBUG - 2023-10-06 12:32:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:32:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:32:27 --> Total execution time: 16.6151
INFO - 2023-10-06 12:33:33 --> Config Class Initialized
INFO - 2023-10-06 12:33:33 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:33:33 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:33:33 --> Utf8 Class Initialized
INFO - 2023-10-06 12:33:33 --> URI Class Initialized
INFO - 2023-10-06 12:33:33 --> Router Class Initialized
INFO - 2023-10-06 12:33:33 --> Output Class Initialized
INFO - 2023-10-06 12:33:33 --> Security Class Initialized
DEBUG - 2023-10-06 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:33:33 --> Input Class Initialized
INFO - 2023-10-06 12:33:33 --> Language Class Initialized
INFO - 2023-10-06 12:33:33 --> Language Class Initialized
INFO - 2023-10-06 12:33:33 --> Config Class Initialized
INFO - 2023-10-06 12:33:33 --> Loader Class Initialized
INFO - 2023-10-06 12:33:33 --> Helper loaded: url_helper
INFO - 2023-10-06 12:33:33 --> Helper loaded: file_helper
INFO - 2023-10-06 12:33:33 --> Helper loaded: form_helper
INFO - 2023-10-06 12:33:33 --> Helper loaded: my_helper
INFO - 2023-10-06 12:33:33 --> Database Driver Class Initialized
INFO - 2023-10-06 12:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:33:33 --> Controller Class Initialized
DEBUG - 2023-10-06 12:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:33:37 --> Final output sent to browser
DEBUG - 2023-10-06 12:33:37 --> Total execution time: 3.5526
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:33:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:33:56 --> Utf8 Class Initialized
INFO - 2023-10-06 12:33:56 --> URI Class Initialized
INFO - 2023-10-06 12:33:56 --> Router Class Initialized
INFO - 2023-10-06 12:33:56 --> Output Class Initialized
INFO - 2023-10-06 12:33:56 --> Security Class Initialized
DEBUG - 2023-10-06 12:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:33:56 --> Input Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Loader Class Initialized
INFO - 2023-10-06 12:33:56 --> Helper loaded: url_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: file_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: form_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: my_helper
INFO - 2023-10-06 12:33:56 --> Database Driver Class Initialized
INFO - 2023-10-06 12:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:33:56 --> Controller Class Initialized
INFO - 2023-10-06 12:33:56 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:33:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:33:56 --> Utf8 Class Initialized
INFO - 2023-10-06 12:33:56 --> URI Class Initialized
INFO - 2023-10-06 12:33:56 --> Router Class Initialized
INFO - 2023-10-06 12:33:56 --> Output Class Initialized
INFO - 2023-10-06 12:33:56 --> Security Class Initialized
DEBUG - 2023-10-06 12:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:33:56 --> Input Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Loader Class Initialized
INFO - 2023-10-06 12:33:56 --> Helper loaded: url_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: file_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: form_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: my_helper
INFO - 2023-10-06 12:33:56 --> Database Driver Class Initialized
INFO - 2023-10-06 12:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:33:56 --> Controller Class Initialized
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:33:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:33:56 --> Utf8 Class Initialized
INFO - 2023-10-06 12:33:56 --> URI Class Initialized
INFO - 2023-10-06 12:33:56 --> Router Class Initialized
INFO - 2023-10-06 12:33:56 --> Output Class Initialized
INFO - 2023-10-06 12:33:56 --> Security Class Initialized
DEBUG - 2023-10-06 12:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:33:56 --> Input Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Language Class Initialized
INFO - 2023-10-06 12:33:56 --> Config Class Initialized
INFO - 2023-10-06 12:33:56 --> Loader Class Initialized
INFO - 2023-10-06 12:33:56 --> Helper loaded: url_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: file_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: form_helper
INFO - 2023-10-06 12:33:56 --> Helper loaded: my_helper
INFO - 2023-10-06 12:33:56 --> Database Driver Class Initialized
INFO - 2023-10-06 12:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:33:56 --> Controller Class Initialized
DEBUG - 2023-10-06 12:33:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:33:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:33:56 --> Final output sent to browser
DEBUG - 2023-10-06 12:33:56 --> Total execution time: 0.0330
INFO - 2023-10-06 12:34:01 --> Config Class Initialized
INFO - 2023-10-06 12:34:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:01 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:01 --> URI Class Initialized
INFO - 2023-10-06 12:34:01 --> Router Class Initialized
INFO - 2023-10-06 12:34:01 --> Output Class Initialized
INFO - 2023-10-06 12:34:01 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:01 --> Input Class Initialized
INFO - 2023-10-06 12:34:01 --> Language Class Initialized
INFO - 2023-10-06 12:34:01 --> Language Class Initialized
INFO - 2023-10-06 12:34:01 --> Config Class Initialized
INFO - 2023-10-06 12:34:01 --> Loader Class Initialized
INFO - 2023-10-06 12:34:01 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:01 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:01 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:01 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:01 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:01 --> Controller Class Initialized
INFO - 2023-10-06 12:34:01 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:01 --> Total execution time: 0.0550
INFO - 2023-10-06 12:34:07 --> Config Class Initialized
INFO - 2023-10-06 12:34:07 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:07 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:07 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:07 --> URI Class Initialized
INFO - 2023-10-06 12:34:07 --> Router Class Initialized
INFO - 2023-10-06 12:34:07 --> Output Class Initialized
INFO - 2023-10-06 12:34:07 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:07 --> Input Class Initialized
INFO - 2023-10-06 12:34:07 --> Language Class Initialized
INFO - 2023-10-06 12:34:07 --> Language Class Initialized
INFO - 2023-10-06 12:34:07 --> Config Class Initialized
INFO - 2023-10-06 12:34:07 --> Loader Class Initialized
INFO - 2023-10-06 12:34:07 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:07 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:07 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:07 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:07 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:07 --> Controller Class Initialized
INFO - 2023-10-06 12:34:07 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:07 --> Total execution time: 0.0342
INFO - 2023-10-06 12:34:11 --> Config Class Initialized
INFO - 2023-10-06 12:34:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:11 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:11 --> URI Class Initialized
INFO - 2023-10-06 12:34:11 --> Router Class Initialized
INFO - 2023-10-06 12:34:11 --> Output Class Initialized
INFO - 2023-10-06 12:34:11 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:11 --> Input Class Initialized
INFO - 2023-10-06 12:34:11 --> Language Class Initialized
INFO - 2023-10-06 12:34:11 --> Language Class Initialized
INFO - 2023-10-06 12:34:11 --> Config Class Initialized
INFO - 2023-10-06 12:34:11 --> Loader Class Initialized
INFO - 2023-10-06 12:34:11 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:11 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:11 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:11 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:11 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:11 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 12:34:13 --> Config Class Initialized
INFO - 2023-10-06 12:34:13 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:13 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:13 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:13 --> URI Class Initialized
INFO - 2023-10-06 12:34:13 --> Router Class Initialized
INFO - 2023-10-06 12:34:13 --> Output Class Initialized
INFO - 2023-10-06 12:34:13 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:13 --> Input Class Initialized
INFO - 2023-10-06 12:34:13 --> Language Class Initialized
INFO - 2023-10-06 12:34:13 --> Language Class Initialized
INFO - 2023-10-06 12:34:13 --> Config Class Initialized
INFO - 2023-10-06 12:34:13 --> Loader Class Initialized
INFO - 2023-10-06 12:34:13 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:13 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:13 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:13 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:13 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:13 --> Controller Class Initialized
INFO - 2023-10-06 12:34:13 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:13 --> Total execution time: 0.1493
INFO - 2023-10-06 12:34:16 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:16 --> Total execution time: 5.1507
INFO - 2023-10-06 12:34:21 --> Config Class Initialized
INFO - 2023-10-06 12:34:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:21 --> URI Class Initialized
INFO - 2023-10-06 12:34:21 --> Router Class Initialized
INFO - 2023-10-06 12:34:21 --> Output Class Initialized
INFO - 2023-10-06 12:34:21 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:21 --> Input Class Initialized
INFO - 2023-10-06 12:34:21 --> Language Class Initialized
INFO - 2023-10-06 12:34:21 --> Language Class Initialized
INFO - 2023-10-06 12:34:21 --> Config Class Initialized
INFO - 2023-10-06 12:34:21 --> Loader Class Initialized
INFO - 2023-10-06 12:34:21 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:21 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:21 --> Controller Class Initialized
INFO - 2023-10-06 12:34:21 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:34:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:21 --> Total execution time: 0.1051
INFO - 2023-10-06 12:34:21 --> Config Class Initialized
INFO - 2023-10-06 12:34:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:21 --> URI Class Initialized
INFO - 2023-10-06 12:34:21 --> Router Class Initialized
INFO - 2023-10-06 12:34:21 --> Output Class Initialized
INFO - 2023-10-06 12:34:21 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:21 --> Input Class Initialized
INFO - 2023-10-06 12:34:21 --> Language Class Initialized
INFO - 2023-10-06 12:34:21 --> Language Class Initialized
INFO - 2023-10-06 12:34:21 --> Config Class Initialized
INFO - 2023-10-06 12:34:21 --> Loader Class Initialized
INFO - 2023-10-06 12:34:21 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:21 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:21 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:21 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:21 --> Total execution time: 0.0546
INFO - 2023-10-06 12:34:23 --> Config Class Initialized
INFO - 2023-10-06 12:34:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:23 --> URI Class Initialized
INFO - 2023-10-06 12:34:23 --> Router Class Initialized
INFO - 2023-10-06 12:34:23 --> Output Class Initialized
INFO - 2023-10-06 12:34:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:23 --> Input Class Initialized
INFO - 2023-10-06 12:34:23 --> Language Class Initialized
INFO - 2023-10-06 12:34:23 --> Language Class Initialized
INFO - 2023-10-06 12:34:23 --> Config Class Initialized
INFO - 2023-10-06 12:34:23 --> Loader Class Initialized
INFO - 2023-10-06 12:34:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:24 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:24 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:24 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:24 --> Total execution time: 0.1141
INFO - 2023-10-06 12:34:25 --> Config Class Initialized
INFO - 2023-10-06 12:34:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:25 --> URI Class Initialized
INFO - 2023-10-06 12:34:25 --> Router Class Initialized
INFO - 2023-10-06 12:34:25 --> Output Class Initialized
INFO - 2023-10-06 12:34:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:25 --> Input Class Initialized
INFO - 2023-10-06 12:34:25 --> Language Class Initialized
INFO - 2023-10-06 12:34:25 --> Language Class Initialized
INFO - 2023-10-06 12:34:25 --> Config Class Initialized
INFO - 2023-10-06 12:34:25 --> Loader Class Initialized
INFO - 2023-10-06 12:34:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:25 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:34:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:25 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:25 --> Total execution time: 0.0368
INFO - 2023-10-06 12:34:25 --> Config Class Initialized
INFO - 2023-10-06 12:34:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:25 --> URI Class Initialized
INFO - 2023-10-06 12:34:25 --> Router Class Initialized
INFO - 2023-10-06 12:34:25 --> Output Class Initialized
INFO - 2023-10-06 12:34:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:25 --> Input Class Initialized
INFO - 2023-10-06 12:34:25 --> Language Class Initialized
INFO - 2023-10-06 12:34:25 --> Language Class Initialized
INFO - 2023-10-06 12:34:25 --> Config Class Initialized
INFO - 2023-10-06 12:34:25 --> Loader Class Initialized
INFO - 2023-10-06 12:34:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:25 --> Controller Class Initialized
INFO - 2023-10-06 12:34:26 --> Config Class Initialized
INFO - 2023-10-06 12:34:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:26 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:26 --> URI Class Initialized
INFO - 2023-10-06 12:34:26 --> Router Class Initialized
INFO - 2023-10-06 12:34:26 --> Output Class Initialized
INFO - 2023-10-06 12:34:26 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:26 --> Input Class Initialized
INFO - 2023-10-06 12:34:26 --> Language Class Initialized
INFO - 2023-10-06 12:34:26 --> Language Class Initialized
INFO - 2023-10-06 12:34:26 --> Config Class Initialized
INFO - 2023-10-06 12:34:26 --> Loader Class Initialized
INFO - 2023-10-06 12:34:26 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:26 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:26 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:26 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:26 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:26 --> Controller Class Initialized
INFO - 2023-10-06 12:34:26 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:26 --> Total execution time: 0.1292
INFO - 2023-10-06 12:34:27 --> Config Class Initialized
INFO - 2023-10-06 12:34:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:27 --> URI Class Initialized
INFO - 2023-10-06 12:34:27 --> Router Class Initialized
INFO - 2023-10-06 12:34:27 --> Output Class Initialized
INFO - 2023-10-06 12:34:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:27 --> Input Class Initialized
INFO - 2023-10-06 12:34:27 --> Language Class Initialized
INFO - 2023-10-06 12:34:27 --> Language Class Initialized
INFO - 2023-10-06 12:34:27 --> Config Class Initialized
INFO - 2023-10-06 12:34:27 --> Loader Class Initialized
INFO - 2023-10-06 12:34:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:27 --> Controller Class Initialized
INFO - 2023-10-06 12:34:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:27 --> Total execution time: 0.0390
INFO - 2023-10-06 12:34:27 --> Config Class Initialized
INFO - 2023-10-06 12:34:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:27 --> URI Class Initialized
INFO - 2023-10-06 12:34:27 --> Router Class Initialized
INFO - 2023-10-06 12:34:27 --> Output Class Initialized
INFO - 2023-10-06 12:34:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:27 --> Input Class Initialized
INFO - 2023-10-06 12:34:27 --> Language Class Initialized
INFO - 2023-10-06 12:34:27 --> Language Class Initialized
INFO - 2023-10-06 12:34:27 --> Config Class Initialized
INFO - 2023-10-06 12:34:27 --> Loader Class Initialized
INFO - 2023-10-06 12:34:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:28 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:28 --> Controller Class Initialized
INFO - 2023-10-06 12:34:28 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:28 --> Total execution time: 0.0363
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:29 --> URI Class Initialized
INFO - 2023-10-06 12:34:29 --> Router Class Initialized
INFO - 2023-10-06 12:34:29 --> Output Class Initialized
INFO - 2023-10-06 12:34:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:29 --> Input Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Loader Class Initialized
INFO - 2023-10-06 12:34:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:29 --> URI Class Initialized
INFO - 2023-10-06 12:34:29 --> Router Class Initialized
INFO - 2023-10-06 12:34:29 --> Output Class Initialized
INFO - 2023-10-06 12:34:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:29 --> Input Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Loader Class Initialized
INFO - 2023-10-06 12:34:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:29 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:29 --> Controller Class Initialized
INFO - 2023-10-06 12:34:29 --> Database Driver Class Initialized
DEBUG - 2023-10-06 12:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:29 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:29 --> Total execution time: 0.1304
INFO - 2023-10-06 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:29 --> Controller Class Initialized
INFO - 2023-10-06 12:34:29 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:29 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:29 --> URI Class Initialized
INFO - 2023-10-06 12:34:29 --> Router Class Initialized
INFO - 2023-10-06 12:34:29 --> Output Class Initialized
INFO - 2023-10-06 12:34:29 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:29 --> Input Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Language Class Initialized
INFO - 2023-10-06 12:34:29 --> Config Class Initialized
INFO - 2023-10-06 12:34:29 --> Loader Class Initialized
INFO - 2023-10-06 12:34:29 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:29 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:29 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:30 --> Controller Class Initialized
INFO - 2023-10-06 12:34:30 --> Config Class Initialized
INFO - 2023-10-06 12:34:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:30 --> URI Class Initialized
INFO - 2023-10-06 12:34:30 --> Router Class Initialized
INFO - 2023-10-06 12:34:30 --> Output Class Initialized
INFO - 2023-10-06 12:34:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:30 --> Input Class Initialized
INFO - 2023-10-06 12:34:30 --> Language Class Initialized
INFO - 2023-10-06 12:34:30 --> Language Class Initialized
INFO - 2023-10-06 12:34:30 --> Config Class Initialized
INFO - 2023-10-06 12:34:30 --> Loader Class Initialized
INFO - 2023-10-06 12:34:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:30 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:30 --> Total execution time: 0.1311
INFO - 2023-10-06 12:34:30 --> Config Class Initialized
INFO - 2023-10-06 12:34:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:30 --> URI Class Initialized
INFO - 2023-10-06 12:34:30 --> Router Class Initialized
INFO - 2023-10-06 12:34:30 --> Output Class Initialized
INFO - 2023-10-06 12:34:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:30 --> Input Class Initialized
INFO - 2023-10-06 12:34:30 --> Language Class Initialized
INFO - 2023-10-06 12:34:30 --> Language Class Initialized
INFO - 2023-10-06 12:34:30 --> Config Class Initialized
INFO - 2023-10-06 12:34:30 --> Loader Class Initialized
INFO - 2023-10-06 12:34:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:30 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:30 --> Total execution time: 0.0440
INFO - 2023-10-06 12:34:31 --> Config Class Initialized
INFO - 2023-10-06 12:34:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:31 --> URI Class Initialized
INFO - 2023-10-06 12:34:31 --> Router Class Initialized
INFO - 2023-10-06 12:34:31 --> Output Class Initialized
INFO - 2023-10-06 12:34:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:31 --> Input Class Initialized
INFO - 2023-10-06 12:34:31 --> Language Class Initialized
INFO - 2023-10-06 12:34:31 --> Language Class Initialized
INFO - 2023-10-06 12:34:31 --> Config Class Initialized
INFO - 2023-10-06 12:34:31 --> Loader Class Initialized
INFO - 2023-10-06 12:34:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:31 --> Controller Class Initialized
INFO - 2023-10-06 12:34:32 --> Config Class Initialized
INFO - 2023-10-06 12:34:32 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:32 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:32 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:32 --> URI Class Initialized
INFO - 2023-10-06 12:34:32 --> Router Class Initialized
INFO - 2023-10-06 12:34:32 --> Output Class Initialized
INFO - 2023-10-06 12:34:32 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:32 --> Input Class Initialized
INFO - 2023-10-06 12:34:32 --> Language Class Initialized
INFO - 2023-10-06 12:34:32 --> Language Class Initialized
INFO - 2023-10-06 12:34:32 --> Config Class Initialized
INFO - 2023-10-06 12:34:32 --> Loader Class Initialized
INFO - 2023-10-06 12:34:32 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:32 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:32 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:32 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:32 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:32 --> Controller Class Initialized
INFO - 2023-10-06 12:34:32 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:32 --> Total execution time: 0.0368
INFO - 2023-10-06 12:34:34 --> Config Class Initialized
INFO - 2023-10-06 12:34:34 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:34 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:34 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:34 --> URI Class Initialized
INFO - 2023-10-06 12:34:34 --> Router Class Initialized
INFO - 2023-10-06 12:34:34 --> Output Class Initialized
INFO - 2023-10-06 12:34:34 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:34 --> Input Class Initialized
INFO - 2023-10-06 12:34:34 --> Language Class Initialized
INFO - 2023-10-06 12:34:34 --> Language Class Initialized
INFO - 2023-10-06 12:34:34 --> Config Class Initialized
INFO - 2023-10-06 12:34:34 --> Loader Class Initialized
INFO - 2023-10-06 12:34:34 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:34 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:34 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:34 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:34 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:34 --> Controller Class Initialized
INFO - 2023-10-06 12:34:34 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:34 --> Total execution time: 0.0347
INFO - 2023-10-06 12:34:35 --> Config Class Initialized
INFO - 2023-10-06 12:34:35 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:35 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:35 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:35 --> URI Class Initialized
INFO - 2023-10-06 12:34:35 --> Router Class Initialized
INFO - 2023-10-06 12:34:35 --> Output Class Initialized
INFO - 2023-10-06 12:34:35 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:35 --> Input Class Initialized
INFO - 2023-10-06 12:34:35 --> Language Class Initialized
INFO - 2023-10-06 12:34:35 --> Language Class Initialized
INFO - 2023-10-06 12:34:35 --> Config Class Initialized
INFO - 2023-10-06 12:34:35 --> Loader Class Initialized
INFO - 2023-10-06 12:34:35 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:35 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:35 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:35 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:35 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:35 --> Controller Class Initialized
INFO - 2023-10-06 12:34:35 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:35 --> Total execution time: 0.1185
INFO - 2023-10-06 12:34:38 --> Config Class Initialized
INFO - 2023-10-06 12:34:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:38 --> URI Class Initialized
INFO - 2023-10-06 12:34:38 --> Router Class Initialized
INFO - 2023-10-06 12:34:38 --> Output Class Initialized
INFO - 2023-10-06 12:34:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:38 --> Input Class Initialized
INFO - 2023-10-06 12:34:38 --> Language Class Initialized
INFO - 2023-10-06 12:34:38 --> Language Class Initialized
INFO - 2023-10-06 12:34:38 --> Config Class Initialized
INFO - 2023-10-06 12:34:38 --> Loader Class Initialized
INFO - 2023-10-06 12:34:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:38 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:38 --> Controller Class Initialized
INFO - 2023-10-06 12:34:38 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:38 --> Total execution time: 0.0909
INFO - 2023-10-06 12:34:43 --> Config Class Initialized
INFO - 2023-10-06 12:34:43 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:43 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:43 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:43 --> URI Class Initialized
INFO - 2023-10-06 12:34:43 --> Router Class Initialized
INFO - 2023-10-06 12:34:43 --> Output Class Initialized
INFO - 2023-10-06 12:34:43 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:43 --> Input Class Initialized
INFO - 2023-10-06 12:34:43 --> Language Class Initialized
INFO - 2023-10-06 12:34:43 --> Language Class Initialized
INFO - 2023-10-06 12:34:43 --> Config Class Initialized
INFO - 2023-10-06 12:34:43 --> Loader Class Initialized
INFO - 2023-10-06 12:34:43 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:43 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:43 --> Controller Class Initialized
INFO - 2023-10-06 12:34:43 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:34:43 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:43 --> Total execution time: 0.0690
INFO - 2023-10-06 12:34:43 --> Config Class Initialized
INFO - 2023-10-06 12:34:43 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:43 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:43 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:43 --> URI Class Initialized
INFO - 2023-10-06 12:34:43 --> Router Class Initialized
INFO - 2023-10-06 12:34:43 --> Output Class Initialized
INFO - 2023-10-06 12:34:43 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:43 --> Input Class Initialized
INFO - 2023-10-06 12:34:43 --> Language Class Initialized
INFO - 2023-10-06 12:34:43 --> Language Class Initialized
INFO - 2023-10-06 12:34:43 --> Config Class Initialized
INFO - 2023-10-06 12:34:43 --> Loader Class Initialized
INFO - 2023-10-06 12:34:43 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:43 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:43 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:43 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:34:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:43 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:43 --> Total execution time: 0.0938
INFO - 2023-10-06 12:34:46 --> Config Class Initialized
INFO - 2023-10-06 12:34:46 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:46 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:46 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:46 --> URI Class Initialized
INFO - 2023-10-06 12:34:46 --> Router Class Initialized
INFO - 2023-10-06 12:34:46 --> Output Class Initialized
INFO - 2023-10-06 12:34:46 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:46 --> Input Class Initialized
INFO - 2023-10-06 12:34:46 --> Language Class Initialized
INFO - 2023-10-06 12:34:46 --> Language Class Initialized
INFO - 2023-10-06 12:34:46 --> Config Class Initialized
INFO - 2023-10-06 12:34:46 --> Loader Class Initialized
INFO - 2023-10-06 12:34:46 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:46 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:46 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:46 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:46 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:46 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:34:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:46 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:46 --> Total execution time: 0.1183
INFO - 2023-10-06 12:34:48 --> Config Class Initialized
INFO - 2023-10-06 12:34:48 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:48 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:48 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:48 --> URI Class Initialized
INFO - 2023-10-06 12:34:48 --> Router Class Initialized
INFO - 2023-10-06 12:34:48 --> Output Class Initialized
INFO - 2023-10-06 12:34:48 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:48 --> Input Class Initialized
INFO - 2023-10-06 12:34:48 --> Language Class Initialized
INFO - 2023-10-06 12:34:48 --> Language Class Initialized
INFO - 2023-10-06 12:34:48 --> Config Class Initialized
INFO - 2023-10-06 12:34:48 --> Loader Class Initialized
INFO - 2023-10-06 12:34:48 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:48 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:48 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:48 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:48 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:48 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:48 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:48 --> Total execution time: 0.0503
INFO - 2023-10-06 12:34:50 --> Config Class Initialized
INFO - 2023-10-06 12:34:50 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:50 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:50 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:50 --> URI Class Initialized
INFO - 2023-10-06 12:34:50 --> Router Class Initialized
INFO - 2023-10-06 12:34:50 --> Output Class Initialized
INFO - 2023-10-06 12:34:50 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:50 --> Input Class Initialized
INFO - 2023-10-06 12:34:50 --> Language Class Initialized
INFO - 2023-10-06 12:34:50 --> Language Class Initialized
INFO - 2023-10-06 12:34:50 --> Config Class Initialized
INFO - 2023-10-06 12:34:50 --> Loader Class Initialized
INFO - 2023-10-06 12:34:50 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:50 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:50 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:34:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:50 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:50 --> Total execution time: 0.0608
INFO - 2023-10-06 12:34:50 --> Config Class Initialized
INFO - 2023-10-06 12:34:50 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:50 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:50 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:50 --> URI Class Initialized
INFO - 2023-10-06 12:34:50 --> Router Class Initialized
INFO - 2023-10-06 12:34:50 --> Output Class Initialized
INFO - 2023-10-06 12:34:50 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:50 --> Input Class Initialized
INFO - 2023-10-06 12:34:50 --> Language Class Initialized
INFO - 2023-10-06 12:34:50 --> Language Class Initialized
INFO - 2023-10-06 12:34:50 --> Config Class Initialized
INFO - 2023-10-06 12:34:50 --> Loader Class Initialized
INFO - 2023-10-06 12:34:50 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:50 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:50 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:50 --> Controller Class Initialized
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:52 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:52 --> URI Class Initialized
INFO - 2023-10-06 12:34:52 --> Router Class Initialized
INFO - 2023-10-06 12:34:52 --> Output Class Initialized
INFO - 2023-10-06 12:34:52 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:52 --> Input Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Loader Class Initialized
INFO - 2023-10-06 12:34:52 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:52 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:52 --> Controller Class Initialized
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:52 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:52 --> URI Class Initialized
INFO - 2023-10-06 12:34:52 --> Router Class Initialized
INFO - 2023-10-06 12:34:52 --> Output Class Initialized
INFO - 2023-10-06 12:34:52 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:52 --> Input Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Loader Class Initialized
INFO - 2023-10-06 12:34:52 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:52 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:52 --> Total execution time: 0.1012
INFO - 2023-10-06 12:34:52 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:52 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:52 --> Controller Class Initialized
DEBUG - 2023-10-06 12:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:34:52 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:52 --> Total execution time: 0.0731
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:52 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:52 --> URI Class Initialized
INFO - 2023-10-06 12:34:52 --> Router Class Initialized
INFO - 2023-10-06 12:34:52 --> Output Class Initialized
INFO - 2023-10-06 12:34:52 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:52 --> Input Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Language Class Initialized
INFO - 2023-10-06 12:34:52 --> Config Class Initialized
INFO - 2023-10-06 12:34:52 --> Loader Class Initialized
INFO - 2023-10-06 12:34:52 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:52 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:52 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:52 --> Controller Class Initialized
INFO - 2023-10-06 12:34:53 --> Config Class Initialized
INFO - 2023-10-06 12:34:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:34:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:34:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:34:53 --> URI Class Initialized
INFO - 2023-10-06 12:34:53 --> Router Class Initialized
INFO - 2023-10-06 12:34:53 --> Output Class Initialized
INFO - 2023-10-06 12:34:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:34:53 --> Input Class Initialized
INFO - 2023-10-06 12:34:53 --> Language Class Initialized
INFO - 2023-10-06 12:34:53 --> Language Class Initialized
INFO - 2023-10-06 12:34:53 --> Config Class Initialized
INFO - 2023-10-06 12:34:53 --> Loader Class Initialized
INFO - 2023-10-06 12:34:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:34:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:34:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:34:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:34:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:34:53 --> Controller Class Initialized
INFO - 2023-10-06 12:34:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:34:53 --> Total execution time: 0.0320
INFO - 2023-10-06 12:35:10 --> Config Class Initialized
INFO - 2023-10-06 12:35:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:10 --> URI Class Initialized
INFO - 2023-10-06 12:35:10 --> Router Class Initialized
INFO - 2023-10-06 12:35:10 --> Output Class Initialized
INFO - 2023-10-06 12:35:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:10 --> Input Class Initialized
INFO - 2023-10-06 12:35:10 --> Language Class Initialized
INFO - 2023-10-06 12:35:10 --> Language Class Initialized
INFO - 2023-10-06 12:35:10 --> Config Class Initialized
INFO - 2023-10-06 12:35:10 --> Loader Class Initialized
INFO - 2023-10-06 12:35:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:10 --> Controller Class Initialized
INFO - 2023-10-06 12:35:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:10 --> Total execution time: 0.0728
INFO - 2023-10-06 12:35:12 --> Config Class Initialized
INFO - 2023-10-06 12:35:12 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:12 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:12 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:12 --> URI Class Initialized
INFO - 2023-10-06 12:35:12 --> Router Class Initialized
INFO - 2023-10-06 12:35:12 --> Output Class Initialized
INFO - 2023-10-06 12:35:12 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:12 --> Input Class Initialized
INFO - 2023-10-06 12:35:12 --> Language Class Initialized
INFO - 2023-10-06 12:35:12 --> Language Class Initialized
INFO - 2023-10-06 12:35:12 --> Config Class Initialized
INFO - 2023-10-06 12:35:12 --> Loader Class Initialized
INFO - 2023-10-06 12:35:12 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:12 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:12 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:12 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:12 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:12 --> Controller Class Initialized
INFO - 2023-10-06 12:35:12 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:12 --> Total execution time: 0.0615
INFO - 2023-10-06 12:35:19 --> Config Class Initialized
INFO - 2023-10-06 12:35:19 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:19 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:19 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:19 --> URI Class Initialized
INFO - 2023-10-06 12:35:19 --> Router Class Initialized
INFO - 2023-10-06 12:35:19 --> Output Class Initialized
INFO - 2023-10-06 12:35:19 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:19 --> Input Class Initialized
INFO - 2023-10-06 12:35:19 --> Language Class Initialized
INFO - 2023-10-06 12:35:19 --> Language Class Initialized
INFO - 2023-10-06 12:35:19 --> Config Class Initialized
INFO - 2023-10-06 12:35:19 --> Loader Class Initialized
INFO - 2023-10-06 12:35:19 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:19 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:19 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:19 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:19 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:19 --> Controller Class Initialized
INFO - 2023-10-06 12:35:19 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:19 --> Total execution time: 0.0887
INFO - 2023-10-06 12:35:23 --> Config Class Initialized
INFO - 2023-10-06 12:35:23 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:23 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:23 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:23 --> URI Class Initialized
INFO - 2023-10-06 12:35:23 --> Router Class Initialized
INFO - 2023-10-06 12:35:23 --> Output Class Initialized
INFO - 2023-10-06 12:35:23 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:23 --> Input Class Initialized
INFO - 2023-10-06 12:35:23 --> Language Class Initialized
INFO - 2023-10-06 12:35:23 --> Language Class Initialized
INFO - 2023-10-06 12:35:23 --> Config Class Initialized
INFO - 2023-10-06 12:35:23 --> Loader Class Initialized
INFO - 2023-10-06 12:35:23 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:23 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:23 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:23 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:23 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:23 --> Controller Class Initialized
INFO - 2023-10-06 12:35:23 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:23 --> Total execution time: 0.0856
INFO - 2023-10-06 12:35:31 --> Config Class Initialized
INFO - 2023-10-06 12:35:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:31 --> URI Class Initialized
INFO - 2023-10-06 12:35:31 --> Router Class Initialized
INFO - 2023-10-06 12:35:31 --> Output Class Initialized
INFO - 2023-10-06 12:35:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:31 --> Input Class Initialized
INFO - 2023-10-06 12:35:31 --> Language Class Initialized
INFO - 2023-10-06 12:35:31 --> Language Class Initialized
INFO - 2023-10-06 12:35:31 --> Config Class Initialized
INFO - 2023-10-06 12:35:31 --> Loader Class Initialized
INFO - 2023-10-06 12:35:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:31 --> Controller Class Initialized
INFO - 2023-10-06 12:35:31 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:31 --> Total execution time: 0.0643
INFO - 2023-10-06 12:35:40 --> Config Class Initialized
INFO - 2023-10-06 12:35:40 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:40 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:40 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:40 --> URI Class Initialized
INFO - 2023-10-06 12:35:40 --> Router Class Initialized
INFO - 2023-10-06 12:35:40 --> Output Class Initialized
INFO - 2023-10-06 12:35:40 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:40 --> Input Class Initialized
INFO - 2023-10-06 12:35:40 --> Language Class Initialized
INFO - 2023-10-06 12:35:40 --> Language Class Initialized
INFO - 2023-10-06 12:35:40 --> Config Class Initialized
INFO - 2023-10-06 12:35:40 --> Loader Class Initialized
INFO - 2023-10-06 12:35:40 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:40 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:40 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:40 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:40 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:40 --> Controller Class Initialized
INFO - 2023-10-06 12:35:40 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:40 --> Total execution time: 0.0468
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:51 --> URI Class Initialized
INFO - 2023-10-06 12:35:51 --> Router Class Initialized
INFO - 2023-10-06 12:35:51 --> Output Class Initialized
INFO - 2023-10-06 12:35:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:51 --> Input Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Loader Class Initialized
INFO - 2023-10-06 12:35:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:51 --> Controller Class Initialized
INFO - 2023-10-06 12:35:51 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:51 --> URI Class Initialized
INFO - 2023-10-06 12:35:51 --> Router Class Initialized
INFO - 2023-10-06 12:35:51 --> Output Class Initialized
INFO - 2023-10-06 12:35:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:51 --> Input Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Loader Class Initialized
INFO - 2023-10-06 12:35:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:51 --> Controller Class Initialized
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:51 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:51 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:51 --> URI Class Initialized
INFO - 2023-10-06 12:35:51 --> Router Class Initialized
INFO - 2023-10-06 12:35:51 --> Output Class Initialized
INFO - 2023-10-06 12:35:51 --> Security Class Initialized
DEBUG - 2023-10-06 12:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:35:51 --> Input Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Language Class Initialized
INFO - 2023-10-06 12:35:51 --> Config Class Initialized
INFO - 2023-10-06 12:35:51 --> Loader Class Initialized
INFO - 2023-10-06 12:35:51 --> Helper loaded: url_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: file_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: form_helper
INFO - 2023-10-06 12:35:51 --> Helper loaded: my_helper
INFO - 2023-10-06 12:35:51 --> Database Driver Class Initialized
INFO - 2023-10-06 12:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:35:51 --> Controller Class Initialized
DEBUG - 2023-10-06 12:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:35:51 --> Final output sent to browser
DEBUG - 2023-10-06 12:35:51 --> Total execution time: 0.0500
INFO - 2023-10-06 12:35:59 --> Config Class Initialized
INFO - 2023-10-06 12:35:59 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:35:59 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:35:59 --> Utf8 Class Initialized
INFO - 2023-10-06 12:35:59 --> URI Class Initialized
INFO - 2023-10-06 12:35:59 --> Router Class Initialized
INFO - 2023-10-06 12:36:00 --> Output Class Initialized
INFO - 2023-10-06 12:36:00 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:00 --> Input Class Initialized
INFO - 2023-10-06 12:36:00 --> Language Class Initialized
INFO - 2023-10-06 12:36:00 --> Language Class Initialized
INFO - 2023-10-06 12:36:00 --> Config Class Initialized
INFO - 2023-10-06 12:36:00 --> Loader Class Initialized
INFO - 2023-10-06 12:36:00 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:00 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:00 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:00 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:00 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:00 --> Controller Class Initialized
INFO - 2023-10-06 12:36:00 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:00 --> Total execution time: 0.0664
INFO - 2023-10-06 12:36:08 --> Config Class Initialized
INFO - 2023-10-06 12:36:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:08 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:08 --> URI Class Initialized
INFO - 2023-10-06 12:36:08 --> Router Class Initialized
INFO - 2023-10-06 12:36:08 --> Output Class Initialized
INFO - 2023-10-06 12:36:08 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:08 --> Input Class Initialized
INFO - 2023-10-06 12:36:08 --> Language Class Initialized
INFO - 2023-10-06 12:36:08 --> Language Class Initialized
INFO - 2023-10-06 12:36:08 --> Config Class Initialized
INFO - 2023-10-06 12:36:08 --> Loader Class Initialized
INFO - 2023-10-06 12:36:08 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:08 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:08 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:08 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:08 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:08 --> Controller Class Initialized
DEBUG - 2023-10-06 12:36:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:36:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:36:08 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:08 --> Total execution time: 0.0353
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:09 --> URI Class Initialized
INFO - 2023-10-06 12:36:09 --> Router Class Initialized
INFO - 2023-10-06 12:36:09 --> Output Class Initialized
INFO - 2023-10-06 12:36:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:09 --> Input Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Loader Class Initialized
INFO - 2023-10-06 12:36:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:09 --> Controller Class Initialized
DEBUG - 2023-10-06 12:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:36:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:09 --> Total execution time: 0.0382
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:09 --> URI Class Initialized
INFO - 2023-10-06 12:36:09 --> Router Class Initialized
INFO - 2023-10-06 12:36:09 --> Output Class Initialized
INFO - 2023-10-06 12:36:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:09 --> Input Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Loader Class Initialized
INFO - 2023-10-06 12:36:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:09 --> Controller Class Initialized
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:09 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:09 --> URI Class Initialized
INFO - 2023-10-06 12:36:09 --> Router Class Initialized
INFO - 2023-10-06 12:36:09 --> Output Class Initialized
INFO - 2023-10-06 12:36:09 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:09 --> Input Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Language Class Initialized
INFO - 2023-10-06 12:36:09 --> Config Class Initialized
INFO - 2023-10-06 12:36:09 --> Loader Class Initialized
INFO - 2023-10-06 12:36:09 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:09 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:09 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:09 --> Controller Class Initialized
INFO - 2023-10-06 12:36:09 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:09 --> Total execution time: 0.0420
INFO - 2023-10-06 12:36:21 --> Config Class Initialized
INFO - 2023-10-06 12:36:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:21 --> URI Class Initialized
INFO - 2023-10-06 12:36:21 --> Router Class Initialized
INFO - 2023-10-06 12:36:21 --> Output Class Initialized
INFO - 2023-10-06 12:36:21 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:21 --> Input Class Initialized
INFO - 2023-10-06 12:36:21 --> Language Class Initialized
INFO - 2023-10-06 12:36:21 --> Language Class Initialized
INFO - 2023-10-06 12:36:21 --> Config Class Initialized
INFO - 2023-10-06 12:36:21 --> Loader Class Initialized
INFO - 2023-10-06 12:36:21 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:21 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:21 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:21 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:21 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:21 --> Controller Class Initialized
INFO - 2023-10-06 12:36:21 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:36:21 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:21 --> Total execution time: 0.0567
INFO - 2023-10-06 12:36:21 --> Config Class Initialized
INFO - 2023-10-06 12:36:21 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:21 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:21 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:21 --> URI Class Initialized
INFO - 2023-10-06 12:36:21 --> Router Class Initialized
INFO - 2023-10-06 12:36:22 --> Output Class Initialized
INFO - 2023-10-06 12:36:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:22 --> Input Class Initialized
INFO - 2023-10-06 12:36:22 --> Language Class Initialized
INFO - 2023-10-06 12:36:22 --> Language Class Initialized
INFO - 2023-10-06 12:36:22 --> Config Class Initialized
INFO - 2023-10-06 12:36:22 --> Loader Class Initialized
INFO - 2023-10-06 12:36:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:22 --> Controller Class Initialized
DEBUG - 2023-10-06 12:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:36:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:22 --> Total execution time: 0.0402
INFO - 2023-10-06 12:36:25 --> Config Class Initialized
INFO - 2023-10-06 12:36:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:25 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:25 --> URI Class Initialized
INFO - 2023-10-06 12:36:25 --> Router Class Initialized
INFO - 2023-10-06 12:36:25 --> Output Class Initialized
INFO - 2023-10-06 12:36:25 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:25 --> Input Class Initialized
INFO - 2023-10-06 12:36:25 --> Language Class Initialized
INFO - 2023-10-06 12:36:25 --> Language Class Initialized
INFO - 2023-10-06 12:36:25 --> Config Class Initialized
INFO - 2023-10-06 12:36:25 --> Loader Class Initialized
INFO - 2023-10-06 12:36:25 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:25 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:25 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:25 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:25 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:25 --> Controller Class Initialized
DEBUG - 2023-10-06 12:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:36:25 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:25 --> Total execution time: 0.0818
INFO - 2023-10-06 12:36:27 --> Config Class Initialized
INFO - 2023-10-06 12:36:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:27 --> URI Class Initialized
INFO - 2023-10-06 12:36:27 --> Router Class Initialized
INFO - 2023-10-06 12:36:27 --> Output Class Initialized
INFO - 2023-10-06 12:36:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:27 --> Input Class Initialized
INFO - 2023-10-06 12:36:27 --> Language Class Initialized
INFO - 2023-10-06 12:36:27 --> Language Class Initialized
INFO - 2023-10-06 12:36:27 --> Config Class Initialized
INFO - 2023-10-06 12:36:27 --> Loader Class Initialized
INFO - 2023-10-06 12:36:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:27 --> Controller Class Initialized
DEBUG - 2023-10-06 12:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:36:27 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:27 --> Total execution time: 0.0336
INFO - 2023-10-06 12:36:27 --> Config Class Initialized
INFO - 2023-10-06 12:36:27 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:27 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:27 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:27 --> URI Class Initialized
INFO - 2023-10-06 12:36:27 --> Router Class Initialized
INFO - 2023-10-06 12:36:27 --> Output Class Initialized
INFO - 2023-10-06 12:36:27 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:27 --> Input Class Initialized
INFO - 2023-10-06 12:36:27 --> Language Class Initialized
INFO - 2023-10-06 12:36:27 --> Language Class Initialized
INFO - 2023-10-06 12:36:27 --> Config Class Initialized
INFO - 2023-10-06 12:36:27 --> Loader Class Initialized
INFO - 2023-10-06 12:36:27 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:27 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:27 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:27 --> Controller Class Initialized
INFO - 2023-10-06 12:36:32 --> Config Class Initialized
INFO - 2023-10-06 12:36:32 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:32 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:32 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:32 --> URI Class Initialized
INFO - 2023-10-06 12:36:32 --> Router Class Initialized
INFO - 2023-10-06 12:36:32 --> Output Class Initialized
INFO - 2023-10-06 12:36:32 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:32 --> Input Class Initialized
INFO - 2023-10-06 12:36:32 --> Language Class Initialized
INFO - 2023-10-06 12:36:32 --> Language Class Initialized
INFO - 2023-10-06 12:36:32 --> Config Class Initialized
INFO - 2023-10-06 12:36:32 --> Loader Class Initialized
INFO - 2023-10-06 12:36:32 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:32 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:32 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:32 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:32 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:32 --> Controller Class Initialized
INFO - 2023-10-06 12:36:32 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:32 --> Total execution time: 0.0348
INFO - 2023-10-06 12:36:53 --> Config Class Initialized
INFO - 2023-10-06 12:36:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:36:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:36:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:36:53 --> URI Class Initialized
INFO - 2023-10-06 12:36:53 --> Router Class Initialized
INFO - 2023-10-06 12:36:53 --> Output Class Initialized
INFO - 2023-10-06 12:36:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:36:53 --> Input Class Initialized
INFO - 2023-10-06 12:36:53 --> Language Class Initialized
INFO - 2023-10-06 12:36:53 --> Language Class Initialized
INFO - 2023-10-06 12:36:53 --> Config Class Initialized
INFO - 2023-10-06 12:36:53 --> Loader Class Initialized
INFO - 2023-10-06 12:36:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:36:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:36:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:36:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:36:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:36:53 --> Controller Class Initialized
INFO - 2023-10-06 12:36:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:36:53 --> Total execution time: 0.0360
INFO - 2023-10-06 12:37:11 --> Config Class Initialized
INFO - 2023-10-06 12:37:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:11 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:11 --> URI Class Initialized
INFO - 2023-10-06 12:37:11 --> Router Class Initialized
INFO - 2023-10-06 12:37:11 --> Output Class Initialized
INFO - 2023-10-06 12:37:11 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:11 --> Input Class Initialized
INFO - 2023-10-06 12:37:11 --> Language Class Initialized
INFO - 2023-10-06 12:37:11 --> Language Class Initialized
INFO - 2023-10-06 12:37:11 --> Config Class Initialized
INFO - 2023-10-06 12:37:11 --> Loader Class Initialized
INFO - 2023-10-06 12:37:11 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:11 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:11 --> Controller Class Initialized
INFO - 2023-10-06 12:37:11 --> Config Class Initialized
INFO - 2023-10-06 12:37:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:11 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:11 --> URI Class Initialized
INFO - 2023-10-06 12:37:11 --> Router Class Initialized
INFO - 2023-10-06 12:37:11 --> Output Class Initialized
INFO - 2023-10-06 12:37:11 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:11 --> Input Class Initialized
INFO - 2023-10-06 12:37:11 --> Language Class Initialized
INFO - 2023-10-06 12:37:11 --> Language Class Initialized
INFO - 2023-10-06 12:37:11 --> Config Class Initialized
INFO - 2023-10-06 12:37:11 --> Loader Class Initialized
INFO - 2023-10-06 12:37:11 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:11 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:11 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:11 --> Controller Class Initialized
DEBUG - 2023-10-06 12:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-06 12:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:37:11 --> Final output sent to browser
DEBUG - 2023-10-06 12:37:11 --> Total execution time: 0.0299
INFO - 2023-10-06 12:37:14 --> Config Class Initialized
INFO - 2023-10-06 12:37:14 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:14 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:14 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:14 --> URI Class Initialized
INFO - 2023-10-06 12:37:14 --> Router Class Initialized
INFO - 2023-10-06 12:37:14 --> Output Class Initialized
INFO - 2023-10-06 12:37:14 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:14 --> Input Class Initialized
INFO - 2023-10-06 12:37:14 --> Language Class Initialized
INFO - 2023-10-06 12:37:14 --> Language Class Initialized
INFO - 2023-10-06 12:37:14 --> Config Class Initialized
INFO - 2023-10-06 12:37:14 --> Loader Class Initialized
INFO - 2023-10-06 12:37:14 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:14 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:14 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:14 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:14 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:14 --> Controller Class Initialized
INFO - 2023-10-06 12:37:14 --> Helper loaded: cookie_helper
INFO - 2023-10-06 12:37:14 --> Final output sent to browser
DEBUG - 2023-10-06 12:37:14 --> Total execution time: 0.0535
INFO - 2023-10-06 12:37:15 --> Config Class Initialized
INFO - 2023-10-06 12:37:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:15 --> URI Class Initialized
INFO - 2023-10-06 12:37:15 --> Router Class Initialized
INFO - 2023-10-06 12:37:15 --> Output Class Initialized
INFO - 2023-10-06 12:37:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:15 --> Input Class Initialized
INFO - 2023-10-06 12:37:15 --> Language Class Initialized
INFO - 2023-10-06 12:37:15 --> Language Class Initialized
INFO - 2023-10-06 12:37:15 --> Config Class Initialized
INFO - 2023-10-06 12:37:15 --> Loader Class Initialized
INFO - 2023-10-06 12:37:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 12:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:37:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:37:15 --> Total execution time: 0.0316
INFO - 2023-10-06 12:37:28 --> Config Class Initialized
INFO - 2023-10-06 12:37:28 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:28 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:28 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:28 --> URI Class Initialized
INFO - 2023-10-06 12:37:28 --> Router Class Initialized
INFO - 2023-10-06 12:37:28 --> Output Class Initialized
INFO - 2023-10-06 12:37:28 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:28 --> Input Class Initialized
INFO - 2023-10-06 12:37:28 --> Language Class Initialized
INFO - 2023-10-06 12:37:28 --> Language Class Initialized
INFO - 2023-10-06 12:37:28 --> Config Class Initialized
INFO - 2023-10-06 12:37:28 --> Loader Class Initialized
INFO - 2023-10-06 12:37:28 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:28 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:28 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:28 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:28 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:28 --> Controller Class Initialized
DEBUG - 2023-10-06 12:37:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:37:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:37:28 --> Final output sent to browser
DEBUG - 2023-10-06 12:37:28 --> Total execution time: 0.0367
INFO - 2023-10-06 12:37:30 --> Config Class Initialized
INFO - 2023-10-06 12:37:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:37:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:37:30 --> Utf8 Class Initialized
INFO - 2023-10-06 12:37:30 --> URI Class Initialized
INFO - 2023-10-06 12:37:30 --> Router Class Initialized
INFO - 2023-10-06 12:37:30 --> Output Class Initialized
INFO - 2023-10-06 12:37:30 --> Security Class Initialized
DEBUG - 2023-10-06 12:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:37:30 --> Input Class Initialized
INFO - 2023-10-06 12:37:30 --> Language Class Initialized
INFO - 2023-10-06 12:37:30 --> Language Class Initialized
INFO - 2023-10-06 12:37:30 --> Config Class Initialized
INFO - 2023-10-06 12:37:30 --> Loader Class Initialized
INFO - 2023-10-06 12:37:30 --> Helper loaded: url_helper
INFO - 2023-10-06 12:37:30 --> Helper loaded: file_helper
INFO - 2023-10-06 12:37:30 --> Helper loaded: form_helper
INFO - 2023-10-06 12:37:30 --> Helper loaded: my_helper
INFO - 2023-10-06 12:37:30 --> Database Driver Class Initialized
INFO - 2023-10-06 12:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:37:30 --> Controller Class Initialized
DEBUG - 2023-10-06 12:37:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:37:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:37:30 --> Final output sent to browser
DEBUG - 2023-10-06 12:37:30 --> Total execution time: 0.0408
INFO - 2023-10-06 12:38:31 --> Config Class Initialized
INFO - 2023-10-06 12:38:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:38:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:38:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:38:31 --> URI Class Initialized
INFO - 2023-10-06 12:38:31 --> Router Class Initialized
INFO - 2023-10-06 12:38:31 --> Output Class Initialized
INFO - 2023-10-06 12:38:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:38:31 --> Input Class Initialized
INFO - 2023-10-06 12:38:31 --> Language Class Initialized
INFO - 2023-10-06 12:38:31 --> Language Class Initialized
INFO - 2023-10-06 12:38:31 --> Config Class Initialized
INFO - 2023-10-06 12:38:31 --> Loader Class Initialized
INFO - 2023-10-06 12:38:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:38:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:38:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:38:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:38:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:38:31 --> Controller Class Initialized
DEBUG - 2023-10-06 12:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:38:31 --> Final output sent to browser
DEBUG - 2023-10-06 12:38:31 --> Total execution time: 0.0460
INFO - 2023-10-06 12:38:34 --> Config Class Initialized
INFO - 2023-10-06 12:38:34 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:38:34 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:38:34 --> Utf8 Class Initialized
INFO - 2023-10-06 12:38:34 --> URI Class Initialized
INFO - 2023-10-06 12:38:34 --> Router Class Initialized
INFO - 2023-10-06 12:38:34 --> Output Class Initialized
INFO - 2023-10-06 12:38:34 --> Security Class Initialized
DEBUG - 2023-10-06 12:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:38:34 --> Input Class Initialized
INFO - 2023-10-06 12:38:34 --> Language Class Initialized
INFO - 2023-10-06 12:38:34 --> Language Class Initialized
INFO - 2023-10-06 12:38:34 --> Config Class Initialized
INFO - 2023-10-06 12:38:34 --> Loader Class Initialized
INFO - 2023-10-06 12:38:34 --> Helper loaded: url_helper
INFO - 2023-10-06 12:38:34 --> Helper loaded: file_helper
INFO - 2023-10-06 12:38:34 --> Helper loaded: form_helper
INFO - 2023-10-06 12:38:34 --> Helper loaded: my_helper
INFO - 2023-10-06 12:38:34 --> Database Driver Class Initialized
INFO - 2023-10-06 12:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:38:34 --> Controller Class Initialized
INFO - 2023-10-06 12:38:34 --> Final output sent to browser
DEBUG - 2023-10-06 12:38:34 --> Total execution time: 0.0479
INFO - 2023-10-06 12:39:36 --> Config Class Initialized
INFO - 2023-10-06 12:39:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:39:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:39:36 --> Utf8 Class Initialized
INFO - 2023-10-06 12:39:36 --> URI Class Initialized
INFO - 2023-10-06 12:39:36 --> Router Class Initialized
INFO - 2023-10-06 12:39:36 --> Output Class Initialized
INFO - 2023-10-06 12:39:36 --> Security Class Initialized
DEBUG - 2023-10-06 12:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:39:36 --> Input Class Initialized
INFO - 2023-10-06 12:39:36 --> Language Class Initialized
INFO - 2023-10-06 12:39:36 --> Language Class Initialized
INFO - 2023-10-06 12:39:36 --> Config Class Initialized
INFO - 2023-10-06 12:39:36 --> Loader Class Initialized
INFO - 2023-10-06 12:39:36 --> Helper loaded: url_helper
INFO - 2023-10-06 12:39:36 --> Helper loaded: file_helper
INFO - 2023-10-06 12:39:36 --> Helper loaded: form_helper
INFO - 2023-10-06 12:39:36 --> Helper loaded: my_helper
INFO - 2023-10-06 12:39:36 --> Database Driver Class Initialized
INFO - 2023-10-06 12:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:39:36 --> Controller Class Initialized
DEBUG - 2023-10-06 12:39:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:39:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:39:36 --> Final output sent to browser
DEBUG - 2023-10-06 12:39:36 --> Total execution time: 0.0345
INFO - 2023-10-06 12:39:38 --> Config Class Initialized
INFO - 2023-10-06 12:39:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:39:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:39:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:39:38 --> URI Class Initialized
INFO - 2023-10-06 12:39:38 --> Router Class Initialized
INFO - 2023-10-06 12:39:38 --> Output Class Initialized
INFO - 2023-10-06 12:39:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:39:38 --> Input Class Initialized
INFO - 2023-10-06 12:39:38 --> Language Class Initialized
INFO - 2023-10-06 12:39:38 --> Language Class Initialized
INFO - 2023-10-06 12:39:38 --> Config Class Initialized
INFO - 2023-10-06 12:39:38 --> Loader Class Initialized
INFO - 2023-10-06 12:39:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:39:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:39:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:39:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:39:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:39:39 --> Controller Class Initialized
DEBUG - 2023-10-06 12:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:39:39 --> Final output sent to browser
DEBUG - 2023-10-06 12:39:39 --> Total execution time: 0.0411
INFO - 2023-10-06 12:39:39 --> Config Class Initialized
INFO - 2023-10-06 12:39:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:39:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:39:39 --> Utf8 Class Initialized
INFO - 2023-10-06 12:39:39 --> URI Class Initialized
INFO - 2023-10-06 12:39:39 --> Router Class Initialized
INFO - 2023-10-06 12:39:39 --> Output Class Initialized
INFO - 2023-10-06 12:39:39 --> Security Class Initialized
DEBUG - 2023-10-06 12:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:39:39 --> Input Class Initialized
INFO - 2023-10-06 12:39:39 --> Language Class Initialized
INFO - 2023-10-06 12:39:39 --> Language Class Initialized
INFO - 2023-10-06 12:39:39 --> Config Class Initialized
INFO - 2023-10-06 12:39:39 --> Loader Class Initialized
INFO - 2023-10-06 12:39:39 --> Helper loaded: url_helper
INFO - 2023-10-06 12:39:39 --> Helper loaded: file_helper
INFO - 2023-10-06 12:39:39 --> Helper loaded: form_helper
INFO - 2023-10-06 12:39:39 --> Helper loaded: my_helper
INFO - 2023-10-06 12:39:39 --> Database Driver Class Initialized
INFO - 2023-10-06 12:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:39:39 --> Controller Class Initialized
INFO - 2023-10-06 12:39:44 --> Config Class Initialized
INFO - 2023-10-06 12:39:44 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:39:44 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:39:44 --> Utf8 Class Initialized
INFO - 2023-10-06 12:39:44 --> URI Class Initialized
INFO - 2023-10-06 12:39:44 --> Router Class Initialized
INFO - 2023-10-06 12:39:44 --> Output Class Initialized
INFO - 2023-10-06 12:39:44 --> Security Class Initialized
DEBUG - 2023-10-06 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:39:44 --> Input Class Initialized
INFO - 2023-10-06 12:39:44 --> Language Class Initialized
INFO - 2023-10-06 12:39:44 --> Language Class Initialized
INFO - 2023-10-06 12:39:44 --> Config Class Initialized
INFO - 2023-10-06 12:39:44 --> Loader Class Initialized
INFO - 2023-10-06 12:39:44 --> Helper loaded: url_helper
INFO - 2023-10-06 12:39:44 --> Helper loaded: file_helper
INFO - 2023-10-06 12:39:44 --> Helper loaded: form_helper
INFO - 2023-10-06 12:39:44 --> Helper loaded: my_helper
INFO - 2023-10-06 12:39:44 --> Database Driver Class Initialized
INFO - 2023-10-06 12:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:39:44 --> Controller Class Initialized
INFO - 2023-10-06 12:39:44 --> Final output sent to browser
DEBUG - 2023-10-06 12:39:44 --> Total execution time: 0.0734
INFO - 2023-10-06 12:45:31 --> Config Class Initialized
INFO - 2023-10-06 12:45:31 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:31 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:31 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:31 --> URI Class Initialized
INFO - 2023-10-06 12:45:31 --> Router Class Initialized
INFO - 2023-10-06 12:45:31 --> Output Class Initialized
INFO - 2023-10-06 12:45:31 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:31 --> Input Class Initialized
INFO - 2023-10-06 12:45:31 --> Language Class Initialized
INFO - 2023-10-06 12:45:31 --> Language Class Initialized
INFO - 2023-10-06 12:45:31 --> Config Class Initialized
INFO - 2023-10-06 12:45:31 --> Loader Class Initialized
INFO - 2023-10-06 12:45:31 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:31 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:31 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:31 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:31 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:31 --> Controller Class Initialized
INFO - 2023-10-06 12:45:35 --> Config Class Initialized
INFO - 2023-10-06 12:45:35 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:35 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:35 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:35 --> URI Class Initialized
INFO - 2023-10-06 12:45:35 --> Router Class Initialized
INFO - 2023-10-06 12:45:35 --> Output Class Initialized
INFO - 2023-10-06 12:45:35 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:35 --> Input Class Initialized
INFO - 2023-10-06 12:45:35 --> Language Class Initialized
INFO - 2023-10-06 12:45:35 --> Language Class Initialized
INFO - 2023-10-06 12:45:35 --> Config Class Initialized
INFO - 2023-10-06 12:45:35 --> Loader Class Initialized
INFO - 2023-10-06 12:45:35 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:35 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:35 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:35 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:35 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:35 --> Controller Class Initialized
DEBUG - 2023-10-06 12:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:45:35 --> Final output sent to browser
DEBUG - 2023-10-06 12:45:35 --> Total execution time: 0.0426
INFO - 2023-10-06 12:45:38 --> Config Class Initialized
INFO - 2023-10-06 12:45:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:38 --> URI Class Initialized
INFO - 2023-10-06 12:45:38 --> Router Class Initialized
INFO - 2023-10-06 12:45:38 --> Output Class Initialized
INFO - 2023-10-06 12:45:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:38 --> Input Class Initialized
INFO - 2023-10-06 12:45:38 --> Language Class Initialized
INFO - 2023-10-06 12:45:38 --> Language Class Initialized
INFO - 2023-10-06 12:45:38 --> Config Class Initialized
INFO - 2023-10-06 12:45:38 --> Loader Class Initialized
INFO - 2023-10-06 12:45:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:38 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:38 --> Controller Class Initialized
DEBUG - 2023-10-06 12:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 12:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:45:38 --> Final output sent to browser
DEBUG - 2023-10-06 12:45:38 --> Total execution time: 0.0366
INFO - 2023-10-06 12:45:38 --> Config Class Initialized
INFO - 2023-10-06 12:45:38 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:38 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:38 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:38 --> URI Class Initialized
INFO - 2023-10-06 12:45:38 --> Router Class Initialized
INFO - 2023-10-06 12:45:38 --> Output Class Initialized
INFO - 2023-10-06 12:45:38 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:38 --> Input Class Initialized
INFO - 2023-10-06 12:45:38 --> Language Class Initialized
INFO - 2023-10-06 12:45:38 --> Language Class Initialized
INFO - 2023-10-06 12:45:38 --> Config Class Initialized
INFO - 2023-10-06 12:45:38 --> Loader Class Initialized
INFO - 2023-10-06 12:45:38 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:38 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:38 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:38 --> Controller Class Initialized
INFO - 2023-10-06 12:45:40 --> Config Class Initialized
INFO - 2023-10-06 12:45:40 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:40 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:40 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:40 --> URI Class Initialized
INFO - 2023-10-06 12:45:40 --> Router Class Initialized
INFO - 2023-10-06 12:45:40 --> Output Class Initialized
INFO - 2023-10-06 12:45:40 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:40 --> Input Class Initialized
INFO - 2023-10-06 12:45:40 --> Language Class Initialized
INFO - 2023-10-06 12:45:40 --> Language Class Initialized
INFO - 2023-10-06 12:45:40 --> Config Class Initialized
INFO - 2023-10-06 12:45:40 --> Loader Class Initialized
INFO - 2023-10-06 12:45:40 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:40 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:40 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:40 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:40 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:40 --> Controller Class Initialized
INFO - 2023-10-06 12:45:44 --> Config Class Initialized
INFO - 2023-10-06 12:45:44 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:45:44 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:45:44 --> Utf8 Class Initialized
INFO - 2023-10-06 12:45:44 --> URI Class Initialized
INFO - 2023-10-06 12:45:44 --> Router Class Initialized
INFO - 2023-10-06 12:45:44 --> Output Class Initialized
INFO - 2023-10-06 12:45:44 --> Security Class Initialized
DEBUG - 2023-10-06 12:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:45:44 --> Input Class Initialized
INFO - 2023-10-06 12:45:44 --> Language Class Initialized
INFO - 2023-10-06 12:45:44 --> Language Class Initialized
INFO - 2023-10-06 12:45:44 --> Config Class Initialized
INFO - 2023-10-06 12:45:44 --> Loader Class Initialized
INFO - 2023-10-06 12:45:44 --> Helper loaded: url_helper
INFO - 2023-10-06 12:45:44 --> Helper loaded: file_helper
INFO - 2023-10-06 12:45:44 --> Helper loaded: form_helper
INFO - 2023-10-06 12:45:44 --> Helper loaded: my_helper
INFO - 2023-10-06 12:45:44 --> Database Driver Class Initialized
INFO - 2023-10-06 12:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:45:44 --> Controller Class Initialized
DEBUG - 2023-10-06 12:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:45:44 --> Final output sent to browser
DEBUG - 2023-10-06 12:45:44 --> Total execution time: 0.0335
INFO - 2023-10-06 12:47:48 --> Config Class Initialized
INFO - 2023-10-06 12:47:48 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:47:48 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:47:48 --> Utf8 Class Initialized
INFO - 2023-10-06 12:47:48 --> URI Class Initialized
INFO - 2023-10-06 12:47:48 --> Router Class Initialized
INFO - 2023-10-06 12:47:48 --> Output Class Initialized
INFO - 2023-10-06 12:47:48 --> Security Class Initialized
DEBUG - 2023-10-06 12:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:47:48 --> Input Class Initialized
INFO - 2023-10-06 12:47:48 --> Language Class Initialized
INFO - 2023-10-06 12:47:48 --> Language Class Initialized
INFO - 2023-10-06 12:47:48 --> Config Class Initialized
INFO - 2023-10-06 12:47:48 --> Loader Class Initialized
INFO - 2023-10-06 12:47:48 --> Helper loaded: url_helper
INFO - 2023-10-06 12:47:48 --> Helper loaded: file_helper
INFO - 2023-10-06 12:47:48 --> Helper loaded: form_helper
INFO - 2023-10-06 12:47:48 --> Helper loaded: my_helper
INFO - 2023-10-06 12:47:48 --> Database Driver Class Initialized
INFO - 2023-10-06 12:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:47:48 --> Controller Class Initialized
DEBUG - 2023-10-06 12:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:47:48 --> Final output sent to browser
DEBUG - 2023-10-06 12:47:48 --> Total execution time: 0.0403
INFO - 2023-10-06 12:47:52 --> Config Class Initialized
INFO - 2023-10-06 12:47:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:47:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:47:52 --> Utf8 Class Initialized
INFO - 2023-10-06 12:47:52 --> URI Class Initialized
INFO - 2023-10-06 12:47:52 --> Router Class Initialized
INFO - 2023-10-06 12:47:52 --> Output Class Initialized
INFO - 2023-10-06 12:47:52 --> Security Class Initialized
DEBUG - 2023-10-06 12:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:47:52 --> Input Class Initialized
INFO - 2023-10-06 12:47:52 --> Language Class Initialized
INFO - 2023-10-06 12:47:52 --> Language Class Initialized
INFO - 2023-10-06 12:47:52 --> Config Class Initialized
INFO - 2023-10-06 12:47:52 --> Loader Class Initialized
INFO - 2023-10-06 12:47:52 --> Helper loaded: url_helper
INFO - 2023-10-06 12:47:52 --> Helper loaded: file_helper
INFO - 2023-10-06 12:47:52 --> Helper loaded: form_helper
INFO - 2023-10-06 12:47:52 --> Helper loaded: my_helper
INFO - 2023-10-06 12:47:52 --> Database Driver Class Initialized
INFO - 2023-10-06 12:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:47:52 --> Controller Class Initialized
INFO - 2023-10-06 12:47:52 --> Final output sent to browser
DEBUG - 2023-10-06 12:47:52 --> Total execution time: 0.0682
INFO - 2023-10-06 12:50:07 --> Config Class Initialized
INFO - 2023-10-06 12:50:07 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:07 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:07 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:07 --> URI Class Initialized
INFO - 2023-10-06 12:50:07 --> Router Class Initialized
INFO - 2023-10-06 12:50:07 --> Output Class Initialized
INFO - 2023-10-06 12:50:07 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:07 --> Input Class Initialized
INFO - 2023-10-06 12:50:07 --> Language Class Initialized
INFO - 2023-10-06 12:50:07 --> Language Class Initialized
INFO - 2023-10-06 12:50:07 --> Config Class Initialized
INFO - 2023-10-06 12:50:07 --> Loader Class Initialized
INFO - 2023-10-06 12:50:07 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:07 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:07 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:07 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:07 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:07 --> Controller Class Initialized
INFO - 2023-10-06 12:50:07 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:07 --> Total execution time: 0.1167
INFO - 2023-10-06 12:50:10 --> Config Class Initialized
INFO - 2023-10-06 12:50:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:10 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:10 --> URI Class Initialized
INFO - 2023-10-06 12:50:10 --> Router Class Initialized
INFO - 2023-10-06 12:50:10 --> Output Class Initialized
INFO - 2023-10-06 12:50:10 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:10 --> Input Class Initialized
INFO - 2023-10-06 12:50:10 --> Language Class Initialized
INFO - 2023-10-06 12:50:10 --> Language Class Initialized
INFO - 2023-10-06 12:50:10 --> Config Class Initialized
INFO - 2023-10-06 12:50:10 --> Loader Class Initialized
INFO - 2023-10-06 12:50:10 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:10 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:10 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:10 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:10 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:10 --> Controller Class Initialized
DEBUG - 2023-10-06 12:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:50:10 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:10 --> Total execution time: 0.0397
INFO - 2023-10-06 12:50:13 --> Config Class Initialized
INFO - 2023-10-06 12:50:13 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:13 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:13 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:13 --> URI Class Initialized
INFO - 2023-10-06 12:50:13 --> Router Class Initialized
INFO - 2023-10-06 12:50:13 --> Output Class Initialized
INFO - 2023-10-06 12:50:13 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:13 --> Input Class Initialized
INFO - 2023-10-06 12:50:13 --> Language Class Initialized
INFO - 2023-10-06 12:50:13 --> Language Class Initialized
INFO - 2023-10-06 12:50:13 --> Config Class Initialized
INFO - 2023-10-06 12:50:13 --> Loader Class Initialized
INFO - 2023-10-06 12:50:13 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:13 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:13 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:13 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:13 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:13 --> Controller Class Initialized
DEBUG - 2023-10-06 12:50:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:50:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:50:13 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:13 --> Total execution time: 0.0405
INFO - 2023-10-06 12:50:15 --> Config Class Initialized
INFO - 2023-10-06 12:50:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:15 --> URI Class Initialized
INFO - 2023-10-06 12:50:15 --> Router Class Initialized
INFO - 2023-10-06 12:50:15 --> Output Class Initialized
INFO - 2023-10-06 12:50:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:15 --> Input Class Initialized
INFO - 2023-10-06 12:50:15 --> Language Class Initialized
INFO - 2023-10-06 12:50:15 --> Language Class Initialized
INFO - 2023-10-06 12:50:15 --> Config Class Initialized
INFO - 2023-10-06 12:50:15 --> Loader Class Initialized
INFO - 2023-10-06 12:50:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:15 --> Controller Class Initialized
INFO - 2023-10-06 12:50:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:15 --> Total execution time: 0.0684
INFO - 2023-10-06 12:50:22 --> Config Class Initialized
INFO - 2023-10-06 12:50:22 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:22 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:22 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:22 --> URI Class Initialized
INFO - 2023-10-06 12:50:22 --> Router Class Initialized
INFO - 2023-10-06 12:50:22 --> Output Class Initialized
INFO - 2023-10-06 12:50:22 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:22 --> Input Class Initialized
INFO - 2023-10-06 12:50:22 --> Language Class Initialized
INFO - 2023-10-06 12:50:22 --> Language Class Initialized
INFO - 2023-10-06 12:50:22 --> Config Class Initialized
INFO - 2023-10-06 12:50:22 --> Loader Class Initialized
INFO - 2023-10-06 12:50:22 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:22 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:22 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:22 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:22 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:22 --> Controller Class Initialized
DEBUG - 2023-10-06 12:50:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:50:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:50:22 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:22 --> Total execution time: 0.0514
INFO - 2023-10-06 12:50:24 --> Config Class Initialized
INFO - 2023-10-06 12:50:24 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:24 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:24 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:24 --> URI Class Initialized
INFO - 2023-10-06 12:50:24 --> Router Class Initialized
INFO - 2023-10-06 12:50:24 --> Output Class Initialized
INFO - 2023-10-06 12:50:24 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:24 --> Input Class Initialized
INFO - 2023-10-06 12:50:24 --> Language Class Initialized
INFO - 2023-10-06 12:50:24 --> Language Class Initialized
INFO - 2023-10-06 12:50:24 --> Config Class Initialized
INFO - 2023-10-06 12:50:24 --> Loader Class Initialized
INFO - 2023-10-06 12:50:24 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:24 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:24 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:24 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:24 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:24 --> Controller Class Initialized
DEBUG - 2023-10-06 12:50:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:50:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:50:24 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:24 --> Total execution time: 0.0716
INFO - 2023-10-06 12:50:42 --> Config Class Initialized
INFO - 2023-10-06 12:50:42 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:50:42 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:50:42 --> Utf8 Class Initialized
INFO - 2023-10-06 12:50:42 --> URI Class Initialized
INFO - 2023-10-06 12:50:42 --> Router Class Initialized
INFO - 2023-10-06 12:50:42 --> Output Class Initialized
INFO - 2023-10-06 12:50:42 --> Security Class Initialized
DEBUG - 2023-10-06 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:50:42 --> Input Class Initialized
INFO - 2023-10-06 12:50:42 --> Language Class Initialized
INFO - 2023-10-06 12:50:42 --> Language Class Initialized
INFO - 2023-10-06 12:50:42 --> Config Class Initialized
INFO - 2023-10-06 12:50:42 --> Loader Class Initialized
INFO - 2023-10-06 12:50:42 --> Helper loaded: url_helper
INFO - 2023-10-06 12:50:42 --> Helper loaded: file_helper
INFO - 2023-10-06 12:50:42 --> Helper loaded: form_helper
INFO - 2023-10-06 12:50:42 --> Helper loaded: my_helper
INFO - 2023-10-06 12:50:42 --> Database Driver Class Initialized
INFO - 2023-10-06 12:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:50:42 --> Controller Class Initialized
INFO - 2023-10-06 12:50:42 --> Final output sent to browser
DEBUG - 2023-10-06 12:50:42 --> Total execution time: 0.0411
INFO - 2023-10-06 12:57:59 --> Config Class Initialized
INFO - 2023-10-06 12:57:59 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:57:59 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:57:59 --> Utf8 Class Initialized
INFO - 2023-10-06 12:57:59 --> URI Class Initialized
INFO - 2023-10-06 12:57:59 --> Router Class Initialized
INFO - 2023-10-06 12:57:59 --> Output Class Initialized
INFO - 2023-10-06 12:57:59 --> Security Class Initialized
DEBUG - 2023-10-06 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:57:59 --> Input Class Initialized
INFO - 2023-10-06 12:57:59 --> Language Class Initialized
INFO - 2023-10-06 12:57:59 --> Language Class Initialized
INFO - 2023-10-06 12:57:59 --> Config Class Initialized
INFO - 2023-10-06 12:57:59 --> Loader Class Initialized
INFO - 2023-10-06 12:57:59 --> Helper loaded: url_helper
INFO - 2023-10-06 12:57:59 --> Helper loaded: file_helper
INFO - 2023-10-06 12:57:59 --> Helper loaded: form_helper
INFO - 2023-10-06 12:57:59 --> Helper loaded: my_helper
INFO - 2023-10-06 12:57:59 --> Database Driver Class Initialized
INFO - 2023-10-06 12:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:57:59 --> Controller Class Initialized
INFO - 2023-10-06 12:57:59 --> Final output sent to browser
DEBUG - 2023-10-06 12:57:59 --> Total execution time: 0.0895
INFO - 2023-10-06 12:58:53 --> Config Class Initialized
INFO - 2023-10-06 12:58:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:58:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:58:53 --> Utf8 Class Initialized
INFO - 2023-10-06 12:58:53 --> URI Class Initialized
INFO - 2023-10-06 12:58:53 --> Router Class Initialized
INFO - 2023-10-06 12:58:53 --> Output Class Initialized
INFO - 2023-10-06 12:58:53 --> Security Class Initialized
DEBUG - 2023-10-06 12:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:58:53 --> Input Class Initialized
INFO - 2023-10-06 12:58:53 --> Language Class Initialized
INFO - 2023-10-06 12:58:53 --> Language Class Initialized
INFO - 2023-10-06 12:58:53 --> Config Class Initialized
INFO - 2023-10-06 12:58:53 --> Loader Class Initialized
INFO - 2023-10-06 12:58:53 --> Helper loaded: url_helper
INFO - 2023-10-06 12:58:53 --> Helper loaded: file_helper
INFO - 2023-10-06 12:58:53 --> Helper loaded: form_helper
INFO - 2023-10-06 12:58:53 --> Helper loaded: my_helper
INFO - 2023-10-06 12:58:53 --> Database Driver Class Initialized
INFO - 2023-10-06 12:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:58:53 --> Controller Class Initialized
DEBUG - 2023-10-06 12:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:58:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:58:53 --> Final output sent to browser
DEBUG - 2023-10-06 12:58:53 --> Total execution time: 0.0363
INFO - 2023-10-06 12:58:55 --> Config Class Initialized
INFO - 2023-10-06 12:58:55 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:58:55 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:58:55 --> Utf8 Class Initialized
INFO - 2023-10-06 12:58:55 --> URI Class Initialized
INFO - 2023-10-06 12:58:55 --> Router Class Initialized
INFO - 2023-10-06 12:58:55 --> Output Class Initialized
INFO - 2023-10-06 12:58:55 --> Security Class Initialized
DEBUG - 2023-10-06 12:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:58:55 --> Input Class Initialized
INFO - 2023-10-06 12:58:55 --> Language Class Initialized
INFO - 2023-10-06 12:58:55 --> Language Class Initialized
INFO - 2023-10-06 12:58:55 --> Config Class Initialized
INFO - 2023-10-06 12:58:55 --> Loader Class Initialized
INFO - 2023-10-06 12:58:55 --> Helper loaded: url_helper
INFO - 2023-10-06 12:58:55 --> Helper loaded: file_helper
INFO - 2023-10-06 12:58:55 --> Helper loaded: form_helper
INFO - 2023-10-06 12:58:55 --> Helper loaded: my_helper
INFO - 2023-10-06 12:58:55 --> Database Driver Class Initialized
INFO - 2023-10-06 12:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:58:55 --> Controller Class Initialized
DEBUG - 2023-10-06 12:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:58:55 --> Final output sent to browser
DEBUG - 2023-10-06 12:58:55 --> Total execution time: 0.0358
INFO - 2023-10-06 12:58:58 --> Config Class Initialized
INFO - 2023-10-06 12:58:58 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:58:58 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:58:58 --> Utf8 Class Initialized
INFO - 2023-10-06 12:58:58 --> URI Class Initialized
INFO - 2023-10-06 12:58:58 --> Router Class Initialized
INFO - 2023-10-06 12:58:58 --> Output Class Initialized
INFO - 2023-10-06 12:58:58 --> Security Class Initialized
DEBUG - 2023-10-06 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:58:58 --> Input Class Initialized
INFO - 2023-10-06 12:58:58 --> Language Class Initialized
INFO - 2023-10-06 12:58:58 --> Language Class Initialized
INFO - 2023-10-06 12:58:58 --> Config Class Initialized
INFO - 2023-10-06 12:58:58 --> Loader Class Initialized
INFO - 2023-10-06 12:58:58 --> Helper loaded: url_helper
INFO - 2023-10-06 12:58:58 --> Helper loaded: file_helper
INFO - 2023-10-06 12:58:58 --> Helper loaded: form_helper
INFO - 2023-10-06 12:58:58 --> Helper loaded: my_helper
INFO - 2023-10-06 12:58:58 --> Database Driver Class Initialized
INFO - 2023-10-06 12:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:58:58 --> Controller Class Initialized
INFO - 2023-10-06 12:58:58 --> Final output sent to browser
DEBUG - 2023-10-06 12:58:58 --> Total execution time: 0.1242
INFO - 2023-10-06 12:59:15 --> Config Class Initialized
INFO - 2023-10-06 12:59:15 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:59:15 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:59:15 --> Utf8 Class Initialized
INFO - 2023-10-06 12:59:15 --> URI Class Initialized
INFO - 2023-10-06 12:59:15 --> Router Class Initialized
INFO - 2023-10-06 12:59:15 --> Output Class Initialized
INFO - 2023-10-06 12:59:15 --> Security Class Initialized
DEBUG - 2023-10-06 12:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:59:15 --> Input Class Initialized
INFO - 2023-10-06 12:59:15 --> Language Class Initialized
INFO - 2023-10-06 12:59:15 --> Language Class Initialized
INFO - 2023-10-06 12:59:15 --> Config Class Initialized
INFO - 2023-10-06 12:59:15 --> Loader Class Initialized
INFO - 2023-10-06 12:59:15 --> Helper loaded: url_helper
INFO - 2023-10-06 12:59:15 --> Helper loaded: file_helper
INFO - 2023-10-06 12:59:15 --> Helper loaded: form_helper
INFO - 2023-10-06 12:59:15 --> Helper loaded: my_helper
INFO - 2023-10-06 12:59:15 --> Database Driver Class Initialized
INFO - 2023-10-06 12:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:59:15 --> Controller Class Initialized
DEBUG - 2023-10-06 12:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 12:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:59:15 --> Final output sent to browser
DEBUG - 2023-10-06 12:59:15 --> Total execution time: 0.0988
INFO - 2023-10-06 12:59:17 --> Config Class Initialized
INFO - 2023-10-06 12:59:17 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:59:17 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:59:17 --> Utf8 Class Initialized
INFO - 2023-10-06 12:59:17 --> URI Class Initialized
INFO - 2023-10-06 12:59:17 --> Router Class Initialized
INFO - 2023-10-06 12:59:17 --> Output Class Initialized
INFO - 2023-10-06 12:59:17 --> Security Class Initialized
DEBUG - 2023-10-06 12:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:59:17 --> Input Class Initialized
INFO - 2023-10-06 12:59:17 --> Language Class Initialized
INFO - 2023-10-06 12:59:17 --> Language Class Initialized
INFO - 2023-10-06 12:59:17 --> Config Class Initialized
INFO - 2023-10-06 12:59:17 --> Loader Class Initialized
INFO - 2023-10-06 12:59:17 --> Helper loaded: url_helper
INFO - 2023-10-06 12:59:17 --> Helper loaded: file_helper
INFO - 2023-10-06 12:59:17 --> Helper loaded: form_helper
INFO - 2023-10-06 12:59:17 --> Helper loaded: my_helper
INFO - 2023-10-06 12:59:17 --> Database Driver Class Initialized
INFO - 2023-10-06 12:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:59:17 --> Controller Class Initialized
DEBUG - 2023-10-06 12:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 12:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 12:59:17 --> Final output sent to browser
DEBUG - 2023-10-06 12:59:17 --> Total execution time: 0.0445
INFO - 2023-10-06 12:59:20 --> Config Class Initialized
INFO - 2023-10-06 12:59:20 --> Hooks Class Initialized
DEBUG - 2023-10-06 12:59:20 --> UTF-8 Support Enabled
INFO - 2023-10-06 12:59:20 --> Utf8 Class Initialized
INFO - 2023-10-06 12:59:20 --> URI Class Initialized
INFO - 2023-10-06 12:59:20 --> Router Class Initialized
INFO - 2023-10-06 12:59:20 --> Output Class Initialized
INFO - 2023-10-06 12:59:20 --> Security Class Initialized
DEBUG - 2023-10-06 12:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 12:59:20 --> Input Class Initialized
INFO - 2023-10-06 12:59:20 --> Language Class Initialized
INFO - 2023-10-06 12:59:20 --> Language Class Initialized
INFO - 2023-10-06 12:59:20 --> Config Class Initialized
INFO - 2023-10-06 12:59:20 --> Loader Class Initialized
INFO - 2023-10-06 12:59:20 --> Helper loaded: url_helper
INFO - 2023-10-06 12:59:20 --> Helper loaded: file_helper
INFO - 2023-10-06 12:59:20 --> Helper loaded: form_helper
INFO - 2023-10-06 12:59:20 --> Helper loaded: my_helper
INFO - 2023-10-06 12:59:20 --> Database Driver Class Initialized
INFO - 2023-10-06 12:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 12:59:20 --> Controller Class Initialized
INFO - 2023-10-06 12:59:20 --> Final output sent to browser
DEBUG - 2023-10-06 12:59:20 --> Total execution time: 0.0354
INFO - 2023-10-06 13:01:01 --> Config Class Initialized
INFO - 2023-10-06 13:01:01 --> Hooks Class Initialized
DEBUG - 2023-10-06 13:01:01 --> UTF-8 Support Enabled
INFO - 2023-10-06 13:01:01 --> Utf8 Class Initialized
INFO - 2023-10-06 13:01:01 --> URI Class Initialized
INFO - 2023-10-06 13:01:01 --> Router Class Initialized
INFO - 2023-10-06 13:01:01 --> Output Class Initialized
INFO - 2023-10-06 13:01:01 --> Security Class Initialized
DEBUG - 2023-10-06 13:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 13:01:01 --> Input Class Initialized
INFO - 2023-10-06 13:01:01 --> Language Class Initialized
INFO - 2023-10-06 13:01:01 --> Language Class Initialized
INFO - 2023-10-06 13:01:01 --> Config Class Initialized
INFO - 2023-10-06 13:01:01 --> Loader Class Initialized
INFO - 2023-10-06 13:01:01 --> Helper loaded: url_helper
INFO - 2023-10-06 13:01:01 --> Helper loaded: file_helper
INFO - 2023-10-06 13:01:01 --> Helper loaded: form_helper
INFO - 2023-10-06 13:01:01 --> Helper loaded: my_helper
INFO - 2023-10-06 13:01:01 --> Database Driver Class Initialized
INFO - 2023-10-06 13:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 13:01:01 --> Controller Class Initialized
INFO - 2023-10-06 13:01:01 --> Final output sent to browser
DEBUG - 2023-10-06 13:01:01 --> Total execution time: 0.1246
INFO - 2023-10-06 13:01:05 --> Config Class Initialized
INFO - 2023-10-06 13:01:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 13:01:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 13:01:05 --> Utf8 Class Initialized
INFO - 2023-10-06 13:01:05 --> URI Class Initialized
INFO - 2023-10-06 13:01:05 --> Router Class Initialized
INFO - 2023-10-06 13:01:05 --> Output Class Initialized
INFO - 2023-10-06 13:01:05 --> Security Class Initialized
DEBUG - 2023-10-06 13:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 13:01:05 --> Input Class Initialized
INFO - 2023-10-06 13:01:05 --> Language Class Initialized
INFO - 2023-10-06 13:01:05 --> Language Class Initialized
INFO - 2023-10-06 13:01:05 --> Config Class Initialized
INFO - 2023-10-06 13:01:05 --> Loader Class Initialized
INFO - 2023-10-06 13:01:05 --> Helper loaded: url_helper
INFO - 2023-10-06 13:01:05 --> Helper loaded: file_helper
INFO - 2023-10-06 13:01:05 --> Helper loaded: form_helper
INFO - 2023-10-06 13:01:05 --> Helper loaded: my_helper
INFO - 2023-10-06 13:01:05 --> Database Driver Class Initialized
INFO - 2023-10-06 13:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 13:01:05 --> Controller Class Initialized
DEBUG - 2023-10-06 13:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 13:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 13:01:05 --> Final output sent to browser
DEBUG - 2023-10-06 13:01:05 --> Total execution time: 0.0390
INFO - 2023-10-06 13:01:07 --> Config Class Initialized
INFO - 2023-10-06 13:01:07 --> Hooks Class Initialized
DEBUG - 2023-10-06 13:01:07 --> UTF-8 Support Enabled
INFO - 2023-10-06 13:01:07 --> Utf8 Class Initialized
INFO - 2023-10-06 13:01:07 --> URI Class Initialized
INFO - 2023-10-06 13:01:07 --> Router Class Initialized
INFO - 2023-10-06 13:01:07 --> Output Class Initialized
INFO - 2023-10-06 13:01:07 --> Security Class Initialized
DEBUG - 2023-10-06 13:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 13:01:07 --> Input Class Initialized
INFO - 2023-10-06 13:01:07 --> Language Class Initialized
INFO - 2023-10-06 13:01:07 --> Language Class Initialized
INFO - 2023-10-06 13:01:07 --> Config Class Initialized
INFO - 2023-10-06 13:01:07 --> Loader Class Initialized
INFO - 2023-10-06 13:01:07 --> Helper loaded: url_helper
INFO - 2023-10-06 13:01:07 --> Helper loaded: file_helper
INFO - 2023-10-06 13:01:07 --> Helper loaded: form_helper
INFO - 2023-10-06 13:01:07 --> Helper loaded: my_helper
INFO - 2023-10-06 13:01:07 --> Database Driver Class Initialized
INFO - 2023-10-06 13:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 13:01:07 --> Controller Class Initialized
DEBUG - 2023-10-06 13:01:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-06 13:01:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 13:01:07 --> Final output sent to browser
DEBUG - 2023-10-06 13:01:07 --> Total execution time: 0.0429
INFO - 2023-10-06 13:01:11 --> Config Class Initialized
INFO - 2023-10-06 13:01:11 --> Hooks Class Initialized
DEBUG - 2023-10-06 13:01:11 --> UTF-8 Support Enabled
INFO - 2023-10-06 13:01:11 --> Utf8 Class Initialized
INFO - 2023-10-06 13:01:11 --> URI Class Initialized
INFO - 2023-10-06 13:01:11 --> Router Class Initialized
INFO - 2023-10-06 13:01:11 --> Output Class Initialized
INFO - 2023-10-06 13:01:11 --> Security Class Initialized
DEBUG - 2023-10-06 13:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 13:01:11 --> Input Class Initialized
INFO - 2023-10-06 13:01:11 --> Language Class Initialized
INFO - 2023-10-06 13:01:11 --> Language Class Initialized
INFO - 2023-10-06 13:01:11 --> Config Class Initialized
INFO - 2023-10-06 13:01:11 --> Loader Class Initialized
INFO - 2023-10-06 13:01:11 --> Helper loaded: url_helper
INFO - 2023-10-06 13:01:11 --> Helper loaded: file_helper
INFO - 2023-10-06 13:01:11 --> Helper loaded: form_helper
INFO - 2023-10-06 13:01:11 --> Helper loaded: my_helper
INFO - 2023-10-06 13:01:11 --> Database Driver Class Initialized
INFO - 2023-10-06 13:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 13:01:11 --> Controller Class Initialized
INFO - 2023-10-06 13:01:11 --> Final output sent to browser
DEBUG - 2023-10-06 13:01:11 --> Total execution time: 0.0950
INFO - 2023-10-06 14:09:05 --> Config Class Initialized
INFO - 2023-10-06 14:09:05 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:05 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:05 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:05 --> URI Class Initialized
DEBUG - 2023-10-06 14:09:05 --> No URI present. Default controller set.
INFO - 2023-10-06 14:09:05 --> Router Class Initialized
INFO - 2023-10-06 14:09:05 --> Output Class Initialized
INFO - 2023-10-06 14:09:05 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:05 --> Input Class Initialized
INFO - 2023-10-06 14:09:05 --> Language Class Initialized
INFO - 2023-10-06 14:09:05 --> Language Class Initialized
INFO - 2023-10-06 14:09:05 --> Config Class Initialized
INFO - 2023-10-06 14:09:05 --> Loader Class Initialized
INFO - 2023-10-06 14:09:05 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:05 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:05 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:05 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:05 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:05 --> Controller Class Initialized
DEBUG - 2023-10-06 14:09:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-06 14:09:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 14:09:05 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:05 --> Total execution time: 0.1160
INFO - 2023-10-06 14:09:08 --> Config Class Initialized
INFO - 2023-10-06 14:09:08 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:08 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:08 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:08 --> URI Class Initialized
INFO - 2023-10-06 14:09:08 --> Router Class Initialized
INFO - 2023-10-06 14:09:08 --> Output Class Initialized
INFO - 2023-10-06 14:09:08 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:08 --> Input Class Initialized
INFO - 2023-10-06 14:09:08 --> Language Class Initialized
INFO - 2023-10-06 14:09:08 --> Language Class Initialized
INFO - 2023-10-06 14:09:08 --> Config Class Initialized
INFO - 2023-10-06 14:09:08 --> Loader Class Initialized
INFO - 2023-10-06 14:09:08 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:08 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:08 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:08 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:08 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:08 --> Controller Class Initialized
DEBUG - 2023-10-06 14:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-10-06 14:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 14:09:08 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:08 --> Total execution time: 0.0355
INFO - 2023-10-06 14:09:10 --> Config Class Initialized
INFO - 2023-10-06 14:09:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:10 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:10 --> URI Class Initialized
INFO - 2023-10-06 14:09:10 --> Router Class Initialized
INFO - 2023-10-06 14:09:10 --> Output Class Initialized
INFO - 2023-10-06 14:09:10 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:10 --> Input Class Initialized
INFO - 2023-10-06 14:09:10 --> Language Class Initialized
INFO - 2023-10-06 14:09:10 --> Language Class Initialized
INFO - 2023-10-06 14:09:10 --> Config Class Initialized
INFO - 2023-10-06 14:09:10 --> Loader Class Initialized
INFO - 2023-10-06 14:09:10 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:10 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:10 --> Controller Class Initialized
DEBUG - 2023-10-06 14:09:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-10-06 14:09:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-06 14:09:10 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:10 --> Total execution time: 0.0520
INFO - 2023-10-06 14:09:10 --> Config Class Initialized
INFO - 2023-10-06 14:09:10 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:10 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:10 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:10 --> URI Class Initialized
INFO - 2023-10-06 14:09:10 --> Router Class Initialized
INFO - 2023-10-06 14:09:10 --> Output Class Initialized
INFO - 2023-10-06 14:09:10 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:10 --> Input Class Initialized
INFO - 2023-10-06 14:09:10 --> Language Class Initialized
INFO - 2023-10-06 14:09:10 --> Language Class Initialized
INFO - 2023-10-06 14:09:10 --> Config Class Initialized
INFO - 2023-10-06 14:09:10 --> Loader Class Initialized
INFO - 2023-10-06 14:09:10 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:10 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:10 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:10 --> Controller Class Initialized
INFO - 2023-10-06 14:09:13 --> Config Class Initialized
INFO - 2023-10-06 14:09:13 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:13 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:13 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:13 --> URI Class Initialized
INFO - 2023-10-06 14:09:13 --> Router Class Initialized
INFO - 2023-10-06 14:09:13 --> Output Class Initialized
INFO - 2023-10-06 14:09:13 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:13 --> Input Class Initialized
INFO - 2023-10-06 14:09:13 --> Language Class Initialized
INFO - 2023-10-06 14:09:13 --> Language Class Initialized
INFO - 2023-10-06 14:09:13 --> Config Class Initialized
INFO - 2023-10-06 14:09:13 --> Loader Class Initialized
INFO - 2023-10-06 14:09:13 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:13 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:13 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:13 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:13 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:13 --> Controller Class Initialized
INFO - 2023-10-06 14:09:13 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:13 --> Total execution time: 0.0735
INFO - 2023-10-06 14:09:29 --> Config Class Initialized
INFO - 2023-10-06 14:09:29 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:29 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:29 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:29 --> URI Class Initialized
INFO - 2023-10-06 14:09:29 --> Router Class Initialized
INFO - 2023-10-06 14:09:29 --> Output Class Initialized
INFO - 2023-10-06 14:09:29 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:29 --> Input Class Initialized
INFO - 2023-10-06 14:09:29 --> Language Class Initialized
INFO - 2023-10-06 14:09:29 --> Language Class Initialized
INFO - 2023-10-06 14:09:29 --> Config Class Initialized
INFO - 2023-10-06 14:09:29 --> Loader Class Initialized
INFO - 2023-10-06 14:09:29 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:29 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:29 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:29 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:29 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:29 --> Controller Class Initialized
INFO - 2023-10-06 14:09:29 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:29 --> Total execution time: 0.0514
INFO - 2023-10-06 14:09:30 --> Config Class Initialized
INFO - 2023-10-06 14:09:30 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:30 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:30 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:30 --> URI Class Initialized
INFO - 2023-10-06 14:09:30 --> Router Class Initialized
INFO - 2023-10-06 14:09:30 --> Output Class Initialized
INFO - 2023-10-06 14:09:30 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:30 --> Input Class Initialized
INFO - 2023-10-06 14:09:30 --> Language Class Initialized
INFO - 2023-10-06 14:09:30 --> Language Class Initialized
INFO - 2023-10-06 14:09:30 --> Config Class Initialized
INFO - 2023-10-06 14:09:30 --> Loader Class Initialized
INFO - 2023-10-06 14:09:30 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:30 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:30 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:30 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:30 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:30 --> Controller Class Initialized
INFO - 2023-10-06 14:09:30 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:30 --> Total execution time: 0.1038
INFO - 2023-10-06 14:09:36 --> Config Class Initialized
INFO - 2023-10-06 14:09:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:36 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:36 --> URI Class Initialized
INFO - 2023-10-06 14:09:36 --> Router Class Initialized
INFO - 2023-10-06 14:09:36 --> Output Class Initialized
INFO - 2023-10-06 14:09:36 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:36 --> Input Class Initialized
INFO - 2023-10-06 14:09:36 --> Language Class Initialized
INFO - 2023-10-06 14:09:36 --> Language Class Initialized
INFO - 2023-10-06 14:09:36 --> Config Class Initialized
INFO - 2023-10-06 14:09:36 --> Loader Class Initialized
INFO - 2023-10-06 14:09:36 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:36 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:36 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:36 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:36 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:36 --> Controller Class Initialized
INFO - 2023-10-06 14:09:36 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:36 --> Total execution time: 0.0360
INFO - 2023-10-06 14:09:39 --> Config Class Initialized
INFO - 2023-10-06 14:09:39 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:39 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:39 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:39 --> URI Class Initialized
INFO - 2023-10-06 14:09:39 --> Router Class Initialized
INFO - 2023-10-06 14:09:39 --> Output Class Initialized
INFO - 2023-10-06 14:09:39 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:39 --> Input Class Initialized
INFO - 2023-10-06 14:09:39 --> Language Class Initialized
INFO - 2023-10-06 14:09:39 --> Language Class Initialized
INFO - 2023-10-06 14:09:39 --> Config Class Initialized
INFO - 2023-10-06 14:09:39 --> Loader Class Initialized
INFO - 2023-10-06 14:09:39 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:39 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:39 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:39 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:39 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:39 --> Controller Class Initialized
INFO - 2023-10-06 14:09:39 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:40 --> Total execution time: 0.0714
INFO - 2023-10-06 14:09:53 --> Config Class Initialized
INFO - 2023-10-06 14:09:53 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:53 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:53 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:53 --> URI Class Initialized
INFO - 2023-10-06 14:09:53 --> Router Class Initialized
INFO - 2023-10-06 14:09:53 --> Output Class Initialized
INFO - 2023-10-06 14:09:53 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:53 --> Input Class Initialized
INFO - 2023-10-06 14:09:53 --> Language Class Initialized
INFO - 2023-10-06 14:09:53 --> Language Class Initialized
INFO - 2023-10-06 14:09:53 --> Config Class Initialized
INFO - 2023-10-06 14:09:53 --> Loader Class Initialized
INFO - 2023-10-06 14:09:53 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:53 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:53 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:53 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:53 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:53 --> Controller Class Initialized
INFO - 2023-10-06 14:09:53 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:53 --> Total execution time: 0.0877
INFO - 2023-10-06 14:09:56 --> Config Class Initialized
INFO - 2023-10-06 14:09:56 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:09:56 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:09:56 --> Utf8 Class Initialized
INFO - 2023-10-06 14:09:56 --> URI Class Initialized
INFO - 2023-10-06 14:09:56 --> Router Class Initialized
INFO - 2023-10-06 14:09:56 --> Output Class Initialized
INFO - 2023-10-06 14:09:56 --> Security Class Initialized
DEBUG - 2023-10-06 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:09:56 --> Input Class Initialized
INFO - 2023-10-06 14:09:56 --> Language Class Initialized
INFO - 2023-10-06 14:09:56 --> Language Class Initialized
INFO - 2023-10-06 14:09:56 --> Config Class Initialized
INFO - 2023-10-06 14:09:56 --> Loader Class Initialized
INFO - 2023-10-06 14:09:56 --> Helper loaded: url_helper
INFO - 2023-10-06 14:09:56 --> Helper loaded: file_helper
INFO - 2023-10-06 14:09:56 --> Helper loaded: form_helper
INFO - 2023-10-06 14:09:56 --> Helper loaded: my_helper
INFO - 2023-10-06 14:09:56 --> Database Driver Class Initialized
INFO - 2023-10-06 14:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:09:56 --> Controller Class Initialized
INFO - 2023-10-06 14:09:56 --> Final output sent to browser
DEBUG - 2023-10-06 14:09:56 --> Total execution time: 0.0461
INFO - 2023-10-06 14:10:06 --> Config Class Initialized
INFO - 2023-10-06 14:10:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:10:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:10:06 --> Utf8 Class Initialized
INFO - 2023-10-06 14:10:06 --> URI Class Initialized
INFO - 2023-10-06 14:10:06 --> Router Class Initialized
INFO - 2023-10-06 14:10:06 --> Output Class Initialized
INFO - 2023-10-06 14:10:06 --> Security Class Initialized
DEBUG - 2023-10-06 14:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:10:06 --> Input Class Initialized
INFO - 2023-10-06 14:10:06 --> Language Class Initialized
INFO - 2023-10-06 14:10:06 --> Language Class Initialized
INFO - 2023-10-06 14:10:06 --> Config Class Initialized
INFO - 2023-10-06 14:10:06 --> Loader Class Initialized
INFO - 2023-10-06 14:10:06 --> Helper loaded: url_helper
INFO - 2023-10-06 14:10:06 --> Helper loaded: file_helper
INFO - 2023-10-06 14:10:06 --> Helper loaded: form_helper
INFO - 2023-10-06 14:10:06 --> Helper loaded: my_helper
INFO - 2023-10-06 14:10:06 --> Database Driver Class Initialized
INFO - 2023-10-06 14:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:10:06 --> Controller Class Initialized
INFO - 2023-10-06 14:12:06 --> Config Class Initialized
INFO - 2023-10-06 14:12:06 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:12:06 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:12:06 --> Utf8 Class Initialized
INFO - 2023-10-06 14:12:06 --> URI Class Initialized
INFO - 2023-10-06 14:12:06 --> Router Class Initialized
INFO - 2023-10-06 14:12:06 --> Output Class Initialized
INFO - 2023-10-06 14:12:06 --> Security Class Initialized
DEBUG - 2023-10-06 14:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:12:06 --> Input Class Initialized
INFO - 2023-10-06 14:12:06 --> Language Class Initialized
INFO - 2023-10-06 14:12:06 --> Language Class Initialized
INFO - 2023-10-06 14:12:06 --> Config Class Initialized
INFO - 2023-10-06 14:12:06 --> Loader Class Initialized
INFO - 2023-10-06 14:12:06 --> Helper loaded: url_helper
INFO - 2023-10-06 14:12:06 --> Helper loaded: file_helper
INFO - 2023-10-06 14:12:06 --> Helper loaded: form_helper
INFO - 2023-10-06 14:12:06 --> Helper loaded: my_helper
INFO - 2023-10-06 14:12:06 --> Database Driver Class Initialized
INFO - 2023-10-06 14:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:12:06 --> Controller Class Initialized
DEBUG - 2023-10-06 14:12:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 14:12:11 --> Final output sent to browser
DEBUG - 2023-10-06 14:12:11 --> Total execution time: 4.7956
INFO - 2023-10-06 14:13:50 --> Config Class Initialized
INFO - 2023-10-06 14:13:50 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:13:50 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:13:50 --> Utf8 Class Initialized
INFO - 2023-10-06 14:13:50 --> URI Class Initialized
INFO - 2023-10-06 14:13:50 --> Router Class Initialized
INFO - 2023-10-06 14:13:50 --> Output Class Initialized
INFO - 2023-10-06 14:13:50 --> Security Class Initialized
DEBUG - 2023-10-06 14:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:13:50 --> Input Class Initialized
INFO - 2023-10-06 14:13:50 --> Language Class Initialized
INFO - 2023-10-06 14:13:50 --> Language Class Initialized
INFO - 2023-10-06 14:13:50 --> Config Class Initialized
INFO - 2023-10-06 14:13:50 --> Loader Class Initialized
INFO - 2023-10-06 14:13:50 --> Helper loaded: url_helper
INFO - 2023-10-06 14:13:50 --> Helper loaded: file_helper
INFO - 2023-10-06 14:13:50 --> Helper loaded: form_helper
INFO - 2023-10-06 14:13:50 --> Helper loaded: my_helper
INFO - 2023-10-06 14:13:50 --> Database Driver Class Initialized
INFO - 2023-10-06 14:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:13:50 --> Controller Class Initialized
INFO - 2023-10-06 14:13:50 --> Final output sent to browser
DEBUG - 2023-10-06 14:13:50 --> Total execution time: 0.0372
INFO - 2023-10-06 14:13:52 --> Config Class Initialized
INFO - 2023-10-06 14:13:52 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:13:52 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:13:52 --> Utf8 Class Initialized
INFO - 2023-10-06 14:13:52 --> URI Class Initialized
INFO - 2023-10-06 14:13:52 --> Router Class Initialized
INFO - 2023-10-06 14:13:52 --> Output Class Initialized
INFO - 2023-10-06 14:13:52 --> Security Class Initialized
DEBUG - 2023-10-06 14:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:13:52 --> Input Class Initialized
INFO - 2023-10-06 14:13:52 --> Language Class Initialized
INFO - 2023-10-06 14:13:52 --> Language Class Initialized
INFO - 2023-10-06 14:13:52 --> Config Class Initialized
INFO - 2023-10-06 14:13:52 --> Loader Class Initialized
INFO - 2023-10-06 14:13:52 --> Helper loaded: url_helper
INFO - 2023-10-06 14:13:52 --> Helper loaded: file_helper
INFO - 2023-10-06 14:13:52 --> Helper loaded: form_helper
INFO - 2023-10-06 14:13:52 --> Helper loaded: my_helper
INFO - 2023-10-06 14:13:52 --> Database Driver Class Initialized
INFO - 2023-10-06 14:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:13:52 --> Controller Class Initialized
INFO - 2023-10-06 14:13:52 --> Final output sent to browser
DEBUG - 2023-10-06 14:13:52 --> Total execution time: 0.0400
INFO - 2023-10-06 14:13:55 --> Config Class Initialized
INFO - 2023-10-06 14:13:55 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:13:55 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:13:55 --> Utf8 Class Initialized
INFO - 2023-10-06 14:13:55 --> URI Class Initialized
INFO - 2023-10-06 14:13:55 --> Router Class Initialized
INFO - 2023-10-06 14:13:55 --> Output Class Initialized
INFO - 2023-10-06 14:13:55 --> Security Class Initialized
DEBUG - 2023-10-06 14:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:13:55 --> Input Class Initialized
INFO - 2023-10-06 14:13:55 --> Language Class Initialized
INFO - 2023-10-06 14:13:55 --> Language Class Initialized
INFO - 2023-10-06 14:13:55 --> Config Class Initialized
INFO - 2023-10-06 14:13:55 --> Loader Class Initialized
INFO - 2023-10-06 14:13:55 --> Helper loaded: url_helper
INFO - 2023-10-06 14:13:55 --> Helper loaded: file_helper
INFO - 2023-10-06 14:13:55 --> Helper loaded: form_helper
INFO - 2023-10-06 14:13:55 --> Helper loaded: my_helper
INFO - 2023-10-06 14:13:55 --> Database Driver Class Initialized
INFO - 2023-10-06 14:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:13:55 --> Controller Class Initialized
INFO - 2023-10-06 14:13:55 --> Final output sent to browser
DEBUG - 2023-10-06 14:13:55 --> Total execution time: 0.0411
INFO - 2023-10-06 14:13:57 --> Config Class Initialized
INFO - 2023-10-06 14:13:57 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:13:57 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:13:57 --> Utf8 Class Initialized
INFO - 2023-10-06 14:13:57 --> URI Class Initialized
INFO - 2023-10-06 14:13:57 --> Router Class Initialized
INFO - 2023-10-06 14:13:57 --> Output Class Initialized
INFO - 2023-10-06 14:13:57 --> Security Class Initialized
DEBUG - 2023-10-06 14:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:13:57 --> Input Class Initialized
INFO - 2023-10-06 14:13:57 --> Language Class Initialized
INFO - 2023-10-06 14:13:57 --> Language Class Initialized
INFO - 2023-10-06 14:13:57 --> Config Class Initialized
INFO - 2023-10-06 14:13:57 --> Loader Class Initialized
INFO - 2023-10-06 14:13:57 --> Helper loaded: url_helper
INFO - 2023-10-06 14:13:57 --> Helper loaded: file_helper
INFO - 2023-10-06 14:13:57 --> Helper loaded: form_helper
INFO - 2023-10-06 14:13:57 --> Helper loaded: my_helper
INFO - 2023-10-06 14:13:57 --> Database Driver Class Initialized
INFO - 2023-10-06 14:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:13:57 --> Controller Class Initialized
INFO - 2023-10-06 14:13:57 --> Final output sent to browser
DEBUG - 2023-10-06 14:13:57 --> Total execution time: 0.0352
INFO - 2023-10-06 14:14:02 --> Config Class Initialized
INFO - 2023-10-06 14:14:02 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:14:02 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:14:02 --> Utf8 Class Initialized
INFO - 2023-10-06 14:14:02 --> URI Class Initialized
INFO - 2023-10-06 14:14:02 --> Router Class Initialized
INFO - 2023-10-06 14:14:02 --> Output Class Initialized
INFO - 2023-10-06 14:14:02 --> Security Class Initialized
DEBUG - 2023-10-06 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:14:02 --> Input Class Initialized
INFO - 2023-10-06 14:14:02 --> Language Class Initialized
INFO - 2023-10-06 14:14:02 --> Language Class Initialized
INFO - 2023-10-06 14:14:02 --> Config Class Initialized
INFO - 2023-10-06 14:14:02 --> Loader Class Initialized
INFO - 2023-10-06 14:14:02 --> Helper loaded: url_helper
INFO - 2023-10-06 14:14:02 --> Helper loaded: file_helper
INFO - 2023-10-06 14:14:02 --> Helper loaded: form_helper
INFO - 2023-10-06 14:14:02 --> Helper loaded: my_helper
INFO - 2023-10-06 14:14:02 --> Database Driver Class Initialized
INFO - 2023-10-06 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:14:02 --> Controller Class Initialized
INFO - 2023-10-06 14:14:02 --> Final output sent to browser
DEBUG - 2023-10-06 14:14:02 --> Total execution time: 0.1095
INFO - 2023-10-06 14:17:09 --> Config Class Initialized
INFO - 2023-10-06 14:17:09 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:17:09 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:17:09 --> Utf8 Class Initialized
INFO - 2023-10-06 14:17:09 --> URI Class Initialized
INFO - 2023-10-06 14:17:09 --> Router Class Initialized
INFO - 2023-10-06 14:17:09 --> Output Class Initialized
INFO - 2023-10-06 14:17:09 --> Security Class Initialized
DEBUG - 2023-10-06 14:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:17:09 --> Input Class Initialized
INFO - 2023-10-06 14:17:09 --> Language Class Initialized
INFO - 2023-10-06 14:17:09 --> Language Class Initialized
INFO - 2023-10-06 14:17:09 --> Config Class Initialized
INFO - 2023-10-06 14:17:09 --> Loader Class Initialized
INFO - 2023-10-06 14:17:09 --> Helper loaded: url_helper
INFO - 2023-10-06 14:17:09 --> Helper loaded: file_helper
INFO - 2023-10-06 14:17:09 --> Helper loaded: form_helper
INFO - 2023-10-06 14:17:09 --> Helper loaded: my_helper
INFO - 2023-10-06 14:17:09 --> Database Driver Class Initialized
INFO - 2023-10-06 14:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:17:09 --> Controller Class Initialized
INFO - 2023-10-06 14:33:36 --> Config Class Initialized
INFO - 2023-10-06 14:33:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:33:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:33:36 --> Utf8 Class Initialized
INFO - 2023-10-06 14:33:36 --> URI Class Initialized
INFO - 2023-10-06 14:33:36 --> Router Class Initialized
INFO - 2023-10-06 14:33:36 --> Output Class Initialized
INFO - 2023-10-06 14:33:36 --> Security Class Initialized
DEBUG - 2023-10-06 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:33:36 --> Input Class Initialized
INFO - 2023-10-06 14:33:36 --> Language Class Initialized
INFO - 2023-10-06 14:33:36 --> Language Class Initialized
INFO - 2023-10-06 14:33:36 --> Config Class Initialized
INFO - 2023-10-06 14:33:36 --> Loader Class Initialized
INFO - 2023-10-06 14:33:36 --> Helper loaded: url_helper
INFO - 2023-10-06 14:33:36 --> Helper loaded: file_helper
INFO - 2023-10-06 14:33:36 --> Helper loaded: form_helper
INFO - 2023-10-06 14:33:36 --> Helper loaded: my_helper
INFO - 2023-10-06 14:33:36 --> Database Driver Class Initialized
INFO - 2023-10-06 14:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:33:36 --> Controller Class Initialized
DEBUG - 2023-10-06 14:33:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 14:33:40 --> Final output sent to browser
DEBUG - 2023-10-06 14:33:40 --> Total execution time: 4.6195
INFO - 2023-10-06 14:56:24 --> Config Class Initialized
INFO - 2023-10-06 14:56:24 --> Hooks Class Initialized
DEBUG - 2023-10-06 14:56:24 --> UTF-8 Support Enabled
INFO - 2023-10-06 14:56:24 --> Utf8 Class Initialized
INFO - 2023-10-06 14:56:24 --> URI Class Initialized
INFO - 2023-10-06 14:56:24 --> Router Class Initialized
INFO - 2023-10-06 14:56:24 --> Output Class Initialized
INFO - 2023-10-06 14:56:24 --> Security Class Initialized
DEBUG - 2023-10-06 14:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 14:56:24 --> Input Class Initialized
INFO - 2023-10-06 14:56:24 --> Language Class Initialized
INFO - 2023-10-06 14:56:24 --> Language Class Initialized
INFO - 2023-10-06 14:56:24 --> Config Class Initialized
INFO - 2023-10-06 14:56:24 --> Loader Class Initialized
INFO - 2023-10-06 14:56:24 --> Helper loaded: url_helper
INFO - 2023-10-06 14:56:24 --> Helper loaded: file_helper
INFO - 2023-10-06 14:56:24 --> Helper loaded: form_helper
INFO - 2023-10-06 14:56:24 --> Helper loaded: my_helper
INFO - 2023-10-06 14:56:24 --> Database Driver Class Initialized
INFO - 2023-10-06 14:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 14:56:24 --> Controller Class Initialized
DEBUG - 2023-10-06 14:56:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 14:56:28 --> Final output sent to browser
DEBUG - 2023-10-06 14:56:28 --> Total execution time: 4.0264
INFO - 2023-10-06 15:12:36 --> Config Class Initialized
INFO - 2023-10-06 15:12:36 --> Hooks Class Initialized
DEBUG - 2023-10-06 15:12:36 --> UTF-8 Support Enabled
INFO - 2023-10-06 15:12:36 --> Utf8 Class Initialized
INFO - 2023-10-06 15:12:36 --> URI Class Initialized
INFO - 2023-10-06 15:12:36 --> Router Class Initialized
INFO - 2023-10-06 15:12:36 --> Output Class Initialized
INFO - 2023-10-06 15:12:36 --> Security Class Initialized
DEBUG - 2023-10-06 15:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 15:12:36 --> Input Class Initialized
INFO - 2023-10-06 15:12:36 --> Language Class Initialized
INFO - 2023-10-06 15:12:36 --> Language Class Initialized
INFO - 2023-10-06 15:12:36 --> Config Class Initialized
INFO - 2023-10-06 15:12:36 --> Loader Class Initialized
INFO - 2023-10-06 15:12:36 --> Helper loaded: url_helper
INFO - 2023-10-06 15:12:36 --> Helper loaded: file_helper
INFO - 2023-10-06 15:12:36 --> Helper loaded: form_helper
INFO - 2023-10-06 15:12:36 --> Helper loaded: my_helper
INFO - 2023-10-06 15:12:36 --> Database Driver Class Initialized
INFO - 2023-10-06 15:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 15:12:36 --> Controller Class Initialized
DEBUG - 2023-10-06 15:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 15:12:40 --> Final output sent to browser
DEBUG - 2023-10-06 15:12:40 --> Total execution time: 4.6880
INFO - 2023-10-06 15:26:26 --> Config Class Initialized
INFO - 2023-10-06 15:26:26 --> Hooks Class Initialized
DEBUG - 2023-10-06 15:26:26 --> UTF-8 Support Enabled
INFO - 2023-10-06 15:26:26 --> Utf8 Class Initialized
INFO - 2023-10-06 15:26:26 --> URI Class Initialized
INFO - 2023-10-06 15:26:26 --> Router Class Initialized
INFO - 2023-10-06 15:26:26 --> Output Class Initialized
INFO - 2023-10-06 15:26:26 --> Security Class Initialized
DEBUG - 2023-10-06 15:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 15:26:26 --> Input Class Initialized
INFO - 2023-10-06 15:26:26 --> Language Class Initialized
INFO - 2023-10-06 15:26:26 --> Language Class Initialized
INFO - 2023-10-06 15:26:26 --> Config Class Initialized
INFO - 2023-10-06 15:26:26 --> Loader Class Initialized
INFO - 2023-10-06 15:26:26 --> Helper loaded: url_helper
INFO - 2023-10-06 15:26:26 --> Helper loaded: file_helper
INFO - 2023-10-06 15:26:26 --> Helper loaded: form_helper
INFO - 2023-10-06 15:26:26 --> Helper loaded: my_helper
INFO - 2023-10-06 15:26:26 --> Database Driver Class Initialized
INFO - 2023-10-06 15:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 15:26:26 --> Controller Class Initialized
DEBUG - 2023-10-06 15:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 15:26:31 --> Final output sent to browser
DEBUG - 2023-10-06 15:26:31 --> Total execution time: 5.1406
INFO - 2023-10-06 16:32:25 --> Config Class Initialized
INFO - 2023-10-06 16:32:25 --> Hooks Class Initialized
DEBUG - 2023-10-06 16:32:25 --> UTF-8 Support Enabled
INFO - 2023-10-06 16:32:25 --> Utf8 Class Initialized
INFO - 2023-10-06 16:32:25 --> URI Class Initialized
INFO - 2023-10-06 16:32:26 --> Router Class Initialized
INFO - 2023-10-06 16:32:26 --> Output Class Initialized
INFO - 2023-10-06 16:32:26 --> Security Class Initialized
DEBUG - 2023-10-06 16:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-06 16:32:26 --> Input Class Initialized
INFO - 2023-10-06 16:32:26 --> Language Class Initialized
INFO - 2023-10-06 16:32:26 --> Language Class Initialized
INFO - 2023-10-06 16:32:26 --> Config Class Initialized
INFO - 2023-10-06 16:32:26 --> Loader Class Initialized
INFO - 2023-10-06 16:32:26 --> Helper loaded: url_helper
INFO - 2023-10-06 16:32:26 --> Helper loaded: file_helper
INFO - 2023-10-06 16:32:26 --> Helper loaded: form_helper
INFO - 2023-10-06 16:32:26 --> Helper loaded: my_helper
INFO - 2023-10-06 16:32:26 --> Database Driver Class Initialized
INFO - 2023-10-06 16:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-06 16:32:26 --> Controller Class Initialized
DEBUG - 2023-10-06 16:32:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-06 16:32:29 --> Final output sent to browser
DEBUG - 2023-10-06 16:32:29 --> Total execution time: 4.1498
