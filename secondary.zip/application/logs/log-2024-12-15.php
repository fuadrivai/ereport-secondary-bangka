<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-15 08:51:30 --> Config Class Initialized
INFO - 2024-12-15 08:51:30 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:51:30 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:51:30 --> Utf8 Class Initialized
INFO - 2024-12-15 08:51:30 --> URI Class Initialized
DEBUG - 2024-12-15 08:51:30 --> No URI present. Default controller set.
INFO - 2024-12-15 08:51:30 --> Router Class Initialized
INFO - 2024-12-15 08:51:30 --> Output Class Initialized
INFO - 2024-12-15 08:51:30 --> Security Class Initialized
DEBUG - 2024-12-15 08:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:51:30 --> Input Class Initialized
INFO - 2024-12-15 08:51:30 --> Language Class Initialized
INFO - 2024-12-15 08:51:30 --> Language Class Initialized
INFO - 2024-12-15 08:51:30 --> Config Class Initialized
INFO - 2024-12-15 08:51:30 --> Loader Class Initialized
INFO - 2024-12-15 08:51:30 --> Helper loaded: url_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: file_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: form_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: my_helper
INFO - 2024-12-15 08:51:30 --> Database Driver Class Initialized
INFO - 2024-12-15 08:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:51:30 --> Controller Class Initialized
INFO - 2024-12-15 08:51:30 --> Config Class Initialized
INFO - 2024-12-15 08:51:30 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:51:30 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:51:30 --> Utf8 Class Initialized
INFO - 2024-12-15 08:51:30 --> URI Class Initialized
INFO - 2024-12-15 08:51:30 --> Router Class Initialized
INFO - 2024-12-15 08:51:30 --> Output Class Initialized
INFO - 2024-12-15 08:51:30 --> Security Class Initialized
DEBUG - 2024-12-15 08:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:51:30 --> Input Class Initialized
INFO - 2024-12-15 08:51:30 --> Language Class Initialized
INFO - 2024-12-15 08:51:30 --> Language Class Initialized
INFO - 2024-12-15 08:51:30 --> Config Class Initialized
INFO - 2024-12-15 08:51:30 --> Loader Class Initialized
INFO - 2024-12-15 08:51:30 --> Helper loaded: url_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: file_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: form_helper
INFO - 2024-12-15 08:51:30 --> Helper loaded: my_helper
INFO - 2024-12-15 08:51:30 --> Database Driver Class Initialized
INFO - 2024-12-15 08:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:51:30 --> Controller Class Initialized
DEBUG - 2024-12-15 08:51:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-15 08:51:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:51:30 --> Final output sent to browser
DEBUG - 2024-12-15 08:51:30 --> Total execution time: 0.0320
INFO - 2024-12-15 08:51:34 --> Config Class Initialized
INFO - 2024-12-15 08:51:34 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:51:34 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:51:34 --> Utf8 Class Initialized
INFO - 2024-12-15 08:51:34 --> URI Class Initialized
INFO - 2024-12-15 08:51:34 --> Router Class Initialized
INFO - 2024-12-15 08:51:34 --> Output Class Initialized
INFO - 2024-12-15 08:51:34 --> Security Class Initialized
DEBUG - 2024-12-15 08:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:51:34 --> Input Class Initialized
INFO - 2024-12-15 08:51:34 --> Language Class Initialized
INFO - 2024-12-15 08:51:34 --> Language Class Initialized
INFO - 2024-12-15 08:51:34 --> Config Class Initialized
INFO - 2024-12-15 08:51:34 --> Loader Class Initialized
INFO - 2024-12-15 08:51:34 --> Helper loaded: url_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: file_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: form_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: my_helper
INFO - 2024-12-15 08:51:34 --> Database Driver Class Initialized
INFO - 2024-12-15 08:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:51:34 --> Controller Class Initialized
INFO - 2024-12-15 08:51:34 --> Helper loaded: cookie_helper
INFO - 2024-12-15 08:51:34 --> Final output sent to browser
DEBUG - 2024-12-15 08:51:34 --> Total execution time: 0.0514
INFO - 2024-12-15 08:51:34 --> Config Class Initialized
INFO - 2024-12-15 08:51:34 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:51:34 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:51:34 --> Utf8 Class Initialized
INFO - 2024-12-15 08:51:34 --> URI Class Initialized
INFO - 2024-12-15 08:51:34 --> Router Class Initialized
INFO - 2024-12-15 08:51:34 --> Output Class Initialized
INFO - 2024-12-15 08:51:34 --> Security Class Initialized
DEBUG - 2024-12-15 08:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:51:34 --> Input Class Initialized
INFO - 2024-12-15 08:51:34 --> Language Class Initialized
INFO - 2024-12-15 08:51:34 --> Language Class Initialized
INFO - 2024-12-15 08:51:34 --> Config Class Initialized
INFO - 2024-12-15 08:51:34 --> Loader Class Initialized
INFO - 2024-12-15 08:51:34 --> Helper loaded: url_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: file_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: form_helper
INFO - 2024-12-15 08:51:34 --> Helper loaded: my_helper
INFO - 2024-12-15 08:51:34 --> Database Driver Class Initialized
INFO - 2024-12-15 08:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:51:34 --> Controller Class Initialized
DEBUG - 2024-12-15 08:51:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-15 08:51:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:51:34 --> Final output sent to browser
DEBUG - 2024-12-15 08:51:34 --> Total execution time: 0.0434
INFO - 2024-12-15 08:51:36 --> Config Class Initialized
INFO - 2024-12-15 08:51:36 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:51:36 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:51:36 --> Utf8 Class Initialized
INFO - 2024-12-15 08:51:36 --> URI Class Initialized
INFO - 2024-12-15 08:51:36 --> Router Class Initialized
INFO - 2024-12-15 08:51:36 --> Output Class Initialized
INFO - 2024-12-15 08:51:36 --> Security Class Initialized
DEBUG - 2024-12-15 08:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:51:36 --> Input Class Initialized
INFO - 2024-12-15 08:51:36 --> Language Class Initialized
INFO - 2024-12-15 08:51:36 --> Language Class Initialized
INFO - 2024-12-15 08:51:36 --> Config Class Initialized
INFO - 2024-12-15 08:51:36 --> Loader Class Initialized
INFO - 2024-12-15 08:51:36 --> Helper loaded: url_helper
INFO - 2024-12-15 08:51:36 --> Helper loaded: file_helper
INFO - 2024-12-15 08:51:36 --> Helper loaded: form_helper
INFO - 2024-12-15 08:51:36 --> Helper loaded: my_helper
INFO - 2024-12-15 08:51:36 --> Database Driver Class Initialized
INFO - 2024-12-15 08:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:51:36 --> Controller Class Initialized
DEBUG - 2024-12-15 08:51:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-15 08:51:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:51:36 --> Final output sent to browser
DEBUG - 2024-12-15 08:51:36 --> Total execution time: 0.0371
INFO - 2024-12-15 08:52:25 --> Config Class Initialized
INFO - 2024-12-15 08:52:25 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:25 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:25 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:25 --> URI Class Initialized
INFO - 2024-12-15 08:52:25 --> Router Class Initialized
INFO - 2024-12-15 08:52:25 --> Output Class Initialized
INFO - 2024-12-15 08:52:25 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:25 --> Input Class Initialized
INFO - 2024-12-15 08:52:25 --> Language Class Initialized
INFO - 2024-12-15 08:52:25 --> Language Class Initialized
INFO - 2024-12-15 08:52:25 --> Config Class Initialized
INFO - 2024-12-15 08:52:25 --> Loader Class Initialized
INFO - 2024-12-15 08:52:25 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:25 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:25 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 08:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:25 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:25 --> Total execution time: 0.0396
INFO - 2024-12-15 08:52:25 --> Config Class Initialized
INFO - 2024-12-15 08:52:25 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:25 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:25 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:25 --> URI Class Initialized
INFO - 2024-12-15 08:52:25 --> Router Class Initialized
INFO - 2024-12-15 08:52:25 --> Output Class Initialized
INFO - 2024-12-15 08:52:25 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:25 --> Input Class Initialized
INFO - 2024-12-15 08:52:25 --> Language Class Initialized
INFO - 2024-12-15 08:52:25 --> Language Class Initialized
INFO - 2024-12-15 08:52:25 --> Config Class Initialized
INFO - 2024-12-15 08:52:25 --> Loader Class Initialized
INFO - 2024-12-15 08:52:25 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:25 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:25 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:25 --> Controller Class Initialized
INFO - 2024-12-15 08:52:29 --> Config Class Initialized
INFO - 2024-12-15 08:52:29 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:29 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:29 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:29 --> URI Class Initialized
INFO - 2024-12-15 08:52:29 --> Router Class Initialized
INFO - 2024-12-15 08:52:29 --> Output Class Initialized
INFO - 2024-12-15 08:52:29 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:29 --> Input Class Initialized
INFO - 2024-12-15 08:52:29 --> Language Class Initialized
INFO - 2024-12-15 08:52:29 --> Language Class Initialized
INFO - 2024-12-15 08:52:29 --> Config Class Initialized
INFO - 2024-12-15 08:52:29 --> Loader Class Initialized
INFO - 2024-12-15 08:52:29 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:29 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:29 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:29 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:29 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:29 --> Controller Class Initialized
INFO - 2024-12-15 08:52:33 --> Config Class Initialized
INFO - 2024-12-15 08:52:33 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:33 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:33 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:33 --> URI Class Initialized
INFO - 2024-12-15 08:52:33 --> Router Class Initialized
INFO - 2024-12-15 08:52:33 --> Output Class Initialized
INFO - 2024-12-15 08:52:33 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:33 --> Input Class Initialized
INFO - 2024-12-15 08:52:33 --> Language Class Initialized
INFO - 2024-12-15 08:52:33 --> Language Class Initialized
INFO - 2024-12-15 08:52:33 --> Config Class Initialized
INFO - 2024-12-15 08:52:33 --> Loader Class Initialized
INFO - 2024-12-15 08:52:33 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:33 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:33 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:33 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:33 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:33 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-15 08:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:33 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:33 --> Total execution time: 0.0286
INFO - 2024-12-15 08:52:35 --> Config Class Initialized
INFO - 2024-12-15 08:52:35 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:35 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:35 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:35 --> URI Class Initialized
INFO - 2024-12-15 08:52:35 --> Router Class Initialized
INFO - 2024-12-15 08:52:35 --> Output Class Initialized
INFO - 2024-12-15 08:52:35 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:35 --> Input Class Initialized
INFO - 2024-12-15 08:52:35 --> Language Class Initialized
INFO - 2024-12-15 08:52:35 --> Language Class Initialized
INFO - 2024-12-15 08:52:35 --> Config Class Initialized
INFO - 2024-12-15 08:52:35 --> Loader Class Initialized
INFO - 2024-12-15 08:52:35 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:35 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:35 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:35 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:35 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:35 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 08:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:35 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:35 --> Total execution time: 0.0345
INFO - 2024-12-15 08:52:36 --> Config Class Initialized
INFO - 2024-12-15 08:52:36 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:36 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:36 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:36 --> URI Class Initialized
INFO - 2024-12-15 08:52:36 --> Router Class Initialized
INFO - 2024-12-15 08:52:36 --> Output Class Initialized
INFO - 2024-12-15 08:52:36 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:36 --> Input Class Initialized
INFO - 2024-12-15 08:52:36 --> Language Class Initialized
INFO - 2024-12-15 08:52:36 --> Language Class Initialized
INFO - 2024-12-15 08:52:36 --> Config Class Initialized
INFO - 2024-12-15 08:52:36 --> Loader Class Initialized
INFO - 2024-12-15 08:52:36 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:36 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:36 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:36 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:36 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:36 --> Controller Class Initialized
INFO - 2024-12-15 08:52:37 --> Config Class Initialized
INFO - 2024-12-15 08:52:37 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:37 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:37 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:37 --> URI Class Initialized
INFO - 2024-12-15 08:52:37 --> Router Class Initialized
INFO - 2024-12-15 08:52:37 --> Output Class Initialized
INFO - 2024-12-15 08:52:37 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:37 --> Input Class Initialized
INFO - 2024-12-15 08:52:37 --> Language Class Initialized
INFO - 2024-12-15 08:52:37 --> Language Class Initialized
INFO - 2024-12-15 08:52:37 --> Config Class Initialized
INFO - 2024-12-15 08:52:37 --> Loader Class Initialized
INFO - 2024-12-15 08:52:37 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:37 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:37 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:37 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:37 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:37 --> Controller Class Initialized
INFO - 2024-12-15 08:52:39 --> Config Class Initialized
INFO - 2024-12-15 08:52:39 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:39 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:39 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:39 --> URI Class Initialized
INFO - 2024-12-15 08:52:39 --> Router Class Initialized
INFO - 2024-12-15 08:52:39 --> Output Class Initialized
INFO - 2024-12-15 08:52:39 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:39 --> Input Class Initialized
INFO - 2024-12-15 08:52:39 --> Language Class Initialized
INFO - 2024-12-15 08:52:39 --> Language Class Initialized
INFO - 2024-12-15 08:52:39 --> Config Class Initialized
INFO - 2024-12-15 08:52:39 --> Loader Class Initialized
INFO - 2024-12-15 08:52:39 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:39 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:39 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:39 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:39 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:39 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-15 08:52:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:39 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:39 --> Total execution time: 0.0296
INFO - 2024-12-15 08:52:41 --> Config Class Initialized
INFO - 2024-12-15 08:52:41 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:41 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:41 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:41 --> URI Class Initialized
INFO - 2024-12-15 08:52:41 --> Router Class Initialized
INFO - 2024-12-15 08:52:41 --> Output Class Initialized
INFO - 2024-12-15 08:52:41 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:41 --> Input Class Initialized
INFO - 2024-12-15 08:52:41 --> Language Class Initialized
INFO - 2024-12-15 08:52:41 --> Language Class Initialized
INFO - 2024-12-15 08:52:41 --> Config Class Initialized
INFO - 2024-12-15 08:52:41 --> Loader Class Initialized
INFO - 2024-12-15 08:52:41 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:41 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:41 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 08:52:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:41 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:41 --> Total execution time: 0.0301
INFO - 2024-12-15 08:52:41 --> Config Class Initialized
INFO - 2024-12-15 08:52:41 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:41 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:41 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:41 --> URI Class Initialized
INFO - 2024-12-15 08:52:41 --> Router Class Initialized
INFO - 2024-12-15 08:52:41 --> Output Class Initialized
INFO - 2024-12-15 08:52:41 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:41 --> Input Class Initialized
INFO - 2024-12-15 08:52:41 --> Language Class Initialized
INFO - 2024-12-15 08:52:41 --> Language Class Initialized
INFO - 2024-12-15 08:52:41 --> Config Class Initialized
INFO - 2024-12-15 08:52:41 --> Loader Class Initialized
INFO - 2024-12-15 08:52:41 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:41 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:41 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:41 --> Controller Class Initialized
INFO - 2024-12-15 08:52:44 --> Config Class Initialized
INFO - 2024-12-15 08:52:44 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:44 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:44 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:44 --> URI Class Initialized
INFO - 2024-12-15 08:52:44 --> Router Class Initialized
INFO - 2024-12-15 08:52:44 --> Output Class Initialized
INFO - 2024-12-15 08:52:44 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:44 --> Input Class Initialized
INFO - 2024-12-15 08:52:44 --> Language Class Initialized
INFO - 2024-12-15 08:52:44 --> Language Class Initialized
INFO - 2024-12-15 08:52:44 --> Config Class Initialized
INFO - 2024-12-15 08:52:44 --> Loader Class Initialized
INFO - 2024-12-15 08:52:44 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:44 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:44 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:44 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:44 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:44 --> Controller Class Initialized
INFO - 2024-12-15 08:52:46 --> Config Class Initialized
INFO - 2024-12-15 08:52:46 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:46 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:46 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:46 --> URI Class Initialized
INFO - 2024-12-15 08:52:46 --> Router Class Initialized
INFO - 2024-12-15 08:52:46 --> Output Class Initialized
INFO - 2024-12-15 08:52:46 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:46 --> Input Class Initialized
INFO - 2024-12-15 08:52:46 --> Language Class Initialized
INFO - 2024-12-15 08:52:46 --> Language Class Initialized
INFO - 2024-12-15 08:52:46 --> Config Class Initialized
INFO - 2024-12-15 08:52:46 --> Loader Class Initialized
INFO - 2024-12-15 08:52:46 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:46 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:46 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:46 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:46 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:46 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-15 08:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:46 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:46 --> Total execution time: 0.0297
INFO - 2024-12-15 08:52:49 --> Config Class Initialized
INFO - 2024-12-15 08:52:49 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:49 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:49 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:49 --> URI Class Initialized
INFO - 2024-12-15 08:52:49 --> Router Class Initialized
INFO - 2024-12-15 08:52:49 --> Output Class Initialized
INFO - 2024-12-15 08:52:49 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:49 --> Input Class Initialized
INFO - 2024-12-15 08:52:49 --> Language Class Initialized
INFO - 2024-12-15 08:52:49 --> Language Class Initialized
INFO - 2024-12-15 08:52:49 --> Config Class Initialized
INFO - 2024-12-15 08:52:49 --> Loader Class Initialized
INFO - 2024-12-15 08:52:49 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:49 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:49 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 08:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:49 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:49 --> Total execution time: 0.0298
INFO - 2024-12-15 08:52:49 --> Config Class Initialized
INFO - 2024-12-15 08:52:49 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:49 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:49 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:49 --> URI Class Initialized
INFO - 2024-12-15 08:52:49 --> Router Class Initialized
INFO - 2024-12-15 08:52:49 --> Output Class Initialized
INFO - 2024-12-15 08:52:49 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:49 --> Input Class Initialized
INFO - 2024-12-15 08:52:49 --> Language Class Initialized
INFO - 2024-12-15 08:52:49 --> Language Class Initialized
INFO - 2024-12-15 08:52:49 --> Config Class Initialized
INFO - 2024-12-15 08:52:49 --> Loader Class Initialized
INFO - 2024-12-15 08:52:49 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:49 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:49 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:49 --> Controller Class Initialized
INFO - 2024-12-15 08:52:51 --> Config Class Initialized
INFO - 2024-12-15 08:52:51 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:51 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:51 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:51 --> URI Class Initialized
INFO - 2024-12-15 08:52:51 --> Router Class Initialized
INFO - 2024-12-15 08:52:51 --> Output Class Initialized
INFO - 2024-12-15 08:52:51 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:51 --> Input Class Initialized
INFO - 2024-12-15 08:52:51 --> Language Class Initialized
INFO - 2024-12-15 08:52:51 --> Language Class Initialized
INFO - 2024-12-15 08:52:51 --> Config Class Initialized
INFO - 2024-12-15 08:52:51 --> Loader Class Initialized
INFO - 2024-12-15 08:52:51 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:51 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:51 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:51 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:51 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:51 --> Controller Class Initialized
INFO - 2024-12-15 08:52:54 --> Config Class Initialized
INFO - 2024-12-15 08:52:54 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:54 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:54 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:54 --> URI Class Initialized
INFO - 2024-12-15 08:52:54 --> Router Class Initialized
INFO - 2024-12-15 08:52:54 --> Output Class Initialized
INFO - 2024-12-15 08:52:54 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:54 --> Input Class Initialized
INFO - 2024-12-15 08:52:54 --> Language Class Initialized
INFO - 2024-12-15 08:52:54 --> Language Class Initialized
INFO - 2024-12-15 08:52:54 --> Config Class Initialized
INFO - 2024-12-15 08:52:54 --> Loader Class Initialized
INFO - 2024-12-15 08:52:54 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:54 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:54 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:54 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:54 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:54 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-15 08:52:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:54 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:54 --> Total execution time: 0.0288
INFO - 2024-12-15 08:52:55 --> Config Class Initialized
INFO - 2024-12-15 08:52:55 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:55 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:55 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:55 --> URI Class Initialized
INFO - 2024-12-15 08:52:55 --> Router Class Initialized
INFO - 2024-12-15 08:52:55 --> Output Class Initialized
INFO - 2024-12-15 08:52:55 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:55 --> Input Class Initialized
INFO - 2024-12-15 08:52:55 --> Language Class Initialized
INFO - 2024-12-15 08:52:55 --> Language Class Initialized
INFO - 2024-12-15 08:52:55 --> Config Class Initialized
INFO - 2024-12-15 08:52:55 --> Loader Class Initialized
INFO - 2024-12-15 08:52:55 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:55 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:55 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:55 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:55 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:55 --> Controller Class Initialized
DEBUG - 2024-12-15 08:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 08:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 08:52:55 --> Final output sent to browser
DEBUG - 2024-12-15 08:52:55 --> Total execution time: 0.0399
INFO - 2024-12-15 08:52:56 --> Config Class Initialized
INFO - 2024-12-15 08:52:56 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:56 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:56 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:56 --> URI Class Initialized
INFO - 2024-12-15 08:52:56 --> Router Class Initialized
INFO - 2024-12-15 08:52:56 --> Output Class Initialized
INFO - 2024-12-15 08:52:56 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:56 --> Input Class Initialized
INFO - 2024-12-15 08:52:56 --> Language Class Initialized
INFO - 2024-12-15 08:52:56 --> Language Class Initialized
INFO - 2024-12-15 08:52:56 --> Config Class Initialized
INFO - 2024-12-15 08:52:56 --> Loader Class Initialized
INFO - 2024-12-15 08:52:56 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:56 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:56 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:56 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:56 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:56 --> Controller Class Initialized
INFO - 2024-12-15 08:52:57 --> Config Class Initialized
INFO - 2024-12-15 08:52:57 --> Hooks Class Initialized
DEBUG - 2024-12-15 08:52:57 --> UTF-8 Support Enabled
INFO - 2024-12-15 08:52:57 --> Utf8 Class Initialized
INFO - 2024-12-15 08:52:57 --> URI Class Initialized
INFO - 2024-12-15 08:52:57 --> Router Class Initialized
INFO - 2024-12-15 08:52:57 --> Output Class Initialized
INFO - 2024-12-15 08:52:57 --> Security Class Initialized
DEBUG - 2024-12-15 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 08:52:57 --> Input Class Initialized
INFO - 2024-12-15 08:52:57 --> Language Class Initialized
INFO - 2024-12-15 08:52:57 --> Language Class Initialized
INFO - 2024-12-15 08:52:57 --> Config Class Initialized
INFO - 2024-12-15 08:52:57 --> Loader Class Initialized
INFO - 2024-12-15 08:52:57 --> Helper loaded: url_helper
INFO - 2024-12-15 08:52:57 --> Helper loaded: file_helper
INFO - 2024-12-15 08:52:57 --> Helper loaded: form_helper
INFO - 2024-12-15 08:52:57 --> Helper loaded: my_helper
INFO - 2024-12-15 08:52:57 --> Database Driver Class Initialized
INFO - 2024-12-15 08:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 08:52:57 --> Controller Class Initialized
INFO - 2024-12-15 09:17:13 --> Config Class Initialized
INFO - 2024-12-15 09:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-15 09:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-15 09:17:13 --> Utf8 Class Initialized
INFO - 2024-12-15 09:17:13 --> URI Class Initialized
INFO - 2024-12-15 09:17:13 --> Router Class Initialized
INFO - 2024-12-15 09:17:13 --> Output Class Initialized
INFO - 2024-12-15 09:17:13 --> Security Class Initialized
DEBUG - 2024-12-15 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 09:17:13 --> Input Class Initialized
INFO - 2024-12-15 09:17:13 --> Language Class Initialized
INFO - 2024-12-15 09:17:13 --> Language Class Initialized
INFO - 2024-12-15 09:17:13 --> Config Class Initialized
INFO - 2024-12-15 09:17:13 --> Loader Class Initialized
INFO - 2024-12-15 09:17:13 --> Helper loaded: url_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: file_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: form_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: my_helper
INFO - 2024-12-15 09:17:13 --> Database Driver Class Initialized
INFO - 2024-12-15 09:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 09:17:13 --> Controller Class Initialized
DEBUG - 2024-12-15 09:17:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 09:17:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 09:17:13 --> Final output sent to browser
DEBUG - 2024-12-15 09:17:13 --> Total execution time: 0.0434
INFO - 2024-12-15 09:17:13 --> Config Class Initialized
INFO - 2024-12-15 09:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-15 09:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-15 09:17:13 --> Utf8 Class Initialized
INFO - 2024-12-15 09:17:13 --> URI Class Initialized
INFO - 2024-12-15 09:17:13 --> Router Class Initialized
INFO - 2024-12-15 09:17:13 --> Output Class Initialized
INFO - 2024-12-15 09:17:13 --> Security Class Initialized
DEBUG - 2024-12-15 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 09:17:13 --> Input Class Initialized
INFO - 2024-12-15 09:17:13 --> Language Class Initialized
INFO - 2024-12-15 09:17:13 --> Language Class Initialized
INFO - 2024-12-15 09:17:13 --> Config Class Initialized
INFO - 2024-12-15 09:17:13 --> Loader Class Initialized
INFO - 2024-12-15 09:17:13 --> Helper loaded: url_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: file_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: form_helper
INFO - 2024-12-15 09:17:13 --> Helper loaded: my_helper
INFO - 2024-12-15 09:17:13 --> Database Driver Class Initialized
INFO - 2024-12-15 09:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 09:17:13 --> Controller Class Initialized
INFO - 2024-12-15 09:38:26 --> Config Class Initialized
INFO - 2024-12-15 09:38:26 --> Hooks Class Initialized
DEBUG - 2024-12-15 09:38:26 --> UTF-8 Support Enabled
INFO - 2024-12-15 09:38:26 --> Utf8 Class Initialized
INFO - 2024-12-15 09:38:26 --> URI Class Initialized
INFO - 2024-12-15 09:38:26 --> Router Class Initialized
INFO - 2024-12-15 09:38:26 --> Output Class Initialized
INFO - 2024-12-15 09:38:26 --> Security Class Initialized
DEBUG - 2024-12-15 09:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 09:38:26 --> Input Class Initialized
INFO - 2024-12-15 09:38:26 --> Language Class Initialized
INFO - 2024-12-15 09:38:26 --> Language Class Initialized
INFO - 2024-12-15 09:38:26 --> Config Class Initialized
INFO - 2024-12-15 09:38:26 --> Loader Class Initialized
INFO - 2024-12-15 09:38:26 --> Helper loaded: url_helper
INFO - 2024-12-15 09:38:26 --> Helper loaded: file_helper
INFO - 2024-12-15 09:38:26 --> Helper loaded: form_helper
INFO - 2024-12-15 09:38:26 --> Helper loaded: my_helper
INFO - 2024-12-15 09:38:26 --> Database Driver Class Initialized
INFO - 2024-12-15 09:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 09:38:26 --> Controller Class Initialized
DEBUG - 2024-12-15 09:38:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-15 09:38:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 09:38:26 --> Final output sent to browser
DEBUG - 2024-12-15 09:38:26 --> Total execution time: 0.0911
INFO - 2024-12-15 09:38:27 --> Config Class Initialized
INFO - 2024-12-15 09:38:27 --> Hooks Class Initialized
DEBUG - 2024-12-15 09:38:27 --> UTF-8 Support Enabled
INFO - 2024-12-15 09:38:27 --> Utf8 Class Initialized
INFO - 2024-12-15 09:38:27 --> URI Class Initialized
INFO - 2024-12-15 09:38:27 --> Router Class Initialized
INFO - 2024-12-15 09:38:27 --> Output Class Initialized
INFO - 2024-12-15 09:38:27 --> Security Class Initialized
DEBUG - 2024-12-15 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 09:38:27 --> Input Class Initialized
INFO - 2024-12-15 09:38:27 --> Language Class Initialized
INFO - 2024-12-15 09:38:27 --> Language Class Initialized
INFO - 2024-12-15 09:38:27 --> Config Class Initialized
INFO - 2024-12-15 09:38:27 --> Loader Class Initialized
INFO - 2024-12-15 09:38:27 --> Helper loaded: url_helper
INFO - 2024-12-15 09:38:27 --> Helper loaded: file_helper
INFO - 2024-12-15 09:38:27 --> Helper loaded: form_helper
INFO - 2024-12-15 09:38:27 --> Helper loaded: my_helper
INFO - 2024-12-15 09:38:27 --> Database Driver Class Initialized
INFO - 2024-12-15 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 09:38:27 --> Controller Class Initialized
INFO - 2024-12-15 19:18:12 --> Config Class Initialized
INFO - 2024-12-15 19:18:12 --> Hooks Class Initialized
DEBUG - 2024-12-15 19:18:12 --> UTF-8 Support Enabled
INFO - 2024-12-15 19:18:12 --> Utf8 Class Initialized
INFO - 2024-12-15 19:18:12 --> URI Class Initialized
INFO - 2024-12-15 19:18:12 --> Router Class Initialized
INFO - 2024-12-15 19:18:12 --> Output Class Initialized
INFO - 2024-12-15 19:18:12 --> Security Class Initialized
DEBUG - 2024-12-15 19:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 19:18:12 --> Input Class Initialized
INFO - 2024-12-15 19:18:12 --> Language Class Initialized
INFO - 2024-12-15 19:18:12 --> Language Class Initialized
INFO - 2024-12-15 19:18:12 --> Config Class Initialized
INFO - 2024-12-15 19:18:12 --> Loader Class Initialized
INFO - 2024-12-15 19:18:12 --> Helper loaded: url_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: file_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: form_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: my_helper
INFO - 2024-12-15 19:18:12 --> Database Driver Class Initialized
INFO - 2024-12-15 19:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 19:18:12 --> Controller Class Initialized
INFO - 2024-12-15 19:18:12 --> Helper loaded: cookie_helper
INFO - 2024-12-15 19:18:12 --> Final output sent to browser
DEBUG - 2024-12-15 19:18:12 --> Total execution time: 0.0949
INFO - 2024-12-15 19:18:12 --> Config Class Initialized
INFO - 2024-12-15 19:18:12 --> Hooks Class Initialized
DEBUG - 2024-12-15 19:18:12 --> UTF-8 Support Enabled
INFO - 2024-12-15 19:18:12 --> Utf8 Class Initialized
INFO - 2024-12-15 19:18:12 --> URI Class Initialized
INFO - 2024-12-15 19:18:12 --> Router Class Initialized
INFO - 2024-12-15 19:18:12 --> Output Class Initialized
INFO - 2024-12-15 19:18:12 --> Security Class Initialized
DEBUG - 2024-12-15 19:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 19:18:12 --> Input Class Initialized
INFO - 2024-12-15 19:18:12 --> Language Class Initialized
INFO - 2024-12-15 19:18:12 --> Language Class Initialized
INFO - 2024-12-15 19:18:12 --> Config Class Initialized
INFO - 2024-12-15 19:18:12 --> Loader Class Initialized
INFO - 2024-12-15 19:18:12 --> Helper loaded: url_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: file_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: form_helper
INFO - 2024-12-15 19:18:12 --> Helper loaded: my_helper
INFO - 2024-12-15 19:18:12 --> Database Driver Class Initialized
INFO - 2024-12-15 19:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 19:18:12 --> Controller Class Initialized
INFO - 2024-12-15 19:18:12 --> Helper loaded: cookie_helper
INFO - 2024-12-15 19:18:13 --> Config Class Initialized
INFO - 2024-12-15 19:18:13 --> Hooks Class Initialized
DEBUG - 2024-12-15 19:18:13 --> UTF-8 Support Enabled
INFO - 2024-12-15 19:18:13 --> Utf8 Class Initialized
INFO - 2024-12-15 19:18:13 --> URI Class Initialized
INFO - 2024-12-15 19:18:13 --> Router Class Initialized
INFO - 2024-12-15 19:18:13 --> Output Class Initialized
INFO - 2024-12-15 19:18:13 --> Security Class Initialized
DEBUG - 2024-12-15 19:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 19:18:13 --> Input Class Initialized
INFO - 2024-12-15 19:18:13 --> Language Class Initialized
INFO - 2024-12-15 19:18:13 --> Language Class Initialized
INFO - 2024-12-15 19:18:13 --> Config Class Initialized
INFO - 2024-12-15 19:18:13 --> Loader Class Initialized
INFO - 2024-12-15 19:18:13 --> Helper loaded: url_helper
INFO - 2024-12-15 19:18:13 --> Helper loaded: file_helper
INFO - 2024-12-15 19:18:13 --> Helper loaded: form_helper
INFO - 2024-12-15 19:18:13 --> Helper loaded: my_helper
INFO - 2024-12-15 19:18:13 --> Database Driver Class Initialized
INFO - 2024-12-15 19:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 19:18:13 --> Controller Class Initialized
DEBUG - 2024-12-15 19:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-15 19:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-15 19:18:13 --> Final output sent to browser
DEBUG - 2024-12-15 19:18:13 --> Total execution time: 0.0605
INFO - 2024-12-15 19:18:14 --> Config Class Initialized
INFO - 2024-12-15 19:18:14 --> Hooks Class Initialized
DEBUG - 2024-12-15 19:18:14 --> UTF-8 Support Enabled
INFO - 2024-12-15 19:18:14 --> Utf8 Class Initialized
INFO - 2024-12-15 19:18:14 --> URI Class Initialized
INFO - 2024-12-15 19:18:14 --> Router Class Initialized
INFO - 2024-12-15 19:18:14 --> Output Class Initialized
INFO - 2024-12-15 19:18:14 --> Security Class Initialized
DEBUG - 2024-12-15 19:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 19:18:14 --> Input Class Initialized
INFO - 2024-12-15 19:18:14 --> Language Class Initialized
INFO - 2024-12-15 19:18:14 --> Language Class Initialized
INFO - 2024-12-15 19:18:14 --> Config Class Initialized
INFO - 2024-12-15 19:18:14 --> Loader Class Initialized
INFO - 2024-12-15 19:18:14 --> Helper loaded: url_helper
INFO - 2024-12-15 19:18:14 --> Helper loaded: file_helper
INFO - 2024-12-15 19:18:14 --> Helper loaded: form_helper
INFO - 2024-12-15 19:18:14 --> Helper loaded: my_helper
INFO - 2024-12-15 19:18:14 --> Database Driver Class Initialized
INFO - 2024-12-15 19:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-15 19:18:14 --> Controller Class Initialized
DEBUG - 2024-12-15 19:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-15 19:18:17 --> Final output sent to browser
DEBUG - 2024-12-15 19:18:17 --> Total execution time: 3.2141
