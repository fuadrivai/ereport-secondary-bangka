<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:23 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:23 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:23 --> URI Class Initialized
INFO - 2024-08-07 10:21:23 --> Router Class Initialized
INFO - 2024-08-07 10:21:23 --> Output Class Initialized
INFO - 2024-08-07 10:21:23 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:23 --> Input Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Loader Class Initialized
INFO - 2024-08-07 10:21:23 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:23 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:23 --> Controller Class Initialized
INFO - 2024-08-07 10:21:23 --> Helper loaded: cookie_helper
INFO - 2024-08-07 10:21:23 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:23 --> Total execution time: 0.0605
INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:23 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:23 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:23 --> URI Class Initialized
INFO - 2024-08-07 10:21:23 --> Router Class Initialized
INFO - 2024-08-07 10:21:23 --> Output Class Initialized
INFO - 2024-08-07 10:21:23 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:23 --> Input Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Loader Class Initialized
INFO - 2024-08-07 10:21:23 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:23 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:23 --> Controller Class Initialized
INFO - 2024-08-07 10:21:23 --> Helper loaded: cookie_helper
INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:23 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:23 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:23 --> URI Class Initialized
INFO - 2024-08-07 10:21:23 --> Router Class Initialized
INFO - 2024-08-07 10:21:23 --> Output Class Initialized
INFO - 2024-08-07 10:21:23 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:23 --> Input Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Language Class Initialized
INFO - 2024-08-07 10:21:23 --> Config Class Initialized
INFO - 2024-08-07 10:21:23 --> Loader Class Initialized
INFO - 2024-08-07 10:21:23 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:23 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:23 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:23 --> Controller Class Initialized
DEBUG - 2024-08-07 10:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 10:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 10:21:23 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:23 --> Total execution time: 0.1504
INFO - 2024-08-07 10:21:29 --> Config Class Initialized
INFO - 2024-08-07 10:21:29 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:29 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:29 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:29 --> URI Class Initialized
INFO - 2024-08-07 10:21:29 --> Router Class Initialized
INFO - 2024-08-07 10:21:29 --> Output Class Initialized
INFO - 2024-08-07 10:21:29 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:29 --> Input Class Initialized
INFO - 2024-08-07 10:21:29 --> Language Class Initialized
INFO - 2024-08-07 10:21:29 --> Language Class Initialized
INFO - 2024-08-07 10:21:29 --> Config Class Initialized
INFO - 2024-08-07 10:21:29 --> Loader Class Initialized
INFO - 2024-08-07 10:21:29 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:29 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:29 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:29 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:29 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:29 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:32 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:32 --> Total execution time: 3.0328
INFO - 2024-08-07 10:21:33 --> Config Class Initialized
INFO - 2024-08-07 10:21:33 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:33 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:33 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:33 --> URI Class Initialized
INFO - 2024-08-07 10:21:33 --> Router Class Initialized
INFO - 2024-08-07 10:21:33 --> Output Class Initialized
INFO - 2024-08-07 10:21:33 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:33 --> Input Class Initialized
INFO - 2024-08-07 10:21:33 --> Language Class Initialized
INFO - 2024-08-07 10:21:33 --> Language Class Initialized
INFO - 2024-08-07 10:21:33 --> Config Class Initialized
INFO - 2024-08-07 10:21:33 --> Loader Class Initialized
INFO - 2024-08-07 10:21:33 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:33 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:33 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:33 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:33 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:33 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:35 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:35 --> Total execution time: 2.8273
INFO - 2024-08-07 10:21:36 --> Config Class Initialized
INFO - 2024-08-07 10:21:36 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:36 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:36 --> URI Class Initialized
INFO - 2024-08-07 10:21:36 --> Router Class Initialized
INFO - 2024-08-07 10:21:36 --> Output Class Initialized
INFO - 2024-08-07 10:21:36 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:36 --> Input Class Initialized
INFO - 2024-08-07 10:21:36 --> Language Class Initialized
INFO - 2024-08-07 10:21:36 --> Language Class Initialized
INFO - 2024-08-07 10:21:36 --> Config Class Initialized
INFO - 2024-08-07 10:21:36 --> Loader Class Initialized
INFO - 2024-08-07 10:21:36 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:36 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:36 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:36 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:36 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:36 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:38 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:38 --> Total execution time: 2.6284
INFO - 2024-08-07 10:21:38 --> Config Class Initialized
INFO - 2024-08-07 10:21:38 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:38 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:38 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:38 --> URI Class Initialized
INFO - 2024-08-07 10:21:38 --> Router Class Initialized
INFO - 2024-08-07 10:21:38 --> Output Class Initialized
INFO - 2024-08-07 10:21:38 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:38 --> Input Class Initialized
INFO - 2024-08-07 10:21:38 --> Language Class Initialized
INFO - 2024-08-07 10:21:38 --> Language Class Initialized
INFO - 2024-08-07 10:21:38 --> Config Class Initialized
INFO - 2024-08-07 10:21:38 --> Loader Class Initialized
INFO - 2024-08-07 10:21:38 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:38 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:38 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:38 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:38 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:38 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:41 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:41 --> Total execution time: 2.6891
INFO - 2024-08-07 10:21:41 --> Config Class Initialized
INFO - 2024-08-07 10:21:41 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:41 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:41 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:41 --> URI Class Initialized
INFO - 2024-08-07 10:21:41 --> Router Class Initialized
INFO - 2024-08-07 10:21:41 --> Output Class Initialized
INFO - 2024-08-07 10:21:41 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:41 --> Input Class Initialized
INFO - 2024-08-07 10:21:41 --> Language Class Initialized
INFO - 2024-08-07 10:21:41 --> Language Class Initialized
INFO - 2024-08-07 10:21:41 --> Config Class Initialized
INFO - 2024-08-07 10:21:41 --> Loader Class Initialized
INFO - 2024-08-07 10:21:41 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:41 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:41 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:41 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:41 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:41 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:44 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:44 --> Total execution time: 2.6119
INFO - 2024-08-07 10:21:44 --> Config Class Initialized
INFO - 2024-08-07 10:21:44 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:44 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:44 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:44 --> URI Class Initialized
INFO - 2024-08-07 10:21:44 --> Router Class Initialized
INFO - 2024-08-07 10:21:44 --> Output Class Initialized
INFO - 2024-08-07 10:21:44 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:44 --> Input Class Initialized
INFO - 2024-08-07 10:21:44 --> Language Class Initialized
INFO - 2024-08-07 10:21:44 --> Language Class Initialized
INFO - 2024-08-07 10:21:44 --> Config Class Initialized
INFO - 2024-08-07 10:21:44 --> Loader Class Initialized
INFO - 2024-08-07 10:21:44 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:44 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:44 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:44 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:44 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:44 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:45 --> Config Class Initialized
INFO - 2024-08-07 10:21:45 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:45 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:45 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:45 --> URI Class Initialized
INFO - 2024-08-07 10:21:45 --> Router Class Initialized
INFO - 2024-08-07 10:21:45 --> Output Class Initialized
INFO - 2024-08-07 10:21:45 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:45 --> Input Class Initialized
INFO - 2024-08-07 10:21:45 --> Language Class Initialized
INFO - 2024-08-07 10:21:45 --> Language Class Initialized
INFO - 2024-08-07 10:21:45 --> Config Class Initialized
INFO - 2024-08-07 10:21:45 --> Loader Class Initialized
INFO - 2024-08-07 10:21:45 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:45 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:45 --> Controller Class Initialized
INFO - 2024-08-07 10:21:45 --> Helper loaded: cookie_helper
INFO - 2024-08-07 10:21:45 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:45 --> Total execution time: 0.0903
INFO - 2024-08-07 10:21:45 --> Config Class Initialized
INFO - 2024-08-07 10:21:45 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:45 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:45 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:45 --> URI Class Initialized
INFO - 2024-08-07 10:21:45 --> Router Class Initialized
INFO - 2024-08-07 10:21:45 --> Output Class Initialized
INFO - 2024-08-07 10:21:45 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:45 --> Input Class Initialized
INFO - 2024-08-07 10:21:45 --> Language Class Initialized
INFO - 2024-08-07 10:21:45 --> Language Class Initialized
INFO - 2024-08-07 10:21:45 --> Config Class Initialized
INFO - 2024-08-07 10:21:45 --> Loader Class Initialized
INFO - 2024-08-07 10:21:45 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:45 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:45 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:47 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:47 --> Total execution time: 2.7246
INFO - 2024-08-07 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:47 --> Controller Class Initialized
INFO - 2024-08-07 10:21:47 --> Helper loaded: cookie_helper
INFO - 2024-08-07 10:21:47 --> Config Class Initialized
INFO - 2024-08-07 10:21:47 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:47 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:47 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:47 --> URI Class Initialized
INFO - 2024-08-07 10:21:47 --> Router Class Initialized
INFO - 2024-08-07 10:21:47 --> Output Class Initialized
INFO - 2024-08-07 10:21:47 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:47 --> Input Class Initialized
INFO - 2024-08-07 10:21:47 --> Language Class Initialized
INFO - 2024-08-07 10:21:47 --> Language Class Initialized
INFO - 2024-08-07 10:21:47 --> Config Class Initialized
INFO - 2024-08-07 10:21:47 --> Loader Class Initialized
INFO - 2024-08-07 10:21:47 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:47 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:47 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:47 --> Config Class Initialized
INFO - 2024-08-07 10:21:47 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:47 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:47 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:47 --> URI Class Initialized
INFO - 2024-08-07 10:21:47 --> Router Class Initialized
INFO - 2024-08-07 10:21:47 --> Output Class Initialized
INFO - 2024-08-07 10:21:47 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:47 --> Input Class Initialized
INFO - 2024-08-07 10:21:47 --> Language Class Initialized
INFO - 2024-08-07 10:21:47 --> Language Class Initialized
INFO - 2024-08-07 10:21:47 --> Config Class Initialized
INFO - 2024-08-07 10:21:47 --> Loader Class Initialized
INFO - 2024-08-07 10:21:47 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:47 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:47 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:50 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:50 --> Total execution time: 2.7796
INFO - 2024-08-07 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:50 --> Controller Class Initialized
DEBUG - 2024-08-07 10:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 10:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 10:21:50 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:50 --> Total execution time: 2.7177
INFO - 2024-08-07 10:21:51 --> Config Class Initialized
INFO - 2024-08-07 10:21:51 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:51 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:51 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:51 --> URI Class Initialized
INFO - 2024-08-07 10:21:51 --> Router Class Initialized
INFO - 2024-08-07 10:21:51 --> Output Class Initialized
INFO - 2024-08-07 10:21:51 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:51 --> Input Class Initialized
INFO - 2024-08-07 10:21:51 --> Language Class Initialized
INFO - 2024-08-07 10:21:51 --> Language Class Initialized
INFO - 2024-08-07 10:21:51 --> Config Class Initialized
INFO - 2024-08-07 10:21:51 --> Loader Class Initialized
INFO - 2024-08-07 10:21:51 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:51 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:51 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:51 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:51 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:51 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:53 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:53 --> Total execution time: 2.4325
INFO - 2024-08-07 10:21:53 --> Config Class Initialized
INFO - 2024-08-07 10:21:53 --> Hooks Class Initialized
DEBUG - 2024-08-07 10:21:53 --> UTF-8 Support Enabled
INFO - 2024-08-07 10:21:53 --> Utf8 Class Initialized
INFO - 2024-08-07 10:21:53 --> URI Class Initialized
INFO - 2024-08-07 10:21:53 --> Router Class Initialized
INFO - 2024-08-07 10:21:53 --> Output Class Initialized
INFO - 2024-08-07 10:21:53 --> Security Class Initialized
DEBUG - 2024-08-07 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 10:21:53 --> Input Class Initialized
INFO - 2024-08-07 10:21:53 --> Language Class Initialized
INFO - 2024-08-07 10:21:53 --> Language Class Initialized
INFO - 2024-08-07 10:21:53 --> Config Class Initialized
INFO - 2024-08-07 10:21:53 --> Loader Class Initialized
INFO - 2024-08-07 10:21:53 --> Helper loaded: url_helper
INFO - 2024-08-07 10:21:53 --> Helper loaded: file_helper
INFO - 2024-08-07 10:21:53 --> Helper loaded: form_helper
INFO - 2024-08-07 10:21:53 --> Helper loaded: my_helper
INFO - 2024-08-07 10:21:53 --> Database Driver Class Initialized
INFO - 2024-08-07 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 10:21:53 --> Controller Class Initialized
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 10:21:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 10:21:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 10:21:56 --> Final output sent to browser
DEBUG - 2024-08-07 10:21:56 --> Total execution time: 2.9138
INFO - 2024-08-07 21:29:06 --> Config Class Initialized
INFO - 2024-08-07 21:29:06 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:06 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:06 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:06 --> URI Class Initialized
INFO - 2024-08-07 21:29:06 --> Router Class Initialized
INFO - 2024-08-07 21:29:06 --> Output Class Initialized
INFO - 2024-08-07 21:29:06 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:06 --> Input Class Initialized
INFO - 2024-08-07 21:29:06 --> Language Class Initialized
INFO - 2024-08-07 21:29:06 --> Language Class Initialized
INFO - 2024-08-07 21:29:06 --> Config Class Initialized
INFO - 2024-08-07 21:29:06 --> Loader Class Initialized
INFO - 2024-08-07 21:29:06 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:06 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:06 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:06 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:06 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:06 --> Controller Class Initialized
INFO - 2024-08-07 21:29:06 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:29:06 --> Final output sent to browser
DEBUG - 2024-08-07 21:29:06 --> Total execution time: 0.0579
INFO - 2024-08-07 21:29:07 --> Config Class Initialized
INFO - 2024-08-07 21:29:07 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:07 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:07 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:07 --> URI Class Initialized
INFO - 2024-08-07 21:29:07 --> Router Class Initialized
INFO - 2024-08-07 21:29:07 --> Output Class Initialized
INFO - 2024-08-07 21:29:07 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:07 --> Input Class Initialized
INFO - 2024-08-07 21:29:07 --> Language Class Initialized
INFO - 2024-08-07 21:29:07 --> Language Class Initialized
INFO - 2024-08-07 21:29:07 --> Config Class Initialized
INFO - 2024-08-07 21:29:07 --> Loader Class Initialized
INFO - 2024-08-07 21:29:07 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:07 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:07 --> Controller Class Initialized
INFO - 2024-08-07 21:29:07 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:29:07 --> Config Class Initialized
INFO - 2024-08-07 21:29:07 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:07 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:07 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:07 --> URI Class Initialized
INFO - 2024-08-07 21:29:07 --> Router Class Initialized
INFO - 2024-08-07 21:29:07 --> Output Class Initialized
INFO - 2024-08-07 21:29:07 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:07 --> Input Class Initialized
INFO - 2024-08-07 21:29:07 --> Language Class Initialized
INFO - 2024-08-07 21:29:07 --> Language Class Initialized
INFO - 2024-08-07 21:29:07 --> Config Class Initialized
INFO - 2024-08-07 21:29:07 --> Loader Class Initialized
INFO - 2024-08-07 21:29:07 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:07 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:07 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:07 --> Controller Class Initialized
DEBUG - 2024-08-07 21:29:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:29:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:29:07 --> Final output sent to browser
DEBUG - 2024-08-07 21:29:07 --> Total execution time: 0.0347
INFO - 2024-08-07 21:29:11 --> Config Class Initialized
INFO - 2024-08-07 21:29:11 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:11 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:11 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:11 --> URI Class Initialized
INFO - 2024-08-07 21:29:11 --> Router Class Initialized
INFO - 2024-08-07 21:29:11 --> Output Class Initialized
INFO - 2024-08-07 21:29:11 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:11 --> Input Class Initialized
INFO - 2024-08-07 21:29:11 --> Language Class Initialized
INFO - 2024-08-07 21:29:11 --> Language Class Initialized
INFO - 2024-08-07 21:29:11 --> Config Class Initialized
INFO - 2024-08-07 21:29:11 --> Loader Class Initialized
INFO - 2024-08-07 21:29:11 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:11 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:11 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:11 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:11 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:11 --> Controller Class Initialized
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-07 21:29:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-07 21:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-07 21:29:14 --> Config Class Initialized
INFO - 2024-08-07 21:29:14 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:14 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:14 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:14 --> URI Class Initialized
INFO - 2024-08-07 21:29:14 --> Router Class Initialized
INFO - 2024-08-07 21:29:14 --> Output Class Initialized
INFO - 2024-08-07 21:29:14 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:14 --> Input Class Initialized
INFO - 2024-08-07 21:29:14 --> Language Class Initialized
INFO - 2024-08-07 21:29:14 --> Language Class Initialized
INFO - 2024-08-07 21:29:14 --> Config Class Initialized
INFO - 2024-08-07 21:29:14 --> Loader Class Initialized
INFO - 2024-08-07 21:29:14 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:14 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:14 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:14 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:14 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:14 --> Final output sent to browser
DEBUG - 2024-08-07 21:29:14 --> Total execution time: 2.7814
INFO - 2024-08-07 21:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:14 --> Controller Class Initialized
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-07 21:29:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-07 21:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-07 21:29:16 --> Final output sent to browser
DEBUG - 2024-08-07 21:29:16 --> Total execution time: 2.4826
INFO - 2024-08-07 21:29:17 --> Config Class Initialized
INFO - 2024-08-07 21:29:17 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:17 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:17 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:17 --> URI Class Initialized
INFO - 2024-08-07 21:29:17 --> Router Class Initialized
INFO - 2024-08-07 21:29:17 --> Output Class Initialized
INFO - 2024-08-07 21:29:17 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:17 --> Input Class Initialized
INFO - 2024-08-07 21:29:17 --> Language Class Initialized
INFO - 2024-08-07 21:29:17 --> Language Class Initialized
INFO - 2024-08-07 21:29:17 --> Config Class Initialized
INFO - 2024-08-07 21:29:17 --> Loader Class Initialized
INFO - 2024-08-07 21:29:17 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:17 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:17 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:17 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:17 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:17 --> Controller Class Initialized
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-07 21:29:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-07 21:29:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-07 21:29:19 --> Config Class Initialized
INFO - 2024-08-07 21:29:19 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:19 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:19 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:19 --> URI Class Initialized
INFO - 2024-08-07 21:29:19 --> Router Class Initialized
INFO - 2024-08-07 21:29:19 --> Output Class Initialized
INFO - 2024-08-07 21:29:19 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:19 --> Input Class Initialized
INFO - 2024-08-07 21:29:19 --> Language Class Initialized
INFO - 2024-08-07 21:29:19 --> Language Class Initialized
INFO - 2024-08-07 21:29:19 --> Config Class Initialized
INFO - 2024-08-07 21:29:19 --> Loader Class Initialized
INFO - 2024-08-07 21:29:19 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:19 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:19 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:19 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:19 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:19 --> Final output sent to browser
DEBUG - 2024-08-07 21:29:19 --> Total execution time: 2.4984
INFO - 2024-08-07 21:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:19 --> Controller Class Initialized
DEBUG - 2024-08-07 21:29:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-07 21:29:21 --> Config Class Initialized
INFO - 2024-08-07 21:29:21 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:21 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:21 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:21 --> URI Class Initialized
INFO - 2024-08-07 21:29:21 --> Router Class Initialized
INFO - 2024-08-07 21:29:21 --> Output Class Initialized
INFO - 2024-08-07 21:29:21 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:21 --> Input Class Initialized
INFO - 2024-08-07 21:29:21 --> Language Class Initialized
INFO - 2024-08-07 21:29:21 --> Language Class Initialized
INFO - 2024-08-07 21:29:21 --> Config Class Initialized
INFO - 2024-08-07 21:29:21 --> Loader Class Initialized
INFO - 2024-08-07 21:29:21 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:21 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:21 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:21 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:21 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:22 --> Config Class Initialized
INFO - 2024-08-07 21:29:22 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:29:22 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:29:22 --> Utf8 Class Initialized
INFO - 2024-08-07 21:29:22 --> URI Class Initialized
INFO - 2024-08-07 21:29:22 --> Router Class Initialized
INFO - 2024-08-07 21:29:22 --> Output Class Initialized
INFO - 2024-08-07 21:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:23 --> Controller Class Initialized
DEBUG - 2024-08-07 21:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-07 21:29:23 --> Security Class Initialized
DEBUG - 2024-08-07 21:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:29:23 --> Input Class Initialized
INFO - 2024-08-07 21:29:23 --> Language Class Initialized
INFO - 2024-08-07 21:29:23 --> Language Class Initialized
INFO - 2024-08-07 21:29:23 --> Config Class Initialized
INFO - 2024-08-07 21:29:23 --> Loader Class Initialized
INFO - 2024-08-07 21:29:23 --> Helper loaded: url_helper
INFO - 2024-08-07 21:29:23 --> Helper loaded: file_helper
INFO - 2024-08-07 21:29:23 --> Helper loaded: form_helper
INFO - 2024-08-07 21:29:23 --> Helper loaded: my_helper
INFO - 2024-08-07 21:29:23 --> Database Driver Class Initialized
INFO - 2024-08-07 21:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:29:26 --> Controller Class Initialized
DEBUG - 2024-08-07 21:29:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:35:02 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:35:02 --> Utf8 Class Initialized
INFO - 2024-08-07 21:35:02 --> URI Class Initialized
INFO - 2024-08-07 21:35:02 --> Router Class Initialized
INFO - 2024-08-07 21:35:02 --> Output Class Initialized
INFO - 2024-08-07 21:35:02 --> Security Class Initialized
DEBUG - 2024-08-07 21:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:35:02 --> Input Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Loader Class Initialized
INFO - 2024-08-07 21:35:02 --> Helper loaded: url_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: file_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: form_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: my_helper
INFO - 2024-08-07 21:35:02 --> Database Driver Class Initialized
INFO - 2024-08-07 21:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:35:02 --> Controller Class Initialized
INFO - 2024-08-07 21:35:02 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:35:02 --> Final output sent to browser
DEBUG - 2024-08-07 21:35:02 --> Total execution time: 0.0682
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:35:02 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:35:02 --> Utf8 Class Initialized
INFO - 2024-08-07 21:35:02 --> URI Class Initialized
INFO - 2024-08-07 21:35:02 --> Router Class Initialized
INFO - 2024-08-07 21:35:02 --> Output Class Initialized
INFO - 2024-08-07 21:35:02 --> Security Class Initialized
DEBUG - 2024-08-07 21:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:35:02 --> Input Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Loader Class Initialized
INFO - 2024-08-07 21:35:02 --> Helper loaded: url_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: file_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: form_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: my_helper
INFO - 2024-08-07 21:35:02 --> Database Driver Class Initialized
INFO - 2024-08-07 21:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:35:02 --> Controller Class Initialized
INFO - 2024-08-07 21:35:02 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:35:02 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:35:02 --> Utf8 Class Initialized
INFO - 2024-08-07 21:35:02 --> URI Class Initialized
INFO - 2024-08-07 21:35:02 --> Router Class Initialized
INFO - 2024-08-07 21:35:02 --> Output Class Initialized
INFO - 2024-08-07 21:35:02 --> Security Class Initialized
DEBUG - 2024-08-07 21:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:35:02 --> Input Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Language Class Initialized
INFO - 2024-08-07 21:35:02 --> Config Class Initialized
INFO - 2024-08-07 21:35:02 --> Loader Class Initialized
INFO - 2024-08-07 21:35:02 --> Helper loaded: url_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: file_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: form_helper
INFO - 2024-08-07 21:35:02 --> Helper loaded: my_helper
INFO - 2024-08-07 21:35:02 --> Database Driver Class Initialized
INFO - 2024-08-07 21:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:35:02 --> Controller Class Initialized
DEBUG - 2024-08-07 21:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:35:02 --> Final output sent to browser
DEBUG - 2024-08-07 21:35:02 --> Total execution time: 0.0409
INFO - 2024-08-07 21:38:14 --> Config Class Initialized
INFO - 2024-08-07 21:38:14 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:14 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:14 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:14 --> URI Class Initialized
INFO - 2024-08-07 21:38:14 --> Router Class Initialized
INFO - 2024-08-07 21:38:14 --> Output Class Initialized
INFO - 2024-08-07 21:38:14 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:14 --> Input Class Initialized
INFO - 2024-08-07 21:38:14 --> Language Class Initialized
INFO - 2024-08-07 21:38:14 --> Language Class Initialized
INFO - 2024-08-07 21:38:14 --> Config Class Initialized
INFO - 2024-08-07 21:38:14 --> Loader Class Initialized
INFO - 2024-08-07 21:38:14 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:14 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:14 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:14 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:14 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:14 --> Controller Class Initialized
INFO - 2024-08-07 21:38:14 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:38:14 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:14 --> Total execution time: 0.0305
INFO - 2024-08-07 21:38:15 --> Config Class Initialized
INFO - 2024-08-07 21:38:15 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:15 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:15 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:15 --> URI Class Initialized
INFO - 2024-08-07 21:38:15 --> Router Class Initialized
INFO - 2024-08-07 21:38:15 --> Output Class Initialized
INFO - 2024-08-07 21:38:15 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:15 --> Input Class Initialized
INFO - 2024-08-07 21:38:15 --> Language Class Initialized
INFO - 2024-08-07 21:38:15 --> Language Class Initialized
INFO - 2024-08-07 21:38:15 --> Config Class Initialized
INFO - 2024-08-07 21:38:15 --> Loader Class Initialized
INFO - 2024-08-07 21:38:15 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:15 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:15 --> Controller Class Initialized
INFO - 2024-08-07 21:38:15 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:38:15 --> Config Class Initialized
INFO - 2024-08-07 21:38:15 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:15 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:15 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:15 --> URI Class Initialized
INFO - 2024-08-07 21:38:15 --> Router Class Initialized
INFO - 2024-08-07 21:38:15 --> Output Class Initialized
INFO - 2024-08-07 21:38:15 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:15 --> Input Class Initialized
INFO - 2024-08-07 21:38:15 --> Language Class Initialized
INFO - 2024-08-07 21:38:15 --> Language Class Initialized
INFO - 2024-08-07 21:38:15 --> Config Class Initialized
INFO - 2024-08-07 21:38:15 --> Loader Class Initialized
INFO - 2024-08-07 21:38:15 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:15 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:15 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:15 --> Controller Class Initialized
DEBUG - 2024-08-07 21:38:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:38:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:38:15 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:15 --> Total execution time: 0.0284
INFO - 2024-08-07 21:38:28 --> Config Class Initialized
INFO - 2024-08-07 21:38:28 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:28 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:28 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:28 --> URI Class Initialized
INFO - 2024-08-07 21:38:28 --> Router Class Initialized
INFO - 2024-08-07 21:38:28 --> Output Class Initialized
INFO - 2024-08-07 21:38:28 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:28 --> Input Class Initialized
INFO - 2024-08-07 21:38:28 --> Language Class Initialized
INFO - 2024-08-07 21:38:28 --> Language Class Initialized
INFO - 2024-08-07 21:38:28 --> Config Class Initialized
INFO - 2024-08-07 21:38:28 --> Loader Class Initialized
INFO - 2024-08-07 21:38:28 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:28 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:28 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:28 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:28 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:28 --> Controller Class Initialized
DEBUG - 2024-08-07 21:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:38:28 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:28 --> Total execution time: 0.0273
INFO - 2024-08-07 21:38:34 --> Config Class Initialized
INFO - 2024-08-07 21:38:34 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:34 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:34 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:34 --> URI Class Initialized
INFO - 2024-08-07 21:38:34 --> Router Class Initialized
INFO - 2024-08-07 21:38:34 --> Output Class Initialized
INFO - 2024-08-07 21:38:34 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:34 --> Input Class Initialized
INFO - 2024-08-07 21:38:34 --> Language Class Initialized
INFO - 2024-08-07 21:38:34 --> Language Class Initialized
INFO - 2024-08-07 21:38:34 --> Config Class Initialized
INFO - 2024-08-07 21:38:34 --> Loader Class Initialized
INFO - 2024-08-07 21:38:34 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:34 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:34 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:34 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:34 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:34 --> Controller Class Initialized
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-07 21:38:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-07 21:38:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-07 21:38:36 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:36 --> Total execution time: 2.4479
INFO - 2024-08-07 21:38:57 --> Config Class Initialized
INFO - 2024-08-07 21:38:57 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:57 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:57 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:57 --> URI Class Initialized
INFO - 2024-08-07 21:38:57 --> Router Class Initialized
INFO - 2024-08-07 21:38:57 --> Output Class Initialized
INFO - 2024-08-07 21:38:57 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:57 --> Input Class Initialized
INFO - 2024-08-07 21:38:57 --> Language Class Initialized
INFO - 2024-08-07 21:38:57 --> Language Class Initialized
INFO - 2024-08-07 21:38:57 --> Config Class Initialized
INFO - 2024-08-07 21:38:57 --> Loader Class Initialized
INFO - 2024-08-07 21:38:57 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:57 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:57 --> Controller Class Initialized
INFO - 2024-08-07 21:38:57 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:38:57 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:57 --> Total execution time: 0.0296
INFO - 2024-08-07 21:38:57 --> Config Class Initialized
INFO - 2024-08-07 21:38:57 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:57 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:57 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:57 --> URI Class Initialized
INFO - 2024-08-07 21:38:57 --> Router Class Initialized
INFO - 2024-08-07 21:38:57 --> Output Class Initialized
INFO - 2024-08-07 21:38:57 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:57 --> Input Class Initialized
INFO - 2024-08-07 21:38:57 --> Language Class Initialized
INFO - 2024-08-07 21:38:57 --> Language Class Initialized
INFO - 2024-08-07 21:38:57 --> Config Class Initialized
INFO - 2024-08-07 21:38:57 --> Loader Class Initialized
INFO - 2024-08-07 21:38:57 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:57 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:57 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:57 --> Controller Class Initialized
INFO - 2024-08-07 21:38:57 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:38:58 --> Config Class Initialized
INFO - 2024-08-07 21:38:58 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:38:58 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:38:58 --> Utf8 Class Initialized
INFO - 2024-08-07 21:38:58 --> URI Class Initialized
INFO - 2024-08-07 21:38:58 --> Router Class Initialized
INFO - 2024-08-07 21:38:58 --> Output Class Initialized
INFO - 2024-08-07 21:38:58 --> Security Class Initialized
DEBUG - 2024-08-07 21:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:38:58 --> Input Class Initialized
INFO - 2024-08-07 21:38:58 --> Language Class Initialized
INFO - 2024-08-07 21:38:58 --> Language Class Initialized
INFO - 2024-08-07 21:38:58 --> Config Class Initialized
INFO - 2024-08-07 21:38:58 --> Loader Class Initialized
INFO - 2024-08-07 21:38:58 --> Helper loaded: url_helper
INFO - 2024-08-07 21:38:58 --> Helper loaded: file_helper
INFO - 2024-08-07 21:38:58 --> Helper loaded: form_helper
INFO - 2024-08-07 21:38:58 --> Helper loaded: my_helper
INFO - 2024-08-07 21:38:58 --> Database Driver Class Initialized
INFO - 2024-08-07 21:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:38:58 --> Controller Class Initialized
DEBUG - 2024-08-07 21:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:38:58 --> Final output sent to browser
DEBUG - 2024-08-07 21:38:58 --> Total execution time: 0.0288
INFO - 2024-08-07 21:39:15 --> Config Class Initialized
INFO - 2024-08-07 21:39:15 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:15 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:15 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:15 --> URI Class Initialized
INFO - 2024-08-07 21:39:15 --> Router Class Initialized
INFO - 2024-08-07 21:39:15 --> Output Class Initialized
INFO - 2024-08-07 21:39:15 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:15 --> Input Class Initialized
INFO - 2024-08-07 21:39:15 --> Language Class Initialized
INFO - 2024-08-07 21:39:15 --> Language Class Initialized
INFO - 2024-08-07 21:39:15 --> Config Class Initialized
INFO - 2024-08-07 21:39:15 --> Loader Class Initialized
INFO - 2024-08-07 21:39:15 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:15 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:15 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:15 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:15 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:15 --> Controller Class Initialized
DEBUG - 2024-08-07 21:39:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-07 21:39:16 --> Config Class Initialized
INFO - 2024-08-07 21:39:16 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:16 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:16 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:16 --> URI Class Initialized
INFO - 2024-08-07 21:39:16 --> Router Class Initialized
INFO - 2024-08-07 21:39:16 --> Output Class Initialized
INFO - 2024-08-07 21:39:16 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:16 --> Input Class Initialized
INFO - 2024-08-07 21:39:16 --> Language Class Initialized
INFO - 2024-08-07 21:39:16 --> Language Class Initialized
INFO - 2024-08-07 21:39:16 --> Config Class Initialized
INFO - 2024-08-07 21:39:16 --> Loader Class Initialized
INFO - 2024-08-07 21:39:16 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:16 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:16 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:16 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:16 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:19 --> Controller Class Initialized
DEBUG - 2024-08-07 21:39:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-07 21:39:22 --> Final output sent to browser
DEBUG - 2024-08-07 21:39:22 --> Total execution time: 5.9741
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:49 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:49 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:49 --> URI Class Initialized
INFO - 2024-08-07 21:39:49 --> Router Class Initialized
INFO - 2024-08-07 21:39:49 --> Output Class Initialized
INFO - 2024-08-07 21:39:49 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:49 --> Input Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Loader Class Initialized
INFO - 2024-08-07 21:39:49 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:49 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:49 --> Controller Class Initialized
INFO - 2024-08-07 21:39:49 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:39:49 --> Final output sent to browser
DEBUG - 2024-08-07 21:39:49 --> Total execution time: 0.0330
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:49 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:49 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:49 --> URI Class Initialized
INFO - 2024-08-07 21:39:49 --> Router Class Initialized
INFO - 2024-08-07 21:39:49 --> Output Class Initialized
INFO - 2024-08-07 21:39:49 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:49 --> Input Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Loader Class Initialized
INFO - 2024-08-07 21:39:49 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:49 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:49 --> Controller Class Initialized
INFO - 2024-08-07 21:39:49 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:49 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:49 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:49 --> URI Class Initialized
INFO - 2024-08-07 21:39:49 --> Router Class Initialized
INFO - 2024-08-07 21:39:49 --> Output Class Initialized
INFO - 2024-08-07 21:39:49 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:49 --> Input Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Language Class Initialized
INFO - 2024-08-07 21:39:49 --> Config Class Initialized
INFO - 2024-08-07 21:39:49 --> Loader Class Initialized
INFO - 2024-08-07 21:39:49 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:49 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:49 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:49 --> Controller Class Initialized
DEBUG - 2024-08-07 21:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:39:49 --> Final output sent to browser
DEBUG - 2024-08-07 21:39:49 --> Total execution time: 0.0582
INFO - 2024-08-07 21:39:53 --> Config Class Initialized
INFO - 2024-08-07 21:39:53 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:39:53 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:39:53 --> Utf8 Class Initialized
INFO - 2024-08-07 21:39:53 --> URI Class Initialized
INFO - 2024-08-07 21:39:53 --> Router Class Initialized
INFO - 2024-08-07 21:39:53 --> Output Class Initialized
INFO - 2024-08-07 21:39:53 --> Security Class Initialized
DEBUG - 2024-08-07 21:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:39:53 --> Input Class Initialized
INFO - 2024-08-07 21:39:53 --> Language Class Initialized
INFO - 2024-08-07 21:39:53 --> Language Class Initialized
INFO - 2024-08-07 21:39:53 --> Config Class Initialized
INFO - 2024-08-07 21:39:53 --> Loader Class Initialized
INFO - 2024-08-07 21:39:53 --> Helper loaded: url_helper
INFO - 2024-08-07 21:39:53 --> Helper loaded: file_helper
INFO - 2024-08-07 21:39:53 --> Helper loaded: form_helper
INFO - 2024-08-07 21:39:53 --> Helper loaded: my_helper
INFO - 2024-08-07 21:39:53 --> Database Driver Class Initialized
INFO - 2024-08-07 21:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:39:53 --> Controller Class Initialized
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-07 21:39:53 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-07 21:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-07 21:39:55 --> Final output sent to browser
DEBUG - 2024-08-07 21:39:55 --> Total execution time: 2.3450
INFO - 2024-08-07 21:40:03 --> Config Class Initialized
INFO - 2024-08-07 21:40:03 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:40:03 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:40:03 --> Utf8 Class Initialized
INFO - 2024-08-07 21:40:03 --> URI Class Initialized
INFO - 2024-08-07 21:40:03 --> Router Class Initialized
INFO - 2024-08-07 21:40:03 --> Output Class Initialized
INFO - 2024-08-07 21:40:03 --> Security Class Initialized
DEBUG - 2024-08-07 21:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:40:03 --> Input Class Initialized
INFO - 2024-08-07 21:40:03 --> Language Class Initialized
INFO - 2024-08-07 21:40:03 --> Language Class Initialized
INFO - 2024-08-07 21:40:03 --> Config Class Initialized
INFO - 2024-08-07 21:40:03 --> Loader Class Initialized
INFO - 2024-08-07 21:40:03 --> Helper loaded: url_helper
INFO - 2024-08-07 21:40:03 --> Helper loaded: file_helper
INFO - 2024-08-07 21:40:03 --> Helper loaded: form_helper
INFO - 2024-08-07 21:40:03 --> Helper loaded: my_helper
INFO - 2024-08-07 21:40:03 --> Database Driver Class Initialized
INFO - 2024-08-07 21:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:40:03 --> Controller Class Initialized
INFO - 2024-08-07 21:40:03 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:40:03 --> Final output sent to browser
DEBUG - 2024-08-07 21:40:03 --> Total execution time: 0.0327
INFO - 2024-08-07 21:40:04 --> Config Class Initialized
INFO - 2024-08-07 21:40:04 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:40:04 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:40:04 --> Utf8 Class Initialized
INFO - 2024-08-07 21:40:04 --> URI Class Initialized
INFO - 2024-08-07 21:40:04 --> Router Class Initialized
INFO - 2024-08-07 21:40:04 --> Output Class Initialized
INFO - 2024-08-07 21:40:04 --> Security Class Initialized
DEBUG - 2024-08-07 21:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:40:04 --> Input Class Initialized
INFO - 2024-08-07 21:40:04 --> Language Class Initialized
INFO - 2024-08-07 21:40:04 --> Language Class Initialized
INFO - 2024-08-07 21:40:04 --> Config Class Initialized
INFO - 2024-08-07 21:40:04 --> Loader Class Initialized
INFO - 2024-08-07 21:40:04 --> Helper loaded: url_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: file_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: form_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: my_helper
INFO - 2024-08-07 21:40:04 --> Database Driver Class Initialized
INFO - 2024-08-07 21:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:40:04 --> Controller Class Initialized
INFO - 2024-08-07 21:40:04 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:40:04 --> Config Class Initialized
INFO - 2024-08-07 21:40:04 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:40:04 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:40:04 --> Utf8 Class Initialized
INFO - 2024-08-07 21:40:04 --> URI Class Initialized
INFO - 2024-08-07 21:40:04 --> Router Class Initialized
INFO - 2024-08-07 21:40:04 --> Output Class Initialized
INFO - 2024-08-07 21:40:04 --> Security Class Initialized
DEBUG - 2024-08-07 21:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:40:04 --> Input Class Initialized
INFO - 2024-08-07 21:40:04 --> Language Class Initialized
INFO - 2024-08-07 21:40:04 --> Language Class Initialized
INFO - 2024-08-07 21:40:04 --> Config Class Initialized
INFO - 2024-08-07 21:40:04 --> Loader Class Initialized
INFO - 2024-08-07 21:40:04 --> Helper loaded: url_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: file_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: form_helper
INFO - 2024-08-07 21:40:04 --> Helper loaded: my_helper
INFO - 2024-08-07 21:40:04 --> Database Driver Class Initialized
INFO - 2024-08-07 21:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:40:04 --> Controller Class Initialized
DEBUG - 2024-08-07 21:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:40:04 --> Final output sent to browser
DEBUG - 2024-08-07 21:40:04 --> Total execution time: 0.0367
INFO - 2024-08-07 21:40:07 --> Config Class Initialized
INFO - 2024-08-07 21:40:07 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:40:07 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:40:07 --> Utf8 Class Initialized
INFO - 2024-08-07 21:40:07 --> URI Class Initialized
INFO - 2024-08-07 21:40:07 --> Router Class Initialized
INFO - 2024-08-07 21:40:07 --> Output Class Initialized
INFO - 2024-08-07 21:40:07 --> Security Class Initialized
DEBUG - 2024-08-07 21:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:40:07 --> Input Class Initialized
INFO - 2024-08-07 21:40:07 --> Language Class Initialized
INFO - 2024-08-07 21:40:07 --> Language Class Initialized
INFO - 2024-08-07 21:40:07 --> Config Class Initialized
INFO - 2024-08-07 21:40:07 --> Loader Class Initialized
INFO - 2024-08-07 21:40:07 --> Helper loaded: url_helper
INFO - 2024-08-07 21:40:07 --> Helper loaded: file_helper
INFO - 2024-08-07 21:40:07 --> Helper loaded: form_helper
INFO - 2024-08-07 21:40:07 --> Helper loaded: my_helper
INFO - 2024-08-07 21:40:07 --> Database Driver Class Initialized
INFO - 2024-08-07 21:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:40:07 --> Controller Class Initialized
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-07 21:40:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-07 21:40:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-07 21:40:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-07 21:40:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-07 21:40:11 --> Final output sent to browser
DEBUG - 2024-08-07 21:40:11 --> Total execution time: 3.5727
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:12 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:12 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:12 --> URI Class Initialized
INFO - 2024-08-07 21:43:12 --> Router Class Initialized
INFO - 2024-08-07 21:43:12 --> Output Class Initialized
INFO - 2024-08-07 21:43:12 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:12 --> Input Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Loader Class Initialized
INFO - 2024-08-07 21:43:12 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:12 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:12 --> Controller Class Initialized
INFO - 2024-08-07 21:43:12 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:43:12 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:12 --> Total execution time: 0.0328
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:12 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:12 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:12 --> URI Class Initialized
INFO - 2024-08-07 21:43:12 --> Router Class Initialized
INFO - 2024-08-07 21:43:12 --> Output Class Initialized
INFO - 2024-08-07 21:43:12 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:12 --> Input Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Loader Class Initialized
INFO - 2024-08-07 21:43:12 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:12 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:12 --> Controller Class Initialized
INFO - 2024-08-07 21:43:12 --> Helper loaded: cookie_helper
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:12 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:12 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:12 --> URI Class Initialized
INFO - 2024-08-07 21:43:12 --> Router Class Initialized
INFO - 2024-08-07 21:43:12 --> Output Class Initialized
INFO - 2024-08-07 21:43:12 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:12 --> Input Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Language Class Initialized
INFO - 2024-08-07 21:43:12 --> Config Class Initialized
INFO - 2024-08-07 21:43:12 --> Loader Class Initialized
INFO - 2024-08-07 21:43:12 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:12 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:12 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:12 --> Controller Class Initialized
DEBUG - 2024-08-07 21:43:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:43:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:43:12 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:12 --> Total execution time: 0.0288
INFO - 2024-08-07 21:43:15 --> Config Class Initialized
INFO - 2024-08-07 21:43:15 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:15 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:15 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:15 --> URI Class Initialized
DEBUG - 2024-08-07 21:43:15 --> No URI present. Default controller set.
INFO - 2024-08-07 21:43:15 --> Router Class Initialized
INFO - 2024-08-07 21:43:15 --> Output Class Initialized
INFO - 2024-08-07 21:43:15 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:15 --> Input Class Initialized
INFO - 2024-08-07 21:43:15 --> Language Class Initialized
INFO - 2024-08-07 21:43:15 --> Language Class Initialized
INFO - 2024-08-07 21:43:15 --> Config Class Initialized
INFO - 2024-08-07 21:43:15 --> Loader Class Initialized
INFO - 2024-08-07 21:43:15 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:15 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:15 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:15 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:15 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:15 --> Controller Class Initialized
DEBUG - 2024-08-07 21:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-07 21:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:43:15 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:15 --> Total execution time: 0.0345
INFO - 2024-08-07 21:43:23 --> Config Class Initialized
INFO - 2024-08-07 21:43:23 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:23 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:23 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:23 --> URI Class Initialized
DEBUG - 2024-08-07 21:43:23 --> No URI present. Default controller set.
INFO - 2024-08-07 21:43:23 --> Router Class Initialized
INFO - 2024-08-07 21:43:23 --> Output Class Initialized
INFO - 2024-08-07 21:43:23 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:23 --> Input Class Initialized
INFO - 2024-08-07 21:43:23 --> Language Class Initialized
INFO - 2024-08-07 21:43:23 --> Language Class Initialized
INFO - 2024-08-07 21:43:23 --> Config Class Initialized
INFO - 2024-08-07 21:43:23 --> Loader Class Initialized
INFO - 2024-08-07 21:43:23 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:23 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:23 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:23 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:23 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:23 --> Controller Class Initialized
DEBUG - 2024-08-07 21:43:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-07 21:43:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:43:23 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:23 --> Total execution time: 0.0289
INFO - 2024-08-07 21:43:24 --> Config Class Initialized
INFO - 2024-08-07 21:43:24 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:24 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:24 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:24 --> URI Class Initialized
DEBUG - 2024-08-07 21:43:24 --> No URI present. Default controller set.
INFO - 2024-08-07 21:43:24 --> Router Class Initialized
INFO - 2024-08-07 21:43:24 --> Output Class Initialized
INFO - 2024-08-07 21:43:24 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:24 --> Input Class Initialized
INFO - 2024-08-07 21:43:24 --> Language Class Initialized
INFO - 2024-08-07 21:43:24 --> Language Class Initialized
INFO - 2024-08-07 21:43:24 --> Config Class Initialized
INFO - 2024-08-07 21:43:24 --> Loader Class Initialized
INFO - 2024-08-07 21:43:24 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:24 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:24 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:24 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:24 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:24 --> Controller Class Initialized
DEBUG - 2024-08-07 21:43:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-07 21:43:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:43:24 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:24 --> Total execution time: 0.0335
INFO - 2024-08-07 21:43:29 --> Config Class Initialized
INFO - 2024-08-07 21:43:29 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:29 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:29 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:29 --> URI Class Initialized
INFO - 2024-08-07 21:43:29 --> Router Class Initialized
INFO - 2024-08-07 21:43:29 --> Output Class Initialized
INFO - 2024-08-07 21:43:29 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:29 --> Input Class Initialized
INFO - 2024-08-07 21:43:29 --> Language Class Initialized
INFO - 2024-08-07 21:43:29 --> Language Class Initialized
INFO - 2024-08-07 21:43:29 --> Config Class Initialized
INFO - 2024-08-07 21:43:29 --> Loader Class Initialized
INFO - 2024-08-07 21:43:29 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:29 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:29 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:29 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:29 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:29 --> Controller Class Initialized
DEBUG - 2024-08-07 21:43:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-07 21:43:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-07 21:43:29 --> Final output sent to browser
DEBUG - 2024-08-07 21:43:29 --> Total execution time: 0.0421
INFO - 2024-08-07 21:43:49 --> Config Class Initialized
INFO - 2024-08-07 21:43:49 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:49 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:49 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:49 --> URI Class Initialized
INFO - 2024-08-07 21:43:49 --> Router Class Initialized
INFO - 2024-08-07 21:43:49 --> Output Class Initialized
INFO - 2024-08-07 21:43:49 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:49 --> Input Class Initialized
INFO - 2024-08-07 21:43:49 --> Language Class Initialized
INFO - 2024-08-07 21:43:49 --> Language Class Initialized
INFO - 2024-08-07 21:43:49 --> Config Class Initialized
INFO - 2024-08-07 21:43:49 --> Loader Class Initialized
INFO - 2024-08-07 21:43:49 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:49 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:49 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:49 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:49 --> Database Driver Class Initialized
INFO - 2024-08-07 21:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:43:49 --> Controller Class Initialized
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-07 21:43:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-07 21:43:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-07 21:43:52 --> Config Class Initialized
INFO - 2024-08-07 21:43:52 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:43:52 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:43:52 --> Utf8 Class Initialized
INFO - 2024-08-07 21:43:52 --> URI Class Initialized
INFO - 2024-08-07 21:43:52 --> Router Class Initialized
INFO - 2024-08-07 21:43:52 --> Output Class Initialized
INFO - 2024-08-07 21:43:52 --> Security Class Initialized
DEBUG - 2024-08-07 21:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:43:52 --> Input Class Initialized
INFO - 2024-08-07 21:43:52 --> Language Class Initialized
INFO - 2024-08-07 21:43:52 --> Language Class Initialized
INFO - 2024-08-07 21:43:52 --> Config Class Initialized
INFO - 2024-08-07 21:43:52 --> Loader Class Initialized
INFO - 2024-08-07 21:43:52 --> Helper loaded: url_helper
INFO - 2024-08-07 21:43:52 --> Helper loaded: file_helper
INFO - 2024-08-07 21:43:52 --> Helper loaded: form_helper
INFO - 2024-08-07 21:43:52 --> Helper loaded: my_helper
INFO - 2024-08-07 21:43:52 --> Database Driver Class Initialized
INFO - 2024-08-07 21:44:30 --> Config Class Initialized
INFO - 2024-08-07 21:44:30 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:44:30 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:44:30 --> Utf8 Class Initialized
INFO - 2024-08-07 21:44:30 --> URI Class Initialized
INFO - 2024-08-07 21:44:30 --> Router Class Initialized
INFO - 2024-08-07 21:44:30 --> Output Class Initialized
INFO - 2024-08-07 21:44:30 --> Security Class Initialized
DEBUG - 2024-08-07 21:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:44:30 --> Input Class Initialized
INFO - 2024-08-07 21:44:30 --> Language Class Initialized
INFO - 2024-08-07 21:44:30 --> Language Class Initialized
INFO - 2024-08-07 21:44:30 --> Config Class Initialized
INFO - 2024-08-07 21:44:30 --> Loader Class Initialized
INFO - 2024-08-07 21:44:30 --> Helper loaded: url_helper
INFO - 2024-08-07 21:44:30 --> Helper loaded: file_helper
INFO - 2024-08-07 21:44:30 --> Helper loaded: form_helper
INFO - 2024-08-07 21:44:30 --> Helper loaded: my_helper
INFO - 2024-08-07 21:44:30 --> Database Driver Class Initialized
INFO - 2024-08-07 21:44:47 --> Config Class Initialized
INFO - 2024-08-07 21:44:47 --> Hooks Class Initialized
DEBUG - 2024-08-07 21:44:47 --> UTF-8 Support Enabled
INFO - 2024-08-07 21:44:47 --> Utf8 Class Initialized
INFO - 2024-08-07 21:44:47 --> URI Class Initialized
INFO - 2024-08-07 21:44:47 --> Router Class Initialized
INFO - 2024-08-07 21:44:47 --> Output Class Initialized
INFO - 2024-08-07 21:44:47 --> Security Class Initialized
DEBUG - 2024-08-07 21:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-07 21:44:47 --> Input Class Initialized
INFO - 2024-08-07 21:44:47 --> Language Class Initialized
INFO - 2024-08-07 21:44:48 --> Language Class Initialized
INFO - 2024-08-07 21:44:48 --> Config Class Initialized
INFO - 2024-08-07 21:44:48 --> Loader Class Initialized
INFO - 2024-08-07 21:44:48 --> Helper loaded: url_helper
INFO - 2024-08-07 21:44:48 --> Helper loaded: file_helper
INFO - 2024-08-07 21:44:48 --> Helper loaded: form_helper
INFO - 2024-08-07 21:44:48 --> Helper loaded: my_helper
INFO - 2024-08-07 21:44:48 --> Database Driver Class Initialized
INFO - 2024-08-07 21:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:46:57 --> Controller Class Initialized
INFO - 2024-08-07 21:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:46:57 --> Controller Class Initialized
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-07 21:46:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-07 21:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-07 21:46:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-07 21:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-07 21:52:43 --> Controller Class Initialized
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-07 21:52:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-07 21:52:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
