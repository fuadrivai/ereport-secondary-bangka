<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-07 11:27:20 --> Config Class Initialized
INFO - 2023-10-07 11:27:20 --> Hooks Class Initialized
DEBUG - 2023-10-07 11:27:20 --> UTF-8 Support Enabled
INFO - 2023-10-07 11:27:20 --> Utf8 Class Initialized
INFO - 2023-10-07 11:27:20 --> URI Class Initialized
INFO - 2023-10-07 11:27:20 --> Router Class Initialized
INFO - 2023-10-07 11:27:20 --> Output Class Initialized
INFO - 2023-10-07 11:27:20 --> Security Class Initialized
DEBUG - 2023-10-07 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-07 11:27:20 --> Input Class Initialized
INFO - 2023-10-07 11:27:20 --> Language Class Initialized
INFO - 2023-10-07 11:27:20 --> Language Class Initialized
INFO - 2023-10-07 11:27:20 --> Config Class Initialized
INFO - 2023-10-07 11:27:20 --> Loader Class Initialized
INFO - 2023-10-07 11:27:20 --> Helper loaded: url_helper
INFO - 2023-10-07 11:27:20 --> Helper loaded: file_helper
INFO - 2023-10-07 11:27:20 --> Helper loaded: form_helper
INFO - 2023-10-07 11:27:20 --> Helper loaded: my_helper
INFO - 2023-10-07 11:27:20 --> Database Driver Class Initialized
INFO - 2023-10-07 11:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-07 11:27:20 --> Controller Class Initialized
ERROR - 2023-10-07 11:27:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2023-10-07 11:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-07 11:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-07 11:27:21 --> Final output sent to browser
DEBUG - 2023-10-07 11:27:21 --> Total execution time: 0.1426
