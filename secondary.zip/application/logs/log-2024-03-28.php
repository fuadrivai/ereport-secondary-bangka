<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-28 08:11:49 --> Config Class Initialized
INFO - 2024-03-28 08:11:49 --> Hooks Class Initialized
DEBUG - 2024-03-28 08:11:49 --> UTF-8 Support Enabled
INFO - 2024-03-28 08:11:49 --> Utf8 Class Initialized
INFO - 2024-03-28 08:11:49 --> URI Class Initialized
INFO - 2024-03-28 08:11:49 --> Router Class Initialized
INFO - 2024-03-28 08:11:49 --> Output Class Initialized
INFO - 2024-03-28 08:11:49 --> Security Class Initialized
DEBUG - 2024-03-28 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 08:11:49 --> Input Class Initialized
INFO - 2024-03-28 08:11:49 --> Language Class Initialized
INFO - 2024-03-28 08:11:49 --> Language Class Initialized
INFO - 2024-03-28 08:11:49 --> Config Class Initialized
INFO - 2024-03-28 08:11:49 --> Loader Class Initialized
INFO - 2024-03-28 08:11:49 --> Helper loaded: url_helper
INFO - 2024-03-28 08:11:49 --> Helper loaded: file_helper
INFO - 2024-03-28 08:11:49 --> Helper loaded: form_helper
INFO - 2024-03-28 08:11:49 --> Helper loaded: my_helper
INFO - 2024-03-28 08:11:49 --> Database Driver Class Initialized
INFO - 2024-03-28 08:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 08:11:49 --> Controller Class Initialized
DEBUG - 2024-03-28 08:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-28 08:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 08:11:49 --> Final output sent to browser
DEBUG - 2024-03-28 08:11:49 --> Total execution time: 0.0632
INFO - 2024-03-28 09:27:29 --> Config Class Initialized
INFO - 2024-03-28 09:27:29 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:27:29 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:27:29 --> Utf8 Class Initialized
INFO - 2024-03-28 09:27:29 --> URI Class Initialized
INFO - 2024-03-28 09:27:29 --> Router Class Initialized
INFO - 2024-03-28 09:27:29 --> Output Class Initialized
INFO - 2024-03-28 09:27:29 --> Security Class Initialized
DEBUG - 2024-03-28 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:27:29 --> Input Class Initialized
INFO - 2024-03-28 09:27:29 --> Language Class Initialized
INFO - 2024-03-28 09:27:29 --> Language Class Initialized
INFO - 2024-03-28 09:27:29 --> Config Class Initialized
INFO - 2024-03-28 09:27:29 --> Loader Class Initialized
INFO - 2024-03-28 09:27:29 --> Helper loaded: url_helper
INFO - 2024-03-28 09:27:29 --> Helper loaded: file_helper
INFO - 2024-03-28 09:27:29 --> Helper loaded: form_helper
INFO - 2024-03-28 09:27:29 --> Helper loaded: my_helper
INFO - 2024-03-28 09:27:29 --> Database Driver Class Initialized
INFO - 2024-03-28 09:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:27:29 --> Controller Class Initialized
DEBUG - 2024-03-28 09:27:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-28 09:27:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 09:27:29 --> Final output sent to browser
DEBUG - 2024-03-28 09:27:29 --> Total execution time: 0.0472
INFO - 2024-03-28 09:29:59 --> Config Class Initialized
INFO - 2024-03-28 09:29:59 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:29:59 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:29:59 --> Utf8 Class Initialized
INFO - 2024-03-28 09:29:59 --> URI Class Initialized
INFO - 2024-03-28 09:29:59 --> Router Class Initialized
INFO - 2024-03-28 09:29:59 --> Output Class Initialized
INFO - 2024-03-28 09:29:59 --> Security Class Initialized
DEBUG - 2024-03-28 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:29:59 --> Input Class Initialized
INFO - 2024-03-28 09:29:59 --> Language Class Initialized
INFO - 2024-03-28 09:29:59 --> Language Class Initialized
INFO - 2024-03-28 09:29:59 --> Config Class Initialized
INFO - 2024-03-28 09:29:59 --> Loader Class Initialized
INFO - 2024-03-28 09:29:59 --> Helper loaded: url_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: file_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: form_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: my_helper
INFO - 2024-03-28 09:29:59 --> Database Driver Class Initialized
INFO - 2024-03-28 09:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:29:59 --> Controller Class Initialized
INFO - 2024-03-28 09:29:59 --> Helper loaded: cookie_helper
INFO - 2024-03-28 09:29:59 --> Final output sent to browser
DEBUG - 2024-03-28 09:29:59 --> Total execution time: 0.0640
INFO - 2024-03-28 09:29:59 --> Config Class Initialized
INFO - 2024-03-28 09:29:59 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:29:59 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:29:59 --> Utf8 Class Initialized
INFO - 2024-03-28 09:29:59 --> URI Class Initialized
INFO - 2024-03-28 09:29:59 --> Router Class Initialized
INFO - 2024-03-28 09:29:59 --> Output Class Initialized
INFO - 2024-03-28 09:29:59 --> Security Class Initialized
DEBUG - 2024-03-28 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:29:59 --> Input Class Initialized
INFO - 2024-03-28 09:29:59 --> Language Class Initialized
INFO - 2024-03-28 09:29:59 --> Language Class Initialized
INFO - 2024-03-28 09:29:59 --> Config Class Initialized
INFO - 2024-03-28 09:29:59 --> Loader Class Initialized
INFO - 2024-03-28 09:29:59 --> Helper loaded: url_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: file_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: form_helper
INFO - 2024-03-28 09:29:59 --> Helper loaded: my_helper
INFO - 2024-03-28 09:29:59 --> Database Driver Class Initialized
INFO - 2024-03-28 09:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:29:59 --> Controller Class Initialized
DEBUG - 2024-03-28 09:29:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-28 09:29:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 09:29:59 --> Final output sent to browser
DEBUG - 2024-03-28 09:29:59 --> Total execution time: 0.0340
INFO - 2024-03-28 09:30:01 --> Config Class Initialized
INFO - 2024-03-28 09:30:01 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:30:01 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:30:01 --> Utf8 Class Initialized
INFO - 2024-03-28 09:30:01 --> URI Class Initialized
INFO - 2024-03-28 09:30:01 --> Router Class Initialized
INFO - 2024-03-28 09:30:01 --> Output Class Initialized
INFO - 2024-03-28 09:30:01 --> Security Class Initialized
DEBUG - 2024-03-28 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:30:01 --> Input Class Initialized
INFO - 2024-03-28 09:30:01 --> Language Class Initialized
INFO - 2024-03-28 09:30:01 --> Language Class Initialized
INFO - 2024-03-28 09:30:01 --> Config Class Initialized
INFO - 2024-03-28 09:30:01 --> Loader Class Initialized
INFO - 2024-03-28 09:30:01 --> Helper loaded: url_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: file_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: form_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: my_helper
INFO - 2024-03-28 09:30:01 --> Config Class Initialized
INFO - 2024-03-28 09:30:01 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:30:01 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:30:01 --> Utf8 Class Initialized
INFO - 2024-03-28 09:30:01 --> URI Class Initialized
INFO - 2024-03-28 09:30:01 --> Database Driver Class Initialized
INFO - 2024-03-28 09:30:01 --> Router Class Initialized
INFO - 2024-03-28 09:30:01 --> Output Class Initialized
INFO - 2024-03-28 09:30:01 --> Security Class Initialized
DEBUG - 2024-03-28 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:30:01 --> Input Class Initialized
INFO - 2024-03-28 09:30:01 --> Language Class Initialized
INFO - 2024-03-28 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:30:01 --> Controller Class Initialized
DEBUG - 2024-03-28 09:30:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-28 09:30:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 09:30:01 --> Final output sent to browser
DEBUG - 2024-03-28 09:30:01 --> Total execution time: 0.4662
INFO - 2024-03-28 09:30:01 --> Language Class Initialized
INFO - 2024-03-28 09:30:01 --> Config Class Initialized
INFO - 2024-03-28 09:30:01 --> Loader Class Initialized
INFO - 2024-03-28 09:30:01 --> Helper loaded: url_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: file_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: form_helper
INFO - 2024-03-28 09:30:01 --> Helper loaded: my_helper
INFO - 2024-03-28 09:30:01 --> Database Driver Class Initialized
INFO - 2024-03-28 09:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:30:02 --> Controller Class Initialized
DEBUG - 2024-03-28 09:30:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-28 09:30:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 09:30:02 --> Final output sent to browser
DEBUG - 2024-03-28 09:30:02 --> Total execution time: 0.7838
INFO - 2024-03-28 09:30:02 --> Config Class Initialized
INFO - 2024-03-28 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:30:02 --> Utf8 Class Initialized
INFO - 2024-03-28 09:30:02 --> URI Class Initialized
INFO - 2024-03-28 09:30:02 --> Router Class Initialized
INFO - 2024-03-28 09:30:02 --> Output Class Initialized
INFO - 2024-03-28 09:30:02 --> Security Class Initialized
DEBUG - 2024-03-28 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:30:02 --> Input Class Initialized
INFO - 2024-03-28 09:30:02 --> Language Class Initialized
INFO - 2024-03-28 09:30:03 --> Language Class Initialized
INFO - 2024-03-28 09:30:03 --> Config Class Initialized
INFO - 2024-03-28 09:30:03 --> Loader Class Initialized
INFO - 2024-03-28 09:30:03 --> Helper loaded: url_helper
INFO - 2024-03-28 09:30:03 --> Helper loaded: file_helper
INFO - 2024-03-28 09:30:03 --> Helper loaded: form_helper
INFO - 2024-03-28 09:30:03 --> Helper loaded: my_helper
INFO - 2024-03-28 09:30:03 --> Database Driver Class Initialized
INFO - 2024-03-28 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:30:03 --> Controller Class Initialized
DEBUG - 2024-03-28 09:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-03-28 09:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 09:30:03 --> Final output sent to browser
DEBUG - 2024-03-28 09:30:03 --> Total execution time: 1.2290
INFO - 2024-03-28 09:30:26 --> Config Class Initialized
INFO - 2024-03-28 09:30:26 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:30:26 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:30:26 --> Utf8 Class Initialized
INFO - 2024-03-28 09:30:26 --> URI Class Initialized
INFO - 2024-03-28 09:30:26 --> Router Class Initialized
INFO - 2024-03-28 09:30:26 --> Output Class Initialized
INFO - 2024-03-28 09:30:26 --> Security Class Initialized
DEBUG - 2024-03-28 09:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:30:26 --> Input Class Initialized
INFO - 2024-03-28 09:30:26 --> Language Class Initialized
INFO - 2024-03-28 09:30:26 --> Language Class Initialized
INFO - 2024-03-28 09:30:26 --> Config Class Initialized
INFO - 2024-03-28 09:30:26 --> Loader Class Initialized
INFO - 2024-03-28 09:30:26 --> Helper loaded: url_helper
INFO - 2024-03-28 09:30:26 --> Helper loaded: file_helper
INFO - 2024-03-28 09:30:26 --> Helper loaded: form_helper
INFO - 2024-03-28 09:30:26 --> Helper loaded: my_helper
INFO - 2024-03-28 09:30:26 --> Database Driver Class Initialized
INFO - 2024-03-28 09:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:30:26 --> Controller Class Initialized
DEBUG - 2024-03-28 09:30:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-28 09:30:26 --> Final output sent to browser
DEBUG - 2024-03-28 09:30:26 --> Total execution time: 0.1524
INFO - 2024-03-28 09:31:13 --> Config Class Initialized
INFO - 2024-03-28 09:31:13 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:31:13 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:31:13 --> Utf8 Class Initialized
INFO - 2024-03-28 09:31:13 --> URI Class Initialized
INFO - 2024-03-28 09:31:13 --> Router Class Initialized
INFO - 2024-03-28 09:31:13 --> Output Class Initialized
INFO - 2024-03-28 09:31:13 --> Security Class Initialized
DEBUG - 2024-03-28 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:31:13 --> Input Class Initialized
INFO - 2024-03-28 09:31:13 --> Language Class Initialized
INFO - 2024-03-28 09:31:13 --> Language Class Initialized
INFO - 2024-03-28 09:31:13 --> Config Class Initialized
INFO - 2024-03-28 09:31:13 --> Loader Class Initialized
INFO - 2024-03-28 09:31:13 --> Helper loaded: url_helper
INFO - 2024-03-28 09:31:13 --> Helper loaded: file_helper
INFO - 2024-03-28 09:31:13 --> Helper loaded: form_helper
INFO - 2024-03-28 09:31:13 --> Helper loaded: my_helper
INFO - 2024-03-28 09:31:13 --> Database Driver Class Initialized
INFO - 2024-03-28 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:31:14 --> Controller Class Initialized
DEBUG - 2024-03-28 09:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-28 09:31:14 --> Final output sent to browser
DEBUG - 2024-03-28 09:31:14 --> Total execution time: 0.0408
INFO - 2024-03-28 09:31:50 --> Config Class Initialized
INFO - 2024-03-28 09:31:50 --> Hooks Class Initialized
DEBUG - 2024-03-28 09:31:50 --> UTF-8 Support Enabled
INFO - 2024-03-28 09:31:50 --> Utf8 Class Initialized
INFO - 2024-03-28 09:31:50 --> URI Class Initialized
INFO - 2024-03-28 09:31:50 --> Router Class Initialized
INFO - 2024-03-28 09:31:50 --> Output Class Initialized
INFO - 2024-03-28 09:31:50 --> Security Class Initialized
DEBUG - 2024-03-28 09:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 09:31:50 --> Input Class Initialized
INFO - 2024-03-28 09:31:50 --> Language Class Initialized
INFO - 2024-03-28 09:31:50 --> Language Class Initialized
INFO - 2024-03-28 09:31:50 --> Config Class Initialized
INFO - 2024-03-28 09:31:50 --> Loader Class Initialized
INFO - 2024-03-28 09:31:50 --> Helper loaded: url_helper
INFO - 2024-03-28 09:31:50 --> Helper loaded: file_helper
INFO - 2024-03-28 09:31:50 --> Helper loaded: form_helper
INFO - 2024-03-28 09:31:50 --> Helper loaded: my_helper
INFO - 2024-03-28 09:31:50 --> Database Driver Class Initialized
INFO - 2024-03-28 09:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 09:31:50 --> Controller Class Initialized
DEBUG - 2024-03-28 09:31:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-28 09:31:50 --> Final output sent to browser
DEBUG - 2024-03-28 09:31:50 --> Total execution time: 0.1021
INFO - 2024-03-28 14:45:46 --> Config Class Initialized
INFO - 2024-03-28 14:45:46 --> Hooks Class Initialized
DEBUG - 2024-03-28 14:45:46 --> UTF-8 Support Enabled
INFO - 2024-03-28 14:45:46 --> Utf8 Class Initialized
INFO - 2024-03-28 14:45:46 --> URI Class Initialized
INFO - 2024-03-28 14:45:46 --> Router Class Initialized
INFO - 2024-03-28 14:45:46 --> Output Class Initialized
INFO - 2024-03-28 14:45:46 --> Security Class Initialized
DEBUG - 2024-03-28 14:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-28 14:45:46 --> Input Class Initialized
INFO - 2024-03-28 14:45:46 --> Language Class Initialized
INFO - 2024-03-28 14:45:46 --> Language Class Initialized
INFO - 2024-03-28 14:45:46 --> Config Class Initialized
INFO - 2024-03-28 14:45:46 --> Loader Class Initialized
INFO - 2024-03-28 14:45:46 --> Helper loaded: url_helper
INFO - 2024-03-28 14:45:46 --> Helper loaded: file_helper
INFO - 2024-03-28 14:45:46 --> Helper loaded: form_helper
INFO - 2024-03-28 14:45:46 --> Helper loaded: my_helper
INFO - 2024-03-28 14:45:46 --> Database Driver Class Initialized
INFO - 2024-03-28 14:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-28 14:45:46 --> Controller Class Initialized
DEBUG - 2024-03-28 14:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-28 14:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-28 14:45:46 --> Final output sent to browser
DEBUG - 2024-03-28 14:45:46 --> Total execution time: 0.0687
