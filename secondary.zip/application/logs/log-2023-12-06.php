<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-06 08:51:44 --> Config Class Initialized
INFO - 2023-12-06 08:51:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:51:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:51:44 --> Utf8 Class Initialized
INFO - 2023-12-06 08:51:44 --> URI Class Initialized
INFO - 2023-12-06 08:51:44 --> Router Class Initialized
INFO - 2023-12-06 08:51:44 --> Output Class Initialized
INFO - 2023-12-06 08:51:44 --> Security Class Initialized
DEBUG - 2023-12-06 08:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:51:44 --> Input Class Initialized
INFO - 2023-12-06 08:51:44 --> Language Class Initialized
INFO - 2023-12-06 08:51:44 --> Language Class Initialized
INFO - 2023-12-06 08:51:44 --> Config Class Initialized
INFO - 2023-12-06 08:51:44 --> Loader Class Initialized
INFO - 2023-12-06 08:51:44 --> Helper loaded: url_helper
INFO - 2023-12-06 08:51:44 --> Helper loaded: file_helper
INFO - 2023-12-06 08:51:44 --> Helper loaded: form_helper
INFO - 2023-12-06 08:51:44 --> Helper loaded: my_helper
INFO - 2023-12-06 08:51:44 --> Database Driver Class Initialized
INFO - 2023-12-06 08:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:51:44 --> Controller Class Initialized
DEBUG - 2023-12-06 08:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 08:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:51:44 --> Final output sent to browser
DEBUG - 2023-12-06 08:51:44 --> Total execution time: 0.0695
INFO - 2023-12-06 08:51:49 --> Config Class Initialized
INFO - 2023-12-06 08:51:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:51:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:51:49 --> Utf8 Class Initialized
INFO - 2023-12-06 08:51:49 --> URI Class Initialized
INFO - 2023-12-06 08:51:49 --> Router Class Initialized
INFO - 2023-12-06 08:51:49 --> Output Class Initialized
INFO - 2023-12-06 08:51:49 --> Security Class Initialized
DEBUG - 2023-12-06 08:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:51:49 --> Input Class Initialized
INFO - 2023-12-06 08:51:49 --> Language Class Initialized
INFO - 2023-12-06 08:51:49 --> Language Class Initialized
INFO - 2023-12-06 08:51:49 --> Config Class Initialized
INFO - 2023-12-06 08:51:49 --> Loader Class Initialized
INFO - 2023-12-06 08:51:49 --> Helper loaded: url_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: file_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: form_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: my_helper
INFO - 2023-12-06 08:51:49 --> Database Driver Class Initialized
INFO - 2023-12-06 08:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:51:49 --> Controller Class Initialized
INFO - 2023-12-06 08:51:49 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:51:49 --> Final output sent to browser
DEBUG - 2023-12-06 08:51:49 --> Total execution time: 0.0344
INFO - 2023-12-06 08:51:49 --> Config Class Initialized
INFO - 2023-12-06 08:51:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:51:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:51:49 --> Utf8 Class Initialized
INFO - 2023-12-06 08:51:49 --> URI Class Initialized
INFO - 2023-12-06 08:51:49 --> Router Class Initialized
INFO - 2023-12-06 08:51:49 --> Output Class Initialized
INFO - 2023-12-06 08:51:49 --> Security Class Initialized
DEBUG - 2023-12-06 08:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:51:49 --> Input Class Initialized
INFO - 2023-12-06 08:51:49 --> Language Class Initialized
INFO - 2023-12-06 08:51:49 --> Language Class Initialized
INFO - 2023-12-06 08:51:49 --> Config Class Initialized
INFO - 2023-12-06 08:51:49 --> Loader Class Initialized
INFO - 2023-12-06 08:51:49 --> Helper loaded: url_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: file_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: form_helper
INFO - 2023-12-06 08:51:49 --> Helper loaded: my_helper
INFO - 2023-12-06 08:51:49 --> Database Driver Class Initialized
INFO - 2023-12-06 08:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:51:49 --> Controller Class Initialized
DEBUG - 2023-12-06 08:51:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 08:51:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:51:49 --> Final output sent to browser
DEBUG - 2023-12-06 08:51:49 --> Total execution time: 0.0339
INFO - 2023-12-06 08:51:51 --> Config Class Initialized
INFO - 2023-12-06 08:51:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:51:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:51:51 --> Utf8 Class Initialized
INFO - 2023-12-06 08:51:51 --> URI Class Initialized
INFO - 2023-12-06 08:51:51 --> Router Class Initialized
INFO - 2023-12-06 08:51:51 --> Output Class Initialized
INFO - 2023-12-06 08:51:51 --> Security Class Initialized
DEBUG - 2023-12-06 08:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:51:51 --> Input Class Initialized
INFO - 2023-12-06 08:51:51 --> Language Class Initialized
INFO - 2023-12-06 08:51:51 --> Language Class Initialized
INFO - 2023-12-06 08:51:51 --> Config Class Initialized
INFO - 2023-12-06 08:51:51 --> Loader Class Initialized
INFO - 2023-12-06 08:51:51 --> Helper loaded: url_helper
INFO - 2023-12-06 08:51:51 --> Helper loaded: file_helper
INFO - 2023-12-06 08:51:51 --> Helper loaded: form_helper
INFO - 2023-12-06 08:51:51 --> Helper loaded: my_helper
INFO - 2023-12-06 08:51:51 --> Database Driver Class Initialized
INFO - 2023-12-06 08:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:51:51 --> Controller Class Initialized
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:51:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 08:51:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 08:51:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:51:51 --> Final output sent to browser
DEBUG - 2023-12-06 08:51:51 --> Total execution time: 0.0408
INFO - 2023-12-06 08:52:05 --> Config Class Initialized
INFO - 2023-12-06 08:52:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:05 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:05 --> URI Class Initialized
INFO - 2023-12-06 08:52:05 --> Router Class Initialized
INFO - 2023-12-06 08:52:05 --> Output Class Initialized
INFO - 2023-12-06 08:52:05 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:05 --> Input Class Initialized
INFO - 2023-12-06 08:52:05 --> Language Class Initialized
INFO - 2023-12-06 08:52:05 --> Language Class Initialized
INFO - 2023-12-06 08:52:05 --> Config Class Initialized
INFO - 2023-12-06 08:52:05 --> Loader Class Initialized
INFO - 2023-12-06 08:52:05 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:05 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:05 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:05 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:05 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:05 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 08:52:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:05 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:05 --> Total execution time: 0.0422
INFO - 2023-12-06 08:52:15 --> Config Class Initialized
INFO - 2023-12-06 08:52:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:15 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:15 --> URI Class Initialized
INFO - 2023-12-06 08:52:15 --> Router Class Initialized
INFO - 2023-12-06 08:52:15 --> Output Class Initialized
INFO - 2023-12-06 08:52:15 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:15 --> Input Class Initialized
INFO - 2023-12-06 08:52:15 --> Language Class Initialized
INFO - 2023-12-06 08:52:15 --> Language Class Initialized
INFO - 2023-12-06 08:52:15 --> Config Class Initialized
INFO - 2023-12-06 08:52:15 --> Loader Class Initialized
INFO - 2023-12-06 08:52:15 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:15 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:15 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:15 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:15 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:15 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 08:52:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:15 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:15 --> Total execution time: 0.0398
INFO - 2023-12-06 08:52:16 --> Config Class Initialized
INFO - 2023-12-06 08:52:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:16 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:16 --> URI Class Initialized
INFO - 2023-12-06 08:52:16 --> Router Class Initialized
INFO - 2023-12-06 08:52:16 --> Output Class Initialized
INFO - 2023-12-06 08:52:16 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:16 --> Input Class Initialized
INFO - 2023-12-06 08:52:16 --> Language Class Initialized
INFO - 2023-12-06 08:52:16 --> Language Class Initialized
INFO - 2023-12-06 08:52:16 --> Config Class Initialized
INFO - 2023-12-06 08:52:16 --> Loader Class Initialized
INFO - 2023-12-06 08:52:16 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:16 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:16 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:16 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:16 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:16 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-06 08:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:16 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:16 --> Total execution time: 0.0931
INFO - 2023-12-06 08:52:22 --> Config Class Initialized
INFO - 2023-12-06 08:52:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:22 --> URI Class Initialized
INFO - 2023-12-06 08:52:22 --> Router Class Initialized
INFO - 2023-12-06 08:52:22 --> Output Class Initialized
INFO - 2023-12-06 08:52:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:22 --> Input Class Initialized
INFO - 2023-12-06 08:52:22 --> Language Class Initialized
INFO - 2023-12-06 08:52:22 --> Language Class Initialized
INFO - 2023-12-06 08:52:22 --> Config Class Initialized
INFO - 2023-12-06 08:52:22 --> Loader Class Initialized
INFO - 2023-12-06 08:52:22 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:22 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:22 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:22 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:22 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:22 --> Controller Class Initialized
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 08:52:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 08:52:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:22 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:22 --> Total execution time: 0.0418
INFO - 2023-12-06 08:52:30 --> Config Class Initialized
INFO - 2023-12-06 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:30 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:30 --> URI Class Initialized
INFO - 2023-12-06 08:52:30 --> Router Class Initialized
INFO - 2023-12-06 08:52:30 --> Output Class Initialized
INFO - 2023-12-06 08:52:30 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:30 --> Input Class Initialized
INFO - 2023-12-06 08:52:30 --> Language Class Initialized
INFO - 2023-12-06 08:52:30 --> Language Class Initialized
INFO - 2023-12-06 08:52:30 --> Config Class Initialized
INFO - 2023-12-06 08:52:30 --> Loader Class Initialized
INFO - 2023-12-06 08:52:30 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:30 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:30 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 08:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:30 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:30 --> Total execution time: 0.0612
INFO - 2023-12-06 08:52:30 --> Config Class Initialized
INFO - 2023-12-06 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:30 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:30 --> URI Class Initialized
INFO - 2023-12-06 08:52:30 --> Router Class Initialized
INFO - 2023-12-06 08:52:30 --> Output Class Initialized
INFO - 2023-12-06 08:52:30 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:30 --> Input Class Initialized
INFO - 2023-12-06 08:52:30 --> Language Class Initialized
INFO - 2023-12-06 08:52:30 --> Language Class Initialized
INFO - 2023-12-06 08:52:30 --> Config Class Initialized
INFO - 2023-12-06 08:52:30 --> Loader Class Initialized
INFO - 2023-12-06 08:52:30 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:30 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:30 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:30 --> Controller Class Initialized
INFO - 2023-12-06 08:52:35 --> Config Class Initialized
INFO - 2023-12-06 08:52:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:35 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:35 --> URI Class Initialized
INFO - 2023-12-06 08:52:35 --> Router Class Initialized
INFO - 2023-12-06 08:52:35 --> Output Class Initialized
INFO - 2023-12-06 08:52:35 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:35 --> Input Class Initialized
INFO - 2023-12-06 08:52:35 --> Language Class Initialized
INFO - 2023-12-06 08:52:35 --> Language Class Initialized
INFO - 2023-12-06 08:52:35 --> Config Class Initialized
INFO - 2023-12-06 08:52:35 --> Loader Class Initialized
INFO - 2023-12-06 08:52:35 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:35 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:35 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:35 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:35 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:35 --> Controller Class Initialized
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:52:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 08:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 08:52:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:35 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:35 --> Total execution time: 0.0478
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:47 --> URI Class Initialized
INFO - 2023-12-06 08:52:47 --> Router Class Initialized
INFO - 2023-12-06 08:52:47 --> Output Class Initialized
INFO - 2023-12-06 08:52:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:47 --> Input Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Loader Class Initialized
INFO - 2023-12-06 08:52:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:47 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:47 --> Controller Class Initialized
INFO - 2023-12-06 08:52:47 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:47 --> URI Class Initialized
INFO - 2023-12-06 08:52:47 --> Router Class Initialized
INFO - 2023-12-06 08:52:47 --> Output Class Initialized
INFO - 2023-12-06 08:52:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:47 --> Input Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Loader Class Initialized
INFO - 2023-12-06 08:52:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:47 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:47 --> Controller Class Initialized
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:47 --> URI Class Initialized
INFO - 2023-12-06 08:52:47 --> Router Class Initialized
INFO - 2023-12-06 08:52:47 --> Output Class Initialized
INFO - 2023-12-06 08:52:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:47 --> Input Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Language Class Initialized
INFO - 2023-12-06 08:52:47 --> Config Class Initialized
INFO - 2023-12-06 08:52:47 --> Loader Class Initialized
INFO - 2023-12-06 08:52:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:47 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:47 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 08:52:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:47 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:47 --> Total execution time: 0.0332
INFO - 2023-12-06 08:52:52 --> Config Class Initialized
INFO - 2023-12-06 08:52:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:52 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:52 --> URI Class Initialized
INFO - 2023-12-06 08:52:52 --> Router Class Initialized
INFO - 2023-12-06 08:52:52 --> Output Class Initialized
INFO - 2023-12-06 08:52:52 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:52 --> Input Class Initialized
INFO - 2023-12-06 08:52:52 --> Language Class Initialized
INFO - 2023-12-06 08:52:52 --> Language Class Initialized
INFO - 2023-12-06 08:52:52 --> Config Class Initialized
INFO - 2023-12-06 08:52:52 --> Loader Class Initialized
INFO - 2023-12-06 08:52:52 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:52 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:52 --> Controller Class Initialized
INFO - 2023-12-06 08:52:52 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:52:52 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:52 --> Total execution time: 0.0684
INFO - 2023-12-06 08:52:52 --> Config Class Initialized
INFO - 2023-12-06 08:52:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:52:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:52:52 --> Utf8 Class Initialized
INFO - 2023-12-06 08:52:52 --> URI Class Initialized
INFO - 2023-12-06 08:52:52 --> Router Class Initialized
INFO - 2023-12-06 08:52:52 --> Output Class Initialized
INFO - 2023-12-06 08:52:52 --> Security Class Initialized
DEBUG - 2023-12-06 08:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:52:52 --> Input Class Initialized
INFO - 2023-12-06 08:52:52 --> Language Class Initialized
INFO - 2023-12-06 08:52:52 --> Language Class Initialized
INFO - 2023-12-06 08:52:52 --> Config Class Initialized
INFO - 2023-12-06 08:52:52 --> Loader Class Initialized
INFO - 2023-12-06 08:52:52 --> Helper loaded: url_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: file_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: form_helper
INFO - 2023-12-06 08:52:52 --> Helper loaded: my_helper
INFO - 2023-12-06 08:52:52 --> Database Driver Class Initialized
INFO - 2023-12-06 08:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:52:52 --> Controller Class Initialized
DEBUG - 2023-12-06 08:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 08:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:52:52 --> Final output sent to browser
DEBUG - 2023-12-06 08:52:52 --> Total execution time: 0.0840
INFO - 2023-12-06 08:53:03 --> Config Class Initialized
INFO - 2023-12-06 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:03 --> URI Class Initialized
INFO - 2023-12-06 08:53:03 --> Router Class Initialized
INFO - 2023-12-06 08:53:03 --> Output Class Initialized
INFO - 2023-12-06 08:53:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:03 --> Input Class Initialized
INFO - 2023-12-06 08:53:03 --> Language Class Initialized
INFO - 2023-12-06 08:53:03 --> Language Class Initialized
INFO - 2023-12-06 08:53:03 --> Config Class Initialized
INFO - 2023-12-06 08:53:03 --> Loader Class Initialized
INFO - 2023-12-06 08:53:03 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:03 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:03 --> Controller Class Initialized
DEBUG - 2023-12-06 08:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-06 08:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:53:03 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:03 --> Total execution time: 0.0494
INFO - 2023-12-06 08:53:03 --> Config Class Initialized
INFO - 2023-12-06 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:03 --> URI Class Initialized
INFO - 2023-12-06 08:53:03 --> Router Class Initialized
INFO - 2023-12-06 08:53:03 --> Output Class Initialized
INFO - 2023-12-06 08:53:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:03 --> Input Class Initialized
INFO - 2023-12-06 08:53:03 --> Language Class Initialized
ERROR - 2023-12-06 08:53:03 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:53:03 --> Config Class Initialized
INFO - 2023-12-06 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:03 --> URI Class Initialized
INFO - 2023-12-06 08:53:03 --> Router Class Initialized
INFO - 2023-12-06 08:53:03 --> Output Class Initialized
INFO - 2023-12-06 08:53:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:03 --> Input Class Initialized
INFO - 2023-12-06 08:53:03 --> Language Class Initialized
INFO - 2023-12-06 08:53:03 --> Language Class Initialized
INFO - 2023-12-06 08:53:03 --> Config Class Initialized
INFO - 2023-12-06 08:53:03 --> Loader Class Initialized
INFO - 2023-12-06 08:53:03 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:03 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:03 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:03 --> Controller Class Initialized
INFO - 2023-12-06 08:53:07 --> Config Class Initialized
INFO - 2023-12-06 08:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:07 --> URI Class Initialized
INFO - 2023-12-06 08:53:07 --> Router Class Initialized
INFO - 2023-12-06 08:53:07 --> Output Class Initialized
INFO - 2023-12-06 08:53:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:07 --> Input Class Initialized
INFO - 2023-12-06 08:53:07 --> Language Class Initialized
INFO - 2023-12-06 08:53:07 --> Language Class Initialized
INFO - 2023-12-06 08:53:07 --> Config Class Initialized
INFO - 2023-12-06 08:53:07 --> Loader Class Initialized
INFO - 2023-12-06 08:53:07 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:07 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:07 --> Controller Class Initialized
DEBUG - 2023-12-06 08:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2023-12-06 08:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:53:07 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:07 --> Total execution time: 0.0352
INFO - 2023-12-06 08:53:07 --> Config Class Initialized
INFO - 2023-12-06 08:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:07 --> URI Class Initialized
INFO - 2023-12-06 08:53:07 --> Router Class Initialized
INFO - 2023-12-06 08:53:07 --> Output Class Initialized
INFO - 2023-12-06 08:53:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:07 --> Input Class Initialized
INFO - 2023-12-06 08:53:07 --> Language Class Initialized
ERROR - 2023-12-06 08:53:07 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:53:07 --> Config Class Initialized
INFO - 2023-12-06 08:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:07 --> URI Class Initialized
INFO - 2023-12-06 08:53:07 --> Router Class Initialized
INFO - 2023-12-06 08:53:07 --> Output Class Initialized
INFO - 2023-12-06 08:53:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:07 --> Input Class Initialized
INFO - 2023-12-06 08:53:07 --> Language Class Initialized
INFO - 2023-12-06 08:53:07 --> Language Class Initialized
INFO - 2023-12-06 08:53:07 --> Config Class Initialized
INFO - 2023-12-06 08:53:07 --> Loader Class Initialized
INFO - 2023-12-06 08:53:07 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:07 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:07 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:07 --> Controller Class Initialized
INFO - 2023-12-06 08:53:13 --> Config Class Initialized
INFO - 2023-12-06 08:53:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:13 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:13 --> URI Class Initialized
INFO - 2023-12-06 08:53:13 --> Router Class Initialized
INFO - 2023-12-06 08:53:13 --> Output Class Initialized
INFO - 2023-12-06 08:53:13 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:13 --> Input Class Initialized
INFO - 2023-12-06 08:53:13 --> Language Class Initialized
INFO - 2023-12-06 08:53:13 --> Language Class Initialized
INFO - 2023-12-06 08:53:13 --> Config Class Initialized
INFO - 2023-12-06 08:53:13 --> Loader Class Initialized
INFO - 2023-12-06 08:53:13 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:13 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:13 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:13 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:13 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:13 --> Controller Class Initialized
INFO - 2023-12-06 08:53:13 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:13 --> Total execution time: 0.0384
INFO - 2023-12-06 08:53:47 --> Config Class Initialized
INFO - 2023-12-06 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:47 --> URI Class Initialized
INFO - 2023-12-06 08:53:47 --> Router Class Initialized
INFO - 2023-12-06 08:53:47 --> Output Class Initialized
INFO - 2023-12-06 08:53:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:47 --> Input Class Initialized
INFO - 2023-12-06 08:53:47 --> Language Class Initialized
INFO - 2023-12-06 08:53:47 --> Language Class Initialized
INFO - 2023-12-06 08:53:47 --> Config Class Initialized
INFO - 2023-12-06 08:53:47 --> Loader Class Initialized
INFO - 2023-12-06 08:53:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:47 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:47 --> Controller Class Initialized
INFO - 2023-12-06 08:53:47 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:47 --> Total execution time: 0.0333
INFO - 2023-12-06 08:53:47 --> Config Class Initialized
INFO - 2023-12-06 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:47 --> URI Class Initialized
INFO - 2023-12-06 08:53:47 --> Router Class Initialized
INFO - 2023-12-06 08:53:47 --> Output Class Initialized
INFO - 2023-12-06 08:53:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:47 --> Input Class Initialized
INFO - 2023-12-06 08:53:47 --> Language Class Initialized
ERROR - 2023-12-06 08:53:47 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:53:47 --> Config Class Initialized
INFO - 2023-12-06 08:53:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:47 --> URI Class Initialized
INFO - 2023-12-06 08:53:47 --> Router Class Initialized
INFO - 2023-12-06 08:53:47 --> Output Class Initialized
INFO - 2023-12-06 08:53:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:47 --> Input Class Initialized
INFO - 2023-12-06 08:53:47 --> Language Class Initialized
INFO - 2023-12-06 08:53:47 --> Language Class Initialized
INFO - 2023-12-06 08:53:47 --> Config Class Initialized
INFO - 2023-12-06 08:53:47 --> Loader Class Initialized
INFO - 2023-12-06 08:53:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:47 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:47 --> Controller Class Initialized
INFO - 2023-12-06 08:53:50 --> Config Class Initialized
INFO - 2023-12-06 08:53:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:50 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:50 --> URI Class Initialized
INFO - 2023-12-06 08:53:50 --> Router Class Initialized
INFO - 2023-12-06 08:53:50 --> Output Class Initialized
INFO - 2023-12-06 08:53:50 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:50 --> Input Class Initialized
INFO - 2023-12-06 08:53:50 --> Language Class Initialized
INFO - 2023-12-06 08:53:50 --> Language Class Initialized
INFO - 2023-12-06 08:53:50 --> Config Class Initialized
INFO - 2023-12-06 08:53:50 --> Loader Class Initialized
INFO - 2023-12-06 08:53:50 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:50 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:50 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:50 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:50 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:50 --> Controller Class Initialized
INFO - 2023-12-06 08:53:50 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:50 --> Total execution time: 0.0597
INFO - 2023-12-06 08:53:59 --> Config Class Initialized
INFO - 2023-12-06 08:53:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:59 --> URI Class Initialized
INFO - 2023-12-06 08:53:59 --> Router Class Initialized
INFO - 2023-12-06 08:53:59 --> Output Class Initialized
INFO - 2023-12-06 08:53:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:59 --> Input Class Initialized
INFO - 2023-12-06 08:53:59 --> Language Class Initialized
INFO - 2023-12-06 08:53:59 --> Language Class Initialized
INFO - 2023-12-06 08:53:59 --> Config Class Initialized
INFO - 2023-12-06 08:53:59 --> Loader Class Initialized
INFO - 2023-12-06 08:53:59 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:59 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:59 --> Controller Class Initialized
INFO - 2023-12-06 08:53:59 --> Final output sent to browser
DEBUG - 2023-12-06 08:53:59 --> Total execution time: 0.0498
INFO - 2023-12-06 08:53:59 --> Config Class Initialized
INFO - 2023-12-06 08:53:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:59 --> URI Class Initialized
INFO - 2023-12-06 08:53:59 --> Router Class Initialized
INFO - 2023-12-06 08:53:59 --> Output Class Initialized
INFO - 2023-12-06 08:53:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:59 --> Input Class Initialized
INFO - 2023-12-06 08:53:59 --> Language Class Initialized
ERROR - 2023-12-06 08:53:59 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:53:59 --> Config Class Initialized
INFO - 2023-12-06 08:53:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:53:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:53:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:53:59 --> URI Class Initialized
INFO - 2023-12-06 08:53:59 --> Router Class Initialized
INFO - 2023-12-06 08:53:59 --> Output Class Initialized
INFO - 2023-12-06 08:53:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:53:59 --> Input Class Initialized
INFO - 2023-12-06 08:53:59 --> Language Class Initialized
INFO - 2023-12-06 08:53:59 --> Language Class Initialized
INFO - 2023-12-06 08:53:59 --> Config Class Initialized
INFO - 2023-12-06 08:53:59 --> Loader Class Initialized
INFO - 2023-12-06 08:53:59 --> Helper loaded: url_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: file_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: form_helper
INFO - 2023-12-06 08:53:59 --> Helper loaded: my_helper
INFO - 2023-12-06 08:53:59 --> Database Driver Class Initialized
INFO - 2023-12-06 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:53:59 --> Controller Class Initialized
INFO - 2023-12-06 08:54:01 --> Config Class Initialized
INFO - 2023-12-06 08:54:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:01 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:01 --> URI Class Initialized
INFO - 2023-12-06 08:54:01 --> Router Class Initialized
INFO - 2023-12-06 08:54:01 --> Output Class Initialized
INFO - 2023-12-06 08:54:01 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:01 --> Input Class Initialized
INFO - 2023-12-06 08:54:01 --> Language Class Initialized
INFO - 2023-12-06 08:54:01 --> Language Class Initialized
INFO - 2023-12-06 08:54:01 --> Config Class Initialized
INFO - 2023-12-06 08:54:01 --> Loader Class Initialized
INFO - 2023-12-06 08:54:01 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:01 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:01 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:01 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:01 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:01 --> Controller Class Initialized
INFO - 2023-12-06 08:54:01 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:01 --> Total execution time: 0.0345
INFO - 2023-12-06 08:54:15 --> Config Class Initialized
INFO - 2023-12-06 08:54:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:15 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:15 --> URI Class Initialized
INFO - 2023-12-06 08:54:15 --> Router Class Initialized
INFO - 2023-12-06 08:54:15 --> Output Class Initialized
INFO - 2023-12-06 08:54:15 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:15 --> Input Class Initialized
INFO - 2023-12-06 08:54:15 --> Language Class Initialized
INFO - 2023-12-06 08:54:15 --> Language Class Initialized
INFO - 2023-12-06 08:54:15 --> Config Class Initialized
INFO - 2023-12-06 08:54:15 --> Loader Class Initialized
INFO - 2023-12-06 08:54:15 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:15 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:15 --> Controller Class Initialized
INFO - 2023-12-06 08:54:15 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:15 --> Total execution time: 0.0497
INFO - 2023-12-06 08:54:15 --> Config Class Initialized
INFO - 2023-12-06 08:54:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:15 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:15 --> URI Class Initialized
INFO - 2023-12-06 08:54:15 --> Router Class Initialized
INFO - 2023-12-06 08:54:15 --> Output Class Initialized
INFO - 2023-12-06 08:54:15 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:15 --> Input Class Initialized
INFO - 2023-12-06 08:54:15 --> Language Class Initialized
ERROR - 2023-12-06 08:54:15 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:54:15 --> Config Class Initialized
INFO - 2023-12-06 08:54:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:15 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:15 --> URI Class Initialized
INFO - 2023-12-06 08:54:15 --> Router Class Initialized
INFO - 2023-12-06 08:54:15 --> Output Class Initialized
INFO - 2023-12-06 08:54:15 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:15 --> Input Class Initialized
INFO - 2023-12-06 08:54:15 --> Language Class Initialized
INFO - 2023-12-06 08:54:15 --> Language Class Initialized
INFO - 2023-12-06 08:54:15 --> Config Class Initialized
INFO - 2023-12-06 08:54:15 --> Loader Class Initialized
INFO - 2023-12-06 08:54:15 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:15 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:15 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:15 --> Controller Class Initialized
INFO - 2023-12-06 08:54:18 --> Config Class Initialized
INFO - 2023-12-06 08:54:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:18 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:18 --> URI Class Initialized
INFO - 2023-12-06 08:54:18 --> Router Class Initialized
INFO - 2023-12-06 08:54:18 --> Output Class Initialized
INFO - 2023-12-06 08:54:18 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:18 --> Input Class Initialized
INFO - 2023-12-06 08:54:18 --> Language Class Initialized
INFO - 2023-12-06 08:54:18 --> Language Class Initialized
INFO - 2023-12-06 08:54:18 --> Config Class Initialized
INFO - 2023-12-06 08:54:18 --> Loader Class Initialized
INFO - 2023-12-06 08:54:18 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:18 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:18 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:18 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:18 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:18 --> Controller Class Initialized
INFO - 2023-12-06 08:54:18 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:18 --> Total execution time: 0.0354
INFO - 2023-12-06 08:54:22 --> Config Class Initialized
INFO - 2023-12-06 08:54:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:22 --> URI Class Initialized
INFO - 2023-12-06 08:54:22 --> Router Class Initialized
INFO - 2023-12-06 08:54:22 --> Output Class Initialized
INFO - 2023-12-06 08:54:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:22 --> Input Class Initialized
INFO - 2023-12-06 08:54:22 --> Language Class Initialized
INFO - 2023-12-06 08:54:22 --> Language Class Initialized
INFO - 2023-12-06 08:54:22 --> Config Class Initialized
INFO - 2023-12-06 08:54:22 --> Loader Class Initialized
INFO - 2023-12-06 08:54:22 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:22 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:22 --> Controller Class Initialized
INFO - 2023-12-06 08:54:22 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:22 --> Total execution time: 0.0389
INFO - 2023-12-06 08:54:22 --> Config Class Initialized
INFO - 2023-12-06 08:54:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:22 --> URI Class Initialized
INFO - 2023-12-06 08:54:22 --> Router Class Initialized
INFO - 2023-12-06 08:54:22 --> Output Class Initialized
INFO - 2023-12-06 08:54:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:22 --> Input Class Initialized
INFO - 2023-12-06 08:54:22 --> Language Class Initialized
ERROR - 2023-12-06 08:54:22 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:54:22 --> Config Class Initialized
INFO - 2023-12-06 08:54:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:22 --> URI Class Initialized
INFO - 2023-12-06 08:54:22 --> Router Class Initialized
INFO - 2023-12-06 08:54:22 --> Output Class Initialized
INFO - 2023-12-06 08:54:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:22 --> Input Class Initialized
INFO - 2023-12-06 08:54:22 --> Language Class Initialized
INFO - 2023-12-06 08:54:22 --> Language Class Initialized
INFO - 2023-12-06 08:54:22 --> Config Class Initialized
INFO - 2023-12-06 08:54:22 --> Loader Class Initialized
INFO - 2023-12-06 08:54:22 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:22 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:22 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:22 --> Controller Class Initialized
INFO - 2023-12-06 08:54:28 --> Config Class Initialized
INFO - 2023-12-06 08:54:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:28 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:28 --> URI Class Initialized
INFO - 2023-12-06 08:54:28 --> Router Class Initialized
INFO - 2023-12-06 08:54:28 --> Output Class Initialized
INFO - 2023-12-06 08:54:28 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:28 --> Input Class Initialized
INFO - 2023-12-06 08:54:28 --> Language Class Initialized
INFO - 2023-12-06 08:54:28 --> Language Class Initialized
INFO - 2023-12-06 08:54:28 --> Config Class Initialized
INFO - 2023-12-06 08:54:28 --> Loader Class Initialized
INFO - 2023-12-06 08:54:28 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:28 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:28 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:28 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:28 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:28 --> Controller Class Initialized
INFO - 2023-12-06 08:54:28 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:28 --> Total execution time: 0.0651
INFO - 2023-12-06 08:54:32 --> Config Class Initialized
INFO - 2023-12-06 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:32 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:32 --> URI Class Initialized
INFO - 2023-12-06 08:54:32 --> Router Class Initialized
INFO - 2023-12-06 08:54:32 --> Output Class Initialized
INFO - 2023-12-06 08:54:32 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:32 --> Input Class Initialized
INFO - 2023-12-06 08:54:32 --> Language Class Initialized
INFO - 2023-12-06 08:54:32 --> Language Class Initialized
INFO - 2023-12-06 08:54:32 --> Config Class Initialized
INFO - 2023-12-06 08:54:32 --> Loader Class Initialized
INFO - 2023-12-06 08:54:32 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:32 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:32 --> Controller Class Initialized
INFO - 2023-12-06 08:54:32 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:32 --> Total execution time: 0.0483
INFO - 2023-12-06 08:54:32 --> Config Class Initialized
INFO - 2023-12-06 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:32 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:32 --> URI Class Initialized
INFO - 2023-12-06 08:54:32 --> Router Class Initialized
INFO - 2023-12-06 08:54:32 --> Output Class Initialized
INFO - 2023-12-06 08:54:32 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:32 --> Input Class Initialized
INFO - 2023-12-06 08:54:32 --> Language Class Initialized
ERROR - 2023-12-06 08:54:32 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:54:32 --> Config Class Initialized
INFO - 2023-12-06 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:32 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:32 --> URI Class Initialized
INFO - 2023-12-06 08:54:32 --> Router Class Initialized
INFO - 2023-12-06 08:54:32 --> Output Class Initialized
INFO - 2023-12-06 08:54:32 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:32 --> Input Class Initialized
INFO - 2023-12-06 08:54:32 --> Language Class Initialized
INFO - 2023-12-06 08:54:32 --> Language Class Initialized
INFO - 2023-12-06 08:54:32 --> Config Class Initialized
INFO - 2023-12-06 08:54:32 --> Loader Class Initialized
INFO - 2023-12-06 08:54:32 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:32 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:32 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:32 --> Controller Class Initialized
INFO - 2023-12-06 08:54:37 --> Config Class Initialized
INFO - 2023-12-06 08:54:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:37 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:37 --> URI Class Initialized
INFO - 2023-12-06 08:54:37 --> Router Class Initialized
INFO - 2023-12-06 08:54:37 --> Output Class Initialized
INFO - 2023-12-06 08:54:37 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:37 --> Input Class Initialized
INFO - 2023-12-06 08:54:37 --> Language Class Initialized
INFO - 2023-12-06 08:54:37 --> Language Class Initialized
INFO - 2023-12-06 08:54:37 --> Config Class Initialized
INFO - 2023-12-06 08:54:37 --> Loader Class Initialized
INFO - 2023-12-06 08:54:37 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:37 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:37 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:37 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:37 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:38 --> Controller Class Initialized
INFO - 2023-12-06 08:54:38 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:38 --> Total execution time: 0.0551
INFO - 2023-12-06 08:54:47 --> Config Class Initialized
INFO - 2023-12-06 08:54:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:47 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:47 --> URI Class Initialized
INFO - 2023-12-06 08:54:47 --> Router Class Initialized
INFO - 2023-12-06 08:54:47 --> Output Class Initialized
INFO - 2023-12-06 08:54:47 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:47 --> Input Class Initialized
INFO - 2023-12-06 08:54:47 --> Language Class Initialized
INFO - 2023-12-06 08:54:47 --> Language Class Initialized
INFO - 2023-12-06 08:54:47 --> Config Class Initialized
INFO - 2023-12-06 08:54:47 --> Loader Class Initialized
INFO - 2023-12-06 08:54:47 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:47 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:47 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:47 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:48 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:48 --> Controller Class Initialized
INFO - 2023-12-06 08:54:48 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:48 --> Total execution time: 0.0373
INFO - 2023-12-06 08:54:48 --> Config Class Initialized
INFO - 2023-12-06 08:54:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:48 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:48 --> URI Class Initialized
INFO - 2023-12-06 08:54:48 --> Router Class Initialized
INFO - 2023-12-06 08:54:48 --> Output Class Initialized
INFO - 2023-12-06 08:54:48 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:48 --> Input Class Initialized
INFO - 2023-12-06 08:54:48 --> Language Class Initialized
ERROR - 2023-12-06 08:54:48 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:54:48 --> Config Class Initialized
INFO - 2023-12-06 08:54:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:48 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:48 --> URI Class Initialized
INFO - 2023-12-06 08:54:48 --> Router Class Initialized
INFO - 2023-12-06 08:54:48 --> Output Class Initialized
INFO - 2023-12-06 08:54:48 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:48 --> Input Class Initialized
INFO - 2023-12-06 08:54:48 --> Language Class Initialized
INFO - 2023-12-06 08:54:48 --> Language Class Initialized
INFO - 2023-12-06 08:54:48 --> Config Class Initialized
INFO - 2023-12-06 08:54:48 --> Loader Class Initialized
INFO - 2023-12-06 08:54:48 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:48 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:48 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:48 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:48 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:48 --> Controller Class Initialized
INFO - 2023-12-06 08:54:53 --> Config Class Initialized
INFO - 2023-12-06 08:54:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:54:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:54:53 --> Utf8 Class Initialized
INFO - 2023-12-06 08:54:53 --> URI Class Initialized
INFO - 2023-12-06 08:54:53 --> Router Class Initialized
INFO - 2023-12-06 08:54:53 --> Output Class Initialized
INFO - 2023-12-06 08:54:53 --> Security Class Initialized
DEBUG - 2023-12-06 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:54:53 --> Input Class Initialized
INFO - 2023-12-06 08:54:53 --> Language Class Initialized
INFO - 2023-12-06 08:54:53 --> Language Class Initialized
INFO - 2023-12-06 08:54:53 --> Config Class Initialized
INFO - 2023-12-06 08:54:53 --> Loader Class Initialized
INFO - 2023-12-06 08:54:53 --> Helper loaded: url_helper
INFO - 2023-12-06 08:54:53 --> Helper loaded: file_helper
INFO - 2023-12-06 08:54:53 --> Helper loaded: form_helper
INFO - 2023-12-06 08:54:53 --> Helper loaded: my_helper
INFO - 2023-12-06 08:54:53 --> Database Driver Class Initialized
INFO - 2023-12-06 08:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:54:53 --> Controller Class Initialized
INFO - 2023-12-06 08:54:53 --> Final output sent to browser
DEBUG - 2023-12-06 08:54:53 --> Total execution time: 0.0355
INFO - 2023-12-06 08:55:01 --> Config Class Initialized
INFO - 2023-12-06 08:55:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:01 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:01 --> URI Class Initialized
INFO - 2023-12-06 08:55:01 --> Router Class Initialized
INFO - 2023-12-06 08:55:01 --> Output Class Initialized
INFO - 2023-12-06 08:55:01 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:01 --> Input Class Initialized
INFO - 2023-12-06 08:55:01 --> Language Class Initialized
INFO - 2023-12-06 08:55:01 --> Language Class Initialized
INFO - 2023-12-06 08:55:01 --> Config Class Initialized
INFO - 2023-12-06 08:55:01 --> Loader Class Initialized
INFO - 2023-12-06 08:55:01 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:01 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:01 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:01 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:01 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:01 --> Controller Class Initialized
INFO - 2023-12-06 08:55:01 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:01 --> Total execution time: 0.0405
INFO - 2023-12-06 08:55:01 --> Config Class Initialized
INFO - 2023-12-06 08:55:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:01 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:01 --> URI Class Initialized
INFO - 2023-12-06 08:55:01 --> Router Class Initialized
INFO - 2023-12-06 08:55:01 --> Output Class Initialized
INFO - 2023-12-06 08:55:01 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:01 --> Input Class Initialized
INFO - 2023-12-06 08:55:01 --> Language Class Initialized
ERROR - 2023-12-06 08:55:01 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:55:02 --> Config Class Initialized
INFO - 2023-12-06 08:55:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:02 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:02 --> URI Class Initialized
INFO - 2023-12-06 08:55:02 --> Router Class Initialized
INFO - 2023-12-06 08:55:02 --> Output Class Initialized
INFO - 2023-12-06 08:55:02 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:02 --> Input Class Initialized
INFO - 2023-12-06 08:55:02 --> Language Class Initialized
INFO - 2023-12-06 08:55:02 --> Language Class Initialized
INFO - 2023-12-06 08:55:02 --> Config Class Initialized
INFO - 2023-12-06 08:55:02 --> Loader Class Initialized
INFO - 2023-12-06 08:55:02 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:02 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:02 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:02 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:02 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:02 --> Controller Class Initialized
INFO - 2023-12-06 08:55:05 --> Config Class Initialized
INFO - 2023-12-06 08:55:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:05 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:05 --> URI Class Initialized
INFO - 2023-12-06 08:55:05 --> Router Class Initialized
INFO - 2023-12-06 08:55:05 --> Output Class Initialized
INFO - 2023-12-06 08:55:05 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:05 --> Input Class Initialized
INFO - 2023-12-06 08:55:05 --> Language Class Initialized
INFO - 2023-12-06 08:55:05 --> Language Class Initialized
INFO - 2023-12-06 08:55:05 --> Config Class Initialized
INFO - 2023-12-06 08:55:05 --> Loader Class Initialized
INFO - 2023-12-06 08:55:05 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:05 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:05 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:05 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:05 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:05 --> Controller Class Initialized
INFO - 2023-12-06 08:55:05 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:05 --> Total execution time: 0.0584
INFO - 2023-12-06 08:55:11 --> Config Class Initialized
INFO - 2023-12-06 08:55:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:11 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:11 --> URI Class Initialized
INFO - 2023-12-06 08:55:11 --> Router Class Initialized
INFO - 2023-12-06 08:55:11 --> Output Class Initialized
INFO - 2023-12-06 08:55:11 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:11 --> Input Class Initialized
INFO - 2023-12-06 08:55:11 --> Language Class Initialized
INFO - 2023-12-06 08:55:11 --> Language Class Initialized
INFO - 2023-12-06 08:55:11 --> Config Class Initialized
INFO - 2023-12-06 08:55:11 --> Loader Class Initialized
INFO - 2023-12-06 08:55:11 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:11 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:11 --> Controller Class Initialized
INFO - 2023-12-06 08:55:11 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:11 --> Total execution time: 0.0363
INFO - 2023-12-06 08:55:11 --> Config Class Initialized
INFO - 2023-12-06 08:55:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:11 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:11 --> URI Class Initialized
INFO - 2023-12-06 08:55:11 --> Router Class Initialized
INFO - 2023-12-06 08:55:11 --> Output Class Initialized
INFO - 2023-12-06 08:55:11 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:11 --> Input Class Initialized
INFO - 2023-12-06 08:55:11 --> Language Class Initialized
ERROR - 2023-12-06 08:55:11 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:55:11 --> Config Class Initialized
INFO - 2023-12-06 08:55:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:11 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:11 --> URI Class Initialized
INFO - 2023-12-06 08:55:11 --> Router Class Initialized
INFO - 2023-12-06 08:55:11 --> Output Class Initialized
INFO - 2023-12-06 08:55:11 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:11 --> Input Class Initialized
INFO - 2023-12-06 08:55:11 --> Language Class Initialized
INFO - 2023-12-06 08:55:11 --> Language Class Initialized
INFO - 2023-12-06 08:55:11 --> Config Class Initialized
INFO - 2023-12-06 08:55:11 --> Loader Class Initialized
INFO - 2023-12-06 08:55:11 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:11 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:11 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:11 --> Controller Class Initialized
INFO - 2023-12-06 08:55:14 --> Config Class Initialized
INFO - 2023-12-06 08:55:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:14 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:14 --> URI Class Initialized
INFO - 2023-12-06 08:55:14 --> Router Class Initialized
INFO - 2023-12-06 08:55:14 --> Output Class Initialized
INFO - 2023-12-06 08:55:14 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:14 --> Input Class Initialized
INFO - 2023-12-06 08:55:14 --> Language Class Initialized
INFO - 2023-12-06 08:55:14 --> Language Class Initialized
INFO - 2023-12-06 08:55:14 --> Config Class Initialized
INFO - 2023-12-06 08:55:14 --> Loader Class Initialized
INFO - 2023-12-06 08:55:14 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:14 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:14 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:14 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:14 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:14 --> Controller Class Initialized
INFO - 2023-12-06 08:55:14 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:14 --> Total execution time: 0.0457
INFO - 2023-12-06 08:55:22 --> Config Class Initialized
INFO - 2023-12-06 08:55:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:22 --> URI Class Initialized
INFO - 2023-12-06 08:55:22 --> Router Class Initialized
INFO - 2023-12-06 08:55:22 --> Output Class Initialized
INFO - 2023-12-06 08:55:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:22 --> Input Class Initialized
INFO - 2023-12-06 08:55:22 --> Language Class Initialized
INFO - 2023-12-06 08:55:22 --> Language Class Initialized
INFO - 2023-12-06 08:55:22 --> Config Class Initialized
INFO - 2023-12-06 08:55:22 --> Loader Class Initialized
INFO - 2023-12-06 08:55:22 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:22 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:22 --> Controller Class Initialized
INFO - 2023-12-06 08:55:22 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:22 --> Total execution time: 0.0316
INFO - 2023-12-06 08:55:22 --> Config Class Initialized
INFO - 2023-12-06 08:55:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:22 --> URI Class Initialized
INFO - 2023-12-06 08:55:22 --> Router Class Initialized
INFO - 2023-12-06 08:55:22 --> Output Class Initialized
INFO - 2023-12-06 08:55:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:22 --> Input Class Initialized
INFO - 2023-12-06 08:55:22 --> Language Class Initialized
ERROR - 2023-12-06 08:55:22 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:55:22 --> Config Class Initialized
INFO - 2023-12-06 08:55:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:22 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:22 --> URI Class Initialized
INFO - 2023-12-06 08:55:22 --> Router Class Initialized
INFO - 2023-12-06 08:55:22 --> Output Class Initialized
INFO - 2023-12-06 08:55:22 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:22 --> Input Class Initialized
INFO - 2023-12-06 08:55:22 --> Language Class Initialized
INFO - 2023-12-06 08:55:22 --> Language Class Initialized
INFO - 2023-12-06 08:55:22 --> Config Class Initialized
INFO - 2023-12-06 08:55:22 --> Loader Class Initialized
INFO - 2023-12-06 08:55:22 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:22 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:22 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:22 --> Controller Class Initialized
INFO - 2023-12-06 08:55:24 --> Config Class Initialized
INFO - 2023-12-06 08:55:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:24 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:24 --> URI Class Initialized
INFO - 2023-12-06 08:55:24 --> Router Class Initialized
INFO - 2023-12-06 08:55:24 --> Output Class Initialized
INFO - 2023-12-06 08:55:24 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:24 --> Input Class Initialized
INFO - 2023-12-06 08:55:24 --> Language Class Initialized
INFO - 2023-12-06 08:55:24 --> Language Class Initialized
INFO - 2023-12-06 08:55:24 --> Config Class Initialized
INFO - 2023-12-06 08:55:24 --> Loader Class Initialized
INFO - 2023-12-06 08:55:24 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:24 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:24 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:24 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:24 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:24 --> Controller Class Initialized
INFO - 2023-12-06 08:55:24 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:24 --> Total execution time: 0.0293
INFO - 2023-12-06 08:55:35 --> Config Class Initialized
INFO - 2023-12-06 08:55:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:35 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:35 --> URI Class Initialized
INFO - 2023-12-06 08:55:35 --> Router Class Initialized
INFO - 2023-12-06 08:55:35 --> Output Class Initialized
INFO - 2023-12-06 08:55:35 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:35 --> Input Class Initialized
INFO - 2023-12-06 08:55:35 --> Language Class Initialized
INFO - 2023-12-06 08:55:35 --> Language Class Initialized
INFO - 2023-12-06 08:55:35 --> Config Class Initialized
INFO - 2023-12-06 08:55:35 --> Loader Class Initialized
INFO - 2023-12-06 08:55:35 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:35 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:35 --> Controller Class Initialized
INFO - 2023-12-06 08:55:35 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:35 --> Total execution time: 0.0323
INFO - 2023-12-06 08:55:35 --> Config Class Initialized
INFO - 2023-12-06 08:55:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:35 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:35 --> URI Class Initialized
INFO - 2023-12-06 08:55:35 --> Router Class Initialized
INFO - 2023-12-06 08:55:35 --> Output Class Initialized
INFO - 2023-12-06 08:55:35 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:35 --> Input Class Initialized
INFO - 2023-12-06 08:55:35 --> Language Class Initialized
ERROR - 2023-12-06 08:55:35 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:55:35 --> Config Class Initialized
INFO - 2023-12-06 08:55:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:35 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:35 --> URI Class Initialized
INFO - 2023-12-06 08:55:35 --> Router Class Initialized
INFO - 2023-12-06 08:55:35 --> Output Class Initialized
INFO - 2023-12-06 08:55:35 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:35 --> Input Class Initialized
INFO - 2023-12-06 08:55:35 --> Language Class Initialized
INFO - 2023-12-06 08:55:35 --> Language Class Initialized
INFO - 2023-12-06 08:55:35 --> Config Class Initialized
INFO - 2023-12-06 08:55:35 --> Loader Class Initialized
INFO - 2023-12-06 08:55:35 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:35 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:35 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:35 --> Controller Class Initialized
INFO - 2023-12-06 08:55:37 --> Config Class Initialized
INFO - 2023-12-06 08:55:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:37 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:37 --> URI Class Initialized
INFO - 2023-12-06 08:55:37 --> Router Class Initialized
INFO - 2023-12-06 08:55:37 --> Output Class Initialized
INFO - 2023-12-06 08:55:37 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:37 --> Input Class Initialized
INFO - 2023-12-06 08:55:37 --> Language Class Initialized
INFO - 2023-12-06 08:55:37 --> Language Class Initialized
INFO - 2023-12-06 08:55:37 --> Config Class Initialized
INFO - 2023-12-06 08:55:37 --> Loader Class Initialized
INFO - 2023-12-06 08:55:37 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:37 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:37 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:37 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:37 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:37 --> Controller Class Initialized
INFO - 2023-12-06 08:55:37 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:37 --> Total execution time: 0.0306
INFO - 2023-12-06 08:55:51 --> Config Class Initialized
INFO - 2023-12-06 08:55:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:51 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:51 --> URI Class Initialized
INFO - 2023-12-06 08:55:51 --> Router Class Initialized
INFO - 2023-12-06 08:55:51 --> Output Class Initialized
INFO - 2023-12-06 08:55:51 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:51 --> Input Class Initialized
INFO - 2023-12-06 08:55:51 --> Language Class Initialized
INFO - 2023-12-06 08:55:51 --> Language Class Initialized
INFO - 2023-12-06 08:55:51 --> Config Class Initialized
INFO - 2023-12-06 08:55:51 --> Loader Class Initialized
INFO - 2023-12-06 08:55:51 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:51 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:51 --> Controller Class Initialized
INFO - 2023-12-06 08:55:51 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:51 --> Total execution time: 0.0425
INFO - 2023-12-06 08:55:51 --> Config Class Initialized
INFO - 2023-12-06 08:55:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:51 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:51 --> URI Class Initialized
INFO - 2023-12-06 08:55:51 --> Router Class Initialized
INFO - 2023-12-06 08:55:51 --> Output Class Initialized
INFO - 2023-12-06 08:55:51 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:51 --> Input Class Initialized
INFO - 2023-12-06 08:55:51 --> Language Class Initialized
ERROR - 2023-12-06 08:55:51 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:55:51 --> Config Class Initialized
INFO - 2023-12-06 08:55:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:51 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:51 --> URI Class Initialized
INFO - 2023-12-06 08:55:51 --> Router Class Initialized
INFO - 2023-12-06 08:55:51 --> Output Class Initialized
INFO - 2023-12-06 08:55:51 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:51 --> Input Class Initialized
INFO - 2023-12-06 08:55:51 --> Language Class Initialized
INFO - 2023-12-06 08:55:51 --> Language Class Initialized
INFO - 2023-12-06 08:55:51 --> Config Class Initialized
INFO - 2023-12-06 08:55:51 --> Loader Class Initialized
INFO - 2023-12-06 08:55:51 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:51 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:51 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:51 --> Controller Class Initialized
INFO - 2023-12-06 08:55:54 --> Config Class Initialized
INFO - 2023-12-06 08:55:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:55:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:55:54 --> Utf8 Class Initialized
INFO - 2023-12-06 08:55:54 --> URI Class Initialized
INFO - 2023-12-06 08:55:54 --> Router Class Initialized
INFO - 2023-12-06 08:55:54 --> Output Class Initialized
INFO - 2023-12-06 08:55:54 --> Security Class Initialized
DEBUG - 2023-12-06 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:55:54 --> Input Class Initialized
INFO - 2023-12-06 08:55:54 --> Language Class Initialized
INFO - 2023-12-06 08:55:54 --> Language Class Initialized
INFO - 2023-12-06 08:55:54 --> Config Class Initialized
INFO - 2023-12-06 08:55:54 --> Loader Class Initialized
INFO - 2023-12-06 08:55:54 --> Helper loaded: url_helper
INFO - 2023-12-06 08:55:54 --> Helper loaded: file_helper
INFO - 2023-12-06 08:55:54 --> Helper loaded: form_helper
INFO - 2023-12-06 08:55:54 --> Helper loaded: my_helper
INFO - 2023-12-06 08:55:54 --> Database Driver Class Initialized
INFO - 2023-12-06 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:55:54 --> Controller Class Initialized
INFO - 2023-12-06 08:55:54 --> Final output sent to browser
DEBUG - 2023-12-06 08:55:54 --> Total execution time: 0.0311
INFO - 2023-12-06 08:56:03 --> Config Class Initialized
INFO - 2023-12-06 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:03 --> URI Class Initialized
INFO - 2023-12-06 08:56:03 --> Router Class Initialized
INFO - 2023-12-06 08:56:03 --> Output Class Initialized
INFO - 2023-12-06 08:56:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:03 --> Input Class Initialized
INFO - 2023-12-06 08:56:03 --> Language Class Initialized
INFO - 2023-12-06 08:56:03 --> Language Class Initialized
INFO - 2023-12-06 08:56:03 --> Config Class Initialized
INFO - 2023-12-06 08:56:03 --> Loader Class Initialized
INFO - 2023-12-06 08:56:03 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:03 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:03 --> Controller Class Initialized
INFO - 2023-12-06 08:56:03 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:03 --> Total execution time: 0.0358
INFO - 2023-12-06 08:56:03 --> Config Class Initialized
INFO - 2023-12-06 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:03 --> URI Class Initialized
INFO - 2023-12-06 08:56:03 --> Router Class Initialized
INFO - 2023-12-06 08:56:03 --> Output Class Initialized
INFO - 2023-12-06 08:56:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:03 --> Input Class Initialized
INFO - 2023-12-06 08:56:03 --> Language Class Initialized
ERROR - 2023-12-06 08:56:03 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:03 --> Config Class Initialized
INFO - 2023-12-06 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:03 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:03 --> URI Class Initialized
INFO - 2023-12-06 08:56:03 --> Router Class Initialized
INFO - 2023-12-06 08:56:03 --> Output Class Initialized
INFO - 2023-12-06 08:56:03 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:03 --> Input Class Initialized
INFO - 2023-12-06 08:56:03 --> Language Class Initialized
INFO - 2023-12-06 08:56:03 --> Language Class Initialized
INFO - 2023-12-06 08:56:03 --> Config Class Initialized
INFO - 2023-12-06 08:56:03 --> Loader Class Initialized
INFO - 2023-12-06 08:56:03 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:03 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:03 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:03 --> Controller Class Initialized
INFO - 2023-12-06 08:56:12 --> Config Class Initialized
INFO - 2023-12-06 08:56:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:12 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:12 --> URI Class Initialized
INFO - 2023-12-06 08:56:12 --> Router Class Initialized
INFO - 2023-12-06 08:56:12 --> Output Class Initialized
INFO - 2023-12-06 08:56:12 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:12 --> Input Class Initialized
INFO - 2023-12-06 08:56:12 --> Language Class Initialized
INFO - 2023-12-06 08:56:12 --> Language Class Initialized
INFO - 2023-12-06 08:56:12 --> Config Class Initialized
INFO - 2023-12-06 08:56:12 --> Loader Class Initialized
INFO - 2023-12-06 08:56:12 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:12 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:12 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:12 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:12 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:12 --> Controller Class Initialized
INFO - 2023-12-06 08:56:12 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:12 --> Total execution time: 0.0367
INFO - 2023-12-06 08:56:17 --> Config Class Initialized
INFO - 2023-12-06 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:17 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:17 --> URI Class Initialized
INFO - 2023-12-06 08:56:17 --> Router Class Initialized
INFO - 2023-12-06 08:56:17 --> Output Class Initialized
INFO - 2023-12-06 08:56:17 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:17 --> Input Class Initialized
INFO - 2023-12-06 08:56:17 --> Language Class Initialized
INFO - 2023-12-06 08:56:17 --> Language Class Initialized
INFO - 2023-12-06 08:56:17 --> Config Class Initialized
INFO - 2023-12-06 08:56:17 --> Loader Class Initialized
INFO - 2023-12-06 08:56:17 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:17 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:17 --> Controller Class Initialized
INFO - 2023-12-06 08:56:17 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:17 --> Total execution time: 0.0365
INFO - 2023-12-06 08:56:17 --> Config Class Initialized
INFO - 2023-12-06 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:17 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:17 --> URI Class Initialized
INFO - 2023-12-06 08:56:17 --> Router Class Initialized
INFO - 2023-12-06 08:56:17 --> Output Class Initialized
INFO - 2023-12-06 08:56:17 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:17 --> Input Class Initialized
INFO - 2023-12-06 08:56:17 --> Language Class Initialized
ERROR - 2023-12-06 08:56:17 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:17 --> Config Class Initialized
INFO - 2023-12-06 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:17 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:17 --> URI Class Initialized
INFO - 2023-12-06 08:56:17 --> Router Class Initialized
INFO - 2023-12-06 08:56:17 --> Output Class Initialized
INFO - 2023-12-06 08:56:17 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:17 --> Input Class Initialized
INFO - 2023-12-06 08:56:17 --> Language Class Initialized
INFO - 2023-12-06 08:56:17 --> Language Class Initialized
INFO - 2023-12-06 08:56:17 --> Config Class Initialized
INFO - 2023-12-06 08:56:17 --> Loader Class Initialized
INFO - 2023-12-06 08:56:17 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:17 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:17 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:17 --> Controller Class Initialized
INFO - 2023-12-06 08:56:19 --> Config Class Initialized
INFO - 2023-12-06 08:56:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:19 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:19 --> URI Class Initialized
INFO - 2023-12-06 08:56:19 --> Router Class Initialized
INFO - 2023-12-06 08:56:19 --> Output Class Initialized
INFO - 2023-12-06 08:56:19 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:19 --> Input Class Initialized
INFO - 2023-12-06 08:56:19 --> Language Class Initialized
INFO - 2023-12-06 08:56:19 --> Language Class Initialized
INFO - 2023-12-06 08:56:19 --> Config Class Initialized
INFO - 2023-12-06 08:56:19 --> Loader Class Initialized
INFO - 2023-12-06 08:56:19 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:19 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:19 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:19 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:19 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:19 --> Controller Class Initialized
INFO - 2023-12-06 08:56:19 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:19 --> Total execution time: 0.0350
INFO - 2023-12-06 08:56:24 --> Config Class Initialized
INFO - 2023-12-06 08:56:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:24 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:24 --> URI Class Initialized
INFO - 2023-12-06 08:56:24 --> Router Class Initialized
INFO - 2023-12-06 08:56:24 --> Output Class Initialized
INFO - 2023-12-06 08:56:24 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:24 --> Input Class Initialized
INFO - 2023-12-06 08:56:24 --> Language Class Initialized
INFO - 2023-12-06 08:56:24 --> Language Class Initialized
INFO - 2023-12-06 08:56:24 --> Config Class Initialized
INFO - 2023-12-06 08:56:24 --> Loader Class Initialized
INFO - 2023-12-06 08:56:24 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:24 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:24 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:24 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:24 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:24 --> Controller Class Initialized
INFO - 2023-12-06 08:56:24 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:24 --> Total execution time: 0.0333
INFO - 2023-12-06 08:56:24 --> Config Class Initialized
INFO - 2023-12-06 08:56:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:24 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:24 --> URI Class Initialized
INFO - 2023-12-06 08:56:24 --> Router Class Initialized
INFO - 2023-12-06 08:56:24 --> Output Class Initialized
INFO - 2023-12-06 08:56:24 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:24 --> Input Class Initialized
INFO - 2023-12-06 08:56:24 --> Language Class Initialized
ERROR - 2023-12-06 08:56:24 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:25 --> Config Class Initialized
INFO - 2023-12-06 08:56:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:25 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:25 --> URI Class Initialized
INFO - 2023-12-06 08:56:25 --> Router Class Initialized
INFO - 2023-12-06 08:56:25 --> Output Class Initialized
INFO - 2023-12-06 08:56:25 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:25 --> Input Class Initialized
INFO - 2023-12-06 08:56:25 --> Language Class Initialized
INFO - 2023-12-06 08:56:25 --> Language Class Initialized
INFO - 2023-12-06 08:56:25 --> Config Class Initialized
INFO - 2023-12-06 08:56:25 --> Loader Class Initialized
INFO - 2023-12-06 08:56:25 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:25 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:25 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:25 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:25 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:25 --> Controller Class Initialized
INFO - 2023-12-06 08:56:27 --> Config Class Initialized
INFO - 2023-12-06 08:56:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:27 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:27 --> URI Class Initialized
INFO - 2023-12-06 08:56:27 --> Router Class Initialized
INFO - 2023-12-06 08:56:27 --> Output Class Initialized
INFO - 2023-12-06 08:56:27 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:27 --> Input Class Initialized
INFO - 2023-12-06 08:56:27 --> Language Class Initialized
INFO - 2023-12-06 08:56:27 --> Language Class Initialized
INFO - 2023-12-06 08:56:27 --> Config Class Initialized
INFO - 2023-12-06 08:56:27 --> Loader Class Initialized
INFO - 2023-12-06 08:56:27 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:27 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:27 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:27 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:27 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:27 --> Controller Class Initialized
INFO - 2023-12-06 08:56:27 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:27 --> Total execution time: 0.0373
INFO - 2023-12-06 08:56:31 --> Config Class Initialized
INFO - 2023-12-06 08:56:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:31 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:31 --> URI Class Initialized
INFO - 2023-12-06 08:56:31 --> Router Class Initialized
INFO - 2023-12-06 08:56:31 --> Output Class Initialized
INFO - 2023-12-06 08:56:31 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:31 --> Input Class Initialized
INFO - 2023-12-06 08:56:31 --> Language Class Initialized
INFO - 2023-12-06 08:56:31 --> Language Class Initialized
INFO - 2023-12-06 08:56:31 --> Config Class Initialized
INFO - 2023-12-06 08:56:31 --> Loader Class Initialized
INFO - 2023-12-06 08:56:31 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:31 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:31 --> Controller Class Initialized
INFO - 2023-12-06 08:56:31 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:31 --> Total execution time: 0.0401
INFO - 2023-12-06 08:56:31 --> Config Class Initialized
INFO - 2023-12-06 08:56:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:31 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:31 --> URI Class Initialized
INFO - 2023-12-06 08:56:31 --> Router Class Initialized
INFO - 2023-12-06 08:56:31 --> Output Class Initialized
INFO - 2023-12-06 08:56:31 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:31 --> Input Class Initialized
INFO - 2023-12-06 08:56:31 --> Language Class Initialized
ERROR - 2023-12-06 08:56:31 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:31 --> Config Class Initialized
INFO - 2023-12-06 08:56:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:31 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:31 --> URI Class Initialized
INFO - 2023-12-06 08:56:31 --> Router Class Initialized
INFO - 2023-12-06 08:56:31 --> Output Class Initialized
INFO - 2023-12-06 08:56:31 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:31 --> Input Class Initialized
INFO - 2023-12-06 08:56:31 --> Language Class Initialized
INFO - 2023-12-06 08:56:31 --> Language Class Initialized
INFO - 2023-12-06 08:56:31 --> Config Class Initialized
INFO - 2023-12-06 08:56:31 --> Loader Class Initialized
INFO - 2023-12-06 08:56:31 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:31 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:31 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:31 --> Controller Class Initialized
INFO - 2023-12-06 08:56:34 --> Config Class Initialized
INFO - 2023-12-06 08:56:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:34 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:34 --> URI Class Initialized
INFO - 2023-12-06 08:56:34 --> Router Class Initialized
INFO - 2023-12-06 08:56:34 --> Output Class Initialized
INFO - 2023-12-06 08:56:34 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:34 --> Input Class Initialized
INFO - 2023-12-06 08:56:34 --> Language Class Initialized
INFO - 2023-12-06 08:56:34 --> Language Class Initialized
INFO - 2023-12-06 08:56:34 --> Config Class Initialized
INFO - 2023-12-06 08:56:34 --> Loader Class Initialized
INFO - 2023-12-06 08:56:34 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:34 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:34 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:34 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:34 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:34 --> Controller Class Initialized
INFO - 2023-12-06 08:56:34 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:34 --> Total execution time: 0.0340
INFO - 2023-12-06 08:56:37 --> Config Class Initialized
INFO - 2023-12-06 08:56:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:37 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:37 --> URI Class Initialized
INFO - 2023-12-06 08:56:37 --> Router Class Initialized
INFO - 2023-12-06 08:56:37 --> Output Class Initialized
INFO - 2023-12-06 08:56:37 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:37 --> Input Class Initialized
INFO - 2023-12-06 08:56:37 --> Language Class Initialized
INFO - 2023-12-06 08:56:37 --> Language Class Initialized
INFO - 2023-12-06 08:56:37 --> Config Class Initialized
INFO - 2023-12-06 08:56:37 --> Loader Class Initialized
INFO - 2023-12-06 08:56:37 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:37 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:37 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:37 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:37 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:37 --> Controller Class Initialized
INFO - 2023-12-06 08:56:37 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:37 --> Total execution time: 0.0770
INFO - 2023-12-06 08:56:37 --> Config Class Initialized
INFO - 2023-12-06 08:56:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:37 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:37 --> URI Class Initialized
INFO - 2023-12-06 08:56:37 --> Router Class Initialized
INFO - 2023-12-06 08:56:37 --> Output Class Initialized
INFO - 2023-12-06 08:56:37 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:37 --> Input Class Initialized
INFO - 2023-12-06 08:56:37 --> Language Class Initialized
ERROR - 2023-12-06 08:56:37 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:38 --> Config Class Initialized
INFO - 2023-12-06 08:56:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:38 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:38 --> URI Class Initialized
INFO - 2023-12-06 08:56:38 --> Router Class Initialized
INFO - 2023-12-06 08:56:38 --> Output Class Initialized
INFO - 2023-12-06 08:56:38 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:38 --> Input Class Initialized
INFO - 2023-12-06 08:56:38 --> Language Class Initialized
INFO - 2023-12-06 08:56:38 --> Language Class Initialized
INFO - 2023-12-06 08:56:38 --> Config Class Initialized
INFO - 2023-12-06 08:56:38 --> Loader Class Initialized
INFO - 2023-12-06 08:56:38 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:38 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:38 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:38 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:38 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:38 --> Controller Class Initialized
INFO - 2023-12-06 08:56:40 --> Config Class Initialized
INFO - 2023-12-06 08:56:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:40 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:40 --> URI Class Initialized
INFO - 2023-12-06 08:56:40 --> Router Class Initialized
INFO - 2023-12-06 08:56:40 --> Output Class Initialized
INFO - 2023-12-06 08:56:40 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:40 --> Input Class Initialized
INFO - 2023-12-06 08:56:40 --> Language Class Initialized
INFO - 2023-12-06 08:56:40 --> Language Class Initialized
INFO - 2023-12-06 08:56:40 --> Config Class Initialized
INFO - 2023-12-06 08:56:40 --> Loader Class Initialized
INFO - 2023-12-06 08:56:40 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:40 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:40 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:40 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:40 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:40 --> Controller Class Initialized
INFO - 2023-12-06 08:56:40 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:40 --> Total execution time: 0.0738
INFO - 2023-12-06 08:56:42 --> Config Class Initialized
INFO - 2023-12-06 08:56:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:42 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:42 --> URI Class Initialized
INFO - 2023-12-06 08:56:42 --> Router Class Initialized
INFO - 2023-12-06 08:56:42 --> Output Class Initialized
INFO - 2023-12-06 08:56:42 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:42 --> Input Class Initialized
INFO - 2023-12-06 08:56:42 --> Language Class Initialized
INFO - 2023-12-06 08:56:42 --> Language Class Initialized
INFO - 2023-12-06 08:56:42 --> Config Class Initialized
INFO - 2023-12-06 08:56:42 --> Loader Class Initialized
INFO - 2023-12-06 08:56:42 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:42 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:42 --> Controller Class Initialized
INFO - 2023-12-06 08:56:42 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:42 --> Total execution time: 0.0345
INFO - 2023-12-06 08:56:42 --> Config Class Initialized
INFO - 2023-12-06 08:56:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:42 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:42 --> URI Class Initialized
INFO - 2023-12-06 08:56:42 --> Router Class Initialized
INFO - 2023-12-06 08:56:42 --> Output Class Initialized
INFO - 2023-12-06 08:56:42 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:42 --> Input Class Initialized
INFO - 2023-12-06 08:56:42 --> Language Class Initialized
ERROR - 2023-12-06 08:56:42 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:42 --> Config Class Initialized
INFO - 2023-12-06 08:56:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:42 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:42 --> URI Class Initialized
INFO - 2023-12-06 08:56:42 --> Router Class Initialized
INFO - 2023-12-06 08:56:42 --> Output Class Initialized
INFO - 2023-12-06 08:56:42 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:42 --> Input Class Initialized
INFO - 2023-12-06 08:56:42 --> Language Class Initialized
INFO - 2023-12-06 08:56:42 --> Language Class Initialized
INFO - 2023-12-06 08:56:42 --> Config Class Initialized
INFO - 2023-12-06 08:56:42 --> Loader Class Initialized
INFO - 2023-12-06 08:56:42 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:42 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:42 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:42 --> Controller Class Initialized
INFO - 2023-12-06 08:56:45 --> Config Class Initialized
INFO - 2023-12-06 08:56:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:45 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:45 --> URI Class Initialized
INFO - 2023-12-06 08:56:45 --> Router Class Initialized
INFO - 2023-12-06 08:56:45 --> Output Class Initialized
INFO - 2023-12-06 08:56:45 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:45 --> Input Class Initialized
INFO - 2023-12-06 08:56:45 --> Language Class Initialized
INFO - 2023-12-06 08:56:45 --> Language Class Initialized
INFO - 2023-12-06 08:56:45 --> Config Class Initialized
INFO - 2023-12-06 08:56:45 --> Loader Class Initialized
INFO - 2023-12-06 08:56:45 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:45 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:45 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:45 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:45 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:45 --> Controller Class Initialized
INFO - 2023-12-06 08:56:45 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:45 --> Total execution time: 0.0294
INFO - 2023-12-06 08:56:50 --> Config Class Initialized
INFO - 2023-12-06 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:50 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:50 --> URI Class Initialized
INFO - 2023-12-06 08:56:50 --> Router Class Initialized
INFO - 2023-12-06 08:56:50 --> Output Class Initialized
INFO - 2023-12-06 08:56:50 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:50 --> Input Class Initialized
INFO - 2023-12-06 08:56:50 --> Language Class Initialized
INFO - 2023-12-06 08:56:50 --> Language Class Initialized
INFO - 2023-12-06 08:56:50 --> Config Class Initialized
INFO - 2023-12-06 08:56:50 --> Loader Class Initialized
INFO - 2023-12-06 08:56:50 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:50 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:50 --> Controller Class Initialized
INFO - 2023-12-06 08:56:50 --> Final output sent to browser
DEBUG - 2023-12-06 08:56:50 --> Total execution time: 0.0381
INFO - 2023-12-06 08:56:50 --> Config Class Initialized
INFO - 2023-12-06 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:50 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:50 --> URI Class Initialized
INFO - 2023-12-06 08:56:50 --> Router Class Initialized
INFO - 2023-12-06 08:56:50 --> Output Class Initialized
INFO - 2023-12-06 08:56:50 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:50 --> Input Class Initialized
INFO - 2023-12-06 08:56:50 --> Language Class Initialized
ERROR - 2023-12-06 08:56:50 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:56:50 --> Config Class Initialized
INFO - 2023-12-06 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:56:50 --> Utf8 Class Initialized
INFO - 2023-12-06 08:56:50 --> URI Class Initialized
INFO - 2023-12-06 08:56:50 --> Router Class Initialized
INFO - 2023-12-06 08:56:50 --> Output Class Initialized
INFO - 2023-12-06 08:56:50 --> Security Class Initialized
DEBUG - 2023-12-06 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:56:50 --> Input Class Initialized
INFO - 2023-12-06 08:56:50 --> Language Class Initialized
INFO - 2023-12-06 08:56:50 --> Language Class Initialized
INFO - 2023-12-06 08:56:50 --> Config Class Initialized
INFO - 2023-12-06 08:56:50 --> Loader Class Initialized
INFO - 2023-12-06 08:56:50 --> Helper loaded: url_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: file_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: form_helper
INFO - 2023-12-06 08:56:50 --> Helper loaded: my_helper
INFO - 2023-12-06 08:56:50 --> Database Driver Class Initialized
INFO - 2023-12-06 08:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:56:50 --> Controller Class Initialized
INFO - 2023-12-06 08:57:01 --> Config Class Initialized
INFO - 2023-12-06 08:57:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:01 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:01 --> URI Class Initialized
INFO - 2023-12-06 08:57:01 --> Router Class Initialized
INFO - 2023-12-06 08:57:01 --> Output Class Initialized
INFO - 2023-12-06 08:57:01 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:01 --> Input Class Initialized
INFO - 2023-12-06 08:57:01 --> Language Class Initialized
INFO - 2023-12-06 08:57:01 --> Language Class Initialized
INFO - 2023-12-06 08:57:01 --> Config Class Initialized
INFO - 2023-12-06 08:57:01 --> Loader Class Initialized
INFO - 2023-12-06 08:57:01 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:01 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:01 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:01 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:01 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:01 --> Controller Class Initialized
DEBUG - 2023-12-06 08:57:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 08:57:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:57:01 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:01 --> Total execution time: 0.0810
INFO - 2023-12-06 08:57:07 --> Config Class Initialized
INFO - 2023-12-06 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:07 --> URI Class Initialized
INFO - 2023-12-06 08:57:07 --> Router Class Initialized
INFO - 2023-12-06 08:57:07 --> Output Class Initialized
INFO - 2023-12-06 08:57:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:07 --> Input Class Initialized
INFO - 2023-12-06 08:57:07 --> Language Class Initialized
INFO - 2023-12-06 08:57:07 --> Language Class Initialized
INFO - 2023-12-06 08:57:07 --> Config Class Initialized
INFO - 2023-12-06 08:57:07 --> Loader Class Initialized
INFO - 2023-12-06 08:57:07 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:07 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:07 --> Controller Class Initialized
DEBUG - 2023-12-06 08:57:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 08:57:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:57:07 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:07 --> Total execution time: 0.0688
INFO - 2023-12-06 08:57:07 --> Config Class Initialized
INFO - 2023-12-06 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:07 --> URI Class Initialized
INFO - 2023-12-06 08:57:07 --> Router Class Initialized
INFO - 2023-12-06 08:57:07 --> Output Class Initialized
INFO - 2023-12-06 08:57:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:07 --> Input Class Initialized
INFO - 2023-12-06 08:57:07 --> Language Class Initialized
ERROR - 2023-12-06 08:57:07 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:57:07 --> Config Class Initialized
INFO - 2023-12-06 08:57:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:07 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:07 --> URI Class Initialized
INFO - 2023-12-06 08:57:07 --> Router Class Initialized
INFO - 2023-12-06 08:57:07 --> Output Class Initialized
INFO - 2023-12-06 08:57:07 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:07 --> Input Class Initialized
INFO - 2023-12-06 08:57:07 --> Language Class Initialized
INFO - 2023-12-06 08:57:07 --> Language Class Initialized
INFO - 2023-12-06 08:57:07 --> Config Class Initialized
INFO - 2023-12-06 08:57:07 --> Loader Class Initialized
INFO - 2023-12-06 08:57:07 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:07 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:07 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:07 --> Controller Class Initialized
INFO - 2023-12-06 08:57:21 --> Config Class Initialized
INFO - 2023-12-06 08:57:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:21 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:21 --> URI Class Initialized
INFO - 2023-12-06 08:57:21 --> Router Class Initialized
INFO - 2023-12-06 08:57:21 --> Output Class Initialized
INFO - 2023-12-06 08:57:21 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:21 --> Input Class Initialized
INFO - 2023-12-06 08:57:21 --> Language Class Initialized
INFO - 2023-12-06 08:57:21 --> Language Class Initialized
INFO - 2023-12-06 08:57:21 --> Config Class Initialized
INFO - 2023-12-06 08:57:21 --> Loader Class Initialized
INFO - 2023-12-06 08:57:21 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:21 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:21 --> Controller Class Initialized
DEBUG - 2023-12-06 08:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-06 08:57:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:57:21 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:21 --> Total execution time: 0.0353
INFO - 2023-12-06 08:57:21 --> Config Class Initialized
INFO - 2023-12-06 08:57:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:21 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:21 --> URI Class Initialized
INFO - 2023-12-06 08:57:21 --> Router Class Initialized
INFO - 2023-12-06 08:57:21 --> Output Class Initialized
INFO - 2023-12-06 08:57:21 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:21 --> Input Class Initialized
INFO - 2023-12-06 08:57:21 --> Language Class Initialized
ERROR - 2023-12-06 08:57:21 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:57:21 --> Config Class Initialized
INFO - 2023-12-06 08:57:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:21 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:21 --> URI Class Initialized
INFO - 2023-12-06 08:57:21 --> Router Class Initialized
INFO - 2023-12-06 08:57:21 --> Output Class Initialized
INFO - 2023-12-06 08:57:21 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:21 --> Input Class Initialized
INFO - 2023-12-06 08:57:21 --> Language Class Initialized
INFO - 2023-12-06 08:57:21 --> Language Class Initialized
INFO - 2023-12-06 08:57:21 --> Config Class Initialized
INFO - 2023-12-06 08:57:21 --> Loader Class Initialized
INFO - 2023-12-06 08:57:21 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:21 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:21 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:21 --> Controller Class Initialized
INFO - 2023-12-06 08:57:23 --> Config Class Initialized
INFO - 2023-12-06 08:57:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:23 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:23 --> URI Class Initialized
INFO - 2023-12-06 08:57:23 --> Router Class Initialized
INFO - 2023-12-06 08:57:23 --> Output Class Initialized
INFO - 2023-12-06 08:57:23 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:23 --> Input Class Initialized
INFO - 2023-12-06 08:57:23 --> Language Class Initialized
INFO - 2023-12-06 08:57:23 --> Language Class Initialized
INFO - 2023-12-06 08:57:23 --> Config Class Initialized
INFO - 2023-12-06 08:57:23 --> Loader Class Initialized
INFO - 2023-12-06 08:57:23 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:23 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:23 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:23 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:23 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:23 --> Controller Class Initialized
INFO - 2023-12-06 08:57:23 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:23 --> Total execution time: 0.0325
INFO - 2023-12-06 08:57:53 --> Config Class Initialized
INFO - 2023-12-06 08:57:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:53 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:53 --> URI Class Initialized
INFO - 2023-12-06 08:57:53 --> Router Class Initialized
INFO - 2023-12-06 08:57:53 --> Output Class Initialized
INFO - 2023-12-06 08:57:53 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:53 --> Input Class Initialized
INFO - 2023-12-06 08:57:53 --> Language Class Initialized
INFO - 2023-12-06 08:57:53 --> Language Class Initialized
INFO - 2023-12-06 08:57:53 --> Config Class Initialized
INFO - 2023-12-06 08:57:53 --> Loader Class Initialized
INFO - 2023-12-06 08:57:53 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:53 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:53 --> Controller Class Initialized
INFO - 2023-12-06 08:57:53 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:53 --> Total execution time: 0.1217
INFO - 2023-12-06 08:57:53 --> Config Class Initialized
INFO - 2023-12-06 08:57:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:53 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:53 --> URI Class Initialized
INFO - 2023-12-06 08:57:53 --> Router Class Initialized
INFO - 2023-12-06 08:57:53 --> Output Class Initialized
INFO - 2023-12-06 08:57:53 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:53 --> Input Class Initialized
INFO - 2023-12-06 08:57:53 --> Language Class Initialized
ERROR - 2023-12-06 08:57:53 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:57:53 --> Config Class Initialized
INFO - 2023-12-06 08:57:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:53 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:53 --> URI Class Initialized
INFO - 2023-12-06 08:57:53 --> Router Class Initialized
INFO - 2023-12-06 08:57:53 --> Output Class Initialized
INFO - 2023-12-06 08:57:53 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:53 --> Input Class Initialized
INFO - 2023-12-06 08:57:53 --> Language Class Initialized
INFO - 2023-12-06 08:57:53 --> Language Class Initialized
INFO - 2023-12-06 08:57:53 --> Config Class Initialized
INFO - 2023-12-06 08:57:53 --> Loader Class Initialized
INFO - 2023-12-06 08:57:53 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:53 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:53 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:53 --> Controller Class Initialized
INFO - 2023-12-06 08:57:55 --> Config Class Initialized
INFO - 2023-12-06 08:57:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:57:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:57:55 --> Utf8 Class Initialized
INFO - 2023-12-06 08:57:55 --> URI Class Initialized
INFO - 2023-12-06 08:57:55 --> Router Class Initialized
INFO - 2023-12-06 08:57:55 --> Output Class Initialized
INFO - 2023-12-06 08:57:55 --> Security Class Initialized
DEBUG - 2023-12-06 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:57:55 --> Input Class Initialized
INFO - 2023-12-06 08:57:55 --> Language Class Initialized
INFO - 2023-12-06 08:57:55 --> Language Class Initialized
INFO - 2023-12-06 08:57:55 --> Config Class Initialized
INFO - 2023-12-06 08:57:55 --> Loader Class Initialized
INFO - 2023-12-06 08:57:55 --> Helper loaded: url_helper
INFO - 2023-12-06 08:57:55 --> Helper loaded: file_helper
INFO - 2023-12-06 08:57:55 --> Helper loaded: form_helper
INFO - 2023-12-06 08:57:55 --> Helper loaded: my_helper
INFO - 2023-12-06 08:57:55 --> Database Driver Class Initialized
INFO - 2023-12-06 08:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:57:55 --> Controller Class Initialized
INFO - 2023-12-06 08:57:55 --> Final output sent to browser
DEBUG - 2023-12-06 08:57:55 --> Total execution time: 0.0672
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:06 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:06 --> URI Class Initialized
INFO - 2023-12-06 08:58:06 --> Router Class Initialized
INFO - 2023-12-06 08:58:06 --> Output Class Initialized
INFO - 2023-12-06 08:58:06 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:06 --> Input Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Loader Class Initialized
INFO - 2023-12-06 08:58:06 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:06 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:06 --> Controller Class Initialized
INFO - 2023-12-06 08:58:06 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:06 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:06 --> URI Class Initialized
INFO - 2023-12-06 08:58:06 --> Router Class Initialized
INFO - 2023-12-06 08:58:06 --> Output Class Initialized
INFO - 2023-12-06 08:58:06 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:06 --> Input Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Loader Class Initialized
INFO - 2023-12-06 08:58:06 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:06 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:06 --> Controller Class Initialized
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:06 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:06 --> URI Class Initialized
INFO - 2023-12-06 08:58:06 --> Router Class Initialized
INFO - 2023-12-06 08:58:06 --> Output Class Initialized
INFO - 2023-12-06 08:58:06 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:06 --> Input Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Language Class Initialized
INFO - 2023-12-06 08:58:06 --> Config Class Initialized
INFO - 2023-12-06 08:58:06 --> Loader Class Initialized
INFO - 2023-12-06 08:58:06 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:06 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:06 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:06 --> Controller Class Initialized
DEBUG - 2023-12-06 08:58:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 08:58:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:06 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:06 --> Total execution time: 0.0371
INFO - 2023-12-06 08:58:11 --> Config Class Initialized
INFO - 2023-12-06 08:58:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:11 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:11 --> URI Class Initialized
INFO - 2023-12-06 08:58:11 --> Router Class Initialized
INFO - 2023-12-06 08:58:11 --> Output Class Initialized
INFO - 2023-12-06 08:58:11 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:11 --> Input Class Initialized
INFO - 2023-12-06 08:58:11 --> Language Class Initialized
INFO - 2023-12-06 08:58:11 --> Language Class Initialized
INFO - 2023-12-06 08:58:11 --> Config Class Initialized
INFO - 2023-12-06 08:58:11 --> Loader Class Initialized
INFO - 2023-12-06 08:58:11 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:11 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:11 --> Controller Class Initialized
INFO - 2023-12-06 08:58:11 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:58:11 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:11 --> Total execution time: 0.0351
INFO - 2023-12-06 08:58:11 --> Config Class Initialized
INFO - 2023-12-06 08:58:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:11 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:11 --> URI Class Initialized
INFO - 2023-12-06 08:58:11 --> Router Class Initialized
INFO - 2023-12-06 08:58:11 --> Output Class Initialized
INFO - 2023-12-06 08:58:11 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:11 --> Input Class Initialized
INFO - 2023-12-06 08:58:11 --> Language Class Initialized
INFO - 2023-12-06 08:58:11 --> Language Class Initialized
INFO - 2023-12-06 08:58:11 --> Config Class Initialized
INFO - 2023-12-06 08:58:11 --> Loader Class Initialized
INFO - 2023-12-06 08:58:11 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:11 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:11 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:11 --> Controller Class Initialized
DEBUG - 2023-12-06 08:58:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 08:58:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:11 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:11 --> Total execution time: 0.0838
INFO - 2023-12-06 08:58:13 --> Config Class Initialized
INFO - 2023-12-06 08:58:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:13 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:13 --> URI Class Initialized
INFO - 2023-12-06 08:58:13 --> Router Class Initialized
INFO - 2023-12-06 08:58:13 --> Output Class Initialized
INFO - 2023-12-06 08:58:13 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:13 --> Input Class Initialized
INFO - 2023-12-06 08:58:13 --> Language Class Initialized
INFO - 2023-12-06 08:58:13 --> Language Class Initialized
INFO - 2023-12-06 08:58:13 --> Config Class Initialized
INFO - 2023-12-06 08:58:13 --> Loader Class Initialized
INFO - 2023-12-06 08:58:13 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:13 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:13 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:13 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:13 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:13 --> Controller Class Initialized
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 08:58:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 08:58:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:13 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:13 --> Total execution time: 0.0387
INFO - 2023-12-06 08:58:18 --> Config Class Initialized
INFO - 2023-12-06 08:58:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:18 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:18 --> URI Class Initialized
INFO - 2023-12-06 08:58:18 --> Router Class Initialized
INFO - 2023-12-06 08:58:18 --> Output Class Initialized
INFO - 2023-12-06 08:58:18 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:18 --> Input Class Initialized
INFO - 2023-12-06 08:58:18 --> Language Class Initialized
INFO - 2023-12-06 08:58:18 --> Language Class Initialized
INFO - 2023-12-06 08:58:18 --> Config Class Initialized
INFO - 2023-12-06 08:58:18 --> Loader Class Initialized
INFO - 2023-12-06 08:58:18 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:18 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:18 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:18 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:18 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:18 --> Controller Class Initialized
DEBUG - 2023-12-06 08:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 08:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:18 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:18 --> Total execution time: 0.0445
INFO - 2023-12-06 08:58:19 --> Config Class Initialized
INFO - 2023-12-06 08:58:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:19 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:19 --> URI Class Initialized
INFO - 2023-12-06 08:58:19 --> Router Class Initialized
INFO - 2023-12-06 08:58:19 --> Output Class Initialized
INFO - 2023-12-06 08:58:19 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:19 --> Input Class Initialized
INFO - 2023-12-06 08:58:19 --> Language Class Initialized
INFO - 2023-12-06 08:58:19 --> Language Class Initialized
INFO - 2023-12-06 08:58:19 --> Config Class Initialized
INFO - 2023-12-06 08:58:19 --> Loader Class Initialized
INFO - 2023-12-06 08:58:19 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:19 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:19 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:19 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:19 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:19 --> Controller Class Initialized
INFO - 2023-12-06 08:58:31 --> Config Class Initialized
INFO - 2023-12-06 08:58:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:31 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:31 --> URI Class Initialized
INFO - 2023-12-06 08:58:31 --> Router Class Initialized
INFO - 2023-12-06 08:58:31 --> Output Class Initialized
INFO - 2023-12-06 08:58:31 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:31 --> Input Class Initialized
INFO - 2023-12-06 08:58:31 --> Language Class Initialized
INFO - 2023-12-06 08:58:31 --> Language Class Initialized
INFO - 2023-12-06 08:58:31 --> Config Class Initialized
INFO - 2023-12-06 08:58:31 --> Loader Class Initialized
INFO - 2023-12-06 08:58:31 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:31 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:31 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:31 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:31 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:31 --> Controller Class Initialized
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 08:58:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 08:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 08:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:31 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:31 --> Total execution time: 0.1032
INFO - 2023-12-06 08:58:38 --> Config Class Initialized
INFO - 2023-12-06 08:58:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:58:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:58:38 --> Utf8 Class Initialized
INFO - 2023-12-06 08:58:38 --> URI Class Initialized
INFO - 2023-12-06 08:58:38 --> Router Class Initialized
INFO - 2023-12-06 08:58:38 --> Output Class Initialized
INFO - 2023-12-06 08:58:38 --> Security Class Initialized
DEBUG - 2023-12-06 08:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:58:38 --> Input Class Initialized
INFO - 2023-12-06 08:58:38 --> Language Class Initialized
INFO - 2023-12-06 08:58:38 --> Language Class Initialized
INFO - 2023-12-06 08:58:38 --> Config Class Initialized
INFO - 2023-12-06 08:58:38 --> Loader Class Initialized
INFO - 2023-12-06 08:58:38 --> Helper loaded: url_helper
INFO - 2023-12-06 08:58:38 --> Helper loaded: file_helper
INFO - 2023-12-06 08:58:38 --> Helper loaded: form_helper
INFO - 2023-12-06 08:58:38 --> Helper loaded: my_helper
INFO - 2023-12-06 08:58:38 --> Database Driver Class Initialized
INFO - 2023-12-06 08:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:58:38 --> Controller Class Initialized
DEBUG - 2023-12-06 08:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 08:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:58:38 --> Final output sent to browser
DEBUG - 2023-12-06 08:58:38 --> Total execution time: 0.1091
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:04 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:04 --> URI Class Initialized
INFO - 2023-12-06 08:59:04 --> Router Class Initialized
INFO - 2023-12-06 08:59:04 --> Output Class Initialized
INFO - 2023-12-06 08:59:04 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:04 --> Input Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Loader Class Initialized
INFO - 2023-12-06 08:59:04 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:04 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:04 --> Controller Class Initialized
INFO - 2023-12-06 08:59:04 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:04 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:04 --> URI Class Initialized
INFO - 2023-12-06 08:59:04 --> Router Class Initialized
INFO - 2023-12-06 08:59:04 --> Output Class Initialized
INFO - 2023-12-06 08:59:04 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:04 --> Input Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Loader Class Initialized
INFO - 2023-12-06 08:59:04 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:04 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:04 --> Controller Class Initialized
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:04 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:04 --> URI Class Initialized
INFO - 2023-12-06 08:59:04 --> Router Class Initialized
INFO - 2023-12-06 08:59:04 --> Output Class Initialized
INFO - 2023-12-06 08:59:04 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:04 --> Input Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Language Class Initialized
INFO - 2023-12-06 08:59:04 --> Config Class Initialized
INFO - 2023-12-06 08:59:04 --> Loader Class Initialized
INFO - 2023-12-06 08:59:04 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:04 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:04 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:04 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 08:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:04 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:04 --> Total execution time: 0.0377
INFO - 2023-12-06 08:59:13 --> Config Class Initialized
INFO - 2023-12-06 08:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:13 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:13 --> URI Class Initialized
INFO - 2023-12-06 08:59:13 --> Router Class Initialized
INFO - 2023-12-06 08:59:13 --> Output Class Initialized
INFO - 2023-12-06 08:59:13 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:13 --> Input Class Initialized
INFO - 2023-12-06 08:59:13 --> Language Class Initialized
INFO - 2023-12-06 08:59:13 --> Language Class Initialized
INFO - 2023-12-06 08:59:13 --> Config Class Initialized
INFO - 2023-12-06 08:59:13 --> Loader Class Initialized
INFO - 2023-12-06 08:59:13 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:13 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:13 --> Controller Class Initialized
INFO - 2023-12-06 08:59:13 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:59:13 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:13 --> Total execution time: 0.0393
INFO - 2023-12-06 08:59:13 --> Config Class Initialized
INFO - 2023-12-06 08:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:13 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:13 --> URI Class Initialized
INFO - 2023-12-06 08:59:13 --> Router Class Initialized
INFO - 2023-12-06 08:59:13 --> Output Class Initialized
INFO - 2023-12-06 08:59:13 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:13 --> Input Class Initialized
INFO - 2023-12-06 08:59:13 --> Language Class Initialized
INFO - 2023-12-06 08:59:13 --> Language Class Initialized
INFO - 2023-12-06 08:59:13 --> Config Class Initialized
INFO - 2023-12-06 08:59:13 --> Loader Class Initialized
INFO - 2023-12-06 08:59:13 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:13 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:13 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:13 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 08:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:13 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:13 --> Total execution time: 0.0377
INFO - 2023-12-06 08:59:16 --> Config Class Initialized
INFO - 2023-12-06 08:59:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:16 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:16 --> URI Class Initialized
INFO - 2023-12-06 08:59:16 --> Router Class Initialized
INFO - 2023-12-06 08:59:16 --> Output Class Initialized
INFO - 2023-12-06 08:59:16 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:16 --> Input Class Initialized
INFO - 2023-12-06 08:59:16 --> Language Class Initialized
INFO - 2023-12-06 08:59:16 --> Language Class Initialized
INFO - 2023-12-06 08:59:16 --> Config Class Initialized
INFO - 2023-12-06 08:59:16 --> Loader Class Initialized
INFO - 2023-12-06 08:59:16 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:16 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:16 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:16 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:16 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:16 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 08:59:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:16 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:16 --> Total execution time: 0.0544
INFO - 2023-12-06 08:59:18 --> Config Class Initialized
INFO - 2023-12-06 08:59:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:18 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:18 --> URI Class Initialized
INFO - 2023-12-06 08:59:18 --> Router Class Initialized
INFO - 2023-12-06 08:59:18 --> Output Class Initialized
INFO - 2023-12-06 08:59:18 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:18 --> Input Class Initialized
INFO - 2023-12-06 08:59:18 --> Language Class Initialized
INFO - 2023-12-06 08:59:18 --> Language Class Initialized
INFO - 2023-12-06 08:59:18 --> Config Class Initialized
INFO - 2023-12-06 08:59:18 --> Loader Class Initialized
INFO - 2023-12-06 08:59:18 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:18 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:18 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:18 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:18 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:18 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-06 08:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:18 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:18 --> Total execution time: 0.0372
INFO - 2023-12-06 08:59:23 --> Config Class Initialized
INFO - 2023-12-06 08:59:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:23 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:23 --> URI Class Initialized
INFO - 2023-12-06 08:59:23 --> Router Class Initialized
INFO - 2023-12-06 08:59:23 --> Output Class Initialized
INFO - 2023-12-06 08:59:23 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:23 --> Input Class Initialized
INFO - 2023-12-06 08:59:23 --> Language Class Initialized
INFO - 2023-12-06 08:59:23 --> Language Class Initialized
INFO - 2023-12-06 08:59:23 --> Config Class Initialized
INFO - 2023-12-06 08:59:23 --> Loader Class Initialized
INFO - 2023-12-06 08:59:23 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:23 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:23 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:23 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:23 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:23 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 08:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:23 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:23 --> Total execution time: 0.0412
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:30 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:30 --> URI Class Initialized
INFO - 2023-12-06 08:59:30 --> Router Class Initialized
INFO - 2023-12-06 08:59:30 --> Output Class Initialized
INFO - 2023-12-06 08:59:30 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:30 --> Input Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Loader Class Initialized
INFO - 2023-12-06 08:59:30 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:30 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:30 --> Controller Class Initialized
INFO - 2023-12-06 08:59:30 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:30 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:30 --> URI Class Initialized
INFO - 2023-12-06 08:59:30 --> Router Class Initialized
INFO - 2023-12-06 08:59:30 --> Output Class Initialized
INFO - 2023-12-06 08:59:30 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:30 --> Input Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Loader Class Initialized
INFO - 2023-12-06 08:59:30 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:30 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:30 --> Controller Class Initialized
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:30 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:30 --> URI Class Initialized
INFO - 2023-12-06 08:59:30 --> Router Class Initialized
INFO - 2023-12-06 08:59:30 --> Output Class Initialized
INFO - 2023-12-06 08:59:30 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:30 --> Input Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Language Class Initialized
INFO - 2023-12-06 08:59:30 --> Config Class Initialized
INFO - 2023-12-06 08:59:30 --> Loader Class Initialized
INFO - 2023-12-06 08:59:30 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:30 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:30 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:30 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 08:59:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:30 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:30 --> Total execution time: 0.0346
INFO - 2023-12-06 08:59:36 --> Config Class Initialized
INFO - 2023-12-06 08:59:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:36 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:36 --> URI Class Initialized
INFO - 2023-12-06 08:59:36 --> Router Class Initialized
INFO - 2023-12-06 08:59:36 --> Output Class Initialized
INFO - 2023-12-06 08:59:36 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:36 --> Input Class Initialized
INFO - 2023-12-06 08:59:36 --> Language Class Initialized
INFO - 2023-12-06 08:59:36 --> Language Class Initialized
INFO - 2023-12-06 08:59:36 --> Config Class Initialized
INFO - 2023-12-06 08:59:36 --> Loader Class Initialized
INFO - 2023-12-06 08:59:36 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:36 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:36 --> Controller Class Initialized
INFO - 2023-12-06 08:59:36 --> Helper loaded: cookie_helper
INFO - 2023-12-06 08:59:36 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:36 --> Total execution time: 0.0304
INFO - 2023-12-06 08:59:36 --> Config Class Initialized
INFO - 2023-12-06 08:59:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:36 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:36 --> URI Class Initialized
INFO - 2023-12-06 08:59:36 --> Router Class Initialized
INFO - 2023-12-06 08:59:36 --> Output Class Initialized
INFO - 2023-12-06 08:59:36 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:36 --> Input Class Initialized
INFO - 2023-12-06 08:59:36 --> Language Class Initialized
INFO - 2023-12-06 08:59:36 --> Language Class Initialized
INFO - 2023-12-06 08:59:36 --> Config Class Initialized
INFO - 2023-12-06 08:59:36 --> Loader Class Initialized
INFO - 2023-12-06 08:59:36 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:36 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:36 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:36 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 08:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:36 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:36 --> Total execution time: 0.0362
INFO - 2023-12-06 08:59:41 --> Config Class Initialized
INFO - 2023-12-06 08:59:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:41 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:41 --> URI Class Initialized
INFO - 2023-12-06 08:59:41 --> Router Class Initialized
INFO - 2023-12-06 08:59:41 --> Output Class Initialized
INFO - 2023-12-06 08:59:41 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:41 --> Input Class Initialized
INFO - 2023-12-06 08:59:41 --> Language Class Initialized
INFO - 2023-12-06 08:59:41 --> Language Class Initialized
INFO - 2023-12-06 08:59:41 --> Config Class Initialized
INFO - 2023-12-06 08:59:41 --> Loader Class Initialized
INFO - 2023-12-06 08:59:41 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:41 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:41 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:41 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:41 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:41 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 08:59:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:41 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:41 --> Total execution time: 0.0383
INFO - 2023-12-06 08:59:51 --> Config Class Initialized
INFO - 2023-12-06 08:59:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:51 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:51 --> URI Class Initialized
INFO - 2023-12-06 08:59:51 --> Router Class Initialized
INFO - 2023-12-06 08:59:51 --> Output Class Initialized
INFO - 2023-12-06 08:59:51 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:51 --> Input Class Initialized
INFO - 2023-12-06 08:59:51 --> Language Class Initialized
INFO - 2023-12-06 08:59:51 --> Language Class Initialized
INFO - 2023-12-06 08:59:51 --> Config Class Initialized
INFO - 2023-12-06 08:59:51 --> Loader Class Initialized
INFO - 2023-12-06 08:59:51 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:51 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:51 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:51 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:51 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:51 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-06 08:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:51 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:51 --> Total execution time: 0.0550
INFO - 2023-12-06 08:59:59 --> Config Class Initialized
INFO - 2023-12-06 08:59:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:59 --> URI Class Initialized
INFO - 2023-12-06 08:59:59 --> Router Class Initialized
INFO - 2023-12-06 08:59:59 --> Output Class Initialized
INFO - 2023-12-06 08:59:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:59 --> Input Class Initialized
INFO - 2023-12-06 08:59:59 --> Language Class Initialized
INFO - 2023-12-06 08:59:59 --> Language Class Initialized
INFO - 2023-12-06 08:59:59 --> Config Class Initialized
INFO - 2023-12-06 08:59:59 --> Loader Class Initialized
INFO - 2023-12-06 08:59:59 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:59 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:59 --> Controller Class Initialized
DEBUG - 2023-12-06 08:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 08:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 08:59:59 --> Final output sent to browser
DEBUG - 2023-12-06 08:59:59 --> Total execution time: 0.0314
INFO - 2023-12-06 08:59:59 --> Config Class Initialized
INFO - 2023-12-06 08:59:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:59 --> URI Class Initialized
INFO - 2023-12-06 08:59:59 --> Router Class Initialized
INFO - 2023-12-06 08:59:59 --> Output Class Initialized
INFO - 2023-12-06 08:59:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:59 --> Input Class Initialized
INFO - 2023-12-06 08:59:59 --> Language Class Initialized
ERROR - 2023-12-06 08:59:59 --> 404 Page Not Found: /index
INFO - 2023-12-06 08:59:59 --> Config Class Initialized
INFO - 2023-12-06 08:59:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 08:59:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 08:59:59 --> Utf8 Class Initialized
INFO - 2023-12-06 08:59:59 --> URI Class Initialized
INFO - 2023-12-06 08:59:59 --> Router Class Initialized
INFO - 2023-12-06 08:59:59 --> Output Class Initialized
INFO - 2023-12-06 08:59:59 --> Security Class Initialized
DEBUG - 2023-12-06 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 08:59:59 --> Input Class Initialized
INFO - 2023-12-06 08:59:59 --> Language Class Initialized
INFO - 2023-12-06 08:59:59 --> Language Class Initialized
INFO - 2023-12-06 08:59:59 --> Config Class Initialized
INFO - 2023-12-06 08:59:59 --> Loader Class Initialized
INFO - 2023-12-06 08:59:59 --> Helper loaded: url_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: file_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: form_helper
INFO - 2023-12-06 08:59:59 --> Helper loaded: my_helper
INFO - 2023-12-06 08:59:59 --> Database Driver Class Initialized
INFO - 2023-12-06 08:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 08:59:59 --> Controller Class Initialized
INFO - 2023-12-06 09:00:02 --> Config Class Initialized
INFO - 2023-12-06 09:00:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:02 --> URI Class Initialized
INFO - 2023-12-06 09:00:02 --> Router Class Initialized
INFO - 2023-12-06 09:00:02 --> Output Class Initialized
INFO - 2023-12-06 09:00:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:03 --> Input Class Initialized
INFO - 2023-12-06 09:00:03 --> Language Class Initialized
INFO - 2023-12-06 09:00:03 --> Language Class Initialized
INFO - 2023-12-06 09:00:03 --> Config Class Initialized
INFO - 2023-12-06 09:00:03 --> Loader Class Initialized
INFO - 2023-12-06 09:00:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:03 --> Controller Class Initialized
INFO - 2023-12-06 09:00:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:03 --> Total execution time: 0.1572
INFO - 2023-12-06 09:00:05 --> Config Class Initialized
INFO - 2023-12-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:05 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:05 --> URI Class Initialized
INFO - 2023-12-06 09:00:05 --> Router Class Initialized
INFO - 2023-12-06 09:00:05 --> Output Class Initialized
INFO - 2023-12-06 09:00:05 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:05 --> Input Class Initialized
INFO - 2023-12-06 09:00:05 --> Language Class Initialized
INFO - 2023-12-06 09:00:05 --> Language Class Initialized
INFO - 2023-12-06 09:00:05 --> Config Class Initialized
INFO - 2023-12-06 09:00:05 --> Loader Class Initialized
INFO - 2023-12-06 09:00:05 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:05 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:05 --> Controller Class Initialized
INFO - 2023-12-06 09:00:05 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:05 --> Total execution time: 0.0896
INFO - 2023-12-06 09:00:05 --> Config Class Initialized
INFO - 2023-12-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:05 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:05 --> URI Class Initialized
INFO - 2023-12-06 09:00:05 --> Router Class Initialized
INFO - 2023-12-06 09:00:05 --> Output Class Initialized
INFO - 2023-12-06 09:00:05 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:05 --> Input Class Initialized
INFO - 2023-12-06 09:00:05 --> Language Class Initialized
ERROR - 2023-12-06 09:00:05 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:00:05 --> Config Class Initialized
INFO - 2023-12-06 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:05 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:05 --> URI Class Initialized
INFO - 2023-12-06 09:00:05 --> Router Class Initialized
INFO - 2023-12-06 09:00:05 --> Output Class Initialized
INFO - 2023-12-06 09:00:05 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:05 --> Input Class Initialized
INFO - 2023-12-06 09:00:05 --> Language Class Initialized
INFO - 2023-12-06 09:00:05 --> Language Class Initialized
INFO - 2023-12-06 09:00:05 --> Config Class Initialized
INFO - 2023-12-06 09:00:05 --> Loader Class Initialized
INFO - 2023-12-06 09:00:05 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:05 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:05 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:05 --> Controller Class Initialized
INFO - 2023-12-06 09:00:14 --> Config Class Initialized
INFO - 2023-12-06 09:00:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:14 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:14 --> URI Class Initialized
INFO - 2023-12-06 09:00:14 --> Router Class Initialized
INFO - 2023-12-06 09:00:14 --> Output Class Initialized
INFO - 2023-12-06 09:00:14 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:14 --> Input Class Initialized
INFO - 2023-12-06 09:00:14 --> Language Class Initialized
INFO - 2023-12-06 09:00:14 --> Language Class Initialized
INFO - 2023-12-06 09:00:14 --> Config Class Initialized
INFO - 2023-12-06 09:00:14 --> Loader Class Initialized
INFO - 2023-12-06 09:00:14 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:14 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:14 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:14 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:14 --> Total execution time: 0.0456
INFO - 2023-12-06 09:00:14 --> Config Class Initialized
INFO - 2023-12-06 09:00:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:14 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:14 --> URI Class Initialized
INFO - 2023-12-06 09:00:14 --> Router Class Initialized
INFO - 2023-12-06 09:00:14 --> Output Class Initialized
INFO - 2023-12-06 09:00:14 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:14 --> Input Class Initialized
INFO - 2023-12-06 09:00:14 --> Language Class Initialized
ERROR - 2023-12-06 09:00:14 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:00:14 --> Config Class Initialized
INFO - 2023-12-06 09:00:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:14 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:14 --> URI Class Initialized
INFO - 2023-12-06 09:00:14 --> Router Class Initialized
INFO - 2023-12-06 09:00:14 --> Output Class Initialized
INFO - 2023-12-06 09:00:14 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:14 --> Input Class Initialized
INFO - 2023-12-06 09:00:14 --> Language Class Initialized
INFO - 2023-12-06 09:00:14 --> Language Class Initialized
INFO - 2023-12-06 09:00:14 --> Config Class Initialized
INFO - 2023-12-06 09:00:14 --> Loader Class Initialized
INFO - 2023-12-06 09:00:14 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:14 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:14 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:14 --> Controller Class Initialized
INFO - 2023-12-06 09:00:16 --> Config Class Initialized
INFO - 2023-12-06 09:00:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:16 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:16 --> URI Class Initialized
INFO - 2023-12-06 09:00:16 --> Router Class Initialized
INFO - 2023-12-06 09:00:16 --> Output Class Initialized
INFO - 2023-12-06 09:00:16 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:16 --> Input Class Initialized
INFO - 2023-12-06 09:00:16 --> Language Class Initialized
INFO - 2023-12-06 09:00:16 --> Language Class Initialized
INFO - 2023-12-06 09:00:16 --> Config Class Initialized
INFO - 2023-12-06 09:00:16 --> Loader Class Initialized
INFO - 2023-12-06 09:00:16 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:16 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:16 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:16 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:16 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:16 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:00:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:16 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:16 --> Total execution time: 0.0422
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:29 --> URI Class Initialized
INFO - 2023-12-06 09:00:29 --> Router Class Initialized
INFO - 2023-12-06 09:00:29 --> Output Class Initialized
INFO - 2023-12-06 09:00:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:29 --> Input Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Loader Class Initialized
INFO - 2023-12-06 09:00:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:29 --> Controller Class Initialized
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:29 --> URI Class Initialized
INFO - 2023-12-06 09:00:29 --> Router Class Initialized
INFO - 2023-12-06 09:00:29 --> Output Class Initialized
INFO - 2023-12-06 09:00:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:29 --> Input Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Loader Class Initialized
INFO - 2023-12-06 09:00:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:29 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:00:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:29 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:29 --> Total execution time: 0.0337
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:29 --> URI Class Initialized
INFO - 2023-12-06 09:00:29 --> Router Class Initialized
INFO - 2023-12-06 09:00:29 --> Output Class Initialized
INFO - 2023-12-06 09:00:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:29 --> Input Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
ERROR - 2023-12-06 09:00:29 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:29 --> URI Class Initialized
INFO - 2023-12-06 09:00:29 --> Router Class Initialized
INFO - 2023-12-06 09:00:29 --> Output Class Initialized
INFO - 2023-12-06 09:00:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:29 --> Input Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Language Class Initialized
INFO - 2023-12-06 09:00:29 --> Config Class Initialized
INFO - 2023-12-06 09:00:29 --> Loader Class Initialized
INFO - 2023-12-06 09:00:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:30 --> Controller Class Initialized
INFO - 2023-12-06 09:00:40 --> Config Class Initialized
INFO - 2023-12-06 09:00:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:40 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:40 --> URI Class Initialized
INFO - 2023-12-06 09:00:40 --> Router Class Initialized
INFO - 2023-12-06 09:00:40 --> Output Class Initialized
INFO - 2023-12-06 09:00:40 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:40 --> Input Class Initialized
INFO - 2023-12-06 09:00:40 --> Language Class Initialized
INFO - 2023-12-06 09:00:40 --> Language Class Initialized
INFO - 2023-12-06 09:00:40 --> Config Class Initialized
INFO - 2023-12-06 09:00:40 --> Loader Class Initialized
INFO - 2023-12-06 09:00:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:40 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:40 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:40 --> Total execution time: 0.0395
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:47 --> URI Class Initialized
INFO - 2023-12-06 09:00:47 --> Router Class Initialized
INFO - 2023-12-06 09:00:47 --> Output Class Initialized
INFO - 2023-12-06 09:00:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:47 --> Input Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Loader Class Initialized
INFO - 2023-12-06 09:00:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:47 --> Controller Class Initialized
INFO - 2023-12-06 09:00:47 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:47 --> URI Class Initialized
INFO - 2023-12-06 09:00:47 --> Router Class Initialized
INFO - 2023-12-06 09:00:47 --> Output Class Initialized
INFO - 2023-12-06 09:00:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:47 --> Input Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Loader Class Initialized
INFO - 2023-12-06 09:00:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:47 --> Controller Class Initialized
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:47 --> URI Class Initialized
INFO - 2023-12-06 09:00:47 --> Router Class Initialized
INFO - 2023-12-06 09:00:47 --> Output Class Initialized
INFO - 2023-12-06 09:00:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:47 --> Input Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Language Class Initialized
INFO - 2023-12-06 09:00:47 --> Config Class Initialized
INFO - 2023-12-06 09:00:47 --> Loader Class Initialized
INFO - 2023-12-06 09:00:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:47 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:00:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:47 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:47 --> Total execution time: 0.0695
INFO - 2023-12-06 09:00:52 --> Config Class Initialized
INFO - 2023-12-06 09:00:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:52 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:52 --> URI Class Initialized
INFO - 2023-12-06 09:00:52 --> Router Class Initialized
INFO - 2023-12-06 09:00:52 --> Output Class Initialized
INFO - 2023-12-06 09:00:52 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:52 --> Input Class Initialized
INFO - 2023-12-06 09:00:52 --> Language Class Initialized
INFO - 2023-12-06 09:00:52 --> Language Class Initialized
INFO - 2023-12-06 09:00:52 --> Config Class Initialized
INFO - 2023-12-06 09:00:52 --> Loader Class Initialized
INFO - 2023-12-06 09:00:52 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:52 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:52 --> Controller Class Initialized
INFO - 2023-12-06 09:00:52 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:00:52 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:52 --> Total execution time: 0.0382
INFO - 2023-12-06 09:00:52 --> Config Class Initialized
INFO - 2023-12-06 09:00:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:52 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:52 --> URI Class Initialized
INFO - 2023-12-06 09:00:52 --> Router Class Initialized
INFO - 2023-12-06 09:00:52 --> Output Class Initialized
INFO - 2023-12-06 09:00:52 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:52 --> Input Class Initialized
INFO - 2023-12-06 09:00:52 --> Language Class Initialized
INFO - 2023-12-06 09:00:52 --> Language Class Initialized
INFO - 2023-12-06 09:00:52 --> Config Class Initialized
INFO - 2023-12-06 09:00:52 --> Loader Class Initialized
INFO - 2023-12-06 09:00:52 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:52 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:52 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:52 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:52 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:52 --> Total execution time: 0.0380
INFO - 2023-12-06 09:00:58 --> Config Class Initialized
INFO - 2023-12-06 09:00:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:00:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:00:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:00:58 --> URI Class Initialized
INFO - 2023-12-06 09:00:58 --> Router Class Initialized
INFO - 2023-12-06 09:00:58 --> Output Class Initialized
INFO - 2023-12-06 09:00:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:00:58 --> Input Class Initialized
INFO - 2023-12-06 09:00:58 --> Language Class Initialized
INFO - 2023-12-06 09:00:58 --> Language Class Initialized
INFO - 2023-12-06 09:00:58 --> Config Class Initialized
INFO - 2023-12-06 09:00:58 --> Loader Class Initialized
INFO - 2023-12-06 09:00:58 --> Helper loaded: url_helper
INFO - 2023-12-06 09:00:58 --> Helper loaded: file_helper
INFO - 2023-12-06 09:00:58 --> Helper loaded: form_helper
INFO - 2023-12-06 09:00:58 --> Helper loaded: my_helper
INFO - 2023-12-06 09:00:58 --> Database Driver Class Initialized
INFO - 2023-12-06 09:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:00:58 --> Controller Class Initialized
DEBUG - 2023-12-06 09:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:00:58 --> Final output sent to browser
DEBUG - 2023-12-06 09:00:58 --> Total execution time: 0.0411
INFO - 2023-12-06 09:01:11 --> Config Class Initialized
INFO - 2023-12-06 09:01:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:01:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:01:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:01:11 --> URI Class Initialized
INFO - 2023-12-06 09:01:11 --> Router Class Initialized
INFO - 2023-12-06 09:01:11 --> Output Class Initialized
INFO - 2023-12-06 09:01:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:01:11 --> Input Class Initialized
INFO - 2023-12-06 09:01:11 --> Language Class Initialized
INFO - 2023-12-06 09:01:11 --> Language Class Initialized
INFO - 2023-12-06 09:01:11 --> Config Class Initialized
INFO - 2023-12-06 09:01:11 --> Loader Class Initialized
INFO - 2023-12-06 09:01:11 --> Helper loaded: url_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: file_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: form_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: my_helper
INFO - 2023-12-06 09:01:11 --> Database Driver Class Initialized
INFO - 2023-12-06 09:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:01:11 --> Controller Class Initialized
DEBUG - 2023-12-06 09:01:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:01:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:01:11 --> Final output sent to browser
DEBUG - 2023-12-06 09:01:11 --> Total execution time: 0.0462
INFO - 2023-12-06 09:01:11 --> Config Class Initialized
INFO - 2023-12-06 09:01:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:01:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:01:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:01:11 --> URI Class Initialized
INFO - 2023-12-06 09:01:11 --> Router Class Initialized
INFO - 2023-12-06 09:01:11 --> Output Class Initialized
INFO - 2023-12-06 09:01:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:01:11 --> Input Class Initialized
INFO - 2023-12-06 09:01:11 --> Language Class Initialized
INFO - 2023-12-06 09:01:11 --> Language Class Initialized
INFO - 2023-12-06 09:01:11 --> Config Class Initialized
INFO - 2023-12-06 09:01:11 --> Loader Class Initialized
INFO - 2023-12-06 09:01:11 --> Helper loaded: url_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: file_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: form_helper
INFO - 2023-12-06 09:01:11 --> Helper loaded: my_helper
INFO - 2023-12-06 09:01:11 --> Database Driver Class Initialized
INFO - 2023-12-06 09:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:01:11 --> Controller Class Initialized
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:04:35 --> URI Class Initialized
INFO - 2023-12-06 09:04:35 --> Router Class Initialized
INFO - 2023-12-06 09:04:35 --> Output Class Initialized
INFO - 2023-12-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:04:35 --> Input Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Loader Class Initialized
INFO - 2023-12-06 09:04:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:04:35 --> Controller Class Initialized
INFO - 2023-12-06 09:04:35 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:04:35 --> URI Class Initialized
INFO - 2023-12-06 09:04:35 --> Router Class Initialized
INFO - 2023-12-06 09:04:35 --> Output Class Initialized
INFO - 2023-12-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:04:35 --> Input Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Loader Class Initialized
INFO - 2023-12-06 09:04:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:04:35 --> Controller Class Initialized
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:04:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:04:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:04:35 --> URI Class Initialized
INFO - 2023-12-06 09:04:35 --> Router Class Initialized
INFO - 2023-12-06 09:04:35 --> Output Class Initialized
INFO - 2023-12-06 09:04:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:04:35 --> Input Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Language Class Initialized
INFO - 2023-12-06 09:04:35 --> Config Class Initialized
INFO - 2023-12-06 09:04:35 --> Loader Class Initialized
INFO - 2023-12-06 09:04:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:04:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:04:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:04:35 --> Controller Class Initialized
DEBUG - 2023-12-06 09:04:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:04:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:04:35 --> Final output sent to browser
DEBUG - 2023-12-06 09:04:35 --> Total execution time: 0.0644
INFO - 2023-12-06 09:08:10 --> Config Class Initialized
INFO - 2023-12-06 09:08:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:08:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:08:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:08:10 --> URI Class Initialized
INFO - 2023-12-06 09:08:10 --> Router Class Initialized
INFO - 2023-12-06 09:08:10 --> Output Class Initialized
INFO - 2023-12-06 09:08:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:08:10 --> Input Class Initialized
INFO - 2023-12-06 09:08:10 --> Language Class Initialized
INFO - 2023-12-06 09:08:10 --> Language Class Initialized
INFO - 2023-12-06 09:08:10 --> Config Class Initialized
INFO - 2023-12-06 09:08:10 --> Loader Class Initialized
INFO - 2023-12-06 09:08:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:08:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:08:10 --> Controller Class Initialized
INFO - 2023-12-06 09:08:10 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:08:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:08:10 --> Total execution time: 0.0396
INFO - 2023-12-06 09:08:10 --> Config Class Initialized
INFO - 2023-12-06 09:08:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:08:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:08:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:08:10 --> URI Class Initialized
INFO - 2023-12-06 09:08:10 --> Router Class Initialized
INFO - 2023-12-06 09:08:10 --> Output Class Initialized
INFO - 2023-12-06 09:08:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:08:10 --> Input Class Initialized
INFO - 2023-12-06 09:08:10 --> Language Class Initialized
INFO - 2023-12-06 09:08:10 --> Language Class Initialized
INFO - 2023-12-06 09:08:10 --> Config Class Initialized
INFO - 2023-12-06 09:08:10 --> Loader Class Initialized
INFO - 2023-12-06 09:08:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:08:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:08:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:08:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:08:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 09:08:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:08:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:08:10 --> Total execution time: 0.0385
INFO - 2023-12-06 09:10:30 --> Config Class Initialized
INFO - 2023-12-06 09:10:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:30 --> URI Class Initialized
INFO - 2023-12-06 09:10:30 --> Router Class Initialized
INFO - 2023-12-06 09:10:30 --> Output Class Initialized
INFO - 2023-12-06 09:10:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:30 --> Input Class Initialized
INFO - 2023-12-06 09:10:30 --> Language Class Initialized
INFO - 2023-12-06 09:10:30 --> Language Class Initialized
INFO - 2023-12-06 09:10:30 --> Config Class Initialized
INFO - 2023-12-06 09:10:30 --> Loader Class Initialized
INFO - 2023-12-06 09:10:30 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:30 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:30 --> Controller Class Initialized
DEBUG - 2023-12-06 09:10:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:10:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:10:30 --> Final output sent to browser
DEBUG - 2023-12-06 09:10:30 --> Total execution time: 0.0627
INFO - 2023-12-06 09:10:30 --> Config Class Initialized
INFO - 2023-12-06 09:10:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:30 --> URI Class Initialized
INFO - 2023-12-06 09:10:30 --> Router Class Initialized
INFO - 2023-12-06 09:10:30 --> Output Class Initialized
INFO - 2023-12-06 09:10:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:30 --> Input Class Initialized
INFO - 2023-12-06 09:10:30 --> Language Class Initialized
ERROR - 2023-12-06 09:10:30 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:10:30 --> Config Class Initialized
INFO - 2023-12-06 09:10:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:30 --> URI Class Initialized
INFO - 2023-12-06 09:10:30 --> Router Class Initialized
INFO - 2023-12-06 09:10:30 --> Output Class Initialized
INFO - 2023-12-06 09:10:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:30 --> Input Class Initialized
INFO - 2023-12-06 09:10:30 --> Language Class Initialized
INFO - 2023-12-06 09:10:30 --> Language Class Initialized
INFO - 2023-12-06 09:10:30 --> Config Class Initialized
INFO - 2023-12-06 09:10:30 --> Loader Class Initialized
INFO - 2023-12-06 09:10:30 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:30 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:30 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:30 --> Controller Class Initialized
INFO - 2023-12-06 09:10:35 --> Config Class Initialized
INFO - 2023-12-06 09:10:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:35 --> URI Class Initialized
INFO - 2023-12-06 09:10:35 --> Router Class Initialized
INFO - 2023-12-06 09:10:35 --> Output Class Initialized
INFO - 2023-12-06 09:10:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:35 --> Input Class Initialized
INFO - 2023-12-06 09:10:35 --> Language Class Initialized
INFO - 2023-12-06 09:10:35 --> Language Class Initialized
INFO - 2023-12-06 09:10:35 --> Config Class Initialized
INFO - 2023-12-06 09:10:35 --> Loader Class Initialized
INFO - 2023-12-06 09:10:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:35 --> Controller Class Initialized
DEBUG - 2023-12-06 09:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:10:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:10:35 --> Final output sent to browser
DEBUG - 2023-12-06 09:10:35 --> Total execution time: 0.0384
INFO - 2023-12-06 09:10:38 --> Config Class Initialized
INFO - 2023-12-06 09:10:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:38 --> URI Class Initialized
INFO - 2023-12-06 09:10:38 --> Router Class Initialized
INFO - 2023-12-06 09:10:38 --> Output Class Initialized
INFO - 2023-12-06 09:10:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:38 --> Input Class Initialized
INFO - 2023-12-06 09:10:38 --> Language Class Initialized
INFO - 2023-12-06 09:10:38 --> Language Class Initialized
INFO - 2023-12-06 09:10:38 --> Config Class Initialized
INFO - 2023-12-06 09:10:38 --> Loader Class Initialized
INFO - 2023-12-06 09:10:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:38 --> Controller Class Initialized
DEBUG - 2023-12-06 09:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:10:38 --> Final output sent to browser
DEBUG - 2023-12-06 09:10:38 --> Total execution time: 0.0474
INFO - 2023-12-06 09:10:38 --> Config Class Initialized
INFO - 2023-12-06 09:10:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:38 --> URI Class Initialized
INFO - 2023-12-06 09:10:38 --> Router Class Initialized
INFO - 2023-12-06 09:10:38 --> Output Class Initialized
INFO - 2023-12-06 09:10:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:38 --> Input Class Initialized
INFO - 2023-12-06 09:10:38 --> Language Class Initialized
ERROR - 2023-12-06 09:10:38 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:10:38 --> Config Class Initialized
INFO - 2023-12-06 09:10:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:38 --> URI Class Initialized
INFO - 2023-12-06 09:10:38 --> Router Class Initialized
INFO - 2023-12-06 09:10:38 --> Output Class Initialized
INFO - 2023-12-06 09:10:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:38 --> Input Class Initialized
INFO - 2023-12-06 09:10:38 --> Language Class Initialized
INFO - 2023-12-06 09:10:38 --> Language Class Initialized
INFO - 2023-12-06 09:10:38 --> Config Class Initialized
INFO - 2023-12-06 09:10:38 --> Loader Class Initialized
INFO - 2023-12-06 09:10:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:38 --> Controller Class Initialized
INFO - 2023-12-06 09:10:49 --> Config Class Initialized
INFO - 2023-12-06 09:10:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:49 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:49 --> URI Class Initialized
INFO - 2023-12-06 09:10:49 --> Router Class Initialized
INFO - 2023-12-06 09:10:49 --> Output Class Initialized
INFO - 2023-12-06 09:10:49 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:49 --> Input Class Initialized
INFO - 2023-12-06 09:10:49 --> Language Class Initialized
INFO - 2023-12-06 09:10:49 --> Language Class Initialized
INFO - 2023-12-06 09:10:49 --> Config Class Initialized
INFO - 2023-12-06 09:10:49 --> Loader Class Initialized
INFO - 2023-12-06 09:10:49 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:49 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:49 --> Controller Class Initialized
DEBUG - 2023-12-06 09:10:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:10:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:10:49 --> Final output sent to browser
DEBUG - 2023-12-06 09:10:49 --> Total execution time: 0.0400
INFO - 2023-12-06 09:10:49 --> Config Class Initialized
INFO - 2023-12-06 09:10:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:49 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:49 --> URI Class Initialized
INFO - 2023-12-06 09:10:49 --> Router Class Initialized
INFO - 2023-12-06 09:10:49 --> Output Class Initialized
INFO - 2023-12-06 09:10:49 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:49 --> Input Class Initialized
INFO - 2023-12-06 09:10:49 --> Language Class Initialized
ERROR - 2023-12-06 09:10:49 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:10:49 --> Config Class Initialized
INFO - 2023-12-06 09:10:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:49 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:49 --> URI Class Initialized
INFO - 2023-12-06 09:10:49 --> Router Class Initialized
INFO - 2023-12-06 09:10:49 --> Output Class Initialized
INFO - 2023-12-06 09:10:49 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:49 --> Input Class Initialized
INFO - 2023-12-06 09:10:49 --> Language Class Initialized
INFO - 2023-12-06 09:10:49 --> Language Class Initialized
INFO - 2023-12-06 09:10:49 --> Config Class Initialized
INFO - 2023-12-06 09:10:49 --> Loader Class Initialized
INFO - 2023-12-06 09:10:49 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:49 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:49 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:49 --> Controller Class Initialized
INFO - 2023-12-06 09:10:53 --> Config Class Initialized
INFO - 2023-12-06 09:10:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:10:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:10:53 --> Utf8 Class Initialized
INFO - 2023-12-06 09:10:53 --> URI Class Initialized
INFO - 2023-12-06 09:10:53 --> Router Class Initialized
INFO - 2023-12-06 09:10:53 --> Output Class Initialized
INFO - 2023-12-06 09:10:53 --> Security Class Initialized
DEBUG - 2023-12-06 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:10:53 --> Input Class Initialized
INFO - 2023-12-06 09:10:53 --> Language Class Initialized
INFO - 2023-12-06 09:10:53 --> Language Class Initialized
INFO - 2023-12-06 09:10:53 --> Config Class Initialized
INFO - 2023-12-06 09:10:53 --> Loader Class Initialized
INFO - 2023-12-06 09:10:53 --> Helper loaded: url_helper
INFO - 2023-12-06 09:10:53 --> Helper loaded: file_helper
INFO - 2023-12-06 09:10:53 --> Helper loaded: form_helper
INFO - 2023-12-06 09:10:53 --> Helper loaded: my_helper
INFO - 2023-12-06 09:10:53 --> Database Driver Class Initialized
INFO - 2023-12-06 09:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:10:53 --> Controller Class Initialized
INFO - 2023-12-06 09:11:02 --> Config Class Initialized
INFO - 2023-12-06 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:02 --> URI Class Initialized
INFO - 2023-12-06 09:11:02 --> Router Class Initialized
INFO - 2023-12-06 09:11:02 --> Output Class Initialized
INFO - 2023-12-06 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:02 --> Input Class Initialized
INFO - 2023-12-06 09:11:02 --> Language Class Initialized
INFO - 2023-12-06 09:11:02 --> Language Class Initialized
INFO - 2023-12-06 09:11:02 --> Config Class Initialized
INFO - 2023-12-06 09:11:02 --> Loader Class Initialized
INFO - 2023-12-06 09:11:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:02 --> Controller Class Initialized
INFO - 2023-12-06 09:11:02 --> Final output sent to browser
DEBUG - 2023-12-06 09:11:02 --> Total execution time: 0.0376
INFO - 2023-12-06 09:11:02 --> Config Class Initialized
INFO - 2023-12-06 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:02 --> URI Class Initialized
INFO - 2023-12-06 09:11:02 --> Router Class Initialized
INFO - 2023-12-06 09:11:02 --> Output Class Initialized
INFO - 2023-12-06 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:02 --> Input Class Initialized
INFO - 2023-12-06 09:11:02 --> Language Class Initialized
ERROR - 2023-12-06 09:11:02 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:11:02 --> Config Class Initialized
INFO - 2023-12-06 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:02 --> URI Class Initialized
INFO - 2023-12-06 09:11:02 --> Router Class Initialized
INFO - 2023-12-06 09:11:02 --> Output Class Initialized
INFO - 2023-12-06 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:02 --> Input Class Initialized
INFO - 2023-12-06 09:11:02 --> Language Class Initialized
INFO - 2023-12-06 09:11:02 --> Language Class Initialized
INFO - 2023-12-06 09:11:02 --> Config Class Initialized
INFO - 2023-12-06 09:11:02 --> Loader Class Initialized
INFO - 2023-12-06 09:11:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:02 --> Controller Class Initialized
INFO - 2023-12-06 09:11:33 --> Config Class Initialized
INFO - 2023-12-06 09:11:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:33 --> URI Class Initialized
INFO - 2023-12-06 09:11:33 --> Router Class Initialized
INFO - 2023-12-06 09:11:33 --> Output Class Initialized
INFO - 2023-12-06 09:11:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:33 --> Input Class Initialized
INFO - 2023-12-06 09:11:33 --> Language Class Initialized
INFO - 2023-12-06 09:11:33 --> Language Class Initialized
INFO - 2023-12-06 09:11:33 --> Config Class Initialized
INFO - 2023-12-06 09:11:33 --> Loader Class Initialized
INFO - 2023-12-06 09:11:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:33 --> Controller Class Initialized
DEBUG - 2023-12-06 09:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:11:33 --> Final output sent to browser
DEBUG - 2023-12-06 09:11:33 --> Total execution time: 0.0431
INFO - 2023-12-06 09:11:40 --> Config Class Initialized
INFO - 2023-12-06 09:11:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:40 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:40 --> URI Class Initialized
INFO - 2023-12-06 09:11:40 --> Router Class Initialized
INFO - 2023-12-06 09:11:40 --> Output Class Initialized
INFO - 2023-12-06 09:11:40 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:40 --> Input Class Initialized
INFO - 2023-12-06 09:11:40 --> Language Class Initialized
INFO - 2023-12-06 09:11:40 --> Language Class Initialized
INFO - 2023-12-06 09:11:40 --> Config Class Initialized
INFO - 2023-12-06 09:11:40 --> Loader Class Initialized
INFO - 2023-12-06 09:11:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:40 --> Controller Class Initialized
DEBUG - 2023-12-06 09:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-06 09:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:11:40 --> Final output sent to browser
DEBUG - 2023-12-06 09:11:40 --> Total execution time: 0.0409
INFO - 2023-12-06 09:11:40 --> Config Class Initialized
INFO - 2023-12-06 09:11:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:40 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:40 --> URI Class Initialized
INFO - 2023-12-06 09:11:40 --> Router Class Initialized
INFO - 2023-12-06 09:11:40 --> Output Class Initialized
INFO - 2023-12-06 09:11:40 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:40 --> Input Class Initialized
INFO - 2023-12-06 09:11:40 --> Language Class Initialized
ERROR - 2023-12-06 09:11:40 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:11:40 --> Config Class Initialized
INFO - 2023-12-06 09:11:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:40 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:40 --> URI Class Initialized
INFO - 2023-12-06 09:11:40 --> Router Class Initialized
INFO - 2023-12-06 09:11:40 --> Output Class Initialized
INFO - 2023-12-06 09:11:40 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:40 --> Input Class Initialized
INFO - 2023-12-06 09:11:40 --> Language Class Initialized
INFO - 2023-12-06 09:11:40 --> Language Class Initialized
INFO - 2023-12-06 09:11:40 --> Config Class Initialized
INFO - 2023-12-06 09:11:40 --> Loader Class Initialized
INFO - 2023-12-06 09:11:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:40 --> Controller Class Initialized
INFO - 2023-12-06 09:11:41 --> Config Class Initialized
INFO - 2023-12-06 09:11:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:41 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:41 --> URI Class Initialized
INFO - 2023-12-06 09:11:41 --> Router Class Initialized
INFO - 2023-12-06 09:11:41 --> Output Class Initialized
INFO - 2023-12-06 09:11:41 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:41 --> Input Class Initialized
INFO - 2023-12-06 09:11:41 --> Language Class Initialized
INFO - 2023-12-06 09:11:41 --> Language Class Initialized
INFO - 2023-12-06 09:11:41 --> Config Class Initialized
INFO - 2023-12-06 09:11:41 --> Loader Class Initialized
INFO - 2023-12-06 09:11:41 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:41 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:41 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:41 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:41 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:41 --> Controller Class Initialized
INFO - 2023-12-06 09:11:41 --> Final output sent to browser
DEBUG - 2023-12-06 09:11:41 --> Total execution time: 0.0372
INFO - 2023-12-06 09:11:45 --> Config Class Initialized
INFO - 2023-12-06 09:11:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:11:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:11:45 --> Utf8 Class Initialized
INFO - 2023-12-06 09:11:45 --> URI Class Initialized
INFO - 2023-12-06 09:11:45 --> Router Class Initialized
INFO - 2023-12-06 09:11:45 --> Output Class Initialized
INFO - 2023-12-06 09:11:45 --> Security Class Initialized
DEBUG - 2023-12-06 09:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:11:45 --> Input Class Initialized
INFO - 2023-12-06 09:11:45 --> Language Class Initialized
INFO - 2023-12-06 09:11:45 --> Language Class Initialized
INFO - 2023-12-06 09:11:45 --> Config Class Initialized
INFO - 2023-12-06 09:11:45 --> Loader Class Initialized
INFO - 2023-12-06 09:11:45 --> Helper loaded: url_helper
INFO - 2023-12-06 09:11:45 --> Helper loaded: file_helper
INFO - 2023-12-06 09:11:45 --> Helper loaded: form_helper
INFO - 2023-12-06 09:11:45 --> Helper loaded: my_helper
INFO - 2023-12-06 09:11:45 --> Database Driver Class Initialized
INFO - 2023-12-06 09:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:11:45 --> Controller Class Initialized
INFO - 2023-12-06 09:11:45 --> Final output sent to browser
DEBUG - 2023-12-06 09:11:45 --> Total execution time: 0.0330
INFO - 2023-12-06 09:12:09 --> Config Class Initialized
INFO - 2023-12-06 09:12:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:09 --> URI Class Initialized
INFO - 2023-12-06 09:12:09 --> Router Class Initialized
INFO - 2023-12-06 09:12:09 --> Output Class Initialized
INFO - 2023-12-06 09:12:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:09 --> Input Class Initialized
INFO - 2023-12-06 09:12:09 --> Language Class Initialized
INFO - 2023-12-06 09:12:09 --> Language Class Initialized
INFO - 2023-12-06 09:12:09 --> Config Class Initialized
INFO - 2023-12-06 09:12:09 --> Loader Class Initialized
INFO - 2023-12-06 09:12:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:09 --> Controller Class Initialized
INFO - 2023-12-06 09:12:09 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:09 --> Total execution time: 0.0838
INFO - 2023-12-06 09:12:09 --> Config Class Initialized
INFO - 2023-12-06 09:12:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:09 --> URI Class Initialized
INFO - 2023-12-06 09:12:09 --> Router Class Initialized
INFO - 2023-12-06 09:12:09 --> Output Class Initialized
INFO - 2023-12-06 09:12:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:09 --> Input Class Initialized
INFO - 2023-12-06 09:12:09 --> Language Class Initialized
ERROR - 2023-12-06 09:12:09 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:12:10 --> Config Class Initialized
INFO - 2023-12-06 09:12:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:10 --> URI Class Initialized
INFO - 2023-12-06 09:12:10 --> Router Class Initialized
INFO - 2023-12-06 09:12:10 --> Output Class Initialized
INFO - 2023-12-06 09:12:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:10 --> Input Class Initialized
INFO - 2023-12-06 09:12:10 --> Language Class Initialized
INFO - 2023-12-06 09:12:10 --> Language Class Initialized
INFO - 2023-12-06 09:12:10 --> Config Class Initialized
INFO - 2023-12-06 09:12:10 --> Loader Class Initialized
INFO - 2023-12-06 09:12:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:10 --> Controller Class Initialized
INFO - 2023-12-06 09:12:12 --> Config Class Initialized
INFO - 2023-12-06 09:12:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:12 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:12 --> URI Class Initialized
INFO - 2023-12-06 09:12:12 --> Router Class Initialized
INFO - 2023-12-06 09:12:12 --> Output Class Initialized
INFO - 2023-12-06 09:12:12 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:12 --> Input Class Initialized
INFO - 2023-12-06 09:12:12 --> Language Class Initialized
INFO - 2023-12-06 09:12:12 --> Language Class Initialized
INFO - 2023-12-06 09:12:12 --> Config Class Initialized
INFO - 2023-12-06 09:12:12 --> Loader Class Initialized
INFO - 2023-12-06 09:12:12 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:12 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:12 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:12 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:12 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:12 --> Controller Class Initialized
INFO - 2023-12-06 09:12:12 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:12 --> Total execution time: 0.0370
INFO - 2023-12-06 09:12:39 --> Config Class Initialized
INFO - 2023-12-06 09:12:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:39 --> URI Class Initialized
INFO - 2023-12-06 09:12:39 --> Router Class Initialized
INFO - 2023-12-06 09:12:39 --> Output Class Initialized
INFO - 2023-12-06 09:12:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:39 --> Input Class Initialized
INFO - 2023-12-06 09:12:39 --> Language Class Initialized
INFO - 2023-12-06 09:12:39 --> Language Class Initialized
INFO - 2023-12-06 09:12:39 --> Config Class Initialized
INFO - 2023-12-06 09:12:39 --> Loader Class Initialized
INFO - 2023-12-06 09:12:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:39 --> Controller Class Initialized
INFO - 2023-12-06 09:12:39 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:39 --> Total execution time: 0.0399
INFO - 2023-12-06 09:12:39 --> Config Class Initialized
INFO - 2023-12-06 09:12:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:39 --> URI Class Initialized
INFO - 2023-12-06 09:12:39 --> Router Class Initialized
INFO - 2023-12-06 09:12:39 --> Output Class Initialized
INFO - 2023-12-06 09:12:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:39 --> Input Class Initialized
INFO - 2023-12-06 09:12:39 --> Language Class Initialized
ERROR - 2023-12-06 09:12:39 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:12:39 --> Config Class Initialized
INFO - 2023-12-06 09:12:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:39 --> URI Class Initialized
INFO - 2023-12-06 09:12:39 --> Router Class Initialized
INFO - 2023-12-06 09:12:39 --> Output Class Initialized
INFO - 2023-12-06 09:12:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:39 --> Input Class Initialized
INFO - 2023-12-06 09:12:39 --> Language Class Initialized
INFO - 2023-12-06 09:12:39 --> Language Class Initialized
INFO - 2023-12-06 09:12:39 --> Config Class Initialized
INFO - 2023-12-06 09:12:39 --> Loader Class Initialized
INFO - 2023-12-06 09:12:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:39 --> Controller Class Initialized
INFO - 2023-12-06 09:12:47 --> Config Class Initialized
INFO - 2023-12-06 09:12:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:47 --> URI Class Initialized
INFO - 2023-12-06 09:12:47 --> Router Class Initialized
INFO - 2023-12-06 09:12:47 --> Output Class Initialized
INFO - 2023-12-06 09:12:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:47 --> Input Class Initialized
INFO - 2023-12-06 09:12:47 --> Language Class Initialized
INFO - 2023-12-06 09:12:47 --> Language Class Initialized
INFO - 2023-12-06 09:12:47 --> Config Class Initialized
INFO - 2023-12-06 09:12:47 --> Loader Class Initialized
INFO - 2023-12-06 09:12:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:47 --> Controller Class Initialized
DEBUG - 2023-12-06 09:12:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-06 09:12:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:12:47 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:47 --> Total execution time: 0.0315
INFO - 2023-12-06 09:12:47 --> Config Class Initialized
INFO - 2023-12-06 09:12:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:47 --> URI Class Initialized
INFO - 2023-12-06 09:12:47 --> Router Class Initialized
INFO - 2023-12-06 09:12:47 --> Output Class Initialized
INFO - 2023-12-06 09:12:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:47 --> Input Class Initialized
INFO - 2023-12-06 09:12:47 --> Language Class Initialized
ERROR - 2023-12-06 09:12:47 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:12:47 --> Config Class Initialized
INFO - 2023-12-06 09:12:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:47 --> URI Class Initialized
INFO - 2023-12-06 09:12:47 --> Router Class Initialized
INFO - 2023-12-06 09:12:47 --> Output Class Initialized
INFO - 2023-12-06 09:12:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:47 --> Input Class Initialized
INFO - 2023-12-06 09:12:47 --> Language Class Initialized
INFO - 2023-12-06 09:12:47 --> Language Class Initialized
INFO - 2023-12-06 09:12:47 --> Config Class Initialized
INFO - 2023-12-06 09:12:47 --> Loader Class Initialized
INFO - 2023-12-06 09:12:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:47 --> Controller Class Initialized
INFO - 2023-12-06 09:12:50 --> Config Class Initialized
INFO - 2023-12-06 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:50 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:50 --> URI Class Initialized
INFO - 2023-12-06 09:12:50 --> Router Class Initialized
INFO - 2023-12-06 09:12:50 --> Output Class Initialized
INFO - 2023-12-06 09:12:50 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:50 --> Input Class Initialized
INFO - 2023-12-06 09:12:50 --> Language Class Initialized
INFO - 2023-12-06 09:12:50 --> Language Class Initialized
INFO - 2023-12-06 09:12:50 --> Config Class Initialized
INFO - 2023-12-06 09:12:50 --> Loader Class Initialized
INFO - 2023-12-06 09:12:50 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:50 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:50 --> Controller Class Initialized
DEBUG - 2023-12-06 09:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2023-12-06 09:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:12:50 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:50 --> Total execution time: 0.0753
INFO - 2023-12-06 09:12:50 --> Config Class Initialized
INFO - 2023-12-06 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:50 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:50 --> URI Class Initialized
INFO - 2023-12-06 09:12:50 --> Router Class Initialized
INFO - 2023-12-06 09:12:50 --> Output Class Initialized
INFO - 2023-12-06 09:12:50 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:50 --> Input Class Initialized
INFO - 2023-12-06 09:12:50 --> Language Class Initialized
ERROR - 2023-12-06 09:12:50 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:12:50 --> Config Class Initialized
INFO - 2023-12-06 09:12:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:50 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:50 --> URI Class Initialized
INFO - 2023-12-06 09:12:50 --> Router Class Initialized
INFO - 2023-12-06 09:12:50 --> Output Class Initialized
INFO - 2023-12-06 09:12:50 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:50 --> Input Class Initialized
INFO - 2023-12-06 09:12:50 --> Language Class Initialized
INFO - 2023-12-06 09:12:50 --> Language Class Initialized
INFO - 2023-12-06 09:12:50 --> Config Class Initialized
INFO - 2023-12-06 09:12:50 --> Loader Class Initialized
INFO - 2023-12-06 09:12:50 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:50 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:50 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:50 --> Controller Class Initialized
INFO - 2023-12-06 09:12:53 --> Config Class Initialized
INFO - 2023-12-06 09:12:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:12:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:12:53 --> Utf8 Class Initialized
INFO - 2023-12-06 09:12:53 --> URI Class Initialized
INFO - 2023-12-06 09:12:53 --> Router Class Initialized
INFO - 2023-12-06 09:12:53 --> Output Class Initialized
INFO - 2023-12-06 09:12:53 --> Security Class Initialized
DEBUG - 2023-12-06 09:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:12:53 --> Input Class Initialized
INFO - 2023-12-06 09:12:53 --> Language Class Initialized
INFO - 2023-12-06 09:12:53 --> Language Class Initialized
INFO - 2023-12-06 09:12:53 --> Config Class Initialized
INFO - 2023-12-06 09:12:53 --> Loader Class Initialized
INFO - 2023-12-06 09:12:53 --> Helper loaded: url_helper
INFO - 2023-12-06 09:12:53 --> Helper loaded: file_helper
INFO - 2023-12-06 09:12:53 --> Helper loaded: form_helper
INFO - 2023-12-06 09:12:53 --> Helper loaded: my_helper
INFO - 2023-12-06 09:12:53 --> Database Driver Class Initialized
INFO - 2023-12-06 09:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:12:53 --> Controller Class Initialized
INFO - 2023-12-06 09:12:53 --> Final output sent to browser
DEBUG - 2023-12-06 09:12:53 --> Total execution time: 0.0335
INFO - 2023-12-06 09:13:03 --> Config Class Initialized
INFO - 2023-12-06 09:13:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:03 --> URI Class Initialized
INFO - 2023-12-06 09:13:03 --> Router Class Initialized
INFO - 2023-12-06 09:13:03 --> Output Class Initialized
INFO - 2023-12-06 09:13:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:03 --> Input Class Initialized
INFO - 2023-12-06 09:13:03 --> Language Class Initialized
INFO - 2023-12-06 09:13:03 --> Language Class Initialized
INFO - 2023-12-06 09:13:03 --> Config Class Initialized
INFO - 2023-12-06 09:13:03 --> Loader Class Initialized
INFO - 2023-12-06 09:13:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:03 --> Controller Class Initialized
INFO - 2023-12-06 09:13:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:03 --> Total execution time: 0.0529
INFO - 2023-12-06 09:13:04 --> Config Class Initialized
INFO - 2023-12-06 09:13:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:04 --> URI Class Initialized
INFO - 2023-12-06 09:13:04 --> Router Class Initialized
INFO - 2023-12-06 09:13:04 --> Output Class Initialized
INFO - 2023-12-06 09:13:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:04 --> Input Class Initialized
INFO - 2023-12-06 09:13:04 --> Language Class Initialized
ERROR - 2023-12-06 09:13:04 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:04 --> Config Class Initialized
INFO - 2023-12-06 09:13:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:04 --> URI Class Initialized
INFO - 2023-12-06 09:13:04 --> Router Class Initialized
INFO - 2023-12-06 09:13:04 --> Output Class Initialized
INFO - 2023-12-06 09:13:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:04 --> Input Class Initialized
INFO - 2023-12-06 09:13:04 --> Language Class Initialized
INFO - 2023-12-06 09:13:04 --> Language Class Initialized
INFO - 2023-12-06 09:13:04 --> Config Class Initialized
INFO - 2023-12-06 09:13:04 --> Loader Class Initialized
INFO - 2023-12-06 09:13:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:04 --> Controller Class Initialized
INFO - 2023-12-06 09:13:06 --> Config Class Initialized
INFO - 2023-12-06 09:13:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:06 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:06 --> URI Class Initialized
INFO - 2023-12-06 09:13:06 --> Router Class Initialized
INFO - 2023-12-06 09:13:06 --> Output Class Initialized
INFO - 2023-12-06 09:13:06 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:06 --> Input Class Initialized
INFO - 2023-12-06 09:13:06 --> Language Class Initialized
INFO - 2023-12-06 09:13:06 --> Language Class Initialized
INFO - 2023-12-06 09:13:06 --> Config Class Initialized
INFO - 2023-12-06 09:13:06 --> Loader Class Initialized
INFO - 2023-12-06 09:13:06 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:06 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:06 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:06 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:06 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:06 --> Controller Class Initialized
INFO - 2023-12-06 09:13:06 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:06 --> Total execution time: 0.0333
INFO - 2023-12-06 09:13:11 --> Config Class Initialized
INFO - 2023-12-06 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:11 --> URI Class Initialized
INFO - 2023-12-06 09:13:11 --> Router Class Initialized
INFO - 2023-12-06 09:13:11 --> Output Class Initialized
INFO - 2023-12-06 09:13:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:11 --> Input Class Initialized
INFO - 2023-12-06 09:13:11 --> Language Class Initialized
INFO - 2023-12-06 09:13:11 --> Language Class Initialized
INFO - 2023-12-06 09:13:11 --> Config Class Initialized
INFO - 2023-12-06 09:13:11 --> Loader Class Initialized
INFO - 2023-12-06 09:13:11 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:11 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:11 --> Controller Class Initialized
INFO - 2023-12-06 09:13:11 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:11 --> Total execution time: 0.0338
INFO - 2023-12-06 09:13:11 --> Config Class Initialized
INFO - 2023-12-06 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:11 --> URI Class Initialized
INFO - 2023-12-06 09:13:11 --> Router Class Initialized
INFO - 2023-12-06 09:13:11 --> Output Class Initialized
INFO - 2023-12-06 09:13:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:11 --> Input Class Initialized
INFO - 2023-12-06 09:13:11 --> Language Class Initialized
ERROR - 2023-12-06 09:13:11 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:11 --> Config Class Initialized
INFO - 2023-12-06 09:13:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:11 --> URI Class Initialized
INFO - 2023-12-06 09:13:11 --> Router Class Initialized
INFO - 2023-12-06 09:13:11 --> Output Class Initialized
INFO - 2023-12-06 09:13:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:11 --> Input Class Initialized
INFO - 2023-12-06 09:13:11 --> Language Class Initialized
INFO - 2023-12-06 09:13:11 --> Language Class Initialized
INFO - 2023-12-06 09:13:11 --> Config Class Initialized
INFO - 2023-12-06 09:13:11 --> Loader Class Initialized
INFO - 2023-12-06 09:13:11 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:11 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:11 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:11 --> Controller Class Initialized
INFO - 2023-12-06 09:13:13 --> Config Class Initialized
INFO - 2023-12-06 09:13:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:13 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:13 --> URI Class Initialized
INFO - 2023-12-06 09:13:13 --> Router Class Initialized
INFO - 2023-12-06 09:13:13 --> Output Class Initialized
INFO - 2023-12-06 09:13:13 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:13 --> Input Class Initialized
INFO - 2023-12-06 09:13:13 --> Language Class Initialized
INFO - 2023-12-06 09:13:13 --> Language Class Initialized
INFO - 2023-12-06 09:13:13 --> Config Class Initialized
INFO - 2023-12-06 09:13:13 --> Loader Class Initialized
INFO - 2023-12-06 09:13:13 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:13 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:13 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:13 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:13 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:13 --> Controller Class Initialized
INFO - 2023-12-06 09:13:13 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:13 --> Total execution time: 0.0516
INFO - 2023-12-06 09:13:22 --> Config Class Initialized
INFO - 2023-12-06 09:13:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:22 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:22 --> URI Class Initialized
INFO - 2023-12-06 09:13:22 --> Router Class Initialized
INFO - 2023-12-06 09:13:22 --> Output Class Initialized
INFO - 2023-12-06 09:13:22 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:22 --> Input Class Initialized
INFO - 2023-12-06 09:13:22 --> Language Class Initialized
INFO - 2023-12-06 09:13:22 --> Language Class Initialized
INFO - 2023-12-06 09:13:22 --> Config Class Initialized
INFO - 2023-12-06 09:13:22 --> Loader Class Initialized
INFO - 2023-12-06 09:13:22 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:22 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:22 --> Controller Class Initialized
INFO - 2023-12-06 09:13:22 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:22 --> Total execution time: 0.0320
INFO - 2023-12-06 09:13:22 --> Config Class Initialized
INFO - 2023-12-06 09:13:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:22 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:22 --> URI Class Initialized
INFO - 2023-12-06 09:13:22 --> Router Class Initialized
INFO - 2023-12-06 09:13:22 --> Output Class Initialized
INFO - 2023-12-06 09:13:22 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:22 --> Input Class Initialized
INFO - 2023-12-06 09:13:22 --> Language Class Initialized
ERROR - 2023-12-06 09:13:22 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:22 --> Config Class Initialized
INFO - 2023-12-06 09:13:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:22 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:22 --> URI Class Initialized
INFO - 2023-12-06 09:13:22 --> Router Class Initialized
INFO - 2023-12-06 09:13:22 --> Output Class Initialized
INFO - 2023-12-06 09:13:22 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:22 --> Input Class Initialized
INFO - 2023-12-06 09:13:22 --> Language Class Initialized
INFO - 2023-12-06 09:13:22 --> Language Class Initialized
INFO - 2023-12-06 09:13:22 --> Config Class Initialized
INFO - 2023-12-06 09:13:22 --> Loader Class Initialized
INFO - 2023-12-06 09:13:22 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:22 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:22 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:23 --> Controller Class Initialized
INFO - 2023-12-06 09:13:25 --> Config Class Initialized
INFO - 2023-12-06 09:13:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:25 --> URI Class Initialized
INFO - 2023-12-06 09:13:25 --> Router Class Initialized
INFO - 2023-12-06 09:13:25 --> Output Class Initialized
INFO - 2023-12-06 09:13:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:25 --> Input Class Initialized
INFO - 2023-12-06 09:13:25 --> Language Class Initialized
INFO - 2023-12-06 09:13:25 --> Language Class Initialized
INFO - 2023-12-06 09:13:25 --> Config Class Initialized
INFO - 2023-12-06 09:13:25 --> Loader Class Initialized
INFO - 2023-12-06 09:13:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:25 --> Controller Class Initialized
INFO - 2023-12-06 09:13:25 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:25 --> Total execution time: 0.0504
INFO - 2023-12-06 09:13:33 --> Config Class Initialized
INFO - 2023-12-06 09:13:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:33 --> URI Class Initialized
INFO - 2023-12-06 09:13:33 --> Router Class Initialized
INFO - 2023-12-06 09:13:33 --> Output Class Initialized
INFO - 2023-12-06 09:13:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:33 --> Input Class Initialized
INFO - 2023-12-06 09:13:33 --> Language Class Initialized
INFO - 2023-12-06 09:13:33 --> Language Class Initialized
INFO - 2023-12-06 09:13:33 --> Config Class Initialized
INFO - 2023-12-06 09:13:33 --> Loader Class Initialized
INFO - 2023-12-06 09:13:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:33 --> Controller Class Initialized
INFO - 2023-12-06 09:13:33 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:33 --> Total execution time: 0.0345
INFO - 2023-12-06 09:13:33 --> Config Class Initialized
INFO - 2023-12-06 09:13:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:33 --> URI Class Initialized
INFO - 2023-12-06 09:13:33 --> Router Class Initialized
INFO - 2023-12-06 09:13:33 --> Output Class Initialized
INFO - 2023-12-06 09:13:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:33 --> Input Class Initialized
INFO - 2023-12-06 09:13:33 --> Language Class Initialized
ERROR - 2023-12-06 09:13:33 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:33 --> Config Class Initialized
INFO - 2023-12-06 09:13:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:33 --> URI Class Initialized
INFO - 2023-12-06 09:13:33 --> Router Class Initialized
INFO - 2023-12-06 09:13:33 --> Output Class Initialized
INFO - 2023-12-06 09:13:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:33 --> Input Class Initialized
INFO - 2023-12-06 09:13:33 --> Language Class Initialized
INFO - 2023-12-06 09:13:33 --> Language Class Initialized
INFO - 2023-12-06 09:13:33 --> Config Class Initialized
INFO - 2023-12-06 09:13:33 --> Loader Class Initialized
INFO - 2023-12-06 09:13:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:33 --> Controller Class Initialized
INFO - 2023-12-06 09:13:39 --> Config Class Initialized
INFO - 2023-12-06 09:13:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:39 --> URI Class Initialized
INFO - 2023-12-06 09:13:39 --> Router Class Initialized
INFO - 2023-12-06 09:13:39 --> Output Class Initialized
INFO - 2023-12-06 09:13:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:39 --> Input Class Initialized
INFO - 2023-12-06 09:13:39 --> Language Class Initialized
INFO - 2023-12-06 09:13:39 --> Language Class Initialized
INFO - 2023-12-06 09:13:39 --> Config Class Initialized
INFO - 2023-12-06 09:13:39 --> Loader Class Initialized
INFO - 2023-12-06 09:13:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:39 --> Controller Class Initialized
INFO - 2023-12-06 09:13:39 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:39 --> Total execution time: 0.0606
INFO - 2023-12-06 09:13:44 --> Config Class Initialized
INFO - 2023-12-06 09:13:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:44 --> URI Class Initialized
INFO - 2023-12-06 09:13:44 --> Router Class Initialized
INFO - 2023-12-06 09:13:44 --> Output Class Initialized
INFO - 2023-12-06 09:13:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:44 --> Input Class Initialized
INFO - 2023-12-06 09:13:44 --> Language Class Initialized
INFO - 2023-12-06 09:13:45 --> Language Class Initialized
INFO - 2023-12-06 09:13:45 --> Config Class Initialized
INFO - 2023-12-06 09:13:45 --> Loader Class Initialized
INFO - 2023-12-06 09:13:45 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:45 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:45 --> Controller Class Initialized
INFO - 2023-12-06 09:13:45 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:45 --> Total execution time: 0.1391
INFO - 2023-12-06 09:13:45 --> Config Class Initialized
INFO - 2023-12-06 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:45 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:45 --> URI Class Initialized
INFO - 2023-12-06 09:13:45 --> Router Class Initialized
INFO - 2023-12-06 09:13:45 --> Output Class Initialized
INFO - 2023-12-06 09:13:45 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:45 --> Input Class Initialized
INFO - 2023-12-06 09:13:45 --> Language Class Initialized
ERROR - 2023-12-06 09:13:45 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:45 --> Config Class Initialized
INFO - 2023-12-06 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:45 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:45 --> URI Class Initialized
INFO - 2023-12-06 09:13:45 --> Router Class Initialized
INFO - 2023-12-06 09:13:45 --> Output Class Initialized
INFO - 2023-12-06 09:13:45 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:45 --> Input Class Initialized
INFO - 2023-12-06 09:13:45 --> Language Class Initialized
INFO - 2023-12-06 09:13:45 --> Language Class Initialized
INFO - 2023-12-06 09:13:45 --> Config Class Initialized
INFO - 2023-12-06 09:13:45 --> Loader Class Initialized
INFO - 2023-12-06 09:13:45 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:45 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:45 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:45 --> Controller Class Initialized
INFO - 2023-12-06 09:13:47 --> Config Class Initialized
INFO - 2023-12-06 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:47 --> URI Class Initialized
INFO - 2023-12-06 09:13:47 --> Router Class Initialized
INFO - 2023-12-06 09:13:47 --> Output Class Initialized
INFO - 2023-12-06 09:13:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:47 --> Input Class Initialized
INFO - 2023-12-06 09:13:47 --> Language Class Initialized
INFO - 2023-12-06 09:13:47 --> Language Class Initialized
INFO - 2023-12-06 09:13:47 --> Config Class Initialized
INFO - 2023-12-06 09:13:47 --> Loader Class Initialized
INFO - 2023-12-06 09:13:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:47 --> Controller Class Initialized
INFO - 2023-12-06 09:13:47 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:47 --> Total execution time: 0.0371
INFO - 2023-12-06 09:13:55 --> Config Class Initialized
INFO - 2023-12-06 09:13:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:55 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:55 --> URI Class Initialized
INFO - 2023-12-06 09:13:55 --> Router Class Initialized
INFO - 2023-12-06 09:13:55 --> Output Class Initialized
INFO - 2023-12-06 09:13:55 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:55 --> Input Class Initialized
INFO - 2023-12-06 09:13:55 --> Language Class Initialized
INFO - 2023-12-06 09:13:55 --> Language Class Initialized
INFO - 2023-12-06 09:13:55 --> Config Class Initialized
INFO - 2023-12-06 09:13:55 --> Loader Class Initialized
INFO - 2023-12-06 09:13:55 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:55 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:55 --> Controller Class Initialized
INFO - 2023-12-06 09:13:55 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:55 --> Total execution time: 0.0375
INFO - 2023-12-06 09:13:55 --> Config Class Initialized
INFO - 2023-12-06 09:13:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:55 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:55 --> URI Class Initialized
INFO - 2023-12-06 09:13:55 --> Router Class Initialized
INFO - 2023-12-06 09:13:55 --> Output Class Initialized
INFO - 2023-12-06 09:13:55 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:55 --> Input Class Initialized
INFO - 2023-12-06 09:13:55 --> Language Class Initialized
ERROR - 2023-12-06 09:13:55 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:13:55 --> Config Class Initialized
INFO - 2023-12-06 09:13:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:55 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:55 --> URI Class Initialized
INFO - 2023-12-06 09:13:55 --> Router Class Initialized
INFO - 2023-12-06 09:13:55 --> Output Class Initialized
INFO - 2023-12-06 09:13:55 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:55 --> Input Class Initialized
INFO - 2023-12-06 09:13:55 --> Language Class Initialized
INFO - 2023-12-06 09:13:55 --> Language Class Initialized
INFO - 2023-12-06 09:13:55 --> Config Class Initialized
INFO - 2023-12-06 09:13:55 --> Loader Class Initialized
INFO - 2023-12-06 09:13:55 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:55 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:55 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:55 --> Controller Class Initialized
INFO - 2023-12-06 09:13:57 --> Config Class Initialized
INFO - 2023-12-06 09:13:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:13:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:13:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:13:57 --> URI Class Initialized
INFO - 2023-12-06 09:13:57 --> Router Class Initialized
INFO - 2023-12-06 09:13:57 --> Output Class Initialized
INFO - 2023-12-06 09:13:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:13:57 --> Input Class Initialized
INFO - 2023-12-06 09:13:57 --> Language Class Initialized
INFO - 2023-12-06 09:13:57 --> Language Class Initialized
INFO - 2023-12-06 09:13:57 --> Config Class Initialized
INFO - 2023-12-06 09:13:57 --> Loader Class Initialized
INFO - 2023-12-06 09:13:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:13:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:13:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:13:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:13:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:13:57 --> Controller Class Initialized
INFO - 2023-12-06 09:13:57 --> Final output sent to browser
DEBUG - 2023-12-06 09:13:57 --> Total execution time: 0.0315
INFO - 2023-12-06 09:14:01 --> Config Class Initialized
INFO - 2023-12-06 09:14:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:01 --> URI Class Initialized
INFO - 2023-12-06 09:14:01 --> Router Class Initialized
INFO - 2023-12-06 09:14:01 --> Output Class Initialized
INFO - 2023-12-06 09:14:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:01 --> Input Class Initialized
INFO - 2023-12-06 09:14:01 --> Language Class Initialized
INFO - 2023-12-06 09:14:01 --> Language Class Initialized
INFO - 2023-12-06 09:14:01 --> Config Class Initialized
INFO - 2023-12-06 09:14:01 --> Loader Class Initialized
INFO - 2023-12-06 09:14:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:01 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:01 --> Controller Class Initialized
INFO - 2023-12-06 09:14:01 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:01 --> Total execution time: 0.1977
INFO - 2023-12-06 09:14:01 --> Config Class Initialized
INFO - 2023-12-06 09:14:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:01 --> URI Class Initialized
INFO - 2023-12-06 09:14:01 --> Router Class Initialized
INFO - 2023-12-06 09:14:01 --> Output Class Initialized
INFO - 2023-12-06 09:14:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:01 --> Input Class Initialized
INFO - 2023-12-06 09:14:01 --> Language Class Initialized
ERROR - 2023-12-06 09:14:01 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:01 --> Config Class Initialized
INFO - 2023-12-06 09:14:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:01 --> URI Class Initialized
INFO - 2023-12-06 09:14:01 --> Router Class Initialized
INFO - 2023-12-06 09:14:01 --> Output Class Initialized
INFO - 2023-12-06 09:14:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:01 --> Input Class Initialized
INFO - 2023-12-06 09:14:01 --> Language Class Initialized
INFO - 2023-12-06 09:14:01 --> Language Class Initialized
INFO - 2023-12-06 09:14:01 --> Config Class Initialized
INFO - 2023-12-06 09:14:01 --> Loader Class Initialized
INFO - 2023-12-06 09:14:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:02 --> Controller Class Initialized
INFO - 2023-12-06 09:14:04 --> Config Class Initialized
INFO - 2023-12-06 09:14:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:04 --> URI Class Initialized
INFO - 2023-12-06 09:14:04 --> Router Class Initialized
INFO - 2023-12-06 09:14:04 --> Output Class Initialized
INFO - 2023-12-06 09:14:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:04 --> Input Class Initialized
INFO - 2023-12-06 09:14:04 --> Language Class Initialized
INFO - 2023-12-06 09:14:04 --> Language Class Initialized
INFO - 2023-12-06 09:14:04 --> Config Class Initialized
INFO - 2023-12-06 09:14:04 --> Loader Class Initialized
INFO - 2023-12-06 09:14:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:04 --> Controller Class Initialized
INFO - 2023-12-06 09:14:04 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:04 --> Total execution time: 0.0547
INFO - 2023-12-06 09:14:10 --> Config Class Initialized
INFO - 2023-12-06 09:14:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:10 --> URI Class Initialized
INFO - 2023-12-06 09:14:10 --> Router Class Initialized
INFO - 2023-12-06 09:14:10 --> Output Class Initialized
INFO - 2023-12-06 09:14:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:10 --> Input Class Initialized
INFO - 2023-12-06 09:14:10 --> Language Class Initialized
INFO - 2023-12-06 09:14:10 --> Language Class Initialized
INFO - 2023-12-06 09:14:10 --> Config Class Initialized
INFO - 2023-12-06 09:14:10 --> Loader Class Initialized
INFO - 2023-12-06 09:14:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:10 --> Controller Class Initialized
INFO - 2023-12-06 09:14:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:10 --> Total execution time: 0.0660
INFO - 2023-12-06 09:14:10 --> Config Class Initialized
INFO - 2023-12-06 09:14:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:10 --> URI Class Initialized
INFO - 2023-12-06 09:14:10 --> Router Class Initialized
INFO - 2023-12-06 09:14:10 --> Output Class Initialized
INFO - 2023-12-06 09:14:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:10 --> Input Class Initialized
INFO - 2023-12-06 09:14:10 --> Language Class Initialized
ERROR - 2023-12-06 09:14:10 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:10 --> Config Class Initialized
INFO - 2023-12-06 09:14:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:10 --> URI Class Initialized
INFO - 2023-12-06 09:14:10 --> Router Class Initialized
INFO - 2023-12-06 09:14:10 --> Output Class Initialized
INFO - 2023-12-06 09:14:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:10 --> Input Class Initialized
INFO - 2023-12-06 09:14:10 --> Language Class Initialized
INFO - 2023-12-06 09:14:10 --> Language Class Initialized
INFO - 2023-12-06 09:14:10 --> Config Class Initialized
INFO - 2023-12-06 09:14:10 --> Loader Class Initialized
INFO - 2023-12-06 09:14:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:10 --> Controller Class Initialized
INFO - 2023-12-06 09:14:13 --> Config Class Initialized
INFO - 2023-12-06 09:14:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:13 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:13 --> URI Class Initialized
INFO - 2023-12-06 09:14:13 --> Router Class Initialized
INFO - 2023-12-06 09:14:13 --> Output Class Initialized
INFO - 2023-12-06 09:14:13 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:13 --> Input Class Initialized
INFO - 2023-12-06 09:14:13 --> Language Class Initialized
INFO - 2023-12-06 09:14:13 --> Language Class Initialized
INFO - 2023-12-06 09:14:13 --> Config Class Initialized
INFO - 2023-12-06 09:14:13 --> Loader Class Initialized
INFO - 2023-12-06 09:14:13 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:13 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:13 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:13 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:13 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:13 --> Controller Class Initialized
INFO - 2023-12-06 09:14:13 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:13 --> Total execution time: 0.0388
INFO - 2023-12-06 09:14:19 --> Config Class Initialized
INFO - 2023-12-06 09:14:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:20 --> URI Class Initialized
INFO - 2023-12-06 09:14:20 --> Router Class Initialized
INFO - 2023-12-06 09:14:20 --> Output Class Initialized
INFO - 2023-12-06 09:14:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:20 --> Input Class Initialized
INFO - 2023-12-06 09:14:20 --> Language Class Initialized
INFO - 2023-12-06 09:14:20 --> Language Class Initialized
INFO - 2023-12-06 09:14:20 --> Config Class Initialized
INFO - 2023-12-06 09:14:20 --> Loader Class Initialized
INFO - 2023-12-06 09:14:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:20 --> Controller Class Initialized
INFO - 2023-12-06 09:14:20 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:20 --> Total execution time: 0.0379
INFO - 2023-12-06 09:14:20 --> Config Class Initialized
INFO - 2023-12-06 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:20 --> URI Class Initialized
INFO - 2023-12-06 09:14:20 --> Router Class Initialized
INFO - 2023-12-06 09:14:20 --> Output Class Initialized
INFO - 2023-12-06 09:14:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:20 --> Input Class Initialized
INFO - 2023-12-06 09:14:20 --> Language Class Initialized
ERROR - 2023-12-06 09:14:20 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:20 --> Config Class Initialized
INFO - 2023-12-06 09:14:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:20 --> URI Class Initialized
INFO - 2023-12-06 09:14:20 --> Router Class Initialized
INFO - 2023-12-06 09:14:20 --> Output Class Initialized
INFO - 2023-12-06 09:14:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:20 --> Input Class Initialized
INFO - 2023-12-06 09:14:20 --> Language Class Initialized
INFO - 2023-12-06 09:14:20 --> Language Class Initialized
INFO - 2023-12-06 09:14:20 --> Config Class Initialized
INFO - 2023-12-06 09:14:20 --> Loader Class Initialized
INFO - 2023-12-06 09:14:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:20 --> Controller Class Initialized
INFO - 2023-12-06 09:14:23 --> Config Class Initialized
INFO - 2023-12-06 09:14:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:23 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:23 --> URI Class Initialized
INFO - 2023-12-06 09:14:23 --> Router Class Initialized
INFO - 2023-12-06 09:14:23 --> Output Class Initialized
INFO - 2023-12-06 09:14:23 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:23 --> Input Class Initialized
INFO - 2023-12-06 09:14:23 --> Language Class Initialized
INFO - 2023-12-06 09:14:23 --> Language Class Initialized
INFO - 2023-12-06 09:14:23 --> Config Class Initialized
INFO - 2023-12-06 09:14:23 --> Loader Class Initialized
INFO - 2023-12-06 09:14:23 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:23 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:23 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:23 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:23 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:23 --> Controller Class Initialized
INFO - 2023-12-06 09:14:23 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:23 --> Total execution time: 0.0524
INFO - 2023-12-06 09:14:29 --> Config Class Initialized
INFO - 2023-12-06 09:14:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:29 --> URI Class Initialized
INFO - 2023-12-06 09:14:29 --> Router Class Initialized
INFO - 2023-12-06 09:14:29 --> Output Class Initialized
INFO - 2023-12-06 09:14:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:29 --> Input Class Initialized
INFO - 2023-12-06 09:14:29 --> Language Class Initialized
INFO - 2023-12-06 09:14:29 --> Language Class Initialized
INFO - 2023-12-06 09:14:29 --> Config Class Initialized
INFO - 2023-12-06 09:14:29 --> Loader Class Initialized
INFO - 2023-12-06 09:14:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:29 --> Controller Class Initialized
INFO - 2023-12-06 09:14:29 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:29 --> Total execution time: 0.0393
INFO - 2023-12-06 09:14:29 --> Config Class Initialized
INFO - 2023-12-06 09:14:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:29 --> URI Class Initialized
INFO - 2023-12-06 09:14:29 --> Router Class Initialized
INFO - 2023-12-06 09:14:29 --> Output Class Initialized
INFO - 2023-12-06 09:14:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:29 --> Input Class Initialized
INFO - 2023-12-06 09:14:29 --> Language Class Initialized
ERROR - 2023-12-06 09:14:29 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:29 --> Config Class Initialized
INFO - 2023-12-06 09:14:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:29 --> URI Class Initialized
INFO - 2023-12-06 09:14:29 --> Router Class Initialized
INFO - 2023-12-06 09:14:29 --> Output Class Initialized
INFO - 2023-12-06 09:14:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:29 --> Input Class Initialized
INFO - 2023-12-06 09:14:29 --> Language Class Initialized
INFO - 2023-12-06 09:14:29 --> Language Class Initialized
INFO - 2023-12-06 09:14:29 --> Config Class Initialized
INFO - 2023-12-06 09:14:29 --> Loader Class Initialized
INFO - 2023-12-06 09:14:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:29 --> Controller Class Initialized
INFO - 2023-12-06 09:14:42 --> Config Class Initialized
INFO - 2023-12-06 09:14:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:42 --> URI Class Initialized
INFO - 2023-12-06 09:14:42 --> Router Class Initialized
INFO - 2023-12-06 09:14:42 --> Output Class Initialized
INFO - 2023-12-06 09:14:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:42 --> Input Class Initialized
INFO - 2023-12-06 09:14:42 --> Language Class Initialized
INFO - 2023-12-06 09:14:42 --> Language Class Initialized
INFO - 2023-12-06 09:14:42 --> Config Class Initialized
INFO - 2023-12-06 09:14:42 --> Loader Class Initialized
INFO - 2023-12-06 09:14:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:42 --> Controller Class Initialized
INFO - 2023-12-06 09:14:42 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:42 --> Total execution time: 0.0805
INFO - 2023-12-06 09:14:46 --> Config Class Initialized
INFO - 2023-12-06 09:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:46 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:46 --> URI Class Initialized
INFO - 2023-12-06 09:14:46 --> Router Class Initialized
INFO - 2023-12-06 09:14:46 --> Output Class Initialized
INFO - 2023-12-06 09:14:46 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:46 --> Input Class Initialized
INFO - 2023-12-06 09:14:46 --> Language Class Initialized
INFO - 2023-12-06 09:14:46 --> Language Class Initialized
INFO - 2023-12-06 09:14:46 --> Config Class Initialized
INFO - 2023-12-06 09:14:46 --> Loader Class Initialized
INFO - 2023-12-06 09:14:46 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:46 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:46 --> Controller Class Initialized
INFO - 2023-12-06 09:14:46 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:46 --> Total execution time: 0.0433
INFO - 2023-12-06 09:14:46 --> Config Class Initialized
INFO - 2023-12-06 09:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:46 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:46 --> URI Class Initialized
INFO - 2023-12-06 09:14:46 --> Router Class Initialized
INFO - 2023-12-06 09:14:46 --> Output Class Initialized
INFO - 2023-12-06 09:14:46 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:46 --> Input Class Initialized
INFO - 2023-12-06 09:14:46 --> Language Class Initialized
ERROR - 2023-12-06 09:14:46 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:46 --> Config Class Initialized
INFO - 2023-12-06 09:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:46 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:46 --> URI Class Initialized
INFO - 2023-12-06 09:14:46 --> Router Class Initialized
INFO - 2023-12-06 09:14:46 --> Output Class Initialized
INFO - 2023-12-06 09:14:46 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:46 --> Input Class Initialized
INFO - 2023-12-06 09:14:46 --> Language Class Initialized
INFO - 2023-12-06 09:14:46 --> Language Class Initialized
INFO - 2023-12-06 09:14:46 --> Config Class Initialized
INFO - 2023-12-06 09:14:46 --> Loader Class Initialized
INFO - 2023-12-06 09:14:46 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:46 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:46 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:46 --> Controller Class Initialized
INFO - 2023-12-06 09:14:48 --> Config Class Initialized
INFO - 2023-12-06 09:14:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:48 --> URI Class Initialized
INFO - 2023-12-06 09:14:48 --> Router Class Initialized
INFO - 2023-12-06 09:14:48 --> Output Class Initialized
INFO - 2023-12-06 09:14:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:48 --> Input Class Initialized
INFO - 2023-12-06 09:14:48 --> Language Class Initialized
INFO - 2023-12-06 09:14:48 --> Language Class Initialized
INFO - 2023-12-06 09:14:48 --> Config Class Initialized
INFO - 2023-12-06 09:14:48 --> Loader Class Initialized
INFO - 2023-12-06 09:14:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:48 --> Controller Class Initialized
INFO - 2023-12-06 09:14:48 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:48 --> Total execution time: 0.0337
INFO - 2023-12-06 09:14:57 --> Config Class Initialized
INFO - 2023-12-06 09:14:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:57 --> URI Class Initialized
INFO - 2023-12-06 09:14:57 --> Router Class Initialized
INFO - 2023-12-06 09:14:57 --> Output Class Initialized
INFO - 2023-12-06 09:14:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:57 --> Input Class Initialized
INFO - 2023-12-06 09:14:57 --> Language Class Initialized
INFO - 2023-12-06 09:14:57 --> Language Class Initialized
INFO - 2023-12-06 09:14:57 --> Config Class Initialized
INFO - 2023-12-06 09:14:57 --> Loader Class Initialized
INFO - 2023-12-06 09:14:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:57 --> Controller Class Initialized
INFO - 2023-12-06 09:14:57 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:57 --> Total execution time: 0.0402
INFO - 2023-12-06 09:14:57 --> Config Class Initialized
INFO - 2023-12-06 09:14:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:57 --> URI Class Initialized
INFO - 2023-12-06 09:14:57 --> Router Class Initialized
INFO - 2023-12-06 09:14:57 --> Output Class Initialized
INFO - 2023-12-06 09:14:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:57 --> Input Class Initialized
INFO - 2023-12-06 09:14:57 --> Language Class Initialized
ERROR - 2023-12-06 09:14:57 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:14:58 --> Config Class Initialized
INFO - 2023-12-06 09:14:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:58 --> URI Class Initialized
INFO - 2023-12-06 09:14:58 --> Router Class Initialized
INFO - 2023-12-06 09:14:58 --> Output Class Initialized
INFO - 2023-12-06 09:14:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:58 --> Input Class Initialized
INFO - 2023-12-06 09:14:58 --> Language Class Initialized
INFO - 2023-12-06 09:14:58 --> Language Class Initialized
INFO - 2023-12-06 09:14:58 --> Config Class Initialized
INFO - 2023-12-06 09:14:58 --> Loader Class Initialized
INFO - 2023-12-06 09:14:58 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:58 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:58 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:58 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:58 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:58 --> Controller Class Initialized
INFO - 2023-12-06 09:14:59 --> Config Class Initialized
INFO - 2023-12-06 09:14:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:14:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:14:59 --> Utf8 Class Initialized
INFO - 2023-12-06 09:14:59 --> URI Class Initialized
INFO - 2023-12-06 09:14:59 --> Router Class Initialized
INFO - 2023-12-06 09:14:59 --> Output Class Initialized
INFO - 2023-12-06 09:14:59 --> Security Class Initialized
DEBUG - 2023-12-06 09:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:14:59 --> Input Class Initialized
INFO - 2023-12-06 09:14:59 --> Language Class Initialized
INFO - 2023-12-06 09:14:59 --> Language Class Initialized
INFO - 2023-12-06 09:14:59 --> Config Class Initialized
INFO - 2023-12-06 09:14:59 --> Loader Class Initialized
INFO - 2023-12-06 09:14:59 --> Helper loaded: url_helper
INFO - 2023-12-06 09:14:59 --> Helper loaded: file_helper
INFO - 2023-12-06 09:14:59 --> Helper loaded: form_helper
INFO - 2023-12-06 09:14:59 --> Helper loaded: my_helper
INFO - 2023-12-06 09:14:59 --> Database Driver Class Initialized
INFO - 2023-12-06 09:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:14:59 --> Controller Class Initialized
INFO - 2023-12-06 09:14:59 --> Final output sent to browser
DEBUG - 2023-12-06 09:14:59 --> Total execution time: 0.0447
INFO - 2023-12-06 09:15:04 --> Config Class Initialized
INFO - 2023-12-06 09:15:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:04 --> URI Class Initialized
INFO - 2023-12-06 09:15:04 --> Router Class Initialized
INFO - 2023-12-06 09:15:04 --> Output Class Initialized
INFO - 2023-12-06 09:15:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:04 --> Input Class Initialized
INFO - 2023-12-06 09:15:04 --> Language Class Initialized
INFO - 2023-12-06 09:15:04 --> Language Class Initialized
INFO - 2023-12-06 09:15:04 --> Config Class Initialized
INFO - 2023-12-06 09:15:04 --> Loader Class Initialized
INFO - 2023-12-06 09:15:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:04 --> Controller Class Initialized
INFO - 2023-12-06 09:15:04 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:04 --> Total execution time: 0.0512
INFO - 2023-12-06 09:15:04 --> Config Class Initialized
INFO - 2023-12-06 09:15:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:04 --> URI Class Initialized
INFO - 2023-12-06 09:15:04 --> Router Class Initialized
INFO - 2023-12-06 09:15:04 --> Output Class Initialized
INFO - 2023-12-06 09:15:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:04 --> Input Class Initialized
INFO - 2023-12-06 09:15:04 --> Language Class Initialized
ERROR - 2023-12-06 09:15:04 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:15:04 --> Config Class Initialized
INFO - 2023-12-06 09:15:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:04 --> URI Class Initialized
INFO - 2023-12-06 09:15:04 --> Router Class Initialized
INFO - 2023-12-06 09:15:04 --> Output Class Initialized
INFO - 2023-12-06 09:15:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:04 --> Input Class Initialized
INFO - 2023-12-06 09:15:04 --> Language Class Initialized
INFO - 2023-12-06 09:15:04 --> Language Class Initialized
INFO - 2023-12-06 09:15:04 --> Config Class Initialized
INFO - 2023-12-06 09:15:04 --> Loader Class Initialized
INFO - 2023-12-06 09:15:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:04 --> Controller Class Initialized
INFO - 2023-12-06 09:15:14 --> Config Class Initialized
INFO - 2023-12-06 09:15:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:14 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:14 --> URI Class Initialized
INFO - 2023-12-06 09:15:14 --> Router Class Initialized
INFO - 2023-12-06 09:15:14 --> Output Class Initialized
INFO - 2023-12-06 09:15:14 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:14 --> Input Class Initialized
INFO - 2023-12-06 09:15:14 --> Language Class Initialized
INFO - 2023-12-06 09:15:14 --> Language Class Initialized
INFO - 2023-12-06 09:15:14 --> Config Class Initialized
INFO - 2023-12-06 09:15:14 --> Loader Class Initialized
INFO - 2023-12-06 09:15:14 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:14 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:14 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:14 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:14 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:14 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:14 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:14 --> Total execution time: 0.0365
INFO - 2023-12-06 09:15:18 --> Config Class Initialized
INFO - 2023-12-06 09:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:18 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:18 --> URI Class Initialized
INFO - 2023-12-06 09:15:18 --> Router Class Initialized
INFO - 2023-12-06 09:15:18 --> Output Class Initialized
INFO - 2023-12-06 09:15:18 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:18 --> Input Class Initialized
INFO - 2023-12-06 09:15:18 --> Language Class Initialized
INFO - 2023-12-06 09:15:18 --> Language Class Initialized
INFO - 2023-12-06 09:15:18 --> Config Class Initialized
INFO - 2023-12-06 09:15:18 --> Loader Class Initialized
INFO - 2023-12-06 09:15:18 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:18 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:18 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:15:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:18 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:18 --> Total execution time: 0.0519
INFO - 2023-12-06 09:15:18 --> Config Class Initialized
INFO - 2023-12-06 09:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:18 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:18 --> URI Class Initialized
INFO - 2023-12-06 09:15:18 --> Router Class Initialized
INFO - 2023-12-06 09:15:18 --> Output Class Initialized
INFO - 2023-12-06 09:15:18 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:18 --> Input Class Initialized
INFO - 2023-12-06 09:15:18 --> Language Class Initialized
ERROR - 2023-12-06 09:15:18 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:15:18 --> Config Class Initialized
INFO - 2023-12-06 09:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:18 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:18 --> URI Class Initialized
INFO - 2023-12-06 09:15:18 --> Router Class Initialized
INFO - 2023-12-06 09:15:18 --> Output Class Initialized
INFO - 2023-12-06 09:15:18 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:18 --> Input Class Initialized
INFO - 2023-12-06 09:15:18 --> Language Class Initialized
INFO - 2023-12-06 09:15:18 --> Language Class Initialized
INFO - 2023-12-06 09:15:18 --> Config Class Initialized
INFO - 2023-12-06 09:15:18 --> Loader Class Initialized
INFO - 2023-12-06 09:15:18 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:18 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:18 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:18 --> Controller Class Initialized
INFO - 2023-12-06 09:15:30 --> Config Class Initialized
INFO - 2023-12-06 09:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:30 --> URI Class Initialized
INFO - 2023-12-06 09:15:30 --> Router Class Initialized
INFO - 2023-12-06 09:15:30 --> Output Class Initialized
INFO - 2023-12-06 09:15:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:30 --> Input Class Initialized
INFO - 2023-12-06 09:15:30 --> Language Class Initialized
INFO - 2023-12-06 09:15:30 --> Language Class Initialized
INFO - 2023-12-06 09:15:30 --> Config Class Initialized
INFO - 2023-12-06 09:15:30 --> Loader Class Initialized
INFO - 2023-12-06 09:15:30 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:30 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:30 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-06 09:15:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:30 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:30 --> Total execution time: 0.0370
INFO - 2023-12-06 09:15:30 --> Config Class Initialized
INFO - 2023-12-06 09:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:30 --> URI Class Initialized
INFO - 2023-12-06 09:15:30 --> Router Class Initialized
INFO - 2023-12-06 09:15:30 --> Output Class Initialized
INFO - 2023-12-06 09:15:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:30 --> Input Class Initialized
INFO - 2023-12-06 09:15:30 --> Language Class Initialized
ERROR - 2023-12-06 09:15:30 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:15:30 --> Config Class Initialized
INFO - 2023-12-06 09:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:30 --> URI Class Initialized
INFO - 2023-12-06 09:15:30 --> Router Class Initialized
INFO - 2023-12-06 09:15:30 --> Output Class Initialized
INFO - 2023-12-06 09:15:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:30 --> Input Class Initialized
INFO - 2023-12-06 09:15:30 --> Language Class Initialized
INFO - 2023-12-06 09:15:30 --> Language Class Initialized
INFO - 2023-12-06 09:15:30 --> Config Class Initialized
INFO - 2023-12-06 09:15:30 --> Loader Class Initialized
INFO - 2023-12-06 09:15:30 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:30 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:30 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:30 --> Controller Class Initialized
INFO - 2023-12-06 09:15:39 --> Config Class Initialized
INFO - 2023-12-06 09:15:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:39 --> URI Class Initialized
INFO - 2023-12-06 09:15:39 --> Router Class Initialized
INFO - 2023-12-06 09:15:39 --> Output Class Initialized
INFO - 2023-12-06 09:15:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:39 --> Input Class Initialized
INFO - 2023-12-06 09:15:39 --> Language Class Initialized
INFO - 2023-12-06 09:15:39 --> Language Class Initialized
INFO - 2023-12-06 09:15:39 --> Config Class Initialized
INFO - 2023-12-06 09:15:39 --> Loader Class Initialized
INFO - 2023-12-06 09:15:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:39 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2023-12-06 09:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:39 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:39 --> Total execution time: 0.0397
INFO - 2023-12-06 09:15:47 --> Config Class Initialized
INFO - 2023-12-06 09:15:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:47 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:47 --> URI Class Initialized
INFO - 2023-12-06 09:15:47 --> Router Class Initialized
INFO - 2023-12-06 09:15:47 --> Output Class Initialized
INFO - 2023-12-06 09:15:47 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:47 --> Input Class Initialized
INFO - 2023-12-06 09:15:47 --> Language Class Initialized
INFO - 2023-12-06 09:15:47 --> Language Class Initialized
INFO - 2023-12-06 09:15:47 --> Config Class Initialized
INFO - 2023-12-06 09:15:47 --> Loader Class Initialized
INFO - 2023-12-06 09:15:47 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:47 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:47 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:47 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:47 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:47 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:47 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:47 --> Total execution time: 0.0831
INFO - 2023-12-06 09:15:48 --> Config Class Initialized
INFO - 2023-12-06 09:15:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:48 --> URI Class Initialized
INFO - 2023-12-06 09:15:48 --> Router Class Initialized
INFO - 2023-12-06 09:15:48 --> Output Class Initialized
INFO - 2023-12-06 09:15:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:48 --> Input Class Initialized
INFO - 2023-12-06 09:15:48 --> Language Class Initialized
ERROR - 2023-12-06 09:15:48 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:15:48 --> Config Class Initialized
INFO - 2023-12-06 09:15:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:48 --> URI Class Initialized
INFO - 2023-12-06 09:15:48 --> Router Class Initialized
INFO - 2023-12-06 09:15:48 --> Output Class Initialized
INFO - 2023-12-06 09:15:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:48 --> Input Class Initialized
INFO - 2023-12-06 09:15:48 --> Language Class Initialized
INFO - 2023-12-06 09:15:48 --> Language Class Initialized
INFO - 2023-12-06 09:15:48 --> Config Class Initialized
INFO - 2023-12-06 09:15:48 --> Loader Class Initialized
INFO - 2023-12-06 09:15:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:48 --> Controller Class Initialized
INFO - 2023-12-06 09:15:50 --> Config Class Initialized
INFO - 2023-12-06 09:15:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:15:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:15:50 --> Utf8 Class Initialized
INFO - 2023-12-06 09:15:50 --> URI Class Initialized
INFO - 2023-12-06 09:15:50 --> Router Class Initialized
INFO - 2023-12-06 09:15:50 --> Output Class Initialized
INFO - 2023-12-06 09:15:50 --> Security Class Initialized
DEBUG - 2023-12-06 09:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:15:50 --> Input Class Initialized
INFO - 2023-12-06 09:15:50 --> Language Class Initialized
INFO - 2023-12-06 09:15:50 --> Language Class Initialized
INFO - 2023-12-06 09:15:50 --> Config Class Initialized
INFO - 2023-12-06 09:15:50 --> Loader Class Initialized
INFO - 2023-12-06 09:15:50 --> Helper loaded: url_helper
INFO - 2023-12-06 09:15:50 --> Helper loaded: file_helper
INFO - 2023-12-06 09:15:50 --> Helper loaded: form_helper
INFO - 2023-12-06 09:15:50 --> Helper loaded: my_helper
INFO - 2023-12-06 09:15:50 --> Database Driver Class Initialized
INFO - 2023-12-06 09:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:15:50 --> Controller Class Initialized
DEBUG - 2023-12-06 09:15:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:15:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:15:50 --> Final output sent to browser
DEBUG - 2023-12-06 09:15:50 --> Total execution time: 0.0364
INFO - 2023-12-06 09:16:10 --> Config Class Initialized
INFO - 2023-12-06 09:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:10 --> URI Class Initialized
INFO - 2023-12-06 09:16:10 --> Router Class Initialized
INFO - 2023-12-06 09:16:10 --> Output Class Initialized
INFO - 2023-12-06 09:16:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:10 --> Input Class Initialized
INFO - 2023-12-06 09:16:10 --> Language Class Initialized
INFO - 2023-12-06 09:16:10 --> Language Class Initialized
INFO - 2023-12-06 09:16:10 --> Config Class Initialized
INFO - 2023-12-06 09:16:10 --> Loader Class Initialized
INFO - 2023-12-06 09:16:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:16:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:10 --> Total execution time: 0.0445
INFO - 2023-12-06 09:16:10 --> Config Class Initialized
INFO - 2023-12-06 09:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:10 --> URI Class Initialized
INFO - 2023-12-06 09:16:10 --> Router Class Initialized
INFO - 2023-12-06 09:16:10 --> Output Class Initialized
INFO - 2023-12-06 09:16:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:10 --> Input Class Initialized
INFO - 2023-12-06 09:16:10 --> Language Class Initialized
ERROR - 2023-12-06 09:16:10 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:16:10 --> Config Class Initialized
INFO - 2023-12-06 09:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:10 --> URI Class Initialized
INFO - 2023-12-06 09:16:10 --> Router Class Initialized
INFO - 2023-12-06 09:16:10 --> Output Class Initialized
INFO - 2023-12-06 09:16:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:10 --> Input Class Initialized
INFO - 2023-12-06 09:16:10 --> Language Class Initialized
INFO - 2023-12-06 09:16:10 --> Language Class Initialized
INFO - 2023-12-06 09:16:10 --> Config Class Initialized
INFO - 2023-12-06 09:16:10 --> Loader Class Initialized
INFO - 2023-12-06 09:16:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:10 --> Controller Class Initialized
INFO - 2023-12-06 09:16:15 --> Config Class Initialized
INFO - 2023-12-06 09:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:15 --> URI Class Initialized
INFO - 2023-12-06 09:16:15 --> Router Class Initialized
INFO - 2023-12-06 09:16:15 --> Output Class Initialized
INFO - 2023-12-06 09:16:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:15 --> Input Class Initialized
INFO - 2023-12-06 09:16:15 --> Language Class Initialized
INFO - 2023-12-06 09:16:15 --> Language Class Initialized
INFO - 2023-12-06 09:16:15 --> Config Class Initialized
INFO - 2023-12-06 09:16:15 --> Loader Class Initialized
INFO - 2023-12-06 09:16:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:15 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:15 --> Controller Class Initialized
DEBUG - 2023-12-06 09:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-06 09:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:16:15 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:15 --> Total execution time: 0.0334
INFO - 2023-12-06 09:16:15 --> Config Class Initialized
INFO - 2023-12-06 09:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:15 --> URI Class Initialized
INFO - 2023-12-06 09:16:15 --> Router Class Initialized
INFO - 2023-12-06 09:16:15 --> Output Class Initialized
INFO - 2023-12-06 09:16:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:15 --> Input Class Initialized
INFO - 2023-12-06 09:16:15 --> Language Class Initialized
ERROR - 2023-12-06 09:16:15 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:16:15 --> Config Class Initialized
INFO - 2023-12-06 09:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:15 --> URI Class Initialized
INFO - 2023-12-06 09:16:15 --> Router Class Initialized
INFO - 2023-12-06 09:16:15 --> Output Class Initialized
INFO - 2023-12-06 09:16:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:15 --> Input Class Initialized
INFO - 2023-12-06 09:16:15 --> Language Class Initialized
INFO - 2023-12-06 09:16:15 --> Language Class Initialized
INFO - 2023-12-06 09:16:15 --> Config Class Initialized
INFO - 2023-12-06 09:16:15 --> Loader Class Initialized
INFO - 2023-12-06 09:16:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:15 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:15 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:15 --> Controller Class Initialized
INFO - 2023-12-06 09:16:18 --> Config Class Initialized
INFO - 2023-12-06 09:16:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:18 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:18 --> URI Class Initialized
INFO - 2023-12-06 09:16:18 --> Router Class Initialized
INFO - 2023-12-06 09:16:18 --> Output Class Initialized
INFO - 2023-12-06 09:16:18 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:18 --> Input Class Initialized
INFO - 2023-12-06 09:16:18 --> Language Class Initialized
INFO - 2023-12-06 09:16:18 --> Language Class Initialized
INFO - 2023-12-06 09:16:18 --> Config Class Initialized
INFO - 2023-12-06 09:16:18 --> Loader Class Initialized
INFO - 2023-12-06 09:16:18 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:18 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:18 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:18 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:18 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:18 --> Controller Class Initialized
INFO - 2023-12-06 09:16:18 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:18 --> Total execution time: 0.0796
INFO - 2023-12-06 09:16:39 --> Config Class Initialized
INFO - 2023-12-06 09:16:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:39 --> URI Class Initialized
INFO - 2023-12-06 09:16:39 --> Router Class Initialized
INFO - 2023-12-06 09:16:39 --> Output Class Initialized
INFO - 2023-12-06 09:16:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:39 --> Input Class Initialized
INFO - 2023-12-06 09:16:39 --> Language Class Initialized
INFO - 2023-12-06 09:16:39 --> Language Class Initialized
INFO - 2023-12-06 09:16:39 --> Config Class Initialized
INFO - 2023-12-06 09:16:39 --> Loader Class Initialized
INFO - 2023-12-06 09:16:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:39 --> Controller Class Initialized
INFO - 2023-12-06 09:16:39 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:39 --> Total execution time: 0.0504
INFO - 2023-12-06 09:16:39 --> Config Class Initialized
INFO - 2023-12-06 09:16:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:39 --> URI Class Initialized
INFO - 2023-12-06 09:16:39 --> Router Class Initialized
INFO - 2023-12-06 09:16:39 --> Output Class Initialized
INFO - 2023-12-06 09:16:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:39 --> Input Class Initialized
INFO - 2023-12-06 09:16:39 --> Language Class Initialized
ERROR - 2023-12-06 09:16:39 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:16:39 --> Config Class Initialized
INFO - 2023-12-06 09:16:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:39 --> URI Class Initialized
INFO - 2023-12-06 09:16:39 --> Router Class Initialized
INFO - 2023-12-06 09:16:39 --> Output Class Initialized
INFO - 2023-12-06 09:16:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:39 --> Input Class Initialized
INFO - 2023-12-06 09:16:39 --> Language Class Initialized
INFO - 2023-12-06 09:16:39 --> Language Class Initialized
INFO - 2023-12-06 09:16:39 --> Config Class Initialized
INFO - 2023-12-06 09:16:39 --> Loader Class Initialized
INFO - 2023-12-06 09:16:39 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:39 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:39 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:39 --> Controller Class Initialized
INFO - 2023-12-06 09:16:42 --> Config Class Initialized
INFO - 2023-12-06 09:16:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:42 --> URI Class Initialized
INFO - 2023-12-06 09:16:42 --> Router Class Initialized
INFO - 2023-12-06 09:16:42 --> Output Class Initialized
INFO - 2023-12-06 09:16:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:42 --> Input Class Initialized
INFO - 2023-12-06 09:16:42 --> Language Class Initialized
INFO - 2023-12-06 09:16:42 --> Language Class Initialized
INFO - 2023-12-06 09:16:42 --> Config Class Initialized
INFO - 2023-12-06 09:16:42 --> Loader Class Initialized
INFO - 2023-12-06 09:16:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:42 --> Controller Class Initialized
INFO - 2023-12-06 09:16:42 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:42 --> Total execution time: 0.0359
INFO - 2023-12-06 09:16:48 --> Config Class Initialized
INFO - 2023-12-06 09:16:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:48 --> URI Class Initialized
INFO - 2023-12-06 09:16:48 --> Router Class Initialized
INFO - 2023-12-06 09:16:48 --> Output Class Initialized
INFO - 2023-12-06 09:16:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:48 --> Input Class Initialized
INFO - 2023-12-06 09:16:48 --> Language Class Initialized
INFO - 2023-12-06 09:16:48 --> Language Class Initialized
INFO - 2023-12-06 09:16:48 --> Config Class Initialized
INFO - 2023-12-06 09:16:48 --> Loader Class Initialized
INFO - 2023-12-06 09:16:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:48 --> Controller Class Initialized
INFO - 2023-12-06 09:16:48 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:48 --> Total execution time: 0.0345
INFO - 2023-12-06 09:16:48 --> Config Class Initialized
INFO - 2023-12-06 09:16:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:48 --> URI Class Initialized
INFO - 2023-12-06 09:16:48 --> Router Class Initialized
INFO - 2023-12-06 09:16:48 --> Output Class Initialized
INFO - 2023-12-06 09:16:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:48 --> Input Class Initialized
INFO - 2023-12-06 09:16:48 --> Language Class Initialized
ERROR - 2023-12-06 09:16:48 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:16:48 --> Config Class Initialized
INFO - 2023-12-06 09:16:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:48 --> URI Class Initialized
INFO - 2023-12-06 09:16:48 --> Router Class Initialized
INFO - 2023-12-06 09:16:48 --> Output Class Initialized
INFO - 2023-12-06 09:16:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:48 --> Input Class Initialized
INFO - 2023-12-06 09:16:48 --> Language Class Initialized
INFO - 2023-12-06 09:16:48 --> Language Class Initialized
INFO - 2023-12-06 09:16:48 --> Config Class Initialized
INFO - 2023-12-06 09:16:48 --> Loader Class Initialized
INFO - 2023-12-06 09:16:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:48 --> Controller Class Initialized
INFO - 2023-12-06 09:16:58 --> Config Class Initialized
INFO - 2023-12-06 09:16:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:58 --> URI Class Initialized
INFO - 2023-12-06 09:16:58 --> Router Class Initialized
INFO - 2023-12-06 09:16:58 --> Output Class Initialized
INFO - 2023-12-06 09:16:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:58 --> Input Class Initialized
INFO - 2023-12-06 09:16:58 --> Language Class Initialized
INFO - 2023-12-06 09:16:58 --> Language Class Initialized
INFO - 2023-12-06 09:16:58 --> Config Class Initialized
INFO - 2023-12-06 09:16:58 --> Loader Class Initialized
INFO - 2023-12-06 09:16:58 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:58 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:58 --> Controller Class Initialized
DEBUG - 2023-12-06 09:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:16:58 --> Final output sent to browser
DEBUG - 2023-12-06 09:16:58 --> Total execution time: 0.0462
INFO - 2023-12-06 09:16:58 --> Config Class Initialized
INFO - 2023-12-06 09:16:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:58 --> URI Class Initialized
INFO - 2023-12-06 09:16:58 --> Router Class Initialized
INFO - 2023-12-06 09:16:58 --> Output Class Initialized
INFO - 2023-12-06 09:16:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:58 --> Input Class Initialized
INFO - 2023-12-06 09:16:58 --> Language Class Initialized
ERROR - 2023-12-06 09:16:58 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:16:58 --> Config Class Initialized
INFO - 2023-12-06 09:16:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:16:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:16:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:16:58 --> URI Class Initialized
INFO - 2023-12-06 09:16:58 --> Router Class Initialized
INFO - 2023-12-06 09:16:58 --> Output Class Initialized
INFO - 2023-12-06 09:16:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:16:58 --> Input Class Initialized
INFO - 2023-12-06 09:16:58 --> Language Class Initialized
INFO - 2023-12-06 09:16:58 --> Language Class Initialized
INFO - 2023-12-06 09:16:58 --> Config Class Initialized
INFO - 2023-12-06 09:16:58 --> Loader Class Initialized
INFO - 2023-12-06 09:16:58 --> Helper loaded: url_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: file_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: form_helper
INFO - 2023-12-06 09:16:58 --> Helper loaded: my_helper
INFO - 2023-12-06 09:16:58 --> Database Driver Class Initialized
INFO - 2023-12-06 09:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:16:58 --> Controller Class Initialized
INFO - 2023-12-06 09:17:00 --> Config Class Initialized
INFO - 2023-12-06 09:17:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:00 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:00 --> URI Class Initialized
INFO - 2023-12-06 09:17:00 --> Router Class Initialized
INFO - 2023-12-06 09:17:00 --> Output Class Initialized
INFO - 2023-12-06 09:17:00 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:00 --> Input Class Initialized
INFO - 2023-12-06 09:17:00 --> Language Class Initialized
INFO - 2023-12-06 09:17:00 --> Language Class Initialized
INFO - 2023-12-06 09:17:00 --> Config Class Initialized
INFO - 2023-12-06 09:17:00 --> Loader Class Initialized
INFO - 2023-12-06 09:17:00 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:00 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:00 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:00 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:00 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:00 --> Controller Class Initialized
DEBUG - 2023-12-06 09:17:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:17:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:17:00 --> Final output sent to browser
DEBUG - 2023-12-06 09:17:00 --> Total execution time: 0.0933
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:31 --> URI Class Initialized
INFO - 2023-12-06 09:17:31 --> Router Class Initialized
INFO - 2023-12-06 09:17:31 --> Output Class Initialized
INFO - 2023-12-06 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:31 --> Input Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Loader Class Initialized
INFO - 2023-12-06 09:17:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:31 --> Controller Class Initialized
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:31 --> URI Class Initialized
INFO - 2023-12-06 09:17:31 --> Router Class Initialized
INFO - 2023-12-06 09:17:31 --> Output Class Initialized
INFO - 2023-12-06 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:31 --> Input Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Loader Class Initialized
INFO - 2023-12-06 09:17:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:31 --> Controller Class Initialized
DEBUG - 2023-12-06 09:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:17:31 --> Final output sent to browser
DEBUG - 2023-12-06 09:17:31 --> Total execution time: 0.0807
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:31 --> URI Class Initialized
INFO - 2023-12-06 09:17:31 --> Router Class Initialized
INFO - 2023-12-06 09:17:31 --> Output Class Initialized
INFO - 2023-12-06 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:31 --> Input Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
ERROR - 2023-12-06 09:17:31 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:31 --> URI Class Initialized
INFO - 2023-12-06 09:17:31 --> Router Class Initialized
INFO - 2023-12-06 09:17:31 --> Output Class Initialized
INFO - 2023-12-06 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:31 --> Input Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Language Class Initialized
INFO - 2023-12-06 09:17:31 --> Config Class Initialized
INFO - 2023-12-06 09:17:31 --> Loader Class Initialized
INFO - 2023-12-06 09:17:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:31 --> Controller Class Initialized
INFO - 2023-12-06 09:17:32 --> Config Class Initialized
INFO - 2023-12-06 09:17:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:32 --> URI Class Initialized
INFO - 2023-12-06 09:17:32 --> Router Class Initialized
INFO - 2023-12-06 09:17:32 --> Output Class Initialized
INFO - 2023-12-06 09:17:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:32 --> Input Class Initialized
INFO - 2023-12-06 09:17:32 --> Language Class Initialized
INFO - 2023-12-06 09:17:32 --> Language Class Initialized
INFO - 2023-12-06 09:17:32 --> Config Class Initialized
INFO - 2023-12-06 09:17:32 --> Loader Class Initialized
INFO - 2023-12-06 09:17:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:32 --> Controller Class Initialized
DEBUG - 2023-12-06 09:17:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:17:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:17:33 --> Final output sent to browser
DEBUG - 2023-12-06 09:17:33 --> Total execution time: 0.0824
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:43 --> URI Class Initialized
INFO - 2023-12-06 09:17:43 --> Router Class Initialized
INFO - 2023-12-06 09:17:43 --> Output Class Initialized
INFO - 2023-12-06 09:17:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:43 --> Input Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Loader Class Initialized
INFO - 2023-12-06 09:17:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:43 --> Controller Class Initialized
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:43 --> URI Class Initialized
INFO - 2023-12-06 09:17:43 --> Router Class Initialized
INFO - 2023-12-06 09:17:43 --> Output Class Initialized
INFO - 2023-12-06 09:17:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:43 --> Input Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Loader Class Initialized
INFO - 2023-12-06 09:17:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:43 --> Controller Class Initialized
DEBUG - 2023-12-06 09:17:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:17:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:17:43 --> Final output sent to browser
DEBUG - 2023-12-06 09:17:43 --> Total execution time: 0.0367
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:43 --> URI Class Initialized
INFO - 2023-12-06 09:17:43 --> Router Class Initialized
INFO - 2023-12-06 09:17:43 --> Output Class Initialized
INFO - 2023-12-06 09:17:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:43 --> Input Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
ERROR - 2023-12-06 09:17:43 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:17:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:17:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:17:43 --> URI Class Initialized
INFO - 2023-12-06 09:17:43 --> Router Class Initialized
INFO - 2023-12-06 09:17:43 --> Output Class Initialized
INFO - 2023-12-06 09:17:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:17:43 --> Input Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Language Class Initialized
INFO - 2023-12-06 09:17:43 --> Config Class Initialized
INFO - 2023-12-06 09:17:43 --> Loader Class Initialized
INFO - 2023-12-06 09:17:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:17:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:17:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:17:43 --> Controller Class Initialized
INFO - 2023-12-06 09:18:09 --> Config Class Initialized
INFO - 2023-12-06 09:18:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:09 --> URI Class Initialized
INFO - 2023-12-06 09:18:09 --> Router Class Initialized
INFO - 2023-12-06 09:18:09 --> Output Class Initialized
INFO - 2023-12-06 09:18:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:09 --> Input Class Initialized
INFO - 2023-12-06 09:18:09 --> Language Class Initialized
INFO - 2023-12-06 09:18:09 --> Language Class Initialized
INFO - 2023-12-06 09:18:09 --> Config Class Initialized
INFO - 2023-12-06 09:18:09 --> Loader Class Initialized
INFO - 2023-12-06 09:18:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:09 --> Controller Class Initialized
INFO - 2023-12-06 09:18:09 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:18:09 --> Config Class Initialized
INFO - 2023-12-06 09:18:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:09 --> URI Class Initialized
INFO - 2023-12-06 09:18:09 --> Router Class Initialized
INFO - 2023-12-06 09:18:09 --> Output Class Initialized
INFO - 2023-12-06 09:18:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:09 --> Input Class Initialized
INFO - 2023-12-06 09:18:09 --> Language Class Initialized
INFO - 2023-12-06 09:18:09 --> Language Class Initialized
INFO - 2023-12-06 09:18:09 --> Config Class Initialized
INFO - 2023-12-06 09:18:09 --> Loader Class Initialized
INFO - 2023-12-06 09:18:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:09 --> Controller Class Initialized
INFO - 2023-12-06 09:18:10 --> Config Class Initialized
INFO - 2023-12-06 09:18:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:10 --> URI Class Initialized
INFO - 2023-12-06 09:18:10 --> Router Class Initialized
INFO - 2023-12-06 09:18:10 --> Output Class Initialized
INFO - 2023-12-06 09:18:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:10 --> Input Class Initialized
INFO - 2023-12-06 09:18:10 --> Language Class Initialized
INFO - 2023-12-06 09:18:10 --> Language Class Initialized
INFO - 2023-12-06 09:18:10 --> Config Class Initialized
INFO - 2023-12-06 09:18:10 --> Loader Class Initialized
INFO - 2023-12-06 09:18:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:10 --> Total execution time: 0.0362
INFO - 2023-12-06 09:18:21 --> Config Class Initialized
INFO - 2023-12-06 09:18:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:21 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:21 --> URI Class Initialized
INFO - 2023-12-06 09:18:21 --> Router Class Initialized
INFO - 2023-12-06 09:18:21 --> Output Class Initialized
INFO - 2023-12-06 09:18:21 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:21 --> Input Class Initialized
INFO - 2023-12-06 09:18:21 --> Language Class Initialized
INFO - 2023-12-06 09:18:21 --> Language Class Initialized
INFO - 2023-12-06 09:18:21 --> Config Class Initialized
INFO - 2023-12-06 09:18:21 --> Loader Class Initialized
INFO - 2023-12-06 09:18:21 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:21 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:21 --> Controller Class Initialized
INFO - 2023-12-06 09:18:21 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:18:21 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:21 --> Total execution time: 0.0520
INFO - 2023-12-06 09:18:21 --> Config Class Initialized
INFO - 2023-12-06 09:18:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:21 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:21 --> URI Class Initialized
INFO - 2023-12-06 09:18:21 --> Router Class Initialized
INFO - 2023-12-06 09:18:21 --> Output Class Initialized
INFO - 2023-12-06 09:18:21 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:21 --> Input Class Initialized
INFO - 2023-12-06 09:18:21 --> Language Class Initialized
INFO - 2023-12-06 09:18:21 --> Language Class Initialized
INFO - 2023-12-06 09:18:21 --> Config Class Initialized
INFO - 2023-12-06 09:18:21 --> Loader Class Initialized
INFO - 2023-12-06 09:18:21 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:21 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:21 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:21 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:18:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:21 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:21 --> Total execution time: 0.0444
INFO - 2023-12-06 09:18:28 --> Config Class Initialized
INFO - 2023-12-06 09:18:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:28 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:28 --> URI Class Initialized
INFO - 2023-12-06 09:18:28 --> Router Class Initialized
INFO - 2023-12-06 09:18:28 --> Output Class Initialized
INFO - 2023-12-06 09:18:28 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:28 --> Input Class Initialized
INFO - 2023-12-06 09:18:28 --> Language Class Initialized
INFO - 2023-12-06 09:18:28 --> Language Class Initialized
INFO - 2023-12-06 09:18:28 --> Config Class Initialized
INFO - 2023-12-06 09:18:28 --> Loader Class Initialized
INFO - 2023-12-06 09:18:28 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:28 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:28 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:28 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:28 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:28 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:28 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:28 --> Total execution time: 0.0375
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:31 --> URI Class Initialized
INFO - 2023-12-06 09:18:31 --> Router Class Initialized
INFO - 2023-12-06 09:18:31 --> Output Class Initialized
INFO - 2023-12-06 09:18:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:31 --> Input Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Loader Class Initialized
INFO - 2023-12-06 09:18:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:31 --> Controller Class Initialized
INFO - 2023-12-06 09:18:31 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:31 --> URI Class Initialized
INFO - 2023-12-06 09:18:31 --> Router Class Initialized
INFO - 2023-12-06 09:18:31 --> Output Class Initialized
INFO - 2023-12-06 09:18:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:31 --> Input Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Loader Class Initialized
INFO - 2023-12-06 09:18:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:31 --> Controller Class Initialized
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:31 --> URI Class Initialized
INFO - 2023-12-06 09:18:31 --> Router Class Initialized
INFO - 2023-12-06 09:18:31 --> Output Class Initialized
INFO - 2023-12-06 09:18:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:31 --> Input Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Language Class Initialized
INFO - 2023-12-06 09:18:31 --> Config Class Initialized
INFO - 2023-12-06 09:18:31 --> Loader Class Initialized
INFO - 2023-12-06 09:18:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:31 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:31 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:31 --> Total execution time: 0.0773
INFO - 2023-12-06 09:18:36 --> Config Class Initialized
INFO - 2023-12-06 09:18:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:36 --> URI Class Initialized
INFO - 2023-12-06 09:18:36 --> Router Class Initialized
INFO - 2023-12-06 09:18:36 --> Output Class Initialized
INFO - 2023-12-06 09:18:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:36 --> Input Class Initialized
INFO - 2023-12-06 09:18:36 --> Language Class Initialized
INFO - 2023-12-06 09:18:36 --> Language Class Initialized
INFO - 2023-12-06 09:18:36 --> Config Class Initialized
INFO - 2023-12-06 09:18:36 --> Loader Class Initialized
INFO - 2023-12-06 09:18:36 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:36 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:36 --> Controller Class Initialized
INFO - 2023-12-06 09:18:36 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:18:36 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:36 --> Total execution time: 0.0471
INFO - 2023-12-06 09:18:36 --> Config Class Initialized
INFO - 2023-12-06 09:18:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:36 --> URI Class Initialized
INFO - 2023-12-06 09:18:36 --> Router Class Initialized
INFO - 2023-12-06 09:18:36 --> Output Class Initialized
INFO - 2023-12-06 09:18:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:36 --> Input Class Initialized
INFO - 2023-12-06 09:18:36 --> Language Class Initialized
INFO - 2023-12-06 09:18:36 --> Language Class Initialized
INFO - 2023-12-06 09:18:36 --> Config Class Initialized
INFO - 2023-12-06 09:18:36 --> Loader Class Initialized
INFO - 2023-12-06 09:18:36 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:36 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:36 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:36 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:36 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:36 --> Total execution time: 0.0752
INFO - 2023-12-06 09:18:41 --> Config Class Initialized
INFO - 2023-12-06 09:18:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:41 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:41 --> URI Class Initialized
INFO - 2023-12-06 09:18:41 --> Router Class Initialized
INFO - 2023-12-06 09:18:41 --> Output Class Initialized
INFO - 2023-12-06 09:18:41 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:41 --> Input Class Initialized
INFO - 2023-12-06 09:18:41 --> Language Class Initialized
INFO - 2023-12-06 09:18:41 --> Language Class Initialized
INFO - 2023-12-06 09:18:41 --> Config Class Initialized
INFO - 2023-12-06 09:18:41 --> Loader Class Initialized
INFO - 2023-12-06 09:18:41 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:41 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:41 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:41 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:41 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:41 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:41 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:41 --> Total execution time: 0.0701
INFO - 2023-12-06 09:18:51 --> Config Class Initialized
INFO - 2023-12-06 09:18:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:51 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:51 --> URI Class Initialized
INFO - 2023-12-06 09:18:51 --> Router Class Initialized
INFO - 2023-12-06 09:18:51 --> Output Class Initialized
INFO - 2023-12-06 09:18:51 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:51 --> Input Class Initialized
INFO - 2023-12-06 09:18:51 --> Language Class Initialized
INFO - 2023-12-06 09:18:51 --> Language Class Initialized
INFO - 2023-12-06 09:18:51 --> Config Class Initialized
INFO - 2023-12-06 09:18:51 --> Loader Class Initialized
INFO - 2023-12-06 09:18:51 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:51 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:51 --> Controller Class Initialized
DEBUG - 2023-12-06 09:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:18:51 --> Final output sent to browser
DEBUG - 2023-12-06 09:18:51 --> Total execution time: 0.0604
INFO - 2023-12-06 09:18:51 --> Config Class Initialized
INFO - 2023-12-06 09:18:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:18:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:18:51 --> Utf8 Class Initialized
INFO - 2023-12-06 09:18:51 --> URI Class Initialized
INFO - 2023-12-06 09:18:51 --> Router Class Initialized
INFO - 2023-12-06 09:18:51 --> Output Class Initialized
INFO - 2023-12-06 09:18:51 --> Security Class Initialized
DEBUG - 2023-12-06 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:18:51 --> Input Class Initialized
INFO - 2023-12-06 09:18:51 --> Language Class Initialized
INFO - 2023-12-06 09:18:51 --> Language Class Initialized
INFO - 2023-12-06 09:18:51 --> Config Class Initialized
INFO - 2023-12-06 09:18:51 --> Loader Class Initialized
INFO - 2023-12-06 09:18:51 --> Helper loaded: url_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: file_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: form_helper
INFO - 2023-12-06 09:18:51 --> Helper loaded: my_helper
INFO - 2023-12-06 09:18:51 --> Database Driver Class Initialized
INFO - 2023-12-06 09:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:18:51 --> Controller Class Initialized
INFO - 2023-12-06 09:19:00 --> Config Class Initialized
INFO - 2023-12-06 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:19:00 --> Utf8 Class Initialized
INFO - 2023-12-06 09:19:00 --> URI Class Initialized
INFO - 2023-12-06 09:19:00 --> Router Class Initialized
INFO - 2023-12-06 09:19:00 --> Output Class Initialized
INFO - 2023-12-06 09:19:00 --> Security Class Initialized
DEBUG - 2023-12-06 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:19:00 --> Input Class Initialized
INFO - 2023-12-06 09:19:00 --> Language Class Initialized
INFO - 2023-12-06 09:19:00 --> Language Class Initialized
INFO - 2023-12-06 09:19:00 --> Config Class Initialized
INFO - 2023-12-06 09:19:00 --> Loader Class Initialized
INFO - 2023-12-06 09:19:00 --> Helper loaded: url_helper
INFO - 2023-12-06 09:19:00 --> Helper loaded: file_helper
INFO - 2023-12-06 09:19:00 --> Helper loaded: form_helper
INFO - 2023-12-06 09:19:00 --> Helper loaded: my_helper
INFO - 2023-12-06 09:19:00 --> Database Driver Class Initialized
INFO - 2023-12-06 09:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:19:00 --> Controller Class Initialized
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 09:19:00 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 09:19:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 09:19:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:19:00 --> Final output sent to browser
DEBUG - 2023-12-06 09:19:00 --> Total execution time: 0.1039
INFO - 2023-12-06 09:29:06 --> Config Class Initialized
INFO - 2023-12-06 09:29:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:06 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:06 --> URI Class Initialized
INFO - 2023-12-06 09:29:06 --> Router Class Initialized
INFO - 2023-12-06 09:29:06 --> Output Class Initialized
INFO - 2023-12-06 09:29:06 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:06 --> Input Class Initialized
INFO - 2023-12-06 09:29:06 --> Language Class Initialized
INFO - 2023-12-06 09:29:06 --> Language Class Initialized
INFO - 2023-12-06 09:29:06 --> Config Class Initialized
INFO - 2023-12-06 09:29:06 --> Loader Class Initialized
INFO - 2023-12-06 09:29:06 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:06 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:06 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:06 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:06 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:06 --> Controller Class Initialized
DEBUG - 2023-12-06 09:29:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:29:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:29:06 --> Final output sent to browser
DEBUG - 2023-12-06 09:29:06 --> Total execution time: 0.0469
INFO - 2023-12-06 09:29:10 --> Config Class Initialized
INFO - 2023-12-06 09:29:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:10 --> URI Class Initialized
INFO - 2023-12-06 09:29:10 --> Router Class Initialized
INFO - 2023-12-06 09:29:10 --> Output Class Initialized
INFO - 2023-12-06 09:29:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:10 --> Input Class Initialized
INFO - 2023-12-06 09:29:10 --> Language Class Initialized
INFO - 2023-12-06 09:29:10 --> Language Class Initialized
INFO - 2023-12-06 09:29:10 --> Config Class Initialized
INFO - 2023-12-06 09:29:10 --> Loader Class Initialized
INFO - 2023-12-06 09:29:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:29:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:29:10 --> Total execution time: 0.0386
INFO - 2023-12-06 09:29:10 --> Config Class Initialized
INFO - 2023-12-06 09:29:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:10 --> URI Class Initialized
INFO - 2023-12-06 09:29:10 --> Router Class Initialized
INFO - 2023-12-06 09:29:10 --> Output Class Initialized
INFO - 2023-12-06 09:29:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:10 --> Input Class Initialized
INFO - 2023-12-06 09:29:10 --> Language Class Initialized
INFO - 2023-12-06 09:29:10 --> Language Class Initialized
INFO - 2023-12-06 09:29:10 --> Config Class Initialized
INFO - 2023-12-06 09:29:10 --> Loader Class Initialized
INFO - 2023-12-06 09:29:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:10 --> Controller Class Initialized
INFO - 2023-12-06 09:29:16 --> Config Class Initialized
INFO - 2023-12-06 09:29:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:16 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:16 --> URI Class Initialized
INFO - 2023-12-06 09:29:16 --> Router Class Initialized
INFO - 2023-12-06 09:29:16 --> Output Class Initialized
INFO - 2023-12-06 09:29:16 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:16 --> Input Class Initialized
INFO - 2023-12-06 09:29:16 --> Language Class Initialized
INFO - 2023-12-06 09:29:16 --> Language Class Initialized
INFO - 2023-12-06 09:29:16 --> Config Class Initialized
INFO - 2023-12-06 09:29:16 --> Loader Class Initialized
INFO - 2023-12-06 09:29:16 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:16 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:16 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:16 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:16 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:16 --> Controller Class Initialized
INFO - 2023-12-06 09:29:16 --> Final output sent to browser
DEBUG - 2023-12-06 09:29:16 --> Total execution time: 0.0355
INFO - 2023-12-06 09:29:57 --> Config Class Initialized
INFO - 2023-12-06 09:29:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:57 --> URI Class Initialized
INFO - 2023-12-06 09:29:57 --> Router Class Initialized
INFO - 2023-12-06 09:29:57 --> Output Class Initialized
INFO - 2023-12-06 09:29:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:57 --> Input Class Initialized
INFO - 2023-12-06 09:29:57 --> Language Class Initialized
INFO - 2023-12-06 09:29:57 --> Language Class Initialized
INFO - 2023-12-06 09:29:57 --> Config Class Initialized
INFO - 2023-12-06 09:29:57 --> Loader Class Initialized
INFO - 2023-12-06 09:29:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:57 --> Controller Class Initialized
INFO - 2023-12-06 09:29:57 --> Final output sent to browser
DEBUG - 2023-12-06 09:29:57 --> Total execution time: 0.0560
INFO - 2023-12-06 09:29:57 --> Config Class Initialized
INFO - 2023-12-06 09:29:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:29:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:29:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:29:57 --> URI Class Initialized
INFO - 2023-12-06 09:29:57 --> Router Class Initialized
INFO - 2023-12-06 09:29:57 --> Output Class Initialized
INFO - 2023-12-06 09:29:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:29:57 --> Input Class Initialized
INFO - 2023-12-06 09:29:57 --> Language Class Initialized
INFO - 2023-12-06 09:29:57 --> Language Class Initialized
INFO - 2023-12-06 09:29:57 --> Config Class Initialized
INFO - 2023-12-06 09:29:57 --> Loader Class Initialized
INFO - 2023-12-06 09:29:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:29:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:29:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:29:57 --> Controller Class Initialized
INFO - 2023-12-06 09:30:02 --> Config Class Initialized
INFO - 2023-12-06 09:30:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:30:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:30:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:30:02 --> URI Class Initialized
INFO - 2023-12-06 09:30:02 --> Router Class Initialized
INFO - 2023-12-06 09:30:02 --> Output Class Initialized
INFO - 2023-12-06 09:30:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:30:02 --> Input Class Initialized
INFO - 2023-12-06 09:30:02 --> Language Class Initialized
INFO - 2023-12-06 09:30:02 --> Language Class Initialized
INFO - 2023-12-06 09:30:02 --> Config Class Initialized
INFO - 2023-12-06 09:30:02 --> Loader Class Initialized
INFO - 2023-12-06 09:30:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:30:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:30:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:30:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:30:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:30:03 --> Controller Class Initialized
INFO - 2023-12-06 09:31:04 --> Config Class Initialized
INFO - 2023-12-06 09:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:31:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:31:04 --> URI Class Initialized
INFO - 2023-12-06 09:31:04 --> Router Class Initialized
INFO - 2023-12-06 09:31:04 --> Output Class Initialized
INFO - 2023-12-06 09:31:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:31:04 --> Input Class Initialized
INFO - 2023-12-06 09:31:04 --> Language Class Initialized
INFO - 2023-12-06 09:31:04 --> Language Class Initialized
INFO - 2023-12-06 09:31:04 --> Config Class Initialized
INFO - 2023-12-06 09:31:04 --> Loader Class Initialized
INFO - 2023-12-06 09:31:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:31:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:31:04 --> Controller Class Initialized
INFO - 2023-12-06 09:31:04 --> Final output sent to browser
DEBUG - 2023-12-06 09:31:04 --> Total execution time: 0.1050
INFO - 2023-12-06 09:31:04 --> Config Class Initialized
INFO - 2023-12-06 09:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:31:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:31:04 --> URI Class Initialized
INFO - 2023-12-06 09:31:04 --> Router Class Initialized
INFO - 2023-12-06 09:31:04 --> Output Class Initialized
INFO - 2023-12-06 09:31:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:31:04 --> Input Class Initialized
INFO - 2023-12-06 09:31:04 --> Language Class Initialized
INFO - 2023-12-06 09:31:04 --> Language Class Initialized
INFO - 2023-12-06 09:31:04 --> Config Class Initialized
INFO - 2023-12-06 09:31:04 --> Loader Class Initialized
INFO - 2023-12-06 09:31:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:31:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:31:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:31:04 --> Controller Class Initialized
INFO - 2023-12-06 09:34:21 --> Config Class Initialized
INFO - 2023-12-06 09:34:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:34:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:34:21 --> Utf8 Class Initialized
INFO - 2023-12-06 09:34:21 --> URI Class Initialized
INFO - 2023-12-06 09:34:21 --> Router Class Initialized
INFO - 2023-12-06 09:34:21 --> Output Class Initialized
INFO - 2023-12-06 09:34:21 --> Security Class Initialized
DEBUG - 2023-12-06 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:34:21 --> Input Class Initialized
INFO - 2023-12-06 09:34:21 --> Language Class Initialized
INFO - 2023-12-06 09:34:21 --> Language Class Initialized
INFO - 2023-12-06 09:34:21 --> Config Class Initialized
INFO - 2023-12-06 09:34:21 --> Loader Class Initialized
INFO - 2023-12-06 09:34:21 --> Helper loaded: url_helper
INFO - 2023-12-06 09:34:21 --> Helper loaded: file_helper
INFO - 2023-12-06 09:34:21 --> Helper loaded: form_helper
INFO - 2023-12-06 09:34:21 --> Helper loaded: my_helper
INFO - 2023-12-06 09:34:21 --> Database Driver Class Initialized
INFO - 2023-12-06 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:34:21 --> Controller Class Initialized
DEBUG - 2023-12-06 09:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 09:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:34:21 --> Final output sent to browser
DEBUG - 2023-12-06 09:34:21 --> Total execution time: 0.0564
INFO - 2023-12-06 09:34:25 --> Config Class Initialized
INFO - 2023-12-06 09:34:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:34:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:34:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:34:25 --> URI Class Initialized
INFO - 2023-12-06 09:34:25 --> Router Class Initialized
INFO - 2023-12-06 09:34:25 --> Output Class Initialized
INFO - 2023-12-06 09:34:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:34:25 --> Input Class Initialized
INFO - 2023-12-06 09:34:25 --> Language Class Initialized
INFO - 2023-12-06 09:34:25 --> Language Class Initialized
INFO - 2023-12-06 09:34:25 --> Config Class Initialized
INFO - 2023-12-06 09:34:25 --> Loader Class Initialized
INFO - 2023-12-06 09:34:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:34:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:34:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:34:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:34:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:34:25 --> Controller Class Initialized
DEBUG - 2023-12-06 09:34:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 09:34:30 --> Final output sent to browser
DEBUG - 2023-12-06 09:34:30 --> Total execution time: 5.2403
INFO - 2023-12-06 09:35:13 --> Config Class Initialized
INFO - 2023-12-06 09:35:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:13 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:13 --> URI Class Initialized
INFO - 2023-12-06 09:35:13 --> Router Class Initialized
INFO - 2023-12-06 09:35:13 --> Output Class Initialized
INFO - 2023-12-06 09:35:13 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:13 --> Input Class Initialized
INFO - 2023-12-06 09:35:13 --> Language Class Initialized
INFO - 2023-12-06 09:35:13 --> Language Class Initialized
INFO - 2023-12-06 09:35:13 --> Config Class Initialized
INFO - 2023-12-06 09:35:13 --> Loader Class Initialized
INFO - 2023-12-06 09:35:13 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:13 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:13 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:13 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:13 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:13 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:13 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:13 --> Total execution time: 0.0730
INFO - 2023-12-06 09:35:17 --> Config Class Initialized
INFO - 2023-12-06 09:35:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:17 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:17 --> URI Class Initialized
INFO - 2023-12-06 09:35:17 --> Router Class Initialized
INFO - 2023-12-06 09:35:17 --> Output Class Initialized
INFO - 2023-12-06 09:35:17 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:17 --> Input Class Initialized
INFO - 2023-12-06 09:35:17 --> Language Class Initialized
INFO - 2023-12-06 09:35:17 --> Language Class Initialized
INFO - 2023-12-06 09:35:17 --> Config Class Initialized
INFO - 2023-12-06 09:35:17 --> Loader Class Initialized
INFO - 2023-12-06 09:35:17 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:17 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:17 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:17 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:17 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:17 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-06 09:35:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:17 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:17 --> Total execution time: 0.0498
INFO - 2023-12-06 09:35:20 --> Config Class Initialized
INFO - 2023-12-06 09:35:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:20 --> URI Class Initialized
INFO - 2023-12-06 09:35:20 --> Router Class Initialized
INFO - 2023-12-06 09:35:20 --> Output Class Initialized
INFO - 2023-12-06 09:35:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:20 --> Input Class Initialized
INFO - 2023-12-06 09:35:20 --> Language Class Initialized
INFO - 2023-12-06 09:35:20 --> Language Class Initialized
INFO - 2023-12-06 09:35:20 --> Config Class Initialized
INFO - 2023-12-06 09:35:20 --> Loader Class Initialized
INFO - 2023-12-06 09:35:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:20 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:20 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:20 --> Total execution time: 0.0366
INFO - 2023-12-06 09:35:24 --> Config Class Initialized
INFO - 2023-12-06 09:35:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:24 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:24 --> URI Class Initialized
INFO - 2023-12-06 09:35:24 --> Router Class Initialized
INFO - 2023-12-06 09:35:24 --> Output Class Initialized
INFO - 2023-12-06 09:35:24 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:24 --> Input Class Initialized
INFO - 2023-12-06 09:35:24 --> Language Class Initialized
INFO - 2023-12-06 09:35:24 --> Language Class Initialized
INFO - 2023-12-06 09:35:24 --> Config Class Initialized
INFO - 2023-12-06 09:35:24 --> Loader Class Initialized
INFO - 2023-12-06 09:35:24 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:24 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:24 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:24 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:24 --> Total execution time: 0.0448
INFO - 2023-12-06 09:35:24 --> Config Class Initialized
INFO - 2023-12-06 09:35:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:24 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:24 --> URI Class Initialized
INFO - 2023-12-06 09:35:24 --> Router Class Initialized
INFO - 2023-12-06 09:35:24 --> Output Class Initialized
INFO - 2023-12-06 09:35:24 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:24 --> Input Class Initialized
INFO - 2023-12-06 09:35:24 --> Language Class Initialized
INFO - 2023-12-06 09:35:24 --> Language Class Initialized
INFO - 2023-12-06 09:35:24 --> Config Class Initialized
INFO - 2023-12-06 09:35:24 --> Loader Class Initialized
INFO - 2023-12-06 09:35:24 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:24 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:24 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:24 --> Controller Class Initialized
INFO - 2023-12-06 09:35:32 --> Config Class Initialized
INFO - 2023-12-06 09:35:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:32 --> URI Class Initialized
INFO - 2023-12-06 09:35:32 --> Router Class Initialized
INFO - 2023-12-06 09:35:32 --> Output Class Initialized
INFO - 2023-12-06 09:35:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:32 --> Input Class Initialized
INFO - 2023-12-06 09:35:32 --> Language Class Initialized
INFO - 2023-12-06 09:35:32 --> Language Class Initialized
INFO - 2023-12-06 09:35:32 --> Config Class Initialized
INFO - 2023-12-06 09:35:32 --> Loader Class Initialized
INFO - 2023-12-06 09:35:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:32 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:35:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:32 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:32 --> Total execution time: 0.0866
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:38 --> URI Class Initialized
INFO - 2023-12-06 09:35:38 --> Router Class Initialized
INFO - 2023-12-06 09:35:38 --> Output Class Initialized
INFO - 2023-12-06 09:35:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:38 --> Input Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Loader Class Initialized
INFO - 2023-12-06 09:35:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:38 --> Controller Class Initialized
INFO - 2023-12-06 09:35:38 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:38 --> URI Class Initialized
INFO - 2023-12-06 09:35:38 --> Router Class Initialized
INFO - 2023-12-06 09:35:38 --> Output Class Initialized
INFO - 2023-12-06 09:35:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:38 --> Input Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Loader Class Initialized
INFO - 2023-12-06 09:35:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:38 --> Controller Class Initialized
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:38 --> URI Class Initialized
INFO - 2023-12-06 09:35:38 --> Router Class Initialized
INFO - 2023-12-06 09:35:38 --> Output Class Initialized
INFO - 2023-12-06 09:35:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:38 --> Input Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Language Class Initialized
INFO - 2023-12-06 09:35:38 --> Config Class Initialized
INFO - 2023-12-06 09:35:38 --> Loader Class Initialized
INFO - 2023-12-06 09:35:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:38 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:38 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:38 --> Total execution time: 0.0359
INFO - 2023-12-06 09:35:44 --> Config Class Initialized
INFO - 2023-12-06 09:35:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:44 --> URI Class Initialized
INFO - 2023-12-06 09:35:44 --> Router Class Initialized
INFO - 2023-12-06 09:35:44 --> Output Class Initialized
INFO - 2023-12-06 09:35:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:44 --> Input Class Initialized
INFO - 2023-12-06 09:35:44 --> Language Class Initialized
INFO - 2023-12-06 09:35:44 --> Language Class Initialized
INFO - 2023-12-06 09:35:44 --> Config Class Initialized
INFO - 2023-12-06 09:35:44 --> Loader Class Initialized
INFO - 2023-12-06 09:35:44 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:44 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:44 --> Controller Class Initialized
INFO - 2023-12-06 09:35:44 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:35:44 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:44 --> Total execution time: 0.0403
INFO - 2023-12-06 09:35:44 --> Config Class Initialized
INFO - 2023-12-06 09:35:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:44 --> URI Class Initialized
INFO - 2023-12-06 09:35:44 --> Router Class Initialized
INFO - 2023-12-06 09:35:44 --> Output Class Initialized
INFO - 2023-12-06 09:35:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:44 --> Input Class Initialized
INFO - 2023-12-06 09:35:44 --> Language Class Initialized
INFO - 2023-12-06 09:35:44 --> Language Class Initialized
INFO - 2023-12-06 09:35:44 --> Config Class Initialized
INFO - 2023-12-06 09:35:44 --> Loader Class Initialized
INFO - 2023-12-06 09:35:44 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:44 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:44 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:44 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 09:35:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:44 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:44 --> Total execution time: 0.0957
INFO - 2023-12-06 09:35:51 --> Config Class Initialized
INFO - 2023-12-06 09:35:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:51 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:51 --> URI Class Initialized
INFO - 2023-12-06 09:35:51 --> Router Class Initialized
INFO - 2023-12-06 09:35:51 --> Output Class Initialized
INFO - 2023-12-06 09:35:51 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:51 --> Input Class Initialized
INFO - 2023-12-06 09:35:51 --> Language Class Initialized
INFO - 2023-12-06 09:35:51 --> Language Class Initialized
INFO - 2023-12-06 09:35:51 --> Config Class Initialized
INFO - 2023-12-06 09:35:51 --> Loader Class Initialized
INFO - 2023-12-06 09:35:51 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:51 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:51 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:51 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:51 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:51 --> Controller Class Initialized
DEBUG - 2023-12-06 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:35:51 --> Final output sent to browser
DEBUG - 2023-12-06 09:35:51 --> Total execution time: 0.0520
INFO - 2023-12-06 09:35:52 --> Config Class Initialized
INFO - 2023-12-06 09:35:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:52 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:52 --> URI Class Initialized
INFO - 2023-12-06 09:35:52 --> Router Class Initialized
INFO - 2023-12-06 09:35:52 --> Output Class Initialized
INFO - 2023-12-06 09:35:52 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:52 --> Input Class Initialized
INFO - 2023-12-06 09:35:52 --> Language Class Initialized
ERROR - 2023-12-06 09:35:52 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:35:52 --> Config Class Initialized
INFO - 2023-12-06 09:35:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:35:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:35:52 --> Utf8 Class Initialized
INFO - 2023-12-06 09:35:52 --> URI Class Initialized
INFO - 2023-12-06 09:35:52 --> Router Class Initialized
INFO - 2023-12-06 09:35:52 --> Output Class Initialized
INFO - 2023-12-06 09:35:52 --> Security Class Initialized
DEBUG - 2023-12-06 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:35:52 --> Input Class Initialized
INFO - 2023-12-06 09:35:52 --> Language Class Initialized
INFO - 2023-12-06 09:35:52 --> Language Class Initialized
INFO - 2023-12-06 09:35:52 --> Config Class Initialized
INFO - 2023-12-06 09:35:52 --> Loader Class Initialized
INFO - 2023-12-06 09:35:52 --> Helper loaded: url_helper
INFO - 2023-12-06 09:35:52 --> Helper loaded: file_helper
INFO - 2023-12-06 09:35:52 --> Helper loaded: form_helper
INFO - 2023-12-06 09:35:52 --> Helper loaded: my_helper
INFO - 2023-12-06 09:35:52 --> Database Driver Class Initialized
INFO - 2023-12-06 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:35:52 --> Controller Class Initialized
INFO - 2023-12-06 09:36:03 --> Config Class Initialized
INFO - 2023-12-06 09:36:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:03 --> URI Class Initialized
INFO - 2023-12-06 09:36:03 --> Router Class Initialized
INFO - 2023-12-06 09:36:03 --> Output Class Initialized
INFO - 2023-12-06 09:36:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:03 --> Input Class Initialized
INFO - 2023-12-06 09:36:03 --> Language Class Initialized
INFO - 2023-12-06 09:36:03 --> Language Class Initialized
INFO - 2023-12-06 09:36:03 --> Config Class Initialized
INFO - 2023-12-06 09:36:03 --> Loader Class Initialized
INFO - 2023-12-06 09:36:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:03 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:03 --> Total execution time: 0.0775
INFO - 2023-12-06 09:36:10 --> Config Class Initialized
INFO - 2023-12-06 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:10 --> URI Class Initialized
INFO - 2023-12-06 09:36:10 --> Router Class Initialized
INFO - 2023-12-06 09:36:10 --> Output Class Initialized
INFO - 2023-12-06 09:36:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:10 --> Input Class Initialized
INFO - 2023-12-06 09:36:10 --> Language Class Initialized
INFO - 2023-12-06 09:36:10 --> Language Class Initialized
INFO - 2023-12-06 09:36:10 --> Config Class Initialized
INFO - 2023-12-06 09:36:10 --> Loader Class Initialized
INFO - 2023-12-06 09:36:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:10 --> Total execution time: 0.0861
INFO - 2023-12-06 09:36:10 --> Config Class Initialized
INFO - 2023-12-06 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:10 --> URI Class Initialized
INFO - 2023-12-06 09:36:10 --> Router Class Initialized
INFO - 2023-12-06 09:36:10 --> Output Class Initialized
INFO - 2023-12-06 09:36:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:10 --> Input Class Initialized
INFO - 2023-12-06 09:36:10 --> Language Class Initialized
ERROR - 2023-12-06 09:36:10 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:36:10 --> Config Class Initialized
INFO - 2023-12-06 09:36:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:10 --> URI Class Initialized
INFO - 2023-12-06 09:36:10 --> Router Class Initialized
INFO - 2023-12-06 09:36:10 --> Output Class Initialized
INFO - 2023-12-06 09:36:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:10 --> Input Class Initialized
INFO - 2023-12-06 09:36:10 --> Language Class Initialized
INFO - 2023-12-06 09:36:10 --> Language Class Initialized
INFO - 2023-12-06 09:36:10 --> Config Class Initialized
INFO - 2023-12-06 09:36:10 --> Loader Class Initialized
INFO - 2023-12-06 09:36:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:10 --> Controller Class Initialized
INFO - 2023-12-06 09:36:28 --> Config Class Initialized
INFO - 2023-12-06 09:36:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:28 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:28 --> URI Class Initialized
INFO - 2023-12-06 09:36:28 --> Router Class Initialized
INFO - 2023-12-06 09:36:28 --> Output Class Initialized
INFO - 2023-12-06 09:36:28 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:28 --> Input Class Initialized
INFO - 2023-12-06 09:36:28 --> Language Class Initialized
INFO - 2023-12-06 09:36:28 --> Language Class Initialized
INFO - 2023-12-06 09:36:28 --> Config Class Initialized
INFO - 2023-12-06 09:36:28 --> Loader Class Initialized
INFO - 2023-12-06 09:36:28 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:28 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:28 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:28 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:28 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:28 --> Controller Class Initialized
INFO - 2023-12-06 09:36:28 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:28 --> Total execution time: 0.0341
INFO - 2023-12-06 09:36:32 --> Config Class Initialized
INFO - 2023-12-06 09:36:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:32 --> URI Class Initialized
INFO - 2023-12-06 09:36:32 --> Router Class Initialized
INFO - 2023-12-06 09:36:32 --> Output Class Initialized
INFO - 2023-12-06 09:36:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:32 --> Input Class Initialized
INFO - 2023-12-06 09:36:32 --> Language Class Initialized
INFO - 2023-12-06 09:36:32 --> Language Class Initialized
INFO - 2023-12-06 09:36:32 --> Config Class Initialized
INFO - 2023-12-06 09:36:32 --> Loader Class Initialized
INFO - 2023-12-06 09:36:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:32 --> Controller Class Initialized
INFO - 2023-12-06 09:36:32 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:32 --> Total execution time: 0.0301
INFO - 2023-12-06 09:36:32 --> Config Class Initialized
INFO - 2023-12-06 09:36:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:32 --> URI Class Initialized
INFO - 2023-12-06 09:36:32 --> Router Class Initialized
INFO - 2023-12-06 09:36:32 --> Output Class Initialized
INFO - 2023-12-06 09:36:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:32 --> Input Class Initialized
INFO - 2023-12-06 09:36:32 --> Language Class Initialized
ERROR - 2023-12-06 09:36:32 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:36:32 --> Config Class Initialized
INFO - 2023-12-06 09:36:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:32 --> URI Class Initialized
INFO - 2023-12-06 09:36:32 --> Router Class Initialized
INFO - 2023-12-06 09:36:32 --> Output Class Initialized
INFO - 2023-12-06 09:36:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:32 --> Input Class Initialized
INFO - 2023-12-06 09:36:32 --> Language Class Initialized
INFO - 2023-12-06 09:36:32 --> Language Class Initialized
INFO - 2023-12-06 09:36:32 --> Config Class Initialized
INFO - 2023-12-06 09:36:32 --> Loader Class Initialized
INFO - 2023-12-06 09:36:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:32 --> Controller Class Initialized
INFO - 2023-12-06 09:36:36 --> Config Class Initialized
INFO - 2023-12-06 09:36:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:36 --> URI Class Initialized
INFO - 2023-12-06 09:36:36 --> Router Class Initialized
INFO - 2023-12-06 09:36:36 --> Output Class Initialized
INFO - 2023-12-06 09:36:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:36 --> Input Class Initialized
INFO - 2023-12-06 09:36:36 --> Language Class Initialized
INFO - 2023-12-06 09:36:36 --> Language Class Initialized
INFO - 2023-12-06 09:36:36 --> Config Class Initialized
INFO - 2023-12-06 09:36:36 --> Loader Class Initialized
INFO - 2023-12-06 09:36:36 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:36 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:36 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:36 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:36 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:36 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2023-12-06 09:36:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:36 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:36 --> Total execution time: 0.0392
INFO - 2023-12-06 09:36:37 --> Config Class Initialized
INFO - 2023-12-06 09:36:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:37 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:37 --> URI Class Initialized
INFO - 2023-12-06 09:36:37 --> Router Class Initialized
INFO - 2023-12-06 09:36:37 --> Output Class Initialized
INFO - 2023-12-06 09:36:37 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:37 --> Input Class Initialized
INFO - 2023-12-06 09:36:37 --> Language Class Initialized
INFO - 2023-12-06 09:36:37 --> Language Class Initialized
INFO - 2023-12-06 09:36:37 --> Config Class Initialized
INFO - 2023-12-06 09:36:37 --> Loader Class Initialized
INFO - 2023-12-06 09:36:37 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:37 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:37 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:37 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:37 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:37 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2023-12-06 09:36:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:37 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:37 --> Total execution time: 0.0539
INFO - 2023-12-06 09:36:44 --> Config Class Initialized
INFO - 2023-12-06 09:36:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:44 --> URI Class Initialized
INFO - 2023-12-06 09:36:44 --> Router Class Initialized
INFO - 2023-12-06 09:36:44 --> Output Class Initialized
INFO - 2023-12-06 09:36:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:44 --> Input Class Initialized
INFO - 2023-12-06 09:36:44 --> Language Class Initialized
INFO - 2023-12-06 09:36:44 --> Language Class Initialized
INFO - 2023-12-06 09:36:44 --> Config Class Initialized
INFO - 2023-12-06 09:36:44 --> Loader Class Initialized
INFO - 2023-12-06 09:36:44 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:44 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:44 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:36:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:44 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:44 --> Total execution time: 0.0963
INFO - 2023-12-06 09:36:44 --> Config Class Initialized
INFO - 2023-12-06 09:36:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:44 --> URI Class Initialized
INFO - 2023-12-06 09:36:44 --> Router Class Initialized
INFO - 2023-12-06 09:36:44 --> Output Class Initialized
INFO - 2023-12-06 09:36:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:44 --> Input Class Initialized
INFO - 2023-12-06 09:36:44 --> Language Class Initialized
ERROR - 2023-12-06 09:36:44 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:36:44 --> Config Class Initialized
INFO - 2023-12-06 09:36:44 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:44 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:44 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:44 --> URI Class Initialized
INFO - 2023-12-06 09:36:44 --> Router Class Initialized
INFO - 2023-12-06 09:36:44 --> Output Class Initialized
INFO - 2023-12-06 09:36:44 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:44 --> Input Class Initialized
INFO - 2023-12-06 09:36:44 --> Language Class Initialized
INFO - 2023-12-06 09:36:44 --> Language Class Initialized
INFO - 2023-12-06 09:36:44 --> Config Class Initialized
INFO - 2023-12-06 09:36:44 --> Loader Class Initialized
INFO - 2023-12-06 09:36:44 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:44 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:44 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:44 --> Controller Class Initialized
INFO - 2023-12-06 09:36:46 --> Config Class Initialized
INFO - 2023-12-06 09:36:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:36:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:36:46 --> Utf8 Class Initialized
INFO - 2023-12-06 09:36:46 --> URI Class Initialized
INFO - 2023-12-06 09:36:46 --> Router Class Initialized
INFO - 2023-12-06 09:36:46 --> Output Class Initialized
INFO - 2023-12-06 09:36:46 --> Security Class Initialized
DEBUG - 2023-12-06 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:36:46 --> Input Class Initialized
INFO - 2023-12-06 09:36:46 --> Language Class Initialized
INFO - 2023-12-06 09:36:46 --> Language Class Initialized
INFO - 2023-12-06 09:36:46 --> Config Class Initialized
INFO - 2023-12-06 09:36:46 --> Loader Class Initialized
INFO - 2023-12-06 09:36:46 --> Helper loaded: url_helper
INFO - 2023-12-06 09:36:46 --> Helper loaded: file_helper
INFO - 2023-12-06 09:36:46 --> Helper loaded: form_helper
INFO - 2023-12-06 09:36:46 --> Helper loaded: my_helper
INFO - 2023-12-06 09:36:46 --> Database Driver Class Initialized
INFO - 2023-12-06 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:36:46 --> Controller Class Initialized
DEBUG - 2023-12-06 09:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-12-06 09:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:36:46 --> Final output sent to browser
DEBUG - 2023-12-06 09:36:46 --> Total execution time: 0.0322
INFO - 2023-12-06 09:37:09 --> Config Class Initialized
INFO - 2023-12-06 09:37:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:09 --> URI Class Initialized
INFO - 2023-12-06 09:37:09 --> Router Class Initialized
INFO - 2023-12-06 09:37:09 --> Output Class Initialized
INFO - 2023-12-06 09:37:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:09 --> Input Class Initialized
INFO - 2023-12-06 09:37:09 --> Language Class Initialized
INFO - 2023-12-06 09:37:09 --> Language Class Initialized
INFO - 2023-12-06 09:37:09 --> Config Class Initialized
INFO - 2023-12-06 09:37:09 --> Loader Class Initialized
INFO - 2023-12-06 09:37:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:09 --> Controller Class Initialized
DEBUG - 2023-12-06 09:37:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-12-06 09:37:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:37:09 --> Final output sent to browser
DEBUG - 2023-12-06 09:37:09 --> Total execution time: 0.0367
INFO - 2023-12-06 09:37:09 --> Config Class Initialized
INFO - 2023-12-06 09:37:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:09 --> URI Class Initialized
INFO - 2023-12-06 09:37:09 --> Router Class Initialized
INFO - 2023-12-06 09:37:09 --> Output Class Initialized
INFO - 2023-12-06 09:37:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:09 --> Input Class Initialized
INFO - 2023-12-06 09:37:09 --> Language Class Initialized
ERROR - 2023-12-06 09:37:09 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:37:09 --> Config Class Initialized
INFO - 2023-12-06 09:37:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:09 --> URI Class Initialized
INFO - 2023-12-06 09:37:09 --> Router Class Initialized
INFO - 2023-12-06 09:37:09 --> Output Class Initialized
INFO - 2023-12-06 09:37:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:09 --> Input Class Initialized
INFO - 2023-12-06 09:37:09 --> Language Class Initialized
INFO - 2023-12-06 09:37:09 --> Language Class Initialized
INFO - 2023-12-06 09:37:09 --> Config Class Initialized
INFO - 2023-12-06 09:37:09 --> Loader Class Initialized
INFO - 2023-12-06 09:37:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:09 --> Controller Class Initialized
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:33 --> URI Class Initialized
INFO - 2023-12-06 09:37:33 --> Router Class Initialized
INFO - 2023-12-06 09:37:33 --> Output Class Initialized
INFO - 2023-12-06 09:37:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:33 --> Input Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Loader Class Initialized
INFO - 2023-12-06 09:37:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:33 --> Controller Class Initialized
INFO - 2023-12-06 09:37:33 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:33 --> URI Class Initialized
INFO - 2023-12-06 09:37:33 --> Router Class Initialized
INFO - 2023-12-06 09:37:33 --> Output Class Initialized
INFO - 2023-12-06 09:37:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:33 --> Input Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Loader Class Initialized
INFO - 2023-12-06 09:37:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:33 --> Controller Class Initialized
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:33 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:33 --> URI Class Initialized
INFO - 2023-12-06 09:37:33 --> Router Class Initialized
INFO - 2023-12-06 09:37:33 --> Output Class Initialized
INFO - 2023-12-06 09:37:33 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:33 --> Input Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Language Class Initialized
INFO - 2023-12-06 09:37:33 --> Config Class Initialized
INFO - 2023-12-06 09:37:33 --> Loader Class Initialized
INFO - 2023-12-06 09:37:33 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:33 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:33 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:33 --> Controller Class Initialized
DEBUG - 2023-12-06 09:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:37:33 --> Final output sent to browser
DEBUG - 2023-12-06 09:37:33 --> Total execution time: 0.0350
INFO - 2023-12-06 09:37:39 --> Config Class Initialized
INFO - 2023-12-06 09:37:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:39 --> URI Class Initialized
INFO - 2023-12-06 09:37:39 --> Router Class Initialized
INFO - 2023-12-06 09:37:39 --> Output Class Initialized
INFO - 2023-12-06 09:37:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:39 --> Input Class Initialized
INFO - 2023-12-06 09:37:39 --> Language Class Initialized
INFO - 2023-12-06 09:37:40 --> Language Class Initialized
INFO - 2023-12-06 09:37:40 --> Config Class Initialized
INFO - 2023-12-06 09:37:40 --> Loader Class Initialized
INFO - 2023-12-06 09:37:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:40 --> Controller Class Initialized
INFO - 2023-12-06 09:37:40 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:37:40 --> Final output sent to browser
DEBUG - 2023-12-06 09:37:40 --> Total execution time: 0.0358
INFO - 2023-12-06 09:37:40 --> Config Class Initialized
INFO - 2023-12-06 09:37:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:37:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:37:40 --> Utf8 Class Initialized
INFO - 2023-12-06 09:37:40 --> URI Class Initialized
INFO - 2023-12-06 09:37:40 --> Router Class Initialized
INFO - 2023-12-06 09:37:40 --> Output Class Initialized
INFO - 2023-12-06 09:37:40 --> Security Class Initialized
DEBUG - 2023-12-06 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:37:40 --> Input Class Initialized
INFO - 2023-12-06 09:37:40 --> Language Class Initialized
INFO - 2023-12-06 09:37:40 --> Language Class Initialized
INFO - 2023-12-06 09:37:40 --> Config Class Initialized
INFO - 2023-12-06 09:37:40 --> Loader Class Initialized
INFO - 2023-12-06 09:37:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:37:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:37:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:37:40 --> Controller Class Initialized
DEBUG - 2023-12-06 09:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:37:40 --> Final output sent to browser
DEBUG - 2023-12-06 09:37:40 --> Total execution time: 0.0556
INFO - 2023-12-06 09:38:08 --> Config Class Initialized
INFO - 2023-12-06 09:38:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:38:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:38:08 --> Utf8 Class Initialized
INFO - 2023-12-06 09:38:08 --> URI Class Initialized
INFO - 2023-12-06 09:38:08 --> Router Class Initialized
INFO - 2023-12-06 09:38:08 --> Output Class Initialized
INFO - 2023-12-06 09:38:08 --> Security Class Initialized
DEBUG - 2023-12-06 09:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:38:08 --> Input Class Initialized
INFO - 2023-12-06 09:38:08 --> Language Class Initialized
INFO - 2023-12-06 09:38:08 --> Language Class Initialized
INFO - 2023-12-06 09:38:08 --> Config Class Initialized
INFO - 2023-12-06 09:38:08 --> Loader Class Initialized
INFO - 2023-12-06 09:38:08 --> Helper loaded: url_helper
INFO - 2023-12-06 09:38:08 --> Helper loaded: file_helper
INFO - 2023-12-06 09:38:08 --> Helper loaded: form_helper
INFO - 2023-12-06 09:38:08 --> Helper loaded: my_helper
INFO - 2023-12-06 09:38:08 --> Database Driver Class Initialized
INFO - 2023-12-06 09:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:38:08 --> Controller Class Initialized
DEBUG - 2023-12-06 09:38:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 09:38:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:38:08 --> Final output sent to browser
DEBUG - 2023-12-06 09:38:08 --> Total execution time: 0.0717
INFO - 2023-12-06 09:38:13 --> Config Class Initialized
INFO - 2023-12-06 09:38:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:38:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:38:13 --> Utf8 Class Initialized
INFO - 2023-12-06 09:38:13 --> URI Class Initialized
INFO - 2023-12-06 09:38:13 --> Router Class Initialized
INFO - 2023-12-06 09:38:13 --> Output Class Initialized
INFO - 2023-12-06 09:38:13 --> Security Class Initialized
DEBUG - 2023-12-06 09:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:38:13 --> Input Class Initialized
INFO - 2023-12-06 09:38:13 --> Language Class Initialized
INFO - 2023-12-06 09:38:13 --> Language Class Initialized
INFO - 2023-12-06 09:38:13 --> Config Class Initialized
INFO - 2023-12-06 09:38:13 --> Loader Class Initialized
INFO - 2023-12-06 09:38:13 --> Helper loaded: url_helper
INFO - 2023-12-06 09:38:13 --> Helper loaded: file_helper
INFO - 2023-12-06 09:38:13 --> Helper loaded: form_helper
INFO - 2023-12-06 09:38:13 --> Helper loaded: my_helper
INFO - 2023-12-06 09:38:13 --> Database Driver Class Initialized
INFO - 2023-12-06 09:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:38:13 --> Controller Class Initialized
ERROR - 2023-12-06 09:38:13 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-06 09:38:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-06 09:38:17 --> Final output sent to browser
DEBUG - 2023-12-06 09:38:17 --> Total execution time: 4.1466
INFO - 2023-12-06 09:39:32 --> Config Class Initialized
INFO - 2023-12-06 09:39:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:39:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:39:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:39:32 --> URI Class Initialized
INFO - 2023-12-06 09:39:32 --> Router Class Initialized
INFO - 2023-12-06 09:39:32 --> Output Class Initialized
INFO - 2023-12-06 09:39:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:39:32 --> Input Class Initialized
INFO - 2023-12-06 09:39:32 --> Language Class Initialized
INFO - 2023-12-06 09:39:32 --> Language Class Initialized
INFO - 2023-12-06 09:39:32 --> Config Class Initialized
INFO - 2023-12-06 09:39:32 --> Loader Class Initialized
INFO - 2023-12-06 09:39:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:39:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:39:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:39:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:39:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:39:32 --> Controller Class Initialized
DEBUG - 2023-12-06 09:39:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-06 09:39:35 --> Final output sent to browser
DEBUG - 2023-12-06 09:39:35 --> Total execution time: 2.7216
INFO - 2023-12-06 09:40:01 --> Config Class Initialized
INFO - 2023-12-06 09:40:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:40:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:40:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:40:01 --> URI Class Initialized
INFO - 2023-12-06 09:40:01 --> Router Class Initialized
INFO - 2023-12-06 09:40:01 --> Output Class Initialized
INFO - 2023-12-06 09:40:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:40:01 --> Input Class Initialized
INFO - 2023-12-06 09:40:01 --> Language Class Initialized
INFO - 2023-12-06 09:40:01 --> Language Class Initialized
INFO - 2023-12-06 09:40:01 --> Config Class Initialized
INFO - 2023-12-06 09:40:01 --> Loader Class Initialized
INFO - 2023-12-06 09:40:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:40:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:40:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:40:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:40:01 --> Database Driver Class Initialized
INFO - 2023-12-06 09:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:40:01 --> Controller Class Initialized
ERROR - 2023-12-06 09:40:01 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-06 09:40:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-06 09:40:07 --> Final output sent to browser
DEBUG - 2023-12-06 09:40:07 --> Total execution time: 6.4289
INFO - 2023-12-06 09:43:59 --> Config Class Initialized
INFO - 2023-12-06 09:43:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:43:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:43:59 --> Utf8 Class Initialized
INFO - 2023-12-06 09:43:59 --> URI Class Initialized
INFO - 2023-12-06 09:43:59 --> Router Class Initialized
INFO - 2023-12-06 09:43:59 --> Output Class Initialized
INFO - 2023-12-06 09:43:59 --> Security Class Initialized
DEBUG - 2023-12-06 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:43:59 --> Input Class Initialized
INFO - 2023-12-06 09:43:59 --> Language Class Initialized
INFO - 2023-12-06 09:43:59 --> Language Class Initialized
INFO - 2023-12-06 09:43:59 --> Config Class Initialized
INFO - 2023-12-06 09:43:59 --> Loader Class Initialized
INFO - 2023-12-06 09:43:59 --> Helper loaded: url_helper
INFO - 2023-12-06 09:43:59 --> Helper loaded: file_helper
INFO - 2023-12-06 09:43:59 --> Helper loaded: form_helper
INFO - 2023-12-06 09:43:59 --> Helper loaded: my_helper
INFO - 2023-12-06 09:43:59 --> Database Driver Class Initialized
INFO - 2023-12-06 09:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:43:59 --> Controller Class Initialized
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
ERROR - 2023-12-06 09:43:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
ERROR - 2023-12-06 09:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
DEBUG - 2023-12-06 09:43:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-06 09:44:07 --> Final output sent to browser
DEBUG - 2023-12-06 09:44:07 --> Total execution time: 7.6876
INFO - 2023-12-06 09:44:25 --> Config Class Initialized
INFO - 2023-12-06 09:44:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:44:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:44:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:44:25 --> URI Class Initialized
INFO - 2023-12-06 09:44:25 --> Router Class Initialized
INFO - 2023-12-06 09:44:25 --> Output Class Initialized
INFO - 2023-12-06 09:44:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:44:25 --> Input Class Initialized
INFO - 2023-12-06 09:44:25 --> Language Class Initialized
INFO - 2023-12-06 09:44:25 --> Language Class Initialized
INFO - 2023-12-06 09:44:25 --> Config Class Initialized
INFO - 2023-12-06 09:44:25 --> Loader Class Initialized
INFO - 2023-12-06 09:44:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:44:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:44:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:44:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:44:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:44:25 --> Controller Class Initialized
DEBUG - 2023-12-06 09:44:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 09:44:30 --> Final output sent to browser
DEBUG - 2023-12-06 09:44:30 --> Total execution time: 5.2144
INFO - 2023-12-06 09:44:58 --> Config Class Initialized
INFO - 2023-12-06 09:44:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:44:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:44:58 --> Utf8 Class Initialized
INFO - 2023-12-06 09:44:58 --> URI Class Initialized
INFO - 2023-12-06 09:44:58 --> Router Class Initialized
INFO - 2023-12-06 09:44:58 --> Output Class Initialized
INFO - 2023-12-06 09:44:58 --> Security Class Initialized
DEBUG - 2023-12-06 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:44:58 --> Input Class Initialized
INFO - 2023-12-06 09:44:58 --> Language Class Initialized
INFO - 2023-12-06 09:44:58 --> Language Class Initialized
INFO - 2023-12-06 09:44:58 --> Config Class Initialized
INFO - 2023-12-06 09:44:58 --> Loader Class Initialized
INFO - 2023-12-06 09:44:58 --> Helper loaded: url_helper
INFO - 2023-12-06 09:44:58 --> Helper loaded: file_helper
INFO - 2023-12-06 09:44:58 --> Helper loaded: form_helper
INFO - 2023-12-06 09:44:58 --> Helper loaded: my_helper
INFO - 2023-12-06 09:44:58 --> Database Driver Class Initialized
INFO - 2023-12-06 09:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:44:58 --> Controller Class Initialized
DEBUG - 2023-12-06 09:44:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:44:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:44:58 --> Final output sent to browser
DEBUG - 2023-12-06 09:44:58 --> Total execution time: 0.0442
INFO - 2023-12-06 09:45:02 --> Config Class Initialized
INFO - 2023-12-06 09:45:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:02 --> URI Class Initialized
INFO - 2023-12-06 09:45:02 --> Router Class Initialized
INFO - 2023-12-06 09:45:02 --> Output Class Initialized
INFO - 2023-12-06 09:45:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:02 --> Input Class Initialized
INFO - 2023-12-06 09:45:02 --> Language Class Initialized
INFO - 2023-12-06 09:45:02 --> Language Class Initialized
INFO - 2023-12-06 09:45:02 --> Config Class Initialized
INFO - 2023-12-06 09:45:02 --> Loader Class Initialized
INFO - 2023-12-06 09:45:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:02 --> Controller Class Initialized
DEBUG - 2023-12-06 09:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:45:02 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:02 --> Total execution time: 0.0736
INFO - 2023-12-06 09:45:02 --> Config Class Initialized
INFO - 2023-12-06 09:45:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:02 --> URI Class Initialized
INFO - 2023-12-06 09:45:02 --> Router Class Initialized
INFO - 2023-12-06 09:45:02 --> Output Class Initialized
INFO - 2023-12-06 09:45:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:02 --> Input Class Initialized
INFO - 2023-12-06 09:45:02 --> Language Class Initialized
INFO - 2023-12-06 09:45:02 --> Language Class Initialized
INFO - 2023-12-06 09:45:02 --> Config Class Initialized
INFO - 2023-12-06 09:45:02 --> Loader Class Initialized
INFO - 2023-12-06 09:45:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:02 --> Controller Class Initialized
INFO - 2023-12-06 09:45:04 --> Config Class Initialized
INFO - 2023-12-06 09:45:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:04 --> URI Class Initialized
INFO - 2023-12-06 09:45:04 --> Router Class Initialized
INFO - 2023-12-06 09:45:04 --> Output Class Initialized
INFO - 2023-12-06 09:45:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:04 --> Input Class Initialized
INFO - 2023-12-06 09:45:04 --> Language Class Initialized
INFO - 2023-12-06 09:45:04 --> Language Class Initialized
INFO - 2023-12-06 09:45:04 --> Config Class Initialized
INFO - 2023-12-06 09:45:04 --> Loader Class Initialized
INFO - 2023-12-06 09:45:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:04 --> Controller Class Initialized
INFO - 2023-12-06 09:45:04 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:04 --> Total execution time: 0.0645
INFO - 2023-12-06 09:45:24 --> Config Class Initialized
INFO - 2023-12-06 09:45:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:24 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:24 --> URI Class Initialized
INFO - 2023-12-06 09:45:24 --> Router Class Initialized
INFO - 2023-12-06 09:45:24 --> Output Class Initialized
INFO - 2023-12-06 09:45:24 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:24 --> Input Class Initialized
INFO - 2023-12-06 09:45:24 --> Language Class Initialized
INFO - 2023-12-06 09:45:24 --> Language Class Initialized
INFO - 2023-12-06 09:45:24 --> Config Class Initialized
INFO - 2023-12-06 09:45:24 --> Loader Class Initialized
INFO - 2023-12-06 09:45:24 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:24 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:24 --> Controller Class Initialized
INFO - 2023-12-06 09:45:24 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:24 --> Total execution time: 0.0360
INFO - 2023-12-06 09:45:24 --> Config Class Initialized
INFO - 2023-12-06 09:45:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:24 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:24 --> URI Class Initialized
INFO - 2023-12-06 09:45:24 --> Router Class Initialized
INFO - 2023-12-06 09:45:24 --> Output Class Initialized
INFO - 2023-12-06 09:45:24 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:24 --> Input Class Initialized
INFO - 2023-12-06 09:45:24 --> Language Class Initialized
INFO - 2023-12-06 09:45:24 --> Language Class Initialized
INFO - 2023-12-06 09:45:24 --> Config Class Initialized
INFO - 2023-12-06 09:45:24 --> Loader Class Initialized
INFO - 2023-12-06 09:45:24 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:24 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:24 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:24 --> Controller Class Initialized
INFO - 2023-12-06 09:45:31 --> Config Class Initialized
INFO - 2023-12-06 09:45:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:31 --> URI Class Initialized
INFO - 2023-12-06 09:45:31 --> Router Class Initialized
INFO - 2023-12-06 09:45:31 --> Output Class Initialized
INFO - 2023-12-06 09:45:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:31 --> Input Class Initialized
INFO - 2023-12-06 09:45:31 --> Language Class Initialized
INFO - 2023-12-06 09:45:31 --> Language Class Initialized
INFO - 2023-12-06 09:45:31 --> Config Class Initialized
INFO - 2023-12-06 09:45:31 --> Loader Class Initialized
INFO - 2023-12-06 09:45:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:31 --> Controller Class Initialized
INFO - 2023-12-06 09:45:31 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:31 --> Total execution time: 0.0962
INFO - 2023-12-06 09:45:43 --> Config Class Initialized
INFO - 2023-12-06 09:45:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:43 --> URI Class Initialized
INFO - 2023-12-06 09:45:43 --> Router Class Initialized
INFO - 2023-12-06 09:45:43 --> Output Class Initialized
INFO - 2023-12-06 09:45:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:43 --> Input Class Initialized
INFO - 2023-12-06 09:45:43 --> Language Class Initialized
INFO - 2023-12-06 09:45:43 --> Language Class Initialized
INFO - 2023-12-06 09:45:43 --> Config Class Initialized
INFO - 2023-12-06 09:45:43 --> Loader Class Initialized
INFO - 2023-12-06 09:45:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:43 --> Controller Class Initialized
INFO - 2023-12-06 09:45:43 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:43 --> Total execution time: 0.0591
INFO - 2023-12-06 09:45:48 --> Config Class Initialized
INFO - 2023-12-06 09:45:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:48 --> URI Class Initialized
INFO - 2023-12-06 09:45:48 --> Router Class Initialized
INFO - 2023-12-06 09:45:48 --> Output Class Initialized
INFO - 2023-12-06 09:45:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:48 --> Input Class Initialized
INFO - 2023-12-06 09:45:48 --> Language Class Initialized
INFO - 2023-12-06 09:45:49 --> Language Class Initialized
INFO - 2023-12-06 09:45:49 --> Config Class Initialized
INFO - 2023-12-06 09:45:49 --> Loader Class Initialized
INFO - 2023-12-06 09:45:49 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:49 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:49 --> Controller Class Initialized
INFO - 2023-12-06 09:45:49 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:49 --> Total execution time: 0.0659
INFO - 2023-12-06 09:45:49 --> Config Class Initialized
INFO - 2023-12-06 09:45:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:45:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:45:49 --> Utf8 Class Initialized
INFO - 2023-12-06 09:45:49 --> URI Class Initialized
INFO - 2023-12-06 09:45:49 --> Router Class Initialized
INFO - 2023-12-06 09:45:49 --> Output Class Initialized
INFO - 2023-12-06 09:45:49 --> Security Class Initialized
DEBUG - 2023-12-06 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:45:49 --> Input Class Initialized
INFO - 2023-12-06 09:45:49 --> Language Class Initialized
INFO - 2023-12-06 09:45:49 --> Language Class Initialized
INFO - 2023-12-06 09:45:49 --> Config Class Initialized
INFO - 2023-12-06 09:45:49 --> Loader Class Initialized
INFO - 2023-12-06 09:45:49 --> Helper loaded: url_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: file_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: form_helper
INFO - 2023-12-06 09:45:49 --> Helper loaded: my_helper
INFO - 2023-12-06 09:45:49 --> Database Driver Class Initialized
INFO - 2023-12-06 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:45:49 --> Controller Class Initialized
INFO - 2023-12-06 09:45:49 --> Final output sent to browser
DEBUG - 2023-12-06 09:45:49 --> Total execution time: 0.1202
INFO - 2023-12-06 09:46:00 --> Config Class Initialized
INFO - 2023-12-06 09:46:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:00 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:00 --> URI Class Initialized
INFO - 2023-12-06 09:46:00 --> Router Class Initialized
INFO - 2023-12-06 09:46:00 --> Output Class Initialized
INFO - 2023-12-06 09:46:00 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:00 --> Input Class Initialized
INFO - 2023-12-06 09:46:00 --> Language Class Initialized
INFO - 2023-12-06 09:46:00 --> Language Class Initialized
INFO - 2023-12-06 09:46:00 --> Config Class Initialized
INFO - 2023-12-06 09:46:00 --> Loader Class Initialized
INFO - 2023-12-06 09:46:00 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:00 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:00 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:00 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:00 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:00 --> Controller Class Initialized
DEBUG - 2023-12-06 09:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:46:00 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:00 --> Total execution time: 0.0876
INFO - 2023-12-06 09:46:04 --> Config Class Initialized
INFO - 2023-12-06 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:04 --> URI Class Initialized
INFO - 2023-12-06 09:46:04 --> Router Class Initialized
INFO - 2023-12-06 09:46:04 --> Output Class Initialized
INFO - 2023-12-06 09:46:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:04 --> Input Class Initialized
INFO - 2023-12-06 09:46:04 --> Language Class Initialized
INFO - 2023-12-06 09:46:04 --> Language Class Initialized
INFO - 2023-12-06 09:46:04 --> Config Class Initialized
INFO - 2023-12-06 09:46:04 --> Loader Class Initialized
INFO - 2023-12-06 09:46:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:04 --> Controller Class Initialized
DEBUG - 2023-12-06 09:46:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 09:46:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:46:04 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:04 --> Total execution time: 0.0463
INFO - 2023-12-06 09:46:04 --> Config Class Initialized
INFO - 2023-12-06 09:46:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:04 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:04 --> URI Class Initialized
INFO - 2023-12-06 09:46:04 --> Router Class Initialized
INFO - 2023-12-06 09:46:04 --> Output Class Initialized
INFO - 2023-12-06 09:46:04 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:04 --> Input Class Initialized
INFO - 2023-12-06 09:46:04 --> Language Class Initialized
INFO - 2023-12-06 09:46:04 --> Language Class Initialized
INFO - 2023-12-06 09:46:04 --> Config Class Initialized
INFO - 2023-12-06 09:46:04 --> Loader Class Initialized
INFO - 2023-12-06 09:46:04 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:04 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:04 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:04 --> Controller Class Initialized
INFO - 2023-12-06 09:46:08 --> Config Class Initialized
INFO - 2023-12-06 09:46:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:08 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:08 --> URI Class Initialized
INFO - 2023-12-06 09:46:08 --> Router Class Initialized
INFO - 2023-12-06 09:46:08 --> Output Class Initialized
INFO - 2023-12-06 09:46:08 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:08 --> Input Class Initialized
INFO - 2023-12-06 09:46:08 --> Language Class Initialized
INFO - 2023-12-06 09:46:08 --> Language Class Initialized
INFO - 2023-12-06 09:46:08 --> Config Class Initialized
INFO - 2023-12-06 09:46:08 --> Loader Class Initialized
INFO - 2023-12-06 09:46:08 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:08 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:08 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:08 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:08 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:08 --> Controller Class Initialized
INFO - 2023-12-06 09:46:08 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:08 --> Total execution time: 0.0520
INFO - 2023-12-06 09:46:26 --> Config Class Initialized
INFO - 2023-12-06 09:46:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:26 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:26 --> URI Class Initialized
INFO - 2023-12-06 09:46:26 --> Router Class Initialized
INFO - 2023-12-06 09:46:26 --> Output Class Initialized
INFO - 2023-12-06 09:46:26 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:26 --> Input Class Initialized
INFO - 2023-12-06 09:46:26 --> Language Class Initialized
INFO - 2023-12-06 09:46:26 --> Language Class Initialized
INFO - 2023-12-06 09:46:26 --> Config Class Initialized
INFO - 2023-12-06 09:46:26 --> Loader Class Initialized
INFO - 2023-12-06 09:46:26 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:26 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:26 --> Controller Class Initialized
INFO - 2023-12-06 09:46:26 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:26 --> Total execution time: 0.1013
INFO - 2023-12-06 09:46:26 --> Config Class Initialized
INFO - 2023-12-06 09:46:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:26 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:26 --> URI Class Initialized
INFO - 2023-12-06 09:46:26 --> Router Class Initialized
INFO - 2023-12-06 09:46:26 --> Output Class Initialized
INFO - 2023-12-06 09:46:26 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:26 --> Input Class Initialized
INFO - 2023-12-06 09:46:26 --> Language Class Initialized
INFO - 2023-12-06 09:46:26 --> Language Class Initialized
INFO - 2023-12-06 09:46:26 --> Config Class Initialized
INFO - 2023-12-06 09:46:26 --> Loader Class Initialized
INFO - 2023-12-06 09:46:26 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:26 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:26 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:26 --> Controller Class Initialized
INFO - 2023-12-06 09:46:28 --> Config Class Initialized
INFO - 2023-12-06 09:46:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:28 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:28 --> URI Class Initialized
INFO - 2023-12-06 09:46:28 --> Router Class Initialized
INFO - 2023-12-06 09:46:28 --> Output Class Initialized
INFO - 2023-12-06 09:46:28 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:28 --> Input Class Initialized
INFO - 2023-12-06 09:46:28 --> Language Class Initialized
INFO - 2023-12-06 09:46:28 --> Language Class Initialized
INFO - 2023-12-06 09:46:28 --> Config Class Initialized
INFO - 2023-12-06 09:46:28 --> Loader Class Initialized
INFO - 2023-12-06 09:46:28 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:28 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:28 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:28 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:28 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:28 --> Controller Class Initialized
INFO - 2023-12-06 09:46:28 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:28 --> Total execution time: 0.0952
INFO - 2023-12-06 09:46:34 --> Config Class Initialized
INFO - 2023-12-06 09:46:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:34 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:34 --> URI Class Initialized
INFO - 2023-12-06 09:46:34 --> Router Class Initialized
INFO - 2023-12-06 09:46:34 --> Output Class Initialized
INFO - 2023-12-06 09:46:34 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:34 --> Input Class Initialized
INFO - 2023-12-06 09:46:34 --> Language Class Initialized
INFO - 2023-12-06 09:46:34 --> Language Class Initialized
INFO - 2023-12-06 09:46:34 --> Config Class Initialized
INFO - 2023-12-06 09:46:34 --> Loader Class Initialized
INFO - 2023-12-06 09:46:34 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:34 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:34 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:34 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:34 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:34 --> Controller Class Initialized
INFO - 2023-12-06 09:46:34 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:34 --> Total execution time: 0.0627
INFO - 2023-12-06 09:46:39 --> Config Class Initialized
INFO - 2023-12-06 09:46:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:39 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:39 --> URI Class Initialized
INFO - 2023-12-06 09:46:39 --> Router Class Initialized
INFO - 2023-12-06 09:46:39 --> Output Class Initialized
INFO - 2023-12-06 09:46:39 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:39 --> Input Class Initialized
INFO - 2023-12-06 09:46:39 --> Language Class Initialized
INFO - 2023-12-06 09:46:40 --> Language Class Initialized
INFO - 2023-12-06 09:46:40 --> Config Class Initialized
INFO - 2023-12-06 09:46:40 --> Loader Class Initialized
INFO - 2023-12-06 09:46:40 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:40 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:40 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:40 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:40 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:40 --> Controller Class Initialized
INFO - 2023-12-06 09:46:40 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:40 --> Total execution time: 0.0777
INFO - 2023-12-06 09:46:54 --> Config Class Initialized
INFO - 2023-12-06 09:46:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:46:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:46:54 --> Utf8 Class Initialized
INFO - 2023-12-06 09:46:54 --> URI Class Initialized
INFO - 2023-12-06 09:46:54 --> Router Class Initialized
INFO - 2023-12-06 09:46:54 --> Output Class Initialized
INFO - 2023-12-06 09:46:54 --> Security Class Initialized
DEBUG - 2023-12-06 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:46:54 --> Input Class Initialized
INFO - 2023-12-06 09:46:54 --> Language Class Initialized
INFO - 2023-12-06 09:46:54 --> Language Class Initialized
INFO - 2023-12-06 09:46:54 --> Config Class Initialized
INFO - 2023-12-06 09:46:54 --> Loader Class Initialized
INFO - 2023-12-06 09:46:54 --> Helper loaded: url_helper
INFO - 2023-12-06 09:46:54 --> Helper loaded: file_helper
INFO - 2023-12-06 09:46:54 --> Helper loaded: form_helper
INFO - 2023-12-06 09:46:54 --> Helper loaded: my_helper
INFO - 2023-12-06 09:46:54 --> Database Driver Class Initialized
INFO - 2023-12-06 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:46:54 --> Controller Class Initialized
INFO - 2023-12-06 09:46:54 --> Final output sent to browser
DEBUG - 2023-12-06 09:46:54 --> Total execution time: 0.0676
INFO - 2023-12-06 09:47:02 --> Config Class Initialized
INFO - 2023-12-06 09:47:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:47:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:47:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:47:02 --> URI Class Initialized
INFO - 2023-12-06 09:47:02 --> Router Class Initialized
INFO - 2023-12-06 09:47:02 --> Output Class Initialized
INFO - 2023-12-06 09:47:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:47:02 --> Input Class Initialized
INFO - 2023-12-06 09:47:02 --> Language Class Initialized
INFO - 2023-12-06 09:47:02 --> Language Class Initialized
INFO - 2023-12-06 09:47:02 --> Config Class Initialized
INFO - 2023-12-06 09:47:02 --> Loader Class Initialized
INFO - 2023-12-06 09:47:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:47:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:47:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:47:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:47:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:47:02 --> Controller Class Initialized
DEBUG - 2023-12-06 09:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:47:02 --> Final output sent to browser
DEBUG - 2023-12-06 09:47:02 --> Total execution time: 0.0754
INFO - 2023-12-06 09:47:06 --> Config Class Initialized
INFO - 2023-12-06 09:47:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:47:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:47:06 --> Utf8 Class Initialized
INFO - 2023-12-06 09:47:06 --> URI Class Initialized
INFO - 2023-12-06 09:47:06 --> Router Class Initialized
INFO - 2023-12-06 09:47:06 --> Output Class Initialized
INFO - 2023-12-06 09:47:06 --> Security Class Initialized
DEBUG - 2023-12-06 09:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:47:06 --> Input Class Initialized
INFO - 2023-12-06 09:47:06 --> Language Class Initialized
INFO - 2023-12-06 09:47:06 --> Language Class Initialized
INFO - 2023-12-06 09:47:06 --> Config Class Initialized
INFO - 2023-12-06 09:47:06 --> Loader Class Initialized
INFO - 2023-12-06 09:47:06 --> Helper loaded: url_helper
INFO - 2023-12-06 09:47:06 --> Helper loaded: file_helper
INFO - 2023-12-06 09:47:06 --> Helper loaded: form_helper
INFO - 2023-12-06 09:47:06 --> Helper loaded: my_helper
INFO - 2023-12-06 09:47:06 --> Database Driver Class Initialized
INFO - 2023-12-06 09:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:47:06 --> Controller Class Initialized
DEBUG - 2023-12-06 09:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-06 09:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:47:06 --> Final output sent to browser
DEBUG - 2023-12-06 09:47:06 --> Total execution time: 0.0772
INFO - 2023-12-06 09:47:07 --> Config Class Initialized
INFO - 2023-12-06 09:47:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:47:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:47:07 --> Utf8 Class Initialized
INFO - 2023-12-06 09:47:07 --> URI Class Initialized
INFO - 2023-12-06 09:47:07 --> Router Class Initialized
INFO - 2023-12-06 09:47:07 --> Output Class Initialized
INFO - 2023-12-06 09:47:07 --> Security Class Initialized
DEBUG - 2023-12-06 09:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:47:07 --> Input Class Initialized
INFO - 2023-12-06 09:47:07 --> Language Class Initialized
INFO - 2023-12-06 09:47:07 --> Language Class Initialized
INFO - 2023-12-06 09:47:07 --> Config Class Initialized
INFO - 2023-12-06 09:47:07 --> Loader Class Initialized
INFO - 2023-12-06 09:47:07 --> Helper loaded: url_helper
INFO - 2023-12-06 09:47:07 --> Helper loaded: file_helper
INFO - 2023-12-06 09:47:07 --> Helper loaded: form_helper
INFO - 2023-12-06 09:47:07 --> Helper loaded: my_helper
INFO - 2023-12-06 09:47:07 --> Database Driver Class Initialized
INFO - 2023-12-06 09:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:47:07 --> Controller Class Initialized
INFO - 2023-12-06 09:47:07 --> Final output sent to browser
DEBUG - 2023-12-06 09:47:07 --> Total execution time: 0.1144
INFO - 2023-12-06 09:48:03 --> Config Class Initialized
INFO - 2023-12-06 09:48:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:48:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:48:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:48:03 --> URI Class Initialized
INFO - 2023-12-06 09:48:03 --> Router Class Initialized
INFO - 2023-12-06 09:48:03 --> Output Class Initialized
INFO - 2023-12-06 09:48:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:48:03 --> Input Class Initialized
INFO - 2023-12-06 09:48:03 --> Language Class Initialized
INFO - 2023-12-06 09:48:03 --> Language Class Initialized
INFO - 2023-12-06 09:48:03 --> Config Class Initialized
INFO - 2023-12-06 09:48:03 --> Loader Class Initialized
INFO - 2023-12-06 09:48:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:48:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:48:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:48:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:48:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:48:03 --> Controller Class Initialized
INFO - 2023-12-06 09:48:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:48:03 --> Total execution time: 0.0709
INFO - 2023-12-06 09:48:07 --> Config Class Initialized
INFO - 2023-12-06 09:48:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:48:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:48:07 --> Utf8 Class Initialized
INFO - 2023-12-06 09:48:07 --> URI Class Initialized
INFO - 2023-12-06 09:48:07 --> Router Class Initialized
INFO - 2023-12-06 09:48:07 --> Output Class Initialized
INFO - 2023-12-06 09:48:07 --> Security Class Initialized
DEBUG - 2023-12-06 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:48:07 --> Input Class Initialized
INFO - 2023-12-06 09:48:07 --> Language Class Initialized
INFO - 2023-12-06 09:48:07 --> Language Class Initialized
INFO - 2023-12-06 09:48:07 --> Config Class Initialized
INFO - 2023-12-06 09:48:07 --> Loader Class Initialized
INFO - 2023-12-06 09:48:07 --> Helper loaded: url_helper
INFO - 2023-12-06 09:48:07 --> Helper loaded: file_helper
INFO - 2023-12-06 09:48:07 --> Helper loaded: form_helper
INFO - 2023-12-06 09:48:07 --> Helper loaded: my_helper
INFO - 2023-12-06 09:48:07 --> Database Driver Class Initialized
INFO - 2023-12-06 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:48:07 --> Controller Class Initialized
DEBUG - 2023-12-06 09:48:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 09:48:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:48:07 --> Final output sent to browser
DEBUG - 2023-12-06 09:48:07 --> Total execution time: 0.0647
INFO - 2023-12-06 09:48:16 --> Config Class Initialized
INFO - 2023-12-06 09:48:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:48:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:48:16 --> Utf8 Class Initialized
INFO - 2023-12-06 09:48:16 --> URI Class Initialized
INFO - 2023-12-06 09:48:16 --> Router Class Initialized
INFO - 2023-12-06 09:48:16 --> Output Class Initialized
INFO - 2023-12-06 09:48:16 --> Security Class Initialized
DEBUG - 2023-12-06 09:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:48:16 --> Input Class Initialized
INFO - 2023-12-06 09:48:16 --> Language Class Initialized
INFO - 2023-12-06 09:48:16 --> Language Class Initialized
INFO - 2023-12-06 09:48:16 --> Config Class Initialized
INFO - 2023-12-06 09:48:16 --> Loader Class Initialized
INFO - 2023-12-06 09:48:16 --> Helper loaded: url_helper
INFO - 2023-12-06 09:48:16 --> Helper loaded: file_helper
INFO - 2023-12-06 09:48:16 --> Helper loaded: form_helper
INFO - 2023-12-06 09:48:16 --> Helper loaded: my_helper
INFO - 2023-12-06 09:48:16 --> Database Driver Class Initialized
INFO - 2023-12-06 09:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:48:16 --> Controller Class Initialized
DEBUG - 2023-12-06 09:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 09:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:48:16 --> Final output sent to browser
DEBUG - 2023-12-06 09:48:16 --> Total execution time: 0.0571
INFO - 2023-12-06 09:48:18 --> Config Class Initialized
INFO - 2023-12-06 09:48:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:48:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:48:18 --> Utf8 Class Initialized
INFO - 2023-12-06 09:48:18 --> URI Class Initialized
INFO - 2023-12-06 09:48:18 --> Router Class Initialized
INFO - 2023-12-06 09:48:18 --> Output Class Initialized
INFO - 2023-12-06 09:48:18 --> Security Class Initialized
DEBUG - 2023-12-06 09:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:48:18 --> Input Class Initialized
INFO - 2023-12-06 09:48:18 --> Language Class Initialized
INFO - 2023-12-06 09:48:18 --> Language Class Initialized
INFO - 2023-12-06 09:48:18 --> Config Class Initialized
INFO - 2023-12-06 09:48:18 --> Loader Class Initialized
INFO - 2023-12-06 09:48:18 --> Helper loaded: url_helper
INFO - 2023-12-06 09:48:18 --> Helper loaded: file_helper
INFO - 2023-12-06 09:48:18 --> Helper loaded: form_helper
INFO - 2023-12-06 09:48:18 --> Helper loaded: my_helper
INFO - 2023-12-06 09:48:18 --> Database Driver Class Initialized
INFO - 2023-12-06 09:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:48:18 --> Controller Class Initialized
DEBUG - 2023-12-06 09:48:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 09:48:23 --> Final output sent to browser
DEBUG - 2023-12-06 09:48:23 --> Total execution time: 5.3672
INFO - 2023-12-06 09:49:00 --> Config Class Initialized
INFO - 2023-12-06 09:49:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:00 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:00 --> URI Class Initialized
INFO - 2023-12-06 09:49:00 --> Router Class Initialized
INFO - 2023-12-06 09:49:00 --> Output Class Initialized
INFO - 2023-12-06 09:49:00 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:00 --> Input Class Initialized
INFO - 2023-12-06 09:49:00 --> Language Class Initialized
INFO - 2023-12-06 09:49:00 --> Language Class Initialized
INFO - 2023-12-06 09:49:00 --> Config Class Initialized
INFO - 2023-12-06 09:49:00 --> Loader Class Initialized
INFO - 2023-12-06 09:49:00 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:00 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:00 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:00 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:00 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:00 --> Controller Class Initialized
INFO - 2023-12-06 09:49:01 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:49:01 --> Config Class Initialized
INFO - 2023-12-06 09:49:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:01 --> URI Class Initialized
INFO - 2023-12-06 09:49:01 --> Router Class Initialized
INFO - 2023-12-06 09:49:01 --> Output Class Initialized
INFO - 2023-12-06 09:49:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:01 --> Input Class Initialized
INFO - 2023-12-06 09:49:01 --> Language Class Initialized
INFO - 2023-12-06 09:49:01 --> Language Class Initialized
INFO - 2023-12-06 09:49:01 --> Config Class Initialized
INFO - 2023-12-06 09:49:01 --> Loader Class Initialized
INFO - 2023-12-06 09:49:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:01 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:01 --> Controller Class Initialized
INFO - 2023-12-06 09:49:01 --> Config Class Initialized
INFO - 2023-12-06 09:49:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:01 --> URI Class Initialized
INFO - 2023-12-06 09:49:01 --> Router Class Initialized
INFO - 2023-12-06 09:49:01 --> Output Class Initialized
INFO - 2023-12-06 09:49:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:01 --> Input Class Initialized
INFO - 2023-12-06 09:49:01 --> Language Class Initialized
INFO - 2023-12-06 09:49:01 --> Language Class Initialized
INFO - 2023-12-06 09:49:01 --> Config Class Initialized
INFO - 2023-12-06 09:49:01 --> Loader Class Initialized
INFO - 2023-12-06 09:49:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:01 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:01 --> Controller Class Initialized
DEBUG - 2023-12-06 09:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:49:01 --> Final output sent to browser
DEBUG - 2023-12-06 09:49:01 --> Total execution time: 0.0787
INFO - 2023-12-06 09:49:37 --> Config Class Initialized
INFO - 2023-12-06 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:37 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:37 --> URI Class Initialized
INFO - 2023-12-06 09:49:37 --> Router Class Initialized
INFO - 2023-12-06 09:49:37 --> Output Class Initialized
INFO - 2023-12-06 09:49:37 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:37 --> Input Class Initialized
INFO - 2023-12-06 09:49:37 --> Language Class Initialized
INFO - 2023-12-06 09:49:37 --> Language Class Initialized
INFO - 2023-12-06 09:49:37 --> Config Class Initialized
INFO - 2023-12-06 09:49:37 --> Loader Class Initialized
INFO - 2023-12-06 09:49:37 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:37 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:37 --> Controller Class Initialized
INFO - 2023-12-06 09:49:37 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:49:37 --> Final output sent to browser
DEBUG - 2023-12-06 09:49:37 --> Total execution time: 0.1633
INFO - 2023-12-06 09:49:37 --> Config Class Initialized
INFO - 2023-12-06 09:49:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:37 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:37 --> URI Class Initialized
INFO - 2023-12-06 09:49:37 --> Router Class Initialized
INFO - 2023-12-06 09:49:37 --> Output Class Initialized
INFO - 2023-12-06 09:49:37 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:37 --> Input Class Initialized
INFO - 2023-12-06 09:49:37 --> Language Class Initialized
INFO - 2023-12-06 09:49:37 --> Language Class Initialized
INFO - 2023-12-06 09:49:37 --> Config Class Initialized
INFO - 2023-12-06 09:49:37 --> Loader Class Initialized
INFO - 2023-12-06 09:49:37 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:37 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:37 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:37 --> Controller Class Initialized
DEBUG - 2023-12-06 09:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:49:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:49:37 --> Final output sent to browser
DEBUG - 2023-12-06 09:49:37 --> Total execution time: 0.1006
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:42 --> URI Class Initialized
INFO - 2023-12-06 09:49:42 --> Router Class Initialized
INFO - 2023-12-06 09:49:42 --> Output Class Initialized
INFO - 2023-12-06 09:49:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:42 --> Input Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Loader Class Initialized
INFO - 2023-12-06 09:49:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:42 --> Controller Class Initialized
INFO - 2023-12-06 09:49:42 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:42 --> URI Class Initialized
INFO - 2023-12-06 09:49:42 --> Router Class Initialized
INFO - 2023-12-06 09:49:42 --> Output Class Initialized
INFO - 2023-12-06 09:49:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:42 --> Input Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Loader Class Initialized
INFO - 2023-12-06 09:49:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:42 --> Controller Class Initialized
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:49:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:49:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:49:42 --> URI Class Initialized
INFO - 2023-12-06 09:49:42 --> Router Class Initialized
INFO - 2023-12-06 09:49:42 --> Output Class Initialized
INFO - 2023-12-06 09:49:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:49:42 --> Input Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Language Class Initialized
INFO - 2023-12-06 09:49:42 --> Config Class Initialized
INFO - 2023-12-06 09:49:42 --> Loader Class Initialized
INFO - 2023-12-06 09:49:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:49:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:49:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:49:42 --> Controller Class Initialized
DEBUG - 2023-12-06 09:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:49:42 --> Final output sent to browser
DEBUG - 2023-12-06 09:49:42 --> Total execution time: 0.0819
INFO - 2023-12-06 09:50:25 --> Config Class Initialized
INFO - 2023-12-06 09:50:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:25 --> URI Class Initialized
INFO - 2023-12-06 09:50:25 --> Router Class Initialized
INFO - 2023-12-06 09:50:25 --> Output Class Initialized
INFO - 2023-12-06 09:50:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:25 --> Input Class Initialized
INFO - 2023-12-06 09:50:25 --> Language Class Initialized
INFO - 2023-12-06 09:50:25 --> Language Class Initialized
INFO - 2023-12-06 09:50:25 --> Config Class Initialized
INFO - 2023-12-06 09:50:25 --> Loader Class Initialized
INFO - 2023-12-06 09:50:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:25 --> Controller Class Initialized
INFO - 2023-12-06 09:50:25 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:50:25 --> Final output sent to browser
DEBUG - 2023-12-06 09:50:25 --> Total execution time: 0.0546
INFO - 2023-12-06 09:50:25 --> Config Class Initialized
INFO - 2023-12-06 09:50:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:25 --> URI Class Initialized
INFO - 2023-12-06 09:50:25 --> Router Class Initialized
INFO - 2023-12-06 09:50:25 --> Output Class Initialized
INFO - 2023-12-06 09:50:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:25 --> Input Class Initialized
INFO - 2023-12-06 09:50:25 --> Language Class Initialized
INFO - 2023-12-06 09:50:25 --> Language Class Initialized
INFO - 2023-12-06 09:50:25 --> Config Class Initialized
INFO - 2023-12-06 09:50:25 --> Loader Class Initialized
INFO - 2023-12-06 09:50:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:25 --> Controller Class Initialized
DEBUG - 2023-12-06 09:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 09:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:50:25 --> Final output sent to browser
DEBUG - 2023-12-06 09:50:25 --> Total execution time: 0.0477
INFO - 2023-12-06 09:50:31 --> Config Class Initialized
INFO - 2023-12-06 09:50:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:31 --> URI Class Initialized
INFO - 2023-12-06 09:50:31 --> Router Class Initialized
INFO - 2023-12-06 09:50:31 --> Output Class Initialized
INFO - 2023-12-06 09:50:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:31 --> Input Class Initialized
INFO - 2023-12-06 09:50:31 --> Language Class Initialized
INFO - 2023-12-06 09:50:31 --> Language Class Initialized
INFO - 2023-12-06 09:50:31 --> Config Class Initialized
INFO - 2023-12-06 09:50:31 --> Loader Class Initialized
INFO - 2023-12-06 09:50:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:31 --> Controller Class Initialized
DEBUG - 2023-12-06 09:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:50:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:50:31 --> Final output sent to browser
DEBUG - 2023-12-06 09:50:31 --> Total execution time: 0.0463
INFO - 2023-12-06 09:50:31 --> Config Class Initialized
INFO - 2023-12-06 09:50:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:31 --> URI Class Initialized
INFO - 2023-12-06 09:50:31 --> Router Class Initialized
INFO - 2023-12-06 09:50:31 --> Output Class Initialized
INFO - 2023-12-06 09:50:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:31 --> Input Class Initialized
INFO - 2023-12-06 09:50:31 --> Language Class Initialized
ERROR - 2023-12-06 09:50:31 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:50:31 --> Config Class Initialized
INFO - 2023-12-06 09:50:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:31 --> URI Class Initialized
INFO - 2023-12-06 09:50:31 --> Router Class Initialized
INFO - 2023-12-06 09:50:31 --> Output Class Initialized
INFO - 2023-12-06 09:50:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:31 --> Input Class Initialized
INFO - 2023-12-06 09:50:31 --> Language Class Initialized
INFO - 2023-12-06 09:50:31 --> Language Class Initialized
INFO - 2023-12-06 09:50:31 --> Config Class Initialized
INFO - 2023-12-06 09:50:31 --> Loader Class Initialized
INFO - 2023-12-06 09:50:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:31 --> Controller Class Initialized
INFO - 2023-12-06 09:50:37 --> Config Class Initialized
INFO - 2023-12-06 09:50:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:37 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:37 --> URI Class Initialized
INFO - 2023-12-06 09:50:37 --> Router Class Initialized
INFO - 2023-12-06 09:50:37 --> Output Class Initialized
INFO - 2023-12-06 09:50:37 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:37 --> Input Class Initialized
INFO - 2023-12-06 09:50:37 --> Language Class Initialized
INFO - 2023-12-06 09:50:38 --> Language Class Initialized
INFO - 2023-12-06 09:50:38 --> Config Class Initialized
INFO - 2023-12-06 09:50:38 --> Loader Class Initialized
INFO - 2023-12-06 09:50:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:38 --> Controller Class Initialized
INFO - 2023-12-06 09:50:38 --> Final output sent to browser
DEBUG - 2023-12-06 09:50:38 --> Total execution time: 0.0394
INFO - 2023-12-06 09:50:43 --> Config Class Initialized
INFO - 2023-12-06 09:50:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:43 --> URI Class Initialized
INFO - 2023-12-06 09:50:43 --> Router Class Initialized
INFO - 2023-12-06 09:50:43 --> Output Class Initialized
INFO - 2023-12-06 09:50:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:43 --> Input Class Initialized
INFO - 2023-12-06 09:50:43 --> Language Class Initialized
INFO - 2023-12-06 09:50:43 --> Language Class Initialized
INFO - 2023-12-06 09:50:43 --> Config Class Initialized
INFO - 2023-12-06 09:50:43 --> Loader Class Initialized
INFO - 2023-12-06 09:50:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:43 --> Controller Class Initialized
INFO - 2023-12-06 09:50:43 --> Final output sent to browser
DEBUG - 2023-12-06 09:50:43 --> Total execution time: 0.0352
INFO - 2023-12-06 09:50:43 --> Config Class Initialized
INFO - 2023-12-06 09:50:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:43 --> URI Class Initialized
INFO - 2023-12-06 09:50:43 --> Router Class Initialized
INFO - 2023-12-06 09:50:43 --> Output Class Initialized
INFO - 2023-12-06 09:50:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:43 --> Input Class Initialized
INFO - 2023-12-06 09:50:43 --> Language Class Initialized
ERROR - 2023-12-06 09:50:43 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:50:43 --> Config Class Initialized
INFO - 2023-12-06 09:50:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:50:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:50:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:50:43 --> URI Class Initialized
INFO - 2023-12-06 09:50:43 --> Router Class Initialized
INFO - 2023-12-06 09:50:43 --> Output Class Initialized
INFO - 2023-12-06 09:50:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:50:43 --> Input Class Initialized
INFO - 2023-12-06 09:50:43 --> Language Class Initialized
INFO - 2023-12-06 09:50:43 --> Language Class Initialized
INFO - 2023-12-06 09:50:43 --> Config Class Initialized
INFO - 2023-12-06 09:50:43 --> Loader Class Initialized
INFO - 2023-12-06 09:50:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:50:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:50:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:50:43 --> Controller Class Initialized
INFO - 2023-12-06 09:51:03 --> Config Class Initialized
INFO - 2023-12-06 09:51:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:03 --> URI Class Initialized
INFO - 2023-12-06 09:51:03 --> Router Class Initialized
INFO - 2023-12-06 09:51:03 --> Output Class Initialized
INFO - 2023-12-06 09:51:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:03 --> Input Class Initialized
INFO - 2023-12-06 09:51:03 --> Language Class Initialized
INFO - 2023-12-06 09:51:03 --> Language Class Initialized
INFO - 2023-12-06 09:51:03 --> Config Class Initialized
INFO - 2023-12-06 09:51:03 --> Loader Class Initialized
INFO - 2023-12-06 09:51:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:03 --> Controller Class Initialized
DEBUG - 2023-12-06 09:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:51:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:03 --> Total execution time: 0.0521
INFO - 2023-12-06 09:51:10 --> Config Class Initialized
INFO - 2023-12-06 09:51:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:10 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:10 --> URI Class Initialized
INFO - 2023-12-06 09:51:10 --> Router Class Initialized
INFO - 2023-12-06 09:51:10 --> Output Class Initialized
INFO - 2023-12-06 09:51:10 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:10 --> Input Class Initialized
INFO - 2023-12-06 09:51:10 --> Language Class Initialized
INFO - 2023-12-06 09:51:10 --> Language Class Initialized
INFO - 2023-12-06 09:51:10 --> Config Class Initialized
INFO - 2023-12-06 09:51:10 --> Loader Class Initialized
INFO - 2023-12-06 09:51:10 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:10 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:10 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:10 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:10 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:10 --> Controller Class Initialized
DEBUG - 2023-12-06 09:51:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-06 09:51:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:51:10 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:10 --> Total execution time: 0.0398
INFO - 2023-12-06 09:51:20 --> Config Class Initialized
INFO - 2023-12-06 09:51:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:20 --> URI Class Initialized
INFO - 2023-12-06 09:51:20 --> Router Class Initialized
INFO - 2023-12-06 09:51:20 --> Output Class Initialized
INFO - 2023-12-06 09:51:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:20 --> Input Class Initialized
INFO - 2023-12-06 09:51:20 --> Language Class Initialized
INFO - 2023-12-06 09:51:20 --> Language Class Initialized
INFO - 2023-12-06 09:51:20 --> Config Class Initialized
INFO - 2023-12-06 09:51:20 --> Loader Class Initialized
INFO - 2023-12-06 09:51:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:20 --> Controller Class Initialized
DEBUG - 2023-12-06 09:51:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:51:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:51:20 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:20 --> Total execution time: 0.0408
INFO - 2023-12-06 09:51:20 --> Config Class Initialized
INFO - 2023-12-06 09:51:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:20 --> URI Class Initialized
INFO - 2023-12-06 09:51:20 --> Router Class Initialized
INFO - 2023-12-06 09:51:20 --> Output Class Initialized
INFO - 2023-12-06 09:51:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:20 --> Input Class Initialized
INFO - 2023-12-06 09:51:20 --> Language Class Initialized
ERROR - 2023-12-06 09:51:20 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:51:20 --> Config Class Initialized
INFO - 2023-12-06 09:51:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:20 --> URI Class Initialized
INFO - 2023-12-06 09:51:20 --> Router Class Initialized
INFO - 2023-12-06 09:51:20 --> Output Class Initialized
INFO - 2023-12-06 09:51:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:20 --> Input Class Initialized
INFO - 2023-12-06 09:51:20 --> Language Class Initialized
INFO - 2023-12-06 09:51:20 --> Language Class Initialized
INFO - 2023-12-06 09:51:20 --> Config Class Initialized
INFO - 2023-12-06 09:51:20 --> Loader Class Initialized
INFO - 2023-12-06 09:51:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:20 --> Controller Class Initialized
INFO - 2023-12-06 09:51:35 --> Config Class Initialized
INFO - 2023-12-06 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:35 --> URI Class Initialized
INFO - 2023-12-06 09:51:35 --> Router Class Initialized
INFO - 2023-12-06 09:51:35 --> Output Class Initialized
INFO - 2023-12-06 09:51:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:35 --> Input Class Initialized
INFO - 2023-12-06 09:51:35 --> Language Class Initialized
INFO - 2023-12-06 09:51:35 --> Language Class Initialized
INFO - 2023-12-06 09:51:35 --> Config Class Initialized
INFO - 2023-12-06 09:51:35 --> Loader Class Initialized
INFO - 2023-12-06 09:51:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:35 --> Controller Class Initialized
DEBUG - 2023-12-06 09:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:51:35 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:35 --> Total execution time: 0.0404
INFO - 2023-12-06 09:51:35 --> Config Class Initialized
INFO - 2023-12-06 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:35 --> URI Class Initialized
INFO - 2023-12-06 09:51:35 --> Router Class Initialized
INFO - 2023-12-06 09:51:35 --> Output Class Initialized
INFO - 2023-12-06 09:51:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:35 --> Input Class Initialized
INFO - 2023-12-06 09:51:35 --> Language Class Initialized
ERROR - 2023-12-06 09:51:35 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:51:35 --> Config Class Initialized
INFO - 2023-12-06 09:51:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:35 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:35 --> URI Class Initialized
INFO - 2023-12-06 09:51:35 --> Router Class Initialized
INFO - 2023-12-06 09:51:35 --> Output Class Initialized
INFO - 2023-12-06 09:51:35 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:35 --> Input Class Initialized
INFO - 2023-12-06 09:51:35 --> Language Class Initialized
INFO - 2023-12-06 09:51:35 --> Language Class Initialized
INFO - 2023-12-06 09:51:35 --> Config Class Initialized
INFO - 2023-12-06 09:51:35 --> Loader Class Initialized
INFO - 2023-12-06 09:51:35 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:35 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:35 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:35 --> Controller Class Initialized
INFO - 2023-12-06 09:51:37 --> Config Class Initialized
INFO - 2023-12-06 09:51:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:37 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:37 --> URI Class Initialized
INFO - 2023-12-06 09:51:37 --> Router Class Initialized
INFO - 2023-12-06 09:51:37 --> Output Class Initialized
INFO - 2023-12-06 09:51:37 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:37 --> Input Class Initialized
INFO - 2023-12-06 09:51:37 --> Language Class Initialized
INFO - 2023-12-06 09:51:37 --> Language Class Initialized
INFO - 2023-12-06 09:51:37 --> Config Class Initialized
INFO - 2023-12-06 09:51:37 --> Loader Class Initialized
INFO - 2023-12-06 09:51:37 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:37 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:37 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:37 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:37 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:37 --> Controller Class Initialized
INFO - 2023-12-06 09:51:37 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:37 --> Total execution time: 0.0456
INFO - 2023-12-06 09:51:57 --> Config Class Initialized
INFO - 2023-12-06 09:51:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:57 --> URI Class Initialized
INFO - 2023-12-06 09:51:57 --> Router Class Initialized
INFO - 2023-12-06 09:51:57 --> Output Class Initialized
INFO - 2023-12-06 09:51:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:57 --> Input Class Initialized
INFO - 2023-12-06 09:51:57 --> Language Class Initialized
INFO - 2023-12-06 09:51:57 --> Language Class Initialized
INFO - 2023-12-06 09:51:57 --> Config Class Initialized
INFO - 2023-12-06 09:51:57 --> Loader Class Initialized
INFO - 2023-12-06 09:51:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:57 --> Controller Class Initialized
INFO - 2023-12-06 09:51:57 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:57 --> Total execution time: 0.0363
INFO - 2023-12-06 09:51:57 --> Config Class Initialized
INFO - 2023-12-06 09:51:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:57 --> URI Class Initialized
INFO - 2023-12-06 09:51:57 --> Router Class Initialized
INFO - 2023-12-06 09:51:57 --> Output Class Initialized
INFO - 2023-12-06 09:51:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:57 --> Input Class Initialized
INFO - 2023-12-06 09:51:57 --> Language Class Initialized
ERROR - 2023-12-06 09:51:57 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:51:57 --> Config Class Initialized
INFO - 2023-12-06 09:51:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:57 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:57 --> URI Class Initialized
INFO - 2023-12-06 09:51:57 --> Router Class Initialized
INFO - 2023-12-06 09:51:57 --> Output Class Initialized
INFO - 2023-12-06 09:51:57 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:57 --> Input Class Initialized
INFO - 2023-12-06 09:51:57 --> Language Class Initialized
INFO - 2023-12-06 09:51:57 --> Language Class Initialized
INFO - 2023-12-06 09:51:57 --> Config Class Initialized
INFO - 2023-12-06 09:51:57 --> Loader Class Initialized
INFO - 2023-12-06 09:51:57 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:57 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:57 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:57 --> Controller Class Initialized
INFO - 2023-12-06 09:51:59 --> Config Class Initialized
INFO - 2023-12-06 09:51:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:51:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:51:59 --> Utf8 Class Initialized
INFO - 2023-12-06 09:51:59 --> URI Class Initialized
INFO - 2023-12-06 09:51:59 --> Router Class Initialized
INFO - 2023-12-06 09:51:59 --> Output Class Initialized
INFO - 2023-12-06 09:51:59 --> Security Class Initialized
DEBUG - 2023-12-06 09:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:51:59 --> Input Class Initialized
INFO - 2023-12-06 09:51:59 --> Language Class Initialized
INFO - 2023-12-06 09:51:59 --> Language Class Initialized
INFO - 2023-12-06 09:51:59 --> Config Class Initialized
INFO - 2023-12-06 09:51:59 --> Loader Class Initialized
INFO - 2023-12-06 09:51:59 --> Helper loaded: url_helper
INFO - 2023-12-06 09:51:59 --> Helper loaded: file_helper
INFO - 2023-12-06 09:51:59 --> Helper loaded: form_helper
INFO - 2023-12-06 09:51:59 --> Helper loaded: my_helper
INFO - 2023-12-06 09:51:59 --> Database Driver Class Initialized
INFO - 2023-12-06 09:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:51:59 --> Controller Class Initialized
INFO - 2023-12-06 09:51:59 --> Final output sent to browser
DEBUG - 2023-12-06 09:51:59 --> Total execution time: 0.0581
INFO - 2023-12-06 09:52:03 --> Config Class Initialized
INFO - 2023-12-06 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:03 --> URI Class Initialized
INFO - 2023-12-06 09:52:03 --> Router Class Initialized
INFO - 2023-12-06 09:52:03 --> Output Class Initialized
INFO - 2023-12-06 09:52:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:03 --> Input Class Initialized
INFO - 2023-12-06 09:52:03 --> Language Class Initialized
INFO - 2023-12-06 09:52:03 --> Language Class Initialized
INFO - 2023-12-06 09:52:03 --> Config Class Initialized
INFO - 2023-12-06 09:52:03 --> Loader Class Initialized
INFO - 2023-12-06 09:52:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:03 --> Controller Class Initialized
INFO - 2023-12-06 09:52:03 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:03 --> Total execution time: 0.0423
INFO - 2023-12-06 09:52:03 --> Config Class Initialized
INFO - 2023-12-06 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:03 --> URI Class Initialized
INFO - 2023-12-06 09:52:03 --> Router Class Initialized
INFO - 2023-12-06 09:52:03 --> Output Class Initialized
INFO - 2023-12-06 09:52:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:03 --> Input Class Initialized
INFO - 2023-12-06 09:52:03 --> Language Class Initialized
ERROR - 2023-12-06 09:52:03 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:52:03 --> Config Class Initialized
INFO - 2023-12-06 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:03 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:03 --> URI Class Initialized
INFO - 2023-12-06 09:52:03 --> Router Class Initialized
INFO - 2023-12-06 09:52:03 --> Output Class Initialized
INFO - 2023-12-06 09:52:03 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:03 --> Input Class Initialized
INFO - 2023-12-06 09:52:03 --> Language Class Initialized
INFO - 2023-12-06 09:52:03 --> Language Class Initialized
INFO - 2023-12-06 09:52:03 --> Config Class Initialized
INFO - 2023-12-06 09:52:03 --> Loader Class Initialized
INFO - 2023-12-06 09:52:03 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:03 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:03 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:03 --> Controller Class Initialized
INFO - 2023-12-06 09:52:05 --> Config Class Initialized
INFO - 2023-12-06 09:52:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:05 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:05 --> URI Class Initialized
INFO - 2023-12-06 09:52:05 --> Router Class Initialized
INFO - 2023-12-06 09:52:05 --> Output Class Initialized
INFO - 2023-12-06 09:52:05 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:05 --> Input Class Initialized
INFO - 2023-12-06 09:52:05 --> Language Class Initialized
INFO - 2023-12-06 09:52:05 --> Language Class Initialized
INFO - 2023-12-06 09:52:05 --> Config Class Initialized
INFO - 2023-12-06 09:52:05 --> Loader Class Initialized
INFO - 2023-12-06 09:52:05 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:05 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:05 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:05 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:05 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:05 --> Controller Class Initialized
INFO - 2023-12-06 09:52:05 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:05 --> Total execution time: 0.0334
INFO - 2023-12-06 09:52:09 --> Config Class Initialized
INFO - 2023-12-06 09:52:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:09 --> URI Class Initialized
INFO - 2023-12-06 09:52:09 --> Router Class Initialized
INFO - 2023-12-06 09:52:09 --> Output Class Initialized
INFO - 2023-12-06 09:52:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:09 --> Input Class Initialized
INFO - 2023-12-06 09:52:09 --> Language Class Initialized
INFO - 2023-12-06 09:52:09 --> Language Class Initialized
INFO - 2023-12-06 09:52:09 --> Config Class Initialized
INFO - 2023-12-06 09:52:09 --> Loader Class Initialized
INFO - 2023-12-06 09:52:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:09 --> Controller Class Initialized
INFO - 2023-12-06 09:52:09 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:09 --> Total execution time: 0.0387
INFO - 2023-12-06 09:52:09 --> Config Class Initialized
INFO - 2023-12-06 09:52:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:09 --> URI Class Initialized
INFO - 2023-12-06 09:52:09 --> Router Class Initialized
INFO - 2023-12-06 09:52:09 --> Output Class Initialized
INFO - 2023-12-06 09:52:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:09 --> Input Class Initialized
INFO - 2023-12-06 09:52:09 --> Language Class Initialized
ERROR - 2023-12-06 09:52:09 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:52:09 --> Config Class Initialized
INFO - 2023-12-06 09:52:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:09 --> URI Class Initialized
INFO - 2023-12-06 09:52:09 --> Router Class Initialized
INFO - 2023-12-06 09:52:09 --> Output Class Initialized
INFO - 2023-12-06 09:52:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:09 --> Input Class Initialized
INFO - 2023-12-06 09:52:09 --> Language Class Initialized
INFO - 2023-12-06 09:52:09 --> Language Class Initialized
INFO - 2023-12-06 09:52:09 --> Config Class Initialized
INFO - 2023-12-06 09:52:09 --> Loader Class Initialized
INFO - 2023-12-06 09:52:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:09 --> Controller Class Initialized
INFO - 2023-12-06 09:52:11 --> Config Class Initialized
INFO - 2023-12-06 09:52:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:11 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:11 --> URI Class Initialized
INFO - 2023-12-06 09:52:11 --> Router Class Initialized
INFO - 2023-12-06 09:52:11 --> Output Class Initialized
INFO - 2023-12-06 09:52:11 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:11 --> Input Class Initialized
INFO - 2023-12-06 09:52:11 --> Language Class Initialized
INFO - 2023-12-06 09:52:11 --> Language Class Initialized
INFO - 2023-12-06 09:52:11 --> Config Class Initialized
INFO - 2023-12-06 09:52:11 --> Loader Class Initialized
INFO - 2023-12-06 09:52:11 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:11 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:11 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:11 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:11 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:11 --> Controller Class Initialized
INFO - 2023-12-06 09:52:11 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:11 --> Total execution time: 0.0511
INFO - 2023-12-06 09:52:15 --> Config Class Initialized
INFO - 2023-12-06 09:52:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:15 --> URI Class Initialized
INFO - 2023-12-06 09:52:15 --> Router Class Initialized
INFO - 2023-12-06 09:52:15 --> Output Class Initialized
INFO - 2023-12-06 09:52:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:15 --> Input Class Initialized
INFO - 2023-12-06 09:52:15 --> Language Class Initialized
INFO - 2023-12-06 09:52:15 --> Language Class Initialized
INFO - 2023-12-06 09:52:15 --> Config Class Initialized
INFO - 2023-12-06 09:52:15 --> Loader Class Initialized
INFO - 2023-12-06 09:52:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:15 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:15 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:15 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:15 --> Controller Class Initialized
INFO - 2023-12-06 09:52:15 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:15 --> Total execution time: 0.0707
INFO - 2023-12-06 09:52:15 --> Config Class Initialized
INFO - 2023-12-06 09:52:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:15 --> URI Class Initialized
INFO - 2023-12-06 09:52:15 --> Router Class Initialized
INFO - 2023-12-06 09:52:15 --> Output Class Initialized
INFO - 2023-12-06 09:52:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:15 --> Input Class Initialized
INFO - 2023-12-06 09:52:15 --> Language Class Initialized
ERROR - 2023-12-06 09:52:15 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:52:15 --> Config Class Initialized
INFO - 2023-12-06 09:52:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:15 --> URI Class Initialized
INFO - 2023-12-06 09:52:15 --> Router Class Initialized
INFO - 2023-12-06 09:52:15 --> Output Class Initialized
INFO - 2023-12-06 09:52:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:15 --> Input Class Initialized
INFO - 2023-12-06 09:52:15 --> Language Class Initialized
INFO - 2023-12-06 09:52:15 --> Language Class Initialized
INFO - 2023-12-06 09:52:15 --> Config Class Initialized
INFO - 2023-12-06 09:52:15 --> Loader Class Initialized
INFO - 2023-12-06 09:52:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:16 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:16 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:16 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:16 --> Controller Class Initialized
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:20 --> URI Class Initialized
INFO - 2023-12-06 09:52:20 --> Router Class Initialized
INFO - 2023-12-06 09:52:20 --> Output Class Initialized
INFO - 2023-12-06 09:52:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:20 --> Input Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Loader Class Initialized
INFO - 2023-12-06 09:52:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:20 --> Controller Class Initialized
INFO - 2023-12-06 09:52:20 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:20 --> URI Class Initialized
INFO - 2023-12-06 09:52:20 --> Router Class Initialized
INFO - 2023-12-06 09:52:20 --> Output Class Initialized
INFO - 2023-12-06 09:52:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:20 --> Input Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Loader Class Initialized
INFO - 2023-12-06 09:52:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:20 --> Controller Class Initialized
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:20 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:20 --> URI Class Initialized
INFO - 2023-12-06 09:52:20 --> Router Class Initialized
INFO - 2023-12-06 09:52:20 --> Output Class Initialized
INFO - 2023-12-06 09:52:20 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:20 --> Input Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Language Class Initialized
INFO - 2023-12-06 09:52:20 --> Config Class Initialized
INFO - 2023-12-06 09:52:20 --> Loader Class Initialized
INFO - 2023-12-06 09:52:20 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:20 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:20 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:20 --> Controller Class Initialized
DEBUG - 2023-12-06 09:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:52:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:52:20 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:20 --> Total execution time: 0.0325
INFO - 2023-12-06 09:52:32 --> Config Class Initialized
INFO - 2023-12-06 09:52:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:32 --> URI Class Initialized
INFO - 2023-12-06 09:52:32 --> Router Class Initialized
INFO - 2023-12-06 09:52:32 --> Output Class Initialized
INFO - 2023-12-06 09:52:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:32 --> Input Class Initialized
INFO - 2023-12-06 09:52:32 --> Language Class Initialized
INFO - 2023-12-06 09:52:32 --> Language Class Initialized
INFO - 2023-12-06 09:52:32 --> Config Class Initialized
INFO - 2023-12-06 09:52:32 --> Loader Class Initialized
INFO - 2023-12-06 09:52:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:32 --> Controller Class Initialized
INFO - 2023-12-06 09:52:32 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:52:32 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:32 --> Total execution time: 0.0344
INFO - 2023-12-06 09:52:32 --> Config Class Initialized
INFO - 2023-12-06 09:52:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:32 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:32 --> URI Class Initialized
INFO - 2023-12-06 09:52:32 --> Router Class Initialized
INFO - 2023-12-06 09:52:32 --> Output Class Initialized
INFO - 2023-12-06 09:52:32 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:32 --> Input Class Initialized
INFO - 2023-12-06 09:52:32 --> Language Class Initialized
INFO - 2023-12-06 09:52:32 --> Language Class Initialized
INFO - 2023-12-06 09:52:32 --> Config Class Initialized
INFO - 2023-12-06 09:52:32 --> Loader Class Initialized
INFO - 2023-12-06 09:52:32 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:32 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:32 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:32 --> Controller Class Initialized
DEBUG - 2023-12-06 09:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:52:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:52:32 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:32 --> Total execution time: 0.0426
INFO - 2023-12-06 09:52:49 --> Config Class Initialized
INFO - 2023-12-06 09:52:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:49 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:49 --> URI Class Initialized
INFO - 2023-12-06 09:52:49 --> Router Class Initialized
INFO - 2023-12-06 09:52:49 --> Output Class Initialized
INFO - 2023-12-06 09:52:49 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:49 --> Input Class Initialized
INFO - 2023-12-06 09:52:49 --> Language Class Initialized
INFO - 2023-12-06 09:52:49 --> Language Class Initialized
INFO - 2023-12-06 09:52:49 --> Config Class Initialized
INFO - 2023-12-06 09:52:49 --> Loader Class Initialized
INFO - 2023-12-06 09:52:49 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:49 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:49 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:49 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:49 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:49 --> Controller Class Initialized
DEBUG - 2023-12-06 09:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 09:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:52:49 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:49 --> Total execution time: 0.0468
INFO - 2023-12-06 09:52:51 --> Config Class Initialized
INFO - 2023-12-06 09:52:51 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:52:51 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:52:51 --> Utf8 Class Initialized
INFO - 2023-12-06 09:52:51 --> URI Class Initialized
INFO - 2023-12-06 09:52:51 --> Router Class Initialized
INFO - 2023-12-06 09:52:51 --> Output Class Initialized
INFO - 2023-12-06 09:52:51 --> Security Class Initialized
DEBUG - 2023-12-06 09:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:52:51 --> Input Class Initialized
INFO - 2023-12-06 09:52:51 --> Language Class Initialized
INFO - 2023-12-06 09:52:51 --> Language Class Initialized
INFO - 2023-12-06 09:52:51 --> Config Class Initialized
INFO - 2023-12-06 09:52:51 --> Loader Class Initialized
INFO - 2023-12-06 09:52:51 --> Helper loaded: url_helper
INFO - 2023-12-06 09:52:51 --> Helper loaded: file_helper
INFO - 2023-12-06 09:52:51 --> Helper loaded: form_helper
INFO - 2023-12-06 09:52:51 --> Helper loaded: my_helper
INFO - 2023-12-06 09:52:51 --> Database Driver Class Initialized
INFO - 2023-12-06 09:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:52:51 --> Controller Class Initialized
DEBUG - 2023-12-06 09:52:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 09:52:57 --> Final output sent to browser
DEBUG - 2023-12-06 09:52:57 --> Total execution time: 5.2854
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:09 --> URI Class Initialized
INFO - 2023-12-06 09:54:09 --> Router Class Initialized
INFO - 2023-12-06 09:54:09 --> Output Class Initialized
INFO - 2023-12-06 09:54:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:09 --> Input Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Loader Class Initialized
INFO - 2023-12-06 09:54:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:09 --> Controller Class Initialized
INFO - 2023-12-06 09:54:09 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:09 --> URI Class Initialized
INFO - 2023-12-06 09:54:09 --> Router Class Initialized
INFO - 2023-12-06 09:54:09 --> Output Class Initialized
INFO - 2023-12-06 09:54:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:09 --> Input Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Loader Class Initialized
INFO - 2023-12-06 09:54:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:09 --> Controller Class Initialized
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:09 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:09 --> URI Class Initialized
INFO - 2023-12-06 09:54:09 --> Router Class Initialized
INFO - 2023-12-06 09:54:09 --> Output Class Initialized
INFO - 2023-12-06 09:54:09 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:09 --> Input Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Language Class Initialized
INFO - 2023-12-06 09:54:09 --> Config Class Initialized
INFO - 2023-12-06 09:54:09 --> Loader Class Initialized
INFO - 2023-12-06 09:54:09 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:09 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:09 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:09 --> Controller Class Initialized
DEBUG - 2023-12-06 09:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:54:09 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:09 --> Total execution time: 0.0349
INFO - 2023-12-06 09:54:15 --> Config Class Initialized
INFO - 2023-12-06 09:54:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:15 --> URI Class Initialized
INFO - 2023-12-06 09:54:15 --> Router Class Initialized
INFO - 2023-12-06 09:54:15 --> Output Class Initialized
INFO - 2023-12-06 09:54:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:15 --> Input Class Initialized
INFO - 2023-12-06 09:54:15 --> Language Class Initialized
INFO - 2023-12-06 09:54:15 --> Language Class Initialized
INFO - 2023-12-06 09:54:15 --> Config Class Initialized
INFO - 2023-12-06 09:54:15 --> Loader Class Initialized
INFO - 2023-12-06 09:54:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:15 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:15 --> Controller Class Initialized
INFO - 2023-12-06 09:54:15 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:54:15 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:15 --> Total execution time: 0.0589
INFO - 2023-12-06 09:54:15 --> Config Class Initialized
INFO - 2023-12-06 09:54:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:15 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:15 --> URI Class Initialized
INFO - 2023-12-06 09:54:15 --> Router Class Initialized
INFO - 2023-12-06 09:54:15 --> Output Class Initialized
INFO - 2023-12-06 09:54:15 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:15 --> Input Class Initialized
INFO - 2023-12-06 09:54:15 --> Language Class Initialized
INFO - 2023-12-06 09:54:15 --> Language Class Initialized
INFO - 2023-12-06 09:54:15 --> Config Class Initialized
INFO - 2023-12-06 09:54:15 --> Loader Class Initialized
INFO - 2023-12-06 09:54:15 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:15 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:15 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:15 --> Controller Class Initialized
DEBUG - 2023-12-06 09:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 09:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:54:15 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:15 --> Total execution time: 0.0363
INFO - 2023-12-06 09:54:23 --> Config Class Initialized
INFO - 2023-12-06 09:54:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:23 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:23 --> URI Class Initialized
INFO - 2023-12-06 09:54:23 --> Router Class Initialized
INFO - 2023-12-06 09:54:23 --> Output Class Initialized
INFO - 2023-12-06 09:54:23 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:23 --> Input Class Initialized
INFO - 2023-12-06 09:54:23 --> Language Class Initialized
INFO - 2023-12-06 09:54:23 --> Language Class Initialized
INFO - 2023-12-06 09:54:23 --> Config Class Initialized
INFO - 2023-12-06 09:54:23 --> Loader Class Initialized
INFO - 2023-12-06 09:54:23 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:23 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:23 --> Controller Class Initialized
DEBUG - 2023-12-06 09:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 09:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:54:23 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:23 --> Total execution time: 0.0406
INFO - 2023-12-06 09:54:23 --> Config Class Initialized
INFO - 2023-12-06 09:54:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:23 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:23 --> URI Class Initialized
INFO - 2023-12-06 09:54:23 --> Router Class Initialized
INFO - 2023-12-06 09:54:23 --> Output Class Initialized
INFO - 2023-12-06 09:54:23 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:23 --> Input Class Initialized
INFO - 2023-12-06 09:54:23 --> Language Class Initialized
ERROR - 2023-12-06 09:54:23 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:54:23 --> Config Class Initialized
INFO - 2023-12-06 09:54:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:23 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:23 --> URI Class Initialized
INFO - 2023-12-06 09:54:23 --> Router Class Initialized
INFO - 2023-12-06 09:54:23 --> Output Class Initialized
INFO - 2023-12-06 09:54:23 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:23 --> Input Class Initialized
INFO - 2023-12-06 09:54:23 --> Language Class Initialized
INFO - 2023-12-06 09:54:23 --> Language Class Initialized
INFO - 2023-12-06 09:54:23 --> Config Class Initialized
INFO - 2023-12-06 09:54:23 --> Loader Class Initialized
INFO - 2023-12-06 09:54:23 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:23 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:23 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:23 --> Controller Class Initialized
INFO - 2023-12-06 09:54:25 --> Config Class Initialized
INFO - 2023-12-06 09:54:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:25 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:25 --> URI Class Initialized
INFO - 2023-12-06 09:54:25 --> Router Class Initialized
INFO - 2023-12-06 09:54:25 --> Output Class Initialized
INFO - 2023-12-06 09:54:25 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:25 --> Input Class Initialized
INFO - 2023-12-06 09:54:25 --> Language Class Initialized
INFO - 2023-12-06 09:54:25 --> Language Class Initialized
INFO - 2023-12-06 09:54:25 --> Config Class Initialized
INFO - 2023-12-06 09:54:25 --> Loader Class Initialized
INFO - 2023-12-06 09:54:25 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:25 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:25 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:25 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:25 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:25 --> Controller Class Initialized
INFO - 2023-12-06 09:54:25 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:25 --> Total execution time: 0.0345
INFO - 2023-12-06 09:54:29 --> Config Class Initialized
INFO - 2023-12-06 09:54:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:29 --> URI Class Initialized
INFO - 2023-12-06 09:54:29 --> Router Class Initialized
INFO - 2023-12-06 09:54:29 --> Output Class Initialized
INFO - 2023-12-06 09:54:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:29 --> Input Class Initialized
INFO - 2023-12-06 09:54:29 --> Language Class Initialized
INFO - 2023-12-06 09:54:29 --> Language Class Initialized
INFO - 2023-12-06 09:54:29 --> Config Class Initialized
INFO - 2023-12-06 09:54:29 --> Loader Class Initialized
INFO - 2023-12-06 09:54:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:29 --> Controller Class Initialized
INFO - 2023-12-06 09:54:29 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:29 --> Total execution time: 0.0397
INFO - 2023-12-06 09:54:29 --> Config Class Initialized
INFO - 2023-12-06 09:54:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:29 --> URI Class Initialized
INFO - 2023-12-06 09:54:29 --> Router Class Initialized
INFO - 2023-12-06 09:54:29 --> Output Class Initialized
INFO - 2023-12-06 09:54:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:29 --> Input Class Initialized
INFO - 2023-12-06 09:54:29 --> Language Class Initialized
ERROR - 2023-12-06 09:54:29 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:54:29 --> Config Class Initialized
INFO - 2023-12-06 09:54:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:29 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:29 --> URI Class Initialized
INFO - 2023-12-06 09:54:29 --> Router Class Initialized
INFO - 2023-12-06 09:54:29 --> Output Class Initialized
INFO - 2023-12-06 09:54:29 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:29 --> Input Class Initialized
INFO - 2023-12-06 09:54:29 --> Language Class Initialized
INFO - 2023-12-06 09:54:29 --> Language Class Initialized
INFO - 2023-12-06 09:54:29 --> Config Class Initialized
INFO - 2023-12-06 09:54:29 --> Loader Class Initialized
INFO - 2023-12-06 09:54:29 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:29 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:29 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:29 --> Controller Class Initialized
INFO - 2023-12-06 09:54:31 --> Config Class Initialized
INFO - 2023-12-06 09:54:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:31 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:31 --> URI Class Initialized
INFO - 2023-12-06 09:54:31 --> Router Class Initialized
INFO - 2023-12-06 09:54:31 --> Output Class Initialized
INFO - 2023-12-06 09:54:31 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:31 --> Input Class Initialized
INFO - 2023-12-06 09:54:31 --> Language Class Initialized
INFO - 2023-12-06 09:54:31 --> Language Class Initialized
INFO - 2023-12-06 09:54:31 --> Config Class Initialized
INFO - 2023-12-06 09:54:31 --> Loader Class Initialized
INFO - 2023-12-06 09:54:31 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:31 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:31 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:31 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:31 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:31 --> Controller Class Initialized
INFO - 2023-12-06 09:54:31 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:31 --> Total execution time: 0.0447
INFO - 2023-12-06 09:54:36 --> Config Class Initialized
INFO - 2023-12-06 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:36 --> URI Class Initialized
INFO - 2023-12-06 09:54:36 --> Router Class Initialized
INFO - 2023-12-06 09:54:36 --> Output Class Initialized
INFO - 2023-12-06 09:54:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:36 --> Input Class Initialized
INFO - 2023-12-06 09:54:36 --> Language Class Initialized
INFO - 2023-12-06 09:54:36 --> Language Class Initialized
INFO - 2023-12-06 09:54:36 --> Config Class Initialized
INFO - 2023-12-06 09:54:36 --> Loader Class Initialized
INFO - 2023-12-06 09:54:36 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:36 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:36 --> Controller Class Initialized
INFO - 2023-12-06 09:54:36 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:36 --> Total execution time: 0.0970
INFO - 2023-12-06 09:54:36 --> Config Class Initialized
INFO - 2023-12-06 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:36 --> URI Class Initialized
INFO - 2023-12-06 09:54:36 --> Router Class Initialized
INFO - 2023-12-06 09:54:36 --> Output Class Initialized
INFO - 2023-12-06 09:54:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:36 --> Input Class Initialized
INFO - 2023-12-06 09:54:36 --> Language Class Initialized
ERROR - 2023-12-06 09:54:36 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:54:36 --> Config Class Initialized
INFO - 2023-12-06 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:36 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:36 --> URI Class Initialized
INFO - 2023-12-06 09:54:36 --> Router Class Initialized
INFO - 2023-12-06 09:54:36 --> Output Class Initialized
INFO - 2023-12-06 09:54:36 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:36 --> Input Class Initialized
INFO - 2023-12-06 09:54:36 --> Language Class Initialized
INFO - 2023-12-06 09:54:36 --> Language Class Initialized
INFO - 2023-12-06 09:54:36 --> Config Class Initialized
INFO - 2023-12-06 09:54:36 --> Loader Class Initialized
INFO - 2023-12-06 09:54:36 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:36 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:36 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:36 --> Controller Class Initialized
INFO - 2023-12-06 09:54:38 --> Config Class Initialized
INFO - 2023-12-06 09:54:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:38 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:38 --> URI Class Initialized
INFO - 2023-12-06 09:54:38 --> Router Class Initialized
INFO - 2023-12-06 09:54:38 --> Output Class Initialized
INFO - 2023-12-06 09:54:38 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:38 --> Input Class Initialized
INFO - 2023-12-06 09:54:38 --> Language Class Initialized
INFO - 2023-12-06 09:54:38 --> Language Class Initialized
INFO - 2023-12-06 09:54:38 --> Config Class Initialized
INFO - 2023-12-06 09:54:38 --> Loader Class Initialized
INFO - 2023-12-06 09:54:38 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:38 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:38 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:38 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:38 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:38 --> Controller Class Initialized
INFO - 2023-12-06 09:54:38 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:38 --> Total execution time: 0.0330
INFO - 2023-12-06 09:54:41 --> Config Class Initialized
INFO - 2023-12-06 09:54:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:41 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:41 --> URI Class Initialized
INFO - 2023-12-06 09:54:41 --> Router Class Initialized
INFO - 2023-12-06 09:54:41 --> Output Class Initialized
INFO - 2023-12-06 09:54:41 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:41 --> Input Class Initialized
INFO - 2023-12-06 09:54:42 --> Language Class Initialized
INFO - 2023-12-06 09:54:42 --> Language Class Initialized
INFO - 2023-12-06 09:54:42 --> Config Class Initialized
INFO - 2023-12-06 09:54:42 --> Loader Class Initialized
INFO - 2023-12-06 09:54:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:42 --> Controller Class Initialized
INFO - 2023-12-06 09:54:42 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:42 --> Total execution time: 0.0637
INFO - 2023-12-06 09:54:42 --> Config Class Initialized
INFO - 2023-12-06 09:54:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:42 --> URI Class Initialized
INFO - 2023-12-06 09:54:42 --> Router Class Initialized
INFO - 2023-12-06 09:54:42 --> Output Class Initialized
INFO - 2023-12-06 09:54:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:42 --> Input Class Initialized
INFO - 2023-12-06 09:54:42 --> Language Class Initialized
ERROR - 2023-12-06 09:54:42 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:54:42 --> Config Class Initialized
INFO - 2023-12-06 09:54:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:42 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:42 --> URI Class Initialized
INFO - 2023-12-06 09:54:42 --> Router Class Initialized
INFO - 2023-12-06 09:54:42 --> Output Class Initialized
INFO - 2023-12-06 09:54:42 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:42 --> Input Class Initialized
INFO - 2023-12-06 09:54:42 --> Language Class Initialized
INFO - 2023-12-06 09:54:42 --> Language Class Initialized
INFO - 2023-12-06 09:54:42 --> Config Class Initialized
INFO - 2023-12-06 09:54:42 --> Loader Class Initialized
INFO - 2023-12-06 09:54:42 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:42 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:42 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:42 --> Controller Class Initialized
INFO - 2023-12-06 09:54:43 --> Config Class Initialized
INFO - 2023-12-06 09:54:43 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:43 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:43 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:43 --> URI Class Initialized
INFO - 2023-12-06 09:54:43 --> Router Class Initialized
INFO - 2023-12-06 09:54:43 --> Output Class Initialized
INFO - 2023-12-06 09:54:43 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:43 --> Input Class Initialized
INFO - 2023-12-06 09:54:43 --> Language Class Initialized
INFO - 2023-12-06 09:54:43 --> Language Class Initialized
INFO - 2023-12-06 09:54:43 --> Config Class Initialized
INFO - 2023-12-06 09:54:43 --> Loader Class Initialized
INFO - 2023-12-06 09:54:43 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:43 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:43 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:43 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:43 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:43 --> Controller Class Initialized
INFO - 2023-12-06 09:54:43 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:43 --> Total execution time: 0.0443
INFO - 2023-12-06 09:54:48 --> Config Class Initialized
INFO - 2023-12-06 09:54:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:48 --> URI Class Initialized
INFO - 2023-12-06 09:54:48 --> Router Class Initialized
INFO - 2023-12-06 09:54:48 --> Output Class Initialized
INFO - 2023-12-06 09:54:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:48 --> Input Class Initialized
INFO - 2023-12-06 09:54:48 --> Language Class Initialized
INFO - 2023-12-06 09:54:48 --> Language Class Initialized
INFO - 2023-12-06 09:54:48 --> Config Class Initialized
INFO - 2023-12-06 09:54:48 --> Loader Class Initialized
INFO - 2023-12-06 09:54:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:48 --> Controller Class Initialized
INFO - 2023-12-06 09:54:48 --> Final output sent to browser
DEBUG - 2023-12-06 09:54:48 --> Total execution time: 0.2012
INFO - 2023-12-06 09:54:48 --> Config Class Initialized
INFO - 2023-12-06 09:54:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:48 --> URI Class Initialized
INFO - 2023-12-06 09:54:48 --> Router Class Initialized
INFO - 2023-12-06 09:54:48 --> Output Class Initialized
INFO - 2023-12-06 09:54:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:48 --> Input Class Initialized
INFO - 2023-12-06 09:54:48 --> Language Class Initialized
ERROR - 2023-12-06 09:54:48 --> 404 Page Not Found: /index
INFO - 2023-12-06 09:54:48 --> Config Class Initialized
INFO - 2023-12-06 09:54:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:54:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:54:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:54:48 --> URI Class Initialized
INFO - 2023-12-06 09:54:48 --> Router Class Initialized
INFO - 2023-12-06 09:54:48 --> Output Class Initialized
INFO - 2023-12-06 09:54:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:54:48 --> Input Class Initialized
INFO - 2023-12-06 09:54:48 --> Language Class Initialized
INFO - 2023-12-06 09:54:48 --> Language Class Initialized
INFO - 2023-12-06 09:54:48 --> Config Class Initialized
INFO - 2023-12-06 09:54:48 --> Loader Class Initialized
INFO - 2023-12-06 09:54:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:54:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:54:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:54:48 --> Controller Class Initialized
INFO - 2023-12-06 09:55:01 --> Config Class Initialized
INFO - 2023-12-06 09:55:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:01 --> URI Class Initialized
INFO - 2023-12-06 09:55:01 --> Router Class Initialized
INFO - 2023-12-06 09:55:01 --> Output Class Initialized
INFO - 2023-12-06 09:55:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:01 --> Input Class Initialized
INFO - 2023-12-06 09:55:01 --> Language Class Initialized
INFO - 2023-12-06 09:55:01 --> Language Class Initialized
INFO - 2023-12-06 09:55:01 --> Config Class Initialized
INFO - 2023-12-06 09:55:01 --> Loader Class Initialized
INFO - 2023-12-06 09:55:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:01 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:01 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:01 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:01 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:01 --> Controller Class Initialized
INFO - 2023-12-06 09:55:01 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:55:01 --> Config Class Initialized
INFO - 2023-12-06 09:55:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:01 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:01 --> URI Class Initialized
INFO - 2023-12-06 09:55:01 --> Router Class Initialized
INFO - 2023-12-06 09:55:01 --> Output Class Initialized
INFO - 2023-12-06 09:55:01 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:01 --> Input Class Initialized
INFO - 2023-12-06 09:55:01 --> Language Class Initialized
INFO - 2023-12-06 09:55:01 --> Language Class Initialized
INFO - 2023-12-06 09:55:01 --> Config Class Initialized
INFO - 2023-12-06 09:55:01 --> Loader Class Initialized
INFO - 2023-12-06 09:55:01 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:02 --> Controller Class Initialized
INFO - 2023-12-06 09:55:02 --> Config Class Initialized
INFO - 2023-12-06 09:55:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:02 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:02 --> URI Class Initialized
INFO - 2023-12-06 09:55:02 --> Router Class Initialized
INFO - 2023-12-06 09:55:02 --> Output Class Initialized
INFO - 2023-12-06 09:55:02 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:02 --> Input Class Initialized
INFO - 2023-12-06 09:55:02 --> Language Class Initialized
INFO - 2023-12-06 09:55:02 --> Language Class Initialized
INFO - 2023-12-06 09:55:02 --> Config Class Initialized
INFO - 2023-12-06 09:55:02 --> Loader Class Initialized
INFO - 2023-12-06 09:55:02 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:02 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:02 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:02 --> Controller Class Initialized
DEBUG - 2023-12-06 09:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 09:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:55:02 --> Final output sent to browser
DEBUG - 2023-12-06 09:55:02 --> Total execution time: 0.1149
INFO - 2023-12-06 09:55:07 --> Config Class Initialized
INFO - 2023-12-06 09:55:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:07 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:07 --> URI Class Initialized
INFO - 2023-12-06 09:55:07 --> Router Class Initialized
INFO - 2023-12-06 09:55:07 --> Output Class Initialized
INFO - 2023-12-06 09:55:07 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:07 --> Input Class Initialized
INFO - 2023-12-06 09:55:07 --> Language Class Initialized
INFO - 2023-12-06 09:55:07 --> Language Class Initialized
INFO - 2023-12-06 09:55:07 --> Config Class Initialized
INFO - 2023-12-06 09:55:07 --> Loader Class Initialized
INFO - 2023-12-06 09:55:07 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:07 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:07 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:07 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:07 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:07 --> Controller Class Initialized
INFO - 2023-12-06 09:55:08 --> Helper loaded: cookie_helper
INFO - 2023-12-06 09:55:08 --> Final output sent to browser
DEBUG - 2023-12-06 09:55:08 --> Total execution time: 0.1184
INFO - 2023-12-06 09:55:08 --> Config Class Initialized
INFO - 2023-12-06 09:55:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:08 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:08 --> URI Class Initialized
INFO - 2023-12-06 09:55:08 --> Router Class Initialized
INFO - 2023-12-06 09:55:08 --> Output Class Initialized
INFO - 2023-12-06 09:55:08 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:08 --> Input Class Initialized
INFO - 2023-12-06 09:55:08 --> Language Class Initialized
INFO - 2023-12-06 09:55:08 --> Language Class Initialized
INFO - 2023-12-06 09:55:08 --> Config Class Initialized
INFO - 2023-12-06 09:55:08 --> Loader Class Initialized
INFO - 2023-12-06 09:55:08 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:08 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:08 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:08 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:08 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:08 --> Controller Class Initialized
DEBUG - 2023-12-06 09:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 09:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:55:08 --> Final output sent to browser
DEBUG - 2023-12-06 09:55:08 --> Total execution time: 0.0475
INFO - 2023-12-06 09:55:30 --> Config Class Initialized
INFO - 2023-12-06 09:55:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:30 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:30 --> URI Class Initialized
INFO - 2023-12-06 09:55:30 --> Router Class Initialized
INFO - 2023-12-06 09:55:30 --> Output Class Initialized
INFO - 2023-12-06 09:55:30 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:30 --> Input Class Initialized
INFO - 2023-12-06 09:55:30 --> Language Class Initialized
INFO - 2023-12-06 09:55:30 --> Language Class Initialized
INFO - 2023-12-06 09:55:30 --> Config Class Initialized
INFO - 2023-12-06 09:55:30 --> Loader Class Initialized
INFO - 2023-12-06 09:55:30 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:30 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:30 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:30 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:30 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:30 --> Controller Class Initialized
DEBUG - 2023-12-06 09:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 09:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 09:55:30 --> Final output sent to browser
DEBUG - 2023-12-06 09:55:30 --> Total execution time: 0.0998
INFO - 2023-12-06 09:55:34 --> Config Class Initialized
INFO - 2023-12-06 09:55:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:55:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:55:34 --> Utf8 Class Initialized
INFO - 2023-12-06 09:55:34 --> URI Class Initialized
INFO - 2023-12-06 09:55:34 --> Router Class Initialized
INFO - 2023-12-06 09:55:34 --> Output Class Initialized
INFO - 2023-12-06 09:55:34 --> Security Class Initialized
DEBUG - 2023-12-06 09:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:55:34 --> Input Class Initialized
INFO - 2023-12-06 09:55:34 --> Language Class Initialized
INFO - 2023-12-06 09:55:34 --> Language Class Initialized
INFO - 2023-12-06 09:55:34 --> Config Class Initialized
INFO - 2023-12-06 09:55:34 --> Loader Class Initialized
INFO - 2023-12-06 09:55:34 --> Helper loaded: url_helper
INFO - 2023-12-06 09:55:34 --> Helper loaded: file_helper
INFO - 2023-12-06 09:55:34 --> Helper loaded: form_helper
INFO - 2023-12-06 09:55:34 --> Helper loaded: my_helper
INFO - 2023-12-06 09:55:34 --> Database Driver Class Initialized
INFO - 2023-12-06 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:55:34 --> Controller Class Initialized
DEBUG - 2023-12-06 09:55:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-06 09:55:36 --> Final output sent to browser
DEBUG - 2023-12-06 09:55:36 --> Total execution time: 2.2879
INFO - 2023-12-06 09:56:48 --> Config Class Initialized
INFO - 2023-12-06 09:56:48 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:56:48 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:56:48 --> Utf8 Class Initialized
INFO - 2023-12-06 09:56:48 --> URI Class Initialized
INFO - 2023-12-06 09:56:48 --> Router Class Initialized
INFO - 2023-12-06 09:56:48 --> Output Class Initialized
INFO - 2023-12-06 09:56:48 --> Security Class Initialized
DEBUG - 2023-12-06 09:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:56:48 --> Input Class Initialized
INFO - 2023-12-06 09:56:48 --> Language Class Initialized
INFO - 2023-12-06 09:56:48 --> Language Class Initialized
INFO - 2023-12-06 09:56:48 --> Config Class Initialized
INFO - 2023-12-06 09:56:48 --> Loader Class Initialized
INFO - 2023-12-06 09:56:48 --> Helper loaded: url_helper
INFO - 2023-12-06 09:56:48 --> Helper loaded: file_helper
INFO - 2023-12-06 09:56:48 --> Helper loaded: form_helper
INFO - 2023-12-06 09:56:48 --> Helper loaded: my_helper
INFO - 2023-12-06 09:56:48 --> Database Driver Class Initialized
INFO - 2023-12-06 09:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:56:48 --> Controller Class Initialized
ERROR - 2023-12-06 09:56:48 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-06 09:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-06 09:56:52 --> Final output sent to browser
DEBUG - 2023-12-06 09:56:52 --> Total execution time: 4.1160
INFO - 2023-12-06 09:57:06 --> Config Class Initialized
INFO - 2023-12-06 09:57:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 09:57:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 09:57:06 --> Utf8 Class Initialized
INFO - 2023-12-06 09:57:06 --> URI Class Initialized
INFO - 2023-12-06 09:57:06 --> Router Class Initialized
INFO - 2023-12-06 09:57:06 --> Output Class Initialized
INFO - 2023-12-06 09:57:06 --> Security Class Initialized
DEBUG - 2023-12-06 09:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 09:57:06 --> Input Class Initialized
INFO - 2023-12-06 09:57:06 --> Language Class Initialized
INFO - 2023-12-06 09:57:06 --> Language Class Initialized
INFO - 2023-12-06 09:57:06 --> Config Class Initialized
INFO - 2023-12-06 09:57:06 --> Loader Class Initialized
INFO - 2023-12-06 09:57:06 --> Helper loaded: url_helper
INFO - 2023-12-06 09:57:06 --> Helper loaded: file_helper
INFO - 2023-12-06 09:57:06 --> Helper loaded: form_helper
INFO - 2023-12-06 09:57:06 --> Helper loaded: my_helper
INFO - 2023-12-06 09:57:06 --> Database Driver Class Initialized
INFO - 2023-12-06 09:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 09:57:06 --> Controller Class Initialized
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3147
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3185
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
ERROR - 2023-12-06 09:57:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
ERROR - 2023-12-06 09:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3223
DEBUG - 2023-12-06 09:57:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-06 09:57:12 --> Final output sent to browser
DEBUG - 2023-12-06 09:57:12 --> Total execution time: 6.4574
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:03:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:03:58 --> Utf8 Class Initialized
INFO - 2023-12-06 10:03:58 --> URI Class Initialized
INFO - 2023-12-06 10:03:58 --> Router Class Initialized
INFO - 2023-12-06 10:03:58 --> Output Class Initialized
INFO - 2023-12-06 10:03:58 --> Security Class Initialized
DEBUG - 2023-12-06 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:03:58 --> Input Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Loader Class Initialized
INFO - 2023-12-06 10:03:58 --> Helper loaded: url_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: file_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: form_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: my_helper
INFO - 2023-12-06 10:03:58 --> Database Driver Class Initialized
INFO - 2023-12-06 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:03:58 --> Controller Class Initialized
INFO - 2023-12-06 10:03:58 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:03:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:03:58 --> Utf8 Class Initialized
INFO - 2023-12-06 10:03:58 --> URI Class Initialized
INFO - 2023-12-06 10:03:58 --> Router Class Initialized
INFO - 2023-12-06 10:03:58 --> Output Class Initialized
INFO - 2023-12-06 10:03:58 --> Security Class Initialized
DEBUG - 2023-12-06 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:03:58 --> Input Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Loader Class Initialized
INFO - 2023-12-06 10:03:58 --> Helper loaded: url_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: file_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: form_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: my_helper
INFO - 2023-12-06 10:03:58 --> Database Driver Class Initialized
INFO - 2023-12-06 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:03:58 --> Controller Class Initialized
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:03:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:03:58 --> Utf8 Class Initialized
INFO - 2023-12-06 10:03:58 --> URI Class Initialized
INFO - 2023-12-06 10:03:58 --> Router Class Initialized
INFO - 2023-12-06 10:03:58 --> Output Class Initialized
INFO - 2023-12-06 10:03:58 --> Security Class Initialized
DEBUG - 2023-12-06 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:03:58 --> Input Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Language Class Initialized
INFO - 2023-12-06 10:03:58 --> Config Class Initialized
INFO - 2023-12-06 10:03:58 --> Loader Class Initialized
INFO - 2023-12-06 10:03:58 --> Helper loaded: url_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: file_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: form_helper
INFO - 2023-12-06 10:03:58 --> Helper loaded: my_helper
INFO - 2023-12-06 10:03:58 --> Database Driver Class Initialized
INFO - 2023-12-06 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:03:58 --> Controller Class Initialized
DEBUG - 2023-12-06 10:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 10:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:03:58 --> Final output sent to browser
DEBUG - 2023-12-06 10:03:58 --> Total execution time: 0.0571
INFO - 2023-12-06 10:04:02 --> Config Class Initialized
INFO - 2023-12-06 10:04:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:04:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:04:02 --> Utf8 Class Initialized
INFO - 2023-12-06 10:04:02 --> URI Class Initialized
INFO - 2023-12-06 10:04:02 --> Router Class Initialized
INFO - 2023-12-06 10:04:02 --> Output Class Initialized
INFO - 2023-12-06 10:04:02 --> Security Class Initialized
DEBUG - 2023-12-06 10:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:04:02 --> Input Class Initialized
INFO - 2023-12-06 10:04:02 --> Language Class Initialized
INFO - 2023-12-06 10:04:02 --> Language Class Initialized
INFO - 2023-12-06 10:04:02 --> Config Class Initialized
INFO - 2023-12-06 10:04:02 --> Loader Class Initialized
INFO - 2023-12-06 10:04:02 --> Helper loaded: url_helper
INFO - 2023-12-06 10:04:02 --> Helper loaded: file_helper
INFO - 2023-12-06 10:04:02 --> Helper loaded: form_helper
INFO - 2023-12-06 10:04:02 --> Helper loaded: my_helper
INFO - 2023-12-06 10:04:02 --> Database Driver Class Initialized
INFO - 2023-12-06 10:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:04:02 --> Controller Class Initialized
INFO - 2023-12-06 10:04:02 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:04:02 --> Final output sent to browser
DEBUG - 2023-12-06 10:04:02 --> Total execution time: 0.2480
INFO - 2023-12-06 10:04:03 --> Config Class Initialized
INFO - 2023-12-06 10:04:03 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:04:03 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:04:03 --> Utf8 Class Initialized
INFO - 2023-12-06 10:04:03 --> URI Class Initialized
INFO - 2023-12-06 10:04:03 --> Router Class Initialized
INFO - 2023-12-06 10:04:03 --> Output Class Initialized
INFO - 2023-12-06 10:04:03 --> Security Class Initialized
DEBUG - 2023-12-06 10:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:04:03 --> Input Class Initialized
INFO - 2023-12-06 10:04:03 --> Language Class Initialized
INFO - 2023-12-06 10:04:03 --> Language Class Initialized
INFO - 2023-12-06 10:04:03 --> Config Class Initialized
INFO - 2023-12-06 10:04:03 --> Loader Class Initialized
INFO - 2023-12-06 10:04:03 --> Helper loaded: url_helper
INFO - 2023-12-06 10:04:03 --> Helper loaded: file_helper
INFO - 2023-12-06 10:04:03 --> Helper loaded: form_helper
INFO - 2023-12-06 10:04:03 --> Helper loaded: my_helper
INFO - 2023-12-06 10:04:03 --> Database Driver Class Initialized
INFO - 2023-12-06 10:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:04:03 --> Controller Class Initialized
DEBUG - 2023-12-06 10:04:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 10:04:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:04:03 --> Final output sent to browser
DEBUG - 2023-12-06 10:04:03 --> Total execution time: 0.1352
INFO - 2023-12-06 10:04:09 --> Config Class Initialized
INFO - 2023-12-06 10:04:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:04:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:04:09 --> Utf8 Class Initialized
INFO - 2023-12-06 10:04:09 --> URI Class Initialized
INFO - 2023-12-06 10:04:09 --> Router Class Initialized
INFO - 2023-12-06 10:04:09 --> Output Class Initialized
INFO - 2023-12-06 10:04:09 --> Security Class Initialized
DEBUG - 2023-12-06 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:04:09 --> Input Class Initialized
INFO - 2023-12-06 10:04:09 --> Language Class Initialized
INFO - 2023-12-06 10:04:09 --> Language Class Initialized
INFO - 2023-12-06 10:04:09 --> Config Class Initialized
INFO - 2023-12-06 10:04:09 --> Loader Class Initialized
INFO - 2023-12-06 10:04:09 --> Helper loaded: url_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: file_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: form_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: my_helper
INFO - 2023-12-06 10:04:09 --> Database Driver Class Initialized
INFO - 2023-12-06 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:04:09 --> Controller Class Initialized
DEBUG - 2023-12-06 10:04:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 10:04:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:04:09 --> Final output sent to browser
DEBUG - 2023-12-06 10:04:09 --> Total execution time: 0.0337
INFO - 2023-12-06 10:04:09 --> Config Class Initialized
INFO - 2023-12-06 10:04:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:04:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:04:09 --> Utf8 Class Initialized
INFO - 2023-12-06 10:04:09 --> URI Class Initialized
INFO - 2023-12-06 10:04:09 --> Router Class Initialized
INFO - 2023-12-06 10:04:09 --> Output Class Initialized
INFO - 2023-12-06 10:04:09 --> Security Class Initialized
DEBUG - 2023-12-06 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:04:09 --> Input Class Initialized
INFO - 2023-12-06 10:04:09 --> Language Class Initialized
ERROR - 2023-12-06 10:04:09 --> 404 Page Not Found: /index
INFO - 2023-12-06 10:04:09 --> Config Class Initialized
INFO - 2023-12-06 10:04:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:04:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:04:09 --> Utf8 Class Initialized
INFO - 2023-12-06 10:04:09 --> URI Class Initialized
INFO - 2023-12-06 10:04:09 --> Router Class Initialized
INFO - 2023-12-06 10:04:09 --> Output Class Initialized
INFO - 2023-12-06 10:04:09 --> Security Class Initialized
DEBUG - 2023-12-06 10:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:04:09 --> Input Class Initialized
INFO - 2023-12-06 10:04:09 --> Language Class Initialized
INFO - 2023-12-06 10:04:09 --> Language Class Initialized
INFO - 2023-12-06 10:04:09 --> Config Class Initialized
INFO - 2023-12-06 10:04:09 --> Loader Class Initialized
INFO - 2023-12-06 10:04:09 --> Helper loaded: url_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: file_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: form_helper
INFO - 2023-12-06 10:04:09 --> Helper loaded: my_helper
INFO - 2023-12-06 10:04:09 --> Database Driver Class Initialized
INFO - 2023-12-06 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:04:09 --> Controller Class Initialized
INFO - 2023-12-06 10:05:59 --> Config Class Initialized
INFO - 2023-12-06 10:05:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:05:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:05:59 --> Utf8 Class Initialized
INFO - 2023-12-06 10:05:59 --> URI Class Initialized
INFO - 2023-12-06 10:05:59 --> Router Class Initialized
INFO - 2023-12-06 10:05:59 --> Output Class Initialized
INFO - 2023-12-06 10:05:59 --> Security Class Initialized
DEBUG - 2023-12-06 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:05:59 --> Input Class Initialized
INFO - 2023-12-06 10:05:59 --> Language Class Initialized
INFO - 2023-12-06 10:05:59 --> Language Class Initialized
INFO - 2023-12-06 10:05:59 --> Config Class Initialized
INFO - 2023-12-06 10:05:59 --> Loader Class Initialized
INFO - 2023-12-06 10:05:59 --> Helper loaded: url_helper
INFO - 2023-12-06 10:05:59 --> Helper loaded: file_helper
INFO - 2023-12-06 10:05:59 --> Helper loaded: form_helper
INFO - 2023-12-06 10:05:59 --> Helper loaded: my_helper
INFO - 2023-12-06 10:05:59 --> Database Driver Class Initialized
INFO - 2023-12-06 10:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:05:59 --> Controller Class Initialized
DEBUG - 2023-12-06 10:05:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 10:05:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:05:59 --> Final output sent to browser
DEBUG - 2023-12-06 10:05:59 --> Total execution time: 0.1051
INFO - 2023-12-06 10:06:06 --> Config Class Initialized
INFO - 2023-12-06 10:06:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:06 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:06 --> URI Class Initialized
DEBUG - 2023-12-06 10:06:06 --> No URI present. Default controller set.
INFO - 2023-12-06 10:06:06 --> Router Class Initialized
INFO - 2023-12-06 10:06:06 --> Output Class Initialized
INFO - 2023-12-06 10:06:06 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:06 --> Input Class Initialized
INFO - 2023-12-06 10:06:06 --> Language Class Initialized
INFO - 2023-12-06 10:06:06 --> Language Class Initialized
INFO - 2023-12-06 10:06:06 --> Config Class Initialized
INFO - 2023-12-06 10:06:06 --> Loader Class Initialized
INFO - 2023-12-06 10:06:06 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:06 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:06 --> Controller Class Initialized
INFO - 2023-12-06 10:06:06 --> Config Class Initialized
INFO - 2023-12-06 10:06:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:06 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:06 --> URI Class Initialized
INFO - 2023-12-06 10:06:06 --> Router Class Initialized
INFO - 2023-12-06 10:06:06 --> Output Class Initialized
INFO - 2023-12-06 10:06:06 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:06 --> Input Class Initialized
INFO - 2023-12-06 10:06:06 --> Language Class Initialized
INFO - 2023-12-06 10:06:06 --> Language Class Initialized
INFO - 2023-12-06 10:06:06 --> Config Class Initialized
INFO - 2023-12-06 10:06:06 --> Loader Class Initialized
INFO - 2023-12-06 10:06:06 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:06 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:06 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:06 --> Controller Class Initialized
DEBUG - 2023-12-06 10:06:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 10:06:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:06:06 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:06 --> Total execution time: 0.0578
INFO - 2023-12-06 10:06:10 --> Config Class Initialized
INFO - 2023-12-06 10:06:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:10 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:10 --> URI Class Initialized
INFO - 2023-12-06 10:06:10 --> Router Class Initialized
INFO - 2023-12-06 10:06:10 --> Output Class Initialized
INFO - 2023-12-06 10:06:10 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:10 --> Input Class Initialized
INFO - 2023-12-06 10:06:10 --> Language Class Initialized
INFO - 2023-12-06 10:06:10 --> Language Class Initialized
INFO - 2023-12-06 10:06:10 --> Config Class Initialized
INFO - 2023-12-06 10:06:10 --> Loader Class Initialized
INFO - 2023-12-06 10:06:10 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:10 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:10 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:10 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:10 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:10 --> Controller Class Initialized
INFO - 2023-12-06 10:06:10 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:10 --> Total execution time: 0.0384
INFO - 2023-12-06 10:06:14 --> Config Class Initialized
INFO - 2023-12-06 10:06:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:14 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:14 --> URI Class Initialized
INFO - 2023-12-06 10:06:14 --> Router Class Initialized
INFO - 2023-12-06 10:06:14 --> Output Class Initialized
INFO - 2023-12-06 10:06:14 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:14 --> Input Class Initialized
INFO - 2023-12-06 10:06:14 --> Language Class Initialized
INFO - 2023-12-06 10:06:14 --> Language Class Initialized
INFO - 2023-12-06 10:06:14 --> Config Class Initialized
INFO - 2023-12-06 10:06:14 --> Loader Class Initialized
INFO - 2023-12-06 10:06:14 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:14 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:14 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:14 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:14 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:14 --> Controller Class Initialized
INFO - 2023-12-06 10:06:14 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:06:14 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:14 --> Total execution time: 0.0544
INFO - 2023-12-06 10:06:14 --> Config Class Initialized
INFO - 2023-12-06 10:06:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:14 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:14 --> URI Class Initialized
INFO - 2023-12-06 10:06:14 --> Router Class Initialized
INFO - 2023-12-06 10:06:14 --> Output Class Initialized
INFO - 2023-12-06 10:06:14 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:14 --> Input Class Initialized
INFO - 2023-12-06 10:06:14 --> Language Class Initialized
INFO - 2023-12-06 10:06:15 --> Language Class Initialized
INFO - 2023-12-06 10:06:15 --> Config Class Initialized
INFO - 2023-12-06 10:06:15 --> Loader Class Initialized
INFO - 2023-12-06 10:06:15 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:15 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:15 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:15 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:15 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:15 --> Controller Class Initialized
DEBUG - 2023-12-06 10:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 10:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:06:15 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:15 --> Total execution time: 0.0391
INFO - 2023-12-06 10:06:17 --> Config Class Initialized
INFO - 2023-12-06 10:06:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:17 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:17 --> URI Class Initialized
INFO - 2023-12-06 10:06:17 --> Router Class Initialized
INFO - 2023-12-06 10:06:17 --> Output Class Initialized
INFO - 2023-12-06 10:06:17 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:17 --> Input Class Initialized
INFO - 2023-12-06 10:06:17 --> Language Class Initialized
INFO - 2023-12-06 10:06:17 --> Language Class Initialized
INFO - 2023-12-06 10:06:17 --> Config Class Initialized
INFO - 2023-12-06 10:06:17 --> Loader Class Initialized
INFO - 2023-12-06 10:06:17 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:17 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:17 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:17 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:17 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:17 --> Controller Class Initialized
DEBUG - 2023-12-06 10:06:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 10:06:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:06:17 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:17 --> Total execution time: 0.0359
INFO - 2023-12-06 10:06:21 --> Config Class Initialized
INFO - 2023-12-06 10:06:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:21 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:21 --> URI Class Initialized
INFO - 2023-12-06 10:06:21 --> Router Class Initialized
INFO - 2023-12-06 10:06:21 --> Output Class Initialized
INFO - 2023-12-06 10:06:21 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:21 --> Input Class Initialized
INFO - 2023-12-06 10:06:21 --> Language Class Initialized
INFO - 2023-12-06 10:06:21 --> Language Class Initialized
INFO - 2023-12-06 10:06:21 --> Config Class Initialized
INFO - 2023-12-06 10:06:21 --> Loader Class Initialized
INFO - 2023-12-06 10:06:21 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:21 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:21 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:21 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:21 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:21 --> Controller Class Initialized
DEBUG - 2023-12-06 10:06:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-06 10:06:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:06:21 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:21 --> Total execution time: 0.0373
INFO - 2023-12-06 10:06:22 --> Config Class Initialized
INFO - 2023-12-06 10:06:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:06:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:06:22 --> Utf8 Class Initialized
INFO - 2023-12-06 10:06:22 --> URI Class Initialized
INFO - 2023-12-06 10:06:22 --> Router Class Initialized
INFO - 2023-12-06 10:06:22 --> Output Class Initialized
INFO - 2023-12-06 10:06:22 --> Security Class Initialized
DEBUG - 2023-12-06 10:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:06:22 --> Input Class Initialized
INFO - 2023-12-06 10:06:22 --> Language Class Initialized
INFO - 2023-12-06 10:06:22 --> Language Class Initialized
INFO - 2023-12-06 10:06:22 --> Config Class Initialized
INFO - 2023-12-06 10:06:22 --> Loader Class Initialized
INFO - 2023-12-06 10:06:22 --> Helper loaded: url_helper
INFO - 2023-12-06 10:06:22 --> Helper loaded: file_helper
INFO - 2023-12-06 10:06:22 --> Helper loaded: form_helper
INFO - 2023-12-06 10:06:22 --> Helper loaded: my_helper
INFO - 2023-12-06 10:06:22 --> Database Driver Class Initialized
INFO - 2023-12-06 10:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:06:22 --> Controller Class Initialized
DEBUG - 2023-12-06 10:06:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 10:06:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:06:22 --> Final output sent to browser
DEBUG - 2023-12-06 10:06:22 --> Total execution time: 0.0402
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:16 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:16 --> URI Class Initialized
INFO - 2023-12-06 10:07:16 --> Router Class Initialized
INFO - 2023-12-06 10:07:16 --> Output Class Initialized
INFO - 2023-12-06 10:07:16 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:16 --> Input Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Loader Class Initialized
INFO - 2023-12-06 10:07:16 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:16 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:16 --> Controller Class Initialized
INFO - 2023-12-06 10:07:16 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:16 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:16 --> URI Class Initialized
INFO - 2023-12-06 10:07:16 --> Router Class Initialized
INFO - 2023-12-06 10:07:16 --> Output Class Initialized
INFO - 2023-12-06 10:07:16 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:16 --> Input Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Loader Class Initialized
INFO - 2023-12-06 10:07:16 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:16 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:16 --> Controller Class Initialized
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:16 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:16 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:16 --> URI Class Initialized
INFO - 2023-12-06 10:07:16 --> Router Class Initialized
INFO - 2023-12-06 10:07:16 --> Output Class Initialized
INFO - 2023-12-06 10:07:16 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:16 --> Input Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Language Class Initialized
INFO - 2023-12-06 10:07:16 --> Config Class Initialized
INFO - 2023-12-06 10:07:16 --> Loader Class Initialized
INFO - 2023-12-06 10:07:16 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:16 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:16 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:16 --> Controller Class Initialized
DEBUG - 2023-12-06 10:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 10:07:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:07:16 --> Final output sent to browser
DEBUG - 2023-12-06 10:07:16 --> Total execution time: 0.0667
INFO - 2023-12-06 10:07:24 --> Config Class Initialized
INFO - 2023-12-06 10:07:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:24 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:24 --> URI Class Initialized
INFO - 2023-12-06 10:07:24 --> Router Class Initialized
INFO - 2023-12-06 10:07:24 --> Output Class Initialized
INFO - 2023-12-06 10:07:24 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:24 --> Input Class Initialized
INFO - 2023-12-06 10:07:24 --> Language Class Initialized
INFO - 2023-12-06 10:07:24 --> Language Class Initialized
INFO - 2023-12-06 10:07:24 --> Config Class Initialized
INFO - 2023-12-06 10:07:24 --> Loader Class Initialized
INFO - 2023-12-06 10:07:24 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:24 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:24 --> Controller Class Initialized
INFO - 2023-12-06 10:07:24 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:07:24 --> Final output sent to browser
DEBUG - 2023-12-06 10:07:24 --> Total execution time: 0.0425
INFO - 2023-12-06 10:07:24 --> Config Class Initialized
INFO - 2023-12-06 10:07:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:24 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:24 --> URI Class Initialized
INFO - 2023-12-06 10:07:24 --> Router Class Initialized
INFO - 2023-12-06 10:07:24 --> Output Class Initialized
INFO - 2023-12-06 10:07:24 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:24 --> Input Class Initialized
INFO - 2023-12-06 10:07:24 --> Language Class Initialized
INFO - 2023-12-06 10:07:24 --> Language Class Initialized
INFO - 2023-12-06 10:07:24 --> Config Class Initialized
INFO - 2023-12-06 10:07:24 --> Loader Class Initialized
INFO - 2023-12-06 10:07:24 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:24 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:24 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:24 --> Controller Class Initialized
DEBUG - 2023-12-06 10:07:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 10:07:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:07:24 --> Final output sent to browser
DEBUG - 2023-12-06 10:07:24 --> Total execution time: 0.0403
INFO - 2023-12-06 10:07:28 --> Config Class Initialized
INFO - 2023-12-06 10:07:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:28 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:28 --> URI Class Initialized
INFO - 2023-12-06 10:07:28 --> Router Class Initialized
INFO - 2023-12-06 10:07:28 --> Output Class Initialized
INFO - 2023-12-06 10:07:28 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:28 --> Input Class Initialized
INFO - 2023-12-06 10:07:28 --> Language Class Initialized
INFO - 2023-12-06 10:07:28 --> Language Class Initialized
INFO - 2023-12-06 10:07:28 --> Config Class Initialized
INFO - 2023-12-06 10:07:28 --> Loader Class Initialized
INFO - 2023-12-06 10:07:28 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:28 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:28 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:28 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:28 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:28 --> Controller Class Initialized
DEBUG - 2023-12-06 10:07:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 10:07:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:07:28 --> Final output sent to browser
DEBUG - 2023-12-06 10:07:28 --> Total execution time: 0.0438
INFO - 2023-12-06 10:07:30 --> Config Class Initialized
INFO - 2023-12-06 10:07:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:07:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:07:30 --> Utf8 Class Initialized
INFO - 2023-12-06 10:07:30 --> URI Class Initialized
INFO - 2023-12-06 10:07:30 --> Router Class Initialized
INFO - 2023-12-06 10:07:30 --> Output Class Initialized
INFO - 2023-12-06 10:07:30 --> Security Class Initialized
DEBUG - 2023-12-06 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:07:30 --> Input Class Initialized
INFO - 2023-12-06 10:07:30 --> Language Class Initialized
INFO - 2023-12-06 10:07:30 --> Language Class Initialized
INFO - 2023-12-06 10:07:30 --> Config Class Initialized
INFO - 2023-12-06 10:07:30 --> Loader Class Initialized
INFO - 2023-12-06 10:07:30 --> Helper loaded: url_helper
INFO - 2023-12-06 10:07:30 --> Helper loaded: file_helper
INFO - 2023-12-06 10:07:30 --> Helper loaded: form_helper
INFO - 2023-12-06 10:07:30 --> Helper loaded: my_helper
INFO - 2023-12-06 10:07:30 --> Database Driver Class Initialized
INFO - 2023-12-06 10:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:07:30 --> Controller Class Initialized
DEBUG - 2023-12-06 10:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 10:07:36 --> Final output sent to browser
DEBUG - 2023-12-06 10:07:36 --> Total execution time: 5.5170
INFO - 2023-12-06 10:11:05 --> Config Class Initialized
INFO - 2023-12-06 10:11:05 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:11:05 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:11:05 --> Utf8 Class Initialized
INFO - 2023-12-06 10:11:05 --> URI Class Initialized
INFO - 2023-12-06 10:11:05 --> Router Class Initialized
INFO - 2023-12-06 10:11:05 --> Output Class Initialized
INFO - 2023-12-06 10:11:05 --> Security Class Initialized
DEBUG - 2023-12-06 10:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:11:05 --> Input Class Initialized
INFO - 2023-12-06 10:11:05 --> Language Class Initialized
INFO - 2023-12-06 10:11:05 --> Language Class Initialized
INFO - 2023-12-06 10:11:05 --> Config Class Initialized
INFO - 2023-12-06 10:11:05 --> Loader Class Initialized
INFO - 2023-12-06 10:11:05 --> Helper loaded: url_helper
INFO - 2023-12-06 10:11:05 --> Helper loaded: file_helper
INFO - 2023-12-06 10:11:05 --> Helper loaded: form_helper
INFO - 2023-12-06 10:11:05 --> Helper loaded: my_helper
INFO - 2023-12-06 10:11:05 --> Database Driver Class Initialized
INFO - 2023-12-06 10:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:11:05 --> Controller Class Initialized
DEBUG - 2023-12-06 10:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 10:11:11 --> Final output sent to browser
DEBUG - 2023-12-06 10:11:11 --> Total execution time: 5.6373
INFO - 2023-12-06 10:13:26 --> Config Class Initialized
INFO - 2023-12-06 10:13:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:13:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:13:26 --> Utf8 Class Initialized
INFO - 2023-12-06 10:13:26 --> URI Class Initialized
INFO - 2023-12-06 10:13:26 --> Router Class Initialized
INFO - 2023-12-06 10:13:26 --> Output Class Initialized
INFO - 2023-12-06 10:13:26 --> Security Class Initialized
DEBUG - 2023-12-06 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:13:26 --> Input Class Initialized
INFO - 2023-12-06 10:13:26 --> Language Class Initialized
INFO - 2023-12-06 10:13:26 --> Language Class Initialized
INFO - 2023-12-06 10:13:26 --> Config Class Initialized
INFO - 2023-12-06 10:13:26 --> Loader Class Initialized
INFO - 2023-12-06 10:13:26 --> Helper loaded: url_helper
INFO - 2023-12-06 10:13:26 --> Helper loaded: file_helper
INFO - 2023-12-06 10:13:26 --> Helper loaded: form_helper
INFO - 2023-12-06 10:13:26 --> Helper loaded: my_helper
INFO - 2023-12-06 10:13:26 --> Database Driver Class Initialized
INFO - 2023-12-06 10:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:13:26 --> Controller Class Initialized
DEBUG - 2023-12-06 10:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 10:13:31 --> Final output sent to browser
DEBUG - 2023-12-06 10:13:31 --> Total execution time: 5.2390
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:17 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:17 --> URI Class Initialized
INFO - 2023-12-06 10:15:17 --> Router Class Initialized
INFO - 2023-12-06 10:15:17 --> Output Class Initialized
INFO - 2023-12-06 10:15:17 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:17 --> Input Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Loader Class Initialized
INFO - 2023-12-06 10:15:17 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:17 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:17 --> Controller Class Initialized
INFO - 2023-12-06 10:15:17 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:17 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:17 --> URI Class Initialized
INFO - 2023-12-06 10:15:17 --> Router Class Initialized
INFO - 2023-12-06 10:15:17 --> Output Class Initialized
INFO - 2023-12-06 10:15:17 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:17 --> Input Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Loader Class Initialized
INFO - 2023-12-06 10:15:17 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:17 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:17 --> Controller Class Initialized
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:17 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:17 --> URI Class Initialized
INFO - 2023-12-06 10:15:17 --> Router Class Initialized
INFO - 2023-12-06 10:15:17 --> Output Class Initialized
INFO - 2023-12-06 10:15:17 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:17 --> Input Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Language Class Initialized
INFO - 2023-12-06 10:15:17 --> Config Class Initialized
INFO - 2023-12-06 10:15:17 --> Loader Class Initialized
INFO - 2023-12-06 10:15:17 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:17 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:17 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:17 --> Controller Class Initialized
DEBUG - 2023-12-06 10:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 10:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:15:17 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:17 --> Total execution time: 0.0412
INFO - 2023-12-06 10:15:24 --> Config Class Initialized
INFO - 2023-12-06 10:15:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:24 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:24 --> URI Class Initialized
INFO - 2023-12-06 10:15:24 --> Router Class Initialized
INFO - 2023-12-06 10:15:24 --> Output Class Initialized
INFO - 2023-12-06 10:15:24 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:24 --> Input Class Initialized
INFO - 2023-12-06 10:15:24 --> Language Class Initialized
INFO - 2023-12-06 10:15:24 --> Language Class Initialized
INFO - 2023-12-06 10:15:24 --> Config Class Initialized
INFO - 2023-12-06 10:15:24 --> Loader Class Initialized
INFO - 2023-12-06 10:15:24 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:24 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:24 --> Controller Class Initialized
INFO - 2023-12-06 10:15:24 --> Helper loaded: cookie_helper
INFO - 2023-12-06 10:15:24 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:24 --> Total execution time: 0.0406
INFO - 2023-12-06 10:15:24 --> Config Class Initialized
INFO - 2023-12-06 10:15:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:24 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:24 --> URI Class Initialized
INFO - 2023-12-06 10:15:24 --> Router Class Initialized
INFO - 2023-12-06 10:15:24 --> Output Class Initialized
INFO - 2023-12-06 10:15:24 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:24 --> Input Class Initialized
INFO - 2023-12-06 10:15:24 --> Language Class Initialized
INFO - 2023-12-06 10:15:24 --> Language Class Initialized
INFO - 2023-12-06 10:15:24 --> Config Class Initialized
INFO - 2023-12-06 10:15:24 --> Loader Class Initialized
INFO - 2023-12-06 10:15:24 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:24 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:24 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:24 --> Controller Class Initialized
DEBUG - 2023-12-06 10:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 10:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:15:24 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:24 --> Total execution time: 0.0392
INFO - 2023-12-06 10:15:28 --> Config Class Initialized
INFO - 2023-12-06 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:28 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:28 --> URI Class Initialized
INFO - 2023-12-06 10:15:28 --> Router Class Initialized
INFO - 2023-12-06 10:15:28 --> Output Class Initialized
INFO - 2023-12-06 10:15:28 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:28 --> Input Class Initialized
INFO - 2023-12-06 10:15:28 --> Language Class Initialized
INFO - 2023-12-06 10:15:28 --> Language Class Initialized
INFO - 2023-12-06 10:15:28 --> Config Class Initialized
INFO - 2023-12-06 10:15:28 --> Loader Class Initialized
INFO - 2023-12-06 10:15:28 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:28 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:28 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:28 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:28 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:28 --> Controller Class Initialized
DEBUG - 2023-12-06 10:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 10:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 10:15:28 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:28 --> Total execution time: 0.0759
INFO - 2023-12-06 10:15:34 --> Config Class Initialized
INFO - 2023-12-06 10:15:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:34 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:34 --> URI Class Initialized
INFO - 2023-12-06 10:15:34 --> Router Class Initialized
INFO - 2023-12-06 10:15:34 --> Output Class Initialized
INFO - 2023-12-06 10:15:34 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:34 --> Input Class Initialized
INFO - 2023-12-06 10:15:34 --> Language Class Initialized
INFO - 2023-12-06 10:15:34 --> Language Class Initialized
INFO - 2023-12-06 10:15:34 --> Config Class Initialized
INFO - 2023-12-06 10:15:34 --> Loader Class Initialized
INFO - 2023-12-06 10:15:34 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:34 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:34 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:34 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:34 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:34 --> Controller Class Initialized
ERROR - 2023-12-06 10:15:34 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-06 10:15:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-06 10:15:38 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:38 --> Total execution time: 4.4316
INFO - 2023-12-06 10:15:39 --> Config Class Initialized
INFO - 2023-12-06 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:15:39 --> Utf8 Class Initialized
INFO - 2023-12-06 10:15:39 --> URI Class Initialized
INFO - 2023-12-06 10:15:39 --> Router Class Initialized
INFO - 2023-12-06 10:15:39 --> Output Class Initialized
INFO - 2023-12-06 10:15:39 --> Security Class Initialized
DEBUG - 2023-12-06 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:15:39 --> Input Class Initialized
INFO - 2023-12-06 10:15:39 --> Language Class Initialized
INFO - 2023-12-06 10:15:39 --> Language Class Initialized
INFO - 2023-12-06 10:15:39 --> Config Class Initialized
INFO - 2023-12-06 10:15:39 --> Loader Class Initialized
INFO - 2023-12-06 10:15:39 --> Helper loaded: url_helper
INFO - 2023-12-06 10:15:39 --> Helper loaded: file_helper
INFO - 2023-12-06 10:15:39 --> Helper loaded: form_helper
INFO - 2023-12-06 10:15:39 --> Helper loaded: my_helper
INFO - 2023-12-06 10:15:39 --> Database Driver Class Initialized
INFO - 2023-12-06 10:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:15:39 --> Controller Class Initialized
DEBUG - 2023-12-06 10:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-06 10:15:42 --> Final output sent to browser
DEBUG - 2023-12-06 10:15:42 --> Total execution time: 2.8309
INFO - 2023-12-06 10:16:07 --> Config Class Initialized
INFO - 2023-12-06 10:16:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:16:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:16:07 --> Utf8 Class Initialized
INFO - 2023-12-06 10:16:07 --> URI Class Initialized
INFO - 2023-12-06 10:16:07 --> Router Class Initialized
INFO - 2023-12-06 10:16:07 --> Output Class Initialized
INFO - 2023-12-06 10:16:07 --> Security Class Initialized
DEBUG - 2023-12-06 10:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:16:07 --> Input Class Initialized
INFO - 2023-12-06 10:16:07 --> Language Class Initialized
INFO - 2023-12-06 10:16:07 --> Language Class Initialized
INFO - 2023-12-06 10:16:07 --> Config Class Initialized
INFO - 2023-12-06 10:16:07 --> Loader Class Initialized
INFO - 2023-12-06 10:16:07 --> Helper loaded: url_helper
INFO - 2023-12-06 10:16:07 --> Helper loaded: file_helper
INFO - 2023-12-06 10:16:07 --> Helper loaded: form_helper
INFO - 2023-12-06 10:16:07 --> Helper loaded: my_helper
INFO - 2023-12-06 10:16:07 --> Database Driver Class Initialized
INFO - 2023-12-06 10:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:16:07 --> Controller Class Initialized
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3154
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3154
ERROR - 2023-12-06 10:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3154
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2023-12-06 10:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
ERROR - 2023-12-06 10:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
ERROR - 2023-12-06 10:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
DEBUG - 2023-12-06 10:16:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-06 10:16:10 --> Config Class Initialized
INFO - 2023-12-06 10:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 10:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 10:16:10 --> Utf8 Class Initialized
INFO - 2023-12-06 10:16:10 --> URI Class Initialized
INFO - 2023-12-06 10:16:10 --> Router Class Initialized
INFO - 2023-12-06 10:16:10 --> Output Class Initialized
INFO - 2023-12-06 10:16:10 --> Security Class Initialized
DEBUG - 2023-12-06 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 10:16:10 --> Input Class Initialized
INFO - 2023-12-06 10:16:10 --> Language Class Initialized
INFO - 2023-12-06 10:16:10 --> Language Class Initialized
INFO - 2023-12-06 10:16:10 --> Config Class Initialized
INFO - 2023-12-06 10:16:10 --> Loader Class Initialized
INFO - 2023-12-06 10:16:10 --> Helper loaded: url_helper
INFO - 2023-12-06 10:16:10 --> Helper loaded: file_helper
INFO - 2023-12-06 10:16:10 --> Helper loaded: form_helper
INFO - 2023-12-06 10:16:10 --> Helper loaded: my_helper
INFO - 2023-12-06 10:16:10 --> Database Driver Class Initialized
INFO - 2023-12-06 10:16:13 --> Final output sent to browser
DEBUG - 2023-12-06 10:16:13 --> Total execution time: 6.3781
INFO - 2023-12-06 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 10:16:13 --> Controller Class Initialized
DEBUG - 2023-12-06 10:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 10:16:19 --> Final output sent to browser
DEBUG - 2023-12-06 10:16:19 --> Total execution time: 9.0717
INFO - 2023-12-06 11:07:57 --> Config Class Initialized
INFO - 2023-12-06 11:07:57 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:07:57 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:07:57 --> Utf8 Class Initialized
INFO - 2023-12-06 11:07:57 --> URI Class Initialized
INFO - 2023-12-06 11:07:57 --> Router Class Initialized
INFO - 2023-12-06 11:07:57 --> Output Class Initialized
INFO - 2023-12-06 11:07:57 --> Security Class Initialized
DEBUG - 2023-12-06 11:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:07:57 --> Input Class Initialized
INFO - 2023-12-06 11:07:57 --> Language Class Initialized
INFO - 2023-12-06 11:07:57 --> Language Class Initialized
INFO - 2023-12-06 11:07:57 --> Config Class Initialized
INFO - 2023-12-06 11:07:57 --> Loader Class Initialized
INFO - 2023-12-06 11:07:57 --> Helper loaded: url_helper
INFO - 2023-12-06 11:07:57 --> Helper loaded: file_helper
INFO - 2023-12-06 11:07:57 --> Helper loaded: form_helper
INFO - 2023-12-06 11:07:57 --> Helper loaded: my_helper
INFO - 2023-12-06 11:07:57 --> Database Driver Class Initialized
INFO - 2023-12-06 11:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:07:57 --> Controller Class Initialized
DEBUG - 2023-12-06 11:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 11:07:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:07:57 --> Final output sent to browser
DEBUG - 2023-12-06 11:07:57 --> Total execution time: 0.0495
INFO - 2023-12-06 11:08:02 --> Config Class Initialized
INFO - 2023-12-06 11:08:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:08:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:08:02 --> Utf8 Class Initialized
INFO - 2023-12-06 11:08:02 --> URI Class Initialized
INFO - 2023-12-06 11:08:02 --> Router Class Initialized
INFO - 2023-12-06 11:08:02 --> Output Class Initialized
INFO - 2023-12-06 11:08:02 --> Security Class Initialized
DEBUG - 2023-12-06 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:08:02 --> Input Class Initialized
INFO - 2023-12-06 11:08:02 --> Language Class Initialized
INFO - 2023-12-06 11:08:02 --> Language Class Initialized
INFO - 2023-12-06 11:08:02 --> Config Class Initialized
INFO - 2023-12-06 11:08:02 --> Loader Class Initialized
INFO - 2023-12-06 11:08:02 --> Helper loaded: url_helper
INFO - 2023-12-06 11:08:02 --> Helper loaded: file_helper
INFO - 2023-12-06 11:08:02 --> Helper loaded: form_helper
INFO - 2023-12-06 11:08:02 --> Helper loaded: my_helper
INFO - 2023-12-06 11:08:02 --> Database Driver Class Initialized
INFO - 2023-12-06 11:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:08:02 --> Controller Class Initialized
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 11:08:02 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 11:08:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 11:08:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:08:02 --> Final output sent to browser
DEBUG - 2023-12-06 11:08:02 --> Total execution time: 0.2682
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:09:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:09:13 --> Utf8 Class Initialized
INFO - 2023-12-06 11:09:13 --> URI Class Initialized
INFO - 2023-12-06 11:09:13 --> Router Class Initialized
INFO - 2023-12-06 11:09:13 --> Output Class Initialized
INFO - 2023-12-06 11:09:13 --> Security Class Initialized
DEBUG - 2023-12-06 11:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:09:13 --> Input Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Loader Class Initialized
INFO - 2023-12-06 11:09:13 --> Helper loaded: url_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: file_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: form_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: my_helper
INFO - 2023-12-06 11:09:13 --> Database Driver Class Initialized
INFO - 2023-12-06 11:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:09:13 --> Controller Class Initialized
INFO - 2023-12-06 11:09:13 --> Helper loaded: cookie_helper
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:09:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:09:13 --> Utf8 Class Initialized
INFO - 2023-12-06 11:09:13 --> URI Class Initialized
INFO - 2023-12-06 11:09:13 --> Router Class Initialized
INFO - 2023-12-06 11:09:13 --> Output Class Initialized
INFO - 2023-12-06 11:09:13 --> Security Class Initialized
DEBUG - 2023-12-06 11:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:09:13 --> Input Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Loader Class Initialized
INFO - 2023-12-06 11:09:13 --> Helper loaded: url_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: file_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: form_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: my_helper
INFO - 2023-12-06 11:09:13 --> Database Driver Class Initialized
INFO - 2023-12-06 11:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:09:13 --> Controller Class Initialized
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:09:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:09:13 --> Utf8 Class Initialized
INFO - 2023-12-06 11:09:13 --> URI Class Initialized
INFO - 2023-12-06 11:09:13 --> Router Class Initialized
INFO - 2023-12-06 11:09:13 --> Output Class Initialized
INFO - 2023-12-06 11:09:13 --> Security Class Initialized
DEBUG - 2023-12-06 11:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:09:13 --> Input Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Language Class Initialized
INFO - 2023-12-06 11:09:13 --> Config Class Initialized
INFO - 2023-12-06 11:09:13 --> Loader Class Initialized
INFO - 2023-12-06 11:09:13 --> Helper loaded: url_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: file_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: form_helper
INFO - 2023-12-06 11:09:13 --> Helper loaded: my_helper
INFO - 2023-12-06 11:09:13 --> Database Driver Class Initialized
INFO - 2023-12-06 11:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:09:13 --> Controller Class Initialized
DEBUG - 2023-12-06 11:09:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 11:09:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:09:13 --> Final output sent to browser
DEBUG - 2023-12-06 11:09:13 --> Total execution time: 0.0354
INFO - 2023-12-06 11:14:53 --> Config Class Initialized
INFO - 2023-12-06 11:14:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:14:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:14:53 --> Utf8 Class Initialized
INFO - 2023-12-06 11:14:53 --> URI Class Initialized
INFO - 2023-12-06 11:14:53 --> Router Class Initialized
INFO - 2023-12-06 11:14:53 --> Output Class Initialized
INFO - 2023-12-06 11:14:53 --> Security Class Initialized
DEBUG - 2023-12-06 11:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:14:53 --> Input Class Initialized
INFO - 2023-12-06 11:14:53 --> Language Class Initialized
INFO - 2023-12-06 11:14:53 --> Language Class Initialized
INFO - 2023-12-06 11:14:53 --> Config Class Initialized
INFO - 2023-12-06 11:14:53 --> Loader Class Initialized
INFO - 2023-12-06 11:14:53 --> Helper loaded: url_helper
INFO - 2023-12-06 11:14:53 --> Helper loaded: file_helper
INFO - 2023-12-06 11:14:53 --> Helper loaded: form_helper
INFO - 2023-12-06 11:14:53 --> Helper loaded: my_helper
INFO - 2023-12-06 11:14:53 --> Database Driver Class Initialized
INFO - 2023-12-06 11:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:14:53 --> Controller Class Initialized
DEBUG - 2023-12-06 11:14:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-06 11:14:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:14:53 --> Final output sent to browser
DEBUG - 2023-12-06 11:14:53 --> Total execution time: 0.0602
INFO - 2023-12-06 11:17:20 --> Config Class Initialized
INFO - 2023-12-06 11:17:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:20 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:20 --> URI Class Initialized
INFO - 2023-12-06 11:17:20 --> Router Class Initialized
INFO - 2023-12-06 11:17:20 --> Output Class Initialized
INFO - 2023-12-06 11:17:20 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:20 --> Input Class Initialized
INFO - 2023-12-06 11:17:20 --> Language Class Initialized
INFO - 2023-12-06 11:17:20 --> Language Class Initialized
INFO - 2023-12-06 11:17:20 --> Config Class Initialized
INFO - 2023-12-06 11:17:20 --> Loader Class Initialized
INFO - 2023-12-06 11:17:20 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:20 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:20 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:20 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:20 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:20 --> Controller Class Initialized
INFO - 2023-12-06 11:17:20 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:20 --> Total execution time: 0.0694
INFO - 2023-12-06 11:17:35 --> Config Class Initialized
INFO - 2023-12-06 11:17:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:35 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:35 --> URI Class Initialized
INFO - 2023-12-06 11:17:35 --> Router Class Initialized
INFO - 2023-12-06 11:17:35 --> Output Class Initialized
INFO - 2023-12-06 11:17:35 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:35 --> Input Class Initialized
INFO - 2023-12-06 11:17:35 --> Language Class Initialized
INFO - 2023-12-06 11:17:35 --> Language Class Initialized
INFO - 2023-12-06 11:17:35 --> Config Class Initialized
INFO - 2023-12-06 11:17:35 --> Loader Class Initialized
INFO - 2023-12-06 11:17:35 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:35 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:35 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:35 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:35 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:35 --> Controller Class Initialized
INFO - 2023-12-06 11:17:35 --> Helper loaded: cookie_helper
INFO - 2023-12-06 11:17:36 --> Config Class Initialized
INFO - 2023-12-06 11:17:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:36 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:36 --> URI Class Initialized
INFO - 2023-12-06 11:17:36 --> Router Class Initialized
INFO - 2023-12-06 11:17:36 --> Output Class Initialized
INFO - 2023-12-06 11:17:36 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:36 --> Input Class Initialized
INFO - 2023-12-06 11:17:36 --> Language Class Initialized
INFO - 2023-12-06 11:17:36 --> Language Class Initialized
INFO - 2023-12-06 11:17:36 --> Config Class Initialized
INFO - 2023-12-06 11:17:36 --> Loader Class Initialized
INFO - 2023-12-06 11:17:36 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:36 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:36 --> Controller Class Initialized
INFO - 2023-12-06 11:17:36 --> Config Class Initialized
INFO - 2023-12-06 11:17:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:36 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:36 --> URI Class Initialized
INFO - 2023-12-06 11:17:36 --> Router Class Initialized
INFO - 2023-12-06 11:17:36 --> Output Class Initialized
INFO - 2023-12-06 11:17:36 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:36 --> Input Class Initialized
INFO - 2023-12-06 11:17:36 --> Language Class Initialized
INFO - 2023-12-06 11:17:36 --> Language Class Initialized
INFO - 2023-12-06 11:17:36 --> Config Class Initialized
INFO - 2023-12-06 11:17:36 --> Loader Class Initialized
INFO - 2023-12-06 11:17:36 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:36 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:36 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:36 --> Controller Class Initialized
DEBUG - 2023-12-06 11:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 11:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:17:36 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:36 --> Total execution time: 0.0870
INFO - 2023-12-06 11:17:40 --> Config Class Initialized
INFO - 2023-12-06 11:17:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:40 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:40 --> URI Class Initialized
INFO - 2023-12-06 11:17:40 --> Router Class Initialized
INFO - 2023-12-06 11:17:40 --> Output Class Initialized
INFO - 2023-12-06 11:17:40 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:40 --> Input Class Initialized
INFO - 2023-12-06 11:17:40 --> Language Class Initialized
INFO - 2023-12-06 11:17:40 --> Language Class Initialized
INFO - 2023-12-06 11:17:40 --> Config Class Initialized
INFO - 2023-12-06 11:17:40 --> Loader Class Initialized
INFO - 2023-12-06 11:17:40 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:40 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:40 --> Controller Class Initialized
INFO - 2023-12-06 11:17:40 --> Helper loaded: cookie_helper
INFO - 2023-12-06 11:17:40 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:40 --> Total execution time: 0.0549
INFO - 2023-12-06 11:17:40 --> Config Class Initialized
INFO - 2023-12-06 11:17:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:40 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:40 --> URI Class Initialized
INFO - 2023-12-06 11:17:40 --> Router Class Initialized
INFO - 2023-12-06 11:17:40 --> Output Class Initialized
INFO - 2023-12-06 11:17:40 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:40 --> Input Class Initialized
INFO - 2023-12-06 11:17:40 --> Language Class Initialized
INFO - 2023-12-06 11:17:40 --> Language Class Initialized
INFO - 2023-12-06 11:17:40 --> Config Class Initialized
INFO - 2023-12-06 11:17:40 --> Loader Class Initialized
INFO - 2023-12-06 11:17:40 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:40 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:40 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:40 --> Controller Class Initialized
DEBUG - 2023-12-06 11:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 11:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:17:40 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:40 --> Total execution time: 0.0380
INFO - 2023-12-06 11:17:52 --> Config Class Initialized
INFO - 2023-12-06 11:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:52 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:52 --> URI Class Initialized
INFO - 2023-12-06 11:17:52 --> Router Class Initialized
INFO - 2023-12-06 11:17:52 --> Output Class Initialized
INFO - 2023-12-06 11:17:52 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:52 --> Input Class Initialized
INFO - 2023-12-06 11:17:52 --> Language Class Initialized
INFO - 2023-12-06 11:17:52 --> Language Class Initialized
INFO - 2023-12-06 11:17:52 --> Config Class Initialized
INFO - 2023-12-06 11:17:52 --> Loader Class Initialized
INFO - 2023-12-06 11:17:52 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:52 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:52 --> Controller Class Initialized
DEBUG - 2023-12-06 11:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-12-06 11:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:17:52 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:52 --> Total execution time: 0.0596
INFO - 2023-12-06 11:17:52 --> Config Class Initialized
INFO - 2023-12-06 11:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:52 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:52 --> URI Class Initialized
INFO - 2023-12-06 11:17:52 --> Router Class Initialized
INFO - 2023-12-06 11:17:52 --> Output Class Initialized
INFO - 2023-12-06 11:17:52 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:52 --> Input Class Initialized
INFO - 2023-12-06 11:17:52 --> Language Class Initialized
ERROR - 2023-12-06 11:17:52 --> 404 Page Not Found: /index
INFO - 2023-12-06 11:17:52 --> Config Class Initialized
INFO - 2023-12-06 11:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:52 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:52 --> URI Class Initialized
INFO - 2023-12-06 11:17:52 --> Router Class Initialized
INFO - 2023-12-06 11:17:52 --> Output Class Initialized
INFO - 2023-12-06 11:17:52 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:52 --> Input Class Initialized
INFO - 2023-12-06 11:17:52 --> Language Class Initialized
INFO - 2023-12-06 11:17:52 --> Language Class Initialized
INFO - 2023-12-06 11:17:52 --> Config Class Initialized
INFO - 2023-12-06 11:17:52 --> Loader Class Initialized
INFO - 2023-12-06 11:17:52 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:52 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:52 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:52 --> Controller Class Initialized
INFO - 2023-12-06 11:17:55 --> Config Class Initialized
INFO - 2023-12-06 11:17:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:17:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:17:55 --> Utf8 Class Initialized
INFO - 2023-12-06 11:17:55 --> URI Class Initialized
INFO - 2023-12-06 11:17:55 --> Router Class Initialized
INFO - 2023-12-06 11:17:55 --> Output Class Initialized
INFO - 2023-12-06 11:17:55 --> Security Class Initialized
DEBUG - 2023-12-06 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:17:55 --> Input Class Initialized
INFO - 2023-12-06 11:17:55 --> Language Class Initialized
INFO - 2023-12-06 11:17:55 --> Language Class Initialized
INFO - 2023-12-06 11:17:55 --> Config Class Initialized
INFO - 2023-12-06 11:17:55 --> Loader Class Initialized
INFO - 2023-12-06 11:17:55 --> Helper loaded: url_helper
INFO - 2023-12-06 11:17:55 --> Helper loaded: file_helper
INFO - 2023-12-06 11:17:55 --> Helper loaded: form_helper
INFO - 2023-12-06 11:17:55 --> Helper loaded: my_helper
INFO - 2023-12-06 11:17:55 --> Database Driver Class Initialized
INFO - 2023-12-06 11:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:17:55 --> Controller Class Initialized
INFO - 2023-12-06 11:17:55 --> Final output sent to browser
DEBUG - 2023-12-06 11:17:55 --> Total execution time: 0.0480
INFO - 2023-12-06 11:18:01 --> Config Class Initialized
INFO - 2023-12-06 11:18:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:01 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:01 --> URI Class Initialized
INFO - 2023-12-06 11:18:01 --> Router Class Initialized
INFO - 2023-12-06 11:18:01 --> Output Class Initialized
INFO - 2023-12-06 11:18:01 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:01 --> Input Class Initialized
INFO - 2023-12-06 11:18:01 --> Language Class Initialized
INFO - 2023-12-06 11:18:01 --> Language Class Initialized
INFO - 2023-12-06 11:18:01 --> Config Class Initialized
INFO - 2023-12-06 11:18:01 --> Loader Class Initialized
INFO - 2023-12-06 11:18:01 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:01 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:01 --> Controller Class Initialized
INFO - 2023-12-06 11:18:01 --> Final output sent to browser
DEBUG - 2023-12-06 11:18:01 --> Total execution time: 0.0386
INFO - 2023-12-06 11:18:01 --> Config Class Initialized
INFO - 2023-12-06 11:18:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:01 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:01 --> URI Class Initialized
INFO - 2023-12-06 11:18:01 --> Router Class Initialized
INFO - 2023-12-06 11:18:01 --> Output Class Initialized
INFO - 2023-12-06 11:18:01 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:01 --> Input Class Initialized
INFO - 2023-12-06 11:18:01 --> Language Class Initialized
ERROR - 2023-12-06 11:18:01 --> 404 Page Not Found: /index
INFO - 2023-12-06 11:18:01 --> Config Class Initialized
INFO - 2023-12-06 11:18:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:01 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:01 --> URI Class Initialized
INFO - 2023-12-06 11:18:01 --> Router Class Initialized
INFO - 2023-12-06 11:18:01 --> Output Class Initialized
INFO - 2023-12-06 11:18:01 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:01 --> Input Class Initialized
INFO - 2023-12-06 11:18:01 --> Language Class Initialized
INFO - 2023-12-06 11:18:01 --> Language Class Initialized
INFO - 2023-12-06 11:18:01 --> Config Class Initialized
INFO - 2023-12-06 11:18:01 --> Loader Class Initialized
INFO - 2023-12-06 11:18:01 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:01 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:01 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:01 --> Controller Class Initialized
INFO - 2023-12-06 11:18:07 --> Config Class Initialized
INFO - 2023-12-06 11:18:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:07 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:07 --> URI Class Initialized
INFO - 2023-12-06 11:18:07 --> Router Class Initialized
INFO - 2023-12-06 11:18:07 --> Output Class Initialized
INFO - 2023-12-06 11:18:07 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:07 --> Input Class Initialized
INFO - 2023-12-06 11:18:07 --> Language Class Initialized
INFO - 2023-12-06 11:18:07 --> Language Class Initialized
INFO - 2023-12-06 11:18:07 --> Config Class Initialized
INFO - 2023-12-06 11:18:07 --> Loader Class Initialized
INFO - 2023-12-06 11:18:07 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:07 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:07 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:07 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:07 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:07 --> Controller Class Initialized
INFO - 2023-12-06 11:18:07 --> Helper loaded: cookie_helper
INFO - 2023-12-06 11:18:08 --> Config Class Initialized
INFO - 2023-12-06 11:18:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:08 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:08 --> URI Class Initialized
INFO - 2023-12-06 11:18:08 --> Router Class Initialized
INFO - 2023-12-06 11:18:08 --> Output Class Initialized
INFO - 2023-12-06 11:18:08 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:08 --> Input Class Initialized
INFO - 2023-12-06 11:18:08 --> Language Class Initialized
INFO - 2023-12-06 11:18:08 --> Language Class Initialized
INFO - 2023-12-06 11:18:08 --> Config Class Initialized
INFO - 2023-12-06 11:18:08 --> Loader Class Initialized
INFO - 2023-12-06 11:18:08 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:08 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:08 --> Controller Class Initialized
INFO - 2023-12-06 11:18:08 --> Config Class Initialized
INFO - 2023-12-06 11:18:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:08 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:08 --> URI Class Initialized
INFO - 2023-12-06 11:18:08 --> Router Class Initialized
INFO - 2023-12-06 11:18:08 --> Output Class Initialized
INFO - 2023-12-06 11:18:08 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:08 --> Input Class Initialized
INFO - 2023-12-06 11:18:08 --> Language Class Initialized
INFO - 2023-12-06 11:18:08 --> Language Class Initialized
INFO - 2023-12-06 11:18:08 --> Config Class Initialized
INFO - 2023-12-06 11:18:08 --> Loader Class Initialized
INFO - 2023-12-06 11:18:08 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:08 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:08 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:08 --> Controller Class Initialized
DEBUG - 2023-12-06 11:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 11:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:18:08 --> Final output sent to browser
DEBUG - 2023-12-06 11:18:08 --> Total execution time: 0.0727
INFO - 2023-12-06 11:18:13 --> Config Class Initialized
INFO - 2023-12-06 11:18:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:13 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:13 --> URI Class Initialized
INFO - 2023-12-06 11:18:13 --> Router Class Initialized
INFO - 2023-12-06 11:18:13 --> Output Class Initialized
INFO - 2023-12-06 11:18:13 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:13 --> Input Class Initialized
INFO - 2023-12-06 11:18:13 --> Language Class Initialized
INFO - 2023-12-06 11:18:13 --> Language Class Initialized
INFO - 2023-12-06 11:18:13 --> Config Class Initialized
INFO - 2023-12-06 11:18:13 --> Loader Class Initialized
INFO - 2023-12-06 11:18:13 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:13 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:13 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:13 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:13 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:14 --> Controller Class Initialized
INFO - 2023-12-06 11:18:14 --> Helper loaded: cookie_helper
INFO - 2023-12-06 11:18:14 --> Final output sent to browser
DEBUG - 2023-12-06 11:18:14 --> Total execution time: 0.0356
INFO - 2023-12-06 11:18:14 --> Config Class Initialized
INFO - 2023-12-06 11:18:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:14 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:14 --> URI Class Initialized
INFO - 2023-12-06 11:18:14 --> Router Class Initialized
INFO - 2023-12-06 11:18:14 --> Output Class Initialized
INFO - 2023-12-06 11:18:14 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:14 --> Input Class Initialized
INFO - 2023-12-06 11:18:14 --> Language Class Initialized
INFO - 2023-12-06 11:18:14 --> Language Class Initialized
INFO - 2023-12-06 11:18:14 --> Config Class Initialized
INFO - 2023-12-06 11:18:14 --> Loader Class Initialized
INFO - 2023-12-06 11:18:14 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:14 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:14 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:14 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:14 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:14 --> Controller Class Initialized
DEBUG - 2023-12-06 11:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 11:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:18:14 --> Final output sent to browser
DEBUG - 2023-12-06 11:18:14 --> Total execution time: 0.0606
INFO - 2023-12-06 11:18:46 --> Config Class Initialized
INFO - 2023-12-06 11:18:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 11:18:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 11:18:46 --> Utf8 Class Initialized
INFO - 2023-12-06 11:18:46 --> URI Class Initialized
INFO - 2023-12-06 11:18:46 --> Router Class Initialized
INFO - 2023-12-06 11:18:46 --> Output Class Initialized
INFO - 2023-12-06 11:18:46 --> Security Class Initialized
DEBUG - 2023-12-06 11:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 11:18:46 --> Input Class Initialized
INFO - 2023-12-06 11:18:46 --> Language Class Initialized
INFO - 2023-12-06 11:18:46 --> Language Class Initialized
INFO - 2023-12-06 11:18:46 --> Config Class Initialized
INFO - 2023-12-06 11:18:46 --> Loader Class Initialized
INFO - 2023-12-06 11:18:46 --> Helper loaded: url_helper
INFO - 2023-12-06 11:18:46 --> Helper loaded: file_helper
INFO - 2023-12-06 11:18:46 --> Helper loaded: form_helper
INFO - 2023-12-06 11:18:46 --> Helper loaded: my_helper
INFO - 2023-12-06 11:18:46 --> Database Driver Class Initialized
INFO - 2023-12-06 11:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 11:18:46 --> Controller Class Initialized
DEBUG - 2023-12-06 11:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-06 11:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 11:18:46 --> Final output sent to browser
DEBUG - 2023-12-06 11:18:46 --> Total execution time: 0.0449
INFO - 2023-12-06 13:59:14 --> Config Class Initialized
INFO - 2023-12-06 13:59:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:14 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:14 --> URI Class Initialized
DEBUG - 2023-12-06 13:59:14 --> No URI present. Default controller set.
INFO - 2023-12-06 13:59:14 --> Router Class Initialized
INFO - 2023-12-06 13:59:14 --> Output Class Initialized
INFO - 2023-12-06 13:59:14 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:14 --> Input Class Initialized
INFO - 2023-12-06 13:59:14 --> Language Class Initialized
INFO - 2023-12-06 13:59:14 --> Language Class Initialized
INFO - 2023-12-06 13:59:14 --> Config Class Initialized
INFO - 2023-12-06 13:59:14 --> Loader Class Initialized
INFO - 2023-12-06 13:59:14 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:14 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:14 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:14 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:14 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:14 --> Controller Class Initialized
DEBUG - 2023-12-06 13:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 13:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 13:59:14 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:14 --> Total execution time: 0.0804
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:19 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:19 --> URI Class Initialized
INFO - 2023-12-06 13:59:19 --> Router Class Initialized
INFO - 2023-12-06 13:59:19 --> Output Class Initialized
INFO - 2023-12-06 13:59:19 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:19 --> Input Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Loader Class Initialized
INFO - 2023-12-06 13:59:19 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:19 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:19 --> Controller Class Initialized
INFO - 2023-12-06 13:59:19 --> Helper loaded: cookie_helper
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:19 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:19 --> URI Class Initialized
INFO - 2023-12-06 13:59:19 --> Router Class Initialized
INFO - 2023-12-06 13:59:19 --> Output Class Initialized
INFO - 2023-12-06 13:59:19 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:19 --> Input Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Loader Class Initialized
INFO - 2023-12-06 13:59:19 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:19 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:19 --> Controller Class Initialized
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:19 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:19 --> URI Class Initialized
INFO - 2023-12-06 13:59:19 --> Router Class Initialized
INFO - 2023-12-06 13:59:19 --> Output Class Initialized
INFO - 2023-12-06 13:59:19 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:19 --> Input Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Language Class Initialized
INFO - 2023-12-06 13:59:19 --> Config Class Initialized
INFO - 2023-12-06 13:59:19 --> Loader Class Initialized
INFO - 2023-12-06 13:59:19 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:19 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:19 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:19 --> Controller Class Initialized
DEBUG - 2023-12-06 13:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 13:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 13:59:19 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:19 --> Total execution time: 0.0554
INFO - 2023-12-06 13:59:24 --> Config Class Initialized
INFO - 2023-12-06 13:59:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:24 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:24 --> URI Class Initialized
INFO - 2023-12-06 13:59:24 --> Router Class Initialized
INFO - 2023-12-06 13:59:24 --> Output Class Initialized
INFO - 2023-12-06 13:59:24 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:24 --> Input Class Initialized
INFO - 2023-12-06 13:59:24 --> Language Class Initialized
INFO - 2023-12-06 13:59:24 --> Language Class Initialized
INFO - 2023-12-06 13:59:24 --> Config Class Initialized
INFO - 2023-12-06 13:59:24 --> Loader Class Initialized
INFO - 2023-12-06 13:59:24 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:24 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:24 --> Controller Class Initialized
INFO - 2023-12-06 13:59:24 --> Helper loaded: cookie_helper
INFO - 2023-12-06 13:59:24 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:24 --> Total execution time: 0.0338
INFO - 2023-12-06 13:59:24 --> Config Class Initialized
INFO - 2023-12-06 13:59:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:24 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:24 --> URI Class Initialized
INFO - 2023-12-06 13:59:24 --> Router Class Initialized
INFO - 2023-12-06 13:59:24 --> Output Class Initialized
INFO - 2023-12-06 13:59:24 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:24 --> Input Class Initialized
INFO - 2023-12-06 13:59:24 --> Language Class Initialized
INFO - 2023-12-06 13:59:24 --> Language Class Initialized
INFO - 2023-12-06 13:59:24 --> Config Class Initialized
INFO - 2023-12-06 13:59:24 --> Loader Class Initialized
INFO - 2023-12-06 13:59:24 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:24 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:24 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:24 --> Controller Class Initialized
DEBUG - 2023-12-06 13:59:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 13:59:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 13:59:24 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:24 --> Total execution time: 0.0372
INFO - 2023-12-06 13:59:28 --> Config Class Initialized
INFO - 2023-12-06 13:59:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:28 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:28 --> URI Class Initialized
INFO - 2023-12-06 13:59:28 --> Router Class Initialized
INFO - 2023-12-06 13:59:28 --> Output Class Initialized
INFO - 2023-12-06 13:59:28 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:28 --> Input Class Initialized
INFO - 2023-12-06 13:59:28 --> Language Class Initialized
INFO - 2023-12-06 13:59:28 --> Language Class Initialized
INFO - 2023-12-06 13:59:28 --> Config Class Initialized
INFO - 2023-12-06 13:59:28 --> Loader Class Initialized
INFO - 2023-12-06 13:59:28 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:28 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:28 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:28 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:28 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:28 --> Controller Class Initialized
DEBUG - 2023-12-06 13:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 13:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 13:59:28 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:28 --> Total execution time: 0.0399
INFO - 2023-12-06 13:59:32 --> Config Class Initialized
INFO - 2023-12-06 13:59:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:32 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:32 --> URI Class Initialized
INFO - 2023-12-06 13:59:32 --> Router Class Initialized
INFO - 2023-12-06 13:59:32 --> Output Class Initialized
INFO - 2023-12-06 13:59:32 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:32 --> Input Class Initialized
INFO - 2023-12-06 13:59:32 --> Language Class Initialized
INFO - 2023-12-06 13:59:32 --> Language Class Initialized
INFO - 2023-12-06 13:59:32 --> Config Class Initialized
INFO - 2023-12-06 13:59:32 --> Loader Class Initialized
INFO - 2023-12-06 13:59:32 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:32 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:32 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:32 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:32 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:32 --> Controller Class Initialized
DEBUG - 2023-12-06 13:59:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-06 13:59:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 13:59:32 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:32 --> Total execution time: 0.0512
INFO - 2023-12-06 13:59:38 --> Config Class Initialized
INFO - 2023-12-06 13:59:38 --> Hooks Class Initialized
DEBUG - 2023-12-06 13:59:38 --> UTF-8 Support Enabled
INFO - 2023-12-06 13:59:38 --> Utf8 Class Initialized
INFO - 2023-12-06 13:59:38 --> URI Class Initialized
INFO - 2023-12-06 13:59:38 --> Router Class Initialized
INFO - 2023-12-06 13:59:38 --> Output Class Initialized
INFO - 2023-12-06 13:59:38 --> Security Class Initialized
DEBUG - 2023-12-06 13:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 13:59:38 --> Input Class Initialized
INFO - 2023-12-06 13:59:38 --> Language Class Initialized
INFO - 2023-12-06 13:59:38 --> Language Class Initialized
INFO - 2023-12-06 13:59:38 --> Config Class Initialized
INFO - 2023-12-06 13:59:38 --> Loader Class Initialized
INFO - 2023-12-06 13:59:38 --> Helper loaded: url_helper
INFO - 2023-12-06 13:59:38 --> Helper loaded: file_helper
INFO - 2023-12-06 13:59:38 --> Helper loaded: form_helper
INFO - 2023-12-06 13:59:38 --> Helper loaded: my_helper
INFO - 2023-12-06 13:59:38 --> Database Driver Class Initialized
INFO - 2023-12-06 13:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 13:59:38 --> Controller Class Initialized
INFO - 2023-12-06 13:59:38 --> Final output sent to browser
DEBUG - 2023-12-06 13:59:38 --> Total execution time: 0.0388
INFO - 2023-12-06 16:15:46 --> Config Class Initialized
INFO - 2023-12-06 16:15:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:15:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:15:46 --> Utf8 Class Initialized
INFO - 2023-12-06 16:15:46 --> URI Class Initialized
INFO - 2023-12-06 16:15:46 --> Router Class Initialized
INFO - 2023-12-06 16:15:46 --> Output Class Initialized
INFO - 2023-12-06 16:15:46 --> Security Class Initialized
DEBUG - 2023-12-06 16:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:15:46 --> Input Class Initialized
INFO - 2023-12-06 16:15:46 --> Language Class Initialized
INFO - 2023-12-06 16:15:46 --> Language Class Initialized
INFO - 2023-12-06 16:15:46 --> Config Class Initialized
INFO - 2023-12-06 16:15:46 --> Loader Class Initialized
INFO - 2023-12-06 16:15:46 --> Helper loaded: url_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: file_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: form_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: my_helper
INFO - 2023-12-06 16:15:46 --> Database Driver Class Initialized
INFO - 2023-12-06 16:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:15:46 --> Controller Class Initialized
INFO - 2023-12-06 16:15:46 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:15:46 --> Config Class Initialized
INFO - 2023-12-06 16:15:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:15:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:15:46 --> Utf8 Class Initialized
INFO - 2023-12-06 16:15:46 --> URI Class Initialized
INFO - 2023-12-06 16:15:46 --> Router Class Initialized
INFO - 2023-12-06 16:15:46 --> Output Class Initialized
INFO - 2023-12-06 16:15:46 --> Security Class Initialized
DEBUG - 2023-12-06 16:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:15:46 --> Input Class Initialized
INFO - 2023-12-06 16:15:46 --> Language Class Initialized
INFO - 2023-12-06 16:15:46 --> Language Class Initialized
INFO - 2023-12-06 16:15:46 --> Config Class Initialized
INFO - 2023-12-06 16:15:46 --> Loader Class Initialized
INFO - 2023-12-06 16:15:46 --> Helper loaded: url_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: file_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: form_helper
INFO - 2023-12-06 16:15:46 --> Helper loaded: my_helper
INFO - 2023-12-06 16:15:46 --> Database Driver Class Initialized
INFO - 2023-12-06 16:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:15:46 --> Controller Class Initialized
INFO - 2023-12-06 16:15:47 --> Config Class Initialized
INFO - 2023-12-06 16:15:47 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:15:47 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:15:47 --> Utf8 Class Initialized
INFO - 2023-12-06 16:15:47 --> URI Class Initialized
INFO - 2023-12-06 16:15:47 --> Router Class Initialized
INFO - 2023-12-06 16:15:47 --> Output Class Initialized
INFO - 2023-12-06 16:15:47 --> Security Class Initialized
DEBUG - 2023-12-06 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:15:47 --> Input Class Initialized
INFO - 2023-12-06 16:15:47 --> Language Class Initialized
INFO - 2023-12-06 16:15:47 --> Language Class Initialized
INFO - 2023-12-06 16:15:47 --> Config Class Initialized
INFO - 2023-12-06 16:15:47 --> Loader Class Initialized
INFO - 2023-12-06 16:15:47 --> Helper loaded: url_helper
INFO - 2023-12-06 16:15:47 --> Helper loaded: file_helper
INFO - 2023-12-06 16:15:47 --> Helper loaded: form_helper
INFO - 2023-12-06 16:15:47 --> Helper loaded: my_helper
INFO - 2023-12-06 16:15:47 --> Database Driver Class Initialized
INFO - 2023-12-06 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:15:47 --> Controller Class Initialized
DEBUG - 2023-12-06 16:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:15:47 --> Final output sent to browser
DEBUG - 2023-12-06 16:15:47 --> Total execution time: 0.0396
INFO - 2023-12-06 16:15:54 --> Config Class Initialized
INFO - 2023-12-06 16:15:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:15:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:15:54 --> Utf8 Class Initialized
INFO - 2023-12-06 16:15:54 --> URI Class Initialized
INFO - 2023-12-06 16:15:54 --> Router Class Initialized
INFO - 2023-12-06 16:15:54 --> Output Class Initialized
INFO - 2023-12-06 16:15:54 --> Security Class Initialized
DEBUG - 2023-12-06 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:15:54 --> Input Class Initialized
INFO - 2023-12-06 16:15:54 --> Language Class Initialized
INFO - 2023-12-06 16:15:54 --> Language Class Initialized
INFO - 2023-12-06 16:15:54 --> Config Class Initialized
INFO - 2023-12-06 16:15:54 --> Loader Class Initialized
INFO - 2023-12-06 16:15:54 --> Helper loaded: url_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: file_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: form_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: my_helper
INFO - 2023-12-06 16:15:54 --> Database Driver Class Initialized
INFO - 2023-12-06 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:15:54 --> Controller Class Initialized
INFO - 2023-12-06 16:15:54 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:15:54 --> Final output sent to browser
DEBUG - 2023-12-06 16:15:54 --> Total execution time: 0.0339
INFO - 2023-12-06 16:15:54 --> Config Class Initialized
INFO - 2023-12-06 16:15:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:15:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:15:54 --> Utf8 Class Initialized
INFO - 2023-12-06 16:15:54 --> URI Class Initialized
INFO - 2023-12-06 16:15:54 --> Router Class Initialized
INFO - 2023-12-06 16:15:54 --> Output Class Initialized
INFO - 2023-12-06 16:15:54 --> Security Class Initialized
DEBUG - 2023-12-06 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:15:54 --> Input Class Initialized
INFO - 2023-12-06 16:15:54 --> Language Class Initialized
INFO - 2023-12-06 16:15:54 --> Language Class Initialized
INFO - 2023-12-06 16:15:54 --> Config Class Initialized
INFO - 2023-12-06 16:15:54 --> Loader Class Initialized
INFO - 2023-12-06 16:15:54 --> Helper loaded: url_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: file_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: form_helper
INFO - 2023-12-06 16:15:54 --> Helper loaded: my_helper
INFO - 2023-12-06 16:15:54 --> Database Driver Class Initialized
INFO - 2023-12-06 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:15:54 --> Controller Class Initialized
DEBUG - 2023-12-06 16:15:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 16:15:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:15:54 --> Final output sent to browser
DEBUG - 2023-12-06 16:15:54 --> Total execution time: 0.0375
INFO - 2023-12-06 16:16:01 --> Config Class Initialized
INFO - 2023-12-06 16:16:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:01 --> URI Class Initialized
INFO - 2023-12-06 16:16:01 --> Router Class Initialized
INFO - 2023-12-06 16:16:01 --> Output Class Initialized
INFO - 2023-12-06 16:16:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:01 --> Input Class Initialized
INFO - 2023-12-06 16:16:01 --> Language Class Initialized
INFO - 2023-12-06 16:16:01 --> Language Class Initialized
INFO - 2023-12-06 16:16:01 --> Config Class Initialized
INFO - 2023-12-06 16:16:01 --> Loader Class Initialized
INFO - 2023-12-06 16:16:01 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:01 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:01 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-06 16:16:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:01 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:01 --> Total execution time: 0.1010
INFO - 2023-12-06 16:16:01 --> Config Class Initialized
INFO - 2023-12-06 16:16:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:01 --> URI Class Initialized
INFO - 2023-12-06 16:16:01 --> Router Class Initialized
INFO - 2023-12-06 16:16:01 --> Output Class Initialized
INFO - 2023-12-06 16:16:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:01 --> Input Class Initialized
INFO - 2023-12-06 16:16:01 --> Language Class Initialized
ERROR - 2023-12-06 16:16:01 --> 404 Page Not Found: /index
INFO - 2023-12-06 16:16:01 --> Config Class Initialized
INFO - 2023-12-06 16:16:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:01 --> URI Class Initialized
INFO - 2023-12-06 16:16:01 --> Router Class Initialized
INFO - 2023-12-06 16:16:01 --> Output Class Initialized
INFO - 2023-12-06 16:16:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:01 --> Input Class Initialized
INFO - 2023-12-06 16:16:01 --> Language Class Initialized
INFO - 2023-12-06 16:16:01 --> Language Class Initialized
INFO - 2023-12-06 16:16:01 --> Config Class Initialized
INFO - 2023-12-06 16:16:01 --> Loader Class Initialized
INFO - 2023-12-06 16:16:01 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:01 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:01 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:01 --> Controller Class Initialized
INFO - 2023-12-06 16:16:14 --> Config Class Initialized
INFO - 2023-12-06 16:16:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:14 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:14 --> URI Class Initialized
INFO - 2023-12-06 16:16:14 --> Router Class Initialized
INFO - 2023-12-06 16:16:14 --> Output Class Initialized
INFO - 2023-12-06 16:16:14 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:14 --> Input Class Initialized
INFO - 2023-12-06 16:16:14 --> Language Class Initialized
INFO - 2023-12-06 16:16:14 --> Language Class Initialized
INFO - 2023-12-06 16:16:14 --> Config Class Initialized
INFO - 2023-12-06 16:16:14 --> Loader Class Initialized
INFO - 2023-12-06 16:16:14 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:14 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:14 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:14 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:14 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:14 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 16:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:14 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:14 --> Total execution time: 0.0374
INFO - 2023-12-06 16:16:15 --> Config Class Initialized
INFO - 2023-12-06 16:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:15 --> URI Class Initialized
INFO - 2023-12-06 16:16:15 --> Router Class Initialized
INFO - 2023-12-06 16:16:15 --> Output Class Initialized
INFO - 2023-12-06 16:16:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:15 --> Input Class Initialized
INFO - 2023-12-06 16:16:15 --> Language Class Initialized
ERROR - 2023-12-06 16:16:15 --> 404 Page Not Found: /index
INFO - 2023-12-06 16:16:15 --> Config Class Initialized
INFO - 2023-12-06 16:16:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:15 --> URI Class Initialized
INFO - 2023-12-06 16:16:15 --> Router Class Initialized
INFO - 2023-12-06 16:16:15 --> Output Class Initialized
INFO - 2023-12-06 16:16:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:15 --> Input Class Initialized
INFO - 2023-12-06 16:16:15 --> Language Class Initialized
INFO - 2023-12-06 16:16:15 --> Language Class Initialized
INFO - 2023-12-06 16:16:15 --> Config Class Initialized
INFO - 2023-12-06 16:16:15 --> Loader Class Initialized
INFO - 2023-12-06 16:16:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:15 --> Controller Class Initialized
INFO - 2023-12-06 16:16:19 --> Config Class Initialized
INFO - 2023-12-06 16:16:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:19 --> URI Class Initialized
INFO - 2023-12-06 16:16:19 --> Router Class Initialized
INFO - 2023-12-06 16:16:19 --> Output Class Initialized
INFO - 2023-12-06 16:16:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:19 --> Input Class Initialized
INFO - 2023-12-06 16:16:19 --> Language Class Initialized
INFO - 2023-12-06 16:16:19 --> Language Class Initialized
INFO - 2023-12-06 16:16:19 --> Config Class Initialized
INFO - 2023-12-06 16:16:19 --> Loader Class Initialized
INFO - 2023-12-06 16:16:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:19 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:19 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:19 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:19 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:19 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-06 16:16:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:20 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:20 --> Total execution time: 0.1775
INFO - 2023-12-06 16:16:25 --> Config Class Initialized
INFO - 2023-12-06 16:16:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:25 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:25 --> URI Class Initialized
INFO - 2023-12-06 16:16:25 --> Router Class Initialized
INFO - 2023-12-06 16:16:25 --> Output Class Initialized
INFO - 2023-12-06 16:16:25 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:25 --> Input Class Initialized
INFO - 2023-12-06 16:16:25 --> Language Class Initialized
INFO - 2023-12-06 16:16:25 --> Language Class Initialized
INFO - 2023-12-06 16:16:25 --> Config Class Initialized
INFO - 2023-12-06 16:16:25 --> Loader Class Initialized
INFO - 2023-12-06 16:16:25 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:25 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:25 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-06 16:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:25 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:25 --> Total execution time: 0.1440
INFO - 2023-12-06 16:16:25 --> Config Class Initialized
INFO - 2023-12-06 16:16:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:25 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:25 --> URI Class Initialized
INFO - 2023-12-06 16:16:25 --> Router Class Initialized
INFO - 2023-12-06 16:16:25 --> Output Class Initialized
INFO - 2023-12-06 16:16:25 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:25 --> Input Class Initialized
INFO - 2023-12-06 16:16:25 --> Language Class Initialized
ERROR - 2023-12-06 16:16:25 --> 404 Page Not Found: /index
INFO - 2023-12-06 16:16:25 --> Config Class Initialized
INFO - 2023-12-06 16:16:25 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:25 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:25 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:25 --> URI Class Initialized
INFO - 2023-12-06 16:16:25 --> Router Class Initialized
INFO - 2023-12-06 16:16:25 --> Output Class Initialized
INFO - 2023-12-06 16:16:25 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:25 --> Input Class Initialized
INFO - 2023-12-06 16:16:25 --> Language Class Initialized
INFO - 2023-12-06 16:16:25 --> Language Class Initialized
INFO - 2023-12-06 16:16:25 --> Config Class Initialized
INFO - 2023-12-06 16:16:25 --> Loader Class Initialized
INFO - 2023-12-06 16:16:25 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:25 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:25 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:25 --> Controller Class Initialized
INFO - 2023-12-06 16:16:29 --> Config Class Initialized
INFO - 2023-12-06 16:16:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:29 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:29 --> URI Class Initialized
INFO - 2023-12-06 16:16:29 --> Router Class Initialized
INFO - 2023-12-06 16:16:29 --> Output Class Initialized
INFO - 2023-12-06 16:16:29 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:29 --> Input Class Initialized
INFO - 2023-12-06 16:16:29 --> Language Class Initialized
INFO - 2023-12-06 16:16:29 --> Language Class Initialized
INFO - 2023-12-06 16:16:29 --> Config Class Initialized
INFO - 2023-12-06 16:16:29 --> Loader Class Initialized
INFO - 2023-12-06 16:16:29 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:29 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:29 --> Controller Class Initialized
INFO - 2023-12-06 16:16:29 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:16:29 --> Config Class Initialized
INFO - 2023-12-06 16:16:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:29 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:29 --> URI Class Initialized
INFO - 2023-12-06 16:16:29 --> Router Class Initialized
INFO - 2023-12-06 16:16:29 --> Output Class Initialized
INFO - 2023-12-06 16:16:29 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:29 --> Input Class Initialized
INFO - 2023-12-06 16:16:29 --> Language Class Initialized
INFO - 2023-12-06 16:16:29 --> Language Class Initialized
INFO - 2023-12-06 16:16:29 --> Config Class Initialized
INFO - 2023-12-06 16:16:29 --> Loader Class Initialized
INFO - 2023-12-06 16:16:29 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:29 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:30 --> Controller Class Initialized
INFO - 2023-12-06 16:16:30 --> Config Class Initialized
INFO - 2023-12-06 16:16:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:30 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:30 --> URI Class Initialized
INFO - 2023-12-06 16:16:30 --> Router Class Initialized
INFO - 2023-12-06 16:16:30 --> Output Class Initialized
INFO - 2023-12-06 16:16:30 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:30 --> Input Class Initialized
INFO - 2023-12-06 16:16:30 --> Language Class Initialized
INFO - 2023-12-06 16:16:30 --> Language Class Initialized
INFO - 2023-12-06 16:16:30 --> Config Class Initialized
INFO - 2023-12-06 16:16:30 --> Loader Class Initialized
INFO - 2023-12-06 16:16:30 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:30 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:30 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:30 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:30 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:30 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:30 --> Total execution time: 0.0700
INFO - 2023-12-06 16:16:34 --> Config Class Initialized
INFO - 2023-12-06 16:16:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:34 --> URI Class Initialized
INFO - 2023-12-06 16:16:34 --> Router Class Initialized
INFO - 2023-12-06 16:16:34 --> Output Class Initialized
INFO - 2023-12-06 16:16:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:34 --> Input Class Initialized
INFO - 2023-12-06 16:16:34 --> Language Class Initialized
INFO - 2023-12-06 16:16:34 --> Language Class Initialized
INFO - 2023-12-06 16:16:34 --> Config Class Initialized
INFO - 2023-12-06 16:16:34 --> Loader Class Initialized
INFO - 2023-12-06 16:16:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:34 --> Controller Class Initialized
INFO - 2023-12-06 16:16:34 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:16:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:34 --> Total execution time: 0.0748
INFO - 2023-12-06 16:16:35 --> Config Class Initialized
INFO - 2023-12-06 16:16:35 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:35 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:35 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:35 --> URI Class Initialized
INFO - 2023-12-06 16:16:35 --> Router Class Initialized
INFO - 2023-12-06 16:16:35 --> Output Class Initialized
INFO - 2023-12-06 16:16:35 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:35 --> Input Class Initialized
INFO - 2023-12-06 16:16:35 --> Language Class Initialized
INFO - 2023-12-06 16:16:35 --> Language Class Initialized
INFO - 2023-12-06 16:16:35 --> Config Class Initialized
INFO - 2023-12-06 16:16:35 --> Loader Class Initialized
INFO - 2023-12-06 16:16:35 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:35 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:35 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:35 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:35 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:35 --> Controller Class Initialized
DEBUG - 2023-12-06 16:16:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:16:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:35 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:35 --> Total execution time: 0.0945
INFO - 2023-12-06 16:16:50 --> Config Class Initialized
INFO - 2023-12-06 16:16:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:16:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:16:50 --> Utf8 Class Initialized
INFO - 2023-12-06 16:16:50 --> URI Class Initialized
INFO - 2023-12-06 16:16:50 --> Router Class Initialized
INFO - 2023-12-06 16:16:50 --> Output Class Initialized
INFO - 2023-12-06 16:16:50 --> Security Class Initialized
DEBUG - 2023-12-06 16:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:16:50 --> Input Class Initialized
INFO - 2023-12-06 16:16:50 --> Language Class Initialized
INFO - 2023-12-06 16:16:50 --> Language Class Initialized
INFO - 2023-12-06 16:16:50 --> Config Class Initialized
INFO - 2023-12-06 16:16:50 --> Loader Class Initialized
INFO - 2023-12-06 16:16:50 --> Helper loaded: url_helper
INFO - 2023-12-06 16:16:50 --> Helper loaded: file_helper
INFO - 2023-12-06 16:16:50 --> Helper loaded: form_helper
INFO - 2023-12-06 16:16:50 --> Helper loaded: my_helper
INFO - 2023-12-06 16:16:50 --> Database Driver Class Initialized
INFO - 2023-12-06 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:16:50 --> Controller Class Initialized
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:16:50 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:16:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:16:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:16:50 --> Final output sent to browser
DEBUG - 2023-12-06 16:16:50 --> Total execution time: 0.0558
INFO - 2023-12-06 16:17:34 --> Config Class Initialized
INFO - 2023-12-06 16:17:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:17:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:17:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:17:34 --> URI Class Initialized
INFO - 2023-12-06 16:17:34 --> Router Class Initialized
INFO - 2023-12-06 16:17:34 --> Output Class Initialized
INFO - 2023-12-06 16:17:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:17:34 --> Input Class Initialized
INFO - 2023-12-06 16:17:34 --> Language Class Initialized
INFO - 2023-12-06 16:17:34 --> Language Class Initialized
INFO - 2023-12-06 16:17:34 --> Config Class Initialized
INFO - 2023-12-06 16:17:34 --> Loader Class Initialized
INFO - 2023-12-06 16:17:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:17:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:17:34 --> Controller Class Initialized
DEBUG - 2023-12-06 16:17:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:17:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:17:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:17:34 --> Total execution time: 0.1663
INFO - 2023-12-06 16:17:34 --> Config Class Initialized
INFO - 2023-12-06 16:17:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:17:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:17:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:17:34 --> URI Class Initialized
INFO - 2023-12-06 16:17:34 --> Router Class Initialized
INFO - 2023-12-06 16:17:34 --> Output Class Initialized
INFO - 2023-12-06 16:17:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:17:34 --> Input Class Initialized
INFO - 2023-12-06 16:17:34 --> Language Class Initialized
INFO - 2023-12-06 16:17:34 --> Language Class Initialized
INFO - 2023-12-06 16:17:34 --> Config Class Initialized
INFO - 2023-12-06 16:17:34 --> Loader Class Initialized
INFO - 2023-12-06 16:17:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:17:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:17:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:17:34 --> Controller Class Initialized
INFO - 2023-12-06 16:17:56 --> Config Class Initialized
INFO - 2023-12-06 16:17:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:17:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:17:56 --> Utf8 Class Initialized
INFO - 2023-12-06 16:17:56 --> URI Class Initialized
INFO - 2023-12-06 16:17:56 --> Router Class Initialized
INFO - 2023-12-06 16:17:56 --> Output Class Initialized
INFO - 2023-12-06 16:17:56 --> Security Class Initialized
DEBUG - 2023-12-06 16:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:17:56 --> Input Class Initialized
INFO - 2023-12-06 16:17:56 --> Language Class Initialized
INFO - 2023-12-06 16:17:56 --> Language Class Initialized
INFO - 2023-12-06 16:17:56 --> Config Class Initialized
INFO - 2023-12-06 16:17:56 --> Loader Class Initialized
INFO - 2023-12-06 16:17:56 --> Helper loaded: url_helper
INFO - 2023-12-06 16:17:56 --> Helper loaded: file_helper
INFO - 2023-12-06 16:17:56 --> Helper loaded: form_helper
INFO - 2023-12-06 16:17:56 --> Helper loaded: my_helper
INFO - 2023-12-06 16:17:56 --> Database Driver Class Initialized
INFO - 2023-12-06 16:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:17:56 --> Controller Class Initialized
DEBUG - 2023-12-06 16:17:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:17:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:17:56 --> Final output sent to browser
DEBUG - 2023-12-06 16:17:56 --> Total execution time: 0.0678
INFO - 2023-12-06 16:18:21 --> Config Class Initialized
INFO - 2023-12-06 16:18:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:18:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:18:21 --> Utf8 Class Initialized
INFO - 2023-12-06 16:18:21 --> URI Class Initialized
DEBUG - 2023-12-06 16:18:21 --> No URI present. Default controller set.
INFO - 2023-12-06 16:18:21 --> Router Class Initialized
INFO - 2023-12-06 16:18:21 --> Output Class Initialized
INFO - 2023-12-06 16:18:21 --> Security Class Initialized
DEBUG - 2023-12-06 16:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:18:21 --> Input Class Initialized
INFO - 2023-12-06 16:18:21 --> Language Class Initialized
INFO - 2023-12-06 16:18:21 --> Language Class Initialized
INFO - 2023-12-06 16:18:21 --> Config Class Initialized
INFO - 2023-12-06 16:18:21 --> Loader Class Initialized
INFO - 2023-12-06 16:18:21 --> Helper loaded: url_helper
INFO - 2023-12-06 16:18:21 --> Helper loaded: file_helper
INFO - 2023-12-06 16:18:21 --> Helper loaded: form_helper
INFO - 2023-12-06 16:18:21 --> Helper loaded: my_helper
INFO - 2023-12-06 16:18:21 --> Database Driver Class Initialized
INFO - 2023-12-06 16:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:18:21 --> Controller Class Initialized
DEBUG - 2023-12-06 16:18:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:18:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:18:21 --> Final output sent to browser
DEBUG - 2023-12-06 16:18:21 --> Total execution time: 0.0485
INFO - 2023-12-06 16:19:27 --> Config Class Initialized
INFO - 2023-12-06 16:19:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:19:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:19:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:19:27 --> URI Class Initialized
INFO - 2023-12-06 16:19:27 --> Router Class Initialized
INFO - 2023-12-06 16:19:27 --> Output Class Initialized
INFO - 2023-12-06 16:19:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:19:27 --> Input Class Initialized
INFO - 2023-12-06 16:19:27 --> Language Class Initialized
INFO - 2023-12-06 16:19:27 --> Language Class Initialized
INFO - 2023-12-06 16:19:27 --> Config Class Initialized
INFO - 2023-12-06 16:19:27 --> Loader Class Initialized
INFO - 2023-12-06 16:19:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:19:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:19:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:19:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:19:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:19:27 --> Controller Class Initialized
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:19:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:19:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:19:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:19:27 --> Final output sent to browser
DEBUG - 2023-12-06 16:19:27 --> Total execution time: 0.0472
INFO - 2023-12-06 16:19:33 --> Config Class Initialized
INFO - 2023-12-06 16:19:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:19:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:19:33 --> Utf8 Class Initialized
INFO - 2023-12-06 16:19:33 --> URI Class Initialized
INFO - 2023-12-06 16:19:33 --> Router Class Initialized
INFO - 2023-12-06 16:19:33 --> Output Class Initialized
INFO - 2023-12-06 16:19:33 --> Security Class Initialized
DEBUG - 2023-12-06 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:19:33 --> Input Class Initialized
INFO - 2023-12-06 16:19:33 --> Language Class Initialized
INFO - 2023-12-06 16:19:33 --> Language Class Initialized
INFO - 2023-12-06 16:19:33 --> Config Class Initialized
INFO - 2023-12-06 16:19:33 --> Loader Class Initialized
INFO - 2023-12-06 16:19:33 --> Helper loaded: url_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: file_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: form_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: my_helper
INFO - 2023-12-06 16:19:33 --> Database Driver Class Initialized
INFO - 2023-12-06 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:19:33 --> Controller Class Initialized
DEBUG - 2023-12-06 16:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:19:33 --> Final output sent to browser
DEBUG - 2023-12-06 16:19:33 --> Total execution time: 0.0399
INFO - 2023-12-06 16:19:33 --> Config Class Initialized
INFO - 2023-12-06 16:19:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:19:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:19:33 --> Utf8 Class Initialized
INFO - 2023-12-06 16:19:33 --> URI Class Initialized
INFO - 2023-12-06 16:19:33 --> Router Class Initialized
INFO - 2023-12-06 16:19:33 --> Output Class Initialized
INFO - 2023-12-06 16:19:33 --> Security Class Initialized
DEBUG - 2023-12-06 16:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:19:33 --> Input Class Initialized
INFO - 2023-12-06 16:19:33 --> Language Class Initialized
INFO - 2023-12-06 16:19:33 --> Language Class Initialized
INFO - 2023-12-06 16:19:33 --> Config Class Initialized
INFO - 2023-12-06 16:19:33 --> Loader Class Initialized
INFO - 2023-12-06 16:19:33 --> Helper loaded: url_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: file_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: form_helper
INFO - 2023-12-06 16:19:33 --> Helper loaded: my_helper
INFO - 2023-12-06 16:19:33 --> Database Driver Class Initialized
INFO - 2023-12-06 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:19:33 --> Controller Class Initialized
INFO - 2023-12-06 16:20:27 --> Config Class Initialized
INFO - 2023-12-06 16:20:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:20:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:20:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:20:27 --> URI Class Initialized
INFO - 2023-12-06 16:20:27 --> Router Class Initialized
INFO - 2023-12-06 16:20:27 --> Output Class Initialized
INFO - 2023-12-06 16:20:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:20:27 --> Input Class Initialized
INFO - 2023-12-06 16:20:27 --> Language Class Initialized
INFO - 2023-12-06 16:20:27 --> Language Class Initialized
INFO - 2023-12-06 16:20:27 --> Config Class Initialized
INFO - 2023-12-06 16:20:27 --> Loader Class Initialized
INFO - 2023-12-06 16:20:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:20:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:20:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:20:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:20:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:20:27 --> Controller Class Initialized
INFO - 2023-12-06 16:20:27 --> Final output sent to browser
DEBUG - 2023-12-06 16:20:27 --> Total execution time: 0.1376
INFO - 2023-12-06 16:20:39 --> Config Class Initialized
INFO - 2023-12-06 16:20:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:20:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:20:39 --> Utf8 Class Initialized
INFO - 2023-12-06 16:20:39 --> URI Class Initialized
INFO - 2023-12-06 16:20:39 --> Router Class Initialized
INFO - 2023-12-06 16:20:39 --> Output Class Initialized
INFO - 2023-12-06 16:20:39 --> Security Class Initialized
DEBUG - 2023-12-06 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:20:39 --> Input Class Initialized
INFO - 2023-12-06 16:20:39 --> Language Class Initialized
INFO - 2023-12-06 16:20:39 --> Language Class Initialized
INFO - 2023-12-06 16:20:39 --> Config Class Initialized
INFO - 2023-12-06 16:20:39 --> Loader Class Initialized
INFO - 2023-12-06 16:20:39 --> Helper loaded: url_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: file_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: form_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: my_helper
INFO - 2023-12-06 16:20:39 --> Database Driver Class Initialized
INFO - 2023-12-06 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:20:39 --> Controller Class Initialized
INFO - 2023-12-06 16:20:39 --> Final output sent to browser
DEBUG - 2023-12-06 16:20:39 --> Total execution time: 0.0466
INFO - 2023-12-06 16:20:39 --> Config Class Initialized
INFO - 2023-12-06 16:20:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:20:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:20:39 --> Utf8 Class Initialized
INFO - 2023-12-06 16:20:39 --> URI Class Initialized
INFO - 2023-12-06 16:20:39 --> Router Class Initialized
INFO - 2023-12-06 16:20:39 --> Output Class Initialized
INFO - 2023-12-06 16:20:39 --> Security Class Initialized
DEBUG - 2023-12-06 16:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:20:39 --> Input Class Initialized
INFO - 2023-12-06 16:20:39 --> Language Class Initialized
INFO - 2023-12-06 16:20:39 --> Language Class Initialized
INFO - 2023-12-06 16:20:39 --> Config Class Initialized
INFO - 2023-12-06 16:20:39 --> Loader Class Initialized
INFO - 2023-12-06 16:20:39 --> Helper loaded: url_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: file_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: form_helper
INFO - 2023-12-06 16:20:39 --> Helper loaded: my_helper
INFO - 2023-12-06 16:20:39 --> Database Driver Class Initialized
INFO - 2023-12-06 16:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:20:39 --> Controller Class Initialized
INFO - 2023-12-06 16:21:12 --> Config Class Initialized
INFO - 2023-12-06 16:21:12 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:21:12 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:21:12 --> Utf8 Class Initialized
INFO - 2023-12-06 16:21:12 --> URI Class Initialized
INFO - 2023-12-06 16:21:12 --> Router Class Initialized
INFO - 2023-12-06 16:21:12 --> Output Class Initialized
INFO - 2023-12-06 16:21:12 --> Security Class Initialized
DEBUG - 2023-12-06 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:21:12 --> Input Class Initialized
INFO - 2023-12-06 16:21:12 --> Language Class Initialized
INFO - 2023-12-06 16:21:12 --> Language Class Initialized
INFO - 2023-12-06 16:21:12 --> Config Class Initialized
INFO - 2023-12-06 16:21:12 --> Loader Class Initialized
INFO - 2023-12-06 16:21:12 --> Helper loaded: url_helper
INFO - 2023-12-06 16:21:12 --> Helper loaded: file_helper
INFO - 2023-12-06 16:21:12 --> Helper loaded: form_helper
INFO - 2023-12-06 16:21:12 --> Helper loaded: my_helper
INFO - 2023-12-06 16:21:12 --> Database Driver Class Initialized
INFO - 2023-12-06 16:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:21:12 --> Controller Class Initialized
INFO - 2023-12-06 16:21:12 --> Final output sent to browser
DEBUG - 2023-12-06 16:21:12 --> Total execution time: 0.0734
INFO - 2023-12-06 16:21:18 --> Config Class Initialized
INFO - 2023-12-06 16:21:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:21:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:21:18 --> Utf8 Class Initialized
INFO - 2023-12-06 16:21:18 --> URI Class Initialized
INFO - 2023-12-06 16:21:18 --> Router Class Initialized
INFO - 2023-12-06 16:21:18 --> Output Class Initialized
INFO - 2023-12-06 16:21:18 --> Security Class Initialized
DEBUG - 2023-12-06 16:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:21:18 --> Input Class Initialized
INFO - 2023-12-06 16:21:18 --> Language Class Initialized
INFO - 2023-12-06 16:21:18 --> Language Class Initialized
INFO - 2023-12-06 16:21:18 --> Config Class Initialized
INFO - 2023-12-06 16:21:18 --> Loader Class Initialized
INFO - 2023-12-06 16:21:18 --> Helper loaded: url_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: file_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: form_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: my_helper
INFO - 2023-12-06 16:21:18 --> Database Driver Class Initialized
INFO - 2023-12-06 16:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:21:18 --> Controller Class Initialized
INFO - 2023-12-06 16:21:18 --> Final output sent to browser
DEBUG - 2023-12-06 16:21:18 --> Total execution time: 0.0546
INFO - 2023-12-06 16:21:18 --> Config Class Initialized
INFO - 2023-12-06 16:21:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:21:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:21:18 --> Utf8 Class Initialized
INFO - 2023-12-06 16:21:18 --> URI Class Initialized
INFO - 2023-12-06 16:21:18 --> Router Class Initialized
INFO - 2023-12-06 16:21:18 --> Output Class Initialized
INFO - 2023-12-06 16:21:18 --> Security Class Initialized
DEBUG - 2023-12-06 16:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:21:18 --> Input Class Initialized
INFO - 2023-12-06 16:21:18 --> Language Class Initialized
INFO - 2023-12-06 16:21:18 --> Language Class Initialized
INFO - 2023-12-06 16:21:18 --> Config Class Initialized
INFO - 2023-12-06 16:21:18 --> Loader Class Initialized
INFO - 2023-12-06 16:21:18 --> Helper loaded: url_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: file_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: form_helper
INFO - 2023-12-06 16:21:18 --> Helper loaded: my_helper
INFO - 2023-12-06 16:21:18 --> Database Driver Class Initialized
INFO - 2023-12-06 16:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:21:18 --> Controller Class Initialized
INFO - 2023-12-06 16:21:20 --> Config Class Initialized
INFO - 2023-12-06 16:21:20 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:21:20 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:21:20 --> Utf8 Class Initialized
INFO - 2023-12-06 16:21:20 --> URI Class Initialized
INFO - 2023-12-06 16:21:20 --> Router Class Initialized
INFO - 2023-12-06 16:21:20 --> Output Class Initialized
INFO - 2023-12-06 16:21:20 --> Security Class Initialized
DEBUG - 2023-12-06 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:21:20 --> Input Class Initialized
INFO - 2023-12-06 16:21:20 --> Language Class Initialized
INFO - 2023-12-06 16:21:20 --> Language Class Initialized
INFO - 2023-12-06 16:21:20 --> Config Class Initialized
INFO - 2023-12-06 16:21:20 --> Loader Class Initialized
INFO - 2023-12-06 16:21:20 --> Helper loaded: url_helper
INFO - 2023-12-06 16:21:20 --> Helper loaded: file_helper
INFO - 2023-12-06 16:21:20 --> Helper loaded: form_helper
INFO - 2023-12-06 16:21:20 --> Helper loaded: my_helper
INFO - 2023-12-06 16:21:20 --> Database Driver Class Initialized
INFO - 2023-12-06 16:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:21:20 --> Controller Class Initialized
INFO - 2023-12-06 16:21:20 --> Final output sent to browser
DEBUG - 2023-12-06 16:21:20 --> Total execution time: 0.1655
INFO - 2023-12-06 16:21:56 --> Config Class Initialized
INFO - 2023-12-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:21:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:21:56 --> Utf8 Class Initialized
INFO - 2023-12-06 16:21:56 --> URI Class Initialized
INFO - 2023-12-06 16:21:56 --> Router Class Initialized
INFO - 2023-12-06 16:21:56 --> Output Class Initialized
INFO - 2023-12-06 16:21:56 --> Security Class Initialized
DEBUG - 2023-12-06 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:21:56 --> Input Class Initialized
INFO - 2023-12-06 16:21:56 --> Language Class Initialized
INFO - 2023-12-06 16:21:56 --> Language Class Initialized
INFO - 2023-12-06 16:21:56 --> Config Class Initialized
INFO - 2023-12-06 16:21:56 --> Loader Class Initialized
INFO - 2023-12-06 16:21:56 --> Helper loaded: url_helper
INFO - 2023-12-06 16:21:56 --> Helper loaded: file_helper
INFO - 2023-12-06 16:21:56 --> Helper loaded: form_helper
INFO - 2023-12-06 16:21:56 --> Helper loaded: my_helper
INFO - 2023-12-06 16:21:56 --> Database Driver Class Initialized
INFO - 2023-12-06 16:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:21:56 --> Controller Class Initialized
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:21:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:21:56 --> Final output sent to browser
DEBUG - 2023-12-06 16:21:56 --> Total execution time: 0.0414
INFO - 2023-12-06 16:22:04 --> Config Class Initialized
INFO - 2023-12-06 16:22:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:22:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:22:04 --> Utf8 Class Initialized
INFO - 2023-12-06 16:22:04 --> URI Class Initialized
INFO - 2023-12-06 16:22:04 --> Router Class Initialized
INFO - 2023-12-06 16:22:04 --> Output Class Initialized
INFO - 2023-12-06 16:22:04 --> Security Class Initialized
DEBUG - 2023-12-06 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:22:04 --> Input Class Initialized
INFO - 2023-12-06 16:22:04 --> Language Class Initialized
INFO - 2023-12-06 16:22:04 --> Language Class Initialized
INFO - 2023-12-06 16:22:04 --> Config Class Initialized
INFO - 2023-12-06 16:22:04 --> Loader Class Initialized
INFO - 2023-12-06 16:22:04 --> Helper loaded: url_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: file_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: form_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: my_helper
INFO - 2023-12-06 16:22:04 --> Database Driver Class Initialized
INFO - 2023-12-06 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:22:04 --> Controller Class Initialized
DEBUG - 2023-12-06 16:22:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:22:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:22:04 --> Final output sent to browser
DEBUG - 2023-12-06 16:22:04 --> Total execution time: 0.0450
INFO - 2023-12-06 16:22:04 --> Config Class Initialized
INFO - 2023-12-06 16:22:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:22:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:22:04 --> Utf8 Class Initialized
INFO - 2023-12-06 16:22:04 --> URI Class Initialized
INFO - 2023-12-06 16:22:04 --> Router Class Initialized
INFO - 2023-12-06 16:22:04 --> Output Class Initialized
INFO - 2023-12-06 16:22:04 --> Security Class Initialized
DEBUG - 2023-12-06 16:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:22:04 --> Input Class Initialized
INFO - 2023-12-06 16:22:04 --> Language Class Initialized
INFO - 2023-12-06 16:22:04 --> Language Class Initialized
INFO - 2023-12-06 16:22:04 --> Config Class Initialized
INFO - 2023-12-06 16:22:04 --> Loader Class Initialized
INFO - 2023-12-06 16:22:04 --> Helper loaded: url_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: file_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: form_helper
INFO - 2023-12-06 16:22:04 --> Helper loaded: my_helper
INFO - 2023-12-06 16:22:04 --> Database Driver Class Initialized
INFO - 2023-12-06 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:22:04 --> Controller Class Initialized
INFO - 2023-12-06 16:22:10 --> Config Class Initialized
INFO - 2023-12-06 16:22:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:22:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:22:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:22:10 --> URI Class Initialized
INFO - 2023-12-06 16:22:10 --> Router Class Initialized
INFO - 2023-12-06 16:22:10 --> Output Class Initialized
INFO - 2023-12-06 16:22:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:22:10 --> Input Class Initialized
INFO - 2023-12-06 16:22:10 --> Language Class Initialized
INFO - 2023-12-06 16:22:10 --> Language Class Initialized
INFO - 2023-12-06 16:22:10 --> Config Class Initialized
INFO - 2023-12-06 16:22:10 --> Loader Class Initialized
INFO - 2023-12-06 16:22:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:22:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:22:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:22:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:22:11 --> Database Driver Class Initialized
INFO - 2023-12-06 16:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:22:11 --> Controller Class Initialized
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:22:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:22:11 --> Final output sent to browser
DEBUG - 2023-12-06 16:22:11 --> Total execution time: 0.0640
INFO - 2023-12-06 16:23:24 --> Config Class Initialized
INFO - 2023-12-06 16:23:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:23:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:23:24 --> Utf8 Class Initialized
INFO - 2023-12-06 16:23:24 --> URI Class Initialized
INFO - 2023-12-06 16:23:24 --> Router Class Initialized
INFO - 2023-12-06 16:23:24 --> Output Class Initialized
INFO - 2023-12-06 16:23:24 --> Security Class Initialized
DEBUG - 2023-12-06 16:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:23:24 --> Input Class Initialized
INFO - 2023-12-06 16:23:24 --> Language Class Initialized
INFO - 2023-12-06 16:23:24 --> Language Class Initialized
INFO - 2023-12-06 16:23:24 --> Config Class Initialized
INFO - 2023-12-06 16:23:24 --> Loader Class Initialized
INFO - 2023-12-06 16:23:24 --> Helper loaded: url_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: file_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: form_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: my_helper
INFO - 2023-12-06 16:23:24 --> Database Driver Class Initialized
INFO - 2023-12-06 16:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:23:24 --> Controller Class Initialized
DEBUG - 2023-12-06 16:23:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:23:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:23:24 --> Final output sent to browser
DEBUG - 2023-12-06 16:23:24 --> Total execution time: 0.0456
INFO - 2023-12-06 16:23:24 --> Config Class Initialized
INFO - 2023-12-06 16:23:24 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:23:24 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:23:24 --> Utf8 Class Initialized
INFO - 2023-12-06 16:23:24 --> URI Class Initialized
INFO - 2023-12-06 16:23:24 --> Router Class Initialized
INFO - 2023-12-06 16:23:24 --> Output Class Initialized
INFO - 2023-12-06 16:23:24 --> Security Class Initialized
DEBUG - 2023-12-06 16:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:23:24 --> Input Class Initialized
INFO - 2023-12-06 16:23:24 --> Language Class Initialized
INFO - 2023-12-06 16:23:24 --> Language Class Initialized
INFO - 2023-12-06 16:23:24 --> Config Class Initialized
INFO - 2023-12-06 16:23:24 --> Loader Class Initialized
INFO - 2023-12-06 16:23:24 --> Helper loaded: url_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: file_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: form_helper
INFO - 2023-12-06 16:23:24 --> Helper loaded: my_helper
INFO - 2023-12-06 16:23:24 --> Database Driver Class Initialized
INFO - 2023-12-06 16:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:23:24 --> Controller Class Initialized
INFO - 2023-12-06 16:23:52 --> Config Class Initialized
INFO - 2023-12-06 16:23:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:23:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:23:52 --> Utf8 Class Initialized
INFO - 2023-12-06 16:23:52 --> URI Class Initialized
INFO - 2023-12-06 16:23:52 --> Router Class Initialized
INFO - 2023-12-06 16:23:52 --> Output Class Initialized
INFO - 2023-12-06 16:23:52 --> Security Class Initialized
DEBUG - 2023-12-06 16:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:23:52 --> Input Class Initialized
INFO - 2023-12-06 16:23:52 --> Language Class Initialized
INFO - 2023-12-06 16:23:52 --> Language Class Initialized
INFO - 2023-12-06 16:23:52 --> Config Class Initialized
INFO - 2023-12-06 16:23:52 --> Loader Class Initialized
INFO - 2023-12-06 16:23:52 --> Helper loaded: url_helper
INFO - 2023-12-06 16:23:52 --> Helper loaded: file_helper
INFO - 2023-12-06 16:23:52 --> Helper loaded: form_helper
INFO - 2023-12-06 16:23:52 --> Helper loaded: my_helper
INFO - 2023-12-06 16:23:52 --> Database Driver Class Initialized
INFO - 2023-12-06 16:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:23:52 --> Controller Class Initialized
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:23:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:23:52 --> Final output sent to browser
DEBUG - 2023-12-06 16:23:52 --> Total execution time: 0.0422
INFO - 2023-12-06 16:25:10 --> Config Class Initialized
INFO - 2023-12-06 16:25:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:10 --> URI Class Initialized
INFO - 2023-12-06 16:25:10 --> Router Class Initialized
INFO - 2023-12-06 16:25:10 --> Output Class Initialized
INFO - 2023-12-06 16:25:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:10 --> Input Class Initialized
INFO - 2023-12-06 16:25:10 --> Language Class Initialized
INFO - 2023-12-06 16:25:10 --> Language Class Initialized
INFO - 2023-12-06 16:25:10 --> Config Class Initialized
INFO - 2023-12-06 16:25:10 --> Loader Class Initialized
INFO - 2023-12-06 16:25:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:10 --> Controller Class Initialized
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:10 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:25:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:25:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:10 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:10 --> Total execution time: 0.0506
INFO - 2023-12-06 16:25:15 --> Config Class Initialized
INFO - 2023-12-06 16:25:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:15 --> URI Class Initialized
INFO - 2023-12-06 16:25:15 --> Router Class Initialized
INFO - 2023-12-06 16:25:15 --> Output Class Initialized
INFO - 2023-12-06 16:25:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:15 --> Input Class Initialized
INFO - 2023-12-06 16:25:15 --> Language Class Initialized
INFO - 2023-12-06 16:25:15 --> Language Class Initialized
INFO - 2023-12-06 16:25:15 --> Config Class Initialized
INFO - 2023-12-06 16:25:15 --> Loader Class Initialized
INFO - 2023-12-06 16:25:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:15 --> Controller Class Initialized
DEBUG - 2023-12-06 16:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:25:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:15 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:15 --> Total execution time: 0.0698
INFO - 2023-12-06 16:25:15 --> Config Class Initialized
INFO - 2023-12-06 16:25:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:15 --> URI Class Initialized
INFO - 2023-12-06 16:25:16 --> Router Class Initialized
INFO - 2023-12-06 16:25:16 --> Output Class Initialized
INFO - 2023-12-06 16:25:16 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:16 --> Input Class Initialized
INFO - 2023-12-06 16:25:16 --> Language Class Initialized
INFO - 2023-12-06 16:25:16 --> Language Class Initialized
INFO - 2023-12-06 16:25:16 --> Config Class Initialized
INFO - 2023-12-06 16:25:16 --> Loader Class Initialized
INFO - 2023-12-06 16:25:16 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:16 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:16 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:16 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:16 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:16 --> Controller Class Initialized
INFO - 2023-12-06 16:25:19 --> Config Class Initialized
INFO - 2023-12-06 16:25:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:19 --> URI Class Initialized
INFO - 2023-12-06 16:25:19 --> Router Class Initialized
INFO - 2023-12-06 16:25:19 --> Output Class Initialized
INFO - 2023-12-06 16:25:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:19 --> Input Class Initialized
INFO - 2023-12-06 16:25:19 --> Language Class Initialized
INFO - 2023-12-06 16:25:19 --> Language Class Initialized
INFO - 2023-12-06 16:25:19 --> Config Class Initialized
INFO - 2023-12-06 16:25:19 --> Loader Class Initialized
INFO - 2023-12-06 16:25:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:20 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:20 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:20 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:20 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:20 --> Controller Class Initialized
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:20 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:20 --> Total execution time: 0.0496
INFO - 2023-12-06 16:25:22 --> Config Class Initialized
INFO - 2023-12-06 16:25:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:22 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:22 --> URI Class Initialized
INFO - 2023-12-06 16:25:22 --> Router Class Initialized
INFO - 2023-12-06 16:25:22 --> Output Class Initialized
INFO - 2023-12-06 16:25:22 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:22 --> Input Class Initialized
INFO - 2023-12-06 16:25:22 --> Language Class Initialized
INFO - 2023-12-06 16:25:22 --> Language Class Initialized
INFO - 2023-12-06 16:25:22 --> Config Class Initialized
INFO - 2023-12-06 16:25:22 --> Loader Class Initialized
INFO - 2023-12-06 16:25:22 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:22 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:22 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:22 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:22 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:22 --> Controller Class Initialized
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:25:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:25:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:22 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:22 --> Total execution time: 0.0663
INFO - 2023-12-06 16:25:34 --> Config Class Initialized
INFO - 2023-12-06 16:25:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:34 --> URI Class Initialized
INFO - 2023-12-06 16:25:34 --> Router Class Initialized
INFO - 2023-12-06 16:25:34 --> Output Class Initialized
INFO - 2023-12-06 16:25:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:34 --> Input Class Initialized
INFO - 2023-12-06 16:25:34 --> Language Class Initialized
INFO - 2023-12-06 16:25:34 --> Language Class Initialized
INFO - 2023-12-06 16:25:34 --> Config Class Initialized
INFO - 2023-12-06 16:25:34 --> Loader Class Initialized
INFO - 2023-12-06 16:25:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:34 --> Controller Class Initialized
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:34 --> Total execution time: 0.0847
INFO - 2023-12-06 16:25:36 --> Config Class Initialized
INFO - 2023-12-06 16:25:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:36 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:36 --> URI Class Initialized
INFO - 2023-12-06 16:25:36 --> Router Class Initialized
INFO - 2023-12-06 16:25:36 --> Output Class Initialized
INFO - 2023-12-06 16:25:36 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:36 --> Input Class Initialized
INFO - 2023-12-06 16:25:36 --> Language Class Initialized
INFO - 2023-12-06 16:25:36 --> Language Class Initialized
INFO - 2023-12-06 16:25:36 --> Config Class Initialized
INFO - 2023-12-06 16:25:36 --> Loader Class Initialized
INFO - 2023-12-06 16:25:36 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:36 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:36 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:36 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:36 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:36 --> Controller Class Initialized
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:25:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:25:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:25:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:36 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:36 --> Total execution time: 0.0531
INFO - 2023-12-06 16:25:49 --> Config Class Initialized
INFO - 2023-12-06 16:25:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:25:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:25:49 --> Utf8 Class Initialized
INFO - 2023-12-06 16:25:49 --> URI Class Initialized
INFO - 2023-12-06 16:25:49 --> Router Class Initialized
INFO - 2023-12-06 16:25:49 --> Output Class Initialized
INFO - 2023-12-06 16:25:49 --> Security Class Initialized
DEBUG - 2023-12-06 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:25:49 --> Input Class Initialized
INFO - 2023-12-06 16:25:49 --> Language Class Initialized
INFO - 2023-12-06 16:25:49 --> Language Class Initialized
INFO - 2023-12-06 16:25:49 --> Config Class Initialized
INFO - 2023-12-06 16:25:49 --> Loader Class Initialized
INFO - 2023-12-06 16:25:49 --> Helper loaded: url_helper
INFO - 2023-12-06 16:25:49 --> Helper loaded: file_helper
INFO - 2023-12-06 16:25:49 --> Helper loaded: form_helper
INFO - 2023-12-06 16:25:49 --> Helper loaded: my_helper
INFO - 2023-12-06 16:25:49 --> Database Driver Class Initialized
INFO - 2023-12-06 16:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:25:49 --> Controller Class Initialized
DEBUG - 2023-12-06 16:25:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2023-12-06 16:25:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:25:49 --> Final output sent to browser
DEBUG - 2023-12-06 16:25:49 --> Total execution time: 0.1324
INFO - 2023-12-06 16:27:17 --> Config Class Initialized
INFO - 2023-12-06 16:27:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:27:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:27:17 --> Utf8 Class Initialized
INFO - 2023-12-06 16:27:17 --> URI Class Initialized
INFO - 2023-12-06 16:27:17 --> Router Class Initialized
INFO - 2023-12-06 16:27:17 --> Output Class Initialized
INFO - 2023-12-06 16:27:17 --> Security Class Initialized
DEBUG - 2023-12-06 16:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:27:17 --> Input Class Initialized
INFO - 2023-12-06 16:27:17 --> Language Class Initialized
INFO - 2023-12-06 16:27:17 --> Language Class Initialized
INFO - 2023-12-06 16:27:17 --> Config Class Initialized
INFO - 2023-12-06 16:27:17 --> Loader Class Initialized
INFO - 2023-12-06 16:27:17 --> Helper loaded: url_helper
INFO - 2023-12-06 16:27:17 --> Helper loaded: file_helper
INFO - 2023-12-06 16:27:17 --> Helper loaded: form_helper
INFO - 2023-12-06 16:27:17 --> Helper loaded: my_helper
INFO - 2023-12-06 16:27:17 --> Database Driver Class Initialized
INFO - 2023-12-06 16:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:27:17 --> Controller Class Initialized
DEBUG - 2023-12-06 16:27:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:27:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:27:17 --> Final output sent to browser
DEBUG - 2023-12-06 16:27:17 --> Total execution time: 0.0846
INFO - 2023-12-06 16:27:36 --> Config Class Initialized
INFO - 2023-12-06 16:27:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:27:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:27:36 --> Utf8 Class Initialized
INFO - 2023-12-06 16:27:36 --> URI Class Initialized
INFO - 2023-12-06 16:27:36 --> Router Class Initialized
INFO - 2023-12-06 16:27:36 --> Output Class Initialized
INFO - 2023-12-06 16:27:36 --> Security Class Initialized
DEBUG - 2023-12-06 16:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:27:36 --> Input Class Initialized
INFO - 2023-12-06 16:27:36 --> Language Class Initialized
INFO - 2023-12-06 16:27:36 --> Language Class Initialized
INFO - 2023-12-06 16:27:36 --> Config Class Initialized
INFO - 2023-12-06 16:27:36 --> Loader Class Initialized
INFO - 2023-12-06 16:27:36 --> Helper loaded: url_helper
INFO - 2023-12-06 16:27:36 --> Helper loaded: file_helper
INFO - 2023-12-06 16:27:36 --> Helper loaded: form_helper
INFO - 2023-12-06 16:27:36 --> Helper loaded: my_helper
INFO - 2023-12-06 16:27:36 --> Database Driver Class Initialized
INFO - 2023-12-06 16:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:27:36 --> Controller Class Initialized
DEBUG - 2023-12-06 16:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 16:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:27:36 --> Final output sent to browser
DEBUG - 2023-12-06 16:27:36 --> Total execution time: 0.1033
INFO - 2023-12-06 16:27:36 --> Config Class Initialized
INFO - 2023-12-06 16:27:36 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:27:36 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:27:36 --> Utf8 Class Initialized
INFO - 2023-12-06 16:27:36 --> URI Class Initialized
INFO - 2023-12-06 16:27:36 --> Router Class Initialized
INFO - 2023-12-06 16:27:36 --> Output Class Initialized
INFO - 2023-12-06 16:27:36 --> Security Class Initialized
DEBUG - 2023-12-06 16:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:27:36 --> Input Class Initialized
INFO - 2023-12-06 16:27:36 --> Language Class Initialized
INFO - 2023-12-06 16:27:37 --> Language Class Initialized
INFO - 2023-12-06 16:27:37 --> Config Class Initialized
INFO - 2023-12-06 16:27:37 --> Loader Class Initialized
INFO - 2023-12-06 16:27:37 --> Helper loaded: url_helper
INFO - 2023-12-06 16:27:37 --> Helper loaded: file_helper
INFO - 2023-12-06 16:27:37 --> Helper loaded: form_helper
INFO - 2023-12-06 16:27:37 --> Helper loaded: my_helper
INFO - 2023-12-06 16:27:37 --> Database Driver Class Initialized
INFO - 2023-12-06 16:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:27:37 --> Controller Class Initialized
INFO - 2023-12-06 16:27:46 --> Config Class Initialized
INFO - 2023-12-06 16:27:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:27:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:27:46 --> Utf8 Class Initialized
INFO - 2023-12-06 16:27:46 --> URI Class Initialized
INFO - 2023-12-06 16:27:46 --> Router Class Initialized
INFO - 2023-12-06 16:27:46 --> Output Class Initialized
INFO - 2023-12-06 16:27:46 --> Security Class Initialized
DEBUG - 2023-12-06 16:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:27:46 --> Input Class Initialized
INFO - 2023-12-06 16:27:46 --> Language Class Initialized
INFO - 2023-12-06 16:27:46 --> Language Class Initialized
INFO - 2023-12-06 16:27:46 --> Config Class Initialized
INFO - 2023-12-06 16:27:46 --> Loader Class Initialized
INFO - 2023-12-06 16:27:46 --> Helper loaded: url_helper
INFO - 2023-12-06 16:27:46 --> Helper loaded: file_helper
INFO - 2023-12-06 16:27:46 --> Helper loaded: form_helper
INFO - 2023-12-06 16:27:46 --> Helper loaded: my_helper
INFO - 2023-12-06 16:27:46 --> Database Driver Class Initialized
INFO - 2023-12-06 16:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:27:46 --> Controller Class Initialized
INFO - 2023-12-06 16:27:46 --> Final output sent to browser
DEBUG - 2023-12-06 16:27:46 --> Total execution time: 0.2116
INFO - 2023-12-06 16:28:00 --> Config Class Initialized
INFO - 2023-12-06 16:28:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:28:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:28:00 --> Utf8 Class Initialized
INFO - 2023-12-06 16:28:00 --> URI Class Initialized
INFO - 2023-12-06 16:28:00 --> Router Class Initialized
INFO - 2023-12-06 16:28:00 --> Output Class Initialized
INFO - 2023-12-06 16:28:00 --> Security Class Initialized
DEBUG - 2023-12-06 16:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:28:00 --> Input Class Initialized
INFO - 2023-12-06 16:28:00 --> Language Class Initialized
INFO - 2023-12-06 16:28:00 --> Language Class Initialized
INFO - 2023-12-06 16:28:00 --> Config Class Initialized
INFO - 2023-12-06 16:28:00 --> Loader Class Initialized
INFO - 2023-12-06 16:28:00 --> Helper loaded: url_helper
INFO - 2023-12-06 16:28:00 --> Helper loaded: file_helper
INFO - 2023-12-06 16:28:00 --> Helper loaded: form_helper
INFO - 2023-12-06 16:28:00 --> Helper loaded: my_helper
INFO - 2023-12-06 16:28:00 --> Database Driver Class Initialized
INFO - 2023-12-06 16:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:28:00 --> Controller Class Initialized
INFO - 2023-12-06 16:28:00 --> Final output sent to browser
DEBUG - 2023-12-06 16:28:00 --> Total execution time: 0.0416
INFO - 2023-12-06 16:28:15 --> Config Class Initialized
INFO - 2023-12-06 16:28:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:28:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:28:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:28:15 --> URI Class Initialized
INFO - 2023-12-06 16:28:15 --> Router Class Initialized
INFO - 2023-12-06 16:28:15 --> Output Class Initialized
INFO - 2023-12-06 16:28:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:28:15 --> Input Class Initialized
INFO - 2023-12-06 16:28:15 --> Language Class Initialized
INFO - 2023-12-06 16:28:15 --> Language Class Initialized
INFO - 2023-12-06 16:28:15 --> Config Class Initialized
INFO - 2023-12-06 16:28:15 --> Loader Class Initialized
INFO - 2023-12-06 16:28:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:28:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:28:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:28:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:28:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:28:15 --> Controller Class Initialized
DEBUG - 2023-12-06 16:28:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:28:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:28:15 --> Final output sent to browser
DEBUG - 2023-12-06 16:28:15 --> Total execution time: 0.1117
INFO - 2023-12-06 16:29:22 --> Config Class Initialized
INFO - 2023-12-06 16:29:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:29:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:29:22 --> Utf8 Class Initialized
INFO - 2023-12-06 16:29:22 --> URI Class Initialized
INFO - 2023-12-06 16:29:22 --> Router Class Initialized
INFO - 2023-12-06 16:29:22 --> Output Class Initialized
INFO - 2023-12-06 16:29:22 --> Security Class Initialized
DEBUG - 2023-12-06 16:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:29:22 --> Input Class Initialized
INFO - 2023-12-06 16:29:22 --> Language Class Initialized
INFO - 2023-12-06 16:29:22 --> Language Class Initialized
INFO - 2023-12-06 16:29:22 --> Config Class Initialized
INFO - 2023-12-06 16:29:22 --> Loader Class Initialized
INFO - 2023-12-06 16:29:22 --> Helper loaded: url_helper
INFO - 2023-12-06 16:29:22 --> Helper loaded: file_helper
INFO - 2023-12-06 16:29:22 --> Helper loaded: form_helper
INFO - 2023-12-06 16:29:22 --> Helper loaded: my_helper
INFO - 2023-12-06 16:29:22 --> Database Driver Class Initialized
INFO - 2023-12-06 16:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:29:22 --> Controller Class Initialized
DEBUG - 2023-12-06 16:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 16:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:29:22 --> Final output sent to browser
DEBUG - 2023-12-06 16:29:22 --> Total execution time: 0.0435
INFO - 2023-12-06 16:29:23 --> Config Class Initialized
INFO - 2023-12-06 16:29:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:29:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:29:23 --> Utf8 Class Initialized
INFO - 2023-12-06 16:29:23 --> URI Class Initialized
INFO - 2023-12-06 16:29:23 --> Router Class Initialized
INFO - 2023-12-06 16:29:23 --> Output Class Initialized
INFO - 2023-12-06 16:29:23 --> Security Class Initialized
DEBUG - 2023-12-06 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:29:23 --> Input Class Initialized
INFO - 2023-12-06 16:29:23 --> Language Class Initialized
INFO - 2023-12-06 16:29:23 --> Language Class Initialized
INFO - 2023-12-06 16:29:23 --> Config Class Initialized
INFO - 2023-12-06 16:29:23 --> Loader Class Initialized
INFO - 2023-12-06 16:29:23 --> Helper loaded: url_helper
INFO - 2023-12-06 16:29:23 --> Helper loaded: file_helper
INFO - 2023-12-06 16:29:23 --> Helper loaded: form_helper
INFO - 2023-12-06 16:29:23 --> Helper loaded: my_helper
INFO - 2023-12-06 16:29:23 --> Database Driver Class Initialized
INFO - 2023-12-06 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:29:23 --> Controller Class Initialized
INFO - 2023-12-06 16:29:46 --> Config Class Initialized
INFO - 2023-12-06 16:29:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:29:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:29:46 --> Utf8 Class Initialized
INFO - 2023-12-06 16:29:46 --> URI Class Initialized
INFO - 2023-12-06 16:29:46 --> Router Class Initialized
INFO - 2023-12-06 16:29:46 --> Output Class Initialized
INFO - 2023-12-06 16:29:46 --> Security Class Initialized
DEBUG - 2023-12-06 16:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:29:46 --> Input Class Initialized
INFO - 2023-12-06 16:29:46 --> Language Class Initialized
INFO - 2023-12-06 16:29:46 --> Language Class Initialized
INFO - 2023-12-06 16:29:46 --> Config Class Initialized
INFO - 2023-12-06 16:29:46 --> Loader Class Initialized
INFO - 2023-12-06 16:29:46 --> Helper loaded: url_helper
INFO - 2023-12-06 16:29:46 --> Helper loaded: file_helper
INFO - 2023-12-06 16:29:46 --> Helper loaded: form_helper
INFO - 2023-12-06 16:29:46 --> Helper loaded: my_helper
INFO - 2023-12-06 16:29:46 --> Database Driver Class Initialized
INFO - 2023-12-06 16:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:29:46 --> Controller Class Initialized
INFO - 2023-12-06 16:29:46 --> Final output sent to browser
DEBUG - 2023-12-06 16:29:46 --> Total execution time: 0.0824
INFO - 2023-12-06 16:30:04 --> Config Class Initialized
INFO - 2023-12-06 16:30:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:04 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:04 --> URI Class Initialized
INFO - 2023-12-06 16:30:04 --> Router Class Initialized
INFO - 2023-12-06 16:30:04 --> Output Class Initialized
INFO - 2023-12-06 16:30:04 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:04 --> Input Class Initialized
INFO - 2023-12-06 16:30:04 --> Language Class Initialized
INFO - 2023-12-06 16:30:04 --> Language Class Initialized
INFO - 2023-12-06 16:30:04 --> Config Class Initialized
INFO - 2023-12-06 16:30:04 --> Loader Class Initialized
INFO - 2023-12-06 16:30:04 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:04 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:04 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:04 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:04 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:04 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 16:30:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:04 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:04 --> Total execution time: 0.2202
INFO - 2023-12-06 16:30:07 --> Config Class Initialized
INFO - 2023-12-06 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:07 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:07 --> URI Class Initialized
INFO - 2023-12-06 16:30:07 --> Router Class Initialized
INFO - 2023-12-06 16:30:07 --> Output Class Initialized
INFO - 2023-12-06 16:30:07 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:07 --> Input Class Initialized
INFO - 2023-12-06 16:30:07 --> Language Class Initialized
INFO - 2023-12-06 16:30:07 --> Language Class Initialized
INFO - 2023-12-06 16:30:07 --> Config Class Initialized
INFO - 2023-12-06 16:30:07 --> Loader Class Initialized
INFO - 2023-12-06 16:30:07 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:07 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:07 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:07 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:07 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:07 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-06 16:30:13 --> Config Class Initialized
INFO - 2023-12-06 16:30:13 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:13 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:13 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:13 --> URI Class Initialized
INFO - 2023-12-06 16:30:13 --> Router Class Initialized
INFO - 2023-12-06 16:30:13 --> Output Class Initialized
INFO - 2023-12-06 16:30:13 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:13 --> Input Class Initialized
INFO - 2023-12-06 16:30:13 --> Language Class Initialized
INFO - 2023-12-06 16:30:13 --> Language Class Initialized
INFO - 2023-12-06 16:30:13 --> Config Class Initialized
INFO - 2023-12-06 16:30:13 --> Loader Class Initialized
INFO - 2023-12-06 16:30:13 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:13 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:13 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:13 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:13 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:13 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 16:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:13 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:13 --> Total execution time: 0.1454
INFO - 2023-12-06 16:30:14 --> Config Class Initialized
INFO - 2023-12-06 16:30:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:14 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:14 --> URI Class Initialized
INFO - 2023-12-06 16:30:14 --> Router Class Initialized
INFO - 2023-12-06 16:30:14 --> Output Class Initialized
INFO - 2023-12-06 16:30:14 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:14 --> Input Class Initialized
INFO - 2023-12-06 16:30:14 --> Language Class Initialized
INFO - 2023-12-06 16:30:14 --> Language Class Initialized
INFO - 2023-12-06 16:30:14 --> Config Class Initialized
INFO - 2023-12-06 16:30:14 --> Loader Class Initialized
INFO - 2023-12-06 16:30:14 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:14 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:14 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:14 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:14 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:14 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:14 --> Total execution time: 7.0878
INFO - 2023-12-06 16:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:14 --> Controller Class Initialized
INFO - 2023-12-06 16:30:26 --> Config Class Initialized
INFO - 2023-12-06 16:30:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:26 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:26 --> URI Class Initialized
DEBUG - 2023-12-06 16:30:26 --> No URI present. Default controller set.
INFO - 2023-12-06 16:30:26 --> Router Class Initialized
INFO - 2023-12-06 16:30:26 --> Output Class Initialized
INFO - 2023-12-06 16:30:26 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:26 --> Input Class Initialized
INFO - 2023-12-06 16:30:26 --> Language Class Initialized
INFO - 2023-12-06 16:30:26 --> Language Class Initialized
INFO - 2023-12-06 16:30:26 --> Config Class Initialized
INFO - 2023-12-06 16:30:26 --> Loader Class Initialized
INFO - 2023-12-06 16:30:26 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:26 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:26 --> Controller Class Initialized
INFO - 2023-12-06 16:30:26 --> Config Class Initialized
INFO - 2023-12-06 16:30:26 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:26 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:26 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:26 --> URI Class Initialized
INFO - 2023-12-06 16:30:26 --> Router Class Initialized
INFO - 2023-12-06 16:30:26 --> Output Class Initialized
INFO - 2023-12-06 16:30:26 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:26 --> Input Class Initialized
INFO - 2023-12-06 16:30:26 --> Language Class Initialized
INFO - 2023-12-06 16:30:26 --> Language Class Initialized
INFO - 2023-12-06 16:30:26 --> Config Class Initialized
INFO - 2023-12-06 16:30:26 --> Loader Class Initialized
INFO - 2023-12-06 16:30:26 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:26 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:26 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:26 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:30:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:26 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:26 --> Total execution time: 0.0652
INFO - 2023-12-06 16:30:29 --> Config Class Initialized
INFO - 2023-12-06 16:30:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:29 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:29 --> URI Class Initialized
INFO - 2023-12-06 16:30:29 --> Router Class Initialized
INFO - 2023-12-06 16:30:29 --> Output Class Initialized
INFO - 2023-12-06 16:30:29 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:29 --> Input Class Initialized
INFO - 2023-12-06 16:30:29 --> Language Class Initialized
INFO - 2023-12-06 16:30:29 --> Language Class Initialized
INFO - 2023-12-06 16:30:29 --> Config Class Initialized
INFO - 2023-12-06 16:30:29 --> Loader Class Initialized
INFO - 2023-12-06 16:30:29 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:29 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:29 --> Controller Class Initialized
INFO - 2023-12-06 16:30:29 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:30:29 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:29 --> Total execution time: 0.0738
INFO - 2023-12-06 16:30:29 --> Config Class Initialized
INFO - 2023-12-06 16:30:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:29 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:29 --> URI Class Initialized
INFO - 2023-12-06 16:30:29 --> Router Class Initialized
INFO - 2023-12-06 16:30:29 --> Output Class Initialized
INFO - 2023-12-06 16:30:29 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:29 --> Input Class Initialized
INFO - 2023-12-06 16:30:29 --> Language Class Initialized
INFO - 2023-12-06 16:30:29 --> Language Class Initialized
INFO - 2023-12-06 16:30:29 --> Config Class Initialized
INFO - 2023-12-06 16:30:29 --> Loader Class Initialized
INFO - 2023-12-06 16:30:29 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:29 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:29 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:29 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:29 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:29 --> Total execution time: 0.0398
INFO - 2023-12-06 16:30:49 --> Config Class Initialized
INFO - 2023-12-06 16:30:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:49 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:49 --> URI Class Initialized
INFO - 2023-12-06 16:30:49 --> Router Class Initialized
INFO - 2023-12-06 16:30:49 --> Output Class Initialized
INFO - 2023-12-06 16:30:49 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:49 --> Input Class Initialized
INFO - 2023-12-06 16:30:49 --> Language Class Initialized
INFO - 2023-12-06 16:30:49 --> Language Class Initialized
INFO - 2023-12-06 16:30:49 --> Config Class Initialized
INFO - 2023-12-06 16:30:49 --> Loader Class Initialized
INFO - 2023-12-06 16:30:49 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:49 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:49 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:49 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:49 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:49 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:30:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:49 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:49 --> Total execution time: 0.0398
INFO - 2023-12-06 16:30:53 --> Config Class Initialized
INFO - 2023-12-06 16:30:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:53 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:53 --> URI Class Initialized
INFO - 2023-12-06 16:30:53 --> Router Class Initialized
INFO - 2023-12-06 16:30:53 --> Output Class Initialized
INFO - 2023-12-06 16:30:53 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:53 --> Input Class Initialized
INFO - 2023-12-06 16:30:53 --> Language Class Initialized
INFO - 2023-12-06 16:30:53 --> Language Class Initialized
INFO - 2023-12-06 16:30:53 --> Config Class Initialized
INFO - 2023-12-06 16:30:53 --> Loader Class Initialized
INFO - 2023-12-06 16:30:53 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:53 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:53 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:53 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:53 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:53 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 16:30:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:53 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:53 --> Total execution time: 0.0991
INFO - 2023-12-06 16:30:54 --> Config Class Initialized
INFO - 2023-12-06 16:30:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:54 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:54 --> URI Class Initialized
INFO - 2023-12-06 16:30:54 --> Router Class Initialized
INFO - 2023-12-06 16:30:54 --> Output Class Initialized
INFO - 2023-12-06 16:30:54 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:54 --> Input Class Initialized
INFO - 2023-12-06 16:30:54 --> Language Class Initialized
INFO - 2023-12-06 16:30:54 --> Language Class Initialized
INFO - 2023-12-06 16:30:54 --> Config Class Initialized
INFO - 2023-12-06 16:30:54 --> Loader Class Initialized
INFO - 2023-12-06 16:30:54 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:54 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:54 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:54 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:54 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:54 --> Controller Class Initialized
INFO - 2023-12-06 16:30:58 --> Config Class Initialized
INFO - 2023-12-06 16:30:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:30:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:30:58 --> Utf8 Class Initialized
INFO - 2023-12-06 16:30:58 --> URI Class Initialized
INFO - 2023-12-06 16:30:58 --> Router Class Initialized
INFO - 2023-12-06 16:30:58 --> Output Class Initialized
INFO - 2023-12-06 16:30:58 --> Security Class Initialized
DEBUG - 2023-12-06 16:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:30:58 --> Input Class Initialized
INFO - 2023-12-06 16:30:58 --> Language Class Initialized
INFO - 2023-12-06 16:30:58 --> Language Class Initialized
INFO - 2023-12-06 16:30:58 --> Config Class Initialized
INFO - 2023-12-06 16:30:58 --> Loader Class Initialized
INFO - 2023-12-06 16:30:58 --> Helper loaded: url_helper
INFO - 2023-12-06 16:30:58 --> Helper loaded: file_helper
INFO - 2023-12-06 16:30:58 --> Helper loaded: form_helper
INFO - 2023-12-06 16:30:58 --> Helper loaded: my_helper
INFO - 2023-12-06 16:30:58 --> Database Driver Class Initialized
INFO - 2023-12-06 16:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:30:58 --> Controller Class Initialized
DEBUG - 2023-12-06 16:30:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:30:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:30:58 --> Final output sent to browser
DEBUG - 2023-12-06 16:30:58 --> Total execution time: 0.0406
INFO - 2023-12-06 16:31:01 --> Config Class Initialized
INFO - 2023-12-06 16:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:31:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:31:01 --> URI Class Initialized
INFO - 2023-12-06 16:31:01 --> Router Class Initialized
INFO - 2023-12-06 16:31:01 --> Output Class Initialized
INFO - 2023-12-06 16:31:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:31:01 --> Input Class Initialized
INFO - 2023-12-06 16:31:01 --> Language Class Initialized
INFO - 2023-12-06 16:31:01 --> Language Class Initialized
INFO - 2023-12-06 16:31:01 --> Config Class Initialized
INFO - 2023-12-06 16:31:01 --> Loader Class Initialized
INFO - 2023-12-06 16:31:01 --> Helper loaded: url_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: file_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: form_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: my_helper
INFO - 2023-12-06 16:31:01 --> Database Driver Class Initialized
INFO - 2023-12-06 16:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:31:01 --> Controller Class Initialized
DEBUG - 2023-12-06 16:31:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-06 16:31:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:31:01 --> Final output sent to browser
DEBUG - 2023-12-06 16:31:01 --> Total execution time: 0.1801
INFO - 2023-12-06 16:31:01 --> Config Class Initialized
INFO - 2023-12-06 16:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:31:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:31:01 --> URI Class Initialized
INFO - 2023-12-06 16:31:01 --> Router Class Initialized
INFO - 2023-12-06 16:31:01 --> Output Class Initialized
INFO - 2023-12-06 16:31:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:31:01 --> Input Class Initialized
INFO - 2023-12-06 16:31:01 --> Language Class Initialized
INFO - 2023-12-06 16:31:01 --> Language Class Initialized
INFO - 2023-12-06 16:31:01 --> Config Class Initialized
INFO - 2023-12-06 16:31:01 --> Loader Class Initialized
INFO - 2023-12-06 16:31:01 --> Helper loaded: url_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: file_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: form_helper
INFO - 2023-12-06 16:31:01 --> Helper loaded: my_helper
INFO - 2023-12-06 16:31:01 --> Database Driver Class Initialized
INFO - 2023-12-06 16:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:31:01 --> Controller Class Initialized
INFO - 2023-12-06 16:31:15 --> Config Class Initialized
INFO - 2023-12-06 16:31:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:31:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:31:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:31:15 --> URI Class Initialized
INFO - 2023-12-06 16:31:15 --> Router Class Initialized
INFO - 2023-12-06 16:31:15 --> Output Class Initialized
INFO - 2023-12-06 16:31:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:31:15 --> Input Class Initialized
INFO - 2023-12-06 16:31:15 --> Language Class Initialized
INFO - 2023-12-06 16:31:15 --> Language Class Initialized
INFO - 2023-12-06 16:31:15 --> Config Class Initialized
INFO - 2023-12-06 16:31:15 --> Loader Class Initialized
INFO - 2023-12-06 16:31:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:31:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:31:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:31:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:31:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:31:15 --> Controller Class Initialized
INFO - 2023-12-06 16:31:15 --> Final output sent to browser
DEBUG - 2023-12-06 16:31:15 --> Total execution time: 0.0411
INFO - 2023-12-06 16:31:19 --> Config Class Initialized
INFO - 2023-12-06 16:31:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:31:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:31:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:31:19 --> URI Class Initialized
INFO - 2023-12-06 16:31:19 --> Router Class Initialized
INFO - 2023-12-06 16:31:19 --> Output Class Initialized
INFO - 2023-12-06 16:31:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:31:19 --> Input Class Initialized
INFO - 2023-12-06 16:31:19 --> Language Class Initialized
INFO - 2023-12-06 16:31:19 --> Language Class Initialized
INFO - 2023-12-06 16:31:19 --> Config Class Initialized
INFO - 2023-12-06 16:31:19 --> Loader Class Initialized
INFO - 2023-12-06 16:31:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:31:19 --> Helper loaded: file_helper
INFO - 2023-12-06 16:31:19 --> Helper loaded: form_helper
INFO - 2023-12-06 16:31:19 --> Helper loaded: my_helper
INFO - 2023-12-06 16:31:20 --> Database Driver Class Initialized
INFO - 2023-12-06 16:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:31:20 --> Controller Class Initialized
DEBUG - 2023-12-06 16:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-06 16:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:31:20 --> Final output sent to browser
DEBUG - 2023-12-06 16:31:20 --> Total execution time: 0.1349
INFO - 2023-12-06 16:32:21 --> Config Class Initialized
INFO - 2023-12-06 16:32:21 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:32:21 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:32:21 --> Utf8 Class Initialized
INFO - 2023-12-06 16:32:21 --> URI Class Initialized
INFO - 2023-12-06 16:32:21 --> Router Class Initialized
INFO - 2023-12-06 16:32:21 --> Output Class Initialized
INFO - 2023-12-06 16:32:21 --> Security Class Initialized
DEBUG - 2023-12-06 16:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:32:21 --> Input Class Initialized
INFO - 2023-12-06 16:32:21 --> Language Class Initialized
INFO - 2023-12-06 16:32:21 --> Language Class Initialized
INFO - 2023-12-06 16:32:21 --> Config Class Initialized
INFO - 2023-12-06 16:32:21 --> Loader Class Initialized
INFO - 2023-12-06 16:32:21 --> Helper loaded: url_helper
INFO - 2023-12-06 16:32:21 --> Helper loaded: file_helper
INFO - 2023-12-06 16:32:21 --> Helper loaded: form_helper
INFO - 2023-12-06 16:32:21 --> Helper loaded: my_helper
INFO - 2023-12-06 16:32:21 --> Database Driver Class Initialized
INFO - 2023-12-06 16:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:32:21 --> Controller Class Initialized
DEBUG - 2023-12-06 16:32:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-06 16:32:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:32:21 --> Final output sent to browser
DEBUG - 2023-12-06 16:32:21 --> Total execution time: 0.0510
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:27 --> URI Class Initialized
INFO - 2023-12-06 16:34:27 --> Router Class Initialized
INFO - 2023-12-06 16:34:27 --> Output Class Initialized
INFO - 2023-12-06 16:34:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:27 --> Input Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Loader Class Initialized
INFO - 2023-12-06 16:34:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:27 --> Controller Class Initialized
INFO - 2023-12-06 16:34:27 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:27 --> URI Class Initialized
INFO - 2023-12-06 16:34:27 --> Router Class Initialized
INFO - 2023-12-06 16:34:27 --> Output Class Initialized
INFO - 2023-12-06 16:34:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:27 --> Input Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Loader Class Initialized
INFO - 2023-12-06 16:34:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:27 --> Controller Class Initialized
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:27 --> URI Class Initialized
INFO - 2023-12-06 16:34:27 --> Router Class Initialized
INFO - 2023-12-06 16:34:27 --> Output Class Initialized
INFO - 2023-12-06 16:34:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:27 --> Input Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Language Class Initialized
INFO - 2023-12-06 16:34:27 --> Config Class Initialized
INFO - 2023-12-06 16:34:27 --> Loader Class Initialized
INFO - 2023-12-06 16:34:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:27 --> Controller Class Initialized
DEBUG - 2023-12-06 16:34:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:34:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:34:27 --> Final output sent to browser
DEBUG - 2023-12-06 16:34:27 --> Total execution time: 0.0631
INFO - 2023-12-06 16:34:40 --> Config Class Initialized
INFO - 2023-12-06 16:34:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:40 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:40 --> URI Class Initialized
INFO - 2023-12-06 16:34:40 --> Router Class Initialized
INFO - 2023-12-06 16:34:40 --> Output Class Initialized
INFO - 2023-12-06 16:34:40 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:40 --> Input Class Initialized
INFO - 2023-12-06 16:34:40 --> Language Class Initialized
INFO - 2023-12-06 16:34:40 --> Language Class Initialized
INFO - 2023-12-06 16:34:40 --> Config Class Initialized
INFO - 2023-12-06 16:34:40 --> Loader Class Initialized
INFO - 2023-12-06 16:34:40 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:40 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:40 --> Controller Class Initialized
INFO - 2023-12-06 16:34:40 --> Config Class Initialized
INFO - 2023-12-06 16:34:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:40 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:40 --> URI Class Initialized
INFO - 2023-12-06 16:34:40 --> Router Class Initialized
INFO - 2023-12-06 16:34:40 --> Output Class Initialized
INFO - 2023-12-06 16:34:40 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:40 --> Input Class Initialized
INFO - 2023-12-06 16:34:40 --> Language Class Initialized
INFO - 2023-12-06 16:34:40 --> Language Class Initialized
INFO - 2023-12-06 16:34:40 --> Config Class Initialized
INFO - 2023-12-06 16:34:40 --> Loader Class Initialized
INFO - 2023-12-06 16:34:40 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:40 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:40 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:40 --> Controller Class Initialized
DEBUG - 2023-12-06 16:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:34:40 --> Final output sent to browser
DEBUG - 2023-12-06 16:34:40 --> Total execution time: 0.0715
INFO - 2023-12-06 16:34:59 --> Config Class Initialized
INFO - 2023-12-06 16:34:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:59 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:59 --> URI Class Initialized
INFO - 2023-12-06 16:34:59 --> Router Class Initialized
INFO - 2023-12-06 16:34:59 --> Output Class Initialized
INFO - 2023-12-06 16:34:59 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:59 --> Input Class Initialized
INFO - 2023-12-06 16:34:59 --> Language Class Initialized
INFO - 2023-12-06 16:34:59 --> Language Class Initialized
INFO - 2023-12-06 16:34:59 --> Config Class Initialized
INFO - 2023-12-06 16:34:59 --> Loader Class Initialized
INFO - 2023-12-06 16:34:59 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:59 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:59 --> Controller Class Initialized
INFO - 2023-12-06 16:34:59 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:34:59 --> Final output sent to browser
DEBUG - 2023-12-06 16:34:59 --> Total execution time: 0.0917
INFO - 2023-12-06 16:34:59 --> Config Class Initialized
INFO - 2023-12-06 16:34:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:34:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:34:59 --> Utf8 Class Initialized
INFO - 2023-12-06 16:34:59 --> URI Class Initialized
INFO - 2023-12-06 16:34:59 --> Router Class Initialized
INFO - 2023-12-06 16:34:59 --> Output Class Initialized
INFO - 2023-12-06 16:34:59 --> Security Class Initialized
DEBUG - 2023-12-06 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:34:59 --> Input Class Initialized
INFO - 2023-12-06 16:34:59 --> Language Class Initialized
INFO - 2023-12-06 16:34:59 --> Language Class Initialized
INFO - 2023-12-06 16:34:59 --> Config Class Initialized
INFO - 2023-12-06 16:34:59 --> Loader Class Initialized
INFO - 2023-12-06 16:34:59 --> Helper loaded: url_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: file_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: form_helper
INFO - 2023-12-06 16:34:59 --> Helper loaded: my_helper
INFO - 2023-12-06 16:34:59 --> Database Driver Class Initialized
INFO - 2023-12-06 16:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:34:59 --> Controller Class Initialized
DEBUG - 2023-12-06 16:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-06 16:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:34:59 --> Final output sent to browser
DEBUG - 2023-12-06 16:34:59 --> Total execution time: 0.0485
INFO - 2023-12-06 16:35:01 --> Config Class Initialized
INFO - 2023-12-06 16:35:01 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:01 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:01 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:01 --> URI Class Initialized
INFO - 2023-12-06 16:35:01 --> Router Class Initialized
INFO - 2023-12-06 16:35:01 --> Output Class Initialized
INFO - 2023-12-06 16:35:01 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:01 --> Input Class Initialized
INFO - 2023-12-06 16:35:01 --> Language Class Initialized
INFO - 2023-12-06 16:35:01 --> Language Class Initialized
INFO - 2023-12-06 16:35:01 --> Config Class Initialized
INFO - 2023-12-06 16:35:01 --> Loader Class Initialized
INFO - 2023-12-06 16:35:01 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:01 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:01 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:01 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:01 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:01 --> Controller Class Initialized
INFO - 2023-12-06 16:35:01 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:35:01 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:01 --> Total execution time: 0.0764
INFO - 2023-12-06 16:35:02 --> Config Class Initialized
INFO - 2023-12-06 16:35:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:02 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:02 --> URI Class Initialized
INFO - 2023-12-06 16:35:02 --> Router Class Initialized
INFO - 2023-12-06 16:35:02 --> Output Class Initialized
INFO - 2023-12-06 16:35:02 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:02 --> Input Class Initialized
INFO - 2023-12-06 16:35:02 --> Language Class Initialized
INFO - 2023-12-06 16:35:02 --> Language Class Initialized
INFO - 2023-12-06 16:35:02 --> Config Class Initialized
INFO - 2023-12-06 16:35:02 --> Loader Class Initialized
INFO - 2023-12-06 16:35:02 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:02 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:02 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:02 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:02 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:02 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:02 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:02 --> Total execution time: 0.0610
INFO - 2023-12-06 16:35:14 --> Config Class Initialized
INFO - 2023-12-06 16:35:14 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:14 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:14 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:14 --> URI Class Initialized
INFO - 2023-12-06 16:35:14 --> Router Class Initialized
INFO - 2023-12-06 16:35:14 --> Output Class Initialized
INFO - 2023-12-06 16:35:14 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:14 --> Input Class Initialized
INFO - 2023-12-06 16:35:14 --> Language Class Initialized
INFO - 2023-12-06 16:35:14 --> Language Class Initialized
INFO - 2023-12-06 16:35:14 --> Config Class Initialized
INFO - 2023-12-06 16:35:14 --> Loader Class Initialized
INFO - 2023-12-06 16:35:14 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:14 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:14 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:14 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:14 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:14 --> Controller Class Initialized
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:14 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:35:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:35:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:14 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:14 --> Total execution time: 0.0427
INFO - 2023-12-06 16:35:27 --> Config Class Initialized
INFO - 2023-12-06 16:35:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:27 --> URI Class Initialized
INFO - 2023-12-06 16:35:27 --> Router Class Initialized
INFO - 2023-12-06 16:35:27 --> Output Class Initialized
INFO - 2023-12-06 16:35:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:27 --> Input Class Initialized
INFO - 2023-12-06 16:35:27 --> Language Class Initialized
INFO - 2023-12-06 16:35:28 --> Language Class Initialized
INFO - 2023-12-06 16:35:28 --> Config Class Initialized
INFO - 2023-12-06 16:35:28 --> Loader Class Initialized
INFO - 2023-12-06 16:35:28 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:28 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:28 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:28 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:28 --> Total execution time: 0.0405
INFO - 2023-12-06 16:35:28 --> Config Class Initialized
INFO - 2023-12-06 16:35:28 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:28 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:28 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:28 --> URI Class Initialized
INFO - 2023-12-06 16:35:28 --> Router Class Initialized
INFO - 2023-12-06 16:35:28 --> Output Class Initialized
INFO - 2023-12-06 16:35:28 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:28 --> Input Class Initialized
INFO - 2023-12-06 16:35:28 --> Language Class Initialized
INFO - 2023-12-06 16:35:28 --> Language Class Initialized
INFO - 2023-12-06 16:35:28 --> Config Class Initialized
INFO - 2023-12-06 16:35:28 --> Loader Class Initialized
INFO - 2023-12-06 16:35:28 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:28 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:28 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:28 --> Controller Class Initialized
INFO - 2023-12-06 16:35:29 --> Config Class Initialized
INFO - 2023-12-06 16:35:29 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:29 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:29 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:29 --> URI Class Initialized
INFO - 2023-12-06 16:35:29 --> Router Class Initialized
INFO - 2023-12-06 16:35:29 --> Output Class Initialized
INFO - 2023-12-06 16:35:29 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:29 --> Input Class Initialized
INFO - 2023-12-06 16:35:29 --> Language Class Initialized
INFO - 2023-12-06 16:35:29 --> Language Class Initialized
INFO - 2023-12-06 16:35:29 --> Config Class Initialized
INFO - 2023-12-06 16:35:29 --> Loader Class Initialized
INFO - 2023-12-06 16:35:29 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:29 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:29 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:29 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:29 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:29 --> Controller Class Initialized
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:35:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:35:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:35:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:29 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:29 --> Total execution time: 0.0702
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:34 --> URI Class Initialized
INFO - 2023-12-06 16:35:34 --> Router Class Initialized
INFO - 2023-12-06 16:35:34 --> Output Class Initialized
INFO - 2023-12-06 16:35:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:34 --> Input Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Loader Class Initialized
INFO - 2023-12-06 16:35:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:34 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2023-12-06 16:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:34 --> Total execution time: 0.0384
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:34 --> URI Class Initialized
INFO - 2023-12-06 16:35:34 --> Router Class Initialized
INFO - 2023-12-06 16:35:34 --> Output Class Initialized
INFO - 2023-12-06 16:35:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:34 --> Input Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Loader Class Initialized
INFO - 2023-12-06 16:35:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:34 --> Controller Class Initialized
INFO - 2023-12-06 16:35:34 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:34 --> URI Class Initialized
INFO - 2023-12-06 16:35:34 --> Router Class Initialized
INFO - 2023-12-06 16:35:34 --> Output Class Initialized
INFO - 2023-12-06 16:35:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:34 --> Input Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Loader Class Initialized
INFO - 2023-12-06 16:35:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:34 --> Controller Class Initialized
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:34 --> URI Class Initialized
INFO - 2023-12-06 16:35:34 --> Router Class Initialized
INFO - 2023-12-06 16:35:34 --> Output Class Initialized
INFO - 2023-12-06 16:35:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:34 --> Input Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Language Class Initialized
INFO - 2023-12-06 16:35:34 --> Config Class Initialized
INFO - 2023-12-06 16:35:34 --> Loader Class Initialized
INFO - 2023-12-06 16:35:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:34 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:34 --> Total execution time: 0.0839
INFO - 2023-12-06 16:35:40 --> Config Class Initialized
INFO - 2023-12-06 16:35:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:40 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:40 --> URI Class Initialized
INFO - 2023-12-06 16:35:40 --> Router Class Initialized
INFO - 2023-12-06 16:35:40 --> Output Class Initialized
INFO - 2023-12-06 16:35:40 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:40 --> Input Class Initialized
INFO - 2023-12-06 16:35:40 --> Language Class Initialized
INFO - 2023-12-06 16:35:40 --> Language Class Initialized
INFO - 2023-12-06 16:35:40 --> Config Class Initialized
INFO - 2023-12-06 16:35:40 --> Loader Class Initialized
INFO - 2023-12-06 16:35:40 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:40 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:40 --> Controller Class Initialized
INFO - 2023-12-06 16:35:40 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:35:40 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:40 --> Total execution time: 0.0831
INFO - 2023-12-06 16:35:40 --> Config Class Initialized
INFO - 2023-12-06 16:35:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:40 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:40 --> URI Class Initialized
INFO - 2023-12-06 16:35:40 --> Router Class Initialized
INFO - 2023-12-06 16:35:40 --> Output Class Initialized
INFO - 2023-12-06 16:35:40 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:40 --> Input Class Initialized
INFO - 2023-12-06 16:35:40 --> Language Class Initialized
INFO - 2023-12-06 16:35:40 --> Language Class Initialized
INFO - 2023-12-06 16:35:40 --> Config Class Initialized
INFO - 2023-12-06 16:35:40 --> Loader Class Initialized
INFO - 2023-12-06 16:35:40 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:40 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:40 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:40 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:40 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:40 --> Total execution time: 0.0342
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:41 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:41 --> URI Class Initialized
INFO - 2023-12-06 16:35:41 --> Router Class Initialized
INFO - 2023-12-06 16:35:41 --> Output Class Initialized
INFO - 2023-12-06 16:35:41 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:41 --> Input Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Loader Class Initialized
INFO - 2023-12-06 16:35:41 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:41 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:41 --> Controller Class Initialized
INFO - 2023-12-06 16:35:41 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:41 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:41 --> URI Class Initialized
INFO - 2023-12-06 16:35:41 --> Router Class Initialized
INFO - 2023-12-06 16:35:41 --> Output Class Initialized
INFO - 2023-12-06 16:35:41 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:41 --> Input Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Loader Class Initialized
INFO - 2023-12-06 16:35:41 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:41 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:41 --> Controller Class Initialized
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:41 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:41 --> URI Class Initialized
INFO - 2023-12-06 16:35:41 --> Router Class Initialized
INFO - 2023-12-06 16:35:41 --> Output Class Initialized
INFO - 2023-12-06 16:35:41 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:41 --> Input Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Language Class Initialized
INFO - 2023-12-06 16:35:41 --> Config Class Initialized
INFO - 2023-12-06 16:35:41 --> Loader Class Initialized
INFO - 2023-12-06 16:35:41 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:41 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:41 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:41 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:41 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:41 --> Total execution time: 0.0626
INFO - 2023-12-06 16:35:45 --> Config Class Initialized
INFO - 2023-12-06 16:35:45 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:45 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:45 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:45 --> URI Class Initialized
INFO - 2023-12-06 16:35:45 --> Router Class Initialized
INFO - 2023-12-06 16:35:45 --> Output Class Initialized
INFO - 2023-12-06 16:35:45 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:45 --> Input Class Initialized
INFO - 2023-12-06 16:35:45 --> Language Class Initialized
INFO - 2023-12-06 16:35:45 --> Language Class Initialized
INFO - 2023-12-06 16:35:45 --> Config Class Initialized
INFO - 2023-12-06 16:35:45 --> Loader Class Initialized
INFO - 2023-12-06 16:35:45 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:45 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:45 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:45 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:45 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:45 --> Controller Class Initialized
DEBUG - 2023-12-06 16:35:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-06 16:35:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:35:45 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:45 --> Total execution time: 0.0495
INFO - 2023-12-06 16:35:50 --> Config Class Initialized
INFO - 2023-12-06 16:35:50 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:35:50 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:35:50 --> Utf8 Class Initialized
INFO - 2023-12-06 16:35:50 --> URI Class Initialized
INFO - 2023-12-06 16:35:50 --> Router Class Initialized
INFO - 2023-12-06 16:35:50 --> Output Class Initialized
INFO - 2023-12-06 16:35:50 --> Security Class Initialized
DEBUG - 2023-12-06 16:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:35:50 --> Input Class Initialized
INFO - 2023-12-06 16:35:50 --> Language Class Initialized
INFO - 2023-12-06 16:35:50 --> Language Class Initialized
INFO - 2023-12-06 16:35:50 --> Config Class Initialized
INFO - 2023-12-06 16:35:50 --> Loader Class Initialized
INFO - 2023-12-06 16:35:50 --> Helper loaded: url_helper
INFO - 2023-12-06 16:35:50 --> Helper loaded: file_helper
INFO - 2023-12-06 16:35:50 --> Helper loaded: form_helper
INFO - 2023-12-06 16:35:50 --> Helper loaded: my_helper
INFO - 2023-12-06 16:35:50 --> Database Driver Class Initialized
INFO - 2023-12-06 16:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:35:50 --> Controller Class Initialized
ERROR - 2023-12-06 16:35:50 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-06 16:35:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-06 16:35:55 --> Final output sent to browser
DEBUG - 2023-12-06 16:35:55 --> Total execution time: 5.3323
INFO - 2023-12-06 16:36:30 --> Config Class Initialized
INFO - 2023-12-06 16:36:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:36:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:36:30 --> Utf8 Class Initialized
INFO - 2023-12-06 16:36:30 --> URI Class Initialized
INFO - 2023-12-06 16:36:30 --> Router Class Initialized
INFO - 2023-12-06 16:36:30 --> Output Class Initialized
INFO - 2023-12-06 16:36:30 --> Security Class Initialized
DEBUG - 2023-12-06 16:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:36:30 --> Input Class Initialized
INFO - 2023-12-06 16:36:30 --> Language Class Initialized
INFO - 2023-12-06 16:36:30 --> Language Class Initialized
INFO - 2023-12-06 16:36:30 --> Config Class Initialized
INFO - 2023-12-06 16:36:30 --> Loader Class Initialized
INFO - 2023-12-06 16:36:30 --> Helper loaded: url_helper
INFO - 2023-12-06 16:36:30 --> Helper loaded: file_helper
INFO - 2023-12-06 16:36:30 --> Helper loaded: form_helper
INFO - 2023-12-06 16:36:30 --> Helper loaded: my_helper
INFO - 2023-12-06 16:36:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:36:30 --> Controller Class Initialized
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:36:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:36:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:36:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:36:30 --> Final output sent to browser
DEBUG - 2023-12-06 16:36:30 --> Total execution time: 0.0676
INFO - 2023-12-06 16:36:55 --> Config Class Initialized
INFO - 2023-12-06 16:36:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:36:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:36:55 --> Utf8 Class Initialized
INFO - 2023-12-06 16:36:55 --> URI Class Initialized
INFO - 2023-12-06 16:36:55 --> Router Class Initialized
INFO - 2023-12-06 16:36:55 --> Output Class Initialized
INFO - 2023-12-06 16:36:55 --> Security Class Initialized
DEBUG - 2023-12-06 16:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:36:55 --> Input Class Initialized
INFO - 2023-12-06 16:36:55 --> Language Class Initialized
INFO - 2023-12-06 16:36:55 --> Language Class Initialized
INFO - 2023-12-06 16:36:55 --> Config Class Initialized
INFO - 2023-12-06 16:36:55 --> Loader Class Initialized
INFO - 2023-12-06 16:36:55 --> Helper loaded: url_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: file_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: form_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: my_helper
INFO - 2023-12-06 16:36:55 --> Database Driver Class Initialized
INFO - 2023-12-06 16:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:36:55 --> Controller Class Initialized
DEBUG - 2023-12-06 16:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:36:55 --> Final output sent to browser
DEBUG - 2023-12-06 16:36:55 --> Total execution time: 0.0437
INFO - 2023-12-06 16:36:55 --> Config Class Initialized
INFO - 2023-12-06 16:36:55 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:36:55 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:36:55 --> Utf8 Class Initialized
INFO - 2023-12-06 16:36:55 --> URI Class Initialized
INFO - 2023-12-06 16:36:55 --> Router Class Initialized
INFO - 2023-12-06 16:36:55 --> Output Class Initialized
INFO - 2023-12-06 16:36:55 --> Security Class Initialized
DEBUG - 2023-12-06 16:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:36:55 --> Input Class Initialized
INFO - 2023-12-06 16:36:55 --> Language Class Initialized
INFO - 2023-12-06 16:36:55 --> Language Class Initialized
INFO - 2023-12-06 16:36:55 --> Config Class Initialized
INFO - 2023-12-06 16:36:55 --> Loader Class Initialized
INFO - 2023-12-06 16:36:55 --> Helper loaded: url_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: file_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: form_helper
INFO - 2023-12-06 16:36:55 --> Helper loaded: my_helper
INFO - 2023-12-06 16:36:55 --> Database Driver Class Initialized
INFO - 2023-12-06 16:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:36:55 --> Controller Class Initialized
INFO - 2023-12-06 16:36:58 --> Config Class Initialized
INFO - 2023-12-06 16:36:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:36:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:36:58 --> Utf8 Class Initialized
INFO - 2023-12-06 16:36:58 --> URI Class Initialized
INFO - 2023-12-06 16:36:58 --> Router Class Initialized
INFO - 2023-12-06 16:36:58 --> Output Class Initialized
INFO - 2023-12-06 16:36:58 --> Security Class Initialized
DEBUG - 2023-12-06 16:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:36:58 --> Input Class Initialized
INFO - 2023-12-06 16:36:58 --> Language Class Initialized
INFO - 2023-12-06 16:36:58 --> Language Class Initialized
INFO - 2023-12-06 16:36:58 --> Config Class Initialized
INFO - 2023-12-06 16:36:58 --> Loader Class Initialized
INFO - 2023-12-06 16:36:58 --> Helper loaded: url_helper
INFO - 2023-12-06 16:36:58 --> Helper loaded: file_helper
INFO - 2023-12-06 16:36:58 --> Helper loaded: form_helper
INFO - 2023-12-06 16:36:58 --> Helper loaded: my_helper
INFO - 2023-12-06 16:36:58 --> Database Driver Class Initialized
INFO - 2023-12-06 16:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:36:58 --> Controller Class Initialized
INFO - 2023-12-06 16:36:58 --> Final output sent to browser
DEBUG - 2023-12-06 16:36:58 --> Total execution time: 0.0445
INFO - 2023-12-06 16:37:06 --> Config Class Initialized
INFO - 2023-12-06 16:37:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:06 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:06 --> URI Class Initialized
INFO - 2023-12-06 16:37:06 --> Router Class Initialized
INFO - 2023-12-06 16:37:06 --> Output Class Initialized
INFO - 2023-12-06 16:37:06 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:06 --> Input Class Initialized
INFO - 2023-12-06 16:37:06 --> Language Class Initialized
INFO - 2023-12-06 16:37:06 --> Language Class Initialized
INFO - 2023-12-06 16:37:06 --> Config Class Initialized
INFO - 2023-12-06 16:37:06 --> Loader Class Initialized
INFO - 2023-12-06 16:37:06 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:06 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:06 --> Controller Class Initialized
INFO - 2023-12-06 16:37:06 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:06 --> Total execution time: 0.0386
INFO - 2023-12-06 16:37:06 --> Config Class Initialized
INFO - 2023-12-06 16:37:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:06 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:06 --> URI Class Initialized
INFO - 2023-12-06 16:37:06 --> Router Class Initialized
INFO - 2023-12-06 16:37:06 --> Output Class Initialized
INFO - 2023-12-06 16:37:06 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:06 --> Input Class Initialized
INFO - 2023-12-06 16:37:06 --> Language Class Initialized
INFO - 2023-12-06 16:37:06 --> Language Class Initialized
INFO - 2023-12-06 16:37:06 --> Config Class Initialized
INFO - 2023-12-06 16:37:06 --> Loader Class Initialized
INFO - 2023-12-06 16:37:06 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:06 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:06 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:06 --> Controller Class Initialized
INFO - 2023-12-06 16:37:10 --> Config Class Initialized
INFO - 2023-12-06 16:37:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:10 --> URI Class Initialized
INFO - 2023-12-06 16:37:10 --> Router Class Initialized
INFO - 2023-12-06 16:37:10 --> Output Class Initialized
INFO - 2023-12-06 16:37:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:10 --> Input Class Initialized
INFO - 2023-12-06 16:37:10 --> Language Class Initialized
INFO - 2023-12-06 16:37:10 --> Language Class Initialized
INFO - 2023-12-06 16:37:10 --> Config Class Initialized
INFO - 2023-12-06 16:37:10 --> Loader Class Initialized
INFO - 2023-12-06 16:37:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:10 --> Controller Class Initialized
INFO - 2023-12-06 16:37:10 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:10 --> Total execution time: 0.0723
INFO - 2023-12-06 16:37:22 --> Config Class Initialized
INFO - 2023-12-06 16:37:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:22 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:22 --> URI Class Initialized
INFO - 2023-12-06 16:37:22 --> Router Class Initialized
INFO - 2023-12-06 16:37:22 --> Output Class Initialized
INFO - 2023-12-06 16:37:22 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:22 --> Input Class Initialized
INFO - 2023-12-06 16:37:22 --> Language Class Initialized
INFO - 2023-12-06 16:37:22 --> Language Class Initialized
INFO - 2023-12-06 16:37:22 --> Config Class Initialized
INFO - 2023-12-06 16:37:22 --> Loader Class Initialized
INFO - 2023-12-06 16:37:22 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:22 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:22 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:22 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:22 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:22 --> Controller Class Initialized
DEBUG - 2023-12-06 16:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:37:22 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:22 --> Total execution time: 0.0624
INFO - 2023-12-06 16:37:32 --> Config Class Initialized
INFO - 2023-12-06 16:37:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:32 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:32 --> URI Class Initialized
INFO - 2023-12-06 16:37:32 --> Router Class Initialized
INFO - 2023-12-06 16:37:32 --> Output Class Initialized
INFO - 2023-12-06 16:37:32 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:32 --> Input Class Initialized
INFO - 2023-12-06 16:37:32 --> Language Class Initialized
INFO - 2023-12-06 16:37:32 --> Language Class Initialized
INFO - 2023-12-06 16:37:32 --> Config Class Initialized
INFO - 2023-12-06 16:37:32 --> Loader Class Initialized
INFO - 2023-12-06 16:37:32 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:32 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:32 --> Controller Class Initialized
INFO - 2023-12-06 16:37:32 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:37:32 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:32 --> Total execution time: 0.0395
INFO - 2023-12-06 16:37:32 --> Config Class Initialized
INFO - 2023-12-06 16:37:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:32 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:32 --> URI Class Initialized
INFO - 2023-12-06 16:37:32 --> Router Class Initialized
INFO - 2023-12-06 16:37:32 --> Output Class Initialized
INFO - 2023-12-06 16:37:32 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:32 --> Input Class Initialized
INFO - 2023-12-06 16:37:32 --> Language Class Initialized
INFO - 2023-12-06 16:37:32 --> Language Class Initialized
INFO - 2023-12-06 16:37:32 --> Config Class Initialized
INFO - 2023-12-06 16:37:32 --> Loader Class Initialized
INFO - 2023-12-06 16:37:32 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:32 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:33 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:33 --> Controller Class Initialized
DEBUG - 2023-12-06 16:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:37:33 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:33 --> Total execution time: 0.2503
INFO - 2023-12-06 16:37:40 --> Config Class Initialized
INFO - 2023-12-06 16:37:40 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:40 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:40 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:40 --> URI Class Initialized
INFO - 2023-12-06 16:37:40 --> Router Class Initialized
INFO - 2023-12-06 16:37:40 --> Output Class Initialized
INFO - 2023-12-06 16:37:40 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:40 --> Input Class Initialized
INFO - 2023-12-06 16:37:40 --> Language Class Initialized
INFO - 2023-12-06 16:37:40 --> Language Class Initialized
INFO - 2023-12-06 16:37:40 --> Config Class Initialized
INFO - 2023-12-06 16:37:40 --> Loader Class Initialized
INFO - 2023-12-06 16:37:40 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:40 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:40 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:40 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:40 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:40 --> Controller Class Initialized
INFO - 2023-12-06 16:37:41 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:41 --> Total execution time: 0.0903
INFO - 2023-12-06 16:37:41 --> Config Class Initialized
INFO - 2023-12-06 16:37:41 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:41 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:41 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:41 --> URI Class Initialized
INFO - 2023-12-06 16:37:41 --> Router Class Initialized
INFO - 2023-12-06 16:37:41 --> Output Class Initialized
INFO - 2023-12-06 16:37:41 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:41 --> Input Class Initialized
INFO - 2023-12-06 16:37:41 --> Language Class Initialized
INFO - 2023-12-06 16:37:41 --> Language Class Initialized
INFO - 2023-12-06 16:37:41 --> Config Class Initialized
INFO - 2023-12-06 16:37:41 --> Loader Class Initialized
INFO - 2023-12-06 16:37:41 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:41 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:41 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:41 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:41 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:41 --> Controller Class Initialized
INFO - 2023-12-06 16:37:52 --> Config Class Initialized
INFO - 2023-12-06 16:37:52 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:52 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:52 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:52 --> URI Class Initialized
INFO - 2023-12-06 16:37:52 --> Router Class Initialized
INFO - 2023-12-06 16:37:52 --> Output Class Initialized
INFO - 2023-12-06 16:37:52 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:52 --> Input Class Initialized
INFO - 2023-12-06 16:37:52 --> Language Class Initialized
INFO - 2023-12-06 16:37:52 --> Language Class Initialized
INFO - 2023-12-06 16:37:52 --> Config Class Initialized
INFO - 2023-12-06 16:37:52 --> Loader Class Initialized
INFO - 2023-12-06 16:37:52 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:52 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:52 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:52 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:52 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:52 --> Controller Class Initialized
INFO - 2023-12-06 16:37:52 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:52 --> Total execution time: 0.0357
INFO - 2023-12-06 16:37:56 --> Config Class Initialized
INFO - 2023-12-06 16:37:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:56 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:56 --> URI Class Initialized
DEBUG - 2023-12-06 16:37:56 --> No URI present. Default controller set.
INFO - 2023-12-06 16:37:56 --> Router Class Initialized
INFO - 2023-12-06 16:37:56 --> Output Class Initialized
INFO - 2023-12-06 16:37:56 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:56 --> Input Class Initialized
INFO - 2023-12-06 16:37:56 --> Language Class Initialized
INFO - 2023-12-06 16:37:56 --> Language Class Initialized
INFO - 2023-12-06 16:37:56 --> Config Class Initialized
INFO - 2023-12-06 16:37:56 --> Loader Class Initialized
INFO - 2023-12-06 16:37:56 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:56 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:56 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:56 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:56 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:56 --> Controller Class Initialized
DEBUG - 2023-12-06 16:37:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:37:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:37:56 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:56 --> Total execution time: 0.1225
INFO - 2023-12-06 16:37:59 --> Config Class Initialized
INFO - 2023-12-06 16:37:59 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:37:59 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:37:59 --> Utf8 Class Initialized
INFO - 2023-12-06 16:37:59 --> URI Class Initialized
DEBUG - 2023-12-06 16:37:59 --> No URI present. Default controller set.
INFO - 2023-12-06 16:37:59 --> Router Class Initialized
INFO - 2023-12-06 16:37:59 --> Output Class Initialized
INFO - 2023-12-06 16:37:59 --> Security Class Initialized
DEBUG - 2023-12-06 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:37:59 --> Input Class Initialized
INFO - 2023-12-06 16:37:59 --> Language Class Initialized
INFO - 2023-12-06 16:37:59 --> Language Class Initialized
INFO - 2023-12-06 16:37:59 --> Config Class Initialized
INFO - 2023-12-06 16:37:59 --> Loader Class Initialized
INFO - 2023-12-06 16:37:59 --> Helper loaded: url_helper
INFO - 2023-12-06 16:37:59 --> Helper loaded: file_helper
INFO - 2023-12-06 16:37:59 --> Helper loaded: form_helper
INFO - 2023-12-06 16:37:59 --> Helper loaded: my_helper
INFO - 2023-12-06 16:37:59 --> Database Driver Class Initialized
INFO - 2023-12-06 16:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:37:59 --> Controller Class Initialized
DEBUG - 2023-12-06 16:37:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:37:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:37:59 --> Final output sent to browser
DEBUG - 2023-12-06 16:37:59 --> Total execution time: 0.0688
INFO - 2023-12-06 16:38:02 --> Config Class Initialized
INFO - 2023-12-06 16:38:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:02 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:02 --> URI Class Initialized
INFO - 2023-12-06 16:38:02 --> Router Class Initialized
INFO - 2023-12-06 16:38:02 --> Output Class Initialized
INFO - 2023-12-06 16:38:02 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:02 --> Input Class Initialized
INFO - 2023-12-06 16:38:02 --> Language Class Initialized
INFO - 2023-12-06 16:38:02 --> Language Class Initialized
INFO - 2023-12-06 16:38:02 --> Config Class Initialized
INFO - 2023-12-06 16:38:02 --> Loader Class Initialized
INFO - 2023-12-06 16:38:02 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:02 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:02 --> Controller Class Initialized
INFO - 2023-12-06 16:38:02 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:02 --> Total execution time: 0.0493
INFO - 2023-12-06 16:38:02 --> Config Class Initialized
INFO - 2023-12-06 16:38:02 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:02 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:02 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:02 --> URI Class Initialized
INFO - 2023-12-06 16:38:02 --> Router Class Initialized
INFO - 2023-12-06 16:38:02 --> Output Class Initialized
INFO - 2023-12-06 16:38:02 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:02 --> Input Class Initialized
INFO - 2023-12-06 16:38:02 --> Language Class Initialized
INFO - 2023-12-06 16:38:02 --> Language Class Initialized
INFO - 2023-12-06 16:38:02 --> Config Class Initialized
INFO - 2023-12-06 16:38:02 --> Loader Class Initialized
INFO - 2023-12-06 16:38:02 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:02 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:02 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:02 --> Controller Class Initialized
INFO - 2023-12-06 16:38:04 --> Config Class Initialized
INFO - 2023-12-06 16:38:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:04 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:04 --> URI Class Initialized
DEBUG - 2023-12-06 16:38:04 --> No URI present. Default controller set.
INFO - 2023-12-06 16:38:04 --> Router Class Initialized
INFO - 2023-12-06 16:38:04 --> Output Class Initialized
INFO - 2023-12-06 16:38:04 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:04 --> Input Class Initialized
INFO - 2023-12-06 16:38:04 --> Language Class Initialized
INFO - 2023-12-06 16:38:04 --> Language Class Initialized
INFO - 2023-12-06 16:38:04 --> Config Class Initialized
INFO - 2023-12-06 16:38:04 --> Loader Class Initialized
INFO - 2023-12-06 16:38:04 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:04 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:04 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:04 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:04 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:04 --> Controller Class Initialized
DEBUG - 2023-12-06 16:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:38:04 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:04 --> Total execution time: 0.0768
INFO - 2023-12-06 16:38:09 --> Config Class Initialized
INFO - 2023-12-06 16:38:09 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:09 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:09 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:09 --> URI Class Initialized
INFO - 2023-12-06 16:38:09 --> Router Class Initialized
INFO - 2023-12-06 16:38:09 --> Output Class Initialized
INFO - 2023-12-06 16:38:09 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:09 --> Input Class Initialized
INFO - 2023-12-06 16:38:09 --> Language Class Initialized
INFO - 2023-12-06 16:38:09 --> Language Class Initialized
INFO - 2023-12-06 16:38:09 --> Config Class Initialized
INFO - 2023-12-06 16:38:09 --> Loader Class Initialized
INFO - 2023-12-06 16:38:09 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:09 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:09 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:09 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:09 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:09 --> Controller Class Initialized
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:38:09 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:38:09 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:09 --> Total execution time: 0.0979
INFO - 2023-12-06 16:38:11 --> Config Class Initialized
INFO - 2023-12-06 16:38:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:11 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:11 --> URI Class Initialized
INFO - 2023-12-06 16:38:11 --> Router Class Initialized
INFO - 2023-12-06 16:38:11 --> Output Class Initialized
INFO - 2023-12-06 16:38:11 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:11 --> Input Class Initialized
INFO - 2023-12-06 16:38:11 --> Language Class Initialized
INFO - 2023-12-06 16:38:11 --> Language Class Initialized
INFO - 2023-12-06 16:38:11 --> Config Class Initialized
INFO - 2023-12-06 16:38:11 --> Loader Class Initialized
INFO - 2023-12-06 16:38:11 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:11 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:11 --> Controller Class Initialized
DEBUG - 2023-12-06 16:38:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:38:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:38:11 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:11 --> Total execution time: 0.0889
INFO - 2023-12-06 16:38:11 --> Config Class Initialized
INFO - 2023-12-06 16:38:11 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:11 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:11 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:11 --> URI Class Initialized
INFO - 2023-12-06 16:38:11 --> Router Class Initialized
INFO - 2023-12-06 16:38:11 --> Output Class Initialized
INFO - 2023-12-06 16:38:11 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:11 --> Input Class Initialized
INFO - 2023-12-06 16:38:11 --> Language Class Initialized
INFO - 2023-12-06 16:38:11 --> Language Class Initialized
INFO - 2023-12-06 16:38:11 --> Config Class Initialized
INFO - 2023-12-06 16:38:11 --> Loader Class Initialized
INFO - 2023-12-06 16:38:11 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:11 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:11 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:11 --> Controller Class Initialized
INFO - 2023-12-06 16:38:22 --> Config Class Initialized
INFO - 2023-12-06 16:38:22 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:22 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:22 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:22 --> URI Class Initialized
INFO - 2023-12-06 16:38:22 --> Router Class Initialized
INFO - 2023-12-06 16:38:22 --> Output Class Initialized
INFO - 2023-12-06 16:38:22 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:22 --> Input Class Initialized
INFO - 2023-12-06 16:38:22 --> Language Class Initialized
INFO - 2023-12-06 16:38:22 --> Language Class Initialized
INFO - 2023-12-06 16:38:22 --> Config Class Initialized
INFO - 2023-12-06 16:38:22 --> Loader Class Initialized
INFO - 2023-12-06 16:38:22 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:22 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:22 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:22 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:22 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:22 --> Controller Class Initialized
INFO - 2023-12-06 16:38:22 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:22 --> Total execution time: 0.0390
INFO - 2023-12-06 16:38:32 --> Config Class Initialized
INFO - 2023-12-06 16:38:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:32 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:32 --> URI Class Initialized
INFO - 2023-12-06 16:38:32 --> Router Class Initialized
INFO - 2023-12-06 16:38:32 --> Output Class Initialized
INFO - 2023-12-06 16:38:32 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:32 --> Input Class Initialized
INFO - 2023-12-06 16:38:32 --> Language Class Initialized
INFO - 2023-12-06 16:38:32 --> Language Class Initialized
INFO - 2023-12-06 16:38:32 --> Config Class Initialized
INFO - 2023-12-06 16:38:32 --> Loader Class Initialized
INFO - 2023-12-06 16:38:32 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:32 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:32 --> Controller Class Initialized
INFO - 2023-12-06 16:38:32 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:32 --> Total execution time: 0.0818
INFO - 2023-12-06 16:38:32 --> Config Class Initialized
INFO - 2023-12-06 16:38:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:32 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:32 --> URI Class Initialized
INFO - 2023-12-06 16:38:32 --> Router Class Initialized
INFO - 2023-12-06 16:38:32 --> Output Class Initialized
INFO - 2023-12-06 16:38:32 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:32 --> Input Class Initialized
INFO - 2023-12-06 16:38:32 --> Language Class Initialized
INFO - 2023-12-06 16:38:32 --> Language Class Initialized
INFO - 2023-12-06 16:38:32 --> Config Class Initialized
INFO - 2023-12-06 16:38:32 --> Loader Class Initialized
INFO - 2023-12-06 16:38:32 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:32 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:32 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:32 --> Controller Class Initialized
INFO - 2023-12-06 16:38:37 --> Config Class Initialized
INFO - 2023-12-06 16:38:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:37 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:37 --> URI Class Initialized
INFO - 2023-12-06 16:38:37 --> Router Class Initialized
INFO - 2023-12-06 16:38:37 --> Output Class Initialized
INFO - 2023-12-06 16:38:37 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:37 --> Input Class Initialized
INFO - 2023-12-06 16:38:37 --> Language Class Initialized
INFO - 2023-12-06 16:38:37 --> Language Class Initialized
INFO - 2023-12-06 16:38:37 --> Config Class Initialized
INFO - 2023-12-06 16:38:37 --> Loader Class Initialized
INFO - 2023-12-06 16:38:37 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:37 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:37 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:37 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:37 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:37 --> Controller Class Initialized
INFO - 2023-12-06 16:38:37 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:37 --> Total execution time: 0.0390
INFO - 2023-12-06 16:38:53 --> Config Class Initialized
INFO - 2023-12-06 16:38:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:53 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:53 --> URI Class Initialized
INFO - 2023-12-06 16:38:53 --> Router Class Initialized
INFO - 2023-12-06 16:38:53 --> Output Class Initialized
INFO - 2023-12-06 16:38:53 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:53 --> Input Class Initialized
INFO - 2023-12-06 16:38:53 --> Language Class Initialized
INFO - 2023-12-06 16:38:53 --> Language Class Initialized
INFO - 2023-12-06 16:38:53 --> Config Class Initialized
INFO - 2023-12-06 16:38:53 --> Loader Class Initialized
INFO - 2023-12-06 16:38:53 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:53 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:53 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:53 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:53 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:53 --> Controller Class Initialized
INFO - 2023-12-06 16:38:53 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:53 --> Total execution time: 0.1339
INFO - 2023-12-06 16:38:53 --> Config Class Initialized
INFO - 2023-12-06 16:38:53 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:53 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:53 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:53 --> URI Class Initialized
INFO - 2023-12-06 16:38:53 --> Router Class Initialized
INFO - 2023-12-06 16:38:54 --> Output Class Initialized
INFO - 2023-12-06 16:38:54 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:54 --> Input Class Initialized
INFO - 2023-12-06 16:38:54 --> Language Class Initialized
INFO - 2023-12-06 16:38:54 --> Language Class Initialized
INFO - 2023-12-06 16:38:54 --> Config Class Initialized
INFO - 2023-12-06 16:38:54 --> Loader Class Initialized
INFO - 2023-12-06 16:38:54 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:54 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:54 --> Controller Class Initialized
INFO - 2023-12-06 16:38:54 --> Config Class Initialized
INFO - 2023-12-06 16:38:54 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:38:54 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:38:54 --> Utf8 Class Initialized
INFO - 2023-12-06 16:38:54 --> URI Class Initialized
INFO - 2023-12-06 16:38:54 --> Router Class Initialized
INFO - 2023-12-06 16:38:54 --> Output Class Initialized
INFO - 2023-12-06 16:38:54 --> Security Class Initialized
DEBUG - 2023-12-06 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:38:54 --> Input Class Initialized
INFO - 2023-12-06 16:38:54 --> Language Class Initialized
INFO - 2023-12-06 16:38:54 --> Language Class Initialized
INFO - 2023-12-06 16:38:54 --> Config Class Initialized
INFO - 2023-12-06 16:38:54 --> Loader Class Initialized
INFO - 2023-12-06 16:38:54 --> Helper loaded: url_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: file_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: form_helper
INFO - 2023-12-06 16:38:54 --> Helper loaded: my_helper
INFO - 2023-12-06 16:38:54 --> Database Driver Class Initialized
INFO - 2023-12-06 16:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:38:54 --> Controller Class Initialized
INFO - 2023-12-06 16:38:54 --> Final output sent to browser
DEBUG - 2023-12-06 16:38:54 --> Total execution time: 0.0984
INFO - 2023-12-06 16:39:10 --> Config Class Initialized
INFO - 2023-12-06 16:39:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:39:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:39:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:39:10 --> URI Class Initialized
INFO - 2023-12-06 16:39:10 --> Router Class Initialized
INFO - 2023-12-06 16:39:10 --> Output Class Initialized
INFO - 2023-12-06 16:39:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:39:10 --> Input Class Initialized
INFO - 2023-12-06 16:39:10 --> Language Class Initialized
INFO - 2023-12-06 16:39:10 --> Language Class Initialized
INFO - 2023-12-06 16:39:10 --> Config Class Initialized
INFO - 2023-12-06 16:39:10 --> Loader Class Initialized
INFO - 2023-12-06 16:39:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:39:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:39:10 --> Controller Class Initialized
INFO - 2023-12-06 16:39:10 --> Final output sent to browser
DEBUG - 2023-12-06 16:39:10 --> Total execution time: 0.0490
INFO - 2023-12-06 16:39:10 --> Config Class Initialized
INFO - 2023-12-06 16:39:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:39:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:39:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:39:10 --> URI Class Initialized
INFO - 2023-12-06 16:39:10 --> Router Class Initialized
INFO - 2023-12-06 16:39:10 --> Output Class Initialized
INFO - 2023-12-06 16:39:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:39:10 --> Input Class Initialized
INFO - 2023-12-06 16:39:10 --> Language Class Initialized
INFO - 2023-12-06 16:39:10 --> Language Class Initialized
INFO - 2023-12-06 16:39:10 --> Config Class Initialized
INFO - 2023-12-06 16:39:10 --> Loader Class Initialized
INFO - 2023-12-06 16:39:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:39:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:39:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:39:10 --> Controller Class Initialized
INFO - 2023-12-06 16:39:32 --> Config Class Initialized
INFO - 2023-12-06 16:39:32 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:39:32 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:39:32 --> Utf8 Class Initialized
INFO - 2023-12-06 16:39:32 --> URI Class Initialized
INFO - 2023-12-06 16:39:32 --> Router Class Initialized
INFO - 2023-12-06 16:39:32 --> Output Class Initialized
INFO - 2023-12-06 16:39:32 --> Security Class Initialized
DEBUG - 2023-12-06 16:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:39:32 --> Input Class Initialized
INFO - 2023-12-06 16:39:32 --> Language Class Initialized
INFO - 2023-12-06 16:39:32 --> Language Class Initialized
INFO - 2023-12-06 16:39:32 --> Config Class Initialized
INFO - 2023-12-06 16:39:32 --> Loader Class Initialized
INFO - 2023-12-06 16:39:32 --> Helper loaded: url_helper
INFO - 2023-12-06 16:39:32 --> Helper loaded: file_helper
INFO - 2023-12-06 16:39:32 --> Helper loaded: form_helper
INFO - 2023-12-06 16:39:32 --> Helper loaded: my_helper
INFO - 2023-12-06 16:39:32 --> Database Driver Class Initialized
INFO - 2023-12-06 16:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:39:32 --> Controller Class Initialized
DEBUG - 2023-12-06 16:39:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-06 16:39:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:39:32 --> Final output sent to browser
DEBUG - 2023-12-06 16:39:32 --> Total execution time: 0.0434
INFO - 2023-12-06 16:39:34 --> Config Class Initialized
INFO - 2023-12-06 16:39:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:39:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:39:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:39:34 --> URI Class Initialized
INFO - 2023-12-06 16:39:34 --> Router Class Initialized
INFO - 2023-12-06 16:39:34 --> Output Class Initialized
INFO - 2023-12-06 16:39:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:39:34 --> Input Class Initialized
INFO - 2023-12-06 16:39:34 --> Language Class Initialized
INFO - 2023-12-06 16:39:34 --> Language Class Initialized
INFO - 2023-12-06 16:39:34 --> Config Class Initialized
INFO - 2023-12-06 16:39:34 --> Loader Class Initialized
INFO - 2023-12-06 16:39:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:39:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:39:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:39:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:39:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:39:34 --> Controller Class Initialized
INFO - 2023-12-06 16:39:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:39:34 --> Total execution time: 0.1132
INFO - 2023-12-06 16:39:42 --> Config Class Initialized
INFO - 2023-12-06 16:39:42 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:39:42 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:39:42 --> Utf8 Class Initialized
INFO - 2023-12-06 16:39:42 --> URI Class Initialized
INFO - 2023-12-06 16:39:42 --> Router Class Initialized
INFO - 2023-12-06 16:39:42 --> Output Class Initialized
INFO - 2023-12-06 16:39:42 --> Security Class Initialized
DEBUG - 2023-12-06 16:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:39:42 --> Input Class Initialized
INFO - 2023-12-06 16:39:42 --> Language Class Initialized
INFO - 2023-12-06 16:39:42 --> Language Class Initialized
INFO - 2023-12-06 16:39:42 --> Config Class Initialized
INFO - 2023-12-06 16:39:42 --> Loader Class Initialized
INFO - 2023-12-06 16:39:42 --> Helper loaded: url_helper
INFO - 2023-12-06 16:39:42 --> Helper loaded: file_helper
INFO - 2023-12-06 16:39:42 --> Helper loaded: form_helper
INFO - 2023-12-06 16:39:42 --> Helper loaded: my_helper
INFO - 2023-12-06 16:39:42 --> Database Driver Class Initialized
INFO - 2023-12-06 16:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:39:42 --> Controller Class Initialized
DEBUG - 2023-12-06 16:39:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-06 16:39:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:39:42 --> Final output sent to browser
DEBUG - 2023-12-06 16:39:42 --> Total execution time: 0.0397
INFO - 2023-12-06 16:40:15 --> Config Class Initialized
INFO - 2023-12-06 16:40:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:15 --> URI Class Initialized
INFO - 2023-12-06 16:40:15 --> Router Class Initialized
INFO - 2023-12-06 16:40:15 --> Output Class Initialized
INFO - 2023-12-06 16:40:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:15 --> Input Class Initialized
INFO - 2023-12-06 16:40:15 --> Language Class Initialized
INFO - 2023-12-06 16:40:15 --> Language Class Initialized
INFO - 2023-12-06 16:40:15 --> Config Class Initialized
INFO - 2023-12-06 16:40:15 --> Loader Class Initialized
INFO - 2023-12-06 16:40:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:15 --> Controller Class Initialized
INFO - 2023-12-06 16:40:15 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:15 --> Total execution time: 0.1462
INFO - 2023-12-06 16:40:17 --> Config Class Initialized
INFO - 2023-12-06 16:40:17 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:17 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:17 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:17 --> URI Class Initialized
INFO - 2023-12-06 16:40:17 --> Router Class Initialized
INFO - 2023-12-06 16:40:17 --> Output Class Initialized
INFO - 2023-12-06 16:40:17 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:17 --> Input Class Initialized
INFO - 2023-12-06 16:40:17 --> Language Class Initialized
INFO - 2023-12-06 16:40:17 --> Language Class Initialized
INFO - 2023-12-06 16:40:17 --> Config Class Initialized
INFO - 2023-12-06 16:40:17 --> Loader Class Initialized
INFO - 2023-12-06 16:40:17 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:17 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:17 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:17 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:17 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:17 --> Controller Class Initialized
INFO - 2023-12-06 16:40:17 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:17 --> Total execution time: 0.0342
INFO - 2023-12-06 16:40:18 --> Config Class Initialized
INFO - 2023-12-06 16:40:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:18 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:18 --> URI Class Initialized
INFO - 2023-12-06 16:40:18 --> Router Class Initialized
INFO - 2023-12-06 16:40:18 --> Output Class Initialized
INFO - 2023-12-06 16:40:18 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:18 --> Input Class Initialized
INFO - 2023-12-06 16:40:18 --> Language Class Initialized
INFO - 2023-12-06 16:40:18 --> Language Class Initialized
INFO - 2023-12-06 16:40:18 --> Config Class Initialized
INFO - 2023-12-06 16:40:18 --> Loader Class Initialized
INFO - 2023-12-06 16:40:18 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:18 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:18 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:18 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:18 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:18 --> Controller Class Initialized
INFO - 2023-12-06 16:40:18 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:18 --> Total execution time: 0.0350
INFO - 2023-12-06 16:40:19 --> Config Class Initialized
INFO - 2023-12-06 16:40:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:19 --> URI Class Initialized
INFO - 2023-12-06 16:40:19 --> Router Class Initialized
INFO - 2023-12-06 16:40:19 --> Output Class Initialized
INFO - 2023-12-06 16:40:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:19 --> Input Class Initialized
INFO - 2023-12-06 16:40:19 --> Language Class Initialized
INFO - 2023-12-06 16:40:19 --> Language Class Initialized
INFO - 2023-12-06 16:40:19 --> Config Class Initialized
INFO - 2023-12-06 16:40:19 --> Loader Class Initialized
INFO - 2023-12-06 16:40:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:19 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:19 --> Controller Class Initialized
INFO - 2023-12-06 16:40:19 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:19 --> Total execution time: 0.0408
INFO - 2023-12-06 16:40:19 --> Config Class Initialized
INFO - 2023-12-06 16:40:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:19 --> URI Class Initialized
INFO - 2023-12-06 16:40:19 --> Router Class Initialized
INFO - 2023-12-06 16:40:19 --> Output Class Initialized
INFO - 2023-12-06 16:40:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:19 --> Input Class Initialized
INFO - 2023-12-06 16:40:19 --> Language Class Initialized
INFO - 2023-12-06 16:40:19 --> Language Class Initialized
INFO - 2023-12-06 16:40:19 --> Config Class Initialized
INFO - 2023-12-06 16:40:19 --> Loader Class Initialized
INFO - 2023-12-06 16:40:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:19 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:19 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:19 --> Controller Class Initialized
INFO - 2023-12-06 16:40:19 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:19 --> Total execution time: 0.0462
INFO - 2023-12-06 16:40:23 --> Config Class Initialized
INFO - 2023-12-06 16:40:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:23 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:23 --> URI Class Initialized
INFO - 2023-12-06 16:40:23 --> Router Class Initialized
INFO - 2023-12-06 16:40:23 --> Output Class Initialized
INFO - 2023-12-06 16:40:23 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:23 --> Input Class Initialized
INFO - 2023-12-06 16:40:23 --> Language Class Initialized
INFO - 2023-12-06 16:40:23 --> Language Class Initialized
INFO - 2023-12-06 16:40:23 --> Config Class Initialized
INFO - 2023-12-06 16:40:23 --> Loader Class Initialized
INFO - 2023-12-06 16:40:23 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:23 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:23 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:23 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:23 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:23 --> Controller Class Initialized
INFO - 2023-12-06 16:40:23 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:23 --> Total execution time: 0.1101
INFO - 2023-12-06 16:40:31 --> Config Class Initialized
INFO - 2023-12-06 16:40:31 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:31 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:31 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:31 --> URI Class Initialized
INFO - 2023-12-06 16:40:31 --> Router Class Initialized
INFO - 2023-12-06 16:40:31 --> Output Class Initialized
INFO - 2023-12-06 16:40:31 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:31 --> Input Class Initialized
INFO - 2023-12-06 16:40:31 --> Language Class Initialized
INFO - 2023-12-06 16:40:31 --> Language Class Initialized
INFO - 2023-12-06 16:40:31 --> Config Class Initialized
INFO - 2023-12-06 16:40:31 --> Loader Class Initialized
INFO - 2023-12-06 16:40:31 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:31 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:31 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:31 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:31 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:31 --> Controller Class Initialized
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:40:31 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:40:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:40:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:40:31 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:31 --> Total execution time: 0.0769
INFO - 2023-12-06 16:40:34 --> Config Class Initialized
INFO - 2023-12-06 16:40:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:34 --> URI Class Initialized
INFO - 2023-12-06 16:40:34 --> Router Class Initialized
INFO - 2023-12-06 16:40:34 --> Output Class Initialized
INFO - 2023-12-06 16:40:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:34 --> Input Class Initialized
INFO - 2023-12-06 16:40:34 --> Language Class Initialized
INFO - 2023-12-06 16:40:34 --> Language Class Initialized
INFO - 2023-12-06 16:40:34 --> Config Class Initialized
INFO - 2023-12-06 16:40:34 --> Loader Class Initialized
INFO - 2023-12-06 16:40:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:34 --> Controller Class Initialized
DEBUG - 2023-12-06 16:40:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:40:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:40:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:34 --> Total execution time: 0.0711
INFO - 2023-12-06 16:40:34 --> Config Class Initialized
INFO - 2023-12-06 16:40:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:34 --> URI Class Initialized
INFO - 2023-12-06 16:40:34 --> Router Class Initialized
INFO - 2023-12-06 16:40:34 --> Output Class Initialized
INFO - 2023-12-06 16:40:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:34 --> Input Class Initialized
INFO - 2023-12-06 16:40:34 --> Language Class Initialized
INFO - 2023-12-06 16:40:34 --> Language Class Initialized
INFO - 2023-12-06 16:40:34 --> Config Class Initialized
INFO - 2023-12-06 16:40:34 --> Loader Class Initialized
INFO - 2023-12-06 16:40:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:34 --> Controller Class Initialized
INFO - 2023-12-06 16:40:46 --> Config Class Initialized
INFO - 2023-12-06 16:40:46 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:46 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:46 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:46 --> URI Class Initialized
INFO - 2023-12-06 16:40:46 --> Router Class Initialized
INFO - 2023-12-06 16:40:46 --> Output Class Initialized
INFO - 2023-12-06 16:40:46 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:46 --> Input Class Initialized
INFO - 2023-12-06 16:40:46 --> Language Class Initialized
INFO - 2023-12-06 16:40:46 --> Language Class Initialized
INFO - 2023-12-06 16:40:46 --> Config Class Initialized
INFO - 2023-12-06 16:40:46 --> Loader Class Initialized
INFO - 2023-12-06 16:40:46 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:46 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:46 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:46 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:46 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:46 --> Controller Class Initialized
INFO - 2023-12-06 16:40:46 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:46 --> Total execution time: 0.0505
INFO - 2023-12-06 16:40:58 --> Config Class Initialized
INFO - 2023-12-06 16:40:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:58 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:58 --> URI Class Initialized
INFO - 2023-12-06 16:40:58 --> Router Class Initialized
INFO - 2023-12-06 16:40:58 --> Output Class Initialized
INFO - 2023-12-06 16:40:58 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:58 --> Input Class Initialized
INFO - 2023-12-06 16:40:58 --> Language Class Initialized
INFO - 2023-12-06 16:40:58 --> Language Class Initialized
INFO - 2023-12-06 16:40:58 --> Config Class Initialized
INFO - 2023-12-06 16:40:58 --> Loader Class Initialized
INFO - 2023-12-06 16:40:58 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:58 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:58 --> Controller Class Initialized
INFO - 2023-12-06 16:40:58 --> Final output sent to browser
DEBUG - 2023-12-06 16:40:58 --> Total execution time: 0.0341
INFO - 2023-12-06 16:40:58 --> Config Class Initialized
INFO - 2023-12-06 16:40:58 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:40:58 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:40:58 --> Utf8 Class Initialized
INFO - 2023-12-06 16:40:58 --> URI Class Initialized
INFO - 2023-12-06 16:40:58 --> Router Class Initialized
INFO - 2023-12-06 16:40:58 --> Output Class Initialized
INFO - 2023-12-06 16:40:58 --> Security Class Initialized
DEBUG - 2023-12-06 16:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:40:58 --> Input Class Initialized
INFO - 2023-12-06 16:40:58 --> Language Class Initialized
INFO - 2023-12-06 16:40:58 --> Language Class Initialized
INFO - 2023-12-06 16:40:58 --> Config Class Initialized
INFO - 2023-12-06 16:40:58 --> Loader Class Initialized
INFO - 2023-12-06 16:40:58 --> Helper loaded: url_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: file_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: form_helper
INFO - 2023-12-06 16:40:58 --> Helper loaded: my_helper
INFO - 2023-12-06 16:40:58 --> Database Driver Class Initialized
INFO - 2023-12-06 16:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:40:58 --> Controller Class Initialized
INFO - 2023-12-06 16:41:00 --> Config Class Initialized
INFO - 2023-12-06 16:41:00 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:00 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:00 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:00 --> URI Class Initialized
INFO - 2023-12-06 16:41:00 --> Router Class Initialized
INFO - 2023-12-06 16:41:00 --> Output Class Initialized
INFO - 2023-12-06 16:41:00 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:00 --> Input Class Initialized
INFO - 2023-12-06 16:41:00 --> Language Class Initialized
INFO - 2023-12-06 16:41:00 --> Language Class Initialized
INFO - 2023-12-06 16:41:00 --> Config Class Initialized
INFO - 2023-12-06 16:41:00 --> Loader Class Initialized
INFO - 2023-12-06 16:41:00 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:00 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:00 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:00 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:00 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:00 --> Controller Class Initialized
INFO - 2023-12-06 16:41:00 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:00 --> Total execution time: 0.0678
INFO - 2023-12-06 16:41:08 --> Config Class Initialized
INFO - 2023-12-06 16:41:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:08 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:08 --> URI Class Initialized
INFO - 2023-12-06 16:41:08 --> Router Class Initialized
INFO - 2023-12-06 16:41:08 --> Output Class Initialized
INFO - 2023-12-06 16:41:08 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:08 --> Input Class Initialized
INFO - 2023-12-06 16:41:08 --> Language Class Initialized
INFO - 2023-12-06 16:41:08 --> Language Class Initialized
INFO - 2023-12-06 16:41:08 --> Config Class Initialized
INFO - 2023-12-06 16:41:08 --> Loader Class Initialized
INFO - 2023-12-06 16:41:08 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:08 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:08 --> Controller Class Initialized
INFO - 2023-12-06 16:41:08 --> Helper loaded: cookie_helper
INFO - 2023-12-06 16:41:08 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:08 --> Total execution time: 0.0484
INFO - 2023-12-06 16:41:08 --> Config Class Initialized
INFO - 2023-12-06 16:41:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:08 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:08 --> URI Class Initialized
INFO - 2023-12-06 16:41:08 --> Router Class Initialized
INFO - 2023-12-06 16:41:08 --> Output Class Initialized
INFO - 2023-12-06 16:41:08 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:08 --> Input Class Initialized
INFO - 2023-12-06 16:41:08 --> Language Class Initialized
INFO - 2023-12-06 16:41:08 --> Language Class Initialized
INFO - 2023-12-06 16:41:08 --> Config Class Initialized
INFO - 2023-12-06 16:41:08 --> Loader Class Initialized
INFO - 2023-12-06 16:41:08 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:08 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:08 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:08 --> Controller Class Initialized
DEBUG - 2023-12-06 16:41:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-06 16:41:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:41:08 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:08 --> Total execution time: 0.0626
INFO - 2023-12-06 16:41:15 --> Config Class Initialized
INFO - 2023-12-06 16:41:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:15 --> URI Class Initialized
INFO - 2023-12-06 16:41:15 --> Router Class Initialized
INFO - 2023-12-06 16:41:15 --> Output Class Initialized
INFO - 2023-12-06 16:41:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:15 --> Input Class Initialized
INFO - 2023-12-06 16:41:15 --> Language Class Initialized
INFO - 2023-12-06 16:41:15 --> Language Class Initialized
INFO - 2023-12-06 16:41:15 --> Config Class Initialized
INFO - 2023-12-06 16:41:15 --> Loader Class Initialized
INFO - 2023-12-06 16:41:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:15 --> Controller Class Initialized
INFO - 2023-12-06 16:41:15 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:15 --> Total execution time: 0.0797
INFO - 2023-12-06 16:41:15 --> Config Class Initialized
INFO - 2023-12-06 16:41:15 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:15 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:15 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:15 --> URI Class Initialized
INFO - 2023-12-06 16:41:15 --> Router Class Initialized
INFO - 2023-12-06 16:41:15 --> Output Class Initialized
INFO - 2023-12-06 16:41:15 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:15 --> Input Class Initialized
INFO - 2023-12-06 16:41:15 --> Language Class Initialized
INFO - 2023-12-06 16:41:15 --> Language Class Initialized
INFO - 2023-12-06 16:41:15 --> Config Class Initialized
INFO - 2023-12-06 16:41:15 --> Loader Class Initialized
INFO - 2023-12-06 16:41:15 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:15 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:15 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:15 --> Controller Class Initialized
INFO - 2023-12-06 16:41:27 --> Config Class Initialized
INFO - 2023-12-06 16:41:27 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:27 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:27 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:27 --> URI Class Initialized
INFO - 2023-12-06 16:41:27 --> Router Class Initialized
INFO - 2023-12-06 16:41:27 --> Output Class Initialized
INFO - 2023-12-06 16:41:27 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:27 --> Input Class Initialized
INFO - 2023-12-06 16:41:27 --> Language Class Initialized
INFO - 2023-12-06 16:41:27 --> Language Class Initialized
INFO - 2023-12-06 16:41:27 --> Config Class Initialized
INFO - 2023-12-06 16:41:27 --> Loader Class Initialized
INFO - 2023-12-06 16:41:27 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:27 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:27 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:27 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:27 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:27 --> Controller Class Initialized
INFO - 2023-12-06 16:41:27 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:27 --> Total execution time: 0.0703
INFO - 2023-12-06 16:41:33 --> Config Class Initialized
INFO - 2023-12-06 16:41:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:33 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:33 --> URI Class Initialized
INFO - 2023-12-06 16:41:33 --> Router Class Initialized
INFO - 2023-12-06 16:41:33 --> Output Class Initialized
INFO - 2023-12-06 16:41:33 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:33 --> Input Class Initialized
INFO - 2023-12-06 16:41:33 --> Language Class Initialized
INFO - 2023-12-06 16:41:33 --> Language Class Initialized
INFO - 2023-12-06 16:41:33 --> Config Class Initialized
INFO - 2023-12-06 16:41:33 --> Loader Class Initialized
INFO - 2023-12-06 16:41:33 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:33 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:33 --> Controller Class Initialized
INFO - 2023-12-06 16:41:33 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:33 --> Total execution time: 0.0363
INFO - 2023-12-06 16:41:33 --> Config Class Initialized
INFO - 2023-12-06 16:41:33 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:33 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:33 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:33 --> URI Class Initialized
INFO - 2023-12-06 16:41:33 --> Router Class Initialized
INFO - 2023-12-06 16:41:33 --> Output Class Initialized
INFO - 2023-12-06 16:41:33 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:33 --> Input Class Initialized
INFO - 2023-12-06 16:41:33 --> Language Class Initialized
INFO - 2023-12-06 16:41:33 --> Language Class Initialized
INFO - 2023-12-06 16:41:33 --> Config Class Initialized
INFO - 2023-12-06 16:41:33 --> Loader Class Initialized
INFO - 2023-12-06 16:41:33 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:33 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:33 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:33 --> Controller Class Initialized
INFO - 2023-12-06 16:41:49 --> Config Class Initialized
INFO - 2023-12-06 16:41:49 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:49 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:49 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:49 --> URI Class Initialized
INFO - 2023-12-06 16:41:49 --> Router Class Initialized
INFO - 2023-12-06 16:41:49 --> Output Class Initialized
INFO - 2023-12-06 16:41:49 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:49 --> Input Class Initialized
INFO - 2023-12-06 16:41:49 --> Language Class Initialized
INFO - 2023-12-06 16:41:49 --> Language Class Initialized
INFO - 2023-12-06 16:41:49 --> Config Class Initialized
INFO - 2023-12-06 16:41:49 --> Loader Class Initialized
INFO - 2023-12-06 16:41:49 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:49 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:49 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:49 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:49 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:49 --> Controller Class Initialized
INFO - 2023-12-06 16:41:49 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:49 --> Total execution time: 0.0464
INFO - 2023-12-06 16:41:56 --> Config Class Initialized
INFO - 2023-12-06 16:41:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:56 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:56 --> URI Class Initialized
INFO - 2023-12-06 16:41:56 --> Router Class Initialized
INFO - 2023-12-06 16:41:56 --> Output Class Initialized
INFO - 2023-12-06 16:41:56 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:56 --> Input Class Initialized
INFO - 2023-12-06 16:41:56 --> Language Class Initialized
INFO - 2023-12-06 16:41:56 --> Language Class Initialized
INFO - 2023-12-06 16:41:56 --> Config Class Initialized
INFO - 2023-12-06 16:41:56 --> Loader Class Initialized
INFO - 2023-12-06 16:41:56 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:56 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:56 --> Controller Class Initialized
INFO - 2023-12-06 16:41:56 --> Final output sent to browser
DEBUG - 2023-12-06 16:41:56 --> Total execution time: 0.1351
INFO - 2023-12-06 16:41:56 --> Config Class Initialized
INFO - 2023-12-06 16:41:56 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:41:56 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:41:56 --> Utf8 Class Initialized
INFO - 2023-12-06 16:41:56 --> URI Class Initialized
INFO - 2023-12-06 16:41:56 --> Router Class Initialized
INFO - 2023-12-06 16:41:56 --> Output Class Initialized
INFO - 2023-12-06 16:41:56 --> Security Class Initialized
DEBUG - 2023-12-06 16:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:41:56 --> Input Class Initialized
INFO - 2023-12-06 16:41:56 --> Language Class Initialized
INFO - 2023-12-06 16:41:56 --> Language Class Initialized
INFO - 2023-12-06 16:41:56 --> Config Class Initialized
INFO - 2023-12-06 16:41:56 --> Loader Class Initialized
INFO - 2023-12-06 16:41:56 --> Helper loaded: url_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: file_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: form_helper
INFO - 2023-12-06 16:41:56 --> Helper loaded: my_helper
INFO - 2023-12-06 16:41:56 --> Database Driver Class Initialized
INFO - 2023-12-06 16:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:41:56 --> Controller Class Initialized
INFO - 2023-12-06 16:42:06 --> Config Class Initialized
INFO - 2023-12-06 16:42:06 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:06 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:06 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:06 --> URI Class Initialized
INFO - 2023-12-06 16:42:06 --> Router Class Initialized
INFO - 2023-12-06 16:42:06 --> Output Class Initialized
INFO - 2023-12-06 16:42:06 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:06 --> Input Class Initialized
INFO - 2023-12-06 16:42:06 --> Language Class Initialized
INFO - 2023-12-06 16:42:06 --> Language Class Initialized
INFO - 2023-12-06 16:42:06 --> Config Class Initialized
INFO - 2023-12-06 16:42:06 --> Loader Class Initialized
INFO - 2023-12-06 16:42:06 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:06 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:06 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:06 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:06 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:06 --> Controller Class Initialized
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:06 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:42:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:42:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:06 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:06 --> Total execution time: 0.0692
INFO - 2023-12-06 16:42:10 --> Config Class Initialized
INFO - 2023-12-06 16:42:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:10 --> URI Class Initialized
INFO - 2023-12-06 16:42:10 --> Router Class Initialized
INFO - 2023-12-06 16:42:10 --> Output Class Initialized
INFO - 2023-12-06 16:42:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:10 --> Input Class Initialized
INFO - 2023-12-06 16:42:10 --> Language Class Initialized
INFO - 2023-12-06 16:42:10 --> Language Class Initialized
INFO - 2023-12-06 16:42:10 --> Config Class Initialized
INFO - 2023-12-06 16:42:10 --> Loader Class Initialized
INFO - 2023-12-06 16:42:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:10 --> Controller Class Initialized
DEBUG - 2023-12-06 16:42:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:42:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:10 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:10 --> Total execution time: 0.0456
INFO - 2023-12-06 16:42:10 --> Config Class Initialized
INFO - 2023-12-06 16:42:10 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:10 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:10 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:10 --> URI Class Initialized
INFO - 2023-12-06 16:42:10 --> Router Class Initialized
INFO - 2023-12-06 16:42:10 --> Output Class Initialized
INFO - 2023-12-06 16:42:10 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:10 --> Input Class Initialized
INFO - 2023-12-06 16:42:10 --> Language Class Initialized
INFO - 2023-12-06 16:42:10 --> Language Class Initialized
INFO - 2023-12-06 16:42:10 --> Config Class Initialized
INFO - 2023-12-06 16:42:10 --> Loader Class Initialized
INFO - 2023-12-06 16:42:10 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:10 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:10 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:10 --> Controller Class Initialized
INFO - 2023-12-06 16:42:18 --> Config Class Initialized
INFO - 2023-12-06 16:42:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:18 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:18 --> URI Class Initialized
INFO - 2023-12-06 16:42:18 --> Router Class Initialized
INFO - 2023-12-06 16:42:18 --> Output Class Initialized
INFO - 2023-12-06 16:42:18 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:18 --> Input Class Initialized
INFO - 2023-12-06 16:42:18 --> Language Class Initialized
INFO - 2023-12-06 16:42:18 --> Language Class Initialized
INFO - 2023-12-06 16:42:18 --> Config Class Initialized
INFO - 2023-12-06 16:42:18 --> Loader Class Initialized
INFO - 2023-12-06 16:42:18 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:18 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:18 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:18 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:18 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:18 --> Controller Class Initialized
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:42:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:42:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:18 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:18 --> Total execution time: 0.0477
INFO - 2023-12-06 16:42:19 --> Config Class Initialized
INFO - 2023-12-06 16:42:19 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:19 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:19 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:19 --> URI Class Initialized
INFO - 2023-12-06 16:42:19 --> Router Class Initialized
INFO - 2023-12-06 16:42:19 --> Output Class Initialized
INFO - 2023-12-06 16:42:19 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:19 --> Input Class Initialized
INFO - 2023-12-06 16:42:19 --> Language Class Initialized
INFO - 2023-12-06 16:42:19 --> Language Class Initialized
INFO - 2023-12-06 16:42:19 --> Config Class Initialized
INFO - 2023-12-06 16:42:19 --> Loader Class Initialized
INFO - 2023-12-06 16:42:19 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:19 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:19 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:19 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:19 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:19 --> Controller Class Initialized
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:19 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:19 --> Total execution time: 0.0619
INFO - 2023-12-06 16:42:23 --> Config Class Initialized
INFO - 2023-12-06 16:42:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:23 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:23 --> URI Class Initialized
INFO - 2023-12-06 16:42:23 --> Router Class Initialized
INFO - 2023-12-06 16:42:23 --> Output Class Initialized
INFO - 2023-12-06 16:42:23 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:23 --> Input Class Initialized
INFO - 2023-12-06 16:42:23 --> Language Class Initialized
INFO - 2023-12-06 16:42:23 --> Language Class Initialized
INFO - 2023-12-06 16:42:23 --> Config Class Initialized
INFO - 2023-12-06 16:42:23 --> Loader Class Initialized
INFO - 2023-12-06 16:42:23 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:23 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:23 --> Controller Class Initialized
DEBUG - 2023-12-06 16:42:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:42:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:23 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:23 --> Total execution time: 0.0747
INFO - 2023-12-06 16:42:23 --> Config Class Initialized
INFO - 2023-12-06 16:42:23 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:23 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:23 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:23 --> URI Class Initialized
INFO - 2023-12-06 16:42:23 --> Router Class Initialized
INFO - 2023-12-06 16:42:23 --> Output Class Initialized
INFO - 2023-12-06 16:42:23 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:23 --> Input Class Initialized
INFO - 2023-12-06 16:42:23 --> Language Class Initialized
INFO - 2023-12-06 16:42:23 --> Language Class Initialized
INFO - 2023-12-06 16:42:23 --> Config Class Initialized
INFO - 2023-12-06 16:42:23 --> Loader Class Initialized
INFO - 2023-12-06 16:42:23 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:23 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:23 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:23 --> Controller Class Initialized
INFO - 2023-12-06 16:42:30 --> Config Class Initialized
INFO - 2023-12-06 16:42:30 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:30 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:30 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:30 --> URI Class Initialized
INFO - 2023-12-06 16:42:30 --> Router Class Initialized
INFO - 2023-12-06 16:42:30 --> Output Class Initialized
INFO - 2023-12-06 16:42:30 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:30 --> Input Class Initialized
INFO - 2023-12-06 16:42:30 --> Language Class Initialized
INFO - 2023-12-06 16:42:30 --> Language Class Initialized
INFO - 2023-12-06 16:42:30 --> Config Class Initialized
INFO - 2023-12-06 16:42:30 --> Loader Class Initialized
INFO - 2023-12-06 16:42:30 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:30 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:30 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:30 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:30 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:30 --> Controller Class Initialized
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:30 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:30 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:30 --> Total execution time: 0.0397
INFO - 2023-12-06 16:42:34 --> Config Class Initialized
INFO - 2023-12-06 16:42:34 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:34 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:34 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:34 --> URI Class Initialized
INFO - 2023-12-06 16:42:34 --> Router Class Initialized
INFO - 2023-12-06 16:42:34 --> Output Class Initialized
INFO - 2023-12-06 16:42:34 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:34 --> Input Class Initialized
INFO - 2023-12-06 16:42:34 --> Language Class Initialized
INFO - 2023-12-06 16:42:34 --> Language Class Initialized
INFO - 2023-12-06 16:42:34 --> Config Class Initialized
INFO - 2023-12-06 16:42:34 --> Loader Class Initialized
INFO - 2023-12-06 16:42:34 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:34 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:34 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:34 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:34 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:34 --> Controller Class Initialized
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:42:34 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:42:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:42:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:34 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:34 --> Total execution time: 0.0393
INFO - 2023-12-06 16:42:37 --> Config Class Initialized
INFO - 2023-12-06 16:42:37 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:37 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:37 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:37 --> URI Class Initialized
INFO - 2023-12-06 16:42:37 --> Router Class Initialized
INFO - 2023-12-06 16:42:37 --> Output Class Initialized
INFO - 2023-12-06 16:42:37 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:37 --> Input Class Initialized
INFO - 2023-12-06 16:42:37 --> Language Class Initialized
INFO - 2023-12-06 16:42:37 --> Language Class Initialized
INFO - 2023-12-06 16:42:37 --> Config Class Initialized
INFO - 2023-12-06 16:42:37 --> Loader Class Initialized
INFO - 2023-12-06 16:42:37 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:37 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:37 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:37 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:37 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:37 --> Controller Class Initialized
DEBUG - 2023-12-06 16:42:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:42:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:42:37 --> Final output sent to browser
DEBUG - 2023-12-06 16:42:37 --> Total execution time: 0.0437
INFO - 2023-12-06 16:42:39 --> Config Class Initialized
INFO - 2023-12-06 16:42:39 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:42:39 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:42:39 --> Utf8 Class Initialized
INFO - 2023-12-06 16:42:39 --> URI Class Initialized
INFO - 2023-12-06 16:42:39 --> Router Class Initialized
INFO - 2023-12-06 16:42:39 --> Output Class Initialized
INFO - 2023-12-06 16:42:39 --> Security Class Initialized
DEBUG - 2023-12-06 16:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:42:39 --> Input Class Initialized
INFO - 2023-12-06 16:42:39 --> Language Class Initialized
INFO - 2023-12-06 16:42:39 --> Language Class Initialized
INFO - 2023-12-06 16:42:39 --> Config Class Initialized
INFO - 2023-12-06 16:42:39 --> Loader Class Initialized
INFO - 2023-12-06 16:42:39 --> Helper loaded: url_helper
INFO - 2023-12-06 16:42:39 --> Helper loaded: file_helper
INFO - 2023-12-06 16:42:39 --> Helper loaded: form_helper
INFO - 2023-12-06 16:42:39 --> Helper loaded: my_helper
INFO - 2023-12-06 16:42:39 --> Database Driver Class Initialized
INFO - 2023-12-06 16:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:42:39 --> Controller Class Initialized
INFO - 2023-12-06 16:43:04 --> Config Class Initialized
INFO - 2023-12-06 16:43:04 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:43:04 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:43:04 --> Utf8 Class Initialized
INFO - 2023-12-06 16:43:04 --> URI Class Initialized
INFO - 2023-12-06 16:43:04 --> Router Class Initialized
INFO - 2023-12-06 16:43:04 --> Output Class Initialized
INFO - 2023-12-06 16:43:04 --> Security Class Initialized
DEBUG - 2023-12-06 16:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:43:04 --> Input Class Initialized
INFO - 2023-12-06 16:43:04 --> Language Class Initialized
INFO - 2023-12-06 16:43:04 --> Language Class Initialized
INFO - 2023-12-06 16:43:04 --> Config Class Initialized
INFO - 2023-12-06 16:43:04 --> Loader Class Initialized
INFO - 2023-12-06 16:43:04 --> Helper loaded: url_helper
INFO - 2023-12-06 16:43:04 --> Helper loaded: file_helper
INFO - 2023-12-06 16:43:04 --> Helper loaded: form_helper
INFO - 2023-12-06 16:43:04 --> Helper loaded: my_helper
INFO - 2023-12-06 16:43:04 --> Database Driver Class Initialized
INFO - 2023-12-06 16:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:43:04 --> Controller Class Initialized
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:04 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:43:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:43:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:43:04 --> Final output sent to browser
DEBUG - 2023-12-06 16:43:04 --> Total execution time: 0.0546
INFO - 2023-12-06 16:43:08 --> Config Class Initialized
INFO - 2023-12-06 16:43:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:43:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:43:08 --> Utf8 Class Initialized
INFO - 2023-12-06 16:43:08 --> URI Class Initialized
INFO - 2023-12-06 16:43:08 --> Router Class Initialized
INFO - 2023-12-06 16:43:08 --> Output Class Initialized
INFO - 2023-12-06 16:43:08 --> Security Class Initialized
DEBUG - 2023-12-06 16:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:43:08 --> Input Class Initialized
INFO - 2023-12-06 16:43:08 --> Language Class Initialized
INFO - 2023-12-06 16:43:08 --> Language Class Initialized
INFO - 2023-12-06 16:43:08 --> Config Class Initialized
INFO - 2023-12-06 16:43:08 --> Loader Class Initialized
INFO - 2023-12-06 16:43:08 --> Helper loaded: url_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: file_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: form_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: my_helper
INFO - 2023-12-06 16:43:08 --> Database Driver Class Initialized
INFO - 2023-12-06 16:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:43:08 --> Controller Class Initialized
DEBUG - 2023-12-06 16:43:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-06 16:43:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:43:08 --> Final output sent to browser
DEBUG - 2023-12-06 16:43:08 --> Total execution time: 0.0559
INFO - 2023-12-06 16:43:08 --> Config Class Initialized
INFO - 2023-12-06 16:43:08 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:43:08 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:43:08 --> Utf8 Class Initialized
INFO - 2023-12-06 16:43:08 --> URI Class Initialized
INFO - 2023-12-06 16:43:08 --> Router Class Initialized
INFO - 2023-12-06 16:43:08 --> Output Class Initialized
INFO - 2023-12-06 16:43:08 --> Security Class Initialized
DEBUG - 2023-12-06 16:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:43:08 --> Input Class Initialized
INFO - 2023-12-06 16:43:08 --> Language Class Initialized
INFO - 2023-12-06 16:43:08 --> Language Class Initialized
INFO - 2023-12-06 16:43:08 --> Config Class Initialized
INFO - 2023-12-06 16:43:08 --> Loader Class Initialized
INFO - 2023-12-06 16:43:08 --> Helper loaded: url_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: file_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: form_helper
INFO - 2023-12-06 16:43:08 --> Helper loaded: my_helper
INFO - 2023-12-06 16:43:08 --> Database Driver Class Initialized
INFO - 2023-12-06 16:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:43:08 --> Controller Class Initialized
INFO - 2023-12-06 16:43:18 --> Config Class Initialized
INFO - 2023-12-06 16:43:18 --> Hooks Class Initialized
DEBUG - 2023-12-06 16:43:18 --> UTF-8 Support Enabled
INFO - 2023-12-06 16:43:18 --> Utf8 Class Initialized
INFO - 2023-12-06 16:43:18 --> URI Class Initialized
INFO - 2023-12-06 16:43:18 --> Router Class Initialized
INFO - 2023-12-06 16:43:18 --> Output Class Initialized
INFO - 2023-12-06 16:43:18 --> Security Class Initialized
DEBUG - 2023-12-06 16:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-06 16:43:18 --> Input Class Initialized
INFO - 2023-12-06 16:43:18 --> Language Class Initialized
INFO - 2023-12-06 16:43:18 --> Language Class Initialized
INFO - 2023-12-06 16:43:18 --> Config Class Initialized
INFO - 2023-12-06 16:43:18 --> Loader Class Initialized
INFO - 2023-12-06 16:43:18 --> Helper loaded: url_helper
INFO - 2023-12-06 16:43:18 --> Helper loaded: file_helper
INFO - 2023-12-06 16:43:18 --> Helper loaded: form_helper
INFO - 2023-12-06 16:43:18 --> Helper loaded: my_helper
INFO - 2023-12-06 16:43:18 --> Database Driver Class Initialized
INFO - 2023-12-06 16:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-06 16:43:18 --> Controller Class Initialized
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-06 16:43:18 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-06 16:43:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-06 16:43:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-06 16:43:18 --> Final output sent to browser
DEBUG - 2023-12-06 16:43:18 --> Total execution time: 0.0812
