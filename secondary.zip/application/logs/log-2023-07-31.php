<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-31 02:44:32 --> Config Class Initialized
INFO - 2023-07-31 02:44:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 02:44:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 02:44:32 --> Utf8 Class Initialized
INFO - 2023-07-31 02:44:32 --> URI Class Initialized
DEBUG - 2023-07-31 02:44:32 --> No URI present. Default controller set.
INFO - 2023-07-31 02:44:32 --> Router Class Initialized
INFO - 2023-07-31 02:44:32 --> Output Class Initialized
INFO - 2023-07-31 02:44:33 --> Security Class Initialized
DEBUG - 2023-07-31 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 02:44:33 --> Input Class Initialized
INFO - 2023-07-31 02:44:33 --> Language Class Initialized
INFO - 2023-07-31 02:44:33 --> Language Class Initialized
INFO - 2023-07-31 02:44:33 --> Config Class Initialized
INFO - 2023-07-31 02:44:33 --> Loader Class Initialized
INFO - 2023-07-31 02:44:33 --> Helper loaded: url_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: file_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: form_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: my_helper
INFO - 2023-07-31 02:44:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 02:44:33 --> Controller Class Initialized
INFO - 2023-07-31 02:44:33 --> Config Class Initialized
INFO - 2023-07-31 02:44:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 02:44:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 02:44:33 --> Utf8 Class Initialized
INFO - 2023-07-31 02:44:33 --> URI Class Initialized
INFO - 2023-07-31 02:44:33 --> Router Class Initialized
INFO - 2023-07-31 02:44:33 --> Output Class Initialized
INFO - 2023-07-31 02:44:33 --> Security Class Initialized
DEBUG - 2023-07-31 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 02:44:33 --> Input Class Initialized
INFO - 2023-07-31 02:44:33 --> Language Class Initialized
INFO - 2023-07-31 02:44:33 --> Language Class Initialized
INFO - 2023-07-31 02:44:33 --> Config Class Initialized
INFO - 2023-07-31 02:44:33 --> Loader Class Initialized
INFO - 2023-07-31 02:44:33 --> Helper loaded: url_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: file_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: form_helper
INFO - 2023-07-31 02:44:33 --> Helper loaded: my_helper
INFO - 2023-07-31 02:44:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 02:44:33 --> Controller Class Initialized
DEBUG - 2023-07-31 02:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-31 02:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 02:44:33 --> Final output sent to browser
DEBUG - 2023-07-31 02:44:33 --> Total execution time: 0.1491
INFO - 2023-07-31 03:42:01 --> Config Class Initialized
INFO - 2023-07-31 03:42:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 03:42:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 03:42:01 --> Utf8 Class Initialized
INFO - 2023-07-31 03:42:01 --> URI Class Initialized
INFO - 2023-07-31 03:42:01 --> Router Class Initialized
INFO - 2023-07-31 03:42:01 --> Output Class Initialized
INFO - 2023-07-31 03:42:01 --> Security Class Initialized
DEBUG - 2023-07-31 03:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 03:42:01 --> Input Class Initialized
INFO - 2023-07-31 03:42:01 --> Language Class Initialized
INFO - 2023-07-31 03:42:01 --> Language Class Initialized
INFO - 2023-07-31 03:42:01 --> Config Class Initialized
INFO - 2023-07-31 03:42:01 --> Loader Class Initialized
INFO - 2023-07-31 03:42:01 --> Helper loaded: url_helper
INFO - 2023-07-31 03:42:01 --> Helper loaded: file_helper
INFO - 2023-07-31 03:42:01 --> Helper loaded: form_helper
INFO - 2023-07-31 03:42:01 --> Helper loaded: my_helper
INFO - 2023-07-31 03:42:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 03:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 03:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 03:42:01 --> Controller Class Initialized
DEBUG - 2023-07-31 03:42:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-31 03:42:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 03:42:01 --> Final output sent to browser
DEBUG - 2023-07-31 03:42:01 --> Total execution time: 0.1236
INFO - 2023-07-31 04:09:04 --> Config Class Initialized
INFO - 2023-07-31 04:09:04 --> Hooks Class Initialized
DEBUG - 2023-07-31 04:09:04 --> UTF-8 Support Enabled
INFO - 2023-07-31 04:09:04 --> Utf8 Class Initialized
INFO - 2023-07-31 04:09:04 --> URI Class Initialized
INFO - 2023-07-31 04:09:04 --> Router Class Initialized
INFO - 2023-07-31 04:09:04 --> Output Class Initialized
INFO - 2023-07-31 04:09:04 --> Security Class Initialized
DEBUG - 2023-07-31 04:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 04:09:04 --> Input Class Initialized
INFO - 2023-07-31 04:09:04 --> Language Class Initialized
INFO - 2023-07-31 04:09:04 --> Language Class Initialized
INFO - 2023-07-31 04:09:04 --> Config Class Initialized
INFO - 2023-07-31 04:09:04 --> Loader Class Initialized
INFO - 2023-07-31 04:09:04 --> Helper loaded: url_helper
INFO - 2023-07-31 04:09:04 --> Helper loaded: file_helper
INFO - 2023-07-31 04:09:04 --> Helper loaded: form_helper
INFO - 2023-07-31 04:09:04 --> Helper loaded: my_helper
INFO - 2023-07-31 04:09:04 --> Database Driver Class Initialized
DEBUG - 2023-07-31 04:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 04:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 04:09:04 --> Controller Class Initialized
ERROR - 2023-07-31 04:09:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\n_catatan_kog\controllers\N_catatan_kog.php 21
ERROR - 2023-07-31 04:09:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\n_catatan_kog\controllers\N_catatan_kog.php 22
DEBUG - 2023-07-31 04:09:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-07-31 04:09:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 04:09:05 --> Final output sent to browser
DEBUG - 2023-07-31 04:09:05 --> Total execution time: 0.3820
INFO - 2023-07-31 08:46:07 --> Config Class Initialized
INFO - 2023-07-31 08:46:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:07 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:07 --> URI Class Initialized
DEBUG - 2023-07-31 08:46:07 --> No URI present. Default controller set.
INFO - 2023-07-31 08:46:07 --> Router Class Initialized
INFO - 2023-07-31 08:46:07 --> Output Class Initialized
INFO - 2023-07-31 08:46:07 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:07 --> Input Class Initialized
INFO - 2023-07-31 08:46:07 --> Language Class Initialized
INFO - 2023-07-31 08:46:07 --> Language Class Initialized
INFO - 2023-07-31 08:46:07 --> Config Class Initialized
INFO - 2023-07-31 08:46:07 --> Loader Class Initialized
INFO - 2023-07-31 08:46:07 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:07 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:07 --> Controller Class Initialized
INFO - 2023-07-31 08:46:07 --> Config Class Initialized
INFO - 2023-07-31 08:46:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:07 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:07 --> URI Class Initialized
INFO - 2023-07-31 08:46:07 --> Router Class Initialized
INFO - 2023-07-31 08:46:07 --> Output Class Initialized
INFO - 2023-07-31 08:46:07 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:07 --> Input Class Initialized
INFO - 2023-07-31 08:46:07 --> Language Class Initialized
INFO - 2023-07-31 08:46:07 --> Language Class Initialized
INFO - 2023-07-31 08:46:07 --> Config Class Initialized
INFO - 2023-07-31 08:46:07 --> Loader Class Initialized
INFO - 2023-07-31 08:46:07 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:07 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:07 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:07 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-31 08:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:07 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:07 --> Total execution time: 0.0974
INFO - 2023-07-31 08:46:14 --> Config Class Initialized
INFO - 2023-07-31 08:46:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:14 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:14 --> URI Class Initialized
INFO - 2023-07-31 08:46:14 --> Router Class Initialized
INFO - 2023-07-31 08:46:14 --> Output Class Initialized
INFO - 2023-07-31 08:46:14 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:14 --> Input Class Initialized
INFO - 2023-07-31 08:46:14 --> Language Class Initialized
INFO - 2023-07-31 08:46:14 --> Language Class Initialized
INFO - 2023-07-31 08:46:14 --> Config Class Initialized
INFO - 2023-07-31 08:46:14 --> Loader Class Initialized
INFO - 2023-07-31 08:46:14 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:14 --> Controller Class Initialized
INFO - 2023-07-31 08:46:14 --> Helper loaded: cookie_helper
INFO - 2023-07-31 08:46:14 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:14 --> Total execution time: 0.1120
INFO - 2023-07-31 08:46:14 --> Config Class Initialized
INFO - 2023-07-31 08:46:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:14 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:14 --> URI Class Initialized
INFO - 2023-07-31 08:46:14 --> Router Class Initialized
INFO - 2023-07-31 08:46:14 --> Output Class Initialized
INFO - 2023-07-31 08:46:14 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:14 --> Input Class Initialized
INFO - 2023-07-31 08:46:14 --> Language Class Initialized
INFO - 2023-07-31 08:46:14 --> Language Class Initialized
INFO - 2023-07-31 08:46:14 --> Config Class Initialized
INFO - 2023-07-31 08:46:14 --> Loader Class Initialized
INFO - 2023-07-31 08:46:14 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:14 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:14 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-31 08:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:14 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:14 --> Total execution time: 0.1138
INFO - 2023-07-31 08:46:16 --> Config Class Initialized
INFO - 2023-07-31 08:46:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:16 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:16 --> URI Class Initialized
INFO - 2023-07-31 08:46:16 --> Router Class Initialized
INFO - 2023-07-31 08:46:16 --> Output Class Initialized
INFO - 2023-07-31 08:46:16 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:16 --> Input Class Initialized
INFO - 2023-07-31 08:46:16 --> Language Class Initialized
INFO - 2023-07-31 08:46:16 --> Language Class Initialized
INFO - 2023-07-31 08:46:16 --> Config Class Initialized
INFO - 2023-07-31 08:46:16 --> Loader Class Initialized
INFO - 2023-07-31 08:46:16 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:16 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:16 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:16 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:16 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:16 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:46:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:16 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:16 --> Total execution time: 0.1045
INFO - 2023-07-31 08:46:16 --> Config Class Initialized
INFO - 2023-07-31 08:46:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:16 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:16 --> URI Class Initialized
INFO - 2023-07-31 08:46:16 --> Router Class Initialized
INFO - 2023-07-31 08:46:16 --> Output Class Initialized
INFO - 2023-07-31 08:46:16 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:16 --> Input Class Initialized
INFO - 2023-07-31 08:46:16 --> Language Class Initialized
INFO - 2023-07-31 08:46:17 --> Language Class Initialized
INFO - 2023-07-31 08:46:17 --> Config Class Initialized
INFO - 2023-07-31 08:46:17 --> Loader Class Initialized
INFO - 2023-07-31 08:46:17 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:17 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-07-31 08:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:17 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:17 --> Total execution time: 0.0914
INFO - 2023-07-31 08:46:17 --> Config Class Initialized
INFO - 2023-07-31 08:46:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:17 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:17 --> URI Class Initialized
INFO - 2023-07-31 08:46:17 --> Router Class Initialized
INFO - 2023-07-31 08:46:17 --> Output Class Initialized
INFO - 2023-07-31 08:46:17 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:17 --> Input Class Initialized
INFO - 2023-07-31 08:46:17 --> Language Class Initialized
INFO - 2023-07-31 08:46:17 --> Language Class Initialized
INFO - 2023-07-31 08:46:17 --> Config Class Initialized
INFO - 2023-07-31 08:46:17 --> Loader Class Initialized
INFO - 2023-07-31 08:46:17 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:17 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:17 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_absensi/views/list.php
DEBUG - 2023-07-31 08:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:17 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:17 --> Total execution time: 0.0821
INFO - 2023-07-31 08:46:18 --> Config Class Initialized
INFO - 2023-07-31 08:46:18 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:18 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:18 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:18 --> URI Class Initialized
INFO - 2023-07-31 08:46:18 --> Router Class Initialized
INFO - 2023-07-31 08:46:18 --> Output Class Initialized
INFO - 2023-07-31 08:46:18 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:18 --> Input Class Initialized
INFO - 2023-07-31 08:46:18 --> Language Class Initialized
INFO - 2023-07-31 08:46:18 --> Language Class Initialized
INFO - 2023-07-31 08:46:18 --> Config Class Initialized
INFO - 2023-07-31 08:46:18 --> Loader Class Initialized
INFO - 2023-07-31 08:46:18 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:18 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:18 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:18 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:18 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:18 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-31 08:46:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:18 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:18 --> Total execution time: 0.1004
INFO - 2023-07-31 08:46:19 --> Config Class Initialized
INFO - 2023-07-31 08:46:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:19 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:19 --> URI Class Initialized
INFO - 2023-07-31 08:46:19 --> Router Class Initialized
INFO - 2023-07-31 08:46:19 --> Output Class Initialized
INFO - 2023-07-31 08:46:19 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:19 --> Input Class Initialized
INFO - 2023-07-31 08:46:19 --> Language Class Initialized
INFO - 2023-07-31 08:46:19 --> Language Class Initialized
INFO - 2023-07-31 08:46:19 --> Config Class Initialized
INFO - 2023-07-31 08:46:19 --> Loader Class Initialized
INFO - 2023-07-31 08:46:19 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:19 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_prestasi/views/list.php
DEBUG - 2023-07-31 08:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:19 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:19 --> Total execution time: 0.0566
INFO - 2023-07-31 08:46:19 --> Config Class Initialized
INFO - 2023-07-31 08:46:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:19 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:19 --> URI Class Initialized
INFO - 2023-07-31 08:46:19 --> Router Class Initialized
INFO - 2023-07-31 08:46:19 --> Output Class Initialized
INFO - 2023-07-31 08:46:19 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:19 --> Input Class Initialized
INFO - 2023-07-31 08:46:19 --> Language Class Initialized
INFO - 2023-07-31 08:46:19 --> Language Class Initialized
INFO - 2023-07-31 08:46:19 --> Config Class Initialized
INFO - 2023-07-31 08:46:19 --> Loader Class Initialized
INFO - 2023-07-31 08:46:19 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:19 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:19 --> Controller Class Initialized
INFO - 2023-07-31 08:46:27 --> Config Class Initialized
INFO - 2023-07-31 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:27 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:27 --> URI Class Initialized
INFO - 2023-07-31 08:46:27 --> Router Class Initialized
INFO - 2023-07-31 08:46:27 --> Output Class Initialized
INFO - 2023-07-31 08:46:27 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:27 --> Input Class Initialized
INFO - 2023-07-31 08:46:27 --> Language Class Initialized
INFO - 2023-07-31 08:46:27 --> Language Class Initialized
INFO - 2023-07-31 08:46:27 --> Config Class Initialized
INFO - 2023-07-31 08:46:27 --> Loader Class Initialized
INFO - 2023-07-31 08:46:27 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:27 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:27 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:27 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:27 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:27 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-31 08:46:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:27 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:27 --> Total execution time: 0.0323
INFO - 2023-07-31 08:46:28 --> Config Class Initialized
INFO - 2023-07-31 08:46:28 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:28 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:28 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:28 --> URI Class Initialized
INFO - 2023-07-31 08:46:28 --> Router Class Initialized
INFO - 2023-07-31 08:46:28 --> Output Class Initialized
INFO - 2023-07-31 08:46:28 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:28 --> Input Class Initialized
INFO - 2023-07-31 08:46:28 --> Language Class Initialized
INFO - 2023-07-31 08:46:28 --> Language Class Initialized
INFO - 2023-07-31 08:46:28 --> Config Class Initialized
INFO - 2023-07-31 08:46:28 --> Loader Class Initialized
INFO - 2023-07-31 08:46:28 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:28 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:28 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_prestasi/views/list.php
DEBUG - 2023-07-31 08:46:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:28 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:28 --> Total execution time: 0.0386
INFO - 2023-07-31 08:46:28 --> Config Class Initialized
INFO - 2023-07-31 08:46:28 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:28 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:28 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:28 --> URI Class Initialized
INFO - 2023-07-31 08:46:28 --> Router Class Initialized
INFO - 2023-07-31 08:46:28 --> Output Class Initialized
INFO - 2023-07-31 08:46:28 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:28 --> Input Class Initialized
INFO - 2023-07-31 08:46:28 --> Language Class Initialized
INFO - 2023-07-31 08:46:28 --> Language Class Initialized
INFO - 2023-07-31 08:46:28 --> Config Class Initialized
INFO - 2023-07-31 08:46:28 --> Loader Class Initialized
INFO - 2023-07-31 08:46:28 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:28 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:28 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:28 --> Controller Class Initialized
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:31 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:31 --> URI Class Initialized
INFO - 2023-07-31 08:46:31 --> Router Class Initialized
INFO - 2023-07-31 08:46:31 --> Output Class Initialized
INFO - 2023-07-31 08:46:31 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:31 --> Input Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Loader Class Initialized
INFO - 2023-07-31 08:46:31 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:31 --> Controller Class Initialized
INFO - 2023-07-31 08:46:31 --> Helper loaded: cookie_helper
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:31 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:31 --> URI Class Initialized
INFO - 2023-07-31 08:46:31 --> Router Class Initialized
INFO - 2023-07-31 08:46:31 --> Output Class Initialized
INFO - 2023-07-31 08:46:31 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:31 --> Input Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Loader Class Initialized
INFO - 2023-07-31 08:46:31 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:31 --> Controller Class Initialized
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:31 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:31 --> URI Class Initialized
INFO - 2023-07-31 08:46:31 --> Router Class Initialized
INFO - 2023-07-31 08:46:31 --> Output Class Initialized
INFO - 2023-07-31 08:46:31 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:31 --> Input Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Language Class Initialized
INFO - 2023-07-31 08:46:31 --> Config Class Initialized
INFO - 2023-07-31 08:46:31 --> Loader Class Initialized
INFO - 2023-07-31 08:46:31 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:31 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:31 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-31 08:46:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:31 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:31 --> Total execution time: 0.0227
INFO - 2023-07-31 08:46:36 --> Config Class Initialized
INFO - 2023-07-31 08:46:36 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:36 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:36 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:36 --> URI Class Initialized
INFO - 2023-07-31 08:46:36 --> Router Class Initialized
INFO - 2023-07-31 08:46:36 --> Output Class Initialized
INFO - 2023-07-31 08:46:36 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:36 --> Input Class Initialized
INFO - 2023-07-31 08:46:36 --> Language Class Initialized
INFO - 2023-07-31 08:46:36 --> Language Class Initialized
INFO - 2023-07-31 08:46:36 --> Config Class Initialized
INFO - 2023-07-31 08:46:36 --> Loader Class Initialized
INFO - 2023-07-31 08:46:36 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:36 --> Controller Class Initialized
INFO - 2023-07-31 08:46:36 --> Helper loaded: cookie_helper
INFO - 2023-07-31 08:46:36 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:36 --> Total execution time: 0.0474
INFO - 2023-07-31 08:46:36 --> Config Class Initialized
INFO - 2023-07-31 08:46:36 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:36 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:36 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:36 --> URI Class Initialized
INFO - 2023-07-31 08:46:36 --> Router Class Initialized
INFO - 2023-07-31 08:46:36 --> Output Class Initialized
INFO - 2023-07-31 08:46:36 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:36 --> Input Class Initialized
INFO - 2023-07-31 08:46:36 --> Language Class Initialized
INFO - 2023-07-31 08:46:36 --> Language Class Initialized
INFO - 2023-07-31 08:46:36 --> Config Class Initialized
INFO - 2023-07-31 08:46:36 --> Loader Class Initialized
INFO - 2023-07-31 08:46:36 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:36 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:36 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-31 08:46:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:36 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:36 --> Total execution time: 0.0463
INFO - 2023-07-31 08:46:37 --> Config Class Initialized
INFO - 2023-07-31 08:46:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:37 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:37 --> URI Class Initialized
INFO - 2023-07-31 08:46:37 --> Router Class Initialized
INFO - 2023-07-31 08:46:37 --> Output Class Initialized
INFO - 2023-07-31 08:46:37 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:37 --> Input Class Initialized
INFO - 2023-07-31 08:46:37 --> Language Class Initialized
INFO - 2023-07-31 08:46:37 --> Language Class Initialized
INFO - 2023-07-31 08:46:37 --> Config Class Initialized
INFO - 2023-07-31 08:46:37 --> Loader Class Initialized
INFO - 2023-07-31 08:46:37 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:37 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:37 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:37 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:38 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:46:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:38 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:38 --> Total execution time: 0.0379
INFO - 2023-07-31 08:46:39 --> Config Class Initialized
INFO - 2023-07-31 08:46:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:39 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:39 --> URI Class Initialized
INFO - 2023-07-31 08:46:39 --> Router Class Initialized
INFO - 2023-07-31 08:46:39 --> Output Class Initialized
INFO - 2023-07-31 08:46:39 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:39 --> Input Class Initialized
INFO - 2023-07-31 08:46:39 --> Language Class Initialized
INFO - 2023-07-31 08:46:39 --> Language Class Initialized
INFO - 2023-07-31 08:46:39 --> Config Class Initialized
INFO - 2023-07-31 08:46:39 --> Loader Class Initialized
INFO - 2023-07-31 08:46:39 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:39 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:39 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:39 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:39 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-31 08:46:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:39 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:39 --> Total execution time: 0.1198
INFO - 2023-07-31 08:46:41 --> Config Class Initialized
INFO - 2023-07-31 08:46:41 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:41 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:41 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:41 --> URI Class Initialized
INFO - 2023-07-31 08:46:41 --> Router Class Initialized
INFO - 2023-07-31 08:46:41 --> Output Class Initialized
INFO - 2023-07-31 08:46:41 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:41 --> Input Class Initialized
INFO - 2023-07-31 08:46:41 --> Language Class Initialized
INFO - 2023-07-31 08:46:41 --> Language Class Initialized
INFO - 2023-07-31 08:46:41 --> Config Class Initialized
INFO - 2023-07-31 08:46:41 --> Loader Class Initialized
INFO - 2023-07-31 08:46:41 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:41 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:41 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:41 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:41 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:41 --> Controller Class Initialized
INFO - 2023-07-31 08:46:41 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:41 --> Total execution time: 0.0279
INFO - 2023-07-31 08:46:46 --> Config Class Initialized
INFO - 2023-07-31 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:46 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:46 --> URI Class Initialized
INFO - 2023-07-31 08:46:46 --> Router Class Initialized
INFO - 2023-07-31 08:46:46 --> Output Class Initialized
INFO - 2023-07-31 08:46:46 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:46 --> Input Class Initialized
INFO - 2023-07-31 08:46:46 --> Language Class Initialized
INFO - 2023-07-31 08:46:46 --> Language Class Initialized
INFO - 2023-07-31 08:46:46 --> Config Class Initialized
INFO - 2023-07-31 08:46:46 --> Loader Class Initialized
INFO - 2023-07-31 08:46:46 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:46 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:46 --> Controller Class Initialized
INFO - 2023-07-31 08:46:46 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:46 --> Total execution time: 0.0294
INFO - 2023-07-31 08:46:46 --> Config Class Initialized
INFO - 2023-07-31 08:46:46 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:46 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:46 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:46 --> URI Class Initialized
INFO - 2023-07-31 08:46:46 --> Router Class Initialized
INFO - 2023-07-31 08:46:46 --> Output Class Initialized
INFO - 2023-07-31 08:46:46 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:46 --> Input Class Initialized
INFO - 2023-07-31 08:46:46 --> Language Class Initialized
INFO - 2023-07-31 08:46:46 --> Language Class Initialized
INFO - 2023-07-31 08:46:46 --> Config Class Initialized
INFO - 2023-07-31 08:46:46 --> Loader Class Initialized
INFO - 2023-07-31 08:46:46 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:46 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:46 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:46 --> Controller Class Initialized
INFO - 2023-07-31 08:46:46 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:46 --> Total execution time: 0.0240
INFO - 2023-07-31 08:46:47 --> Config Class Initialized
INFO - 2023-07-31 08:46:47 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:47 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:47 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:47 --> URI Class Initialized
INFO - 2023-07-31 08:46:47 --> Router Class Initialized
INFO - 2023-07-31 08:46:47 --> Output Class Initialized
INFO - 2023-07-31 08:46:47 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:47 --> Input Class Initialized
INFO - 2023-07-31 08:46:47 --> Language Class Initialized
INFO - 2023-07-31 08:46:47 --> Language Class Initialized
INFO - 2023-07-31 08:46:47 --> Config Class Initialized
INFO - 2023-07-31 08:46:47 --> Loader Class Initialized
INFO - 2023-07-31 08:46:47 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:47 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:47 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:47 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:47 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:47 --> Controller Class Initialized
INFO - 2023-07-31 08:46:47 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:47 --> Total execution time: 0.0260
INFO - 2023-07-31 08:46:50 --> Config Class Initialized
INFO - 2023-07-31 08:46:50 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:50 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:50 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:50 --> URI Class Initialized
INFO - 2023-07-31 08:46:50 --> Router Class Initialized
INFO - 2023-07-31 08:46:50 --> Output Class Initialized
INFO - 2023-07-31 08:46:50 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:50 --> Input Class Initialized
INFO - 2023-07-31 08:46:50 --> Language Class Initialized
INFO - 2023-07-31 08:46:50 --> Language Class Initialized
INFO - 2023-07-31 08:46:50 --> Config Class Initialized
INFO - 2023-07-31 08:46:50 --> Loader Class Initialized
INFO - 2023-07-31 08:46:50 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:50 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:50 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:50 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:50 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:50 --> Controller Class Initialized
INFO - 2023-07-31 08:46:50 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:50 --> Total execution time: 0.0416
INFO - 2023-07-31 08:46:53 --> Config Class Initialized
INFO - 2023-07-31 08:46:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:53 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:53 --> URI Class Initialized
INFO - 2023-07-31 08:46:53 --> Router Class Initialized
INFO - 2023-07-31 08:46:53 --> Output Class Initialized
INFO - 2023-07-31 08:46:53 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:53 --> Input Class Initialized
INFO - 2023-07-31 08:46:53 --> Language Class Initialized
INFO - 2023-07-31 08:46:53 --> Language Class Initialized
INFO - 2023-07-31 08:46:53 --> Config Class Initialized
INFO - 2023-07-31 08:46:53 --> Loader Class Initialized
INFO - 2023-07-31 08:46:53 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:53 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:53 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:53 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:53 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:53 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:53 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:53 --> Total execution time: 0.0321
INFO - 2023-07-31 08:46:54 --> Config Class Initialized
INFO - 2023-07-31 08:46:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:54 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:54 --> URI Class Initialized
INFO - 2023-07-31 08:46:54 --> Router Class Initialized
INFO - 2023-07-31 08:46:54 --> Output Class Initialized
INFO - 2023-07-31 08:46:54 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:54 --> Input Class Initialized
INFO - 2023-07-31 08:46:54 --> Language Class Initialized
INFO - 2023-07-31 08:46:54 --> Language Class Initialized
INFO - 2023-07-31 08:46:54 --> Config Class Initialized
INFO - 2023-07-31 08:46:54 --> Loader Class Initialized
INFO - 2023-07-31 08:46:54 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:54 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-31 08:46:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:54 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:54 --> Total execution time: 0.0788
INFO - 2023-07-31 08:46:54 --> Config Class Initialized
INFO - 2023-07-31 08:46:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:54 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:54 --> URI Class Initialized
INFO - 2023-07-31 08:46:54 --> Router Class Initialized
INFO - 2023-07-31 08:46:54 --> Output Class Initialized
INFO - 2023-07-31 08:46:54 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:54 --> Input Class Initialized
INFO - 2023-07-31 08:46:54 --> Language Class Initialized
INFO - 2023-07-31 08:46:54 --> Language Class Initialized
INFO - 2023-07-31 08:46:54 --> Config Class Initialized
INFO - 2023-07-31 08:46:54 --> Loader Class Initialized
INFO - 2023-07-31 08:46:54 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:54 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:54 --> Controller Class Initialized
INFO - 2023-07-31 08:46:56 --> Config Class Initialized
INFO - 2023-07-31 08:46:56 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:56 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:56 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:56 --> URI Class Initialized
INFO - 2023-07-31 08:46:56 --> Router Class Initialized
INFO - 2023-07-31 08:46:56 --> Output Class Initialized
INFO - 2023-07-31 08:46:56 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:56 --> Input Class Initialized
INFO - 2023-07-31 08:46:56 --> Language Class Initialized
INFO - 2023-07-31 08:46:56 --> Language Class Initialized
INFO - 2023-07-31 08:46:56 --> Config Class Initialized
INFO - 2023-07-31 08:46:56 --> Loader Class Initialized
INFO - 2023-07-31 08:46:56 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:56 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:56 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:56 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:56 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:56 --> Controller Class Initialized
INFO - 2023-07-31 08:46:56 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:56 --> Total execution time: 0.0260
INFO - 2023-07-31 08:46:58 --> Config Class Initialized
INFO - 2023-07-31 08:46:58 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:58 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:58 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:58 --> URI Class Initialized
INFO - 2023-07-31 08:46:58 --> Router Class Initialized
INFO - 2023-07-31 08:46:58 --> Output Class Initialized
INFO - 2023-07-31 08:46:58 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:58 --> Input Class Initialized
INFO - 2023-07-31 08:46:58 --> Language Class Initialized
INFO - 2023-07-31 08:46:58 --> Language Class Initialized
INFO - 2023-07-31 08:46:58 --> Config Class Initialized
INFO - 2023-07-31 08:46:58 --> Loader Class Initialized
INFO - 2023-07-31 08:46:58 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:58 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:58 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:58 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:58 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:58 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:46:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:58 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:58 --> Total execution time: 0.0286
INFO - 2023-07-31 08:46:59 --> Config Class Initialized
INFO - 2023-07-31 08:46:59 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:46:59 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:46:59 --> Utf8 Class Initialized
INFO - 2023-07-31 08:46:59 --> URI Class Initialized
INFO - 2023-07-31 08:46:59 --> Router Class Initialized
INFO - 2023-07-31 08:46:59 --> Output Class Initialized
INFO - 2023-07-31 08:46:59 --> Security Class Initialized
DEBUG - 2023-07-31 08:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:46:59 --> Input Class Initialized
INFO - 2023-07-31 08:46:59 --> Language Class Initialized
INFO - 2023-07-31 08:46:59 --> Language Class Initialized
INFO - 2023-07-31 08:46:59 --> Config Class Initialized
INFO - 2023-07-31 08:46:59 --> Loader Class Initialized
INFO - 2023-07-31 08:46:59 --> Helper loaded: url_helper
INFO - 2023-07-31 08:46:59 --> Helper loaded: file_helper
INFO - 2023-07-31 08:46:59 --> Helper loaded: form_helper
INFO - 2023-07-31 08:46:59 --> Helper loaded: my_helper
INFO - 2023-07-31 08:46:59 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:46:59 --> Controller Class Initialized
DEBUG - 2023-07-31 08:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-07-31 08:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:46:59 --> Final output sent to browser
DEBUG - 2023-07-31 08:46:59 --> Total execution time: 0.0716
INFO - 2023-07-31 08:47:02 --> Config Class Initialized
INFO - 2023-07-31 08:47:02 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:02 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:02 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:02 --> URI Class Initialized
INFO - 2023-07-31 08:47:02 --> Router Class Initialized
INFO - 2023-07-31 08:47:02 --> Output Class Initialized
INFO - 2023-07-31 08:47:02 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:02 --> Input Class Initialized
INFO - 2023-07-31 08:47:02 --> Language Class Initialized
INFO - 2023-07-31 08:47:02 --> Language Class Initialized
INFO - 2023-07-31 08:47:02 --> Config Class Initialized
INFO - 2023-07-31 08:47:02 --> Loader Class Initialized
INFO - 2023-07-31 08:47:02 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:02 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:02 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:02 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:02 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:02 --> Controller Class Initialized
INFO - 2023-07-31 08:47:02 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:02 --> Total execution time: 0.0252
INFO - 2023-07-31 08:47:11 --> Config Class Initialized
INFO - 2023-07-31 08:47:11 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:11 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:11 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:11 --> URI Class Initialized
INFO - 2023-07-31 08:47:11 --> Router Class Initialized
INFO - 2023-07-31 08:47:11 --> Output Class Initialized
INFO - 2023-07-31 08:47:11 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:11 --> Input Class Initialized
INFO - 2023-07-31 08:47:11 --> Language Class Initialized
INFO - 2023-07-31 08:47:11 --> Language Class Initialized
INFO - 2023-07-31 08:47:11 --> Config Class Initialized
INFO - 2023-07-31 08:47:11 --> Loader Class Initialized
INFO - 2023-07-31 08:47:11 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:11 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:11 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:11 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:11 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:11 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:47:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:11 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:11 --> Total execution time: 0.0442
INFO - 2023-07-31 08:47:12 --> Config Class Initialized
INFO - 2023-07-31 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:12 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:12 --> URI Class Initialized
INFO - 2023-07-31 08:47:12 --> Router Class Initialized
INFO - 2023-07-31 08:47:12 --> Output Class Initialized
INFO - 2023-07-31 08:47:12 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:12 --> Input Class Initialized
INFO - 2023-07-31 08:47:12 --> Language Class Initialized
INFO - 2023-07-31 08:47:12 --> Language Class Initialized
INFO - 2023-07-31 08:47:12 --> Config Class Initialized
INFO - 2023-07-31 08:47:12 --> Loader Class Initialized
INFO - 2023-07-31 08:47:12 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:12 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:12 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-31 08:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:12 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:12 --> Total execution time: 0.0284
INFO - 2023-07-31 08:47:12 --> Config Class Initialized
INFO - 2023-07-31 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:12 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:12 --> URI Class Initialized
INFO - 2023-07-31 08:47:12 --> Router Class Initialized
INFO - 2023-07-31 08:47:12 --> Output Class Initialized
INFO - 2023-07-31 08:47:12 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:12 --> Input Class Initialized
INFO - 2023-07-31 08:47:12 --> Language Class Initialized
INFO - 2023-07-31 08:47:12 --> Language Class Initialized
INFO - 2023-07-31 08:47:12 --> Config Class Initialized
INFO - 2023-07-31 08:47:12 --> Loader Class Initialized
INFO - 2023-07-31 08:47:12 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:12 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:12 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:12 --> Controller Class Initialized
INFO - 2023-07-31 08:47:14 --> Config Class Initialized
INFO - 2023-07-31 08:47:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:14 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:14 --> URI Class Initialized
INFO - 2023-07-31 08:47:14 --> Router Class Initialized
INFO - 2023-07-31 08:47:14 --> Output Class Initialized
INFO - 2023-07-31 08:47:14 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:14 --> Input Class Initialized
INFO - 2023-07-31 08:47:14 --> Language Class Initialized
INFO - 2023-07-31 08:47:14 --> Language Class Initialized
INFO - 2023-07-31 08:47:14 --> Config Class Initialized
INFO - 2023-07-31 08:47:14 --> Loader Class Initialized
INFO - 2023-07-31 08:47:14 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:14 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:14 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:14 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:14 --> Controller Class Initialized
INFO - 2023-07-31 08:47:14 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:14 --> Total execution time: 0.0267
INFO - 2023-07-31 08:47:20 --> Config Class Initialized
INFO - 2023-07-31 08:47:20 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:20 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:20 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:20 --> URI Class Initialized
INFO - 2023-07-31 08:47:20 --> Router Class Initialized
INFO - 2023-07-31 08:47:20 --> Output Class Initialized
INFO - 2023-07-31 08:47:20 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:20 --> Input Class Initialized
INFO - 2023-07-31 08:47:20 --> Language Class Initialized
INFO - 2023-07-31 08:47:20 --> Language Class Initialized
INFO - 2023-07-31 08:47:20 --> Config Class Initialized
INFO - 2023-07-31 08:47:20 --> Loader Class Initialized
INFO - 2023-07-31 08:47:20 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:20 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:20 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:20 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:20 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:20 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:47:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:20 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:20 --> Total execution time: 0.0273
INFO - 2023-07-31 08:47:21 --> Config Class Initialized
INFO - 2023-07-31 08:47:21 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:21 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:21 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:21 --> URI Class Initialized
INFO - 2023-07-31 08:47:21 --> Router Class Initialized
INFO - 2023-07-31 08:47:21 --> Output Class Initialized
INFO - 2023-07-31 08:47:21 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:21 --> Input Class Initialized
INFO - 2023-07-31 08:47:21 --> Language Class Initialized
INFO - 2023-07-31 08:47:21 --> Language Class Initialized
INFO - 2023-07-31 08:47:21 --> Config Class Initialized
INFO - 2023-07-31 08:47:21 --> Loader Class Initialized
INFO - 2023-07-31 08:47:21 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:21 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:21 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:21 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:21 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:21 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-31 08:47:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:21 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:21 --> Total execution time: 0.0255
INFO - 2023-07-31 08:47:25 --> Config Class Initialized
INFO - 2023-07-31 08:47:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:25 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:25 --> URI Class Initialized
INFO - 2023-07-31 08:47:25 --> Router Class Initialized
INFO - 2023-07-31 08:47:25 --> Output Class Initialized
INFO - 2023-07-31 08:47:25 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:25 --> Input Class Initialized
INFO - 2023-07-31 08:47:25 --> Language Class Initialized
INFO - 2023-07-31 08:47:25 --> Language Class Initialized
INFO - 2023-07-31 08:47:25 --> Config Class Initialized
INFO - 2023-07-31 08:47:25 --> Loader Class Initialized
INFO - 2023-07-31 08:47:25 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:25 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:25 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:25 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:25 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:25 --> Controller Class Initialized
INFO - 2023-07-31 08:47:25 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:25 --> Total execution time: 0.0276
INFO - 2023-07-31 08:47:30 --> Config Class Initialized
INFO - 2023-07-31 08:47:30 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:30 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:30 --> URI Class Initialized
INFO - 2023-07-31 08:47:30 --> Router Class Initialized
INFO - 2023-07-31 08:47:30 --> Output Class Initialized
INFO - 2023-07-31 08:47:30 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:30 --> Input Class Initialized
INFO - 2023-07-31 08:47:30 --> Language Class Initialized
INFO - 2023-07-31 08:47:30 --> Language Class Initialized
INFO - 2023-07-31 08:47:30 --> Config Class Initialized
INFO - 2023-07-31 08:47:30 --> Loader Class Initialized
INFO - 2023-07-31 08:47:30 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:30 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:30 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:30 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:30 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:30 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:47:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:30 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:30 --> Total execution time: 0.0287
INFO - 2023-07-31 08:47:38 --> Config Class Initialized
INFO - 2023-07-31 08:47:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:38 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:38 --> URI Class Initialized
INFO - 2023-07-31 08:47:38 --> Router Class Initialized
INFO - 2023-07-31 08:47:38 --> Output Class Initialized
INFO - 2023-07-31 08:47:38 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:38 --> Input Class Initialized
INFO - 2023-07-31 08:47:38 --> Language Class Initialized
INFO - 2023-07-31 08:47:38 --> Language Class Initialized
INFO - 2023-07-31 08:47:38 --> Config Class Initialized
INFO - 2023-07-31 08:47:38 --> Loader Class Initialized
INFO - 2023-07-31 08:47:38 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:38 --> Controller Class Initialized
DEBUG - 2023-07-31 08:47:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-31 08:47:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:47:38 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:38 --> Total execution time: 0.0389
INFO - 2023-07-31 08:47:38 --> Config Class Initialized
INFO - 2023-07-31 08:47:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:38 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:38 --> URI Class Initialized
INFO - 2023-07-31 08:47:38 --> Router Class Initialized
INFO - 2023-07-31 08:47:38 --> Output Class Initialized
INFO - 2023-07-31 08:47:38 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:38 --> Input Class Initialized
INFO - 2023-07-31 08:47:38 --> Language Class Initialized
INFO - 2023-07-31 08:47:38 --> Language Class Initialized
INFO - 2023-07-31 08:47:38 --> Config Class Initialized
INFO - 2023-07-31 08:47:38 --> Loader Class Initialized
INFO - 2023-07-31 08:47:38 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:38 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:38 --> Controller Class Initialized
INFO - 2023-07-31 08:47:40 --> Config Class Initialized
INFO - 2023-07-31 08:47:40 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:40 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:40 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:40 --> URI Class Initialized
INFO - 2023-07-31 08:47:40 --> Router Class Initialized
INFO - 2023-07-31 08:47:40 --> Output Class Initialized
INFO - 2023-07-31 08:47:40 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:40 --> Input Class Initialized
INFO - 2023-07-31 08:47:40 --> Language Class Initialized
INFO - 2023-07-31 08:47:40 --> Language Class Initialized
INFO - 2023-07-31 08:47:40 --> Config Class Initialized
INFO - 2023-07-31 08:47:40 --> Loader Class Initialized
INFO - 2023-07-31 08:47:40 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:40 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:40 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:40 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:40 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:40 --> Controller Class Initialized
INFO - 2023-07-31 08:47:40 --> Final output sent to browser
DEBUG - 2023-07-31 08:47:40 --> Total execution time: 0.0373
INFO - 2023-07-31 08:47:57 --> Config Class Initialized
INFO - 2023-07-31 08:47:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:47:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:47:57 --> Utf8 Class Initialized
INFO - 2023-07-31 08:47:57 --> URI Class Initialized
INFO - 2023-07-31 08:47:57 --> Router Class Initialized
INFO - 2023-07-31 08:47:57 --> Output Class Initialized
INFO - 2023-07-31 08:47:57 --> Security Class Initialized
DEBUG - 2023-07-31 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:47:57 --> Input Class Initialized
INFO - 2023-07-31 08:47:57 --> Language Class Initialized
INFO - 2023-07-31 08:47:57 --> Language Class Initialized
INFO - 2023-07-31 08:47:57 --> Config Class Initialized
INFO - 2023-07-31 08:47:57 --> Loader Class Initialized
INFO - 2023-07-31 08:47:57 --> Helper loaded: url_helper
INFO - 2023-07-31 08:47:57 --> Helper loaded: file_helper
INFO - 2023-07-31 08:47:57 --> Helper loaded: form_helper
INFO - 2023-07-31 08:47:57 --> Helper loaded: my_helper
INFO - 2023-07-31 08:47:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:47:57 --> Controller Class Initialized
INFO - 2023-07-31 08:48:59 --> Config Class Initialized
INFO - 2023-07-31 08:48:59 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:48:59 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:48:59 --> Utf8 Class Initialized
INFO - 2023-07-31 08:48:59 --> URI Class Initialized
INFO - 2023-07-31 08:48:59 --> Router Class Initialized
INFO - 2023-07-31 08:48:59 --> Output Class Initialized
INFO - 2023-07-31 08:48:59 --> Security Class Initialized
DEBUG - 2023-07-31 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:48:59 --> Input Class Initialized
INFO - 2023-07-31 08:48:59 --> Language Class Initialized
INFO - 2023-07-31 08:48:59 --> Language Class Initialized
INFO - 2023-07-31 08:48:59 --> Config Class Initialized
INFO - 2023-07-31 08:48:59 --> Loader Class Initialized
INFO - 2023-07-31 08:48:59 --> Helper loaded: url_helper
INFO - 2023-07-31 08:48:59 --> Helper loaded: file_helper
INFO - 2023-07-31 08:48:59 --> Helper loaded: form_helper
INFO - 2023-07-31 08:48:59 --> Helper loaded: my_helper
INFO - 2023-07-31 08:48:59 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:48:59 --> Controller Class Initialized
DEBUG - 2023-07-31 08:48:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-07-31 08:48:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:48:59 --> Final output sent to browser
DEBUG - 2023-07-31 08:48:59 --> Total execution time: 0.0534
INFO - 2023-07-31 08:49:04 --> Config Class Initialized
INFO - 2023-07-31 08:49:04 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:04 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:04 --> URI Class Initialized
INFO - 2023-07-31 08:49:04 --> Router Class Initialized
INFO - 2023-07-31 08:49:04 --> Output Class Initialized
INFO - 2023-07-31 08:49:04 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:04 --> Input Class Initialized
INFO - 2023-07-31 08:49:04 --> Language Class Initialized
INFO - 2023-07-31 08:49:04 --> Language Class Initialized
INFO - 2023-07-31 08:49:04 --> Config Class Initialized
INFO - 2023-07-31 08:49:04 --> Loader Class Initialized
INFO - 2023-07-31 08:49:04 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:04 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:04 --> Controller Class Initialized
INFO - 2023-07-31 08:49:04 --> Config Class Initialized
INFO - 2023-07-31 08:49:04 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:04 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:04 --> URI Class Initialized
INFO - 2023-07-31 08:49:04 --> Router Class Initialized
INFO - 2023-07-31 08:49:04 --> Output Class Initialized
INFO - 2023-07-31 08:49:04 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:04 --> Input Class Initialized
INFO - 2023-07-31 08:49:04 --> Language Class Initialized
INFO - 2023-07-31 08:49:04 --> Language Class Initialized
INFO - 2023-07-31 08:49:04 --> Config Class Initialized
INFO - 2023-07-31 08:49:04 --> Loader Class Initialized
INFO - 2023-07-31 08:49:04 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:04 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:04 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:04 --> Controller Class Initialized
DEBUG - 2023-07-31 08:49:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-31 08:49:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:49:04 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:04 --> Total execution time: 0.0426
INFO - 2023-07-31 08:49:05 --> Config Class Initialized
INFO - 2023-07-31 08:49:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:05 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:05 --> URI Class Initialized
INFO - 2023-07-31 08:49:05 --> Router Class Initialized
INFO - 2023-07-31 08:49:05 --> Output Class Initialized
INFO - 2023-07-31 08:49:05 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:05 --> Input Class Initialized
INFO - 2023-07-31 08:49:05 --> Language Class Initialized
INFO - 2023-07-31 08:49:05 --> Language Class Initialized
INFO - 2023-07-31 08:49:05 --> Config Class Initialized
INFO - 2023-07-31 08:49:05 --> Loader Class Initialized
INFO - 2023-07-31 08:49:05 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:05 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:05 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:05 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:05 --> Controller Class Initialized
INFO - 2023-07-31 08:49:06 --> Config Class Initialized
INFO - 2023-07-31 08:49:06 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:06 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:06 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:06 --> URI Class Initialized
INFO - 2023-07-31 08:49:06 --> Router Class Initialized
INFO - 2023-07-31 08:49:06 --> Output Class Initialized
INFO - 2023-07-31 08:49:06 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:06 --> Input Class Initialized
INFO - 2023-07-31 08:49:06 --> Language Class Initialized
INFO - 2023-07-31 08:49:06 --> Language Class Initialized
INFO - 2023-07-31 08:49:06 --> Config Class Initialized
INFO - 2023-07-31 08:49:06 --> Loader Class Initialized
INFO - 2023-07-31 08:49:06 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:06 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:06 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:06 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:06 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:06 --> Controller Class Initialized
INFO - 2023-07-31 08:49:06 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:06 --> Total execution time: 0.0265
INFO - 2023-07-31 08:49:29 --> Config Class Initialized
INFO - 2023-07-31 08:49:29 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:29 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:29 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:29 --> URI Class Initialized
INFO - 2023-07-31 08:49:29 --> Router Class Initialized
INFO - 2023-07-31 08:49:29 --> Output Class Initialized
INFO - 2023-07-31 08:49:29 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:29 --> Input Class Initialized
INFO - 2023-07-31 08:49:29 --> Language Class Initialized
INFO - 2023-07-31 08:49:29 --> Language Class Initialized
INFO - 2023-07-31 08:49:29 --> Config Class Initialized
INFO - 2023-07-31 08:49:29 --> Loader Class Initialized
INFO - 2023-07-31 08:49:29 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:29 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:29 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:29 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:29 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:29 --> Controller Class Initialized
INFO - 2023-07-31 08:49:29 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:29 --> Total execution time: 0.0468
INFO - 2023-07-31 08:49:32 --> Config Class Initialized
INFO - 2023-07-31 08:49:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:32 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:32 --> URI Class Initialized
INFO - 2023-07-31 08:49:32 --> Router Class Initialized
INFO - 2023-07-31 08:49:32 --> Output Class Initialized
INFO - 2023-07-31 08:49:32 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:32 --> Input Class Initialized
INFO - 2023-07-31 08:49:32 --> Language Class Initialized
INFO - 2023-07-31 08:49:32 --> Language Class Initialized
INFO - 2023-07-31 08:49:32 --> Config Class Initialized
INFO - 2023-07-31 08:49:32 --> Loader Class Initialized
INFO - 2023-07-31 08:49:32 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:32 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:32 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:32 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:32 --> Controller Class Initialized
DEBUG - 2023-07-31 08:49:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:49:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:49:32 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:32 --> Total execution time: 0.0290
INFO - 2023-07-31 08:49:33 --> Config Class Initialized
INFO - 2023-07-31 08:49:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:33 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:33 --> URI Class Initialized
INFO - 2023-07-31 08:49:33 --> Router Class Initialized
INFO - 2023-07-31 08:49:33 --> Output Class Initialized
INFO - 2023-07-31 08:49:33 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:33 --> Input Class Initialized
INFO - 2023-07-31 08:49:33 --> Language Class Initialized
INFO - 2023-07-31 08:49:33 --> Language Class Initialized
INFO - 2023-07-31 08:49:33 --> Config Class Initialized
INFO - 2023-07-31 08:49:33 --> Loader Class Initialized
INFO - 2023-07-31 08:49:33 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:33 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:33 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:33 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:33 --> Controller Class Initialized
DEBUG - 2023-07-31 08:49:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-31 08:49:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:49:33 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:33 --> Total execution time: 0.0424
INFO - 2023-07-31 08:49:35 --> Config Class Initialized
INFO - 2023-07-31 08:49:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:35 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:35 --> URI Class Initialized
INFO - 2023-07-31 08:49:35 --> Router Class Initialized
INFO - 2023-07-31 08:49:35 --> Output Class Initialized
INFO - 2023-07-31 08:49:35 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:35 --> Input Class Initialized
INFO - 2023-07-31 08:49:35 --> Language Class Initialized
INFO - 2023-07-31 08:49:35 --> Language Class Initialized
INFO - 2023-07-31 08:49:35 --> Config Class Initialized
INFO - 2023-07-31 08:49:35 --> Loader Class Initialized
INFO - 2023-07-31 08:49:35 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:35 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:35 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:35 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:35 --> Controller Class Initialized
INFO - 2023-07-31 08:49:38 --> Config Class Initialized
INFO - 2023-07-31 08:49:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:38 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:38 --> URI Class Initialized
INFO - 2023-07-31 08:49:38 --> Router Class Initialized
INFO - 2023-07-31 08:49:38 --> Output Class Initialized
INFO - 2023-07-31 08:49:38 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:38 --> Input Class Initialized
INFO - 2023-07-31 08:49:38 --> Language Class Initialized
INFO - 2023-07-31 08:49:38 --> Language Class Initialized
INFO - 2023-07-31 08:49:38 --> Config Class Initialized
INFO - 2023-07-31 08:49:38 --> Loader Class Initialized
INFO - 2023-07-31 08:49:38 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:38 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:38 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:38 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:38 --> Controller Class Initialized
INFO - 2023-07-31 08:49:38 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:38 --> Total execution time: 0.0298
INFO - 2023-07-31 08:49:52 --> Config Class Initialized
INFO - 2023-07-31 08:49:52 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:52 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:52 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:52 --> URI Class Initialized
INFO - 2023-07-31 08:49:52 --> Router Class Initialized
INFO - 2023-07-31 08:49:52 --> Output Class Initialized
INFO - 2023-07-31 08:49:52 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:52 --> Input Class Initialized
INFO - 2023-07-31 08:49:52 --> Language Class Initialized
INFO - 2023-07-31 08:49:52 --> Language Class Initialized
INFO - 2023-07-31 08:49:52 --> Config Class Initialized
INFO - 2023-07-31 08:49:52 --> Loader Class Initialized
INFO - 2023-07-31 08:49:52 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:52 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:52 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:52 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:52 --> Controller Class Initialized
INFO - 2023-07-31 08:49:52 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:52 --> Total execution time: 0.0498
INFO - 2023-07-31 08:49:56 --> Config Class Initialized
INFO - 2023-07-31 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:56 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:56 --> URI Class Initialized
INFO - 2023-07-31 08:49:56 --> Router Class Initialized
INFO - 2023-07-31 08:49:56 --> Output Class Initialized
INFO - 2023-07-31 08:49:56 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:56 --> Input Class Initialized
INFO - 2023-07-31 08:49:56 --> Language Class Initialized
INFO - 2023-07-31 08:49:56 --> Language Class Initialized
INFO - 2023-07-31 08:49:56 --> Config Class Initialized
INFO - 2023-07-31 08:49:56 --> Loader Class Initialized
INFO - 2023-07-31 08:49:56 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:56 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:56 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:56 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:56 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:56 --> Controller Class Initialized
INFO - 2023-07-31 08:49:57 --> Config Class Initialized
INFO - 2023-07-31 08:49:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:49:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:49:57 --> Utf8 Class Initialized
INFO - 2023-07-31 08:49:57 --> URI Class Initialized
INFO - 2023-07-31 08:49:57 --> Router Class Initialized
INFO - 2023-07-31 08:49:57 --> Output Class Initialized
INFO - 2023-07-31 08:49:57 --> Security Class Initialized
DEBUG - 2023-07-31 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:49:57 --> Input Class Initialized
INFO - 2023-07-31 08:49:57 --> Language Class Initialized
INFO - 2023-07-31 08:49:57 --> Language Class Initialized
INFO - 2023-07-31 08:49:57 --> Config Class Initialized
INFO - 2023-07-31 08:49:57 --> Loader Class Initialized
INFO - 2023-07-31 08:49:57 --> Helper loaded: url_helper
INFO - 2023-07-31 08:49:57 --> Helper loaded: file_helper
INFO - 2023-07-31 08:49:57 --> Helper loaded: form_helper
INFO - 2023-07-31 08:49:57 --> Helper loaded: my_helper
INFO - 2023-07-31 08:49:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:49:57 --> Controller Class Initialized
DEBUG - 2023-07-31 08:49:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/form.php
DEBUG - 2023-07-31 08:49:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:49:57 --> Final output sent to browser
DEBUG - 2023-07-31 08:49:57 --> Total execution time: 0.0507
INFO - 2023-07-31 08:50:01 --> Config Class Initialized
INFO - 2023-07-31 08:50:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:50:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:50:01 --> Utf8 Class Initialized
INFO - 2023-07-31 08:50:01 --> URI Class Initialized
INFO - 2023-07-31 08:50:01 --> Router Class Initialized
INFO - 2023-07-31 08:50:01 --> Output Class Initialized
INFO - 2023-07-31 08:50:01 --> Security Class Initialized
DEBUG - 2023-07-31 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:50:01 --> Input Class Initialized
INFO - 2023-07-31 08:50:01 --> Language Class Initialized
INFO - 2023-07-31 08:50:01 --> Language Class Initialized
INFO - 2023-07-31 08:50:01 --> Config Class Initialized
INFO - 2023-07-31 08:50:01 --> Loader Class Initialized
INFO - 2023-07-31 08:50:01 --> Helper loaded: url_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: file_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: form_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: my_helper
INFO - 2023-07-31 08:50:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:50:01 --> Controller Class Initialized
INFO - 2023-07-31 08:50:01 --> Config Class Initialized
INFO - 2023-07-31 08:50:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:50:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:50:01 --> Utf8 Class Initialized
INFO - 2023-07-31 08:50:01 --> URI Class Initialized
INFO - 2023-07-31 08:50:01 --> Router Class Initialized
INFO - 2023-07-31 08:50:01 --> Output Class Initialized
INFO - 2023-07-31 08:50:01 --> Security Class Initialized
DEBUG - 2023-07-31 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:50:01 --> Input Class Initialized
INFO - 2023-07-31 08:50:01 --> Language Class Initialized
INFO - 2023-07-31 08:50:01 --> Language Class Initialized
INFO - 2023-07-31 08:50:01 --> Config Class Initialized
INFO - 2023-07-31 08:50:01 --> Loader Class Initialized
INFO - 2023-07-31 08:50:01 --> Helper loaded: url_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: file_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: form_helper
INFO - 2023-07-31 08:50:01 --> Helper loaded: my_helper
INFO - 2023-07-31 08:50:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:50:01 --> Controller Class Initialized
DEBUG - 2023-07-31 08:50:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-31 08:50:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:50:01 --> Final output sent to browser
DEBUG - 2023-07-31 08:50:01 --> Total execution time: 0.0250
INFO - 2023-07-31 08:50:03 --> Config Class Initialized
INFO - 2023-07-31 08:50:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:50:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:50:03 --> Utf8 Class Initialized
INFO - 2023-07-31 08:50:03 --> URI Class Initialized
INFO - 2023-07-31 08:50:03 --> Router Class Initialized
INFO - 2023-07-31 08:50:03 --> Output Class Initialized
INFO - 2023-07-31 08:50:03 --> Security Class Initialized
DEBUG - 2023-07-31 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:50:03 --> Input Class Initialized
INFO - 2023-07-31 08:50:03 --> Language Class Initialized
INFO - 2023-07-31 08:50:03 --> Language Class Initialized
INFO - 2023-07-31 08:50:03 --> Config Class Initialized
INFO - 2023-07-31 08:50:03 --> Loader Class Initialized
INFO - 2023-07-31 08:50:03 --> Helper loaded: url_helper
INFO - 2023-07-31 08:50:03 --> Helper loaded: file_helper
INFO - 2023-07-31 08:50:03 --> Helper loaded: form_helper
INFO - 2023-07-31 08:50:03 --> Helper loaded: my_helper
INFO - 2023-07-31 08:50:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:50:03 --> Controller Class Initialized
INFO - 2023-07-31 08:50:03 --> Final output sent to browser
DEBUG - 2023-07-31 08:50:03 --> Total execution time: 0.0262
INFO - 2023-07-31 08:50:47 --> Config Class Initialized
INFO - 2023-07-31 08:50:47 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:50:47 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:50:47 --> Utf8 Class Initialized
INFO - 2023-07-31 08:50:47 --> URI Class Initialized
INFO - 2023-07-31 08:50:47 --> Router Class Initialized
INFO - 2023-07-31 08:50:47 --> Output Class Initialized
INFO - 2023-07-31 08:50:47 --> Security Class Initialized
DEBUG - 2023-07-31 08:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:50:47 --> Input Class Initialized
INFO - 2023-07-31 08:50:47 --> Language Class Initialized
INFO - 2023-07-31 08:50:47 --> Language Class Initialized
INFO - 2023-07-31 08:50:47 --> Config Class Initialized
INFO - 2023-07-31 08:50:47 --> Loader Class Initialized
INFO - 2023-07-31 08:50:47 --> Helper loaded: url_helper
INFO - 2023-07-31 08:50:47 --> Helper loaded: file_helper
INFO - 2023-07-31 08:50:47 --> Helper loaded: form_helper
INFO - 2023-07-31 08:50:47 --> Helper loaded: my_helper
INFO - 2023-07-31 08:50:47 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:50:47 --> Controller Class Initialized
INFO - 2023-07-31 08:50:47 --> Final output sent to browser
DEBUG - 2023-07-31 08:50:47 --> Total execution time: 0.0490
INFO - 2023-07-31 08:53:35 --> Config Class Initialized
INFO - 2023-07-31 08:53:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:35 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:35 --> URI Class Initialized
INFO - 2023-07-31 08:53:35 --> Router Class Initialized
INFO - 2023-07-31 08:53:35 --> Output Class Initialized
INFO - 2023-07-31 08:53:35 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:35 --> Input Class Initialized
INFO - 2023-07-31 08:53:35 --> Language Class Initialized
INFO - 2023-07-31 08:53:35 --> Language Class Initialized
INFO - 2023-07-31 08:53:35 --> Config Class Initialized
INFO - 2023-07-31 08:53:35 --> Loader Class Initialized
INFO - 2023-07-31 08:53:35 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:35 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:35 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:35 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:35 --> Controller Class Initialized
DEBUG - 2023-07-31 08:53:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:53:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:53:35 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:35 --> Total execution time: 0.0312
INFO - 2023-07-31 08:53:38 --> Config Class Initialized
INFO - 2023-07-31 08:53:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:38 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:38 --> URI Class Initialized
INFO - 2023-07-31 08:53:38 --> Router Class Initialized
INFO - 2023-07-31 08:53:38 --> Output Class Initialized
INFO - 2023-07-31 08:53:38 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:38 --> Input Class Initialized
INFO - 2023-07-31 08:53:38 --> Language Class Initialized
INFO - 2023-07-31 08:53:38 --> Language Class Initialized
INFO - 2023-07-31 08:53:38 --> Config Class Initialized
INFO - 2023-07-31 08:53:38 --> Loader Class Initialized
INFO - 2023-07-31 08:53:38 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:38 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:38 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:38 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:38 --> Controller Class Initialized
DEBUG - 2023-07-31 08:53:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-07-31 08:53:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:53:38 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:38 --> Total execution time: 0.0280
INFO - 2023-07-31 08:53:40 --> Config Class Initialized
INFO - 2023-07-31 08:53:40 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:40 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:40 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:40 --> URI Class Initialized
INFO - 2023-07-31 08:53:40 --> Router Class Initialized
INFO - 2023-07-31 08:53:40 --> Output Class Initialized
INFO - 2023-07-31 08:53:40 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:40 --> Input Class Initialized
INFO - 2023-07-31 08:53:40 --> Language Class Initialized
INFO - 2023-07-31 08:53:40 --> Language Class Initialized
INFO - 2023-07-31 08:53:40 --> Config Class Initialized
INFO - 2023-07-31 08:53:40 --> Loader Class Initialized
INFO - 2023-07-31 08:53:40 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:40 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:40 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:40 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:40 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:40 --> Controller Class Initialized
INFO - 2023-07-31 08:53:40 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:40 --> Total execution time: 0.0269
INFO - 2023-07-31 08:53:42 --> Config Class Initialized
INFO - 2023-07-31 08:53:42 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:42 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:42 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:42 --> URI Class Initialized
INFO - 2023-07-31 08:53:42 --> Router Class Initialized
INFO - 2023-07-31 08:53:42 --> Output Class Initialized
INFO - 2023-07-31 08:53:42 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:42 --> Input Class Initialized
INFO - 2023-07-31 08:53:42 --> Language Class Initialized
INFO - 2023-07-31 08:53:42 --> Language Class Initialized
INFO - 2023-07-31 08:53:42 --> Config Class Initialized
INFO - 2023-07-31 08:53:42 --> Loader Class Initialized
INFO - 2023-07-31 08:53:42 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:42 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:42 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:42 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:42 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:42 --> Controller Class Initialized
DEBUG - 2023-07-31 08:53:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-31 08:53:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:53:42 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:42 --> Total execution time: 0.0277
INFO - 2023-07-31 08:53:48 --> Config Class Initialized
INFO - 2023-07-31 08:53:48 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:48 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:48 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:48 --> URI Class Initialized
INFO - 2023-07-31 08:53:48 --> Router Class Initialized
INFO - 2023-07-31 08:53:48 --> Output Class Initialized
INFO - 2023-07-31 08:53:48 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:48 --> Input Class Initialized
INFO - 2023-07-31 08:53:48 --> Language Class Initialized
INFO - 2023-07-31 08:53:48 --> Language Class Initialized
INFO - 2023-07-31 08:53:48 --> Config Class Initialized
INFO - 2023-07-31 08:53:48 --> Loader Class Initialized
INFO - 2023-07-31 08:53:48 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:48 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:48 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:48 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:48 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:48 --> Controller Class Initialized
DEBUG - 2023-07-31 08:53:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-07-31 08:53:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:53:48 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:48 --> Total execution time: 0.0313
INFO - 2023-07-31 08:53:49 --> Config Class Initialized
INFO - 2023-07-31 08:53:49 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:53:49 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:53:49 --> Utf8 Class Initialized
INFO - 2023-07-31 08:53:49 --> URI Class Initialized
DEBUG - 2023-07-31 08:53:49 --> No URI present. Default controller set.
INFO - 2023-07-31 08:53:49 --> Router Class Initialized
INFO - 2023-07-31 08:53:49 --> Output Class Initialized
INFO - 2023-07-31 08:53:49 --> Security Class Initialized
DEBUG - 2023-07-31 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:53:49 --> Input Class Initialized
INFO - 2023-07-31 08:53:49 --> Language Class Initialized
INFO - 2023-07-31 08:53:49 --> Language Class Initialized
INFO - 2023-07-31 08:53:49 --> Config Class Initialized
INFO - 2023-07-31 08:53:49 --> Loader Class Initialized
INFO - 2023-07-31 08:53:49 --> Helper loaded: url_helper
INFO - 2023-07-31 08:53:49 --> Helper loaded: file_helper
INFO - 2023-07-31 08:53:49 --> Helper loaded: form_helper
INFO - 2023-07-31 08:53:49 --> Helper loaded: my_helper
INFO - 2023-07-31 08:53:49 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:53:49 --> Controller Class Initialized
DEBUG - 2023-07-31 08:53:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-31 08:53:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:53:49 --> Final output sent to browser
DEBUG - 2023-07-31 08:53:49 --> Total execution time: 0.0463
INFO - 2023-07-31 08:56:03 --> Config Class Initialized
INFO - 2023-07-31 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:03 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:03 --> URI Class Initialized
INFO - 2023-07-31 08:56:03 --> Router Class Initialized
INFO - 2023-07-31 08:56:03 --> Output Class Initialized
INFO - 2023-07-31 08:56:03 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:03 --> Input Class Initialized
INFO - 2023-07-31 08:56:03 --> Language Class Initialized
INFO - 2023-07-31 08:56:03 --> Language Class Initialized
INFO - 2023-07-31 08:56:03 --> Config Class Initialized
INFO - 2023-07-31 08:56:03 --> Loader Class Initialized
INFO - 2023-07-31 08:56:03 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:03 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:03 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:03 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:03 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-07-31 08:56:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:03 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:03 --> Total execution time: 0.0484
INFO - 2023-07-31 08:56:05 --> Config Class Initialized
INFO - 2023-07-31 08:56:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:05 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:05 --> URI Class Initialized
DEBUG - 2023-07-31 08:56:05 --> No URI present. Default controller set.
INFO - 2023-07-31 08:56:05 --> Router Class Initialized
INFO - 2023-07-31 08:56:05 --> Output Class Initialized
INFO - 2023-07-31 08:56:05 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:05 --> Input Class Initialized
INFO - 2023-07-31 08:56:05 --> Language Class Initialized
INFO - 2023-07-31 08:56:05 --> Language Class Initialized
INFO - 2023-07-31 08:56:05 --> Config Class Initialized
INFO - 2023-07-31 08:56:05 --> Loader Class Initialized
INFO - 2023-07-31 08:56:05 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:05 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:05 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:05 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:05 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-31 08:56:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:05 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:05 --> Total execution time: 0.0281
INFO - 2023-07-31 08:56:09 --> Config Class Initialized
INFO - 2023-07-31 08:56:09 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:09 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:09 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:09 --> URI Class Initialized
INFO - 2023-07-31 08:56:09 --> Router Class Initialized
INFO - 2023-07-31 08:56:09 --> Output Class Initialized
INFO - 2023-07-31 08:56:09 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:09 --> Input Class Initialized
INFO - 2023-07-31 08:56:09 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Config Class Initialized
INFO - 2023-07-31 08:56:10 --> Loader Class Initialized
INFO - 2023-07-31 08:56:10 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:10 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:10 --> Controller Class Initialized
INFO - 2023-07-31 08:56:10 --> Helper loaded: cookie_helper
INFO - 2023-07-31 08:56:10 --> Config Class Initialized
INFO - 2023-07-31 08:56:10 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:10 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:10 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:10 --> URI Class Initialized
INFO - 2023-07-31 08:56:10 --> Router Class Initialized
INFO - 2023-07-31 08:56:10 --> Output Class Initialized
INFO - 2023-07-31 08:56:10 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:10 --> Input Class Initialized
INFO - 2023-07-31 08:56:10 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Config Class Initialized
INFO - 2023-07-31 08:56:10 --> Loader Class Initialized
INFO - 2023-07-31 08:56:10 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:10 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:10 --> Controller Class Initialized
INFO - 2023-07-31 08:56:10 --> Config Class Initialized
INFO - 2023-07-31 08:56:10 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:10 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:10 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:10 --> URI Class Initialized
INFO - 2023-07-31 08:56:10 --> Router Class Initialized
INFO - 2023-07-31 08:56:10 --> Output Class Initialized
INFO - 2023-07-31 08:56:10 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:10 --> Input Class Initialized
INFO - 2023-07-31 08:56:10 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Language Class Initialized
INFO - 2023-07-31 08:56:10 --> Config Class Initialized
INFO - 2023-07-31 08:56:10 --> Loader Class Initialized
INFO - 2023-07-31 08:56:10 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:10 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:10 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:10 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-31 08:56:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:10 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:10 --> Total execution time: 0.0237
INFO - 2023-07-31 08:56:17 --> Config Class Initialized
INFO - 2023-07-31 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:17 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:17 --> URI Class Initialized
INFO - 2023-07-31 08:56:17 --> Router Class Initialized
INFO - 2023-07-31 08:56:17 --> Output Class Initialized
INFO - 2023-07-31 08:56:17 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:17 --> Input Class Initialized
INFO - 2023-07-31 08:56:17 --> Language Class Initialized
INFO - 2023-07-31 08:56:17 --> Language Class Initialized
INFO - 2023-07-31 08:56:17 --> Config Class Initialized
INFO - 2023-07-31 08:56:17 --> Loader Class Initialized
INFO - 2023-07-31 08:56:17 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:17 --> Controller Class Initialized
INFO - 2023-07-31 08:56:17 --> Helper loaded: cookie_helper
INFO - 2023-07-31 08:56:17 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:17 --> Total execution time: 0.0273
INFO - 2023-07-31 08:56:17 --> Config Class Initialized
INFO - 2023-07-31 08:56:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:17 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:17 --> URI Class Initialized
INFO - 2023-07-31 08:56:17 --> Router Class Initialized
INFO - 2023-07-31 08:56:17 --> Output Class Initialized
INFO - 2023-07-31 08:56:17 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:17 --> Input Class Initialized
INFO - 2023-07-31 08:56:17 --> Language Class Initialized
INFO - 2023-07-31 08:56:17 --> Language Class Initialized
INFO - 2023-07-31 08:56:17 --> Config Class Initialized
INFO - 2023-07-31 08:56:17 --> Loader Class Initialized
INFO - 2023-07-31 08:56:17 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:17 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:17 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-31 08:56:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:17 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:17 --> Total execution time: 0.0680
INFO - 2023-07-31 08:56:20 --> Config Class Initialized
INFO - 2023-07-31 08:56:20 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:20 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:20 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:20 --> URI Class Initialized
INFO - 2023-07-31 08:56:20 --> Router Class Initialized
INFO - 2023-07-31 08:56:20 --> Output Class Initialized
INFO - 2023-07-31 08:56:20 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:20 --> Input Class Initialized
INFO - 2023-07-31 08:56:20 --> Language Class Initialized
INFO - 2023-07-31 08:56:20 --> Language Class Initialized
INFO - 2023-07-31 08:56:20 --> Config Class Initialized
INFO - 2023-07-31 08:56:20 --> Loader Class Initialized
INFO - 2023-07-31 08:56:20 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:20 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:20 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 08:56:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:20 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:20 --> Total execution time: 0.0945
INFO - 2023-07-31 08:56:20 --> Config Class Initialized
INFO - 2023-07-31 08:56:20 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:20 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:20 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:20 --> URI Class Initialized
INFO - 2023-07-31 08:56:20 --> Router Class Initialized
INFO - 2023-07-31 08:56:20 --> Output Class Initialized
INFO - 2023-07-31 08:56:20 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:20 --> Input Class Initialized
INFO - 2023-07-31 08:56:20 --> Language Class Initialized
INFO - 2023-07-31 08:56:20 --> Language Class Initialized
INFO - 2023-07-31 08:56:20 --> Config Class Initialized
INFO - 2023-07-31 08:56:20 --> Loader Class Initialized
INFO - 2023-07-31 08:56:20 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:20 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:20 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:20 --> Controller Class Initialized
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:24 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:24 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:24 --> URI Class Initialized
INFO - 2023-07-31 08:56:24 --> Router Class Initialized
INFO - 2023-07-31 08:56:24 --> Output Class Initialized
INFO - 2023-07-31 08:56:24 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:24 --> Input Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Loader Class Initialized
INFO - 2023-07-31 08:56:24 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:24 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:24 --> Controller Class Initialized
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:24 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:24 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:24 --> URI Class Initialized
INFO - 2023-07-31 08:56:24 --> Router Class Initialized
INFO - 2023-07-31 08:56:24 --> Output Class Initialized
INFO - 2023-07-31 08:56:24 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:24 --> Input Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Loader Class Initialized
INFO - 2023-07-31 08:56:24 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:24 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:24 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 08:56:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:24 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:24 --> Total execution time: 0.0318
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:24 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:24 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:24 --> URI Class Initialized
INFO - 2023-07-31 08:56:24 --> Router Class Initialized
INFO - 2023-07-31 08:56:24 --> Output Class Initialized
INFO - 2023-07-31 08:56:24 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:24 --> Input Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Language Class Initialized
INFO - 2023-07-31 08:56:24 --> Config Class Initialized
INFO - 2023-07-31 08:56:24 --> Loader Class Initialized
INFO - 2023-07-31 08:56:24 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:24 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:24 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:24 --> Controller Class Initialized
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:26 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:26 --> URI Class Initialized
INFO - 2023-07-31 08:56:26 --> Router Class Initialized
INFO - 2023-07-31 08:56:26 --> Output Class Initialized
INFO - 2023-07-31 08:56:26 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:26 --> Input Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Loader Class Initialized
INFO - 2023-07-31 08:56:26 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:26 --> Controller Class Initialized
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:26 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:26 --> URI Class Initialized
INFO - 2023-07-31 08:56:26 --> Router Class Initialized
INFO - 2023-07-31 08:56:26 --> Output Class Initialized
INFO - 2023-07-31 08:56:26 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:26 --> Input Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Loader Class Initialized
INFO - 2023-07-31 08:56:26 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:26 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 08:56:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:26 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:26 --> Total execution time: 0.0493
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:26 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:26 --> URI Class Initialized
INFO - 2023-07-31 08:56:26 --> Router Class Initialized
INFO - 2023-07-31 08:56:26 --> Output Class Initialized
INFO - 2023-07-31 08:56:26 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:26 --> Input Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Language Class Initialized
INFO - 2023-07-31 08:56:26 --> Config Class Initialized
INFO - 2023-07-31 08:56:26 --> Loader Class Initialized
INFO - 2023-07-31 08:56:26 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:26 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:26 --> Controller Class Initialized
INFO - 2023-07-31 08:56:29 --> Config Class Initialized
INFO - 2023-07-31 08:56:29 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:29 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:29 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:29 --> URI Class Initialized
INFO - 2023-07-31 08:56:29 --> Router Class Initialized
INFO - 2023-07-31 08:56:29 --> Output Class Initialized
INFO - 2023-07-31 08:56:29 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:29 --> Input Class Initialized
INFO - 2023-07-31 08:56:29 --> Language Class Initialized
INFO - 2023-07-31 08:56:29 --> Language Class Initialized
INFO - 2023-07-31 08:56:29 --> Config Class Initialized
INFO - 2023-07-31 08:56:29 --> Loader Class Initialized
INFO - 2023-07-31 08:56:29 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:29 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:29 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:29 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:29 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:29 --> Controller Class Initialized
ERROR - 2023-07-31 08:56:30 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 08:56:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 08:56:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:30 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:30 --> Total execution time: 0.1710
INFO - 2023-07-31 08:56:33 --> Config Class Initialized
INFO - 2023-07-31 08:56:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:33 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:33 --> URI Class Initialized
INFO - 2023-07-31 08:56:33 --> Router Class Initialized
INFO - 2023-07-31 08:56:33 --> Output Class Initialized
INFO - 2023-07-31 08:56:33 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:33 --> Input Class Initialized
INFO - 2023-07-31 08:56:33 --> Language Class Initialized
INFO - 2023-07-31 08:56:33 --> Language Class Initialized
INFO - 2023-07-31 08:56:33 --> Config Class Initialized
INFO - 2023-07-31 08:56:33 --> Loader Class Initialized
INFO - 2023-07-31 08:56:33 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:33 --> Controller Class Initialized
DEBUG - 2023-07-31 08:56:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 08:56:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 08:56:33 --> Final output sent to browser
DEBUG - 2023-07-31 08:56:33 --> Total execution time: 0.0262
INFO - 2023-07-31 08:56:33 --> Config Class Initialized
INFO - 2023-07-31 08:56:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 08:56:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 08:56:33 --> Utf8 Class Initialized
INFO - 2023-07-31 08:56:33 --> URI Class Initialized
INFO - 2023-07-31 08:56:33 --> Router Class Initialized
INFO - 2023-07-31 08:56:33 --> Output Class Initialized
INFO - 2023-07-31 08:56:33 --> Security Class Initialized
DEBUG - 2023-07-31 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 08:56:33 --> Input Class Initialized
INFO - 2023-07-31 08:56:33 --> Language Class Initialized
INFO - 2023-07-31 08:56:33 --> Language Class Initialized
INFO - 2023-07-31 08:56:33 --> Config Class Initialized
INFO - 2023-07-31 08:56:33 --> Loader Class Initialized
INFO - 2023-07-31 08:56:33 --> Helper loaded: url_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: file_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: form_helper
INFO - 2023-07-31 08:56:33 --> Helper loaded: my_helper
INFO - 2023-07-31 08:56:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 08:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 08:56:33 --> Controller Class Initialized
INFO - 2023-07-31 09:01:31 --> Config Class Initialized
INFO - 2023-07-31 09:01:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:01:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:01:31 --> Utf8 Class Initialized
INFO - 2023-07-31 09:01:31 --> URI Class Initialized
INFO - 2023-07-31 09:01:31 --> Router Class Initialized
INFO - 2023-07-31 09:01:31 --> Output Class Initialized
INFO - 2023-07-31 09:01:31 --> Security Class Initialized
DEBUG - 2023-07-31 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:01:31 --> Input Class Initialized
INFO - 2023-07-31 09:01:31 --> Language Class Initialized
INFO - 2023-07-31 09:01:31 --> Language Class Initialized
INFO - 2023-07-31 09:01:31 --> Config Class Initialized
INFO - 2023-07-31 09:01:31 --> Loader Class Initialized
INFO - 2023-07-31 09:01:31 --> Helper loaded: url_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: file_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: form_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: my_helper
INFO - 2023-07-31 09:01:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:01:31 --> Controller Class Initialized
DEBUG - 2023-07-31 09:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:01:31 --> Final output sent to browser
DEBUG - 2023-07-31 09:01:31 --> Total execution time: 0.1016
INFO - 2023-07-31 09:01:31 --> Config Class Initialized
INFO - 2023-07-31 09:01:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:01:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:01:31 --> Utf8 Class Initialized
INFO - 2023-07-31 09:01:31 --> URI Class Initialized
INFO - 2023-07-31 09:01:31 --> Router Class Initialized
INFO - 2023-07-31 09:01:31 --> Output Class Initialized
INFO - 2023-07-31 09:01:31 --> Security Class Initialized
DEBUG - 2023-07-31 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:01:31 --> Input Class Initialized
INFO - 2023-07-31 09:01:31 --> Language Class Initialized
INFO - 2023-07-31 09:01:31 --> Language Class Initialized
INFO - 2023-07-31 09:01:31 --> Config Class Initialized
INFO - 2023-07-31 09:01:31 --> Loader Class Initialized
INFO - 2023-07-31 09:01:31 --> Helper loaded: url_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: file_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: form_helper
INFO - 2023-07-31 09:01:31 --> Helper loaded: my_helper
INFO - 2023-07-31 09:01:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:01:31 --> Controller Class Initialized
INFO - 2023-07-31 09:01:32 --> Config Class Initialized
INFO - 2023-07-31 09:01:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:01:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:01:32 --> Utf8 Class Initialized
INFO - 2023-07-31 09:01:32 --> URI Class Initialized
INFO - 2023-07-31 09:01:32 --> Router Class Initialized
INFO - 2023-07-31 09:01:32 --> Output Class Initialized
INFO - 2023-07-31 09:01:32 --> Security Class Initialized
DEBUG - 2023-07-31 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:01:32 --> Input Class Initialized
INFO - 2023-07-31 09:01:32 --> Language Class Initialized
INFO - 2023-07-31 09:01:32 --> Language Class Initialized
INFO - 2023-07-31 09:01:32 --> Config Class Initialized
INFO - 2023-07-31 09:01:32 --> Loader Class Initialized
INFO - 2023-07-31 09:01:32 --> Helper loaded: url_helper
INFO - 2023-07-31 09:01:32 --> Helper loaded: file_helper
INFO - 2023-07-31 09:01:32 --> Helper loaded: form_helper
INFO - 2023-07-31 09:01:32 --> Helper loaded: my_helper
INFO - 2023-07-31 09:01:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:01:32 --> Controller Class Initialized
ERROR - 2023-07-31 09:01:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:01:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:01:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:01:32 --> Final output sent to browser
DEBUG - 2023-07-31 09:01:32 --> Total execution time: 0.0456
INFO - 2023-07-31 09:01:37 --> Config Class Initialized
INFO - 2023-07-31 09:01:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:01:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:01:37 --> Utf8 Class Initialized
INFO - 2023-07-31 09:01:37 --> URI Class Initialized
INFO - 2023-07-31 09:01:37 --> Router Class Initialized
INFO - 2023-07-31 09:01:37 --> Output Class Initialized
INFO - 2023-07-31 09:01:37 --> Security Class Initialized
DEBUG - 2023-07-31 09:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:01:37 --> Input Class Initialized
INFO - 2023-07-31 09:01:37 --> Language Class Initialized
ERROR - 2023-07-31 09:01:37 --> 404 Page Not Found: /index
INFO - 2023-07-31 09:04:26 --> Config Class Initialized
INFO - 2023-07-31 09:04:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:26 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:26 --> URI Class Initialized
INFO - 2023-07-31 09:04:26 --> Router Class Initialized
INFO - 2023-07-31 09:04:26 --> Output Class Initialized
INFO - 2023-07-31 09:04:26 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:26 --> Input Class Initialized
INFO - 2023-07-31 09:04:26 --> Language Class Initialized
INFO - 2023-07-31 09:04:26 --> Language Class Initialized
INFO - 2023-07-31 09:04:26 --> Config Class Initialized
INFO - 2023-07-31 09:04:26 --> Loader Class Initialized
INFO - 2023-07-31 09:04:26 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:26 --> Controller Class Initialized
DEBUG - 2023-07-31 09:04:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:04:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:04:26 --> Final output sent to browser
DEBUG - 2023-07-31 09:04:26 --> Total execution time: 0.0342
INFO - 2023-07-31 09:04:26 --> Config Class Initialized
INFO - 2023-07-31 09:04:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:26 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:26 --> URI Class Initialized
INFO - 2023-07-31 09:04:26 --> Router Class Initialized
INFO - 2023-07-31 09:04:26 --> Output Class Initialized
INFO - 2023-07-31 09:04:26 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:26 --> Input Class Initialized
INFO - 2023-07-31 09:04:26 --> Language Class Initialized
INFO - 2023-07-31 09:04:26 --> Language Class Initialized
INFO - 2023-07-31 09:04:26 --> Config Class Initialized
INFO - 2023-07-31 09:04:26 --> Loader Class Initialized
INFO - 2023-07-31 09:04:26 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:26 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:26 --> Controller Class Initialized
INFO - 2023-07-31 09:04:27 --> Config Class Initialized
INFO - 2023-07-31 09:04:27 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:27 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:27 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:27 --> URI Class Initialized
INFO - 2023-07-31 09:04:27 --> Router Class Initialized
INFO - 2023-07-31 09:04:27 --> Output Class Initialized
INFO - 2023-07-31 09:04:27 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:27 --> Input Class Initialized
INFO - 2023-07-31 09:04:27 --> Language Class Initialized
INFO - 2023-07-31 09:04:27 --> Language Class Initialized
INFO - 2023-07-31 09:04:27 --> Config Class Initialized
INFO - 2023-07-31 09:04:27 --> Loader Class Initialized
INFO - 2023-07-31 09:04:27 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:27 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:27 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:27 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:27 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:27 --> Controller Class Initialized
DEBUG - 2023-07-31 09:04:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:04:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:04:27 --> Final output sent to browser
DEBUG - 2023-07-31 09:04:27 --> Total execution time: 0.0418
INFO - 2023-07-31 09:04:32 --> Config Class Initialized
INFO - 2023-07-31 09:04:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:32 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:32 --> URI Class Initialized
INFO - 2023-07-31 09:04:32 --> Router Class Initialized
INFO - 2023-07-31 09:04:32 --> Output Class Initialized
INFO - 2023-07-31 09:04:32 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:32 --> Input Class Initialized
INFO - 2023-07-31 09:04:32 --> Language Class Initialized
INFO - 2023-07-31 09:04:32 --> Language Class Initialized
INFO - 2023-07-31 09:04:32 --> Config Class Initialized
INFO - 2023-07-31 09:04:32 --> Loader Class Initialized
INFO - 2023-07-31 09:04:32 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:32 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:32 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:32 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:32 --> Controller Class Initialized
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:04:32 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:04:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:04:48 --> Config Class Initialized
INFO - 2023-07-31 09:04:48 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:48 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:48 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:48 --> URI Class Initialized
INFO - 2023-07-31 09:04:48 --> Router Class Initialized
INFO - 2023-07-31 09:04:48 --> Output Class Initialized
INFO - 2023-07-31 09:04:48 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:48 --> Input Class Initialized
INFO - 2023-07-31 09:04:48 --> Language Class Initialized
INFO - 2023-07-31 09:04:48 --> Language Class Initialized
INFO - 2023-07-31 09:04:48 --> Config Class Initialized
INFO - 2023-07-31 09:04:48 --> Loader Class Initialized
INFO - 2023-07-31 09:04:48 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:48 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:48 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:48 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:48 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:48 --> Controller Class Initialized
DEBUG - 2023-07-31 09:04:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:04:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:04:48 --> Final output sent to browser
DEBUG - 2023-07-31 09:04:48 --> Total execution time: 0.0258
INFO - 2023-07-31 09:04:51 --> Config Class Initialized
INFO - 2023-07-31 09:04:51 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:51 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:51 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:51 --> URI Class Initialized
INFO - 2023-07-31 09:04:51 --> Router Class Initialized
INFO - 2023-07-31 09:04:51 --> Output Class Initialized
INFO - 2023-07-31 09:04:51 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:51 --> Input Class Initialized
INFO - 2023-07-31 09:04:51 --> Language Class Initialized
INFO - 2023-07-31 09:04:51 --> Language Class Initialized
INFO - 2023-07-31 09:04:51 --> Config Class Initialized
INFO - 2023-07-31 09:04:51 --> Loader Class Initialized
INFO - 2023-07-31 09:04:51 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:51 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:51 --> Controller Class Initialized
DEBUG - 2023-07-31 09:04:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:04:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:04:51 --> Final output sent to browser
DEBUG - 2023-07-31 09:04:51 --> Total execution time: 0.0267
INFO - 2023-07-31 09:04:51 --> Config Class Initialized
INFO - 2023-07-31 09:04:51 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:51 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:51 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:51 --> URI Class Initialized
INFO - 2023-07-31 09:04:51 --> Router Class Initialized
INFO - 2023-07-31 09:04:51 --> Output Class Initialized
INFO - 2023-07-31 09:04:51 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:51 --> Input Class Initialized
INFO - 2023-07-31 09:04:51 --> Language Class Initialized
INFO - 2023-07-31 09:04:51 --> Language Class Initialized
INFO - 2023-07-31 09:04:51 --> Config Class Initialized
INFO - 2023-07-31 09:04:51 --> Loader Class Initialized
INFO - 2023-07-31 09:04:51 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:51 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:51 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:51 --> Controller Class Initialized
INFO - 2023-07-31 09:04:53 --> Config Class Initialized
INFO - 2023-07-31 09:04:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:04:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:04:53 --> Utf8 Class Initialized
INFO - 2023-07-31 09:04:53 --> URI Class Initialized
INFO - 2023-07-31 09:04:53 --> Router Class Initialized
INFO - 2023-07-31 09:04:53 --> Output Class Initialized
INFO - 2023-07-31 09:04:53 --> Security Class Initialized
DEBUG - 2023-07-31 09:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:04:53 --> Input Class Initialized
INFO - 2023-07-31 09:04:53 --> Language Class Initialized
INFO - 2023-07-31 09:04:53 --> Language Class Initialized
INFO - 2023-07-31 09:04:53 --> Config Class Initialized
INFO - 2023-07-31 09:04:53 --> Loader Class Initialized
INFO - 2023-07-31 09:04:53 --> Helper loaded: url_helper
INFO - 2023-07-31 09:04:53 --> Helper loaded: file_helper
INFO - 2023-07-31 09:04:53 --> Helper loaded: form_helper
INFO - 2023-07-31 09:04:53 --> Helper loaded: my_helper
INFO - 2023-07-31 09:04:53 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:04:53 --> Controller Class Initialized
ERROR - 2023-07-31 09:04:53 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:04:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:04:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:04:53 --> Final output sent to browser
DEBUG - 2023-07-31 09:04:53 --> Total execution time: 0.0299
INFO - 2023-07-31 09:05:05 --> Config Class Initialized
INFO - 2023-07-31 09:05:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:05 --> URI Class Initialized
INFO - 2023-07-31 09:05:05 --> Router Class Initialized
INFO - 2023-07-31 09:05:05 --> Output Class Initialized
INFO - 2023-07-31 09:05:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:05 --> Input Class Initialized
INFO - 2023-07-31 09:05:05 --> Language Class Initialized
INFO - 2023-07-31 09:05:05 --> Language Class Initialized
INFO - 2023-07-31 09:05:05 --> Config Class Initialized
INFO - 2023-07-31 09:05:05 --> Loader Class Initialized
INFO - 2023-07-31 09:05:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:05 --> Controller Class Initialized
DEBUG - 2023-07-31 09:05:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-31 09:05:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:05:05 --> Final output sent to browser
DEBUG - 2023-07-31 09:05:05 --> Total execution time: 0.0800
INFO - 2023-07-31 09:05:06 --> Config Class Initialized
INFO - 2023-07-31 09:05:06 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:06 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:06 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:06 --> URI Class Initialized
INFO - 2023-07-31 09:05:06 --> Router Class Initialized
INFO - 2023-07-31 09:05:06 --> Output Class Initialized
INFO - 2023-07-31 09:05:06 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:06 --> Input Class Initialized
INFO - 2023-07-31 09:05:06 --> Language Class Initialized
INFO - 2023-07-31 09:05:06 --> Language Class Initialized
INFO - 2023-07-31 09:05:06 --> Config Class Initialized
INFO - 2023-07-31 09:05:06 --> Loader Class Initialized
INFO - 2023-07-31 09:05:06 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:06 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:06 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:06 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:06 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:06 --> Controller Class Initialized
DEBUG - 2023-07-31 09:05:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-31 09:05:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:05:06 --> Final output sent to browser
DEBUG - 2023-07-31 09:05:06 --> Total execution time: 0.0498
INFO - 2023-07-31 09:05:07 --> Config Class Initialized
INFO - 2023-07-31 09:05:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:07 --> URI Class Initialized
DEBUG - 2023-07-31 09:05:07 --> No URI present. Default controller set.
INFO - 2023-07-31 09:05:07 --> Router Class Initialized
INFO - 2023-07-31 09:05:07 --> Output Class Initialized
INFO - 2023-07-31 09:05:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:07 --> Input Class Initialized
INFO - 2023-07-31 09:05:07 --> Language Class Initialized
INFO - 2023-07-31 09:05:07 --> Language Class Initialized
INFO - 2023-07-31 09:05:07 --> Config Class Initialized
INFO - 2023-07-31 09:05:07 --> Loader Class Initialized
INFO - 2023-07-31 09:05:07 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:07 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:07 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:07 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:07 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:07 --> Controller Class Initialized
DEBUG - 2023-07-31 09:05:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-31 09:05:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:05:07 --> Final output sent to browser
DEBUG - 2023-07-31 09:05:07 --> Total execution time: 0.0322
INFO - 2023-07-31 09:05:15 --> Config Class Initialized
INFO - 2023-07-31 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:15 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:15 --> URI Class Initialized
INFO - 2023-07-31 09:05:15 --> Router Class Initialized
INFO - 2023-07-31 09:05:15 --> Output Class Initialized
INFO - 2023-07-31 09:05:15 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:15 --> Input Class Initialized
INFO - 2023-07-31 09:05:15 --> Language Class Initialized
INFO - 2023-07-31 09:05:15 --> Language Class Initialized
INFO - 2023-07-31 09:05:15 --> Config Class Initialized
INFO - 2023-07-31 09:05:15 --> Loader Class Initialized
INFO - 2023-07-31 09:05:15 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:15 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:15 --> Controller Class Initialized
DEBUG - 2023-07-31 09:05:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:05:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:05:15 --> Final output sent to browser
DEBUG - 2023-07-31 09:05:15 --> Total execution time: 0.0263
INFO - 2023-07-31 09:05:15 --> Config Class Initialized
INFO - 2023-07-31 09:05:15 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:15 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:15 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:15 --> URI Class Initialized
INFO - 2023-07-31 09:05:15 --> Router Class Initialized
INFO - 2023-07-31 09:05:15 --> Output Class Initialized
INFO - 2023-07-31 09:05:15 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:15 --> Input Class Initialized
INFO - 2023-07-31 09:05:15 --> Language Class Initialized
INFO - 2023-07-31 09:05:15 --> Language Class Initialized
INFO - 2023-07-31 09:05:15 --> Config Class Initialized
INFO - 2023-07-31 09:05:15 --> Loader Class Initialized
INFO - 2023-07-31 09:05:15 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:15 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:15 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:15 --> Controller Class Initialized
INFO - 2023-07-31 09:05:16 --> Config Class Initialized
INFO - 2023-07-31 09:05:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:05:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:05:16 --> Utf8 Class Initialized
INFO - 2023-07-31 09:05:16 --> URI Class Initialized
INFO - 2023-07-31 09:05:16 --> Router Class Initialized
INFO - 2023-07-31 09:05:16 --> Output Class Initialized
INFO - 2023-07-31 09:05:16 --> Security Class Initialized
DEBUG - 2023-07-31 09:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:05:16 --> Input Class Initialized
INFO - 2023-07-31 09:05:16 --> Language Class Initialized
INFO - 2023-07-31 09:05:16 --> Language Class Initialized
INFO - 2023-07-31 09:05:16 --> Config Class Initialized
INFO - 2023-07-31 09:05:16 --> Loader Class Initialized
INFO - 2023-07-31 09:05:16 --> Helper loaded: url_helper
INFO - 2023-07-31 09:05:16 --> Helper loaded: file_helper
INFO - 2023-07-31 09:05:16 --> Helper loaded: form_helper
INFO - 2023-07-31 09:05:16 --> Helper loaded: my_helper
INFO - 2023-07-31 09:05:16 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:05:16 --> Controller Class Initialized
ERROR - 2023-07-31 09:05:16 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:05:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:05:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:05:16 --> Final output sent to browser
DEBUG - 2023-07-31 09:05:16 --> Total execution time: 0.0296
INFO - 2023-07-31 09:09:17 --> Config Class Initialized
INFO - 2023-07-31 09:09:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:17 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:17 --> URI Class Initialized
INFO - 2023-07-31 09:09:17 --> Router Class Initialized
INFO - 2023-07-31 09:09:17 --> Output Class Initialized
INFO - 2023-07-31 09:09:17 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:17 --> Input Class Initialized
INFO - 2023-07-31 09:09:17 --> Language Class Initialized
INFO - 2023-07-31 09:09:17 --> Language Class Initialized
INFO - 2023-07-31 09:09:17 --> Config Class Initialized
INFO - 2023-07-31 09:09:17 --> Loader Class Initialized
INFO - 2023-07-31 09:09:17 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:17 --> Controller Class Initialized
DEBUG - 2023-07-31 09:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:09:17 --> Final output sent to browser
DEBUG - 2023-07-31 09:09:17 --> Total execution time: 0.0596
INFO - 2023-07-31 09:09:17 --> Config Class Initialized
INFO - 2023-07-31 09:09:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:17 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:17 --> URI Class Initialized
INFO - 2023-07-31 09:09:17 --> Router Class Initialized
INFO - 2023-07-31 09:09:17 --> Output Class Initialized
INFO - 2023-07-31 09:09:17 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:17 --> Input Class Initialized
INFO - 2023-07-31 09:09:17 --> Language Class Initialized
INFO - 2023-07-31 09:09:17 --> Language Class Initialized
INFO - 2023-07-31 09:09:17 --> Config Class Initialized
INFO - 2023-07-31 09:09:17 --> Loader Class Initialized
INFO - 2023-07-31 09:09:17 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:17 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:17 --> Controller Class Initialized
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:19 --> URI Class Initialized
INFO - 2023-07-31 09:09:19 --> Router Class Initialized
INFO - 2023-07-31 09:09:19 --> Output Class Initialized
INFO - 2023-07-31 09:09:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:19 --> Input Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Loader Class Initialized
INFO - 2023-07-31 09:09:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:19 --> Controller Class Initialized
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:19 --> URI Class Initialized
INFO - 2023-07-31 09:09:19 --> Router Class Initialized
INFO - 2023-07-31 09:09:19 --> Output Class Initialized
INFO - 2023-07-31 09:09:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:19 --> Input Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Loader Class Initialized
INFO - 2023-07-31 09:09:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:19 --> Controller Class Initialized
DEBUG - 2023-07-31 09:09:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:09:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:09:19 --> Final output sent to browser
DEBUG - 2023-07-31 09:09:19 --> Total execution time: 0.0553
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:19 --> URI Class Initialized
INFO - 2023-07-31 09:09:19 --> Router Class Initialized
INFO - 2023-07-31 09:09:19 --> Output Class Initialized
INFO - 2023-07-31 09:09:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:19 --> Input Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Language Class Initialized
INFO - 2023-07-31 09:09:19 --> Config Class Initialized
INFO - 2023-07-31 09:09:19 --> Loader Class Initialized
INFO - 2023-07-31 09:09:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:19 --> Controller Class Initialized
INFO - 2023-07-31 09:09:22 --> Config Class Initialized
INFO - 2023-07-31 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:22 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:22 --> URI Class Initialized
INFO - 2023-07-31 09:09:22 --> Router Class Initialized
INFO - 2023-07-31 09:09:22 --> Output Class Initialized
INFO - 2023-07-31 09:09:22 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:22 --> Input Class Initialized
INFO - 2023-07-31 09:09:22 --> Language Class Initialized
INFO - 2023-07-31 09:09:22 --> Language Class Initialized
INFO - 2023-07-31 09:09:22 --> Config Class Initialized
INFO - 2023-07-31 09:09:22 --> Loader Class Initialized
INFO - 2023-07-31 09:09:22 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:22 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:22 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:22 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:22 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:22 --> Controller Class Initialized
DEBUG - 2023-07-31 09:09:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:09:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:09:22 --> Final output sent to browser
DEBUG - 2023-07-31 09:09:22 --> Total execution time: 0.0256
INFO - 2023-07-31 09:09:25 --> Config Class Initialized
INFO - 2023-07-31 09:09:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:09:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:09:25 --> Utf8 Class Initialized
INFO - 2023-07-31 09:09:25 --> URI Class Initialized
INFO - 2023-07-31 09:09:25 --> Router Class Initialized
INFO - 2023-07-31 09:09:25 --> Output Class Initialized
INFO - 2023-07-31 09:09:25 --> Security Class Initialized
DEBUG - 2023-07-31 09:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:09:25 --> Input Class Initialized
INFO - 2023-07-31 09:09:25 --> Language Class Initialized
INFO - 2023-07-31 09:09:25 --> Language Class Initialized
INFO - 2023-07-31 09:09:25 --> Config Class Initialized
INFO - 2023-07-31 09:09:25 --> Loader Class Initialized
INFO - 2023-07-31 09:09:25 --> Helper loaded: url_helper
INFO - 2023-07-31 09:09:25 --> Helper loaded: file_helper
INFO - 2023-07-31 09:09:25 --> Helper loaded: form_helper
INFO - 2023-07-31 09:09:25 --> Helper loaded: my_helper
INFO - 2023-07-31 09:09:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:09:26 --> Controller Class Initialized
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:09:26 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:09:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:13:40 --> Config Class Initialized
INFO - 2023-07-31 09:13:40 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:40 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:40 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:40 --> URI Class Initialized
INFO - 2023-07-31 09:13:40 --> Router Class Initialized
INFO - 2023-07-31 09:13:40 --> Output Class Initialized
INFO - 2023-07-31 09:13:40 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:40 --> Input Class Initialized
INFO - 2023-07-31 09:13:40 --> Language Class Initialized
INFO - 2023-07-31 09:13:40 --> Language Class Initialized
INFO - 2023-07-31 09:13:40 --> Config Class Initialized
INFO - 2023-07-31 09:13:40 --> Loader Class Initialized
INFO - 2023-07-31 09:13:40 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:40 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:40 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:40 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:40 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:40 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:13:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:40 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:40 --> Total execution time: 0.0734
INFO - 2023-07-31 09:13:45 --> Config Class Initialized
INFO - 2023-07-31 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:45 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:45 --> URI Class Initialized
INFO - 2023-07-31 09:13:45 --> Router Class Initialized
INFO - 2023-07-31 09:13:45 --> Output Class Initialized
INFO - 2023-07-31 09:13:45 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:45 --> Input Class Initialized
INFO - 2023-07-31 09:13:45 --> Language Class Initialized
INFO - 2023-07-31 09:13:45 --> Language Class Initialized
INFO - 2023-07-31 09:13:45 --> Config Class Initialized
INFO - 2023-07-31 09:13:45 --> Loader Class Initialized
INFO - 2023-07-31 09:13:45 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:45 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:45 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:13:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:45 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:45 --> Total execution time: 0.0275
INFO - 2023-07-31 09:13:45 --> Config Class Initialized
INFO - 2023-07-31 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:45 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:45 --> URI Class Initialized
INFO - 2023-07-31 09:13:45 --> Router Class Initialized
INFO - 2023-07-31 09:13:45 --> Output Class Initialized
INFO - 2023-07-31 09:13:45 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:45 --> Input Class Initialized
INFO - 2023-07-31 09:13:45 --> Language Class Initialized
INFO - 2023-07-31 09:13:45 --> Language Class Initialized
INFO - 2023-07-31 09:13:45 --> Config Class Initialized
INFO - 2023-07-31 09:13:45 --> Loader Class Initialized
INFO - 2023-07-31 09:13:45 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:45 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:45 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:45 --> Controller Class Initialized
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:47 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:47 --> URI Class Initialized
INFO - 2023-07-31 09:13:47 --> Router Class Initialized
INFO - 2023-07-31 09:13:47 --> Output Class Initialized
INFO - 2023-07-31 09:13:47 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:47 --> Input Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Loader Class Initialized
INFO - 2023-07-31 09:13:47 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:47 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:47 --> Controller Class Initialized
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:47 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:47 --> URI Class Initialized
INFO - 2023-07-31 09:13:47 --> Router Class Initialized
INFO - 2023-07-31 09:13:47 --> Output Class Initialized
INFO - 2023-07-31 09:13:47 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:47 --> Input Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Loader Class Initialized
INFO - 2023-07-31 09:13:47 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:47 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:47 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:13:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:47 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:47 --> Total execution time: 0.0325
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:47 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:47 --> URI Class Initialized
INFO - 2023-07-31 09:13:47 --> Router Class Initialized
INFO - 2023-07-31 09:13:47 --> Output Class Initialized
INFO - 2023-07-31 09:13:47 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:47 --> Input Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Language Class Initialized
INFO - 2023-07-31 09:13:47 --> Config Class Initialized
INFO - 2023-07-31 09:13:47 --> Loader Class Initialized
INFO - 2023-07-31 09:13:47 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:47 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:47 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:47 --> Controller Class Initialized
INFO - 2023-07-31 09:13:48 --> Config Class Initialized
INFO - 2023-07-31 09:13:48 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:48 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:48 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:48 --> URI Class Initialized
INFO - 2023-07-31 09:13:48 --> Router Class Initialized
INFO - 2023-07-31 09:13:48 --> Output Class Initialized
INFO - 2023-07-31 09:13:48 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:48 --> Input Class Initialized
INFO - 2023-07-31 09:13:48 --> Language Class Initialized
INFO - 2023-07-31 09:13:48 --> Language Class Initialized
INFO - 2023-07-31 09:13:48 --> Config Class Initialized
INFO - 2023-07-31 09:13:48 --> Loader Class Initialized
INFO - 2023-07-31 09:13:48 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:48 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:48 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:48 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:48 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:48 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:13:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:48 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:48 --> Total execution time: 0.0293
INFO - 2023-07-31 09:13:51 --> Config Class Initialized
INFO - 2023-07-31 09:13:51 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:51 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:51 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:51 --> URI Class Initialized
INFO - 2023-07-31 09:13:51 --> Router Class Initialized
INFO - 2023-07-31 09:13:51 --> Output Class Initialized
INFO - 2023-07-31 09:13:51 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:51 --> Input Class Initialized
INFO - 2023-07-31 09:13:51 --> Language Class Initialized
INFO - 2023-07-31 09:13:51 --> Language Class Initialized
INFO - 2023-07-31 09:13:51 --> Config Class Initialized
INFO - 2023-07-31 09:13:51 --> Loader Class Initialized
INFO - 2023-07-31 09:13:51 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:51 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:51 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:51 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:51 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:51 --> Controller Class Initialized
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:13:51 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:13:51 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (45132) at position 4 (2): Unexpected character C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
ERROR - 2023-07-31 09:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-31 09:13:52 --> Config Class Initialized
INFO - 2023-07-31 09:13:52 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:52 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:52 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:52 --> URI Class Initialized
INFO - 2023-07-31 09:13:52 --> Router Class Initialized
INFO - 2023-07-31 09:13:52 --> Output Class Initialized
INFO - 2023-07-31 09:13:52 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:52 --> Input Class Initialized
INFO - 2023-07-31 09:13:52 --> Language Class Initialized
INFO - 2023-07-31 09:13:52 --> Language Class Initialized
INFO - 2023-07-31 09:13:52 --> Config Class Initialized
INFO - 2023-07-31 09:13:52 --> Loader Class Initialized
INFO - 2023-07-31 09:13:52 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:52 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:52 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:52 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:52 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:13:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:52 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:52 --> Total execution time: 0.0274
INFO - 2023-07-31 09:13:54 --> Config Class Initialized
INFO - 2023-07-31 09:13:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:54 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:54 --> URI Class Initialized
INFO - 2023-07-31 09:13:54 --> Router Class Initialized
INFO - 2023-07-31 09:13:54 --> Output Class Initialized
INFO - 2023-07-31 09:13:54 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:54 --> Input Class Initialized
INFO - 2023-07-31 09:13:54 --> Language Class Initialized
INFO - 2023-07-31 09:13:54 --> Language Class Initialized
INFO - 2023-07-31 09:13:54 --> Config Class Initialized
INFO - 2023-07-31 09:13:54 --> Loader Class Initialized
INFO - 2023-07-31 09:13:54 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:54 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:13:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:54 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:54 --> Total execution time: 0.0446
INFO - 2023-07-31 09:13:54 --> Config Class Initialized
INFO - 2023-07-31 09:13:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:54 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:54 --> URI Class Initialized
INFO - 2023-07-31 09:13:54 --> Router Class Initialized
INFO - 2023-07-31 09:13:54 --> Output Class Initialized
INFO - 2023-07-31 09:13:54 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:54 --> Input Class Initialized
INFO - 2023-07-31 09:13:54 --> Language Class Initialized
INFO - 2023-07-31 09:13:54 --> Language Class Initialized
INFO - 2023-07-31 09:13:54 --> Config Class Initialized
INFO - 2023-07-31 09:13:54 --> Loader Class Initialized
INFO - 2023-07-31 09:13:54 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:54 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:54 --> Controller Class Initialized
INFO - 2023-07-31 09:13:56 --> Config Class Initialized
INFO - 2023-07-31 09:13:56 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:56 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:56 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:56 --> URI Class Initialized
INFO - 2023-07-31 09:13:56 --> Router Class Initialized
INFO - 2023-07-31 09:13:56 --> Output Class Initialized
INFO - 2023-07-31 09:13:56 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:56 --> Input Class Initialized
INFO - 2023-07-31 09:13:56 --> Language Class Initialized
INFO - 2023-07-31 09:13:56 --> Language Class Initialized
INFO - 2023-07-31 09:13:56 --> Config Class Initialized
INFO - 2023-07-31 09:13:56 --> Loader Class Initialized
INFO - 2023-07-31 09:13:56 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:56 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:56 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:56 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:56 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:56 --> Controller Class Initialized
DEBUG - 2023-07-31 09:13:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:13:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:13:56 --> Final output sent to browser
DEBUG - 2023-07-31 09:13:56 --> Total execution time: 0.0266
INFO - 2023-07-31 09:13:59 --> Config Class Initialized
INFO - 2023-07-31 09:13:59 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:13:59 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:13:59 --> Utf8 Class Initialized
INFO - 2023-07-31 09:13:59 --> URI Class Initialized
INFO - 2023-07-31 09:13:59 --> Router Class Initialized
INFO - 2023-07-31 09:13:59 --> Output Class Initialized
INFO - 2023-07-31 09:13:59 --> Security Class Initialized
DEBUG - 2023-07-31 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:13:59 --> Input Class Initialized
INFO - 2023-07-31 09:13:59 --> Language Class Initialized
INFO - 2023-07-31 09:13:59 --> Language Class Initialized
INFO - 2023-07-31 09:13:59 --> Config Class Initialized
INFO - 2023-07-31 09:13:59 --> Loader Class Initialized
INFO - 2023-07-31 09:13:59 --> Helper loaded: url_helper
INFO - 2023-07-31 09:13:59 --> Helper loaded: file_helper
INFO - 2023-07-31 09:13:59 --> Helper loaded: form_helper
INFO - 2023-07-31 09:13:59 --> Helper loaded: my_helper
INFO - 2023-07-31 09:13:59 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:13:59 --> Controller Class Initialized
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:13:59 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:13:59 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (45132) at position 4 (2): Unexpected character C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
ERROR - 2023-07-31 09:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-31 09:16:39 --> Config Class Initialized
INFO - 2023-07-31 09:16:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:39 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:39 --> URI Class Initialized
INFO - 2023-07-31 09:16:39 --> Router Class Initialized
INFO - 2023-07-31 09:16:39 --> Output Class Initialized
INFO - 2023-07-31 09:16:39 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:39 --> Input Class Initialized
INFO - 2023-07-31 09:16:39 --> Language Class Initialized
INFO - 2023-07-31 09:16:39 --> Language Class Initialized
INFO - 2023-07-31 09:16:39 --> Config Class Initialized
INFO - 2023-07-31 09:16:39 --> Loader Class Initialized
INFO - 2023-07-31 09:16:39 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:39 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:39 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:39 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:39 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:16:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:39 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:39 --> Total execution time: 0.0478
INFO - 2023-07-31 09:16:41 --> Config Class Initialized
INFO - 2023-07-31 09:16:41 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:41 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:41 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:41 --> URI Class Initialized
INFO - 2023-07-31 09:16:41 --> Router Class Initialized
INFO - 2023-07-31 09:16:41 --> Output Class Initialized
INFO - 2023-07-31 09:16:41 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:41 --> Input Class Initialized
INFO - 2023-07-31 09:16:41 --> Language Class Initialized
INFO - 2023-07-31 09:16:41 --> Language Class Initialized
INFO - 2023-07-31 09:16:41 --> Config Class Initialized
INFO - 2023-07-31 09:16:41 --> Loader Class Initialized
INFO - 2023-07-31 09:16:41 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:41 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:41 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:16:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:41 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:41 --> Total execution time: 0.0262
INFO - 2023-07-31 09:16:41 --> Config Class Initialized
INFO - 2023-07-31 09:16:41 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:41 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:41 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:41 --> URI Class Initialized
INFO - 2023-07-31 09:16:41 --> Router Class Initialized
INFO - 2023-07-31 09:16:41 --> Output Class Initialized
INFO - 2023-07-31 09:16:41 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:41 --> Input Class Initialized
INFO - 2023-07-31 09:16:41 --> Language Class Initialized
INFO - 2023-07-31 09:16:41 --> Language Class Initialized
INFO - 2023-07-31 09:16:41 --> Config Class Initialized
INFO - 2023-07-31 09:16:41 --> Loader Class Initialized
INFO - 2023-07-31 09:16:41 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:41 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:41 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:41 --> Controller Class Initialized
INFO - 2023-07-31 09:16:42 --> Config Class Initialized
INFO - 2023-07-31 09:16:42 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:42 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:42 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:42 --> URI Class Initialized
INFO - 2023-07-31 09:16:42 --> Router Class Initialized
INFO - 2023-07-31 09:16:42 --> Output Class Initialized
INFO - 2023-07-31 09:16:42 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:42 --> Input Class Initialized
INFO - 2023-07-31 09:16:42 --> Language Class Initialized
INFO - 2023-07-31 09:16:42 --> Language Class Initialized
INFO - 2023-07-31 09:16:42 --> Config Class Initialized
INFO - 2023-07-31 09:16:42 --> Loader Class Initialized
INFO - 2023-07-31 09:16:42 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:42 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:42 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:16:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:42 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:42 --> Total execution time: 0.0260
INFO - 2023-07-31 09:16:42 --> Config Class Initialized
INFO - 2023-07-31 09:16:42 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:42 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:42 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:42 --> URI Class Initialized
INFO - 2023-07-31 09:16:42 --> Router Class Initialized
INFO - 2023-07-31 09:16:42 --> Output Class Initialized
INFO - 2023-07-31 09:16:42 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:42 --> Input Class Initialized
INFO - 2023-07-31 09:16:42 --> Language Class Initialized
INFO - 2023-07-31 09:16:42 --> Language Class Initialized
INFO - 2023-07-31 09:16:42 --> Config Class Initialized
INFO - 2023-07-31 09:16:42 --> Loader Class Initialized
INFO - 2023-07-31 09:16:42 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:42 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:42 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:42 --> Controller Class Initialized
INFO - 2023-07-31 09:16:43 --> Config Class Initialized
INFO - 2023-07-31 09:16:43 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:43 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:43 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:43 --> URI Class Initialized
INFO - 2023-07-31 09:16:43 --> Router Class Initialized
INFO - 2023-07-31 09:16:43 --> Output Class Initialized
INFO - 2023-07-31 09:16:43 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:43 --> Input Class Initialized
INFO - 2023-07-31 09:16:43 --> Language Class Initialized
INFO - 2023-07-31 09:16:43 --> Language Class Initialized
INFO - 2023-07-31 09:16:43 --> Config Class Initialized
INFO - 2023-07-31 09:16:43 --> Loader Class Initialized
INFO - 2023-07-31 09:16:43 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:43 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:43 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:43 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:43 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:43 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:16:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:43 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:43 --> Total execution time: 0.0248
INFO - 2023-07-31 09:16:46 --> Config Class Initialized
INFO - 2023-07-31 09:16:46 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:46 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:46 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:46 --> URI Class Initialized
INFO - 2023-07-31 09:16:46 --> Router Class Initialized
INFO - 2023-07-31 09:16:46 --> Output Class Initialized
INFO - 2023-07-31 09:16:46 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:46 --> Input Class Initialized
INFO - 2023-07-31 09:16:46 --> Language Class Initialized
INFO - 2023-07-31 09:16:46 --> Language Class Initialized
INFO - 2023-07-31 09:16:46 --> Config Class Initialized
INFO - 2023-07-31 09:16:46 --> Loader Class Initialized
INFO - 2023-07-31 09:16:46 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:46 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:46 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:46 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:46 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:46 --> Controller Class Initialized
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:16:46 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:16:46 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (45132) at position 4 (2): Unexpected character C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 238
ERROR - 2023-07-31 09:16:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-31 09:16:52 --> Config Class Initialized
INFO - 2023-07-31 09:16:52 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:52 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:52 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:52 --> URI Class Initialized
INFO - 2023-07-31 09:16:52 --> Router Class Initialized
INFO - 2023-07-31 09:16:52 --> Output Class Initialized
INFO - 2023-07-31 09:16:52 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:52 --> Input Class Initialized
INFO - 2023-07-31 09:16:52 --> Language Class Initialized
INFO - 2023-07-31 09:16:52 --> Language Class Initialized
INFO - 2023-07-31 09:16:52 --> Config Class Initialized
INFO - 2023-07-31 09:16:52 --> Loader Class Initialized
INFO - 2023-07-31 09:16:52 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:52 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:52 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:52 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:52 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:16:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:52 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:52 --> Total execution time: 0.0247
INFO - 2023-07-31 09:16:53 --> Config Class Initialized
INFO - 2023-07-31 09:16:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:53 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:53 --> URI Class Initialized
INFO - 2023-07-31 09:16:53 --> Router Class Initialized
INFO - 2023-07-31 09:16:53 --> Output Class Initialized
INFO - 2023-07-31 09:16:53 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:53 --> Input Class Initialized
INFO - 2023-07-31 09:16:53 --> Language Class Initialized
INFO - 2023-07-31 09:16:53 --> Language Class Initialized
INFO - 2023-07-31 09:16:53 --> Config Class Initialized
INFO - 2023-07-31 09:16:53 --> Loader Class Initialized
INFO - 2023-07-31 09:16:53 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:53 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:53 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:16:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:53 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:53 --> Total execution time: 0.0245
INFO - 2023-07-31 09:16:53 --> Config Class Initialized
INFO - 2023-07-31 09:16:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:53 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:53 --> URI Class Initialized
INFO - 2023-07-31 09:16:53 --> Router Class Initialized
INFO - 2023-07-31 09:16:53 --> Output Class Initialized
INFO - 2023-07-31 09:16:53 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:53 --> Input Class Initialized
INFO - 2023-07-31 09:16:53 --> Language Class Initialized
INFO - 2023-07-31 09:16:53 --> Language Class Initialized
INFO - 2023-07-31 09:16:53 --> Config Class Initialized
INFO - 2023-07-31 09:16:53 --> Loader Class Initialized
INFO - 2023-07-31 09:16:53 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:53 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:53 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:53 --> Controller Class Initialized
INFO - 2023-07-31 09:16:54 --> Config Class Initialized
INFO - 2023-07-31 09:16:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:54 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:54 --> URI Class Initialized
INFO - 2023-07-31 09:16:54 --> Router Class Initialized
INFO - 2023-07-31 09:16:54 --> Output Class Initialized
INFO - 2023-07-31 09:16:54 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:54 --> Input Class Initialized
INFO - 2023-07-31 09:16:54 --> Language Class Initialized
INFO - 2023-07-31 09:16:54 --> Language Class Initialized
INFO - 2023-07-31 09:16:54 --> Config Class Initialized
INFO - 2023-07-31 09:16:54 --> Loader Class Initialized
INFO - 2023-07-31 09:16:54 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:54 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:54 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:54 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:54 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:16:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:54 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:54 --> Total execution time: 0.0233
INFO - 2023-07-31 09:16:55 --> Config Class Initialized
INFO - 2023-07-31 09:16:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:55 --> URI Class Initialized
INFO - 2023-07-31 09:16:55 --> Router Class Initialized
INFO - 2023-07-31 09:16:55 --> Output Class Initialized
INFO - 2023-07-31 09:16:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:55 --> Input Class Initialized
INFO - 2023-07-31 09:16:55 --> Language Class Initialized
INFO - 2023-07-31 09:16:55 --> Language Class Initialized
INFO - 2023-07-31 09:16:55 --> Config Class Initialized
INFO - 2023-07-31 09:16:55 --> Loader Class Initialized
INFO - 2023-07-31 09:16:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:55 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:16:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:55 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:55 --> Total execution time: 0.0237
INFO - 2023-07-31 09:16:55 --> Config Class Initialized
INFO - 2023-07-31 09:16:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:55 --> URI Class Initialized
INFO - 2023-07-31 09:16:55 --> Router Class Initialized
INFO - 2023-07-31 09:16:55 --> Output Class Initialized
INFO - 2023-07-31 09:16:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:55 --> Input Class Initialized
INFO - 2023-07-31 09:16:55 --> Language Class Initialized
INFO - 2023-07-31 09:16:55 --> Language Class Initialized
INFO - 2023-07-31 09:16:55 --> Config Class Initialized
INFO - 2023-07-31 09:16:55 --> Loader Class Initialized
INFO - 2023-07-31 09:16:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:55 --> Controller Class Initialized
INFO - 2023-07-31 09:16:56 --> Config Class Initialized
INFO - 2023-07-31 09:16:56 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:56 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:56 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:56 --> URI Class Initialized
INFO - 2023-07-31 09:16:56 --> Router Class Initialized
INFO - 2023-07-31 09:16:56 --> Output Class Initialized
INFO - 2023-07-31 09:16:56 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:56 --> Input Class Initialized
INFO - 2023-07-31 09:16:56 --> Language Class Initialized
INFO - 2023-07-31 09:16:56 --> Language Class Initialized
INFO - 2023-07-31 09:16:56 --> Config Class Initialized
INFO - 2023-07-31 09:16:56 --> Loader Class Initialized
INFO - 2023-07-31 09:16:56 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:56 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:56 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:56 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:56 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:56 --> Controller Class Initialized
DEBUG - 2023-07-31 09:16:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:16:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:16:56 --> Final output sent to browser
DEBUG - 2023-07-31 09:16:56 --> Total execution time: 0.0516
INFO - 2023-07-31 09:16:57 --> Config Class Initialized
INFO - 2023-07-31 09:16:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:16:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:16:57 --> Utf8 Class Initialized
INFO - 2023-07-31 09:16:57 --> URI Class Initialized
INFO - 2023-07-31 09:16:57 --> Router Class Initialized
INFO - 2023-07-31 09:16:57 --> Output Class Initialized
INFO - 2023-07-31 09:16:57 --> Security Class Initialized
DEBUG - 2023-07-31 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:16:57 --> Input Class Initialized
INFO - 2023-07-31 09:16:57 --> Language Class Initialized
INFO - 2023-07-31 09:16:57 --> Language Class Initialized
INFO - 2023-07-31 09:16:57 --> Config Class Initialized
INFO - 2023-07-31 09:16:57 --> Loader Class Initialized
INFO - 2023-07-31 09:16:57 --> Helper loaded: url_helper
INFO - 2023-07-31 09:16:57 --> Helper loaded: file_helper
INFO - 2023-07-31 09:16:57 --> Helper loaded: form_helper
INFO - 2023-07-31 09:16:57 --> Helper loaded: my_helper
INFO - 2023-07-31 09:16:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:16:57 --> Controller Class Initialized
INFO - 2023-07-31 09:25:59 --> Config Class Initialized
INFO - 2023-07-31 09:25:59 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:25:59 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:25:59 --> Utf8 Class Initialized
INFO - 2023-07-31 09:25:59 --> URI Class Initialized
INFO - 2023-07-31 09:25:59 --> Router Class Initialized
INFO - 2023-07-31 09:25:59 --> Output Class Initialized
INFO - 2023-07-31 09:25:59 --> Security Class Initialized
DEBUG - 2023-07-31 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:25:59 --> Input Class Initialized
INFO - 2023-07-31 09:25:59 --> Language Class Initialized
INFO - 2023-07-31 09:25:59 --> Language Class Initialized
INFO - 2023-07-31 09:25:59 --> Config Class Initialized
INFO - 2023-07-31 09:25:59 --> Loader Class Initialized
INFO - 2023-07-31 09:25:59 --> Helper loaded: url_helper
INFO - 2023-07-31 09:25:59 --> Helper loaded: file_helper
INFO - 2023-07-31 09:25:59 --> Helper loaded: form_helper
INFO - 2023-07-31 09:25:59 --> Helper loaded: my_helper
INFO - 2023-07-31 09:25:59 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:25:59 --> Controller Class Initialized
DEBUG - 2023-07-31 09:25:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:25:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:25:59 --> Final output sent to browser
DEBUG - 2023-07-31 09:25:59 --> Total execution time: 0.0705
INFO - 2023-07-31 09:26:02 --> Config Class Initialized
INFO - 2023-07-31 09:26:02 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:26:02 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:26:02 --> Utf8 Class Initialized
INFO - 2023-07-31 09:26:02 --> URI Class Initialized
INFO - 2023-07-31 09:26:02 --> Router Class Initialized
INFO - 2023-07-31 09:26:02 --> Output Class Initialized
INFO - 2023-07-31 09:26:02 --> Security Class Initialized
DEBUG - 2023-07-31 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:26:02 --> Input Class Initialized
INFO - 2023-07-31 09:26:02 --> Language Class Initialized
INFO - 2023-07-31 09:26:02 --> Language Class Initialized
INFO - 2023-07-31 09:26:02 --> Config Class Initialized
INFO - 2023-07-31 09:26:02 --> Loader Class Initialized
INFO - 2023-07-31 09:26:02 --> Helper loaded: url_helper
INFO - 2023-07-31 09:26:02 --> Helper loaded: file_helper
INFO - 2023-07-31 09:26:02 --> Helper loaded: form_helper
INFO - 2023-07-31 09:26:02 --> Helper loaded: my_helper
INFO - 2023-07-31 09:26:02 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:26:02 --> Controller Class Initialized
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:26:02 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:26:02 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (45132) at position 4 (2): Unexpected character C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 238
ERROR - 2023-07-31 09:26:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Common.php 570
INFO - 2023-07-31 09:34:11 --> Config Class Initialized
INFO - 2023-07-31 09:34:11 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:11 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:11 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:11 --> URI Class Initialized
INFO - 2023-07-31 09:34:11 --> Router Class Initialized
INFO - 2023-07-31 09:34:11 --> Output Class Initialized
INFO - 2023-07-31 09:34:11 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:11 --> Input Class Initialized
INFO - 2023-07-31 09:34:11 --> Language Class Initialized
INFO - 2023-07-31 09:34:11 --> Language Class Initialized
INFO - 2023-07-31 09:34:11 --> Config Class Initialized
INFO - 2023-07-31 09:34:11 --> Loader Class Initialized
INFO - 2023-07-31 09:34:11 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:11 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:11 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:11 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:11 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:11 --> Controller Class Initialized
DEBUG - 2023-07-31 09:34:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:34:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:34:11 --> Final output sent to browser
DEBUG - 2023-07-31 09:34:11 --> Total execution time: 0.0725
INFO - 2023-07-31 09:34:12 --> Config Class Initialized
INFO - 2023-07-31 09:34:12 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:12 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:12 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:12 --> URI Class Initialized
INFO - 2023-07-31 09:34:12 --> Router Class Initialized
INFO - 2023-07-31 09:34:12 --> Output Class Initialized
INFO - 2023-07-31 09:34:12 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:12 --> Input Class Initialized
INFO - 2023-07-31 09:34:12 --> Language Class Initialized
INFO - 2023-07-31 09:34:12 --> Language Class Initialized
INFO - 2023-07-31 09:34:12 --> Config Class Initialized
INFO - 2023-07-31 09:34:12 --> Loader Class Initialized
INFO - 2023-07-31 09:34:12 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:12 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:12 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:12 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:12 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:12 --> Controller Class Initialized
DEBUG - 2023-07-31 09:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:34:12 --> Final output sent to browser
DEBUG - 2023-07-31 09:34:12 --> Total execution time: 0.0421
INFO - 2023-07-31 09:34:16 --> Config Class Initialized
INFO - 2023-07-31 09:34:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:16 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:16 --> URI Class Initialized
INFO - 2023-07-31 09:34:16 --> Router Class Initialized
INFO - 2023-07-31 09:34:16 --> Output Class Initialized
INFO - 2023-07-31 09:34:16 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:16 --> Input Class Initialized
INFO - 2023-07-31 09:34:16 --> Language Class Initialized
INFO - 2023-07-31 09:34:16 --> Language Class Initialized
INFO - 2023-07-31 09:34:16 --> Config Class Initialized
INFO - 2023-07-31 09:34:16 --> Loader Class Initialized
INFO - 2023-07-31 09:34:16 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:16 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:16 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:16 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:16 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:16 --> Controller Class Initialized
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:34:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:34:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:34:23 --> Config Class Initialized
INFO - 2023-07-31 09:34:23 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:23 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:23 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:23 --> URI Class Initialized
INFO - 2023-07-31 09:34:23 --> Router Class Initialized
INFO - 2023-07-31 09:34:23 --> Output Class Initialized
INFO - 2023-07-31 09:34:23 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:23 --> Input Class Initialized
INFO - 2023-07-31 09:34:23 --> Language Class Initialized
INFO - 2023-07-31 09:34:23 --> Language Class Initialized
INFO - 2023-07-31 09:34:23 --> Config Class Initialized
INFO - 2023-07-31 09:34:23 --> Loader Class Initialized
INFO - 2023-07-31 09:34:23 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:23 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:23 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:23 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:23 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:23 --> Controller Class Initialized
DEBUG - 2023-07-31 09:34:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:34:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:34:23 --> Final output sent to browser
DEBUG - 2023-07-31 09:34:23 --> Total execution time: 0.0489
INFO - 2023-07-31 09:34:25 --> Config Class Initialized
INFO - 2023-07-31 09:34:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:25 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:25 --> URI Class Initialized
INFO - 2023-07-31 09:34:25 --> Router Class Initialized
INFO - 2023-07-31 09:34:25 --> Output Class Initialized
INFO - 2023-07-31 09:34:25 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:25 --> Input Class Initialized
INFO - 2023-07-31 09:34:25 --> Language Class Initialized
INFO - 2023-07-31 09:34:25 --> Language Class Initialized
INFO - 2023-07-31 09:34:25 --> Config Class Initialized
INFO - 2023-07-31 09:34:25 --> Loader Class Initialized
INFO - 2023-07-31 09:34:25 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:25 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:25 --> Controller Class Initialized
DEBUG - 2023-07-31 09:34:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:34:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:34:25 --> Final output sent to browser
DEBUG - 2023-07-31 09:34:25 --> Total execution time: 0.0258
INFO - 2023-07-31 09:34:25 --> Config Class Initialized
INFO - 2023-07-31 09:34:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:25 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:25 --> URI Class Initialized
INFO - 2023-07-31 09:34:25 --> Router Class Initialized
INFO - 2023-07-31 09:34:25 --> Output Class Initialized
INFO - 2023-07-31 09:34:25 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:25 --> Input Class Initialized
INFO - 2023-07-31 09:34:25 --> Language Class Initialized
INFO - 2023-07-31 09:34:25 --> Language Class Initialized
INFO - 2023-07-31 09:34:25 --> Config Class Initialized
INFO - 2023-07-31 09:34:25 --> Loader Class Initialized
INFO - 2023-07-31 09:34:25 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:25 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:25 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:25 --> Controller Class Initialized
INFO - 2023-07-31 09:34:26 --> Config Class Initialized
INFO - 2023-07-31 09:34:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:34:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:34:26 --> Utf8 Class Initialized
INFO - 2023-07-31 09:34:26 --> URI Class Initialized
INFO - 2023-07-31 09:34:26 --> Router Class Initialized
INFO - 2023-07-31 09:34:26 --> Output Class Initialized
INFO - 2023-07-31 09:34:26 --> Security Class Initialized
DEBUG - 2023-07-31 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:34:26 --> Input Class Initialized
INFO - 2023-07-31 09:34:26 --> Language Class Initialized
INFO - 2023-07-31 09:34:26 --> Language Class Initialized
INFO - 2023-07-31 09:34:26 --> Config Class Initialized
INFO - 2023-07-31 09:34:27 --> Loader Class Initialized
INFO - 2023-07-31 09:34:27 --> Helper loaded: url_helper
INFO - 2023-07-31 09:34:27 --> Helper loaded: file_helper
INFO - 2023-07-31 09:34:27 --> Helper loaded: form_helper
INFO - 2023-07-31 09:34:27 --> Helper loaded: my_helper
INFO - 2023-07-31 09:34:27 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:34:27 --> Controller Class Initialized
ERROR - 2023-07-31 09:34:27 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:34:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:34:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:34:27 --> Final output sent to browser
DEBUG - 2023-07-31 09:34:27 --> Total execution time: 0.0462
INFO - 2023-07-31 09:35:01 --> Config Class Initialized
INFO - 2023-07-31 09:35:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:01 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:01 --> URI Class Initialized
INFO - 2023-07-31 09:35:01 --> Router Class Initialized
INFO - 2023-07-31 09:35:01 --> Output Class Initialized
INFO - 2023-07-31 09:35:01 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:01 --> Input Class Initialized
INFO - 2023-07-31 09:35:01 --> Language Class Initialized
INFO - 2023-07-31 09:35:01 --> Language Class Initialized
INFO - 2023-07-31 09:35:01 --> Config Class Initialized
INFO - 2023-07-31 09:35:01 --> Loader Class Initialized
INFO - 2023-07-31 09:35:01 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:01 --> Controller Class Initialized
DEBUG - 2023-07-31 09:35:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 09:35:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:35:01 --> Final output sent to browser
DEBUG - 2023-07-31 09:35:01 --> Total execution time: 0.1059
INFO - 2023-07-31 09:35:01 --> Config Class Initialized
INFO - 2023-07-31 09:35:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:01 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:01 --> URI Class Initialized
INFO - 2023-07-31 09:35:01 --> Router Class Initialized
INFO - 2023-07-31 09:35:01 --> Output Class Initialized
INFO - 2023-07-31 09:35:01 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:01 --> Input Class Initialized
INFO - 2023-07-31 09:35:01 --> Language Class Initialized
INFO - 2023-07-31 09:35:01 --> Language Class Initialized
INFO - 2023-07-31 09:35:01 --> Config Class Initialized
INFO - 2023-07-31 09:35:01 --> Loader Class Initialized
INFO - 2023-07-31 09:35:01 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:01 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:01 --> Controller Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:03 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:03 --> URI Class Initialized
INFO - 2023-07-31 09:35:03 --> Router Class Initialized
INFO - 2023-07-31 09:35:03 --> Output Class Initialized
INFO - 2023-07-31 09:35:03 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:03 --> Input Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Loader Class Initialized
INFO - 2023-07-31 09:35:03 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:03 --> Controller Class Initialized
DEBUG - 2023-07-31 09:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 09:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:35:03 --> Final output sent to browser
DEBUG - 2023-07-31 09:35:03 --> Total execution time: 0.0499
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:03 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:03 --> URI Class Initialized
INFO - 2023-07-31 09:35:03 --> Router Class Initialized
INFO - 2023-07-31 09:35:03 --> Output Class Initialized
INFO - 2023-07-31 09:35:03 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:03 --> Input Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Loader Class Initialized
INFO - 2023-07-31 09:35:03 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:03 --> Controller Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:03 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:03 --> URI Class Initialized
INFO - 2023-07-31 09:35:03 --> Router Class Initialized
INFO - 2023-07-31 09:35:03 --> Output Class Initialized
INFO - 2023-07-31 09:35:03 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:03 --> Input Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Loader Class Initialized
INFO - 2023-07-31 09:35:03 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:03 --> Controller Class Initialized
DEBUG - 2023-07-31 09:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:35:03 --> Final output sent to browser
DEBUG - 2023-07-31 09:35:03 --> Total execution time: 0.0241
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:03 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:03 --> URI Class Initialized
INFO - 2023-07-31 09:35:03 --> Router Class Initialized
INFO - 2023-07-31 09:35:03 --> Output Class Initialized
INFO - 2023-07-31 09:35:03 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:03 --> Input Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Language Class Initialized
INFO - 2023-07-31 09:35:03 --> Config Class Initialized
INFO - 2023-07-31 09:35:03 --> Loader Class Initialized
INFO - 2023-07-31 09:35:03 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:03 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:03 --> Controller Class Initialized
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:05 --> URI Class Initialized
INFO - 2023-07-31 09:35:05 --> Router Class Initialized
INFO - 2023-07-31 09:35:05 --> Output Class Initialized
INFO - 2023-07-31 09:35:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:05 --> Input Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Loader Class Initialized
INFO - 2023-07-31 09:35:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:05 --> Controller Class Initialized
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:05 --> URI Class Initialized
INFO - 2023-07-31 09:35:05 --> Router Class Initialized
INFO - 2023-07-31 09:35:05 --> Output Class Initialized
INFO - 2023-07-31 09:35:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:05 --> Input Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Loader Class Initialized
INFO - 2023-07-31 09:35:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:05 --> Controller Class Initialized
DEBUG - 2023-07-31 09:35:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:35:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:35:05 --> Final output sent to browser
DEBUG - 2023-07-31 09:35:05 --> Total execution time: 0.0286
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:35:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:35:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:35:05 --> URI Class Initialized
INFO - 2023-07-31 09:35:05 --> Router Class Initialized
INFO - 2023-07-31 09:35:05 --> Output Class Initialized
INFO - 2023-07-31 09:35:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:35:05 --> Input Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Language Class Initialized
INFO - 2023-07-31 09:35:05 --> Config Class Initialized
INFO - 2023-07-31 09:35:05 --> Loader Class Initialized
INFO - 2023-07-31 09:35:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:35:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:35:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:35:05 --> Controller Class Initialized
INFO - 2023-07-31 09:36:25 --> Config Class Initialized
INFO - 2023-07-31 09:36:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:25 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:25 --> URI Class Initialized
INFO - 2023-07-31 09:36:25 --> Router Class Initialized
INFO - 2023-07-31 09:36:25 --> Output Class Initialized
INFO - 2023-07-31 09:36:25 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:25 --> Input Class Initialized
INFO - 2023-07-31 09:36:25 --> Language Class Initialized
INFO - 2023-07-31 09:36:25 --> Language Class Initialized
INFO - 2023-07-31 09:36:25 --> Config Class Initialized
INFO - 2023-07-31 09:36:25 --> Loader Class Initialized
INFO - 2023-07-31 09:36:25 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:25 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:25 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:25 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:25 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:25 --> Controller Class Initialized
DEBUG - 2023-07-31 09:36:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:36:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:36:25 --> Final output sent to browser
DEBUG - 2023-07-31 09:36:25 --> Total execution time: 0.0516
INFO - 2023-07-31 09:36:28 --> Config Class Initialized
INFO - 2023-07-31 09:36:28 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:28 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:28 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:28 --> URI Class Initialized
INFO - 2023-07-31 09:36:28 --> Router Class Initialized
INFO - 2023-07-31 09:36:28 --> Output Class Initialized
INFO - 2023-07-31 09:36:28 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:28 --> Input Class Initialized
INFO - 2023-07-31 09:36:28 --> Language Class Initialized
INFO - 2023-07-31 09:36:28 --> Language Class Initialized
INFO - 2023-07-31 09:36:28 --> Config Class Initialized
INFO - 2023-07-31 09:36:28 --> Loader Class Initialized
INFO - 2023-07-31 09:36:28 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:28 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:28 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:28 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:28 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:28 --> Controller Class Initialized
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:36:28 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:36:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:36:33 --> Config Class Initialized
INFO - 2023-07-31 09:36:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:33 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:33 --> URI Class Initialized
INFO - 2023-07-31 09:36:33 --> Router Class Initialized
INFO - 2023-07-31 09:36:33 --> Output Class Initialized
INFO - 2023-07-31 09:36:33 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:33 --> Input Class Initialized
INFO - 2023-07-31 09:36:33 --> Language Class Initialized
INFO - 2023-07-31 09:36:33 --> Language Class Initialized
INFO - 2023-07-31 09:36:33 --> Config Class Initialized
INFO - 2023-07-31 09:36:33 --> Loader Class Initialized
INFO - 2023-07-31 09:36:33 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:33 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:33 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:33 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:33 --> Controller Class Initialized
DEBUG - 2023-07-31 09:36:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:36:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:36:33 --> Final output sent to browser
DEBUG - 2023-07-31 09:36:33 --> Total execution time: 0.0475
INFO - 2023-07-31 09:36:35 --> Config Class Initialized
INFO - 2023-07-31 09:36:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:35 --> URI Class Initialized
INFO - 2023-07-31 09:36:35 --> Router Class Initialized
INFO - 2023-07-31 09:36:35 --> Output Class Initialized
INFO - 2023-07-31 09:36:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:35 --> Input Class Initialized
INFO - 2023-07-31 09:36:35 --> Language Class Initialized
INFO - 2023-07-31 09:36:35 --> Language Class Initialized
INFO - 2023-07-31 09:36:35 --> Config Class Initialized
INFO - 2023-07-31 09:36:35 --> Loader Class Initialized
INFO - 2023-07-31 09:36:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:35 --> Controller Class Initialized
DEBUG - 2023-07-31 09:36:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:36:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:36:35 --> Final output sent to browser
DEBUG - 2023-07-31 09:36:35 --> Total execution time: 0.0265
INFO - 2023-07-31 09:36:35 --> Config Class Initialized
INFO - 2023-07-31 09:36:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:35 --> URI Class Initialized
INFO - 2023-07-31 09:36:35 --> Router Class Initialized
INFO - 2023-07-31 09:36:35 --> Output Class Initialized
INFO - 2023-07-31 09:36:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:35 --> Input Class Initialized
INFO - 2023-07-31 09:36:35 --> Language Class Initialized
INFO - 2023-07-31 09:36:35 --> Language Class Initialized
INFO - 2023-07-31 09:36:35 --> Config Class Initialized
INFO - 2023-07-31 09:36:35 --> Loader Class Initialized
INFO - 2023-07-31 09:36:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:35 --> Controller Class Initialized
INFO - 2023-07-31 09:36:36 --> Config Class Initialized
INFO - 2023-07-31 09:36:36 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:36:36 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:36:36 --> Utf8 Class Initialized
INFO - 2023-07-31 09:36:36 --> URI Class Initialized
INFO - 2023-07-31 09:36:36 --> Router Class Initialized
INFO - 2023-07-31 09:36:36 --> Output Class Initialized
INFO - 2023-07-31 09:36:36 --> Security Class Initialized
DEBUG - 2023-07-31 09:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:36:36 --> Input Class Initialized
INFO - 2023-07-31 09:36:36 --> Language Class Initialized
INFO - 2023-07-31 09:36:36 --> Language Class Initialized
INFO - 2023-07-31 09:36:36 --> Config Class Initialized
INFO - 2023-07-31 09:36:36 --> Loader Class Initialized
INFO - 2023-07-31 09:36:36 --> Helper loaded: url_helper
INFO - 2023-07-31 09:36:36 --> Helper loaded: file_helper
INFO - 2023-07-31 09:36:36 --> Helper loaded: form_helper
INFO - 2023-07-31 09:36:36 --> Helper loaded: my_helper
INFO - 2023-07-31 09:36:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:36:36 --> Controller Class Initialized
ERROR - 2023-07-31 09:36:36 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:36:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:36:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:36:36 --> Final output sent to browser
DEBUG - 2023-07-31 09:36:36 --> Total execution time: 0.0410
INFO - 2023-07-31 09:37:13 --> Config Class Initialized
INFO - 2023-07-31 09:37:13 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:13 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:13 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:13 --> URI Class Initialized
INFO - 2023-07-31 09:37:13 --> Router Class Initialized
INFO - 2023-07-31 09:37:13 --> Output Class Initialized
INFO - 2023-07-31 09:37:13 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:13 --> Input Class Initialized
INFO - 2023-07-31 09:37:13 --> Language Class Initialized
INFO - 2023-07-31 09:37:13 --> Language Class Initialized
INFO - 2023-07-31 09:37:13 --> Config Class Initialized
INFO - 2023-07-31 09:37:13 --> Loader Class Initialized
INFO - 2023-07-31 09:37:13 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:13 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:13 --> Controller Class Initialized
DEBUG - 2023-07-31 09:37:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:37:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:37:13 --> Final output sent to browser
DEBUG - 2023-07-31 09:37:13 --> Total execution time: 0.0265
INFO - 2023-07-31 09:37:13 --> Config Class Initialized
INFO - 2023-07-31 09:37:13 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:13 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:13 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:13 --> URI Class Initialized
INFO - 2023-07-31 09:37:13 --> Router Class Initialized
INFO - 2023-07-31 09:37:13 --> Output Class Initialized
INFO - 2023-07-31 09:37:13 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:13 --> Input Class Initialized
INFO - 2023-07-31 09:37:13 --> Language Class Initialized
INFO - 2023-07-31 09:37:13 --> Language Class Initialized
INFO - 2023-07-31 09:37:13 --> Config Class Initialized
INFO - 2023-07-31 09:37:13 --> Loader Class Initialized
INFO - 2023-07-31 09:37:13 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:13 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:13 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:13 --> Controller Class Initialized
INFO - 2023-07-31 09:37:14 --> Config Class Initialized
INFO - 2023-07-31 09:37:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:14 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:14 --> URI Class Initialized
INFO - 2023-07-31 09:37:14 --> Router Class Initialized
INFO - 2023-07-31 09:37:14 --> Output Class Initialized
INFO - 2023-07-31 09:37:14 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:14 --> Input Class Initialized
INFO - 2023-07-31 09:37:14 --> Language Class Initialized
INFO - 2023-07-31 09:37:14 --> Language Class Initialized
INFO - 2023-07-31 09:37:14 --> Config Class Initialized
INFO - 2023-07-31 09:37:14 --> Loader Class Initialized
INFO - 2023-07-31 09:37:14 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:14 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:14 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:14 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:14 --> Controller Class Initialized
INFO - 2023-07-31 09:37:14 --> Config Class Initialized
INFO - 2023-07-31 09:37:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:14 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:14 --> URI Class Initialized
INFO - 2023-07-31 09:37:14 --> Router Class Initialized
INFO - 2023-07-31 09:37:14 --> Output Class Initialized
INFO - 2023-07-31 09:37:14 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:14 --> Input Class Initialized
INFO - 2023-07-31 09:37:14 --> Language Class Initialized
INFO - 2023-07-31 09:37:14 --> Language Class Initialized
INFO - 2023-07-31 09:37:14 --> Config Class Initialized
INFO - 2023-07-31 09:37:14 --> Loader Class Initialized
INFO - 2023-07-31 09:37:14 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:14 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:15 --> Controller Class Initialized
DEBUG - 2023-07-31 09:37:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:37:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:37:15 --> Final output sent to browser
DEBUG - 2023-07-31 09:37:15 --> Total execution time: 0.0396
INFO - 2023-07-31 09:37:15 --> Config Class Initialized
INFO - 2023-07-31 09:37:15 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:15 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:15 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:15 --> URI Class Initialized
INFO - 2023-07-31 09:37:15 --> Router Class Initialized
INFO - 2023-07-31 09:37:15 --> Output Class Initialized
INFO - 2023-07-31 09:37:15 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:15 --> Input Class Initialized
INFO - 2023-07-31 09:37:15 --> Language Class Initialized
INFO - 2023-07-31 09:37:15 --> Language Class Initialized
INFO - 2023-07-31 09:37:15 --> Config Class Initialized
INFO - 2023-07-31 09:37:15 --> Loader Class Initialized
INFO - 2023-07-31 09:37:15 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:15 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:15 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:15 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:15 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:15 --> Controller Class Initialized
INFO - 2023-07-31 09:37:17 --> Config Class Initialized
INFO - 2023-07-31 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:17 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:17 --> URI Class Initialized
INFO - 2023-07-31 09:37:17 --> Router Class Initialized
INFO - 2023-07-31 09:37:17 --> Output Class Initialized
INFO - 2023-07-31 09:37:17 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:17 --> Input Class Initialized
INFO - 2023-07-31 09:37:17 --> Language Class Initialized
INFO - 2023-07-31 09:37:17 --> Language Class Initialized
INFO - 2023-07-31 09:37:17 --> Config Class Initialized
INFO - 2023-07-31 09:37:17 --> Loader Class Initialized
INFO - 2023-07-31 09:37:17 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:17 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:17 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:17 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:17 --> Controller Class Initialized
DEBUG - 2023-07-31 09:37:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:37:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:37:17 --> Final output sent to browser
DEBUG - 2023-07-31 09:37:17 --> Total execution time: 0.0268
INFO - 2023-07-31 09:37:20 --> Config Class Initialized
INFO - 2023-07-31 09:37:20 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:37:20 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:37:20 --> Utf8 Class Initialized
INFO - 2023-07-31 09:37:20 --> URI Class Initialized
INFO - 2023-07-31 09:37:20 --> Router Class Initialized
INFO - 2023-07-31 09:37:20 --> Output Class Initialized
INFO - 2023-07-31 09:37:20 --> Security Class Initialized
DEBUG - 2023-07-31 09:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:37:20 --> Input Class Initialized
INFO - 2023-07-31 09:37:20 --> Language Class Initialized
INFO - 2023-07-31 09:37:20 --> Language Class Initialized
INFO - 2023-07-31 09:37:20 --> Config Class Initialized
INFO - 2023-07-31 09:37:20 --> Loader Class Initialized
INFO - 2023-07-31 09:37:20 --> Helper loaded: url_helper
INFO - 2023-07-31 09:37:20 --> Helper loaded: file_helper
INFO - 2023-07-31 09:37:20 --> Helper loaded: form_helper
INFO - 2023-07-31 09:37:20 --> Helper loaded: my_helper
INFO - 2023-07-31 09:37:20 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:37:20 --> Controller Class Initialized
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:37:20 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:37:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:39:27 --> Config Class Initialized
INFO - 2023-07-31 09:39:27 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:27 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:27 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:27 --> URI Class Initialized
INFO - 2023-07-31 09:39:27 --> Router Class Initialized
INFO - 2023-07-31 09:39:27 --> Output Class Initialized
INFO - 2023-07-31 09:39:27 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:27 --> Input Class Initialized
INFO - 2023-07-31 09:39:27 --> Language Class Initialized
INFO - 2023-07-31 09:39:27 --> Language Class Initialized
INFO - 2023-07-31 09:39:27 --> Config Class Initialized
INFO - 2023-07-31 09:39:27 --> Loader Class Initialized
INFO - 2023-07-31 09:39:27 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:27 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:27 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:27 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:27 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:27 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:27 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:27 --> Total execution time: 0.0667
INFO - 2023-07-31 09:39:28 --> Config Class Initialized
INFO - 2023-07-31 09:39:28 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:28 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:28 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:28 --> URI Class Initialized
INFO - 2023-07-31 09:39:28 --> Router Class Initialized
INFO - 2023-07-31 09:39:28 --> Output Class Initialized
INFO - 2023-07-31 09:39:28 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:28 --> Input Class Initialized
INFO - 2023-07-31 09:39:28 --> Language Class Initialized
INFO - 2023-07-31 09:39:28 --> Language Class Initialized
INFO - 2023-07-31 09:39:28 --> Config Class Initialized
INFO - 2023-07-31 09:39:28 --> Loader Class Initialized
INFO - 2023-07-31 09:39:28 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:28 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:28 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:39:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:28 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:28 --> Total execution time: 0.0352
INFO - 2023-07-31 09:39:28 --> Config Class Initialized
INFO - 2023-07-31 09:39:28 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:28 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:28 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:28 --> URI Class Initialized
INFO - 2023-07-31 09:39:28 --> Router Class Initialized
INFO - 2023-07-31 09:39:28 --> Output Class Initialized
INFO - 2023-07-31 09:39:28 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:28 --> Input Class Initialized
INFO - 2023-07-31 09:39:28 --> Language Class Initialized
INFO - 2023-07-31 09:39:28 --> Language Class Initialized
INFO - 2023-07-31 09:39:28 --> Config Class Initialized
INFO - 2023-07-31 09:39:28 --> Loader Class Initialized
INFO - 2023-07-31 09:39:28 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:28 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:28 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:28 --> Controller Class Initialized
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:30 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:30 --> URI Class Initialized
INFO - 2023-07-31 09:39:30 --> Router Class Initialized
INFO - 2023-07-31 09:39:30 --> Output Class Initialized
INFO - 2023-07-31 09:39:30 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:30 --> Input Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Loader Class Initialized
INFO - 2023-07-31 09:39:30 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:30 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:30 --> Controller Class Initialized
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:30 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:30 --> URI Class Initialized
INFO - 2023-07-31 09:39:30 --> Router Class Initialized
INFO - 2023-07-31 09:39:30 --> Output Class Initialized
INFO - 2023-07-31 09:39:30 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:30 --> Input Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Loader Class Initialized
INFO - 2023-07-31 09:39:30 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:30 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:30 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:39:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:30 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:30 --> Total execution time: 0.0280
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:30 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:30 --> URI Class Initialized
INFO - 2023-07-31 09:39:30 --> Router Class Initialized
INFO - 2023-07-31 09:39:30 --> Output Class Initialized
INFO - 2023-07-31 09:39:30 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:30 --> Input Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Language Class Initialized
INFO - 2023-07-31 09:39:30 --> Config Class Initialized
INFO - 2023-07-31 09:39:30 --> Loader Class Initialized
INFO - 2023-07-31 09:39:30 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:30 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:30 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:30 --> Controller Class Initialized
INFO - 2023-07-31 09:39:38 --> Config Class Initialized
INFO - 2023-07-31 09:39:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:38 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:38 --> URI Class Initialized
INFO - 2023-07-31 09:39:38 --> Router Class Initialized
INFO - 2023-07-31 09:39:38 --> Output Class Initialized
INFO - 2023-07-31 09:39:38 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:38 --> Input Class Initialized
INFO - 2023-07-31 09:39:38 --> Language Class Initialized
INFO - 2023-07-31 09:39:38 --> Language Class Initialized
INFO - 2023-07-31 09:39:38 --> Config Class Initialized
INFO - 2023-07-31 09:39:38 --> Loader Class Initialized
INFO - 2023-07-31 09:39:38 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:38 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:38 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:38 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:38 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:38 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:38 --> Total execution time: 0.0364
INFO - 2023-07-31 09:39:41 --> Config Class Initialized
INFO - 2023-07-31 09:39:41 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:41 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:41 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:41 --> URI Class Initialized
INFO - 2023-07-31 09:39:41 --> Router Class Initialized
INFO - 2023-07-31 09:39:41 --> Output Class Initialized
INFO - 2023-07-31 09:39:41 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:41 --> Input Class Initialized
INFO - 2023-07-31 09:39:41 --> Language Class Initialized
INFO - 2023-07-31 09:39:41 --> Language Class Initialized
INFO - 2023-07-31 09:39:41 --> Config Class Initialized
INFO - 2023-07-31 09:39:41 --> Loader Class Initialized
INFO - 2023-07-31 09:39:41 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:41 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:41 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:41 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:41 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:41 --> Controller Class Initialized
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:39:41 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:39:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:39:42 --> Config Class Initialized
INFO - 2023-07-31 09:39:42 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:42 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:42 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:42 --> URI Class Initialized
INFO - 2023-07-31 09:39:42 --> Router Class Initialized
INFO - 2023-07-31 09:39:42 --> Output Class Initialized
INFO - 2023-07-31 09:39:42 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:42 --> Input Class Initialized
INFO - 2023-07-31 09:39:42 --> Language Class Initialized
INFO - 2023-07-31 09:39:42 --> Language Class Initialized
INFO - 2023-07-31 09:39:42 --> Config Class Initialized
INFO - 2023-07-31 09:39:42 --> Loader Class Initialized
INFO - 2023-07-31 09:39:42 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:42 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:42 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:42 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:42 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:42 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:39:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:42 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:42 --> Total execution time: 0.0440
INFO - 2023-07-31 09:39:44 --> Config Class Initialized
INFO - 2023-07-31 09:39:44 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:44 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:44 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:44 --> URI Class Initialized
INFO - 2023-07-31 09:39:44 --> Router Class Initialized
INFO - 2023-07-31 09:39:44 --> Output Class Initialized
INFO - 2023-07-31 09:39:44 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:44 --> Input Class Initialized
INFO - 2023-07-31 09:39:44 --> Language Class Initialized
INFO - 2023-07-31 09:39:44 --> Language Class Initialized
INFO - 2023-07-31 09:39:44 --> Config Class Initialized
INFO - 2023-07-31 09:39:44 --> Loader Class Initialized
INFO - 2023-07-31 09:39:44 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:44 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:44 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:39:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:44 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:44 --> Total execution time: 0.0364
INFO - 2023-07-31 09:39:44 --> Config Class Initialized
INFO - 2023-07-31 09:39:44 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:44 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:44 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:44 --> URI Class Initialized
INFO - 2023-07-31 09:39:44 --> Router Class Initialized
INFO - 2023-07-31 09:39:44 --> Output Class Initialized
INFO - 2023-07-31 09:39:44 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:44 --> Input Class Initialized
INFO - 2023-07-31 09:39:44 --> Language Class Initialized
INFO - 2023-07-31 09:39:44 --> Language Class Initialized
INFO - 2023-07-31 09:39:44 --> Config Class Initialized
INFO - 2023-07-31 09:39:44 --> Loader Class Initialized
INFO - 2023-07-31 09:39:44 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:44 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:44 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:44 --> Controller Class Initialized
INFO - 2023-07-31 09:39:45 --> Config Class Initialized
INFO - 2023-07-31 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:45 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:45 --> URI Class Initialized
INFO - 2023-07-31 09:39:45 --> Router Class Initialized
INFO - 2023-07-31 09:39:45 --> Output Class Initialized
INFO - 2023-07-31 09:39:45 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:45 --> Input Class Initialized
INFO - 2023-07-31 09:39:45 --> Language Class Initialized
INFO - 2023-07-31 09:39:45 --> Language Class Initialized
INFO - 2023-07-31 09:39:45 --> Config Class Initialized
INFO - 2023-07-31 09:39:45 --> Loader Class Initialized
INFO - 2023-07-31 09:39:45 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:45 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:45 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:45 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:45 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:45 --> Controller Class Initialized
ERROR - 2023-07-31 09:39:45 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:39:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:39:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:45 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:45 --> Total execution time: 0.0268
INFO - 2023-07-31 09:39:55 --> Config Class Initialized
INFO - 2023-07-31 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:55 --> URI Class Initialized
INFO - 2023-07-31 09:39:55 --> Router Class Initialized
INFO - 2023-07-31 09:39:55 --> Output Class Initialized
INFO - 2023-07-31 09:39:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:55 --> Input Class Initialized
INFO - 2023-07-31 09:39:55 --> Language Class Initialized
INFO - 2023-07-31 09:39:55 --> Language Class Initialized
INFO - 2023-07-31 09:39:55 --> Config Class Initialized
INFO - 2023-07-31 09:39:55 --> Loader Class Initialized
INFO - 2023-07-31 09:39:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:55 --> Controller Class Initialized
DEBUG - 2023-07-31 09:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:39:55 --> Final output sent to browser
DEBUG - 2023-07-31 09:39:55 --> Total execution time: 0.0254
INFO - 2023-07-31 09:39:55 --> Config Class Initialized
INFO - 2023-07-31 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:39:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:39:55 --> URI Class Initialized
INFO - 2023-07-31 09:39:55 --> Router Class Initialized
INFO - 2023-07-31 09:39:55 --> Output Class Initialized
INFO - 2023-07-31 09:39:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:39:55 --> Input Class Initialized
INFO - 2023-07-31 09:39:55 --> Language Class Initialized
INFO - 2023-07-31 09:39:55 --> Language Class Initialized
INFO - 2023-07-31 09:39:55 --> Config Class Initialized
INFO - 2023-07-31 09:39:55 --> Loader Class Initialized
INFO - 2023-07-31 09:39:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:39:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:39:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:39:55 --> Controller Class Initialized
INFO - 2023-07-31 09:40:26 --> Config Class Initialized
INFO - 2023-07-31 09:40:26 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:26 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:26 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:26 --> URI Class Initialized
INFO - 2023-07-31 09:40:26 --> Router Class Initialized
INFO - 2023-07-31 09:40:26 --> Output Class Initialized
INFO - 2023-07-31 09:40:26 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:26 --> Input Class Initialized
INFO - 2023-07-31 09:40:26 --> Language Class Initialized
INFO - 2023-07-31 09:40:26 --> Language Class Initialized
INFO - 2023-07-31 09:40:26 --> Config Class Initialized
INFO - 2023-07-31 09:40:26 --> Loader Class Initialized
INFO - 2023-07-31 09:40:26 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:26 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:26 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:26 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:26 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:26 --> Controller Class Initialized
DEBUG - 2023-07-31 09:40:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:40:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:40:26 --> Final output sent to browser
DEBUG - 2023-07-31 09:40:26 --> Total execution time: 0.0438
INFO - 2023-07-31 09:40:29 --> Config Class Initialized
INFO - 2023-07-31 09:40:29 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:29 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:29 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:29 --> URI Class Initialized
INFO - 2023-07-31 09:40:29 --> Router Class Initialized
INFO - 2023-07-31 09:40:29 --> Output Class Initialized
INFO - 2023-07-31 09:40:29 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:29 --> Input Class Initialized
INFO - 2023-07-31 09:40:29 --> Language Class Initialized
INFO - 2023-07-31 09:40:29 --> Language Class Initialized
INFO - 2023-07-31 09:40:29 --> Config Class Initialized
INFO - 2023-07-31 09:40:29 --> Loader Class Initialized
INFO - 2023-07-31 09:40:29 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:29 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:29 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:29 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:29 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:29 --> Controller Class Initialized
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:40:29 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:40:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:40:34 --> Config Class Initialized
INFO - 2023-07-31 09:40:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:34 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:34 --> URI Class Initialized
INFO - 2023-07-31 09:40:34 --> Router Class Initialized
INFO - 2023-07-31 09:40:34 --> Output Class Initialized
INFO - 2023-07-31 09:40:34 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:34 --> Input Class Initialized
INFO - 2023-07-31 09:40:34 --> Language Class Initialized
INFO - 2023-07-31 09:40:34 --> Language Class Initialized
INFO - 2023-07-31 09:40:34 --> Config Class Initialized
INFO - 2023-07-31 09:40:34 --> Loader Class Initialized
INFO - 2023-07-31 09:40:34 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:34 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:34 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:34 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:34 --> Controller Class Initialized
DEBUG - 2023-07-31 09:40:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:40:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:40:34 --> Final output sent to browser
DEBUG - 2023-07-31 09:40:34 --> Total execution time: 0.0481
INFO - 2023-07-31 09:40:35 --> Config Class Initialized
INFO - 2023-07-31 09:40:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:35 --> URI Class Initialized
INFO - 2023-07-31 09:40:35 --> Router Class Initialized
INFO - 2023-07-31 09:40:35 --> Output Class Initialized
INFO - 2023-07-31 09:40:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:35 --> Input Class Initialized
INFO - 2023-07-31 09:40:35 --> Language Class Initialized
INFO - 2023-07-31 09:40:35 --> Language Class Initialized
INFO - 2023-07-31 09:40:35 --> Config Class Initialized
INFO - 2023-07-31 09:40:35 --> Loader Class Initialized
INFO - 2023-07-31 09:40:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:35 --> Controller Class Initialized
DEBUG - 2023-07-31 09:40:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 09:40:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:40:35 --> Final output sent to browser
DEBUG - 2023-07-31 09:40:35 --> Total execution time: 0.0257
INFO - 2023-07-31 09:40:35 --> Config Class Initialized
INFO - 2023-07-31 09:40:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:35 --> URI Class Initialized
INFO - 2023-07-31 09:40:35 --> Router Class Initialized
INFO - 2023-07-31 09:40:35 --> Output Class Initialized
INFO - 2023-07-31 09:40:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:35 --> Input Class Initialized
INFO - 2023-07-31 09:40:35 --> Language Class Initialized
INFO - 2023-07-31 09:40:35 --> Language Class Initialized
INFO - 2023-07-31 09:40:35 --> Config Class Initialized
INFO - 2023-07-31 09:40:35 --> Loader Class Initialized
INFO - 2023-07-31 09:40:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:35 --> Controller Class Initialized
INFO - 2023-07-31 09:40:36 --> Config Class Initialized
INFO - 2023-07-31 09:40:36 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:36 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:36 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:36 --> URI Class Initialized
INFO - 2023-07-31 09:40:36 --> Router Class Initialized
INFO - 2023-07-31 09:40:36 --> Output Class Initialized
INFO - 2023-07-31 09:40:36 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:36 --> Input Class Initialized
INFO - 2023-07-31 09:40:36 --> Language Class Initialized
INFO - 2023-07-31 09:40:36 --> Language Class Initialized
INFO - 2023-07-31 09:40:36 --> Config Class Initialized
INFO - 2023-07-31 09:40:36 --> Loader Class Initialized
INFO - 2023-07-31 09:40:36 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:36 --> Controller Class Initialized
DEBUG - 2023-07-31 09:40:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:40:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:40:36 --> Final output sent to browser
DEBUG - 2023-07-31 09:40:36 --> Total execution time: 0.0446
INFO - 2023-07-31 09:40:36 --> Config Class Initialized
INFO - 2023-07-31 09:40:36 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:36 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:36 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:36 --> URI Class Initialized
INFO - 2023-07-31 09:40:36 --> Router Class Initialized
INFO - 2023-07-31 09:40:36 --> Output Class Initialized
INFO - 2023-07-31 09:40:36 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:36 --> Input Class Initialized
INFO - 2023-07-31 09:40:36 --> Language Class Initialized
INFO - 2023-07-31 09:40:36 --> Language Class Initialized
INFO - 2023-07-31 09:40:36 --> Config Class Initialized
INFO - 2023-07-31 09:40:36 --> Loader Class Initialized
INFO - 2023-07-31 09:40:36 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:36 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:36 --> Controller Class Initialized
INFO - 2023-07-31 09:40:37 --> Config Class Initialized
INFO - 2023-07-31 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:40:37 --> Utf8 Class Initialized
INFO - 2023-07-31 09:40:37 --> URI Class Initialized
INFO - 2023-07-31 09:40:37 --> Router Class Initialized
INFO - 2023-07-31 09:40:37 --> Output Class Initialized
INFO - 2023-07-31 09:40:37 --> Security Class Initialized
DEBUG - 2023-07-31 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:40:37 --> Input Class Initialized
INFO - 2023-07-31 09:40:37 --> Language Class Initialized
INFO - 2023-07-31 09:40:37 --> Language Class Initialized
INFO - 2023-07-31 09:40:37 --> Config Class Initialized
INFO - 2023-07-31 09:40:37 --> Loader Class Initialized
INFO - 2023-07-31 09:40:37 --> Helper loaded: url_helper
INFO - 2023-07-31 09:40:37 --> Helper loaded: file_helper
INFO - 2023-07-31 09:40:37 --> Helper loaded: form_helper
INFO - 2023-07-31 09:40:37 --> Helper loaded: my_helper
INFO - 2023-07-31 09:40:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:40:37 --> Controller Class Initialized
ERROR - 2023-07-31 09:40:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:40:37 --> Final output sent to browser
DEBUG - 2023-07-31 09:40:37 --> Total execution time: 0.0285
INFO - 2023-07-31 09:42:51 --> Config Class Initialized
INFO - 2023-07-31 09:42:51 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:51 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:51 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:51 --> URI Class Initialized
INFO - 2023-07-31 09:42:51 --> Router Class Initialized
INFO - 2023-07-31 09:42:51 --> Output Class Initialized
INFO - 2023-07-31 09:42:51 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:51 --> Input Class Initialized
INFO - 2023-07-31 09:42:51 --> Language Class Initialized
ERROR - 2023-07-31 09:42:51 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:42:52 --> Config Class Initialized
INFO - 2023-07-31 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:52 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:52 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:52 --> URI Class Initialized
INFO - 2023-07-31 09:42:52 --> Router Class Initialized
INFO - 2023-07-31 09:42:52 --> Output Class Initialized
INFO - 2023-07-31 09:42:52 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:52 --> Input Class Initialized
INFO - 2023-07-31 09:42:52 --> Language Class Initialized
INFO - 2023-07-31 09:42:52 --> Language Class Initialized
INFO - 2023-07-31 09:42:52 --> Config Class Initialized
INFO - 2023-07-31 09:42:52 --> Loader Class Initialized
INFO - 2023-07-31 09:42:52 --> Helper loaded: url_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: file_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: form_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: my_helper
INFO - 2023-07-31 09:42:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:42:52 --> Controller Class Initialized
DEBUG - 2023-07-31 09:42:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 09:42:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:42:52 --> Final output sent to browser
DEBUG - 2023-07-31 09:42:52 --> Total execution time: 0.0247
INFO - 2023-07-31 09:42:52 --> Config Class Initialized
INFO - 2023-07-31 09:42:52 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:52 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:52 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:52 --> URI Class Initialized
INFO - 2023-07-31 09:42:52 --> Router Class Initialized
INFO - 2023-07-31 09:42:52 --> Output Class Initialized
INFO - 2023-07-31 09:42:52 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:52 --> Input Class Initialized
INFO - 2023-07-31 09:42:52 --> Language Class Initialized
INFO - 2023-07-31 09:42:52 --> Language Class Initialized
INFO - 2023-07-31 09:42:52 --> Config Class Initialized
INFO - 2023-07-31 09:42:52 --> Loader Class Initialized
INFO - 2023-07-31 09:42:52 --> Helper loaded: url_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: file_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: form_helper
INFO - 2023-07-31 09:42:52 --> Helper loaded: my_helper
INFO - 2023-07-31 09:42:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:42:52 --> Controller Class Initialized
INFO - 2023-07-31 09:42:53 --> Config Class Initialized
INFO - 2023-07-31 09:42:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:53 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:53 --> URI Class Initialized
INFO - 2023-07-31 09:42:53 --> Router Class Initialized
INFO - 2023-07-31 09:42:53 --> Output Class Initialized
INFO - 2023-07-31 09:42:53 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:53 --> Input Class Initialized
INFO - 2023-07-31 09:42:53 --> Language Class Initialized
ERROR - 2023-07-31 09:42:53 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:42:55 --> Config Class Initialized
INFO - 2023-07-31 09:42:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:55 --> URI Class Initialized
INFO - 2023-07-31 09:42:55 --> Router Class Initialized
INFO - 2023-07-31 09:42:55 --> Output Class Initialized
INFO - 2023-07-31 09:42:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:55 --> Input Class Initialized
INFO - 2023-07-31 09:42:55 --> Language Class Initialized
INFO - 2023-07-31 09:42:55 --> Language Class Initialized
INFO - 2023-07-31 09:42:55 --> Config Class Initialized
INFO - 2023-07-31 09:42:55 --> Loader Class Initialized
INFO - 2023-07-31 09:42:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:42:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:42:55 --> Controller Class Initialized
DEBUG - 2023-07-31 09:42:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 09:42:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:42:55 --> Final output sent to browser
DEBUG - 2023-07-31 09:42:55 --> Total execution time: 0.0361
INFO - 2023-07-31 09:42:55 --> Config Class Initialized
INFO - 2023-07-31 09:42:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:55 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:55 --> URI Class Initialized
INFO - 2023-07-31 09:42:55 --> Router Class Initialized
INFO - 2023-07-31 09:42:55 --> Output Class Initialized
INFO - 2023-07-31 09:42:55 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:55 --> Input Class Initialized
INFO - 2023-07-31 09:42:55 --> Language Class Initialized
INFO - 2023-07-31 09:42:55 --> Language Class Initialized
INFO - 2023-07-31 09:42:55 --> Config Class Initialized
INFO - 2023-07-31 09:42:55 --> Loader Class Initialized
INFO - 2023-07-31 09:42:55 --> Helper loaded: url_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: file_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: form_helper
INFO - 2023-07-31 09:42:55 --> Helper loaded: my_helper
INFO - 2023-07-31 09:42:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:42:55 --> Controller Class Initialized
INFO - 2023-07-31 09:42:57 --> Config Class Initialized
INFO - 2023-07-31 09:42:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:42:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:42:57 --> Utf8 Class Initialized
INFO - 2023-07-31 09:42:57 --> URI Class Initialized
INFO - 2023-07-31 09:42:57 --> Router Class Initialized
INFO - 2023-07-31 09:42:57 --> Output Class Initialized
INFO - 2023-07-31 09:42:57 --> Security Class Initialized
DEBUG - 2023-07-31 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:42:57 --> Input Class Initialized
INFO - 2023-07-31 09:42:57 --> Language Class Initialized
ERROR - 2023-07-31 09:42:57 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:05 --> Config Class Initialized
INFO - 2023-07-31 09:43:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:05 --> URI Class Initialized
INFO - 2023-07-31 09:43:05 --> Router Class Initialized
INFO - 2023-07-31 09:43:05 --> Output Class Initialized
INFO - 2023-07-31 09:43:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:05 --> Input Class Initialized
INFO - 2023-07-31 09:43:05 --> Language Class Initialized
ERROR - 2023-07-31 09:43:05 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:06 --> Config Class Initialized
INFO - 2023-07-31 09:43:06 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:06 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:06 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:06 --> URI Class Initialized
INFO - 2023-07-31 09:43:06 --> Router Class Initialized
INFO - 2023-07-31 09:43:06 --> Output Class Initialized
INFO - 2023-07-31 09:43:06 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:06 --> Input Class Initialized
INFO - 2023-07-31 09:43:06 --> Language Class Initialized
ERROR - 2023-07-31 09:43:06 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:06 --> Config Class Initialized
INFO - 2023-07-31 09:43:06 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:06 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:06 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:06 --> URI Class Initialized
INFO - 2023-07-31 09:43:06 --> Router Class Initialized
INFO - 2023-07-31 09:43:06 --> Output Class Initialized
INFO - 2023-07-31 09:43:06 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:06 --> Input Class Initialized
INFO - 2023-07-31 09:43:06 --> Language Class Initialized
ERROR - 2023-07-31 09:43:06 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:07 --> Config Class Initialized
INFO - 2023-07-31 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:07 --> URI Class Initialized
INFO - 2023-07-31 09:43:07 --> Router Class Initialized
INFO - 2023-07-31 09:43:07 --> Output Class Initialized
INFO - 2023-07-31 09:43:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:07 --> Input Class Initialized
INFO - 2023-07-31 09:43:07 --> Language Class Initialized
ERROR - 2023-07-31 09:43:07 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:07 --> Config Class Initialized
INFO - 2023-07-31 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:07 --> URI Class Initialized
INFO - 2023-07-31 09:43:07 --> Router Class Initialized
INFO - 2023-07-31 09:43:07 --> Output Class Initialized
INFO - 2023-07-31 09:43:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:07 --> Input Class Initialized
INFO - 2023-07-31 09:43:07 --> Language Class Initialized
ERROR - 2023-07-31 09:43:07 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:07 --> Config Class Initialized
INFO - 2023-07-31 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:07 --> URI Class Initialized
INFO - 2023-07-31 09:43:07 --> Router Class Initialized
INFO - 2023-07-31 09:43:07 --> Output Class Initialized
INFO - 2023-07-31 09:43:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:07 --> Input Class Initialized
INFO - 2023-07-31 09:43:07 --> Language Class Initialized
ERROR - 2023-07-31 09:43:07 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:07 --> Config Class Initialized
INFO - 2023-07-31 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:07 --> URI Class Initialized
INFO - 2023-07-31 09:43:07 --> Router Class Initialized
INFO - 2023-07-31 09:43:07 --> Output Class Initialized
INFO - 2023-07-31 09:43:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:07 --> Input Class Initialized
INFO - 2023-07-31 09:43:07 --> Language Class Initialized
ERROR - 2023-07-31 09:43:07 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:07 --> Config Class Initialized
INFO - 2023-07-31 09:43:07 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:07 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:07 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:07 --> URI Class Initialized
INFO - 2023-07-31 09:43:07 --> Router Class Initialized
INFO - 2023-07-31 09:43:07 --> Output Class Initialized
INFO - 2023-07-31 09:43:07 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:07 --> Input Class Initialized
INFO - 2023-07-31 09:43:07 --> Language Class Initialized
ERROR - 2023-07-31 09:43:07 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:08 --> Config Class Initialized
INFO - 2023-07-31 09:43:08 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:08 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:08 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:08 --> URI Class Initialized
INFO - 2023-07-31 09:43:08 --> Router Class Initialized
INFO - 2023-07-31 09:43:08 --> Output Class Initialized
INFO - 2023-07-31 09:43:08 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:08 --> Input Class Initialized
INFO - 2023-07-31 09:43:08 --> Language Class Initialized
ERROR - 2023-07-31 09:43:08 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 237
INFO - 2023-07-31 09:43:15 --> Config Class Initialized
INFO - 2023-07-31 09:43:15 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:15 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:15 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:15 --> URI Class Initialized
INFO - 2023-07-31 09:43:15 --> Router Class Initialized
INFO - 2023-07-31 09:43:15 --> Output Class Initialized
INFO - 2023-07-31 09:43:15 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:15 --> Input Class Initialized
INFO - 2023-07-31 09:43:15 --> Language Class Initialized
INFO - 2023-07-31 09:43:15 --> Language Class Initialized
INFO - 2023-07-31 09:43:15 --> Config Class Initialized
INFO - 2023-07-31 09:43:15 --> Loader Class Initialized
INFO - 2023-07-31 09:43:15 --> Helper loaded: url_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: file_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: form_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: my_helper
INFO - 2023-07-31 09:43:15 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:43:15 --> Controller Class Initialized
DEBUG - 2023-07-31 09:43:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:43:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:43:15 --> Final output sent to browser
DEBUG - 2023-07-31 09:43:15 --> Total execution time: 0.0367
INFO - 2023-07-31 09:43:15 --> Config Class Initialized
INFO - 2023-07-31 09:43:15 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:15 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:15 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:15 --> URI Class Initialized
INFO - 2023-07-31 09:43:15 --> Router Class Initialized
INFO - 2023-07-31 09:43:15 --> Output Class Initialized
INFO - 2023-07-31 09:43:15 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:15 --> Input Class Initialized
INFO - 2023-07-31 09:43:15 --> Language Class Initialized
INFO - 2023-07-31 09:43:15 --> Language Class Initialized
INFO - 2023-07-31 09:43:15 --> Config Class Initialized
INFO - 2023-07-31 09:43:15 --> Loader Class Initialized
INFO - 2023-07-31 09:43:15 --> Helper loaded: url_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: file_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: form_helper
INFO - 2023-07-31 09:43:15 --> Helper loaded: my_helper
INFO - 2023-07-31 09:43:15 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:43:15 --> Controller Class Initialized
INFO - 2023-07-31 09:43:16 --> Config Class Initialized
INFO - 2023-07-31 09:43:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:16 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:16 --> URI Class Initialized
INFO - 2023-07-31 09:43:16 --> Router Class Initialized
INFO - 2023-07-31 09:43:16 --> Output Class Initialized
INFO - 2023-07-31 09:43:16 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:16 --> Input Class Initialized
INFO - 2023-07-31 09:43:16 --> Language Class Initialized
INFO - 2023-07-31 09:43:16 --> Language Class Initialized
INFO - 2023-07-31 09:43:16 --> Config Class Initialized
INFO - 2023-07-31 09:43:16 --> Loader Class Initialized
INFO - 2023-07-31 09:43:16 --> Helper loaded: url_helper
INFO - 2023-07-31 09:43:16 --> Helper loaded: file_helper
INFO - 2023-07-31 09:43:16 --> Helper loaded: form_helper
INFO - 2023-07-31 09:43:16 --> Helper loaded: my_helper
INFO - 2023-07-31 09:43:16 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:43:16 --> Controller Class Initialized
DEBUG - 2023-07-31 09:43:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:43:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:43:16 --> Final output sent to browser
DEBUG - 2023-07-31 09:43:16 --> Total execution time: 0.0232
INFO - 2023-07-31 09:43:19 --> Config Class Initialized
INFO - 2023-07-31 09:43:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:43:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:43:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:43:19 --> URI Class Initialized
INFO - 2023-07-31 09:43:19 --> Router Class Initialized
INFO - 2023-07-31 09:43:19 --> Output Class Initialized
INFO - 2023-07-31 09:43:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:43:19 --> Input Class Initialized
INFO - 2023-07-31 09:43:19 --> Language Class Initialized
INFO - 2023-07-31 09:43:19 --> Language Class Initialized
INFO - 2023-07-31 09:43:19 --> Config Class Initialized
INFO - 2023-07-31 09:43:19 --> Loader Class Initialized
INFO - 2023-07-31 09:43:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:43:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:43:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:43:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:43:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:43:19 --> Controller Class Initialized
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:43:19 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:43:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:48:57 --> Config Class Initialized
INFO - 2023-07-31 09:48:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:48:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:48:57 --> Utf8 Class Initialized
INFO - 2023-07-31 09:48:57 --> URI Class Initialized
INFO - 2023-07-31 09:48:57 --> Router Class Initialized
INFO - 2023-07-31 09:48:57 --> Output Class Initialized
INFO - 2023-07-31 09:48:57 --> Security Class Initialized
DEBUG - 2023-07-31 09:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:48:57 --> Input Class Initialized
INFO - 2023-07-31 09:48:57 --> Language Class Initialized
INFO - 2023-07-31 09:48:57 --> Language Class Initialized
INFO - 2023-07-31 09:48:57 --> Config Class Initialized
INFO - 2023-07-31 09:48:57 --> Loader Class Initialized
INFO - 2023-07-31 09:48:57 --> Helper loaded: url_helper
INFO - 2023-07-31 09:48:57 --> Helper loaded: file_helper
INFO - 2023-07-31 09:48:57 --> Helper loaded: form_helper
INFO - 2023-07-31 09:48:57 --> Helper loaded: my_helper
INFO - 2023-07-31 09:48:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:48:57 --> Controller Class Initialized
DEBUG - 2023-07-31 09:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:48:57 --> Final output sent to browser
DEBUG - 2023-07-31 09:48:57 --> Total execution time: 0.0768
INFO - 2023-07-31 09:48:58 --> Config Class Initialized
INFO - 2023-07-31 09:48:58 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:48:58 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:48:58 --> Utf8 Class Initialized
INFO - 2023-07-31 09:48:58 --> URI Class Initialized
INFO - 2023-07-31 09:48:58 --> Router Class Initialized
INFO - 2023-07-31 09:48:58 --> Output Class Initialized
INFO - 2023-07-31 09:48:58 --> Security Class Initialized
DEBUG - 2023-07-31 09:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:48:58 --> Input Class Initialized
INFO - 2023-07-31 09:48:58 --> Language Class Initialized
INFO - 2023-07-31 09:48:58 --> Language Class Initialized
INFO - 2023-07-31 09:48:58 --> Config Class Initialized
INFO - 2023-07-31 09:48:58 --> Loader Class Initialized
INFO - 2023-07-31 09:48:58 --> Helper loaded: url_helper
INFO - 2023-07-31 09:48:58 --> Helper loaded: file_helper
INFO - 2023-07-31 09:48:58 --> Helper loaded: form_helper
INFO - 2023-07-31 09:48:58 --> Helper loaded: my_helper
INFO - 2023-07-31 09:48:58 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:48:58 --> Controller Class Initialized
DEBUG - 2023-07-31 09:48:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:48:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:48:58 --> Final output sent to browser
DEBUG - 2023-07-31 09:48:58 --> Total execution time: 0.0400
INFO - 2023-07-31 09:48:59 --> Config Class Initialized
INFO - 2023-07-31 09:48:59 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:48:59 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:48:59 --> Utf8 Class Initialized
INFO - 2023-07-31 09:48:59 --> URI Class Initialized
INFO - 2023-07-31 09:48:59 --> Router Class Initialized
INFO - 2023-07-31 09:48:59 --> Output Class Initialized
INFO - 2023-07-31 09:48:59 --> Security Class Initialized
DEBUG - 2023-07-31 09:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:48:59 --> Input Class Initialized
INFO - 2023-07-31 09:48:59 --> Language Class Initialized
INFO - 2023-07-31 09:48:59 --> Language Class Initialized
INFO - 2023-07-31 09:48:59 --> Config Class Initialized
INFO - 2023-07-31 09:48:59 --> Loader Class Initialized
INFO - 2023-07-31 09:48:59 --> Helper loaded: url_helper
INFO - 2023-07-31 09:48:59 --> Helper loaded: file_helper
INFO - 2023-07-31 09:48:59 --> Helper loaded: form_helper
INFO - 2023-07-31 09:48:59 --> Helper loaded: my_helper
INFO - 2023-07-31 09:48:59 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:48:59 --> Controller Class Initialized
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:49:01 --> Utf8 Class Initialized
INFO - 2023-07-31 09:49:01 --> URI Class Initialized
INFO - 2023-07-31 09:49:01 --> Router Class Initialized
INFO - 2023-07-31 09:49:01 --> Output Class Initialized
INFO - 2023-07-31 09:49:01 --> Security Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:49:01 --> Input Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Loader Class Initialized
INFO - 2023-07-31 09:49:01 --> Helper loaded: url_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: file_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: form_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: my_helper
INFO - 2023-07-31 09:49:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:49:01 --> Controller Class Initialized
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:49:01 --> Utf8 Class Initialized
INFO - 2023-07-31 09:49:01 --> URI Class Initialized
INFO - 2023-07-31 09:49:01 --> Router Class Initialized
INFO - 2023-07-31 09:49:01 --> Output Class Initialized
INFO - 2023-07-31 09:49:01 --> Security Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:49:01 --> Input Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Loader Class Initialized
INFO - 2023-07-31 09:49:01 --> Helper loaded: url_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: file_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: form_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: my_helper
INFO - 2023-07-31 09:49:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:49:01 --> Controller Class Initialized
DEBUG - 2023-07-31 09:49:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:49:01 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:49:01 --> Final output sent to browser
DEBUG - 2023-07-31 09:49:01 --> Total execution time: 0.0321
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:49:01 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:49:01 --> Utf8 Class Initialized
INFO - 2023-07-31 09:49:01 --> URI Class Initialized
INFO - 2023-07-31 09:49:01 --> Router Class Initialized
INFO - 2023-07-31 09:49:01 --> Output Class Initialized
INFO - 2023-07-31 09:49:01 --> Security Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:49:01 --> Input Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Language Class Initialized
INFO - 2023-07-31 09:49:01 --> Config Class Initialized
INFO - 2023-07-31 09:49:01 --> Loader Class Initialized
INFO - 2023-07-31 09:49:01 --> Helper loaded: url_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: file_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: form_helper
INFO - 2023-07-31 09:49:01 --> Helper loaded: my_helper
INFO - 2023-07-31 09:49:01 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:49:01 --> Controller Class Initialized
INFO - 2023-07-31 09:49:02 --> Config Class Initialized
INFO - 2023-07-31 09:49:02 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:49:02 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:49:02 --> Utf8 Class Initialized
INFO - 2023-07-31 09:49:02 --> URI Class Initialized
INFO - 2023-07-31 09:49:02 --> Router Class Initialized
INFO - 2023-07-31 09:49:02 --> Output Class Initialized
INFO - 2023-07-31 09:49:02 --> Security Class Initialized
DEBUG - 2023-07-31 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:49:02 --> Input Class Initialized
INFO - 2023-07-31 09:49:02 --> Language Class Initialized
INFO - 2023-07-31 09:49:02 --> Language Class Initialized
INFO - 2023-07-31 09:49:02 --> Config Class Initialized
INFO - 2023-07-31 09:49:02 --> Loader Class Initialized
INFO - 2023-07-31 09:49:02 --> Helper loaded: url_helper
INFO - 2023-07-31 09:49:02 --> Helper loaded: file_helper
INFO - 2023-07-31 09:49:02 --> Helper loaded: form_helper
INFO - 2023-07-31 09:49:02 --> Helper loaded: my_helper
INFO - 2023-07-31 09:49:02 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:49:02 --> Controller Class Initialized
DEBUG - 2023-07-31 09:49:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:49:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:49:02 --> Final output sent to browser
DEBUG - 2023-07-31 09:49:02 --> Total execution time: 0.0410
INFO - 2023-07-31 09:49:05 --> Config Class Initialized
INFO - 2023-07-31 09:49:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:49:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:49:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:49:05 --> URI Class Initialized
INFO - 2023-07-31 09:49:05 --> Router Class Initialized
INFO - 2023-07-31 09:49:05 --> Output Class Initialized
INFO - 2023-07-31 09:49:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:49:05 --> Input Class Initialized
INFO - 2023-07-31 09:49:05 --> Language Class Initialized
INFO - 2023-07-31 09:49:05 --> Language Class Initialized
INFO - 2023-07-31 09:49:05 --> Config Class Initialized
INFO - 2023-07-31 09:49:05 --> Loader Class Initialized
INFO - 2023-07-31 09:49:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:49:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:49:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:49:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:49:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:49:05 --> Controller Class Initialized
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:49:05 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:49:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:51:16 --> Config Class Initialized
INFO - 2023-07-31 09:51:16 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:16 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:16 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:16 --> URI Class Initialized
INFO - 2023-07-31 09:51:16 --> Router Class Initialized
INFO - 2023-07-31 09:51:16 --> Output Class Initialized
INFO - 2023-07-31 09:51:16 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:16 --> Input Class Initialized
INFO - 2023-07-31 09:51:16 --> Language Class Initialized
INFO - 2023-07-31 09:51:16 --> Language Class Initialized
INFO - 2023-07-31 09:51:16 --> Config Class Initialized
INFO - 2023-07-31 09:51:16 --> Loader Class Initialized
INFO - 2023-07-31 09:51:16 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:16 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:16 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:16 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:16 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:16 --> Controller Class Initialized
DEBUG - 2023-07-31 09:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:51:16 --> Final output sent to browser
DEBUG - 2023-07-31 09:51:16 --> Total execution time: 0.0506
INFO - 2023-07-31 09:51:19 --> Config Class Initialized
INFO - 2023-07-31 09:51:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:19 --> URI Class Initialized
INFO - 2023-07-31 09:51:19 --> Router Class Initialized
INFO - 2023-07-31 09:51:19 --> Output Class Initialized
INFO - 2023-07-31 09:51:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:19 --> Input Class Initialized
INFO - 2023-07-31 09:51:19 --> Language Class Initialized
INFO - 2023-07-31 09:51:19 --> Language Class Initialized
INFO - 2023-07-31 09:51:19 --> Config Class Initialized
INFO - 2023-07-31 09:51:19 --> Loader Class Initialized
INFO - 2023-07-31 09:51:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:19 --> Controller Class Initialized
DEBUG - 2023-07-31 09:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:51:19 --> Final output sent to browser
DEBUG - 2023-07-31 09:51:19 --> Total execution time: 0.0340
INFO - 2023-07-31 09:51:19 --> Config Class Initialized
INFO - 2023-07-31 09:51:19 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:19 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:19 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:19 --> URI Class Initialized
INFO - 2023-07-31 09:51:19 --> Router Class Initialized
INFO - 2023-07-31 09:51:19 --> Output Class Initialized
INFO - 2023-07-31 09:51:19 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:19 --> Input Class Initialized
INFO - 2023-07-31 09:51:19 --> Language Class Initialized
INFO - 2023-07-31 09:51:19 --> Language Class Initialized
INFO - 2023-07-31 09:51:19 --> Config Class Initialized
INFO - 2023-07-31 09:51:19 --> Loader Class Initialized
INFO - 2023-07-31 09:51:19 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:19 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:19 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:19 --> Controller Class Initialized
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:21 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:21 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:21 --> URI Class Initialized
INFO - 2023-07-31 09:51:21 --> Router Class Initialized
INFO - 2023-07-31 09:51:21 --> Output Class Initialized
INFO - 2023-07-31 09:51:21 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:21 --> Input Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Loader Class Initialized
INFO - 2023-07-31 09:51:21 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:21 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:21 --> Controller Class Initialized
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:21 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:21 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:21 --> URI Class Initialized
INFO - 2023-07-31 09:51:21 --> Router Class Initialized
INFO - 2023-07-31 09:51:21 --> Output Class Initialized
INFO - 2023-07-31 09:51:21 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:21 --> Input Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Loader Class Initialized
INFO - 2023-07-31 09:51:21 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:21 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:21 --> Controller Class Initialized
DEBUG - 2023-07-31 09:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:51:21 --> Final output sent to browser
DEBUG - 2023-07-31 09:51:21 --> Total execution time: 0.0432
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:21 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:21 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:21 --> URI Class Initialized
INFO - 2023-07-31 09:51:21 --> Router Class Initialized
INFO - 2023-07-31 09:51:21 --> Output Class Initialized
INFO - 2023-07-31 09:51:21 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:21 --> Input Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Language Class Initialized
INFO - 2023-07-31 09:51:21 --> Config Class Initialized
INFO - 2023-07-31 09:51:21 --> Loader Class Initialized
INFO - 2023-07-31 09:51:21 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:21 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:21 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:21 --> Controller Class Initialized
INFO - 2023-07-31 09:51:22 --> Config Class Initialized
INFO - 2023-07-31 09:51:22 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:22 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:22 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:22 --> URI Class Initialized
INFO - 2023-07-31 09:51:22 --> Router Class Initialized
INFO - 2023-07-31 09:51:22 --> Output Class Initialized
INFO - 2023-07-31 09:51:22 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:22 --> Input Class Initialized
INFO - 2023-07-31 09:51:22 --> Language Class Initialized
INFO - 2023-07-31 09:51:22 --> Language Class Initialized
INFO - 2023-07-31 09:51:22 --> Config Class Initialized
INFO - 2023-07-31 09:51:22 --> Loader Class Initialized
INFO - 2023-07-31 09:51:22 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:22 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:22 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:22 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:22 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:22 --> Controller Class Initialized
DEBUG - 2023-07-31 09:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:51:22 --> Final output sent to browser
DEBUG - 2023-07-31 09:51:22 --> Total execution time: 0.0240
INFO - 2023-07-31 09:51:25 --> Config Class Initialized
INFO - 2023-07-31 09:51:25 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:51:25 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:51:25 --> Utf8 Class Initialized
INFO - 2023-07-31 09:51:25 --> URI Class Initialized
INFO - 2023-07-31 09:51:25 --> Router Class Initialized
INFO - 2023-07-31 09:51:25 --> Output Class Initialized
INFO - 2023-07-31 09:51:25 --> Security Class Initialized
DEBUG - 2023-07-31 09:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:51:25 --> Input Class Initialized
INFO - 2023-07-31 09:51:25 --> Language Class Initialized
INFO - 2023-07-31 09:51:25 --> Language Class Initialized
INFO - 2023-07-31 09:51:25 --> Config Class Initialized
INFO - 2023-07-31 09:51:25 --> Loader Class Initialized
INFO - 2023-07-31 09:51:25 --> Helper loaded: url_helper
INFO - 2023-07-31 09:51:25 --> Helper loaded: file_helper
INFO - 2023-07-31 09:51:25 --> Helper loaded: form_helper
INFO - 2023-07-31 09:51:25 --> Helper loaded: my_helper
INFO - 2023-07-31 09:51:25 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:51:25 --> Controller Class Initialized
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:51:25 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:51:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:52:10 --> Config Class Initialized
INFO - 2023-07-31 09:52:10 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:10 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:10 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:10 --> URI Class Initialized
INFO - 2023-07-31 09:52:10 --> Router Class Initialized
INFO - 2023-07-31 09:52:10 --> Output Class Initialized
INFO - 2023-07-31 09:52:10 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:10 --> Input Class Initialized
INFO - 2023-07-31 09:52:10 --> Language Class Initialized
INFO - 2023-07-31 09:52:10 --> Language Class Initialized
INFO - 2023-07-31 09:52:10 --> Config Class Initialized
INFO - 2023-07-31 09:52:10 --> Loader Class Initialized
INFO - 2023-07-31 09:52:10 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:10 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:10 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:10 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:10 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:10 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:52:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:10 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:10 --> Total execution time: 0.0436
INFO - 2023-07-31 09:52:11 --> Config Class Initialized
INFO - 2023-07-31 09:52:11 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:11 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:11 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:11 --> URI Class Initialized
INFO - 2023-07-31 09:52:11 --> Router Class Initialized
INFO - 2023-07-31 09:52:11 --> Output Class Initialized
INFO - 2023-07-31 09:52:11 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:11 --> Input Class Initialized
INFO - 2023-07-31 09:52:11 --> Language Class Initialized
INFO - 2023-07-31 09:52:11 --> Language Class Initialized
INFO - 2023-07-31 09:52:11 --> Config Class Initialized
INFO - 2023-07-31 09:52:11 --> Loader Class Initialized
INFO - 2023-07-31 09:52:11 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:11 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:11 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:52:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:11 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:11 --> Total execution time: 0.0434
INFO - 2023-07-31 09:52:11 --> Config Class Initialized
INFO - 2023-07-31 09:52:11 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:11 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:11 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:11 --> URI Class Initialized
INFO - 2023-07-31 09:52:11 --> Router Class Initialized
INFO - 2023-07-31 09:52:11 --> Output Class Initialized
INFO - 2023-07-31 09:52:11 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:11 --> Input Class Initialized
INFO - 2023-07-31 09:52:11 --> Language Class Initialized
INFO - 2023-07-31 09:52:11 --> Language Class Initialized
INFO - 2023-07-31 09:52:11 --> Config Class Initialized
INFO - 2023-07-31 09:52:11 --> Loader Class Initialized
INFO - 2023-07-31 09:52:11 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:11 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:11 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:11 --> Controller Class Initialized
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:13 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:13 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:13 --> URI Class Initialized
INFO - 2023-07-31 09:52:13 --> Router Class Initialized
INFO - 2023-07-31 09:52:13 --> Output Class Initialized
INFO - 2023-07-31 09:52:13 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:13 --> Input Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Loader Class Initialized
INFO - 2023-07-31 09:52:13 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:13 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:13 --> Controller Class Initialized
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:13 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:13 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:13 --> URI Class Initialized
INFO - 2023-07-31 09:52:13 --> Router Class Initialized
INFO - 2023-07-31 09:52:13 --> Output Class Initialized
INFO - 2023-07-31 09:52:13 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:13 --> Input Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Loader Class Initialized
INFO - 2023-07-31 09:52:13 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:13 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:13 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:52:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:13 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:13 --> Total execution time: 0.0340
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:13 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:13 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:13 --> URI Class Initialized
INFO - 2023-07-31 09:52:13 --> Router Class Initialized
INFO - 2023-07-31 09:52:13 --> Output Class Initialized
INFO - 2023-07-31 09:52:13 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:13 --> Input Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Language Class Initialized
INFO - 2023-07-31 09:52:13 --> Config Class Initialized
INFO - 2023-07-31 09:52:13 --> Loader Class Initialized
INFO - 2023-07-31 09:52:13 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:13 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:13 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:13 --> Controller Class Initialized
INFO - 2023-07-31 09:52:14 --> Config Class Initialized
INFO - 2023-07-31 09:52:14 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:14 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:14 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:14 --> URI Class Initialized
INFO - 2023-07-31 09:52:14 --> Router Class Initialized
INFO - 2023-07-31 09:52:14 --> Output Class Initialized
INFO - 2023-07-31 09:52:14 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:14 --> Input Class Initialized
INFO - 2023-07-31 09:52:14 --> Language Class Initialized
INFO - 2023-07-31 09:52:14 --> Language Class Initialized
INFO - 2023-07-31 09:52:14 --> Config Class Initialized
INFO - 2023-07-31 09:52:14 --> Loader Class Initialized
INFO - 2023-07-31 09:52:14 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:14 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:14 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:14 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:14 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:14 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:52:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:14 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:14 --> Total execution time: 0.0280
INFO - 2023-07-31 09:52:17 --> Config Class Initialized
INFO - 2023-07-31 09:52:17 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:17 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:17 --> URI Class Initialized
INFO - 2023-07-31 09:52:17 --> Router Class Initialized
INFO - 2023-07-31 09:52:17 --> Output Class Initialized
INFO - 2023-07-31 09:52:17 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:17 --> Input Class Initialized
INFO - 2023-07-31 09:52:17 --> Language Class Initialized
INFO - 2023-07-31 09:52:17 --> Language Class Initialized
INFO - 2023-07-31 09:52:17 --> Config Class Initialized
INFO - 2023-07-31 09:52:17 --> Loader Class Initialized
INFO - 2023-07-31 09:52:17 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:17 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:17 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:17 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:17 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:17 --> Controller Class Initialized
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:52:17 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-07-31 09:52:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\bintaro\primary\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\bintaro\primary\system\helpers\url_helper.php 564
INFO - 2023-07-31 09:52:31 --> Config Class Initialized
INFO - 2023-07-31 09:52:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:31 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:31 --> URI Class Initialized
INFO - 2023-07-31 09:52:31 --> Router Class Initialized
INFO - 2023-07-31 09:52:31 --> Output Class Initialized
INFO - 2023-07-31 09:52:31 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:31 --> Input Class Initialized
INFO - 2023-07-31 09:52:31 --> Language Class Initialized
INFO - 2023-07-31 09:52:31 --> Language Class Initialized
INFO - 2023-07-31 09:52:31 --> Config Class Initialized
INFO - 2023-07-31 09:52:31 --> Loader Class Initialized
INFO - 2023-07-31 09:52:31 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:31 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:31 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:31 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:31 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:52:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:31 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:31 --> Total execution time: 0.0377
INFO - 2023-07-31 09:52:32 --> Config Class Initialized
INFO - 2023-07-31 09:52:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:32 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:32 --> URI Class Initialized
INFO - 2023-07-31 09:52:32 --> Router Class Initialized
INFO - 2023-07-31 09:52:32 --> Output Class Initialized
INFO - 2023-07-31 09:52:32 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:32 --> Input Class Initialized
INFO - 2023-07-31 09:52:32 --> Language Class Initialized
INFO - 2023-07-31 09:52:32 --> Language Class Initialized
INFO - 2023-07-31 09:52:32 --> Config Class Initialized
INFO - 2023-07-31 09:52:32 --> Loader Class Initialized
INFO - 2023-07-31 09:52:32 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:32 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:32 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:32 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:32 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:52:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:32 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:32 --> Total execution time: 0.0436
INFO - 2023-07-31 09:52:33 --> Config Class Initialized
INFO - 2023-07-31 09:52:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:33 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:33 --> URI Class Initialized
INFO - 2023-07-31 09:52:33 --> Router Class Initialized
INFO - 2023-07-31 09:52:33 --> Output Class Initialized
INFO - 2023-07-31 09:52:33 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:33 --> Input Class Initialized
INFO - 2023-07-31 09:52:33 --> Language Class Initialized
INFO - 2023-07-31 09:52:33 --> Language Class Initialized
INFO - 2023-07-31 09:52:33 --> Config Class Initialized
INFO - 2023-07-31 09:52:33 --> Loader Class Initialized
INFO - 2023-07-31 09:52:33 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:33 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:33 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:33 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:33 --> Controller Class Initialized
INFO - 2023-07-31 09:52:34 --> Config Class Initialized
INFO - 2023-07-31 09:52:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:34 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:34 --> URI Class Initialized
INFO - 2023-07-31 09:52:34 --> Router Class Initialized
INFO - 2023-07-31 09:52:34 --> Output Class Initialized
INFO - 2023-07-31 09:52:34 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:34 --> Input Class Initialized
INFO - 2023-07-31 09:52:34 --> Language Class Initialized
INFO - 2023-07-31 09:52:34 --> Language Class Initialized
INFO - 2023-07-31 09:52:34 --> Config Class Initialized
INFO - 2023-07-31 09:52:34 --> Loader Class Initialized
INFO - 2023-07-31 09:52:34 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:34 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:34 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:34 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:34 --> Controller Class Initialized
ERROR - 2023-07-31 09:52:34 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:52:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:52:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:34 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:34 --> Total execution time: 0.0434
INFO - 2023-07-31 09:52:35 --> Config Class Initialized
INFO - 2023-07-31 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:35 --> URI Class Initialized
INFO - 2023-07-31 09:52:35 --> Router Class Initialized
INFO - 2023-07-31 09:52:35 --> Output Class Initialized
INFO - 2023-07-31 09:52:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:35 --> Input Class Initialized
INFO - 2023-07-31 09:52:35 --> Language Class Initialized
INFO - 2023-07-31 09:52:35 --> Language Class Initialized
INFO - 2023-07-31 09:52:35 --> Config Class Initialized
INFO - 2023-07-31 09:52:35 --> Loader Class Initialized
INFO - 2023-07-31 09:52:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:35 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:35 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:35 --> Total execution time: 0.0255
INFO - 2023-07-31 09:52:35 --> Config Class Initialized
INFO - 2023-07-31 09:52:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:35 --> URI Class Initialized
INFO - 2023-07-31 09:52:35 --> Router Class Initialized
INFO - 2023-07-31 09:52:35 --> Output Class Initialized
INFO - 2023-07-31 09:52:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:35 --> Input Class Initialized
INFO - 2023-07-31 09:52:35 --> Language Class Initialized
INFO - 2023-07-31 09:52:35 --> Language Class Initialized
INFO - 2023-07-31 09:52:35 --> Config Class Initialized
INFO - 2023-07-31 09:52:35 --> Loader Class Initialized
INFO - 2023-07-31 09:52:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:36 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:36 --> Controller Class Initialized
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:37 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:37 --> URI Class Initialized
INFO - 2023-07-31 09:52:37 --> Router Class Initialized
INFO - 2023-07-31 09:52:37 --> Output Class Initialized
INFO - 2023-07-31 09:52:37 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:37 --> Input Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Loader Class Initialized
INFO - 2023-07-31 09:52:37 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:37 --> Controller Class Initialized
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:37 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:37 --> URI Class Initialized
INFO - 2023-07-31 09:52:37 --> Router Class Initialized
INFO - 2023-07-31 09:52:37 --> Output Class Initialized
INFO - 2023-07-31 09:52:37 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:37 --> Input Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Loader Class Initialized
INFO - 2023-07-31 09:52:37 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:37 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:52:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:37 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:37 --> Total execution time: 0.0337
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:37 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:37 --> URI Class Initialized
INFO - 2023-07-31 09:52:37 --> Router Class Initialized
INFO - 2023-07-31 09:52:37 --> Output Class Initialized
INFO - 2023-07-31 09:52:37 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:37 --> Input Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Language Class Initialized
INFO - 2023-07-31 09:52:37 --> Config Class Initialized
INFO - 2023-07-31 09:52:37 --> Loader Class Initialized
INFO - 2023-07-31 09:52:37 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:37 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:37 --> Controller Class Initialized
INFO - 2023-07-31 09:52:38 --> Config Class Initialized
INFO - 2023-07-31 09:52:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:38 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:38 --> URI Class Initialized
INFO - 2023-07-31 09:52:38 --> Router Class Initialized
INFO - 2023-07-31 09:52:38 --> Output Class Initialized
INFO - 2023-07-31 09:52:38 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:38 --> Input Class Initialized
INFO - 2023-07-31 09:52:38 --> Language Class Initialized
INFO - 2023-07-31 09:52:38 --> Language Class Initialized
INFO - 2023-07-31 09:52:38 --> Config Class Initialized
INFO - 2023-07-31 09:52:38 --> Loader Class Initialized
INFO - 2023-07-31 09:52:38 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:38 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:38 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:38 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:38 --> Controller Class Initialized
DEBUG - 2023-07-31 09:52:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:52:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:52:38 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:38 --> Total execution time: 0.0263
INFO - 2023-07-31 09:52:42 --> Config Class Initialized
INFO - 2023-07-31 09:52:42 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:52:42 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:52:42 --> Utf8 Class Initialized
INFO - 2023-07-31 09:52:42 --> URI Class Initialized
INFO - 2023-07-31 09:52:42 --> Router Class Initialized
INFO - 2023-07-31 09:52:42 --> Output Class Initialized
INFO - 2023-07-31 09:52:42 --> Security Class Initialized
DEBUG - 2023-07-31 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:52:42 --> Input Class Initialized
INFO - 2023-07-31 09:52:42 --> Language Class Initialized
INFO - 2023-07-31 09:52:42 --> Language Class Initialized
INFO - 2023-07-31 09:52:42 --> Config Class Initialized
INFO - 2023-07-31 09:52:42 --> Loader Class Initialized
INFO - 2023-07-31 09:52:42 --> Helper loaded: url_helper
INFO - 2023-07-31 09:52:42 --> Helper loaded: file_helper
INFO - 2023-07-31 09:52:42 --> Helper loaded: form_helper
INFO - 2023-07-31 09:52:42 --> Helper loaded: my_helper
INFO - 2023-07-31 09:52:42 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:52:42 --> Controller Class Initialized
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-07-31 09:52:42 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
INFO - 2023-07-31 09:52:42 --> Final output sent to browser
DEBUG - 2023-07-31 09:52:42 --> Total execution time: 0.1439
INFO - 2023-07-31 09:55:56 --> Config Class Initialized
INFO - 2023-07-31 09:55:56 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:55:56 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:55:56 --> Utf8 Class Initialized
INFO - 2023-07-31 09:55:56 --> URI Class Initialized
INFO - 2023-07-31 09:55:56 --> Router Class Initialized
INFO - 2023-07-31 09:55:56 --> Output Class Initialized
INFO - 2023-07-31 09:55:56 --> Security Class Initialized
DEBUG - 2023-07-31 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:55:56 --> Input Class Initialized
INFO - 2023-07-31 09:55:56 --> Language Class Initialized
INFO - 2023-07-31 09:55:56 --> Language Class Initialized
INFO - 2023-07-31 09:55:56 --> Config Class Initialized
INFO - 2023-07-31 09:55:56 --> Loader Class Initialized
INFO - 2023-07-31 09:55:56 --> Helper loaded: url_helper
INFO - 2023-07-31 09:55:56 --> Helper loaded: file_helper
INFO - 2023-07-31 09:55:56 --> Helper loaded: form_helper
INFO - 2023-07-31 09:55:56 --> Helper loaded: my_helper
INFO - 2023-07-31 09:55:56 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:55:56 --> Controller Class Initialized
DEBUG - 2023-07-31 09:55:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:55:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:55:56 --> Final output sent to browser
DEBUG - 2023-07-31 09:55:56 --> Total execution time: 0.0465
INFO - 2023-07-31 09:55:58 --> Config Class Initialized
INFO - 2023-07-31 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:55:58 --> Utf8 Class Initialized
INFO - 2023-07-31 09:55:58 --> URI Class Initialized
INFO - 2023-07-31 09:55:58 --> Router Class Initialized
INFO - 2023-07-31 09:55:58 --> Output Class Initialized
INFO - 2023-07-31 09:55:58 --> Security Class Initialized
DEBUG - 2023-07-31 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:55:58 --> Input Class Initialized
INFO - 2023-07-31 09:55:58 --> Language Class Initialized
INFO - 2023-07-31 09:55:58 --> Language Class Initialized
INFO - 2023-07-31 09:55:58 --> Config Class Initialized
INFO - 2023-07-31 09:55:58 --> Loader Class Initialized
INFO - 2023-07-31 09:55:58 --> Helper loaded: url_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: file_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: form_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: my_helper
INFO - 2023-07-31 09:55:58 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:55:58 --> Controller Class Initialized
DEBUG - 2023-07-31 09:55:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:55:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:55:58 --> Final output sent to browser
DEBUG - 2023-07-31 09:55:58 --> Total execution time: 0.0277
INFO - 2023-07-31 09:55:58 --> Config Class Initialized
INFO - 2023-07-31 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:55:58 --> Utf8 Class Initialized
INFO - 2023-07-31 09:55:58 --> URI Class Initialized
INFO - 2023-07-31 09:55:58 --> Router Class Initialized
INFO - 2023-07-31 09:55:58 --> Output Class Initialized
INFO - 2023-07-31 09:55:58 --> Security Class Initialized
DEBUG - 2023-07-31 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:55:58 --> Input Class Initialized
INFO - 2023-07-31 09:55:58 --> Language Class Initialized
INFO - 2023-07-31 09:55:58 --> Language Class Initialized
INFO - 2023-07-31 09:55:58 --> Config Class Initialized
INFO - 2023-07-31 09:55:58 --> Loader Class Initialized
INFO - 2023-07-31 09:55:58 --> Helper loaded: url_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: file_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: form_helper
INFO - 2023-07-31 09:55:58 --> Helper loaded: my_helper
INFO - 2023-07-31 09:55:58 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:55:58 --> Controller Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:56:00 --> Utf8 Class Initialized
INFO - 2023-07-31 09:56:00 --> URI Class Initialized
INFO - 2023-07-31 09:56:00 --> Router Class Initialized
INFO - 2023-07-31 09:56:00 --> Output Class Initialized
INFO - 2023-07-31 09:56:00 --> Security Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:56:00 --> Input Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Loader Class Initialized
INFO - 2023-07-31 09:56:00 --> Helper loaded: url_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: file_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: form_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: my_helper
INFO - 2023-07-31 09:56:00 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:56:00 --> Controller Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:56:00 --> Utf8 Class Initialized
INFO - 2023-07-31 09:56:00 --> URI Class Initialized
INFO - 2023-07-31 09:56:00 --> Router Class Initialized
INFO - 2023-07-31 09:56:00 --> Output Class Initialized
INFO - 2023-07-31 09:56:00 --> Security Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:56:00 --> Input Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Loader Class Initialized
INFO - 2023-07-31 09:56:00 --> Helper loaded: url_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: file_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: form_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: my_helper
INFO - 2023-07-31 09:56:00 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:56:00 --> Controller Class Initialized
DEBUG - 2023-07-31 09:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:56:00 --> Final output sent to browser
DEBUG - 2023-07-31 09:56:00 --> Total execution time: 0.0424
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:56:00 --> Utf8 Class Initialized
INFO - 2023-07-31 09:56:00 --> URI Class Initialized
INFO - 2023-07-31 09:56:00 --> Router Class Initialized
INFO - 2023-07-31 09:56:00 --> Output Class Initialized
INFO - 2023-07-31 09:56:00 --> Security Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:56:00 --> Input Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Loader Class Initialized
INFO - 2023-07-31 09:56:00 --> Helper loaded: url_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: file_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: form_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: my_helper
INFO - 2023-07-31 09:56:00 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:56:00 --> Controller Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:56:00 --> Utf8 Class Initialized
INFO - 2023-07-31 09:56:00 --> URI Class Initialized
INFO - 2023-07-31 09:56:00 --> Router Class Initialized
INFO - 2023-07-31 09:56:00 --> Output Class Initialized
INFO - 2023-07-31 09:56:00 --> Security Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:56:00 --> Input Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Language Class Initialized
INFO - 2023-07-31 09:56:00 --> Config Class Initialized
INFO - 2023-07-31 09:56:00 --> Loader Class Initialized
INFO - 2023-07-31 09:56:00 --> Helper loaded: url_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: file_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: form_helper
INFO - 2023-07-31 09:56:00 --> Helper loaded: my_helper
INFO - 2023-07-31 09:56:00 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:56:00 --> Controller Class Initialized
DEBUG - 2023-07-31 09:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:56:00 --> Final output sent to browser
DEBUG - 2023-07-31 09:56:00 --> Total execution time: 0.0368
INFO - 2023-07-31 09:56:03 --> Config Class Initialized
INFO - 2023-07-31 09:56:03 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:56:03 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:56:03 --> Utf8 Class Initialized
INFO - 2023-07-31 09:56:03 --> URI Class Initialized
INFO - 2023-07-31 09:56:03 --> Router Class Initialized
INFO - 2023-07-31 09:56:03 --> Output Class Initialized
INFO - 2023-07-31 09:56:03 --> Security Class Initialized
DEBUG - 2023-07-31 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:56:03 --> Input Class Initialized
INFO - 2023-07-31 09:56:03 --> Language Class Initialized
INFO - 2023-07-31 09:56:03 --> Language Class Initialized
INFO - 2023-07-31 09:56:03 --> Config Class Initialized
INFO - 2023-07-31 09:56:03 --> Loader Class Initialized
INFO - 2023-07-31 09:56:03 --> Helper loaded: url_helper
INFO - 2023-07-31 09:56:03 --> Helper loaded: file_helper
INFO - 2023-07-31 09:56:03 --> Helper loaded: form_helper
INFO - 2023-07-31 09:56:03 --> Helper loaded: my_helper
INFO - 2023-07-31 09:56:03 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:56:03 --> Controller Class Initialized
ERROR - 2023-07-31 09:56:03 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa C:\xampp\htdocs\myraportk13\bintaro\primary\application\third_party\PHP_Excel\PHPExcel.php 711
INFO - 2023-07-31 09:57:00 --> Config Class Initialized
INFO - 2023-07-31 09:57:00 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:00 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:00 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:00 --> URI Class Initialized
INFO - 2023-07-31 09:57:00 --> Router Class Initialized
INFO - 2023-07-31 09:57:00 --> Output Class Initialized
INFO - 2023-07-31 09:57:00 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:00 --> Input Class Initialized
INFO - 2023-07-31 09:57:00 --> Language Class Initialized
INFO - 2023-07-31 09:57:00 --> Language Class Initialized
INFO - 2023-07-31 09:57:00 --> Config Class Initialized
INFO - 2023-07-31 09:57:00 --> Loader Class Initialized
INFO - 2023-07-31 09:57:00 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:00 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:00 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:00 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:00 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:00 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:57:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:00 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:00 --> Total execution time: 0.0474
INFO - 2023-07-31 09:57:02 --> Config Class Initialized
INFO - 2023-07-31 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:02 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:02 --> URI Class Initialized
INFO - 2023-07-31 09:57:02 --> Router Class Initialized
INFO - 2023-07-31 09:57:02 --> Output Class Initialized
INFO - 2023-07-31 09:57:02 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:02 --> Input Class Initialized
INFO - 2023-07-31 09:57:02 --> Language Class Initialized
INFO - 2023-07-31 09:57:02 --> Language Class Initialized
INFO - 2023-07-31 09:57:02 --> Config Class Initialized
INFO - 2023-07-31 09:57:02 --> Loader Class Initialized
INFO - 2023-07-31 09:57:02 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:02 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:02 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:02 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:02 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:02 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:57:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:02 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:02 --> Total execution time: 0.0262
INFO - 2023-07-31 09:57:05 --> Config Class Initialized
INFO - 2023-07-31 09:57:05 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:05 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:05 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:05 --> URI Class Initialized
INFO - 2023-07-31 09:57:05 --> Router Class Initialized
INFO - 2023-07-31 09:57:05 --> Output Class Initialized
INFO - 2023-07-31 09:57:05 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:05 --> Input Class Initialized
INFO - 2023-07-31 09:57:05 --> Language Class Initialized
INFO - 2023-07-31 09:57:05 --> Language Class Initialized
INFO - 2023-07-31 09:57:05 --> Config Class Initialized
INFO - 2023-07-31 09:57:05 --> Loader Class Initialized
INFO - 2023-07-31 09:57:05 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:05 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:05 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:05 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:05 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:05 --> Controller Class Initialized
INFO - 2023-07-31 09:57:05 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:05 --> Total execution time: 0.0998
INFO - 2023-07-31 09:57:30 --> Config Class Initialized
INFO - 2023-07-31 09:57:30 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:30 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:30 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:30 --> URI Class Initialized
INFO - 2023-07-31 09:57:30 --> Router Class Initialized
INFO - 2023-07-31 09:57:30 --> Output Class Initialized
INFO - 2023-07-31 09:57:30 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:30 --> Input Class Initialized
INFO - 2023-07-31 09:57:30 --> Language Class Initialized
INFO - 2023-07-31 09:57:30 --> Language Class Initialized
INFO - 2023-07-31 09:57:30 --> Config Class Initialized
INFO - 2023-07-31 09:57:30 --> Loader Class Initialized
INFO - 2023-07-31 09:57:30 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:30 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:30 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:30 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:30 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:30 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:30 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:30 --> Total execution time: 0.0387
INFO - 2023-07-31 09:57:32 --> Config Class Initialized
INFO - 2023-07-31 09:57:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:32 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:32 --> URI Class Initialized
INFO - 2023-07-31 09:57:32 --> Router Class Initialized
INFO - 2023-07-31 09:57:32 --> Output Class Initialized
INFO - 2023-07-31 09:57:32 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:32 --> Input Class Initialized
INFO - 2023-07-31 09:57:32 --> Language Class Initialized
INFO - 2023-07-31 09:57:32 --> Language Class Initialized
INFO - 2023-07-31 09:57:32 --> Config Class Initialized
INFO - 2023-07-31 09:57:32 --> Loader Class Initialized
INFO - 2023-07-31 09:57:32 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:32 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:57:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:32 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:32 --> Total execution time: 0.0241
INFO - 2023-07-31 09:57:32 --> Config Class Initialized
INFO - 2023-07-31 09:57:32 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:32 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:32 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:32 --> URI Class Initialized
INFO - 2023-07-31 09:57:32 --> Router Class Initialized
INFO - 2023-07-31 09:57:32 --> Output Class Initialized
INFO - 2023-07-31 09:57:32 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:32 --> Input Class Initialized
INFO - 2023-07-31 09:57:32 --> Language Class Initialized
INFO - 2023-07-31 09:57:32 --> Language Class Initialized
INFO - 2023-07-31 09:57:32 --> Config Class Initialized
INFO - 2023-07-31 09:57:32 --> Loader Class Initialized
INFO - 2023-07-31 09:57:32 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:32 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:32 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:32 --> Controller Class Initialized
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:34 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:34 --> URI Class Initialized
INFO - 2023-07-31 09:57:34 --> Router Class Initialized
INFO - 2023-07-31 09:57:34 --> Output Class Initialized
INFO - 2023-07-31 09:57:34 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:34 --> Input Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Loader Class Initialized
INFO - 2023-07-31 09:57:34 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:34 --> Controller Class Initialized
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:34 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:34 --> URI Class Initialized
INFO - 2023-07-31 09:57:34 --> Router Class Initialized
INFO - 2023-07-31 09:57:34 --> Output Class Initialized
INFO - 2023-07-31 09:57:34 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:34 --> Input Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Loader Class Initialized
INFO - 2023-07-31 09:57:34 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:34 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:57:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:34 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:34 --> Total execution time: 0.0341
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:34 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:34 --> URI Class Initialized
INFO - 2023-07-31 09:57:34 --> Router Class Initialized
INFO - 2023-07-31 09:57:34 --> Output Class Initialized
INFO - 2023-07-31 09:57:34 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:34 --> Input Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Language Class Initialized
INFO - 2023-07-31 09:57:34 --> Config Class Initialized
INFO - 2023-07-31 09:57:34 --> Loader Class Initialized
INFO - 2023-07-31 09:57:34 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:34 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:34 --> Controller Class Initialized
INFO - 2023-07-31 09:57:35 --> Config Class Initialized
INFO - 2023-07-31 09:57:35 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:35 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:35 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:35 --> URI Class Initialized
INFO - 2023-07-31 09:57:35 --> Router Class Initialized
INFO - 2023-07-31 09:57:35 --> Output Class Initialized
INFO - 2023-07-31 09:57:35 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:35 --> Input Class Initialized
INFO - 2023-07-31 09:57:35 --> Language Class Initialized
INFO - 2023-07-31 09:57:35 --> Language Class Initialized
INFO - 2023-07-31 09:57:35 --> Config Class Initialized
INFO - 2023-07-31 09:57:35 --> Loader Class Initialized
INFO - 2023-07-31 09:57:35 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:35 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:35 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:35 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:35 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:35 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:57:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:35 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:35 --> Total execution time: 0.0289
INFO - 2023-07-31 09:57:38 --> Config Class Initialized
INFO - 2023-07-31 09:57:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:38 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:38 --> URI Class Initialized
INFO - 2023-07-31 09:57:38 --> Router Class Initialized
INFO - 2023-07-31 09:57:38 --> Output Class Initialized
INFO - 2023-07-31 09:57:38 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:38 --> Input Class Initialized
INFO - 2023-07-31 09:57:38 --> Language Class Initialized
INFO - 2023-07-31 09:57:38 --> Language Class Initialized
INFO - 2023-07-31 09:57:38 --> Config Class Initialized
INFO - 2023-07-31 09:57:38 --> Loader Class Initialized
INFO - 2023-07-31 09:57:38 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:38 --> Controller Class Initialized
INFO - 2023-07-31 09:57:38 --> Config Class Initialized
INFO - 2023-07-31 09:57:38 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:38 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:38 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:38 --> URI Class Initialized
INFO - 2023-07-31 09:57:38 --> Router Class Initialized
INFO - 2023-07-31 09:57:38 --> Output Class Initialized
INFO - 2023-07-31 09:57:38 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:38 --> Input Class Initialized
INFO - 2023-07-31 09:57:38 --> Language Class Initialized
INFO - 2023-07-31 09:57:38 --> Language Class Initialized
INFO - 2023-07-31 09:57:38 --> Config Class Initialized
INFO - 2023-07-31 09:57:38 --> Loader Class Initialized
INFO - 2023-07-31 09:57:38 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:38 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:38 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:38 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 09:57:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:38 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:38 --> Total execution time: 0.0218
INFO - 2023-07-31 09:57:39 --> Config Class Initialized
INFO - 2023-07-31 09:57:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:39 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:39 --> URI Class Initialized
INFO - 2023-07-31 09:57:39 --> Router Class Initialized
INFO - 2023-07-31 09:57:39 --> Output Class Initialized
INFO - 2023-07-31 09:57:39 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:39 --> Input Class Initialized
INFO - 2023-07-31 09:57:39 --> Language Class Initialized
INFO - 2023-07-31 09:57:39 --> Language Class Initialized
INFO - 2023-07-31 09:57:39 --> Config Class Initialized
INFO - 2023-07-31 09:57:39 --> Loader Class Initialized
INFO - 2023-07-31 09:57:39 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:39 --> Controller Class Initialized
DEBUG - 2023-07-31 09:57:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 09:57:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:39 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:39 --> Total execution time: 0.0265
INFO - 2023-07-31 09:57:39 --> Config Class Initialized
INFO - 2023-07-31 09:57:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:39 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:39 --> URI Class Initialized
INFO - 2023-07-31 09:57:39 --> Router Class Initialized
INFO - 2023-07-31 09:57:39 --> Output Class Initialized
INFO - 2023-07-31 09:57:39 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:39 --> Input Class Initialized
INFO - 2023-07-31 09:57:39 --> Language Class Initialized
INFO - 2023-07-31 09:57:39 --> Language Class Initialized
INFO - 2023-07-31 09:57:39 --> Config Class Initialized
INFO - 2023-07-31 09:57:39 --> Loader Class Initialized
INFO - 2023-07-31 09:57:39 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:39 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:39 --> Controller Class Initialized
INFO - 2023-07-31 09:57:40 --> Config Class Initialized
INFO - 2023-07-31 09:57:40 --> Hooks Class Initialized
DEBUG - 2023-07-31 09:57:40 --> UTF-8 Support Enabled
INFO - 2023-07-31 09:57:40 --> Utf8 Class Initialized
INFO - 2023-07-31 09:57:40 --> URI Class Initialized
INFO - 2023-07-31 09:57:40 --> Router Class Initialized
INFO - 2023-07-31 09:57:40 --> Output Class Initialized
INFO - 2023-07-31 09:57:40 --> Security Class Initialized
DEBUG - 2023-07-31 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 09:57:40 --> Input Class Initialized
INFO - 2023-07-31 09:57:40 --> Language Class Initialized
INFO - 2023-07-31 09:57:40 --> Language Class Initialized
INFO - 2023-07-31 09:57:40 --> Config Class Initialized
INFO - 2023-07-31 09:57:40 --> Loader Class Initialized
INFO - 2023-07-31 09:57:40 --> Helper loaded: url_helper
INFO - 2023-07-31 09:57:40 --> Helper loaded: file_helper
INFO - 2023-07-31 09:57:40 --> Helper loaded: form_helper
INFO - 2023-07-31 09:57:40 --> Helper loaded: my_helper
INFO - 2023-07-31 09:57:40 --> Database Driver Class Initialized
DEBUG - 2023-07-31 09:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 09:57:40 --> Controller Class Initialized
ERROR - 2023-07-31 09:57:40 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-31 09:57:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-31 09:57:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 09:57:40 --> Final output sent to browser
DEBUG - 2023-07-31 09:57:40 --> Total execution time: 0.0477
INFO - 2023-07-31 10:01:31 --> Config Class Initialized
INFO - 2023-07-31 10:01:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:31 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:31 --> URI Class Initialized
INFO - 2023-07-31 10:01:31 --> Router Class Initialized
INFO - 2023-07-31 10:01:31 --> Output Class Initialized
INFO - 2023-07-31 10:01:31 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:31 --> Input Class Initialized
INFO - 2023-07-31 10:01:31 --> Language Class Initialized
INFO - 2023-07-31 10:01:31 --> Language Class Initialized
INFO - 2023-07-31 10:01:31 --> Config Class Initialized
INFO - 2023-07-31 10:01:31 --> Loader Class Initialized
INFO - 2023-07-31 10:01:31 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:31 --> Controller Class Initialized
DEBUG - 2023-07-31 10:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:01:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:01:31 --> Final output sent to browser
DEBUG - 2023-07-31 10:01:31 --> Total execution time: 0.0798
INFO - 2023-07-31 10:01:31 --> Config Class Initialized
INFO - 2023-07-31 10:01:31 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:31 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:31 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:31 --> URI Class Initialized
INFO - 2023-07-31 10:01:31 --> Router Class Initialized
INFO - 2023-07-31 10:01:31 --> Output Class Initialized
INFO - 2023-07-31 10:01:31 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:31 --> Input Class Initialized
INFO - 2023-07-31 10:01:31 --> Language Class Initialized
INFO - 2023-07-31 10:01:31 --> Language Class Initialized
INFO - 2023-07-31 10:01:31 --> Config Class Initialized
INFO - 2023-07-31 10:01:31 --> Loader Class Initialized
INFO - 2023-07-31 10:01:31 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:31 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:31 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:31 --> Controller Class Initialized
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:33 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:33 --> URI Class Initialized
INFO - 2023-07-31 10:01:33 --> Router Class Initialized
INFO - 2023-07-31 10:01:33 --> Output Class Initialized
INFO - 2023-07-31 10:01:33 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:33 --> Input Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Loader Class Initialized
INFO - 2023-07-31 10:01:33 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:33 --> Controller Class Initialized
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:33 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:33 --> URI Class Initialized
INFO - 2023-07-31 10:01:33 --> Router Class Initialized
INFO - 2023-07-31 10:01:33 --> Output Class Initialized
INFO - 2023-07-31 10:01:33 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:33 --> Input Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Loader Class Initialized
INFO - 2023-07-31 10:01:33 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:33 --> Controller Class Initialized
DEBUG - 2023-07-31 10:01:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:01:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:01:33 --> Final output sent to browser
DEBUG - 2023-07-31 10:01:33 --> Total execution time: 0.0403
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:33 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:33 --> URI Class Initialized
INFO - 2023-07-31 10:01:33 --> Router Class Initialized
INFO - 2023-07-31 10:01:33 --> Output Class Initialized
INFO - 2023-07-31 10:01:33 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:33 --> Input Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Language Class Initialized
INFO - 2023-07-31 10:01:33 --> Config Class Initialized
INFO - 2023-07-31 10:01:33 --> Loader Class Initialized
INFO - 2023-07-31 10:01:33 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:33 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:33 --> Controller Class Initialized
INFO - 2023-07-31 10:01:34 --> Config Class Initialized
INFO - 2023-07-31 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:34 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:34 --> URI Class Initialized
INFO - 2023-07-31 10:01:34 --> Router Class Initialized
INFO - 2023-07-31 10:01:34 --> Output Class Initialized
INFO - 2023-07-31 10:01:34 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:34 --> Input Class Initialized
INFO - 2023-07-31 10:01:34 --> Language Class Initialized
INFO - 2023-07-31 10:01:34 --> Language Class Initialized
INFO - 2023-07-31 10:01:34 --> Config Class Initialized
INFO - 2023-07-31 10:01:34 --> Loader Class Initialized
INFO - 2023-07-31 10:01:34 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:34 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:34 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:34 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:34 --> Controller Class Initialized
DEBUG - 2023-07-31 10:01:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 10:01:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:01:34 --> Final output sent to browser
DEBUG - 2023-07-31 10:01:34 --> Total execution time: 0.0342
INFO - 2023-07-31 10:01:37 --> Config Class Initialized
INFO - 2023-07-31 10:01:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:01:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:01:37 --> Utf8 Class Initialized
INFO - 2023-07-31 10:01:37 --> URI Class Initialized
INFO - 2023-07-31 10:01:37 --> Router Class Initialized
INFO - 2023-07-31 10:01:37 --> Output Class Initialized
INFO - 2023-07-31 10:01:37 --> Security Class Initialized
DEBUG - 2023-07-31 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:01:37 --> Input Class Initialized
INFO - 2023-07-31 10:01:37 --> Language Class Initialized
INFO - 2023-07-31 10:01:37 --> Language Class Initialized
INFO - 2023-07-31 10:01:37 --> Config Class Initialized
INFO - 2023-07-31 10:01:37 --> Loader Class Initialized
INFO - 2023-07-31 10:01:37 --> Helper loaded: url_helper
INFO - 2023-07-31 10:01:37 --> Helper loaded: file_helper
INFO - 2023-07-31 10:01:37 --> Helper loaded: form_helper
INFO - 2023-07-31 10:01:37 --> Helper loaded: my_helper
INFO - 2023-07-31 10:01:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:01:37 --> Controller Class Initialized
ERROR - 2023-07-31 10:01:37 --> Severity: error --> Exception: Call to a member function getValue() on float C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\controllers\Data_siswa.php 247
INFO - 2023-07-31 10:04:33 --> Config Class Initialized
INFO - 2023-07-31 10:04:33 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:33 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:33 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:33 --> URI Class Initialized
INFO - 2023-07-31 10:04:33 --> Router Class Initialized
INFO - 2023-07-31 10:04:33 --> Output Class Initialized
INFO - 2023-07-31 10:04:33 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:33 --> Input Class Initialized
INFO - 2023-07-31 10:04:33 --> Language Class Initialized
INFO - 2023-07-31 10:04:33 --> Language Class Initialized
INFO - 2023-07-31 10:04:33 --> Config Class Initialized
INFO - 2023-07-31 10:04:33 --> Loader Class Initialized
INFO - 2023-07-31 10:04:33 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:33 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:33 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:33 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:33 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:33 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 10:04:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:33 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:33 --> Total execution time: 0.0728
INFO - 2023-07-31 10:04:34 --> Config Class Initialized
INFO - 2023-07-31 10:04:34 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:34 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:34 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:34 --> URI Class Initialized
INFO - 2023-07-31 10:04:34 --> Router Class Initialized
INFO - 2023-07-31 10:04:34 --> Output Class Initialized
INFO - 2023-07-31 10:04:34 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:34 --> Input Class Initialized
INFO - 2023-07-31 10:04:34 --> Language Class Initialized
INFO - 2023-07-31 10:04:34 --> Language Class Initialized
INFO - 2023-07-31 10:04:34 --> Config Class Initialized
INFO - 2023-07-31 10:04:34 --> Loader Class Initialized
INFO - 2023-07-31 10:04:34 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:34 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:34 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:34 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:34 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:34 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 10:04:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:34 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:34 --> Total execution time: 0.0240
INFO - 2023-07-31 10:04:37 --> Config Class Initialized
INFO - 2023-07-31 10:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:37 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:37 --> URI Class Initialized
INFO - 2023-07-31 10:04:37 --> Router Class Initialized
INFO - 2023-07-31 10:04:37 --> Output Class Initialized
INFO - 2023-07-31 10:04:37 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:37 --> Input Class Initialized
INFO - 2023-07-31 10:04:37 --> Language Class Initialized
INFO - 2023-07-31 10:04:37 --> Language Class Initialized
INFO - 2023-07-31 10:04:37 --> Config Class Initialized
INFO - 2023-07-31 10:04:37 --> Loader Class Initialized
INFO - 2023-07-31 10:04:37 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:37 --> Controller Class Initialized
INFO - 2023-07-31 10:04:37 --> Config Class Initialized
INFO - 2023-07-31 10:04:37 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:37 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:37 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:37 --> URI Class Initialized
INFO - 2023-07-31 10:04:37 --> Router Class Initialized
INFO - 2023-07-31 10:04:37 --> Output Class Initialized
INFO - 2023-07-31 10:04:37 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:37 --> Input Class Initialized
INFO - 2023-07-31 10:04:37 --> Language Class Initialized
INFO - 2023-07-31 10:04:37 --> Language Class Initialized
INFO - 2023-07-31 10:04:37 --> Config Class Initialized
INFO - 2023-07-31 10:04:37 --> Loader Class Initialized
INFO - 2023-07-31 10:04:37 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:37 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:37 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:37 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-31 10:04:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:37 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:37 --> Total execution time: 0.0388
INFO - 2023-07-31 10:04:39 --> Config Class Initialized
INFO - 2023-07-31 10:04:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:39 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:39 --> URI Class Initialized
INFO - 2023-07-31 10:04:39 --> Router Class Initialized
INFO - 2023-07-31 10:04:39 --> Output Class Initialized
INFO - 2023-07-31 10:04:39 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:39 --> Input Class Initialized
INFO - 2023-07-31 10:04:39 --> Language Class Initialized
INFO - 2023-07-31 10:04:39 --> Language Class Initialized
INFO - 2023-07-31 10:04:39 --> Config Class Initialized
INFO - 2023-07-31 10:04:39 --> Loader Class Initialized
INFO - 2023-07-31 10:04:39 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:39 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:04:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:39 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:39 --> Total execution time: 0.0255
INFO - 2023-07-31 10:04:39 --> Config Class Initialized
INFO - 2023-07-31 10:04:39 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:39 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:39 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:39 --> URI Class Initialized
INFO - 2023-07-31 10:04:39 --> Router Class Initialized
INFO - 2023-07-31 10:04:39 --> Output Class Initialized
INFO - 2023-07-31 10:04:39 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:39 --> Input Class Initialized
INFO - 2023-07-31 10:04:39 --> Language Class Initialized
INFO - 2023-07-31 10:04:39 --> Language Class Initialized
INFO - 2023-07-31 10:04:39 --> Config Class Initialized
INFO - 2023-07-31 10:04:39 --> Loader Class Initialized
INFO - 2023-07-31 10:04:39 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:39 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:39 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:39 --> Controller Class Initialized
INFO - 2023-07-31 10:04:49 --> Config Class Initialized
INFO - 2023-07-31 10:04:49 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:49 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:49 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:49 --> URI Class Initialized
INFO - 2023-07-31 10:04:49 --> Router Class Initialized
INFO - 2023-07-31 10:04:49 --> Output Class Initialized
INFO - 2023-07-31 10:04:49 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:49 --> Input Class Initialized
INFO - 2023-07-31 10:04:49 --> Language Class Initialized
INFO - 2023-07-31 10:04:49 --> Language Class Initialized
INFO - 2023-07-31 10:04:49 --> Config Class Initialized
INFO - 2023-07-31 10:04:49 --> Loader Class Initialized
INFO - 2023-07-31 10:04:49 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:49 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:49 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:49 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:49 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:49 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-31 10:04:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:49 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:49 --> Total execution time: 0.0544
INFO - 2023-07-31 10:04:51 --> Config Class Initialized
INFO - 2023-07-31 10:04:51 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:51 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:51 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:52 --> URI Class Initialized
INFO - 2023-07-31 10:04:52 --> Router Class Initialized
INFO - 2023-07-31 10:04:52 --> Output Class Initialized
INFO - 2023-07-31 10:04:52 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:52 --> Input Class Initialized
INFO - 2023-07-31 10:04:52 --> Language Class Initialized
INFO - 2023-07-31 10:04:52 --> Language Class Initialized
INFO - 2023-07-31 10:04:52 --> Config Class Initialized
INFO - 2023-07-31 10:04:52 --> Loader Class Initialized
INFO - 2023-07-31 10:04:52 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:52 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:52 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:52 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:52 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:52 --> Controller Class Initialized
ERROR - 2023-07-31 10:04:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-31 10:04:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-31 10:04:52 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-07-31 10:04:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-31 10:04:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:52 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:52 --> Total execution time: 0.0325
INFO - 2023-07-31 10:04:53 --> Config Class Initialized
INFO - 2023-07-31 10:04:53 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:53 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:53 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:53 --> URI Class Initialized
DEBUG - 2023-07-31 10:04:53 --> No URI present. Default controller set.
INFO - 2023-07-31 10:04:53 --> Router Class Initialized
INFO - 2023-07-31 10:04:53 --> Output Class Initialized
INFO - 2023-07-31 10:04:53 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:53 --> Input Class Initialized
INFO - 2023-07-31 10:04:53 --> Language Class Initialized
INFO - 2023-07-31 10:04:53 --> Language Class Initialized
INFO - 2023-07-31 10:04:53 --> Config Class Initialized
INFO - 2023-07-31 10:04:53 --> Loader Class Initialized
INFO - 2023-07-31 10:04:53 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:53 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:53 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:53 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:53 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:53 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-31 10:04:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:53 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:53 --> Total execution time: 0.0334
INFO - 2023-07-31 10:04:54 --> Config Class Initialized
INFO - 2023-07-31 10:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:54 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:54 --> URI Class Initialized
INFO - 2023-07-31 10:04:54 --> Router Class Initialized
INFO - 2023-07-31 10:04:54 --> Output Class Initialized
INFO - 2023-07-31 10:04:54 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:54 --> Input Class Initialized
INFO - 2023-07-31 10:04:54 --> Language Class Initialized
INFO - 2023-07-31 10:04:54 --> Language Class Initialized
INFO - 2023-07-31 10:04:54 --> Config Class Initialized
INFO - 2023-07-31 10:04:54 --> Loader Class Initialized
INFO - 2023-07-31 10:04:54 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:54 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-31 10:04:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:54 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:54 --> Total execution time: 0.0464
INFO - 2023-07-31 10:04:54 --> Config Class Initialized
INFO - 2023-07-31 10:04:54 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:54 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:54 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:54 --> URI Class Initialized
INFO - 2023-07-31 10:04:54 --> Router Class Initialized
INFO - 2023-07-31 10:04:54 --> Output Class Initialized
INFO - 2023-07-31 10:04:54 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:54 --> Input Class Initialized
INFO - 2023-07-31 10:04:54 --> Language Class Initialized
INFO - 2023-07-31 10:04:54 --> Language Class Initialized
INFO - 2023-07-31 10:04:54 --> Config Class Initialized
INFO - 2023-07-31 10:04:54 --> Loader Class Initialized
INFO - 2023-07-31 10:04:54 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:54 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:54 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:54 --> Controller Class Initialized
INFO - 2023-07-31 10:04:55 --> Config Class Initialized
INFO - 2023-07-31 10:04:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:55 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:55 --> URI Class Initialized
INFO - 2023-07-31 10:04:55 --> Router Class Initialized
INFO - 2023-07-31 10:04:55 --> Output Class Initialized
INFO - 2023-07-31 10:04:55 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:55 --> Input Class Initialized
INFO - 2023-07-31 10:04:55 --> Language Class Initialized
INFO - 2023-07-31 10:04:55 --> Language Class Initialized
INFO - 2023-07-31 10:04:55 --> Config Class Initialized
INFO - 2023-07-31 10:04:55 --> Loader Class Initialized
INFO - 2023-07-31 10:04:55 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:55 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:04:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:55 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:55 --> Total execution time: 0.0409
INFO - 2023-07-31 10:04:55 --> Config Class Initialized
INFO - 2023-07-31 10:04:55 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:55 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:55 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:55 --> URI Class Initialized
INFO - 2023-07-31 10:04:55 --> Router Class Initialized
INFO - 2023-07-31 10:04:55 --> Output Class Initialized
INFO - 2023-07-31 10:04:55 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:55 --> Input Class Initialized
INFO - 2023-07-31 10:04:55 --> Language Class Initialized
INFO - 2023-07-31 10:04:55 --> Language Class Initialized
INFO - 2023-07-31 10:04:55 --> Config Class Initialized
INFO - 2023-07-31 10:04:55 --> Loader Class Initialized
INFO - 2023-07-31 10:04:55 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:55 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:55 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:55 --> Controller Class Initialized
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:57 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:57 --> URI Class Initialized
INFO - 2023-07-31 10:04:57 --> Router Class Initialized
INFO - 2023-07-31 10:04:57 --> Output Class Initialized
INFO - 2023-07-31 10:04:57 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:57 --> Input Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Loader Class Initialized
INFO - 2023-07-31 10:04:57 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:57 --> Controller Class Initialized
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:57 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:57 --> URI Class Initialized
INFO - 2023-07-31 10:04:57 --> Router Class Initialized
INFO - 2023-07-31 10:04:57 --> Output Class Initialized
INFO - 2023-07-31 10:04:57 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:57 --> Input Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Loader Class Initialized
INFO - 2023-07-31 10:04:57 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:57 --> Controller Class Initialized
DEBUG - 2023-07-31 10:04:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:04:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:04:57 --> Final output sent to browser
DEBUG - 2023-07-31 10:04:57 --> Total execution time: 0.0495
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:04:57 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:04:57 --> Utf8 Class Initialized
INFO - 2023-07-31 10:04:57 --> URI Class Initialized
INFO - 2023-07-31 10:04:57 --> Router Class Initialized
INFO - 2023-07-31 10:04:57 --> Output Class Initialized
INFO - 2023-07-31 10:04:57 --> Security Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:04:57 --> Input Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Language Class Initialized
INFO - 2023-07-31 10:04:57 --> Config Class Initialized
INFO - 2023-07-31 10:04:57 --> Loader Class Initialized
INFO - 2023-07-31 10:04:57 --> Helper loaded: url_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: file_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: form_helper
INFO - 2023-07-31 10:04:57 --> Helper loaded: my_helper
INFO - 2023-07-31 10:04:57 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:04:57 --> Controller Class Initialized
INFO - 2023-07-31 10:28:45 --> Config Class Initialized
INFO - 2023-07-31 10:28:45 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:28:45 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:28:45 --> Utf8 Class Initialized
INFO - 2023-07-31 10:28:45 --> URI Class Initialized
INFO - 2023-07-31 10:28:45 --> Router Class Initialized
INFO - 2023-07-31 10:28:45 --> Output Class Initialized
INFO - 2023-07-31 10:28:45 --> Security Class Initialized
DEBUG - 2023-07-31 10:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:28:45 --> Input Class Initialized
INFO - 2023-07-31 10:28:45 --> Language Class Initialized
INFO - 2023-07-31 10:28:45 --> Language Class Initialized
INFO - 2023-07-31 10:28:45 --> Config Class Initialized
INFO - 2023-07-31 10:28:45 --> Loader Class Initialized
INFO - 2023-07-31 10:28:45 --> Helper loaded: url_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: file_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: form_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: my_helper
INFO - 2023-07-31 10:28:45 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:28:45 --> Controller Class Initialized
DEBUG - 2023-07-31 10:28:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-31 10:28:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-31 10:28:45 --> Final output sent to browser
DEBUG - 2023-07-31 10:28:45 --> Total execution time: 0.0608
INFO - 2023-07-31 10:28:45 --> Config Class Initialized
INFO - 2023-07-31 10:28:45 --> Hooks Class Initialized
DEBUG - 2023-07-31 10:28:45 --> UTF-8 Support Enabled
INFO - 2023-07-31 10:28:45 --> Utf8 Class Initialized
INFO - 2023-07-31 10:28:45 --> URI Class Initialized
INFO - 2023-07-31 10:28:45 --> Router Class Initialized
INFO - 2023-07-31 10:28:45 --> Output Class Initialized
INFO - 2023-07-31 10:28:45 --> Security Class Initialized
DEBUG - 2023-07-31 10:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-31 10:28:45 --> Input Class Initialized
INFO - 2023-07-31 10:28:45 --> Language Class Initialized
INFO - 2023-07-31 10:28:45 --> Language Class Initialized
INFO - 2023-07-31 10:28:45 --> Config Class Initialized
INFO - 2023-07-31 10:28:45 --> Loader Class Initialized
INFO - 2023-07-31 10:28:45 --> Helper loaded: url_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: file_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: form_helper
INFO - 2023-07-31 10:28:45 --> Helper loaded: my_helper
INFO - 2023-07-31 10:28:45 --> Database Driver Class Initialized
DEBUG - 2023-07-31 10:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-31 10:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-31 10:28:45 --> Controller Class Initialized
