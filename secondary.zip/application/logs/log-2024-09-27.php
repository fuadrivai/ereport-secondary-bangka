<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-27 13:38:06 --> Config Class Initialized
INFO - 2024-09-27 13:38:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:38:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:38:06 --> Utf8 Class Initialized
INFO - 2024-09-27 13:38:06 --> URI Class Initialized
INFO - 2024-09-27 13:38:06 --> Router Class Initialized
INFO - 2024-09-27 13:38:06 --> Output Class Initialized
INFO - 2024-09-27 13:38:06 --> Security Class Initialized
DEBUG - 2024-09-27 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:38:06 --> Input Class Initialized
INFO - 2024-09-27 13:38:06 --> Language Class Initialized
INFO - 2024-09-27 13:38:06 --> Language Class Initialized
INFO - 2024-09-27 13:38:06 --> Config Class Initialized
INFO - 2024-09-27 13:38:06 --> Loader Class Initialized
INFO - 2024-09-27 13:38:06 --> Helper loaded: url_helper
INFO - 2024-09-27 13:38:06 --> Helper loaded: file_helper
INFO - 2024-09-27 13:38:06 --> Helper loaded: form_helper
INFO - 2024-09-27 13:38:06 --> Helper loaded: my_helper
INFO - 2024-09-27 13:38:06 --> Database Driver Class Initialized
INFO - 2024-09-27 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:38:06 --> Controller Class Initialized
INFO - 2024-09-27 13:38:06 --> Helper loaded: cookie_helper
INFO - 2024-09-27 13:38:06 --> Final output sent to browser
DEBUG - 2024-09-27 13:38:06 --> Total execution time: 0.0940
INFO - 2024-09-27 13:38:07 --> Config Class Initialized
INFO - 2024-09-27 13:38:07 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:38:07 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:38:07 --> Utf8 Class Initialized
INFO - 2024-09-27 13:38:07 --> URI Class Initialized
INFO - 2024-09-27 13:38:07 --> Router Class Initialized
INFO - 2024-09-27 13:38:07 --> Output Class Initialized
INFO - 2024-09-27 13:38:07 --> Security Class Initialized
DEBUG - 2024-09-27 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:38:07 --> Input Class Initialized
INFO - 2024-09-27 13:38:07 --> Language Class Initialized
INFO - 2024-09-27 13:38:07 --> Language Class Initialized
INFO - 2024-09-27 13:38:07 --> Config Class Initialized
INFO - 2024-09-27 13:38:07 --> Loader Class Initialized
INFO - 2024-09-27 13:38:07 --> Helper loaded: url_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: file_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: form_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: my_helper
INFO - 2024-09-27 13:38:07 --> Database Driver Class Initialized
INFO - 2024-09-27 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:38:07 --> Controller Class Initialized
INFO - 2024-09-27 13:38:07 --> Helper loaded: cookie_helper
INFO - 2024-09-27 13:38:07 --> Config Class Initialized
INFO - 2024-09-27 13:38:07 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:38:07 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:38:07 --> Utf8 Class Initialized
INFO - 2024-09-27 13:38:07 --> URI Class Initialized
INFO - 2024-09-27 13:38:07 --> Router Class Initialized
INFO - 2024-09-27 13:38:07 --> Output Class Initialized
INFO - 2024-09-27 13:38:07 --> Security Class Initialized
DEBUG - 2024-09-27 13:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:38:07 --> Input Class Initialized
INFO - 2024-09-27 13:38:07 --> Language Class Initialized
INFO - 2024-09-27 13:38:07 --> Language Class Initialized
INFO - 2024-09-27 13:38:07 --> Config Class Initialized
INFO - 2024-09-27 13:38:07 --> Loader Class Initialized
INFO - 2024-09-27 13:38:07 --> Helper loaded: url_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: file_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: form_helper
INFO - 2024-09-27 13:38:07 --> Helper loaded: my_helper
INFO - 2024-09-27 13:38:07 --> Database Driver Class Initialized
INFO - 2024-09-27 13:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:38:07 --> Controller Class Initialized
DEBUG - 2024-09-27 13:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-27 13:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-27 13:38:07 --> Final output sent to browser
DEBUG - 2024-09-27 13:38:07 --> Total execution time: 0.2476
INFO - 2024-09-27 13:38:09 --> Config Class Initialized
INFO - 2024-09-27 13:38:09 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:38:09 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:38:09 --> Utf8 Class Initialized
INFO - 2024-09-27 13:38:09 --> URI Class Initialized
INFO - 2024-09-27 13:38:09 --> Router Class Initialized
INFO - 2024-09-27 13:38:09 --> Output Class Initialized
INFO - 2024-09-27 13:38:09 --> Security Class Initialized
DEBUG - 2024-09-27 13:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:38:09 --> Input Class Initialized
INFO - 2024-09-27 13:38:09 --> Language Class Initialized
INFO - 2024-09-27 13:38:09 --> Language Class Initialized
INFO - 2024-09-27 13:38:09 --> Config Class Initialized
INFO - 2024-09-27 13:38:09 --> Loader Class Initialized
INFO - 2024-09-27 13:38:09 --> Helper loaded: url_helper
INFO - 2024-09-27 13:38:09 --> Helper loaded: file_helper
INFO - 2024-09-27 13:38:09 --> Helper loaded: form_helper
INFO - 2024-09-27 13:38:09 --> Helper loaded: my_helper
INFO - 2024-09-27 13:38:09 --> Database Driver Class Initialized
INFO - 2024-09-27 13:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:38:09 --> Controller Class Initialized
ERROR - 2024-09-27 13:38:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-27 13:38:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-27 13:38:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-27 13:38:12 --> Final output sent to browser
DEBUG - 2024-09-27 13:38:12 --> Total execution time: 2.4862
INFO - 2024-09-27 13:38:21 --> Config Class Initialized
INFO - 2024-09-27 13:38:21 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:38:21 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:38:21 --> Utf8 Class Initialized
INFO - 2024-09-27 13:38:21 --> URI Class Initialized
INFO - 2024-09-27 13:38:21 --> Router Class Initialized
INFO - 2024-09-27 13:38:21 --> Output Class Initialized
INFO - 2024-09-27 13:38:21 --> Security Class Initialized
DEBUG - 2024-09-27 13:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:38:21 --> Input Class Initialized
INFO - 2024-09-27 13:38:21 --> Language Class Initialized
INFO - 2024-09-27 13:38:21 --> Language Class Initialized
INFO - 2024-09-27 13:38:21 --> Config Class Initialized
INFO - 2024-09-27 13:38:21 --> Loader Class Initialized
INFO - 2024-09-27 13:38:21 --> Helper loaded: url_helper
INFO - 2024-09-27 13:38:21 --> Helper loaded: file_helper
INFO - 2024-09-27 13:38:21 --> Helper loaded: form_helper
INFO - 2024-09-27 13:38:21 --> Helper loaded: my_helper
INFO - 2024-09-27 13:38:21 --> Database Driver Class Initialized
INFO - 2024-09-27 13:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:38:21 --> Controller Class Initialized
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-27 13:38:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-27 13:38:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-27 13:38:24 --> Final output sent to browser
DEBUG - 2024-09-27 13:38:24 --> Total execution time: 2.7499
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:46:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:46:06 --> Utf8 Class Initialized
INFO - 2024-09-27 13:46:06 --> URI Class Initialized
INFO - 2024-09-27 13:46:06 --> Router Class Initialized
INFO - 2024-09-27 13:46:06 --> Output Class Initialized
INFO - 2024-09-27 13:46:06 --> Security Class Initialized
DEBUG - 2024-09-27 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:46:06 --> Input Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Loader Class Initialized
INFO - 2024-09-27 13:46:06 --> Helper loaded: url_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: file_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: form_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: my_helper
INFO - 2024-09-27 13:46:06 --> Database Driver Class Initialized
INFO - 2024-09-27 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:46:06 --> Controller Class Initialized
INFO - 2024-09-27 13:46:06 --> Helper loaded: cookie_helper
INFO - 2024-09-27 13:46:06 --> Final output sent to browser
DEBUG - 2024-09-27 13:46:06 --> Total execution time: 0.0301
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:46:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:46:06 --> Utf8 Class Initialized
INFO - 2024-09-27 13:46:06 --> URI Class Initialized
INFO - 2024-09-27 13:46:06 --> Router Class Initialized
INFO - 2024-09-27 13:46:06 --> Output Class Initialized
INFO - 2024-09-27 13:46:06 --> Security Class Initialized
DEBUG - 2024-09-27 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:46:06 --> Input Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Loader Class Initialized
INFO - 2024-09-27 13:46:06 --> Helper loaded: url_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: file_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: form_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: my_helper
INFO - 2024-09-27 13:46:06 --> Database Driver Class Initialized
INFO - 2024-09-27 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:46:06 --> Controller Class Initialized
INFO - 2024-09-27 13:46:06 --> Helper loaded: cookie_helper
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:46:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:46:06 --> Utf8 Class Initialized
INFO - 2024-09-27 13:46:06 --> URI Class Initialized
INFO - 2024-09-27 13:46:06 --> Router Class Initialized
INFO - 2024-09-27 13:46:06 --> Output Class Initialized
INFO - 2024-09-27 13:46:06 --> Security Class Initialized
DEBUG - 2024-09-27 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:46:06 --> Input Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Language Class Initialized
INFO - 2024-09-27 13:46:06 --> Config Class Initialized
INFO - 2024-09-27 13:46:06 --> Loader Class Initialized
INFO - 2024-09-27 13:46:06 --> Helper loaded: url_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: file_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: form_helper
INFO - 2024-09-27 13:46:06 --> Helper loaded: my_helper
INFO - 2024-09-27 13:46:06 --> Database Driver Class Initialized
INFO - 2024-09-27 13:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:46:06 --> Controller Class Initialized
DEBUG - 2024-09-27 13:46:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-27 13:46:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-27 13:46:06 --> Final output sent to browser
DEBUG - 2024-09-27 13:46:06 --> Total execution time: 0.0318
INFO - 2024-09-27 13:46:15 --> Config Class Initialized
INFO - 2024-09-27 13:46:15 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:46:15 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:46:15 --> Utf8 Class Initialized
INFO - 2024-09-27 13:46:15 --> URI Class Initialized
INFO - 2024-09-27 13:46:15 --> Router Class Initialized
INFO - 2024-09-27 13:46:15 --> Output Class Initialized
INFO - 2024-09-27 13:46:15 --> Security Class Initialized
DEBUG - 2024-09-27 13:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:46:15 --> Input Class Initialized
INFO - 2024-09-27 13:46:15 --> Language Class Initialized
INFO - 2024-09-27 13:46:15 --> Language Class Initialized
INFO - 2024-09-27 13:46:15 --> Config Class Initialized
INFO - 2024-09-27 13:46:15 --> Loader Class Initialized
INFO - 2024-09-27 13:46:15 --> Helper loaded: url_helper
INFO - 2024-09-27 13:46:15 --> Helper loaded: file_helper
INFO - 2024-09-27 13:46:15 --> Helper loaded: form_helper
INFO - 2024-09-27 13:46:15 --> Helper loaded: my_helper
INFO - 2024-09-27 13:46:15 --> Database Driver Class Initialized
INFO - 2024-09-27 13:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:46:15 --> Controller Class Initialized
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-27 13:46:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-27 13:46:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-27 13:46:17 --> Final output sent to browser
DEBUG - 2024-09-27 13:46:17 --> Total execution time: 2.3854
INFO - 2024-09-27 13:46:42 --> Config Class Initialized
INFO - 2024-09-27 13:46:42 --> Hooks Class Initialized
DEBUG - 2024-09-27 13:46:42 --> UTF-8 Support Enabled
INFO - 2024-09-27 13:46:42 --> Utf8 Class Initialized
INFO - 2024-09-27 13:46:42 --> URI Class Initialized
INFO - 2024-09-27 13:46:42 --> Router Class Initialized
INFO - 2024-09-27 13:46:42 --> Output Class Initialized
INFO - 2024-09-27 13:46:42 --> Security Class Initialized
DEBUG - 2024-09-27 13:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 13:46:42 --> Input Class Initialized
INFO - 2024-09-27 13:46:42 --> Language Class Initialized
INFO - 2024-09-27 13:46:42 --> Language Class Initialized
INFO - 2024-09-27 13:46:42 --> Config Class Initialized
INFO - 2024-09-27 13:46:42 --> Loader Class Initialized
INFO - 2024-09-27 13:46:42 --> Helper loaded: url_helper
INFO - 2024-09-27 13:46:42 --> Helper loaded: file_helper
INFO - 2024-09-27 13:46:42 --> Helper loaded: form_helper
INFO - 2024-09-27 13:46:42 --> Helper loaded: my_helper
INFO - 2024-09-27 13:46:42 --> Database Driver Class Initialized
INFO - 2024-09-27 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 13:46:42 --> Controller Class Initialized
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-09-27 13:46:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-09-27 13:46:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-09-27 15:31:05 --> Config Class Initialized
INFO - 2024-09-27 15:31:05 --> Hooks Class Initialized
DEBUG - 2024-09-27 15:31:05 --> UTF-8 Support Enabled
INFO - 2024-09-27 15:31:05 --> Utf8 Class Initialized
INFO - 2024-09-27 15:31:05 --> URI Class Initialized
INFO - 2024-09-27 15:31:05 --> Router Class Initialized
INFO - 2024-09-27 15:31:05 --> Output Class Initialized
INFO - 2024-09-27 15:31:05 --> Security Class Initialized
DEBUG - 2024-09-27 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 15:31:05 --> Input Class Initialized
INFO - 2024-09-27 15:31:05 --> Language Class Initialized
INFO - 2024-09-27 15:31:05 --> Language Class Initialized
INFO - 2024-09-27 15:31:05 --> Config Class Initialized
INFO - 2024-09-27 15:31:05 --> Loader Class Initialized
INFO - 2024-09-27 15:31:05 --> Helper loaded: url_helper
INFO - 2024-09-27 15:31:05 --> Helper loaded: file_helper
INFO - 2024-09-27 15:31:05 --> Helper loaded: form_helper
INFO - 2024-09-27 15:31:05 --> Helper loaded: my_helper
INFO - 2024-09-27 15:31:05 --> Database Driver Class Initialized
INFO - 2024-09-27 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 15:31:05 --> Controller Class Initialized
INFO - 2024-09-27 15:31:05 --> Helper loaded: cookie_helper
INFO - 2024-09-27 15:31:05 --> Final output sent to browser
DEBUG - 2024-09-27 15:31:05 --> Total execution time: 0.0671
INFO - 2024-09-27 15:31:06 --> Config Class Initialized
INFO - 2024-09-27 15:31:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 15:31:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 15:31:06 --> Utf8 Class Initialized
INFO - 2024-09-27 15:31:06 --> URI Class Initialized
INFO - 2024-09-27 15:31:06 --> Router Class Initialized
INFO - 2024-09-27 15:31:06 --> Output Class Initialized
INFO - 2024-09-27 15:31:06 --> Security Class Initialized
DEBUG - 2024-09-27 15:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 15:31:06 --> Input Class Initialized
INFO - 2024-09-27 15:31:06 --> Language Class Initialized
INFO - 2024-09-27 15:31:06 --> Language Class Initialized
INFO - 2024-09-27 15:31:06 --> Config Class Initialized
INFO - 2024-09-27 15:31:06 --> Loader Class Initialized
INFO - 2024-09-27 15:31:06 --> Helper loaded: url_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: file_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: form_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: my_helper
INFO - 2024-09-27 15:31:06 --> Database Driver Class Initialized
INFO - 2024-09-27 15:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 15:31:06 --> Controller Class Initialized
INFO - 2024-09-27 15:31:06 --> Helper loaded: cookie_helper
INFO - 2024-09-27 15:31:06 --> Config Class Initialized
INFO - 2024-09-27 15:31:06 --> Hooks Class Initialized
DEBUG - 2024-09-27 15:31:06 --> UTF-8 Support Enabled
INFO - 2024-09-27 15:31:06 --> Utf8 Class Initialized
INFO - 2024-09-27 15:31:06 --> URI Class Initialized
INFO - 2024-09-27 15:31:06 --> Router Class Initialized
INFO - 2024-09-27 15:31:06 --> Output Class Initialized
INFO - 2024-09-27 15:31:06 --> Security Class Initialized
DEBUG - 2024-09-27 15:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 15:31:06 --> Input Class Initialized
INFO - 2024-09-27 15:31:06 --> Language Class Initialized
INFO - 2024-09-27 15:31:06 --> Language Class Initialized
INFO - 2024-09-27 15:31:06 --> Config Class Initialized
INFO - 2024-09-27 15:31:06 --> Loader Class Initialized
INFO - 2024-09-27 15:31:06 --> Helper loaded: url_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: file_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: form_helper
INFO - 2024-09-27 15:31:06 --> Helper loaded: my_helper
INFO - 2024-09-27 15:31:06 --> Database Driver Class Initialized
INFO - 2024-09-27 15:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 15:31:06 --> Controller Class Initialized
DEBUG - 2024-09-27 15:31:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-27 15:31:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-27 15:31:06 --> Final output sent to browser
DEBUG - 2024-09-27 15:31:06 --> Total execution time: 0.0311
INFO - 2024-09-27 15:31:10 --> Config Class Initialized
INFO - 2024-09-27 15:31:10 --> Hooks Class Initialized
DEBUG - 2024-09-27 15:31:10 --> UTF-8 Support Enabled
INFO - 2024-09-27 15:31:10 --> Utf8 Class Initialized
INFO - 2024-09-27 15:31:10 --> URI Class Initialized
INFO - 2024-09-27 15:31:10 --> Router Class Initialized
INFO - 2024-09-27 15:31:10 --> Output Class Initialized
INFO - 2024-09-27 15:31:10 --> Security Class Initialized
DEBUG - 2024-09-27 15:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 15:31:10 --> Input Class Initialized
INFO - 2024-09-27 15:31:10 --> Language Class Initialized
INFO - 2024-09-27 15:31:10 --> Language Class Initialized
INFO - 2024-09-27 15:31:10 --> Config Class Initialized
INFO - 2024-09-27 15:31:10 --> Loader Class Initialized
INFO - 2024-09-27 15:31:10 --> Helper loaded: url_helper
INFO - 2024-09-27 15:31:10 --> Helper loaded: file_helper
INFO - 2024-09-27 15:31:10 --> Helper loaded: form_helper
INFO - 2024-09-27 15:31:10 --> Helper loaded: my_helper
INFO - 2024-09-27 15:31:10 --> Database Driver Class Initialized
INFO - 2024-09-27 15:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 15:31:10 --> Controller Class Initialized
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-27 15:31:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-27 15:31:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-27 15:31:13 --> Final output sent to browser
DEBUG - 2024-09-27 15:31:13 --> Total execution time: 2.7249
INFO - 2024-09-27 15:31:21 --> Config Class Initialized
INFO - 2024-09-27 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-09-27 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-09-27 15:31:21 --> Utf8 Class Initialized
INFO - 2024-09-27 15:31:21 --> URI Class Initialized
INFO - 2024-09-27 15:31:21 --> Router Class Initialized
INFO - 2024-09-27 15:31:21 --> Output Class Initialized
INFO - 2024-09-27 15:31:21 --> Security Class Initialized
DEBUG - 2024-09-27 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-27 15:31:21 --> Input Class Initialized
INFO - 2024-09-27 15:31:21 --> Language Class Initialized
INFO - 2024-09-27 15:31:21 --> Language Class Initialized
INFO - 2024-09-27 15:31:21 --> Config Class Initialized
INFO - 2024-09-27 15:31:21 --> Loader Class Initialized
INFO - 2024-09-27 15:31:21 --> Helper loaded: url_helper
INFO - 2024-09-27 15:31:21 --> Helper loaded: file_helper
INFO - 2024-09-27 15:31:21 --> Helper loaded: form_helper
INFO - 2024-09-27 15:31:21 --> Helper loaded: my_helper
INFO - 2024-09-27 15:31:21 --> Database Driver Class Initialized
INFO - 2024-09-27 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-27 15:31:21 --> Controller Class Initialized
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-27 15:31:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-27 15:31:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-27 15:31:25 --> Final output sent to browser
DEBUG - 2024-09-27 15:31:25 --> Total execution time: 4.4217
