<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-31 10:03:57 --> Config Class Initialized
INFO - 2024-10-31 10:03:57 --> Hooks Class Initialized
DEBUG - 2024-10-31 10:03:57 --> UTF-8 Support Enabled
INFO - 2024-10-31 10:03:57 --> Utf8 Class Initialized
INFO - 2024-10-31 10:03:57 --> URI Class Initialized
INFO - 2024-10-31 10:03:57 --> Router Class Initialized
INFO - 2024-10-31 10:03:57 --> Output Class Initialized
INFO - 2024-10-31 10:03:57 --> Security Class Initialized
DEBUG - 2024-10-31 10:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 10:03:57 --> Input Class Initialized
INFO - 2024-10-31 10:03:57 --> Language Class Initialized
INFO - 2024-10-31 10:03:57 --> Language Class Initialized
INFO - 2024-10-31 10:03:57 --> Config Class Initialized
INFO - 2024-10-31 10:03:57 --> Loader Class Initialized
INFO - 2024-10-31 10:03:57 --> Helper loaded: url_helper
INFO - 2024-10-31 10:03:57 --> Helper loaded: file_helper
INFO - 2024-10-31 10:03:57 --> Helper loaded: form_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: my_helper
INFO - 2024-10-31 10:03:58 --> Database Driver Class Initialized
INFO - 2024-10-31 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 10:03:58 --> Controller Class Initialized
INFO - 2024-10-31 10:03:58 --> Helper loaded: cookie_helper
INFO - 2024-10-31 10:03:58 --> Final output sent to browser
DEBUG - 2024-10-31 10:03:58 --> Total execution time: 0.0632
INFO - 2024-10-31 10:03:58 --> Config Class Initialized
INFO - 2024-10-31 10:03:58 --> Hooks Class Initialized
DEBUG - 2024-10-31 10:03:58 --> UTF-8 Support Enabled
INFO - 2024-10-31 10:03:58 --> Utf8 Class Initialized
INFO - 2024-10-31 10:03:58 --> URI Class Initialized
INFO - 2024-10-31 10:03:58 --> Router Class Initialized
INFO - 2024-10-31 10:03:58 --> Output Class Initialized
INFO - 2024-10-31 10:03:58 --> Security Class Initialized
DEBUG - 2024-10-31 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 10:03:58 --> Input Class Initialized
INFO - 2024-10-31 10:03:58 --> Language Class Initialized
INFO - 2024-10-31 10:03:58 --> Language Class Initialized
INFO - 2024-10-31 10:03:58 --> Config Class Initialized
INFO - 2024-10-31 10:03:58 --> Loader Class Initialized
INFO - 2024-10-31 10:03:58 --> Helper loaded: url_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: file_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: form_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: my_helper
INFO - 2024-10-31 10:03:58 --> Database Driver Class Initialized
INFO - 2024-10-31 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 10:03:58 --> Controller Class Initialized
INFO - 2024-10-31 10:03:58 --> Helper loaded: cookie_helper
INFO - 2024-10-31 10:03:58 --> Config Class Initialized
INFO - 2024-10-31 10:03:58 --> Hooks Class Initialized
DEBUG - 2024-10-31 10:03:58 --> UTF-8 Support Enabled
INFO - 2024-10-31 10:03:58 --> Utf8 Class Initialized
INFO - 2024-10-31 10:03:58 --> URI Class Initialized
INFO - 2024-10-31 10:03:58 --> Router Class Initialized
INFO - 2024-10-31 10:03:58 --> Output Class Initialized
INFO - 2024-10-31 10:03:58 --> Security Class Initialized
DEBUG - 2024-10-31 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 10:03:58 --> Input Class Initialized
INFO - 2024-10-31 10:03:58 --> Language Class Initialized
INFO - 2024-10-31 10:03:58 --> Language Class Initialized
INFO - 2024-10-31 10:03:58 --> Config Class Initialized
INFO - 2024-10-31 10:03:58 --> Loader Class Initialized
INFO - 2024-10-31 10:03:58 --> Helper loaded: url_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: file_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: form_helper
INFO - 2024-10-31 10:03:58 --> Helper loaded: my_helper
INFO - 2024-10-31 10:03:58 --> Database Driver Class Initialized
INFO - 2024-10-31 10:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 10:03:58 --> Controller Class Initialized
DEBUG - 2024-10-31 10:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-31 10:03:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-31 10:03:58 --> Final output sent to browser
DEBUG - 2024-10-31 10:03:58 --> Total execution time: 0.0354
INFO - 2024-10-31 10:04:01 --> Config Class Initialized
INFO - 2024-10-31 10:04:01 --> Hooks Class Initialized
DEBUG - 2024-10-31 10:04:01 --> UTF-8 Support Enabled
INFO - 2024-10-31 10:04:01 --> Utf8 Class Initialized
INFO - 2024-10-31 10:04:01 --> URI Class Initialized
INFO - 2024-10-31 10:04:01 --> Router Class Initialized
INFO - 2024-10-31 10:04:01 --> Output Class Initialized
INFO - 2024-10-31 10:04:01 --> Security Class Initialized
DEBUG - 2024-10-31 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 10:04:01 --> Input Class Initialized
INFO - 2024-10-31 10:04:01 --> Language Class Initialized
INFO - 2024-10-31 10:04:01 --> Language Class Initialized
INFO - 2024-10-31 10:04:01 --> Config Class Initialized
INFO - 2024-10-31 10:04:01 --> Loader Class Initialized
INFO - 2024-10-31 10:04:01 --> Helper loaded: url_helper
INFO - 2024-10-31 10:04:01 --> Helper loaded: file_helper
INFO - 2024-10-31 10:04:01 --> Helper loaded: form_helper
INFO - 2024-10-31 10:04:01 --> Helper loaded: my_helper
INFO - 2024-10-31 10:04:01 --> Database Driver Class Initialized
INFO - 2024-10-31 10:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 10:04:02 --> Controller Class Initialized
DEBUG - 2024-10-31 10:04:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-31 10:04:06 --> Final output sent to browser
DEBUG - 2024-10-31 10:04:06 --> Total execution time: 4.6323
