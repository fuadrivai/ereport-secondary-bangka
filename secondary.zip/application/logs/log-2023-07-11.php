<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-11 09:25:30 --> Config Class Initialized
INFO - 2023-07-11 09:25:30 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:30 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:30 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:30 --> URI Class Initialized
DEBUG - 2023-07-11 09:25:30 --> No URI present. Default controller set.
INFO - 2023-07-11 09:25:30 --> Router Class Initialized
INFO - 2023-07-11 09:25:30 --> Output Class Initialized
INFO - 2023-07-11 09:25:30 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:30 --> Input Class Initialized
INFO - 2023-07-11 09:25:30 --> Language Class Initialized
INFO - 2023-07-11 09:25:31 --> Language Class Initialized
INFO - 2023-07-11 09:25:31 --> Config Class Initialized
INFO - 2023-07-11 09:25:31 --> Loader Class Initialized
INFO - 2023-07-11 09:25:31 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:31 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:31 --> Controller Class Initialized
INFO - 2023-07-11 09:25:31 --> Config Class Initialized
INFO - 2023-07-11 09:25:31 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:31 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:31 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:31 --> URI Class Initialized
INFO - 2023-07-11 09:25:31 --> Router Class Initialized
INFO - 2023-07-11 09:25:31 --> Output Class Initialized
INFO - 2023-07-11 09:25:31 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:31 --> Input Class Initialized
INFO - 2023-07-11 09:25:31 --> Language Class Initialized
INFO - 2023-07-11 09:25:31 --> Language Class Initialized
INFO - 2023-07-11 09:25:31 --> Config Class Initialized
INFO - 2023-07-11 09:25:31 --> Loader Class Initialized
INFO - 2023-07-11 09:25:31 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:31 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:31 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:31 --> Controller Class Initialized
DEBUG - 2023-07-11 09:25:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-11 09:25:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:25:31 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:31 --> Total execution time: 0.1167
INFO - 2023-07-11 09:25:36 --> Config Class Initialized
INFO - 2023-07-11 09:25:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:36 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:36 --> URI Class Initialized
INFO - 2023-07-11 09:25:36 --> Router Class Initialized
INFO - 2023-07-11 09:25:36 --> Output Class Initialized
INFO - 2023-07-11 09:25:36 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:36 --> Input Class Initialized
INFO - 2023-07-11 09:25:36 --> Language Class Initialized
INFO - 2023-07-11 09:25:36 --> Language Class Initialized
INFO - 2023-07-11 09:25:36 --> Config Class Initialized
INFO - 2023-07-11 09:25:36 --> Loader Class Initialized
INFO - 2023-07-11 09:25:36 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:36 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:36 --> Controller Class Initialized
INFO - 2023-07-11 09:25:36 --> Helper loaded: cookie_helper
INFO - 2023-07-11 09:25:36 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:36 --> Total execution time: 0.0756
INFO - 2023-07-11 09:25:36 --> Config Class Initialized
INFO - 2023-07-11 09:25:36 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:36 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:36 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:36 --> URI Class Initialized
INFO - 2023-07-11 09:25:36 --> Router Class Initialized
INFO - 2023-07-11 09:25:36 --> Output Class Initialized
INFO - 2023-07-11 09:25:36 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:36 --> Input Class Initialized
INFO - 2023-07-11 09:25:36 --> Language Class Initialized
INFO - 2023-07-11 09:25:36 --> Language Class Initialized
INFO - 2023-07-11 09:25:36 --> Config Class Initialized
INFO - 2023-07-11 09:25:36 --> Loader Class Initialized
INFO - 2023-07-11 09:25:36 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:36 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:36 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:36 --> Controller Class Initialized
DEBUG - 2023-07-11 09:25:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-11 09:25:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:25:36 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:36 --> Total execution time: 0.1171
INFO - 2023-07-11 09:25:40 --> Config Class Initialized
INFO - 2023-07-11 09:25:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:40 --> URI Class Initialized
INFO - 2023-07-11 09:25:40 --> Router Class Initialized
INFO - 2023-07-11 09:25:40 --> Output Class Initialized
INFO - 2023-07-11 09:25:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:40 --> Input Class Initialized
INFO - 2023-07-11 09:25:40 --> Language Class Initialized
INFO - 2023-07-11 09:25:40 --> Language Class Initialized
INFO - 2023-07-11 09:25:40 --> Config Class Initialized
INFO - 2023-07-11 09:25:40 --> Loader Class Initialized
INFO - 2023-07-11 09:25:40 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:40 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:40 --> Controller Class Initialized
DEBUG - 2023-07-11 09:25:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 09:25:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:25:40 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:40 --> Total execution time: 0.0771
INFO - 2023-07-11 09:25:40 --> Config Class Initialized
INFO - 2023-07-11 09:25:40 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:40 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:40 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:40 --> URI Class Initialized
INFO - 2023-07-11 09:25:40 --> Router Class Initialized
INFO - 2023-07-11 09:25:40 --> Output Class Initialized
INFO - 2023-07-11 09:25:40 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:40 --> Input Class Initialized
INFO - 2023-07-11 09:25:40 --> Language Class Initialized
INFO - 2023-07-11 09:25:40 --> Language Class Initialized
INFO - 2023-07-11 09:25:40 --> Config Class Initialized
INFO - 2023-07-11 09:25:40 --> Loader Class Initialized
INFO - 2023-07-11 09:25:40 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:40 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:40 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:40 --> Controller Class Initialized
INFO - 2023-07-11 09:25:42 --> Config Class Initialized
INFO - 2023-07-11 09:25:42 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:42 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:42 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:42 --> URI Class Initialized
INFO - 2023-07-11 09:25:42 --> Router Class Initialized
INFO - 2023-07-11 09:25:42 --> Output Class Initialized
INFO - 2023-07-11 09:25:42 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:42 --> Input Class Initialized
INFO - 2023-07-11 09:25:42 --> Language Class Initialized
INFO - 2023-07-11 09:25:42 --> Language Class Initialized
INFO - 2023-07-11 09:25:42 --> Config Class Initialized
INFO - 2023-07-11 09:25:42 --> Loader Class Initialized
INFO - 2023-07-11 09:25:42 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:42 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:42 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:42 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:42 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:42 --> Controller Class Initialized
ERROR - 2023-07-11 09:25:42 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-11 09:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-11 09:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:25:42 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:42 --> Total execution time: 0.1026
INFO - 2023-07-11 09:25:53 --> Config Class Initialized
INFO - 2023-07-11 09:25:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:53 --> URI Class Initialized
INFO - 2023-07-11 09:25:53 --> Router Class Initialized
INFO - 2023-07-11 09:25:53 --> Output Class Initialized
INFO - 2023-07-11 09:25:53 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:53 --> Input Class Initialized
INFO - 2023-07-11 09:25:53 --> Language Class Initialized
INFO - 2023-07-11 09:25:53 --> Language Class Initialized
INFO - 2023-07-11 09:25:53 --> Config Class Initialized
INFO - 2023-07-11 09:25:53 --> Loader Class Initialized
INFO - 2023-07-11 09:25:53 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:53 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:53 --> Controller Class Initialized
DEBUG - 2023-07-11 09:25:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 09:25:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:25:53 --> Final output sent to browser
DEBUG - 2023-07-11 09:25:53 --> Total execution time: 0.0460
INFO - 2023-07-11 09:25:53 --> Config Class Initialized
INFO - 2023-07-11 09:25:53 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:25:53 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:25:53 --> Utf8 Class Initialized
INFO - 2023-07-11 09:25:53 --> URI Class Initialized
INFO - 2023-07-11 09:25:53 --> Router Class Initialized
INFO - 2023-07-11 09:25:53 --> Output Class Initialized
INFO - 2023-07-11 09:25:53 --> Security Class Initialized
DEBUG - 2023-07-11 09:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:25:53 --> Input Class Initialized
INFO - 2023-07-11 09:25:53 --> Language Class Initialized
INFO - 2023-07-11 09:25:53 --> Language Class Initialized
INFO - 2023-07-11 09:25:53 --> Config Class Initialized
INFO - 2023-07-11 09:25:53 --> Loader Class Initialized
INFO - 2023-07-11 09:25:53 --> Helper loaded: url_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: file_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: form_helper
INFO - 2023-07-11 09:25:53 --> Helper loaded: my_helper
INFO - 2023-07-11 09:25:53 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:25:53 --> Controller Class Initialized
INFO - 2023-07-11 09:26:11 --> Config Class Initialized
INFO - 2023-07-11 09:26:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:26:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:26:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:26:11 --> URI Class Initialized
INFO - 2023-07-11 09:26:11 --> Router Class Initialized
INFO - 2023-07-11 09:26:11 --> Output Class Initialized
INFO - 2023-07-11 09:26:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:26:11 --> Input Class Initialized
INFO - 2023-07-11 09:26:11 --> Language Class Initialized
INFO - 2023-07-11 09:26:11 --> Language Class Initialized
INFO - 2023-07-11 09:26:11 --> Config Class Initialized
INFO - 2023-07-11 09:26:11 --> Loader Class Initialized
INFO - 2023-07-11 09:26:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:26:11 --> Helper loaded: file_helper
INFO - 2023-07-11 09:26:11 --> Helper loaded: form_helper
INFO - 2023-07-11 09:26:11 --> Helper loaded: my_helper
INFO - 2023-07-11 09:26:11 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:26:11 --> Controller Class Initialized
DEBUG - 2023-07-11 09:26:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-11 09:26:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:26:11 --> Final output sent to browser
DEBUG - 2023-07-11 09:26:11 --> Total execution time: 0.0540
INFO - 2023-07-11 09:27:10 --> Config Class Initialized
INFO - 2023-07-11 09:27:10 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:27:10 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:27:10 --> Utf8 Class Initialized
INFO - 2023-07-11 09:27:10 --> URI Class Initialized
INFO - 2023-07-11 09:27:10 --> Router Class Initialized
INFO - 2023-07-11 09:27:10 --> Output Class Initialized
INFO - 2023-07-11 09:27:10 --> Security Class Initialized
DEBUG - 2023-07-11 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:27:10 --> Input Class Initialized
INFO - 2023-07-11 09:27:10 --> Language Class Initialized
ERROR - 2023-07-11 09:27:10 --> 404 Page Not Found: /index
INFO - 2023-07-11 09:34:11 --> Config Class Initialized
INFO - 2023-07-11 09:34:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:11 --> URI Class Initialized
DEBUG - 2023-07-11 09:34:11 --> No URI present. Default controller set.
INFO - 2023-07-11 09:34:11 --> Router Class Initialized
INFO - 2023-07-11 09:34:11 --> Output Class Initialized
INFO - 2023-07-11 09:34:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:11 --> Input Class Initialized
INFO - 2023-07-11 09:34:11 --> Language Class Initialized
INFO - 2023-07-11 09:34:11 --> Language Class Initialized
INFO - 2023-07-11 09:34:11 --> Config Class Initialized
INFO - 2023-07-11 09:34:11 --> Loader Class Initialized
INFO - 2023-07-11 09:34:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:11 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:11 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:11 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:11 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:12 --> Controller Class Initialized
DEBUG - 2023-07-11 09:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-11 09:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:12 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:12 --> Total execution time: 0.0434
INFO - 2023-07-11 09:34:13 --> Config Class Initialized
INFO - 2023-07-11 09:34:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:13 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:13 --> URI Class Initialized
INFO - 2023-07-11 09:34:13 --> Router Class Initialized
INFO - 2023-07-11 09:34:13 --> Output Class Initialized
INFO - 2023-07-11 09:34:13 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:13 --> Input Class Initialized
INFO - 2023-07-11 09:34:13 --> Language Class Initialized
INFO - 2023-07-11 09:34:13 --> Language Class Initialized
INFO - 2023-07-11 09:34:13 --> Config Class Initialized
INFO - 2023-07-11 09:34:13 --> Loader Class Initialized
INFO - 2023-07-11 09:34:13 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:13 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:13 --> Controller Class Initialized
DEBUG - 2023-07-11 09:34:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-11 09:34:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:13 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:13 --> Total execution time: 0.0742
INFO - 2023-07-11 09:34:13 --> Config Class Initialized
INFO - 2023-07-11 09:34:13 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:13 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:13 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:13 --> URI Class Initialized
INFO - 2023-07-11 09:34:13 --> Router Class Initialized
INFO - 2023-07-11 09:34:13 --> Output Class Initialized
INFO - 2023-07-11 09:34:13 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:13 --> Input Class Initialized
INFO - 2023-07-11 09:34:13 --> Language Class Initialized
INFO - 2023-07-11 09:34:13 --> Language Class Initialized
INFO - 2023-07-11 09:34:13 --> Config Class Initialized
INFO - 2023-07-11 09:34:13 --> Loader Class Initialized
INFO - 2023-07-11 09:34:13 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:13 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:13 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:13 --> Controller Class Initialized
INFO - 2023-07-11 09:34:14 --> Config Class Initialized
INFO - 2023-07-11 09:34:14 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:14 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:14 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:14 --> URI Class Initialized
INFO - 2023-07-11 09:34:14 --> Router Class Initialized
INFO - 2023-07-11 09:34:14 --> Output Class Initialized
INFO - 2023-07-11 09:34:14 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:14 --> Input Class Initialized
INFO - 2023-07-11 09:34:14 --> Language Class Initialized
INFO - 2023-07-11 09:34:14 --> Language Class Initialized
INFO - 2023-07-11 09:34:14 --> Config Class Initialized
INFO - 2023-07-11 09:34:14 --> Loader Class Initialized
INFO - 2023-07-11 09:34:14 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:14 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:14 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:14 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:14 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:14 --> Controller Class Initialized
INFO - 2023-07-11 09:34:14 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:14 --> Total execution time: 0.0336
INFO - 2023-07-11 09:34:21 --> Config Class Initialized
INFO - 2023-07-11 09:34:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:21 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:21 --> URI Class Initialized
INFO - 2023-07-11 09:34:21 --> Router Class Initialized
INFO - 2023-07-11 09:34:21 --> Output Class Initialized
INFO - 2023-07-11 09:34:21 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:21 --> Input Class Initialized
INFO - 2023-07-11 09:34:21 --> Language Class Initialized
INFO - 2023-07-11 09:34:21 --> Language Class Initialized
INFO - 2023-07-11 09:34:21 --> Config Class Initialized
INFO - 2023-07-11 09:34:21 --> Loader Class Initialized
INFO - 2023-07-11 09:34:21 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:21 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:21 --> Controller Class Initialized
DEBUG - 2023-07-11 09:34:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 09:34:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:21 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:21 --> Total execution time: 0.0312
INFO - 2023-07-11 09:34:21 --> Config Class Initialized
INFO - 2023-07-11 09:34:21 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:21 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:21 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:21 --> URI Class Initialized
INFO - 2023-07-11 09:34:21 --> Router Class Initialized
INFO - 2023-07-11 09:34:21 --> Output Class Initialized
INFO - 2023-07-11 09:34:21 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:21 --> Input Class Initialized
INFO - 2023-07-11 09:34:21 --> Language Class Initialized
INFO - 2023-07-11 09:34:21 --> Language Class Initialized
INFO - 2023-07-11 09:34:21 --> Config Class Initialized
INFO - 2023-07-11 09:34:21 --> Loader Class Initialized
INFO - 2023-07-11 09:34:21 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:21 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:21 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:21 --> Controller Class Initialized
INFO - 2023-07-11 09:34:23 --> Config Class Initialized
INFO - 2023-07-11 09:34:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:23 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:23 --> URI Class Initialized
INFO - 2023-07-11 09:34:23 --> Router Class Initialized
INFO - 2023-07-11 09:34:23 --> Output Class Initialized
INFO - 2023-07-11 09:34:23 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:23 --> Input Class Initialized
INFO - 2023-07-11 09:34:23 --> Language Class Initialized
INFO - 2023-07-11 09:34:23 --> Language Class Initialized
INFO - 2023-07-11 09:34:23 --> Config Class Initialized
INFO - 2023-07-11 09:34:23 --> Loader Class Initialized
INFO - 2023-07-11 09:34:23 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:23 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:23 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:23 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:23 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:23 --> Controller Class Initialized
ERROR - 2023-07-11 09:34:23 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-11 09:34:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-11 09:34:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:23 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:23 --> Total execution time: 0.0368
INFO - 2023-07-11 09:34:27 --> Config Class Initialized
INFO - 2023-07-11 09:34:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:27 --> URI Class Initialized
INFO - 2023-07-11 09:34:27 --> Router Class Initialized
INFO - 2023-07-11 09:34:27 --> Output Class Initialized
INFO - 2023-07-11 09:34:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:27 --> Input Class Initialized
INFO - 2023-07-11 09:34:27 --> Language Class Initialized
INFO - 2023-07-11 09:34:27 --> Language Class Initialized
INFO - 2023-07-11 09:34:27 --> Config Class Initialized
INFO - 2023-07-11 09:34:27 --> Loader Class Initialized
INFO - 2023-07-11 09:34:27 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:27 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:27 --> Controller Class Initialized
DEBUG - 2023-07-11 09:34:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 09:34:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:27 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:27 --> Total execution time: 0.0381
INFO - 2023-07-11 09:34:27 --> Config Class Initialized
INFO - 2023-07-11 09:34:27 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:27 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:27 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:27 --> URI Class Initialized
INFO - 2023-07-11 09:34:27 --> Router Class Initialized
INFO - 2023-07-11 09:34:27 --> Output Class Initialized
INFO - 2023-07-11 09:34:27 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:27 --> Input Class Initialized
INFO - 2023-07-11 09:34:27 --> Language Class Initialized
INFO - 2023-07-11 09:34:27 --> Language Class Initialized
INFO - 2023-07-11 09:34:27 --> Config Class Initialized
INFO - 2023-07-11 09:34:27 --> Loader Class Initialized
INFO - 2023-07-11 09:34:27 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:27 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:27 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:27 --> Controller Class Initialized
INFO - 2023-07-11 09:34:28 --> Config Class Initialized
INFO - 2023-07-11 09:34:28 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:34:28 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:34:28 --> Utf8 Class Initialized
INFO - 2023-07-11 09:34:28 --> URI Class Initialized
INFO - 2023-07-11 09:34:28 --> Router Class Initialized
INFO - 2023-07-11 09:34:28 --> Output Class Initialized
INFO - 2023-07-11 09:34:28 --> Security Class Initialized
DEBUG - 2023-07-11 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:34:28 --> Input Class Initialized
INFO - 2023-07-11 09:34:28 --> Language Class Initialized
INFO - 2023-07-11 09:34:28 --> Language Class Initialized
INFO - 2023-07-11 09:34:28 --> Config Class Initialized
INFO - 2023-07-11 09:34:28 --> Loader Class Initialized
INFO - 2023-07-11 09:34:28 --> Helper loaded: url_helper
INFO - 2023-07-11 09:34:28 --> Helper loaded: file_helper
INFO - 2023-07-11 09:34:28 --> Helper loaded: form_helper
INFO - 2023-07-11 09:34:28 --> Helper loaded: my_helper
INFO - 2023-07-11 09:34:28 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:34:28 --> Controller Class Initialized
ERROR - 2023-07-11 09:34:28 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-11 09:34:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-11 09:34:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:34:28 --> Final output sent to browser
DEBUG - 2023-07-11 09:34:28 --> Total execution time: 0.0328
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:11 --> URI Class Initialized
INFO - 2023-07-11 09:35:11 --> Router Class Initialized
INFO - 2023-07-11 09:35:11 --> Output Class Initialized
INFO - 2023-07-11 09:35:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:11 --> Input Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Loader Class Initialized
INFO - 2023-07-11 09:35:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:11 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:11 --> Controller Class Initialized
INFO - 2023-07-11 09:35:11 --> Upload Class Initialized
INFO - 2023-07-11 09:35:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-07-11 09:35:11 --> The upload path does not appear to be valid.
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:11 --> URI Class Initialized
INFO - 2023-07-11 09:35:11 --> Router Class Initialized
INFO - 2023-07-11 09:35:11 --> Output Class Initialized
INFO - 2023-07-11 09:35:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:11 --> Input Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Loader Class Initialized
INFO - 2023-07-11 09:35:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:11 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:11 --> Controller Class Initialized
DEBUG - 2023-07-11 09:35:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 09:35:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:35:11 --> Final output sent to browser
DEBUG - 2023-07-11 09:35:11 --> Total execution time: 0.0234
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:11 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:11 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:11 --> URI Class Initialized
INFO - 2023-07-11 09:35:11 --> Router Class Initialized
INFO - 2023-07-11 09:35:11 --> Output Class Initialized
INFO - 2023-07-11 09:35:11 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:11 --> Input Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Language Class Initialized
INFO - 2023-07-11 09:35:11 --> Config Class Initialized
INFO - 2023-07-11 09:35:11 --> Loader Class Initialized
INFO - 2023-07-11 09:35:11 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:11 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:11 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:11 --> Controller Class Initialized
INFO - 2023-07-11 09:35:19 --> Config Class Initialized
INFO - 2023-07-11 09:35:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:19 --> URI Class Initialized
INFO - 2023-07-11 09:35:19 --> Router Class Initialized
INFO - 2023-07-11 09:35:19 --> Output Class Initialized
INFO - 2023-07-11 09:35:19 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:19 --> Input Class Initialized
INFO - 2023-07-11 09:35:19 --> Language Class Initialized
INFO - 2023-07-11 09:35:19 --> Language Class Initialized
INFO - 2023-07-11 09:35:19 --> Config Class Initialized
INFO - 2023-07-11 09:35:19 --> Loader Class Initialized
INFO - 2023-07-11 09:35:19 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:19 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:19 --> Controller Class Initialized
DEBUG - 2023-07-11 09:35:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-11 09:35:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:35:19 --> Final output sent to browser
DEBUG - 2023-07-11 09:35:19 --> Total execution time: 0.0587
INFO - 2023-07-11 09:35:19 --> Config Class Initialized
INFO - 2023-07-11 09:35:19 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:19 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:19 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:19 --> URI Class Initialized
INFO - 2023-07-11 09:35:19 --> Router Class Initialized
INFO - 2023-07-11 09:35:19 --> Output Class Initialized
INFO - 2023-07-11 09:35:19 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:19 --> Input Class Initialized
INFO - 2023-07-11 09:35:19 --> Language Class Initialized
INFO - 2023-07-11 09:35:19 --> Language Class Initialized
INFO - 2023-07-11 09:35:19 --> Config Class Initialized
INFO - 2023-07-11 09:35:19 --> Loader Class Initialized
INFO - 2023-07-11 09:35:19 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:19 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:19 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:19 --> Controller Class Initialized
INFO - 2023-07-11 09:35:22 --> Config Class Initialized
INFO - 2023-07-11 09:35:22 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:22 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:22 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:22 --> URI Class Initialized
INFO - 2023-07-11 09:35:22 --> Router Class Initialized
INFO - 2023-07-11 09:35:22 --> Output Class Initialized
INFO - 2023-07-11 09:35:22 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:22 --> Input Class Initialized
INFO - 2023-07-11 09:35:22 --> Language Class Initialized
INFO - 2023-07-11 09:35:22 --> Language Class Initialized
INFO - 2023-07-11 09:35:22 --> Config Class Initialized
INFO - 2023-07-11 09:35:22 --> Loader Class Initialized
INFO - 2023-07-11 09:35:22 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:22 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:22 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:22 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:22 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:22 --> Controller Class Initialized
DEBUG - 2023-07-11 09:35:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-11 09:35:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:35:22 --> Final output sent to browser
DEBUG - 2023-07-11 09:35:22 --> Total execution time: 0.0663
INFO - 2023-07-11 09:35:23 --> Config Class Initialized
INFO - 2023-07-11 09:35:23 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:23 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:23 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:23 --> URI Class Initialized
INFO - 2023-07-11 09:35:23 --> Router Class Initialized
INFO - 2023-07-11 09:35:23 --> Output Class Initialized
INFO - 2023-07-11 09:35:23 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:23 --> Input Class Initialized
INFO - 2023-07-11 09:35:23 --> Language Class Initialized
INFO - 2023-07-11 09:35:23 --> Language Class Initialized
INFO - 2023-07-11 09:35:23 --> Config Class Initialized
INFO - 2023-07-11 09:35:23 --> Loader Class Initialized
INFO - 2023-07-11 09:35:23 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:23 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:23 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:23 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:23 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:23 --> Controller Class Initialized
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 59
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-11 09:35:23 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-07-11 09:35:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-11 09:35:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:35:23 --> Final output sent to browser
DEBUG - 2023-07-11 09:35:23 --> Total execution time: 0.0774
INFO - 2023-07-11 09:35:29 --> Config Class Initialized
INFO - 2023-07-11 09:35:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 09:35:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 09:35:29 --> Utf8 Class Initialized
INFO - 2023-07-11 09:35:29 --> URI Class Initialized
DEBUG - 2023-07-11 09:35:29 --> No URI present. Default controller set.
INFO - 2023-07-11 09:35:29 --> Router Class Initialized
INFO - 2023-07-11 09:35:29 --> Output Class Initialized
INFO - 2023-07-11 09:35:29 --> Security Class Initialized
DEBUG - 2023-07-11 09:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 09:35:29 --> Input Class Initialized
INFO - 2023-07-11 09:35:29 --> Language Class Initialized
INFO - 2023-07-11 09:35:29 --> Language Class Initialized
INFO - 2023-07-11 09:35:29 --> Config Class Initialized
INFO - 2023-07-11 09:35:29 --> Loader Class Initialized
INFO - 2023-07-11 09:35:29 --> Helper loaded: url_helper
INFO - 2023-07-11 09:35:29 --> Helper loaded: file_helper
INFO - 2023-07-11 09:35:29 --> Helper loaded: form_helper
INFO - 2023-07-11 09:35:29 --> Helper loaded: my_helper
INFO - 2023-07-11 09:35:29 --> Database Driver Class Initialized
DEBUG - 2023-07-11 09:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 09:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 09:35:29 --> Controller Class Initialized
DEBUG - 2023-07-11 09:35:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-11 09:35:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 09:35:29 --> Final output sent to browser
DEBUG - 2023-07-11 09:35:29 --> Total execution time: 0.0302
INFO - 2023-07-11 10:07:29 --> Config Class Initialized
INFO - 2023-07-11 10:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:29 --> URI Class Initialized
INFO - 2023-07-11 10:07:29 --> Router Class Initialized
INFO - 2023-07-11 10:07:29 --> Output Class Initialized
INFO - 2023-07-11 10:07:29 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:29 --> Input Class Initialized
INFO - 2023-07-11 10:07:29 --> Language Class Initialized
INFO - 2023-07-11 10:07:29 --> Language Class Initialized
INFO - 2023-07-11 10:07:29 --> Config Class Initialized
INFO - 2023-07-11 10:07:29 --> Loader Class Initialized
INFO - 2023-07-11 10:07:29 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:29 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:29 --> Controller Class Initialized
DEBUG - 2023-07-11 10:07:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-11 10:07:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:07:29 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:29 --> Total execution time: 0.0532
INFO - 2023-07-11 10:07:29 --> Config Class Initialized
INFO - 2023-07-11 10:07:29 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:29 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:29 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:29 --> URI Class Initialized
INFO - 2023-07-11 10:07:29 --> Router Class Initialized
INFO - 2023-07-11 10:07:29 --> Output Class Initialized
INFO - 2023-07-11 10:07:29 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:29 --> Input Class Initialized
INFO - 2023-07-11 10:07:29 --> Language Class Initialized
INFO - 2023-07-11 10:07:29 --> Language Class Initialized
INFO - 2023-07-11 10:07:29 --> Config Class Initialized
INFO - 2023-07-11 10:07:29 --> Loader Class Initialized
INFO - 2023-07-11 10:07:29 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:29 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:29 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:29 --> Controller Class Initialized
INFO - 2023-07-11 10:07:39 --> Config Class Initialized
INFO - 2023-07-11 10:07:39 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:39 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:39 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:39 --> URI Class Initialized
DEBUG - 2023-07-11 10:07:39 --> No URI present. Default controller set.
INFO - 2023-07-11 10:07:39 --> Router Class Initialized
INFO - 2023-07-11 10:07:39 --> Output Class Initialized
INFO - 2023-07-11 10:07:39 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:39 --> Input Class Initialized
INFO - 2023-07-11 10:07:39 --> Language Class Initialized
INFO - 2023-07-11 10:07:39 --> Language Class Initialized
INFO - 2023-07-11 10:07:39 --> Config Class Initialized
INFO - 2023-07-11 10:07:39 --> Loader Class Initialized
INFO - 2023-07-11 10:07:39 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:39 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:39 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:39 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:39 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:39 --> Controller Class Initialized
DEBUG - 2023-07-11 10:07:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-11 10:07:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:07:39 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:39 --> Total execution time: 0.0340
INFO - 2023-07-11 10:07:41 --> Config Class Initialized
INFO - 2023-07-11 10:07:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:41 --> URI Class Initialized
INFO - 2023-07-11 10:07:41 --> Router Class Initialized
INFO - 2023-07-11 10:07:41 --> Output Class Initialized
INFO - 2023-07-11 10:07:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:41 --> Input Class Initialized
INFO - 2023-07-11 10:07:41 --> Language Class Initialized
INFO - 2023-07-11 10:07:41 --> Language Class Initialized
INFO - 2023-07-11 10:07:41 --> Config Class Initialized
INFO - 2023-07-11 10:07:41 --> Loader Class Initialized
INFO - 2023-07-11 10:07:41 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:41 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:41 --> Controller Class Initialized
DEBUG - 2023-07-11 10:07:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-11 10:07:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:07:41 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:41 --> Total execution time: 0.0341
INFO - 2023-07-11 10:07:41 --> Config Class Initialized
INFO - 2023-07-11 10:07:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:41 --> URI Class Initialized
INFO - 2023-07-11 10:07:41 --> Router Class Initialized
INFO - 2023-07-11 10:07:41 --> Output Class Initialized
INFO - 2023-07-11 10:07:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:41 --> Input Class Initialized
INFO - 2023-07-11 10:07:41 --> Language Class Initialized
INFO - 2023-07-11 10:07:41 --> Language Class Initialized
INFO - 2023-07-11 10:07:41 --> Config Class Initialized
INFO - 2023-07-11 10:07:41 --> Loader Class Initialized
INFO - 2023-07-11 10:07:41 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:41 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:41 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:41 --> Controller Class Initialized
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:55 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:55 --> URI Class Initialized
INFO - 2023-07-11 10:07:55 --> Router Class Initialized
INFO - 2023-07-11 10:07:55 --> Output Class Initialized
INFO - 2023-07-11 10:07:55 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:55 --> Input Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Loader Class Initialized
INFO - 2023-07-11 10:07:55 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:55 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:55 --> Controller Class Initialized
INFO - 2023-07-11 10:07:55 --> Helper loaded: cookie_helper
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:55 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:55 --> URI Class Initialized
INFO - 2023-07-11 10:07:55 --> Router Class Initialized
INFO - 2023-07-11 10:07:55 --> Output Class Initialized
INFO - 2023-07-11 10:07:55 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:55 --> Input Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Loader Class Initialized
INFO - 2023-07-11 10:07:55 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:55 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:55 --> Controller Class Initialized
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:55 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:55 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:55 --> URI Class Initialized
INFO - 2023-07-11 10:07:55 --> Router Class Initialized
INFO - 2023-07-11 10:07:55 --> Output Class Initialized
INFO - 2023-07-11 10:07:55 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:55 --> Input Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Language Class Initialized
INFO - 2023-07-11 10:07:55 --> Config Class Initialized
INFO - 2023-07-11 10:07:55 --> Loader Class Initialized
INFO - 2023-07-11 10:07:55 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:55 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:55 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:55 --> Controller Class Initialized
DEBUG - 2023-07-11 10:07:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-11 10:07:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:07:55 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:55 --> Total execution time: 0.0329
INFO - 2023-07-11 10:07:59 --> Config Class Initialized
INFO - 2023-07-11 10:07:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:59 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:59 --> URI Class Initialized
INFO - 2023-07-11 10:07:59 --> Router Class Initialized
INFO - 2023-07-11 10:07:59 --> Output Class Initialized
INFO - 2023-07-11 10:07:59 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:59 --> Input Class Initialized
INFO - 2023-07-11 10:07:59 --> Language Class Initialized
INFO - 2023-07-11 10:07:59 --> Language Class Initialized
INFO - 2023-07-11 10:07:59 --> Config Class Initialized
INFO - 2023-07-11 10:07:59 --> Loader Class Initialized
INFO - 2023-07-11 10:07:59 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:59 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:59 --> Controller Class Initialized
INFO - 2023-07-11 10:07:59 --> Helper loaded: cookie_helper
INFO - 2023-07-11 10:07:59 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:59 --> Total execution time: 0.0439
INFO - 2023-07-11 10:07:59 --> Config Class Initialized
INFO - 2023-07-11 10:07:59 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:07:59 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:07:59 --> Utf8 Class Initialized
INFO - 2023-07-11 10:07:59 --> URI Class Initialized
INFO - 2023-07-11 10:07:59 --> Router Class Initialized
INFO - 2023-07-11 10:07:59 --> Output Class Initialized
INFO - 2023-07-11 10:07:59 --> Security Class Initialized
DEBUG - 2023-07-11 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:07:59 --> Input Class Initialized
INFO - 2023-07-11 10:07:59 --> Language Class Initialized
INFO - 2023-07-11 10:07:59 --> Language Class Initialized
INFO - 2023-07-11 10:07:59 --> Config Class Initialized
INFO - 2023-07-11 10:07:59 --> Loader Class Initialized
INFO - 2023-07-11 10:07:59 --> Helper loaded: url_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: file_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: form_helper
INFO - 2023-07-11 10:07:59 --> Helper loaded: my_helper
INFO - 2023-07-11 10:07:59 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:07:59 --> Controller Class Initialized
DEBUG - 2023-07-11 10:07:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-11 10:07:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:07:59 --> Final output sent to browser
DEBUG - 2023-07-11 10:07:59 --> Total execution time: 0.1132
INFO - 2023-07-11 10:08:03 --> Config Class Initialized
INFO - 2023-07-11 10:08:03 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:08:03 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:08:03 --> Utf8 Class Initialized
INFO - 2023-07-11 10:08:03 --> URI Class Initialized
INFO - 2023-07-11 10:08:03 --> Router Class Initialized
INFO - 2023-07-11 10:08:03 --> Output Class Initialized
INFO - 2023-07-11 10:08:03 --> Security Class Initialized
DEBUG - 2023-07-11 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:08:03 --> Input Class Initialized
INFO - 2023-07-11 10:08:03 --> Language Class Initialized
INFO - 2023-07-11 10:08:03 --> Language Class Initialized
INFO - 2023-07-11 10:08:03 --> Config Class Initialized
INFO - 2023-07-11 10:08:03 --> Loader Class Initialized
INFO - 2023-07-11 10:08:03 --> Helper loaded: url_helper
INFO - 2023-07-11 10:08:03 --> Helper loaded: file_helper
INFO - 2023-07-11 10:08:03 --> Helper loaded: form_helper
INFO - 2023-07-11 10:08:03 --> Helper loaded: my_helper
INFO - 2023-07-11 10:08:03 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:08:03 --> Controller Class Initialized
DEBUG - 2023-07-11 10:08:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-11 10:08:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:08:03 --> Final output sent to browser
DEBUG - 2023-07-11 10:08:03 --> Total execution time: 0.1829
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:12:34 --> Utf8 Class Initialized
INFO - 2023-07-11 10:12:34 --> URI Class Initialized
INFO - 2023-07-11 10:12:34 --> Router Class Initialized
INFO - 2023-07-11 10:12:34 --> Output Class Initialized
INFO - 2023-07-11 10:12:34 --> Security Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:12:34 --> Input Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Loader Class Initialized
INFO - 2023-07-11 10:12:34 --> Helper loaded: url_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: file_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: form_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: my_helper
INFO - 2023-07-11 10:12:34 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:12:34 --> Controller Class Initialized
INFO - 2023-07-11 10:12:34 --> Helper loaded: cookie_helper
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:12:34 --> Utf8 Class Initialized
INFO - 2023-07-11 10:12:34 --> URI Class Initialized
INFO - 2023-07-11 10:12:34 --> Router Class Initialized
INFO - 2023-07-11 10:12:34 --> Output Class Initialized
INFO - 2023-07-11 10:12:34 --> Security Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:12:34 --> Input Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Loader Class Initialized
INFO - 2023-07-11 10:12:34 --> Helper loaded: url_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: file_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: form_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: my_helper
INFO - 2023-07-11 10:12:34 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:12:34 --> Controller Class Initialized
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:12:34 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:12:34 --> Utf8 Class Initialized
INFO - 2023-07-11 10:12:34 --> URI Class Initialized
INFO - 2023-07-11 10:12:34 --> Router Class Initialized
INFO - 2023-07-11 10:12:34 --> Output Class Initialized
INFO - 2023-07-11 10:12:34 --> Security Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:12:34 --> Input Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Language Class Initialized
INFO - 2023-07-11 10:12:34 --> Config Class Initialized
INFO - 2023-07-11 10:12:34 --> Loader Class Initialized
INFO - 2023-07-11 10:12:34 --> Helper loaded: url_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: file_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: form_helper
INFO - 2023-07-11 10:12:34 --> Helper loaded: my_helper
INFO - 2023-07-11 10:12:34 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:12:34 --> Controller Class Initialized
DEBUG - 2023-07-11 10:12:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-11 10:12:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:12:34 --> Final output sent to browser
DEBUG - 2023-07-11 10:12:34 --> Total execution time: 0.0419
INFO - 2023-07-11 10:12:41 --> Config Class Initialized
INFO - 2023-07-11 10:12:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:12:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:12:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:12:41 --> URI Class Initialized
INFO - 2023-07-11 10:12:41 --> Router Class Initialized
INFO - 2023-07-11 10:12:41 --> Output Class Initialized
INFO - 2023-07-11 10:12:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:12:41 --> Input Class Initialized
INFO - 2023-07-11 10:12:41 --> Language Class Initialized
INFO - 2023-07-11 10:12:41 --> Language Class Initialized
INFO - 2023-07-11 10:12:41 --> Config Class Initialized
INFO - 2023-07-11 10:12:41 --> Loader Class Initialized
INFO - 2023-07-11 10:12:41 --> Helper loaded: url_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: file_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: form_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: my_helper
INFO - 2023-07-11 10:12:41 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:12:41 --> Controller Class Initialized
INFO - 2023-07-11 10:12:41 --> Helper loaded: cookie_helper
INFO - 2023-07-11 10:12:41 --> Final output sent to browser
DEBUG - 2023-07-11 10:12:41 --> Total execution time: 0.0649
INFO - 2023-07-11 10:12:41 --> Config Class Initialized
INFO - 2023-07-11 10:12:41 --> Hooks Class Initialized
DEBUG - 2023-07-11 10:12:41 --> UTF-8 Support Enabled
INFO - 2023-07-11 10:12:41 --> Utf8 Class Initialized
INFO - 2023-07-11 10:12:41 --> URI Class Initialized
INFO - 2023-07-11 10:12:41 --> Router Class Initialized
INFO - 2023-07-11 10:12:41 --> Output Class Initialized
INFO - 2023-07-11 10:12:41 --> Security Class Initialized
DEBUG - 2023-07-11 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-11 10:12:41 --> Input Class Initialized
INFO - 2023-07-11 10:12:41 --> Language Class Initialized
INFO - 2023-07-11 10:12:41 --> Language Class Initialized
INFO - 2023-07-11 10:12:41 --> Config Class Initialized
INFO - 2023-07-11 10:12:41 --> Loader Class Initialized
INFO - 2023-07-11 10:12:41 --> Helper loaded: url_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: file_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: form_helper
INFO - 2023-07-11 10:12:41 --> Helper loaded: my_helper
INFO - 2023-07-11 10:12:41 --> Database Driver Class Initialized
DEBUG - 2023-07-11 10:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-11 10:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-11 10:12:41 --> Controller Class Initialized
DEBUG - 2023-07-11 10:12:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-11 10:12:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-11 10:12:41 --> Final output sent to browser
DEBUG - 2023-07-11 10:12:41 --> Total execution time: 0.0484
