<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-20 10:18:04 --> Config Class Initialized
INFO - 2024-08-20 10:18:04 --> Hooks Class Initialized
DEBUG - 2024-08-20 10:18:04 --> UTF-8 Support Enabled
INFO - 2024-08-20 10:18:04 --> Utf8 Class Initialized
INFO - 2024-08-20 10:18:04 --> URI Class Initialized
INFO - 2024-08-20 10:18:04 --> Router Class Initialized
INFO - 2024-08-20 10:18:04 --> Output Class Initialized
INFO - 2024-08-20 10:18:04 --> Security Class Initialized
DEBUG - 2024-08-20 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 10:18:04 --> Input Class Initialized
INFO - 2024-08-20 10:18:04 --> Language Class Initialized
INFO - 2024-08-20 10:18:04 --> Language Class Initialized
INFO - 2024-08-20 10:18:04 --> Config Class Initialized
INFO - 2024-08-20 10:18:04 --> Loader Class Initialized
INFO - 2024-08-20 10:18:04 --> Helper loaded: url_helper
INFO - 2024-08-20 10:18:04 --> Helper loaded: file_helper
INFO - 2024-08-20 10:18:04 --> Helper loaded: form_helper
INFO - 2024-08-20 10:18:04 --> Helper loaded: my_helper
INFO - 2024-08-20 10:18:04 --> Database Driver Class Initialized
INFO - 2024-08-20 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 10:18:04 --> Controller Class Initialized
INFO - 2024-08-20 10:18:04 --> Helper loaded: cookie_helper
INFO - 2024-08-20 10:18:04 --> Final output sent to browser
DEBUG - 2024-08-20 10:18:04 --> Total execution time: 0.1295
INFO - 2024-08-20 10:18:06 --> Config Class Initialized
INFO - 2024-08-20 10:18:06 --> Hooks Class Initialized
DEBUG - 2024-08-20 10:18:06 --> UTF-8 Support Enabled
INFO - 2024-08-20 10:18:06 --> Utf8 Class Initialized
INFO - 2024-08-20 10:18:06 --> URI Class Initialized
INFO - 2024-08-20 10:18:06 --> Router Class Initialized
INFO - 2024-08-20 10:18:06 --> Output Class Initialized
INFO - 2024-08-20 10:18:06 --> Security Class Initialized
DEBUG - 2024-08-20 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 10:18:06 --> Input Class Initialized
INFO - 2024-08-20 10:18:06 --> Language Class Initialized
INFO - 2024-08-20 10:18:06 --> Language Class Initialized
INFO - 2024-08-20 10:18:06 --> Config Class Initialized
INFO - 2024-08-20 10:18:06 --> Loader Class Initialized
INFO - 2024-08-20 10:18:06 --> Helper loaded: url_helper
INFO - 2024-08-20 10:18:06 --> Helper loaded: file_helper
INFO - 2024-08-20 10:18:06 --> Helper loaded: form_helper
INFO - 2024-08-20 10:18:06 --> Helper loaded: my_helper
INFO - 2024-08-20 10:18:06 --> Database Driver Class Initialized
INFO - 2024-08-20 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 10:18:07 --> Controller Class Initialized
INFO - 2024-08-20 10:18:07 --> Helper loaded: cookie_helper
INFO - 2024-08-20 10:18:07 --> Config Class Initialized
INFO - 2024-08-20 10:18:07 --> Hooks Class Initialized
DEBUG - 2024-08-20 10:18:07 --> UTF-8 Support Enabled
INFO - 2024-08-20 10:18:07 --> Utf8 Class Initialized
INFO - 2024-08-20 10:18:07 --> URI Class Initialized
INFO - 2024-08-20 10:18:07 --> Router Class Initialized
INFO - 2024-08-20 10:18:07 --> Output Class Initialized
INFO - 2024-08-20 10:18:07 --> Security Class Initialized
DEBUG - 2024-08-20 10:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-20 10:18:07 --> Input Class Initialized
INFO - 2024-08-20 10:18:07 --> Language Class Initialized
INFO - 2024-08-20 10:18:07 --> Language Class Initialized
INFO - 2024-08-20 10:18:07 --> Config Class Initialized
INFO - 2024-08-20 10:18:07 --> Loader Class Initialized
INFO - 2024-08-20 10:18:07 --> Helper loaded: url_helper
INFO - 2024-08-20 10:18:07 --> Helper loaded: file_helper
INFO - 2024-08-20 10:18:07 --> Helper loaded: form_helper
INFO - 2024-08-20 10:18:07 --> Helper loaded: my_helper
INFO - 2024-08-20 10:18:07 --> Database Driver Class Initialized
INFO - 2024-08-20 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-20 10:18:07 --> Controller Class Initialized
DEBUG - 2024-08-20 10:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-20 10:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-20 10:18:07 --> Final output sent to browser
DEBUG - 2024-08-20 10:18:07 --> Total execution time: 0.0781
