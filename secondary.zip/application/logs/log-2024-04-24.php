<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-04-24 15:45:39 --> Config Class Initialized
INFO - 2024-04-24 15:45:39 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:45:39 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:45:39 --> Utf8 Class Initialized
INFO - 2024-04-24 15:45:39 --> URI Class Initialized
INFO - 2024-04-24 15:45:39 --> Router Class Initialized
INFO - 2024-04-24 15:45:39 --> Output Class Initialized
INFO - 2024-04-24 15:45:39 --> Security Class Initialized
DEBUG - 2024-04-24 15:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:45:39 --> Input Class Initialized
INFO - 2024-04-24 15:45:39 --> Language Class Initialized
INFO - 2024-04-24 15:45:39 --> Language Class Initialized
INFO - 2024-04-24 15:45:39 --> Config Class Initialized
INFO - 2024-04-24 15:45:39 --> Loader Class Initialized
INFO - 2024-04-24 15:45:39 --> Helper loaded: url_helper
INFO - 2024-04-24 15:45:39 --> Helper loaded: file_helper
INFO - 2024-04-24 15:45:39 --> Helper loaded: form_helper
INFO - 2024-04-24 15:45:39 --> Helper loaded: my_helper
INFO - 2024-04-24 15:45:39 --> Database Driver Class Initialized
INFO - 2024-04-24 15:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:45:39 --> Controller Class Initialized
DEBUG - 2024-04-24 15:45:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-04-24 15:45:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-24 15:45:39 --> Final output sent to browser
DEBUG - 2024-04-24 15:45:39 --> Total execution time: 0.1993
INFO - 2024-04-24 15:45:46 --> Config Class Initialized
INFO - 2024-04-24 15:45:46 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:45:46 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:45:46 --> Utf8 Class Initialized
INFO - 2024-04-24 15:45:46 --> URI Class Initialized
INFO - 2024-04-24 15:45:46 --> Router Class Initialized
INFO - 2024-04-24 15:45:46 --> Output Class Initialized
INFO - 2024-04-24 15:45:46 --> Security Class Initialized
DEBUG - 2024-04-24 15:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:45:46 --> Input Class Initialized
INFO - 2024-04-24 15:45:46 --> Language Class Initialized
INFO - 2024-04-24 15:45:46 --> Language Class Initialized
INFO - 2024-04-24 15:45:46 --> Config Class Initialized
INFO - 2024-04-24 15:45:46 --> Loader Class Initialized
INFO - 2024-04-24 15:45:46 --> Helper loaded: url_helper
INFO - 2024-04-24 15:45:46 --> Helper loaded: file_helper
INFO - 2024-04-24 15:45:46 --> Helper loaded: form_helper
INFO - 2024-04-24 15:45:46 --> Helper loaded: my_helper
INFO - 2024-04-24 15:45:46 --> Database Driver Class Initialized
INFO - 2024-04-24 15:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:45:47 --> Controller Class Initialized
INFO - 2024-04-24 15:45:47 --> Helper loaded: cookie_helper
INFO - 2024-04-24 15:45:47 --> Final output sent to browser
DEBUG - 2024-04-24 15:45:47 --> Total execution time: 0.0953
INFO - 2024-04-24 15:45:47 --> Config Class Initialized
INFO - 2024-04-24 15:45:47 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:45:47 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:45:47 --> Utf8 Class Initialized
INFO - 2024-04-24 15:45:47 --> URI Class Initialized
INFO - 2024-04-24 15:45:47 --> Router Class Initialized
INFO - 2024-04-24 15:45:47 --> Output Class Initialized
INFO - 2024-04-24 15:45:47 --> Security Class Initialized
DEBUG - 2024-04-24 15:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:45:47 --> Input Class Initialized
INFO - 2024-04-24 15:45:47 --> Language Class Initialized
INFO - 2024-04-24 15:45:47 --> Language Class Initialized
INFO - 2024-04-24 15:45:47 --> Config Class Initialized
INFO - 2024-04-24 15:45:47 --> Loader Class Initialized
INFO - 2024-04-24 15:45:47 --> Helper loaded: url_helper
INFO - 2024-04-24 15:45:47 --> Helper loaded: file_helper
INFO - 2024-04-24 15:45:47 --> Helper loaded: form_helper
INFO - 2024-04-24 15:45:47 --> Helper loaded: my_helper
INFO - 2024-04-24 15:45:47 --> Database Driver Class Initialized
INFO - 2024-04-24 15:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:45:47 --> Controller Class Initialized
DEBUG - 2024-04-24 15:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-04-24 15:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-24 15:45:47 --> Final output sent to browser
DEBUG - 2024-04-24 15:45:47 --> Total execution time: 0.1558
INFO - 2024-04-24 15:46:38 --> Config Class Initialized
INFO - 2024-04-24 15:46:38 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:46:38 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:46:38 --> Utf8 Class Initialized
INFO - 2024-04-24 15:46:38 --> URI Class Initialized
INFO - 2024-04-24 15:46:38 --> Router Class Initialized
INFO - 2024-04-24 15:46:38 --> Output Class Initialized
INFO - 2024-04-24 15:46:38 --> Security Class Initialized
DEBUG - 2024-04-24 15:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:46:38 --> Input Class Initialized
INFO - 2024-04-24 15:46:38 --> Language Class Initialized
INFO - 2024-04-24 15:46:38 --> Language Class Initialized
INFO - 2024-04-24 15:46:38 --> Config Class Initialized
INFO - 2024-04-24 15:46:38 --> Loader Class Initialized
INFO - 2024-04-24 15:46:38 --> Helper loaded: url_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: file_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: form_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: my_helper
INFO - 2024-04-24 15:46:38 --> Database Driver Class Initialized
INFO - 2024-04-24 15:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:46:38 --> Controller Class Initialized
DEBUG - 2024-04-24 15:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-04-24 15:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-24 15:46:38 --> Final output sent to browser
DEBUG - 2024-04-24 15:46:38 --> Total execution time: 0.0508
INFO - 2024-04-24 15:46:38 --> Config Class Initialized
INFO - 2024-04-24 15:46:38 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:46:38 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:46:38 --> Utf8 Class Initialized
INFO - 2024-04-24 15:46:38 --> URI Class Initialized
INFO - 2024-04-24 15:46:38 --> Router Class Initialized
INFO - 2024-04-24 15:46:38 --> Output Class Initialized
INFO - 2024-04-24 15:46:38 --> Security Class Initialized
DEBUG - 2024-04-24 15:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:46:38 --> Input Class Initialized
INFO - 2024-04-24 15:46:38 --> Language Class Initialized
ERROR - 2024-04-24 15:46:38 --> 404 Page Not Found: /index
INFO - 2024-04-24 15:46:38 --> Config Class Initialized
INFO - 2024-04-24 15:46:38 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:46:38 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:46:38 --> Utf8 Class Initialized
INFO - 2024-04-24 15:46:38 --> URI Class Initialized
INFO - 2024-04-24 15:46:38 --> Router Class Initialized
INFO - 2024-04-24 15:46:38 --> Output Class Initialized
INFO - 2024-04-24 15:46:38 --> Security Class Initialized
DEBUG - 2024-04-24 15:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:46:38 --> Input Class Initialized
INFO - 2024-04-24 15:46:38 --> Language Class Initialized
INFO - 2024-04-24 15:46:38 --> Language Class Initialized
INFO - 2024-04-24 15:46:38 --> Config Class Initialized
INFO - 2024-04-24 15:46:38 --> Loader Class Initialized
INFO - 2024-04-24 15:46:38 --> Helper loaded: url_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: file_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: form_helper
INFO - 2024-04-24 15:46:38 --> Helper loaded: my_helper
INFO - 2024-04-24 15:46:38 --> Database Driver Class Initialized
INFO - 2024-04-24 15:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:46:38 --> Controller Class Initialized
INFO - 2024-04-24 15:46:45 --> Config Class Initialized
INFO - 2024-04-24 15:46:45 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:46:45 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:46:45 --> Utf8 Class Initialized
INFO - 2024-04-24 15:46:45 --> URI Class Initialized
INFO - 2024-04-24 15:46:45 --> Router Class Initialized
INFO - 2024-04-24 15:46:45 --> Output Class Initialized
INFO - 2024-04-24 15:46:45 --> Security Class Initialized
DEBUG - 2024-04-24 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:46:45 --> Input Class Initialized
INFO - 2024-04-24 15:46:45 --> Language Class Initialized
INFO - 2024-04-24 15:46:45 --> Language Class Initialized
INFO - 2024-04-24 15:46:45 --> Config Class Initialized
INFO - 2024-04-24 15:46:45 --> Loader Class Initialized
INFO - 2024-04-24 15:46:45 --> Helper loaded: url_helper
INFO - 2024-04-24 15:46:45 --> Helper loaded: file_helper
INFO - 2024-04-24 15:46:45 --> Helper loaded: form_helper
INFO - 2024-04-24 15:46:45 --> Helper loaded: my_helper
INFO - 2024-04-24 15:46:45 --> Database Driver Class Initialized
INFO - 2024-04-24 15:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:46:45 --> Controller Class Initialized
INFO - 2024-04-24 15:46:45 --> Final output sent to browser
DEBUG - 2024-04-24 15:46:45 --> Total execution time: 0.0332
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:47:06 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:47:06 --> Utf8 Class Initialized
INFO - 2024-04-24 15:47:06 --> URI Class Initialized
INFO - 2024-04-24 15:47:06 --> Router Class Initialized
INFO - 2024-04-24 15:47:06 --> Output Class Initialized
INFO - 2024-04-24 15:47:06 --> Security Class Initialized
DEBUG - 2024-04-24 15:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:47:06 --> Input Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Loader Class Initialized
INFO - 2024-04-24 15:47:06 --> Helper loaded: url_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: file_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: form_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: my_helper
INFO - 2024-04-24 15:47:06 --> Database Driver Class Initialized
INFO - 2024-04-24 15:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:47:06 --> Controller Class Initialized
INFO - 2024-04-24 15:47:06 --> Helper loaded: cookie_helper
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:47:06 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:47:06 --> Utf8 Class Initialized
INFO - 2024-04-24 15:47:06 --> URI Class Initialized
INFO - 2024-04-24 15:47:06 --> Router Class Initialized
INFO - 2024-04-24 15:47:06 --> Output Class Initialized
INFO - 2024-04-24 15:47:06 --> Security Class Initialized
DEBUG - 2024-04-24 15:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:47:06 --> Input Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Loader Class Initialized
INFO - 2024-04-24 15:47:06 --> Helper loaded: url_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: file_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: form_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: my_helper
INFO - 2024-04-24 15:47:06 --> Database Driver Class Initialized
INFO - 2024-04-24 15:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:47:06 --> Controller Class Initialized
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Hooks Class Initialized
DEBUG - 2024-04-24 15:47:06 --> UTF-8 Support Enabled
INFO - 2024-04-24 15:47:06 --> Utf8 Class Initialized
INFO - 2024-04-24 15:47:06 --> URI Class Initialized
INFO - 2024-04-24 15:47:06 --> Router Class Initialized
INFO - 2024-04-24 15:47:06 --> Output Class Initialized
INFO - 2024-04-24 15:47:06 --> Security Class Initialized
DEBUG - 2024-04-24 15:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-24 15:47:06 --> Input Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Language Class Initialized
INFO - 2024-04-24 15:47:06 --> Config Class Initialized
INFO - 2024-04-24 15:47:06 --> Loader Class Initialized
INFO - 2024-04-24 15:47:06 --> Helper loaded: url_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: file_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: form_helper
INFO - 2024-04-24 15:47:06 --> Helper loaded: my_helper
INFO - 2024-04-24 15:47:06 --> Database Driver Class Initialized
INFO - 2024-04-24 15:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-24 15:47:07 --> Controller Class Initialized
DEBUG - 2024-04-24 15:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-04-24 15:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-24 15:47:07 --> Final output sent to browser
DEBUG - 2024-04-24 15:47:07 --> Total execution time: 0.1606
