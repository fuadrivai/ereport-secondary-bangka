<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-11 11:11:09 --> Config Class Initialized
INFO - 2024-11-11 11:11:09 --> Hooks Class Initialized
DEBUG - 2024-11-11 11:11:09 --> UTF-8 Support Enabled
INFO - 2024-11-11 11:11:09 --> Utf8 Class Initialized
INFO - 2024-11-11 11:11:09 --> URI Class Initialized
INFO - 2024-11-11 11:11:09 --> Router Class Initialized
INFO - 2024-11-11 11:11:09 --> Output Class Initialized
INFO - 2024-11-11 11:11:09 --> Security Class Initialized
DEBUG - 2024-11-11 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 11:11:09 --> Input Class Initialized
INFO - 2024-11-11 11:11:09 --> Language Class Initialized
INFO - 2024-11-11 11:11:09 --> Language Class Initialized
INFO - 2024-11-11 11:11:09 --> Config Class Initialized
INFO - 2024-11-11 11:11:09 --> Loader Class Initialized
INFO - 2024-11-11 11:11:09 --> Helper loaded: url_helper
INFO - 2024-11-11 11:11:09 --> Helper loaded: file_helper
INFO - 2024-11-11 11:11:09 --> Helper loaded: form_helper
INFO - 2024-11-11 11:11:09 --> Helper loaded: my_helper
INFO - 2024-11-11 11:11:09 --> Database Driver Class Initialized
INFO - 2024-11-11 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 11:11:09 --> Controller Class Initialized
INFO - 2024-11-11 11:11:09 --> Helper loaded: cookie_helper
INFO - 2024-11-11 11:11:09 --> Final output sent to browser
DEBUG - 2024-11-11 11:11:09 --> Total execution time: 0.0613
INFO - 2024-11-11 11:11:10 --> Config Class Initialized
INFO - 2024-11-11 11:11:10 --> Hooks Class Initialized
DEBUG - 2024-11-11 11:11:10 --> UTF-8 Support Enabled
INFO - 2024-11-11 11:11:10 --> Utf8 Class Initialized
INFO - 2024-11-11 11:11:10 --> URI Class Initialized
INFO - 2024-11-11 11:11:10 --> Router Class Initialized
INFO - 2024-11-11 11:11:10 --> Output Class Initialized
INFO - 2024-11-11 11:11:10 --> Security Class Initialized
DEBUG - 2024-11-11 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 11:11:10 --> Input Class Initialized
INFO - 2024-11-11 11:11:10 --> Language Class Initialized
INFO - 2024-11-11 11:11:10 --> Language Class Initialized
INFO - 2024-11-11 11:11:10 --> Config Class Initialized
INFO - 2024-11-11 11:11:10 --> Loader Class Initialized
INFO - 2024-11-11 11:11:10 --> Helper loaded: url_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: file_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: form_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: my_helper
INFO - 2024-11-11 11:11:10 --> Database Driver Class Initialized
INFO - 2024-11-11 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 11:11:10 --> Controller Class Initialized
INFO - 2024-11-11 11:11:10 --> Helper loaded: cookie_helper
INFO - 2024-11-11 11:11:10 --> Config Class Initialized
INFO - 2024-11-11 11:11:10 --> Hooks Class Initialized
DEBUG - 2024-11-11 11:11:10 --> UTF-8 Support Enabled
INFO - 2024-11-11 11:11:10 --> Utf8 Class Initialized
INFO - 2024-11-11 11:11:10 --> URI Class Initialized
INFO - 2024-11-11 11:11:10 --> Router Class Initialized
INFO - 2024-11-11 11:11:10 --> Output Class Initialized
INFO - 2024-11-11 11:11:10 --> Security Class Initialized
DEBUG - 2024-11-11 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 11:11:10 --> Input Class Initialized
INFO - 2024-11-11 11:11:10 --> Language Class Initialized
INFO - 2024-11-11 11:11:10 --> Language Class Initialized
INFO - 2024-11-11 11:11:10 --> Config Class Initialized
INFO - 2024-11-11 11:11:10 --> Loader Class Initialized
INFO - 2024-11-11 11:11:10 --> Helper loaded: url_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: file_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: form_helper
INFO - 2024-11-11 11:11:10 --> Helper loaded: my_helper
INFO - 2024-11-11 11:11:10 --> Database Driver Class Initialized
INFO - 2024-11-11 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 11:11:10 --> Controller Class Initialized
DEBUG - 2024-11-11 11:11:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-11 11:11:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-11 11:11:10 --> Final output sent to browser
DEBUG - 2024-11-11 11:11:10 --> Total execution time: 0.0373
INFO - 2024-11-11 11:11:11 --> Config Class Initialized
INFO - 2024-11-11 11:11:11 --> Hooks Class Initialized
DEBUG - 2024-11-11 11:11:11 --> UTF-8 Support Enabled
INFO - 2024-11-11 11:11:11 --> Utf8 Class Initialized
INFO - 2024-11-11 11:11:11 --> URI Class Initialized
INFO - 2024-11-11 11:11:11 --> Router Class Initialized
INFO - 2024-11-11 11:11:11 --> Output Class Initialized
INFO - 2024-11-11 11:11:11 --> Security Class Initialized
DEBUG - 2024-11-11 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 11:11:11 --> Input Class Initialized
INFO - 2024-11-11 11:11:11 --> Language Class Initialized
INFO - 2024-11-11 11:11:11 --> Language Class Initialized
INFO - 2024-11-11 11:11:11 --> Config Class Initialized
INFO - 2024-11-11 11:11:11 --> Loader Class Initialized
INFO - 2024-11-11 11:11:11 --> Helper loaded: url_helper
INFO - 2024-11-11 11:11:11 --> Helper loaded: file_helper
INFO - 2024-11-11 11:11:11 --> Helper loaded: form_helper
INFO - 2024-11-11 11:11:11 --> Helper loaded: my_helper
INFO - 2024-11-11 11:11:11 --> Database Driver Class Initialized
INFO - 2024-11-11 11:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 11:11:11 --> Controller Class Initialized
DEBUG - 2024-11-11 11:11:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-11 11:11:15 --> Final output sent to browser
DEBUG - 2024-11-11 11:11:15 --> Total execution time: 3.5373
INFO - 2024-11-11 12:37:07 --> Config Class Initialized
INFO - 2024-11-11 12:37:07 --> Hooks Class Initialized
DEBUG - 2024-11-11 12:37:07 --> UTF-8 Support Enabled
INFO - 2024-11-11 12:37:07 --> Utf8 Class Initialized
INFO - 2024-11-11 12:37:07 --> URI Class Initialized
INFO - 2024-11-11 12:37:07 --> Router Class Initialized
INFO - 2024-11-11 12:37:07 --> Output Class Initialized
INFO - 2024-11-11 12:37:07 --> Security Class Initialized
DEBUG - 2024-11-11 12:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 12:37:07 --> Input Class Initialized
INFO - 2024-11-11 12:37:07 --> Language Class Initialized
INFO - 2024-11-11 12:37:07 --> Language Class Initialized
INFO - 2024-11-11 12:37:07 --> Config Class Initialized
INFO - 2024-11-11 12:37:07 --> Loader Class Initialized
INFO - 2024-11-11 12:37:07 --> Helper loaded: url_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: file_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: form_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: my_helper
INFO - 2024-11-11 12:37:07 --> Database Driver Class Initialized
INFO - 2024-11-11 12:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 12:37:07 --> Controller Class Initialized
INFO - 2024-11-11 12:37:07 --> Config Class Initialized
INFO - 2024-11-11 12:37:07 --> Hooks Class Initialized
DEBUG - 2024-11-11 12:37:07 --> UTF-8 Support Enabled
INFO - 2024-11-11 12:37:07 --> Utf8 Class Initialized
INFO - 2024-11-11 12:37:07 --> URI Class Initialized
INFO - 2024-11-11 12:37:07 --> Router Class Initialized
INFO - 2024-11-11 12:37:07 --> Output Class Initialized
INFO - 2024-11-11 12:37:07 --> Security Class Initialized
DEBUG - 2024-11-11 12:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 12:37:07 --> Input Class Initialized
INFO - 2024-11-11 12:37:07 --> Language Class Initialized
INFO - 2024-11-11 12:37:07 --> Language Class Initialized
INFO - 2024-11-11 12:37:07 --> Config Class Initialized
INFO - 2024-11-11 12:37:07 --> Loader Class Initialized
INFO - 2024-11-11 12:37:07 --> Helper loaded: url_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: file_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: form_helper
INFO - 2024-11-11 12:37:07 --> Helper loaded: my_helper
INFO - 2024-11-11 12:37:07 --> Database Driver Class Initialized
INFO - 2024-11-11 12:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 12:37:07 --> Controller Class Initialized
DEBUG - 2024-11-11 12:37:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-11 12:37:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-11 12:37:07 --> Final output sent to browser
DEBUG - 2024-11-11 12:37:07 --> Total execution time: 0.0282
