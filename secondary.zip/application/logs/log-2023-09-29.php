<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-29 15:16:03 --> Config Class Initialized
INFO - 2023-09-29 15:16:03 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:03 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:03 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:03 --> URI Class Initialized
INFO - 2023-09-29 15:16:03 --> Router Class Initialized
INFO - 2023-09-29 15:16:03 --> Output Class Initialized
INFO - 2023-09-29 15:16:03 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:03 --> Input Class Initialized
INFO - 2023-09-29 15:16:03 --> Language Class Initialized
INFO - 2023-09-29 15:16:03 --> Language Class Initialized
INFO - 2023-09-29 15:16:03 --> Config Class Initialized
INFO - 2023-09-29 15:16:03 --> Loader Class Initialized
INFO - 2023-09-29 15:16:03 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:03 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:03 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:03 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:03 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:03 --> Controller Class Initialized
INFO - 2023-09-29 15:16:04 --> Config Class Initialized
INFO - 2023-09-29 15:16:04 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:04 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:04 --> URI Class Initialized
INFO - 2023-09-29 15:16:04 --> Router Class Initialized
INFO - 2023-09-29 15:16:04 --> Output Class Initialized
INFO - 2023-09-29 15:16:04 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:04 --> Input Class Initialized
INFO - 2023-09-29 15:16:04 --> Language Class Initialized
INFO - 2023-09-29 15:16:04 --> Language Class Initialized
INFO - 2023-09-29 15:16:04 --> Config Class Initialized
INFO - 2023-09-29 15:16:04 --> Loader Class Initialized
INFO - 2023-09-29 15:16:04 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:04 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:04 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:04 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:04 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:04 --> Controller Class Initialized
DEBUG - 2023-09-29 15:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 15:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 15:16:04 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:04 --> Total execution time: 0.1016
INFO - 2023-09-29 15:16:14 --> Config Class Initialized
INFO - 2023-09-29 15:16:14 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:14 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:14 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:14 --> URI Class Initialized
INFO - 2023-09-29 15:16:14 --> Router Class Initialized
INFO - 2023-09-29 15:16:14 --> Output Class Initialized
INFO - 2023-09-29 15:16:14 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:14 --> Input Class Initialized
INFO - 2023-09-29 15:16:14 --> Language Class Initialized
INFO - 2023-09-29 15:16:14 --> Language Class Initialized
INFO - 2023-09-29 15:16:14 --> Config Class Initialized
INFO - 2023-09-29 15:16:14 --> Loader Class Initialized
INFO - 2023-09-29 15:16:14 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:14 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:14 --> Controller Class Initialized
INFO - 2023-09-29 15:16:14 --> Helper loaded: cookie_helper
INFO - 2023-09-29 15:16:14 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:14 --> Total execution time: 0.1515
INFO - 2023-09-29 15:16:14 --> Config Class Initialized
INFO - 2023-09-29 15:16:14 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:14 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:14 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:14 --> URI Class Initialized
INFO - 2023-09-29 15:16:14 --> Router Class Initialized
INFO - 2023-09-29 15:16:14 --> Output Class Initialized
INFO - 2023-09-29 15:16:14 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:14 --> Input Class Initialized
INFO - 2023-09-29 15:16:14 --> Language Class Initialized
INFO - 2023-09-29 15:16:14 --> Language Class Initialized
INFO - 2023-09-29 15:16:14 --> Config Class Initialized
INFO - 2023-09-29 15:16:14 --> Loader Class Initialized
INFO - 2023-09-29 15:16:14 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:14 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:14 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:14 --> Controller Class Initialized
DEBUG - 2023-09-29 15:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 15:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 15:16:14 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:14 --> Total execution time: 0.0722
INFO - 2023-09-29 15:16:16 --> Config Class Initialized
INFO - 2023-09-29 15:16:16 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:16 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:16 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:16 --> URI Class Initialized
INFO - 2023-09-29 15:16:16 --> Router Class Initialized
INFO - 2023-09-29 15:16:16 --> Output Class Initialized
INFO - 2023-09-29 15:16:16 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:16 --> Input Class Initialized
INFO - 2023-09-29 15:16:16 --> Language Class Initialized
INFO - 2023-09-29 15:16:16 --> Language Class Initialized
INFO - 2023-09-29 15:16:16 --> Config Class Initialized
INFO - 2023-09-29 15:16:16 --> Loader Class Initialized
INFO - 2023-09-29 15:16:16 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:16 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:16 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:16 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:16 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:16 --> Controller Class Initialized
DEBUG - 2023-09-29 15:16:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 15:16:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 15:16:16 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:16 --> Total execution time: 0.1137
INFO - 2023-09-29 15:16:18 --> Config Class Initialized
INFO - 2023-09-29 15:16:18 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:18 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:18 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:18 --> URI Class Initialized
INFO - 2023-09-29 15:16:18 --> Router Class Initialized
INFO - 2023-09-29 15:16:18 --> Output Class Initialized
INFO - 2023-09-29 15:16:18 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:18 --> Input Class Initialized
INFO - 2023-09-29 15:16:18 --> Language Class Initialized
INFO - 2023-09-29 15:16:18 --> Language Class Initialized
INFO - 2023-09-29 15:16:18 --> Config Class Initialized
INFO - 2023-09-29 15:16:18 --> Loader Class Initialized
INFO - 2023-09-29 15:16:18 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:18 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:18 --> Controller Class Initialized
DEBUG - 2023-09-29 15:16:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 15:16:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 15:16:18 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:18 --> Total execution time: 0.1304
INFO - 2023-09-29 15:16:18 --> Config Class Initialized
INFO - 2023-09-29 15:16:18 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:18 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:18 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:18 --> URI Class Initialized
INFO - 2023-09-29 15:16:18 --> Router Class Initialized
INFO - 2023-09-29 15:16:18 --> Output Class Initialized
INFO - 2023-09-29 15:16:18 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:18 --> Input Class Initialized
INFO - 2023-09-29 15:16:18 --> Language Class Initialized
INFO - 2023-09-29 15:16:18 --> Language Class Initialized
INFO - 2023-09-29 15:16:18 --> Config Class Initialized
INFO - 2023-09-29 15:16:18 --> Loader Class Initialized
INFO - 2023-09-29 15:16:18 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:18 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:18 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:18 --> Controller Class Initialized
INFO - 2023-09-29 15:16:22 --> Config Class Initialized
INFO - 2023-09-29 15:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:22 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:22 --> URI Class Initialized
INFO - 2023-09-29 15:16:22 --> Router Class Initialized
INFO - 2023-09-29 15:16:22 --> Output Class Initialized
INFO - 2023-09-29 15:16:22 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:22 --> Input Class Initialized
INFO - 2023-09-29 15:16:22 --> Language Class Initialized
INFO - 2023-09-29 15:16:22 --> Language Class Initialized
INFO - 2023-09-29 15:16:22 --> Config Class Initialized
INFO - 2023-09-29 15:16:22 --> Loader Class Initialized
INFO - 2023-09-29 15:16:22 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:22 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:22 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:22 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:22 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:22 --> Controller Class Initialized
INFO - 2023-09-29 15:16:22 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:22 --> Total execution time: 0.1974
INFO - 2023-09-29 15:16:35 --> Config Class Initialized
INFO - 2023-09-29 15:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:35 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:35 --> URI Class Initialized
INFO - 2023-09-29 15:16:35 --> Router Class Initialized
INFO - 2023-09-29 15:16:35 --> Output Class Initialized
INFO - 2023-09-29 15:16:35 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:35 --> Input Class Initialized
INFO - 2023-09-29 15:16:35 --> Language Class Initialized
INFO - 2023-09-29 15:16:35 --> Language Class Initialized
INFO - 2023-09-29 15:16:35 --> Config Class Initialized
INFO - 2023-09-29 15:16:35 --> Loader Class Initialized
INFO - 2023-09-29 15:16:35 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:35 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:35 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:35 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:35 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:35 --> Controller Class Initialized
INFO - 2023-09-29 15:16:35 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:35 --> Total execution time: 0.1247
INFO - 2023-09-29 15:16:44 --> Config Class Initialized
INFO - 2023-09-29 15:16:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:44 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:44 --> URI Class Initialized
INFO - 2023-09-29 15:16:44 --> Router Class Initialized
INFO - 2023-09-29 15:16:44 --> Output Class Initialized
INFO - 2023-09-29 15:16:44 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:44 --> Input Class Initialized
INFO - 2023-09-29 15:16:44 --> Language Class Initialized
INFO - 2023-09-29 15:16:44 --> Language Class Initialized
INFO - 2023-09-29 15:16:44 --> Config Class Initialized
INFO - 2023-09-29 15:16:44 --> Loader Class Initialized
INFO - 2023-09-29 15:16:44 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:44 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:44 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:44 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:44 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:44 --> Controller Class Initialized
INFO - 2023-09-29 15:16:44 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:44 --> Total execution time: 0.2271
INFO - 2023-09-29 15:16:59 --> Config Class Initialized
INFO - 2023-09-29 15:16:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:16:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:16:59 --> Utf8 Class Initialized
INFO - 2023-09-29 15:16:59 --> URI Class Initialized
INFO - 2023-09-29 15:16:59 --> Router Class Initialized
INFO - 2023-09-29 15:16:59 --> Output Class Initialized
INFO - 2023-09-29 15:16:59 --> Security Class Initialized
DEBUG - 2023-09-29 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:16:59 --> Input Class Initialized
INFO - 2023-09-29 15:16:59 --> Language Class Initialized
INFO - 2023-09-29 15:16:59 --> Language Class Initialized
INFO - 2023-09-29 15:16:59 --> Config Class Initialized
INFO - 2023-09-29 15:16:59 --> Loader Class Initialized
INFO - 2023-09-29 15:16:59 --> Helper loaded: url_helper
INFO - 2023-09-29 15:16:59 --> Helper loaded: file_helper
INFO - 2023-09-29 15:16:59 --> Helper loaded: form_helper
INFO - 2023-09-29 15:16:59 --> Helper loaded: my_helper
INFO - 2023-09-29 15:16:59 --> Database Driver Class Initialized
INFO - 2023-09-29 15:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:16:59 --> Controller Class Initialized
INFO - 2023-09-29 15:16:59 --> Final output sent to browser
DEBUG - 2023-09-29 15:16:59 --> Total execution time: 0.4949
INFO - 2023-09-29 15:17:04 --> Config Class Initialized
INFO - 2023-09-29 15:17:04 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:17:04 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:17:04 --> Utf8 Class Initialized
INFO - 2023-09-29 15:17:04 --> URI Class Initialized
INFO - 2023-09-29 15:17:04 --> Router Class Initialized
INFO - 2023-09-29 15:17:04 --> Output Class Initialized
INFO - 2023-09-29 15:17:04 --> Security Class Initialized
DEBUG - 2023-09-29 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:17:04 --> Input Class Initialized
INFO - 2023-09-29 15:17:04 --> Language Class Initialized
INFO - 2023-09-29 15:17:04 --> Language Class Initialized
INFO - 2023-09-29 15:17:04 --> Config Class Initialized
INFO - 2023-09-29 15:17:04 --> Loader Class Initialized
INFO - 2023-09-29 15:17:04 --> Helper loaded: url_helper
INFO - 2023-09-29 15:17:04 --> Helper loaded: file_helper
INFO - 2023-09-29 15:17:04 --> Helper loaded: form_helper
INFO - 2023-09-29 15:17:04 --> Helper loaded: my_helper
INFO - 2023-09-29 15:17:04 --> Database Driver Class Initialized
INFO - 2023-09-29 15:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:17:04 --> Controller Class Initialized
INFO - 2023-09-29 15:17:04 --> Final output sent to browser
DEBUG - 2023-09-29 15:17:04 --> Total execution time: 0.1727
INFO - 2023-09-29 15:17:12 --> Config Class Initialized
INFO - 2023-09-29 15:17:12 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:17:12 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:17:12 --> Utf8 Class Initialized
INFO - 2023-09-29 15:17:12 --> URI Class Initialized
INFO - 2023-09-29 15:17:12 --> Router Class Initialized
INFO - 2023-09-29 15:17:12 --> Output Class Initialized
INFO - 2023-09-29 15:17:12 --> Security Class Initialized
DEBUG - 2023-09-29 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:17:12 --> Input Class Initialized
INFO - 2023-09-29 15:17:12 --> Language Class Initialized
INFO - 2023-09-29 15:17:12 --> Language Class Initialized
INFO - 2023-09-29 15:17:12 --> Config Class Initialized
INFO - 2023-09-29 15:17:12 --> Loader Class Initialized
INFO - 2023-09-29 15:17:12 --> Helper loaded: url_helper
INFO - 2023-09-29 15:17:12 --> Helper loaded: file_helper
INFO - 2023-09-29 15:17:12 --> Helper loaded: form_helper
INFO - 2023-09-29 15:17:12 --> Helper loaded: my_helper
INFO - 2023-09-29 15:17:12 --> Database Driver Class Initialized
INFO - 2023-09-29 15:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:17:12 --> Controller Class Initialized
INFO - 2023-09-29 15:17:12 --> Final output sent to browser
DEBUG - 2023-09-29 15:17:12 --> Total execution time: 0.1454
INFO - 2023-09-29 15:17:19 --> Config Class Initialized
INFO - 2023-09-29 15:17:19 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:17:19 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:17:19 --> Utf8 Class Initialized
INFO - 2023-09-29 15:17:19 --> URI Class Initialized
INFO - 2023-09-29 15:17:19 --> Router Class Initialized
INFO - 2023-09-29 15:17:19 --> Output Class Initialized
INFO - 2023-09-29 15:17:19 --> Security Class Initialized
DEBUG - 2023-09-29 15:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:17:19 --> Input Class Initialized
INFO - 2023-09-29 15:17:19 --> Language Class Initialized
INFO - 2023-09-29 15:17:19 --> Language Class Initialized
INFO - 2023-09-29 15:17:19 --> Config Class Initialized
INFO - 2023-09-29 15:17:19 --> Loader Class Initialized
INFO - 2023-09-29 15:17:19 --> Helper loaded: url_helper
INFO - 2023-09-29 15:17:19 --> Helper loaded: file_helper
INFO - 2023-09-29 15:17:19 --> Helper loaded: form_helper
INFO - 2023-09-29 15:17:19 --> Helper loaded: my_helper
INFO - 2023-09-29 15:17:19 --> Database Driver Class Initialized
INFO - 2023-09-29 15:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:17:19 --> Controller Class Initialized
INFO - 2023-09-29 15:17:19 --> Final output sent to browser
DEBUG - 2023-09-29 15:17:19 --> Total execution time: 0.0804
INFO - 2023-09-29 15:17:23 --> Config Class Initialized
INFO - 2023-09-29 15:17:23 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:17:23 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:17:23 --> Utf8 Class Initialized
INFO - 2023-09-29 15:17:23 --> URI Class Initialized
INFO - 2023-09-29 15:17:23 --> Router Class Initialized
INFO - 2023-09-29 15:17:23 --> Output Class Initialized
INFO - 2023-09-29 15:17:23 --> Security Class Initialized
DEBUG - 2023-09-29 15:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:17:23 --> Input Class Initialized
INFO - 2023-09-29 15:17:23 --> Language Class Initialized
INFO - 2023-09-29 15:17:23 --> Language Class Initialized
INFO - 2023-09-29 15:17:23 --> Config Class Initialized
INFO - 2023-09-29 15:17:23 --> Loader Class Initialized
INFO - 2023-09-29 15:17:23 --> Helper loaded: url_helper
INFO - 2023-09-29 15:17:23 --> Helper loaded: file_helper
INFO - 2023-09-29 15:17:23 --> Helper loaded: form_helper
INFO - 2023-09-29 15:17:23 --> Helper loaded: my_helper
INFO - 2023-09-29 15:17:23 --> Database Driver Class Initialized
INFO - 2023-09-29 15:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:17:23 --> Controller Class Initialized
INFO - 2023-09-29 15:17:23 --> Final output sent to browser
DEBUG - 2023-09-29 15:17:23 --> Total execution time: 0.0499
INFO - 2023-09-29 15:17:27 --> Config Class Initialized
INFO - 2023-09-29 15:17:27 --> Hooks Class Initialized
DEBUG - 2023-09-29 15:17:27 --> UTF-8 Support Enabled
INFO - 2023-09-29 15:17:27 --> Utf8 Class Initialized
INFO - 2023-09-29 15:17:27 --> URI Class Initialized
DEBUG - 2023-09-29 15:17:27 --> No URI present. Default controller set.
INFO - 2023-09-29 15:17:27 --> Router Class Initialized
INFO - 2023-09-29 15:17:27 --> Output Class Initialized
INFO - 2023-09-29 15:17:27 --> Security Class Initialized
DEBUG - 2023-09-29 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 15:17:27 --> Input Class Initialized
INFO - 2023-09-29 15:17:27 --> Language Class Initialized
INFO - 2023-09-29 15:17:27 --> Language Class Initialized
INFO - 2023-09-29 15:17:27 --> Config Class Initialized
INFO - 2023-09-29 15:17:27 --> Loader Class Initialized
INFO - 2023-09-29 15:17:27 --> Helper loaded: url_helper
INFO - 2023-09-29 15:17:27 --> Helper loaded: file_helper
INFO - 2023-09-29 15:17:27 --> Helper loaded: form_helper
INFO - 2023-09-29 15:17:27 --> Helper loaded: my_helper
INFO - 2023-09-29 15:17:27 --> Database Driver Class Initialized
INFO - 2023-09-29 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 15:17:27 --> Controller Class Initialized
DEBUG - 2023-09-29 15:17:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 15:17:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 15:17:27 --> Final output sent to browser
DEBUG - 2023-09-29 15:17:27 --> Total execution time: 0.1389
INFO - 2023-09-29 16:02:58 --> Config Class Initialized
INFO - 2023-09-29 16:02:58 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:02:58 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:02:58 --> Utf8 Class Initialized
INFO - 2023-09-29 16:02:58 --> URI Class Initialized
INFO - 2023-09-29 16:02:58 --> Router Class Initialized
INFO - 2023-09-29 16:02:58 --> Output Class Initialized
INFO - 2023-09-29 16:02:58 --> Security Class Initialized
DEBUG - 2023-09-29 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:02:58 --> Input Class Initialized
INFO - 2023-09-29 16:02:58 --> Language Class Initialized
INFO - 2023-09-29 16:02:58 --> Language Class Initialized
INFO - 2023-09-29 16:02:58 --> Config Class Initialized
INFO - 2023-09-29 16:02:58 --> Loader Class Initialized
INFO - 2023-09-29 16:02:58 --> Helper loaded: url_helper
INFO - 2023-09-29 16:02:58 --> Helper loaded: file_helper
INFO - 2023-09-29 16:02:58 --> Helper loaded: form_helper
INFO - 2023-09-29 16:02:58 --> Helper loaded: my_helper
INFO - 2023-09-29 16:02:58 --> Database Driver Class Initialized
INFO - 2023-09-29 16:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:02:59 --> Controller Class Initialized
DEBUG - 2023-09-29 16:02:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 16:02:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:02:59 --> Final output sent to browser
DEBUG - 2023-09-29 16:02:59 --> Total execution time: 0.0773
INFO - 2023-09-29 16:03:02 --> Config Class Initialized
INFO - 2023-09-29 16:03:02 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:02 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:02 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:02 --> URI Class Initialized
INFO - 2023-09-29 16:03:02 --> Router Class Initialized
INFO - 2023-09-29 16:03:02 --> Output Class Initialized
INFO - 2023-09-29 16:03:02 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:02 --> Input Class Initialized
INFO - 2023-09-29 16:03:02 --> Language Class Initialized
INFO - 2023-09-29 16:03:02 --> Language Class Initialized
INFO - 2023-09-29 16:03:02 --> Config Class Initialized
INFO - 2023-09-29 16:03:02 --> Loader Class Initialized
INFO - 2023-09-29 16:03:02 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:02 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:02 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:02 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:02 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:02 --> Controller Class Initialized
INFO - 2023-09-29 16:03:02 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:03:02 --> Final output sent to browser
DEBUG - 2023-09-29 16:03:02 --> Total execution time: 0.0935
INFO - 2023-09-29 16:03:03 --> Config Class Initialized
INFO - 2023-09-29 16:03:03 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:03 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:03 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:03 --> URI Class Initialized
INFO - 2023-09-29 16:03:03 --> Router Class Initialized
INFO - 2023-09-29 16:03:03 --> Output Class Initialized
INFO - 2023-09-29 16:03:03 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:03 --> Input Class Initialized
INFO - 2023-09-29 16:03:03 --> Language Class Initialized
INFO - 2023-09-29 16:03:03 --> Language Class Initialized
INFO - 2023-09-29 16:03:03 --> Config Class Initialized
INFO - 2023-09-29 16:03:03 --> Loader Class Initialized
INFO - 2023-09-29 16:03:03 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:03 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:03 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:03 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:03 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:03 --> Controller Class Initialized
DEBUG - 2023-09-29 16:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:03:03 --> Final output sent to browser
DEBUG - 2023-09-29 16:03:03 --> Total execution time: 0.0450
INFO - 2023-09-29 16:03:12 --> Config Class Initialized
INFO - 2023-09-29 16:03:12 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:12 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:12 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:12 --> URI Class Initialized
INFO - 2023-09-29 16:03:12 --> Router Class Initialized
INFO - 2023-09-29 16:03:12 --> Output Class Initialized
INFO - 2023-09-29 16:03:12 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:12 --> Input Class Initialized
INFO - 2023-09-29 16:03:12 --> Language Class Initialized
INFO - 2023-09-29 16:03:12 --> Language Class Initialized
INFO - 2023-09-29 16:03:12 --> Config Class Initialized
INFO - 2023-09-29 16:03:12 --> Loader Class Initialized
INFO - 2023-09-29 16:03:12 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:12 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:12 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:12 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:12 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:12 --> Controller Class Initialized
DEBUG - 2023-09-29 16:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 16:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:03:12 --> Final output sent to browser
DEBUG - 2023-09-29 16:03:12 --> Total execution time: 0.0499
INFO - 2023-09-29 16:03:16 --> Config Class Initialized
INFO - 2023-09-29 16:03:16 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:16 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:16 --> URI Class Initialized
INFO - 2023-09-29 16:03:16 --> Router Class Initialized
INFO - 2023-09-29 16:03:16 --> Output Class Initialized
INFO - 2023-09-29 16:03:16 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:16 --> Input Class Initialized
INFO - 2023-09-29 16:03:16 --> Language Class Initialized
INFO - 2023-09-29 16:03:16 --> Language Class Initialized
INFO - 2023-09-29 16:03:16 --> Config Class Initialized
INFO - 2023-09-29 16:03:16 --> Loader Class Initialized
INFO - 2023-09-29 16:03:16 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:16 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:16 --> Controller Class Initialized
DEBUG - 2023-09-29 16:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 16:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:03:16 --> Final output sent to browser
DEBUG - 2023-09-29 16:03:16 --> Total execution time: 0.2095
INFO - 2023-09-29 16:03:16 --> Config Class Initialized
INFO - 2023-09-29 16:03:16 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:16 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:16 --> URI Class Initialized
INFO - 2023-09-29 16:03:16 --> Router Class Initialized
INFO - 2023-09-29 16:03:16 --> Output Class Initialized
INFO - 2023-09-29 16:03:16 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:16 --> Input Class Initialized
INFO - 2023-09-29 16:03:16 --> Language Class Initialized
INFO - 2023-09-29 16:03:16 --> Language Class Initialized
INFO - 2023-09-29 16:03:16 --> Config Class Initialized
INFO - 2023-09-29 16:03:16 --> Loader Class Initialized
INFO - 2023-09-29 16:03:16 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:16 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:16 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:16 --> Controller Class Initialized
INFO - 2023-09-29 16:03:26 --> Config Class Initialized
INFO - 2023-09-29 16:03:26 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:03:26 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:03:26 --> Utf8 Class Initialized
INFO - 2023-09-29 16:03:26 --> URI Class Initialized
INFO - 2023-09-29 16:03:26 --> Router Class Initialized
INFO - 2023-09-29 16:03:26 --> Output Class Initialized
INFO - 2023-09-29 16:03:26 --> Security Class Initialized
DEBUG - 2023-09-29 16:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:03:26 --> Input Class Initialized
INFO - 2023-09-29 16:03:26 --> Language Class Initialized
INFO - 2023-09-29 16:03:26 --> Language Class Initialized
INFO - 2023-09-29 16:03:26 --> Config Class Initialized
INFO - 2023-09-29 16:03:26 --> Loader Class Initialized
INFO - 2023-09-29 16:03:26 --> Helper loaded: url_helper
INFO - 2023-09-29 16:03:26 --> Helper loaded: file_helper
INFO - 2023-09-29 16:03:26 --> Helper loaded: form_helper
INFO - 2023-09-29 16:03:26 --> Helper loaded: my_helper
INFO - 2023-09-29 16:03:27 --> Database Driver Class Initialized
INFO - 2023-09-29 16:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:03:27 --> Controller Class Initialized
INFO - 2023-09-29 16:03:27 --> Final output sent to browser
DEBUG - 2023-09-29 16:03:27 --> Total execution time: 0.7344
INFO - 2023-09-29 16:04:47 --> Config Class Initialized
INFO - 2023-09-29 16:04:47 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:04:47 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:04:47 --> Utf8 Class Initialized
INFO - 2023-09-29 16:04:47 --> URI Class Initialized
INFO - 2023-09-29 16:04:47 --> Router Class Initialized
INFO - 2023-09-29 16:04:47 --> Output Class Initialized
INFO - 2023-09-29 16:04:47 --> Security Class Initialized
DEBUG - 2023-09-29 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:04:47 --> Input Class Initialized
INFO - 2023-09-29 16:04:47 --> Language Class Initialized
INFO - 2023-09-29 16:04:47 --> Language Class Initialized
INFO - 2023-09-29 16:04:47 --> Config Class Initialized
INFO - 2023-09-29 16:04:47 --> Loader Class Initialized
INFO - 2023-09-29 16:04:47 --> Helper loaded: url_helper
INFO - 2023-09-29 16:04:47 --> Helper loaded: file_helper
INFO - 2023-09-29 16:04:47 --> Helper loaded: form_helper
INFO - 2023-09-29 16:04:47 --> Helper loaded: my_helper
INFO - 2023-09-29 16:04:47 --> Database Driver Class Initialized
INFO - 2023-09-29 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:04:47 --> Controller Class Initialized
INFO - 2023-09-29 16:04:47 --> Final output sent to browser
DEBUG - 2023-09-29 16:04:47 --> Total execution time: 0.0685
INFO - 2023-09-29 16:04:48 --> Config Class Initialized
INFO - 2023-09-29 16:04:48 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:04:48 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:04:48 --> Utf8 Class Initialized
INFO - 2023-09-29 16:04:48 --> URI Class Initialized
INFO - 2023-09-29 16:04:48 --> Router Class Initialized
INFO - 2023-09-29 16:04:48 --> Output Class Initialized
INFO - 2023-09-29 16:04:48 --> Security Class Initialized
DEBUG - 2023-09-29 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:04:48 --> Input Class Initialized
INFO - 2023-09-29 16:04:48 --> Language Class Initialized
INFO - 2023-09-29 16:04:48 --> Language Class Initialized
INFO - 2023-09-29 16:04:48 --> Config Class Initialized
INFO - 2023-09-29 16:04:48 --> Loader Class Initialized
INFO - 2023-09-29 16:04:48 --> Helper loaded: url_helper
INFO - 2023-09-29 16:04:48 --> Helper loaded: file_helper
INFO - 2023-09-29 16:04:48 --> Helper loaded: form_helper
INFO - 2023-09-29 16:04:48 --> Helper loaded: my_helper
INFO - 2023-09-29 16:04:48 --> Database Driver Class Initialized
INFO - 2023-09-29 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:04:48 --> Controller Class Initialized
INFO - 2023-09-29 16:04:53 --> Config Class Initialized
INFO - 2023-09-29 16:04:53 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:04:53 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:04:53 --> Utf8 Class Initialized
INFO - 2023-09-29 16:04:53 --> URI Class Initialized
INFO - 2023-09-29 16:04:53 --> Router Class Initialized
INFO - 2023-09-29 16:04:53 --> Output Class Initialized
INFO - 2023-09-29 16:04:53 --> Security Class Initialized
DEBUG - 2023-09-29 16:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:04:53 --> Input Class Initialized
INFO - 2023-09-29 16:04:53 --> Language Class Initialized
INFO - 2023-09-29 16:04:53 --> Language Class Initialized
INFO - 2023-09-29 16:04:53 --> Config Class Initialized
INFO - 2023-09-29 16:04:53 --> Loader Class Initialized
INFO - 2023-09-29 16:04:53 --> Helper loaded: url_helper
INFO - 2023-09-29 16:04:53 --> Helper loaded: file_helper
INFO - 2023-09-29 16:04:53 --> Helper loaded: form_helper
INFO - 2023-09-29 16:04:53 --> Helper loaded: my_helper
INFO - 2023-09-29 16:04:53 --> Database Driver Class Initialized
INFO - 2023-09-29 16:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:04:53 --> Controller Class Initialized
INFO - 2023-09-29 16:13:25 --> Config Class Initialized
INFO - 2023-09-29 16:13:25 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:13:25 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:13:25 --> Utf8 Class Initialized
INFO - 2023-09-29 16:13:25 --> URI Class Initialized
INFO - 2023-09-29 16:13:25 --> Router Class Initialized
INFO - 2023-09-29 16:13:25 --> Output Class Initialized
INFO - 2023-09-29 16:13:25 --> Security Class Initialized
DEBUG - 2023-09-29 16:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:13:25 --> Input Class Initialized
INFO - 2023-09-29 16:13:25 --> Language Class Initialized
INFO - 2023-09-29 16:13:25 --> Language Class Initialized
INFO - 2023-09-29 16:13:25 --> Config Class Initialized
INFO - 2023-09-29 16:13:25 --> Loader Class Initialized
INFO - 2023-09-29 16:13:25 --> Helper loaded: url_helper
INFO - 2023-09-29 16:13:25 --> Helper loaded: file_helper
INFO - 2023-09-29 16:13:25 --> Helper loaded: form_helper
INFO - 2023-09-29 16:13:25 --> Helper loaded: my_helper
INFO - 2023-09-29 16:13:25 --> Database Driver Class Initialized
INFO - 2023-09-29 16:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:13:25 --> Controller Class Initialized
INFO - 2023-09-29 16:13:25 --> Final output sent to browser
DEBUG - 2023-09-29 16:13:25 --> Total execution time: 0.2161
INFO - 2023-09-29 16:14:24 --> Config Class Initialized
INFO - 2023-09-29 16:14:24 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:14:24 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:14:24 --> Utf8 Class Initialized
INFO - 2023-09-29 16:14:24 --> URI Class Initialized
INFO - 2023-09-29 16:14:24 --> Router Class Initialized
INFO - 2023-09-29 16:14:24 --> Output Class Initialized
INFO - 2023-09-29 16:14:24 --> Security Class Initialized
DEBUG - 2023-09-29 16:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:14:24 --> Input Class Initialized
INFO - 2023-09-29 16:14:24 --> Language Class Initialized
INFO - 2023-09-29 16:14:24 --> Language Class Initialized
INFO - 2023-09-29 16:14:24 --> Config Class Initialized
INFO - 2023-09-29 16:14:24 --> Loader Class Initialized
INFO - 2023-09-29 16:14:24 --> Helper loaded: url_helper
INFO - 2023-09-29 16:14:24 --> Helper loaded: file_helper
INFO - 2023-09-29 16:14:24 --> Helper loaded: form_helper
INFO - 2023-09-29 16:14:24 --> Helper loaded: my_helper
INFO - 2023-09-29 16:14:24 --> Database Driver Class Initialized
INFO - 2023-09-29 16:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:14:24 --> Controller Class Initialized
INFO - 2023-09-29 16:14:24 --> Final output sent to browser
DEBUG - 2023-09-29 16:14:24 --> Total execution time: 0.0601
INFO - 2023-09-29 16:14:25 --> Config Class Initialized
INFO - 2023-09-29 16:14:25 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:14:25 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:14:25 --> Utf8 Class Initialized
INFO - 2023-09-29 16:14:25 --> URI Class Initialized
INFO - 2023-09-29 16:14:25 --> Router Class Initialized
INFO - 2023-09-29 16:14:25 --> Output Class Initialized
INFO - 2023-09-29 16:14:25 --> Security Class Initialized
DEBUG - 2023-09-29 16:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:14:25 --> Input Class Initialized
INFO - 2023-09-29 16:14:25 --> Language Class Initialized
INFO - 2023-09-29 16:14:25 --> Language Class Initialized
INFO - 2023-09-29 16:14:25 --> Config Class Initialized
INFO - 2023-09-29 16:14:25 --> Loader Class Initialized
INFO - 2023-09-29 16:14:25 --> Helper loaded: url_helper
INFO - 2023-09-29 16:14:25 --> Helper loaded: file_helper
INFO - 2023-09-29 16:14:25 --> Helper loaded: form_helper
INFO - 2023-09-29 16:14:25 --> Helper loaded: my_helper
INFO - 2023-09-29 16:14:25 --> Database Driver Class Initialized
INFO - 2023-09-29 16:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:14:25 --> Controller Class Initialized
INFO - 2023-09-29 16:14:34 --> Config Class Initialized
INFO - 2023-09-29 16:14:34 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:14:34 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:14:34 --> Utf8 Class Initialized
INFO - 2023-09-29 16:14:34 --> URI Class Initialized
INFO - 2023-09-29 16:14:34 --> Router Class Initialized
INFO - 2023-09-29 16:14:34 --> Output Class Initialized
INFO - 2023-09-29 16:14:34 --> Security Class Initialized
DEBUG - 2023-09-29 16:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:14:34 --> Input Class Initialized
INFO - 2023-09-29 16:14:34 --> Language Class Initialized
INFO - 2023-09-29 16:14:34 --> Language Class Initialized
INFO - 2023-09-29 16:14:34 --> Config Class Initialized
INFO - 2023-09-29 16:14:34 --> Loader Class Initialized
INFO - 2023-09-29 16:14:34 --> Helper loaded: url_helper
INFO - 2023-09-29 16:14:34 --> Helper loaded: file_helper
INFO - 2023-09-29 16:14:34 --> Helper loaded: form_helper
INFO - 2023-09-29 16:14:34 --> Helper loaded: my_helper
INFO - 2023-09-29 16:14:34 --> Database Driver Class Initialized
INFO - 2023-09-29 16:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:14:34 --> Controller Class Initialized
INFO - 2023-09-29 16:27:57 --> Config Class Initialized
INFO - 2023-09-29 16:27:57 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:27:57 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:27:57 --> Utf8 Class Initialized
INFO - 2023-09-29 16:27:57 --> URI Class Initialized
INFO - 2023-09-29 16:27:57 --> Router Class Initialized
INFO - 2023-09-29 16:27:57 --> Output Class Initialized
INFO - 2023-09-29 16:27:57 --> Security Class Initialized
DEBUG - 2023-09-29 16:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:27:57 --> Input Class Initialized
INFO - 2023-09-29 16:27:57 --> Language Class Initialized
INFO - 2023-09-29 16:27:57 --> Language Class Initialized
INFO - 2023-09-29 16:27:57 --> Config Class Initialized
INFO - 2023-09-29 16:27:57 --> Loader Class Initialized
INFO - 2023-09-29 16:27:57 --> Helper loaded: url_helper
INFO - 2023-09-29 16:27:57 --> Helper loaded: file_helper
INFO - 2023-09-29 16:27:57 --> Helper loaded: form_helper
INFO - 2023-09-29 16:27:57 --> Helper loaded: my_helper
INFO - 2023-09-29 16:27:57 --> Database Driver Class Initialized
INFO - 2023-09-29 16:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:27:57 --> Controller Class Initialized
DEBUG - 2023-09-29 16:27:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-29 16:27:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:27:57 --> Final output sent to browser
DEBUG - 2023-09-29 16:27:57 --> Total execution time: 0.0730
INFO - 2023-09-29 16:28:19 --> Config Class Initialized
INFO - 2023-09-29 16:28:19 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:28:19 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:28:19 --> Utf8 Class Initialized
INFO - 2023-09-29 16:28:19 --> URI Class Initialized
INFO - 2023-09-29 16:28:19 --> Router Class Initialized
INFO - 2023-09-29 16:28:19 --> Output Class Initialized
INFO - 2023-09-29 16:28:19 --> Security Class Initialized
DEBUG - 2023-09-29 16:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:28:19 --> Input Class Initialized
INFO - 2023-09-29 16:28:19 --> Language Class Initialized
INFO - 2023-09-29 16:28:19 --> Language Class Initialized
INFO - 2023-09-29 16:28:19 --> Config Class Initialized
INFO - 2023-09-29 16:28:19 --> Loader Class Initialized
INFO - 2023-09-29 16:28:19 --> Helper loaded: url_helper
INFO - 2023-09-29 16:28:19 --> Helper loaded: file_helper
INFO - 2023-09-29 16:28:19 --> Helper loaded: form_helper
INFO - 2023-09-29 16:28:19 --> Helper loaded: my_helper
INFO - 2023-09-29 16:28:19 --> Database Driver Class Initialized
INFO - 2023-09-29 16:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:28:19 --> Controller Class Initialized
INFO - 2023-09-29 16:28:20 --> Config Class Initialized
INFO - 2023-09-29 16:28:20 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:28:20 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:28:20 --> Utf8 Class Initialized
INFO - 2023-09-29 16:28:20 --> URI Class Initialized
INFO - 2023-09-29 16:28:20 --> Router Class Initialized
INFO - 2023-09-29 16:28:20 --> Output Class Initialized
INFO - 2023-09-29 16:28:20 --> Security Class Initialized
DEBUG - 2023-09-29 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:28:20 --> Input Class Initialized
INFO - 2023-09-29 16:28:20 --> Language Class Initialized
INFO - 2023-09-29 16:28:20 --> Language Class Initialized
INFO - 2023-09-29 16:28:20 --> Config Class Initialized
INFO - 2023-09-29 16:28:20 --> Loader Class Initialized
INFO - 2023-09-29 16:28:20 --> Helper loaded: url_helper
INFO - 2023-09-29 16:28:20 --> Helper loaded: file_helper
INFO - 2023-09-29 16:28:20 --> Helper loaded: form_helper
INFO - 2023-09-29 16:28:20 --> Helper loaded: my_helper
INFO - 2023-09-29 16:28:20 --> Database Driver Class Initialized
INFO - 2023-09-29 16:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:28:20 --> Controller Class Initialized
DEBUG - 2023-09-29 16:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 16:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:28:20 --> Final output sent to browser
DEBUG - 2023-09-29 16:28:20 --> Total execution time: 0.2863
INFO - 2023-09-29 16:28:20 --> Config Class Initialized
INFO - 2023-09-29 16:28:20 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:28:20 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:28:20 --> Utf8 Class Initialized
INFO - 2023-09-29 16:28:20 --> URI Class Initialized
INFO - 2023-09-29 16:28:20 --> Router Class Initialized
INFO - 2023-09-29 16:28:20 --> Output Class Initialized
INFO - 2023-09-29 16:28:20 --> Security Class Initialized
DEBUG - 2023-09-29 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:28:20 --> Input Class Initialized
INFO - 2023-09-29 16:28:20 --> Language Class Initialized
INFO - 2023-09-29 16:28:21 --> Language Class Initialized
INFO - 2023-09-29 16:28:21 --> Config Class Initialized
INFO - 2023-09-29 16:28:21 --> Loader Class Initialized
INFO - 2023-09-29 16:28:21 --> Helper loaded: url_helper
INFO - 2023-09-29 16:28:21 --> Helper loaded: file_helper
INFO - 2023-09-29 16:28:21 --> Helper loaded: form_helper
INFO - 2023-09-29 16:28:21 --> Helper loaded: my_helper
INFO - 2023-09-29 16:28:21 --> Database Driver Class Initialized
INFO - 2023-09-29 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:28:21 --> Controller Class Initialized
INFO - 2023-09-29 16:29:07 --> Config Class Initialized
INFO - 2023-09-29 16:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:29:07 --> Utf8 Class Initialized
INFO - 2023-09-29 16:29:07 --> URI Class Initialized
INFO - 2023-09-29 16:29:07 --> Router Class Initialized
INFO - 2023-09-29 16:29:07 --> Output Class Initialized
INFO - 2023-09-29 16:29:07 --> Security Class Initialized
DEBUG - 2023-09-29 16:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:29:07 --> Input Class Initialized
INFO - 2023-09-29 16:29:07 --> Language Class Initialized
INFO - 2023-09-29 16:29:07 --> Language Class Initialized
INFO - 2023-09-29 16:29:07 --> Config Class Initialized
INFO - 2023-09-29 16:29:07 --> Loader Class Initialized
INFO - 2023-09-29 16:29:07 --> Helper loaded: url_helper
INFO - 2023-09-29 16:29:07 --> Helper loaded: file_helper
INFO - 2023-09-29 16:29:07 --> Helper loaded: form_helper
INFO - 2023-09-29 16:29:07 --> Helper loaded: my_helper
INFO - 2023-09-29 16:29:07 --> Database Driver Class Initialized
INFO - 2023-09-29 16:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:29:07 --> Controller Class Initialized
INFO - 2023-09-29 16:29:07 --> Final output sent to browser
DEBUG - 2023-09-29 16:29:07 --> Total execution time: 0.1994
INFO - 2023-09-29 16:29:15 --> Config Class Initialized
INFO - 2023-09-29 16:29:15 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:29:15 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:29:15 --> Utf8 Class Initialized
INFO - 2023-09-29 16:29:15 --> URI Class Initialized
INFO - 2023-09-29 16:29:15 --> Router Class Initialized
INFO - 2023-09-29 16:29:15 --> Output Class Initialized
INFO - 2023-09-29 16:29:15 --> Security Class Initialized
DEBUG - 2023-09-29 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:29:15 --> Input Class Initialized
INFO - 2023-09-29 16:29:15 --> Language Class Initialized
INFO - 2023-09-29 16:29:15 --> Language Class Initialized
INFO - 2023-09-29 16:29:15 --> Config Class Initialized
INFO - 2023-09-29 16:29:15 --> Loader Class Initialized
INFO - 2023-09-29 16:29:15 --> Helper loaded: url_helper
INFO - 2023-09-29 16:29:15 --> Helper loaded: file_helper
INFO - 2023-09-29 16:29:15 --> Helper loaded: form_helper
INFO - 2023-09-29 16:29:15 --> Helper loaded: my_helper
INFO - 2023-09-29 16:29:15 --> Database Driver Class Initialized
INFO - 2023-09-29 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:29:15 --> Controller Class Initialized
INFO - 2023-09-29 16:29:15 --> Final output sent to browser
DEBUG - 2023-09-29 16:29:15 --> Total execution time: 0.0381
INFO - 2023-09-29 16:29:38 --> Config Class Initialized
INFO - 2023-09-29 16:29:38 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:29:38 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:29:38 --> Utf8 Class Initialized
INFO - 2023-09-29 16:29:38 --> URI Class Initialized
INFO - 2023-09-29 16:29:38 --> Router Class Initialized
INFO - 2023-09-29 16:29:38 --> Output Class Initialized
INFO - 2023-09-29 16:29:38 --> Security Class Initialized
DEBUG - 2023-09-29 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:29:38 --> Input Class Initialized
INFO - 2023-09-29 16:29:38 --> Language Class Initialized
INFO - 2023-09-29 16:29:38 --> Language Class Initialized
INFO - 2023-09-29 16:29:38 --> Config Class Initialized
INFO - 2023-09-29 16:29:38 --> Loader Class Initialized
INFO - 2023-09-29 16:29:38 --> Helper loaded: url_helper
INFO - 2023-09-29 16:29:38 --> Helper loaded: file_helper
INFO - 2023-09-29 16:29:38 --> Helper loaded: form_helper
INFO - 2023-09-29 16:29:38 --> Helper loaded: my_helper
INFO - 2023-09-29 16:29:38 --> Database Driver Class Initialized
INFO - 2023-09-29 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:29:38 --> Controller Class Initialized
INFO - 2023-09-29 16:29:38 --> Final output sent to browser
DEBUG - 2023-09-29 16:29:38 --> Total execution time: 0.1899
INFO - 2023-09-29 16:32:25 --> Config Class Initialized
INFO - 2023-09-29 16:32:25 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:32:25 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:32:25 --> Utf8 Class Initialized
INFO - 2023-09-29 16:32:25 --> URI Class Initialized
INFO - 2023-09-29 16:32:25 --> Router Class Initialized
INFO - 2023-09-29 16:32:25 --> Output Class Initialized
INFO - 2023-09-29 16:32:25 --> Security Class Initialized
DEBUG - 2023-09-29 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:32:25 --> Input Class Initialized
INFO - 2023-09-29 16:32:25 --> Language Class Initialized
INFO - 2023-09-29 16:32:25 --> Language Class Initialized
INFO - 2023-09-29 16:32:25 --> Config Class Initialized
INFO - 2023-09-29 16:32:25 --> Loader Class Initialized
INFO - 2023-09-29 16:32:25 --> Helper loaded: url_helper
INFO - 2023-09-29 16:32:25 --> Helper loaded: file_helper
INFO - 2023-09-29 16:32:25 --> Helper loaded: form_helper
INFO - 2023-09-29 16:32:25 --> Helper loaded: my_helper
INFO - 2023-09-29 16:32:25 --> Database Driver Class Initialized
INFO - 2023-09-29 16:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:32:25 --> Controller Class Initialized
DEBUG - 2023-09-29 16:32:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-29 16:32:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:32:25 --> Final output sent to browser
DEBUG - 2023-09-29 16:32:25 --> Total execution time: 0.0744
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:32:32 --> Utf8 Class Initialized
INFO - 2023-09-29 16:32:32 --> URI Class Initialized
INFO - 2023-09-29 16:32:32 --> Router Class Initialized
INFO - 2023-09-29 16:32:32 --> Output Class Initialized
INFO - 2023-09-29 16:32:32 --> Security Class Initialized
DEBUG - 2023-09-29 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:32:32 --> Input Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Loader Class Initialized
INFO - 2023-09-29 16:32:32 --> Helper loaded: url_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: file_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: form_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: my_helper
INFO - 2023-09-29 16:32:32 --> Database Driver Class Initialized
INFO - 2023-09-29 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:32:32 --> Controller Class Initialized
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:32:32 --> Utf8 Class Initialized
INFO - 2023-09-29 16:32:32 --> URI Class Initialized
INFO - 2023-09-29 16:32:32 --> Router Class Initialized
INFO - 2023-09-29 16:32:32 --> Output Class Initialized
INFO - 2023-09-29 16:32:32 --> Security Class Initialized
DEBUG - 2023-09-29 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:32:32 --> Input Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Loader Class Initialized
INFO - 2023-09-29 16:32:32 --> Helper loaded: url_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: file_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: form_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: my_helper
INFO - 2023-09-29 16:32:32 --> Database Driver Class Initialized
INFO - 2023-09-29 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:32:32 --> Controller Class Initialized
DEBUG - 2023-09-29 16:32:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 16:32:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:32:32 --> Final output sent to browser
DEBUG - 2023-09-29 16:32:32 --> Total execution time: 0.0343
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:32:32 --> Utf8 Class Initialized
INFO - 2023-09-29 16:32:32 --> URI Class Initialized
INFO - 2023-09-29 16:32:32 --> Router Class Initialized
INFO - 2023-09-29 16:32:32 --> Output Class Initialized
INFO - 2023-09-29 16:32:32 --> Security Class Initialized
DEBUG - 2023-09-29 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:32:32 --> Input Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Language Class Initialized
INFO - 2023-09-29 16:32:32 --> Config Class Initialized
INFO - 2023-09-29 16:32:32 --> Loader Class Initialized
INFO - 2023-09-29 16:32:32 --> Helper loaded: url_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: file_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: form_helper
INFO - 2023-09-29 16:32:32 --> Helper loaded: my_helper
INFO - 2023-09-29 16:32:32 --> Database Driver Class Initialized
INFO - 2023-09-29 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:32:32 --> Controller Class Initialized
INFO - 2023-09-29 16:34:04 --> Config Class Initialized
INFO - 2023-09-29 16:34:04 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:04 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:04 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:04 --> URI Class Initialized
INFO - 2023-09-29 16:34:04 --> Router Class Initialized
INFO - 2023-09-29 16:34:04 --> Output Class Initialized
INFO - 2023-09-29 16:34:04 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:04 --> Input Class Initialized
INFO - 2023-09-29 16:34:04 --> Language Class Initialized
INFO - 2023-09-29 16:34:04 --> Language Class Initialized
INFO - 2023-09-29 16:34:04 --> Config Class Initialized
INFO - 2023-09-29 16:34:04 --> Loader Class Initialized
INFO - 2023-09-29 16:34:04 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:04 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:04 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:04 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:04 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:04 --> Controller Class Initialized
DEBUG - 2023-09-29 16:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-29 16:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:34:04 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:04 --> Total execution time: 0.1302
INFO - 2023-09-29 16:34:15 --> Config Class Initialized
INFO - 2023-09-29 16:34:15 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:15 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:15 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:15 --> URI Class Initialized
INFO - 2023-09-29 16:34:15 --> Router Class Initialized
INFO - 2023-09-29 16:34:15 --> Output Class Initialized
INFO - 2023-09-29 16:34:15 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:15 --> Input Class Initialized
INFO - 2023-09-29 16:34:15 --> Language Class Initialized
INFO - 2023-09-29 16:34:15 --> Language Class Initialized
INFO - 2023-09-29 16:34:15 --> Config Class Initialized
INFO - 2023-09-29 16:34:15 --> Loader Class Initialized
INFO - 2023-09-29 16:34:15 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:15 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:15 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:16 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:16 --> Controller Class Initialized
INFO - 2023-09-29 16:34:16 --> Config Class Initialized
INFO - 2023-09-29 16:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:16 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:16 --> URI Class Initialized
INFO - 2023-09-29 16:34:16 --> Router Class Initialized
INFO - 2023-09-29 16:34:16 --> Output Class Initialized
INFO - 2023-09-29 16:34:16 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:16 --> Input Class Initialized
INFO - 2023-09-29 16:34:16 --> Language Class Initialized
INFO - 2023-09-29 16:34:16 --> Language Class Initialized
INFO - 2023-09-29 16:34:16 --> Config Class Initialized
INFO - 2023-09-29 16:34:16 --> Loader Class Initialized
INFO - 2023-09-29 16:34:16 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:16 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:16 --> Controller Class Initialized
DEBUG - 2023-09-29 16:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 16:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:34:16 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:16 --> Total execution time: 0.0531
INFO - 2023-09-29 16:34:16 --> Config Class Initialized
INFO - 2023-09-29 16:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:16 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:16 --> URI Class Initialized
INFO - 2023-09-29 16:34:16 --> Router Class Initialized
INFO - 2023-09-29 16:34:16 --> Output Class Initialized
INFO - 2023-09-29 16:34:16 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:16 --> Input Class Initialized
INFO - 2023-09-29 16:34:16 --> Language Class Initialized
INFO - 2023-09-29 16:34:16 --> Language Class Initialized
INFO - 2023-09-29 16:34:16 --> Config Class Initialized
INFO - 2023-09-29 16:34:16 --> Loader Class Initialized
INFO - 2023-09-29 16:34:16 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:16 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:16 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:16 --> Controller Class Initialized
INFO - 2023-09-29 16:34:23 --> Config Class Initialized
INFO - 2023-09-29 16:34:23 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:23 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:23 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:23 --> URI Class Initialized
INFO - 2023-09-29 16:34:23 --> Router Class Initialized
INFO - 2023-09-29 16:34:23 --> Output Class Initialized
INFO - 2023-09-29 16:34:23 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:23 --> Input Class Initialized
INFO - 2023-09-29 16:34:23 --> Language Class Initialized
INFO - 2023-09-29 16:34:23 --> Language Class Initialized
INFO - 2023-09-29 16:34:23 --> Config Class Initialized
INFO - 2023-09-29 16:34:23 --> Loader Class Initialized
INFO - 2023-09-29 16:34:23 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:23 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:23 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:23 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:23 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:23 --> Controller Class Initialized
INFO - 2023-09-29 16:34:23 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:23 --> Total execution time: 0.0623
INFO - 2023-09-29 16:34:37 --> Config Class Initialized
INFO - 2023-09-29 16:34:37 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:37 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:37 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:37 --> URI Class Initialized
INFO - 2023-09-29 16:34:37 --> Router Class Initialized
INFO - 2023-09-29 16:34:37 --> Output Class Initialized
INFO - 2023-09-29 16:34:37 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:37 --> Input Class Initialized
INFO - 2023-09-29 16:34:37 --> Language Class Initialized
INFO - 2023-09-29 16:34:37 --> Language Class Initialized
INFO - 2023-09-29 16:34:37 --> Config Class Initialized
INFO - 2023-09-29 16:34:37 --> Loader Class Initialized
INFO - 2023-09-29 16:34:37 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:37 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:37 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:37 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:37 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:37 --> Controller Class Initialized
INFO - 2023-09-29 16:34:37 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:37 --> Total execution time: 0.1685
INFO - 2023-09-29 16:34:39 --> Config Class Initialized
INFO - 2023-09-29 16:34:39 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:39 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:39 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:39 --> URI Class Initialized
INFO - 2023-09-29 16:34:39 --> Router Class Initialized
INFO - 2023-09-29 16:34:39 --> Output Class Initialized
INFO - 2023-09-29 16:34:39 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:39 --> Input Class Initialized
INFO - 2023-09-29 16:34:39 --> Language Class Initialized
INFO - 2023-09-29 16:34:39 --> Language Class Initialized
INFO - 2023-09-29 16:34:39 --> Config Class Initialized
INFO - 2023-09-29 16:34:39 --> Loader Class Initialized
INFO - 2023-09-29 16:34:39 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:39 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:39 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:39 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:39 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:39 --> Controller Class Initialized
INFO - 2023-09-29 16:34:39 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:39 --> Total execution time: 0.0463
INFO - 2023-09-29 16:34:41 --> Config Class Initialized
INFO - 2023-09-29 16:34:41 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:41 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:41 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:41 --> URI Class Initialized
INFO - 2023-09-29 16:34:41 --> Router Class Initialized
INFO - 2023-09-29 16:34:41 --> Output Class Initialized
INFO - 2023-09-29 16:34:41 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:41 --> Input Class Initialized
INFO - 2023-09-29 16:34:41 --> Language Class Initialized
INFO - 2023-09-29 16:34:41 --> Language Class Initialized
INFO - 2023-09-29 16:34:41 --> Config Class Initialized
INFO - 2023-09-29 16:34:41 --> Loader Class Initialized
INFO - 2023-09-29 16:34:41 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:41 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:41 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:41 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:41 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:41 --> Controller Class Initialized
INFO - 2023-09-29 16:34:41 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:41 --> Total execution time: 0.0340
INFO - 2023-09-29 16:34:47 --> Config Class Initialized
INFO - 2023-09-29 16:34:47 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:47 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:47 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:47 --> URI Class Initialized
INFO - 2023-09-29 16:34:47 --> Router Class Initialized
INFO - 2023-09-29 16:34:47 --> Output Class Initialized
INFO - 2023-09-29 16:34:47 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:47 --> Input Class Initialized
INFO - 2023-09-29 16:34:47 --> Language Class Initialized
INFO - 2023-09-29 16:34:47 --> Language Class Initialized
INFO - 2023-09-29 16:34:47 --> Config Class Initialized
INFO - 2023-09-29 16:34:47 --> Loader Class Initialized
INFO - 2023-09-29 16:34:47 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:47 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:47 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:47 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:47 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:47 --> Controller Class Initialized
INFO - 2023-09-29 16:34:47 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:47 --> Total execution time: 0.0390
INFO - 2023-09-29 16:34:48 --> Config Class Initialized
INFO - 2023-09-29 16:34:48 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:48 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:48 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:48 --> URI Class Initialized
INFO - 2023-09-29 16:34:48 --> Router Class Initialized
INFO - 2023-09-29 16:34:48 --> Output Class Initialized
INFO - 2023-09-29 16:34:48 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:48 --> Input Class Initialized
INFO - 2023-09-29 16:34:48 --> Language Class Initialized
INFO - 2023-09-29 16:34:48 --> Language Class Initialized
INFO - 2023-09-29 16:34:48 --> Config Class Initialized
INFO - 2023-09-29 16:34:48 --> Loader Class Initialized
INFO - 2023-09-29 16:34:48 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:48 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:48 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:48 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:48 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:48 --> Controller Class Initialized
INFO - 2023-09-29 16:34:48 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:48 --> Total execution time: 0.0716
INFO - 2023-09-29 16:34:49 --> Config Class Initialized
INFO - 2023-09-29 16:34:49 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:49 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:49 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:49 --> URI Class Initialized
INFO - 2023-09-29 16:34:49 --> Router Class Initialized
INFO - 2023-09-29 16:34:49 --> Output Class Initialized
INFO - 2023-09-29 16:34:49 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:49 --> Input Class Initialized
INFO - 2023-09-29 16:34:49 --> Language Class Initialized
INFO - 2023-09-29 16:34:49 --> Language Class Initialized
INFO - 2023-09-29 16:34:49 --> Config Class Initialized
INFO - 2023-09-29 16:34:49 --> Loader Class Initialized
INFO - 2023-09-29 16:34:49 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:49 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:49 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:49 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:49 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:49 --> Controller Class Initialized
INFO - 2023-09-29 16:34:49 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:49 --> Total execution time: 0.1268
INFO - 2023-09-29 16:34:56 --> Config Class Initialized
INFO - 2023-09-29 16:34:56 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:34:56 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:34:56 --> Utf8 Class Initialized
INFO - 2023-09-29 16:34:56 --> URI Class Initialized
INFO - 2023-09-29 16:34:56 --> Router Class Initialized
INFO - 2023-09-29 16:34:56 --> Output Class Initialized
INFO - 2023-09-29 16:34:56 --> Security Class Initialized
DEBUG - 2023-09-29 16:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:34:56 --> Input Class Initialized
INFO - 2023-09-29 16:34:56 --> Language Class Initialized
INFO - 2023-09-29 16:34:56 --> Language Class Initialized
INFO - 2023-09-29 16:34:56 --> Config Class Initialized
INFO - 2023-09-29 16:34:56 --> Loader Class Initialized
INFO - 2023-09-29 16:34:56 --> Helper loaded: url_helper
INFO - 2023-09-29 16:34:56 --> Helper loaded: file_helper
INFO - 2023-09-29 16:34:56 --> Helper loaded: form_helper
INFO - 2023-09-29 16:34:56 --> Helper loaded: my_helper
INFO - 2023-09-29 16:34:56 --> Database Driver Class Initialized
INFO - 2023-09-29 16:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:34:56 --> Controller Class Initialized
INFO - 2023-09-29 16:34:56 --> Final output sent to browser
DEBUG - 2023-09-29 16:34:56 --> Total execution time: 0.0846
INFO - 2023-09-29 16:38:24 --> Config Class Initialized
INFO - 2023-09-29 16:38:24 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:38:24 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:38:24 --> Utf8 Class Initialized
INFO - 2023-09-29 16:38:24 --> URI Class Initialized
INFO - 2023-09-29 16:38:24 --> Router Class Initialized
INFO - 2023-09-29 16:38:24 --> Output Class Initialized
INFO - 2023-09-29 16:38:24 --> Security Class Initialized
DEBUG - 2023-09-29 16:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:38:24 --> Input Class Initialized
INFO - 2023-09-29 16:38:24 --> Language Class Initialized
INFO - 2023-09-29 16:38:24 --> Language Class Initialized
INFO - 2023-09-29 16:38:24 --> Config Class Initialized
INFO - 2023-09-29 16:38:24 --> Loader Class Initialized
INFO - 2023-09-29 16:38:24 --> Helper loaded: url_helper
INFO - 2023-09-29 16:38:24 --> Helper loaded: file_helper
INFO - 2023-09-29 16:38:24 --> Helper loaded: form_helper
INFO - 2023-09-29 16:38:24 --> Helper loaded: my_helper
INFO - 2023-09-29 16:38:24 --> Database Driver Class Initialized
INFO - 2023-09-29 16:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:38:24 --> Controller Class Initialized
INFO - 2023-09-29 16:44:51 --> Config Class Initialized
INFO - 2023-09-29 16:44:51 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:44:51 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:44:51 --> Utf8 Class Initialized
INFO - 2023-09-29 16:44:51 --> URI Class Initialized
INFO - 2023-09-29 16:44:51 --> Router Class Initialized
INFO - 2023-09-29 16:44:51 --> Output Class Initialized
INFO - 2023-09-29 16:44:51 --> Security Class Initialized
DEBUG - 2023-09-29 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:44:51 --> Input Class Initialized
INFO - 2023-09-29 16:44:51 --> Language Class Initialized
INFO - 2023-09-29 16:44:51 --> Language Class Initialized
INFO - 2023-09-29 16:44:51 --> Config Class Initialized
INFO - 2023-09-29 16:44:51 --> Loader Class Initialized
INFO - 2023-09-29 16:44:51 --> Helper loaded: url_helper
INFO - 2023-09-29 16:44:51 --> Helper loaded: file_helper
INFO - 2023-09-29 16:44:51 --> Helper loaded: form_helper
INFO - 2023-09-29 16:44:51 --> Helper loaded: my_helper
INFO - 2023-09-29 16:44:51 --> Database Driver Class Initialized
INFO - 2023-09-29 16:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:44:51 --> Controller Class Initialized
INFO - 2023-09-29 16:44:51 --> Final output sent to browser
DEBUG - 2023-09-29 16:44:51 --> Total execution time: 0.4298
INFO - 2023-09-29 16:45:10 --> Config Class Initialized
INFO - 2023-09-29 16:45:10 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:10 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:10 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:10 --> URI Class Initialized
INFO - 2023-09-29 16:45:10 --> Router Class Initialized
INFO - 2023-09-29 16:45:10 --> Output Class Initialized
INFO - 2023-09-29 16:45:10 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:10 --> Input Class Initialized
INFO - 2023-09-29 16:45:11 --> Language Class Initialized
INFO - 2023-09-29 16:45:11 --> Language Class Initialized
INFO - 2023-09-29 16:45:11 --> Config Class Initialized
INFO - 2023-09-29 16:45:11 --> Loader Class Initialized
INFO - 2023-09-29 16:45:11 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:11 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:11 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:11 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:11 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:11 --> Controller Class Initialized
INFO - 2023-09-29 16:45:11 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:11 --> Total execution time: 0.2986
INFO - 2023-09-29 16:45:12 --> Config Class Initialized
INFO - 2023-09-29 16:45:12 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:12 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:12 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:12 --> URI Class Initialized
INFO - 2023-09-29 16:45:12 --> Router Class Initialized
INFO - 2023-09-29 16:45:12 --> Output Class Initialized
INFO - 2023-09-29 16:45:12 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:12 --> Input Class Initialized
INFO - 2023-09-29 16:45:12 --> Language Class Initialized
INFO - 2023-09-29 16:45:12 --> Language Class Initialized
INFO - 2023-09-29 16:45:12 --> Config Class Initialized
INFO - 2023-09-29 16:45:12 --> Loader Class Initialized
INFO - 2023-09-29 16:45:12 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:12 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:12 --> Controller Class Initialized
INFO - 2023-09-29 16:45:12 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:12 --> Total execution time: 0.0434
INFO - 2023-09-29 16:45:12 --> Config Class Initialized
INFO - 2023-09-29 16:45:12 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:12 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:12 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:12 --> URI Class Initialized
INFO - 2023-09-29 16:45:12 --> Router Class Initialized
INFO - 2023-09-29 16:45:12 --> Output Class Initialized
INFO - 2023-09-29 16:45:12 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:12 --> Input Class Initialized
INFO - 2023-09-29 16:45:12 --> Language Class Initialized
INFO - 2023-09-29 16:45:12 --> Language Class Initialized
INFO - 2023-09-29 16:45:12 --> Config Class Initialized
INFO - 2023-09-29 16:45:12 --> Loader Class Initialized
INFO - 2023-09-29 16:45:12 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:12 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:12 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:12 --> Controller Class Initialized
INFO - 2023-09-29 16:45:12 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:12 --> Total execution time: 0.0384
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:19 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:19 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:19 --> URI Class Initialized
INFO - 2023-09-29 16:45:19 --> Router Class Initialized
INFO - 2023-09-29 16:45:19 --> Output Class Initialized
INFO - 2023-09-29 16:45:19 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:19 --> Input Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Loader Class Initialized
INFO - 2023-09-29 16:45:19 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:19 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:19 --> Controller Class Initialized
INFO - 2023-09-29 16:45:19 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:19 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:19 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:19 --> URI Class Initialized
INFO - 2023-09-29 16:45:19 --> Router Class Initialized
INFO - 2023-09-29 16:45:19 --> Output Class Initialized
INFO - 2023-09-29 16:45:19 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:19 --> Input Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Loader Class Initialized
INFO - 2023-09-29 16:45:19 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:19 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:19 --> Controller Class Initialized
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:19 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:19 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:19 --> URI Class Initialized
INFO - 2023-09-29 16:45:19 --> Router Class Initialized
INFO - 2023-09-29 16:45:19 --> Output Class Initialized
INFO - 2023-09-29 16:45:19 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:19 --> Input Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Language Class Initialized
INFO - 2023-09-29 16:45:19 --> Config Class Initialized
INFO - 2023-09-29 16:45:19 --> Loader Class Initialized
INFO - 2023-09-29 16:45:19 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:19 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:19 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:19 --> Controller Class Initialized
DEBUG - 2023-09-29 16:45:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 16:45:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:45:19 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:19 --> Total execution time: 0.0612
INFO - 2023-09-29 16:45:35 --> Config Class Initialized
INFO - 2023-09-29 16:45:35 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:35 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:35 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:35 --> URI Class Initialized
INFO - 2023-09-29 16:45:35 --> Router Class Initialized
INFO - 2023-09-29 16:45:35 --> Output Class Initialized
INFO - 2023-09-29 16:45:35 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:35 --> Input Class Initialized
INFO - 2023-09-29 16:45:35 --> Language Class Initialized
INFO - 2023-09-29 16:45:35 --> Language Class Initialized
INFO - 2023-09-29 16:45:35 --> Config Class Initialized
INFO - 2023-09-29 16:45:35 --> Loader Class Initialized
INFO - 2023-09-29 16:45:35 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:35 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:35 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:35 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:36 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:36 --> Controller Class Initialized
INFO - 2023-09-29 16:45:36 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:45:36 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:36 --> Total execution time: 0.3201
INFO - 2023-09-29 16:45:36 --> Config Class Initialized
INFO - 2023-09-29 16:45:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:36 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:36 --> URI Class Initialized
INFO - 2023-09-29 16:45:36 --> Router Class Initialized
INFO - 2023-09-29 16:45:36 --> Output Class Initialized
INFO - 2023-09-29 16:45:36 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:36 --> Input Class Initialized
INFO - 2023-09-29 16:45:36 --> Language Class Initialized
INFO - 2023-09-29 16:45:36 --> Language Class Initialized
INFO - 2023-09-29 16:45:36 --> Config Class Initialized
INFO - 2023-09-29 16:45:36 --> Loader Class Initialized
INFO - 2023-09-29 16:45:36 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:36 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:36 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:36 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:36 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:36 --> Controller Class Initialized
DEBUG - 2023-09-29 16:45:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:45:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:45:36 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:36 --> Total execution time: 0.1036
INFO - 2023-09-29 16:45:43 --> Config Class Initialized
INFO - 2023-09-29 16:45:43 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:43 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:43 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:43 --> URI Class Initialized
INFO - 2023-09-29 16:45:43 --> Router Class Initialized
INFO - 2023-09-29 16:45:43 --> Output Class Initialized
INFO - 2023-09-29 16:45:43 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:43 --> Input Class Initialized
INFO - 2023-09-29 16:45:43 --> Language Class Initialized
INFO - 2023-09-29 16:45:43 --> Language Class Initialized
INFO - 2023-09-29 16:45:43 --> Config Class Initialized
INFO - 2023-09-29 16:45:43 --> Loader Class Initialized
INFO - 2023-09-29 16:45:43 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:43 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:43 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:43 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:43 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:43 --> Controller Class Initialized
DEBUG - 2023-09-29 16:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 16:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:45:44 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:44 --> Total execution time: 0.4539
INFO - 2023-09-29 16:45:54 --> Config Class Initialized
INFO - 2023-09-29 16:45:54 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:54 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:54 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:54 --> URI Class Initialized
DEBUG - 2023-09-29 16:45:54 --> No URI present. Default controller set.
INFO - 2023-09-29 16:45:54 --> Router Class Initialized
INFO - 2023-09-29 16:45:54 --> Output Class Initialized
INFO - 2023-09-29 16:45:54 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:54 --> Input Class Initialized
INFO - 2023-09-29 16:45:54 --> Language Class Initialized
INFO - 2023-09-29 16:45:54 --> Language Class Initialized
INFO - 2023-09-29 16:45:54 --> Config Class Initialized
INFO - 2023-09-29 16:45:54 --> Loader Class Initialized
INFO - 2023-09-29 16:45:54 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:54 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:54 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:54 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:54 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:54 --> Controller Class Initialized
DEBUG - 2023-09-29 16:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:45:54 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:54 --> Total execution time: 0.1934
INFO - 2023-09-29 16:45:57 --> Config Class Initialized
INFO - 2023-09-29 16:45:57 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:45:57 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:45:57 --> Utf8 Class Initialized
INFO - 2023-09-29 16:45:57 --> URI Class Initialized
INFO - 2023-09-29 16:45:57 --> Router Class Initialized
INFO - 2023-09-29 16:45:57 --> Output Class Initialized
INFO - 2023-09-29 16:45:57 --> Security Class Initialized
DEBUG - 2023-09-29 16:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:45:57 --> Input Class Initialized
INFO - 2023-09-29 16:45:57 --> Language Class Initialized
INFO - 2023-09-29 16:45:57 --> Language Class Initialized
INFO - 2023-09-29 16:45:57 --> Config Class Initialized
INFO - 2023-09-29 16:45:57 --> Loader Class Initialized
INFO - 2023-09-29 16:45:57 --> Helper loaded: url_helper
INFO - 2023-09-29 16:45:57 --> Helper loaded: file_helper
INFO - 2023-09-29 16:45:57 --> Helper loaded: form_helper
INFO - 2023-09-29 16:45:57 --> Helper loaded: my_helper
INFO - 2023-09-29 16:45:57 --> Database Driver Class Initialized
INFO - 2023-09-29 16:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:45:57 --> Controller Class Initialized
DEBUG - 2023-09-29 16:45:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 16:45:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:45:57 --> Final output sent to browser
DEBUG - 2023-09-29 16:45:57 --> Total execution time: 0.2582
INFO - 2023-09-29 16:46:00 --> Config Class Initialized
INFO - 2023-09-29 16:46:00 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:00 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:00 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:00 --> URI Class Initialized
INFO - 2023-09-29 16:46:00 --> Router Class Initialized
INFO - 2023-09-29 16:46:00 --> Output Class Initialized
INFO - 2023-09-29 16:46:00 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:00 --> Input Class Initialized
INFO - 2023-09-29 16:46:00 --> Language Class Initialized
INFO - 2023-09-29 16:46:00 --> Language Class Initialized
INFO - 2023-09-29 16:46:00 --> Config Class Initialized
INFO - 2023-09-29 16:46:00 --> Loader Class Initialized
INFO - 2023-09-29 16:46:00 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:00 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:00 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:00 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:00 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:00 --> Controller Class Initialized
DEBUG - 2023-09-29 16:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-29 16:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:46:00 --> Final output sent to browser
DEBUG - 2023-09-29 16:46:00 --> Total execution time: 0.1566
INFO - 2023-09-29 16:46:13 --> Config Class Initialized
INFO - 2023-09-29 16:46:13 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:13 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:13 --> URI Class Initialized
INFO - 2023-09-29 16:46:14 --> Router Class Initialized
INFO - 2023-09-29 16:46:14 --> Output Class Initialized
INFO - 2023-09-29 16:46:14 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:14 --> Input Class Initialized
INFO - 2023-09-29 16:46:14 --> Language Class Initialized
INFO - 2023-09-29 16:46:14 --> Language Class Initialized
INFO - 2023-09-29 16:46:14 --> Config Class Initialized
INFO - 2023-09-29 16:46:14 --> Loader Class Initialized
INFO - 2023-09-29 16:46:14 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:14 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:14 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:14 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:14 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:14 --> Controller Class Initialized
DEBUG - 2023-09-29 16:46:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-09-29 16:46:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:46:14 --> Final output sent to browser
DEBUG - 2023-09-29 16:46:14 --> Total execution time: 0.4944
INFO - 2023-09-29 16:46:35 --> Config Class Initialized
INFO - 2023-09-29 16:46:35 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:35 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:35 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:35 --> URI Class Initialized
DEBUG - 2023-09-29 16:46:35 --> No URI present. Default controller set.
INFO - 2023-09-29 16:46:35 --> Router Class Initialized
INFO - 2023-09-29 16:46:35 --> Output Class Initialized
INFO - 2023-09-29 16:46:35 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:35 --> Input Class Initialized
INFO - 2023-09-29 16:46:35 --> Language Class Initialized
INFO - 2023-09-29 16:46:35 --> Language Class Initialized
INFO - 2023-09-29 16:46:35 --> Config Class Initialized
INFO - 2023-09-29 16:46:35 --> Loader Class Initialized
INFO - 2023-09-29 16:46:35 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:35 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:35 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:35 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:35 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:35 --> Controller Class Initialized
DEBUG - 2023-09-29 16:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:46:35 --> Final output sent to browser
DEBUG - 2023-09-29 16:46:35 --> Total execution time: 0.5744
INFO - 2023-09-29 16:46:43 --> Config Class Initialized
INFO - 2023-09-29 16:46:43 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:43 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:43 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:43 --> URI Class Initialized
INFO - 2023-09-29 16:46:43 --> Router Class Initialized
INFO - 2023-09-29 16:46:43 --> Output Class Initialized
INFO - 2023-09-29 16:46:43 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:43 --> Input Class Initialized
INFO - 2023-09-29 16:46:43 --> Language Class Initialized
INFO - 2023-09-29 16:46:43 --> Language Class Initialized
INFO - 2023-09-29 16:46:43 --> Config Class Initialized
INFO - 2023-09-29 16:46:43 --> Loader Class Initialized
INFO - 2023-09-29 16:46:43 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:43 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:43 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:43 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:43 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:43 --> Controller Class Initialized
DEBUG - 2023-09-29 16:46:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-09-29 16:46:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:46:43 --> Final output sent to browser
DEBUG - 2023-09-29 16:46:43 --> Total execution time: 0.0930
INFO - 2023-09-29 16:46:47 --> Config Class Initialized
INFO - 2023-09-29 16:46:47 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:47 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:47 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:47 --> URI Class Initialized
INFO - 2023-09-29 16:46:47 --> Router Class Initialized
INFO - 2023-09-29 16:46:47 --> Output Class Initialized
INFO - 2023-09-29 16:46:47 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:47 --> Input Class Initialized
INFO - 2023-09-29 16:46:47 --> Language Class Initialized
INFO - 2023-09-29 16:46:47 --> Language Class Initialized
INFO - 2023-09-29 16:46:47 --> Config Class Initialized
INFO - 2023-09-29 16:46:47 --> Loader Class Initialized
INFO - 2023-09-29 16:46:47 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:47 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:47 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:47 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:47 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:47 --> Controller Class Initialized
ERROR - 2023-09-29 16:46:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-29 16:46:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-29 16:46:48 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-29 16:46:51 --> Config Class Initialized
INFO - 2023-09-29 16:46:51 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:51 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:51 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:51 --> URI Class Initialized
INFO - 2023-09-29 16:46:51 --> Router Class Initialized
INFO - 2023-09-29 16:46:51 --> Output Class Initialized
INFO - 2023-09-29 16:46:51 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:51 --> Input Class Initialized
INFO - 2023-09-29 16:46:51 --> Language Class Initialized
INFO - 2023-09-29 16:46:51 --> Language Class Initialized
INFO - 2023-09-29 16:46:51 --> Config Class Initialized
INFO - 2023-09-29 16:46:51 --> Loader Class Initialized
INFO - 2023-09-29 16:46:51 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:51 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:51 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:51 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:51 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:51 --> Controller Class Initialized
ERROR - 2023-09-29 16:46:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-29 16:46:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-29 16:46:51 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-29 16:46:54 --> Config Class Initialized
INFO - 2023-09-29 16:46:54 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:46:54 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:46:54 --> Utf8 Class Initialized
INFO - 2023-09-29 16:46:54 --> URI Class Initialized
INFO - 2023-09-29 16:46:54 --> Router Class Initialized
INFO - 2023-09-29 16:46:54 --> Output Class Initialized
INFO - 2023-09-29 16:46:54 --> Security Class Initialized
DEBUG - 2023-09-29 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:46:54 --> Input Class Initialized
INFO - 2023-09-29 16:46:54 --> Language Class Initialized
INFO - 2023-09-29 16:46:54 --> Language Class Initialized
INFO - 2023-09-29 16:46:54 --> Config Class Initialized
INFO - 2023-09-29 16:46:54 --> Loader Class Initialized
INFO - 2023-09-29 16:46:54 --> Helper loaded: url_helper
INFO - 2023-09-29 16:46:54 --> Helper loaded: file_helper
INFO - 2023-09-29 16:46:54 --> Helper loaded: form_helper
INFO - 2023-09-29 16:46:54 --> Helper loaded: my_helper
INFO - 2023-09-29 16:46:54 --> Database Driver Class Initialized
INFO - 2023-09-29 16:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:46:54 --> Controller Class Initialized
ERROR - 2023-09-29 16:46:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-29 16:46:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-29 16:46:54 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-29 16:47:15 --> Config Class Initialized
INFO - 2023-09-29 16:47:15 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:15 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:15 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:15 --> URI Class Initialized
INFO - 2023-09-29 16:47:15 --> Router Class Initialized
INFO - 2023-09-29 16:47:15 --> Output Class Initialized
INFO - 2023-09-29 16:47:15 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:15 --> Input Class Initialized
INFO - 2023-09-29 16:47:15 --> Language Class Initialized
INFO - 2023-09-29 16:47:15 --> Language Class Initialized
INFO - 2023-09-29 16:47:15 --> Config Class Initialized
INFO - 2023-09-29 16:47:15 --> Loader Class Initialized
INFO - 2023-09-29 16:47:15 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:15 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:15 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:15 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:15 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:15 --> Controller Class Initialized
ERROR - 2023-09-29 16:47:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-29 16:47:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-29 16:47:15 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-29 16:47:29 --> Config Class Initialized
INFO - 2023-09-29 16:47:29 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:29 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:29 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:29 --> URI Class Initialized
INFO - 2023-09-29 16:47:29 --> Router Class Initialized
INFO - 2023-09-29 16:47:29 --> Output Class Initialized
INFO - 2023-09-29 16:47:29 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:29 --> Input Class Initialized
INFO - 2023-09-29 16:47:29 --> Language Class Initialized
INFO - 2023-09-29 16:47:29 --> Language Class Initialized
INFO - 2023-09-29 16:47:29 --> Config Class Initialized
INFO - 2023-09-29 16:47:29 --> Loader Class Initialized
INFO - 2023-09-29 16:47:29 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:29 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:29 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:29 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:29 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:29 --> Controller Class Initialized
DEBUG - 2023-09-29 16:47:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2023-09-29 16:47:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:47:29 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:29 --> Total execution time: 0.2181
INFO - 2023-09-29 16:47:31 --> Config Class Initialized
INFO - 2023-09-29 16:47:31 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:31 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:31 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:31 --> URI Class Initialized
INFO - 2023-09-29 16:47:31 --> Router Class Initialized
INFO - 2023-09-29 16:47:31 --> Output Class Initialized
INFO - 2023-09-29 16:47:31 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:31 --> Input Class Initialized
INFO - 2023-09-29 16:47:31 --> Language Class Initialized
INFO - 2023-09-29 16:47:31 --> Language Class Initialized
INFO - 2023-09-29 16:47:31 --> Config Class Initialized
INFO - 2023-09-29 16:47:31 --> Loader Class Initialized
INFO - 2023-09-29 16:47:31 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:31 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:31 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:31 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:31 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:31 --> Controller Class Initialized
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:31 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-09-29 16:47:32 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
DEBUG - 2023-09-29 16:47:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak.php
INFO - 2023-09-29 16:47:32 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:32 --> Total execution time: 0.6597
INFO - 2023-09-29 16:47:36 --> Config Class Initialized
INFO - 2023-09-29 16:47:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:36 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:36 --> URI Class Initialized
INFO - 2023-09-29 16:47:36 --> Router Class Initialized
INFO - 2023-09-29 16:47:36 --> Output Class Initialized
INFO - 2023-09-29 16:47:36 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:36 --> Input Class Initialized
INFO - 2023-09-29 16:47:36 --> Language Class Initialized
INFO - 2023-09-29 16:47:36 --> Language Class Initialized
INFO - 2023-09-29 16:47:36 --> Config Class Initialized
INFO - 2023-09-29 16:47:36 --> Loader Class Initialized
INFO - 2023-09-29 16:47:36 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:36 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:36 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:36 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:36 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:36 --> Controller Class Initialized
DEBUG - 2023-09-29 16:47:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak_ekstra.php
INFO - 2023-09-29 16:47:37 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:37 --> Total execution time: 0.2731
INFO - 2023-09-29 16:47:47 --> Config Class Initialized
INFO - 2023-09-29 16:47:47 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:47 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:47 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:47 --> URI Class Initialized
DEBUG - 2023-09-29 16:47:47 --> No URI present. Default controller set.
INFO - 2023-09-29 16:47:47 --> Router Class Initialized
INFO - 2023-09-29 16:47:47 --> Output Class Initialized
INFO - 2023-09-29 16:47:47 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:47 --> Input Class Initialized
INFO - 2023-09-29 16:47:47 --> Language Class Initialized
INFO - 2023-09-29 16:47:47 --> Language Class Initialized
INFO - 2023-09-29 16:47:47 --> Config Class Initialized
INFO - 2023-09-29 16:47:47 --> Loader Class Initialized
INFO - 2023-09-29 16:47:47 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:47 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:47 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:47 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:47 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:47 --> Controller Class Initialized
DEBUG - 2023-09-29 16:47:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:47:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:47:47 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:47 --> Total execution time: 0.3542
INFO - 2023-09-29 16:47:48 --> Config Class Initialized
INFO - 2023-09-29 16:47:48 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:48 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:48 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:48 --> URI Class Initialized
DEBUG - 2023-09-29 16:47:48 --> No URI present. Default controller set.
INFO - 2023-09-29 16:47:48 --> Router Class Initialized
INFO - 2023-09-29 16:47:48 --> Output Class Initialized
INFO - 2023-09-29 16:47:48 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:48 --> Input Class Initialized
INFO - 2023-09-29 16:47:48 --> Language Class Initialized
INFO - 2023-09-29 16:47:48 --> Language Class Initialized
INFO - 2023-09-29 16:47:48 --> Config Class Initialized
INFO - 2023-09-29 16:47:48 --> Loader Class Initialized
INFO - 2023-09-29 16:47:48 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:48 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:48 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:48 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:48 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:48 --> Controller Class Initialized
DEBUG - 2023-09-29 16:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:47:48 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:48 --> Total execution time: 0.0441
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:59 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:59 --> URI Class Initialized
INFO - 2023-09-29 16:47:59 --> Router Class Initialized
INFO - 2023-09-29 16:47:59 --> Output Class Initialized
INFO - 2023-09-29 16:47:59 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:59 --> Input Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Loader Class Initialized
INFO - 2023-09-29 16:47:59 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:59 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:59 --> Controller Class Initialized
INFO - 2023-09-29 16:47:59 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:59 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:59 --> URI Class Initialized
INFO - 2023-09-29 16:47:59 --> Router Class Initialized
INFO - 2023-09-29 16:47:59 --> Output Class Initialized
INFO - 2023-09-29 16:47:59 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:59 --> Input Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Loader Class Initialized
INFO - 2023-09-29 16:47:59 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:59 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:59 --> Controller Class Initialized
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:47:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:47:59 --> Utf8 Class Initialized
INFO - 2023-09-29 16:47:59 --> URI Class Initialized
INFO - 2023-09-29 16:47:59 --> Router Class Initialized
INFO - 2023-09-29 16:47:59 --> Output Class Initialized
INFO - 2023-09-29 16:47:59 --> Security Class Initialized
DEBUG - 2023-09-29 16:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:47:59 --> Input Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Language Class Initialized
INFO - 2023-09-29 16:47:59 --> Config Class Initialized
INFO - 2023-09-29 16:47:59 --> Loader Class Initialized
INFO - 2023-09-29 16:47:59 --> Helper loaded: url_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: file_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: form_helper
INFO - 2023-09-29 16:47:59 --> Helper loaded: my_helper
INFO - 2023-09-29 16:47:59 --> Database Driver Class Initialized
INFO - 2023-09-29 16:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:47:59 --> Controller Class Initialized
DEBUG - 2023-09-29 16:47:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 16:47:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:47:59 --> Final output sent to browser
DEBUG - 2023-09-29 16:47:59 --> Total execution time: 0.0344
INFO - 2023-09-29 16:48:01 --> Config Class Initialized
INFO - 2023-09-29 16:48:01 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:48:01 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:48:01 --> Utf8 Class Initialized
INFO - 2023-09-29 16:48:01 --> URI Class Initialized
INFO - 2023-09-29 16:48:01 --> Router Class Initialized
INFO - 2023-09-29 16:48:01 --> Output Class Initialized
INFO - 2023-09-29 16:48:01 --> Security Class Initialized
DEBUG - 2023-09-29 16:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:48:01 --> Input Class Initialized
INFO - 2023-09-29 16:48:01 --> Language Class Initialized
INFO - 2023-09-29 16:48:01 --> Language Class Initialized
INFO - 2023-09-29 16:48:01 --> Config Class Initialized
INFO - 2023-09-29 16:48:01 --> Loader Class Initialized
INFO - 2023-09-29 16:48:01 --> Helper loaded: url_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: file_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: form_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: my_helper
INFO - 2023-09-29 16:48:01 --> Database Driver Class Initialized
INFO - 2023-09-29 16:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:48:01 --> Controller Class Initialized
INFO - 2023-09-29 16:48:01 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:48:01 --> Final output sent to browser
DEBUG - 2023-09-29 16:48:01 --> Total execution time: 0.1073
INFO - 2023-09-29 16:48:01 --> Config Class Initialized
INFO - 2023-09-29 16:48:01 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:48:01 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:48:01 --> Utf8 Class Initialized
INFO - 2023-09-29 16:48:01 --> URI Class Initialized
INFO - 2023-09-29 16:48:01 --> Router Class Initialized
INFO - 2023-09-29 16:48:01 --> Output Class Initialized
INFO - 2023-09-29 16:48:01 --> Security Class Initialized
DEBUG - 2023-09-29 16:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:48:01 --> Input Class Initialized
INFO - 2023-09-29 16:48:01 --> Language Class Initialized
INFO - 2023-09-29 16:48:01 --> Language Class Initialized
INFO - 2023-09-29 16:48:01 --> Config Class Initialized
INFO - 2023-09-29 16:48:01 --> Loader Class Initialized
INFO - 2023-09-29 16:48:01 --> Helper loaded: url_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: file_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: form_helper
INFO - 2023-09-29 16:48:01 --> Helper loaded: my_helper
INFO - 2023-09-29 16:48:01 --> Database Driver Class Initialized
INFO - 2023-09-29 16:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:48:01 --> Controller Class Initialized
DEBUG - 2023-09-29 16:48:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:48:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:48:01 --> Final output sent to browser
DEBUG - 2023-09-29 16:48:01 --> Total execution time: 0.0600
INFO - 2023-09-29 16:48:04 --> Config Class Initialized
INFO - 2023-09-29 16:48:04 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:48:04 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:48:04 --> Utf8 Class Initialized
INFO - 2023-09-29 16:48:04 --> URI Class Initialized
INFO - 2023-09-29 16:48:04 --> Router Class Initialized
INFO - 2023-09-29 16:48:04 --> Output Class Initialized
INFO - 2023-09-29 16:48:04 --> Security Class Initialized
DEBUG - 2023-09-29 16:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:48:04 --> Input Class Initialized
INFO - 2023-09-29 16:48:04 --> Language Class Initialized
INFO - 2023-09-29 16:48:04 --> Language Class Initialized
INFO - 2023-09-29 16:48:04 --> Config Class Initialized
INFO - 2023-09-29 16:48:04 --> Loader Class Initialized
INFO - 2023-09-29 16:48:04 --> Helper loaded: url_helper
INFO - 2023-09-29 16:48:04 --> Helper loaded: file_helper
INFO - 2023-09-29 16:48:04 --> Helper loaded: form_helper
INFO - 2023-09-29 16:48:04 --> Helper loaded: my_helper
INFO - 2023-09-29 16:48:04 --> Database Driver Class Initialized
INFO - 2023-09-29 16:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:48:04 --> Controller Class Initialized
DEBUG - 2023-09-29 16:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-29 16:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:48:04 --> Final output sent to browser
DEBUG - 2023-09-29 16:48:04 --> Total execution time: 0.0465
INFO - 2023-09-29 16:48:06 --> Config Class Initialized
INFO - 2023-09-29 16:48:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:48:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:48:06 --> Utf8 Class Initialized
INFO - 2023-09-29 16:48:06 --> URI Class Initialized
INFO - 2023-09-29 16:48:06 --> Router Class Initialized
INFO - 2023-09-29 16:48:06 --> Output Class Initialized
INFO - 2023-09-29 16:48:06 --> Security Class Initialized
DEBUG - 2023-09-29 16:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:48:06 --> Input Class Initialized
INFO - 2023-09-29 16:48:06 --> Language Class Initialized
INFO - 2023-09-29 16:48:06 --> Language Class Initialized
INFO - 2023-09-29 16:48:06 --> Config Class Initialized
INFO - 2023-09-29 16:48:06 --> Loader Class Initialized
INFO - 2023-09-29 16:48:06 --> Helper loaded: url_helper
INFO - 2023-09-29 16:48:06 --> Helper loaded: file_helper
INFO - 2023-09-29 16:48:06 --> Helper loaded: form_helper
INFO - 2023-09-29 16:48:06 --> Helper loaded: my_helper
INFO - 2023-09-29 16:48:06 --> Database Driver Class Initialized
INFO - 2023-09-29 16:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:48:06 --> Controller Class Initialized
DEBUG - 2023-09-29 16:48:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-29 16:48:06 --> Final output sent to browser
DEBUG - 2023-09-29 16:48:06 --> Total execution time: 0.0913
INFO - 2023-09-29 16:48:43 --> Config Class Initialized
INFO - 2023-09-29 16:48:43 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:48:43 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:48:43 --> Utf8 Class Initialized
INFO - 2023-09-29 16:48:43 --> URI Class Initialized
INFO - 2023-09-29 16:48:43 --> Router Class Initialized
INFO - 2023-09-29 16:48:43 --> Output Class Initialized
INFO - 2023-09-29 16:48:43 --> Security Class Initialized
DEBUG - 2023-09-29 16:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:48:43 --> Input Class Initialized
INFO - 2023-09-29 16:48:43 --> Language Class Initialized
INFO - 2023-09-29 16:48:43 --> Language Class Initialized
INFO - 2023-09-29 16:48:43 --> Config Class Initialized
INFO - 2023-09-29 16:48:43 --> Loader Class Initialized
INFO - 2023-09-29 16:48:43 --> Helper loaded: url_helper
INFO - 2023-09-29 16:48:43 --> Helper loaded: file_helper
INFO - 2023-09-29 16:48:43 --> Helper loaded: form_helper
INFO - 2023-09-29 16:48:43 --> Helper loaded: my_helper
INFO - 2023-09-29 16:48:43 --> Database Driver Class Initialized
INFO - 2023-09-29 16:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:48:43 --> Controller Class Initialized
DEBUG - 2023-09-29 16:48:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-09-29 16:48:43 --> Final output sent to browser
DEBUG - 2023-09-29 16:48:43 --> Total execution time: 0.0439
INFO - 2023-09-29 16:52:52 --> Config Class Initialized
INFO - 2023-09-29 16:52:52 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:52:52 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:52:52 --> Utf8 Class Initialized
INFO - 2023-09-29 16:52:52 --> URI Class Initialized
INFO - 2023-09-29 16:52:52 --> Router Class Initialized
INFO - 2023-09-29 16:52:52 --> Output Class Initialized
INFO - 2023-09-29 16:52:52 --> Security Class Initialized
DEBUG - 2023-09-29 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:52:52 --> Input Class Initialized
INFO - 2023-09-29 16:52:52 --> Language Class Initialized
INFO - 2023-09-29 16:52:52 --> Language Class Initialized
INFO - 2023-09-29 16:52:52 --> Config Class Initialized
INFO - 2023-09-29 16:52:52 --> Loader Class Initialized
INFO - 2023-09-29 16:52:52 --> Helper loaded: url_helper
INFO - 2023-09-29 16:52:52 --> Helper loaded: file_helper
INFO - 2023-09-29 16:52:52 --> Helper loaded: form_helper
INFO - 2023-09-29 16:52:52 --> Helper loaded: my_helper
INFO - 2023-09-29 16:52:52 --> Database Driver Class Initialized
INFO - 2023-09-29 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:52:52 --> Controller Class Initialized
DEBUG - 2023-09-29 16:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 16:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:52:52 --> Final output sent to browser
DEBUG - 2023-09-29 16:52:52 --> Total execution time: 0.3242
INFO - 2023-09-29 16:52:58 --> Config Class Initialized
INFO - 2023-09-29 16:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:52:58 --> Utf8 Class Initialized
INFO - 2023-09-29 16:52:58 --> URI Class Initialized
INFO - 2023-09-29 16:52:58 --> Router Class Initialized
INFO - 2023-09-29 16:52:58 --> Output Class Initialized
INFO - 2023-09-29 16:52:58 --> Security Class Initialized
DEBUG - 2023-09-29 16:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:52:58 --> Input Class Initialized
INFO - 2023-09-29 16:52:58 --> Language Class Initialized
INFO - 2023-09-29 16:52:58 --> Language Class Initialized
INFO - 2023-09-29 16:52:58 --> Config Class Initialized
INFO - 2023-09-29 16:52:58 --> Loader Class Initialized
INFO - 2023-09-29 16:52:58 --> Helper loaded: url_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: file_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: form_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: my_helper
INFO - 2023-09-29 16:52:58 --> Database Driver Class Initialized
INFO - 2023-09-29 16:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:52:58 --> Controller Class Initialized
INFO - 2023-09-29 16:52:58 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:52:58 --> Final output sent to browser
DEBUG - 2023-09-29 16:52:58 --> Total execution time: 0.3802
INFO - 2023-09-29 16:52:58 --> Config Class Initialized
INFO - 2023-09-29 16:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:52:58 --> Utf8 Class Initialized
INFO - 2023-09-29 16:52:58 --> URI Class Initialized
INFO - 2023-09-29 16:52:58 --> Router Class Initialized
INFO - 2023-09-29 16:52:58 --> Output Class Initialized
INFO - 2023-09-29 16:52:58 --> Security Class Initialized
DEBUG - 2023-09-29 16:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:52:58 --> Input Class Initialized
INFO - 2023-09-29 16:52:58 --> Language Class Initialized
INFO - 2023-09-29 16:52:58 --> Language Class Initialized
INFO - 2023-09-29 16:52:58 --> Config Class Initialized
INFO - 2023-09-29 16:52:58 --> Loader Class Initialized
INFO - 2023-09-29 16:52:58 --> Helper loaded: url_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: file_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: form_helper
INFO - 2023-09-29 16:52:58 --> Helper loaded: my_helper
INFO - 2023-09-29 16:52:58 --> Database Driver Class Initialized
INFO - 2023-09-29 16:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:52:58 --> Controller Class Initialized
DEBUG - 2023-09-29 16:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:52:59 --> Final output sent to browser
DEBUG - 2023-09-29 16:52:59 --> Total execution time: 0.1568
INFO - 2023-09-29 16:53:02 --> Config Class Initialized
INFO - 2023-09-29 16:53:02 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:53:02 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:53:02 --> Utf8 Class Initialized
INFO - 2023-09-29 16:53:02 --> URI Class Initialized
INFO - 2023-09-29 16:53:02 --> Router Class Initialized
INFO - 2023-09-29 16:53:02 --> Output Class Initialized
INFO - 2023-09-29 16:53:02 --> Security Class Initialized
DEBUG - 2023-09-29 16:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:53:02 --> Input Class Initialized
INFO - 2023-09-29 16:53:02 --> Language Class Initialized
INFO - 2023-09-29 16:53:02 --> Language Class Initialized
INFO - 2023-09-29 16:53:02 --> Config Class Initialized
INFO - 2023-09-29 16:53:02 --> Loader Class Initialized
INFO - 2023-09-29 16:53:02 --> Helper loaded: url_helper
INFO - 2023-09-29 16:53:02 --> Helper loaded: file_helper
INFO - 2023-09-29 16:53:02 --> Helper loaded: form_helper
INFO - 2023-09-29 16:53:02 --> Helper loaded: my_helper
INFO - 2023-09-29 16:53:02 --> Database Driver Class Initialized
INFO - 2023-09-29 16:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:53:03 --> Controller Class Initialized
DEBUG - 2023-09-29 16:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 16:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:53:03 --> Final output sent to browser
DEBUG - 2023-09-29 16:53:03 --> Total execution time: 0.2923
INFO - 2023-09-29 16:53:08 --> Config Class Initialized
INFO - 2023-09-29 16:53:08 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:53:08 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:53:08 --> Utf8 Class Initialized
INFO - 2023-09-29 16:53:08 --> URI Class Initialized
INFO - 2023-09-29 16:53:08 --> Router Class Initialized
INFO - 2023-09-29 16:53:08 --> Output Class Initialized
INFO - 2023-09-29 16:53:08 --> Security Class Initialized
DEBUG - 2023-09-29 16:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:53:08 --> Input Class Initialized
INFO - 2023-09-29 16:53:08 --> Language Class Initialized
INFO - 2023-09-29 16:53:08 --> Language Class Initialized
INFO - 2023-09-29 16:53:08 --> Config Class Initialized
INFO - 2023-09-29 16:53:08 --> Loader Class Initialized
INFO - 2023-09-29 16:53:08 --> Helper loaded: url_helper
INFO - 2023-09-29 16:53:08 --> Helper loaded: file_helper
INFO - 2023-09-29 16:53:08 --> Helper loaded: form_helper
INFO - 2023-09-29 16:53:08 --> Helper loaded: my_helper
INFO - 2023-09-29 16:53:08 --> Database Driver Class Initialized
INFO - 2023-09-29 16:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:53:08 --> Controller Class Initialized
DEBUG - 2023-09-29 16:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-29 16:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:53:09 --> Final output sent to browser
DEBUG - 2023-09-29 16:53:09 --> Total execution time: 0.9547
INFO - 2023-09-29 16:53:11 --> Config Class Initialized
INFO - 2023-09-29 16:53:11 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:53:11 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:53:11 --> Utf8 Class Initialized
INFO - 2023-09-29 16:53:11 --> URI Class Initialized
INFO - 2023-09-29 16:53:11 --> Router Class Initialized
INFO - 2023-09-29 16:53:11 --> Output Class Initialized
INFO - 2023-09-29 16:53:11 --> Security Class Initialized
DEBUG - 2023-09-29 16:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:53:11 --> Input Class Initialized
INFO - 2023-09-29 16:53:11 --> Language Class Initialized
INFO - 2023-09-29 16:53:11 --> Language Class Initialized
INFO - 2023-09-29 16:53:11 --> Config Class Initialized
INFO - 2023-09-29 16:53:11 --> Loader Class Initialized
INFO - 2023-09-29 16:53:11 --> Helper loaded: url_helper
INFO - 2023-09-29 16:53:11 --> Helper loaded: file_helper
INFO - 2023-09-29 16:53:11 --> Helper loaded: form_helper
INFO - 2023-09-29 16:53:11 --> Helper loaded: my_helper
INFO - 2023-09-29 16:53:11 --> Database Driver Class Initialized
INFO - 2023-09-29 16:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:53:11 --> Controller Class Initialized
INFO - 2023-09-29 16:53:14 --> Config Class Initialized
INFO - 2023-09-29 16:53:14 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:53:14 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:53:14 --> Utf8 Class Initialized
INFO - 2023-09-29 16:53:14 --> URI Class Initialized
INFO - 2023-09-29 16:53:14 --> Router Class Initialized
INFO - 2023-09-29 16:53:14 --> Output Class Initialized
INFO - 2023-09-29 16:53:14 --> Security Class Initialized
DEBUG - 2023-09-29 16:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:53:14 --> Input Class Initialized
INFO - 2023-09-29 16:53:14 --> Language Class Initialized
INFO - 2023-09-29 16:53:14 --> Language Class Initialized
INFO - 2023-09-29 16:53:14 --> Config Class Initialized
INFO - 2023-09-29 16:53:14 --> Loader Class Initialized
INFO - 2023-09-29 16:53:14 --> Helper loaded: url_helper
INFO - 2023-09-29 16:53:14 --> Helper loaded: file_helper
INFO - 2023-09-29 16:53:14 --> Helper loaded: form_helper
INFO - 2023-09-29 16:53:14 --> Helper loaded: my_helper
INFO - 2023-09-29 16:53:14 --> Database Driver Class Initialized
INFO - 2023-09-29 16:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:53:14 --> Controller Class Initialized
INFO - 2023-09-29 16:53:14 --> Final output sent to browser
DEBUG - 2023-09-29 16:53:14 --> Total execution time: 0.1957
INFO - 2023-09-29 16:53:59 --> Config Class Initialized
INFO - 2023-09-29 16:53:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:53:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:53:59 --> Utf8 Class Initialized
INFO - 2023-09-29 16:53:59 --> URI Class Initialized
INFO - 2023-09-29 16:53:59 --> Router Class Initialized
INFO - 2023-09-29 16:53:59 --> Output Class Initialized
INFO - 2023-09-29 16:53:59 --> Security Class Initialized
DEBUG - 2023-09-29 16:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:53:59 --> Input Class Initialized
INFO - 2023-09-29 16:53:59 --> Language Class Initialized
INFO - 2023-09-29 16:53:59 --> Language Class Initialized
INFO - 2023-09-29 16:53:59 --> Config Class Initialized
INFO - 2023-09-29 16:53:59 --> Loader Class Initialized
INFO - 2023-09-29 16:53:59 --> Helper loaded: url_helper
INFO - 2023-09-29 16:53:59 --> Helper loaded: file_helper
INFO - 2023-09-29 16:53:59 --> Helper loaded: form_helper
INFO - 2023-09-29 16:53:59 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:00 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:00 --> Controller Class Initialized
INFO - 2023-09-29 16:54:00 --> Final output sent to browser
DEBUG - 2023-09-29 16:54:00 --> Total execution time: 0.3200
INFO - 2023-09-29 16:54:00 --> Config Class Initialized
INFO - 2023-09-29 16:54:00 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:00 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:00 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:00 --> URI Class Initialized
INFO - 2023-09-29 16:54:00 --> Router Class Initialized
INFO - 2023-09-29 16:54:00 --> Output Class Initialized
INFO - 2023-09-29 16:54:00 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:00 --> Input Class Initialized
INFO - 2023-09-29 16:54:00 --> Language Class Initialized
INFO - 2023-09-29 16:54:00 --> Language Class Initialized
INFO - 2023-09-29 16:54:00 --> Config Class Initialized
INFO - 2023-09-29 16:54:00 --> Loader Class Initialized
INFO - 2023-09-29 16:54:00 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:00 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:00 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:00 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:00 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:00 --> Controller Class Initialized
INFO - 2023-09-29 16:54:15 --> Config Class Initialized
INFO - 2023-09-29 16:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:15 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:15 --> URI Class Initialized
INFO - 2023-09-29 16:54:15 --> Router Class Initialized
INFO - 2023-09-29 16:54:15 --> Output Class Initialized
INFO - 2023-09-29 16:54:15 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:15 --> Input Class Initialized
INFO - 2023-09-29 16:54:15 --> Language Class Initialized
INFO - 2023-09-29 16:54:15 --> Language Class Initialized
INFO - 2023-09-29 16:54:15 --> Config Class Initialized
INFO - 2023-09-29 16:54:15 --> Loader Class Initialized
INFO - 2023-09-29 16:54:15 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:15 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:15 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:15 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:15 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:15 --> Controller Class Initialized
INFO - 2023-09-29 16:54:15 --> Final output sent to browser
DEBUG - 2023-09-29 16:54:15 --> Total execution time: 0.1881
INFO - 2023-09-29 16:54:30 --> Config Class Initialized
INFO - 2023-09-29 16:54:30 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:30 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:30 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:30 --> URI Class Initialized
INFO - 2023-09-29 16:54:30 --> Router Class Initialized
INFO - 2023-09-29 16:54:30 --> Output Class Initialized
INFO - 2023-09-29 16:54:30 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:30 --> Input Class Initialized
INFO - 2023-09-29 16:54:30 --> Language Class Initialized
INFO - 2023-09-29 16:54:30 --> Language Class Initialized
INFO - 2023-09-29 16:54:30 --> Config Class Initialized
INFO - 2023-09-29 16:54:30 --> Loader Class Initialized
INFO - 2023-09-29 16:54:30 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:30 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:30 --> Controller Class Initialized
INFO - 2023-09-29 16:54:30 --> Final output sent to browser
DEBUG - 2023-09-29 16:54:30 --> Total execution time: 0.1968
INFO - 2023-09-29 16:54:30 --> Config Class Initialized
INFO - 2023-09-29 16:54:30 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:30 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:30 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:30 --> URI Class Initialized
INFO - 2023-09-29 16:54:30 --> Router Class Initialized
INFO - 2023-09-29 16:54:30 --> Output Class Initialized
INFO - 2023-09-29 16:54:30 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:30 --> Input Class Initialized
INFO - 2023-09-29 16:54:30 --> Language Class Initialized
INFO - 2023-09-29 16:54:30 --> Language Class Initialized
INFO - 2023-09-29 16:54:30 --> Config Class Initialized
INFO - 2023-09-29 16:54:30 --> Loader Class Initialized
INFO - 2023-09-29 16:54:30 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:30 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:30 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:30 --> Controller Class Initialized
INFO - 2023-09-29 16:54:32 --> Config Class Initialized
INFO - 2023-09-29 16:54:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:32 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:32 --> URI Class Initialized
INFO - 2023-09-29 16:54:32 --> Router Class Initialized
INFO - 2023-09-29 16:54:32 --> Output Class Initialized
INFO - 2023-09-29 16:54:32 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:32 --> Input Class Initialized
INFO - 2023-09-29 16:54:32 --> Language Class Initialized
INFO - 2023-09-29 16:54:32 --> Language Class Initialized
INFO - 2023-09-29 16:54:32 --> Config Class Initialized
INFO - 2023-09-29 16:54:32 --> Loader Class Initialized
INFO - 2023-09-29 16:54:32 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:32 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:32 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:32 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:32 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:32 --> Controller Class Initialized
INFO - 2023-09-29 16:54:32 --> Final output sent to browser
DEBUG - 2023-09-29 16:54:32 --> Total execution time: 0.2971
INFO - 2023-09-29 16:54:59 --> Config Class Initialized
INFO - 2023-09-29 16:54:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:54:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:54:59 --> Utf8 Class Initialized
INFO - 2023-09-29 16:54:59 --> URI Class Initialized
INFO - 2023-09-29 16:54:59 --> Router Class Initialized
INFO - 2023-09-29 16:54:59 --> Output Class Initialized
INFO - 2023-09-29 16:54:59 --> Security Class Initialized
DEBUG - 2023-09-29 16:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:54:59 --> Input Class Initialized
INFO - 2023-09-29 16:54:59 --> Language Class Initialized
INFO - 2023-09-29 16:54:59 --> Language Class Initialized
INFO - 2023-09-29 16:54:59 --> Config Class Initialized
INFO - 2023-09-29 16:54:59 --> Loader Class Initialized
INFO - 2023-09-29 16:54:59 --> Helper loaded: url_helper
INFO - 2023-09-29 16:54:59 --> Helper loaded: file_helper
INFO - 2023-09-29 16:54:59 --> Helper loaded: form_helper
INFO - 2023-09-29 16:54:59 --> Helper loaded: my_helper
INFO - 2023-09-29 16:54:59 --> Database Driver Class Initialized
INFO - 2023-09-29 16:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:54:59 --> Controller Class Initialized
INFO - 2023-09-29 16:54:59 --> Final output sent to browser
DEBUG - 2023-09-29 16:54:59 --> Total execution time: 0.5287
INFO - 2023-09-29 16:55:00 --> Config Class Initialized
INFO - 2023-09-29 16:55:00 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:55:00 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:55:00 --> Utf8 Class Initialized
INFO - 2023-09-29 16:55:00 --> URI Class Initialized
INFO - 2023-09-29 16:55:00 --> Router Class Initialized
INFO - 2023-09-29 16:55:00 --> Output Class Initialized
INFO - 2023-09-29 16:55:00 --> Security Class Initialized
DEBUG - 2023-09-29 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:55:00 --> Input Class Initialized
INFO - 2023-09-29 16:55:00 --> Language Class Initialized
INFO - 2023-09-29 16:55:00 --> Language Class Initialized
INFO - 2023-09-29 16:55:00 --> Config Class Initialized
INFO - 2023-09-29 16:55:00 --> Loader Class Initialized
INFO - 2023-09-29 16:55:00 --> Helper loaded: url_helper
INFO - 2023-09-29 16:55:00 --> Helper loaded: file_helper
INFO - 2023-09-29 16:55:00 --> Helper loaded: form_helper
INFO - 2023-09-29 16:55:00 --> Helper loaded: my_helper
INFO - 2023-09-29 16:55:00 --> Database Driver Class Initialized
INFO - 2023-09-29 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:55:00 --> Controller Class Initialized
INFO - 2023-09-29 16:55:36 --> Config Class Initialized
INFO - 2023-09-29 16:55:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:55:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:55:36 --> Utf8 Class Initialized
INFO - 2023-09-29 16:55:36 --> URI Class Initialized
INFO - 2023-09-29 16:55:36 --> Router Class Initialized
INFO - 2023-09-29 16:55:36 --> Output Class Initialized
INFO - 2023-09-29 16:55:36 --> Security Class Initialized
DEBUG - 2023-09-29 16:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:55:36 --> Input Class Initialized
INFO - 2023-09-29 16:55:36 --> Language Class Initialized
INFO - 2023-09-29 16:55:36 --> Language Class Initialized
INFO - 2023-09-29 16:55:36 --> Config Class Initialized
INFO - 2023-09-29 16:55:36 --> Loader Class Initialized
INFO - 2023-09-29 16:55:36 --> Helper loaded: url_helper
INFO - 2023-09-29 16:55:36 --> Helper loaded: file_helper
INFO - 2023-09-29 16:55:36 --> Helper loaded: form_helper
INFO - 2023-09-29 16:55:36 --> Helper loaded: my_helper
INFO - 2023-09-29 16:55:36 --> Database Driver Class Initialized
INFO - 2023-09-29 16:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:55:36 --> Controller Class Initialized
INFO - 2023-09-29 16:55:36 --> Final output sent to browser
DEBUG - 2023-09-29 16:55:36 --> Total execution time: 0.3884
INFO - 2023-09-29 16:56:28 --> Config Class Initialized
INFO - 2023-09-29 16:56:28 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:56:28 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:56:28 --> Utf8 Class Initialized
INFO - 2023-09-29 16:56:28 --> URI Class Initialized
INFO - 2023-09-29 16:56:28 --> Router Class Initialized
INFO - 2023-09-29 16:56:28 --> Output Class Initialized
INFO - 2023-09-29 16:56:28 --> Security Class Initialized
DEBUG - 2023-09-29 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:56:28 --> Input Class Initialized
INFO - 2023-09-29 16:56:28 --> Language Class Initialized
INFO - 2023-09-29 16:56:28 --> Language Class Initialized
INFO - 2023-09-29 16:56:28 --> Config Class Initialized
INFO - 2023-09-29 16:56:28 --> Loader Class Initialized
INFO - 2023-09-29 16:56:28 --> Helper loaded: url_helper
INFO - 2023-09-29 16:56:28 --> Helper loaded: file_helper
INFO - 2023-09-29 16:56:28 --> Helper loaded: form_helper
INFO - 2023-09-29 16:56:28 --> Helper loaded: my_helper
INFO - 2023-09-29 16:56:29 --> Database Driver Class Initialized
INFO - 2023-09-29 16:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:56:29 --> Controller Class Initialized
INFO - 2023-09-29 16:56:29 --> Final output sent to browser
DEBUG - 2023-09-29 16:56:29 --> Total execution time: 0.4505
INFO - 2023-09-29 16:56:29 --> Config Class Initialized
INFO - 2023-09-29 16:56:29 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:56:29 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:56:29 --> Utf8 Class Initialized
INFO - 2023-09-29 16:56:29 --> URI Class Initialized
INFO - 2023-09-29 16:56:29 --> Router Class Initialized
INFO - 2023-09-29 16:56:29 --> Output Class Initialized
INFO - 2023-09-29 16:56:29 --> Security Class Initialized
DEBUG - 2023-09-29 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:56:29 --> Input Class Initialized
INFO - 2023-09-29 16:56:29 --> Language Class Initialized
INFO - 2023-09-29 16:56:29 --> Language Class Initialized
INFO - 2023-09-29 16:56:29 --> Config Class Initialized
INFO - 2023-09-29 16:56:29 --> Loader Class Initialized
INFO - 2023-09-29 16:56:29 --> Helper loaded: url_helper
INFO - 2023-09-29 16:56:29 --> Helper loaded: file_helper
INFO - 2023-09-29 16:56:29 --> Helper loaded: form_helper
INFO - 2023-09-29 16:56:29 --> Helper loaded: my_helper
INFO - 2023-09-29 16:56:29 --> Database Driver Class Initialized
INFO - 2023-09-29 16:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:56:29 --> Controller Class Initialized
INFO - 2023-09-29 16:57:32 --> Config Class Initialized
INFO - 2023-09-29 16:57:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:57:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:57:32 --> Utf8 Class Initialized
INFO - 2023-09-29 16:57:32 --> URI Class Initialized
DEBUG - 2023-09-29 16:57:32 --> No URI present. Default controller set.
INFO - 2023-09-29 16:57:32 --> Router Class Initialized
INFO - 2023-09-29 16:57:32 --> Output Class Initialized
INFO - 2023-09-29 16:57:32 --> Security Class Initialized
DEBUG - 2023-09-29 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:57:32 --> Input Class Initialized
INFO - 2023-09-29 16:57:32 --> Language Class Initialized
INFO - 2023-09-29 16:57:32 --> Language Class Initialized
INFO - 2023-09-29 16:57:32 --> Config Class Initialized
INFO - 2023-09-29 16:57:32 --> Loader Class Initialized
INFO - 2023-09-29 16:57:32 --> Helper loaded: url_helper
INFO - 2023-09-29 16:57:32 --> Helper loaded: file_helper
INFO - 2023-09-29 16:57:32 --> Helper loaded: form_helper
INFO - 2023-09-29 16:57:32 --> Helper loaded: my_helper
INFO - 2023-09-29 16:57:32 --> Database Driver Class Initialized
INFO - 2023-09-29 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:57:32 --> Controller Class Initialized
DEBUG - 2023-09-29 16:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:57:32 --> Final output sent to browser
DEBUG - 2023-09-29 16:57:32 --> Total execution time: 0.0741
INFO - 2023-09-29 16:57:34 --> Config Class Initialized
INFO - 2023-09-29 16:57:34 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:57:34 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:57:34 --> Utf8 Class Initialized
INFO - 2023-09-29 16:57:34 --> URI Class Initialized
INFO - 2023-09-29 16:57:34 --> Router Class Initialized
INFO - 2023-09-29 16:57:34 --> Output Class Initialized
INFO - 2023-09-29 16:57:34 --> Security Class Initialized
DEBUG - 2023-09-29 16:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:57:34 --> Input Class Initialized
INFO - 2023-09-29 16:57:34 --> Language Class Initialized
INFO - 2023-09-29 16:57:34 --> Language Class Initialized
INFO - 2023-09-29 16:57:34 --> Config Class Initialized
INFO - 2023-09-29 16:57:34 --> Loader Class Initialized
INFO - 2023-09-29 16:57:34 --> Helper loaded: url_helper
INFO - 2023-09-29 16:57:34 --> Helper loaded: file_helper
INFO - 2023-09-29 16:57:34 --> Helper loaded: form_helper
INFO - 2023-09-29 16:57:34 --> Helper loaded: my_helper
INFO - 2023-09-29 16:57:34 --> Database Driver Class Initialized
INFO - 2023-09-29 16:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:57:34 --> Controller Class Initialized
INFO - 2023-09-29 16:57:34 --> Final output sent to browser
DEBUG - 2023-09-29 16:57:34 --> Total execution time: 0.0397
INFO - 2023-09-29 16:57:44 --> Config Class Initialized
INFO - 2023-09-29 16:57:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:57:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:57:44 --> Utf8 Class Initialized
INFO - 2023-09-29 16:57:44 --> URI Class Initialized
INFO - 2023-09-29 16:57:44 --> Router Class Initialized
INFO - 2023-09-29 16:57:44 --> Output Class Initialized
INFO - 2023-09-29 16:57:44 --> Security Class Initialized
DEBUG - 2023-09-29 16:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:57:44 --> Input Class Initialized
INFO - 2023-09-29 16:57:44 --> Language Class Initialized
INFO - 2023-09-29 16:57:44 --> Language Class Initialized
INFO - 2023-09-29 16:57:44 --> Config Class Initialized
INFO - 2023-09-29 16:57:44 --> Loader Class Initialized
INFO - 2023-09-29 16:57:44 --> Helper loaded: url_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: file_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: form_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: my_helper
INFO - 2023-09-29 16:57:44 --> Database Driver Class Initialized
INFO - 2023-09-29 16:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:57:44 --> Controller Class Initialized
INFO - 2023-09-29 16:57:44 --> Final output sent to browser
DEBUG - 2023-09-29 16:57:44 --> Total execution time: 0.3052
INFO - 2023-09-29 16:57:44 --> Config Class Initialized
INFO - 2023-09-29 16:57:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:57:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:57:44 --> Utf8 Class Initialized
INFO - 2023-09-29 16:57:44 --> URI Class Initialized
INFO - 2023-09-29 16:57:44 --> Router Class Initialized
INFO - 2023-09-29 16:57:44 --> Output Class Initialized
INFO - 2023-09-29 16:57:44 --> Security Class Initialized
DEBUG - 2023-09-29 16:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:57:44 --> Input Class Initialized
INFO - 2023-09-29 16:57:44 --> Language Class Initialized
INFO - 2023-09-29 16:57:44 --> Language Class Initialized
INFO - 2023-09-29 16:57:44 --> Config Class Initialized
INFO - 2023-09-29 16:57:44 --> Loader Class Initialized
INFO - 2023-09-29 16:57:44 --> Helper loaded: url_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: file_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: form_helper
INFO - 2023-09-29 16:57:44 --> Helper loaded: my_helper
INFO - 2023-09-29 16:57:44 --> Database Driver Class Initialized
INFO - 2023-09-29 16:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:57:44 --> Controller Class Initialized
INFO - 2023-09-29 16:58:42 --> Config Class Initialized
INFO - 2023-09-29 16:58:42 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:58:42 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:58:42 --> Utf8 Class Initialized
INFO - 2023-09-29 16:58:42 --> URI Class Initialized
INFO - 2023-09-29 16:58:42 --> Router Class Initialized
INFO - 2023-09-29 16:58:42 --> Output Class Initialized
INFO - 2023-09-29 16:58:42 --> Security Class Initialized
DEBUG - 2023-09-29 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:58:42 --> Input Class Initialized
INFO - 2023-09-29 16:58:42 --> Language Class Initialized
INFO - 2023-09-29 16:58:42 --> Language Class Initialized
INFO - 2023-09-29 16:58:42 --> Config Class Initialized
INFO - 2023-09-29 16:58:42 --> Loader Class Initialized
INFO - 2023-09-29 16:58:42 --> Helper loaded: url_helper
INFO - 2023-09-29 16:58:42 --> Helper loaded: file_helper
INFO - 2023-09-29 16:58:42 --> Helper loaded: form_helper
INFO - 2023-09-29 16:58:42 --> Helper loaded: my_helper
INFO - 2023-09-29 16:58:43 --> Database Driver Class Initialized
INFO - 2023-09-29 16:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:58:43 --> Controller Class Initialized
DEBUG - 2023-09-29 16:58:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-29 16:58:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:58:43 --> Final output sent to browser
DEBUG - 2023-09-29 16:58:43 --> Total execution time: 0.5687
INFO - 2023-09-29 16:58:56 --> Config Class Initialized
INFO - 2023-09-29 16:58:56 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:58:56 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:58:56 --> Utf8 Class Initialized
INFO - 2023-09-29 16:58:56 --> URI Class Initialized
INFO - 2023-09-29 16:58:56 --> Router Class Initialized
INFO - 2023-09-29 16:58:56 --> Output Class Initialized
INFO - 2023-09-29 16:58:56 --> Security Class Initialized
DEBUG - 2023-09-29 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:58:56 --> Input Class Initialized
INFO - 2023-09-29 16:58:56 --> Language Class Initialized
INFO - 2023-09-29 16:58:57 --> Language Class Initialized
INFO - 2023-09-29 16:58:57 --> Config Class Initialized
INFO - 2023-09-29 16:58:57 --> Loader Class Initialized
INFO - 2023-09-29 16:58:57 --> Helper loaded: url_helper
INFO - 2023-09-29 16:58:57 --> Helper loaded: file_helper
INFO - 2023-09-29 16:58:57 --> Helper loaded: form_helper
INFO - 2023-09-29 16:58:57 --> Helper loaded: my_helper
INFO - 2023-09-29 16:58:57 --> Database Driver Class Initialized
INFO - 2023-09-29 16:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:58:57 --> Controller Class Initialized
INFO - 2023-09-29 16:58:57 --> Helper loaded: cookie_helper
INFO - 2023-09-29 16:58:57 --> Final output sent to browser
DEBUG - 2023-09-29 16:58:57 --> Total execution time: 0.8771
INFO - 2023-09-29 16:58:57 --> Config Class Initialized
INFO - 2023-09-29 16:58:57 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:58:57 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:58:57 --> Utf8 Class Initialized
INFO - 2023-09-29 16:58:57 --> URI Class Initialized
INFO - 2023-09-29 16:58:57 --> Router Class Initialized
INFO - 2023-09-29 16:58:57 --> Output Class Initialized
INFO - 2023-09-29 16:58:57 --> Security Class Initialized
DEBUG - 2023-09-29 16:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:58:57 --> Input Class Initialized
INFO - 2023-09-29 16:58:57 --> Language Class Initialized
INFO - 2023-09-29 16:58:58 --> Language Class Initialized
INFO - 2023-09-29 16:58:58 --> Config Class Initialized
INFO - 2023-09-29 16:58:58 --> Loader Class Initialized
INFO - 2023-09-29 16:58:58 --> Helper loaded: url_helper
INFO - 2023-09-29 16:58:58 --> Helper loaded: file_helper
INFO - 2023-09-29 16:58:58 --> Helper loaded: form_helper
INFO - 2023-09-29 16:58:58 --> Helper loaded: my_helper
INFO - 2023-09-29 16:58:58 --> Database Driver Class Initialized
INFO - 2023-09-29 16:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:58:58 --> Controller Class Initialized
DEBUG - 2023-09-29 16:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 16:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:58:58 --> Final output sent to browser
DEBUG - 2023-09-29 16:58:58 --> Total execution time: 0.5785
INFO - 2023-09-29 16:59:07 --> Config Class Initialized
INFO - 2023-09-29 16:59:07 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:59:07 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:59:07 --> Utf8 Class Initialized
INFO - 2023-09-29 16:59:07 --> URI Class Initialized
INFO - 2023-09-29 16:59:07 --> Router Class Initialized
INFO - 2023-09-29 16:59:07 --> Output Class Initialized
INFO - 2023-09-29 16:59:07 --> Security Class Initialized
DEBUG - 2023-09-29 16:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:59:07 --> Input Class Initialized
INFO - 2023-09-29 16:59:07 --> Language Class Initialized
INFO - 2023-09-29 16:59:07 --> Language Class Initialized
INFO - 2023-09-29 16:59:07 --> Config Class Initialized
INFO - 2023-09-29 16:59:07 --> Loader Class Initialized
INFO - 2023-09-29 16:59:07 --> Helper loaded: url_helper
INFO - 2023-09-29 16:59:07 --> Helper loaded: file_helper
INFO - 2023-09-29 16:59:07 --> Helper loaded: form_helper
INFO - 2023-09-29 16:59:07 --> Helper loaded: my_helper
INFO - 2023-09-29 16:59:07 --> Database Driver Class Initialized
INFO - 2023-09-29 16:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:59:07 --> Controller Class Initialized
DEBUG - 2023-09-29 16:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-29 16:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 16:59:07 --> Final output sent to browser
DEBUG - 2023-09-29 16:59:07 --> Total execution time: 0.2979
INFO - 2023-09-29 16:59:10 --> Config Class Initialized
INFO - 2023-09-29 16:59:10 --> Hooks Class Initialized
DEBUG - 2023-09-29 16:59:10 --> UTF-8 Support Enabled
INFO - 2023-09-29 16:59:10 --> Utf8 Class Initialized
INFO - 2023-09-29 16:59:10 --> URI Class Initialized
INFO - 2023-09-29 16:59:10 --> Router Class Initialized
INFO - 2023-09-29 16:59:10 --> Output Class Initialized
INFO - 2023-09-29 16:59:10 --> Security Class Initialized
DEBUG - 2023-09-29 16:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 16:59:10 --> Input Class Initialized
INFO - 2023-09-29 16:59:10 --> Language Class Initialized
INFO - 2023-09-29 16:59:10 --> Language Class Initialized
INFO - 2023-09-29 16:59:10 --> Config Class Initialized
INFO - 2023-09-29 16:59:10 --> Loader Class Initialized
INFO - 2023-09-29 16:59:10 --> Helper loaded: url_helper
INFO - 2023-09-29 16:59:10 --> Helper loaded: file_helper
INFO - 2023-09-29 16:59:10 --> Helper loaded: form_helper
INFO - 2023-09-29 16:59:10 --> Helper loaded: my_helper
INFO - 2023-09-29 16:59:10 --> Database Driver Class Initialized
INFO - 2023-09-29 16:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 16:59:10 --> Controller Class Initialized
DEBUG - 2023-09-29 16:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-29 16:59:11 --> Final output sent to browser
DEBUG - 2023-09-29 16:59:11 --> Total execution time: 1.1922
INFO - 2023-09-29 17:03:39 --> Config Class Initialized
INFO - 2023-09-29 17:03:39 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:03:39 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:03:39 --> Utf8 Class Initialized
INFO - 2023-09-29 17:03:39 --> URI Class Initialized
INFO - 2023-09-29 17:03:39 --> Router Class Initialized
INFO - 2023-09-29 17:03:39 --> Output Class Initialized
INFO - 2023-09-29 17:03:39 --> Security Class Initialized
DEBUG - 2023-09-29 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:03:39 --> Input Class Initialized
INFO - 2023-09-29 17:03:39 --> Language Class Initialized
INFO - 2023-09-29 17:03:39 --> Language Class Initialized
INFO - 2023-09-29 17:03:39 --> Config Class Initialized
INFO - 2023-09-29 17:03:39 --> Loader Class Initialized
INFO - 2023-09-29 17:03:39 --> Helper loaded: url_helper
INFO - 2023-09-29 17:03:39 --> Helper loaded: file_helper
INFO - 2023-09-29 17:03:39 --> Helper loaded: form_helper
INFO - 2023-09-29 17:03:39 --> Helper loaded: my_helper
INFO - 2023-09-29 17:03:39 --> Database Driver Class Initialized
INFO - 2023-09-29 17:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:03:39 --> Controller Class Initialized
INFO - 2023-09-29 17:03:39 --> Final output sent to browser
DEBUG - 2023-09-29 17:03:39 --> Total execution time: 0.0754
INFO - 2023-09-29 17:03:48 --> Config Class Initialized
INFO - 2023-09-29 17:03:48 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:03:48 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:03:48 --> Utf8 Class Initialized
INFO - 2023-09-29 17:03:48 --> URI Class Initialized
INFO - 2023-09-29 17:03:48 --> Router Class Initialized
INFO - 2023-09-29 17:03:48 --> Output Class Initialized
INFO - 2023-09-29 17:03:48 --> Security Class Initialized
DEBUG - 2023-09-29 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:03:48 --> Input Class Initialized
INFO - 2023-09-29 17:03:48 --> Language Class Initialized
INFO - 2023-09-29 17:03:48 --> Language Class Initialized
INFO - 2023-09-29 17:03:48 --> Config Class Initialized
INFO - 2023-09-29 17:03:48 --> Loader Class Initialized
INFO - 2023-09-29 17:03:48 --> Helper loaded: url_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: file_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: form_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: my_helper
INFO - 2023-09-29 17:03:48 --> Database Driver Class Initialized
INFO - 2023-09-29 17:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:03:48 --> Controller Class Initialized
INFO - 2023-09-29 17:03:48 --> Final output sent to browser
DEBUG - 2023-09-29 17:03:48 --> Total execution time: 0.0843
INFO - 2023-09-29 17:03:48 --> Config Class Initialized
INFO - 2023-09-29 17:03:48 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:03:48 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:03:48 --> Utf8 Class Initialized
INFO - 2023-09-29 17:03:48 --> URI Class Initialized
INFO - 2023-09-29 17:03:48 --> Router Class Initialized
INFO - 2023-09-29 17:03:48 --> Output Class Initialized
INFO - 2023-09-29 17:03:48 --> Security Class Initialized
DEBUG - 2023-09-29 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:03:48 --> Input Class Initialized
INFO - 2023-09-29 17:03:48 --> Language Class Initialized
INFO - 2023-09-29 17:03:48 --> Language Class Initialized
INFO - 2023-09-29 17:03:48 --> Config Class Initialized
INFO - 2023-09-29 17:03:48 --> Loader Class Initialized
INFO - 2023-09-29 17:03:48 --> Helper loaded: url_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: file_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: form_helper
INFO - 2023-09-29 17:03:48 --> Helper loaded: my_helper
INFO - 2023-09-29 17:03:48 --> Database Driver Class Initialized
INFO - 2023-09-29 17:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:03:48 --> Controller Class Initialized
INFO - 2023-09-29 17:04:25 --> Config Class Initialized
INFO - 2023-09-29 17:04:25 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:04:25 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:04:25 --> Utf8 Class Initialized
INFO - 2023-09-29 17:04:25 --> URI Class Initialized
INFO - 2023-09-29 17:04:25 --> Router Class Initialized
INFO - 2023-09-29 17:04:25 --> Output Class Initialized
INFO - 2023-09-29 17:04:25 --> Security Class Initialized
DEBUG - 2023-09-29 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:04:25 --> Input Class Initialized
INFO - 2023-09-29 17:04:25 --> Language Class Initialized
INFO - 2023-09-29 17:04:25 --> Language Class Initialized
INFO - 2023-09-29 17:04:25 --> Config Class Initialized
INFO - 2023-09-29 17:04:25 --> Loader Class Initialized
INFO - 2023-09-29 17:04:25 --> Helper loaded: url_helper
INFO - 2023-09-29 17:04:25 --> Helper loaded: file_helper
INFO - 2023-09-29 17:04:25 --> Helper loaded: form_helper
INFO - 2023-09-29 17:04:25 --> Helper loaded: my_helper
INFO - 2023-09-29 17:04:25 --> Database Driver Class Initialized
INFO - 2023-09-29 17:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:04:26 --> Controller Class Initialized
INFO - 2023-09-29 17:04:26 --> Final output sent to browser
DEBUG - 2023-09-29 17:04:26 --> Total execution time: 0.1818
INFO - 2023-09-29 17:04:37 --> Config Class Initialized
INFO - 2023-09-29 17:04:37 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:04:37 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:04:37 --> Utf8 Class Initialized
INFO - 2023-09-29 17:04:37 --> URI Class Initialized
INFO - 2023-09-29 17:04:37 --> Router Class Initialized
INFO - 2023-09-29 17:04:37 --> Output Class Initialized
INFO - 2023-09-29 17:04:37 --> Security Class Initialized
DEBUG - 2023-09-29 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:04:37 --> Input Class Initialized
INFO - 2023-09-29 17:04:37 --> Language Class Initialized
INFO - 2023-09-29 17:04:37 --> Language Class Initialized
INFO - 2023-09-29 17:04:37 --> Config Class Initialized
INFO - 2023-09-29 17:04:37 --> Loader Class Initialized
INFO - 2023-09-29 17:04:37 --> Helper loaded: url_helper
INFO - 2023-09-29 17:04:37 --> Helper loaded: file_helper
INFO - 2023-09-29 17:04:37 --> Helper loaded: form_helper
INFO - 2023-09-29 17:04:37 --> Helper loaded: my_helper
INFO - 2023-09-29 17:04:37 --> Database Driver Class Initialized
INFO - 2023-09-29 17:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:04:37 --> Controller Class Initialized
INFO - 2023-09-29 17:04:37 --> Final output sent to browser
DEBUG - 2023-09-29 17:04:37 --> Total execution time: 0.0639
INFO - 2023-09-29 17:04:37 --> Config Class Initialized
INFO - 2023-09-29 17:04:37 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:04:37 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:04:37 --> Utf8 Class Initialized
INFO - 2023-09-29 17:04:37 --> URI Class Initialized
INFO - 2023-09-29 17:04:37 --> Router Class Initialized
INFO - 2023-09-29 17:04:37 --> Output Class Initialized
INFO - 2023-09-29 17:04:37 --> Security Class Initialized
DEBUG - 2023-09-29 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:04:37 --> Input Class Initialized
INFO - 2023-09-29 17:04:37 --> Language Class Initialized
INFO - 2023-09-29 17:04:37 --> Language Class Initialized
INFO - 2023-09-29 17:04:37 --> Config Class Initialized
INFO - 2023-09-29 17:04:37 --> Loader Class Initialized
INFO - 2023-09-29 17:04:37 --> Helper loaded: url_helper
INFO - 2023-09-29 17:04:37 --> Helper loaded: file_helper
INFO - 2023-09-29 17:04:37 --> Helper loaded: form_helper
INFO - 2023-09-29 17:04:38 --> Helper loaded: my_helper
INFO - 2023-09-29 17:04:38 --> Database Driver Class Initialized
INFO - 2023-09-29 17:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:04:38 --> Controller Class Initialized
INFO - 2023-09-29 17:05:34 --> Config Class Initialized
INFO - 2023-09-29 17:05:34 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:05:34 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:05:34 --> Utf8 Class Initialized
INFO - 2023-09-29 17:05:34 --> URI Class Initialized
INFO - 2023-09-29 17:05:34 --> Router Class Initialized
INFO - 2023-09-29 17:05:34 --> Output Class Initialized
INFO - 2023-09-29 17:05:34 --> Security Class Initialized
DEBUG - 2023-09-29 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:05:34 --> Input Class Initialized
INFO - 2023-09-29 17:05:34 --> Language Class Initialized
INFO - 2023-09-29 17:05:34 --> Language Class Initialized
INFO - 2023-09-29 17:05:34 --> Config Class Initialized
INFO - 2023-09-29 17:05:34 --> Loader Class Initialized
INFO - 2023-09-29 17:05:34 --> Helper loaded: url_helper
INFO - 2023-09-29 17:05:34 --> Helper loaded: file_helper
INFO - 2023-09-29 17:05:34 --> Helper loaded: form_helper
INFO - 2023-09-29 17:05:34 --> Helper loaded: my_helper
INFO - 2023-09-29 17:05:34 --> Database Driver Class Initialized
INFO - 2023-09-29 17:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:05:34 --> Controller Class Initialized
INFO - 2023-09-29 17:05:34 --> Final output sent to browser
DEBUG - 2023-09-29 17:05:34 --> Total execution time: 0.0497
INFO - 2023-09-29 17:05:42 --> Config Class Initialized
INFO - 2023-09-29 17:05:42 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:05:42 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:05:42 --> Utf8 Class Initialized
INFO - 2023-09-29 17:05:42 --> URI Class Initialized
INFO - 2023-09-29 17:05:42 --> Router Class Initialized
INFO - 2023-09-29 17:05:42 --> Output Class Initialized
INFO - 2023-09-29 17:05:42 --> Security Class Initialized
DEBUG - 2023-09-29 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:05:42 --> Input Class Initialized
INFO - 2023-09-29 17:05:42 --> Language Class Initialized
INFO - 2023-09-29 17:05:42 --> Language Class Initialized
INFO - 2023-09-29 17:05:42 --> Config Class Initialized
INFO - 2023-09-29 17:05:42 --> Loader Class Initialized
INFO - 2023-09-29 17:05:42 --> Helper loaded: url_helper
INFO - 2023-09-29 17:05:42 --> Helper loaded: file_helper
INFO - 2023-09-29 17:05:42 --> Helper loaded: form_helper
INFO - 2023-09-29 17:05:42 --> Helper loaded: my_helper
INFO - 2023-09-29 17:05:42 --> Database Driver Class Initialized
INFO - 2023-09-29 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:05:42 --> Controller Class Initialized
INFO - 2023-09-29 17:05:42 --> Final output sent to browser
DEBUG - 2023-09-29 17:05:42 --> Total execution time: 0.6442
INFO - 2023-09-29 17:05:43 --> Config Class Initialized
INFO - 2023-09-29 17:05:43 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:05:43 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:05:43 --> Utf8 Class Initialized
INFO - 2023-09-29 17:05:43 --> URI Class Initialized
INFO - 2023-09-29 17:05:43 --> Router Class Initialized
INFO - 2023-09-29 17:05:43 --> Output Class Initialized
INFO - 2023-09-29 17:05:43 --> Security Class Initialized
DEBUG - 2023-09-29 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:05:43 --> Input Class Initialized
INFO - 2023-09-29 17:05:43 --> Language Class Initialized
INFO - 2023-09-29 17:05:43 --> Language Class Initialized
INFO - 2023-09-29 17:05:43 --> Config Class Initialized
INFO - 2023-09-29 17:05:43 --> Loader Class Initialized
INFO - 2023-09-29 17:05:43 --> Helper loaded: url_helper
INFO - 2023-09-29 17:05:43 --> Helper loaded: file_helper
INFO - 2023-09-29 17:05:43 --> Helper loaded: form_helper
INFO - 2023-09-29 17:05:43 --> Helper loaded: my_helper
INFO - 2023-09-29 17:05:43 --> Database Driver Class Initialized
INFO - 2023-09-29 17:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:05:43 --> Controller Class Initialized
INFO - 2023-09-29 17:05:59 --> Config Class Initialized
INFO - 2023-09-29 17:05:59 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:05:59 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:05:59 --> Utf8 Class Initialized
INFO - 2023-09-29 17:05:59 --> URI Class Initialized
INFO - 2023-09-29 17:05:59 --> Router Class Initialized
INFO - 2023-09-29 17:05:59 --> Output Class Initialized
INFO - 2023-09-29 17:05:59 --> Security Class Initialized
DEBUG - 2023-09-29 17:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:05:59 --> Input Class Initialized
INFO - 2023-09-29 17:05:59 --> Language Class Initialized
INFO - 2023-09-29 17:05:59 --> Language Class Initialized
INFO - 2023-09-29 17:05:59 --> Config Class Initialized
INFO - 2023-09-29 17:05:59 --> Loader Class Initialized
INFO - 2023-09-29 17:05:59 --> Helper loaded: url_helper
INFO - 2023-09-29 17:05:59 --> Helper loaded: file_helper
INFO - 2023-09-29 17:05:59 --> Helper loaded: form_helper
INFO - 2023-09-29 17:05:59 --> Helper loaded: my_helper
INFO - 2023-09-29 17:05:59 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:00 --> Controller Class Initialized
INFO - 2023-09-29 17:06:00 --> Final output sent to browser
DEBUG - 2023-09-29 17:06:00 --> Total execution time: 0.4810
INFO - 2023-09-29 17:06:08 --> Config Class Initialized
INFO - 2023-09-29 17:06:08 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:06:08 --> Utf8 Class Initialized
INFO - 2023-09-29 17:06:08 --> URI Class Initialized
INFO - 2023-09-29 17:06:09 --> Router Class Initialized
INFO - 2023-09-29 17:06:09 --> Output Class Initialized
INFO - 2023-09-29 17:06:09 --> Security Class Initialized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:06:09 --> Input Class Initialized
INFO - 2023-09-29 17:06:09 --> Language Class Initialized
INFO - 2023-09-29 17:06:09 --> Language Class Initialized
INFO - 2023-09-29 17:06:09 --> Config Class Initialized
INFO - 2023-09-29 17:06:09 --> Loader Class Initialized
INFO - 2023-09-29 17:06:09 --> Helper loaded: url_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: file_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: form_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: my_helper
INFO - 2023-09-29 17:06:09 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:09 --> Controller Class Initialized
INFO - 2023-09-29 17:06:09 --> Final output sent to browser
DEBUG - 2023-09-29 17:06:09 --> Total execution time: 0.5100
INFO - 2023-09-29 17:06:09 --> Config Class Initialized
INFO - 2023-09-29 17:06:09 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:06:09 --> Utf8 Class Initialized
INFO - 2023-09-29 17:06:09 --> URI Class Initialized
INFO - 2023-09-29 17:06:09 --> Router Class Initialized
INFO - 2023-09-29 17:06:09 --> Output Class Initialized
INFO - 2023-09-29 17:06:09 --> Security Class Initialized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:06:09 --> Input Class Initialized
INFO - 2023-09-29 17:06:09 --> Language Class Initialized
INFO - 2023-09-29 17:06:09 --> Language Class Initialized
INFO - 2023-09-29 17:06:09 --> Config Class Initialized
INFO - 2023-09-29 17:06:09 --> Loader Class Initialized
INFO - 2023-09-29 17:06:09 --> Helper loaded: url_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: file_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: form_helper
INFO - 2023-09-29 17:06:09 --> Helper loaded: my_helper
INFO - 2023-09-29 17:06:09 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:09 --> Controller Class Initialized
INFO - 2023-09-29 17:06:42 --> Config Class Initialized
INFO - 2023-09-29 17:06:42 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:06:42 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:06:42 --> Utf8 Class Initialized
INFO - 2023-09-29 17:06:42 --> URI Class Initialized
INFO - 2023-09-29 17:06:42 --> Router Class Initialized
INFO - 2023-09-29 17:06:42 --> Output Class Initialized
INFO - 2023-09-29 17:06:42 --> Security Class Initialized
DEBUG - 2023-09-29 17:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:06:42 --> Input Class Initialized
INFO - 2023-09-29 17:06:43 --> Language Class Initialized
INFO - 2023-09-29 17:06:43 --> Language Class Initialized
INFO - 2023-09-29 17:06:43 --> Config Class Initialized
INFO - 2023-09-29 17:06:43 --> Loader Class Initialized
INFO - 2023-09-29 17:06:43 --> Helper loaded: url_helper
INFO - 2023-09-29 17:06:43 --> Helper loaded: file_helper
INFO - 2023-09-29 17:06:43 --> Helper loaded: form_helper
INFO - 2023-09-29 17:06:43 --> Helper loaded: my_helper
INFO - 2023-09-29 17:06:43 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:43 --> Controller Class Initialized
INFO - 2023-09-29 17:06:43 --> Final output sent to browser
DEBUG - 2023-09-29 17:06:43 --> Total execution time: 0.7887
INFO - 2023-09-29 17:06:52 --> Config Class Initialized
INFO - 2023-09-29 17:06:52 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:06:52 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:06:52 --> Utf8 Class Initialized
INFO - 2023-09-29 17:06:52 --> URI Class Initialized
INFO - 2023-09-29 17:06:52 --> Router Class Initialized
INFO - 2023-09-29 17:06:52 --> Output Class Initialized
INFO - 2023-09-29 17:06:52 --> Security Class Initialized
DEBUG - 2023-09-29 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:06:52 --> Input Class Initialized
INFO - 2023-09-29 17:06:52 --> Language Class Initialized
INFO - 2023-09-29 17:06:52 --> Language Class Initialized
INFO - 2023-09-29 17:06:52 --> Config Class Initialized
INFO - 2023-09-29 17:06:52 --> Loader Class Initialized
INFO - 2023-09-29 17:06:52 --> Helper loaded: url_helper
INFO - 2023-09-29 17:06:52 --> Helper loaded: file_helper
INFO - 2023-09-29 17:06:52 --> Helper loaded: form_helper
INFO - 2023-09-29 17:06:52 --> Helper loaded: my_helper
INFO - 2023-09-29 17:06:52 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:52 --> Controller Class Initialized
INFO - 2023-09-29 17:06:53 --> Final output sent to browser
DEBUG - 2023-09-29 17:06:53 --> Total execution time: 0.5140
INFO - 2023-09-29 17:06:53 --> Config Class Initialized
INFO - 2023-09-29 17:06:53 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:06:53 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:06:53 --> Utf8 Class Initialized
INFO - 2023-09-29 17:06:53 --> URI Class Initialized
INFO - 2023-09-29 17:06:53 --> Router Class Initialized
INFO - 2023-09-29 17:06:53 --> Output Class Initialized
INFO - 2023-09-29 17:06:53 --> Security Class Initialized
DEBUG - 2023-09-29 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:06:53 --> Input Class Initialized
INFO - 2023-09-29 17:06:53 --> Language Class Initialized
INFO - 2023-09-29 17:06:53 --> Language Class Initialized
INFO - 2023-09-29 17:06:53 --> Config Class Initialized
INFO - 2023-09-29 17:06:53 --> Loader Class Initialized
INFO - 2023-09-29 17:06:53 --> Helper loaded: url_helper
INFO - 2023-09-29 17:06:53 --> Helper loaded: file_helper
INFO - 2023-09-29 17:06:53 --> Helper loaded: form_helper
INFO - 2023-09-29 17:06:53 --> Helper loaded: my_helper
INFO - 2023-09-29 17:06:53 --> Database Driver Class Initialized
INFO - 2023-09-29 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:06:53 --> Controller Class Initialized
INFO - 2023-09-29 17:07:07 --> Config Class Initialized
INFO - 2023-09-29 17:07:07 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:07 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:07 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:07 --> URI Class Initialized
INFO - 2023-09-29 17:07:07 --> Router Class Initialized
INFO - 2023-09-29 17:07:07 --> Output Class Initialized
INFO - 2023-09-29 17:07:07 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:07 --> Input Class Initialized
INFO - 2023-09-29 17:07:07 --> Language Class Initialized
INFO - 2023-09-29 17:07:07 --> Language Class Initialized
INFO - 2023-09-29 17:07:07 --> Config Class Initialized
INFO - 2023-09-29 17:07:07 --> Loader Class Initialized
INFO - 2023-09-29 17:07:07 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:07 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:07 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:07 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:07 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:07 --> Controller Class Initialized
INFO - 2023-09-29 17:07:07 --> Final output sent to browser
DEBUG - 2023-09-29 17:07:07 --> Total execution time: 0.3032
INFO - 2023-09-29 17:07:17 --> Config Class Initialized
INFO - 2023-09-29 17:07:17 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:17 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:17 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:17 --> URI Class Initialized
INFO - 2023-09-29 17:07:17 --> Router Class Initialized
INFO - 2023-09-29 17:07:17 --> Output Class Initialized
INFO - 2023-09-29 17:07:17 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:17 --> Input Class Initialized
INFO - 2023-09-29 17:07:17 --> Language Class Initialized
INFO - 2023-09-29 17:07:17 --> Language Class Initialized
INFO - 2023-09-29 17:07:17 --> Config Class Initialized
INFO - 2023-09-29 17:07:17 --> Loader Class Initialized
INFO - 2023-09-29 17:07:17 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:17 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:17 --> Controller Class Initialized
INFO - 2023-09-29 17:07:17 --> Final output sent to browser
DEBUG - 2023-09-29 17:07:17 --> Total execution time: 0.4579
INFO - 2023-09-29 17:07:17 --> Config Class Initialized
INFO - 2023-09-29 17:07:17 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:17 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:17 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:17 --> URI Class Initialized
INFO - 2023-09-29 17:07:17 --> Router Class Initialized
INFO - 2023-09-29 17:07:17 --> Output Class Initialized
INFO - 2023-09-29 17:07:17 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:17 --> Input Class Initialized
INFO - 2023-09-29 17:07:17 --> Language Class Initialized
INFO - 2023-09-29 17:07:17 --> Language Class Initialized
INFO - 2023-09-29 17:07:17 --> Config Class Initialized
INFO - 2023-09-29 17:07:17 --> Loader Class Initialized
INFO - 2023-09-29 17:07:17 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:17 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:17 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:17 --> Controller Class Initialized
INFO - 2023-09-29 17:07:29 --> Config Class Initialized
INFO - 2023-09-29 17:07:29 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:29 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:29 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:29 --> URI Class Initialized
INFO - 2023-09-29 17:07:29 --> Router Class Initialized
INFO - 2023-09-29 17:07:29 --> Output Class Initialized
INFO - 2023-09-29 17:07:29 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:29 --> Input Class Initialized
INFO - 2023-09-29 17:07:29 --> Language Class Initialized
INFO - 2023-09-29 17:07:29 --> Language Class Initialized
INFO - 2023-09-29 17:07:29 --> Config Class Initialized
INFO - 2023-09-29 17:07:29 --> Loader Class Initialized
INFO - 2023-09-29 17:07:29 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:29 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:29 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:29 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:29 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:29 --> Controller Class Initialized
INFO - 2023-09-29 17:07:29 --> Final output sent to browser
DEBUG - 2023-09-29 17:07:29 --> Total execution time: 0.0802
INFO - 2023-09-29 17:07:39 --> Config Class Initialized
INFO - 2023-09-29 17:07:39 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:39 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:39 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:39 --> URI Class Initialized
INFO - 2023-09-29 17:07:39 --> Router Class Initialized
INFO - 2023-09-29 17:07:39 --> Output Class Initialized
INFO - 2023-09-29 17:07:39 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:39 --> Input Class Initialized
INFO - 2023-09-29 17:07:39 --> Language Class Initialized
INFO - 2023-09-29 17:07:39 --> Language Class Initialized
INFO - 2023-09-29 17:07:39 --> Config Class Initialized
INFO - 2023-09-29 17:07:39 --> Loader Class Initialized
INFO - 2023-09-29 17:07:39 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:39 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:39 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:39 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:39 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:39 --> Controller Class Initialized
INFO - 2023-09-29 17:07:39 --> Final output sent to browser
DEBUG - 2023-09-29 17:07:39 --> Total execution time: 0.0460
INFO - 2023-09-29 17:07:39 --> Config Class Initialized
INFO - 2023-09-29 17:07:39 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:39 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:39 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:39 --> URI Class Initialized
INFO - 2023-09-29 17:07:39 --> Router Class Initialized
INFO - 2023-09-29 17:07:39 --> Output Class Initialized
INFO - 2023-09-29 17:07:39 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:39 --> Input Class Initialized
INFO - 2023-09-29 17:07:39 --> Language Class Initialized
INFO - 2023-09-29 17:07:39 --> Language Class Initialized
INFO - 2023-09-29 17:07:39 --> Config Class Initialized
INFO - 2023-09-29 17:07:39 --> Loader Class Initialized
INFO - 2023-09-29 17:07:40 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:40 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:40 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:40 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:40 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:40 --> Controller Class Initialized
INFO - 2023-09-29 17:07:57 --> Config Class Initialized
INFO - 2023-09-29 17:07:57 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:07:57 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:07:57 --> Utf8 Class Initialized
INFO - 2023-09-29 17:07:57 --> URI Class Initialized
INFO - 2023-09-29 17:07:57 --> Router Class Initialized
INFO - 2023-09-29 17:07:57 --> Output Class Initialized
INFO - 2023-09-29 17:07:57 --> Security Class Initialized
DEBUG - 2023-09-29 17:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:07:57 --> Input Class Initialized
INFO - 2023-09-29 17:07:57 --> Language Class Initialized
INFO - 2023-09-29 17:07:57 --> Language Class Initialized
INFO - 2023-09-29 17:07:57 --> Config Class Initialized
INFO - 2023-09-29 17:07:57 --> Loader Class Initialized
INFO - 2023-09-29 17:07:57 --> Helper loaded: url_helper
INFO - 2023-09-29 17:07:57 --> Helper loaded: file_helper
INFO - 2023-09-29 17:07:57 --> Helper loaded: form_helper
INFO - 2023-09-29 17:07:57 --> Helper loaded: my_helper
INFO - 2023-09-29 17:07:57 --> Database Driver Class Initialized
INFO - 2023-09-29 17:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:07:57 --> Controller Class Initialized
INFO - 2023-09-29 17:07:57 --> Final output sent to browser
DEBUG - 2023-09-29 17:07:57 --> Total execution time: 0.0681
INFO - 2023-09-29 17:08:02 --> Config Class Initialized
INFO - 2023-09-29 17:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:02 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:02 --> URI Class Initialized
INFO - 2023-09-29 17:08:02 --> Router Class Initialized
INFO - 2023-09-29 17:08:02 --> Output Class Initialized
INFO - 2023-09-29 17:08:02 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:02 --> Input Class Initialized
INFO - 2023-09-29 17:08:02 --> Language Class Initialized
INFO - 2023-09-29 17:08:02 --> Language Class Initialized
INFO - 2023-09-29 17:08:02 --> Config Class Initialized
INFO - 2023-09-29 17:08:02 --> Loader Class Initialized
INFO - 2023-09-29 17:08:02 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:02 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:02 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:02 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:02 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:02 --> Controller Class Initialized
INFO - 2023-09-29 17:08:02 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:02 --> Total execution time: 0.4460
INFO - 2023-09-29 17:08:05 --> Config Class Initialized
INFO - 2023-09-29 17:08:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:05 --> URI Class Initialized
INFO - 2023-09-29 17:08:05 --> Router Class Initialized
INFO - 2023-09-29 17:08:05 --> Output Class Initialized
INFO - 2023-09-29 17:08:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:05 --> Input Class Initialized
INFO - 2023-09-29 17:08:05 --> Language Class Initialized
INFO - 2023-09-29 17:08:05 --> Language Class Initialized
INFO - 2023-09-29 17:08:05 --> Config Class Initialized
INFO - 2023-09-29 17:08:05 --> Loader Class Initialized
INFO - 2023-09-29 17:08:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:05 --> Controller Class Initialized
INFO - 2023-09-29 17:08:05 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:05 --> Total execution time: 0.1248
INFO - 2023-09-29 17:08:08 --> Config Class Initialized
INFO - 2023-09-29 17:08:08 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:08 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:08 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:08 --> URI Class Initialized
INFO - 2023-09-29 17:08:08 --> Router Class Initialized
INFO - 2023-09-29 17:08:08 --> Output Class Initialized
INFO - 2023-09-29 17:08:08 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:08 --> Input Class Initialized
INFO - 2023-09-29 17:08:08 --> Language Class Initialized
INFO - 2023-09-29 17:08:08 --> Language Class Initialized
INFO - 2023-09-29 17:08:08 --> Config Class Initialized
INFO - 2023-09-29 17:08:08 --> Loader Class Initialized
INFO - 2023-09-29 17:08:08 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:08 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:08 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:08 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:08 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:08 --> Controller Class Initialized
INFO - 2023-09-29 17:08:08 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:08 --> Total execution time: 0.1125
INFO - 2023-09-29 17:08:10 --> Config Class Initialized
INFO - 2023-09-29 17:08:10 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:10 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:10 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:10 --> URI Class Initialized
INFO - 2023-09-29 17:08:10 --> Router Class Initialized
INFO - 2023-09-29 17:08:10 --> Output Class Initialized
INFO - 2023-09-29 17:08:10 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:10 --> Input Class Initialized
INFO - 2023-09-29 17:08:10 --> Language Class Initialized
INFO - 2023-09-29 17:08:10 --> Language Class Initialized
INFO - 2023-09-29 17:08:10 --> Config Class Initialized
INFO - 2023-09-29 17:08:10 --> Loader Class Initialized
INFO - 2023-09-29 17:08:10 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:10 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:10 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:10 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:10 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:10 --> Controller Class Initialized
INFO - 2023-09-29 17:08:10 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:10 --> Total execution time: 0.2492
INFO - 2023-09-29 17:08:11 --> Config Class Initialized
INFO - 2023-09-29 17:08:11 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:11 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:11 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:11 --> URI Class Initialized
INFO - 2023-09-29 17:08:11 --> Router Class Initialized
INFO - 2023-09-29 17:08:11 --> Output Class Initialized
INFO - 2023-09-29 17:08:11 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:11 --> Input Class Initialized
INFO - 2023-09-29 17:08:11 --> Language Class Initialized
INFO - 2023-09-29 17:08:11 --> Language Class Initialized
INFO - 2023-09-29 17:08:11 --> Config Class Initialized
INFO - 2023-09-29 17:08:11 --> Loader Class Initialized
INFO - 2023-09-29 17:08:11 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:11 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:11 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:11 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:11 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:11 --> Controller Class Initialized
INFO - 2023-09-29 17:08:11 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:11 --> Total execution time: 0.0572
INFO - 2023-09-29 17:08:13 --> Config Class Initialized
INFO - 2023-09-29 17:08:13 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:08:13 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:08:13 --> Utf8 Class Initialized
INFO - 2023-09-29 17:08:13 --> URI Class Initialized
INFO - 2023-09-29 17:08:13 --> Router Class Initialized
INFO - 2023-09-29 17:08:13 --> Output Class Initialized
INFO - 2023-09-29 17:08:13 --> Security Class Initialized
DEBUG - 2023-09-29 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:08:13 --> Input Class Initialized
INFO - 2023-09-29 17:08:13 --> Language Class Initialized
INFO - 2023-09-29 17:08:13 --> Language Class Initialized
INFO - 2023-09-29 17:08:13 --> Config Class Initialized
INFO - 2023-09-29 17:08:13 --> Loader Class Initialized
INFO - 2023-09-29 17:08:13 --> Helper loaded: url_helper
INFO - 2023-09-29 17:08:13 --> Helper loaded: file_helper
INFO - 2023-09-29 17:08:13 --> Helper loaded: form_helper
INFO - 2023-09-29 17:08:13 --> Helper loaded: my_helper
INFO - 2023-09-29 17:08:13 --> Database Driver Class Initialized
INFO - 2023-09-29 17:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:08:13 --> Controller Class Initialized
INFO - 2023-09-29 17:08:13 --> Final output sent to browser
DEBUG - 2023-09-29 17:08:13 --> Total execution time: 0.0557
INFO - 2023-09-29 17:10:49 --> Config Class Initialized
INFO - 2023-09-29 17:10:49 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:10:49 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:10:49 --> Utf8 Class Initialized
INFO - 2023-09-29 17:10:49 --> URI Class Initialized
INFO - 2023-09-29 17:10:49 --> Router Class Initialized
INFO - 2023-09-29 17:10:49 --> Output Class Initialized
INFO - 2023-09-29 17:10:49 --> Security Class Initialized
DEBUG - 2023-09-29 17:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:10:49 --> Input Class Initialized
INFO - 2023-09-29 17:10:49 --> Language Class Initialized
INFO - 2023-09-29 17:10:49 --> Language Class Initialized
INFO - 2023-09-29 17:10:49 --> Config Class Initialized
INFO - 2023-09-29 17:10:49 --> Loader Class Initialized
INFO - 2023-09-29 17:10:49 --> Helper loaded: url_helper
INFO - 2023-09-29 17:10:49 --> Helper loaded: file_helper
INFO - 2023-09-29 17:10:49 --> Helper loaded: form_helper
INFO - 2023-09-29 17:10:49 --> Helper loaded: my_helper
INFO - 2023-09-29 17:10:49 --> Database Driver Class Initialized
INFO - 2023-09-29 17:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:10:49 --> Controller Class Initialized
INFO - 2023-09-29 17:10:49 --> Final output sent to browser
DEBUG - 2023-09-29 17:10:49 --> Total execution time: 0.2450
INFO - 2023-09-29 17:10:58 --> Config Class Initialized
INFO - 2023-09-29 17:10:58 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:10:58 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:10:58 --> Utf8 Class Initialized
INFO - 2023-09-29 17:10:58 --> URI Class Initialized
INFO - 2023-09-29 17:10:58 --> Router Class Initialized
INFO - 2023-09-29 17:10:58 --> Output Class Initialized
INFO - 2023-09-29 17:10:58 --> Security Class Initialized
DEBUG - 2023-09-29 17:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:10:58 --> Input Class Initialized
INFO - 2023-09-29 17:10:58 --> Language Class Initialized
INFO - 2023-09-29 17:10:58 --> Language Class Initialized
INFO - 2023-09-29 17:10:58 --> Config Class Initialized
INFO - 2023-09-29 17:10:58 --> Loader Class Initialized
INFO - 2023-09-29 17:10:58 --> Helper loaded: url_helper
INFO - 2023-09-29 17:10:58 --> Helper loaded: file_helper
INFO - 2023-09-29 17:10:58 --> Helper loaded: form_helper
INFO - 2023-09-29 17:10:58 --> Helper loaded: my_helper
INFO - 2023-09-29 17:10:59 --> Database Driver Class Initialized
INFO - 2023-09-29 17:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:10:59 --> Controller Class Initialized
DEBUG - 2023-09-29 17:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 17:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 17:10:59 --> Final output sent to browser
DEBUG - 2023-09-29 17:10:59 --> Total execution time: 0.7037
INFO - 2023-09-29 17:11:02 --> Config Class Initialized
INFO - 2023-09-29 17:11:02 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:11:02 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:11:02 --> Utf8 Class Initialized
INFO - 2023-09-29 17:11:02 --> URI Class Initialized
INFO - 2023-09-29 17:11:02 --> Router Class Initialized
INFO - 2023-09-29 17:11:02 --> Output Class Initialized
INFO - 2023-09-29 17:11:02 --> Security Class Initialized
DEBUG - 2023-09-29 17:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:11:02 --> Input Class Initialized
INFO - 2023-09-29 17:11:02 --> Language Class Initialized
INFO - 2023-09-29 17:11:02 --> Language Class Initialized
INFO - 2023-09-29 17:11:02 --> Config Class Initialized
INFO - 2023-09-29 17:11:02 --> Loader Class Initialized
INFO - 2023-09-29 17:11:02 --> Helper loaded: url_helper
INFO - 2023-09-29 17:11:02 --> Helper loaded: file_helper
INFO - 2023-09-29 17:11:02 --> Helper loaded: form_helper
INFO - 2023-09-29 17:11:02 --> Helper loaded: my_helper
INFO - 2023-09-29 17:11:02 --> Database Driver Class Initialized
INFO - 2023-09-29 17:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:11:02 --> Controller Class Initialized
DEBUG - 2023-09-29 17:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-29 17:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 17:11:03 --> Final output sent to browser
DEBUG - 2023-09-29 17:11:03 --> Total execution time: 1.0657
INFO - 2023-09-29 17:11:05 --> Config Class Initialized
INFO - 2023-09-29 17:11:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:11:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:11:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:11:05 --> URI Class Initialized
INFO - 2023-09-29 17:11:05 --> Router Class Initialized
INFO - 2023-09-29 17:11:05 --> Output Class Initialized
INFO - 2023-09-29 17:11:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:11:05 --> Input Class Initialized
INFO - 2023-09-29 17:11:05 --> Language Class Initialized
INFO - 2023-09-29 17:11:05 --> Language Class Initialized
INFO - 2023-09-29 17:11:05 --> Config Class Initialized
INFO - 2023-09-29 17:11:05 --> Loader Class Initialized
INFO - 2023-09-29 17:11:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:11:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:11:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:11:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:11:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:11:05 --> Controller Class Initialized
INFO - 2023-09-29 17:11:05 --> Final output sent to browser
DEBUG - 2023-09-29 17:11:05 --> Total execution time: 0.2683
INFO - 2023-09-29 17:14:22 --> Config Class Initialized
INFO - 2023-09-29 17:14:22 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:14:22 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:14:22 --> Utf8 Class Initialized
INFO - 2023-09-29 17:14:22 --> URI Class Initialized
INFO - 2023-09-29 17:14:22 --> Router Class Initialized
INFO - 2023-09-29 17:14:22 --> Output Class Initialized
INFO - 2023-09-29 17:14:22 --> Security Class Initialized
DEBUG - 2023-09-29 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:14:22 --> Input Class Initialized
INFO - 2023-09-29 17:14:22 --> Language Class Initialized
INFO - 2023-09-29 17:14:22 --> Language Class Initialized
INFO - 2023-09-29 17:14:22 --> Config Class Initialized
INFO - 2023-09-29 17:14:22 --> Loader Class Initialized
INFO - 2023-09-29 17:14:22 --> Helper loaded: url_helper
INFO - 2023-09-29 17:14:22 --> Helper loaded: file_helper
INFO - 2023-09-29 17:14:22 --> Helper loaded: form_helper
INFO - 2023-09-29 17:14:22 --> Helper loaded: my_helper
INFO - 2023-09-29 17:14:22 --> Database Driver Class Initialized
INFO - 2023-09-29 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:14:22 --> Controller Class Initialized
INFO - 2023-09-29 17:15:25 --> Config Class Initialized
INFO - 2023-09-29 17:15:25 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:25 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:25 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:25 --> URI Class Initialized
INFO - 2023-09-29 17:15:25 --> Router Class Initialized
INFO - 2023-09-29 17:15:25 --> Output Class Initialized
INFO - 2023-09-29 17:15:26 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:26 --> Input Class Initialized
INFO - 2023-09-29 17:15:26 --> Language Class Initialized
INFO - 2023-09-29 17:15:26 --> Language Class Initialized
INFO - 2023-09-29 17:15:26 --> Config Class Initialized
INFO - 2023-09-29 17:15:26 --> Loader Class Initialized
INFO - 2023-09-29 17:15:26 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:26 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:26 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:26 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:26 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:26 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:33 --> Config Class Initialized
INFO - 2023-09-29 17:15:33 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:33 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:33 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:33 --> URI Class Initialized
INFO - 2023-09-29 17:15:33 --> Router Class Initialized
INFO - 2023-09-29 17:15:33 --> Output Class Initialized
INFO - 2023-09-29 17:15:33 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:33 --> Input Class Initialized
INFO - 2023-09-29 17:15:33 --> Language Class Initialized
INFO - 2023-09-29 17:15:33 --> Language Class Initialized
INFO - 2023-09-29 17:15:33 --> Config Class Initialized
INFO - 2023-09-29 17:15:33 --> Loader Class Initialized
INFO - 2023-09-29 17:15:33 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:34 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:34 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:34 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:34 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:34 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:36 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:36 --> URI Class Initialized
INFO - 2023-09-29 17:15:36 --> Router Class Initialized
INFO - 2023-09-29 17:15:36 --> Output Class Initialized
INFO - 2023-09-29 17:15:36 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:36 --> Input Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Loader Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:36 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:36 --> URI Class Initialized
INFO - 2023-09-29 17:15:36 --> Router Class Initialized
INFO - 2023-09-29 17:15:36 --> Output Class Initialized
INFO - 2023-09-29 17:15:36 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:36 --> Input Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Loader Class Initialized
INFO - 2023-09-29 17:15:36 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:36 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:36 --> Controller Class Initialized
INFO - 2023-09-29 17:15:36 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:36 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:36 --> URI Class Initialized
INFO - 2023-09-29 17:15:36 --> Router Class Initialized
INFO - 2023-09-29 17:15:36 --> Output Class Initialized
INFO - 2023-09-29 17:15:36 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:36 --> Input Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Loader Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:36 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:36 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:36 --> URI Class Initialized
INFO - 2023-09-29 17:15:36 --> Router Class Initialized
INFO - 2023-09-29 17:15:36 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:36 --> Database Driver Class Initialized
ERROR - 2023-09-29 17:15:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:36 --> Controller Class Initialized
INFO - 2023-09-29 17:15:36 --> Output Class Initialized
INFO - 2023-09-29 17:15:36 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:36 --> Input Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Language Class Initialized
INFO - 2023-09-29 17:15:36 --> Config Class Initialized
INFO - 2023-09-29 17:15:36 --> Loader Class Initialized
INFO - 2023-09-29 17:15:36 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:36 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:37 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:37 --> Config Class Initialized
INFO - 2023-09-29 17:15:37 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:37 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:37 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:37 --> URI Class Initialized
INFO - 2023-09-29 17:15:37 --> Router Class Initialized
ERROR - 2023-09-29 17:15:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:37 --> Output Class Initialized
INFO - 2023-09-29 17:15:37 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:37 --> Input Class Initialized
INFO - 2023-09-29 17:15:37 --> Language Class Initialized
INFO - 2023-09-29 17:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:37 --> Controller Class Initialized
INFO - 2023-09-29 17:15:37 --> Language Class Initialized
INFO - 2023-09-29 17:15:37 --> Config Class Initialized
INFO - 2023-09-29 17:15:37 --> Loader Class Initialized
INFO - 2023-09-29 17:15:37 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:37 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:37 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:37 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:37 --> Database Driver Class Initialized
ERROR - 2023-09-29 17:15:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:37 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:37 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:41 --> Config Class Initialized
INFO - 2023-09-29 17:15:41 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:41 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:41 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:41 --> URI Class Initialized
INFO - 2023-09-29 17:15:41 --> Router Class Initialized
INFO - 2023-09-29 17:15:41 --> Output Class Initialized
INFO - 2023-09-29 17:15:41 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:41 --> Input Class Initialized
INFO - 2023-09-29 17:15:41 --> Language Class Initialized
INFO - 2023-09-29 17:15:41 --> Language Class Initialized
INFO - 2023-09-29 17:15:41 --> Config Class Initialized
INFO - 2023-09-29 17:15:41 --> Loader Class Initialized
INFO - 2023-09-29 17:15:41 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:41 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:41 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:41 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:41 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:41 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:42 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:42 --> Config Class Initialized
INFO - 2023-09-29 17:15:42 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:42 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:42 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:42 --> URI Class Initialized
INFO - 2023-09-29 17:15:42 --> Router Class Initialized
INFO - 2023-09-29 17:15:42 --> Output Class Initialized
INFO - 2023-09-29 17:15:42 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:42 --> Input Class Initialized
INFO - 2023-09-29 17:15:42 --> Language Class Initialized
INFO - 2023-09-29 17:15:42 --> Language Class Initialized
INFO - 2023-09-29 17:15:42 --> Config Class Initialized
INFO - 2023-09-29 17:15:42 --> Loader Class Initialized
INFO - 2023-09-29 17:15:42 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:42 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:42 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:42 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:42 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:43 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:43 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:44 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:44 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:44 --> URI Class Initialized
INFO - 2023-09-29 17:15:44 --> Router Class Initialized
INFO - 2023-09-29 17:15:44 --> Output Class Initialized
INFO - 2023-09-29 17:15:44 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:44 --> Input Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Language Class Initialized
INFO - 2023-09-29 17:15:44 --> Config Class Initialized
INFO - 2023-09-29 17:15:44 --> Loader Class Initialized
INFO - 2023-09-29 17:15:44 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:44 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:44 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:44 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:45 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:45 --> URI Class Initialized
INFO - 2023-09-29 17:15:45 --> Router Class Initialized
INFO - 2023-09-29 17:15:45 --> Output Class Initialized
INFO - 2023-09-29 17:15:45 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:45 --> Input Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Loader Class Initialized
INFO - 2023-09-29 17:15:45 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:45 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:45 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:45 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:45 --> URI Class Initialized
INFO - 2023-09-29 17:15:45 --> Router Class Initialized
INFO - 2023-09-29 17:15:45 --> Output Class Initialized
INFO - 2023-09-29 17:15:45 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:45 --> Input Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Loader Class Initialized
INFO - 2023-09-29 17:15:45 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:45 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:45 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:45 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:45 --> URI Class Initialized
INFO - 2023-09-29 17:15:45 --> Router Class Initialized
INFO - 2023-09-29 17:15:45 --> Output Class Initialized
INFO - 2023-09-29 17:15:45 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:45 --> Input Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Loader Class Initialized
INFO - 2023-09-29 17:15:45 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:45 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:45 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:45 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:45 --> URI Class Initialized
INFO - 2023-09-29 17:15:45 --> Router Class Initialized
INFO - 2023-09-29 17:15:45 --> Output Class Initialized
INFO - 2023-09-29 17:15:45 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:45 --> Input Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Loader Class Initialized
INFO - 2023-09-29 17:15:45 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:45 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:45 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:45 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:45 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:45 --> URI Class Initialized
INFO - 2023-09-29 17:15:45 --> Router Class Initialized
INFO - 2023-09-29 17:15:45 --> Output Class Initialized
INFO - 2023-09-29 17:15:45 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:45 --> Input Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Language Class Initialized
INFO - 2023-09-29 17:15:45 --> Config Class Initialized
INFO - 2023-09-29 17:15:45 --> Loader Class Initialized
INFO - 2023-09-29 17:15:45 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:45 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:45 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:45 --> Controller Class Initialized
ERROR - 2023-09-29 17:15:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:15:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:15:50 --> Config Class Initialized
INFO - 2023-09-29 17:15:50 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:50 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:50 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:50 --> URI Class Initialized
INFO - 2023-09-29 17:15:50 --> Router Class Initialized
INFO - 2023-09-29 17:15:50 --> Output Class Initialized
INFO - 2023-09-29 17:15:50 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:50 --> Input Class Initialized
INFO - 2023-09-29 17:15:50 --> Language Class Initialized
INFO - 2023-09-29 17:15:50 --> Language Class Initialized
INFO - 2023-09-29 17:15:50 --> Config Class Initialized
INFO - 2023-09-29 17:15:50 --> Loader Class Initialized
INFO - 2023-09-29 17:15:50 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:50 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:50 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:50 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:50 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:50 --> Controller Class Initialized
DEBUG - 2023-09-29 17:15:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-29 17:15:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 17:15:50 --> Final output sent to browser
DEBUG - 2023-09-29 17:15:50 --> Total execution time: 0.0777
INFO - 2023-09-29 17:15:53 --> Config Class Initialized
INFO - 2023-09-29 17:15:53 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:53 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:53 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:53 --> URI Class Initialized
INFO - 2023-09-29 17:15:53 --> Router Class Initialized
INFO - 2023-09-29 17:15:53 --> Output Class Initialized
INFO - 2023-09-29 17:15:53 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:53 --> Input Class Initialized
INFO - 2023-09-29 17:15:53 --> Language Class Initialized
INFO - 2023-09-29 17:15:53 --> Language Class Initialized
INFO - 2023-09-29 17:15:53 --> Config Class Initialized
INFO - 2023-09-29 17:15:53 --> Loader Class Initialized
INFO - 2023-09-29 17:15:53 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:53 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:53 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:53 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:53 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:53 --> Controller Class Initialized
DEBUG - 2023-09-29 17:15:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-29 17:15:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 17:15:53 --> Final output sent to browser
DEBUG - 2023-09-29 17:15:53 --> Total execution time: 0.1724
INFO - 2023-09-29 17:15:56 --> Config Class Initialized
INFO - 2023-09-29 17:15:56 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:15:56 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:15:56 --> Utf8 Class Initialized
INFO - 2023-09-29 17:15:56 --> URI Class Initialized
INFO - 2023-09-29 17:15:56 --> Router Class Initialized
INFO - 2023-09-29 17:15:56 --> Output Class Initialized
INFO - 2023-09-29 17:15:56 --> Security Class Initialized
DEBUG - 2023-09-29 17:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:15:56 --> Input Class Initialized
INFO - 2023-09-29 17:15:56 --> Language Class Initialized
INFO - 2023-09-29 17:15:56 --> Language Class Initialized
INFO - 2023-09-29 17:15:56 --> Config Class Initialized
INFO - 2023-09-29 17:15:56 --> Loader Class Initialized
INFO - 2023-09-29 17:15:56 --> Helper loaded: url_helper
INFO - 2023-09-29 17:15:56 --> Helper loaded: file_helper
INFO - 2023-09-29 17:15:56 --> Helper loaded: form_helper
INFO - 2023-09-29 17:15:56 --> Helper loaded: my_helper
INFO - 2023-09-29 17:15:56 --> Database Driver Class Initialized
INFO - 2023-09-29 17:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:15:56 --> Controller Class Initialized
INFO - 2023-09-29 17:15:56 --> Final output sent to browser
DEBUG - 2023-09-29 17:15:56 --> Total execution time: 0.0744
INFO - 2023-09-29 17:16:53 --> Config Class Initialized
INFO - 2023-09-29 17:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:16:53 --> Utf8 Class Initialized
INFO - 2023-09-29 17:16:53 --> URI Class Initialized
INFO - 2023-09-29 17:16:53 --> Router Class Initialized
INFO - 2023-09-29 17:16:53 --> Output Class Initialized
INFO - 2023-09-29 17:16:53 --> Security Class Initialized
DEBUG - 2023-09-29 17:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:16:53 --> Input Class Initialized
INFO - 2023-09-29 17:16:53 --> Language Class Initialized
INFO - 2023-09-29 17:16:54 --> Language Class Initialized
INFO - 2023-09-29 17:16:54 --> Config Class Initialized
INFO - 2023-09-29 17:16:54 --> Loader Class Initialized
INFO - 2023-09-29 17:16:54 --> Helper loaded: url_helper
INFO - 2023-09-29 17:16:54 --> Helper loaded: file_helper
INFO - 2023-09-29 17:16:54 --> Helper loaded: form_helper
INFO - 2023-09-29 17:16:54 --> Helper loaded: my_helper
INFO - 2023-09-29 17:16:54 --> Database Driver Class Initialized
INFO - 2023-09-29 17:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:16:54 --> Controller Class Initialized
ERROR - 2023-09-29 17:16:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:16:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:05 --> URI Class Initialized
INFO - 2023-09-29 17:17:05 --> Router Class Initialized
INFO - 2023-09-29 17:17:05 --> Output Class Initialized
INFO - 2023-09-29 17:17:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:05 --> Input Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Loader Class Initialized
INFO - 2023-09-29 17:17:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:05 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:05 --> URI Class Initialized
INFO - 2023-09-29 17:17:05 --> Router Class Initialized
INFO - 2023-09-29 17:17:05 --> Output Class Initialized
INFO - 2023-09-29 17:17:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:05 --> Input Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Loader Class Initialized
INFO - 2023-09-29 17:17:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:05 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:05 --> URI Class Initialized
INFO - 2023-09-29 17:17:05 --> Router Class Initialized
INFO - 2023-09-29 17:17:05 --> Output Class Initialized
INFO - 2023-09-29 17:17:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:05 --> Input Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Loader Class Initialized
INFO - 2023-09-29 17:17:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:05 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:05 --> URI Class Initialized
INFO - 2023-09-29 17:17:05 --> Router Class Initialized
INFO - 2023-09-29 17:17:05 --> Output Class Initialized
INFO - 2023-09-29 17:17:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:05 --> Input Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Loader Class Initialized
INFO - 2023-09-29 17:17:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:05 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:05 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:05 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:05 --> URI Class Initialized
INFO - 2023-09-29 17:17:05 --> Router Class Initialized
INFO - 2023-09-29 17:17:05 --> Output Class Initialized
INFO - 2023-09-29 17:17:05 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:05 --> Input Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Language Class Initialized
INFO - 2023-09-29 17:17:05 --> Config Class Initialized
INFO - 2023-09-29 17:17:05 --> Loader Class Initialized
INFO - 2023-09-29 17:17:05 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:05 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:05 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:05 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:06 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:06 --> URI Class Initialized
INFO - 2023-09-29 17:17:06 --> Router Class Initialized
INFO - 2023-09-29 17:17:06 --> Output Class Initialized
INFO - 2023-09-29 17:17:06 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:06 --> Input Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Loader Class Initialized
INFO - 2023-09-29 17:17:06 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:06 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:06 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:06 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:06 --> URI Class Initialized
INFO - 2023-09-29 17:17:06 --> Router Class Initialized
INFO - 2023-09-29 17:17:06 --> Output Class Initialized
INFO - 2023-09-29 17:17:06 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:06 --> Input Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Loader Class Initialized
INFO - 2023-09-29 17:17:06 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:06 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:06 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:06 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:06 --> URI Class Initialized
INFO - 2023-09-29 17:17:06 --> Router Class Initialized
INFO - 2023-09-29 17:17:06 --> Output Class Initialized
INFO - 2023-09-29 17:17:06 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:06 --> Input Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Loader Class Initialized
INFO - 2023-09-29 17:17:06 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:06 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:06 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:06 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:06 --> URI Class Initialized
INFO - 2023-09-29 17:17:06 --> Router Class Initialized
INFO - 2023-09-29 17:17:06 --> Output Class Initialized
INFO - 2023-09-29 17:17:06 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:06 --> Input Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Loader Class Initialized
INFO - 2023-09-29 17:17:06 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:06 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:06 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:06 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:06 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:06 --> URI Class Initialized
INFO - 2023-09-29 17:17:06 --> Router Class Initialized
INFO - 2023-09-29 17:17:06 --> Output Class Initialized
INFO - 2023-09-29 17:17:06 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:06 --> Input Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Language Class Initialized
INFO - 2023-09-29 17:17:06 --> Config Class Initialized
INFO - 2023-09-29 17:17:06 --> Loader Class Initialized
INFO - 2023-09-29 17:17:06 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:06 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:06 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:06 --> Controller Class Initialized
INFO - 2023-09-29 17:17:07 --> Config Class Initialized
INFO - 2023-09-29 17:17:07 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:07 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:07 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:07 --> URI Class Initialized
INFO - 2023-09-29 17:17:07 --> Router Class Initialized
INFO - 2023-09-29 17:17:07 --> Output Class Initialized
INFO - 2023-09-29 17:17:07 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:07 --> Input Class Initialized
INFO - 2023-09-29 17:17:07 --> Language Class Initialized
INFO - 2023-09-29 17:17:07 --> Language Class Initialized
INFO - 2023-09-29 17:17:07 --> Config Class Initialized
INFO - 2023-09-29 17:17:07 --> Loader Class Initialized
INFO - 2023-09-29 17:17:07 --> Helper loaded: url_helper
ERROR - 2023-09-29 17:17:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:07 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:07 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:07 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:07 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:07 --> Controller Class Initialized
INFO - 2023-09-29 17:17:07 --> Config Class Initialized
INFO - 2023-09-29 17:17:07 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:07 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:07 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:07 --> URI Class Initialized
INFO - 2023-09-29 17:17:07 --> Router Class Initialized
INFO - 2023-09-29 17:17:07 --> Output Class Initialized
INFO - 2023-09-29 17:17:07 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:07 --> Input Class Initialized
INFO - 2023-09-29 17:17:07 --> Language Class Initialized
INFO - 2023-09-29 17:17:07 --> Language Class Initialized
INFO - 2023-09-29 17:17:07 --> Config Class Initialized
INFO - 2023-09-29 17:17:07 --> Loader Class Initialized
INFO - 2023-09-29 17:17:07 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:07 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:07 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:07 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:07 --> Database Driver Class Initialized
ERROR - 2023-09-29 17:17:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:07 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:08 --> Config Class Initialized
INFO - 2023-09-29 17:17:08 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:08 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:08 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:08 --> URI Class Initialized
INFO - 2023-09-29 17:17:08 --> Router Class Initialized
INFO - 2023-09-29 17:17:08 --> Output Class Initialized
INFO - 2023-09-29 17:17:08 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:08 --> Input Class Initialized
INFO - 2023-09-29 17:17:08 --> Language Class Initialized
INFO - 2023-09-29 17:17:08 --> Language Class Initialized
INFO - 2023-09-29 17:17:08 --> Config Class Initialized
INFO - 2023-09-29 17:17:08 --> Loader Class Initialized
INFO - 2023-09-29 17:17:08 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:08 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:08 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:08 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:08 --> Config Class Initialized
INFO - 2023-09-29 17:17:08 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:08 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:08 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:08 --> URI Class Initialized
INFO - 2023-09-29 17:17:08 --> Router Class Initialized
INFO - 2023-09-29 17:17:08 --> Output Class Initialized
INFO - 2023-09-29 17:17:08 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:08 --> Input Class Initialized
INFO - 2023-09-29 17:17:08 --> Language Class Initialized
INFO - 2023-09-29 17:17:08 --> Language Class Initialized
INFO - 2023-09-29 17:17:08 --> Config Class Initialized
INFO - 2023-09-29 17:17:08 --> Loader Class Initialized
INFO - 2023-09-29 17:17:08 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:08 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:08 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:08 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:09 --> Config Class Initialized
INFO - 2023-09-29 17:17:09 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:09 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:09 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:09 --> URI Class Initialized
INFO - 2023-09-29 17:17:09 --> Router Class Initialized
INFO - 2023-09-29 17:17:09 --> Output Class Initialized
INFO - 2023-09-29 17:17:09 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:09 --> Input Class Initialized
INFO - 2023-09-29 17:17:09 --> Language Class Initialized
INFO - 2023-09-29 17:17:09 --> Language Class Initialized
INFO - 2023-09-29 17:17:09 --> Config Class Initialized
INFO - 2023-09-29 17:17:09 --> Loader Class Initialized
INFO - 2023-09-29 17:17:09 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:09 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:09 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 17:17:09 --> Config Class Initialized
INFO - 2023-09-29 17:17:09 --> Hooks Class Initialized
DEBUG - 2023-09-29 17:17:09 --> UTF-8 Support Enabled
INFO - 2023-09-29 17:17:09 --> Utf8 Class Initialized
INFO - 2023-09-29 17:17:09 --> URI Class Initialized
INFO - 2023-09-29 17:17:09 --> Router Class Initialized
INFO - 2023-09-29 17:17:09 --> Output Class Initialized
INFO - 2023-09-29 17:17:09 --> Security Class Initialized
DEBUG - 2023-09-29 17:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 17:17:09 --> Input Class Initialized
INFO - 2023-09-29 17:17:09 --> Language Class Initialized
INFO - 2023-09-29 17:17:09 --> Language Class Initialized
INFO - 2023-09-29 17:17:09 --> Config Class Initialized
INFO - 2023-09-29 17:17:09 --> Loader Class Initialized
INFO - 2023-09-29 17:17:09 --> Helper loaded: url_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: file_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: form_helper
INFO - 2023-09-29 17:17:09 --> Helper loaded: my_helper
INFO - 2023-09-29 17:17:09 --> Database Driver Class Initialized
INFO - 2023-09-29 17:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 17:17:09 --> Controller Class Initialized
ERROR - 2023-09-29 17:17:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20231', 'c', '3', '10', '12', '-', 'There is noticeable progress in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2023-09-29 17:17:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-29 18:20:32 --> Config Class Initialized
INFO - 2023-09-29 18:20:32 --> Hooks Class Initialized
DEBUG - 2023-09-29 18:20:32 --> UTF-8 Support Enabled
INFO - 2023-09-29 18:20:32 --> Utf8 Class Initialized
INFO - 2023-09-29 18:20:32 --> URI Class Initialized
INFO - 2023-09-29 18:20:32 --> Router Class Initialized
INFO - 2023-09-29 18:20:32 --> Output Class Initialized
INFO - 2023-09-29 18:20:32 --> Security Class Initialized
DEBUG - 2023-09-29 18:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 18:20:32 --> Input Class Initialized
INFO - 2023-09-29 18:20:32 --> Language Class Initialized
INFO - 2023-09-29 18:20:32 --> Language Class Initialized
INFO - 2023-09-29 18:20:32 --> Config Class Initialized
INFO - 2023-09-29 18:20:32 --> Loader Class Initialized
INFO - 2023-09-29 18:20:32 --> Helper loaded: url_helper
INFO - 2023-09-29 18:20:32 --> Helper loaded: file_helper
INFO - 2023-09-29 18:20:32 --> Helper loaded: form_helper
INFO - 2023-09-29 18:20:32 --> Helper loaded: my_helper
INFO - 2023-09-29 18:20:32 --> Database Driver Class Initialized
INFO - 2023-09-29 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 18:20:32 --> Controller Class Initialized
DEBUG - 2023-09-29 18:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-09-29 18:20:32 --> Final output sent to browser
DEBUG - 2023-09-29 18:20:32 --> Total execution time: 0.2027
INFO - 2023-09-29 18:20:41 --> Config Class Initialized
INFO - 2023-09-29 18:20:41 --> Hooks Class Initialized
DEBUG - 2023-09-29 18:20:41 --> UTF-8 Support Enabled
INFO - 2023-09-29 18:20:41 --> Utf8 Class Initialized
INFO - 2023-09-29 18:20:41 --> URI Class Initialized
INFO - 2023-09-29 18:20:42 --> Router Class Initialized
INFO - 2023-09-29 18:20:42 --> Output Class Initialized
INFO - 2023-09-29 18:20:42 --> Security Class Initialized
DEBUG - 2023-09-29 18:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 18:20:42 --> Input Class Initialized
INFO - 2023-09-29 18:20:42 --> Language Class Initialized
INFO - 2023-09-29 18:20:42 --> Language Class Initialized
INFO - 2023-09-29 18:20:42 --> Config Class Initialized
INFO - 2023-09-29 18:20:42 --> Loader Class Initialized
INFO - 2023-09-29 18:20:42 --> Helper loaded: url_helper
INFO - 2023-09-29 18:20:42 --> Helper loaded: file_helper
INFO - 2023-09-29 18:20:42 --> Helper loaded: form_helper
INFO - 2023-09-29 18:20:42 --> Helper loaded: my_helper
INFO - 2023-09-29 18:20:42 --> Database Driver Class Initialized
INFO - 2023-09-29 18:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 18:20:42 --> Controller Class Initialized
DEBUG - 2023-09-29 18:20:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 18:20:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 18:20:42 --> Final output sent to browser
DEBUG - 2023-09-29 18:20:42 --> Total execution time: 0.1633
INFO - 2023-09-29 19:03:02 --> Config Class Initialized
INFO - 2023-09-29 19:03:02 --> Hooks Class Initialized
DEBUG - 2023-09-29 19:03:02 --> UTF-8 Support Enabled
INFO - 2023-09-29 19:03:02 --> Utf8 Class Initialized
INFO - 2023-09-29 19:03:02 --> URI Class Initialized
INFO - 2023-09-29 19:03:02 --> Router Class Initialized
INFO - 2023-09-29 19:03:02 --> Output Class Initialized
INFO - 2023-09-29 19:03:02 --> Security Class Initialized
DEBUG - 2023-09-29 19:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-29 19:03:02 --> Input Class Initialized
INFO - 2023-09-29 19:03:02 --> Language Class Initialized
INFO - 2023-09-29 19:03:02 --> Language Class Initialized
INFO - 2023-09-29 19:03:02 --> Config Class Initialized
INFO - 2023-09-29 19:03:02 --> Loader Class Initialized
INFO - 2023-09-29 19:03:02 --> Helper loaded: url_helper
INFO - 2023-09-29 19:03:02 --> Helper loaded: file_helper
INFO - 2023-09-29 19:03:02 --> Helper loaded: form_helper
INFO - 2023-09-29 19:03:02 --> Helper loaded: my_helper
INFO - 2023-09-29 19:03:02 --> Database Driver Class Initialized
INFO - 2023-09-29 19:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-29 19:03:02 --> Controller Class Initialized
DEBUG - 2023-09-29 19:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-29 19:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-29 19:03:03 --> Final output sent to browser
DEBUG - 2023-09-29 19:03:03 --> Total execution time: 0.0903
