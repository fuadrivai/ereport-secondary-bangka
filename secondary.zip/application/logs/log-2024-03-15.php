<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-15 08:39:01 --> Config Class Initialized
INFO - 2024-03-15 08:39:01 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:39:01 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:39:01 --> Utf8 Class Initialized
INFO - 2024-03-15 08:39:01 --> URI Class Initialized
INFO - 2024-03-15 08:39:01 --> Router Class Initialized
INFO - 2024-03-15 08:39:01 --> Output Class Initialized
INFO - 2024-03-15 08:39:01 --> Security Class Initialized
DEBUG - 2024-03-15 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:39:01 --> Input Class Initialized
INFO - 2024-03-15 08:39:01 --> Language Class Initialized
INFO - 2024-03-15 08:39:01 --> Language Class Initialized
INFO - 2024-03-15 08:39:01 --> Config Class Initialized
INFO - 2024-03-15 08:39:01 --> Loader Class Initialized
INFO - 2024-03-15 08:39:01 --> Helper loaded: url_helper
INFO - 2024-03-15 08:39:01 --> Helper loaded: file_helper
INFO - 2024-03-15 08:39:01 --> Helper loaded: form_helper
INFO - 2024-03-15 08:39:01 --> Helper loaded: my_helper
INFO - 2024-03-15 08:39:01 --> Database Driver Class Initialized
INFO - 2024-03-15 08:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:39:01 --> Controller Class Initialized
DEBUG - 2024-03-15 08:39:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:39:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:39:01 --> Final output sent to browser
DEBUG - 2024-03-15 08:39:01 --> Total execution time: 0.0650
INFO - 2024-03-15 08:39:04 --> Config Class Initialized
INFO - 2024-03-15 08:39:04 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:39:04 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:39:04 --> Utf8 Class Initialized
INFO - 2024-03-15 08:39:04 --> URI Class Initialized
INFO - 2024-03-15 08:39:04 --> Router Class Initialized
INFO - 2024-03-15 08:39:04 --> Output Class Initialized
INFO - 2024-03-15 08:39:04 --> Security Class Initialized
DEBUG - 2024-03-15 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:39:04 --> Input Class Initialized
INFO - 2024-03-15 08:39:04 --> Language Class Initialized
INFO - 2024-03-15 08:39:04 --> Language Class Initialized
INFO - 2024-03-15 08:39:04 --> Config Class Initialized
INFO - 2024-03-15 08:39:04 --> Loader Class Initialized
INFO - 2024-03-15 08:39:04 --> Helper loaded: url_helper
INFO - 2024-03-15 08:39:04 --> Helper loaded: file_helper
INFO - 2024-03-15 08:39:04 --> Helper loaded: form_helper
INFO - 2024-03-15 08:39:04 --> Helper loaded: my_helper
INFO - 2024-03-15 08:39:04 --> Database Driver Class Initialized
INFO - 2024-03-15 08:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:39:04 --> Controller Class Initialized
INFO - 2024-03-15 08:39:04 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:39:04 --> Final output sent to browser
DEBUG - 2024-03-15 08:39:04 --> Total execution time: 0.0341
INFO - 2024-03-15 08:39:05 --> Config Class Initialized
INFO - 2024-03-15 08:39:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:39:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:39:05 --> Utf8 Class Initialized
INFO - 2024-03-15 08:39:05 --> URI Class Initialized
INFO - 2024-03-15 08:39:05 --> Router Class Initialized
INFO - 2024-03-15 08:39:05 --> Output Class Initialized
INFO - 2024-03-15 08:39:05 --> Security Class Initialized
DEBUG - 2024-03-15 08:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:39:05 --> Input Class Initialized
INFO - 2024-03-15 08:39:05 --> Language Class Initialized
INFO - 2024-03-15 08:39:05 --> Language Class Initialized
INFO - 2024-03-15 08:39:05 --> Config Class Initialized
INFO - 2024-03-15 08:39:05 --> Loader Class Initialized
INFO - 2024-03-15 08:39:05 --> Helper loaded: url_helper
INFO - 2024-03-15 08:39:05 --> Helper loaded: file_helper
INFO - 2024-03-15 08:39:05 --> Helper loaded: form_helper
INFO - 2024-03-15 08:39:05 --> Helper loaded: my_helper
INFO - 2024-03-15 08:39:05 --> Database Driver Class Initialized
INFO - 2024-03-15 08:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:39:05 --> Controller Class Initialized
DEBUG - 2024-03-15 08:39:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:39:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:39:05 --> Final output sent to browser
DEBUG - 2024-03-15 08:39:05 --> Total execution time: 0.0734
INFO - 2024-03-15 08:39:10 --> Config Class Initialized
INFO - 2024-03-15 08:39:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:39:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:39:10 --> Utf8 Class Initialized
INFO - 2024-03-15 08:39:10 --> URI Class Initialized
INFO - 2024-03-15 08:39:10 --> Router Class Initialized
INFO - 2024-03-15 08:39:10 --> Output Class Initialized
INFO - 2024-03-15 08:39:10 --> Security Class Initialized
DEBUG - 2024-03-15 08:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:39:10 --> Input Class Initialized
INFO - 2024-03-15 08:39:10 --> Language Class Initialized
INFO - 2024-03-15 08:39:10 --> Language Class Initialized
INFO - 2024-03-15 08:39:10 --> Config Class Initialized
INFO - 2024-03-15 08:39:10 --> Loader Class Initialized
INFO - 2024-03-15 08:39:10 --> Helper loaded: url_helper
INFO - 2024-03-15 08:39:10 --> Helper loaded: file_helper
INFO - 2024-03-15 08:39:10 --> Helper loaded: form_helper
INFO - 2024-03-15 08:39:10 --> Helper loaded: my_helper
INFO - 2024-03-15 08:39:10 --> Database Driver Class Initialized
INFO - 2024-03-15 08:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:39:10 --> Controller Class Initialized
DEBUG - 2024-03-15 08:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 08:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:39:10 --> Final output sent to browser
DEBUG - 2024-03-15 08:39:10 --> Total execution time: 0.0388
INFO - 2024-03-15 08:39:12 --> Config Class Initialized
INFO - 2024-03-15 08:39:12 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:39:12 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:39:12 --> Utf8 Class Initialized
INFO - 2024-03-15 08:39:12 --> URI Class Initialized
INFO - 2024-03-15 08:39:12 --> Router Class Initialized
INFO - 2024-03-15 08:39:12 --> Output Class Initialized
INFO - 2024-03-15 08:39:12 --> Security Class Initialized
DEBUG - 2024-03-15 08:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:39:12 --> Input Class Initialized
INFO - 2024-03-15 08:39:12 --> Language Class Initialized
INFO - 2024-03-15 08:39:12 --> Language Class Initialized
INFO - 2024-03-15 08:39:12 --> Config Class Initialized
INFO - 2024-03-15 08:39:12 --> Loader Class Initialized
INFO - 2024-03-15 08:39:12 --> Helper loaded: url_helper
INFO - 2024-03-15 08:39:12 --> Helper loaded: file_helper
INFO - 2024-03-15 08:39:12 --> Helper loaded: form_helper
INFO - 2024-03-15 08:39:12 --> Helper loaded: my_helper
INFO - 2024-03-15 08:39:13 --> Database Driver Class Initialized
INFO - 2024-03-15 08:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:39:13 --> Controller Class Initialized
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:39:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 08:39:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 08:39:16 --> Final output sent to browser
DEBUG - 2024-03-15 08:39:16 --> Total execution time: 3.3619
INFO - 2024-03-15 08:45:11 --> Config Class Initialized
INFO - 2024-03-15 08:45:11 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:45:11 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:45:11 --> Utf8 Class Initialized
INFO - 2024-03-15 08:45:11 --> URI Class Initialized
INFO - 2024-03-15 08:45:11 --> Router Class Initialized
INFO - 2024-03-15 08:45:11 --> Output Class Initialized
INFO - 2024-03-15 08:45:11 --> Security Class Initialized
DEBUG - 2024-03-15 08:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:45:11 --> Input Class Initialized
INFO - 2024-03-15 08:45:11 --> Language Class Initialized
INFO - 2024-03-15 08:45:11 --> Language Class Initialized
INFO - 2024-03-15 08:45:11 --> Config Class Initialized
INFO - 2024-03-15 08:45:11 --> Loader Class Initialized
INFO - 2024-03-15 08:45:11 --> Helper loaded: url_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: file_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: form_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: my_helper
INFO - 2024-03-15 08:45:11 --> Database Driver Class Initialized
INFO - 2024-03-15 08:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:45:11 --> Controller Class Initialized
INFO - 2024-03-15 08:45:11 --> Config Class Initialized
INFO - 2024-03-15 08:45:11 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:45:11 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:45:11 --> Utf8 Class Initialized
INFO - 2024-03-15 08:45:11 --> URI Class Initialized
INFO - 2024-03-15 08:45:11 --> Router Class Initialized
INFO - 2024-03-15 08:45:11 --> Output Class Initialized
INFO - 2024-03-15 08:45:11 --> Security Class Initialized
DEBUG - 2024-03-15 08:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:45:11 --> Input Class Initialized
INFO - 2024-03-15 08:45:11 --> Language Class Initialized
INFO - 2024-03-15 08:45:11 --> Language Class Initialized
INFO - 2024-03-15 08:45:11 --> Config Class Initialized
INFO - 2024-03-15 08:45:11 --> Loader Class Initialized
INFO - 2024-03-15 08:45:11 --> Helper loaded: url_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: file_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: form_helper
INFO - 2024-03-15 08:45:11 --> Helper loaded: my_helper
INFO - 2024-03-15 08:45:11 --> Database Driver Class Initialized
INFO - 2024-03-15 08:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:45:11 --> Controller Class Initialized
DEBUG - 2024-03-15 08:45:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:45:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:45:11 --> Final output sent to browser
DEBUG - 2024-03-15 08:45:11 --> Total execution time: 0.0350
INFO - 2024-03-15 08:45:14 --> Config Class Initialized
INFO - 2024-03-15 08:45:14 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:45:14 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:45:14 --> Utf8 Class Initialized
INFO - 2024-03-15 08:45:14 --> URI Class Initialized
INFO - 2024-03-15 08:45:14 --> Router Class Initialized
INFO - 2024-03-15 08:45:14 --> Output Class Initialized
INFO - 2024-03-15 08:45:14 --> Security Class Initialized
DEBUG - 2024-03-15 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:45:14 --> Input Class Initialized
INFO - 2024-03-15 08:45:14 --> Language Class Initialized
INFO - 2024-03-15 08:45:14 --> Language Class Initialized
INFO - 2024-03-15 08:45:14 --> Config Class Initialized
INFO - 2024-03-15 08:45:14 --> Loader Class Initialized
INFO - 2024-03-15 08:45:14 --> Helper loaded: url_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: file_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: form_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: my_helper
INFO - 2024-03-15 08:45:14 --> Database Driver Class Initialized
INFO - 2024-03-15 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:45:14 --> Controller Class Initialized
INFO - 2024-03-15 08:45:14 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:45:14 --> Final output sent to browser
DEBUG - 2024-03-15 08:45:14 --> Total execution time: 0.0349
INFO - 2024-03-15 08:45:14 --> Config Class Initialized
INFO - 2024-03-15 08:45:14 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:45:14 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:45:14 --> Utf8 Class Initialized
INFO - 2024-03-15 08:45:14 --> URI Class Initialized
INFO - 2024-03-15 08:45:14 --> Router Class Initialized
INFO - 2024-03-15 08:45:14 --> Output Class Initialized
INFO - 2024-03-15 08:45:14 --> Security Class Initialized
DEBUG - 2024-03-15 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:45:14 --> Input Class Initialized
INFO - 2024-03-15 08:45:14 --> Language Class Initialized
INFO - 2024-03-15 08:45:14 --> Language Class Initialized
INFO - 2024-03-15 08:45:14 --> Config Class Initialized
INFO - 2024-03-15 08:45:14 --> Loader Class Initialized
INFO - 2024-03-15 08:45:14 --> Helper loaded: url_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: file_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: form_helper
INFO - 2024-03-15 08:45:14 --> Helper loaded: my_helper
INFO - 2024-03-15 08:45:14 --> Database Driver Class Initialized
INFO - 2024-03-15 08:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:45:14 --> Controller Class Initialized
DEBUG - 2024-03-15 08:45:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:45:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:45:14 --> Final output sent to browser
DEBUG - 2024-03-15 08:45:14 --> Total execution time: 0.0547
INFO - 2024-03-15 08:45:55 --> Config Class Initialized
INFO - 2024-03-15 08:45:55 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:45:55 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:45:55 --> Utf8 Class Initialized
INFO - 2024-03-15 08:45:55 --> URI Class Initialized
INFO - 2024-03-15 08:45:55 --> Router Class Initialized
INFO - 2024-03-15 08:45:55 --> Output Class Initialized
INFO - 2024-03-15 08:45:55 --> Security Class Initialized
DEBUG - 2024-03-15 08:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:45:55 --> Input Class Initialized
INFO - 2024-03-15 08:45:55 --> Language Class Initialized
INFO - 2024-03-15 08:45:55 --> Language Class Initialized
INFO - 2024-03-15 08:45:55 --> Config Class Initialized
INFO - 2024-03-15 08:45:55 --> Loader Class Initialized
INFO - 2024-03-15 08:45:55 --> Helper loaded: url_helper
INFO - 2024-03-15 08:45:55 --> Helper loaded: file_helper
INFO - 2024-03-15 08:45:55 --> Helper loaded: form_helper
INFO - 2024-03-15 08:45:55 --> Helper loaded: my_helper
INFO - 2024-03-15 08:45:55 --> Database Driver Class Initialized
INFO - 2024-03-15 08:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:45:55 --> Controller Class Initialized
DEBUG - 2024-03-15 08:45:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:45:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:45:55 --> Final output sent to browser
DEBUG - 2024-03-15 08:45:55 --> Total execution time: 0.0294
INFO - 2024-03-15 08:46:18 --> Config Class Initialized
INFO - 2024-03-15 08:46:18 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:46:18 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:46:18 --> Utf8 Class Initialized
INFO - 2024-03-15 08:46:18 --> URI Class Initialized
INFO - 2024-03-15 08:46:18 --> Router Class Initialized
INFO - 2024-03-15 08:46:18 --> Output Class Initialized
INFO - 2024-03-15 08:46:18 --> Security Class Initialized
DEBUG - 2024-03-15 08:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:46:18 --> Input Class Initialized
INFO - 2024-03-15 08:46:18 --> Language Class Initialized
INFO - 2024-03-15 08:46:18 --> Language Class Initialized
INFO - 2024-03-15 08:46:18 --> Config Class Initialized
INFO - 2024-03-15 08:46:18 --> Loader Class Initialized
INFO - 2024-03-15 08:46:18 --> Helper loaded: url_helper
INFO - 2024-03-15 08:46:18 --> Helper loaded: file_helper
INFO - 2024-03-15 08:46:18 --> Helper loaded: form_helper
INFO - 2024-03-15 08:46:18 --> Helper loaded: my_helper
INFO - 2024-03-15 08:46:18 --> Database Driver Class Initialized
INFO - 2024-03-15 08:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:46:18 --> Controller Class Initialized
DEBUG - 2024-03-15 08:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:46:18 --> Final output sent to browser
DEBUG - 2024-03-15 08:46:18 --> Total execution time: 0.0359
INFO - 2024-03-15 08:46:25 --> Config Class Initialized
INFO - 2024-03-15 08:46:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:46:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:46:25 --> Utf8 Class Initialized
INFO - 2024-03-15 08:46:25 --> URI Class Initialized
INFO - 2024-03-15 08:46:25 --> Router Class Initialized
INFO - 2024-03-15 08:46:25 --> Output Class Initialized
INFO - 2024-03-15 08:46:25 --> Security Class Initialized
DEBUG - 2024-03-15 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:46:25 --> Input Class Initialized
INFO - 2024-03-15 08:46:25 --> Language Class Initialized
INFO - 2024-03-15 08:46:25 --> Language Class Initialized
INFO - 2024-03-15 08:46:25 --> Config Class Initialized
INFO - 2024-03-15 08:46:25 --> Loader Class Initialized
INFO - 2024-03-15 08:46:25 --> Helper loaded: url_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: file_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: form_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: my_helper
INFO - 2024-03-15 08:46:25 --> Database Driver Class Initialized
INFO - 2024-03-15 08:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:46:25 --> Controller Class Initialized
DEBUG - 2024-03-15 08:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 08:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:46:25 --> Final output sent to browser
DEBUG - 2024-03-15 08:46:25 --> Total execution time: 0.0377
INFO - 2024-03-15 08:46:25 --> Config Class Initialized
INFO - 2024-03-15 08:46:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:46:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:46:25 --> Utf8 Class Initialized
INFO - 2024-03-15 08:46:25 --> URI Class Initialized
INFO - 2024-03-15 08:46:25 --> Router Class Initialized
INFO - 2024-03-15 08:46:25 --> Output Class Initialized
INFO - 2024-03-15 08:46:25 --> Security Class Initialized
DEBUG - 2024-03-15 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:46:25 --> Input Class Initialized
INFO - 2024-03-15 08:46:25 --> Language Class Initialized
INFO - 2024-03-15 08:46:25 --> Language Class Initialized
INFO - 2024-03-15 08:46:25 --> Config Class Initialized
INFO - 2024-03-15 08:46:25 --> Loader Class Initialized
INFO - 2024-03-15 08:46:25 --> Helper loaded: url_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: file_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: form_helper
INFO - 2024-03-15 08:46:25 --> Helper loaded: my_helper
INFO - 2024-03-15 08:46:25 --> Database Driver Class Initialized
INFO - 2024-03-15 08:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:46:25 --> Controller Class Initialized
INFO - 2024-03-15 08:46:31 --> Config Class Initialized
INFO - 2024-03-15 08:46:31 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:46:31 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:46:31 --> Utf8 Class Initialized
INFO - 2024-03-15 08:46:31 --> URI Class Initialized
INFO - 2024-03-15 08:46:31 --> Router Class Initialized
INFO - 2024-03-15 08:46:31 --> Output Class Initialized
INFO - 2024-03-15 08:46:31 --> Security Class Initialized
DEBUG - 2024-03-15 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:46:31 --> Input Class Initialized
INFO - 2024-03-15 08:46:31 --> Language Class Initialized
INFO - 2024-03-15 08:46:31 --> Language Class Initialized
INFO - 2024-03-15 08:46:31 --> Config Class Initialized
INFO - 2024-03-15 08:46:31 --> Loader Class Initialized
INFO - 2024-03-15 08:46:31 --> Helper loaded: url_helper
INFO - 2024-03-15 08:46:31 --> Helper loaded: file_helper
INFO - 2024-03-15 08:46:31 --> Helper loaded: form_helper
INFO - 2024-03-15 08:46:31 --> Helper loaded: my_helper
INFO - 2024-03-15 08:46:31 --> Database Driver Class Initialized
INFO - 2024-03-15 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:46:31 --> Controller Class Initialized
INFO - 2024-03-15 08:46:31 --> Final output sent to browser
DEBUG - 2024-03-15 08:46:31 --> Total execution time: 0.0424
INFO - 2024-03-15 08:50:04 --> Config Class Initialized
INFO - 2024-03-15 08:50:04 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:50:04 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:50:04 --> Utf8 Class Initialized
INFO - 2024-03-15 08:50:04 --> URI Class Initialized
INFO - 2024-03-15 08:50:04 --> Router Class Initialized
INFO - 2024-03-15 08:50:04 --> Output Class Initialized
INFO - 2024-03-15 08:50:04 --> Security Class Initialized
DEBUG - 2024-03-15 08:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:50:04 --> Input Class Initialized
INFO - 2024-03-15 08:50:04 --> Language Class Initialized
INFO - 2024-03-15 08:50:04 --> Language Class Initialized
INFO - 2024-03-15 08:50:04 --> Config Class Initialized
INFO - 2024-03-15 08:50:04 --> Loader Class Initialized
INFO - 2024-03-15 08:50:04 --> Helper loaded: url_helper
INFO - 2024-03-15 08:50:04 --> Helper loaded: file_helper
INFO - 2024-03-15 08:50:04 --> Helper loaded: form_helper
INFO - 2024-03-15 08:50:04 --> Helper loaded: my_helper
INFO - 2024-03-15 08:50:04 --> Database Driver Class Initialized
INFO - 2024-03-15 08:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:50:04 --> Controller Class Initialized
INFO - 2024-03-15 08:50:04 --> Final output sent to browser
DEBUG - 2024-03-15 08:50:04 --> Total execution time: 0.1545
INFO - 2024-03-15 08:50:23 --> Config Class Initialized
INFO - 2024-03-15 08:50:23 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:50:23 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:50:23 --> Utf8 Class Initialized
INFO - 2024-03-15 08:50:23 --> URI Class Initialized
INFO - 2024-03-15 08:50:23 --> Router Class Initialized
INFO - 2024-03-15 08:50:23 --> Output Class Initialized
INFO - 2024-03-15 08:50:23 --> Security Class Initialized
DEBUG - 2024-03-15 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:50:23 --> Input Class Initialized
INFO - 2024-03-15 08:50:23 --> Language Class Initialized
INFO - 2024-03-15 08:50:23 --> Language Class Initialized
INFO - 2024-03-15 08:50:23 --> Config Class Initialized
INFO - 2024-03-15 08:50:23 --> Loader Class Initialized
INFO - 2024-03-15 08:50:23 --> Helper loaded: url_helper
INFO - 2024-03-15 08:50:23 --> Helper loaded: file_helper
INFO - 2024-03-15 08:50:23 --> Helper loaded: form_helper
INFO - 2024-03-15 08:50:23 --> Helper loaded: my_helper
INFO - 2024-03-15 08:50:23 --> Database Driver Class Initialized
INFO - 2024-03-15 08:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:50:23 --> Controller Class Initialized
DEBUG - 2024-03-15 08:50:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 08:50:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:50:23 --> Final output sent to browser
DEBUG - 2024-03-15 08:50:23 --> Total execution time: 0.0373
INFO - 2024-03-15 08:50:35 --> Config Class Initialized
INFO - 2024-03-15 08:50:35 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:50:35 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:50:35 --> Utf8 Class Initialized
INFO - 2024-03-15 08:50:35 --> URI Class Initialized
INFO - 2024-03-15 08:50:35 --> Router Class Initialized
INFO - 2024-03-15 08:50:35 --> Output Class Initialized
INFO - 2024-03-15 08:50:35 --> Security Class Initialized
DEBUG - 2024-03-15 08:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:50:35 --> Input Class Initialized
INFO - 2024-03-15 08:50:35 --> Language Class Initialized
INFO - 2024-03-15 08:50:35 --> Language Class Initialized
INFO - 2024-03-15 08:50:35 --> Config Class Initialized
INFO - 2024-03-15 08:50:35 --> Loader Class Initialized
INFO - 2024-03-15 08:50:35 --> Helper loaded: url_helper
INFO - 2024-03-15 08:50:35 --> Helper loaded: file_helper
INFO - 2024-03-15 08:50:35 --> Helper loaded: form_helper
INFO - 2024-03-15 08:50:35 --> Helper loaded: my_helper
INFO - 2024-03-15 08:50:35 --> Database Driver Class Initialized
INFO - 2024-03-15 08:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:50:35 --> Controller Class Initialized
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:50:35 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:50:35 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:50:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 08:50:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 08:50:38 --> Final output sent to browser
DEBUG - 2024-03-15 08:50:38 --> Total execution time: 3.1328
INFO - 2024-03-15 08:52:13 --> Config Class Initialized
INFO - 2024-03-15 08:52:13 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:13 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:13 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:13 --> URI Class Initialized
INFO - 2024-03-15 08:52:13 --> Router Class Initialized
INFO - 2024-03-15 08:52:13 --> Output Class Initialized
INFO - 2024-03-15 08:52:13 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:13 --> Input Class Initialized
INFO - 2024-03-15 08:52:13 --> Language Class Initialized
INFO - 2024-03-15 08:52:13 --> Language Class Initialized
INFO - 2024-03-15 08:52:13 --> Config Class Initialized
INFO - 2024-03-15 08:52:13 --> Loader Class Initialized
INFO - 2024-03-15 08:52:13 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:13 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:13 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:13 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:13 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:13 --> Controller Class Initialized
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 08:52:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 08:52:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 08:52:17 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:17 --> Total execution time: 3.1862
INFO - 2024-03-15 08:52:29 --> Config Class Initialized
INFO - 2024-03-15 08:52:29 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:29 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:29 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:29 --> URI Class Initialized
INFO - 2024-03-15 08:52:29 --> Router Class Initialized
INFO - 2024-03-15 08:52:29 --> Output Class Initialized
INFO - 2024-03-15 08:52:29 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:29 --> Input Class Initialized
INFO - 2024-03-15 08:52:29 --> Language Class Initialized
INFO - 2024-03-15 08:52:29 --> Language Class Initialized
INFO - 2024-03-15 08:52:29 --> Config Class Initialized
INFO - 2024-03-15 08:52:29 --> Loader Class Initialized
INFO - 2024-03-15 08:52:29 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:29 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:29 --> Controller Class Initialized
INFO - 2024-03-15 08:52:29 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:52:29 --> Config Class Initialized
INFO - 2024-03-15 08:52:29 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:29 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:29 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:29 --> URI Class Initialized
INFO - 2024-03-15 08:52:29 --> Router Class Initialized
INFO - 2024-03-15 08:52:29 --> Output Class Initialized
INFO - 2024-03-15 08:52:29 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:29 --> Input Class Initialized
INFO - 2024-03-15 08:52:29 --> Language Class Initialized
INFO - 2024-03-15 08:52:29 --> Language Class Initialized
INFO - 2024-03-15 08:52:29 --> Config Class Initialized
INFO - 2024-03-15 08:52:29 --> Loader Class Initialized
INFO - 2024-03-15 08:52:29 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:29 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:29 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:29 --> Controller Class Initialized
INFO - 2024-03-15 08:52:30 --> Config Class Initialized
INFO - 2024-03-15 08:52:30 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:30 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:30 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:30 --> URI Class Initialized
INFO - 2024-03-15 08:52:30 --> Router Class Initialized
INFO - 2024-03-15 08:52:30 --> Output Class Initialized
INFO - 2024-03-15 08:52:30 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:30 --> Input Class Initialized
INFO - 2024-03-15 08:52:30 --> Language Class Initialized
INFO - 2024-03-15 08:52:30 --> Language Class Initialized
INFO - 2024-03-15 08:52:30 --> Config Class Initialized
INFO - 2024-03-15 08:52:30 --> Loader Class Initialized
INFO - 2024-03-15 08:52:30 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:30 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:30 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:30 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:30 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:30 --> Controller Class Initialized
DEBUG - 2024-03-15 08:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:52:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:52:30 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:30 --> Total execution time: 0.0372
INFO - 2024-03-15 08:52:34 --> Config Class Initialized
INFO - 2024-03-15 08:52:34 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:34 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:34 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:34 --> URI Class Initialized
INFO - 2024-03-15 08:52:34 --> Router Class Initialized
INFO - 2024-03-15 08:52:34 --> Output Class Initialized
INFO - 2024-03-15 08:52:34 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:34 --> Input Class Initialized
INFO - 2024-03-15 08:52:34 --> Language Class Initialized
INFO - 2024-03-15 08:52:34 --> Language Class Initialized
INFO - 2024-03-15 08:52:34 --> Config Class Initialized
INFO - 2024-03-15 08:52:34 --> Loader Class Initialized
INFO - 2024-03-15 08:52:34 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:34 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:34 --> Controller Class Initialized
INFO - 2024-03-15 08:52:34 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:52:34 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:34 --> Total execution time: 0.0406
INFO - 2024-03-15 08:52:34 --> Config Class Initialized
INFO - 2024-03-15 08:52:34 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:34 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:34 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:34 --> URI Class Initialized
INFO - 2024-03-15 08:52:34 --> Router Class Initialized
INFO - 2024-03-15 08:52:34 --> Output Class Initialized
INFO - 2024-03-15 08:52:34 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:34 --> Input Class Initialized
INFO - 2024-03-15 08:52:34 --> Language Class Initialized
INFO - 2024-03-15 08:52:34 --> Language Class Initialized
INFO - 2024-03-15 08:52:34 --> Config Class Initialized
INFO - 2024-03-15 08:52:34 --> Loader Class Initialized
INFO - 2024-03-15 08:52:34 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:34 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:34 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:34 --> Controller Class Initialized
DEBUG - 2024-03-15 08:52:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:52:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:52:34 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:34 --> Total execution time: 0.0383
INFO - 2024-03-15 08:52:36 --> Config Class Initialized
INFO - 2024-03-15 08:52:36 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:36 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:36 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:36 --> URI Class Initialized
INFO - 2024-03-15 08:52:36 --> Router Class Initialized
INFO - 2024-03-15 08:52:36 --> Output Class Initialized
INFO - 2024-03-15 08:52:36 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:36 --> Input Class Initialized
INFO - 2024-03-15 08:52:36 --> Language Class Initialized
INFO - 2024-03-15 08:52:36 --> Language Class Initialized
INFO - 2024-03-15 08:52:36 --> Config Class Initialized
INFO - 2024-03-15 08:52:36 --> Loader Class Initialized
INFO - 2024-03-15 08:52:36 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:36 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:36 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:36 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:36 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:36 --> Controller Class Initialized
DEBUG - 2024-03-15 08:52:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:52:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:52:36 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:36 --> Total execution time: 0.0309
INFO - 2024-03-15 08:52:37 --> Config Class Initialized
INFO - 2024-03-15 08:52:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:37 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:37 --> URI Class Initialized
INFO - 2024-03-15 08:52:37 --> Router Class Initialized
INFO - 2024-03-15 08:52:37 --> Output Class Initialized
INFO - 2024-03-15 08:52:37 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:37 --> Input Class Initialized
INFO - 2024-03-15 08:52:37 --> Language Class Initialized
INFO - 2024-03-15 08:52:37 --> Language Class Initialized
INFO - 2024-03-15 08:52:37 --> Config Class Initialized
INFO - 2024-03-15 08:52:37 --> Loader Class Initialized
INFO - 2024-03-15 08:52:37 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:37 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:37 --> Controller Class Initialized
DEBUG - 2024-03-15 08:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 08:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:52:37 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:37 --> Total execution time: 0.0357
INFO - 2024-03-15 08:52:37 --> Config Class Initialized
INFO - 2024-03-15 08:52:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:37 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:37 --> URI Class Initialized
INFO - 2024-03-15 08:52:37 --> Router Class Initialized
INFO - 2024-03-15 08:52:37 --> Output Class Initialized
INFO - 2024-03-15 08:52:37 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:37 --> Input Class Initialized
INFO - 2024-03-15 08:52:37 --> Language Class Initialized
INFO - 2024-03-15 08:52:37 --> Language Class Initialized
INFO - 2024-03-15 08:52:37 --> Config Class Initialized
INFO - 2024-03-15 08:52:37 --> Loader Class Initialized
INFO - 2024-03-15 08:52:37 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:37 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:37 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:37 --> Controller Class Initialized
INFO - 2024-03-15 08:52:41 --> Config Class Initialized
INFO - 2024-03-15 08:52:41 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:52:41 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:52:41 --> Utf8 Class Initialized
INFO - 2024-03-15 08:52:41 --> URI Class Initialized
INFO - 2024-03-15 08:52:41 --> Router Class Initialized
INFO - 2024-03-15 08:52:41 --> Output Class Initialized
INFO - 2024-03-15 08:52:41 --> Security Class Initialized
DEBUG - 2024-03-15 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:52:41 --> Input Class Initialized
INFO - 2024-03-15 08:52:41 --> Language Class Initialized
INFO - 2024-03-15 08:52:41 --> Language Class Initialized
INFO - 2024-03-15 08:52:41 --> Config Class Initialized
INFO - 2024-03-15 08:52:41 --> Loader Class Initialized
INFO - 2024-03-15 08:52:41 --> Helper loaded: url_helper
INFO - 2024-03-15 08:52:41 --> Helper loaded: file_helper
INFO - 2024-03-15 08:52:41 --> Helper loaded: form_helper
INFO - 2024-03-15 08:52:41 --> Helper loaded: my_helper
INFO - 2024-03-15 08:52:41 --> Database Driver Class Initialized
INFO - 2024-03-15 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:52:41 --> Controller Class Initialized
DEBUG - 2024-03-15 08:52:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-15 08:52:41 --> Final output sent to browser
DEBUG - 2024-03-15 08:52:41 --> Total execution time: 0.0735
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:37 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:37 --> URI Class Initialized
INFO - 2024-03-15 08:53:37 --> Router Class Initialized
INFO - 2024-03-15 08:53:37 --> Output Class Initialized
INFO - 2024-03-15 08:53:37 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:37 --> Input Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Loader Class Initialized
INFO - 2024-03-15 08:53:37 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:37 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:37 --> Controller Class Initialized
INFO - 2024-03-15 08:53:37 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:37 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:37 --> URI Class Initialized
INFO - 2024-03-15 08:53:37 --> Router Class Initialized
INFO - 2024-03-15 08:53:37 --> Output Class Initialized
INFO - 2024-03-15 08:53:37 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:37 --> Input Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Loader Class Initialized
INFO - 2024-03-15 08:53:37 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:37 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:37 --> Controller Class Initialized
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:37 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:37 --> URI Class Initialized
INFO - 2024-03-15 08:53:37 --> Router Class Initialized
INFO - 2024-03-15 08:53:37 --> Output Class Initialized
INFO - 2024-03-15 08:53:37 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:37 --> Input Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Language Class Initialized
INFO - 2024-03-15 08:53:37 --> Config Class Initialized
INFO - 2024-03-15 08:53:37 --> Loader Class Initialized
INFO - 2024-03-15 08:53:37 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:37 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:37 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:37 --> Controller Class Initialized
DEBUG - 2024-03-15 08:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:53:37 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:37 --> Total execution time: 0.0371
INFO - 2024-03-15 08:53:42 --> Config Class Initialized
INFO - 2024-03-15 08:53:42 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:42 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:42 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:42 --> URI Class Initialized
INFO - 2024-03-15 08:53:42 --> Router Class Initialized
INFO - 2024-03-15 08:53:42 --> Output Class Initialized
INFO - 2024-03-15 08:53:42 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:42 --> Input Class Initialized
INFO - 2024-03-15 08:53:42 --> Language Class Initialized
INFO - 2024-03-15 08:53:42 --> Language Class Initialized
INFO - 2024-03-15 08:53:42 --> Config Class Initialized
INFO - 2024-03-15 08:53:42 --> Loader Class Initialized
INFO - 2024-03-15 08:53:42 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:42 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:42 --> Controller Class Initialized
INFO - 2024-03-15 08:53:42 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:53:42 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:42 --> Total execution time: 0.0418
INFO - 2024-03-15 08:53:42 --> Config Class Initialized
INFO - 2024-03-15 08:53:42 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:42 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:42 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:42 --> URI Class Initialized
INFO - 2024-03-15 08:53:42 --> Router Class Initialized
INFO - 2024-03-15 08:53:42 --> Output Class Initialized
INFO - 2024-03-15 08:53:42 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:42 --> Input Class Initialized
INFO - 2024-03-15 08:53:42 --> Language Class Initialized
INFO - 2024-03-15 08:53:42 --> Language Class Initialized
INFO - 2024-03-15 08:53:42 --> Config Class Initialized
INFO - 2024-03-15 08:53:42 --> Loader Class Initialized
INFO - 2024-03-15 08:53:42 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:42 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:42 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:42 --> Controller Class Initialized
DEBUG - 2024-03-15 08:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:53:42 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:42 --> Total execution time: 0.0288
INFO - 2024-03-15 08:53:48 --> Config Class Initialized
INFO - 2024-03-15 08:53:48 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:48 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:48 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:48 --> URI Class Initialized
INFO - 2024-03-15 08:53:48 --> Router Class Initialized
INFO - 2024-03-15 08:53:48 --> Output Class Initialized
INFO - 2024-03-15 08:53:48 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:48 --> Input Class Initialized
INFO - 2024-03-15 08:53:48 --> Language Class Initialized
INFO - 2024-03-15 08:53:48 --> Language Class Initialized
INFO - 2024-03-15 08:53:48 --> Config Class Initialized
INFO - 2024-03-15 08:53:48 --> Loader Class Initialized
INFO - 2024-03-15 08:53:48 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:48 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:48 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:48 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:48 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:48 --> Controller Class Initialized
DEBUG - 2024-03-15 08:53:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:53:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:53:48 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:48 --> Total execution time: 0.0283
INFO - 2024-03-15 08:53:50 --> Config Class Initialized
INFO - 2024-03-15 08:53:50 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:50 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:50 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:50 --> URI Class Initialized
INFO - 2024-03-15 08:53:50 --> Router Class Initialized
INFO - 2024-03-15 08:53:50 --> Output Class Initialized
INFO - 2024-03-15 08:53:50 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:50 --> Input Class Initialized
INFO - 2024-03-15 08:53:50 --> Language Class Initialized
INFO - 2024-03-15 08:53:50 --> Language Class Initialized
INFO - 2024-03-15 08:53:50 --> Config Class Initialized
INFO - 2024-03-15 08:53:50 --> Loader Class Initialized
INFO - 2024-03-15 08:53:50 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:50 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:50 --> Controller Class Initialized
DEBUG - 2024-03-15 08:53:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 08:53:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:53:50 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:50 --> Total execution time: 0.0319
INFO - 2024-03-15 08:53:50 --> Config Class Initialized
INFO - 2024-03-15 08:53:50 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:50 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:50 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:50 --> URI Class Initialized
INFO - 2024-03-15 08:53:50 --> Router Class Initialized
INFO - 2024-03-15 08:53:50 --> Output Class Initialized
INFO - 2024-03-15 08:53:50 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:50 --> Input Class Initialized
INFO - 2024-03-15 08:53:50 --> Language Class Initialized
INFO - 2024-03-15 08:53:50 --> Language Class Initialized
INFO - 2024-03-15 08:53:50 --> Config Class Initialized
INFO - 2024-03-15 08:53:50 --> Loader Class Initialized
INFO - 2024-03-15 08:53:50 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:50 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:50 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:50 --> Controller Class Initialized
INFO - 2024-03-15 08:53:58 --> Config Class Initialized
INFO - 2024-03-15 08:53:58 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:53:58 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:53:58 --> Utf8 Class Initialized
INFO - 2024-03-15 08:53:58 --> URI Class Initialized
INFO - 2024-03-15 08:53:58 --> Router Class Initialized
INFO - 2024-03-15 08:53:58 --> Output Class Initialized
INFO - 2024-03-15 08:53:58 --> Security Class Initialized
DEBUG - 2024-03-15 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:53:58 --> Input Class Initialized
INFO - 2024-03-15 08:53:58 --> Language Class Initialized
INFO - 2024-03-15 08:53:58 --> Language Class Initialized
INFO - 2024-03-15 08:53:58 --> Config Class Initialized
INFO - 2024-03-15 08:53:58 --> Loader Class Initialized
INFO - 2024-03-15 08:53:58 --> Helper loaded: url_helper
INFO - 2024-03-15 08:53:58 --> Helper loaded: file_helper
INFO - 2024-03-15 08:53:58 --> Helper loaded: form_helper
INFO - 2024-03-15 08:53:58 --> Helper loaded: my_helper
INFO - 2024-03-15 08:53:58 --> Database Driver Class Initialized
INFO - 2024-03-15 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:53:58 --> Controller Class Initialized
INFO - 2024-03-15 08:53:58 --> Final output sent to browser
DEBUG - 2024-03-15 08:53:58 --> Total execution time: 0.0397
INFO - 2024-03-15 08:55:06 --> Config Class Initialized
INFO - 2024-03-15 08:55:06 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:06 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:06 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:06 --> URI Class Initialized
DEBUG - 2024-03-15 08:55:06 --> No URI present. Default controller set.
INFO - 2024-03-15 08:55:06 --> Router Class Initialized
INFO - 2024-03-15 08:55:06 --> Output Class Initialized
INFO - 2024-03-15 08:55:06 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:06 --> Input Class Initialized
INFO - 2024-03-15 08:55:06 --> Language Class Initialized
INFO - 2024-03-15 08:55:06 --> Language Class Initialized
INFO - 2024-03-15 08:55:06 --> Config Class Initialized
INFO - 2024-03-15 08:55:06 --> Loader Class Initialized
INFO - 2024-03-15 08:55:06 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:06 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:06 --> Controller Class Initialized
INFO - 2024-03-15 08:55:06 --> Config Class Initialized
INFO - 2024-03-15 08:55:06 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:06 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:06 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:06 --> URI Class Initialized
INFO - 2024-03-15 08:55:06 --> Router Class Initialized
INFO - 2024-03-15 08:55:06 --> Output Class Initialized
INFO - 2024-03-15 08:55:06 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:06 --> Input Class Initialized
INFO - 2024-03-15 08:55:06 --> Language Class Initialized
INFO - 2024-03-15 08:55:06 --> Language Class Initialized
INFO - 2024-03-15 08:55:06 --> Config Class Initialized
INFO - 2024-03-15 08:55:06 --> Loader Class Initialized
INFO - 2024-03-15 08:55:06 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:06 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:07 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:07 --> Controller Class Initialized
DEBUG - 2024-03-15 08:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:55:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:55:07 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:07 --> Total execution time: 0.0312
INFO - 2024-03-15 08:55:12 --> Config Class Initialized
INFO - 2024-03-15 08:55:12 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:12 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:12 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:12 --> URI Class Initialized
INFO - 2024-03-15 08:55:12 --> Router Class Initialized
INFO - 2024-03-15 08:55:12 --> Output Class Initialized
INFO - 2024-03-15 08:55:12 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:12 --> Input Class Initialized
INFO - 2024-03-15 08:55:12 --> Language Class Initialized
INFO - 2024-03-15 08:55:12 --> Language Class Initialized
INFO - 2024-03-15 08:55:12 --> Config Class Initialized
INFO - 2024-03-15 08:55:12 --> Loader Class Initialized
INFO - 2024-03-15 08:55:12 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:12 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:12 --> Controller Class Initialized
INFO - 2024-03-15 08:55:12 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:55:12 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:12 --> Total execution time: 0.0359
INFO - 2024-03-15 08:55:12 --> Config Class Initialized
INFO - 2024-03-15 08:55:12 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:12 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:12 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:12 --> URI Class Initialized
INFO - 2024-03-15 08:55:12 --> Router Class Initialized
INFO - 2024-03-15 08:55:12 --> Output Class Initialized
INFO - 2024-03-15 08:55:12 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:12 --> Input Class Initialized
INFO - 2024-03-15 08:55:12 --> Language Class Initialized
INFO - 2024-03-15 08:55:12 --> Language Class Initialized
INFO - 2024-03-15 08:55:12 --> Config Class Initialized
INFO - 2024-03-15 08:55:12 --> Loader Class Initialized
INFO - 2024-03-15 08:55:12 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:12 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:12 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:12 --> Controller Class Initialized
DEBUG - 2024-03-15 08:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:55:12 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:12 --> Total execution time: 0.0351
INFO - 2024-03-15 08:55:14 --> Config Class Initialized
INFO - 2024-03-15 08:55:14 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:14 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:14 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:14 --> URI Class Initialized
INFO - 2024-03-15 08:55:14 --> Router Class Initialized
INFO - 2024-03-15 08:55:14 --> Output Class Initialized
INFO - 2024-03-15 08:55:14 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:14 --> Input Class Initialized
INFO - 2024-03-15 08:55:14 --> Language Class Initialized
INFO - 2024-03-15 08:55:14 --> Language Class Initialized
INFO - 2024-03-15 08:55:14 --> Config Class Initialized
INFO - 2024-03-15 08:55:14 --> Loader Class Initialized
INFO - 2024-03-15 08:55:14 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:14 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:14 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:14 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:14 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:14 --> Controller Class Initialized
DEBUG - 2024-03-15 08:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:55:14 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:14 --> Total execution time: 0.0302
INFO - 2024-03-15 08:55:17 --> Config Class Initialized
INFO - 2024-03-15 08:55:17 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:17 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:17 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:17 --> URI Class Initialized
INFO - 2024-03-15 08:55:17 --> Router Class Initialized
INFO - 2024-03-15 08:55:17 --> Output Class Initialized
INFO - 2024-03-15 08:55:17 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:17 --> Input Class Initialized
INFO - 2024-03-15 08:55:17 --> Language Class Initialized
INFO - 2024-03-15 08:55:17 --> Language Class Initialized
INFO - 2024-03-15 08:55:17 --> Config Class Initialized
INFO - 2024-03-15 08:55:17 --> Loader Class Initialized
INFO - 2024-03-15 08:55:17 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:17 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:17 --> Controller Class Initialized
DEBUG - 2024-03-15 08:55:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 08:55:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:55:17 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:17 --> Total execution time: 0.0309
INFO - 2024-03-15 08:55:17 --> Config Class Initialized
INFO - 2024-03-15 08:55:17 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:17 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:17 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:17 --> URI Class Initialized
INFO - 2024-03-15 08:55:17 --> Router Class Initialized
INFO - 2024-03-15 08:55:17 --> Output Class Initialized
INFO - 2024-03-15 08:55:17 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:17 --> Input Class Initialized
INFO - 2024-03-15 08:55:17 --> Language Class Initialized
INFO - 2024-03-15 08:55:17 --> Language Class Initialized
INFO - 2024-03-15 08:55:17 --> Config Class Initialized
INFO - 2024-03-15 08:55:17 --> Loader Class Initialized
INFO - 2024-03-15 08:55:17 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:17 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:17 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:17 --> Controller Class Initialized
INFO - 2024-03-15 08:55:19 --> Config Class Initialized
INFO - 2024-03-15 08:55:19 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:55:19 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:55:19 --> Utf8 Class Initialized
INFO - 2024-03-15 08:55:19 --> URI Class Initialized
INFO - 2024-03-15 08:55:19 --> Router Class Initialized
INFO - 2024-03-15 08:55:19 --> Output Class Initialized
INFO - 2024-03-15 08:55:19 --> Security Class Initialized
DEBUG - 2024-03-15 08:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:55:19 --> Input Class Initialized
INFO - 2024-03-15 08:55:19 --> Language Class Initialized
INFO - 2024-03-15 08:55:19 --> Language Class Initialized
INFO - 2024-03-15 08:55:19 --> Config Class Initialized
INFO - 2024-03-15 08:55:19 --> Loader Class Initialized
INFO - 2024-03-15 08:55:19 --> Helper loaded: url_helper
INFO - 2024-03-15 08:55:19 --> Helper loaded: file_helper
INFO - 2024-03-15 08:55:19 --> Helper loaded: form_helper
INFO - 2024-03-15 08:55:19 --> Helper loaded: my_helper
INFO - 2024-03-15 08:55:19 --> Database Driver Class Initialized
INFO - 2024-03-15 08:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:55:19 --> Controller Class Initialized
DEBUG - 2024-03-15 08:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-15 08:55:19 --> Final output sent to browser
DEBUG - 2024-03-15 08:55:19 --> Total execution time: 0.0787
INFO - 2024-03-15 08:57:40 --> Config Class Initialized
INFO - 2024-03-15 08:57:40 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:40 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:40 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:40 --> URI Class Initialized
INFO - 2024-03-15 08:57:40 --> Router Class Initialized
INFO - 2024-03-15 08:57:40 --> Output Class Initialized
INFO - 2024-03-15 08:57:40 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:40 --> Input Class Initialized
INFO - 2024-03-15 08:57:40 --> Language Class Initialized
INFO - 2024-03-15 08:57:40 --> Language Class Initialized
INFO - 2024-03-15 08:57:40 --> Config Class Initialized
INFO - 2024-03-15 08:57:40 --> Loader Class Initialized
INFO - 2024-03-15 08:57:41 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:41 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:41 --> Controller Class Initialized
INFO - 2024-03-15 08:57:41 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:57:41 --> Config Class Initialized
INFO - 2024-03-15 08:57:41 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:41 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:41 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:41 --> URI Class Initialized
INFO - 2024-03-15 08:57:41 --> Router Class Initialized
INFO - 2024-03-15 08:57:41 --> Output Class Initialized
INFO - 2024-03-15 08:57:41 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:41 --> Input Class Initialized
INFO - 2024-03-15 08:57:41 --> Language Class Initialized
INFO - 2024-03-15 08:57:41 --> Language Class Initialized
INFO - 2024-03-15 08:57:41 --> Config Class Initialized
INFO - 2024-03-15 08:57:41 --> Loader Class Initialized
INFO - 2024-03-15 08:57:41 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:41 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:41 --> Controller Class Initialized
INFO - 2024-03-15 08:57:41 --> Config Class Initialized
INFO - 2024-03-15 08:57:41 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:41 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:41 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:41 --> URI Class Initialized
INFO - 2024-03-15 08:57:41 --> Router Class Initialized
INFO - 2024-03-15 08:57:41 --> Output Class Initialized
INFO - 2024-03-15 08:57:41 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:41 --> Input Class Initialized
INFO - 2024-03-15 08:57:41 --> Language Class Initialized
INFO - 2024-03-15 08:57:41 --> Language Class Initialized
INFO - 2024-03-15 08:57:41 --> Config Class Initialized
INFO - 2024-03-15 08:57:41 --> Loader Class Initialized
INFO - 2024-03-15 08:57:41 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:41 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:41 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:41 --> Controller Class Initialized
DEBUG - 2024-03-15 08:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 08:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:57:41 --> Final output sent to browser
DEBUG - 2024-03-15 08:57:41 --> Total execution time: 0.0284
INFO - 2024-03-15 08:57:48 --> Config Class Initialized
INFO - 2024-03-15 08:57:48 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:48 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:48 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:48 --> URI Class Initialized
INFO - 2024-03-15 08:57:48 --> Router Class Initialized
INFO - 2024-03-15 08:57:48 --> Output Class Initialized
INFO - 2024-03-15 08:57:48 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:48 --> Input Class Initialized
INFO - 2024-03-15 08:57:48 --> Language Class Initialized
INFO - 2024-03-15 08:57:48 --> Language Class Initialized
INFO - 2024-03-15 08:57:48 --> Config Class Initialized
INFO - 2024-03-15 08:57:48 --> Loader Class Initialized
INFO - 2024-03-15 08:57:48 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:48 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:48 --> Controller Class Initialized
INFO - 2024-03-15 08:57:48 --> Helper loaded: cookie_helper
INFO - 2024-03-15 08:57:48 --> Final output sent to browser
DEBUG - 2024-03-15 08:57:48 --> Total execution time: 0.0324
INFO - 2024-03-15 08:57:48 --> Config Class Initialized
INFO - 2024-03-15 08:57:48 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:48 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:48 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:48 --> URI Class Initialized
INFO - 2024-03-15 08:57:48 --> Router Class Initialized
INFO - 2024-03-15 08:57:48 --> Output Class Initialized
INFO - 2024-03-15 08:57:48 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:48 --> Input Class Initialized
INFO - 2024-03-15 08:57:48 --> Language Class Initialized
INFO - 2024-03-15 08:57:48 --> Language Class Initialized
INFO - 2024-03-15 08:57:48 --> Config Class Initialized
INFO - 2024-03-15 08:57:48 --> Loader Class Initialized
INFO - 2024-03-15 08:57:48 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:48 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:48 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:48 --> Controller Class Initialized
DEBUG - 2024-03-15 08:57:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 08:57:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:57:48 --> Final output sent to browser
DEBUG - 2024-03-15 08:57:48 --> Total execution time: 0.0305
INFO - 2024-03-15 08:57:50 --> Config Class Initialized
INFO - 2024-03-15 08:57:50 --> Hooks Class Initialized
DEBUG - 2024-03-15 08:57:50 --> UTF-8 Support Enabled
INFO - 2024-03-15 08:57:50 --> Utf8 Class Initialized
INFO - 2024-03-15 08:57:50 --> URI Class Initialized
INFO - 2024-03-15 08:57:50 --> Router Class Initialized
INFO - 2024-03-15 08:57:50 --> Output Class Initialized
INFO - 2024-03-15 08:57:50 --> Security Class Initialized
DEBUG - 2024-03-15 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 08:57:50 --> Input Class Initialized
INFO - 2024-03-15 08:57:50 --> Language Class Initialized
INFO - 2024-03-15 08:57:50 --> Language Class Initialized
INFO - 2024-03-15 08:57:50 --> Config Class Initialized
INFO - 2024-03-15 08:57:50 --> Loader Class Initialized
INFO - 2024-03-15 08:57:50 --> Helper loaded: url_helper
INFO - 2024-03-15 08:57:50 --> Helper loaded: file_helper
INFO - 2024-03-15 08:57:50 --> Helper loaded: form_helper
INFO - 2024-03-15 08:57:50 --> Helper loaded: my_helper
INFO - 2024-03-15 08:57:50 --> Database Driver Class Initialized
INFO - 2024-03-15 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 08:57:50 --> Controller Class Initialized
DEBUG - 2024-03-15 08:57:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 08:57:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 08:57:50 --> Final output sent to browser
DEBUG - 2024-03-15 08:57:50 --> Total execution time: 0.0303
INFO - 2024-03-15 09:00:22 --> Config Class Initialized
INFO - 2024-03-15 09:00:22 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:00:22 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:00:22 --> Utf8 Class Initialized
INFO - 2024-03-15 09:00:22 --> URI Class Initialized
INFO - 2024-03-15 09:00:22 --> Router Class Initialized
INFO - 2024-03-15 09:00:22 --> Output Class Initialized
INFO - 2024-03-15 09:00:22 --> Security Class Initialized
DEBUG - 2024-03-15 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:00:22 --> Input Class Initialized
INFO - 2024-03-15 09:00:22 --> Language Class Initialized
INFO - 2024-03-15 09:00:22 --> Language Class Initialized
INFO - 2024-03-15 09:00:22 --> Config Class Initialized
INFO - 2024-03-15 09:00:22 --> Loader Class Initialized
INFO - 2024-03-15 09:00:22 --> Helper loaded: url_helper
INFO - 2024-03-15 09:00:22 --> Helper loaded: file_helper
INFO - 2024-03-15 09:00:22 --> Helper loaded: form_helper
INFO - 2024-03-15 09:00:22 --> Helper loaded: my_helper
INFO - 2024-03-15 09:00:22 --> Database Driver Class Initialized
INFO - 2024-03-15 09:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:00:22 --> Controller Class Initialized
DEBUG - 2024-03-15 09:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 09:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:00:22 --> Final output sent to browser
DEBUG - 2024-03-15 09:00:22 --> Total execution time: 0.0499
INFO - 2024-03-15 09:00:45 --> Config Class Initialized
INFO - 2024-03-15 09:00:45 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:00:45 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:00:45 --> Utf8 Class Initialized
INFO - 2024-03-15 09:00:45 --> URI Class Initialized
INFO - 2024-03-15 09:00:45 --> Router Class Initialized
INFO - 2024-03-15 09:00:45 --> Output Class Initialized
INFO - 2024-03-15 09:00:45 --> Security Class Initialized
DEBUG - 2024-03-15 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:00:45 --> Input Class Initialized
INFO - 2024-03-15 09:00:45 --> Language Class Initialized
INFO - 2024-03-15 09:00:45 --> Language Class Initialized
INFO - 2024-03-15 09:00:45 --> Config Class Initialized
INFO - 2024-03-15 09:00:45 --> Loader Class Initialized
INFO - 2024-03-15 09:00:45 --> Helper loaded: url_helper
INFO - 2024-03-15 09:00:45 --> Helper loaded: file_helper
INFO - 2024-03-15 09:00:45 --> Helper loaded: form_helper
INFO - 2024-03-15 09:00:45 --> Helper loaded: my_helper
INFO - 2024-03-15 09:00:45 --> Database Driver Class Initialized
INFO - 2024-03-15 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:00:45 --> Controller Class Initialized
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:00:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:00:49 --> Final output sent to browser
DEBUG - 2024-03-15 09:00:49 --> Total execution time: 3.8542
INFO - 2024-03-15 09:00:55 --> Config Class Initialized
INFO - 2024-03-15 09:00:55 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:00:55 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:00:55 --> Utf8 Class Initialized
INFO - 2024-03-15 09:00:55 --> URI Class Initialized
INFO - 2024-03-15 09:00:55 --> Router Class Initialized
INFO - 2024-03-15 09:00:55 --> Output Class Initialized
INFO - 2024-03-15 09:00:55 --> Security Class Initialized
DEBUG - 2024-03-15 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:00:55 --> Input Class Initialized
INFO - 2024-03-15 09:00:55 --> Language Class Initialized
INFO - 2024-03-15 09:00:55 --> Language Class Initialized
INFO - 2024-03-15 09:00:55 --> Config Class Initialized
INFO - 2024-03-15 09:00:55 --> Loader Class Initialized
INFO - 2024-03-15 09:00:55 --> Helper loaded: url_helper
INFO - 2024-03-15 09:00:55 --> Helper loaded: file_helper
INFO - 2024-03-15 09:00:55 --> Helper loaded: form_helper
INFO - 2024-03-15 09:00:55 --> Helper loaded: my_helper
INFO - 2024-03-15 09:00:55 --> Database Driver Class Initialized
INFO - 2024-03-15 09:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:00:55 --> Controller Class Initialized
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:55 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:55 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:00:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:00:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:01:03 --> Final output sent to browser
DEBUG - 2024-03-15 09:01:03 --> Total execution time: 7.4026
INFO - 2024-03-15 09:01:10 --> Config Class Initialized
INFO - 2024-03-15 09:01:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:01:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:01:10 --> Utf8 Class Initialized
INFO - 2024-03-15 09:01:10 --> URI Class Initialized
DEBUG - 2024-03-15 09:01:10 --> No URI present. Default controller set.
INFO - 2024-03-15 09:01:10 --> Router Class Initialized
INFO - 2024-03-15 09:01:10 --> Output Class Initialized
INFO - 2024-03-15 09:01:10 --> Security Class Initialized
DEBUG - 2024-03-15 09:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:01:10 --> Input Class Initialized
INFO - 2024-03-15 09:01:10 --> Language Class Initialized
INFO - 2024-03-15 09:01:10 --> Language Class Initialized
INFO - 2024-03-15 09:01:10 --> Config Class Initialized
INFO - 2024-03-15 09:01:10 --> Loader Class Initialized
INFO - 2024-03-15 09:01:10 --> Helper loaded: url_helper
INFO - 2024-03-15 09:01:10 --> Helper loaded: file_helper
INFO - 2024-03-15 09:01:10 --> Helper loaded: form_helper
INFO - 2024-03-15 09:01:10 --> Helper loaded: my_helper
INFO - 2024-03-15 09:01:10 --> Database Driver Class Initialized
INFO - 2024-03-15 09:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:01:10 --> Controller Class Initialized
DEBUG - 2024-03-15 09:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 09:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:01:10 --> Final output sent to browser
DEBUG - 2024-03-15 09:01:10 --> Total execution time: 0.0395
INFO - 2024-03-15 09:01:18 --> Config Class Initialized
INFO - 2024-03-15 09:01:18 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:01:18 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:01:18 --> Utf8 Class Initialized
INFO - 2024-03-15 09:01:18 --> URI Class Initialized
INFO - 2024-03-15 09:01:18 --> Router Class Initialized
INFO - 2024-03-15 09:01:18 --> Output Class Initialized
INFO - 2024-03-15 09:01:18 --> Security Class Initialized
DEBUG - 2024-03-15 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:01:18 --> Input Class Initialized
INFO - 2024-03-15 09:01:18 --> Language Class Initialized
INFO - 2024-03-15 09:01:18 --> Language Class Initialized
INFO - 2024-03-15 09:01:18 --> Config Class Initialized
INFO - 2024-03-15 09:01:18 --> Loader Class Initialized
INFO - 2024-03-15 09:01:18 --> Helper loaded: url_helper
INFO - 2024-03-15 09:01:18 --> Helper loaded: file_helper
INFO - 2024-03-15 09:01:18 --> Helper loaded: form_helper
INFO - 2024-03-15 09:01:18 --> Helper loaded: my_helper
INFO - 2024-03-15 09:01:18 --> Database Driver Class Initialized
INFO - 2024-03-15 09:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:01:18 --> Controller Class Initialized
DEBUG - 2024-03-15 09:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2024-03-15 09:01:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:01:18 --> Final output sent to browser
DEBUG - 2024-03-15 09:01:18 --> Total execution time: 0.0480
INFO - 2024-03-15 09:01:23 --> Config Class Initialized
INFO - 2024-03-15 09:01:23 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:01:23 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:01:23 --> Utf8 Class Initialized
INFO - 2024-03-15 09:01:23 --> URI Class Initialized
INFO - 2024-03-15 09:01:23 --> Router Class Initialized
INFO - 2024-03-15 09:01:23 --> Output Class Initialized
INFO - 2024-03-15 09:01:23 --> Security Class Initialized
DEBUG - 2024-03-15 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:01:23 --> Input Class Initialized
INFO - 2024-03-15 09:01:23 --> Language Class Initialized
INFO - 2024-03-15 09:01:23 --> Language Class Initialized
INFO - 2024-03-15 09:01:23 --> Config Class Initialized
INFO - 2024-03-15 09:01:23 --> Loader Class Initialized
INFO - 2024-03-15 09:01:23 --> Helper loaded: url_helper
INFO - 2024-03-15 09:01:23 --> Helper loaded: file_helper
INFO - 2024-03-15 09:01:23 --> Helper loaded: form_helper
INFO - 2024-03-15 09:01:23 --> Helper loaded: my_helper
INFO - 2024-03-15 09:01:23 --> Database Driver Class Initialized
INFO - 2024-03-15 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:01:23 --> Controller Class Initialized
DEBUG - 2024-03-15 09:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 09:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:01:23 --> Final output sent to browser
DEBUG - 2024-03-15 09:01:23 --> Total execution time: 0.0376
INFO - 2024-03-15 09:01:31 --> Config Class Initialized
INFO - 2024-03-15 09:01:31 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:01:31 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:01:31 --> Utf8 Class Initialized
INFO - 2024-03-15 09:01:31 --> URI Class Initialized
INFO - 2024-03-15 09:01:31 --> Router Class Initialized
INFO - 2024-03-15 09:01:31 --> Output Class Initialized
INFO - 2024-03-15 09:01:31 --> Security Class Initialized
DEBUG - 2024-03-15 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:01:31 --> Input Class Initialized
INFO - 2024-03-15 09:01:31 --> Language Class Initialized
INFO - 2024-03-15 09:01:31 --> Language Class Initialized
INFO - 2024-03-15 09:01:31 --> Config Class Initialized
INFO - 2024-03-15 09:01:31 --> Loader Class Initialized
INFO - 2024-03-15 09:01:31 --> Helper loaded: url_helper
INFO - 2024-03-15 09:01:31 --> Helper loaded: file_helper
INFO - 2024-03-15 09:01:31 --> Helper loaded: form_helper
INFO - 2024-03-15 09:01:31 --> Helper loaded: my_helper
INFO - 2024-03-15 09:01:31 --> Database Driver Class Initialized
INFO - 2024-03-15 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:01:31 --> Controller Class Initialized
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:01:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:01:35 --> Final output sent to browser
DEBUG - 2024-03-15 09:01:35 --> Total execution time: 4.0708
INFO - 2024-03-15 09:02:26 --> Config Class Initialized
INFO - 2024-03-15 09:02:26 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:02:26 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:02:26 --> Utf8 Class Initialized
INFO - 2024-03-15 09:02:26 --> URI Class Initialized
INFO - 2024-03-15 09:02:26 --> Router Class Initialized
INFO - 2024-03-15 09:02:26 --> Output Class Initialized
INFO - 2024-03-15 09:02:26 --> Security Class Initialized
DEBUG - 2024-03-15 09:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:02:26 --> Input Class Initialized
INFO - 2024-03-15 09:02:26 --> Language Class Initialized
INFO - 2024-03-15 09:02:26 --> Language Class Initialized
INFO - 2024-03-15 09:02:26 --> Config Class Initialized
INFO - 2024-03-15 09:02:26 --> Loader Class Initialized
INFO - 2024-03-15 09:02:26 --> Helper loaded: url_helper
INFO - 2024-03-15 09:02:26 --> Helper loaded: file_helper
INFO - 2024-03-15 09:02:26 --> Helper loaded: form_helper
INFO - 2024-03-15 09:02:26 --> Helper loaded: my_helper
INFO - 2024-03-15 09:02:26 --> Database Driver Class Initialized
INFO - 2024-03-15 09:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:02:26 --> Controller Class Initialized
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:02:26 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:02:26 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:02:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:02:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:02:29 --> Final output sent to browser
DEBUG - 2024-03-15 09:02:29 --> Total execution time: 3.5282
INFO - 2024-03-15 09:03:02 --> Config Class Initialized
INFO - 2024-03-15 09:03:02 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:03:02 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:03:02 --> Utf8 Class Initialized
INFO - 2024-03-15 09:03:02 --> URI Class Initialized
INFO - 2024-03-15 09:03:02 --> Router Class Initialized
INFO - 2024-03-15 09:03:02 --> Output Class Initialized
INFO - 2024-03-15 09:03:02 --> Security Class Initialized
DEBUG - 2024-03-15 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:03:02 --> Input Class Initialized
INFO - 2024-03-15 09:03:02 --> Language Class Initialized
INFO - 2024-03-15 09:03:02 --> Language Class Initialized
INFO - 2024-03-15 09:03:02 --> Config Class Initialized
INFO - 2024-03-15 09:03:02 --> Loader Class Initialized
INFO - 2024-03-15 09:03:02 --> Helper loaded: url_helper
INFO - 2024-03-15 09:03:02 --> Helper loaded: file_helper
INFO - 2024-03-15 09:03:02 --> Helper loaded: form_helper
INFO - 2024-03-15 09:03:02 --> Helper loaded: my_helper
INFO - 2024-03-15 09:03:02 --> Database Driver Class Initialized
INFO - 2024-03-15 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:03:02 --> Controller Class Initialized
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:03:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:03:08 --> Final output sent to browser
DEBUG - 2024-03-15 09:03:08 --> Total execution time: 6.4976
INFO - 2024-03-15 09:03:51 --> Config Class Initialized
INFO - 2024-03-15 09:03:51 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:03:51 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:03:51 --> Utf8 Class Initialized
INFO - 2024-03-15 09:03:51 --> URI Class Initialized
INFO - 2024-03-15 09:03:51 --> Router Class Initialized
INFO - 2024-03-15 09:03:51 --> Output Class Initialized
INFO - 2024-03-15 09:03:51 --> Security Class Initialized
DEBUG - 2024-03-15 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:03:51 --> Input Class Initialized
INFO - 2024-03-15 09:03:51 --> Language Class Initialized
INFO - 2024-03-15 09:03:51 --> Language Class Initialized
INFO - 2024-03-15 09:03:51 --> Config Class Initialized
INFO - 2024-03-15 09:03:51 --> Loader Class Initialized
INFO - 2024-03-15 09:03:51 --> Helper loaded: url_helper
INFO - 2024-03-15 09:03:51 --> Helper loaded: file_helper
INFO - 2024-03-15 09:03:51 --> Helper loaded: form_helper
INFO - 2024-03-15 09:03:51 --> Helper loaded: my_helper
INFO - 2024-03-15 09:03:51 --> Database Driver Class Initialized
INFO - 2024-03-15 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:03:51 --> Controller Class Initialized
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:03:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:03:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:03:54 --> Final output sent to browser
DEBUG - 2024-03-15 09:03:54 --> Total execution time: 3.2529
INFO - 2024-03-15 09:04:24 --> Config Class Initialized
INFO - 2024-03-15 09:04:24 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:04:24 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:04:24 --> Utf8 Class Initialized
INFO - 2024-03-15 09:04:24 --> URI Class Initialized
INFO - 2024-03-15 09:04:24 --> Router Class Initialized
INFO - 2024-03-15 09:04:24 --> Output Class Initialized
INFO - 2024-03-15 09:04:24 --> Security Class Initialized
DEBUG - 2024-03-15 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:04:24 --> Input Class Initialized
INFO - 2024-03-15 09:04:24 --> Language Class Initialized
INFO - 2024-03-15 09:04:24 --> Language Class Initialized
INFO - 2024-03-15 09:04:24 --> Config Class Initialized
INFO - 2024-03-15 09:04:24 --> Loader Class Initialized
INFO - 2024-03-15 09:04:24 --> Helper loaded: url_helper
INFO - 2024-03-15 09:04:24 --> Helper loaded: file_helper
INFO - 2024-03-15 09:04:24 --> Helper loaded: form_helper
INFO - 2024-03-15 09:04:24 --> Helper loaded: my_helper
INFO - 2024-03-15 09:04:24 --> Database Driver Class Initialized
INFO - 2024-03-15 09:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:04:24 --> Controller Class Initialized
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:04:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:04:27 --> Final output sent to browser
DEBUG - 2024-03-15 09:04:27 --> Total execution time: 3.0912
INFO - 2024-03-15 09:04:52 --> Config Class Initialized
INFO - 2024-03-15 09:04:52 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:04:52 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:04:52 --> Utf8 Class Initialized
INFO - 2024-03-15 09:04:52 --> URI Class Initialized
INFO - 2024-03-15 09:04:52 --> Router Class Initialized
INFO - 2024-03-15 09:04:52 --> Output Class Initialized
INFO - 2024-03-15 09:04:52 --> Security Class Initialized
DEBUG - 2024-03-15 09:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:04:52 --> Input Class Initialized
INFO - 2024-03-15 09:04:52 --> Language Class Initialized
INFO - 2024-03-15 09:04:52 --> Language Class Initialized
INFO - 2024-03-15 09:04:52 --> Config Class Initialized
INFO - 2024-03-15 09:04:52 --> Loader Class Initialized
INFO - 2024-03-15 09:04:52 --> Helper loaded: url_helper
INFO - 2024-03-15 09:04:52 --> Helper loaded: file_helper
INFO - 2024-03-15 09:04:52 --> Helper loaded: form_helper
INFO - 2024-03-15 09:04:52 --> Helper loaded: my_helper
INFO - 2024-03-15 09:04:52 --> Database Driver Class Initialized
INFO - 2024-03-15 09:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:04:52 --> Controller Class Initialized
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:52 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:52 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:04:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:04:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:04:55 --> Final output sent to browser
DEBUG - 2024-03-15 09:04:55 --> Total execution time: 3.0806
INFO - 2024-03-15 09:05:28 --> Config Class Initialized
INFO - 2024-03-15 09:05:28 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:05:28 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:05:28 --> Utf8 Class Initialized
INFO - 2024-03-15 09:05:28 --> URI Class Initialized
INFO - 2024-03-15 09:05:28 --> Router Class Initialized
INFO - 2024-03-15 09:05:28 --> Output Class Initialized
INFO - 2024-03-15 09:05:28 --> Security Class Initialized
DEBUG - 2024-03-15 09:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:05:28 --> Input Class Initialized
INFO - 2024-03-15 09:05:28 --> Language Class Initialized
INFO - 2024-03-15 09:05:28 --> Language Class Initialized
INFO - 2024-03-15 09:05:28 --> Config Class Initialized
INFO - 2024-03-15 09:05:28 --> Loader Class Initialized
INFO - 2024-03-15 09:05:28 --> Helper loaded: url_helper
INFO - 2024-03-15 09:05:28 --> Helper loaded: file_helper
INFO - 2024-03-15 09:05:28 --> Helper loaded: form_helper
INFO - 2024-03-15 09:05:28 --> Helper loaded: my_helper
INFO - 2024-03-15 09:05:28 --> Database Driver Class Initialized
INFO - 2024-03-15 09:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:05:28 --> Controller Class Initialized
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:05:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:05:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:05:31 --> Final output sent to browser
DEBUG - 2024-03-15 09:05:31 --> Total execution time: 3.0902
INFO - 2024-03-15 09:06:07 --> Config Class Initialized
INFO - 2024-03-15 09:06:07 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:06:07 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:06:07 --> Utf8 Class Initialized
INFO - 2024-03-15 09:06:07 --> URI Class Initialized
INFO - 2024-03-15 09:06:07 --> Router Class Initialized
INFO - 2024-03-15 09:06:07 --> Output Class Initialized
INFO - 2024-03-15 09:06:07 --> Security Class Initialized
DEBUG - 2024-03-15 09:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:06:07 --> Input Class Initialized
INFO - 2024-03-15 09:06:07 --> Language Class Initialized
INFO - 2024-03-15 09:06:07 --> Language Class Initialized
INFO - 2024-03-15 09:06:07 --> Config Class Initialized
INFO - 2024-03-15 09:06:07 --> Loader Class Initialized
INFO - 2024-03-15 09:06:07 --> Helper loaded: url_helper
INFO - 2024-03-15 09:06:07 --> Helper loaded: file_helper
INFO - 2024-03-15 09:06:07 --> Helper loaded: form_helper
INFO - 2024-03-15 09:06:07 --> Helper loaded: my_helper
INFO - 2024-03-15 09:06:07 --> Database Driver Class Initialized
INFO - 2024-03-15 09:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:06:07 --> Controller Class Initialized
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:06:11 --> Final output sent to browser
DEBUG - 2024-03-15 09:06:11 --> Total execution time: 3.4946
INFO - 2024-03-15 09:06:46 --> Config Class Initialized
INFO - 2024-03-15 09:06:46 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:06:46 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:06:46 --> Utf8 Class Initialized
INFO - 2024-03-15 09:06:46 --> URI Class Initialized
INFO - 2024-03-15 09:06:46 --> Router Class Initialized
INFO - 2024-03-15 09:06:46 --> Output Class Initialized
INFO - 2024-03-15 09:06:46 --> Security Class Initialized
DEBUG - 2024-03-15 09:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:06:46 --> Input Class Initialized
INFO - 2024-03-15 09:06:46 --> Language Class Initialized
INFO - 2024-03-15 09:06:46 --> Language Class Initialized
INFO - 2024-03-15 09:06:46 --> Config Class Initialized
INFO - 2024-03-15 09:06:46 --> Loader Class Initialized
INFO - 2024-03-15 09:06:46 --> Helper loaded: url_helper
INFO - 2024-03-15 09:06:46 --> Helper loaded: file_helper
INFO - 2024-03-15 09:06:46 --> Helper loaded: form_helper
INFO - 2024-03-15 09:06:46 --> Helper loaded: my_helper
INFO - 2024-03-15 09:06:46 --> Database Driver Class Initialized
INFO - 2024-03-15 09:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:06:46 --> Controller Class Initialized
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:06:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:06:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:06:51 --> Final output sent to browser
DEBUG - 2024-03-15 09:06:51 --> Total execution time: 4.6715
INFO - 2024-03-15 09:07:02 --> Config Class Initialized
INFO - 2024-03-15 09:07:02 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:07:02 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:07:02 --> Utf8 Class Initialized
INFO - 2024-03-15 09:07:02 --> URI Class Initialized
INFO - 2024-03-15 09:07:02 --> Router Class Initialized
INFO - 2024-03-15 09:07:02 --> Output Class Initialized
INFO - 2024-03-15 09:07:02 --> Security Class Initialized
DEBUG - 2024-03-15 09:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:07:02 --> Input Class Initialized
INFO - 2024-03-15 09:07:02 --> Language Class Initialized
INFO - 2024-03-15 09:07:02 --> Language Class Initialized
INFO - 2024-03-15 09:07:02 --> Config Class Initialized
INFO - 2024-03-15 09:07:02 --> Loader Class Initialized
INFO - 2024-03-15 09:07:02 --> Helper loaded: url_helper
INFO - 2024-03-15 09:07:02 --> Helper loaded: file_helper
INFO - 2024-03-15 09:07:02 --> Helper loaded: form_helper
INFO - 2024-03-15 09:07:02 --> Helper loaded: my_helper
INFO - 2024-03-15 09:07:02 --> Database Driver Class Initialized
INFO - 2024-03-15 09:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:07:02 --> Controller Class Initialized
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:07:05 --> Final output sent to browser
DEBUG - 2024-03-15 09:07:05 --> Total execution time: 3.5043
INFO - 2024-03-15 09:07:35 --> Config Class Initialized
INFO - 2024-03-15 09:07:35 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:07:35 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:07:35 --> Utf8 Class Initialized
INFO - 2024-03-15 09:07:35 --> URI Class Initialized
INFO - 2024-03-15 09:07:35 --> Router Class Initialized
INFO - 2024-03-15 09:07:35 --> Output Class Initialized
INFO - 2024-03-15 09:07:35 --> Security Class Initialized
DEBUG - 2024-03-15 09:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:07:35 --> Input Class Initialized
INFO - 2024-03-15 09:07:35 --> Language Class Initialized
INFO - 2024-03-15 09:07:35 --> Language Class Initialized
INFO - 2024-03-15 09:07:35 --> Config Class Initialized
INFO - 2024-03-15 09:07:35 --> Loader Class Initialized
INFO - 2024-03-15 09:07:35 --> Helper loaded: url_helper
INFO - 2024-03-15 09:07:35 --> Helper loaded: file_helper
INFO - 2024-03-15 09:07:35 --> Helper loaded: form_helper
INFO - 2024-03-15 09:07:35 --> Helper loaded: my_helper
INFO - 2024-03-15 09:07:35 --> Database Driver Class Initialized
INFO - 2024-03-15 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:07:35 --> Controller Class Initialized
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:07:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:07:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:07:38 --> Final output sent to browser
DEBUG - 2024-03-15 09:07:38 --> Total execution time: 2.8902
INFO - 2024-03-15 09:08:08 --> Config Class Initialized
INFO - 2024-03-15 09:08:08 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:08:08 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:08:08 --> Utf8 Class Initialized
INFO - 2024-03-15 09:08:08 --> URI Class Initialized
INFO - 2024-03-15 09:08:08 --> Router Class Initialized
INFO - 2024-03-15 09:08:08 --> Output Class Initialized
INFO - 2024-03-15 09:08:08 --> Security Class Initialized
DEBUG - 2024-03-15 09:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:08:08 --> Input Class Initialized
INFO - 2024-03-15 09:08:08 --> Language Class Initialized
INFO - 2024-03-15 09:08:08 --> Language Class Initialized
INFO - 2024-03-15 09:08:08 --> Config Class Initialized
INFO - 2024-03-15 09:08:08 --> Loader Class Initialized
INFO - 2024-03-15 09:08:08 --> Helper loaded: url_helper
INFO - 2024-03-15 09:08:08 --> Helper loaded: file_helper
INFO - 2024-03-15 09:08:08 --> Helper loaded: form_helper
INFO - 2024-03-15 09:08:08 --> Helper loaded: my_helper
INFO - 2024-03-15 09:08:08 --> Database Driver Class Initialized
INFO - 2024-03-15 09:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:08:08 --> Controller Class Initialized
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:08:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:08:11 --> Final output sent to browser
DEBUG - 2024-03-15 09:08:11 --> Total execution time: 3.0865
INFO - 2024-03-15 09:08:43 --> Config Class Initialized
INFO - 2024-03-15 09:08:43 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:08:43 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:08:43 --> Utf8 Class Initialized
INFO - 2024-03-15 09:08:43 --> URI Class Initialized
INFO - 2024-03-15 09:08:43 --> Router Class Initialized
INFO - 2024-03-15 09:08:43 --> Output Class Initialized
INFO - 2024-03-15 09:08:43 --> Security Class Initialized
DEBUG - 2024-03-15 09:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:08:43 --> Input Class Initialized
INFO - 2024-03-15 09:08:43 --> Language Class Initialized
INFO - 2024-03-15 09:08:43 --> Language Class Initialized
INFO - 2024-03-15 09:08:43 --> Config Class Initialized
INFO - 2024-03-15 09:08:43 --> Loader Class Initialized
INFO - 2024-03-15 09:08:43 --> Helper loaded: url_helper
INFO - 2024-03-15 09:08:43 --> Helper loaded: file_helper
INFO - 2024-03-15 09:08:43 --> Helper loaded: form_helper
INFO - 2024-03-15 09:08:43 --> Helper loaded: my_helper
INFO - 2024-03-15 09:08:43 --> Database Driver Class Initialized
INFO - 2024-03-15 09:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:08:43 --> Controller Class Initialized
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:08:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:08:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:08:47 --> Final output sent to browser
DEBUG - 2024-03-15 09:08:47 --> Total execution time: 3.1828
INFO - 2024-03-15 09:09:15 --> Config Class Initialized
INFO - 2024-03-15 09:09:15 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:09:15 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:09:15 --> Utf8 Class Initialized
INFO - 2024-03-15 09:09:15 --> URI Class Initialized
INFO - 2024-03-15 09:09:15 --> Router Class Initialized
INFO - 2024-03-15 09:09:15 --> Output Class Initialized
INFO - 2024-03-15 09:09:15 --> Security Class Initialized
DEBUG - 2024-03-15 09:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:09:15 --> Input Class Initialized
INFO - 2024-03-15 09:09:15 --> Language Class Initialized
INFO - 2024-03-15 09:09:15 --> Language Class Initialized
INFO - 2024-03-15 09:09:15 --> Config Class Initialized
INFO - 2024-03-15 09:09:15 --> Loader Class Initialized
INFO - 2024-03-15 09:09:15 --> Helper loaded: url_helper
INFO - 2024-03-15 09:09:15 --> Helper loaded: file_helper
INFO - 2024-03-15 09:09:15 --> Helper loaded: form_helper
INFO - 2024-03-15 09:09:15 --> Helper loaded: my_helper
INFO - 2024-03-15 09:09:15 --> Database Driver Class Initialized
INFO - 2024-03-15 09:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:09:15 --> Controller Class Initialized
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:09:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:09:18 --> Final output sent to browser
DEBUG - 2024-03-15 09:09:18 --> Total execution time: 3.1940
INFO - 2024-03-15 09:09:43 --> Config Class Initialized
INFO - 2024-03-15 09:09:43 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:09:43 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:09:43 --> Utf8 Class Initialized
INFO - 2024-03-15 09:09:43 --> URI Class Initialized
INFO - 2024-03-15 09:09:43 --> Router Class Initialized
INFO - 2024-03-15 09:09:43 --> Output Class Initialized
INFO - 2024-03-15 09:09:43 --> Security Class Initialized
DEBUG - 2024-03-15 09:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:09:43 --> Input Class Initialized
INFO - 2024-03-15 09:09:43 --> Language Class Initialized
INFO - 2024-03-15 09:09:43 --> Language Class Initialized
INFO - 2024-03-15 09:09:43 --> Config Class Initialized
INFO - 2024-03-15 09:09:43 --> Loader Class Initialized
INFO - 2024-03-15 09:09:43 --> Helper loaded: url_helper
INFO - 2024-03-15 09:09:43 --> Helper loaded: file_helper
INFO - 2024-03-15 09:09:43 --> Helper loaded: form_helper
INFO - 2024-03-15 09:09:43 --> Helper loaded: my_helper
INFO - 2024-03-15 09:09:43 --> Database Driver Class Initialized
INFO - 2024-03-15 09:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:09:43 --> Controller Class Initialized
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:09:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:09:46 --> Final output sent to browser
DEBUG - 2024-03-15 09:09:46 --> Total execution time: 3.0853
INFO - 2024-03-15 09:10:08 --> Config Class Initialized
INFO - 2024-03-15 09:10:08 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:10:09 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:10:09 --> Utf8 Class Initialized
INFO - 2024-03-15 09:10:09 --> URI Class Initialized
INFO - 2024-03-15 09:10:09 --> Router Class Initialized
INFO - 2024-03-15 09:10:09 --> Output Class Initialized
INFO - 2024-03-15 09:10:09 --> Security Class Initialized
DEBUG - 2024-03-15 09:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:10:09 --> Input Class Initialized
INFO - 2024-03-15 09:10:09 --> Language Class Initialized
INFO - 2024-03-15 09:10:09 --> Language Class Initialized
INFO - 2024-03-15 09:10:09 --> Config Class Initialized
INFO - 2024-03-15 09:10:09 --> Loader Class Initialized
INFO - 2024-03-15 09:10:09 --> Helper loaded: url_helper
INFO - 2024-03-15 09:10:09 --> Helper loaded: file_helper
INFO - 2024-03-15 09:10:09 --> Helper loaded: form_helper
INFO - 2024-03-15 09:10:09 --> Helper loaded: my_helper
INFO - 2024-03-15 09:10:09 --> Database Driver Class Initialized
INFO - 2024-03-15 09:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:10:09 --> Controller Class Initialized
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:10:12 --> Final output sent to browser
DEBUG - 2024-03-15 09:10:12 --> Total execution time: 3.0986
INFO - 2024-03-15 09:10:31 --> Config Class Initialized
INFO - 2024-03-15 09:10:31 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:10:31 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:10:31 --> Utf8 Class Initialized
INFO - 2024-03-15 09:10:31 --> URI Class Initialized
INFO - 2024-03-15 09:10:31 --> Router Class Initialized
INFO - 2024-03-15 09:10:31 --> Output Class Initialized
INFO - 2024-03-15 09:10:31 --> Security Class Initialized
DEBUG - 2024-03-15 09:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:10:31 --> Input Class Initialized
INFO - 2024-03-15 09:10:31 --> Language Class Initialized
INFO - 2024-03-15 09:10:31 --> Language Class Initialized
INFO - 2024-03-15 09:10:31 --> Config Class Initialized
INFO - 2024-03-15 09:10:31 --> Loader Class Initialized
INFO - 2024-03-15 09:10:31 --> Helper loaded: url_helper
INFO - 2024-03-15 09:10:31 --> Helper loaded: file_helper
INFO - 2024-03-15 09:10:31 --> Helper loaded: form_helper
INFO - 2024-03-15 09:10:31 --> Helper loaded: my_helper
INFO - 2024-03-15 09:10:32 --> Database Driver Class Initialized
INFO - 2024-03-15 09:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:10:32 --> Controller Class Initialized
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 09:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 09:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 09:10:35 --> Final output sent to browser
DEBUG - 2024-03-15 09:10:35 --> Total execution time: 3.7839
INFO - 2024-03-15 09:10:57 --> Config Class Initialized
INFO - 2024-03-15 09:10:57 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:10:57 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:10:57 --> Utf8 Class Initialized
INFO - 2024-03-15 09:10:57 --> URI Class Initialized
INFO - 2024-03-15 09:10:57 --> Router Class Initialized
INFO - 2024-03-15 09:10:57 --> Output Class Initialized
INFO - 2024-03-15 09:10:57 --> Security Class Initialized
DEBUG - 2024-03-15 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:10:57 --> Input Class Initialized
INFO - 2024-03-15 09:10:57 --> Language Class Initialized
INFO - 2024-03-15 09:10:57 --> Language Class Initialized
INFO - 2024-03-15 09:10:57 --> Config Class Initialized
INFO - 2024-03-15 09:10:57 --> Loader Class Initialized
INFO - 2024-03-15 09:10:58 --> Helper loaded: url_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: file_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: form_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: my_helper
INFO - 2024-03-15 09:10:58 --> Database Driver Class Initialized
INFO - 2024-03-15 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:10:58 --> Controller Class Initialized
INFO - 2024-03-15 09:10:58 --> Helper loaded: cookie_helper
INFO - 2024-03-15 09:10:58 --> Config Class Initialized
INFO - 2024-03-15 09:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:10:58 --> Utf8 Class Initialized
INFO - 2024-03-15 09:10:58 --> URI Class Initialized
INFO - 2024-03-15 09:10:58 --> Router Class Initialized
INFO - 2024-03-15 09:10:58 --> Output Class Initialized
INFO - 2024-03-15 09:10:58 --> Security Class Initialized
DEBUG - 2024-03-15 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:10:58 --> Input Class Initialized
INFO - 2024-03-15 09:10:58 --> Language Class Initialized
INFO - 2024-03-15 09:10:58 --> Language Class Initialized
INFO - 2024-03-15 09:10:58 --> Config Class Initialized
INFO - 2024-03-15 09:10:58 --> Loader Class Initialized
INFO - 2024-03-15 09:10:58 --> Helper loaded: url_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: file_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: form_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: my_helper
INFO - 2024-03-15 09:10:58 --> Database Driver Class Initialized
INFO - 2024-03-15 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:10:58 --> Controller Class Initialized
INFO - 2024-03-15 09:10:58 --> Config Class Initialized
INFO - 2024-03-15 09:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:10:58 --> Utf8 Class Initialized
INFO - 2024-03-15 09:10:58 --> URI Class Initialized
INFO - 2024-03-15 09:10:58 --> Router Class Initialized
INFO - 2024-03-15 09:10:58 --> Output Class Initialized
INFO - 2024-03-15 09:10:58 --> Security Class Initialized
DEBUG - 2024-03-15 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:10:58 --> Input Class Initialized
INFO - 2024-03-15 09:10:58 --> Language Class Initialized
INFO - 2024-03-15 09:10:58 --> Language Class Initialized
INFO - 2024-03-15 09:10:58 --> Config Class Initialized
INFO - 2024-03-15 09:10:58 --> Loader Class Initialized
INFO - 2024-03-15 09:10:58 --> Helper loaded: url_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: file_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: form_helper
INFO - 2024-03-15 09:10:58 --> Helper loaded: my_helper
INFO - 2024-03-15 09:10:58 --> Database Driver Class Initialized
INFO - 2024-03-15 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:10:58 --> Controller Class Initialized
DEBUG - 2024-03-15 09:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 09:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:10:58 --> Final output sent to browser
DEBUG - 2024-03-15 09:10:58 --> Total execution time: 0.0320
INFO - 2024-03-15 09:11:05 --> Config Class Initialized
INFO - 2024-03-15 09:11:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:11:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:11:05 --> Utf8 Class Initialized
INFO - 2024-03-15 09:11:05 --> URI Class Initialized
INFO - 2024-03-15 09:11:05 --> Router Class Initialized
INFO - 2024-03-15 09:11:05 --> Output Class Initialized
INFO - 2024-03-15 09:11:05 --> Security Class Initialized
DEBUG - 2024-03-15 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:11:05 --> Input Class Initialized
INFO - 2024-03-15 09:11:05 --> Language Class Initialized
INFO - 2024-03-15 09:11:05 --> Language Class Initialized
INFO - 2024-03-15 09:11:05 --> Config Class Initialized
INFO - 2024-03-15 09:11:05 --> Loader Class Initialized
INFO - 2024-03-15 09:11:05 --> Helper loaded: url_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: file_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: form_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: my_helper
INFO - 2024-03-15 09:11:05 --> Database Driver Class Initialized
INFO - 2024-03-15 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:11:05 --> Controller Class Initialized
INFO - 2024-03-15 09:11:05 --> Helper loaded: cookie_helper
INFO - 2024-03-15 09:11:05 --> Final output sent to browser
DEBUG - 2024-03-15 09:11:05 --> Total execution time: 0.0330
INFO - 2024-03-15 09:11:05 --> Config Class Initialized
INFO - 2024-03-15 09:11:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:11:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:11:05 --> Utf8 Class Initialized
INFO - 2024-03-15 09:11:05 --> URI Class Initialized
INFO - 2024-03-15 09:11:05 --> Router Class Initialized
INFO - 2024-03-15 09:11:05 --> Output Class Initialized
INFO - 2024-03-15 09:11:05 --> Security Class Initialized
DEBUG - 2024-03-15 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:11:05 --> Input Class Initialized
INFO - 2024-03-15 09:11:05 --> Language Class Initialized
INFO - 2024-03-15 09:11:05 --> Language Class Initialized
INFO - 2024-03-15 09:11:05 --> Config Class Initialized
INFO - 2024-03-15 09:11:05 --> Loader Class Initialized
INFO - 2024-03-15 09:11:05 --> Helper loaded: url_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: file_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: form_helper
INFO - 2024-03-15 09:11:05 --> Helper loaded: my_helper
INFO - 2024-03-15 09:11:05 --> Database Driver Class Initialized
INFO - 2024-03-15 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:11:05 --> Controller Class Initialized
DEBUG - 2024-03-15 09:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 09:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:11:05 --> Final output sent to browser
DEBUG - 2024-03-15 09:11:05 --> Total execution time: 0.0344
INFO - 2024-03-15 09:11:06 --> Config Class Initialized
INFO - 2024-03-15 09:11:06 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:11:06 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:11:06 --> Utf8 Class Initialized
INFO - 2024-03-15 09:11:06 --> URI Class Initialized
INFO - 2024-03-15 09:11:06 --> Router Class Initialized
INFO - 2024-03-15 09:11:06 --> Output Class Initialized
INFO - 2024-03-15 09:11:06 --> Security Class Initialized
DEBUG - 2024-03-15 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:11:06 --> Input Class Initialized
INFO - 2024-03-15 09:11:06 --> Language Class Initialized
INFO - 2024-03-15 09:11:06 --> Language Class Initialized
INFO - 2024-03-15 09:11:06 --> Config Class Initialized
INFO - 2024-03-15 09:11:06 --> Loader Class Initialized
INFO - 2024-03-15 09:11:06 --> Helper loaded: url_helper
INFO - 2024-03-15 09:11:06 --> Helper loaded: file_helper
INFO - 2024-03-15 09:11:06 --> Helper loaded: form_helper
INFO - 2024-03-15 09:11:06 --> Helper loaded: my_helper
INFO - 2024-03-15 09:11:06 --> Database Driver Class Initialized
INFO - 2024-03-15 09:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:11:06 --> Controller Class Initialized
DEBUG - 2024-03-15 09:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-15 09:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:11:06 --> Final output sent to browser
DEBUG - 2024-03-15 09:11:06 --> Total execution time: 0.0462
INFO - 2024-03-15 09:11:09 --> Config Class Initialized
INFO - 2024-03-15 09:11:09 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:11:09 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:11:09 --> Utf8 Class Initialized
INFO - 2024-03-15 09:11:09 --> URI Class Initialized
INFO - 2024-03-15 09:11:09 --> Router Class Initialized
INFO - 2024-03-15 09:11:09 --> Output Class Initialized
INFO - 2024-03-15 09:11:09 --> Security Class Initialized
DEBUG - 2024-03-15 09:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:11:09 --> Input Class Initialized
INFO - 2024-03-15 09:11:09 --> Language Class Initialized
INFO - 2024-03-15 09:11:09 --> Language Class Initialized
INFO - 2024-03-15 09:11:09 --> Config Class Initialized
INFO - 2024-03-15 09:11:09 --> Loader Class Initialized
INFO - 2024-03-15 09:11:09 --> Helper loaded: url_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: file_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: form_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: my_helper
INFO - 2024-03-15 09:11:09 --> Database Driver Class Initialized
INFO - 2024-03-15 09:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:11:09 --> Controller Class Initialized
DEBUG - 2024-03-15 09:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 09:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:11:09 --> Final output sent to browser
DEBUG - 2024-03-15 09:11:09 --> Total execution time: 0.0331
INFO - 2024-03-15 09:11:09 --> Config Class Initialized
INFO - 2024-03-15 09:11:09 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:11:09 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:11:09 --> Utf8 Class Initialized
INFO - 2024-03-15 09:11:09 --> URI Class Initialized
INFO - 2024-03-15 09:11:09 --> Router Class Initialized
INFO - 2024-03-15 09:11:09 --> Output Class Initialized
INFO - 2024-03-15 09:11:09 --> Security Class Initialized
DEBUG - 2024-03-15 09:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:11:09 --> Input Class Initialized
INFO - 2024-03-15 09:11:09 --> Language Class Initialized
INFO - 2024-03-15 09:11:09 --> Language Class Initialized
INFO - 2024-03-15 09:11:09 --> Config Class Initialized
INFO - 2024-03-15 09:11:09 --> Loader Class Initialized
INFO - 2024-03-15 09:11:09 --> Helper loaded: url_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: file_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: form_helper
INFO - 2024-03-15 09:11:09 --> Helper loaded: my_helper
INFO - 2024-03-15 09:11:09 --> Database Driver Class Initialized
INFO - 2024-03-15 09:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:11:09 --> Controller Class Initialized
INFO - 2024-03-15 09:14:54 --> Config Class Initialized
INFO - 2024-03-15 09:14:54 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:14:54 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:14:54 --> Utf8 Class Initialized
INFO - 2024-03-15 09:14:54 --> URI Class Initialized
INFO - 2024-03-15 09:14:54 --> Router Class Initialized
INFO - 2024-03-15 09:14:54 --> Output Class Initialized
INFO - 2024-03-15 09:14:54 --> Security Class Initialized
DEBUG - 2024-03-15 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:14:54 --> Input Class Initialized
INFO - 2024-03-15 09:14:54 --> Language Class Initialized
INFO - 2024-03-15 09:14:54 --> Language Class Initialized
INFO - 2024-03-15 09:14:54 --> Config Class Initialized
INFO - 2024-03-15 09:14:54 --> Loader Class Initialized
INFO - 2024-03-15 09:14:54 --> Helper loaded: url_helper
INFO - 2024-03-15 09:14:54 --> Helper loaded: file_helper
INFO - 2024-03-15 09:14:54 --> Helper loaded: form_helper
INFO - 2024-03-15 09:14:54 --> Helper loaded: my_helper
INFO - 2024-03-15 09:14:54 --> Database Driver Class Initialized
INFO - 2024-03-15 09:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:14:54 --> Controller Class Initialized
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> Division by zero /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 210
ERROR - 2024-03-15 09:14:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 211
DEBUG - 2024-03-15 09:14:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-15 09:14:54 --> Final output sent to browser
DEBUG - 2024-03-15 09:14:54 --> Total execution time: 0.0595
INFO - 2024-03-15 09:14:55 --> Config Class Initialized
INFO - 2024-03-15 09:14:55 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:14:55 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:14:55 --> Utf8 Class Initialized
INFO - 2024-03-15 09:14:55 --> URI Class Initialized
INFO - 2024-03-15 09:14:55 --> Router Class Initialized
INFO - 2024-03-15 09:14:55 --> Output Class Initialized
INFO - 2024-03-15 09:14:55 --> Security Class Initialized
DEBUG - 2024-03-15 09:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:14:55 --> Input Class Initialized
INFO - 2024-03-15 09:14:55 --> Language Class Initialized
INFO - 2024-03-15 09:14:55 --> Language Class Initialized
INFO - 2024-03-15 09:14:55 --> Config Class Initialized
INFO - 2024-03-15 09:14:55 --> Loader Class Initialized
INFO - 2024-03-15 09:14:55 --> Helper loaded: url_helper
INFO - 2024-03-15 09:14:55 --> Helper loaded: file_helper
INFO - 2024-03-15 09:14:55 --> Helper loaded: form_helper
INFO - 2024-03-15 09:14:55 --> Helper loaded: my_helper
INFO - 2024-03-15 09:14:55 --> Database Driver Class Initialized
INFO - 2024-03-15 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:14:55 --> Controller Class Initialized
DEBUG - 2024-03-15 09:14:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-15 09:14:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 09:14:55 --> Final output sent to browser
DEBUG - 2024-03-15 09:14:55 --> Total execution time: 0.0324
INFO - 2024-03-15 09:14:56 --> Config Class Initialized
INFO - 2024-03-15 09:14:56 --> Hooks Class Initialized
DEBUG - 2024-03-15 09:14:56 --> UTF-8 Support Enabled
INFO - 2024-03-15 09:14:56 --> Utf8 Class Initialized
INFO - 2024-03-15 09:14:56 --> URI Class Initialized
INFO - 2024-03-15 09:14:56 --> Router Class Initialized
INFO - 2024-03-15 09:14:56 --> Output Class Initialized
INFO - 2024-03-15 09:14:56 --> Security Class Initialized
DEBUG - 2024-03-15 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 09:14:56 --> Input Class Initialized
INFO - 2024-03-15 09:14:56 --> Language Class Initialized
INFO - 2024-03-15 09:14:56 --> Language Class Initialized
INFO - 2024-03-15 09:14:56 --> Config Class Initialized
INFO - 2024-03-15 09:14:56 --> Loader Class Initialized
INFO - 2024-03-15 09:14:56 --> Helper loaded: url_helper
INFO - 2024-03-15 09:14:56 --> Helper loaded: file_helper
INFO - 2024-03-15 09:14:56 --> Helper loaded: form_helper
INFO - 2024-03-15 09:14:56 --> Helper loaded: my_helper
INFO - 2024-03-15 09:14:56 --> Database Driver Class Initialized
INFO - 2024-03-15 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 09:14:56 --> Controller Class Initialized
INFO - 2024-03-15 10:44:04 --> Config Class Initialized
INFO - 2024-03-15 10:44:04 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:04 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:04 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:04 --> URI Class Initialized
INFO - 2024-03-15 10:44:04 --> Router Class Initialized
INFO - 2024-03-15 10:44:04 --> Output Class Initialized
INFO - 2024-03-15 10:44:04 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:04 --> Input Class Initialized
INFO - 2024-03-15 10:44:04 --> Language Class Initialized
INFO - 2024-03-15 10:44:04 --> Language Class Initialized
INFO - 2024-03-15 10:44:04 --> Config Class Initialized
INFO - 2024-03-15 10:44:04 --> Loader Class Initialized
INFO - 2024-03-15 10:44:04 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:04 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:04 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:04 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:04 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:04 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-15 10:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:04 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:04 --> Total execution time: 0.0735
INFO - 2024-03-15 10:44:05 --> Config Class Initialized
INFO - 2024-03-15 10:44:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:05 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:05 --> URI Class Initialized
INFO - 2024-03-15 10:44:05 --> Router Class Initialized
INFO - 2024-03-15 10:44:05 --> Output Class Initialized
INFO - 2024-03-15 10:44:05 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:05 --> Input Class Initialized
INFO - 2024-03-15 10:44:05 --> Language Class Initialized
INFO - 2024-03-15 10:44:05 --> Language Class Initialized
INFO - 2024-03-15 10:44:05 --> Config Class Initialized
INFO - 2024-03-15 10:44:05 --> Loader Class Initialized
INFO - 2024-03-15 10:44:05 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:05 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:05 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:05 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:05 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:05 --> Controller Class Initialized
INFO - 2024-03-15 10:44:11 --> Config Class Initialized
INFO - 2024-03-15 10:44:11 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:11 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:11 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:11 --> URI Class Initialized
DEBUG - 2024-03-15 10:44:11 --> No URI present. Default controller set.
INFO - 2024-03-15 10:44:11 --> Router Class Initialized
INFO - 2024-03-15 10:44:11 --> Output Class Initialized
INFO - 2024-03-15 10:44:11 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:11 --> Input Class Initialized
INFO - 2024-03-15 10:44:11 --> Language Class Initialized
INFO - 2024-03-15 10:44:11 --> Language Class Initialized
INFO - 2024-03-15 10:44:11 --> Config Class Initialized
INFO - 2024-03-15 10:44:11 --> Loader Class Initialized
INFO - 2024-03-15 10:44:11 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:11 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:11 --> Controller Class Initialized
INFO - 2024-03-15 10:44:11 --> Config Class Initialized
INFO - 2024-03-15 10:44:11 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:11 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:11 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:11 --> URI Class Initialized
INFO - 2024-03-15 10:44:11 --> Router Class Initialized
INFO - 2024-03-15 10:44:11 --> Output Class Initialized
INFO - 2024-03-15 10:44:11 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:11 --> Input Class Initialized
INFO - 2024-03-15 10:44:11 --> Language Class Initialized
INFO - 2024-03-15 10:44:11 --> Language Class Initialized
INFO - 2024-03-15 10:44:11 --> Config Class Initialized
INFO - 2024-03-15 10:44:11 --> Loader Class Initialized
INFO - 2024-03-15 10:44:11 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:11 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:11 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:11 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 10:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:11 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:11 --> Total execution time: 0.0350
INFO - 2024-03-15 10:44:15 --> Config Class Initialized
INFO - 2024-03-15 10:44:15 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:15 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:15 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:15 --> URI Class Initialized
INFO - 2024-03-15 10:44:15 --> Router Class Initialized
INFO - 2024-03-15 10:44:15 --> Output Class Initialized
INFO - 2024-03-15 10:44:15 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:15 --> Input Class Initialized
INFO - 2024-03-15 10:44:15 --> Language Class Initialized
INFO - 2024-03-15 10:44:15 --> Language Class Initialized
INFO - 2024-03-15 10:44:15 --> Config Class Initialized
INFO - 2024-03-15 10:44:15 --> Loader Class Initialized
INFO - 2024-03-15 10:44:15 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:15 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:15 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:15 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:15 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:15 --> Controller Class Initialized
INFO - 2024-03-15 10:44:15 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:15 --> Total execution time: 0.0434
INFO - 2024-03-15 10:44:22 --> Config Class Initialized
INFO - 2024-03-15 10:44:22 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:22 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:22 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:22 --> URI Class Initialized
INFO - 2024-03-15 10:44:22 --> Router Class Initialized
INFO - 2024-03-15 10:44:22 --> Output Class Initialized
INFO - 2024-03-15 10:44:22 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:22 --> Input Class Initialized
INFO - 2024-03-15 10:44:22 --> Language Class Initialized
INFO - 2024-03-15 10:44:22 --> Language Class Initialized
INFO - 2024-03-15 10:44:22 --> Config Class Initialized
INFO - 2024-03-15 10:44:22 --> Loader Class Initialized
INFO - 2024-03-15 10:44:22 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:22 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:22 --> Controller Class Initialized
INFO - 2024-03-15 10:44:22 --> Helper loaded: cookie_helper
INFO - 2024-03-15 10:44:22 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:22 --> Total execution time: 0.0310
INFO - 2024-03-15 10:44:22 --> Config Class Initialized
INFO - 2024-03-15 10:44:22 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:22 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:22 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:22 --> URI Class Initialized
INFO - 2024-03-15 10:44:22 --> Router Class Initialized
INFO - 2024-03-15 10:44:22 --> Output Class Initialized
INFO - 2024-03-15 10:44:22 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:22 --> Input Class Initialized
INFO - 2024-03-15 10:44:22 --> Language Class Initialized
INFO - 2024-03-15 10:44:22 --> Language Class Initialized
INFO - 2024-03-15 10:44:22 --> Config Class Initialized
INFO - 2024-03-15 10:44:22 --> Loader Class Initialized
INFO - 2024-03-15 10:44:22 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:22 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:22 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:22 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-15 10:44:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:22 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:22 --> Total execution time: 0.0350
INFO - 2024-03-15 10:44:25 --> Config Class Initialized
INFO - 2024-03-15 10:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:25 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:25 --> URI Class Initialized
INFO - 2024-03-15 10:44:25 --> Router Class Initialized
INFO - 2024-03-15 10:44:25 --> Output Class Initialized
INFO - 2024-03-15 10:44:25 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:25 --> Input Class Initialized
INFO - 2024-03-15 10:44:25 --> Language Class Initialized
INFO - 2024-03-15 10:44:25 --> Language Class Initialized
INFO - 2024-03-15 10:44:25 --> Config Class Initialized
INFO - 2024-03-15 10:44:25 --> Loader Class Initialized
INFO - 2024-03-15 10:44:25 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:25 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:25 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-03-15 10:44:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:25 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:25 --> Total execution time: 0.0327
INFO - 2024-03-15 10:44:25 --> Config Class Initialized
INFO - 2024-03-15 10:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:25 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:25 --> URI Class Initialized
INFO - 2024-03-15 10:44:25 --> Router Class Initialized
INFO - 2024-03-15 10:44:25 --> Output Class Initialized
INFO - 2024-03-15 10:44:25 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:25 --> Input Class Initialized
INFO - 2024-03-15 10:44:25 --> Language Class Initialized
ERROR - 2024-03-15 10:44:25 --> 404 Page Not Found: /index
INFO - 2024-03-15 10:44:25 --> Config Class Initialized
INFO - 2024-03-15 10:44:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:25 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:25 --> URI Class Initialized
INFO - 2024-03-15 10:44:25 --> Router Class Initialized
INFO - 2024-03-15 10:44:25 --> Output Class Initialized
INFO - 2024-03-15 10:44:25 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:25 --> Input Class Initialized
INFO - 2024-03-15 10:44:25 --> Language Class Initialized
INFO - 2024-03-15 10:44:25 --> Language Class Initialized
INFO - 2024-03-15 10:44:25 --> Config Class Initialized
INFO - 2024-03-15 10:44:25 --> Loader Class Initialized
INFO - 2024-03-15 10:44:25 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:25 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:25 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:25 --> Controller Class Initialized
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:28 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:28 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:28 --> URI Class Initialized
INFO - 2024-03-15 10:44:28 --> Router Class Initialized
INFO - 2024-03-15 10:44:28 --> Output Class Initialized
INFO - 2024-03-15 10:44:28 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:28 --> Input Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Loader Class Initialized
INFO - 2024-03-15 10:44:28 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:28 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:28 --> Controller Class Initialized
INFO - 2024-03-15 10:44:28 --> Helper loaded: cookie_helper
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:28 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:28 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:28 --> URI Class Initialized
INFO - 2024-03-15 10:44:28 --> Router Class Initialized
INFO - 2024-03-15 10:44:28 --> Output Class Initialized
INFO - 2024-03-15 10:44:28 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:28 --> Input Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Loader Class Initialized
INFO - 2024-03-15 10:44:28 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:28 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:28 --> Controller Class Initialized
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:28 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:28 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:28 --> URI Class Initialized
INFO - 2024-03-15 10:44:28 --> Router Class Initialized
INFO - 2024-03-15 10:44:28 --> Output Class Initialized
INFO - 2024-03-15 10:44:28 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:28 --> Input Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Language Class Initialized
INFO - 2024-03-15 10:44:28 --> Config Class Initialized
INFO - 2024-03-15 10:44:28 --> Loader Class Initialized
INFO - 2024-03-15 10:44:28 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:28 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:28 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:28 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 10:44:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:28 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:28 --> Total execution time: 0.0302
INFO - 2024-03-15 10:44:32 --> Config Class Initialized
INFO - 2024-03-15 10:44:32 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:32 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:32 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:32 --> URI Class Initialized
INFO - 2024-03-15 10:44:32 --> Router Class Initialized
INFO - 2024-03-15 10:44:32 --> Output Class Initialized
INFO - 2024-03-15 10:44:32 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:32 --> Input Class Initialized
INFO - 2024-03-15 10:44:32 --> Language Class Initialized
INFO - 2024-03-15 10:44:32 --> Language Class Initialized
INFO - 2024-03-15 10:44:32 --> Config Class Initialized
INFO - 2024-03-15 10:44:32 --> Loader Class Initialized
INFO - 2024-03-15 10:44:32 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:32 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:32 --> Controller Class Initialized
INFO - 2024-03-15 10:44:32 --> Helper loaded: cookie_helper
INFO - 2024-03-15 10:44:32 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:32 --> Total execution time: 0.0444
INFO - 2024-03-15 10:44:32 --> Config Class Initialized
INFO - 2024-03-15 10:44:32 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:32 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:32 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:32 --> URI Class Initialized
INFO - 2024-03-15 10:44:32 --> Router Class Initialized
INFO - 2024-03-15 10:44:32 --> Output Class Initialized
INFO - 2024-03-15 10:44:32 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:32 --> Input Class Initialized
INFO - 2024-03-15 10:44:32 --> Language Class Initialized
INFO - 2024-03-15 10:44:32 --> Language Class Initialized
INFO - 2024-03-15 10:44:32 --> Config Class Initialized
INFO - 2024-03-15 10:44:32 --> Loader Class Initialized
INFO - 2024-03-15 10:44:32 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:32 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:32 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:32 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 10:44:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:32 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:32 --> Total execution time: 0.0399
INFO - 2024-03-15 10:44:36 --> Config Class Initialized
INFO - 2024-03-15 10:44:36 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:36 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:36 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:36 --> URI Class Initialized
INFO - 2024-03-15 10:44:36 --> Router Class Initialized
INFO - 2024-03-15 10:44:36 --> Output Class Initialized
INFO - 2024-03-15 10:44:36 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:36 --> Input Class Initialized
INFO - 2024-03-15 10:44:36 --> Language Class Initialized
INFO - 2024-03-15 10:44:36 --> Language Class Initialized
INFO - 2024-03-15 10:44:36 --> Config Class Initialized
INFO - 2024-03-15 10:44:36 --> Loader Class Initialized
INFO - 2024-03-15 10:44:36 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:36 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:36 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:36 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:36 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:36 --> Controller Class Initialized
DEBUG - 2024-03-15 10:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 10:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:44:36 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:36 --> Total execution time: 0.0409
INFO - 2024-03-15 10:44:37 --> Config Class Initialized
INFO - 2024-03-15 10:44:37 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:44:37 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:44:37 --> Utf8 Class Initialized
INFO - 2024-03-15 10:44:37 --> URI Class Initialized
INFO - 2024-03-15 10:44:37 --> Router Class Initialized
INFO - 2024-03-15 10:44:37 --> Output Class Initialized
INFO - 2024-03-15 10:44:37 --> Security Class Initialized
DEBUG - 2024-03-15 10:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:44:37 --> Input Class Initialized
INFO - 2024-03-15 10:44:37 --> Language Class Initialized
INFO - 2024-03-15 10:44:37 --> Language Class Initialized
INFO - 2024-03-15 10:44:37 --> Config Class Initialized
INFO - 2024-03-15 10:44:37 --> Loader Class Initialized
INFO - 2024-03-15 10:44:37 --> Helper loaded: url_helper
INFO - 2024-03-15 10:44:37 --> Helper loaded: file_helper
INFO - 2024-03-15 10:44:37 --> Helper loaded: form_helper
INFO - 2024-03-15 10:44:37 --> Helper loaded: my_helper
INFO - 2024-03-15 10:44:37 --> Database Driver Class Initialized
INFO - 2024-03-15 10:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:44:37 --> Controller Class Initialized
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 10:44:37 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 10:44:37 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-15 10:44:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-15 10:44:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-15 10:44:41 --> Final output sent to browser
DEBUG - 2024-03-15 10:44:41 --> Total execution time: 3.4923
INFO - 2024-03-15 10:57:13 --> Config Class Initialized
INFO - 2024-03-15 10:57:13 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:13 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:13 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:13 --> URI Class Initialized
INFO - 2024-03-15 10:57:13 --> Router Class Initialized
INFO - 2024-03-15 10:57:13 --> Output Class Initialized
INFO - 2024-03-15 10:57:13 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:13 --> Input Class Initialized
INFO - 2024-03-15 10:57:13 --> Language Class Initialized
INFO - 2024-03-15 10:57:13 --> Language Class Initialized
INFO - 2024-03-15 10:57:13 --> Config Class Initialized
INFO - 2024-03-15 10:57:13 --> Loader Class Initialized
INFO - 2024-03-15 10:57:13 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:13 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:13 --> Controller Class Initialized
DEBUG - 2024-03-15 10:57:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-15 10:57:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:57:13 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:13 --> Total execution time: 0.0537
INFO - 2024-03-15 10:57:13 --> Config Class Initialized
INFO - 2024-03-15 10:57:13 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:13 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:13 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:13 --> URI Class Initialized
INFO - 2024-03-15 10:57:13 --> Router Class Initialized
INFO - 2024-03-15 10:57:13 --> Output Class Initialized
INFO - 2024-03-15 10:57:13 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:13 --> Input Class Initialized
INFO - 2024-03-15 10:57:13 --> Language Class Initialized
INFO - 2024-03-15 10:57:13 --> Language Class Initialized
INFO - 2024-03-15 10:57:13 --> Config Class Initialized
INFO - 2024-03-15 10:57:13 --> Loader Class Initialized
INFO - 2024-03-15 10:57:13 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:13 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:13 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:13 --> Controller Class Initialized
INFO - 2024-03-15 10:57:17 --> Config Class Initialized
INFO - 2024-03-15 10:57:17 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:17 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:17 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:17 --> URI Class Initialized
INFO - 2024-03-15 10:57:17 --> Router Class Initialized
INFO - 2024-03-15 10:57:17 --> Output Class Initialized
INFO - 2024-03-15 10:57:17 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:17 --> Input Class Initialized
INFO - 2024-03-15 10:57:17 --> Language Class Initialized
INFO - 2024-03-15 10:57:17 --> Language Class Initialized
INFO - 2024-03-15 10:57:17 --> Config Class Initialized
INFO - 2024-03-15 10:57:17 --> Loader Class Initialized
INFO - 2024-03-15 10:57:17 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:17 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:17 --> Controller Class Initialized
INFO - 2024-03-15 10:57:17 --> Config Class Initialized
INFO - 2024-03-15 10:57:17 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:17 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:17 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:17 --> URI Class Initialized
INFO - 2024-03-15 10:57:17 --> Router Class Initialized
INFO - 2024-03-15 10:57:17 --> Output Class Initialized
INFO - 2024-03-15 10:57:17 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:17 --> Input Class Initialized
INFO - 2024-03-15 10:57:17 --> Language Class Initialized
INFO - 2024-03-15 10:57:17 --> Language Class Initialized
INFO - 2024-03-15 10:57:17 --> Config Class Initialized
INFO - 2024-03-15 10:57:17 --> Loader Class Initialized
INFO - 2024-03-15 10:57:17 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:17 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:17 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:17 --> Controller Class Initialized
DEBUG - 2024-03-15 10:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 10:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:57:17 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:17 --> Total execution time: 0.0295
INFO - 2024-03-15 10:57:25 --> Config Class Initialized
INFO - 2024-03-15 10:57:25 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:25 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:25 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:25 --> URI Class Initialized
INFO - 2024-03-15 10:57:25 --> Router Class Initialized
INFO - 2024-03-15 10:57:25 --> Output Class Initialized
INFO - 2024-03-15 10:57:25 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:25 --> Input Class Initialized
INFO - 2024-03-15 10:57:25 --> Language Class Initialized
INFO - 2024-03-15 10:57:25 --> Language Class Initialized
INFO - 2024-03-15 10:57:25 --> Config Class Initialized
INFO - 2024-03-15 10:57:25 --> Loader Class Initialized
INFO - 2024-03-15 10:57:25 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:25 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:25 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:25 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:25 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:25 --> Controller Class Initialized
DEBUG - 2024-03-15 10:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 10:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:57:25 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:25 --> Total execution time: 0.0400
INFO - 2024-03-15 10:57:26 --> Config Class Initialized
INFO - 2024-03-15 10:57:26 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:26 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:26 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:26 --> URI Class Initialized
INFO - 2024-03-15 10:57:26 --> Router Class Initialized
INFO - 2024-03-15 10:57:26 --> Output Class Initialized
INFO - 2024-03-15 10:57:26 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:26 --> Input Class Initialized
INFO - 2024-03-15 10:57:26 --> Language Class Initialized
INFO - 2024-03-15 10:57:26 --> Language Class Initialized
INFO - 2024-03-15 10:57:26 --> Config Class Initialized
INFO - 2024-03-15 10:57:26 --> Loader Class Initialized
INFO - 2024-03-15 10:57:26 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:26 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:26 --> Controller Class Initialized
INFO - 2024-03-15 10:57:26 --> Helper loaded: cookie_helper
INFO - 2024-03-15 10:57:26 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:26 --> Total execution time: 0.0355
INFO - 2024-03-15 10:57:26 --> Config Class Initialized
INFO - 2024-03-15 10:57:26 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:26 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:26 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:26 --> URI Class Initialized
INFO - 2024-03-15 10:57:26 --> Router Class Initialized
INFO - 2024-03-15 10:57:26 --> Output Class Initialized
INFO - 2024-03-15 10:57:26 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:26 --> Input Class Initialized
INFO - 2024-03-15 10:57:26 --> Language Class Initialized
INFO - 2024-03-15 10:57:26 --> Language Class Initialized
INFO - 2024-03-15 10:57:26 --> Config Class Initialized
INFO - 2024-03-15 10:57:26 --> Loader Class Initialized
INFO - 2024-03-15 10:57:26 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:26 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:26 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:26 --> Controller Class Initialized
DEBUG - 2024-03-15 10:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 10:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:57:26 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:26 --> Total execution time: 0.0412
INFO - 2024-03-15 10:57:38 --> Config Class Initialized
INFO - 2024-03-15 10:57:38 --> Hooks Class Initialized
DEBUG - 2024-03-15 10:57:38 --> UTF-8 Support Enabled
INFO - 2024-03-15 10:57:38 --> Utf8 Class Initialized
INFO - 2024-03-15 10:57:38 --> URI Class Initialized
INFO - 2024-03-15 10:57:38 --> Router Class Initialized
INFO - 2024-03-15 10:57:38 --> Output Class Initialized
INFO - 2024-03-15 10:57:38 --> Security Class Initialized
DEBUG - 2024-03-15 10:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 10:57:38 --> Input Class Initialized
INFO - 2024-03-15 10:57:38 --> Language Class Initialized
INFO - 2024-03-15 10:57:38 --> Language Class Initialized
INFO - 2024-03-15 10:57:38 --> Config Class Initialized
INFO - 2024-03-15 10:57:38 --> Loader Class Initialized
INFO - 2024-03-15 10:57:38 --> Helper loaded: url_helper
INFO - 2024-03-15 10:57:38 --> Helper loaded: file_helper
INFO - 2024-03-15 10:57:38 --> Helper loaded: form_helper
INFO - 2024-03-15 10:57:38 --> Helper loaded: my_helper
INFO - 2024-03-15 10:57:38 --> Database Driver Class Initialized
INFO - 2024-03-15 10:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 10:57:38 --> Controller Class Initialized
DEBUG - 2024-03-15 10:57:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 10:57:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 10:57:38 --> Final output sent to browser
DEBUG - 2024-03-15 10:57:38 --> Total execution time: 0.0401
INFO - 2024-03-15 11:02:05 --> Config Class Initialized
INFO - 2024-03-15 11:02:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 11:02:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 11:02:05 --> Utf8 Class Initialized
INFO - 2024-03-15 11:02:05 --> URI Class Initialized
INFO - 2024-03-15 11:02:05 --> Router Class Initialized
INFO - 2024-03-15 11:02:05 --> Output Class Initialized
INFO - 2024-03-15 11:02:05 --> Security Class Initialized
DEBUG - 2024-03-15 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 11:02:05 --> Input Class Initialized
INFO - 2024-03-15 11:02:05 --> Language Class Initialized
INFO - 2024-03-15 11:02:05 --> Language Class Initialized
INFO - 2024-03-15 11:02:05 --> Config Class Initialized
INFO - 2024-03-15 11:02:05 --> Loader Class Initialized
INFO - 2024-03-15 11:02:05 --> Helper loaded: url_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: file_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: form_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: my_helper
INFO - 2024-03-15 11:02:05 --> Database Driver Class Initialized
INFO - 2024-03-15 11:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 11:02:05 --> Controller Class Initialized
INFO - 2024-03-15 11:02:05 --> Helper loaded: cookie_helper
INFO - 2024-03-15 11:02:05 --> Final output sent to browser
DEBUG - 2024-03-15 11:02:05 --> Total execution time: 0.0917
INFO - 2024-03-15 11:02:05 --> Config Class Initialized
INFO - 2024-03-15 11:02:05 --> Hooks Class Initialized
DEBUG - 2024-03-15 11:02:05 --> UTF-8 Support Enabled
INFO - 2024-03-15 11:02:05 --> Utf8 Class Initialized
INFO - 2024-03-15 11:02:05 --> URI Class Initialized
INFO - 2024-03-15 11:02:05 --> Router Class Initialized
INFO - 2024-03-15 11:02:05 --> Output Class Initialized
INFO - 2024-03-15 11:02:05 --> Security Class Initialized
DEBUG - 2024-03-15 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 11:02:05 --> Input Class Initialized
INFO - 2024-03-15 11:02:05 --> Language Class Initialized
INFO - 2024-03-15 11:02:05 --> Language Class Initialized
INFO - 2024-03-15 11:02:05 --> Config Class Initialized
INFO - 2024-03-15 11:02:05 --> Loader Class Initialized
INFO - 2024-03-15 11:02:05 --> Helper loaded: url_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: file_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: form_helper
INFO - 2024-03-15 11:02:05 --> Helper loaded: my_helper
INFO - 2024-03-15 11:02:05 --> Database Driver Class Initialized
INFO - 2024-03-15 11:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 11:02:05 --> Controller Class Initialized
DEBUG - 2024-03-15 11:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-15 11:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 11:02:05 --> Final output sent to browser
DEBUG - 2024-03-15 11:02:05 --> Total execution time: 0.0431
INFO - 2024-03-15 11:02:10 --> Config Class Initialized
INFO - 2024-03-15 11:02:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 11:02:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 11:02:10 --> Utf8 Class Initialized
INFO - 2024-03-15 11:02:10 --> URI Class Initialized
INFO - 2024-03-15 11:02:10 --> Router Class Initialized
INFO - 2024-03-15 11:02:10 --> Output Class Initialized
INFO - 2024-03-15 11:02:10 --> Security Class Initialized
DEBUG - 2024-03-15 11:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 11:02:10 --> Input Class Initialized
INFO - 2024-03-15 11:02:10 --> Language Class Initialized
INFO - 2024-03-15 11:02:10 --> Language Class Initialized
INFO - 2024-03-15 11:02:10 --> Config Class Initialized
INFO - 2024-03-15 11:02:10 --> Loader Class Initialized
INFO - 2024-03-15 11:02:10 --> Helper loaded: url_helper
INFO - 2024-03-15 11:02:10 --> Helper loaded: file_helper
INFO - 2024-03-15 11:02:10 --> Helper loaded: form_helper
INFO - 2024-03-15 11:02:10 --> Helper loaded: my_helper
INFO - 2024-03-15 11:02:10 --> Database Driver Class Initialized
INFO - 2024-03-15 11:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 11:02:10 --> Controller Class Initialized
DEBUG - 2024-03-15 11:02:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-03-15 11:02:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 11:02:10 --> Final output sent to browser
DEBUG - 2024-03-15 11:02:10 --> Total execution time: 0.0468
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 14:23:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 14:23:10 --> Utf8 Class Initialized
INFO - 2024-03-15 14:23:10 --> URI Class Initialized
INFO - 2024-03-15 14:23:10 --> Router Class Initialized
INFO - 2024-03-15 14:23:10 --> Output Class Initialized
INFO - 2024-03-15 14:23:10 --> Security Class Initialized
DEBUG - 2024-03-15 14:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 14:23:10 --> Input Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Loader Class Initialized
INFO - 2024-03-15 14:23:10 --> Helper loaded: url_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: file_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: form_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: my_helper
INFO - 2024-03-15 14:23:10 --> Database Driver Class Initialized
INFO - 2024-03-15 14:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 14:23:10 --> Controller Class Initialized
INFO - 2024-03-15 14:23:10 --> Helper loaded: cookie_helper
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 14:23:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 14:23:10 --> Utf8 Class Initialized
INFO - 2024-03-15 14:23:10 --> URI Class Initialized
INFO - 2024-03-15 14:23:10 --> Router Class Initialized
INFO - 2024-03-15 14:23:10 --> Output Class Initialized
INFO - 2024-03-15 14:23:10 --> Security Class Initialized
DEBUG - 2024-03-15 14:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 14:23:10 --> Input Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Loader Class Initialized
INFO - 2024-03-15 14:23:10 --> Helper loaded: url_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: file_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: form_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: my_helper
INFO - 2024-03-15 14:23:10 --> Database Driver Class Initialized
INFO - 2024-03-15 14:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 14:23:10 --> Controller Class Initialized
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Hooks Class Initialized
DEBUG - 2024-03-15 14:23:10 --> UTF-8 Support Enabled
INFO - 2024-03-15 14:23:10 --> Utf8 Class Initialized
INFO - 2024-03-15 14:23:10 --> URI Class Initialized
INFO - 2024-03-15 14:23:10 --> Router Class Initialized
INFO - 2024-03-15 14:23:10 --> Output Class Initialized
INFO - 2024-03-15 14:23:10 --> Security Class Initialized
DEBUG - 2024-03-15 14:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 14:23:10 --> Input Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Language Class Initialized
INFO - 2024-03-15 14:23:10 --> Config Class Initialized
INFO - 2024-03-15 14:23:10 --> Loader Class Initialized
INFO - 2024-03-15 14:23:10 --> Helper loaded: url_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: file_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: form_helper
INFO - 2024-03-15 14:23:10 --> Helper loaded: my_helper
INFO - 2024-03-15 14:23:10 --> Database Driver Class Initialized
INFO - 2024-03-15 14:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 14:23:10 --> Controller Class Initialized
DEBUG - 2024-03-15 14:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-15 14:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 14:23:10 --> Final output sent to browser
DEBUG - 2024-03-15 14:23:10 --> Total execution time: 0.0470
INFO - 2024-03-15 15:06:27 --> Config Class Initialized
INFO - 2024-03-15 15:06:27 --> Hooks Class Initialized
DEBUG - 2024-03-15 15:06:27 --> UTF-8 Support Enabled
INFO - 2024-03-15 15:06:27 --> Utf8 Class Initialized
INFO - 2024-03-15 15:06:27 --> URI Class Initialized
INFO - 2024-03-15 15:06:27 --> Router Class Initialized
INFO - 2024-03-15 15:06:27 --> Output Class Initialized
INFO - 2024-03-15 15:06:27 --> Security Class Initialized
DEBUG - 2024-03-15 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 15:06:27 --> Input Class Initialized
INFO - 2024-03-15 15:06:27 --> Language Class Initialized
INFO - 2024-03-15 15:06:27 --> Language Class Initialized
INFO - 2024-03-15 15:06:27 --> Config Class Initialized
INFO - 2024-03-15 15:06:27 --> Loader Class Initialized
INFO - 2024-03-15 15:06:27 --> Helper loaded: url_helper
INFO - 2024-03-15 15:06:27 --> Helper loaded: file_helper
INFO - 2024-03-15 15:06:27 --> Helper loaded: form_helper
INFO - 2024-03-15 15:06:27 --> Helper loaded: my_helper
INFO - 2024-03-15 15:06:28 --> Database Driver Class Initialized
INFO - 2024-03-15 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 15:06:28 --> Controller Class Initialized
ERROR - 2024-03-15 15:06:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2389
DEBUG - 2024-03-15 15:06:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-15 15:06:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 15:06:28 --> Final output sent to browser
DEBUG - 2024-03-15 15:06:28 --> Total execution time: 0.0715
INFO - 2024-03-15 15:13:07 --> Config Class Initialized
INFO - 2024-03-15 15:13:07 --> Hooks Class Initialized
DEBUG - 2024-03-15 15:13:07 --> UTF-8 Support Enabled
INFO - 2024-03-15 15:13:07 --> Utf8 Class Initialized
INFO - 2024-03-15 15:13:07 --> URI Class Initialized
INFO - 2024-03-15 15:13:07 --> Router Class Initialized
INFO - 2024-03-15 15:13:07 --> Output Class Initialized
INFO - 2024-03-15 15:13:07 --> Security Class Initialized
DEBUG - 2024-03-15 15:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-15 15:13:07 --> Input Class Initialized
INFO - 2024-03-15 15:13:07 --> Language Class Initialized
INFO - 2024-03-15 15:13:07 --> Language Class Initialized
INFO - 2024-03-15 15:13:07 --> Config Class Initialized
INFO - 2024-03-15 15:13:07 --> Loader Class Initialized
INFO - 2024-03-15 15:13:07 --> Helper loaded: url_helper
INFO - 2024-03-15 15:13:07 --> Helper loaded: file_helper
INFO - 2024-03-15 15:13:07 --> Helper loaded: form_helper
INFO - 2024-03-15 15:13:07 --> Helper loaded: my_helper
INFO - 2024-03-15 15:13:07 --> Database Driver Class Initialized
INFO - 2024-03-15 15:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-15 15:13:07 --> Controller Class Initialized
ERROR - 2024-03-15 15:13:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2024-03-15 15:13:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-03-15 15:13:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-15 15:13:08 --> Final output sent to browser
DEBUG - 2024-03-15 15:13:08 --> Total execution time: 0.0659
