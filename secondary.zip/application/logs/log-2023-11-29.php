<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-29 11:39:51 --> Config Class Initialized
INFO - 2023-11-29 11:39:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:39:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:39:51 --> Utf8 Class Initialized
INFO - 2023-11-29 11:39:51 --> URI Class Initialized
INFO - 2023-11-29 11:39:51 --> Router Class Initialized
INFO - 2023-11-29 11:39:51 --> Output Class Initialized
INFO - 2023-11-29 11:39:51 --> Security Class Initialized
DEBUG - 2023-11-29 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:39:51 --> Input Class Initialized
INFO - 2023-11-29 11:39:51 --> Language Class Initialized
INFO - 2023-11-29 11:39:51 --> Language Class Initialized
INFO - 2023-11-29 11:39:51 --> Config Class Initialized
INFO - 2023-11-29 11:39:51 --> Loader Class Initialized
INFO - 2023-11-29 11:39:51 --> Helper loaded: url_helper
INFO - 2023-11-29 11:39:51 --> Helper loaded: file_helper
INFO - 2023-11-29 11:39:51 --> Helper loaded: form_helper
INFO - 2023-11-29 11:39:51 --> Helper loaded: my_helper
INFO - 2023-11-29 11:39:51 --> Database Driver Class Initialized
INFO - 2023-11-29 11:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:39:51 --> Controller Class Initialized
INFO - 2023-11-29 11:39:51 --> Config Class Initialized
INFO - 2023-11-29 11:39:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:39:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:39:51 --> Utf8 Class Initialized
INFO - 2023-11-29 11:39:51 --> URI Class Initialized
INFO - 2023-11-29 11:39:51 --> Router Class Initialized
INFO - 2023-11-29 11:39:51 --> Output Class Initialized
INFO - 2023-11-29 11:39:51 --> Security Class Initialized
DEBUG - 2023-11-29 11:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:39:51 --> Input Class Initialized
INFO - 2023-11-29 11:39:51 --> Language Class Initialized
INFO - 2023-11-29 11:39:51 --> Language Class Initialized
INFO - 2023-11-29 11:39:51 --> Config Class Initialized
INFO - 2023-11-29 11:39:51 --> Loader Class Initialized
INFO - 2023-11-29 11:39:52 --> Helper loaded: url_helper
INFO - 2023-11-29 11:39:52 --> Helper loaded: file_helper
INFO - 2023-11-29 11:39:52 --> Helper loaded: form_helper
INFO - 2023-11-29 11:39:52 --> Helper loaded: my_helper
INFO - 2023-11-29 11:39:52 --> Database Driver Class Initialized
INFO - 2023-11-29 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:39:52 --> Controller Class Initialized
DEBUG - 2023-11-29 11:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 11:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 11:39:52 --> Final output sent to browser
DEBUG - 2023-11-29 11:39:52 --> Total execution time: 0.0360
INFO - 2023-11-29 11:39:53 --> Config Class Initialized
INFO - 2023-11-29 11:39:53 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:39:53 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:39:53 --> Utf8 Class Initialized
INFO - 2023-11-29 11:39:53 --> URI Class Initialized
INFO - 2023-11-29 11:39:53 --> Router Class Initialized
INFO - 2023-11-29 11:39:53 --> Output Class Initialized
INFO - 2023-11-29 11:39:53 --> Security Class Initialized
DEBUG - 2023-11-29 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:39:53 --> Input Class Initialized
INFO - 2023-11-29 11:39:53 --> Language Class Initialized
INFO - 2023-11-29 11:39:53 --> Language Class Initialized
INFO - 2023-11-29 11:39:53 --> Config Class Initialized
INFO - 2023-11-29 11:39:53 --> Loader Class Initialized
INFO - 2023-11-29 11:39:53 --> Helper loaded: url_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: file_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: form_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: my_helper
INFO - 2023-11-29 11:39:53 --> Database Driver Class Initialized
INFO - 2023-11-29 11:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:39:53 --> Controller Class Initialized
INFO - 2023-11-29 11:39:53 --> Helper loaded: cookie_helper
INFO - 2023-11-29 11:39:53 --> Final output sent to browser
DEBUG - 2023-11-29 11:39:53 --> Total execution time: 0.0523
INFO - 2023-11-29 11:39:53 --> Config Class Initialized
INFO - 2023-11-29 11:39:53 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:39:53 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:39:53 --> Utf8 Class Initialized
INFO - 2023-11-29 11:39:53 --> URI Class Initialized
INFO - 2023-11-29 11:39:53 --> Router Class Initialized
INFO - 2023-11-29 11:39:53 --> Output Class Initialized
INFO - 2023-11-29 11:39:53 --> Security Class Initialized
DEBUG - 2023-11-29 11:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:39:53 --> Input Class Initialized
INFO - 2023-11-29 11:39:53 --> Language Class Initialized
INFO - 2023-11-29 11:39:53 --> Language Class Initialized
INFO - 2023-11-29 11:39:53 --> Config Class Initialized
INFO - 2023-11-29 11:39:53 --> Loader Class Initialized
INFO - 2023-11-29 11:39:53 --> Helper loaded: url_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: file_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: form_helper
INFO - 2023-11-29 11:39:53 --> Helper loaded: my_helper
INFO - 2023-11-29 11:39:53 --> Database Driver Class Initialized
INFO - 2023-11-29 11:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:39:53 --> Controller Class Initialized
DEBUG - 2023-11-29 11:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 11:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 11:39:53 --> Final output sent to browser
DEBUG - 2023-11-29 11:39:53 --> Total execution time: 0.0386
INFO - 2023-11-29 11:40:00 --> Config Class Initialized
INFO - 2023-11-29 11:40:00 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:40:00 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:40:00 --> Utf8 Class Initialized
INFO - 2023-11-29 11:40:00 --> URI Class Initialized
INFO - 2023-11-29 11:40:00 --> Router Class Initialized
INFO - 2023-11-29 11:40:00 --> Output Class Initialized
INFO - 2023-11-29 11:40:00 --> Security Class Initialized
DEBUG - 2023-11-29 11:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:40:00 --> Input Class Initialized
INFO - 2023-11-29 11:40:00 --> Language Class Initialized
INFO - 2023-11-29 11:40:00 --> Language Class Initialized
INFO - 2023-11-29 11:40:00 --> Config Class Initialized
INFO - 2023-11-29 11:40:00 --> Loader Class Initialized
INFO - 2023-11-29 11:40:00 --> Helper loaded: url_helper
INFO - 2023-11-29 11:40:00 --> Helper loaded: file_helper
INFO - 2023-11-29 11:40:00 --> Helper loaded: form_helper
INFO - 2023-11-29 11:40:00 --> Helper loaded: my_helper
INFO - 2023-11-29 11:40:00 --> Database Driver Class Initialized
INFO - 2023-11-29 11:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:40:00 --> Controller Class Initialized
DEBUG - 2023-11-29 11:40:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 11:40:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 11:40:00 --> Final output sent to browser
DEBUG - 2023-11-29 11:40:00 --> Total execution time: 0.0376
INFO - 2023-11-29 11:40:02 --> Config Class Initialized
INFO - 2023-11-29 11:40:02 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:40:02 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:40:02 --> Utf8 Class Initialized
INFO - 2023-11-29 11:40:02 --> URI Class Initialized
INFO - 2023-11-29 11:40:02 --> Router Class Initialized
INFO - 2023-11-29 11:40:02 --> Output Class Initialized
INFO - 2023-11-29 11:40:02 --> Security Class Initialized
DEBUG - 2023-11-29 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:40:02 --> Input Class Initialized
INFO - 2023-11-29 11:40:02 --> Language Class Initialized
INFO - 2023-11-29 11:40:02 --> Language Class Initialized
INFO - 2023-11-29 11:40:02 --> Config Class Initialized
INFO - 2023-11-29 11:40:02 --> Loader Class Initialized
INFO - 2023-11-29 11:40:02 --> Helper loaded: url_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: file_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: form_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: my_helper
INFO - 2023-11-29 11:40:02 --> Database Driver Class Initialized
INFO - 2023-11-29 11:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:40:02 --> Controller Class Initialized
DEBUG - 2023-11-29 11:40:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 11:40:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 11:40:02 --> Final output sent to browser
DEBUG - 2023-11-29 11:40:02 --> Total execution time: 0.0578
INFO - 2023-11-29 11:40:02 --> Config Class Initialized
INFO - 2023-11-29 11:40:02 --> Hooks Class Initialized
DEBUG - 2023-11-29 11:40:02 --> UTF-8 Support Enabled
INFO - 2023-11-29 11:40:02 --> Utf8 Class Initialized
INFO - 2023-11-29 11:40:02 --> URI Class Initialized
INFO - 2023-11-29 11:40:02 --> Router Class Initialized
INFO - 2023-11-29 11:40:02 --> Output Class Initialized
INFO - 2023-11-29 11:40:02 --> Security Class Initialized
DEBUG - 2023-11-29 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 11:40:02 --> Input Class Initialized
INFO - 2023-11-29 11:40:02 --> Language Class Initialized
INFO - 2023-11-29 11:40:02 --> Language Class Initialized
INFO - 2023-11-29 11:40:02 --> Config Class Initialized
INFO - 2023-11-29 11:40:02 --> Loader Class Initialized
INFO - 2023-11-29 11:40:02 --> Helper loaded: url_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: file_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: form_helper
INFO - 2023-11-29 11:40:02 --> Helper loaded: my_helper
INFO - 2023-11-29 11:40:02 --> Database Driver Class Initialized
INFO - 2023-11-29 11:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 11:40:02 --> Controller Class Initialized
INFO - 2023-11-29 12:18:24 --> Config Class Initialized
INFO - 2023-11-29 12:18:24 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:18:24 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:18:24 --> Utf8 Class Initialized
INFO - 2023-11-29 12:18:24 --> URI Class Initialized
INFO - 2023-11-29 12:18:24 --> Router Class Initialized
INFO - 2023-11-29 12:18:24 --> Output Class Initialized
INFO - 2023-11-29 12:18:25 --> Security Class Initialized
DEBUG - 2023-11-29 12:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:18:25 --> Input Class Initialized
INFO - 2023-11-29 12:18:25 --> Language Class Initialized
INFO - 2023-11-29 12:18:25 --> Language Class Initialized
INFO - 2023-11-29 12:18:25 --> Config Class Initialized
INFO - 2023-11-29 12:18:25 --> Loader Class Initialized
INFO - 2023-11-29 12:18:25 --> Helper loaded: url_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: file_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: form_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: my_helper
INFO - 2023-11-29 12:18:25 --> Database Driver Class Initialized
INFO - 2023-11-29 12:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:18:25 --> Controller Class Initialized
DEBUG - 2023-11-29 12:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 12:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:18:25 --> Final output sent to browser
DEBUG - 2023-11-29 12:18:25 --> Total execution time: 0.1531
INFO - 2023-11-29 12:18:25 --> Config Class Initialized
INFO - 2023-11-29 12:18:25 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:18:25 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:18:25 --> Utf8 Class Initialized
INFO - 2023-11-29 12:18:25 --> URI Class Initialized
INFO - 2023-11-29 12:18:25 --> Router Class Initialized
INFO - 2023-11-29 12:18:25 --> Output Class Initialized
INFO - 2023-11-29 12:18:25 --> Security Class Initialized
DEBUG - 2023-11-29 12:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:18:25 --> Input Class Initialized
INFO - 2023-11-29 12:18:25 --> Language Class Initialized
INFO - 2023-11-29 12:18:25 --> Language Class Initialized
INFO - 2023-11-29 12:18:25 --> Config Class Initialized
INFO - 2023-11-29 12:18:25 --> Loader Class Initialized
INFO - 2023-11-29 12:18:25 --> Helper loaded: url_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: file_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: form_helper
INFO - 2023-11-29 12:18:25 --> Helper loaded: my_helper
INFO - 2023-11-29 12:18:25 --> Database Driver Class Initialized
INFO - 2023-11-29 12:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:18:25 --> Controller Class Initialized
INFO - 2023-11-29 12:18:31 --> Config Class Initialized
INFO - 2023-11-29 12:18:31 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:18:31 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:18:31 --> Utf8 Class Initialized
INFO - 2023-11-29 12:18:31 --> URI Class Initialized
INFO - 2023-11-29 12:18:31 --> Router Class Initialized
INFO - 2023-11-29 12:18:31 --> Output Class Initialized
INFO - 2023-11-29 12:18:31 --> Security Class Initialized
DEBUG - 2023-11-29 12:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:18:31 --> Input Class Initialized
INFO - 2023-11-29 12:18:31 --> Language Class Initialized
INFO - 2023-11-29 12:18:31 --> Language Class Initialized
INFO - 2023-11-29 12:18:31 --> Config Class Initialized
INFO - 2023-11-29 12:18:31 --> Loader Class Initialized
INFO - 2023-11-29 12:18:31 --> Helper loaded: url_helper
INFO - 2023-11-29 12:18:31 --> Helper loaded: file_helper
INFO - 2023-11-29 12:18:31 --> Helper loaded: form_helper
INFO - 2023-11-29 12:18:31 --> Helper loaded: my_helper
INFO - 2023-11-29 12:18:31 --> Database Driver Class Initialized
INFO - 2023-11-29 12:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:18:31 --> Controller Class Initialized
INFO - 2023-11-29 12:18:31 --> Final output sent to browser
DEBUG - 2023-11-29 12:18:31 --> Total execution time: 0.0890
INFO - 2023-11-29 12:26:31 --> Config Class Initialized
INFO - 2023-11-29 12:26:31 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:31 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:31 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:31 --> URI Class Initialized
INFO - 2023-11-29 12:26:31 --> Router Class Initialized
INFO - 2023-11-29 12:26:31 --> Output Class Initialized
INFO - 2023-11-29 12:26:31 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:31 --> Input Class Initialized
INFO - 2023-11-29 12:26:31 --> Language Class Initialized
INFO - 2023-11-29 12:26:31 --> Language Class Initialized
INFO - 2023-11-29 12:26:31 --> Config Class Initialized
INFO - 2023-11-29 12:26:31 --> Loader Class Initialized
INFO - 2023-11-29 12:26:31 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:31 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:31 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:31 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:31 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:31 --> Controller Class Initialized
DEBUG - 2023-11-29 12:26:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-11-29 12:26:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:26:31 --> Final output sent to browser
DEBUG - 2023-11-29 12:26:31 --> Total execution time: 0.0869
INFO - 2023-11-29 12:26:45 --> Config Class Initialized
INFO - 2023-11-29 12:26:45 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:45 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:45 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:45 --> URI Class Initialized
INFO - 2023-11-29 12:26:45 --> Router Class Initialized
INFO - 2023-11-29 12:26:45 --> Output Class Initialized
INFO - 2023-11-29 12:26:45 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:45 --> Input Class Initialized
INFO - 2023-11-29 12:26:45 --> Language Class Initialized
INFO - 2023-11-29 12:26:45 --> Language Class Initialized
INFO - 2023-11-29 12:26:45 --> Config Class Initialized
INFO - 2023-11-29 12:26:45 --> Loader Class Initialized
INFO - 2023-11-29 12:26:45 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:45 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:45 --> Controller Class Initialized
INFO - 2023-11-29 12:26:45 --> Config Class Initialized
INFO - 2023-11-29 12:26:45 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:45 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:45 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:45 --> URI Class Initialized
INFO - 2023-11-29 12:26:45 --> Router Class Initialized
INFO - 2023-11-29 12:26:45 --> Output Class Initialized
INFO - 2023-11-29 12:26:45 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:45 --> Input Class Initialized
INFO - 2023-11-29 12:26:45 --> Language Class Initialized
INFO - 2023-11-29 12:26:45 --> Language Class Initialized
INFO - 2023-11-29 12:26:45 --> Config Class Initialized
INFO - 2023-11-29 12:26:45 --> Loader Class Initialized
INFO - 2023-11-29 12:26:45 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:45 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:45 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:45 --> Controller Class Initialized
DEBUG - 2023-11-29 12:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 12:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:26:45 --> Final output sent to browser
DEBUG - 2023-11-29 12:26:45 --> Total execution time: 0.0974
INFO - 2023-11-29 12:26:45 --> Config Class Initialized
INFO - 2023-11-29 12:26:45 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:45 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:45 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:45 --> URI Class Initialized
INFO - 2023-11-29 12:26:45 --> Router Class Initialized
INFO - 2023-11-29 12:26:45 --> Output Class Initialized
INFO - 2023-11-29 12:26:45 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:45 --> Input Class Initialized
INFO - 2023-11-29 12:26:45 --> Language Class Initialized
INFO - 2023-11-29 12:26:46 --> Language Class Initialized
INFO - 2023-11-29 12:26:46 --> Config Class Initialized
INFO - 2023-11-29 12:26:46 --> Loader Class Initialized
INFO - 2023-11-29 12:26:46 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:46 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:46 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:46 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:46 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:46 --> Controller Class Initialized
INFO - 2023-11-29 12:26:51 --> Config Class Initialized
INFO - 2023-11-29 12:26:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:51 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:51 --> URI Class Initialized
INFO - 2023-11-29 12:26:51 --> Router Class Initialized
INFO - 2023-11-29 12:26:51 --> Output Class Initialized
INFO - 2023-11-29 12:26:51 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:51 --> Input Class Initialized
INFO - 2023-11-29 12:26:51 --> Language Class Initialized
INFO - 2023-11-29 12:26:51 --> Language Class Initialized
INFO - 2023-11-29 12:26:51 --> Config Class Initialized
INFO - 2023-11-29 12:26:51 --> Loader Class Initialized
INFO - 2023-11-29 12:26:51 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:51 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:51 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:51 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:51 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:51 --> Controller Class Initialized
INFO - 2023-11-29 12:26:52 --> Final output sent to browser
DEBUG - 2023-11-29 12:26:52 --> Total execution time: 0.6083
INFO - 2023-11-29 12:26:56 --> Config Class Initialized
INFO - 2023-11-29 12:26:56 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:26:56 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:26:56 --> Utf8 Class Initialized
INFO - 2023-11-29 12:26:56 --> URI Class Initialized
INFO - 2023-11-29 12:26:56 --> Router Class Initialized
INFO - 2023-11-29 12:26:56 --> Output Class Initialized
INFO - 2023-11-29 12:26:56 --> Security Class Initialized
DEBUG - 2023-11-29 12:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:26:56 --> Input Class Initialized
INFO - 2023-11-29 12:26:56 --> Language Class Initialized
INFO - 2023-11-29 12:26:56 --> Language Class Initialized
INFO - 2023-11-29 12:26:56 --> Config Class Initialized
INFO - 2023-11-29 12:26:56 --> Loader Class Initialized
INFO - 2023-11-29 12:26:56 --> Helper loaded: url_helper
INFO - 2023-11-29 12:26:56 --> Helper loaded: file_helper
INFO - 2023-11-29 12:26:56 --> Helper loaded: form_helper
INFO - 2023-11-29 12:26:56 --> Helper loaded: my_helper
INFO - 2023-11-29 12:26:56 --> Database Driver Class Initialized
INFO - 2023-11-29 12:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:26:56 --> Controller Class Initialized
INFO - 2023-11-29 12:26:56 --> Final output sent to browser
DEBUG - 2023-11-29 12:26:56 --> Total execution time: 0.0481
INFO - 2023-11-29 12:27:00 --> Config Class Initialized
INFO - 2023-11-29 12:27:00 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:00 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:00 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:00 --> URI Class Initialized
INFO - 2023-11-29 12:27:00 --> Router Class Initialized
INFO - 2023-11-29 12:27:00 --> Output Class Initialized
INFO - 2023-11-29 12:27:00 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:00 --> Input Class Initialized
INFO - 2023-11-29 12:27:00 --> Language Class Initialized
INFO - 2023-11-29 12:27:00 --> Language Class Initialized
INFO - 2023-11-29 12:27:00 --> Config Class Initialized
INFO - 2023-11-29 12:27:00 --> Loader Class Initialized
INFO - 2023-11-29 12:27:00 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:00 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:00 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:00 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:00 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:00 --> Controller Class Initialized
INFO - 2023-11-29 12:27:00 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:00 --> Total execution time: 0.0434
INFO - 2023-11-29 12:27:05 --> Config Class Initialized
INFO - 2023-11-29 12:27:05 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:05 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:05 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:05 --> URI Class Initialized
INFO - 2023-11-29 12:27:05 --> Router Class Initialized
INFO - 2023-11-29 12:27:05 --> Output Class Initialized
INFO - 2023-11-29 12:27:05 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:05 --> Input Class Initialized
INFO - 2023-11-29 12:27:05 --> Language Class Initialized
INFO - 2023-11-29 12:27:05 --> Language Class Initialized
INFO - 2023-11-29 12:27:05 --> Config Class Initialized
INFO - 2023-11-29 12:27:05 --> Loader Class Initialized
INFO - 2023-11-29 12:27:05 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:05 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:05 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:05 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:05 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:06 --> Controller Class Initialized
INFO - 2023-11-29 12:27:06 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:06 --> Total execution time: 0.0553
INFO - 2023-11-29 12:27:08 --> Config Class Initialized
INFO - 2023-11-29 12:27:08 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:08 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:08 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:08 --> URI Class Initialized
INFO - 2023-11-29 12:27:08 --> Router Class Initialized
INFO - 2023-11-29 12:27:08 --> Output Class Initialized
INFO - 2023-11-29 12:27:08 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:08 --> Input Class Initialized
INFO - 2023-11-29 12:27:08 --> Language Class Initialized
INFO - 2023-11-29 12:27:08 --> Language Class Initialized
INFO - 2023-11-29 12:27:08 --> Config Class Initialized
INFO - 2023-11-29 12:27:08 --> Loader Class Initialized
INFO - 2023-11-29 12:27:08 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:08 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:08 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:08 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:08 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:08 --> Controller Class Initialized
DEBUG - 2023-11-29 12:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 12:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:27:08 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:08 --> Total execution time: 0.0363
INFO - 2023-11-29 12:27:09 --> Config Class Initialized
INFO - 2023-11-29 12:27:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:09 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:09 --> URI Class Initialized
INFO - 2023-11-29 12:27:09 --> Router Class Initialized
INFO - 2023-11-29 12:27:09 --> Output Class Initialized
INFO - 2023-11-29 12:27:09 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:09 --> Input Class Initialized
INFO - 2023-11-29 12:27:09 --> Language Class Initialized
INFO - 2023-11-29 12:27:09 --> Language Class Initialized
INFO - 2023-11-29 12:27:09 --> Config Class Initialized
INFO - 2023-11-29 12:27:09 --> Loader Class Initialized
INFO - 2023-11-29 12:27:09 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:09 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:09 --> Controller Class Initialized
DEBUG - 2023-11-29 12:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 12:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:27:09 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:09 --> Total execution time: 0.0364
INFO - 2023-11-29 12:27:09 --> Config Class Initialized
INFO - 2023-11-29 12:27:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:09 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:09 --> URI Class Initialized
INFO - 2023-11-29 12:27:09 --> Router Class Initialized
INFO - 2023-11-29 12:27:09 --> Output Class Initialized
INFO - 2023-11-29 12:27:09 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:09 --> Input Class Initialized
INFO - 2023-11-29 12:27:09 --> Language Class Initialized
INFO - 2023-11-29 12:27:09 --> Language Class Initialized
INFO - 2023-11-29 12:27:09 --> Config Class Initialized
INFO - 2023-11-29 12:27:09 --> Loader Class Initialized
INFO - 2023-11-29 12:27:09 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:09 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:09 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:09 --> Controller Class Initialized
INFO - 2023-11-29 12:27:12 --> Config Class Initialized
INFO - 2023-11-29 12:27:12 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:12 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:12 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:12 --> URI Class Initialized
INFO - 2023-11-29 12:27:12 --> Router Class Initialized
INFO - 2023-11-29 12:27:12 --> Output Class Initialized
INFO - 2023-11-29 12:27:12 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:12 --> Input Class Initialized
INFO - 2023-11-29 12:27:12 --> Language Class Initialized
INFO - 2023-11-29 12:27:12 --> Language Class Initialized
INFO - 2023-11-29 12:27:12 --> Config Class Initialized
INFO - 2023-11-29 12:27:12 --> Loader Class Initialized
INFO - 2023-11-29 12:27:12 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:12 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:12 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:12 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:12 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:12 --> Controller Class Initialized
INFO - 2023-11-29 12:27:12 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:12 --> Total execution time: 0.0492
INFO - 2023-11-29 12:27:14 --> Config Class Initialized
INFO - 2023-11-29 12:27:14 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:14 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:14 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:14 --> URI Class Initialized
INFO - 2023-11-29 12:27:14 --> Router Class Initialized
INFO - 2023-11-29 12:27:14 --> Output Class Initialized
INFO - 2023-11-29 12:27:14 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:14 --> Input Class Initialized
INFO - 2023-11-29 12:27:14 --> Language Class Initialized
INFO - 2023-11-29 12:27:14 --> Language Class Initialized
INFO - 2023-11-29 12:27:14 --> Config Class Initialized
INFO - 2023-11-29 12:27:14 --> Loader Class Initialized
INFO - 2023-11-29 12:27:14 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:14 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:14 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:14 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:14 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:14 --> Controller Class Initialized
DEBUG - 2023-11-29 12:27:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 12:27:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:27:14 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:14 --> Total execution time: 0.1027
INFO - 2023-11-29 12:27:16 --> Config Class Initialized
INFO - 2023-11-29 12:27:16 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:16 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:16 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:16 --> URI Class Initialized
INFO - 2023-11-29 12:27:16 --> Router Class Initialized
INFO - 2023-11-29 12:27:16 --> Output Class Initialized
INFO - 2023-11-29 12:27:16 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:16 --> Input Class Initialized
INFO - 2023-11-29 12:27:16 --> Language Class Initialized
INFO - 2023-11-29 12:27:16 --> Language Class Initialized
INFO - 2023-11-29 12:27:16 --> Config Class Initialized
INFO - 2023-11-29 12:27:16 --> Loader Class Initialized
INFO - 2023-11-29 12:27:16 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:16 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:16 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:16 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:16 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:16 --> Controller Class Initialized
DEBUG - 2023-11-29 12:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 12:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 12:27:16 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:16 --> Total execution time: 0.0911
INFO - 2023-11-29 12:27:16 --> Config Class Initialized
INFO - 2023-11-29 12:27:16 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:16 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:16 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:16 --> URI Class Initialized
INFO - 2023-11-29 12:27:16 --> Router Class Initialized
INFO - 2023-11-29 12:27:16 --> Output Class Initialized
INFO - 2023-11-29 12:27:16 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:16 --> Input Class Initialized
INFO - 2023-11-29 12:27:16 --> Language Class Initialized
INFO - 2023-11-29 12:27:17 --> Language Class Initialized
INFO - 2023-11-29 12:27:17 --> Config Class Initialized
INFO - 2023-11-29 12:27:17 --> Loader Class Initialized
INFO - 2023-11-29 12:27:17 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:17 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:17 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:17 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:17 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:17 --> Controller Class Initialized
INFO - 2023-11-29 12:27:19 --> Config Class Initialized
INFO - 2023-11-29 12:27:19 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:27:19 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:27:19 --> Utf8 Class Initialized
INFO - 2023-11-29 12:27:19 --> URI Class Initialized
INFO - 2023-11-29 12:27:19 --> Router Class Initialized
INFO - 2023-11-29 12:27:19 --> Output Class Initialized
INFO - 2023-11-29 12:27:19 --> Security Class Initialized
DEBUG - 2023-11-29 12:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:27:19 --> Input Class Initialized
INFO - 2023-11-29 12:27:19 --> Language Class Initialized
INFO - 2023-11-29 12:27:19 --> Language Class Initialized
INFO - 2023-11-29 12:27:19 --> Config Class Initialized
INFO - 2023-11-29 12:27:19 --> Loader Class Initialized
INFO - 2023-11-29 12:27:19 --> Helper loaded: url_helper
INFO - 2023-11-29 12:27:19 --> Helper loaded: file_helper
INFO - 2023-11-29 12:27:19 --> Helper loaded: form_helper
INFO - 2023-11-29 12:27:19 --> Helper loaded: my_helper
INFO - 2023-11-29 12:27:19 --> Database Driver Class Initialized
INFO - 2023-11-29 12:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:27:19 --> Controller Class Initialized
INFO - 2023-11-29 12:27:19 --> Final output sent to browser
DEBUG - 2023-11-29 12:27:19 --> Total execution time: 0.0485
INFO - 2023-11-29 12:29:03 --> Config Class Initialized
INFO - 2023-11-29 12:29:03 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:03 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:03 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:03 --> URI Class Initialized
INFO - 2023-11-29 12:29:03 --> Router Class Initialized
INFO - 2023-11-29 12:29:03 --> Output Class Initialized
INFO - 2023-11-29 12:29:03 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:03 --> Input Class Initialized
INFO - 2023-11-29 12:29:03 --> Language Class Initialized
INFO - 2023-11-29 12:29:03 --> Language Class Initialized
INFO - 2023-11-29 12:29:03 --> Config Class Initialized
INFO - 2023-11-29 12:29:03 --> Loader Class Initialized
INFO - 2023-11-29 12:29:03 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:03 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:03 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:03 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:03 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:03 --> Controller Class Initialized
INFO - 2023-11-29 12:29:03 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:03 --> Total execution time: 0.1261
INFO - 2023-11-29 12:29:13 --> Config Class Initialized
INFO - 2023-11-29 12:29:13 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:13 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:13 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:13 --> URI Class Initialized
INFO - 2023-11-29 12:29:13 --> Router Class Initialized
INFO - 2023-11-29 12:29:13 --> Output Class Initialized
INFO - 2023-11-29 12:29:13 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:13 --> Input Class Initialized
INFO - 2023-11-29 12:29:13 --> Language Class Initialized
INFO - 2023-11-29 12:29:13 --> Language Class Initialized
INFO - 2023-11-29 12:29:13 --> Config Class Initialized
INFO - 2023-11-29 12:29:13 --> Loader Class Initialized
INFO - 2023-11-29 12:29:13 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:13 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:13 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:13 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:13 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:13 --> Controller Class Initialized
INFO - 2023-11-29 12:29:13 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:13 --> Total execution time: 0.0697
INFO - 2023-11-29 12:29:22 --> Config Class Initialized
INFO - 2023-11-29 12:29:22 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:22 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:22 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:22 --> URI Class Initialized
INFO - 2023-11-29 12:29:22 --> Router Class Initialized
INFO - 2023-11-29 12:29:22 --> Output Class Initialized
INFO - 2023-11-29 12:29:22 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:22 --> Input Class Initialized
INFO - 2023-11-29 12:29:22 --> Language Class Initialized
INFO - 2023-11-29 12:29:22 --> Language Class Initialized
INFO - 2023-11-29 12:29:22 --> Config Class Initialized
INFO - 2023-11-29 12:29:22 --> Loader Class Initialized
INFO - 2023-11-29 12:29:22 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:22 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:22 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:22 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:22 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:22 --> Controller Class Initialized
INFO - 2023-11-29 12:29:22 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:22 --> Total execution time: 0.1506
INFO - 2023-11-29 12:29:33 --> Config Class Initialized
INFO - 2023-11-29 12:29:33 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:33 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:33 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:33 --> URI Class Initialized
INFO - 2023-11-29 12:29:33 --> Router Class Initialized
INFO - 2023-11-29 12:29:33 --> Output Class Initialized
INFO - 2023-11-29 12:29:33 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:33 --> Input Class Initialized
INFO - 2023-11-29 12:29:33 --> Language Class Initialized
INFO - 2023-11-29 12:29:33 --> Language Class Initialized
INFO - 2023-11-29 12:29:33 --> Config Class Initialized
INFO - 2023-11-29 12:29:33 --> Loader Class Initialized
INFO - 2023-11-29 12:29:33 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:33 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:33 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:33 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:33 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:33 --> Controller Class Initialized
INFO - 2023-11-29 12:29:33 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:33 --> Total execution time: 0.0457
INFO - 2023-11-29 12:29:39 --> Config Class Initialized
INFO - 2023-11-29 12:29:39 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:39 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:39 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:39 --> URI Class Initialized
INFO - 2023-11-29 12:29:39 --> Router Class Initialized
INFO - 2023-11-29 12:29:39 --> Output Class Initialized
INFO - 2023-11-29 12:29:39 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:39 --> Input Class Initialized
INFO - 2023-11-29 12:29:39 --> Language Class Initialized
INFO - 2023-11-29 12:29:39 --> Language Class Initialized
INFO - 2023-11-29 12:29:39 --> Config Class Initialized
INFO - 2023-11-29 12:29:39 --> Loader Class Initialized
INFO - 2023-11-29 12:29:39 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:39 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:39 --> Controller Class Initialized
INFO - 2023-11-29 12:29:39 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:39 --> Total execution time: 0.0389
INFO - 2023-11-29 12:29:39 --> Config Class Initialized
INFO - 2023-11-29 12:29:39 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:39 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:39 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:39 --> URI Class Initialized
INFO - 2023-11-29 12:29:39 --> Router Class Initialized
INFO - 2023-11-29 12:29:39 --> Output Class Initialized
INFO - 2023-11-29 12:29:39 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:39 --> Input Class Initialized
INFO - 2023-11-29 12:29:39 --> Language Class Initialized
INFO - 2023-11-29 12:29:39 --> Language Class Initialized
INFO - 2023-11-29 12:29:39 --> Config Class Initialized
INFO - 2023-11-29 12:29:39 --> Loader Class Initialized
INFO - 2023-11-29 12:29:39 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:39 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:39 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:39 --> Controller Class Initialized
INFO - 2023-11-29 12:29:49 --> Config Class Initialized
INFO - 2023-11-29 12:29:49 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:29:49 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:29:49 --> Utf8 Class Initialized
INFO - 2023-11-29 12:29:49 --> URI Class Initialized
INFO - 2023-11-29 12:29:49 --> Router Class Initialized
INFO - 2023-11-29 12:29:49 --> Output Class Initialized
INFO - 2023-11-29 12:29:49 --> Security Class Initialized
DEBUG - 2023-11-29 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:29:49 --> Input Class Initialized
INFO - 2023-11-29 12:29:49 --> Language Class Initialized
INFO - 2023-11-29 12:29:49 --> Language Class Initialized
INFO - 2023-11-29 12:29:49 --> Config Class Initialized
INFO - 2023-11-29 12:29:49 --> Loader Class Initialized
INFO - 2023-11-29 12:29:49 --> Helper loaded: url_helper
INFO - 2023-11-29 12:29:49 --> Helper loaded: file_helper
INFO - 2023-11-29 12:29:49 --> Helper loaded: form_helper
INFO - 2023-11-29 12:29:49 --> Helper loaded: my_helper
INFO - 2023-11-29 12:29:49 --> Database Driver Class Initialized
INFO - 2023-11-29 12:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:29:49 --> Controller Class Initialized
INFO - 2023-11-29 12:29:49 --> Final output sent to browser
DEBUG - 2023-11-29 12:29:49 --> Total execution time: 0.0493
INFO - 2023-11-29 12:30:03 --> Config Class Initialized
INFO - 2023-11-29 12:30:03 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:30:03 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:30:03 --> Utf8 Class Initialized
INFO - 2023-11-29 12:30:03 --> URI Class Initialized
INFO - 2023-11-29 12:30:03 --> Router Class Initialized
INFO - 2023-11-29 12:30:03 --> Output Class Initialized
INFO - 2023-11-29 12:30:03 --> Security Class Initialized
DEBUG - 2023-11-29 12:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:30:03 --> Input Class Initialized
INFO - 2023-11-29 12:30:03 --> Language Class Initialized
INFO - 2023-11-29 12:30:03 --> Language Class Initialized
INFO - 2023-11-29 12:30:03 --> Config Class Initialized
INFO - 2023-11-29 12:30:03 --> Loader Class Initialized
INFO - 2023-11-29 12:30:03 --> Helper loaded: url_helper
INFO - 2023-11-29 12:30:03 --> Helper loaded: file_helper
INFO - 2023-11-29 12:30:03 --> Helper loaded: form_helper
INFO - 2023-11-29 12:30:03 --> Helper loaded: my_helper
INFO - 2023-11-29 12:30:03 --> Database Driver Class Initialized
INFO - 2023-11-29 12:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:30:03 --> Controller Class Initialized
INFO - 2023-11-29 12:30:03 --> Final output sent to browser
DEBUG - 2023-11-29 12:30:03 --> Total execution time: 0.2074
INFO - 2023-11-29 12:30:04 --> Config Class Initialized
INFO - 2023-11-29 12:30:04 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:30:04 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:30:04 --> Utf8 Class Initialized
INFO - 2023-11-29 12:30:04 --> URI Class Initialized
INFO - 2023-11-29 12:30:04 --> Router Class Initialized
INFO - 2023-11-29 12:30:04 --> Output Class Initialized
INFO - 2023-11-29 12:30:04 --> Security Class Initialized
DEBUG - 2023-11-29 12:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:30:04 --> Input Class Initialized
INFO - 2023-11-29 12:30:04 --> Language Class Initialized
INFO - 2023-11-29 12:30:04 --> Language Class Initialized
INFO - 2023-11-29 12:30:04 --> Config Class Initialized
INFO - 2023-11-29 12:30:04 --> Loader Class Initialized
INFO - 2023-11-29 12:30:04 --> Helper loaded: url_helper
INFO - 2023-11-29 12:30:04 --> Helper loaded: file_helper
INFO - 2023-11-29 12:30:04 --> Helper loaded: form_helper
INFO - 2023-11-29 12:30:04 --> Helper loaded: my_helper
INFO - 2023-11-29 12:30:04 --> Database Driver Class Initialized
INFO - 2023-11-29 12:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:30:04 --> Controller Class Initialized
INFO - 2023-11-29 12:30:10 --> Config Class Initialized
INFO - 2023-11-29 12:30:10 --> Hooks Class Initialized
DEBUG - 2023-11-29 12:30:10 --> UTF-8 Support Enabled
INFO - 2023-11-29 12:30:10 --> Utf8 Class Initialized
INFO - 2023-11-29 12:30:10 --> URI Class Initialized
INFO - 2023-11-29 12:30:10 --> Router Class Initialized
INFO - 2023-11-29 12:30:10 --> Output Class Initialized
INFO - 2023-11-29 12:30:10 --> Security Class Initialized
DEBUG - 2023-11-29 12:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 12:30:10 --> Input Class Initialized
INFO - 2023-11-29 12:30:10 --> Language Class Initialized
INFO - 2023-11-29 12:30:10 --> Language Class Initialized
INFO - 2023-11-29 12:30:10 --> Config Class Initialized
INFO - 2023-11-29 12:30:10 --> Loader Class Initialized
INFO - 2023-11-29 12:30:10 --> Helper loaded: url_helper
INFO - 2023-11-29 12:30:10 --> Helper loaded: file_helper
INFO - 2023-11-29 12:30:10 --> Helper loaded: form_helper
INFO - 2023-11-29 12:30:10 --> Helper loaded: my_helper
INFO - 2023-11-29 12:30:10 --> Database Driver Class Initialized
INFO - 2023-11-29 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 12:30:10 --> Controller Class Initialized
INFO - 2023-11-29 14:19:40 --> Config Class Initialized
INFO - 2023-11-29 14:19:40 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:40 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:40 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:40 --> URI Class Initialized
INFO - 2023-11-29 14:19:40 --> Router Class Initialized
INFO - 2023-11-29 14:19:40 --> Output Class Initialized
INFO - 2023-11-29 14:19:40 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:40 --> Input Class Initialized
INFO - 2023-11-29 14:19:40 --> Language Class Initialized
INFO - 2023-11-29 14:19:40 --> Language Class Initialized
INFO - 2023-11-29 14:19:40 --> Config Class Initialized
INFO - 2023-11-29 14:19:40 --> Loader Class Initialized
INFO - 2023-11-29 14:19:40 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:40 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:40 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:40 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:40 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:40 --> Controller Class Initialized
DEBUG - 2023-11-29 14:19:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-11-29 14:19:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:19:40 --> Final output sent to browser
DEBUG - 2023-11-29 14:19:40 --> Total execution time: 0.0998
INFO - 2023-11-29 14:19:48 --> Config Class Initialized
INFO - 2023-11-29 14:19:48 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:48 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:48 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:48 --> URI Class Initialized
INFO - 2023-11-29 14:19:48 --> Router Class Initialized
INFO - 2023-11-29 14:19:48 --> Output Class Initialized
INFO - 2023-11-29 14:19:48 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:48 --> Input Class Initialized
INFO - 2023-11-29 14:19:48 --> Language Class Initialized
INFO - 2023-11-29 14:19:48 --> Language Class Initialized
INFO - 2023-11-29 14:19:48 --> Config Class Initialized
INFO - 2023-11-29 14:19:48 --> Loader Class Initialized
INFO - 2023-11-29 14:19:48 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:48 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:48 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:48 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:48 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:48 --> Controller Class Initialized
INFO - 2023-11-29 14:19:49 --> Config Class Initialized
INFO - 2023-11-29 14:19:49 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:49 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:49 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:49 --> URI Class Initialized
INFO - 2023-11-29 14:19:49 --> Router Class Initialized
INFO - 2023-11-29 14:19:49 --> Output Class Initialized
INFO - 2023-11-29 14:19:49 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:49 --> Input Class Initialized
INFO - 2023-11-29 14:19:49 --> Language Class Initialized
INFO - 2023-11-29 14:19:49 --> Language Class Initialized
INFO - 2023-11-29 14:19:49 --> Config Class Initialized
INFO - 2023-11-29 14:19:49 --> Loader Class Initialized
INFO - 2023-11-29 14:19:49 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:49 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:49 --> Controller Class Initialized
DEBUG - 2023-11-29 14:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 14:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:19:49 --> Final output sent to browser
DEBUG - 2023-11-29 14:19:49 --> Total execution time: 0.0506
INFO - 2023-11-29 14:19:49 --> Config Class Initialized
INFO - 2023-11-29 14:19:49 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:49 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:49 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:49 --> URI Class Initialized
INFO - 2023-11-29 14:19:49 --> Router Class Initialized
INFO - 2023-11-29 14:19:49 --> Output Class Initialized
INFO - 2023-11-29 14:19:49 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:49 --> Input Class Initialized
INFO - 2023-11-29 14:19:49 --> Language Class Initialized
INFO - 2023-11-29 14:19:49 --> Language Class Initialized
INFO - 2023-11-29 14:19:49 --> Config Class Initialized
INFO - 2023-11-29 14:19:49 --> Loader Class Initialized
INFO - 2023-11-29 14:19:49 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:49 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:49 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:49 --> Controller Class Initialized
INFO - 2023-11-29 14:19:51 --> Config Class Initialized
INFO - 2023-11-29 14:19:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:51 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:51 --> URI Class Initialized
INFO - 2023-11-29 14:19:51 --> Router Class Initialized
INFO - 2023-11-29 14:19:51 --> Output Class Initialized
INFO - 2023-11-29 14:19:51 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:51 --> Input Class Initialized
INFO - 2023-11-29 14:19:51 --> Language Class Initialized
INFO - 2023-11-29 14:19:51 --> Language Class Initialized
INFO - 2023-11-29 14:19:51 --> Config Class Initialized
INFO - 2023-11-29 14:19:51 --> Loader Class Initialized
INFO - 2023-11-29 14:19:51 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:51 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:51 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:51 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:51 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:51 --> Controller Class Initialized
INFO - 2023-11-29 14:19:51 --> Final output sent to browser
DEBUG - 2023-11-29 14:19:51 --> Total execution time: 0.0583
INFO - 2023-11-29 14:19:56 --> Config Class Initialized
INFO - 2023-11-29 14:19:56 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:19:56 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:19:56 --> Utf8 Class Initialized
INFO - 2023-11-29 14:19:56 --> URI Class Initialized
INFO - 2023-11-29 14:19:56 --> Router Class Initialized
INFO - 2023-11-29 14:19:56 --> Output Class Initialized
INFO - 2023-11-29 14:19:56 --> Security Class Initialized
DEBUG - 2023-11-29 14:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:19:56 --> Input Class Initialized
INFO - 2023-11-29 14:19:56 --> Language Class Initialized
INFO - 2023-11-29 14:19:56 --> Language Class Initialized
INFO - 2023-11-29 14:19:56 --> Config Class Initialized
INFO - 2023-11-29 14:19:56 --> Loader Class Initialized
INFO - 2023-11-29 14:19:56 --> Helper loaded: url_helper
INFO - 2023-11-29 14:19:56 --> Helper loaded: file_helper
INFO - 2023-11-29 14:19:56 --> Helper loaded: form_helper
INFO - 2023-11-29 14:19:56 --> Helper loaded: my_helper
INFO - 2023-11-29 14:19:56 --> Database Driver Class Initialized
INFO - 2023-11-29 14:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:19:56 --> Controller Class Initialized
INFO - 2023-11-29 14:19:56 --> Final output sent to browser
DEBUG - 2023-11-29 14:19:56 --> Total execution time: 0.0446
INFO - 2023-11-29 14:20:00 --> Config Class Initialized
INFO - 2023-11-29 14:20:00 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:00 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:00 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:00 --> URI Class Initialized
INFO - 2023-11-29 14:20:00 --> Router Class Initialized
INFO - 2023-11-29 14:20:00 --> Output Class Initialized
INFO - 2023-11-29 14:20:00 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:00 --> Input Class Initialized
INFO - 2023-11-29 14:20:00 --> Language Class Initialized
INFO - 2023-11-29 14:20:00 --> Language Class Initialized
INFO - 2023-11-29 14:20:00 --> Config Class Initialized
INFO - 2023-11-29 14:20:00 --> Loader Class Initialized
INFO - 2023-11-29 14:20:00 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:00 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:00 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:00 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:00 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:00 --> Controller Class Initialized
INFO - 2023-11-29 14:20:00 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:00 --> Total execution time: 0.0477
INFO - 2023-11-29 14:20:21 --> Config Class Initialized
INFO - 2023-11-29 14:20:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:21 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:21 --> URI Class Initialized
INFO - 2023-11-29 14:20:21 --> Router Class Initialized
INFO - 2023-11-29 14:20:21 --> Output Class Initialized
INFO - 2023-11-29 14:20:21 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:21 --> Input Class Initialized
INFO - 2023-11-29 14:20:21 --> Language Class Initialized
INFO - 2023-11-29 14:20:21 --> Language Class Initialized
INFO - 2023-11-29 14:20:21 --> Config Class Initialized
INFO - 2023-11-29 14:20:21 --> Loader Class Initialized
INFO - 2023-11-29 14:20:21 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:21 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:21 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:21 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:21 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:21 --> Controller Class Initialized
DEBUG - 2023-11-29 14:20:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 14:20:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:20:21 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:21 --> Total execution time: 0.0473
INFO - 2023-11-29 14:20:22 --> Config Class Initialized
INFO - 2023-11-29 14:20:22 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:22 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:22 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:22 --> URI Class Initialized
INFO - 2023-11-29 14:20:22 --> Router Class Initialized
INFO - 2023-11-29 14:20:22 --> Output Class Initialized
INFO - 2023-11-29 14:20:22 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:22 --> Input Class Initialized
INFO - 2023-11-29 14:20:22 --> Language Class Initialized
INFO - 2023-11-29 14:20:22 --> Language Class Initialized
INFO - 2023-11-29 14:20:22 --> Config Class Initialized
INFO - 2023-11-29 14:20:22 --> Loader Class Initialized
INFO - 2023-11-29 14:20:22 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:22 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:22 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:22 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:22 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:22 --> Controller Class Initialized
DEBUG - 2023-11-29 14:20:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-29 14:20:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:20:22 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:22 --> Total execution time: 0.1083
INFO - 2023-11-29 14:20:27 --> Config Class Initialized
INFO - 2023-11-29 14:20:27 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:27 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:27 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:27 --> URI Class Initialized
INFO - 2023-11-29 14:20:27 --> Router Class Initialized
INFO - 2023-11-29 14:20:27 --> Output Class Initialized
INFO - 2023-11-29 14:20:27 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:27 --> Input Class Initialized
INFO - 2023-11-29 14:20:27 --> Language Class Initialized
INFO - 2023-11-29 14:20:27 --> Language Class Initialized
INFO - 2023-11-29 14:20:27 --> Config Class Initialized
INFO - 2023-11-29 14:20:27 --> Loader Class Initialized
INFO - 2023-11-29 14:20:27 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:27 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:27 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:27 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:27 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:27 --> Controller Class Initialized
INFO - 2023-11-29 14:20:27 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:27 --> Total execution time: 0.0620
INFO - 2023-11-29 14:20:27 --> Config Class Initialized
INFO - 2023-11-29 14:20:27 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:27 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:27 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:27 --> URI Class Initialized
INFO - 2023-11-29 14:20:27 --> Router Class Initialized
INFO - 2023-11-29 14:20:27 --> Output Class Initialized
INFO - 2023-11-29 14:20:27 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:27 --> Input Class Initialized
INFO - 2023-11-29 14:20:27 --> Language Class Initialized
INFO - 2023-11-29 14:20:28 --> Language Class Initialized
INFO - 2023-11-29 14:20:28 --> Config Class Initialized
INFO - 2023-11-29 14:20:28 --> Loader Class Initialized
INFO - 2023-11-29 14:20:28 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:28 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:28 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:28 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:28 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:28 --> Controller Class Initialized
INFO - 2023-11-29 14:20:28 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:28 --> Total execution time: 0.0402
INFO - 2023-11-29 14:20:31 --> Config Class Initialized
INFO - 2023-11-29 14:20:31 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:31 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:31 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:31 --> URI Class Initialized
INFO - 2023-11-29 14:20:31 --> Router Class Initialized
INFO - 2023-11-29 14:20:31 --> Output Class Initialized
INFO - 2023-11-29 14:20:31 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:31 --> Input Class Initialized
INFO - 2023-11-29 14:20:31 --> Language Class Initialized
INFO - 2023-11-29 14:20:31 --> Language Class Initialized
INFO - 2023-11-29 14:20:31 --> Config Class Initialized
INFO - 2023-11-29 14:20:31 --> Loader Class Initialized
INFO - 2023-11-29 14:20:31 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:31 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:31 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:31 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:31 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:31 --> Controller Class Initialized
INFO - 2023-11-29 14:20:34 --> Config Class Initialized
INFO - 2023-11-29 14:20:34 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:34 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:34 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:34 --> URI Class Initialized
INFO - 2023-11-29 14:20:34 --> Router Class Initialized
INFO - 2023-11-29 14:20:34 --> Output Class Initialized
INFO - 2023-11-29 14:20:34 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:34 --> Input Class Initialized
INFO - 2023-11-29 14:20:34 --> Language Class Initialized
INFO - 2023-11-29 14:20:34 --> Language Class Initialized
INFO - 2023-11-29 14:20:34 --> Config Class Initialized
INFO - 2023-11-29 14:20:34 --> Loader Class Initialized
INFO - 2023-11-29 14:20:34 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:34 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:34 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:34 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:34 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:34 --> Controller Class Initialized
DEBUG - 2023-11-29 14:20:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 14:20:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:20:34 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:34 --> Total execution time: 0.0399
INFO - 2023-11-29 14:20:36 --> Config Class Initialized
INFO - 2023-11-29 14:20:36 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:36 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:36 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:36 --> URI Class Initialized
INFO - 2023-11-29 14:20:36 --> Router Class Initialized
INFO - 2023-11-29 14:20:36 --> Output Class Initialized
INFO - 2023-11-29 14:20:36 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:36 --> Input Class Initialized
INFO - 2023-11-29 14:20:36 --> Language Class Initialized
INFO - 2023-11-29 14:20:36 --> Language Class Initialized
INFO - 2023-11-29 14:20:36 --> Config Class Initialized
INFO - 2023-11-29 14:20:36 --> Loader Class Initialized
INFO - 2023-11-29 14:20:36 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:36 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:36 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:36 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:36 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:36 --> Controller Class Initialized
DEBUG - 2023-11-29 14:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-29 14:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 14:20:36 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:36 --> Total execution time: 0.0436
INFO - 2023-11-29 14:20:37 --> Config Class Initialized
INFO - 2023-11-29 14:20:37 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:37 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:37 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:37 --> URI Class Initialized
INFO - 2023-11-29 14:20:37 --> Router Class Initialized
INFO - 2023-11-29 14:20:37 --> Output Class Initialized
INFO - 2023-11-29 14:20:37 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:37 --> Input Class Initialized
INFO - 2023-11-29 14:20:37 --> Language Class Initialized
INFO - 2023-11-29 14:20:37 --> Language Class Initialized
INFO - 2023-11-29 14:20:37 --> Config Class Initialized
INFO - 2023-11-29 14:20:37 --> Loader Class Initialized
INFO - 2023-11-29 14:20:37 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:37 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:37 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:37 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:37 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:37 --> Controller Class Initialized
INFO - 2023-11-29 14:20:39 --> Config Class Initialized
INFO - 2023-11-29 14:20:39 --> Hooks Class Initialized
DEBUG - 2023-11-29 14:20:39 --> UTF-8 Support Enabled
INFO - 2023-11-29 14:20:39 --> Utf8 Class Initialized
INFO - 2023-11-29 14:20:39 --> URI Class Initialized
INFO - 2023-11-29 14:20:39 --> Router Class Initialized
INFO - 2023-11-29 14:20:39 --> Output Class Initialized
INFO - 2023-11-29 14:20:39 --> Security Class Initialized
DEBUG - 2023-11-29 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 14:20:39 --> Input Class Initialized
INFO - 2023-11-29 14:20:39 --> Language Class Initialized
INFO - 2023-11-29 14:20:39 --> Language Class Initialized
INFO - 2023-11-29 14:20:39 --> Config Class Initialized
INFO - 2023-11-29 14:20:39 --> Loader Class Initialized
INFO - 2023-11-29 14:20:39 --> Helper loaded: url_helper
INFO - 2023-11-29 14:20:39 --> Helper loaded: file_helper
INFO - 2023-11-29 14:20:39 --> Helper loaded: form_helper
INFO - 2023-11-29 14:20:39 --> Helper loaded: my_helper
INFO - 2023-11-29 14:20:39 --> Database Driver Class Initialized
INFO - 2023-11-29 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 14:20:39 --> Controller Class Initialized
INFO - 2023-11-29 14:20:39 --> Final output sent to browser
DEBUG - 2023-11-29 14:20:39 --> Total execution time: 0.0760
INFO - 2023-11-29 15:53:11 --> Config Class Initialized
INFO - 2023-11-29 15:53:11 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:11 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:11 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:11 --> URI Class Initialized
DEBUG - 2023-11-29 15:53:11 --> No URI present. Default controller set.
INFO - 2023-11-29 15:53:11 --> Router Class Initialized
INFO - 2023-11-29 15:53:11 --> Output Class Initialized
INFO - 2023-11-29 15:53:11 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:11 --> Input Class Initialized
INFO - 2023-11-29 15:53:11 --> Language Class Initialized
INFO - 2023-11-29 15:53:11 --> Language Class Initialized
INFO - 2023-11-29 15:53:11 --> Config Class Initialized
INFO - 2023-11-29 15:53:11 --> Loader Class Initialized
INFO - 2023-11-29 15:53:11 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:11 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:11 --> Controller Class Initialized
INFO - 2023-11-29 15:53:11 --> Config Class Initialized
INFO - 2023-11-29 15:53:11 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:11 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:11 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:11 --> URI Class Initialized
INFO - 2023-11-29 15:53:11 --> Router Class Initialized
INFO - 2023-11-29 15:53:11 --> Output Class Initialized
INFO - 2023-11-29 15:53:11 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:11 --> Input Class Initialized
INFO - 2023-11-29 15:53:11 --> Language Class Initialized
INFO - 2023-11-29 15:53:11 --> Language Class Initialized
INFO - 2023-11-29 15:53:11 --> Config Class Initialized
INFO - 2023-11-29 15:53:11 --> Loader Class Initialized
INFO - 2023-11-29 15:53:11 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:11 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:11 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:11 --> Controller Class Initialized
DEBUG - 2023-11-29 15:53:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 15:53:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 15:53:11 --> Final output sent to browser
DEBUG - 2023-11-29 15:53:11 --> Total execution time: 0.0445
INFO - 2023-11-29 15:53:13 --> Config Class Initialized
INFO - 2023-11-29 15:53:13 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:13 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:13 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:13 --> URI Class Initialized
INFO - 2023-11-29 15:53:13 --> Router Class Initialized
INFO - 2023-11-29 15:53:13 --> Output Class Initialized
INFO - 2023-11-29 15:53:13 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:13 --> Input Class Initialized
INFO - 2023-11-29 15:53:13 --> Language Class Initialized
INFO - 2023-11-29 15:53:13 --> Language Class Initialized
INFO - 2023-11-29 15:53:13 --> Config Class Initialized
INFO - 2023-11-29 15:53:13 --> Loader Class Initialized
INFO - 2023-11-29 15:53:13 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:13 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:13 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:13 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:13 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:13 --> Controller Class Initialized
INFO - 2023-11-29 15:53:13 --> Helper loaded: cookie_helper
INFO - 2023-11-29 15:53:13 --> Final output sent to browser
DEBUG - 2023-11-29 15:53:13 --> Total execution time: 0.0616
INFO - 2023-11-29 15:53:14 --> Config Class Initialized
INFO - 2023-11-29 15:53:14 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:14 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:14 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:14 --> URI Class Initialized
INFO - 2023-11-29 15:53:14 --> Router Class Initialized
INFO - 2023-11-29 15:53:14 --> Output Class Initialized
INFO - 2023-11-29 15:53:14 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:14 --> Input Class Initialized
INFO - 2023-11-29 15:53:14 --> Language Class Initialized
INFO - 2023-11-29 15:53:14 --> Language Class Initialized
INFO - 2023-11-29 15:53:14 --> Config Class Initialized
INFO - 2023-11-29 15:53:14 --> Loader Class Initialized
INFO - 2023-11-29 15:53:14 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:14 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:14 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:14 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:14 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:14 --> Controller Class Initialized
DEBUG - 2023-11-29 15:53:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 15:53:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 15:53:14 --> Final output sent to browser
DEBUG - 2023-11-29 15:53:14 --> Total execution time: 0.0362
INFO - 2023-11-29 15:53:16 --> Config Class Initialized
INFO - 2023-11-29 15:53:16 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:16 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:16 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:16 --> URI Class Initialized
INFO - 2023-11-29 15:53:16 --> Router Class Initialized
INFO - 2023-11-29 15:53:16 --> Output Class Initialized
INFO - 2023-11-29 15:53:16 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:16 --> Input Class Initialized
INFO - 2023-11-29 15:53:16 --> Language Class Initialized
INFO - 2023-11-29 15:53:16 --> Language Class Initialized
INFO - 2023-11-29 15:53:16 --> Config Class Initialized
INFO - 2023-11-29 15:53:16 --> Loader Class Initialized
INFO - 2023-11-29 15:53:16 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:16 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:16 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:16 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:16 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:16 --> Controller Class Initialized
DEBUG - 2023-11-29 15:53:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 15:53:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 15:53:16 --> Final output sent to browser
DEBUG - 2023-11-29 15:53:16 --> Total execution time: 0.0461
INFO - 2023-11-29 15:53:21 --> Config Class Initialized
INFO - 2023-11-29 15:53:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:21 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:21 --> URI Class Initialized
INFO - 2023-11-29 15:53:21 --> Router Class Initialized
INFO - 2023-11-29 15:53:21 --> Output Class Initialized
INFO - 2023-11-29 15:53:21 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:21 --> Input Class Initialized
INFO - 2023-11-29 15:53:21 --> Language Class Initialized
INFO - 2023-11-29 15:53:21 --> Language Class Initialized
INFO - 2023-11-29 15:53:21 --> Config Class Initialized
INFO - 2023-11-29 15:53:21 --> Loader Class Initialized
INFO - 2023-11-29 15:53:21 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:21 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:21 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:21 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:21 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:21 --> Controller Class Initialized
DEBUG - 2023-11-29 15:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 15:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 15:53:21 --> Final output sent to browser
DEBUG - 2023-11-29 15:53:21 --> Total execution time: 0.0587
INFO - 2023-11-29 15:53:21 --> Config Class Initialized
INFO - 2023-11-29 15:53:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 15:53:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 15:53:21 --> Utf8 Class Initialized
INFO - 2023-11-29 15:53:21 --> URI Class Initialized
INFO - 2023-11-29 15:53:21 --> Router Class Initialized
INFO - 2023-11-29 15:53:22 --> Output Class Initialized
INFO - 2023-11-29 15:53:22 --> Security Class Initialized
DEBUG - 2023-11-29 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 15:53:22 --> Input Class Initialized
INFO - 2023-11-29 15:53:22 --> Language Class Initialized
INFO - 2023-11-29 15:53:22 --> Language Class Initialized
INFO - 2023-11-29 15:53:22 --> Config Class Initialized
INFO - 2023-11-29 15:53:22 --> Loader Class Initialized
INFO - 2023-11-29 15:53:22 --> Helper loaded: url_helper
INFO - 2023-11-29 15:53:22 --> Helper loaded: file_helper
INFO - 2023-11-29 15:53:22 --> Helper loaded: form_helper
INFO - 2023-11-29 15:53:22 --> Helper loaded: my_helper
INFO - 2023-11-29 15:53:22 --> Database Driver Class Initialized
INFO - 2023-11-29 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 15:53:22 --> Controller Class Initialized
INFO - 2023-11-29 16:27:45 --> Config Class Initialized
INFO - 2023-11-29 16:27:45 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:27:45 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:27:45 --> Utf8 Class Initialized
INFO - 2023-11-29 16:27:45 --> URI Class Initialized
INFO - 2023-11-29 16:27:45 --> Router Class Initialized
INFO - 2023-11-29 16:27:45 --> Output Class Initialized
INFO - 2023-11-29 16:27:45 --> Security Class Initialized
DEBUG - 2023-11-29 16:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:27:45 --> Input Class Initialized
INFO - 2023-11-29 16:27:45 --> Language Class Initialized
INFO - 2023-11-29 16:27:45 --> Language Class Initialized
INFO - 2023-11-29 16:27:45 --> Config Class Initialized
INFO - 2023-11-29 16:27:45 --> Loader Class Initialized
INFO - 2023-11-29 16:27:45 --> Helper loaded: url_helper
INFO - 2023-11-29 16:27:45 --> Helper loaded: file_helper
INFO - 2023-11-29 16:27:45 --> Helper loaded: form_helper
INFO - 2023-11-29 16:27:45 --> Helper loaded: my_helper
INFO - 2023-11-29 16:27:45 --> Database Driver Class Initialized
INFO - 2023-11-29 16:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:27:45 --> Controller Class Initialized
DEBUG - 2023-11-29 16:27:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 16:27:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:27:45 --> Final output sent to browser
DEBUG - 2023-11-29 16:27:45 --> Total execution time: 0.0728
INFO - 2023-11-29 16:27:58 --> Config Class Initialized
INFO - 2023-11-29 16:27:58 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:27:58 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:27:58 --> Utf8 Class Initialized
INFO - 2023-11-29 16:27:58 --> URI Class Initialized
INFO - 2023-11-29 16:27:58 --> Router Class Initialized
INFO - 2023-11-29 16:27:58 --> Output Class Initialized
INFO - 2023-11-29 16:27:58 --> Security Class Initialized
DEBUG - 2023-11-29 16:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:27:58 --> Input Class Initialized
INFO - 2023-11-29 16:27:58 --> Language Class Initialized
INFO - 2023-11-29 16:27:58 --> Language Class Initialized
INFO - 2023-11-29 16:27:58 --> Config Class Initialized
INFO - 2023-11-29 16:27:58 --> Loader Class Initialized
INFO - 2023-11-29 16:27:58 --> Helper loaded: url_helper
INFO - 2023-11-29 16:27:58 --> Helper loaded: file_helper
INFO - 2023-11-29 16:27:58 --> Helper loaded: form_helper
INFO - 2023-11-29 16:27:58 --> Helper loaded: my_helper
INFO - 2023-11-29 16:27:58 --> Database Driver Class Initialized
INFO - 2023-11-29 16:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:27:58 --> Controller Class Initialized
DEBUG - 2023-11-29 16:27:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 16:27:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:27:58 --> Final output sent to browser
DEBUG - 2023-11-29 16:27:58 --> Total execution time: 0.0451
INFO - 2023-11-29 16:28:01 --> Config Class Initialized
INFO - 2023-11-29 16:28:01 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:01 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:01 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:01 --> URI Class Initialized
INFO - 2023-11-29 16:28:01 --> Router Class Initialized
INFO - 2023-11-29 16:28:01 --> Output Class Initialized
INFO - 2023-11-29 16:28:01 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:01 --> Input Class Initialized
INFO - 2023-11-29 16:28:01 --> Language Class Initialized
INFO - 2023-11-29 16:28:01 --> Language Class Initialized
INFO - 2023-11-29 16:28:01 --> Config Class Initialized
INFO - 2023-11-29 16:28:01 --> Loader Class Initialized
INFO - 2023-11-29 16:28:01 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:01 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:01 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:01 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:01 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:01 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 16:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:01 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:01 --> Total execution time: 0.0404
INFO - 2023-11-29 16:28:09 --> Config Class Initialized
INFO - 2023-11-29 16:28:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:09 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:09 --> URI Class Initialized
INFO - 2023-11-29 16:28:09 --> Router Class Initialized
INFO - 2023-11-29 16:28:09 --> Output Class Initialized
INFO - 2023-11-29 16:28:09 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:09 --> Input Class Initialized
INFO - 2023-11-29 16:28:09 --> Language Class Initialized
INFO - 2023-11-29 16:28:09 --> Language Class Initialized
INFO - 2023-11-29 16:28:09 --> Config Class Initialized
INFO - 2023-11-29 16:28:09 --> Loader Class Initialized
INFO - 2023-11-29 16:28:09 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:09 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:09 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:09 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:09 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:09 --> Controller Class Initialized
INFO - 2023-11-29 16:28:10 --> Helper loaded: cookie_helper
INFO - 2023-11-29 16:28:10 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:10 --> Total execution time: 0.2370
INFO - 2023-11-29 16:28:10 --> Config Class Initialized
INFO - 2023-11-29 16:28:10 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:10 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:10 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:10 --> URI Class Initialized
INFO - 2023-11-29 16:28:10 --> Router Class Initialized
INFO - 2023-11-29 16:28:10 --> Output Class Initialized
INFO - 2023-11-29 16:28:10 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:10 --> Input Class Initialized
INFO - 2023-11-29 16:28:10 --> Language Class Initialized
INFO - 2023-11-29 16:28:10 --> Language Class Initialized
INFO - 2023-11-29 16:28:10 --> Config Class Initialized
INFO - 2023-11-29 16:28:10 --> Loader Class Initialized
INFO - 2023-11-29 16:28:10 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:10 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:10 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:10 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:10 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:10 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 16:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:10 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:10 --> Total execution time: 0.0414
INFO - 2023-11-29 16:28:12 --> Config Class Initialized
INFO - 2023-11-29 16:28:12 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:12 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:12 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:12 --> URI Class Initialized
INFO - 2023-11-29 16:28:12 --> Router Class Initialized
INFO - 2023-11-29 16:28:12 --> Output Class Initialized
INFO - 2023-11-29 16:28:12 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:12 --> Input Class Initialized
INFO - 2023-11-29 16:28:12 --> Language Class Initialized
INFO - 2023-11-29 16:28:12 --> Language Class Initialized
INFO - 2023-11-29 16:28:12 --> Config Class Initialized
INFO - 2023-11-29 16:28:12 --> Loader Class Initialized
INFO - 2023-11-29 16:28:12 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:12 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:12 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:12 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:12 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:12 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 16:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:12 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:12 --> Total execution time: 0.0442
INFO - 2023-11-29 16:28:17 --> Config Class Initialized
INFO - 2023-11-29 16:28:17 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:17 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:17 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:17 --> URI Class Initialized
DEBUG - 2023-11-29 16:28:17 --> No URI present. Default controller set.
INFO - 2023-11-29 16:28:17 --> Router Class Initialized
INFO - 2023-11-29 16:28:17 --> Output Class Initialized
INFO - 2023-11-29 16:28:17 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:17 --> Input Class Initialized
INFO - 2023-11-29 16:28:17 --> Language Class Initialized
INFO - 2023-11-29 16:28:18 --> Language Class Initialized
INFO - 2023-11-29 16:28:18 --> Config Class Initialized
INFO - 2023-11-29 16:28:18 --> Loader Class Initialized
INFO - 2023-11-29 16:28:18 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:18 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:18 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:18 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:18 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:18 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 16:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:18 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:18 --> Total execution time: 0.0408
INFO - 2023-11-29 16:28:20 --> Config Class Initialized
INFO - 2023-11-29 16:28:20 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:20 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:20 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:20 --> URI Class Initialized
INFO - 2023-11-29 16:28:20 --> Router Class Initialized
INFO - 2023-11-29 16:28:20 --> Output Class Initialized
INFO - 2023-11-29 16:28:20 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:20 --> Input Class Initialized
INFO - 2023-11-29 16:28:20 --> Language Class Initialized
INFO - 2023-11-29 16:28:20 --> Language Class Initialized
INFO - 2023-11-29 16:28:20 --> Config Class Initialized
INFO - 2023-11-29 16:28:20 --> Loader Class Initialized
INFO - 2023-11-29 16:28:20 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:20 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:20 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:20 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:20 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:20 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 16:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:20 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:20 --> Total execution time: 0.0396
INFO - 2023-11-29 16:28:21 --> Config Class Initialized
INFO - 2023-11-29 16:28:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:21 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:21 --> URI Class Initialized
INFO - 2023-11-29 16:28:21 --> Router Class Initialized
INFO - 2023-11-29 16:28:21 --> Output Class Initialized
INFO - 2023-11-29 16:28:21 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:21 --> Input Class Initialized
INFO - 2023-11-29 16:28:21 --> Language Class Initialized
INFO - 2023-11-29 16:28:21 --> Language Class Initialized
INFO - 2023-11-29 16:28:21 --> Config Class Initialized
INFO - 2023-11-29 16:28:21 --> Loader Class Initialized
INFO - 2023-11-29 16:28:21 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:21 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:21 --> Controller Class Initialized
INFO - 2023-11-29 16:28:21 --> Helper loaded: cookie_helper
INFO - 2023-11-29 16:28:21 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:21 --> Total execution time: 0.0725
INFO - 2023-11-29 16:28:21 --> Config Class Initialized
INFO - 2023-11-29 16:28:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:21 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:21 --> URI Class Initialized
INFO - 2023-11-29 16:28:21 --> Router Class Initialized
INFO - 2023-11-29 16:28:21 --> Output Class Initialized
INFO - 2023-11-29 16:28:21 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:21 --> Input Class Initialized
INFO - 2023-11-29 16:28:21 --> Language Class Initialized
INFO - 2023-11-29 16:28:21 --> Language Class Initialized
INFO - 2023-11-29 16:28:21 --> Config Class Initialized
INFO - 2023-11-29 16:28:21 --> Loader Class Initialized
INFO - 2023-11-29 16:28:21 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:21 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:21 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:21 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 16:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:21 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:21 --> Total execution time: 0.0585
INFO - 2023-11-29 16:28:31 --> Config Class Initialized
INFO - 2023-11-29 16:28:31 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:31 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:31 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:31 --> URI Class Initialized
INFO - 2023-11-29 16:28:31 --> Router Class Initialized
INFO - 2023-11-29 16:28:31 --> Output Class Initialized
INFO - 2023-11-29 16:28:31 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:31 --> Input Class Initialized
INFO - 2023-11-29 16:28:31 --> Language Class Initialized
INFO - 2023-11-29 16:28:31 --> Language Class Initialized
INFO - 2023-11-29 16:28:31 --> Config Class Initialized
INFO - 2023-11-29 16:28:31 --> Loader Class Initialized
INFO - 2023-11-29 16:28:31 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:31 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:31 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:31 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:31 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:31 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-29 16:28:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:31 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:31 --> Total execution time: 0.0383
INFO - 2023-11-29 16:28:35 --> Config Class Initialized
INFO - 2023-11-29 16:28:35 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:35 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:35 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:35 --> URI Class Initialized
INFO - 2023-11-29 16:28:35 --> Router Class Initialized
INFO - 2023-11-29 16:28:35 --> Output Class Initialized
INFO - 2023-11-29 16:28:35 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:35 --> Input Class Initialized
INFO - 2023-11-29 16:28:35 --> Language Class Initialized
INFO - 2023-11-29 16:28:35 --> Language Class Initialized
INFO - 2023-11-29 16:28:35 --> Config Class Initialized
INFO - 2023-11-29 16:28:35 --> Loader Class Initialized
INFO - 2023-11-29 16:28:35 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:35 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:35 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:35 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:35 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:35 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-11-29 16:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:35 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:35 --> Total execution time: 0.1051
INFO - 2023-11-29 16:28:38 --> Config Class Initialized
INFO - 2023-11-29 16:28:38 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:38 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:38 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:38 --> URI Class Initialized
INFO - 2023-11-29 16:28:38 --> Router Class Initialized
INFO - 2023-11-29 16:28:38 --> Output Class Initialized
INFO - 2023-11-29 16:28:38 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:38 --> Input Class Initialized
INFO - 2023-11-29 16:28:38 --> Language Class Initialized
INFO - 2023-11-29 16:28:38 --> Language Class Initialized
INFO - 2023-11-29 16:28:38 --> Config Class Initialized
INFO - 2023-11-29 16:28:38 --> Loader Class Initialized
INFO - 2023-11-29 16:28:38 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:38 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:38 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:38 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:38 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:38 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 16:28:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:38 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:38 --> Total execution time: 0.0563
INFO - 2023-11-29 16:28:41 --> Config Class Initialized
INFO - 2023-11-29 16:28:41 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:41 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:41 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:41 --> URI Class Initialized
INFO - 2023-11-29 16:28:41 --> Router Class Initialized
INFO - 2023-11-29 16:28:41 --> Output Class Initialized
INFO - 2023-11-29 16:28:41 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:41 --> Input Class Initialized
INFO - 2023-11-29 16:28:41 --> Language Class Initialized
INFO - 2023-11-29 16:28:41 --> Language Class Initialized
INFO - 2023-11-29 16:28:41 --> Config Class Initialized
INFO - 2023-11-29 16:28:41 --> Loader Class Initialized
INFO - 2023-11-29 16:28:41 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:41 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:41 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:41 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:41 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:41 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-11-29 16:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:41 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:41 --> Total execution time: 0.0487
INFO - 2023-11-29 16:28:42 --> Config Class Initialized
INFO - 2023-11-29 16:28:42 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:42 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:42 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:42 --> URI Class Initialized
INFO - 2023-11-29 16:28:42 --> Router Class Initialized
INFO - 2023-11-29 16:28:42 --> Output Class Initialized
INFO - 2023-11-29 16:28:42 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:42 --> Input Class Initialized
INFO - 2023-11-29 16:28:42 --> Language Class Initialized
INFO - 2023-11-29 16:28:42 --> Language Class Initialized
INFO - 2023-11-29 16:28:42 --> Config Class Initialized
INFO - 2023-11-29 16:28:42 --> Loader Class Initialized
INFO - 2023-11-29 16:28:42 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:42 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:42 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:42 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:42 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:42 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-29 16:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:42 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:42 --> Total execution time: 0.0372
INFO - 2023-11-29 16:28:44 --> Config Class Initialized
INFO - 2023-11-29 16:28:44 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:44 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:44 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:44 --> URI Class Initialized
INFO - 2023-11-29 16:28:44 --> Router Class Initialized
INFO - 2023-11-29 16:28:44 --> Output Class Initialized
INFO - 2023-11-29 16:28:44 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:44 --> Input Class Initialized
INFO - 2023-11-29 16:28:44 --> Language Class Initialized
INFO - 2023-11-29 16:28:44 --> Language Class Initialized
INFO - 2023-11-29 16:28:44 --> Config Class Initialized
INFO - 2023-11-29 16:28:44 --> Loader Class Initialized
INFO - 2023-11-29 16:28:44 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:44 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:44 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:44 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:44 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:44 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-11-29 16:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:44 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:44 --> Total execution time: 0.0395
INFO - 2023-11-29 16:28:50 --> Config Class Initialized
INFO - 2023-11-29 16:28:50 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:50 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:50 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:50 --> URI Class Initialized
INFO - 2023-11-29 16:28:50 --> Router Class Initialized
INFO - 2023-11-29 16:28:50 --> Output Class Initialized
INFO - 2023-11-29 16:28:50 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:50 --> Input Class Initialized
INFO - 2023-11-29 16:28:50 --> Language Class Initialized
INFO - 2023-11-29 16:28:50 --> Language Class Initialized
INFO - 2023-11-29 16:28:50 --> Config Class Initialized
INFO - 2023-11-29 16:28:50 --> Loader Class Initialized
INFO - 2023-11-29 16:28:50 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:50 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:50 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:50 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:50 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:50 --> Controller Class Initialized
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-11-29 16:28:50 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
DEBUG - 2023-11-29 16:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-11-29 16:28:50 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:50 --> Total execution time: 0.1501
INFO - 2023-11-29 16:28:51 --> Config Class Initialized
INFO - 2023-11-29 16:28:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:28:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:28:51 --> Utf8 Class Initialized
INFO - 2023-11-29 16:28:51 --> URI Class Initialized
INFO - 2023-11-29 16:28:51 --> Router Class Initialized
INFO - 2023-11-29 16:28:51 --> Output Class Initialized
INFO - 2023-11-29 16:28:51 --> Security Class Initialized
DEBUG - 2023-11-29 16:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:28:51 --> Input Class Initialized
INFO - 2023-11-29 16:28:51 --> Language Class Initialized
INFO - 2023-11-29 16:28:51 --> Language Class Initialized
INFO - 2023-11-29 16:28:51 --> Config Class Initialized
INFO - 2023-11-29 16:28:51 --> Loader Class Initialized
INFO - 2023-11-29 16:28:51 --> Helper loaded: url_helper
INFO - 2023-11-29 16:28:51 --> Helper loaded: file_helper
INFO - 2023-11-29 16:28:51 --> Helper loaded: form_helper
INFO - 2023-11-29 16:28:51 --> Helper loaded: my_helper
INFO - 2023-11-29 16:28:51 --> Database Driver Class Initialized
INFO - 2023-11-29 16:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:28:51 --> Controller Class Initialized
DEBUG - 2023-11-29 16:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-11-29 16:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:28:51 --> Final output sent to browser
DEBUG - 2023-11-29 16:28:51 --> Total execution time: 0.0488
INFO - 2023-11-29 16:29:02 --> Config Class Initialized
INFO - 2023-11-29 16:29:02 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:02 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:02 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:02 --> URI Class Initialized
INFO - 2023-11-29 16:29:02 --> Router Class Initialized
INFO - 2023-11-29 16:29:02 --> Output Class Initialized
INFO - 2023-11-29 16:29:02 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:02 --> Input Class Initialized
INFO - 2023-11-29 16:29:02 --> Language Class Initialized
INFO - 2023-11-29 16:29:02 --> Language Class Initialized
INFO - 2023-11-29 16:29:02 --> Config Class Initialized
INFO - 2023-11-29 16:29:02 --> Loader Class Initialized
INFO - 2023-11-29 16:29:02 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:02 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:02 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:02 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:02 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:02 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-11-29 16:29:02 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:02 --> Total execution time: 0.2536
INFO - 2023-11-29 16:29:13 --> Config Class Initialized
INFO - 2023-11-29 16:29:13 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:13 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:13 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:13 --> URI Class Initialized
INFO - 2023-11-29 16:29:13 --> Router Class Initialized
INFO - 2023-11-29 16:29:13 --> Output Class Initialized
INFO - 2023-11-29 16:29:13 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:13 --> Input Class Initialized
INFO - 2023-11-29 16:29:13 --> Language Class Initialized
INFO - 2023-11-29 16:29:13 --> Language Class Initialized
INFO - 2023-11-29 16:29:13 --> Config Class Initialized
INFO - 2023-11-29 16:29:13 --> Loader Class Initialized
INFO - 2023-11-29 16:29:13 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:13 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:13 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:13 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:13 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:13 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-29 16:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:13 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:13 --> Total execution time: 0.0373
INFO - 2023-11-29 16:29:18 --> Config Class Initialized
INFO - 2023-11-29 16:29:18 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:18 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:18 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:18 --> URI Class Initialized
INFO - 2023-11-29 16:29:18 --> Router Class Initialized
INFO - 2023-11-29 16:29:18 --> Output Class Initialized
INFO - 2023-11-29 16:29:18 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:18 --> Input Class Initialized
INFO - 2023-11-29 16:29:18 --> Language Class Initialized
INFO - 2023-11-29 16:29:18 --> Language Class Initialized
INFO - 2023-11-29 16:29:18 --> Config Class Initialized
INFO - 2023-11-29 16:29:18 --> Loader Class Initialized
INFO - 2023-11-29 16:29:18 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:18 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:18 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:18 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:18 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:18 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-11-29 16:29:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:18 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:18 --> Total execution time: 0.0384
INFO - 2023-11-29 16:29:20 --> Config Class Initialized
INFO - 2023-11-29 16:29:20 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:20 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:20 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:20 --> URI Class Initialized
INFO - 2023-11-29 16:29:20 --> Router Class Initialized
INFO - 2023-11-29 16:29:20 --> Output Class Initialized
INFO - 2023-11-29 16:29:20 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:20 --> Input Class Initialized
INFO - 2023-11-29 16:29:20 --> Language Class Initialized
INFO - 2023-11-29 16:29:20 --> Language Class Initialized
INFO - 2023-11-29 16:29:20 --> Config Class Initialized
INFO - 2023-11-29 16:29:20 --> Loader Class Initialized
INFO - 2023-11-29 16:29:20 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:20 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:20 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:20 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:20 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:20 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-11-29 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:20 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:20 --> Total execution time: 0.1281
INFO - 2023-11-29 16:29:24 --> Config Class Initialized
INFO - 2023-11-29 16:29:24 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:24 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:24 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:24 --> URI Class Initialized
INFO - 2023-11-29 16:29:24 --> Router Class Initialized
INFO - 2023-11-29 16:29:24 --> Output Class Initialized
INFO - 2023-11-29 16:29:24 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:24 --> Input Class Initialized
INFO - 2023-11-29 16:29:24 --> Language Class Initialized
INFO - 2023-11-29 16:29:24 --> Language Class Initialized
INFO - 2023-11-29 16:29:24 --> Config Class Initialized
INFO - 2023-11-29 16:29:24 --> Loader Class Initialized
INFO - 2023-11-29 16:29:24 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:24 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:24 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2023-11-29 16:29:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:24 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:24 --> Total execution time: 0.0392
INFO - 2023-11-29 16:29:24 --> Config Class Initialized
INFO - 2023-11-29 16:29:24 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:24 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:24 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:24 --> URI Class Initialized
INFO - 2023-11-29 16:29:24 --> Router Class Initialized
INFO - 2023-11-29 16:29:24 --> Output Class Initialized
INFO - 2023-11-29 16:29:24 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:24 --> Input Class Initialized
INFO - 2023-11-29 16:29:24 --> Language Class Initialized
ERROR - 2023-11-29 16:29:24 --> 404 Page Not Found: /index
INFO - 2023-11-29 16:29:24 --> Config Class Initialized
INFO - 2023-11-29 16:29:24 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:24 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:24 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:24 --> URI Class Initialized
INFO - 2023-11-29 16:29:24 --> Router Class Initialized
INFO - 2023-11-29 16:29:24 --> Output Class Initialized
INFO - 2023-11-29 16:29:24 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:24 --> Input Class Initialized
INFO - 2023-11-29 16:29:24 --> Language Class Initialized
INFO - 2023-11-29 16:29:24 --> Language Class Initialized
INFO - 2023-11-29 16:29:24 --> Config Class Initialized
INFO - 2023-11-29 16:29:24 --> Loader Class Initialized
INFO - 2023-11-29 16:29:24 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:24 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:24 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:24 --> Controller Class Initialized
INFO - 2023-11-29 16:29:28 --> Config Class Initialized
INFO - 2023-11-29 16:29:28 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:28 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:28 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:28 --> URI Class Initialized
INFO - 2023-11-29 16:29:28 --> Router Class Initialized
INFO - 2023-11-29 16:29:28 --> Output Class Initialized
INFO - 2023-11-29 16:29:28 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:28 --> Input Class Initialized
INFO - 2023-11-29 16:29:28 --> Language Class Initialized
INFO - 2023-11-29 16:29:28 --> Language Class Initialized
INFO - 2023-11-29 16:29:28 --> Config Class Initialized
INFO - 2023-11-29 16:29:28 --> Loader Class Initialized
INFO - 2023-11-29 16:29:28 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:28 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:28 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:28 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:28 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:28 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-29 16:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:28 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:28 --> Total execution time: 0.0337
INFO - 2023-11-29 16:29:39 --> Config Class Initialized
INFO - 2023-11-29 16:29:39 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:39 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:39 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:39 --> URI Class Initialized
DEBUG - 2023-11-29 16:29:39 --> No URI present. Default controller set.
INFO - 2023-11-29 16:29:39 --> Router Class Initialized
INFO - 2023-11-29 16:29:39 --> Output Class Initialized
INFO - 2023-11-29 16:29:39 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:39 --> Input Class Initialized
INFO - 2023-11-29 16:29:39 --> Language Class Initialized
INFO - 2023-11-29 16:29:39 --> Language Class Initialized
INFO - 2023-11-29 16:29:39 --> Config Class Initialized
INFO - 2023-11-29 16:29:39 --> Loader Class Initialized
INFO - 2023-11-29 16:29:39 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:39 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:39 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:39 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:39 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:39 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-29 16:29:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:39 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:39 --> Total execution time: 0.0402
INFO - 2023-11-29 16:29:41 --> Config Class Initialized
INFO - 2023-11-29 16:29:41 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:41 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:41 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:41 --> URI Class Initialized
INFO - 2023-11-29 16:29:41 --> Router Class Initialized
INFO - 2023-11-29 16:29:41 --> Output Class Initialized
INFO - 2023-11-29 16:29:41 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:41 --> Input Class Initialized
INFO - 2023-11-29 16:29:41 --> Language Class Initialized
INFO - 2023-11-29 16:29:41 --> Language Class Initialized
INFO - 2023-11-29 16:29:41 --> Config Class Initialized
INFO - 2023-11-29 16:29:41 --> Loader Class Initialized
INFO - 2023-11-29 16:29:41 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:41 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:41 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:41 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:41 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:41 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 16:29:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:41 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:41 --> Total execution time: 0.0448
INFO - 2023-11-29 16:29:43 --> Config Class Initialized
INFO - 2023-11-29 16:29:43 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:43 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:43 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:43 --> URI Class Initialized
INFO - 2023-11-29 16:29:43 --> Router Class Initialized
INFO - 2023-11-29 16:29:43 --> Output Class Initialized
INFO - 2023-11-29 16:29:43 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:43 --> Input Class Initialized
INFO - 2023-11-29 16:29:43 --> Language Class Initialized
INFO - 2023-11-29 16:29:43 --> Language Class Initialized
INFO - 2023-11-29 16:29:43 --> Config Class Initialized
INFO - 2023-11-29 16:29:43 --> Loader Class Initialized
INFO - 2023-11-29 16:29:43 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:43 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:43 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:43 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:43 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:43 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-11-29 16:29:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:43 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:43 --> Total execution time: 0.0404
INFO - 2023-11-29 16:29:47 --> Config Class Initialized
INFO - 2023-11-29 16:29:47 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:47 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:47 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:47 --> URI Class Initialized
INFO - 2023-11-29 16:29:47 --> Router Class Initialized
INFO - 2023-11-29 16:29:47 --> Output Class Initialized
INFO - 2023-11-29 16:29:47 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:47 --> Input Class Initialized
INFO - 2023-11-29 16:29:47 --> Language Class Initialized
INFO - 2023-11-29 16:29:47 --> Language Class Initialized
INFO - 2023-11-29 16:29:47 --> Config Class Initialized
INFO - 2023-11-29 16:29:47 --> Loader Class Initialized
INFO - 2023-11-29 16:29:47 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:47 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:47 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:47 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:47 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:47 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 16:29:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:47 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:47 --> Total execution time: 0.0359
INFO - 2023-11-29 16:29:51 --> Config Class Initialized
INFO - 2023-11-29 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:51 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:51 --> URI Class Initialized
INFO - 2023-11-29 16:29:51 --> Router Class Initialized
INFO - 2023-11-29 16:29:51 --> Output Class Initialized
INFO - 2023-11-29 16:29:51 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:51 --> Input Class Initialized
INFO - 2023-11-29 16:29:51 --> Language Class Initialized
INFO - 2023-11-29 16:29:51 --> Language Class Initialized
INFO - 2023-11-29 16:29:51 --> Config Class Initialized
INFO - 2023-11-29 16:29:51 --> Loader Class Initialized
INFO - 2023-11-29 16:29:51 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:51 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:51 --> Controller Class Initialized
DEBUG - 2023-11-29 16:29:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 16:29:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:29:51 --> Final output sent to browser
DEBUG - 2023-11-29 16:29:51 --> Total execution time: 0.4588
INFO - 2023-11-29 16:29:51 --> Config Class Initialized
INFO - 2023-11-29 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:29:51 --> Utf8 Class Initialized
INFO - 2023-11-29 16:29:51 --> URI Class Initialized
INFO - 2023-11-29 16:29:51 --> Router Class Initialized
INFO - 2023-11-29 16:29:51 --> Output Class Initialized
INFO - 2023-11-29 16:29:51 --> Security Class Initialized
DEBUG - 2023-11-29 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:29:51 --> Input Class Initialized
INFO - 2023-11-29 16:29:51 --> Language Class Initialized
INFO - 2023-11-29 16:29:51 --> Language Class Initialized
INFO - 2023-11-29 16:29:51 --> Config Class Initialized
INFO - 2023-11-29 16:29:51 --> Loader Class Initialized
INFO - 2023-11-29 16:29:51 --> Helper loaded: url_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: file_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: form_helper
INFO - 2023-11-29 16:29:51 --> Helper loaded: my_helper
INFO - 2023-11-29 16:29:51 --> Database Driver Class Initialized
INFO - 2023-11-29 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:29:51 --> Controller Class Initialized
INFO - 2023-11-29 16:30:09 --> Config Class Initialized
INFO - 2023-11-29 16:30:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:09 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:09 --> URI Class Initialized
INFO - 2023-11-29 16:30:09 --> Router Class Initialized
INFO - 2023-11-29 16:30:09 --> Output Class Initialized
INFO - 2023-11-29 16:30:09 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:09 --> Input Class Initialized
INFO - 2023-11-29 16:30:09 --> Language Class Initialized
INFO - 2023-11-29 16:30:09 --> Language Class Initialized
INFO - 2023-11-29 16:30:09 --> Config Class Initialized
INFO - 2023-11-29 16:30:09 --> Loader Class Initialized
INFO - 2023-11-29 16:30:09 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:09 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:09 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:09 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:09 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:09 --> Controller Class Initialized
INFO - 2023-11-29 16:30:09 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:09 --> Total execution time: 0.0459
INFO - 2023-11-29 16:30:18 --> Config Class Initialized
INFO - 2023-11-29 16:30:18 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:18 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:18 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:18 --> URI Class Initialized
INFO - 2023-11-29 16:30:18 --> Router Class Initialized
INFO - 2023-11-29 16:30:18 --> Output Class Initialized
INFO - 2023-11-29 16:30:18 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:18 --> Input Class Initialized
INFO - 2023-11-29 16:30:18 --> Language Class Initialized
INFO - 2023-11-29 16:30:18 --> Language Class Initialized
INFO - 2023-11-29 16:30:18 --> Config Class Initialized
INFO - 2023-11-29 16:30:18 --> Loader Class Initialized
INFO - 2023-11-29 16:30:18 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:18 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:18 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:18 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:18 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:18 --> Controller Class Initialized
INFO - 2023-11-29 16:30:18 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:18 --> Total execution time: 0.0541
INFO - 2023-11-29 16:30:20 --> Config Class Initialized
INFO - 2023-11-29 16:30:20 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:20 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:20 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:20 --> URI Class Initialized
INFO - 2023-11-29 16:30:20 --> Router Class Initialized
INFO - 2023-11-29 16:30:20 --> Output Class Initialized
INFO - 2023-11-29 16:30:20 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:20 --> Input Class Initialized
INFO - 2023-11-29 16:30:20 --> Language Class Initialized
INFO - 2023-11-29 16:30:20 --> Language Class Initialized
INFO - 2023-11-29 16:30:20 --> Config Class Initialized
INFO - 2023-11-29 16:30:20 --> Loader Class Initialized
INFO - 2023-11-29 16:30:20 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:20 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:20 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:20 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:20 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:20 --> Controller Class Initialized
INFO - 2023-11-29 16:30:20 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:20 --> Total execution time: 0.0396
INFO - 2023-11-29 16:30:22 --> Config Class Initialized
INFO - 2023-11-29 16:30:22 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:22 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:22 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:22 --> URI Class Initialized
INFO - 2023-11-29 16:30:22 --> Router Class Initialized
INFO - 2023-11-29 16:30:22 --> Output Class Initialized
INFO - 2023-11-29 16:30:22 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:22 --> Input Class Initialized
INFO - 2023-11-29 16:30:22 --> Language Class Initialized
INFO - 2023-11-29 16:30:22 --> Language Class Initialized
INFO - 2023-11-29 16:30:22 --> Config Class Initialized
INFO - 2023-11-29 16:30:22 --> Loader Class Initialized
INFO - 2023-11-29 16:30:22 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:22 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:22 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:22 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:22 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:22 --> Controller Class Initialized
INFO - 2023-11-29 16:30:22 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:22 --> Total execution time: 0.0983
INFO - 2023-11-29 16:30:24 --> Config Class Initialized
INFO - 2023-11-29 16:30:24 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:24 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:24 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:24 --> URI Class Initialized
INFO - 2023-11-29 16:30:24 --> Router Class Initialized
INFO - 2023-11-29 16:30:24 --> Output Class Initialized
INFO - 2023-11-29 16:30:24 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:24 --> Input Class Initialized
INFO - 2023-11-29 16:30:24 --> Language Class Initialized
INFO - 2023-11-29 16:30:24 --> Language Class Initialized
INFO - 2023-11-29 16:30:24 --> Config Class Initialized
INFO - 2023-11-29 16:30:24 --> Loader Class Initialized
INFO - 2023-11-29 16:30:24 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:24 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:24 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:24 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:24 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:24 --> Controller Class Initialized
INFO - 2023-11-29 16:30:24 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:24 --> Total execution time: 0.0990
INFO - 2023-11-29 16:30:26 --> Config Class Initialized
INFO - 2023-11-29 16:30:26 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:26 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:26 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:26 --> URI Class Initialized
INFO - 2023-11-29 16:30:26 --> Router Class Initialized
INFO - 2023-11-29 16:30:26 --> Output Class Initialized
INFO - 2023-11-29 16:30:26 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:26 --> Input Class Initialized
INFO - 2023-11-29 16:30:26 --> Language Class Initialized
INFO - 2023-11-29 16:30:26 --> Language Class Initialized
INFO - 2023-11-29 16:30:26 --> Config Class Initialized
INFO - 2023-11-29 16:30:26 --> Loader Class Initialized
INFO - 2023-11-29 16:30:26 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:26 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:26 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:26 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:26 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:26 --> Controller Class Initialized
INFO - 2023-11-29 16:30:26 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:26 --> Total execution time: 0.0451
INFO - 2023-11-29 16:30:33 --> Config Class Initialized
INFO - 2023-11-29 16:30:33 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:33 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:33 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:33 --> URI Class Initialized
INFO - 2023-11-29 16:30:33 --> Router Class Initialized
INFO - 2023-11-29 16:30:33 --> Output Class Initialized
INFO - 2023-11-29 16:30:33 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:33 --> Input Class Initialized
INFO - 2023-11-29 16:30:33 --> Language Class Initialized
INFO - 2023-11-29 16:30:33 --> Language Class Initialized
INFO - 2023-11-29 16:30:33 --> Config Class Initialized
INFO - 2023-11-29 16:30:33 --> Loader Class Initialized
INFO - 2023-11-29 16:30:33 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:33 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:33 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:33 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:33 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:33 --> Controller Class Initialized
INFO - 2023-11-29 16:30:33 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:33 --> Total execution time: 0.1433
INFO - 2023-11-29 16:30:57 --> Config Class Initialized
INFO - 2023-11-29 16:30:57 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:30:57 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:30:57 --> Utf8 Class Initialized
INFO - 2023-11-29 16:30:57 --> URI Class Initialized
INFO - 2023-11-29 16:30:57 --> Router Class Initialized
INFO - 2023-11-29 16:30:57 --> Output Class Initialized
INFO - 2023-11-29 16:30:57 --> Security Class Initialized
DEBUG - 2023-11-29 16:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:30:57 --> Input Class Initialized
INFO - 2023-11-29 16:30:57 --> Language Class Initialized
INFO - 2023-11-29 16:30:57 --> Language Class Initialized
INFO - 2023-11-29 16:30:57 --> Config Class Initialized
INFO - 2023-11-29 16:30:57 --> Loader Class Initialized
INFO - 2023-11-29 16:30:57 --> Helper loaded: url_helper
INFO - 2023-11-29 16:30:57 --> Helper loaded: file_helper
INFO - 2023-11-29 16:30:57 --> Helper loaded: form_helper
INFO - 2023-11-29 16:30:57 --> Helper loaded: my_helper
INFO - 2023-11-29 16:30:57 --> Database Driver Class Initialized
INFO - 2023-11-29 16:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:30:57 --> Controller Class Initialized
INFO - 2023-11-29 16:30:58 --> Final output sent to browser
DEBUG - 2023-11-29 16:30:58 --> Total execution time: 0.2282
INFO - 2023-11-29 16:31:01 --> Config Class Initialized
INFO - 2023-11-29 16:31:01 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:01 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:01 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:01 --> URI Class Initialized
INFO - 2023-11-29 16:31:01 --> Router Class Initialized
INFO - 2023-11-29 16:31:01 --> Output Class Initialized
INFO - 2023-11-29 16:31:01 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:01 --> Input Class Initialized
INFO - 2023-11-29 16:31:01 --> Language Class Initialized
INFO - 2023-11-29 16:31:01 --> Language Class Initialized
INFO - 2023-11-29 16:31:01 --> Config Class Initialized
INFO - 2023-11-29 16:31:01 --> Loader Class Initialized
INFO - 2023-11-29 16:31:01 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:01 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:01 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:01 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:01 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:01 --> Controller Class Initialized
INFO - 2023-11-29 16:31:01 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:01 --> Total execution time: 0.0652
INFO - 2023-11-29 16:31:03 --> Config Class Initialized
INFO - 2023-11-29 16:31:03 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:03 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:03 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:03 --> URI Class Initialized
INFO - 2023-11-29 16:31:03 --> Router Class Initialized
INFO - 2023-11-29 16:31:03 --> Output Class Initialized
INFO - 2023-11-29 16:31:03 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:03 --> Input Class Initialized
INFO - 2023-11-29 16:31:03 --> Language Class Initialized
INFO - 2023-11-29 16:31:03 --> Language Class Initialized
INFO - 2023-11-29 16:31:03 --> Config Class Initialized
INFO - 2023-11-29 16:31:03 --> Loader Class Initialized
INFO - 2023-11-29 16:31:03 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:03 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:03 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:03 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:03 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:03 --> Controller Class Initialized
INFO - 2023-11-29 16:31:03 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:03 --> Total execution time: 0.0536
INFO - 2023-11-29 16:31:04 --> Config Class Initialized
INFO - 2023-11-29 16:31:04 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:04 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:04 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:04 --> URI Class Initialized
INFO - 2023-11-29 16:31:04 --> Router Class Initialized
INFO - 2023-11-29 16:31:04 --> Output Class Initialized
INFO - 2023-11-29 16:31:04 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:04 --> Input Class Initialized
INFO - 2023-11-29 16:31:04 --> Language Class Initialized
INFO - 2023-11-29 16:31:05 --> Language Class Initialized
INFO - 2023-11-29 16:31:05 --> Config Class Initialized
INFO - 2023-11-29 16:31:05 --> Loader Class Initialized
INFO - 2023-11-29 16:31:05 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:05 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:05 --> Controller Class Initialized
INFO - 2023-11-29 16:31:05 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:05 --> Total execution time: 0.0883
INFO - 2023-11-29 16:31:05 --> Config Class Initialized
INFO - 2023-11-29 16:31:05 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:05 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:05 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:05 --> URI Class Initialized
INFO - 2023-11-29 16:31:05 --> Router Class Initialized
INFO - 2023-11-29 16:31:05 --> Output Class Initialized
INFO - 2023-11-29 16:31:05 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:05 --> Input Class Initialized
INFO - 2023-11-29 16:31:05 --> Language Class Initialized
INFO - 2023-11-29 16:31:05 --> Language Class Initialized
INFO - 2023-11-29 16:31:05 --> Config Class Initialized
INFO - 2023-11-29 16:31:05 --> Loader Class Initialized
INFO - 2023-11-29 16:31:05 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:05 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:05 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:05 --> Controller Class Initialized
INFO - 2023-11-29 16:31:05 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:05 --> Total execution time: 0.0438
INFO - 2023-11-29 16:31:07 --> Config Class Initialized
INFO - 2023-11-29 16:31:07 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:07 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:07 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:07 --> URI Class Initialized
INFO - 2023-11-29 16:31:07 --> Router Class Initialized
INFO - 2023-11-29 16:31:07 --> Output Class Initialized
INFO - 2023-11-29 16:31:07 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:07 --> Input Class Initialized
INFO - 2023-11-29 16:31:07 --> Language Class Initialized
INFO - 2023-11-29 16:31:07 --> Language Class Initialized
INFO - 2023-11-29 16:31:07 --> Config Class Initialized
INFO - 2023-11-29 16:31:07 --> Loader Class Initialized
INFO - 2023-11-29 16:31:07 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:07 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:07 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:07 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:07 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:07 --> Controller Class Initialized
INFO - 2023-11-29 16:31:07 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:07 --> Total execution time: 0.0410
INFO - 2023-11-29 16:31:09 --> Config Class Initialized
INFO - 2023-11-29 16:31:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:09 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:09 --> URI Class Initialized
INFO - 2023-11-29 16:31:09 --> Router Class Initialized
INFO - 2023-11-29 16:31:09 --> Output Class Initialized
INFO - 2023-11-29 16:31:09 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:09 --> Input Class Initialized
INFO - 2023-11-29 16:31:09 --> Language Class Initialized
INFO - 2023-11-29 16:31:09 --> Language Class Initialized
INFO - 2023-11-29 16:31:09 --> Config Class Initialized
INFO - 2023-11-29 16:31:09 --> Loader Class Initialized
INFO - 2023-11-29 16:31:09 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:09 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:09 --> Controller Class Initialized
INFO - 2023-11-29 16:31:09 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:09 --> Total execution time: 0.0626
INFO - 2023-11-29 16:31:09 --> Config Class Initialized
INFO - 2023-11-29 16:31:09 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:09 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:09 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:09 --> URI Class Initialized
INFO - 2023-11-29 16:31:09 --> Router Class Initialized
INFO - 2023-11-29 16:31:09 --> Output Class Initialized
INFO - 2023-11-29 16:31:09 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:09 --> Input Class Initialized
INFO - 2023-11-29 16:31:09 --> Language Class Initialized
INFO - 2023-11-29 16:31:09 --> Language Class Initialized
INFO - 2023-11-29 16:31:09 --> Config Class Initialized
INFO - 2023-11-29 16:31:09 --> Loader Class Initialized
INFO - 2023-11-29 16:31:09 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:09 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:09 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:09 --> Controller Class Initialized
INFO - 2023-11-29 16:31:09 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:09 --> Total execution time: 0.0764
INFO - 2023-11-29 16:31:10 --> Config Class Initialized
INFO - 2023-11-29 16:31:10 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:10 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:10 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:10 --> URI Class Initialized
INFO - 2023-11-29 16:31:10 --> Router Class Initialized
INFO - 2023-11-29 16:31:10 --> Output Class Initialized
INFO - 2023-11-29 16:31:10 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:10 --> Input Class Initialized
INFO - 2023-11-29 16:31:10 --> Language Class Initialized
INFO - 2023-11-29 16:31:10 --> Language Class Initialized
INFO - 2023-11-29 16:31:10 --> Config Class Initialized
INFO - 2023-11-29 16:31:10 --> Loader Class Initialized
INFO - 2023-11-29 16:31:10 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:10 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:10 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:10 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:10 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:10 --> Controller Class Initialized
INFO - 2023-11-29 16:31:10 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:10 --> Total execution time: 0.0465
INFO - 2023-11-29 16:31:12 --> Config Class Initialized
INFO - 2023-11-29 16:31:12 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:12 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:12 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:12 --> URI Class Initialized
INFO - 2023-11-29 16:31:12 --> Router Class Initialized
INFO - 2023-11-29 16:31:12 --> Output Class Initialized
INFO - 2023-11-29 16:31:12 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:12 --> Input Class Initialized
INFO - 2023-11-29 16:31:12 --> Language Class Initialized
INFO - 2023-11-29 16:31:12 --> Language Class Initialized
INFO - 2023-11-29 16:31:12 --> Config Class Initialized
INFO - 2023-11-29 16:31:12 --> Loader Class Initialized
INFO - 2023-11-29 16:31:12 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:12 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:12 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:12 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:12 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:12 --> Controller Class Initialized
INFO - 2023-11-29 16:31:12 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:12 --> Total execution time: 0.0413
INFO - 2023-11-29 16:31:17 --> Config Class Initialized
INFO - 2023-11-29 16:31:17 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:17 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:17 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:17 --> URI Class Initialized
INFO - 2023-11-29 16:31:17 --> Router Class Initialized
INFO - 2023-11-29 16:31:17 --> Output Class Initialized
INFO - 2023-11-29 16:31:17 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:17 --> Input Class Initialized
INFO - 2023-11-29 16:31:17 --> Language Class Initialized
INFO - 2023-11-29 16:31:17 --> Language Class Initialized
INFO - 2023-11-29 16:31:17 --> Config Class Initialized
INFO - 2023-11-29 16:31:17 --> Loader Class Initialized
INFO - 2023-11-29 16:31:17 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:17 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:17 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:17 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:17 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:18 --> Controller Class Initialized
INFO - 2023-11-29 16:31:18 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:18 --> Total execution time: 0.0388
INFO - 2023-11-29 16:31:35 --> Config Class Initialized
INFO - 2023-11-29 16:31:35 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:35 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:35 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:35 --> URI Class Initialized
INFO - 2023-11-29 16:31:35 --> Router Class Initialized
INFO - 2023-11-29 16:31:35 --> Output Class Initialized
INFO - 2023-11-29 16:31:35 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:35 --> Input Class Initialized
INFO - 2023-11-29 16:31:35 --> Language Class Initialized
INFO - 2023-11-29 16:31:35 --> Language Class Initialized
INFO - 2023-11-29 16:31:35 --> Config Class Initialized
INFO - 2023-11-29 16:31:35 --> Loader Class Initialized
INFO - 2023-11-29 16:31:35 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:35 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:35 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:35 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:35 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:35 --> Controller Class Initialized
INFO - 2023-11-29 16:31:35 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:35 --> Total execution time: 0.0835
INFO - 2023-11-29 16:31:43 --> Config Class Initialized
INFO - 2023-11-29 16:31:43 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:43 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:43 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:43 --> URI Class Initialized
INFO - 2023-11-29 16:31:43 --> Router Class Initialized
INFO - 2023-11-29 16:31:43 --> Output Class Initialized
INFO - 2023-11-29 16:31:43 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:43 --> Input Class Initialized
INFO - 2023-11-29 16:31:43 --> Language Class Initialized
INFO - 2023-11-29 16:31:43 --> Language Class Initialized
INFO - 2023-11-29 16:31:43 --> Config Class Initialized
INFO - 2023-11-29 16:31:43 --> Loader Class Initialized
INFO - 2023-11-29 16:31:43 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:43 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:43 --> Controller Class Initialized
INFO - 2023-11-29 16:31:43 --> Helper loaded: cookie_helper
INFO - 2023-11-29 16:31:43 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:43 --> Total execution time: 0.0522
INFO - 2023-11-29 16:31:43 --> Config Class Initialized
INFO - 2023-11-29 16:31:43 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:43 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:43 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:43 --> URI Class Initialized
INFO - 2023-11-29 16:31:43 --> Router Class Initialized
INFO - 2023-11-29 16:31:43 --> Output Class Initialized
INFO - 2023-11-29 16:31:43 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:43 --> Input Class Initialized
INFO - 2023-11-29 16:31:43 --> Language Class Initialized
INFO - 2023-11-29 16:31:43 --> Language Class Initialized
INFO - 2023-11-29 16:31:43 --> Config Class Initialized
INFO - 2023-11-29 16:31:43 --> Loader Class Initialized
INFO - 2023-11-29 16:31:43 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:43 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:43 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:43 --> Controller Class Initialized
DEBUG - 2023-11-29 16:31:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-29 16:31:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:31:43 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:43 --> Total execution time: 0.0412
INFO - 2023-11-29 16:31:43 --> Config Class Initialized
INFO - 2023-11-29 16:31:43 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:44 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:44 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:44 --> URI Class Initialized
INFO - 2023-11-29 16:31:44 --> Router Class Initialized
INFO - 2023-11-29 16:31:44 --> Output Class Initialized
INFO - 2023-11-29 16:31:44 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:44 --> Input Class Initialized
INFO - 2023-11-29 16:31:44 --> Language Class Initialized
INFO - 2023-11-29 16:31:44 --> Language Class Initialized
INFO - 2023-11-29 16:31:44 --> Config Class Initialized
INFO - 2023-11-29 16:31:44 --> Loader Class Initialized
INFO - 2023-11-29 16:31:44 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:44 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:44 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:44 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:44 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:44 --> Controller Class Initialized
DEBUG - 2023-11-29 16:31:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-29 16:31:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:31:44 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:44 --> Total execution time: 0.0428
INFO - 2023-11-29 16:31:46 --> Config Class Initialized
INFO - 2023-11-29 16:31:46 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:46 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:46 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:46 --> URI Class Initialized
INFO - 2023-11-29 16:31:46 --> Router Class Initialized
INFO - 2023-11-29 16:31:46 --> Output Class Initialized
INFO - 2023-11-29 16:31:46 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:46 --> Input Class Initialized
INFO - 2023-11-29 16:31:46 --> Language Class Initialized
INFO - 2023-11-29 16:31:46 --> Language Class Initialized
INFO - 2023-11-29 16:31:46 --> Config Class Initialized
INFO - 2023-11-29 16:31:46 --> Loader Class Initialized
INFO - 2023-11-29 16:31:46 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:46 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:46 --> Controller Class Initialized
DEBUG - 2023-11-29 16:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-29 16:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 16:31:46 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:46 --> Total execution time: 0.0375
INFO - 2023-11-29 16:31:46 --> Config Class Initialized
INFO - 2023-11-29 16:31:46 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:46 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:46 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:46 --> URI Class Initialized
INFO - 2023-11-29 16:31:46 --> Router Class Initialized
INFO - 2023-11-29 16:31:46 --> Output Class Initialized
INFO - 2023-11-29 16:31:46 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:46 --> Input Class Initialized
INFO - 2023-11-29 16:31:46 --> Language Class Initialized
INFO - 2023-11-29 16:31:46 --> Language Class Initialized
INFO - 2023-11-29 16:31:46 --> Config Class Initialized
INFO - 2023-11-29 16:31:46 --> Loader Class Initialized
INFO - 2023-11-29 16:31:46 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:46 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:46 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:46 --> Controller Class Initialized
INFO - 2023-11-29 16:31:54 --> Config Class Initialized
INFO - 2023-11-29 16:31:54 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:54 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:54 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:54 --> URI Class Initialized
INFO - 2023-11-29 16:31:54 --> Router Class Initialized
INFO - 2023-11-29 16:31:54 --> Output Class Initialized
INFO - 2023-11-29 16:31:54 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:54 --> Input Class Initialized
INFO - 2023-11-29 16:31:54 --> Language Class Initialized
INFO - 2023-11-29 16:31:54 --> Language Class Initialized
INFO - 2023-11-29 16:31:54 --> Config Class Initialized
INFO - 2023-11-29 16:31:54 --> Loader Class Initialized
INFO - 2023-11-29 16:31:54 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:54 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:54 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:54 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:54 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:54 --> Controller Class Initialized
INFO - 2023-11-29 16:31:54 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:54 --> Total execution time: 0.0420
INFO - 2023-11-29 16:31:55 --> Config Class Initialized
INFO - 2023-11-29 16:31:55 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:55 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:55 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:55 --> URI Class Initialized
INFO - 2023-11-29 16:31:55 --> Router Class Initialized
INFO - 2023-11-29 16:31:55 --> Output Class Initialized
INFO - 2023-11-29 16:31:55 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:55 --> Input Class Initialized
INFO - 2023-11-29 16:31:55 --> Language Class Initialized
INFO - 2023-11-29 16:31:55 --> Language Class Initialized
INFO - 2023-11-29 16:31:55 --> Config Class Initialized
INFO - 2023-11-29 16:31:55 --> Loader Class Initialized
INFO - 2023-11-29 16:31:55 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:55 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:55 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:55 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:55 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:55 --> Controller Class Initialized
INFO - 2023-11-29 16:31:55 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:55 --> Total execution time: 0.0369
INFO - 2023-11-29 16:31:56 --> Config Class Initialized
INFO - 2023-11-29 16:31:56 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:56 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:56 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:56 --> URI Class Initialized
INFO - 2023-11-29 16:31:56 --> Router Class Initialized
INFO - 2023-11-29 16:31:56 --> Output Class Initialized
INFO - 2023-11-29 16:31:56 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:56 --> Input Class Initialized
INFO - 2023-11-29 16:31:56 --> Language Class Initialized
INFO - 2023-11-29 16:31:56 --> Language Class Initialized
INFO - 2023-11-29 16:31:56 --> Config Class Initialized
INFO - 2023-11-29 16:31:56 --> Loader Class Initialized
INFO - 2023-11-29 16:31:56 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:56 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:56 --> Controller Class Initialized
INFO - 2023-11-29 16:31:56 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:56 --> Total execution time: 0.0510
INFO - 2023-11-29 16:31:56 --> Config Class Initialized
INFO - 2023-11-29 16:31:56 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:56 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:56 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:56 --> URI Class Initialized
INFO - 2023-11-29 16:31:56 --> Router Class Initialized
INFO - 2023-11-29 16:31:56 --> Output Class Initialized
INFO - 2023-11-29 16:31:56 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:56 --> Input Class Initialized
INFO - 2023-11-29 16:31:56 --> Language Class Initialized
INFO - 2023-11-29 16:31:56 --> Language Class Initialized
INFO - 2023-11-29 16:31:56 --> Config Class Initialized
INFO - 2023-11-29 16:31:56 --> Loader Class Initialized
INFO - 2023-11-29 16:31:56 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:56 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:56 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:56 --> Controller Class Initialized
INFO - 2023-11-29 16:31:56 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:56 --> Total execution time: 0.0417
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:58 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:58 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:58 --> URI Class Initialized
INFO - 2023-11-29 16:31:58 --> Router Class Initialized
INFO - 2023-11-29 16:31:58 --> Output Class Initialized
INFO - 2023-11-29 16:31:58 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:58 --> Input Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Loader Class Initialized
INFO - 2023-11-29 16:31:58 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:58 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:58 --> Controller Class Initialized
INFO - 2023-11-29 16:31:58 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:58 --> Total execution time: 0.0419
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:58 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:58 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:58 --> URI Class Initialized
INFO - 2023-11-29 16:31:58 --> Router Class Initialized
INFO - 2023-11-29 16:31:58 --> Output Class Initialized
INFO - 2023-11-29 16:31:58 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:58 --> Input Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Loader Class Initialized
INFO - 2023-11-29 16:31:58 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:58 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:58 --> Controller Class Initialized
INFO - 2023-11-29 16:31:58 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:58 --> Total execution time: 0.0928
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:31:58 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:31:58 --> Utf8 Class Initialized
INFO - 2023-11-29 16:31:58 --> URI Class Initialized
INFO - 2023-11-29 16:31:58 --> Router Class Initialized
INFO - 2023-11-29 16:31:58 --> Output Class Initialized
INFO - 2023-11-29 16:31:58 --> Security Class Initialized
DEBUG - 2023-11-29 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:31:58 --> Input Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Language Class Initialized
INFO - 2023-11-29 16:31:58 --> Config Class Initialized
INFO - 2023-11-29 16:31:58 --> Loader Class Initialized
INFO - 2023-11-29 16:31:58 --> Helper loaded: url_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: file_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: form_helper
INFO - 2023-11-29 16:31:58 --> Helper loaded: my_helper
INFO - 2023-11-29 16:31:58 --> Database Driver Class Initialized
INFO - 2023-11-29 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:31:58 --> Controller Class Initialized
INFO - 2023-11-29 16:31:58 --> Final output sent to browser
DEBUG - 2023-11-29 16:31:58 --> Total execution time: 0.0362
INFO - 2023-11-29 16:32:04 --> Config Class Initialized
INFO - 2023-11-29 16:32:04 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:32:04 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:32:04 --> Utf8 Class Initialized
INFO - 2023-11-29 16:32:04 --> URI Class Initialized
INFO - 2023-11-29 16:32:04 --> Router Class Initialized
INFO - 2023-11-29 16:32:04 --> Output Class Initialized
INFO - 2023-11-29 16:32:04 --> Security Class Initialized
DEBUG - 2023-11-29 16:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:32:04 --> Input Class Initialized
INFO - 2023-11-29 16:32:04 --> Language Class Initialized
INFO - 2023-11-29 16:32:04 --> Language Class Initialized
INFO - 2023-11-29 16:32:04 --> Config Class Initialized
INFO - 2023-11-29 16:32:04 --> Loader Class Initialized
INFO - 2023-11-29 16:32:04 --> Helper loaded: url_helper
INFO - 2023-11-29 16:32:04 --> Helper loaded: file_helper
INFO - 2023-11-29 16:32:04 --> Helper loaded: form_helper
INFO - 2023-11-29 16:32:04 --> Helper loaded: my_helper
INFO - 2023-11-29 16:32:04 --> Database Driver Class Initialized
INFO - 2023-11-29 16:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:32:04 --> Controller Class Initialized
INFO - 2023-11-29 16:32:04 --> Final output sent to browser
DEBUG - 2023-11-29 16:32:04 --> Total execution time: 0.0460
INFO - 2023-11-29 16:32:13 --> Config Class Initialized
INFO - 2023-11-29 16:32:13 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:32:13 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:32:13 --> Utf8 Class Initialized
INFO - 2023-11-29 16:32:13 --> URI Class Initialized
INFO - 2023-11-29 16:32:13 --> Router Class Initialized
INFO - 2023-11-29 16:32:13 --> Output Class Initialized
INFO - 2023-11-29 16:32:13 --> Security Class Initialized
DEBUG - 2023-11-29 16:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:32:13 --> Input Class Initialized
INFO - 2023-11-29 16:32:13 --> Language Class Initialized
INFO - 2023-11-29 16:32:13 --> Language Class Initialized
INFO - 2023-11-29 16:32:13 --> Config Class Initialized
INFO - 2023-11-29 16:32:13 --> Loader Class Initialized
INFO - 2023-11-29 16:32:13 --> Helper loaded: url_helper
INFO - 2023-11-29 16:32:13 --> Helper loaded: file_helper
INFO - 2023-11-29 16:32:13 --> Helper loaded: form_helper
INFO - 2023-11-29 16:32:13 --> Helper loaded: my_helper
INFO - 2023-11-29 16:32:13 --> Database Driver Class Initialized
INFO - 2023-11-29 16:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:32:13 --> Controller Class Initialized
INFO - 2023-11-29 16:32:13 --> Final output sent to browser
DEBUG - 2023-11-29 16:32:13 --> Total execution time: 0.0366
INFO - 2023-11-29 16:32:21 --> Config Class Initialized
INFO - 2023-11-29 16:32:21 --> Hooks Class Initialized
DEBUG - 2023-11-29 16:32:21 --> UTF-8 Support Enabled
INFO - 2023-11-29 16:32:21 --> Utf8 Class Initialized
INFO - 2023-11-29 16:32:21 --> URI Class Initialized
INFO - 2023-11-29 16:32:21 --> Router Class Initialized
INFO - 2023-11-29 16:32:21 --> Output Class Initialized
INFO - 2023-11-29 16:32:21 --> Security Class Initialized
DEBUG - 2023-11-29 16:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 16:32:21 --> Input Class Initialized
INFO - 2023-11-29 16:32:21 --> Language Class Initialized
INFO - 2023-11-29 16:32:21 --> Language Class Initialized
INFO - 2023-11-29 16:32:21 --> Config Class Initialized
INFO - 2023-11-29 16:32:21 --> Loader Class Initialized
INFO - 2023-11-29 16:32:21 --> Helper loaded: url_helper
INFO - 2023-11-29 16:32:21 --> Helper loaded: file_helper
INFO - 2023-11-29 16:32:21 --> Helper loaded: form_helper
INFO - 2023-11-29 16:32:21 --> Helper loaded: my_helper
INFO - 2023-11-29 16:32:21 --> Database Driver Class Initialized
INFO - 2023-11-29 16:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 16:32:21 --> Controller Class Initialized
INFO - 2023-11-29 16:32:21 --> Final output sent to browser
DEBUG - 2023-11-29 16:32:21 --> Total execution time: 0.0374
INFO - 2023-11-29 22:51:52 --> Config Class Initialized
INFO - 2023-11-29 22:51:52 --> Hooks Class Initialized
DEBUG - 2023-11-29 22:51:52 --> UTF-8 Support Enabled
INFO - 2023-11-29 22:51:52 --> Utf8 Class Initialized
INFO - 2023-11-29 22:51:52 --> URI Class Initialized
INFO - 2023-11-29 22:51:52 --> Router Class Initialized
INFO - 2023-11-29 22:51:52 --> Output Class Initialized
INFO - 2023-11-29 22:51:52 --> Security Class Initialized
DEBUG - 2023-11-29 22:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-29 22:51:52 --> Input Class Initialized
INFO - 2023-11-29 22:51:52 --> Language Class Initialized
INFO - 2023-11-29 22:51:52 --> Language Class Initialized
INFO - 2023-11-29 22:51:52 --> Config Class Initialized
INFO - 2023-11-29 22:51:52 --> Loader Class Initialized
INFO - 2023-11-29 22:51:52 --> Helper loaded: url_helper
INFO - 2023-11-29 22:51:52 --> Helper loaded: file_helper
INFO - 2023-11-29 22:51:52 --> Helper loaded: form_helper
INFO - 2023-11-29 22:51:52 --> Helper loaded: my_helper
INFO - 2023-11-29 22:51:52 --> Database Driver Class Initialized
INFO - 2023-11-29 22:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-29 22:51:52 --> Controller Class Initialized
DEBUG - 2023-11-29 22:51:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-29 22:51:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-29 22:51:52 --> Final output sent to browser
DEBUG - 2023-11-29 22:51:52 --> Total execution time: 0.0681
