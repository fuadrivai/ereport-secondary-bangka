<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-06 04:47:45 --> Config Class Initialized
INFO - 2020-02-06 04:47:45 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:47:45 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:47:45 --> Utf8 Class Initialized
INFO - 2020-02-06 04:47:45 --> URI Class Initialized
DEBUG - 2020-02-06 04:47:46 --> No URI present. Default controller set.
INFO - 2020-02-06 04:47:46 --> Router Class Initialized
INFO - 2020-02-06 04:47:46 --> Output Class Initialized
INFO - 2020-02-06 04:47:46 --> Security Class Initialized
DEBUG - 2020-02-06 04:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:47:46 --> Input Class Initialized
INFO - 2020-02-06 04:47:46 --> Language Class Initialized
INFO - 2020-02-06 04:47:46 --> Language Class Initialized
INFO - 2020-02-06 04:47:46 --> Config Class Initialized
INFO - 2020-02-06 04:47:46 --> Loader Class Initialized
INFO - 2020-02-06 04:47:46 --> Helper loaded: url_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: file_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: form_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: my_helper
INFO - 2020-02-06 04:47:46 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:47:46 --> Controller Class Initialized
INFO - 2020-02-06 04:47:46 --> Config Class Initialized
INFO - 2020-02-06 04:47:46 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:47:46 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:47:46 --> Utf8 Class Initialized
INFO - 2020-02-06 04:47:46 --> URI Class Initialized
INFO - 2020-02-06 04:47:46 --> Router Class Initialized
INFO - 2020-02-06 04:47:46 --> Output Class Initialized
INFO - 2020-02-06 04:47:46 --> Security Class Initialized
DEBUG - 2020-02-06 04:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:47:46 --> Input Class Initialized
INFO - 2020-02-06 04:47:46 --> Language Class Initialized
INFO - 2020-02-06 04:47:46 --> Language Class Initialized
INFO - 2020-02-06 04:47:46 --> Config Class Initialized
INFO - 2020-02-06 04:47:46 --> Loader Class Initialized
INFO - 2020-02-06 04:47:46 --> Helper loaded: url_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: file_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: form_helper
INFO - 2020-02-06 04:47:46 --> Helper loaded: my_helper
INFO - 2020-02-06 04:47:46 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:47:46 --> Controller Class Initialized
DEBUG - 2020-02-06 04:47:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-06 04:47:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-06 04:47:47 --> Final output sent to browser
DEBUG - 2020-02-06 04:47:47 --> Total execution time: 0.2862
INFO - 2020-02-06 04:47:54 --> Config Class Initialized
INFO - 2020-02-06 04:47:54 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:47:54 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:47:54 --> Utf8 Class Initialized
INFO - 2020-02-06 04:47:54 --> URI Class Initialized
INFO - 2020-02-06 04:47:54 --> Router Class Initialized
INFO - 2020-02-06 04:47:54 --> Output Class Initialized
INFO - 2020-02-06 04:47:54 --> Security Class Initialized
DEBUG - 2020-02-06 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:47:54 --> Input Class Initialized
INFO - 2020-02-06 04:47:54 --> Language Class Initialized
INFO - 2020-02-06 04:47:54 --> Language Class Initialized
INFO - 2020-02-06 04:47:54 --> Config Class Initialized
INFO - 2020-02-06 04:47:54 --> Loader Class Initialized
INFO - 2020-02-06 04:47:54 --> Helper loaded: url_helper
INFO - 2020-02-06 04:47:54 --> Helper loaded: file_helper
INFO - 2020-02-06 04:47:54 --> Helper loaded: form_helper
INFO - 2020-02-06 04:47:54 --> Helper loaded: my_helper
INFO - 2020-02-06 04:47:54 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:47:54 --> Controller Class Initialized
INFO - 2020-02-06 04:47:54 --> Helper loaded: cookie_helper
INFO - 2020-02-06 04:47:54 --> Final output sent to browser
DEBUG - 2020-02-06 04:47:54 --> Total execution time: 0.3253
INFO - 2020-02-06 04:47:54 --> Config Class Initialized
INFO - 2020-02-06 04:47:54 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:47:54 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:47:54 --> Utf8 Class Initialized
INFO - 2020-02-06 04:47:54 --> URI Class Initialized
INFO - 2020-02-06 04:47:54 --> Router Class Initialized
INFO - 2020-02-06 04:47:54 --> Output Class Initialized
INFO - 2020-02-06 04:47:54 --> Security Class Initialized
DEBUG - 2020-02-06 04:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:47:54 --> Input Class Initialized
INFO - 2020-02-06 04:47:54 --> Language Class Initialized
INFO - 2020-02-06 04:47:54 --> Language Class Initialized
INFO - 2020-02-06 04:47:54 --> Config Class Initialized
INFO - 2020-02-06 04:47:55 --> Loader Class Initialized
INFO - 2020-02-06 04:47:55 --> Helper loaded: url_helper
INFO - 2020-02-06 04:47:55 --> Helper loaded: file_helper
INFO - 2020-02-06 04:47:55 --> Helper loaded: form_helper
INFO - 2020-02-06 04:47:55 --> Helper loaded: my_helper
INFO - 2020-02-06 04:47:55 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:47:55 --> Controller Class Initialized
DEBUG - 2020-02-06 04:47:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-06 04:47:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-06 04:47:55 --> Final output sent to browser
DEBUG - 2020-02-06 04:47:55 --> Total execution time: 0.3842
INFO - 2020-02-06 04:48:00 --> Config Class Initialized
INFO - 2020-02-06 04:48:00 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:48:00 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:48:00 --> Utf8 Class Initialized
INFO - 2020-02-06 04:48:00 --> URI Class Initialized
INFO - 2020-02-06 04:48:00 --> Router Class Initialized
INFO - 2020-02-06 04:48:00 --> Output Class Initialized
INFO - 2020-02-06 04:48:00 --> Security Class Initialized
DEBUG - 2020-02-06 04:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:48:00 --> Input Class Initialized
INFO - 2020-02-06 04:48:00 --> Language Class Initialized
INFO - 2020-02-06 04:48:00 --> Language Class Initialized
INFO - 2020-02-06 04:48:00 --> Config Class Initialized
INFO - 2020-02-06 04:48:00 --> Loader Class Initialized
INFO - 2020-02-06 04:48:00 --> Helper loaded: url_helper
INFO - 2020-02-06 04:48:00 --> Helper loaded: file_helper
INFO - 2020-02-06 04:48:00 --> Helper loaded: form_helper
INFO - 2020-02-06 04:48:01 --> Helper loaded: my_helper
INFO - 2020-02-06 04:48:01 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:48:01 --> Controller Class Initialized
DEBUG - 2020-02-06 04:48:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-06 04:48:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-06 04:48:01 --> Final output sent to browser
DEBUG - 2020-02-06 04:48:01 --> Total execution time: 0.3018
INFO - 2020-02-06 04:48:04 --> Config Class Initialized
INFO - 2020-02-06 04:48:04 --> Hooks Class Initialized
DEBUG - 2020-02-06 04:48:04 --> UTF-8 Support Enabled
INFO - 2020-02-06 04:48:04 --> Utf8 Class Initialized
INFO - 2020-02-06 04:48:04 --> URI Class Initialized
INFO - 2020-02-06 04:48:04 --> Router Class Initialized
INFO - 2020-02-06 04:48:04 --> Output Class Initialized
INFO - 2020-02-06 04:48:04 --> Security Class Initialized
DEBUG - 2020-02-06 04:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-06 04:48:04 --> Input Class Initialized
INFO - 2020-02-06 04:48:04 --> Language Class Initialized
INFO - 2020-02-06 04:48:04 --> Language Class Initialized
INFO - 2020-02-06 04:48:04 --> Config Class Initialized
INFO - 2020-02-06 04:48:04 --> Loader Class Initialized
INFO - 2020-02-06 04:48:04 --> Helper loaded: url_helper
INFO - 2020-02-06 04:48:04 --> Helper loaded: file_helper
INFO - 2020-02-06 04:48:04 --> Helper loaded: form_helper
INFO - 2020-02-06 04:48:04 --> Helper loaded: my_helper
INFO - 2020-02-06 04:48:04 --> Database Driver Class Initialized
DEBUG - 2020-02-06 04:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-06 04:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-06 04:48:04 --> Controller Class Initialized
