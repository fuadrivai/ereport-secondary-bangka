<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-04 06:48:26 --> Config Class Initialized
INFO - 2023-07-04 06:48:26 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:48:26 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:48:26 --> Utf8 Class Initialized
INFO - 2023-07-04 06:48:26 --> URI Class Initialized
DEBUG - 2023-07-04 06:48:26 --> No URI present. Default controller set.
INFO - 2023-07-04 06:48:26 --> Router Class Initialized
INFO - 2023-07-04 06:48:26 --> Output Class Initialized
INFO - 2023-07-04 06:48:26 --> Security Class Initialized
DEBUG - 2023-07-04 06:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:48:26 --> Input Class Initialized
INFO - 2023-07-04 06:48:26 --> Language Class Initialized
INFO - 2023-07-04 06:48:26 --> Language Class Initialized
INFO - 2023-07-04 06:48:26 --> Config Class Initialized
INFO - 2023-07-04 06:48:26 --> Loader Class Initialized
INFO - 2023-07-04 06:48:26 --> Helper loaded: url_helper
INFO - 2023-07-04 06:48:26 --> Helper loaded: file_helper
INFO - 2023-07-04 06:48:26 --> Helper loaded: form_helper
INFO - 2023-07-04 06:48:26 --> Helper loaded: my_helper
INFO - 2023-07-04 06:48:26 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:48:27 --> Controller Class Initialized
INFO - 2023-07-04 06:48:27 --> Config Class Initialized
INFO - 2023-07-04 06:48:27 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:48:27 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:48:27 --> Utf8 Class Initialized
INFO - 2023-07-04 06:48:27 --> URI Class Initialized
INFO - 2023-07-04 06:48:27 --> Router Class Initialized
INFO - 2023-07-04 06:48:27 --> Output Class Initialized
INFO - 2023-07-04 06:48:27 --> Security Class Initialized
DEBUG - 2023-07-04 06:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:48:27 --> Input Class Initialized
INFO - 2023-07-04 06:48:27 --> Language Class Initialized
INFO - 2023-07-04 06:48:27 --> Language Class Initialized
INFO - 2023-07-04 06:48:27 --> Config Class Initialized
INFO - 2023-07-04 06:48:27 --> Loader Class Initialized
INFO - 2023-07-04 06:48:27 --> Helper loaded: url_helper
INFO - 2023-07-04 06:48:27 --> Helper loaded: file_helper
INFO - 2023-07-04 06:48:27 --> Helper loaded: form_helper
INFO - 2023-07-04 06:48:27 --> Helper loaded: my_helper
INFO - 2023-07-04 06:48:27 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:48:27 --> Controller Class Initialized
DEBUG - 2023-07-04 06:48:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:48:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:48:27 --> Final output sent to browser
DEBUG - 2023-07-04 06:48:27 --> Total execution time: 0.1013
INFO - 2023-07-04 06:51:32 --> Config Class Initialized
INFO - 2023-07-04 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:51:32 --> Utf8 Class Initialized
INFO - 2023-07-04 06:51:32 --> URI Class Initialized
INFO - 2023-07-04 06:51:32 --> Router Class Initialized
INFO - 2023-07-04 06:51:32 --> Output Class Initialized
INFO - 2023-07-04 06:51:32 --> Security Class Initialized
DEBUG - 2023-07-04 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:51:32 --> Input Class Initialized
INFO - 2023-07-04 06:51:32 --> Language Class Initialized
INFO - 2023-07-04 06:51:32 --> Language Class Initialized
INFO - 2023-07-04 06:51:32 --> Config Class Initialized
INFO - 2023-07-04 06:51:32 --> Loader Class Initialized
INFO - 2023-07-04 06:51:32 --> Helper loaded: url_helper
INFO - 2023-07-04 06:51:32 --> Helper loaded: file_helper
INFO - 2023-07-04 06:51:32 --> Helper loaded: form_helper
INFO - 2023-07-04 06:51:32 --> Helper loaded: my_helper
INFO - 2023-07-04 06:51:32 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:51:32 --> Controller Class Initialized
DEBUG - 2023-07-04 06:51:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:51:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:51:32 --> Final output sent to browser
DEBUG - 2023-07-04 06:51:32 --> Total execution time: 0.0716
INFO - 2023-07-04 06:52:16 --> Config Class Initialized
INFO - 2023-07-04 06:52:16 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:52:16 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:52:16 --> Utf8 Class Initialized
INFO - 2023-07-04 06:52:16 --> URI Class Initialized
INFO - 2023-07-04 06:52:16 --> Router Class Initialized
INFO - 2023-07-04 06:52:16 --> Output Class Initialized
INFO - 2023-07-04 06:52:16 --> Security Class Initialized
DEBUG - 2023-07-04 06:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:52:16 --> Input Class Initialized
INFO - 2023-07-04 06:52:16 --> Language Class Initialized
ERROR - 2023-07-04 06:52:16 --> 404 Page Not Found: /index
INFO - 2023-07-04 06:52:45 --> Config Class Initialized
INFO - 2023-07-04 06:52:45 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:52:45 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:52:45 --> Utf8 Class Initialized
INFO - 2023-07-04 06:52:45 --> URI Class Initialized
INFO - 2023-07-04 06:52:45 --> Router Class Initialized
INFO - 2023-07-04 06:52:45 --> Output Class Initialized
INFO - 2023-07-04 06:52:45 --> Security Class Initialized
DEBUG - 2023-07-04 06:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:52:45 --> Input Class Initialized
INFO - 2023-07-04 06:52:45 --> Language Class Initialized
INFO - 2023-07-04 06:52:45 --> Language Class Initialized
INFO - 2023-07-04 06:52:45 --> Config Class Initialized
INFO - 2023-07-04 06:52:45 --> Loader Class Initialized
INFO - 2023-07-04 06:52:45 --> Helper loaded: url_helper
INFO - 2023-07-04 06:52:45 --> Helper loaded: file_helper
INFO - 2023-07-04 06:52:45 --> Helper loaded: form_helper
INFO - 2023-07-04 06:52:45 --> Helper loaded: my_helper
INFO - 2023-07-04 06:52:45 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:52:45 --> Controller Class Initialized
DEBUG - 2023-07-04 06:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:52:45 --> Final output sent to browser
DEBUG - 2023-07-04 06:52:45 --> Total execution time: 0.0557
INFO - 2023-07-04 06:52:45 --> Config Class Initialized
INFO - 2023-07-04 06:52:45 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:52:45 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:52:45 --> Utf8 Class Initialized
INFO - 2023-07-04 06:52:45 --> URI Class Initialized
INFO - 2023-07-04 06:52:45 --> Router Class Initialized
INFO - 2023-07-04 06:52:45 --> Output Class Initialized
INFO - 2023-07-04 06:52:45 --> Security Class Initialized
DEBUG - 2023-07-04 06:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:52:45 --> Input Class Initialized
INFO - 2023-07-04 06:52:45 --> Language Class Initialized
ERROR - 2023-07-04 06:52:45 --> 404 Page Not Found: /index
INFO - 2023-07-04 06:53:07 --> Config Class Initialized
INFO - 2023-07-04 06:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:53:07 --> Utf8 Class Initialized
INFO - 2023-07-04 06:53:07 --> URI Class Initialized
INFO - 2023-07-04 06:53:07 --> Router Class Initialized
INFO - 2023-07-04 06:53:07 --> Output Class Initialized
INFO - 2023-07-04 06:53:07 --> Security Class Initialized
DEBUG - 2023-07-04 06:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:53:07 --> Input Class Initialized
INFO - 2023-07-04 06:53:07 --> Language Class Initialized
INFO - 2023-07-04 06:53:07 --> Language Class Initialized
INFO - 2023-07-04 06:53:07 --> Config Class Initialized
INFO - 2023-07-04 06:53:07 --> Loader Class Initialized
INFO - 2023-07-04 06:53:07 --> Helper loaded: url_helper
INFO - 2023-07-04 06:53:07 --> Helper loaded: file_helper
INFO - 2023-07-04 06:53:07 --> Helper loaded: form_helper
INFO - 2023-07-04 06:53:07 --> Helper loaded: my_helper
INFO - 2023-07-04 06:53:07 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:53:07 --> Controller Class Initialized
DEBUG - 2023-07-04 06:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:53:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:53:07 --> Final output sent to browser
DEBUG - 2023-07-04 06:53:07 --> Total execution time: 0.0488
INFO - 2023-07-04 06:53:07 --> Config Class Initialized
INFO - 2023-07-04 06:53:07 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:53:07 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:53:07 --> Utf8 Class Initialized
INFO - 2023-07-04 06:53:07 --> URI Class Initialized
INFO - 2023-07-04 06:53:07 --> Router Class Initialized
INFO - 2023-07-04 06:53:07 --> Output Class Initialized
INFO - 2023-07-04 06:53:07 --> Security Class Initialized
DEBUG - 2023-07-04 06:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:53:07 --> Input Class Initialized
INFO - 2023-07-04 06:53:07 --> Language Class Initialized
ERROR - 2023-07-04 06:53:07 --> 404 Page Not Found: /index
INFO - 2023-07-04 06:54:05 --> Config Class Initialized
INFO - 2023-07-04 06:54:05 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:54:05 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:54:05 --> Utf8 Class Initialized
INFO - 2023-07-04 06:54:05 --> URI Class Initialized
INFO - 2023-07-04 06:54:05 --> Router Class Initialized
INFO - 2023-07-04 06:54:05 --> Output Class Initialized
INFO - 2023-07-04 06:54:05 --> Security Class Initialized
DEBUG - 2023-07-04 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:54:05 --> Input Class Initialized
INFO - 2023-07-04 06:54:05 --> Language Class Initialized
INFO - 2023-07-04 06:54:05 --> Language Class Initialized
INFO - 2023-07-04 06:54:05 --> Config Class Initialized
INFO - 2023-07-04 06:54:05 --> Loader Class Initialized
INFO - 2023-07-04 06:54:05 --> Helper loaded: url_helper
INFO - 2023-07-04 06:54:05 --> Helper loaded: file_helper
INFO - 2023-07-04 06:54:05 --> Helper loaded: form_helper
INFO - 2023-07-04 06:54:05 --> Helper loaded: my_helper
INFO - 2023-07-04 06:54:05 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:54:05 --> Controller Class Initialized
DEBUG - 2023-07-04 06:54:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:54:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:54:06 --> Final output sent to browser
DEBUG - 2023-07-04 06:54:06 --> Total execution time: 0.0662
INFO - 2023-07-04 06:55:42 --> Config Class Initialized
INFO - 2023-07-04 06:55:42 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:55:42 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:55:42 --> Utf8 Class Initialized
INFO - 2023-07-04 06:55:42 --> URI Class Initialized
INFO - 2023-07-04 06:55:42 --> Router Class Initialized
INFO - 2023-07-04 06:55:42 --> Output Class Initialized
INFO - 2023-07-04 06:55:42 --> Security Class Initialized
DEBUG - 2023-07-04 06:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:55:42 --> Input Class Initialized
INFO - 2023-07-04 06:55:42 --> Language Class Initialized
ERROR - 2023-07-04 06:55:42 --> 404 Page Not Found: /index
INFO - 2023-07-04 06:55:46 --> Config Class Initialized
INFO - 2023-07-04 06:55:46 --> Hooks Class Initialized
DEBUG - 2023-07-04 06:55:46 --> UTF-8 Support Enabled
INFO - 2023-07-04 06:55:46 --> Utf8 Class Initialized
INFO - 2023-07-04 06:55:46 --> URI Class Initialized
INFO - 2023-07-04 06:55:46 --> Router Class Initialized
INFO - 2023-07-04 06:55:46 --> Output Class Initialized
INFO - 2023-07-04 06:55:46 --> Security Class Initialized
DEBUG - 2023-07-04 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 06:55:46 --> Input Class Initialized
INFO - 2023-07-04 06:55:46 --> Language Class Initialized
INFO - 2023-07-04 06:55:46 --> Language Class Initialized
INFO - 2023-07-04 06:55:46 --> Config Class Initialized
INFO - 2023-07-04 06:55:46 --> Loader Class Initialized
INFO - 2023-07-04 06:55:46 --> Helper loaded: url_helper
INFO - 2023-07-04 06:55:46 --> Helper loaded: file_helper
INFO - 2023-07-04 06:55:46 --> Helper loaded: form_helper
INFO - 2023-07-04 06:55:46 --> Helper loaded: my_helper
INFO - 2023-07-04 06:55:46 --> Database Driver Class Initialized
DEBUG - 2023-07-04 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 06:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 06:55:46 --> Controller Class Initialized
DEBUG - 2023-07-04 06:55:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-07-04 06:55:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-07-04 06:55:46 --> Final output sent to browser
DEBUG - 2023-07-04 06:55:46 --> Total execution time: 0.0381
INFO - 2023-07-04 07:43:24 --> Config Class Initialized
INFO - 2023-07-04 07:43:24 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:43:24 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:43:24 --> Utf8 Class Initialized
INFO - 2023-07-04 07:43:24 --> URI Class Initialized
DEBUG - 2023-07-04 07:43:24 --> No URI present. Default controller set.
INFO - 2023-07-04 07:43:24 --> Router Class Initialized
INFO - 2023-07-04 07:43:24 --> Output Class Initialized
INFO - 2023-07-04 07:43:24 --> Security Class Initialized
DEBUG - 2023-07-04 07:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:43:24 --> Input Class Initialized
INFO - 2023-07-04 07:43:24 --> Language Class Initialized
INFO - 2023-07-04 07:43:24 --> Language Class Initialized
INFO - 2023-07-04 07:43:24 --> Config Class Initialized
INFO - 2023-07-04 07:43:24 --> Loader Class Initialized
INFO - 2023-07-04 07:43:24 --> Helper loaded: url_helper
INFO - 2023-07-04 07:43:24 --> Helper loaded: file_helper
INFO - 2023-07-04 07:43:24 --> Helper loaded: form_helper
INFO - 2023-07-04 07:43:24 --> Helper loaded: my_helper
INFO - 2023-07-04 07:43:24 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:43:24 --> Controller Class Initialized
INFO - 2023-07-04 07:43:51 --> Config Class Initialized
INFO - 2023-07-04 07:43:51 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:43:51 --> Utf8 Class Initialized
INFO - 2023-07-04 07:43:51 --> URI Class Initialized
DEBUG - 2023-07-04 07:43:51 --> No URI present. Default controller set.
INFO - 2023-07-04 07:43:51 --> Router Class Initialized
INFO - 2023-07-04 07:43:51 --> Output Class Initialized
INFO - 2023-07-04 07:43:51 --> Security Class Initialized
DEBUG - 2023-07-04 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:43:51 --> Input Class Initialized
INFO - 2023-07-04 07:43:51 --> Language Class Initialized
INFO - 2023-07-04 07:43:51 --> Language Class Initialized
INFO - 2023-07-04 07:43:51 --> Config Class Initialized
INFO - 2023-07-04 07:43:51 --> Loader Class Initialized
INFO - 2023-07-04 07:43:51 --> Helper loaded: url_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: file_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: form_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: my_helper
INFO - 2023-07-04 07:43:51 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:43:51 --> Controller Class Initialized
INFO - 2023-07-04 07:43:51 --> Config Class Initialized
INFO - 2023-07-04 07:43:51 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:43:51 --> Utf8 Class Initialized
INFO - 2023-07-04 07:43:51 --> URI Class Initialized
INFO - 2023-07-04 07:43:51 --> Router Class Initialized
INFO - 2023-07-04 07:43:51 --> Output Class Initialized
INFO - 2023-07-04 07:43:51 --> Security Class Initialized
DEBUG - 2023-07-04 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:43:51 --> Input Class Initialized
INFO - 2023-07-04 07:43:51 --> Language Class Initialized
INFO - 2023-07-04 07:43:51 --> Language Class Initialized
INFO - 2023-07-04 07:43:51 --> Config Class Initialized
INFO - 2023-07-04 07:43:51 --> Loader Class Initialized
INFO - 2023-07-04 07:43:51 --> Helper loaded: url_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: file_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: form_helper
INFO - 2023-07-04 07:43:51 --> Helper loaded: my_helper
INFO - 2023-07-04 07:43:51 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:43:51 --> Controller Class Initialized
DEBUG - 2023-07-04 07:43:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-04 07:43:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-04 07:43:51 --> Final output sent to browser
DEBUG - 2023-07-04 07:43:51 --> Total execution time: 0.0295
INFO - 2023-07-04 07:44:36 --> Config Class Initialized
INFO - 2023-07-04 07:44:36 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:44:36 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:44:36 --> Utf8 Class Initialized
INFO - 2023-07-04 07:44:36 --> URI Class Initialized
DEBUG - 2023-07-04 07:44:36 --> No URI present. Default controller set.
INFO - 2023-07-04 07:44:36 --> Router Class Initialized
INFO - 2023-07-04 07:44:36 --> Output Class Initialized
INFO - 2023-07-04 07:44:36 --> Security Class Initialized
DEBUG - 2023-07-04 07:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:44:36 --> Input Class Initialized
INFO - 2023-07-04 07:44:36 --> Language Class Initialized
INFO - 2023-07-04 07:44:36 --> Language Class Initialized
INFO - 2023-07-04 07:44:36 --> Config Class Initialized
INFO - 2023-07-04 07:44:36 --> Loader Class Initialized
INFO - 2023-07-04 07:44:36 --> Helper loaded: url_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: file_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: form_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: my_helper
INFO - 2023-07-04 07:44:36 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:44:36 --> Controller Class Initialized
INFO - 2023-07-04 07:44:36 --> Config Class Initialized
INFO - 2023-07-04 07:44:36 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:44:36 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:44:36 --> Utf8 Class Initialized
INFO - 2023-07-04 07:44:36 --> URI Class Initialized
INFO - 2023-07-04 07:44:36 --> Router Class Initialized
INFO - 2023-07-04 07:44:36 --> Output Class Initialized
INFO - 2023-07-04 07:44:36 --> Security Class Initialized
DEBUG - 2023-07-04 07:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:44:36 --> Input Class Initialized
INFO - 2023-07-04 07:44:36 --> Language Class Initialized
INFO - 2023-07-04 07:44:36 --> Language Class Initialized
INFO - 2023-07-04 07:44:36 --> Config Class Initialized
INFO - 2023-07-04 07:44:36 --> Loader Class Initialized
INFO - 2023-07-04 07:44:36 --> Helper loaded: url_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: file_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: form_helper
INFO - 2023-07-04 07:44:36 --> Helper loaded: my_helper
INFO - 2023-07-04 07:44:36 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:44:36 --> Controller Class Initialized
DEBUG - 2023-07-04 07:44:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-04 07:44:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-04 07:44:36 --> Final output sent to browser
DEBUG - 2023-07-04 07:44:36 --> Total execution time: 0.0261
INFO - 2023-07-04 07:57:00 --> Config Class Initialized
INFO - 2023-07-04 07:57:00 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:57:00 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:57:00 --> Utf8 Class Initialized
INFO - 2023-07-04 07:57:00 --> URI Class Initialized
DEBUG - 2023-07-04 07:57:00 --> No URI present. Default controller set.
INFO - 2023-07-04 07:57:00 --> Router Class Initialized
INFO - 2023-07-04 07:57:00 --> Output Class Initialized
INFO - 2023-07-04 07:57:00 --> Security Class Initialized
DEBUG - 2023-07-04 07:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:57:00 --> Input Class Initialized
INFO - 2023-07-04 07:57:00 --> Language Class Initialized
INFO - 2023-07-04 07:57:00 --> Language Class Initialized
INFO - 2023-07-04 07:57:00 --> Config Class Initialized
INFO - 2023-07-04 07:57:00 --> Loader Class Initialized
INFO - 2023-07-04 07:57:00 --> Helper loaded: url_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: file_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: form_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: my_helper
INFO - 2023-07-04 07:57:00 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:57:00 --> Controller Class Initialized
INFO - 2023-07-04 07:57:00 --> Config Class Initialized
INFO - 2023-07-04 07:57:00 --> Hooks Class Initialized
DEBUG - 2023-07-04 07:57:00 --> UTF-8 Support Enabled
INFO - 2023-07-04 07:57:00 --> Utf8 Class Initialized
INFO - 2023-07-04 07:57:00 --> URI Class Initialized
INFO - 2023-07-04 07:57:00 --> Router Class Initialized
INFO - 2023-07-04 07:57:00 --> Output Class Initialized
INFO - 2023-07-04 07:57:00 --> Security Class Initialized
DEBUG - 2023-07-04 07:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-04 07:57:00 --> Input Class Initialized
INFO - 2023-07-04 07:57:00 --> Language Class Initialized
INFO - 2023-07-04 07:57:00 --> Language Class Initialized
INFO - 2023-07-04 07:57:00 --> Config Class Initialized
INFO - 2023-07-04 07:57:00 --> Loader Class Initialized
INFO - 2023-07-04 07:57:00 --> Helper loaded: url_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: file_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: form_helper
INFO - 2023-07-04 07:57:00 --> Helper loaded: my_helper
INFO - 2023-07-04 07:57:00 --> Database Driver Class Initialized
DEBUG - 2023-07-04 07:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-04 07:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-04 07:57:00 --> Controller Class Initialized
DEBUG - 2023-07-04 07:57:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-04 07:57:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-04 07:57:00 --> Final output sent to browser
DEBUG - 2023-07-04 07:57:00 --> Total execution time: 0.0439
