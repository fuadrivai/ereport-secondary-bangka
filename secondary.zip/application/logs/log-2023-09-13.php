<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-13 08:42:47 --> Config Class Initialized
INFO - 2023-09-13 08:42:47 --> Hooks Class Initialized
DEBUG - 2023-09-13 08:42:47 --> UTF-8 Support Enabled
INFO - 2023-09-13 08:42:47 --> Utf8 Class Initialized
INFO - 2023-09-13 08:42:47 --> URI Class Initialized
INFO - 2023-09-13 08:42:47 --> Router Class Initialized
INFO - 2023-09-13 08:42:47 --> Output Class Initialized
INFO - 2023-09-13 08:42:47 --> Security Class Initialized
DEBUG - 2023-09-13 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 08:42:47 --> Input Class Initialized
INFO - 2023-09-13 08:42:47 --> Language Class Initialized
INFO - 2023-09-13 08:42:47 --> Language Class Initialized
INFO - 2023-09-13 08:42:47 --> Config Class Initialized
INFO - 2023-09-13 08:42:47 --> Loader Class Initialized
INFO - 2023-09-13 08:42:47 --> Helper loaded: url_helper
INFO - 2023-09-13 08:42:47 --> Helper loaded: file_helper
INFO - 2023-09-13 08:42:47 --> Helper loaded: form_helper
INFO - 2023-09-13 08:42:47 --> Helper loaded: my_helper
INFO - 2023-09-13 08:42:47 --> Database Driver Class Initialized
INFO - 2023-09-13 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 08:42:47 --> Controller Class Initialized
DEBUG - 2023-09-13 08:42:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 08:42:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 08:42:47 --> Final output sent to browser
DEBUG - 2023-09-13 08:42:47 --> Total execution time: 0.0563
INFO - 2023-09-13 09:18:58 --> Config Class Initialized
INFO - 2023-09-13 09:18:58 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:18:58 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:18:58 --> Utf8 Class Initialized
INFO - 2023-09-13 09:18:58 --> URI Class Initialized
INFO - 2023-09-13 09:18:58 --> Router Class Initialized
INFO - 2023-09-13 09:18:58 --> Output Class Initialized
INFO - 2023-09-13 09:18:58 --> Security Class Initialized
DEBUG - 2023-09-13 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:18:58 --> Input Class Initialized
INFO - 2023-09-13 09:18:58 --> Language Class Initialized
INFO - 2023-09-13 09:18:58 --> Language Class Initialized
INFO - 2023-09-13 09:18:58 --> Config Class Initialized
INFO - 2023-09-13 09:18:58 --> Loader Class Initialized
INFO - 2023-09-13 09:18:58 --> Helper loaded: url_helper
INFO - 2023-09-13 09:18:58 --> Helper loaded: file_helper
INFO - 2023-09-13 09:18:58 --> Helper loaded: form_helper
INFO - 2023-09-13 09:18:58 --> Helper loaded: my_helper
INFO - 2023-09-13 09:18:58 --> Database Driver Class Initialized
INFO - 2023-09-13 09:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:18:58 --> Controller Class Initialized
DEBUG - 2023-09-13 09:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 09:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 09:18:58 --> Final output sent to browser
DEBUG - 2023-09-13 09:18:58 --> Total execution time: 0.0590
INFO - 2023-09-13 09:19:01 --> Config Class Initialized
INFO - 2023-09-13 09:19:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:01 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:01 --> URI Class Initialized
INFO - 2023-09-13 09:19:01 --> Router Class Initialized
INFO - 2023-09-13 09:19:01 --> Output Class Initialized
INFO - 2023-09-13 09:19:01 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:01 --> Input Class Initialized
INFO - 2023-09-13 09:19:01 --> Language Class Initialized
INFO - 2023-09-13 09:19:01 --> Language Class Initialized
INFO - 2023-09-13 09:19:01 --> Config Class Initialized
INFO - 2023-09-13 09:19:01 --> Loader Class Initialized
INFO - 2023-09-13 09:19:01 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:01 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:01 --> Controller Class Initialized
INFO - 2023-09-13 09:19:01 --> Helper loaded: cookie_helper
INFO - 2023-09-13 09:19:01 --> Final output sent to browser
DEBUG - 2023-09-13 09:19:01 --> Total execution time: 0.0498
INFO - 2023-09-13 09:19:01 --> Config Class Initialized
INFO - 2023-09-13 09:19:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:01 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:01 --> URI Class Initialized
INFO - 2023-09-13 09:19:01 --> Router Class Initialized
INFO - 2023-09-13 09:19:01 --> Output Class Initialized
INFO - 2023-09-13 09:19:01 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:01 --> Input Class Initialized
INFO - 2023-09-13 09:19:01 --> Language Class Initialized
INFO - 2023-09-13 09:19:01 --> Language Class Initialized
INFO - 2023-09-13 09:19:01 --> Config Class Initialized
INFO - 2023-09-13 09:19:01 --> Loader Class Initialized
INFO - 2023-09-13 09:19:01 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:01 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:01 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:01 --> Controller Class Initialized
DEBUG - 2023-09-13 09:19:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 09:19:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 09:19:01 --> Final output sent to browser
DEBUG - 2023-09-13 09:19:01 --> Total execution time: 0.0443
INFO - 2023-09-13 09:19:06 --> Config Class Initialized
INFO - 2023-09-13 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:06 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:06 --> URI Class Initialized
INFO - 2023-09-13 09:19:06 --> Router Class Initialized
INFO - 2023-09-13 09:19:06 --> Output Class Initialized
INFO - 2023-09-13 09:19:06 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:06 --> Input Class Initialized
INFO - 2023-09-13 09:19:06 --> Language Class Initialized
INFO - 2023-09-13 09:19:06 --> Language Class Initialized
INFO - 2023-09-13 09:19:06 --> Config Class Initialized
INFO - 2023-09-13 09:19:06 --> Loader Class Initialized
INFO - 2023-09-13 09:19:06 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:06 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:06 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:06 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:06 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:06 --> Controller Class Initialized
DEBUG - 2023-09-13 09:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 09:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 09:19:06 --> Final output sent to browser
DEBUG - 2023-09-13 09:19:06 --> Total execution time: 0.0377
INFO - 2023-09-13 09:19:09 --> Config Class Initialized
INFO - 2023-09-13 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:09 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:09 --> URI Class Initialized
INFO - 2023-09-13 09:19:09 --> Router Class Initialized
INFO - 2023-09-13 09:19:09 --> Output Class Initialized
INFO - 2023-09-13 09:19:09 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:09 --> Input Class Initialized
INFO - 2023-09-13 09:19:09 --> Language Class Initialized
INFO - 2023-09-13 09:19:09 --> Language Class Initialized
INFO - 2023-09-13 09:19:09 --> Config Class Initialized
INFO - 2023-09-13 09:19:09 --> Loader Class Initialized
INFO - 2023-09-13 09:19:09 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:09 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:09 --> Controller Class Initialized
DEBUG - 2023-09-13 09:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 09:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 09:19:09 --> Final output sent to browser
DEBUG - 2023-09-13 09:19:09 --> Total execution time: 0.0376
INFO - 2023-09-13 09:19:09 --> Config Class Initialized
INFO - 2023-09-13 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:09 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:09 --> URI Class Initialized
INFO - 2023-09-13 09:19:09 --> Router Class Initialized
INFO - 2023-09-13 09:19:09 --> Output Class Initialized
INFO - 2023-09-13 09:19:09 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:09 --> Input Class Initialized
INFO - 2023-09-13 09:19:09 --> Language Class Initialized
INFO - 2023-09-13 09:19:09 --> Language Class Initialized
INFO - 2023-09-13 09:19:09 --> Config Class Initialized
INFO - 2023-09-13 09:19:09 --> Loader Class Initialized
INFO - 2023-09-13 09:19:09 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:09 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:09 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:09 --> Controller Class Initialized
INFO - 2023-09-13 09:19:23 --> Config Class Initialized
INFO - 2023-09-13 09:19:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 09:19:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 09:19:23 --> Utf8 Class Initialized
INFO - 2023-09-13 09:19:23 --> URI Class Initialized
INFO - 2023-09-13 09:19:23 --> Router Class Initialized
INFO - 2023-09-13 09:19:23 --> Output Class Initialized
INFO - 2023-09-13 09:19:23 --> Security Class Initialized
DEBUG - 2023-09-13 09:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 09:19:23 --> Input Class Initialized
INFO - 2023-09-13 09:19:23 --> Language Class Initialized
INFO - 2023-09-13 09:19:23 --> Language Class Initialized
INFO - 2023-09-13 09:19:23 --> Config Class Initialized
INFO - 2023-09-13 09:19:23 --> Loader Class Initialized
INFO - 2023-09-13 09:19:23 --> Helper loaded: url_helper
INFO - 2023-09-13 09:19:23 --> Helper loaded: file_helper
INFO - 2023-09-13 09:19:23 --> Helper loaded: form_helper
INFO - 2023-09-13 09:19:23 --> Helper loaded: my_helper
INFO - 2023-09-13 09:19:23 --> Database Driver Class Initialized
INFO - 2023-09-13 09:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 09:19:23 --> Controller Class Initialized
INFO - 2023-09-13 09:19:23 --> Final output sent to browser
DEBUG - 2023-09-13 09:19:23 --> Total execution time: 0.0684
INFO - 2023-09-13 15:20:40 --> Config Class Initialized
INFO - 2023-09-13 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 15:20:40 --> Utf8 Class Initialized
INFO - 2023-09-13 15:20:40 --> URI Class Initialized
INFO - 2023-09-13 15:20:40 --> Router Class Initialized
INFO - 2023-09-13 15:20:40 --> Output Class Initialized
INFO - 2023-09-13 15:20:40 --> Security Class Initialized
DEBUG - 2023-09-13 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 15:20:40 --> Input Class Initialized
INFO - 2023-09-13 15:20:40 --> Language Class Initialized
INFO - 2023-09-13 15:20:40 --> Language Class Initialized
INFO - 2023-09-13 15:20:40 --> Config Class Initialized
INFO - 2023-09-13 15:20:40 --> Loader Class Initialized
INFO - 2023-09-13 15:20:40 --> Helper loaded: url_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: file_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: form_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: my_helper
INFO - 2023-09-13 15:20:40 --> Database Driver Class Initialized
INFO - 2023-09-13 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 15:20:40 --> Controller Class Initialized
DEBUG - 2023-09-13 15:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 15:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 15:20:40 --> Final output sent to browser
DEBUG - 2023-09-13 15:20:40 --> Total execution time: 0.0672
INFO - 2023-09-13 15:20:40 --> Config Class Initialized
INFO - 2023-09-13 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 15:20:40 --> Utf8 Class Initialized
INFO - 2023-09-13 15:20:40 --> URI Class Initialized
INFO - 2023-09-13 15:20:40 --> Router Class Initialized
INFO - 2023-09-13 15:20:40 --> Output Class Initialized
INFO - 2023-09-13 15:20:40 --> Security Class Initialized
DEBUG - 2023-09-13 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 15:20:40 --> Input Class Initialized
INFO - 2023-09-13 15:20:40 --> Language Class Initialized
INFO - 2023-09-13 15:20:40 --> Language Class Initialized
INFO - 2023-09-13 15:20:40 --> Config Class Initialized
INFO - 2023-09-13 15:20:40 --> Loader Class Initialized
INFO - 2023-09-13 15:20:40 --> Helper loaded: url_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: file_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: form_helper
INFO - 2023-09-13 15:20:40 --> Helper loaded: my_helper
INFO - 2023-09-13 15:20:40 --> Database Driver Class Initialized
INFO - 2023-09-13 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 15:20:40 --> Controller Class Initialized
INFO - 2023-09-13 16:29:16 --> Config Class Initialized
INFO - 2023-09-13 16:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:16 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:16 --> URI Class Initialized
INFO - 2023-09-13 16:29:16 --> Router Class Initialized
INFO - 2023-09-13 16:29:16 --> Output Class Initialized
INFO - 2023-09-13 16:29:16 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:16 --> Input Class Initialized
INFO - 2023-09-13 16:29:16 --> Language Class Initialized
INFO - 2023-09-13 16:29:16 --> Language Class Initialized
INFO - 2023-09-13 16:29:16 --> Config Class Initialized
INFO - 2023-09-13 16:29:16 --> Loader Class Initialized
INFO - 2023-09-13 16:29:16 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:16 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:16 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:16 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:16 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:16 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:29:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:16 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:16 --> Total execution time: 0.0967
INFO - 2023-09-13 16:29:19 --> Config Class Initialized
INFO - 2023-09-13 16:29:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:19 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:19 --> URI Class Initialized
INFO - 2023-09-13 16:29:19 --> Router Class Initialized
INFO - 2023-09-13 16:29:19 --> Output Class Initialized
INFO - 2023-09-13 16:29:19 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:19 --> Input Class Initialized
INFO - 2023-09-13 16:29:19 --> Language Class Initialized
INFO - 2023-09-13 16:29:19 --> Language Class Initialized
INFO - 2023-09-13 16:29:19 --> Config Class Initialized
INFO - 2023-09-13 16:29:19 --> Loader Class Initialized
INFO - 2023-09-13 16:29:19 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:19 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:19 --> Controller Class Initialized
INFO - 2023-09-13 16:29:19 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:29:19 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:19 --> Total execution time: 0.2355
INFO - 2023-09-13 16:29:19 --> Config Class Initialized
INFO - 2023-09-13 16:29:19 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:19 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:19 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:19 --> URI Class Initialized
INFO - 2023-09-13 16:29:19 --> Router Class Initialized
INFO - 2023-09-13 16:29:19 --> Output Class Initialized
INFO - 2023-09-13 16:29:19 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:19 --> Input Class Initialized
INFO - 2023-09-13 16:29:19 --> Language Class Initialized
INFO - 2023-09-13 16:29:19 --> Language Class Initialized
INFO - 2023-09-13 16:29:19 --> Config Class Initialized
INFO - 2023-09-13 16:29:19 --> Loader Class Initialized
INFO - 2023-09-13 16:29:19 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:19 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:19 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:19 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:20 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:20 --> Total execution time: 0.1155
INFO - 2023-09-13 16:29:23 --> Config Class Initialized
INFO - 2023-09-13 16:29:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:23 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:23 --> URI Class Initialized
INFO - 2023-09-13 16:29:23 --> Router Class Initialized
INFO - 2023-09-13 16:29:23 --> Output Class Initialized
INFO - 2023-09-13 16:29:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:23 --> Input Class Initialized
INFO - 2023-09-13 16:29:23 --> Language Class Initialized
INFO - 2023-09-13 16:29:23 --> Language Class Initialized
INFO - 2023-09-13 16:29:23 --> Config Class Initialized
INFO - 2023-09-13 16:29:23 --> Loader Class Initialized
INFO - 2023-09-13 16:29:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:23 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:23 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:23 --> Total execution time: 0.0321
INFO - 2023-09-13 16:29:23 --> Config Class Initialized
INFO - 2023-09-13 16:29:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:23 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:23 --> URI Class Initialized
INFO - 2023-09-13 16:29:23 --> Router Class Initialized
INFO - 2023-09-13 16:29:23 --> Output Class Initialized
INFO - 2023-09-13 16:29:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:23 --> Input Class Initialized
INFO - 2023-09-13 16:29:23 --> Language Class Initialized
INFO - 2023-09-13 16:29:23 --> Language Class Initialized
INFO - 2023-09-13 16:29:23 --> Config Class Initialized
INFO - 2023-09-13 16:29:23 --> Loader Class Initialized
INFO - 2023-09-13 16:29:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:23 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:23 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:23 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:23 --> Total execution time: 0.0519
INFO - 2023-09-13 16:29:48 --> Config Class Initialized
INFO - 2023-09-13 16:29:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:48 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:48 --> URI Class Initialized
INFO - 2023-09-13 16:29:48 --> Router Class Initialized
INFO - 2023-09-13 16:29:48 --> Output Class Initialized
INFO - 2023-09-13 16:29:48 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:48 --> Input Class Initialized
INFO - 2023-09-13 16:29:48 --> Language Class Initialized
INFO - 2023-09-13 16:29:48 --> Language Class Initialized
INFO - 2023-09-13 16:29:48 --> Config Class Initialized
INFO - 2023-09-13 16:29:48 --> Loader Class Initialized
INFO - 2023-09-13 16:29:48 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:48 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:48 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:48 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:48 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:48 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:29:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:48 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:48 --> Total execution time: 0.0340
INFO - 2023-09-13 16:29:51 --> Config Class Initialized
INFO - 2023-09-13 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:51 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:51 --> URI Class Initialized
INFO - 2023-09-13 16:29:51 --> Router Class Initialized
INFO - 2023-09-13 16:29:51 --> Output Class Initialized
INFO - 2023-09-13 16:29:51 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:51 --> Input Class Initialized
INFO - 2023-09-13 16:29:51 --> Language Class Initialized
INFO - 2023-09-13 16:29:51 --> Language Class Initialized
INFO - 2023-09-13 16:29:51 --> Config Class Initialized
INFO - 2023-09-13 16:29:51 --> Loader Class Initialized
INFO - 2023-09-13 16:29:51 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:51 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:51 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:51 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:51 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:51 --> Controller Class Initialized
DEBUG - 2023-09-13 16:29:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:29:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:29:51 --> Final output sent to browser
DEBUG - 2023-09-13 16:29:51 --> Total execution time: 0.3035
INFO - 2023-09-13 16:29:51 --> Config Class Initialized
INFO - 2023-09-13 16:29:51 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:29:51 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:29:51 --> Utf8 Class Initialized
INFO - 2023-09-13 16:29:51 --> URI Class Initialized
INFO - 2023-09-13 16:29:51 --> Router Class Initialized
INFO - 2023-09-13 16:29:51 --> Output Class Initialized
INFO - 2023-09-13 16:29:51 --> Security Class Initialized
DEBUG - 2023-09-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:29:51 --> Input Class Initialized
INFO - 2023-09-13 16:29:51 --> Language Class Initialized
INFO - 2023-09-13 16:29:52 --> Language Class Initialized
INFO - 2023-09-13 16:29:52 --> Config Class Initialized
INFO - 2023-09-13 16:29:52 --> Loader Class Initialized
INFO - 2023-09-13 16:29:52 --> Helper loaded: url_helper
INFO - 2023-09-13 16:29:52 --> Helper loaded: file_helper
INFO - 2023-09-13 16:29:52 --> Helper loaded: form_helper
INFO - 2023-09-13 16:29:52 --> Helper loaded: my_helper
INFO - 2023-09-13 16:29:52 --> Database Driver Class Initialized
INFO - 2023-09-13 16:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:29:52 --> Controller Class Initialized
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:07 --> URI Class Initialized
INFO - 2023-09-13 16:30:07 --> Router Class Initialized
INFO - 2023-09-13 16:30:07 --> Output Class Initialized
INFO - 2023-09-13 16:30:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:07 --> Input Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Loader Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:07 --> Controller Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:30:07 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:07 --> Total execution time: 0.0491
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:07 --> URI Class Initialized
INFO - 2023-09-13 16:30:07 --> Router Class Initialized
INFO - 2023-09-13 16:30:07 --> Output Class Initialized
INFO - 2023-09-13 16:30:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:07 --> Input Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Loader Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:07 --> Controller Class Initialized
DEBUG - 2023-09-13 16:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:30:07 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:07 --> Total execution time: 0.1005
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:07 --> URI Class Initialized
INFO - 2023-09-13 16:30:07 --> Router Class Initialized
INFO - 2023-09-13 16:30:07 --> Output Class Initialized
INFO - 2023-09-13 16:30:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:07 --> Input Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Loader Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:07 --> Controller Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:30:07 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:07 --> Total execution time: 0.0521
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:07 --> URI Class Initialized
INFO - 2023-09-13 16:30:07 --> Router Class Initialized
INFO - 2023-09-13 16:30:07 --> Output Class Initialized
INFO - 2023-09-13 16:30:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:07 --> Input Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Language Class Initialized
INFO - 2023-09-13 16:30:07 --> Config Class Initialized
INFO - 2023-09-13 16:30:07 --> Loader Class Initialized
INFO - 2023-09-13 16:30:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:07 --> Controller Class Initialized
DEBUG - 2023-09-13 16:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-13 16:30:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:30:07 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:07 --> Total execution time: 0.1170
INFO - 2023-09-13 16:30:13 --> Config Class Initialized
INFO - 2023-09-13 16:30:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:13 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:13 --> URI Class Initialized
INFO - 2023-09-13 16:30:13 --> Router Class Initialized
INFO - 2023-09-13 16:30:13 --> Output Class Initialized
INFO - 2023-09-13 16:30:13 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:13 --> Input Class Initialized
INFO - 2023-09-13 16:30:13 --> Language Class Initialized
INFO - 2023-09-13 16:30:13 --> Language Class Initialized
INFO - 2023-09-13 16:30:13 --> Config Class Initialized
INFO - 2023-09-13 16:30:13 --> Loader Class Initialized
INFO - 2023-09-13 16:30:13 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:13 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:13 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:13 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:13 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:13 --> Controller Class Initialized
DEBUG - 2023-09-13 16:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-13 16:30:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:30:13 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:13 --> Total execution time: 0.3154
INFO - 2023-09-13 16:30:17 --> Config Class Initialized
INFO - 2023-09-13 16:30:17 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:17 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:17 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:17 --> URI Class Initialized
INFO - 2023-09-13 16:30:17 --> Router Class Initialized
INFO - 2023-09-13 16:30:17 --> Output Class Initialized
INFO - 2023-09-13 16:30:17 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:17 --> Input Class Initialized
INFO - 2023-09-13 16:30:17 --> Language Class Initialized
ERROR - 2023-09-13 16:30:17 --> 404 Page Not Found: /index
INFO - 2023-09-13 16:30:20 --> Config Class Initialized
INFO - 2023-09-13 16:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:20 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:20 --> URI Class Initialized
INFO - 2023-09-13 16:30:20 --> Router Class Initialized
INFO - 2023-09-13 16:30:20 --> Output Class Initialized
INFO - 2023-09-13 16:30:20 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:20 --> Input Class Initialized
INFO - 2023-09-13 16:30:20 --> Language Class Initialized
INFO - 2023-09-13 16:30:20 --> Language Class Initialized
INFO - 2023-09-13 16:30:20 --> Config Class Initialized
INFO - 2023-09-13 16:30:20 --> Loader Class Initialized
INFO - 2023-09-13 16:30:20 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:20 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:20 --> Controller Class Initialized
DEBUG - 2023-09-13 16:30:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:30:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:30:20 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:20 --> Total execution time: 0.1730
INFO - 2023-09-13 16:30:20 --> Config Class Initialized
INFO - 2023-09-13 16:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:20 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:20 --> URI Class Initialized
INFO - 2023-09-13 16:30:20 --> Router Class Initialized
INFO - 2023-09-13 16:30:20 --> Output Class Initialized
INFO - 2023-09-13 16:30:20 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:20 --> Input Class Initialized
INFO - 2023-09-13 16:30:20 --> Language Class Initialized
INFO - 2023-09-13 16:30:20 --> Language Class Initialized
INFO - 2023-09-13 16:30:20 --> Config Class Initialized
INFO - 2023-09-13 16:30:20 --> Loader Class Initialized
INFO - 2023-09-13 16:30:20 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:20 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:20 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:20 --> Controller Class Initialized
INFO - 2023-09-13 16:30:23 --> Config Class Initialized
INFO - 2023-09-13 16:30:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:23 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:23 --> URI Class Initialized
INFO - 2023-09-13 16:30:23 --> Router Class Initialized
INFO - 2023-09-13 16:30:23 --> Output Class Initialized
INFO - 2023-09-13 16:30:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:23 --> Input Class Initialized
INFO - 2023-09-13 16:30:23 --> Language Class Initialized
INFO - 2023-09-13 16:30:23 --> Language Class Initialized
INFO - 2023-09-13 16:30:23 --> Config Class Initialized
INFO - 2023-09-13 16:30:23 --> Loader Class Initialized
INFO - 2023-09-13 16:30:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:23 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:23 --> Controller Class Initialized
INFO - 2023-09-13 16:30:23 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:23 --> Total execution time: 0.2383
INFO - 2023-09-13 16:30:26 --> Config Class Initialized
INFO - 2023-09-13 16:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:26 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:26 --> URI Class Initialized
INFO - 2023-09-13 16:30:26 --> Router Class Initialized
INFO - 2023-09-13 16:30:26 --> Output Class Initialized
INFO - 2023-09-13 16:30:26 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:26 --> Input Class Initialized
INFO - 2023-09-13 16:30:26 --> Language Class Initialized
INFO - 2023-09-13 16:30:26 --> Language Class Initialized
INFO - 2023-09-13 16:30:26 --> Config Class Initialized
INFO - 2023-09-13 16:30:26 --> Loader Class Initialized
INFO - 2023-09-13 16:30:26 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:26 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:26 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:26 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:26 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:26 --> Controller Class Initialized
INFO - 2023-09-13 16:30:26 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:26 --> Total execution time: 0.1410
INFO - 2023-09-13 16:30:28 --> Config Class Initialized
INFO - 2023-09-13 16:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:28 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:28 --> URI Class Initialized
INFO - 2023-09-13 16:30:28 --> Router Class Initialized
INFO - 2023-09-13 16:30:28 --> Output Class Initialized
INFO - 2023-09-13 16:30:28 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:28 --> Input Class Initialized
INFO - 2023-09-13 16:30:28 --> Language Class Initialized
INFO - 2023-09-13 16:30:28 --> Language Class Initialized
INFO - 2023-09-13 16:30:28 --> Config Class Initialized
INFO - 2023-09-13 16:30:28 --> Loader Class Initialized
INFO - 2023-09-13 16:30:28 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:28 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:28 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:28 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:28 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:28 --> Controller Class Initialized
INFO - 2023-09-13 16:30:31 --> Config Class Initialized
INFO - 2023-09-13 16:30:31 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:31 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:31 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:31 --> URI Class Initialized
INFO - 2023-09-13 16:30:31 --> Router Class Initialized
INFO - 2023-09-13 16:30:31 --> Output Class Initialized
INFO - 2023-09-13 16:30:31 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:31 --> Input Class Initialized
INFO - 2023-09-13 16:30:31 --> Language Class Initialized
INFO - 2023-09-13 16:30:31 --> Language Class Initialized
INFO - 2023-09-13 16:30:31 --> Config Class Initialized
INFO - 2023-09-13 16:30:31 --> Loader Class Initialized
INFO - 2023-09-13 16:30:31 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:31 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:31 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:31 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:31 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:31 --> Controller Class Initialized
INFO - 2023-09-13 16:30:59 --> Config Class Initialized
INFO - 2023-09-13 16:30:59 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:30:59 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:30:59 --> Utf8 Class Initialized
INFO - 2023-09-13 16:30:59 --> URI Class Initialized
INFO - 2023-09-13 16:30:59 --> Router Class Initialized
INFO - 2023-09-13 16:30:59 --> Output Class Initialized
INFO - 2023-09-13 16:30:59 --> Security Class Initialized
DEBUG - 2023-09-13 16:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:30:59 --> Input Class Initialized
INFO - 2023-09-13 16:30:59 --> Language Class Initialized
INFO - 2023-09-13 16:30:59 --> Language Class Initialized
INFO - 2023-09-13 16:30:59 --> Config Class Initialized
INFO - 2023-09-13 16:30:59 --> Loader Class Initialized
INFO - 2023-09-13 16:30:59 --> Helper loaded: url_helper
INFO - 2023-09-13 16:30:59 --> Helper loaded: file_helper
INFO - 2023-09-13 16:30:59 --> Helper loaded: form_helper
INFO - 2023-09-13 16:30:59 --> Helper loaded: my_helper
INFO - 2023-09-13 16:30:59 --> Database Driver Class Initialized
INFO - 2023-09-13 16:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:30:59 --> Controller Class Initialized
INFO - 2023-09-13 16:30:59 --> Final output sent to browser
DEBUG - 2023-09-13 16:30:59 --> Total execution time: 0.1465
INFO - 2023-09-13 16:31:07 --> Config Class Initialized
INFO - 2023-09-13 16:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:07 --> URI Class Initialized
INFO - 2023-09-13 16:31:07 --> Router Class Initialized
INFO - 2023-09-13 16:31:07 --> Output Class Initialized
INFO - 2023-09-13 16:31:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:07 --> Input Class Initialized
INFO - 2023-09-13 16:31:07 --> Language Class Initialized
INFO - 2023-09-13 16:31:07 --> Language Class Initialized
INFO - 2023-09-13 16:31:07 --> Config Class Initialized
INFO - 2023-09-13 16:31:07 --> Loader Class Initialized
INFO - 2023-09-13 16:31:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:08 --> Controller Class Initialized
INFO - 2023-09-13 16:31:08 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:08 --> Total execution time: 0.2220
INFO - 2023-09-13 16:31:08 --> Config Class Initialized
INFO - 2023-09-13 16:31:08 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:08 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:08 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:08 --> URI Class Initialized
INFO - 2023-09-13 16:31:08 --> Router Class Initialized
INFO - 2023-09-13 16:31:08 --> Output Class Initialized
INFO - 2023-09-13 16:31:08 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:08 --> Input Class Initialized
INFO - 2023-09-13 16:31:08 --> Language Class Initialized
INFO - 2023-09-13 16:31:08 --> Language Class Initialized
INFO - 2023-09-13 16:31:08 --> Config Class Initialized
INFO - 2023-09-13 16:31:08 --> Loader Class Initialized
INFO - 2023-09-13 16:31:08 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:08 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:08 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:08 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:08 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:08 --> Controller Class Initialized
INFO - 2023-09-13 16:31:10 --> Config Class Initialized
INFO - 2023-09-13 16:31:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:10 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:10 --> URI Class Initialized
INFO - 2023-09-13 16:31:10 --> Router Class Initialized
INFO - 2023-09-13 16:31:10 --> Output Class Initialized
INFO - 2023-09-13 16:31:10 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:10 --> Input Class Initialized
INFO - 2023-09-13 16:31:10 --> Language Class Initialized
INFO - 2023-09-13 16:31:10 --> Language Class Initialized
INFO - 2023-09-13 16:31:10 --> Config Class Initialized
INFO - 2023-09-13 16:31:10 --> Loader Class Initialized
INFO - 2023-09-13 16:31:10 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:10 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:10 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:10 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:10 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:10 --> Controller Class Initialized
INFO - 2023-09-13 16:31:10 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:10 --> Total execution time: 0.0964
INFO - 2023-09-13 16:31:11 --> Config Class Initialized
INFO - 2023-09-13 16:31:11 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:11 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:11 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:11 --> URI Class Initialized
INFO - 2023-09-13 16:31:11 --> Router Class Initialized
INFO - 2023-09-13 16:31:11 --> Output Class Initialized
INFO - 2023-09-13 16:31:11 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:11 --> Input Class Initialized
INFO - 2023-09-13 16:31:11 --> Language Class Initialized
INFO - 2023-09-13 16:31:11 --> Language Class Initialized
INFO - 2023-09-13 16:31:11 --> Config Class Initialized
INFO - 2023-09-13 16:31:11 --> Loader Class Initialized
INFO - 2023-09-13 16:31:11 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:11 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:11 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:31:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:11 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:11 --> Total execution time: 0.0425
INFO - 2023-09-13 16:31:11 --> Config Class Initialized
INFO - 2023-09-13 16:31:11 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:11 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:11 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:11 --> URI Class Initialized
INFO - 2023-09-13 16:31:11 --> Router Class Initialized
INFO - 2023-09-13 16:31:11 --> Output Class Initialized
INFO - 2023-09-13 16:31:11 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:11 --> Input Class Initialized
INFO - 2023-09-13 16:31:11 --> Language Class Initialized
INFO - 2023-09-13 16:31:11 --> Language Class Initialized
INFO - 2023-09-13 16:31:11 --> Config Class Initialized
INFO - 2023-09-13 16:31:11 --> Loader Class Initialized
INFO - 2023-09-13 16:31:11 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:11 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:11 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:11 --> Controller Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:14 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:14 --> URI Class Initialized
INFO - 2023-09-13 16:31:14 --> Router Class Initialized
INFO - 2023-09-13 16:31:14 --> Output Class Initialized
INFO - 2023-09-13 16:31:14 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:14 --> Input Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Loader Class Initialized
INFO - 2023-09-13 16:31:14 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:14 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:14 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:14 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:14 --> Total execution time: 0.0380
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:14 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:14 --> URI Class Initialized
INFO - 2023-09-13 16:31:14 --> Router Class Initialized
INFO - 2023-09-13 16:31:14 --> Output Class Initialized
INFO - 2023-09-13 16:31:14 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:14 --> Input Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:14 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:14 --> URI Class Initialized
INFO - 2023-09-13 16:31:14 --> Router Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Loader Class Initialized
INFO - 2023-09-13 16:31:14 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:14 --> Output Class Initialized
INFO - 2023-09-13 16:31:14 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:14 --> Input Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Loader Class Initialized
INFO - 2023-09-13 16:31:14 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:14 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:14 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:14 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:14 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-09-13 16:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:14 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:14 --> Total execution time: 0.0697
INFO - 2023-09-13 16:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:14 --> Controller Class Initialized
INFO - 2023-09-13 16:31:14 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:14 --> Total execution time: 0.0603
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:14 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:14 --> URI Class Initialized
INFO - 2023-09-13 16:31:14 --> Router Class Initialized
INFO - 2023-09-13 16:31:14 --> Output Class Initialized
INFO - 2023-09-13 16:31:14 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:14 --> Input Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Language Class Initialized
INFO - 2023-09-13 16:31:14 --> Config Class Initialized
INFO - 2023-09-13 16:31:14 --> Loader Class Initialized
INFO - 2023-09-13 16:31:14 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:14 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:14 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:14 --> Controller Class Initialized
INFO - 2023-09-13 16:31:15 --> Config Class Initialized
INFO - 2023-09-13 16:31:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:15 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:15 --> URI Class Initialized
INFO - 2023-09-13 16:31:15 --> Router Class Initialized
INFO - 2023-09-13 16:31:15 --> Output Class Initialized
INFO - 2023-09-13 16:31:15 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:15 --> Input Class Initialized
INFO - 2023-09-13 16:31:15 --> Language Class Initialized
ERROR - 2023-09-13 16:31:15 --> 404 Page Not Found: /index
INFO - 2023-09-13 16:31:16 --> Config Class Initialized
INFO - 2023-09-13 16:31:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:16 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:16 --> URI Class Initialized
INFO - 2023-09-13 16:31:16 --> Router Class Initialized
INFO - 2023-09-13 16:31:16 --> Output Class Initialized
INFO - 2023-09-13 16:31:16 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:16 --> Input Class Initialized
INFO - 2023-09-13 16:31:16 --> Language Class Initialized
INFO - 2023-09-13 16:31:16 --> Language Class Initialized
INFO - 2023-09-13 16:31:16 --> Config Class Initialized
INFO - 2023-09-13 16:31:16 --> Loader Class Initialized
INFO - 2023-09-13 16:31:16 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:16 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:16 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:16 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:16 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:16 --> Controller Class Initialized
INFO - 2023-09-13 16:31:18 --> Config Class Initialized
INFO - 2023-09-13 16:31:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:18 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:18 --> URI Class Initialized
INFO - 2023-09-13 16:31:18 --> Router Class Initialized
INFO - 2023-09-13 16:31:18 --> Output Class Initialized
INFO - 2023-09-13 16:31:18 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:18 --> Input Class Initialized
INFO - 2023-09-13 16:31:18 --> Language Class Initialized
INFO - 2023-09-13 16:31:18 --> Language Class Initialized
INFO - 2023-09-13 16:31:18 --> Config Class Initialized
INFO - 2023-09-13 16:31:18 --> Loader Class Initialized
INFO - 2023-09-13 16:31:18 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:18 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:18 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-13 16:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:18 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:18 --> Total execution time: 0.0575
INFO - 2023-09-13 16:31:18 --> Config Class Initialized
INFO - 2023-09-13 16:31:18 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:18 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:18 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:18 --> URI Class Initialized
INFO - 2023-09-13 16:31:18 --> Router Class Initialized
INFO - 2023-09-13 16:31:18 --> Output Class Initialized
INFO - 2023-09-13 16:31:18 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:18 --> Input Class Initialized
INFO - 2023-09-13 16:31:18 --> Language Class Initialized
INFO - 2023-09-13 16:31:18 --> Language Class Initialized
INFO - 2023-09-13 16:31:18 --> Config Class Initialized
INFO - 2023-09-13 16:31:18 --> Loader Class Initialized
INFO - 2023-09-13 16:31:18 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:18 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:18 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:18 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-13 16:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:18 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:18 --> Total execution time: 0.0744
INFO - 2023-09-13 16:31:21 --> Config Class Initialized
INFO - 2023-09-13 16:31:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:21 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:21 --> URI Class Initialized
INFO - 2023-09-13 16:31:21 --> Router Class Initialized
INFO - 2023-09-13 16:31:21 --> Output Class Initialized
INFO - 2023-09-13 16:31:21 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:21 --> Input Class Initialized
INFO - 2023-09-13 16:31:21 --> Language Class Initialized
INFO - 2023-09-13 16:31:21 --> Language Class Initialized
INFO - 2023-09-13 16:31:21 --> Config Class Initialized
INFO - 2023-09-13 16:31:21 --> Loader Class Initialized
INFO - 2023-09-13 16:31:21 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:21 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:21 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-13 16:31:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:21 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:21 --> Total execution time: 0.0688
INFO - 2023-09-13 16:31:21 --> Config Class Initialized
INFO - 2023-09-13 16:31:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:21 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:21 --> URI Class Initialized
INFO - 2023-09-13 16:31:21 --> Router Class Initialized
INFO - 2023-09-13 16:31:21 --> Output Class Initialized
INFO - 2023-09-13 16:31:21 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:21 --> Input Class Initialized
INFO - 2023-09-13 16:31:21 --> Language Class Initialized
INFO - 2023-09-13 16:31:21 --> Language Class Initialized
INFO - 2023-09-13 16:31:21 --> Config Class Initialized
INFO - 2023-09-13 16:31:21 --> Loader Class Initialized
INFO - 2023-09-13 16:31:21 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:21 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:21 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:21 --> Controller Class Initialized
INFO - 2023-09-13 16:31:21 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:21 --> Total execution time: 0.0328
INFO - 2023-09-13 16:31:22 --> Config Class Initialized
INFO - 2023-09-13 16:31:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:22 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:22 --> URI Class Initialized
INFO - 2023-09-13 16:31:22 --> Router Class Initialized
INFO - 2023-09-13 16:31:22 --> Output Class Initialized
INFO - 2023-09-13 16:31:22 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:22 --> Input Class Initialized
INFO - 2023-09-13 16:31:22 --> Language Class Initialized
ERROR - 2023-09-13 16:31:22 --> 404 Page Not Found: /index
INFO - 2023-09-13 16:31:22 --> Config Class Initialized
INFO - 2023-09-13 16:31:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:22 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:22 --> URI Class Initialized
INFO - 2023-09-13 16:31:22 --> Router Class Initialized
INFO - 2023-09-13 16:31:22 --> Output Class Initialized
INFO - 2023-09-13 16:31:22 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:22 --> Input Class Initialized
INFO - 2023-09-13 16:31:22 --> Language Class Initialized
INFO - 2023-09-13 16:31:22 --> Language Class Initialized
INFO - 2023-09-13 16:31:22 --> Config Class Initialized
INFO - 2023-09-13 16:31:22 --> Loader Class Initialized
INFO - 2023-09-13 16:31:22 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:22 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:22 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:22 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:22 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:22 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:22 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:22 --> Total execution time: 0.0691
INFO - 2023-09-13 16:31:22 --> Config Class Initialized
INFO - 2023-09-13 16:31:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:22 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:22 --> URI Class Initialized
DEBUG - 2023-09-13 16:31:23 --> No URI present. Default controller set.
INFO - 2023-09-13 16:31:23 --> Router Class Initialized
INFO - 2023-09-13 16:31:23 --> Output Class Initialized
INFO - 2023-09-13 16:31:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:23 --> Input Class Initialized
INFO - 2023-09-13 16:31:23 --> Language Class Initialized
INFO - 2023-09-13 16:31:23 --> Language Class Initialized
INFO - 2023-09-13 16:31:23 --> Config Class Initialized
INFO - 2023-09-13 16:31:23 --> Loader Class Initialized
INFO - 2023-09-13 16:31:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:23 --> Config Class Initialized
INFO - 2023-09-13 16:31:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:23 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:23 --> URI Class Initialized
INFO - 2023-09-13 16:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:23 --> Controller Class Initialized
INFO - 2023-09-13 16:31:23 --> Router Class Initialized
INFO - 2023-09-13 16:31:23 --> Output Class Initialized
INFO - 2023-09-13 16:31:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:23 --> Input Class Initialized
INFO - 2023-09-13 16:31:23 --> Language Class Initialized
INFO - 2023-09-13 16:31:23 --> Language Class Initialized
INFO - 2023-09-13 16:31:23 --> Config Class Initialized
INFO - 2023-09-13 16:31:23 --> Loader Class Initialized
INFO - 2023-09-13 16:31:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:23 --> Helper loaded: my_helper
DEBUG - 2023-09-13 16:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-13 16:31:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:23 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:23 --> Total execution time: 0.0797
INFO - 2023-09-13 16:31:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:23 --> Controller Class Initialized
INFO - 2023-09-13 16:31:25 --> Config Class Initialized
INFO - 2023-09-13 16:31:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:25 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:25 --> URI Class Initialized
INFO - 2023-09-13 16:31:25 --> Router Class Initialized
INFO - 2023-09-13 16:31:25 --> Output Class Initialized
INFO - 2023-09-13 16:31:25 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:25 --> Input Class Initialized
INFO - 2023-09-13 16:31:25 --> Language Class Initialized
INFO - 2023-09-13 16:31:25 --> Language Class Initialized
INFO - 2023-09-13 16:31:25 --> Config Class Initialized
INFO - 2023-09-13 16:31:25 --> Loader Class Initialized
INFO - 2023-09-13 16:31:25 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:25 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:25 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:31:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:25 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:25 --> Total execution time: 0.0901
INFO - 2023-09-13 16:31:25 --> Config Class Initialized
INFO - 2023-09-13 16:31:25 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:25 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:25 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:25 --> URI Class Initialized
INFO - 2023-09-13 16:31:25 --> Router Class Initialized
INFO - 2023-09-13 16:31:25 --> Output Class Initialized
INFO - 2023-09-13 16:31:25 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:25 --> Input Class Initialized
INFO - 2023-09-13 16:31:25 --> Language Class Initialized
INFO - 2023-09-13 16:31:25 --> Language Class Initialized
INFO - 2023-09-13 16:31:25 --> Config Class Initialized
INFO - 2023-09-13 16:31:25 --> Loader Class Initialized
INFO - 2023-09-13 16:31:25 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:25 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:25 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:25 --> Controller Class Initialized
INFO - 2023-09-13 16:31:27 --> Config Class Initialized
INFO - 2023-09-13 16:31:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:27 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:27 --> URI Class Initialized
INFO - 2023-09-13 16:31:27 --> Router Class Initialized
INFO - 2023-09-13 16:31:27 --> Output Class Initialized
INFO - 2023-09-13 16:31:27 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:27 --> Input Class Initialized
INFO - 2023-09-13 16:31:27 --> Language Class Initialized
INFO - 2023-09-13 16:31:27 --> Language Class Initialized
INFO - 2023-09-13 16:31:27 --> Config Class Initialized
INFO - 2023-09-13 16:31:27 --> Loader Class Initialized
INFO - 2023-09-13 16:31:27 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:27 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:27 --> Controller Class Initialized
INFO - 2023-09-13 16:31:27 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:27 --> Total execution time: 0.0417
INFO - 2023-09-13 16:31:27 --> Config Class Initialized
INFO - 2023-09-13 16:31:27 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:27 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:27 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:27 --> URI Class Initialized
INFO - 2023-09-13 16:31:27 --> Router Class Initialized
INFO - 2023-09-13 16:31:27 --> Output Class Initialized
INFO - 2023-09-13 16:31:27 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:27 --> Input Class Initialized
INFO - 2023-09-13 16:31:27 --> Language Class Initialized
INFO - 2023-09-13 16:31:27 --> Language Class Initialized
INFO - 2023-09-13 16:31:27 --> Config Class Initialized
INFO - 2023-09-13 16:31:27 --> Loader Class Initialized
INFO - 2023-09-13 16:31:27 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:27 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:27 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:27 --> Controller Class Initialized
INFO - 2023-09-13 16:31:28 --> Config Class Initialized
INFO - 2023-09-13 16:31:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:28 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:28 --> URI Class Initialized
INFO - 2023-09-13 16:31:28 --> Router Class Initialized
INFO - 2023-09-13 16:31:28 --> Output Class Initialized
INFO - 2023-09-13 16:31:28 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:28 --> Input Class Initialized
INFO - 2023-09-13 16:31:28 --> Language Class Initialized
INFO - 2023-09-13 16:31:28 --> Language Class Initialized
INFO - 2023-09-13 16:31:28 --> Config Class Initialized
INFO - 2023-09-13 16:31:28 --> Loader Class Initialized
INFO - 2023-09-13 16:31:28 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:28 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:28 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:28 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:28 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:28 --> Controller Class Initialized
INFO - 2023-09-13 16:31:28 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:28 --> Total execution time: 0.0375
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:29 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:29 --> URI Class Initialized
INFO - 2023-09-13 16:31:29 --> Router Class Initialized
INFO - 2023-09-13 16:31:29 --> Output Class Initialized
INFO - 2023-09-13 16:31:29 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:29 --> Input Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Loader Class Initialized
INFO - 2023-09-13 16:31:29 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:29 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:29 --> Controller Class Initialized
INFO - 2023-09-13 16:31:29 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:29 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:29 --> URI Class Initialized
INFO - 2023-09-13 16:31:29 --> Router Class Initialized
INFO - 2023-09-13 16:31:29 --> Output Class Initialized
INFO - 2023-09-13 16:31:29 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:29 --> Input Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Loader Class Initialized
INFO - 2023-09-13 16:31:29 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:29 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:29 --> Controller Class Initialized
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:29 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:29 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:29 --> URI Class Initialized
INFO - 2023-09-13 16:31:29 --> Router Class Initialized
INFO - 2023-09-13 16:31:29 --> Output Class Initialized
INFO - 2023-09-13 16:31:29 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:29 --> Input Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Language Class Initialized
INFO - 2023-09-13 16:31:29 --> Config Class Initialized
INFO - 2023-09-13 16:31:29 --> Loader Class Initialized
INFO - 2023-09-13 16:31:29 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:29 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:29 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:29 --> Controller Class Initialized
DEBUG - 2023-09-13 16:31:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:31:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:31:29 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:29 --> Total execution time: 0.1155
INFO - 2023-09-13 16:31:34 --> Config Class Initialized
INFO - 2023-09-13 16:31:34 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:34 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:34 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:34 --> URI Class Initialized
INFO - 2023-09-13 16:31:34 --> Router Class Initialized
INFO - 2023-09-13 16:31:34 --> Output Class Initialized
INFO - 2023-09-13 16:31:34 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:34 --> Input Class Initialized
INFO - 2023-09-13 16:31:34 --> Language Class Initialized
INFO - 2023-09-13 16:31:34 --> Language Class Initialized
INFO - 2023-09-13 16:31:34 --> Config Class Initialized
INFO - 2023-09-13 16:31:34 --> Loader Class Initialized
INFO - 2023-09-13 16:31:34 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:34 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:34 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:34 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:34 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:34 --> Controller Class Initialized
INFO - 2023-09-13 16:31:34 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:34 --> Total execution time: 0.0753
INFO - 2023-09-13 16:31:38 --> Config Class Initialized
INFO - 2023-09-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:38 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:38 --> URI Class Initialized
INFO - 2023-09-13 16:31:38 --> Router Class Initialized
INFO - 2023-09-13 16:31:38 --> Output Class Initialized
INFO - 2023-09-13 16:31:38 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:38 --> Input Class Initialized
INFO - 2023-09-13 16:31:38 --> Language Class Initialized
INFO - 2023-09-13 16:31:38 --> Language Class Initialized
INFO - 2023-09-13 16:31:38 --> Config Class Initialized
INFO - 2023-09-13 16:31:38 --> Loader Class Initialized
INFO - 2023-09-13 16:31:38 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:38 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:38 --> Controller Class Initialized
INFO - 2023-09-13 16:31:38 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:38 --> Total execution time: 0.0332
INFO - 2023-09-13 16:31:38 --> Config Class Initialized
INFO - 2023-09-13 16:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:38 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:38 --> URI Class Initialized
INFO - 2023-09-13 16:31:38 --> Router Class Initialized
INFO - 2023-09-13 16:31:38 --> Output Class Initialized
INFO - 2023-09-13 16:31:38 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:38 --> Input Class Initialized
INFO - 2023-09-13 16:31:38 --> Language Class Initialized
INFO - 2023-09-13 16:31:38 --> Language Class Initialized
INFO - 2023-09-13 16:31:38 --> Config Class Initialized
INFO - 2023-09-13 16:31:38 --> Loader Class Initialized
INFO - 2023-09-13 16:31:38 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:38 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:38 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:38 --> Controller Class Initialized
INFO - 2023-09-13 16:31:40 --> Config Class Initialized
INFO - 2023-09-13 16:31:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:40 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:40 --> URI Class Initialized
INFO - 2023-09-13 16:31:40 --> Router Class Initialized
INFO - 2023-09-13 16:31:40 --> Output Class Initialized
INFO - 2023-09-13 16:31:40 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:40 --> Input Class Initialized
INFO - 2023-09-13 16:31:40 --> Language Class Initialized
INFO - 2023-09-13 16:31:40 --> Language Class Initialized
INFO - 2023-09-13 16:31:40 --> Config Class Initialized
INFO - 2023-09-13 16:31:40 --> Loader Class Initialized
INFO - 2023-09-13 16:31:40 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:40 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:40 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:40 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:40 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:40 --> Controller Class Initialized
INFO - 2023-09-13 16:31:40 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:40 --> Total execution time: 0.0326
INFO - 2023-09-13 16:31:45 --> Config Class Initialized
INFO - 2023-09-13 16:31:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:45 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:45 --> URI Class Initialized
INFO - 2023-09-13 16:31:45 --> Router Class Initialized
INFO - 2023-09-13 16:31:45 --> Output Class Initialized
INFO - 2023-09-13 16:31:45 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:45 --> Input Class Initialized
INFO - 2023-09-13 16:31:45 --> Language Class Initialized
INFO - 2023-09-13 16:31:45 --> Language Class Initialized
INFO - 2023-09-13 16:31:45 --> Config Class Initialized
INFO - 2023-09-13 16:31:45 --> Loader Class Initialized
INFO - 2023-09-13 16:31:45 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:45 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:45 --> Controller Class Initialized
INFO - 2023-09-13 16:31:45 --> Final output sent to browser
DEBUG - 2023-09-13 16:31:45 --> Total execution time: 0.0383
INFO - 2023-09-13 16:31:45 --> Config Class Initialized
INFO - 2023-09-13 16:31:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:45 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:45 --> URI Class Initialized
INFO - 2023-09-13 16:31:45 --> Router Class Initialized
INFO - 2023-09-13 16:31:45 --> Output Class Initialized
INFO - 2023-09-13 16:31:45 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:45 --> Input Class Initialized
INFO - 2023-09-13 16:31:45 --> Language Class Initialized
INFO - 2023-09-13 16:31:45 --> Language Class Initialized
INFO - 2023-09-13 16:31:45 --> Config Class Initialized
INFO - 2023-09-13 16:31:45 --> Loader Class Initialized
INFO - 2023-09-13 16:31:45 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:45 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:45 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:45 --> Controller Class Initialized
INFO - 2023-09-13 16:31:57 --> Config Class Initialized
INFO - 2023-09-13 16:31:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:31:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:31:57 --> Utf8 Class Initialized
INFO - 2023-09-13 16:31:57 --> URI Class Initialized
INFO - 2023-09-13 16:31:57 --> Router Class Initialized
INFO - 2023-09-13 16:31:57 --> Output Class Initialized
INFO - 2023-09-13 16:31:57 --> Security Class Initialized
DEBUG - 2023-09-13 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:31:57 --> Input Class Initialized
INFO - 2023-09-13 16:31:57 --> Language Class Initialized
INFO - 2023-09-13 16:31:57 --> Language Class Initialized
INFO - 2023-09-13 16:31:57 --> Config Class Initialized
INFO - 2023-09-13 16:31:57 --> Loader Class Initialized
INFO - 2023-09-13 16:31:57 --> Helper loaded: url_helper
INFO - 2023-09-13 16:31:57 --> Helper loaded: file_helper
INFO - 2023-09-13 16:31:57 --> Helper loaded: form_helper
INFO - 2023-09-13 16:31:57 --> Helper loaded: my_helper
INFO - 2023-09-13 16:31:57 --> Database Driver Class Initialized
INFO - 2023-09-13 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:31:57 --> Controller Class Initialized
INFO - 2023-09-13 16:32:05 --> Config Class Initialized
INFO - 2023-09-13 16:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:05 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:05 --> URI Class Initialized
INFO - 2023-09-13 16:32:05 --> Router Class Initialized
INFO - 2023-09-13 16:32:05 --> Output Class Initialized
INFO - 2023-09-13 16:32:05 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:05 --> Input Class Initialized
INFO - 2023-09-13 16:32:05 --> Language Class Initialized
INFO - 2023-09-13 16:32:05 --> Language Class Initialized
INFO - 2023-09-13 16:32:05 --> Config Class Initialized
INFO - 2023-09-13 16:32:05 --> Loader Class Initialized
INFO - 2023-09-13 16:32:05 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:05 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:05 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:32:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:05 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:05 --> Total execution time: 0.0623
INFO - 2023-09-13 16:32:05 --> Config Class Initialized
INFO - 2023-09-13 16:32:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:05 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:05 --> URI Class Initialized
INFO - 2023-09-13 16:32:05 --> Router Class Initialized
INFO - 2023-09-13 16:32:05 --> Output Class Initialized
INFO - 2023-09-13 16:32:05 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:05 --> Input Class Initialized
INFO - 2023-09-13 16:32:05 --> Language Class Initialized
INFO - 2023-09-13 16:32:05 --> Language Class Initialized
INFO - 2023-09-13 16:32:05 --> Config Class Initialized
INFO - 2023-09-13 16:32:05 --> Loader Class Initialized
INFO - 2023-09-13 16:32:05 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:05 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:05 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:05 --> Controller Class Initialized
INFO - 2023-09-13 16:32:08 --> Config Class Initialized
INFO - 2023-09-13 16:32:08 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:08 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:08 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:08 --> URI Class Initialized
INFO - 2023-09-13 16:32:08 --> Router Class Initialized
INFO - 2023-09-13 16:32:08 --> Output Class Initialized
INFO - 2023-09-13 16:32:08 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:08 --> Input Class Initialized
INFO - 2023-09-13 16:32:08 --> Language Class Initialized
INFO - 2023-09-13 16:32:08 --> Language Class Initialized
INFO - 2023-09-13 16:32:08 --> Config Class Initialized
INFO - 2023-09-13 16:32:08 --> Loader Class Initialized
INFO - 2023-09-13 16:32:08 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:08 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:08 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:08 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:08 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:08 --> Controller Class Initialized
INFO - 2023-09-13 16:32:10 --> Config Class Initialized
INFO - 2023-09-13 16:32:10 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:10 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:10 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:10 --> URI Class Initialized
INFO - 2023-09-13 16:32:10 --> Router Class Initialized
INFO - 2023-09-13 16:32:10 --> Output Class Initialized
INFO - 2023-09-13 16:32:10 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:10 --> Input Class Initialized
INFO - 2023-09-13 16:32:10 --> Language Class Initialized
INFO - 2023-09-13 16:32:10 --> Language Class Initialized
INFO - 2023-09-13 16:32:10 --> Config Class Initialized
INFO - 2023-09-13 16:32:10 --> Loader Class Initialized
INFO - 2023-09-13 16:32:10 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:10 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:11 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:11 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:11 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:11 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:32:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:11 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:11 --> Total execution time: 0.0624
INFO - 2023-09-13 16:32:11 --> Config Class Initialized
INFO - 2023-09-13 16:32:11 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:11 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:11 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:11 --> URI Class Initialized
INFO - 2023-09-13 16:32:11 --> Router Class Initialized
INFO - 2023-09-13 16:32:11 --> Output Class Initialized
INFO - 2023-09-13 16:32:11 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:11 --> Input Class Initialized
INFO - 2023-09-13 16:32:11 --> Language Class Initialized
INFO - 2023-09-13 16:32:11 --> Language Class Initialized
INFO - 2023-09-13 16:32:11 --> Config Class Initialized
INFO - 2023-09-13 16:32:11 --> Loader Class Initialized
INFO - 2023-09-13 16:32:11 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:11 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:11 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:11 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:11 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:11 --> Controller Class Initialized
INFO - 2023-09-13 16:32:14 --> Config Class Initialized
INFO - 2023-09-13 16:32:14 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:14 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:14 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:14 --> URI Class Initialized
INFO - 2023-09-13 16:32:14 --> Router Class Initialized
INFO - 2023-09-13 16:32:14 --> Output Class Initialized
INFO - 2023-09-13 16:32:14 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:14 --> Input Class Initialized
INFO - 2023-09-13 16:32:14 --> Language Class Initialized
INFO - 2023-09-13 16:32:14 --> Language Class Initialized
INFO - 2023-09-13 16:32:14 --> Config Class Initialized
INFO - 2023-09-13 16:32:14 --> Loader Class Initialized
INFO - 2023-09-13 16:32:14 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:14 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:14 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:14 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:14 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:14 --> Controller Class Initialized
INFO - 2023-09-13 16:32:14 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:14 --> Total execution time: 0.0664
INFO - 2023-09-13 16:32:15 --> Config Class Initialized
INFO - 2023-09-13 16:32:15 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:15 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:15 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:15 --> URI Class Initialized
INFO - 2023-09-13 16:32:15 --> Router Class Initialized
INFO - 2023-09-13 16:32:15 --> Output Class Initialized
INFO - 2023-09-13 16:32:15 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:15 --> Input Class Initialized
INFO - 2023-09-13 16:32:15 --> Language Class Initialized
INFO - 2023-09-13 16:32:15 --> Language Class Initialized
INFO - 2023-09-13 16:32:15 --> Config Class Initialized
INFO - 2023-09-13 16:32:15 --> Loader Class Initialized
INFO - 2023-09-13 16:32:15 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:15 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:15 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:15 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:15 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:15 --> Controller Class Initialized
INFO - 2023-09-13 16:32:15 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:15 --> Total execution time: 0.0659
INFO - 2023-09-13 16:32:16 --> Config Class Initialized
INFO - 2023-09-13 16:32:16 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:16 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:16 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:16 --> URI Class Initialized
INFO - 2023-09-13 16:32:16 --> Router Class Initialized
INFO - 2023-09-13 16:32:16 --> Output Class Initialized
INFO - 2023-09-13 16:32:16 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:16 --> Input Class Initialized
INFO - 2023-09-13 16:32:16 --> Language Class Initialized
INFO - 2023-09-13 16:32:16 --> Language Class Initialized
INFO - 2023-09-13 16:32:16 --> Config Class Initialized
INFO - 2023-09-13 16:32:16 --> Loader Class Initialized
INFO - 2023-09-13 16:32:16 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:16 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:16 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:16 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:16 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:16 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:16 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:16 --> Total execution time: 0.0384
INFO - 2023-09-13 16:32:22 --> Config Class Initialized
INFO - 2023-09-13 16:32:22 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:22 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:22 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:22 --> URI Class Initialized
INFO - 2023-09-13 16:32:22 --> Router Class Initialized
INFO - 2023-09-13 16:32:22 --> Output Class Initialized
INFO - 2023-09-13 16:32:22 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:22 --> Input Class Initialized
INFO - 2023-09-13 16:32:22 --> Language Class Initialized
INFO - 2023-09-13 16:32:22 --> Language Class Initialized
INFO - 2023-09-13 16:32:22 --> Config Class Initialized
INFO - 2023-09-13 16:32:22 --> Loader Class Initialized
INFO - 2023-09-13 16:32:22 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:22 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:22 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:22 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:22 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:22 --> Controller Class Initialized
INFO - 2023-09-13 16:32:23 --> Config Class Initialized
INFO - 2023-09-13 16:32:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:23 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:23 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:23 --> URI Class Initialized
INFO - 2023-09-13 16:32:23 --> Router Class Initialized
INFO - 2023-09-13 16:32:23 --> Output Class Initialized
INFO - 2023-09-13 16:32:23 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:23 --> Input Class Initialized
INFO - 2023-09-13 16:32:23 --> Language Class Initialized
INFO - 2023-09-13 16:32:23 --> Language Class Initialized
INFO - 2023-09-13 16:32:23 --> Config Class Initialized
INFO - 2023-09-13 16:32:23 --> Loader Class Initialized
INFO - 2023-09-13 16:32:23 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:23 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:23 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:23 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:23 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:23 --> Controller Class Initialized
INFO - 2023-09-13 16:32:23 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:32:23 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:23 --> Total execution time: 0.0540
INFO - 2023-09-13 16:32:23 --> Config Class Initialized
INFO - 2023-09-13 16:32:23 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:24 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:24 --> URI Class Initialized
INFO - 2023-09-13 16:32:24 --> Router Class Initialized
INFO - 2023-09-13 16:32:24 --> Output Class Initialized
INFO - 2023-09-13 16:32:24 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:24 --> Input Class Initialized
INFO - 2023-09-13 16:32:24 --> Language Class Initialized
INFO - 2023-09-13 16:32:24 --> Language Class Initialized
INFO - 2023-09-13 16:32:24 --> Config Class Initialized
INFO - 2023-09-13 16:32:24 --> Loader Class Initialized
INFO - 2023-09-13 16:32:24 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:24 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:24 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:24 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:24 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:24 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:32:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:24 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:24 --> Total execution time: 0.0521
INFO - 2023-09-13 16:32:28 --> Config Class Initialized
INFO - 2023-09-13 16:32:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:28 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:28 --> URI Class Initialized
INFO - 2023-09-13 16:32:28 --> Router Class Initialized
INFO - 2023-09-13 16:32:28 --> Output Class Initialized
INFO - 2023-09-13 16:32:28 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:28 --> Input Class Initialized
INFO - 2023-09-13 16:32:28 --> Language Class Initialized
INFO - 2023-09-13 16:32:28 --> Language Class Initialized
INFO - 2023-09-13 16:32:28 --> Config Class Initialized
INFO - 2023-09-13 16:32:28 --> Loader Class Initialized
INFO - 2023-09-13 16:32:28 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:28 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:28 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:32:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:28 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:28 --> Total execution time: 0.0350
INFO - 2023-09-13 16:32:28 --> Config Class Initialized
INFO - 2023-09-13 16:32:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:28 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:28 --> URI Class Initialized
INFO - 2023-09-13 16:32:28 --> Router Class Initialized
INFO - 2023-09-13 16:32:28 --> Output Class Initialized
INFO - 2023-09-13 16:32:28 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:28 --> Input Class Initialized
INFO - 2023-09-13 16:32:28 --> Language Class Initialized
INFO - 2023-09-13 16:32:28 --> Language Class Initialized
INFO - 2023-09-13 16:32:28 --> Config Class Initialized
INFO - 2023-09-13 16:32:28 --> Loader Class Initialized
INFO - 2023-09-13 16:32:28 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:28 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:28 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:28 --> Controller Class Initialized
INFO - 2023-09-13 16:32:32 --> Config Class Initialized
INFO - 2023-09-13 16:32:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:32 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:32 --> URI Class Initialized
INFO - 2023-09-13 16:32:32 --> Router Class Initialized
INFO - 2023-09-13 16:32:32 --> Output Class Initialized
INFO - 2023-09-13 16:32:32 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:32 --> Input Class Initialized
INFO - 2023-09-13 16:32:32 --> Language Class Initialized
INFO - 2023-09-13 16:32:32 --> Language Class Initialized
INFO - 2023-09-13 16:32:32 --> Config Class Initialized
INFO - 2023-09-13 16:32:32 --> Loader Class Initialized
INFO - 2023-09-13 16:32:32 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:32 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:32 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:32 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:32 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:32 --> Controller Class Initialized
INFO - 2023-09-13 16:32:40 --> Config Class Initialized
INFO - 2023-09-13 16:32:40 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:40 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:40 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:40 --> URI Class Initialized
INFO - 2023-09-13 16:32:40 --> Router Class Initialized
INFO - 2023-09-13 16:32:40 --> Output Class Initialized
INFO - 2023-09-13 16:32:40 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:40 --> Input Class Initialized
INFO - 2023-09-13 16:32:40 --> Language Class Initialized
INFO - 2023-09-13 16:32:40 --> Language Class Initialized
INFO - 2023-09-13 16:32:40 --> Config Class Initialized
INFO - 2023-09-13 16:32:40 --> Loader Class Initialized
INFO - 2023-09-13 16:32:40 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:40 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:40 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:40 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:40 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:40 --> Controller Class Initialized
INFO - 2023-09-13 16:32:43 --> Config Class Initialized
INFO - 2023-09-13 16:32:43 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:43 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:43 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:43 --> URI Class Initialized
DEBUG - 2023-09-13 16:32:43 --> No URI present. Default controller set.
INFO - 2023-09-13 16:32:43 --> Router Class Initialized
INFO - 2023-09-13 16:32:43 --> Output Class Initialized
INFO - 2023-09-13 16:32:43 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:43 --> Input Class Initialized
INFO - 2023-09-13 16:32:43 --> Language Class Initialized
INFO - 2023-09-13 16:32:43 --> Language Class Initialized
INFO - 2023-09-13 16:32:43 --> Config Class Initialized
INFO - 2023-09-13 16:32:43 --> Loader Class Initialized
INFO - 2023-09-13 16:32:43 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:43 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:43 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:43 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:43 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:43 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:32:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:43 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:43 --> Total execution time: 0.0708
INFO - 2023-09-13 16:32:45 --> Config Class Initialized
INFO - 2023-09-13 16:32:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:45 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:45 --> URI Class Initialized
INFO - 2023-09-13 16:32:45 --> Router Class Initialized
INFO - 2023-09-13 16:32:45 --> Output Class Initialized
INFO - 2023-09-13 16:32:45 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:45 --> Input Class Initialized
INFO - 2023-09-13 16:32:45 --> Language Class Initialized
INFO - 2023-09-13 16:32:45 --> Language Class Initialized
INFO - 2023-09-13 16:32:45 --> Config Class Initialized
INFO - 2023-09-13 16:32:45 --> Loader Class Initialized
INFO - 2023-09-13 16:32:45 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:45 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:45 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:45 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:45 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:45 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:45 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:45 --> Total execution time: 0.0336
INFO - 2023-09-13 16:32:48 --> Config Class Initialized
INFO - 2023-09-13 16:32:48 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:48 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:48 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:48 --> URI Class Initialized
INFO - 2023-09-13 16:32:48 --> Router Class Initialized
INFO - 2023-09-13 16:32:48 --> Output Class Initialized
INFO - 2023-09-13 16:32:48 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:48 --> Input Class Initialized
INFO - 2023-09-13 16:32:48 --> Language Class Initialized
INFO - 2023-09-13 16:32:48 --> Language Class Initialized
INFO - 2023-09-13 16:32:48 --> Config Class Initialized
INFO - 2023-09-13 16:32:48 --> Loader Class Initialized
INFO - 2023-09-13 16:32:48 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:48 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:48 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:48 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:48 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:48 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-13 16:32:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:48 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:48 --> Total execution time: 0.0597
INFO - 2023-09-13 16:32:49 --> Config Class Initialized
INFO - 2023-09-13 16:32:49 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:49 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:49 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:49 --> URI Class Initialized
INFO - 2023-09-13 16:32:49 --> Router Class Initialized
INFO - 2023-09-13 16:32:49 --> Output Class Initialized
INFO - 2023-09-13 16:32:49 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:49 --> Input Class Initialized
INFO - 2023-09-13 16:32:49 --> Language Class Initialized
INFO - 2023-09-13 16:32:49 --> Language Class Initialized
INFO - 2023-09-13 16:32:49 --> Config Class Initialized
INFO - 2023-09-13 16:32:49 --> Loader Class Initialized
INFO - 2023-09-13 16:32:49 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:49 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:49 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:49 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:49 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:49 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:49 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:49 --> Total execution time: 0.0562
INFO - 2023-09-13 16:32:50 --> Config Class Initialized
INFO - 2023-09-13 16:32:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:50 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:50 --> URI Class Initialized
INFO - 2023-09-13 16:32:50 --> Router Class Initialized
INFO - 2023-09-13 16:32:50 --> Output Class Initialized
INFO - 2023-09-13 16:32:50 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:50 --> Input Class Initialized
INFO - 2023-09-13 16:32:50 --> Language Class Initialized
INFO - 2023-09-13 16:32:50 --> Language Class Initialized
INFO - 2023-09-13 16:32:50 --> Config Class Initialized
INFO - 2023-09-13 16:32:50 --> Loader Class Initialized
INFO - 2023-09-13 16:32:50 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:50 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:50 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:50 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:50 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:50 --> Controller Class Initialized
INFO - 2023-09-13 16:32:55 --> Config Class Initialized
INFO - 2023-09-13 16:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:55 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:55 --> URI Class Initialized
INFO - 2023-09-13 16:32:55 --> Router Class Initialized
INFO - 2023-09-13 16:32:55 --> Output Class Initialized
INFO - 2023-09-13 16:32:55 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:55 --> Input Class Initialized
INFO - 2023-09-13 16:32:55 --> Language Class Initialized
INFO - 2023-09-13 16:32:55 --> Language Class Initialized
INFO - 2023-09-13 16:32:55 --> Config Class Initialized
INFO - 2023-09-13 16:32:55 --> Loader Class Initialized
INFO - 2023-09-13 16:32:55 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:55 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:55 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:55 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:55 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:55 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-13 16:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:55 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:55 --> Total execution time: 0.0805
INFO - 2023-09-13 16:32:57 --> Config Class Initialized
INFO - 2023-09-13 16:32:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:32:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:32:57 --> Utf8 Class Initialized
INFO - 2023-09-13 16:32:57 --> URI Class Initialized
INFO - 2023-09-13 16:32:57 --> Router Class Initialized
INFO - 2023-09-13 16:32:57 --> Output Class Initialized
INFO - 2023-09-13 16:32:57 --> Security Class Initialized
DEBUG - 2023-09-13 16:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:32:57 --> Input Class Initialized
INFO - 2023-09-13 16:32:57 --> Language Class Initialized
INFO - 2023-09-13 16:32:57 --> Language Class Initialized
INFO - 2023-09-13 16:32:57 --> Config Class Initialized
INFO - 2023-09-13 16:32:57 --> Loader Class Initialized
INFO - 2023-09-13 16:32:57 --> Helper loaded: url_helper
INFO - 2023-09-13 16:32:57 --> Helper loaded: file_helper
INFO - 2023-09-13 16:32:57 --> Helper loaded: form_helper
INFO - 2023-09-13 16:32:57 --> Helper loaded: my_helper
INFO - 2023-09-13 16:32:57 --> Database Driver Class Initialized
INFO - 2023-09-13 16:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:32:57 --> Controller Class Initialized
DEBUG - 2023-09-13 16:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:32:57 --> Final output sent to browser
DEBUG - 2023-09-13 16:32:57 --> Total execution time: 0.0333
INFO - 2023-09-13 16:33:00 --> Config Class Initialized
INFO - 2023-09-13 16:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:00 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:00 --> URI Class Initialized
INFO - 2023-09-13 16:33:00 --> Router Class Initialized
INFO - 2023-09-13 16:33:00 --> Output Class Initialized
INFO - 2023-09-13 16:33:00 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:00 --> Input Class Initialized
INFO - 2023-09-13 16:33:00 --> Language Class Initialized
INFO - 2023-09-13 16:33:00 --> Language Class Initialized
INFO - 2023-09-13 16:33:00 --> Config Class Initialized
INFO - 2023-09-13 16:33:00 --> Loader Class Initialized
INFO - 2023-09-13 16:33:00 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:00 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:00 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:00 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:00 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:00 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:00 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:00 --> Total execution time: 0.0385
INFO - 2023-09-13 16:33:01 --> Config Class Initialized
INFO - 2023-09-13 16:33:01 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:01 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:01 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:01 --> URI Class Initialized
INFO - 2023-09-13 16:33:01 --> Router Class Initialized
INFO - 2023-09-13 16:33:01 --> Output Class Initialized
INFO - 2023-09-13 16:33:01 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:01 --> Input Class Initialized
INFO - 2023-09-13 16:33:01 --> Language Class Initialized
INFO - 2023-09-13 16:33:01 --> Language Class Initialized
INFO - 2023-09-13 16:33:01 --> Config Class Initialized
INFO - 2023-09-13 16:33:01 --> Loader Class Initialized
INFO - 2023-09-13 16:33:01 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:01 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:01 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:01 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:01 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:01 --> Controller Class Initialized
INFO - 2023-09-13 16:33:05 --> Config Class Initialized
INFO - 2023-09-13 16:33:05 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:05 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:05 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:05 --> URI Class Initialized
INFO - 2023-09-13 16:33:05 --> Router Class Initialized
INFO - 2023-09-13 16:33:05 --> Output Class Initialized
INFO - 2023-09-13 16:33:05 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:05 --> Input Class Initialized
INFO - 2023-09-13 16:33:05 --> Language Class Initialized
INFO - 2023-09-13 16:33:05 --> Language Class Initialized
INFO - 2023-09-13 16:33:05 --> Config Class Initialized
INFO - 2023-09-13 16:33:05 --> Loader Class Initialized
INFO - 2023-09-13 16:33:05 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:05 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:05 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:05 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:05 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:05 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:05 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:05 --> Total execution time: 0.0556
INFO - 2023-09-13 16:33:07 --> Config Class Initialized
INFO - 2023-09-13 16:33:07 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:07 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:07 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:07 --> URI Class Initialized
INFO - 2023-09-13 16:33:07 --> Router Class Initialized
INFO - 2023-09-13 16:33:07 --> Output Class Initialized
INFO - 2023-09-13 16:33:07 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:07 --> Input Class Initialized
INFO - 2023-09-13 16:33:07 --> Language Class Initialized
INFO - 2023-09-13 16:33:07 --> Language Class Initialized
INFO - 2023-09-13 16:33:07 --> Config Class Initialized
INFO - 2023-09-13 16:33:07 --> Loader Class Initialized
INFO - 2023-09-13 16:33:07 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:07 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:07 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:07 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:07 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:07 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-13 16:33:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:07 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:07 --> Total execution time: 0.1907
INFO - 2023-09-13 16:33:11 --> Config Class Initialized
INFO - 2023-09-13 16:33:11 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:11 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:11 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:11 --> URI Class Initialized
INFO - 2023-09-13 16:33:11 --> Router Class Initialized
INFO - 2023-09-13 16:33:11 --> Output Class Initialized
INFO - 2023-09-13 16:33:11 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:11 --> Input Class Initialized
INFO - 2023-09-13 16:33:11 --> Language Class Initialized
INFO - 2023-09-13 16:33:11 --> Language Class Initialized
INFO - 2023-09-13 16:33:11 --> Config Class Initialized
INFO - 2023-09-13 16:33:11 --> Loader Class Initialized
INFO - 2023-09-13 16:33:11 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:11 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:11 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:11 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:11 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:11 --> Controller Class Initialized
INFO - 2023-09-13 16:33:11 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:11 --> Total execution time: 0.0711
INFO - 2023-09-13 16:33:12 --> Config Class Initialized
INFO - 2023-09-13 16:33:12 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:12 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:12 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:12 --> URI Class Initialized
INFO - 2023-09-13 16:33:12 --> Router Class Initialized
INFO - 2023-09-13 16:33:12 --> Output Class Initialized
INFO - 2023-09-13 16:33:12 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:12 --> Input Class Initialized
INFO - 2023-09-13 16:33:12 --> Language Class Initialized
INFO - 2023-09-13 16:33:12 --> Language Class Initialized
INFO - 2023-09-13 16:33:12 --> Config Class Initialized
INFO - 2023-09-13 16:33:12 --> Loader Class Initialized
INFO - 2023-09-13 16:33:12 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:12 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:12 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:12 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:12 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:12 --> Controller Class Initialized
INFO - 2023-09-13 16:33:12 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:12 --> Total execution time: 0.0370
INFO - 2023-09-13 16:33:13 --> Config Class Initialized
INFO - 2023-09-13 16:33:13 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:13 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:13 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:13 --> URI Class Initialized
INFO - 2023-09-13 16:33:13 --> Router Class Initialized
INFO - 2023-09-13 16:33:13 --> Output Class Initialized
INFO - 2023-09-13 16:33:13 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:13 --> Input Class Initialized
INFO - 2023-09-13 16:33:13 --> Language Class Initialized
INFO - 2023-09-13 16:33:13 --> Language Class Initialized
INFO - 2023-09-13 16:33:13 --> Config Class Initialized
INFO - 2023-09-13 16:33:13 --> Loader Class Initialized
INFO - 2023-09-13 16:33:13 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:13 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:13 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:13 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:13 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:13 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 16:33:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:13 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:13 --> Total execution time: 0.0580
INFO - 2023-09-13 16:33:21 --> Config Class Initialized
INFO - 2023-09-13 16:33:21 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:21 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:21 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:21 --> URI Class Initialized
INFO - 2023-09-13 16:33:21 --> Router Class Initialized
INFO - 2023-09-13 16:33:21 --> Output Class Initialized
INFO - 2023-09-13 16:33:21 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:21 --> Input Class Initialized
INFO - 2023-09-13 16:33:21 --> Language Class Initialized
INFO - 2023-09-13 16:33:21 --> Language Class Initialized
INFO - 2023-09-13 16:33:21 --> Config Class Initialized
INFO - 2023-09-13 16:33:21 --> Loader Class Initialized
INFO - 2023-09-13 16:33:21 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:21 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:21 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:21 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:21 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:22 --> Controller Class Initialized
INFO - 2023-09-13 16:33:22 --> Helper loaded: cookie_helper
INFO - 2023-09-13 16:33:22 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:22 --> Total execution time: 0.0518
INFO - 2023-09-13 16:33:28 --> Config Class Initialized
INFO - 2023-09-13 16:33:28 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:28 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:28 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:28 --> URI Class Initialized
INFO - 2023-09-13 16:33:28 --> Router Class Initialized
INFO - 2023-09-13 16:33:28 --> Output Class Initialized
INFO - 2023-09-13 16:33:28 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:28 --> Input Class Initialized
INFO - 2023-09-13 16:33:28 --> Language Class Initialized
INFO - 2023-09-13 16:33:28 --> Language Class Initialized
INFO - 2023-09-13 16:33:28 --> Config Class Initialized
INFO - 2023-09-13 16:33:28 --> Loader Class Initialized
INFO - 2023-09-13 16:33:28 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:28 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:28 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:28 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:28 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:28 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:28 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:28 --> Total execution time: 0.0415
INFO - 2023-09-13 16:33:32 --> Config Class Initialized
INFO - 2023-09-13 16:33:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:32 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:32 --> URI Class Initialized
INFO - 2023-09-13 16:33:32 --> Router Class Initialized
INFO - 2023-09-13 16:33:32 --> Output Class Initialized
INFO - 2023-09-13 16:33:32 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:32 --> Input Class Initialized
INFO - 2023-09-13 16:33:32 --> Language Class Initialized
INFO - 2023-09-13 16:33:32 --> Language Class Initialized
INFO - 2023-09-13 16:33:32 --> Config Class Initialized
INFO - 2023-09-13 16:33:32 --> Loader Class Initialized
INFO - 2023-09-13 16:33:32 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:32 --> Config Class Initialized
INFO - 2023-09-13 16:33:32 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:32 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:32 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:32 --> URI Class Initialized
INFO - 2023-09-13 16:33:32 --> Router Class Initialized
INFO - 2023-09-13 16:33:32 --> Output Class Initialized
INFO - 2023-09-13 16:33:32 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:32 --> Input Class Initialized
INFO - 2023-09-13 16:33:32 --> Language Class Initialized
INFO - 2023-09-13 16:33:32 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:32 --> Controller Class Initialized
INFO - 2023-09-13 16:33:32 --> Language Class Initialized
INFO - 2023-09-13 16:33:32 --> Config Class Initialized
INFO - 2023-09-13 16:33:32 --> Loader Class Initialized
INFO - 2023-09-13 16:33:32 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:32 --> Helper loaded: my_helper
DEBUG - 2023-09-13 16:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:32 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:32 --> Total execution time: 0.1430
INFO - 2023-09-13 16:33:32 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:32 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-09-13 16:33:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:32 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:32 --> Total execution time: 0.2597
INFO - 2023-09-13 16:33:35 --> Config Class Initialized
INFO - 2023-09-13 16:33:35 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:35 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:35 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:35 --> URI Class Initialized
INFO - 2023-09-13 16:33:35 --> Router Class Initialized
INFO - 2023-09-13 16:33:35 --> Output Class Initialized
INFO - 2023-09-13 16:33:35 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:35 --> Input Class Initialized
INFO - 2023-09-13 16:33:35 --> Language Class Initialized
INFO - 2023-09-13 16:33:35 --> Language Class Initialized
INFO - 2023-09-13 16:33:35 --> Config Class Initialized
INFO - 2023-09-13 16:33:35 --> Loader Class Initialized
INFO - 2023-09-13 16:33:35 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:35 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:35 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:35 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:35 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:35 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:35 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:35 --> Total execution time: 0.0656
INFO - 2023-09-13 16:33:36 --> Config Class Initialized
INFO - 2023-09-13 16:33:36 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:36 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:36 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:36 --> URI Class Initialized
INFO - 2023-09-13 16:33:36 --> Router Class Initialized
INFO - 2023-09-13 16:33:36 --> Output Class Initialized
INFO - 2023-09-13 16:33:36 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:36 --> Input Class Initialized
INFO - 2023-09-13 16:33:36 --> Language Class Initialized
INFO - 2023-09-13 16:33:36 --> Language Class Initialized
INFO - 2023-09-13 16:33:36 --> Config Class Initialized
INFO - 2023-09-13 16:33:36 --> Loader Class Initialized
INFO - 2023-09-13 16:33:36 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:36 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:36 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:36 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:36 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:36 --> Controller Class Initialized
INFO - 2023-09-13 16:33:38 --> Config Class Initialized
INFO - 2023-09-13 16:33:38 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:38 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:38 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:38 --> URI Class Initialized
DEBUG - 2023-09-13 16:33:38 --> No URI present. Default controller set.
INFO - 2023-09-13 16:33:38 --> Router Class Initialized
INFO - 2023-09-13 16:33:38 --> Output Class Initialized
INFO - 2023-09-13 16:33:38 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:38 --> Input Class Initialized
INFO - 2023-09-13 16:33:38 --> Language Class Initialized
INFO - 2023-09-13 16:33:38 --> Language Class Initialized
INFO - 2023-09-13 16:33:38 --> Config Class Initialized
INFO - 2023-09-13 16:33:38 --> Loader Class Initialized
INFO - 2023-09-13 16:33:38 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:38 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:38 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:38 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:38 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:38 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-13 16:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:38 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:38 --> Total execution time: 0.0358
INFO - 2023-09-13 16:33:42 --> Config Class Initialized
INFO - 2023-09-13 16:33:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:42 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:42 --> URI Class Initialized
INFO - 2023-09-13 16:33:42 --> Router Class Initialized
INFO - 2023-09-13 16:33:42 --> Output Class Initialized
INFO - 2023-09-13 16:33:42 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:42 --> Input Class Initialized
INFO - 2023-09-13 16:33:42 --> Language Class Initialized
INFO - 2023-09-13 16:33:42 --> Language Class Initialized
INFO - 2023-09-13 16:33:42 --> Config Class Initialized
INFO - 2023-09-13 16:33:42 --> Loader Class Initialized
INFO - 2023-09-13 16:33:42 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:42 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:42 --> Controller Class Initialized
INFO - 2023-09-13 16:33:42 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:42 --> Total execution time: 0.0981
INFO - 2023-09-13 16:33:42 --> Config Class Initialized
INFO - 2023-09-13 16:33:42 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:42 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:42 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:42 --> URI Class Initialized
INFO - 2023-09-13 16:33:42 --> Router Class Initialized
INFO - 2023-09-13 16:33:42 --> Output Class Initialized
INFO - 2023-09-13 16:33:42 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:42 --> Input Class Initialized
INFO - 2023-09-13 16:33:42 --> Language Class Initialized
INFO - 2023-09-13 16:33:42 --> Language Class Initialized
INFO - 2023-09-13 16:33:42 --> Config Class Initialized
INFO - 2023-09-13 16:33:42 --> Loader Class Initialized
INFO - 2023-09-13 16:33:42 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:42 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:42 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:42 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-13 16:33:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:42 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:42 --> Total execution time: 0.0351
INFO - 2023-09-13 16:33:44 --> Config Class Initialized
INFO - 2023-09-13 16:33:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:44 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:44 --> URI Class Initialized
INFO - 2023-09-13 16:33:44 --> Router Class Initialized
INFO - 2023-09-13 16:33:44 --> Output Class Initialized
INFO - 2023-09-13 16:33:44 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:44 --> Input Class Initialized
INFO - 2023-09-13 16:33:44 --> Language Class Initialized
INFO - 2023-09-13 16:33:44 --> Language Class Initialized
INFO - 2023-09-13 16:33:44 --> Config Class Initialized
INFO - 2023-09-13 16:33:44 --> Loader Class Initialized
INFO - 2023-09-13 16:33:44 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:44 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:44 --> Controller Class Initialized
INFO - 2023-09-13 16:33:44 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:44 --> Total execution time: 0.0672
INFO - 2023-09-13 16:33:44 --> Config Class Initialized
INFO - 2023-09-13 16:33:44 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:44 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:44 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:44 --> URI Class Initialized
INFO - 2023-09-13 16:33:44 --> Router Class Initialized
INFO - 2023-09-13 16:33:44 --> Output Class Initialized
INFO - 2023-09-13 16:33:44 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:44 --> Input Class Initialized
INFO - 2023-09-13 16:33:44 --> Language Class Initialized
INFO - 2023-09-13 16:33:44 --> Language Class Initialized
INFO - 2023-09-13 16:33:44 --> Config Class Initialized
INFO - 2023-09-13 16:33:44 --> Loader Class Initialized
INFO - 2023-09-13 16:33:44 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:44 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:44 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:44 --> Controller Class Initialized
INFO - 2023-09-13 16:33:44 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:44 --> Total execution time: 0.0396
INFO - 2023-09-13 16:33:46 --> Config Class Initialized
INFO - 2023-09-13 16:33:46 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:46 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:46 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:46 --> URI Class Initialized
INFO - 2023-09-13 16:33:46 --> Router Class Initialized
INFO - 2023-09-13 16:33:46 --> Output Class Initialized
INFO - 2023-09-13 16:33:46 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:46 --> Input Class Initialized
INFO - 2023-09-13 16:33:46 --> Language Class Initialized
INFO - 2023-09-13 16:33:46 --> Language Class Initialized
INFO - 2023-09-13 16:33:46 --> Config Class Initialized
INFO - 2023-09-13 16:33:46 --> Loader Class Initialized
INFO - 2023-09-13 16:33:46 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:46 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:46 --> Controller Class Initialized
INFO - 2023-09-13 16:33:46 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:46 --> Total execution time: 0.0502
INFO - 2023-09-13 16:33:46 --> Config Class Initialized
INFO - 2023-09-13 16:33:46 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:46 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:46 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:46 --> URI Class Initialized
INFO - 2023-09-13 16:33:46 --> Router Class Initialized
INFO - 2023-09-13 16:33:46 --> Output Class Initialized
INFO - 2023-09-13 16:33:46 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:46 --> Input Class Initialized
INFO - 2023-09-13 16:33:46 --> Language Class Initialized
INFO - 2023-09-13 16:33:46 --> Language Class Initialized
INFO - 2023-09-13 16:33:46 --> Config Class Initialized
INFO - 2023-09-13 16:33:46 --> Loader Class Initialized
INFO - 2023-09-13 16:33:46 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:46 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:46 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:46 --> Controller Class Initialized
INFO - 2023-09-13 16:33:46 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:46 --> Total execution time: 0.0436
INFO - 2023-09-13 16:33:57 --> Config Class Initialized
INFO - 2023-09-13 16:33:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:57 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:57 --> URI Class Initialized
INFO - 2023-09-13 16:33:57 --> Router Class Initialized
INFO - 2023-09-13 16:33:57 --> Output Class Initialized
INFO - 2023-09-13 16:33:57 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:57 --> Input Class Initialized
INFO - 2023-09-13 16:33:57 --> Language Class Initialized
INFO - 2023-09-13 16:33:57 --> Language Class Initialized
INFO - 2023-09-13 16:33:57 --> Config Class Initialized
INFO - 2023-09-13 16:33:57 --> Loader Class Initialized
INFO - 2023-09-13 16:33:57 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:57 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:57 --> Controller Class Initialized
DEBUG - 2023-09-13 16:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-13 16:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 16:33:57 --> Final output sent to browser
DEBUG - 2023-09-13 16:33:57 --> Total execution time: 0.0407
INFO - 2023-09-13 16:33:57 --> Config Class Initialized
INFO - 2023-09-13 16:33:57 --> Hooks Class Initialized
DEBUG - 2023-09-13 16:33:57 --> UTF-8 Support Enabled
INFO - 2023-09-13 16:33:57 --> Utf8 Class Initialized
INFO - 2023-09-13 16:33:57 --> URI Class Initialized
INFO - 2023-09-13 16:33:57 --> Router Class Initialized
INFO - 2023-09-13 16:33:57 --> Output Class Initialized
INFO - 2023-09-13 16:33:57 --> Security Class Initialized
DEBUG - 2023-09-13 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 16:33:57 --> Input Class Initialized
INFO - 2023-09-13 16:33:57 --> Language Class Initialized
INFO - 2023-09-13 16:33:57 --> Language Class Initialized
INFO - 2023-09-13 16:33:57 --> Config Class Initialized
INFO - 2023-09-13 16:33:57 --> Loader Class Initialized
INFO - 2023-09-13 16:33:57 --> Helper loaded: url_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: file_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: form_helper
INFO - 2023-09-13 16:33:57 --> Helper loaded: my_helper
INFO - 2023-09-13 16:33:57 --> Database Driver Class Initialized
INFO - 2023-09-13 16:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 16:33:57 --> Controller Class Initialized
INFO - 2023-09-13 20:39:37 --> Config Class Initialized
INFO - 2023-09-13 20:39:37 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:39:37 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:39:37 --> Utf8 Class Initialized
INFO - 2023-09-13 20:39:37 --> URI Class Initialized
DEBUG - 2023-09-13 20:39:37 --> No URI present. Default controller set.
INFO - 2023-09-13 20:39:37 --> Router Class Initialized
INFO - 2023-09-13 20:39:37 --> Output Class Initialized
INFO - 2023-09-13 20:39:37 --> Security Class Initialized
DEBUG - 2023-09-13 20:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:39:37 --> Input Class Initialized
INFO - 2023-09-13 20:39:37 --> Language Class Initialized
INFO - 2023-09-13 20:39:37 --> Language Class Initialized
INFO - 2023-09-13 20:39:37 --> Config Class Initialized
INFO - 2023-09-13 20:39:37 --> Loader Class Initialized
INFO - 2023-09-13 20:39:37 --> Helper loaded: url_helper
INFO - 2023-09-13 20:39:37 --> Helper loaded: file_helper
INFO - 2023-09-13 20:39:37 --> Helper loaded: form_helper
INFO - 2023-09-13 20:39:37 --> Helper loaded: my_helper
INFO - 2023-09-13 20:39:37 --> Database Driver Class Initialized
INFO - 2023-09-13 20:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:39:37 --> Controller Class Initialized
INFO - 2023-09-13 20:39:45 --> Config Class Initialized
INFO - 2023-09-13 20:39:45 --> Hooks Class Initialized
DEBUG - 2023-09-13 20:39:45 --> UTF-8 Support Enabled
INFO - 2023-09-13 20:39:45 --> Utf8 Class Initialized
INFO - 2023-09-13 20:39:45 --> URI Class Initialized
INFO - 2023-09-13 20:39:45 --> Router Class Initialized
INFO - 2023-09-13 20:39:45 --> Output Class Initialized
INFO - 2023-09-13 20:39:45 --> Security Class Initialized
DEBUG - 2023-09-13 20:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 20:39:45 --> Input Class Initialized
INFO - 2023-09-13 20:39:45 --> Language Class Initialized
INFO - 2023-09-13 20:39:45 --> Language Class Initialized
INFO - 2023-09-13 20:39:45 --> Config Class Initialized
INFO - 2023-09-13 20:39:45 --> Loader Class Initialized
INFO - 2023-09-13 20:39:45 --> Helper loaded: url_helper
INFO - 2023-09-13 20:39:45 --> Helper loaded: file_helper
INFO - 2023-09-13 20:39:45 --> Helper loaded: form_helper
INFO - 2023-09-13 20:39:45 --> Helper loaded: my_helper
INFO - 2023-09-13 20:39:45 --> Database Driver Class Initialized
INFO - 2023-09-13 20:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 20:39:45 --> Controller Class Initialized
DEBUG - 2023-09-13 20:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 20:39:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 20:39:45 --> Final output sent to browser
DEBUG - 2023-09-13 20:39:45 --> Total execution time: 0.0772
INFO - 2023-09-13 21:45:50 --> Config Class Initialized
INFO - 2023-09-13 21:45:50 --> Hooks Class Initialized
DEBUG - 2023-09-13 21:45:50 --> UTF-8 Support Enabled
INFO - 2023-09-13 21:45:50 --> Utf8 Class Initialized
INFO - 2023-09-13 21:45:50 --> URI Class Initialized
INFO - 2023-09-13 21:45:50 --> Router Class Initialized
INFO - 2023-09-13 21:45:50 --> Output Class Initialized
INFO - 2023-09-13 21:45:50 --> Security Class Initialized
DEBUG - 2023-09-13 21:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 21:45:50 --> Input Class Initialized
INFO - 2023-09-13 21:45:50 --> Language Class Initialized
INFO - 2023-09-13 21:45:50 --> Language Class Initialized
INFO - 2023-09-13 21:45:50 --> Config Class Initialized
INFO - 2023-09-13 21:45:50 --> Loader Class Initialized
INFO - 2023-09-13 21:45:50 --> Helper loaded: url_helper
INFO - 2023-09-13 21:45:50 --> Helper loaded: file_helper
INFO - 2023-09-13 21:45:50 --> Helper loaded: form_helper
INFO - 2023-09-13 21:45:50 --> Helper loaded: my_helper
INFO - 2023-09-13 21:45:50 --> Database Driver Class Initialized
INFO - 2023-09-13 21:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 21:45:50 --> Controller Class Initialized
DEBUG - 2023-09-13 21:45:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 21:45:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 21:45:50 --> Final output sent to browser
DEBUG - 2023-09-13 21:45:50 --> Total execution time: 0.1070
INFO - 2023-09-13 21:49:56 --> Config Class Initialized
INFO - 2023-09-13 21:49:56 --> Hooks Class Initialized
DEBUG - 2023-09-13 21:49:56 --> UTF-8 Support Enabled
INFO - 2023-09-13 21:49:56 --> Utf8 Class Initialized
INFO - 2023-09-13 21:49:56 --> URI Class Initialized
INFO - 2023-09-13 21:49:56 --> Router Class Initialized
INFO - 2023-09-13 21:49:56 --> Output Class Initialized
INFO - 2023-09-13 21:49:56 --> Security Class Initialized
DEBUG - 2023-09-13 21:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-13 21:49:56 --> Input Class Initialized
INFO - 2023-09-13 21:49:56 --> Language Class Initialized
INFO - 2023-09-13 21:49:56 --> Language Class Initialized
INFO - 2023-09-13 21:49:56 --> Config Class Initialized
INFO - 2023-09-13 21:49:56 --> Loader Class Initialized
INFO - 2023-09-13 21:49:56 --> Helper loaded: url_helper
INFO - 2023-09-13 21:49:56 --> Helper loaded: file_helper
INFO - 2023-09-13 21:49:56 --> Helper loaded: form_helper
INFO - 2023-09-13 21:49:56 --> Helper loaded: my_helper
INFO - 2023-09-13 21:49:56 --> Database Driver Class Initialized
INFO - 2023-09-13 21:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-13 21:49:56 --> Controller Class Initialized
DEBUG - 2023-09-13 21:49:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-13 21:49:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-13 21:49:56 --> Final output sent to browser
DEBUG - 2023-09-13 21:49:56 --> Total execution time: 0.0935
