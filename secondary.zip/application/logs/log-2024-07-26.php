<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-26 11:26:17 --> Config Class Initialized
INFO - 2024-07-26 11:26:17 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:17 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:17 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:17 --> URI Class Initialized
DEBUG - 2024-07-26 11:26:17 --> No URI present. Default controller set.
INFO - 2024-07-26 11:26:17 --> Router Class Initialized
INFO - 2024-07-26 11:26:17 --> Output Class Initialized
INFO - 2024-07-26 11:26:17 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:17 --> Input Class Initialized
INFO - 2024-07-26 11:26:17 --> Language Class Initialized
INFO - 2024-07-26 11:26:17 --> Language Class Initialized
INFO - 2024-07-26 11:26:17 --> Config Class Initialized
INFO - 2024-07-26 11:26:17 --> Loader Class Initialized
INFO - 2024-07-26 11:26:17 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:17 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:17 --> Controller Class Initialized
INFO - 2024-07-26 11:26:17 --> Config Class Initialized
INFO - 2024-07-26 11:26:17 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:17 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:17 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:17 --> URI Class Initialized
INFO - 2024-07-26 11:26:17 --> Router Class Initialized
INFO - 2024-07-26 11:26:17 --> Output Class Initialized
INFO - 2024-07-26 11:26:17 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:17 --> Input Class Initialized
INFO - 2024-07-26 11:26:17 --> Language Class Initialized
INFO - 2024-07-26 11:26:17 --> Language Class Initialized
INFO - 2024-07-26 11:26:17 --> Config Class Initialized
INFO - 2024-07-26 11:26:17 --> Loader Class Initialized
INFO - 2024-07-26 11:26:17 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:17 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:17 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:17 --> Controller Class Initialized
DEBUG - 2024-07-26 11:26:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-26 11:26:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:26:17 --> Final output sent to browser
DEBUG - 2024-07-26 11:26:17 --> Total execution time: 0.0332
INFO - 2024-07-26 11:26:25 --> Config Class Initialized
INFO - 2024-07-26 11:26:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:25 --> URI Class Initialized
INFO - 2024-07-26 11:26:25 --> Router Class Initialized
INFO - 2024-07-26 11:26:25 --> Output Class Initialized
INFO - 2024-07-26 11:26:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:25 --> Input Class Initialized
INFO - 2024-07-26 11:26:25 --> Language Class Initialized
INFO - 2024-07-26 11:26:25 --> Language Class Initialized
INFO - 2024-07-26 11:26:25 --> Config Class Initialized
INFO - 2024-07-26 11:26:25 --> Loader Class Initialized
INFO - 2024-07-26 11:26:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:25 --> Controller Class Initialized
INFO - 2024-07-26 11:26:25 --> Helper loaded: cookie_helper
INFO - 2024-07-26 11:26:25 --> Final output sent to browser
DEBUG - 2024-07-26 11:26:25 --> Total execution time: 0.2033
INFO - 2024-07-26 11:26:26 --> Config Class Initialized
INFO - 2024-07-26 11:26:26 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:26 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:26 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:26 --> URI Class Initialized
INFO - 2024-07-26 11:26:26 --> Router Class Initialized
INFO - 2024-07-26 11:26:26 --> Output Class Initialized
INFO - 2024-07-26 11:26:26 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:26 --> Input Class Initialized
INFO - 2024-07-26 11:26:26 --> Language Class Initialized
INFO - 2024-07-26 11:26:26 --> Language Class Initialized
INFO - 2024-07-26 11:26:26 --> Config Class Initialized
INFO - 2024-07-26 11:26:26 --> Loader Class Initialized
INFO - 2024-07-26 11:26:26 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:26 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:26 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:26 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:26 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:26 --> Controller Class Initialized
DEBUG - 2024-07-26 11:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-26 11:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:26:26 --> Final output sent to browser
DEBUG - 2024-07-26 11:26:26 --> Total execution time: 0.0684
INFO - 2024-07-26 11:26:38 --> Config Class Initialized
INFO - 2024-07-26 11:26:38 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:38 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:38 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:38 --> URI Class Initialized
INFO - 2024-07-26 11:26:38 --> Router Class Initialized
INFO - 2024-07-26 11:26:38 --> Output Class Initialized
INFO - 2024-07-26 11:26:38 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:38 --> Input Class Initialized
INFO - 2024-07-26 11:26:38 --> Language Class Initialized
INFO - 2024-07-26 11:26:39 --> Language Class Initialized
INFO - 2024-07-26 11:26:39 --> Config Class Initialized
INFO - 2024-07-26 11:26:39 --> Loader Class Initialized
INFO - 2024-07-26 11:26:39 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:39 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:39 --> Controller Class Initialized
DEBUG - 2024-07-26 11:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:26:39 --> Final output sent to browser
DEBUG - 2024-07-26 11:26:39 --> Total execution time: 0.0320
INFO - 2024-07-26 11:26:39 --> Config Class Initialized
INFO - 2024-07-26 11:26:39 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:39 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:39 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:39 --> URI Class Initialized
INFO - 2024-07-26 11:26:39 --> Router Class Initialized
INFO - 2024-07-26 11:26:39 --> Output Class Initialized
INFO - 2024-07-26 11:26:39 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:39 --> Input Class Initialized
INFO - 2024-07-26 11:26:39 --> Language Class Initialized
ERROR - 2024-07-26 11:26:39 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:26:39 --> Config Class Initialized
INFO - 2024-07-26 11:26:39 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:39 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:39 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:39 --> URI Class Initialized
INFO - 2024-07-26 11:26:39 --> Router Class Initialized
INFO - 2024-07-26 11:26:39 --> Output Class Initialized
INFO - 2024-07-26 11:26:39 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:39 --> Input Class Initialized
INFO - 2024-07-26 11:26:39 --> Language Class Initialized
INFO - 2024-07-26 11:26:39 --> Language Class Initialized
INFO - 2024-07-26 11:26:39 --> Config Class Initialized
INFO - 2024-07-26 11:26:39 --> Loader Class Initialized
INFO - 2024-07-26 11:26:39 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:39 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:39 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:39 --> Controller Class Initialized
INFO - 2024-07-26 11:26:43 --> Config Class Initialized
INFO - 2024-07-26 11:26:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:43 --> URI Class Initialized
INFO - 2024-07-26 11:26:43 --> Router Class Initialized
INFO - 2024-07-26 11:26:43 --> Output Class Initialized
INFO - 2024-07-26 11:26:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:43 --> Input Class Initialized
INFO - 2024-07-26 11:26:43 --> Language Class Initialized
INFO - 2024-07-26 11:26:43 --> Language Class Initialized
INFO - 2024-07-26 11:26:43 --> Config Class Initialized
INFO - 2024-07-26 11:26:43 --> Loader Class Initialized
INFO - 2024-07-26 11:26:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:43 --> Controller Class Initialized
INFO - 2024-07-26 11:26:44 --> Config Class Initialized
INFO - 2024-07-26 11:26:44 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:44 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:44 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:44 --> URI Class Initialized
INFO - 2024-07-26 11:26:44 --> Router Class Initialized
INFO - 2024-07-26 11:26:44 --> Output Class Initialized
INFO - 2024-07-26 11:26:44 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:44 --> Input Class Initialized
INFO - 2024-07-26 11:26:44 --> Language Class Initialized
INFO - 2024-07-26 11:26:44 --> Language Class Initialized
INFO - 2024-07-26 11:26:44 --> Config Class Initialized
INFO - 2024-07-26 11:26:44 --> Loader Class Initialized
INFO - 2024-07-26 11:26:44 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:44 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:44 --> Controller Class Initialized
INFO - 2024-07-26 11:26:44 --> Config Class Initialized
INFO - 2024-07-26 11:26:44 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:44 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:44 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:44 --> URI Class Initialized
INFO - 2024-07-26 11:26:44 --> Router Class Initialized
INFO - 2024-07-26 11:26:44 --> Output Class Initialized
INFO - 2024-07-26 11:26:44 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:44 --> Input Class Initialized
INFO - 2024-07-26 11:26:44 --> Language Class Initialized
INFO - 2024-07-26 11:26:44 --> Language Class Initialized
INFO - 2024-07-26 11:26:44 --> Config Class Initialized
INFO - 2024-07-26 11:26:44 --> Loader Class Initialized
INFO - 2024-07-26 11:26:44 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:44 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:44 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:44 --> Controller Class Initialized
INFO - 2024-07-26 11:26:45 --> Config Class Initialized
INFO - 2024-07-26 11:26:45 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:45 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:45 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:45 --> URI Class Initialized
INFO - 2024-07-26 11:26:45 --> Router Class Initialized
INFO - 2024-07-26 11:26:45 --> Output Class Initialized
INFO - 2024-07-26 11:26:45 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:45 --> Input Class Initialized
INFO - 2024-07-26 11:26:45 --> Language Class Initialized
INFO - 2024-07-26 11:26:45 --> Language Class Initialized
INFO - 2024-07-26 11:26:45 --> Config Class Initialized
INFO - 2024-07-26 11:26:45 --> Loader Class Initialized
INFO - 2024-07-26 11:26:45 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:45 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:45 --> Controller Class Initialized
INFO - 2024-07-26 11:26:45 --> Config Class Initialized
INFO - 2024-07-26 11:26:45 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:45 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:45 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:45 --> URI Class Initialized
INFO - 2024-07-26 11:26:45 --> Router Class Initialized
INFO - 2024-07-26 11:26:45 --> Output Class Initialized
INFO - 2024-07-26 11:26:45 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:45 --> Input Class Initialized
INFO - 2024-07-26 11:26:45 --> Language Class Initialized
INFO - 2024-07-26 11:26:45 --> Language Class Initialized
INFO - 2024-07-26 11:26:45 --> Config Class Initialized
INFO - 2024-07-26 11:26:45 --> Loader Class Initialized
INFO - 2024-07-26 11:26:45 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:45 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:45 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:45 --> Controller Class Initialized
INFO - 2024-07-26 11:26:46 --> Config Class Initialized
INFO - 2024-07-26 11:26:46 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:46 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:46 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:46 --> URI Class Initialized
INFO - 2024-07-26 11:26:46 --> Router Class Initialized
INFO - 2024-07-26 11:26:46 --> Output Class Initialized
INFO - 2024-07-26 11:26:46 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:46 --> Input Class Initialized
INFO - 2024-07-26 11:26:46 --> Language Class Initialized
INFO - 2024-07-26 11:26:46 --> Language Class Initialized
INFO - 2024-07-26 11:26:46 --> Config Class Initialized
INFO - 2024-07-26 11:26:46 --> Loader Class Initialized
INFO - 2024-07-26 11:26:46 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:46 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:46 --> Controller Class Initialized
INFO - 2024-07-26 11:26:46 --> Config Class Initialized
INFO - 2024-07-26 11:26:46 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:46 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:46 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:46 --> URI Class Initialized
INFO - 2024-07-26 11:26:46 --> Router Class Initialized
INFO - 2024-07-26 11:26:46 --> Output Class Initialized
INFO - 2024-07-26 11:26:46 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:46 --> Input Class Initialized
INFO - 2024-07-26 11:26:46 --> Language Class Initialized
INFO - 2024-07-26 11:26:46 --> Language Class Initialized
INFO - 2024-07-26 11:26:46 --> Config Class Initialized
INFO - 2024-07-26 11:26:46 --> Loader Class Initialized
INFO - 2024-07-26 11:26:46 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:46 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:46 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:46 --> Controller Class Initialized
INFO - 2024-07-26 11:26:47 --> Config Class Initialized
INFO - 2024-07-26 11:26:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:47 --> URI Class Initialized
INFO - 2024-07-26 11:26:47 --> Router Class Initialized
INFO - 2024-07-26 11:26:47 --> Output Class Initialized
INFO - 2024-07-26 11:26:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:47 --> Input Class Initialized
INFO - 2024-07-26 11:26:47 --> Language Class Initialized
INFO - 2024-07-26 11:26:47 --> Language Class Initialized
INFO - 2024-07-26 11:26:47 --> Config Class Initialized
INFO - 2024-07-26 11:26:47 --> Loader Class Initialized
INFO - 2024-07-26 11:26:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:47 --> Controller Class Initialized
INFO - 2024-07-26 11:26:47 --> Config Class Initialized
INFO - 2024-07-26 11:26:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:47 --> URI Class Initialized
INFO - 2024-07-26 11:26:47 --> Router Class Initialized
INFO - 2024-07-26 11:26:47 --> Output Class Initialized
INFO - 2024-07-26 11:26:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:47 --> Input Class Initialized
INFO - 2024-07-26 11:26:47 --> Language Class Initialized
INFO - 2024-07-26 11:26:47 --> Language Class Initialized
INFO - 2024-07-26 11:26:47 --> Config Class Initialized
INFO - 2024-07-26 11:26:47 --> Loader Class Initialized
INFO - 2024-07-26 11:26:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:47 --> Controller Class Initialized
INFO - 2024-07-26 11:26:50 --> Config Class Initialized
INFO - 2024-07-26 11:26:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:26:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:26:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:26:50 --> URI Class Initialized
INFO - 2024-07-26 11:26:50 --> Router Class Initialized
INFO - 2024-07-26 11:26:50 --> Output Class Initialized
INFO - 2024-07-26 11:26:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:26:50 --> Input Class Initialized
INFO - 2024-07-26 11:26:50 --> Language Class Initialized
INFO - 2024-07-26 11:26:50 --> Language Class Initialized
INFO - 2024-07-26 11:26:50 --> Config Class Initialized
INFO - 2024-07-26 11:26:50 --> Loader Class Initialized
INFO - 2024-07-26 11:26:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:26:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:26:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:26:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:26:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:26:50 --> Controller Class Initialized
ERROR - 2024-07-26 11:26:50 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-26 11:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-26 11:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:26:50 --> Final output sent to browser
DEBUG - 2024-07-26 11:26:50 --> Total execution time: 0.0455
INFO - 2024-07-26 11:27:16 --> Config Class Initialized
INFO - 2024-07-26 11:27:16 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:16 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:16 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:16 --> URI Class Initialized
INFO - 2024-07-26 11:27:16 --> Router Class Initialized
INFO - 2024-07-26 11:27:16 --> Output Class Initialized
INFO - 2024-07-26 11:27:16 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:16 --> Input Class Initialized
INFO - 2024-07-26 11:27:16 --> Language Class Initialized
INFO - 2024-07-26 11:27:16 --> Language Class Initialized
INFO - 2024-07-26 11:27:16 --> Config Class Initialized
INFO - 2024-07-26 11:27:16 --> Loader Class Initialized
INFO - 2024-07-26 11:27:16 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:16 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:16 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-26 11:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:16 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:16 --> Total execution time: 0.0254
INFO - 2024-07-26 11:27:16 --> Config Class Initialized
INFO - 2024-07-26 11:27:16 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:16 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:16 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:16 --> URI Class Initialized
INFO - 2024-07-26 11:27:16 --> Router Class Initialized
INFO - 2024-07-26 11:27:16 --> Output Class Initialized
INFO - 2024-07-26 11:27:16 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:16 --> Input Class Initialized
INFO - 2024-07-26 11:27:16 --> Language Class Initialized
ERROR - 2024-07-26 11:27:16 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:16 --> Config Class Initialized
INFO - 2024-07-26 11:27:16 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:16 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:16 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:16 --> URI Class Initialized
INFO - 2024-07-26 11:27:16 --> Router Class Initialized
INFO - 2024-07-26 11:27:16 --> Output Class Initialized
INFO - 2024-07-26 11:27:16 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:16 --> Input Class Initialized
INFO - 2024-07-26 11:27:16 --> Language Class Initialized
INFO - 2024-07-26 11:27:16 --> Language Class Initialized
INFO - 2024-07-26 11:27:16 --> Config Class Initialized
INFO - 2024-07-26 11:27:16 --> Loader Class Initialized
INFO - 2024-07-26 11:27:16 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:16 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:16 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:16 --> Controller Class Initialized
INFO - 2024-07-26 11:27:18 --> Config Class Initialized
INFO - 2024-07-26 11:27:18 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:18 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:18 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:18 --> URI Class Initialized
INFO - 2024-07-26 11:27:18 --> Router Class Initialized
INFO - 2024-07-26 11:27:18 --> Output Class Initialized
INFO - 2024-07-26 11:27:18 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:18 --> Input Class Initialized
INFO - 2024-07-26 11:27:18 --> Language Class Initialized
INFO - 2024-07-26 11:27:18 --> Language Class Initialized
INFO - 2024-07-26 11:27:18 --> Config Class Initialized
INFO - 2024-07-26 11:27:18 --> Loader Class Initialized
INFO - 2024-07-26 11:27:18 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:18 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:18 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:18 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:18 --> Total execution time: 0.0732
INFO - 2024-07-26 11:27:18 --> Config Class Initialized
INFO - 2024-07-26 11:27:18 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:18 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:18 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:18 --> URI Class Initialized
INFO - 2024-07-26 11:27:18 --> Router Class Initialized
INFO - 2024-07-26 11:27:18 --> Output Class Initialized
INFO - 2024-07-26 11:27:18 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:18 --> Input Class Initialized
INFO - 2024-07-26 11:27:18 --> Language Class Initialized
ERROR - 2024-07-26 11:27:18 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:18 --> Config Class Initialized
INFO - 2024-07-26 11:27:18 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:18 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:18 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:18 --> URI Class Initialized
INFO - 2024-07-26 11:27:18 --> Router Class Initialized
INFO - 2024-07-26 11:27:18 --> Output Class Initialized
INFO - 2024-07-26 11:27:18 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:18 --> Input Class Initialized
INFO - 2024-07-26 11:27:18 --> Language Class Initialized
INFO - 2024-07-26 11:27:18 --> Language Class Initialized
INFO - 2024-07-26 11:27:18 --> Config Class Initialized
INFO - 2024-07-26 11:27:18 --> Loader Class Initialized
INFO - 2024-07-26 11:27:18 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:18 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:18 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:18 --> Controller Class Initialized
INFO - 2024-07-26 11:27:20 --> Config Class Initialized
INFO - 2024-07-26 11:27:20 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:20 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:20 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:20 --> URI Class Initialized
INFO - 2024-07-26 11:27:20 --> Router Class Initialized
INFO - 2024-07-26 11:27:20 --> Output Class Initialized
INFO - 2024-07-26 11:27:20 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:20 --> Input Class Initialized
INFO - 2024-07-26 11:27:20 --> Language Class Initialized
INFO - 2024-07-26 11:27:20 --> Language Class Initialized
INFO - 2024-07-26 11:27:20 --> Config Class Initialized
INFO - 2024-07-26 11:27:20 --> Loader Class Initialized
INFO - 2024-07-26 11:27:20 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:20 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:20 --> Controller Class Initialized
INFO - 2024-07-26 11:27:20 --> Config Class Initialized
INFO - 2024-07-26 11:27:20 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:20 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:20 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:20 --> URI Class Initialized
INFO - 2024-07-26 11:27:20 --> Router Class Initialized
INFO - 2024-07-26 11:27:20 --> Output Class Initialized
INFO - 2024-07-26 11:27:20 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:20 --> Input Class Initialized
INFO - 2024-07-26 11:27:20 --> Language Class Initialized
INFO - 2024-07-26 11:27:20 --> Language Class Initialized
INFO - 2024-07-26 11:27:20 --> Config Class Initialized
INFO - 2024-07-26 11:27:20 --> Loader Class Initialized
INFO - 2024-07-26 11:27:20 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:20 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:20 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:20 --> Controller Class Initialized
INFO - 2024-07-26 11:27:21 --> Config Class Initialized
INFO - 2024-07-26 11:27:21 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:21 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:21 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:21 --> URI Class Initialized
INFO - 2024-07-26 11:27:21 --> Router Class Initialized
INFO - 2024-07-26 11:27:21 --> Output Class Initialized
INFO - 2024-07-26 11:27:21 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:21 --> Input Class Initialized
INFO - 2024-07-26 11:27:21 --> Language Class Initialized
INFO - 2024-07-26 11:27:21 --> Language Class Initialized
INFO - 2024-07-26 11:27:21 --> Config Class Initialized
INFO - 2024-07-26 11:27:21 --> Loader Class Initialized
INFO - 2024-07-26 11:27:21 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:21 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:21 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:21 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:21 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:21 --> Controller Class Initialized
INFO - 2024-07-26 11:27:32 --> Config Class Initialized
INFO - 2024-07-26 11:27:32 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:32 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:32 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:32 --> URI Class Initialized
INFO - 2024-07-26 11:27:32 --> Router Class Initialized
INFO - 2024-07-26 11:27:32 --> Output Class Initialized
INFO - 2024-07-26 11:27:32 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:32 --> Input Class Initialized
INFO - 2024-07-26 11:27:32 --> Language Class Initialized
INFO - 2024-07-26 11:27:32 --> Language Class Initialized
INFO - 2024-07-26 11:27:32 --> Config Class Initialized
INFO - 2024-07-26 11:27:32 --> Loader Class Initialized
INFO - 2024-07-26 11:27:32 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:32 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:32 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:32 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:32 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:32 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:27:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:32 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:32 --> Total execution time: 0.0339
INFO - 2024-07-26 11:27:36 --> Config Class Initialized
INFO - 2024-07-26 11:27:36 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:36 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:36 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:36 --> URI Class Initialized
INFO - 2024-07-26 11:27:36 --> Router Class Initialized
INFO - 2024-07-26 11:27:36 --> Output Class Initialized
INFO - 2024-07-26 11:27:36 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:36 --> Input Class Initialized
INFO - 2024-07-26 11:27:36 --> Language Class Initialized
INFO - 2024-07-26 11:27:37 --> Language Class Initialized
INFO - 2024-07-26 11:27:37 --> Config Class Initialized
INFO - 2024-07-26 11:27:37 --> Loader Class Initialized
INFO - 2024-07-26 11:27:37 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:37 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:37 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-26 11:27:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:37 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:37 --> Total execution time: 0.0648
INFO - 2024-07-26 11:27:37 --> Config Class Initialized
INFO - 2024-07-26 11:27:37 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:37 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:37 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:37 --> URI Class Initialized
INFO - 2024-07-26 11:27:37 --> Router Class Initialized
INFO - 2024-07-26 11:27:37 --> Output Class Initialized
INFO - 2024-07-26 11:27:37 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:37 --> Input Class Initialized
INFO - 2024-07-26 11:27:37 --> Language Class Initialized
ERROR - 2024-07-26 11:27:37 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:37 --> Config Class Initialized
INFO - 2024-07-26 11:27:37 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:37 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:37 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:37 --> URI Class Initialized
INFO - 2024-07-26 11:27:37 --> Router Class Initialized
INFO - 2024-07-26 11:27:37 --> Output Class Initialized
INFO - 2024-07-26 11:27:37 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:37 --> Input Class Initialized
INFO - 2024-07-26 11:27:37 --> Language Class Initialized
INFO - 2024-07-26 11:27:37 --> Language Class Initialized
INFO - 2024-07-26 11:27:37 --> Config Class Initialized
INFO - 2024-07-26 11:27:37 --> Loader Class Initialized
INFO - 2024-07-26 11:27:37 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:37 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:37 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:37 --> Controller Class Initialized
INFO - 2024-07-26 11:27:43 --> Config Class Initialized
INFO - 2024-07-26 11:27:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:43 --> URI Class Initialized
INFO - 2024-07-26 11:27:43 --> Router Class Initialized
INFO - 2024-07-26 11:27:43 --> Output Class Initialized
INFO - 2024-07-26 11:27:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:43 --> Input Class Initialized
INFO - 2024-07-26 11:27:43 --> Language Class Initialized
INFO - 2024-07-26 11:27:43 --> Language Class Initialized
INFO - 2024-07-26 11:27:43 --> Config Class Initialized
INFO - 2024-07-26 11:27:43 --> Loader Class Initialized
INFO - 2024-07-26 11:27:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:43 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-07-26 11:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:43 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:43 --> Total execution time: 0.0520
INFO - 2024-07-26 11:27:47 --> Config Class Initialized
INFO - 2024-07-26 11:27:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:47 --> URI Class Initialized
INFO - 2024-07-26 11:27:47 --> Router Class Initialized
INFO - 2024-07-26 11:27:47 --> Output Class Initialized
INFO - 2024-07-26 11:27:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:47 --> Input Class Initialized
INFO - 2024-07-26 11:27:47 --> Language Class Initialized
INFO - 2024-07-26 11:27:47 --> Language Class Initialized
INFO - 2024-07-26 11:27:47 --> Config Class Initialized
INFO - 2024-07-26 11:27:47 --> Loader Class Initialized
INFO - 2024-07-26 11:27:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:47 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-07-26 11:27:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:47 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:47 --> Total execution time: 0.0822
INFO - 2024-07-26 11:27:47 --> Config Class Initialized
INFO - 2024-07-26 11:27:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:47 --> URI Class Initialized
INFO - 2024-07-26 11:27:47 --> Router Class Initialized
INFO - 2024-07-26 11:27:47 --> Output Class Initialized
INFO - 2024-07-26 11:27:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:47 --> Input Class Initialized
INFO - 2024-07-26 11:27:47 --> Language Class Initialized
ERROR - 2024-07-26 11:27:47 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:47 --> Config Class Initialized
INFO - 2024-07-26 11:27:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:47 --> URI Class Initialized
INFO - 2024-07-26 11:27:47 --> Router Class Initialized
INFO - 2024-07-26 11:27:47 --> Output Class Initialized
INFO - 2024-07-26 11:27:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:47 --> Input Class Initialized
INFO - 2024-07-26 11:27:47 --> Language Class Initialized
INFO - 2024-07-26 11:27:47 --> Language Class Initialized
INFO - 2024-07-26 11:27:47 --> Config Class Initialized
INFO - 2024-07-26 11:27:47 --> Loader Class Initialized
INFO - 2024-07-26 11:27:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:48 --> Controller Class Initialized
INFO - 2024-07-26 11:27:50 --> Config Class Initialized
INFO - 2024-07-26 11:27:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:50 --> URI Class Initialized
INFO - 2024-07-26 11:27:50 --> Router Class Initialized
INFO - 2024-07-26 11:27:50 --> Output Class Initialized
INFO - 2024-07-26 11:27:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:50 --> Input Class Initialized
INFO - 2024-07-26 11:27:50 --> Language Class Initialized
INFO - 2024-07-26 11:27:50 --> Language Class Initialized
INFO - 2024-07-26 11:27:50 --> Config Class Initialized
INFO - 2024-07-26 11:27:50 --> Loader Class Initialized
INFO - 2024-07-26 11:27:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:50 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-26 11:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:50 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:50 --> Total execution time: 0.0282
INFO - 2024-07-26 11:27:50 --> Config Class Initialized
INFO - 2024-07-26 11:27:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:50 --> URI Class Initialized
INFO - 2024-07-26 11:27:50 --> Router Class Initialized
INFO - 2024-07-26 11:27:50 --> Output Class Initialized
INFO - 2024-07-26 11:27:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:50 --> Input Class Initialized
INFO - 2024-07-26 11:27:50 --> Language Class Initialized
ERROR - 2024-07-26 11:27:50 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:50 --> Config Class Initialized
INFO - 2024-07-26 11:27:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:50 --> URI Class Initialized
INFO - 2024-07-26 11:27:50 --> Router Class Initialized
INFO - 2024-07-26 11:27:50 --> Output Class Initialized
INFO - 2024-07-26 11:27:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:50 --> Input Class Initialized
INFO - 2024-07-26 11:27:50 --> Language Class Initialized
INFO - 2024-07-26 11:27:50 --> Language Class Initialized
INFO - 2024-07-26 11:27:50 --> Config Class Initialized
INFO - 2024-07-26 11:27:50 --> Loader Class Initialized
INFO - 2024-07-26 11:27:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:50 --> Controller Class Initialized
INFO - 2024-07-26 11:27:53 --> Config Class Initialized
INFO - 2024-07-26 11:27:53 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:53 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:53 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:53 --> URI Class Initialized
INFO - 2024-07-26 11:27:53 --> Router Class Initialized
INFO - 2024-07-26 11:27:53 --> Output Class Initialized
INFO - 2024-07-26 11:27:53 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:53 --> Input Class Initialized
INFO - 2024-07-26 11:27:53 --> Language Class Initialized
INFO - 2024-07-26 11:27:53 --> Language Class Initialized
INFO - 2024-07-26 11:27:53 --> Config Class Initialized
INFO - 2024-07-26 11:27:53 --> Loader Class Initialized
INFO - 2024-07-26 11:27:53 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:53 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:53 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-07-26 11:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:53 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:53 --> Total execution time: 0.0582
INFO - 2024-07-26 11:27:53 --> Config Class Initialized
INFO - 2024-07-26 11:27:53 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:53 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:53 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:53 --> URI Class Initialized
INFO - 2024-07-26 11:27:53 --> Router Class Initialized
INFO - 2024-07-26 11:27:53 --> Output Class Initialized
INFO - 2024-07-26 11:27:53 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:53 --> Input Class Initialized
INFO - 2024-07-26 11:27:53 --> Language Class Initialized
ERROR - 2024-07-26 11:27:53 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:53 --> Config Class Initialized
INFO - 2024-07-26 11:27:53 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:53 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:53 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:53 --> URI Class Initialized
INFO - 2024-07-26 11:27:53 --> Router Class Initialized
INFO - 2024-07-26 11:27:53 --> Output Class Initialized
INFO - 2024-07-26 11:27:53 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:53 --> Input Class Initialized
INFO - 2024-07-26 11:27:53 --> Language Class Initialized
INFO - 2024-07-26 11:27:53 --> Language Class Initialized
INFO - 2024-07-26 11:27:53 --> Config Class Initialized
INFO - 2024-07-26 11:27:53 --> Loader Class Initialized
INFO - 2024-07-26 11:27:53 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:53 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:53 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:53 --> Controller Class Initialized
INFO - 2024-07-26 11:27:59 --> Config Class Initialized
INFO - 2024-07-26 11:27:59 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:59 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:59 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:59 --> URI Class Initialized
INFO - 2024-07-26 11:27:59 --> Router Class Initialized
INFO - 2024-07-26 11:27:59 --> Output Class Initialized
INFO - 2024-07-26 11:27:59 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:59 --> Input Class Initialized
INFO - 2024-07-26 11:27:59 --> Language Class Initialized
INFO - 2024-07-26 11:27:59 --> Language Class Initialized
INFO - 2024-07-26 11:27:59 --> Config Class Initialized
INFO - 2024-07-26 11:27:59 --> Loader Class Initialized
INFO - 2024-07-26 11:27:59 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:59 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:59 --> Controller Class Initialized
DEBUG - 2024-07-26 11:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-07-26 11:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:27:59 --> Final output sent to browser
DEBUG - 2024-07-26 11:27:59 --> Total execution time: 0.0273
INFO - 2024-07-26 11:27:59 --> Config Class Initialized
INFO - 2024-07-26 11:27:59 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:59 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:59 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:59 --> URI Class Initialized
INFO - 2024-07-26 11:27:59 --> Router Class Initialized
INFO - 2024-07-26 11:27:59 --> Output Class Initialized
INFO - 2024-07-26 11:27:59 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:59 --> Input Class Initialized
INFO - 2024-07-26 11:27:59 --> Language Class Initialized
ERROR - 2024-07-26 11:27:59 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:27:59 --> Config Class Initialized
INFO - 2024-07-26 11:27:59 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:27:59 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:27:59 --> Utf8 Class Initialized
INFO - 2024-07-26 11:27:59 --> URI Class Initialized
INFO - 2024-07-26 11:27:59 --> Router Class Initialized
INFO - 2024-07-26 11:27:59 --> Output Class Initialized
INFO - 2024-07-26 11:27:59 --> Security Class Initialized
DEBUG - 2024-07-26 11:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:27:59 --> Input Class Initialized
INFO - 2024-07-26 11:27:59 --> Language Class Initialized
INFO - 2024-07-26 11:27:59 --> Language Class Initialized
INFO - 2024-07-26 11:27:59 --> Config Class Initialized
INFO - 2024-07-26 11:27:59 --> Loader Class Initialized
INFO - 2024-07-26 11:27:59 --> Helper loaded: url_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: file_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: form_helper
INFO - 2024-07-26 11:27:59 --> Helper loaded: my_helper
INFO - 2024-07-26 11:27:59 --> Database Driver Class Initialized
INFO - 2024-07-26 11:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:27:59 --> Controller Class Initialized
INFO - 2024-07-26 11:28:01 --> Config Class Initialized
INFO - 2024-07-26 11:28:01 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:01 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:01 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:01 --> URI Class Initialized
INFO - 2024-07-26 11:28:01 --> Router Class Initialized
INFO - 2024-07-26 11:28:01 --> Output Class Initialized
INFO - 2024-07-26 11:28:01 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:01 --> Input Class Initialized
INFO - 2024-07-26 11:28:01 --> Language Class Initialized
INFO - 2024-07-26 11:28:01 --> Language Class Initialized
INFO - 2024-07-26 11:28:01 --> Config Class Initialized
INFO - 2024-07-26 11:28:01 --> Loader Class Initialized
INFO - 2024-07-26 11:28:01 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:01 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:01 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-26 11:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:01 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:01 --> Total execution time: 0.0966
INFO - 2024-07-26 11:28:01 --> Config Class Initialized
INFO - 2024-07-26 11:28:01 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:01 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:01 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:01 --> URI Class Initialized
INFO - 2024-07-26 11:28:01 --> Router Class Initialized
INFO - 2024-07-26 11:28:01 --> Output Class Initialized
INFO - 2024-07-26 11:28:01 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:01 --> Input Class Initialized
INFO - 2024-07-26 11:28:01 --> Language Class Initialized
ERROR - 2024-07-26 11:28:01 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:28:01 --> Config Class Initialized
INFO - 2024-07-26 11:28:01 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:01 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:01 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:01 --> URI Class Initialized
INFO - 2024-07-26 11:28:01 --> Router Class Initialized
INFO - 2024-07-26 11:28:01 --> Output Class Initialized
INFO - 2024-07-26 11:28:01 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:01 --> Input Class Initialized
INFO - 2024-07-26 11:28:01 --> Language Class Initialized
INFO - 2024-07-26 11:28:01 --> Language Class Initialized
INFO - 2024-07-26 11:28:01 --> Config Class Initialized
INFO - 2024-07-26 11:28:01 --> Loader Class Initialized
INFO - 2024-07-26 11:28:01 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:01 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:01 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:01 --> Controller Class Initialized
INFO - 2024-07-26 11:28:05 --> Config Class Initialized
INFO - 2024-07-26 11:28:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:05 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:05 --> URI Class Initialized
INFO - 2024-07-26 11:28:05 --> Router Class Initialized
INFO - 2024-07-26 11:28:05 --> Output Class Initialized
INFO - 2024-07-26 11:28:05 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:05 --> Input Class Initialized
INFO - 2024-07-26 11:28:05 --> Language Class Initialized
INFO - 2024-07-26 11:28:05 --> Language Class Initialized
INFO - 2024-07-26 11:28:05 --> Config Class Initialized
INFO - 2024-07-26 11:28:05 --> Loader Class Initialized
INFO - 2024-07-26 11:28:05 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:05 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:05 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-26 11:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:05 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:05 --> Total execution time: 0.0545
INFO - 2024-07-26 11:28:05 --> Config Class Initialized
INFO - 2024-07-26 11:28:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:05 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:05 --> URI Class Initialized
INFO - 2024-07-26 11:28:05 --> Router Class Initialized
INFO - 2024-07-26 11:28:05 --> Output Class Initialized
INFO - 2024-07-26 11:28:05 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:05 --> Input Class Initialized
INFO - 2024-07-26 11:28:05 --> Language Class Initialized
ERROR - 2024-07-26 11:28:05 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:28:05 --> Config Class Initialized
INFO - 2024-07-26 11:28:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:05 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:05 --> URI Class Initialized
INFO - 2024-07-26 11:28:05 --> Router Class Initialized
INFO - 2024-07-26 11:28:05 --> Output Class Initialized
INFO - 2024-07-26 11:28:05 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:05 --> Input Class Initialized
INFO - 2024-07-26 11:28:05 --> Language Class Initialized
INFO - 2024-07-26 11:28:05 --> Language Class Initialized
INFO - 2024-07-26 11:28:05 --> Config Class Initialized
INFO - 2024-07-26 11:28:05 --> Loader Class Initialized
INFO - 2024-07-26 11:28:05 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:05 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:05 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:05 --> Controller Class Initialized
INFO - 2024-07-26 11:28:07 --> Config Class Initialized
INFO - 2024-07-26 11:28:07 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:07 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:07 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:07 --> URI Class Initialized
INFO - 2024-07-26 11:28:07 --> Router Class Initialized
INFO - 2024-07-26 11:28:07 --> Output Class Initialized
INFO - 2024-07-26 11:28:07 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:07 --> Input Class Initialized
INFO - 2024-07-26 11:28:07 --> Language Class Initialized
INFO - 2024-07-26 11:28:07 --> Language Class Initialized
INFO - 2024-07-26 11:28:07 --> Config Class Initialized
INFO - 2024-07-26 11:28:07 --> Loader Class Initialized
INFO - 2024-07-26 11:28:07 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:07 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:07 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-26 11:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:07 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:07 --> Total execution time: 0.0293
INFO - 2024-07-26 11:28:07 --> Config Class Initialized
INFO - 2024-07-26 11:28:07 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:07 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:07 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:07 --> URI Class Initialized
INFO - 2024-07-26 11:28:07 --> Router Class Initialized
INFO - 2024-07-26 11:28:07 --> Output Class Initialized
INFO - 2024-07-26 11:28:07 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:07 --> Input Class Initialized
INFO - 2024-07-26 11:28:07 --> Language Class Initialized
ERROR - 2024-07-26 11:28:07 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:28:07 --> Config Class Initialized
INFO - 2024-07-26 11:28:07 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:07 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:07 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:07 --> URI Class Initialized
INFO - 2024-07-26 11:28:07 --> Router Class Initialized
INFO - 2024-07-26 11:28:07 --> Output Class Initialized
INFO - 2024-07-26 11:28:07 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:07 --> Input Class Initialized
INFO - 2024-07-26 11:28:07 --> Language Class Initialized
INFO - 2024-07-26 11:28:07 --> Language Class Initialized
INFO - 2024-07-26 11:28:07 --> Config Class Initialized
INFO - 2024-07-26 11:28:07 --> Loader Class Initialized
INFO - 2024-07-26 11:28:07 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:07 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:07 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:07 --> Controller Class Initialized
INFO - 2024-07-26 11:28:10 --> Config Class Initialized
INFO - 2024-07-26 11:28:10 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:10 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:10 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:10 --> URI Class Initialized
INFO - 2024-07-26 11:28:10 --> Router Class Initialized
INFO - 2024-07-26 11:28:10 --> Output Class Initialized
INFO - 2024-07-26 11:28:10 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:10 --> Input Class Initialized
INFO - 2024-07-26 11:28:10 --> Language Class Initialized
INFO - 2024-07-26 11:28:10 --> Language Class Initialized
INFO - 2024-07-26 11:28:10 --> Config Class Initialized
INFO - 2024-07-26 11:28:10 --> Loader Class Initialized
INFO - 2024-07-26 11:28:10 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:10 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:10 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:10 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:10 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:10 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:10 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:10 --> Total execution time: 0.0296
INFO - 2024-07-26 11:28:15 --> Config Class Initialized
INFO - 2024-07-26 11:28:15 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:15 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:15 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:15 --> URI Class Initialized
INFO - 2024-07-26 11:28:15 --> Router Class Initialized
INFO - 2024-07-26 11:28:15 --> Output Class Initialized
INFO - 2024-07-26 11:28:15 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:15 --> Input Class Initialized
INFO - 2024-07-26 11:28:15 --> Language Class Initialized
INFO - 2024-07-26 11:28:15 --> Language Class Initialized
INFO - 2024-07-26 11:28:15 --> Config Class Initialized
INFO - 2024-07-26 11:28:15 --> Loader Class Initialized
INFO - 2024-07-26 11:28:15 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:15 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:15 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:15 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:15 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:15 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-26 11:28:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:15 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:15 --> Total execution time: 0.0437
INFO - 2024-07-26 11:28:15 --> Config Class Initialized
INFO - 2024-07-26 11:28:15 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:15 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:15 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:15 --> URI Class Initialized
INFO - 2024-07-26 11:28:15 --> Router Class Initialized
INFO - 2024-07-26 11:28:15 --> Output Class Initialized
INFO - 2024-07-26 11:28:15 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:15 --> Input Class Initialized
INFO - 2024-07-26 11:28:15 --> Language Class Initialized
ERROR - 2024-07-26 11:28:15 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:28:15 --> Config Class Initialized
INFO - 2024-07-26 11:28:15 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:15 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:15 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:15 --> URI Class Initialized
INFO - 2024-07-26 11:28:15 --> Router Class Initialized
INFO - 2024-07-26 11:28:16 --> Output Class Initialized
INFO - 2024-07-26 11:28:16 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:16 --> Input Class Initialized
INFO - 2024-07-26 11:28:16 --> Language Class Initialized
INFO - 2024-07-26 11:28:16 --> Language Class Initialized
INFO - 2024-07-26 11:28:16 --> Config Class Initialized
INFO - 2024-07-26 11:28:16 --> Loader Class Initialized
INFO - 2024-07-26 11:28:16 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:16 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:16 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:16 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:16 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:16 --> Controller Class Initialized
INFO - 2024-07-26 11:28:21 --> Config Class Initialized
INFO - 2024-07-26 11:28:21 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:21 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:21 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:21 --> URI Class Initialized
INFO - 2024-07-26 11:28:21 --> Router Class Initialized
INFO - 2024-07-26 11:28:21 --> Output Class Initialized
INFO - 2024-07-26 11:28:21 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:21 --> Input Class Initialized
INFO - 2024-07-26 11:28:21 --> Language Class Initialized
INFO - 2024-07-26 11:28:21 --> Language Class Initialized
INFO - 2024-07-26 11:28:21 --> Config Class Initialized
INFO - 2024-07-26 11:28:21 --> Loader Class Initialized
INFO - 2024-07-26 11:28:21 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:21 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:21 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:21 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:21 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:21 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:21 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:21 --> Total execution time: 0.0339
INFO - 2024-07-26 11:28:25 --> Config Class Initialized
INFO - 2024-07-26 11:28:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:25 --> URI Class Initialized
INFO - 2024-07-26 11:28:25 --> Router Class Initialized
INFO - 2024-07-26 11:28:25 --> Output Class Initialized
INFO - 2024-07-26 11:28:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:25 --> Input Class Initialized
INFO - 2024-07-26 11:28:25 --> Language Class Initialized
INFO - 2024-07-26 11:28:25 --> Language Class Initialized
INFO - 2024-07-26 11:28:25 --> Config Class Initialized
INFO - 2024-07-26 11:28:25 --> Loader Class Initialized
INFO - 2024-07-26 11:28:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:25 --> Controller Class Initialized
INFO - 2024-07-26 11:28:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:25 --> Config Class Initialized
INFO - 2024-07-26 11:28:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:25 --> URI Class Initialized
INFO - 2024-07-26 11:28:25 --> Router Class Initialized
INFO - 2024-07-26 11:28:25 --> Output Class Initialized
INFO - 2024-07-26 11:28:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:25 --> Input Class Initialized
INFO - 2024-07-26 11:28:25 --> Language Class Initialized
INFO - 2024-07-26 11:28:25 --> Language Class Initialized
INFO - 2024-07-26 11:28:25 --> Config Class Initialized
INFO - 2024-07-26 11:28:25 --> Loader Class Initialized
INFO - 2024-07-26 11:28:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:25 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:25 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:25 --> Total execution time: 0.0713
INFO - 2024-07-26 11:28:27 --> Config Class Initialized
INFO - 2024-07-26 11:28:27 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:27 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:27 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:27 --> URI Class Initialized
INFO - 2024-07-26 11:28:27 --> Router Class Initialized
INFO - 2024-07-26 11:28:27 --> Output Class Initialized
INFO - 2024-07-26 11:28:27 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:27 --> Input Class Initialized
INFO - 2024-07-26 11:28:27 --> Language Class Initialized
INFO - 2024-07-26 11:28:27 --> Language Class Initialized
INFO - 2024-07-26 11:28:27 --> Config Class Initialized
INFO - 2024-07-26 11:28:27 --> Loader Class Initialized
INFO - 2024-07-26 11:28:27 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:27 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:27 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:27 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:27 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:27 --> Controller Class Initialized
INFO - 2024-07-26 11:28:27 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:28 --> Config Class Initialized
INFO - 2024-07-26 11:28:28 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:28:28 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:28:28 --> Utf8 Class Initialized
INFO - 2024-07-26 11:28:28 --> URI Class Initialized
INFO - 2024-07-26 11:28:28 --> Router Class Initialized
INFO - 2024-07-26 11:28:28 --> Output Class Initialized
INFO - 2024-07-26 11:28:28 --> Security Class Initialized
DEBUG - 2024-07-26 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:28:28 --> Input Class Initialized
INFO - 2024-07-26 11:28:28 --> Language Class Initialized
INFO - 2024-07-26 11:28:28 --> Language Class Initialized
INFO - 2024-07-26 11:28:28 --> Config Class Initialized
INFO - 2024-07-26 11:28:28 --> Loader Class Initialized
INFO - 2024-07-26 11:28:28 --> Helper loaded: url_helper
INFO - 2024-07-26 11:28:28 --> Helper loaded: file_helper
INFO - 2024-07-26 11:28:28 --> Helper loaded: form_helper
INFO - 2024-07-26 11:28:28 --> Helper loaded: my_helper
INFO - 2024-07-26 11:28:28 --> Database Driver Class Initialized
INFO - 2024-07-26 11:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:28:28 --> Controller Class Initialized
DEBUG - 2024-07-26 11:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:28:28 --> Final output sent to browser
DEBUG - 2024-07-26 11:28:28 --> Total execution time: 0.0306
INFO - 2024-07-26 11:29:12 --> Config Class Initialized
INFO - 2024-07-26 11:29:12 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:12 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:12 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:12 --> URI Class Initialized
INFO - 2024-07-26 11:29:12 --> Router Class Initialized
INFO - 2024-07-26 11:29:12 --> Output Class Initialized
INFO - 2024-07-26 11:29:12 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:12 --> Input Class Initialized
INFO - 2024-07-26 11:29:12 --> Language Class Initialized
INFO - 2024-07-26 11:29:12 --> Language Class Initialized
INFO - 2024-07-26 11:29:12 --> Config Class Initialized
INFO - 2024-07-26 11:29:12 --> Loader Class Initialized
INFO - 2024-07-26 11:29:12 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:12 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:12 --> Controller Class Initialized
DEBUG - 2024-07-26 11:29:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:29:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:29:12 --> Final output sent to browser
DEBUG - 2024-07-26 11:29:12 --> Total execution time: 0.0361
INFO - 2024-07-26 11:29:12 --> Config Class Initialized
INFO - 2024-07-26 11:29:12 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:12 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:12 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:12 --> URI Class Initialized
INFO - 2024-07-26 11:29:12 --> Router Class Initialized
INFO - 2024-07-26 11:29:12 --> Output Class Initialized
INFO - 2024-07-26 11:29:12 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:12 --> Input Class Initialized
INFO - 2024-07-26 11:29:12 --> Language Class Initialized
ERROR - 2024-07-26 11:29:12 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:29:12 --> Config Class Initialized
INFO - 2024-07-26 11:29:12 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:12 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:12 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:12 --> URI Class Initialized
INFO - 2024-07-26 11:29:12 --> Router Class Initialized
INFO - 2024-07-26 11:29:12 --> Output Class Initialized
INFO - 2024-07-26 11:29:12 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:12 --> Input Class Initialized
INFO - 2024-07-26 11:29:12 --> Language Class Initialized
INFO - 2024-07-26 11:29:12 --> Language Class Initialized
INFO - 2024-07-26 11:29:12 --> Config Class Initialized
INFO - 2024-07-26 11:29:12 --> Loader Class Initialized
INFO - 2024-07-26 11:29:12 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:12 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:12 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:12 --> Controller Class Initialized
INFO - 2024-07-26 11:29:28 --> Config Class Initialized
INFO - 2024-07-26 11:29:28 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:28 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:28 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:28 --> URI Class Initialized
INFO - 2024-07-26 11:29:28 --> Router Class Initialized
INFO - 2024-07-26 11:29:28 --> Output Class Initialized
INFO - 2024-07-26 11:29:28 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:28 --> Input Class Initialized
INFO - 2024-07-26 11:29:28 --> Language Class Initialized
INFO - 2024-07-26 11:29:28 --> Language Class Initialized
INFO - 2024-07-26 11:29:28 --> Config Class Initialized
INFO - 2024-07-26 11:29:28 --> Loader Class Initialized
INFO - 2024-07-26 11:29:28 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:28 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:28 --> Controller Class Initialized
INFO - 2024-07-26 11:29:28 --> Config Class Initialized
INFO - 2024-07-26 11:29:28 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:28 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:28 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:28 --> URI Class Initialized
INFO - 2024-07-26 11:29:28 --> Router Class Initialized
INFO - 2024-07-26 11:29:28 --> Output Class Initialized
INFO - 2024-07-26 11:29:28 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:28 --> Input Class Initialized
INFO - 2024-07-26 11:29:28 --> Language Class Initialized
INFO - 2024-07-26 11:29:28 --> Language Class Initialized
INFO - 2024-07-26 11:29:28 --> Config Class Initialized
INFO - 2024-07-26 11:29:28 --> Loader Class Initialized
INFO - 2024-07-26 11:29:28 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:28 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:28 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:28 --> Controller Class Initialized
INFO - 2024-07-26 11:29:29 --> Config Class Initialized
INFO - 2024-07-26 11:29:29 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:29 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:29 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:29 --> URI Class Initialized
INFO - 2024-07-26 11:29:29 --> Router Class Initialized
INFO - 2024-07-26 11:29:29 --> Output Class Initialized
INFO - 2024-07-26 11:29:29 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:29 --> Input Class Initialized
INFO - 2024-07-26 11:29:29 --> Language Class Initialized
INFO - 2024-07-26 11:29:29 --> Language Class Initialized
INFO - 2024-07-26 11:29:29 --> Config Class Initialized
INFO - 2024-07-26 11:29:29 --> Loader Class Initialized
INFO - 2024-07-26 11:29:29 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:29 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:29 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:29 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:29 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:29 --> Controller Class Initialized
INFO - 2024-07-26 11:29:30 --> Config Class Initialized
INFO - 2024-07-26 11:29:30 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:29:30 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:29:30 --> Utf8 Class Initialized
INFO - 2024-07-26 11:29:30 --> URI Class Initialized
INFO - 2024-07-26 11:29:30 --> Router Class Initialized
INFO - 2024-07-26 11:29:30 --> Output Class Initialized
INFO - 2024-07-26 11:29:30 --> Security Class Initialized
DEBUG - 2024-07-26 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:29:30 --> Input Class Initialized
INFO - 2024-07-26 11:29:30 --> Language Class Initialized
INFO - 2024-07-26 11:29:30 --> Language Class Initialized
INFO - 2024-07-26 11:29:30 --> Config Class Initialized
INFO - 2024-07-26 11:29:30 --> Loader Class Initialized
INFO - 2024-07-26 11:29:30 --> Helper loaded: url_helper
INFO - 2024-07-26 11:29:30 --> Helper loaded: file_helper
INFO - 2024-07-26 11:29:30 --> Helper loaded: form_helper
INFO - 2024-07-26 11:29:30 --> Helper loaded: my_helper
INFO - 2024-07-26 11:29:30 --> Database Driver Class Initialized
INFO - 2024-07-26 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:29:30 --> Controller Class Initialized
ERROR - 2024-07-26 11:29:30 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-26 11:29:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-26 11:29:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:29:30 --> Final output sent to browser
DEBUG - 2024-07-26 11:29:30 --> Total execution time: 0.0512
INFO - 2024-07-26 11:36:18 --> Config Class Initialized
INFO - 2024-07-26 11:36:18 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:18 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:18 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:18 --> URI Class Initialized
INFO - 2024-07-26 11:36:18 --> Router Class Initialized
INFO - 2024-07-26 11:36:18 --> Output Class Initialized
INFO - 2024-07-26 11:36:18 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:18 --> Input Class Initialized
INFO - 2024-07-26 11:36:18 --> Language Class Initialized
INFO - 2024-07-26 11:36:18 --> Language Class Initialized
INFO - 2024-07-26 11:36:18 --> Config Class Initialized
INFO - 2024-07-26 11:36:18 --> Loader Class Initialized
INFO - 2024-07-26 11:36:18 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:18 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:18 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:18 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:18 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:19 --> Controller Class Initialized
DEBUG - 2024-07-26 11:36:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:36:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:36:19 --> Final output sent to browser
DEBUG - 2024-07-26 11:36:19 --> Total execution time: 0.0535
INFO - 2024-07-26 11:36:19 --> Config Class Initialized
INFO - 2024-07-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:19 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:19 --> URI Class Initialized
INFO - 2024-07-26 11:36:19 --> Router Class Initialized
INFO - 2024-07-26 11:36:19 --> Output Class Initialized
INFO - 2024-07-26 11:36:19 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:19 --> Input Class Initialized
INFO - 2024-07-26 11:36:19 --> Language Class Initialized
ERROR - 2024-07-26 11:36:19 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:36:19 --> Config Class Initialized
INFO - 2024-07-26 11:36:19 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:19 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:19 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:19 --> URI Class Initialized
INFO - 2024-07-26 11:36:19 --> Router Class Initialized
INFO - 2024-07-26 11:36:19 --> Output Class Initialized
INFO - 2024-07-26 11:36:19 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:19 --> Input Class Initialized
INFO - 2024-07-26 11:36:19 --> Language Class Initialized
INFO - 2024-07-26 11:36:19 --> Language Class Initialized
INFO - 2024-07-26 11:36:19 --> Config Class Initialized
INFO - 2024-07-26 11:36:19 --> Loader Class Initialized
INFO - 2024-07-26 11:36:19 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:19 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:19 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:19 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:19 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:19 --> Controller Class Initialized
INFO - 2024-07-26 11:36:26 --> Config Class Initialized
INFO - 2024-07-26 11:36:26 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:26 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:26 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:26 --> URI Class Initialized
INFO - 2024-07-26 11:36:26 --> Router Class Initialized
INFO - 2024-07-26 11:36:26 --> Output Class Initialized
INFO - 2024-07-26 11:36:26 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:26 --> Input Class Initialized
INFO - 2024-07-26 11:36:26 --> Language Class Initialized
INFO - 2024-07-26 11:36:26 --> Language Class Initialized
INFO - 2024-07-26 11:36:26 --> Config Class Initialized
INFO - 2024-07-26 11:36:26 --> Loader Class Initialized
INFO - 2024-07-26 11:36:26 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:26 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:26 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:26 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:26 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:26 --> Controller Class Initialized
INFO - 2024-07-26 11:36:29 --> Config Class Initialized
INFO - 2024-07-26 11:36:29 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:29 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:29 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:29 --> URI Class Initialized
INFO - 2024-07-26 11:36:29 --> Router Class Initialized
INFO - 2024-07-26 11:36:29 --> Output Class Initialized
INFO - 2024-07-26 11:36:29 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:29 --> Input Class Initialized
INFO - 2024-07-26 11:36:29 --> Language Class Initialized
INFO - 2024-07-26 11:36:29 --> Language Class Initialized
INFO - 2024-07-26 11:36:29 --> Config Class Initialized
INFO - 2024-07-26 11:36:29 --> Loader Class Initialized
INFO - 2024-07-26 11:36:29 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:29 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:29 --> Controller Class Initialized
INFO - 2024-07-26 11:36:29 --> Config Class Initialized
INFO - 2024-07-26 11:36:29 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:29 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:29 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:29 --> URI Class Initialized
INFO - 2024-07-26 11:36:29 --> Router Class Initialized
INFO - 2024-07-26 11:36:29 --> Output Class Initialized
INFO - 2024-07-26 11:36:29 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:29 --> Input Class Initialized
INFO - 2024-07-26 11:36:29 --> Language Class Initialized
INFO - 2024-07-26 11:36:29 --> Language Class Initialized
INFO - 2024-07-26 11:36:29 --> Config Class Initialized
INFO - 2024-07-26 11:36:29 --> Loader Class Initialized
INFO - 2024-07-26 11:36:29 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:29 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:29 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:29 --> Controller Class Initialized
INFO - 2024-07-26 11:36:31 --> Config Class Initialized
INFO - 2024-07-26 11:36:31 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:31 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:31 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:31 --> URI Class Initialized
INFO - 2024-07-26 11:36:31 --> Router Class Initialized
INFO - 2024-07-26 11:36:31 --> Output Class Initialized
INFO - 2024-07-26 11:36:31 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:31 --> Input Class Initialized
INFO - 2024-07-26 11:36:31 --> Language Class Initialized
INFO - 2024-07-26 11:36:31 --> Language Class Initialized
INFO - 2024-07-26 11:36:31 --> Config Class Initialized
INFO - 2024-07-26 11:36:31 --> Loader Class Initialized
INFO - 2024-07-26 11:36:31 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:31 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:31 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:31 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:31 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:31 --> Controller Class Initialized
INFO - 2024-07-26 11:36:43 --> Config Class Initialized
INFO - 2024-07-26 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:43 --> URI Class Initialized
INFO - 2024-07-26 11:36:43 --> Router Class Initialized
INFO - 2024-07-26 11:36:43 --> Output Class Initialized
INFO - 2024-07-26 11:36:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:43 --> Input Class Initialized
INFO - 2024-07-26 11:36:43 --> Language Class Initialized
INFO - 2024-07-26 11:36:43 --> Language Class Initialized
INFO - 2024-07-26 11:36:43 --> Config Class Initialized
INFO - 2024-07-26 11:36:43 --> Loader Class Initialized
INFO - 2024-07-26 11:36:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:43 --> Controller Class Initialized
INFO - 2024-07-26 11:36:43 --> Config Class Initialized
INFO - 2024-07-26 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:43 --> URI Class Initialized
INFO - 2024-07-26 11:36:43 --> Router Class Initialized
INFO - 2024-07-26 11:36:43 --> Output Class Initialized
INFO - 2024-07-26 11:36:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:43 --> Input Class Initialized
INFO - 2024-07-26 11:36:43 --> Language Class Initialized
INFO - 2024-07-26 11:36:43 --> Language Class Initialized
INFO - 2024-07-26 11:36:43 --> Config Class Initialized
INFO - 2024-07-26 11:36:43 --> Loader Class Initialized
INFO - 2024-07-26 11:36:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:43 --> Controller Class Initialized
INFO - 2024-07-26 11:36:44 --> Config Class Initialized
INFO - 2024-07-26 11:36:44 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:36:44 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:36:44 --> Utf8 Class Initialized
INFO - 2024-07-26 11:36:44 --> URI Class Initialized
INFO - 2024-07-26 11:36:44 --> Router Class Initialized
INFO - 2024-07-26 11:36:44 --> Output Class Initialized
INFO - 2024-07-26 11:36:44 --> Security Class Initialized
DEBUG - 2024-07-26 11:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:36:44 --> Input Class Initialized
INFO - 2024-07-26 11:36:44 --> Language Class Initialized
INFO - 2024-07-26 11:36:44 --> Language Class Initialized
INFO - 2024-07-26 11:36:44 --> Config Class Initialized
INFO - 2024-07-26 11:36:44 --> Loader Class Initialized
INFO - 2024-07-26 11:36:44 --> Helper loaded: url_helper
INFO - 2024-07-26 11:36:44 --> Helper loaded: file_helper
INFO - 2024-07-26 11:36:44 --> Helper loaded: form_helper
INFO - 2024-07-26 11:36:44 --> Helper loaded: my_helper
INFO - 2024-07-26 11:36:44 --> Database Driver Class Initialized
INFO - 2024-07-26 11:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:36:44 --> Controller Class Initialized
INFO - 2024-07-26 11:55:40 --> Config Class Initialized
INFO - 2024-07-26 11:55:40 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:40 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:40 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:40 --> URI Class Initialized
INFO - 2024-07-26 11:55:40 --> Router Class Initialized
INFO - 2024-07-26 11:55:40 --> Output Class Initialized
INFO - 2024-07-26 11:55:40 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:40 --> Input Class Initialized
INFO - 2024-07-26 11:55:40 --> Language Class Initialized
INFO - 2024-07-26 11:55:40 --> Language Class Initialized
INFO - 2024-07-26 11:55:40 --> Config Class Initialized
INFO - 2024-07-26 11:55:40 --> Loader Class Initialized
INFO - 2024-07-26 11:55:40 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:40 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:40 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:40 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:40 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:40 --> Controller Class Initialized
DEBUG - 2024-07-26 11:55:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:55:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:55:40 --> Final output sent to browser
DEBUG - 2024-07-26 11:55:40 --> Total execution time: 0.0528
INFO - 2024-07-26 11:55:41 --> Config Class Initialized
INFO - 2024-07-26 11:55:41 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:41 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:41 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:41 --> URI Class Initialized
INFO - 2024-07-26 11:55:41 --> Router Class Initialized
INFO - 2024-07-26 11:55:41 --> Output Class Initialized
INFO - 2024-07-26 11:55:41 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:41 --> Input Class Initialized
INFO - 2024-07-26 11:55:41 --> Language Class Initialized
ERROR - 2024-07-26 11:55:41 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:55:41 --> Config Class Initialized
INFO - 2024-07-26 11:55:41 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:41 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:41 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:41 --> URI Class Initialized
INFO - 2024-07-26 11:55:41 --> Router Class Initialized
INFO - 2024-07-26 11:55:41 --> Output Class Initialized
INFO - 2024-07-26 11:55:41 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:41 --> Input Class Initialized
INFO - 2024-07-26 11:55:41 --> Language Class Initialized
INFO - 2024-07-26 11:55:41 --> Language Class Initialized
INFO - 2024-07-26 11:55:41 --> Config Class Initialized
INFO - 2024-07-26 11:55:41 --> Loader Class Initialized
INFO - 2024-07-26 11:55:41 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:41 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:41 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:41 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:41 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:41 --> Controller Class Initialized
INFO - 2024-07-26 11:55:43 --> Config Class Initialized
INFO - 2024-07-26 11:55:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:43 --> URI Class Initialized
INFO - 2024-07-26 11:55:43 --> Router Class Initialized
INFO - 2024-07-26 11:55:43 --> Output Class Initialized
INFO - 2024-07-26 11:55:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:43 --> Input Class Initialized
INFO - 2024-07-26 11:55:43 --> Language Class Initialized
INFO - 2024-07-26 11:55:43 --> Language Class Initialized
INFO - 2024-07-26 11:55:43 --> Config Class Initialized
INFO - 2024-07-26 11:55:43 --> Loader Class Initialized
INFO - 2024-07-26 11:55:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:43 --> Controller Class Initialized
INFO - 2024-07-26 11:55:43 --> Config Class Initialized
INFO - 2024-07-26 11:55:43 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:43 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:43 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:43 --> URI Class Initialized
INFO - 2024-07-26 11:55:43 --> Router Class Initialized
INFO - 2024-07-26 11:55:43 --> Output Class Initialized
INFO - 2024-07-26 11:55:43 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:43 --> Input Class Initialized
INFO - 2024-07-26 11:55:43 --> Language Class Initialized
INFO - 2024-07-26 11:55:43 --> Language Class Initialized
INFO - 2024-07-26 11:55:43 --> Config Class Initialized
INFO - 2024-07-26 11:55:43 --> Loader Class Initialized
INFO - 2024-07-26 11:55:43 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:43 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:43 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:43 --> Controller Class Initialized
INFO - 2024-07-26 11:55:47 --> Config Class Initialized
INFO - 2024-07-26 11:55:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:47 --> URI Class Initialized
INFO - 2024-07-26 11:55:47 --> Router Class Initialized
INFO - 2024-07-26 11:55:47 --> Output Class Initialized
INFO - 2024-07-26 11:55:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:47 --> Input Class Initialized
INFO - 2024-07-26 11:55:47 --> Language Class Initialized
INFO - 2024-07-26 11:55:47 --> Language Class Initialized
INFO - 2024-07-26 11:55:47 --> Config Class Initialized
INFO - 2024-07-26 11:55:47 --> Loader Class Initialized
INFO - 2024-07-26 11:55:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:47 --> Controller Class Initialized
INFO - 2024-07-26 11:55:47 --> Config Class Initialized
INFO - 2024-07-26 11:55:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:47 --> URI Class Initialized
INFO - 2024-07-26 11:55:47 --> Router Class Initialized
INFO - 2024-07-26 11:55:47 --> Output Class Initialized
INFO - 2024-07-26 11:55:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:47 --> Input Class Initialized
INFO - 2024-07-26 11:55:47 --> Language Class Initialized
INFO - 2024-07-26 11:55:47 --> Language Class Initialized
INFO - 2024-07-26 11:55:47 --> Config Class Initialized
INFO - 2024-07-26 11:55:47 --> Loader Class Initialized
INFO - 2024-07-26 11:55:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:47 --> Controller Class Initialized
INFO - 2024-07-26 11:55:50 --> Config Class Initialized
INFO - 2024-07-26 11:55:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:50 --> URI Class Initialized
INFO - 2024-07-26 11:55:50 --> Router Class Initialized
INFO - 2024-07-26 11:55:50 --> Output Class Initialized
INFO - 2024-07-26 11:55:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:50 --> Input Class Initialized
INFO - 2024-07-26 11:55:50 --> Language Class Initialized
INFO - 2024-07-26 11:55:50 --> Language Class Initialized
INFO - 2024-07-26 11:55:50 --> Config Class Initialized
INFO - 2024-07-26 11:55:50 --> Loader Class Initialized
INFO - 2024-07-26 11:55:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:50 --> Controller Class Initialized
INFO - 2024-07-26 11:55:50 --> Config Class Initialized
INFO - 2024-07-26 11:55:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:50 --> URI Class Initialized
INFO - 2024-07-26 11:55:50 --> Router Class Initialized
INFO - 2024-07-26 11:55:50 --> Output Class Initialized
INFO - 2024-07-26 11:55:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:50 --> Input Class Initialized
INFO - 2024-07-26 11:55:50 --> Language Class Initialized
INFO - 2024-07-26 11:55:50 --> Language Class Initialized
INFO - 2024-07-26 11:55:50 --> Config Class Initialized
INFO - 2024-07-26 11:55:50 --> Loader Class Initialized
INFO - 2024-07-26 11:55:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:50 --> Controller Class Initialized
INFO - 2024-07-26 11:55:51 --> Config Class Initialized
INFO - 2024-07-26 11:55:51 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:51 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:51 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:51 --> URI Class Initialized
INFO - 2024-07-26 11:55:51 --> Router Class Initialized
INFO - 2024-07-26 11:55:51 --> Output Class Initialized
INFO - 2024-07-26 11:55:51 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:51 --> Input Class Initialized
INFO - 2024-07-26 11:55:51 --> Language Class Initialized
INFO - 2024-07-26 11:55:51 --> Language Class Initialized
INFO - 2024-07-26 11:55:51 --> Config Class Initialized
INFO - 2024-07-26 11:55:51 --> Loader Class Initialized
INFO - 2024-07-26 11:55:51 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:51 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:51 --> Controller Class Initialized
INFO - 2024-07-26 11:55:51 --> Config Class Initialized
INFO - 2024-07-26 11:55:51 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:51 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:51 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:51 --> URI Class Initialized
INFO - 2024-07-26 11:55:51 --> Router Class Initialized
INFO - 2024-07-26 11:55:51 --> Output Class Initialized
INFO - 2024-07-26 11:55:51 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:51 --> Input Class Initialized
INFO - 2024-07-26 11:55:51 --> Language Class Initialized
INFO - 2024-07-26 11:55:51 --> Language Class Initialized
INFO - 2024-07-26 11:55:51 --> Config Class Initialized
INFO - 2024-07-26 11:55:51 --> Loader Class Initialized
INFO - 2024-07-26 11:55:51 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:51 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:51 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:51 --> Controller Class Initialized
INFO - 2024-07-26 11:55:52 --> Config Class Initialized
INFO - 2024-07-26 11:55:52 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:52 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:52 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:52 --> URI Class Initialized
INFO - 2024-07-26 11:55:52 --> Router Class Initialized
INFO - 2024-07-26 11:55:52 --> Output Class Initialized
INFO - 2024-07-26 11:55:52 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:52 --> Input Class Initialized
INFO - 2024-07-26 11:55:52 --> Language Class Initialized
INFO - 2024-07-26 11:55:52 --> Language Class Initialized
INFO - 2024-07-26 11:55:52 --> Config Class Initialized
INFO - 2024-07-26 11:55:52 --> Loader Class Initialized
INFO - 2024-07-26 11:55:52 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:52 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:52 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:52 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:52 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:52 --> Controller Class Initialized
INFO - 2024-07-26 11:55:53 --> Config Class Initialized
INFO - 2024-07-26 11:55:53 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:53 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:53 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:53 --> URI Class Initialized
INFO - 2024-07-26 11:55:53 --> Router Class Initialized
INFO - 2024-07-26 11:55:53 --> Output Class Initialized
INFO - 2024-07-26 11:55:53 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:53 --> Input Class Initialized
INFO - 2024-07-26 11:55:53 --> Language Class Initialized
INFO - 2024-07-26 11:55:53 --> Language Class Initialized
INFO - 2024-07-26 11:55:53 --> Config Class Initialized
INFO - 2024-07-26 11:55:53 --> Loader Class Initialized
INFO - 2024-07-26 11:55:53 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:53 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:53 --> Controller Class Initialized
INFO - 2024-07-26 11:55:53 --> Config Class Initialized
INFO - 2024-07-26 11:55:53 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:53 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:53 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:53 --> URI Class Initialized
INFO - 2024-07-26 11:55:53 --> Router Class Initialized
INFO - 2024-07-26 11:55:53 --> Output Class Initialized
INFO - 2024-07-26 11:55:53 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:53 --> Input Class Initialized
INFO - 2024-07-26 11:55:53 --> Language Class Initialized
INFO - 2024-07-26 11:55:53 --> Language Class Initialized
INFO - 2024-07-26 11:55:53 --> Config Class Initialized
INFO - 2024-07-26 11:55:53 --> Loader Class Initialized
INFO - 2024-07-26 11:55:53 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:53 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:53 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:53 --> Controller Class Initialized
INFO - 2024-07-26 11:55:54 --> Config Class Initialized
INFO - 2024-07-26 11:55:54 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:54 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:54 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:54 --> URI Class Initialized
INFO - 2024-07-26 11:55:54 --> Router Class Initialized
INFO - 2024-07-26 11:55:54 --> Output Class Initialized
INFO - 2024-07-26 11:55:54 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:54 --> Input Class Initialized
INFO - 2024-07-26 11:55:54 --> Language Class Initialized
INFO - 2024-07-26 11:55:54 --> Language Class Initialized
INFO - 2024-07-26 11:55:54 --> Config Class Initialized
INFO - 2024-07-26 11:55:54 --> Loader Class Initialized
INFO - 2024-07-26 11:55:54 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:54 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:54 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:54 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:54 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:54 --> Controller Class Initialized
INFO - 2024-07-26 11:55:55 --> Config Class Initialized
INFO - 2024-07-26 11:55:55 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:55 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:55 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:55 --> URI Class Initialized
INFO - 2024-07-26 11:55:55 --> Router Class Initialized
INFO - 2024-07-26 11:55:55 --> Output Class Initialized
INFO - 2024-07-26 11:55:55 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:55 --> Input Class Initialized
INFO - 2024-07-26 11:55:55 --> Language Class Initialized
INFO - 2024-07-26 11:55:55 --> Language Class Initialized
INFO - 2024-07-26 11:55:55 --> Config Class Initialized
INFO - 2024-07-26 11:55:55 --> Loader Class Initialized
INFO - 2024-07-26 11:55:55 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:55 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:55 --> Controller Class Initialized
INFO - 2024-07-26 11:55:55 --> Config Class Initialized
INFO - 2024-07-26 11:55:55 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:55 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:55 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:55 --> URI Class Initialized
INFO - 2024-07-26 11:55:55 --> Router Class Initialized
INFO - 2024-07-26 11:55:55 --> Output Class Initialized
INFO - 2024-07-26 11:55:55 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:55 --> Input Class Initialized
INFO - 2024-07-26 11:55:55 --> Language Class Initialized
INFO - 2024-07-26 11:55:55 --> Language Class Initialized
INFO - 2024-07-26 11:55:55 --> Config Class Initialized
INFO - 2024-07-26 11:55:55 --> Loader Class Initialized
INFO - 2024-07-26 11:55:55 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:55 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:55 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:55 --> Controller Class Initialized
INFO - 2024-07-26 11:55:56 --> Config Class Initialized
INFO - 2024-07-26 11:55:56 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:56 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:56 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:56 --> URI Class Initialized
INFO - 2024-07-26 11:55:56 --> Router Class Initialized
INFO - 2024-07-26 11:55:56 --> Output Class Initialized
INFO - 2024-07-26 11:55:56 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:56 --> Input Class Initialized
INFO - 2024-07-26 11:55:56 --> Language Class Initialized
INFO - 2024-07-26 11:55:56 --> Language Class Initialized
INFO - 2024-07-26 11:55:56 --> Config Class Initialized
INFO - 2024-07-26 11:55:56 --> Loader Class Initialized
INFO - 2024-07-26 11:55:56 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:56 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:56 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:56 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:56 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:56 --> Controller Class Initialized
INFO - 2024-07-26 11:55:57 --> Config Class Initialized
INFO - 2024-07-26 11:55:57 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:57 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:57 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:57 --> URI Class Initialized
INFO - 2024-07-26 11:55:57 --> Router Class Initialized
INFO - 2024-07-26 11:55:57 --> Output Class Initialized
INFO - 2024-07-26 11:55:57 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:57 --> Input Class Initialized
INFO - 2024-07-26 11:55:57 --> Language Class Initialized
INFO - 2024-07-26 11:55:57 --> Language Class Initialized
INFO - 2024-07-26 11:55:57 --> Config Class Initialized
INFO - 2024-07-26 11:55:57 --> Loader Class Initialized
INFO - 2024-07-26 11:55:57 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:57 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:57 --> Controller Class Initialized
INFO - 2024-07-26 11:55:57 --> Config Class Initialized
INFO - 2024-07-26 11:55:57 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:55:57 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:55:57 --> Utf8 Class Initialized
INFO - 2024-07-26 11:55:57 --> URI Class Initialized
INFO - 2024-07-26 11:55:57 --> Router Class Initialized
INFO - 2024-07-26 11:55:57 --> Output Class Initialized
INFO - 2024-07-26 11:55:57 --> Security Class Initialized
DEBUG - 2024-07-26 11:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:55:57 --> Input Class Initialized
INFO - 2024-07-26 11:55:57 --> Language Class Initialized
INFO - 2024-07-26 11:55:57 --> Language Class Initialized
INFO - 2024-07-26 11:55:57 --> Config Class Initialized
INFO - 2024-07-26 11:55:57 --> Loader Class Initialized
INFO - 2024-07-26 11:55:57 --> Helper loaded: url_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: file_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: form_helper
INFO - 2024-07-26 11:55:57 --> Helper loaded: my_helper
INFO - 2024-07-26 11:55:57 --> Database Driver Class Initialized
INFO - 2024-07-26 11:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:55:57 --> Controller Class Initialized
INFO - 2024-07-26 11:56:00 --> Config Class Initialized
INFO - 2024-07-26 11:56:00 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:00 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:00 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:00 --> URI Class Initialized
INFO - 2024-07-26 11:56:00 --> Router Class Initialized
INFO - 2024-07-26 11:56:00 --> Output Class Initialized
INFO - 2024-07-26 11:56:00 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:00 --> Input Class Initialized
INFO - 2024-07-26 11:56:00 --> Language Class Initialized
INFO - 2024-07-26 11:56:00 --> Language Class Initialized
INFO - 2024-07-26 11:56:00 --> Config Class Initialized
INFO - 2024-07-26 11:56:00 --> Loader Class Initialized
INFO - 2024-07-26 11:56:00 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:00 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:00 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:00 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:00 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:00 --> Controller Class Initialized
INFO - 2024-07-26 11:56:10 --> Config Class Initialized
INFO - 2024-07-26 11:56:10 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:10 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:10 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:10 --> URI Class Initialized
INFO - 2024-07-26 11:56:10 --> Router Class Initialized
INFO - 2024-07-26 11:56:10 --> Output Class Initialized
INFO - 2024-07-26 11:56:10 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:10 --> Input Class Initialized
INFO - 2024-07-26 11:56:10 --> Language Class Initialized
INFO - 2024-07-26 11:56:10 --> Language Class Initialized
INFO - 2024-07-26 11:56:10 --> Config Class Initialized
INFO - 2024-07-26 11:56:10 --> Loader Class Initialized
INFO - 2024-07-26 11:56:10 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:10 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:10 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:10 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:10 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:10 --> Controller Class Initialized
INFO - 2024-07-26 11:56:13 --> Config Class Initialized
INFO - 2024-07-26 11:56:13 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:13 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:13 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:13 --> URI Class Initialized
INFO - 2024-07-26 11:56:13 --> Router Class Initialized
INFO - 2024-07-26 11:56:13 --> Output Class Initialized
INFO - 2024-07-26 11:56:13 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:13 --> Input Class Initialized
INFO - 2024-07-26 11:56:13 --> Language Class Initialized
INFO - 2024-07-26 11:56:13 --> Language Class Initialized
INFO - 2024-07-26 11:56:13 --> Config Class Initialized
INFO - 2024-07-26 11:56:13 --> Loader Class Initialized
INFO - 2024-07-26 11:56:13 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:13 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:13 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:13 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:13 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:13 --> Controller Class Initialized
INFO - 2024-07-26 11:56:15 --> Config Class Initialized
INFO - 2024-07-26 11:56:15 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:15 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:15 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:15 --> URI Class Initialized
INFO - 2024-07-26 11:56:15 --> Router Class Initialized
INFO - 2024-07-26 11:56:15 --> Output Class Initialized
INFO - 2024-07-26 11:56:15 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:15 --> Input Class Initialized
INFO - 2024-07-26 11:56:15 --> Language Class Initialized
INFO - 2024-07-26 11:56:15 --> Language Class Initialized
INFO - 2024-07-26 11:56:15 --> Config Class Initialized
INFO - 2024-07-26 11:56:15 --> Loader Class Initialized
INFO - 2024-07-26 11:56:15 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:15 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:15 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:15 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:15 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:15 --> Controller Class Initialized
ERROR - 2024-07-26 11:56:15 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-26 11:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-26 11:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:56:15 --> Final output sent to browser
DEBUG - 2024-07-26 11:56:15 --> Total execution time: 0.0278
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:25 --> URI Class Initialized
INFO - 2024-07-26 11:56:25 --> Router Class Initialized
INFO - 2024-07-26 11:56:25 --> Output Class Initialized
INFO - 2024-07-26 11:56:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:25 --> Input Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Loader Class Initialized
INFO - 2024-07-26 11:56:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:25 --> Controller Class Initialized
INFO - 2024-07-26 11:56:25 --> Upload Class Initialized
INFO - 2024-07-26 11:56:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-26 11:56:25 --> The upload path does not appear to be valid.
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:25 --> URI Class Initialized
INFO - 2024-07-26 11:56:25 --> Router Class Initialized
INFO - 2024-07-26 11:56:25 --> Output Class Initialized
INFO - 2024-07-26 11:56:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:25 --> Input Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Loader Class Initialized
INFO - 2024-07-26 11:56:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:25 --> Controller Class Initialized
DEBUG - 2024-07-26 11:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 11:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:56:25 --> Final output sent to browser
DEBUG - 2024-07-26 11:56:25 --> Total execution time: 0.0265
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:25 --> URI Class Initialized
INFO - 2024-07-26 11:56:25 --> Router Class Initialized
INFO - 2024-07-26 11:56:25 --> Output Class Initialized
INFO - 2024-07-26 11:56:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:25 --> Input Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
ERROR - 2024-07-26 11:56:25 --> 404 Page Not Found: /index
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:25 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:25 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:25 --> URI Class Initialized
INFO - 2024-07-26 11:56:25 --> Router Class Initialized
INFO - 2024-07-26 11:56:25 --> Output Class Initialized
INFO - 2024-07-26 11:56:25 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:25 --> Input Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Language Class Initialized
INFO - 2024-07-26 11:56:25 --> Config Class Initialized
INFO - 2024-07-26 11:56:25 --> Loader Class Initialized
INFO - 2024-07-26 11:56:25 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:25 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:25 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:25 --> Controller Class Initialized
INFO - 2024-07-26 11:56:28 --> Config Class Initialized
INFO - 2024-07-26 11:56:28 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:28 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:28 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:28 --> URI Class Initialized
INFO - 2024-07-26 11:56:28 --> Router Class Initialized
INFO - 2024-07-26 11:56:28 --> Output Class Initialized
INFO - 2024-07-26 11:56:28 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:28 --> Input Class Initialized
INFO - 2024-07-26 11:56:28 --> Language Class Initialized
INFO - 2024-07-26 11:56:28 --> Language Class Initialized
INFO - 2024-07-26 11:56:28 --> Config Class Initialized
INFO - 2024-07-26 11:56:28 --> Loader Class Initialized
INFO - 2024-07-26 11:56:28 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:28 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:28 --> Controller Class Initialized
INFO - 2024-07-26 11:56:28 --> Config Class Initialized
INFO - 2024-07-26 11:56:28 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:28 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:28 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:28 --> URI Class Initialized
INFO - 2024-07-26 11:56:28 --> Router Class Initialized
INFO - 2024-07-26 11:56:28 --> Output Class Initialized
INFO - 2024-07-26 11:56:28 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:28 --> Input Class Initialized
INFO - 2024-07-26 11:56:28 --> Language Class Initialized
INFO - 2024-07-26 11:56:28 --> Language Class Initialized
INFO - 2024-07-26 11:56:28 --> Config Class Initialized
INFO - 2024-07-26 11:56:28 --> Loader Class Initialized
INFO - 2024-07-26 11:56:28 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:28 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:28 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:28 --> Controller Class Initialized
INFO - 2024-07-26 11:56:29 --> Config Class Initialized
INFO - 2024-07-26 11:56:29 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:29 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:29 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:29 --> URI Class Initialized
INFO - 2024-07-26 11:56:29 --> Router Class Initialized
INFO - 2024-07-26 11:56:29 --> Output Class Initialized
INFO - 2024-07-26 11:56:29 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:29 --> Input Class Initialized
INFO - 2024-07-26 11:56:29 --> Language Class Initialized
INFO - 2024-07-26 11:56:29 --> Language Class Initialized
INFO - 2024-07-26 11:56:29 --> Config Class Initialized
INFO - 2024-07-26 11:56:29 --> Loader Class Initialized
INFO - 2024-07-26 11:56:29 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:29 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:29 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:29 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:29 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:29 --> Controller Class Initialized
INFO - 2024-07-26 11:56:47 --> Config Class Initialized
INFO - 2024-07-26 11:56:47 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:47 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:47 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:47 --> URI Class Initialized
INFO - 2024-07-26 11:56:47 --> Router Class Initialized
INFO - 2024-07-26 11:56:47 --> Output Class Initialized
INFO - 2024-07-26 11:56:47 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:47 --> Input Class Initialized
INFO - 2024-07-26 11:56:47 --> Language Class Initialized
INFO - 2024-07-26 11:56:47 --> Language Class Initialized
INFO - 2024-07-26 11:56:47 --> Config Class Initialized
INFO - 2024-07-26 11:56:47 --> Loader Class Initialized
INFO - 2024-07-26 11:56:47 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:47 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:47 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:47 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:47 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:47 --> Controller Class Initialized
DEBUG - 2024-07-26 11:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:56:47 --> Final output sent to browser
DEBUG - 2024-07-26 11:56:47 --> Total execution time: 0.0355
INFO - 2024-07-26 11:56:50 --> Config Class Initialized
INFO - 2024-07-26 11:56:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:50 --> URI Class Initialized
INFO - 2024-07-26 11:56:50 --> Router Class Initialized
INFO - 2024-07-26 11:56:50 --> Output Class Initialized
INFO - 2024-07-26 11:56:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:50 --> Input Class Initialized
INFO - 2024-07-26 11:56:50 --> Language Class Initialized
INFO - 2024-07-26 11:56:50 --> Language Class Initialized
INFO - 2024-07-26 11:56:50 --> Config Class Initialized
INFO - 2024-07-26 11:56:50 --> Loader Class Initialized
INFO - 2024-07-26 11:56:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:50 --> Controller Class Initialized
INFO - 2024-07-26 11:56:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:50 --> Config Class Initialized
INFO - 2024-07-26 11:56:50 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:56:50 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:56:50 --> Utf8 Class Initialized
INFO - 2024-07-26 11:56:50 --> URI Class Initialized
INFO - 2024-07-26 11:56:50 --> Router Class Initialized
INFO - 2024-07-26 11:56:50 --> Output Class Initialized
INFO - 2024-07-26 11:56:50 --> Security Class Initialized
DEBUG - 2024-07-26 11:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:56:50 --> Input Class Initialized
INFO - 2024-07-26 11:56:50 --> Language Class Initialized
INFO - 2024-07-26 11:56:50 --> Language Class Initialized
INFO - 2024-07-26 11:56:50 --> Config Class Initialized
INFO - 2024-07-26 11:56:50 --> Loader Class Initialized
INFO - 2024-07-26 11:56:50 --> Helper loaded: url_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: file_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: form_helper
INFO - 2024-07-26 11:56:50 --> Helper loaded: my_helper
INFO - 2024-07-26 11:56:50 --> Database Driver Class Initialized
INFO - 2024-07-26 11:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:56:50 --> Controller Class Initialized
DEBUG - 2024-07-26 11:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-26 11:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:56:50 --> Final output sent to browser
DEBUG - 2024-07-26 11:56:50 --> Total execution time: 0.0337
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:59:36 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:59:36 --> Utf8 Class Initialized
INFO - 2024-07-26 11:59:36 --> URI Class Initialized
INFO - 2024-07-26 11:59:36 --> Router Class Initialized
INFO - 2024-07-26 11:59:36 --> Output Class Initialized
INFO - 2024-07-26 11:59:36 --> Security Class Initialized
DEBUG - 2024-07-26 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:59:36 --> Input Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Loader Class Initialized
INFO - 2024-07-26 11:59:36 --> Helper loaded: url_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: file_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: form_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: my_helper
INFO - 2024-07-26 11:59:36 --> Database Driver Class Initialized
INFO - 2024-07-26 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:59:36 --> Controller Class Initialized
INFO - 2024-07-26 11:59:36 --> Helper loaded: cookie_helper
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:59:36 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:59:36 --> Utf8 Class Initialized
INFO - 2024-07-26 11:59:36 --> URI Class Initialized
INFO - 2024-07-26 11:59:36 --> Router Class Initialized
INFO - 2024-07-26 11:59:36 --> Output Class Initialized
INFO - 2024-07-26 11:59:36 --> Security Class Initialized
DEBUG - 2024-07-26 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:59:36 --> Input Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Loader Class Initialized
INFO - 2024-07-26 11:59:36 --> Helper loaded: url_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: file_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: form_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: my_helper
INFO - 2024-07-26 11:59:36 --> Database Driver Class Initialized
INFO - 2024-07-26 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:59:36 --> Controller Class Initialized
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:59:36 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:59:36 --> Utf8 Class Initialized
INFO - 2024-07-26 11:59:36 --> URI Class Initialized
INFO - 2024-07-26 11:59:36 --> Router Class Initialized
INFO - 2024-07-26 11:59:36 --> Output Class Initialized
INFO - 2024-07-26 11:59:36 --> Security Class Initialized
DEBUG - 2024-07-26 11:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:59:36 --> Input Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Language Class Initialized
INFO - 2024-07-26 11:59:36 --> Config Class Initialized
INFO - 2024-07-26 11:59:36 --> Loader Class Initialized
INFO - 2024-07-26 11:59:36 --> Helper loaded: url_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: file_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: form_helper
INFO - 2024-07-26 11:59:36 --> Helper loaded: my_helper
INFO - 2024-07-26 11:59:36 --> Database Driver Class Initialized
INFO - 2024-07-26 11:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:59:36 --> Controller Class Initialized
DEBUG - 2024-07-26 11:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-26 11:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:59:36 --> Final output sent to browser
DEBUG - 2024-07-26 11:59:36 --> Total execution time: 0.0534
INFO - 2024-07-26 11:59:56 --> Config Class Initialized
INFO - 2024-07-26 11:59:56 --> Hooks Class Initialized
DEBUG - 2024-07-26 11:59:56 --> UTF-8 Support Enabled
INFO - 2024-07-26 11:59:56 --> Utf8 Class Initialized
INFO - 2024-07-26 11:59:56 --> URI Class Initialized
INFO - 2024-07-26 11:59:56 --> Router Class Initialized
INFO - 2024-07-26 11:59:56 --> Output Class Initialized
INFO - 2024-07-26 11:59:56 --> Security Class Initialized
DEBUG - 2024-07-26 11:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 11:59:56 --> Input Class Initialized
INFO - 2024-07-26 11:59:56 --> Language Class Initialized
INFO - 2024-07-26 11:59:56 --> Language Class Initialized
INFO - 2024-07-26 11:59:56 --> Config Class Initialized
INFO - 2024-07-26 11:59:56 --> Loader Class Initialized
INFO - 2024-07-26 11:59:56 --> Helper loaded: url_helper
INFO - 2024-07-26 11:59:56 --> Helper loaded: file_helper
INFO - 2024-07-26 11:59:56 --> Helper loaded: form_helper
INFO - 2024-07-26 11:59:56 --> Helper loaded: my_helper
INFO - 2024-07-26 11:59:56 --> Database Driver Class Initialized
INFO - 2024-07-26 11:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 11:59:56 --> Controller Class Initialized
DEBUG - 2024-07-26 11:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-26 11:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 11:59:56 --> Final output sent to browser
DEBUG - 2024-07-26 11:59:56 --> Total execution time: 0.1767
INFO - 2024-07-26 12:00:02 --> Config Class Initialized
INFO - 2024-07-26 12:00:02 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:02 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:02 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:02 --> URI Class Initialized
INFO - 2024-07-26 12:00:02 --> Router Class Initialized
INFO - 2024-07-26 12:00:02 --> Output Class Initialized
INFO - 2024-07-26 12:00:02 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:02 --> Input Class Initialized
INFO - 2024-07-26 12:00:02 --> Language Class Initialized
INFO - 2024-07-26 12:00:02 --> Language Class Initialized
INFO - 2024-07-26 12:00:02 --> Config Class Initialized
INFO - 2024-07-26 12:00:02 --> Loader Class Initialized
INFO - 2024-07-26 12:00:02 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:02 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:02 --> Controller Class Initialized
INFO - 2024-07-26 12:00:02 --> Helper loaded: cookie_helper
INFO - 2024-07-26 12:00:02 --> Final output sent to browser
DEBUG - 2024-07-26 12:00:02 --> Total execution time: 0.3052
INFO - 2024-07-26 12:00:02 --> Config Class Initialized
INFO - 2024-07-26 12:00:02 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:02 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:02 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:02 --> URI Class Initialized
INFO - 2024-07-26 12:00:02 --> Router Class Initialized
INFO - 2024-07-26 12:00:02 --> Output Class Initialized
INFO - 2024-07-26 12:00:02 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:02 --> Input Class Initialized
INFO - 2024-07-26 12:00:02 --> Language Class Initialized
INFO - 2024-07-26 12:00:02 --> Language Class Initialized
INFO - 2024-07-26 12:00:02 --> Config Class Initialized
INFO - 2024-07-26 12:00:02 --> Loader Class Initialized
INFO - 2024-07-26 12:00:02 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:02 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:02 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:02 --> Controller Class Initialized
DEBUG - 2024-07-26 12:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-26 12:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 12:00:02 --> Final output sent to browser
DEBUG - 2024-07-26 12:00:02 --> Total execution time: 0.0495
INFO - 2024-07-26 12:00:04 --> Config Class Initialized
INFO - 2024-07-26 12:00:04 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:04 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:04 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:04 --> URI Class Initialized
INFO - 2024-07-26 12:00:04 --> Router Class Initialized
INFO - 2024-07-26 12:00:04 --> Output Class Initialized
INFO - 2024-07-26 12:00:04 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:04 --> Input Class Initialized
INFO - 2024-07-26 12:00:04 --> Language Class Initialized
INFO - 2024-07-26 12:00:05 --> Language Class Initialized
INFO - 2024-07-26 12:00:05 --> Config Class Initialized
INFO - 2024-07-26 12:00:05 --> Loader Class Initialized
INFO - 2024-07-26 12:00:05 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:05 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:05 --> Controller Class Initialized
DEBUG - 2024-07-26 12:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-26 12:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-26 12:00:05 --> Final output sent to browser
DEBUG - 2024-07-26 12:00:05 --> Total execution time: 0.0865
INFO - 2024-07-26 12:00:05 --> Config Class Initialized
INFO - 2024-07-26 12:00:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:05 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:05 --> URI Class Initialized
INFO - 2024-07-26 12:00:05 --> Router Class Initialized
INFO - 2024-07-26 12:00:05 --> Output Class Initialized
INFO - 2024-07-26 12:00:05 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:05 --> Input Class Initialized
INFO - 2024-07-26 12:00:05 --> Language Class Initialized
ERROR - 2024-07-26 12:00:05 --> 404 Page Not Found: /index
INFO - 2024-07-26 12:00:05 --> Config Class Initialized
INFO - 2024-07-26 12:00:05 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:05 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:05 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:05 --> URI Class Initialized
INFO - 2024-07-26 12:00:05 --> Router Class Initialized
INFO - 2024-07-26 12:00:05 --> Output Class Initialized
INFO - 2024-07-26 12:00:05 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:05 --> Input Class Initialized
INFO - 2024-07-26 12:00:05 --> Language Class Initialized
INFO - 2024-07-26 12:00:05 --> Language Class Initialized
INFO - 2024-07-26 12:00:05 --> Config Class Initialized
INFO - 2024-07-26 12:00:05 --> Loader Class Initialized
INFO - 2024-07-26 12:00:05 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:05 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:05 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:05 --> Controller Class Initialized
INFO - 2024-07-26 12:00:30 --> Config Class Initialized
INFO - 2024-07-26 12:00:30 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:30 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:30 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:30 --> URI Class Initialized
INFO - 2024-07-26 12:00:30 --> Router Class Initialized
INFO - 2024-07-26 12:00:30 --> Output Class Initialized
INFO - 2024-07-26 12:00:30 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:30 --> Input Class Initialized
INFO - 2024-07-26 12:00:30 --> Language Class Initialized
INFO - 2024-07-26 12:00:30 --> Language Class Initialized
INFO - 2024-07-26 12:00:30 --> Config Class Initialized
INFO - 2024-07-26 12:00:30 --> Loader Class Initialized
INFO - 2024-07-26 12:00:30 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:30 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:30 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:30 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:30 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:30 --> Controller Class Initialized
INFO - 2024-07-26 12:00:31 --> Config Class Initialized
INFO - 2024-07-26 12:00:31 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:31 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:31 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:31 --> URI Class Initialized
INFO - 2024-07-26 12:00:31 --> Router Class Initialized
INFO - 2024-07-26 12:00:31 --> Output Class Initialized
INFO - 2024-07-26 12:00:31 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:31 --> Input Class Initialized
INFO - 2024-07-26 12:00:31 --> Language Class Initialized
INFO - 2024-07-26 12:00:31 --> Language Class Initialized
INFO - 2024-07-26 12:00:31 --> Config Class Initialized
INFO - 2024-07-26 12:00:31 --> Loader Class Initialized
INFO - 2024-07-26 12:00:31 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:31 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:31 --> Controller Class Initialized
INFO - 2024-07-26 12:00:31 --> Config Class Initialized
INFO - 2024-07-26 12:00:31 --> Hooks Class Initialized
DEBUG - 2024-07-26 12:00:31 --> UTF-8 Support Enabled
INFO - 2024-07-26 12:00:31 --> Utf8 Class Initialized
INFO - 2024-07-26 12:00:31 --> URI Class Initialized
INFO - 2024-07-26 12:00:31 --> Router Class Initialized
INFO - 2024-07-26 12:00:31 --> Output Class Initialized
INFO - 2024-07-26 12:00:31 --> Security Class Initialized
DEBUG - 2024-07-26 12:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-26 12:00:31 --> Input Class Initialized
INFO - 2024-07-26 12:00:31 --> Language Class Initialized
INFO - 2024-07-26 12:00:31 --> Language Class Initialized
INFO - 2024-07-26 12:00:31 --> Config Class Initialized
INFO - 2024-07-26 12:00:31 --> Loader Class Initialized
INFO - 2024-07-26 12:00:31 --> Helper loaded: url_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: file_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: form_helper
INFO - 2024-07-26 12:00:31 --> Helper loaded: my_helper
INFO - 2024-07-26 12:00:31 --> Database Driver Class Initialized
INFO - 2024-07-26 12:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-26 12:00:31 --> Controller Class Initialized
