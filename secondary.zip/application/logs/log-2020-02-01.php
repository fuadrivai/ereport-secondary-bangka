<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-01 02:17:44 --> Config Class Initialized
INFO - 2020-02-01 02:17:44 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:44 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:44 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:44 --> URI Class Initialized
INFO - 2020-02-01 02:17:44 --> Router Class Initialized
INFO - 2020-02-01 02:17:44 --> Output Class Initialized
INFO - 2020-02-01 02:17:44 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:44 --> Input Class Initialized
INFO - 2020-02-01 02:17:44 --> Language Class Initialized
INFO - 2020-02-01 02:17:44 --> Language Class Initialized
INFO - 2020-02-01 02:17:44 --> Config Class Initialized
INFO - 2020-02-01 02:17:44 --> Loader Class Initialized
INFO - 2020-02-01 02:17:44 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:44 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:44 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:44 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:44 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:44 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-02-01 02:17:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:44 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:44 --> Total execution time: 0.2399
INFO - 2020-02-01 02:17:49 --> Config Class Initialized
INFO - 2020-02-01 02:17:49 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:49 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:49 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:49 --> URI Class Initialized
INFO - 2020-02-01 02:17:49 --> Router Class Initialized
INFO - 2020-02-01 02:17:49 --> Output Class Initialized
INFO - 2020-02-01 02:17:49 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:49 --> Input Class Initialized
INFO - 2020-02-01 02:17:49 --> Language Class Initialized
INFO - 2020-02-01 02:17:49 --> Language Class Initialized
INFO - 2020-02-01 02:17:49 --> Config Class Initialized
INFO - 2020-02-01 02:17:49 --> Loader Class Initialized
INFO - 2020-02-01 02:17:49 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:49 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:49 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:49 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:49 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:49 --> Controller Class Initialized
INFO - 2020-02-01 02:17:49 --> Helper loaded: cookie_helper
INFO - 2020-02-01 02:17:49 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:49 --> Total execution time: 0.2838
INFO - 2020-02-01 02:17:49 --> Config Class Initialized
INFO - 2020-02-01 02:17:49 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:49 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:49 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:49 --> URI Class Initialized
INFO - 2020-02-01 02:17:49 --> Router Class Initialized
INFO - 2020-02-01 02:17:49 --> Output Class Initialized
INFO - 2020-02-01 02:17:49 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:49 --> Input Class Initialized
INFO - 2020-02-01 02:17:49 --> Language Class Initialized
INFO - 2020-02-01 02:17:49 --> Language Class Initialized
INFO - 2020-02-01 02:17:49 --> Config Class Initialized
INFO - 2020-02-01 02:17:49 --> Loader Class Initialized
INFO - 2020-02-01 02:17:49 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:50 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:50 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:50 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:50 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:50 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-02-01 02:17:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:50 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:50 --> Total execution time: 0.3956
INFO - 2020-02-01 02:17:51 --> Config Class Initialized
INFO - 2020-02-01 02:17:51 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:51 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:51 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:51 --> URI Class Initialized
INFO - 2020-02-01 02:17:51 --> Router Class Initialized
INFO - 2020-02-01 02:17:51 --> Output Class Initialized
INFO - 2020-02-01 02:17:51 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:51 --> Input Class Initialized
INFO - 2020-02-01 02:17:51 --> Language Class Initialized
INFO - 2020-02-01 02:17:51 --> Language Class Initialized
INFO - 2020-02-01 02:17:51 --> Config Class Initialized
INFO - 2020-02-01 02:17:51 --> Loader Class Initialized
INFO - 2020-02-01 02:17:51 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:51 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:51 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:51 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:51 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:51 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-02-01 02:17:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:51 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:51 --> Total execution time: 0.2922
INFO - 2020-02-01 02:17:52 --> Config Class Initialized
INFO - 2020-02-01 02:17:52 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:52 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:52 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:52 --> URI Class Initialized
INFO - 2020-02-01 02:17:52 --> Router Class Initialized
INFO - 2020-02-01 02:17:52 --> Output Class Initialized
INFO - 2020-02-01 02:17:52 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:52 --> Input Class Initialized
INFO - 2020-02-01 02:17:52 --> Language Class Initialized
INFO - 2020-02-01 02:17:52 --> Language Class Initialized
INFO - 2020-02-01 02:17:52 --> Config Class Initialized
INFO - 2020-02-01 02:17:52 --> Loader Class Initialized
INFO - 2020-02-01 02:17:52 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:52 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:52 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:52 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:52 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:52 --> Controller Class Initialized
INFO - 2020-02-01 02:17:52 --> Config Class Initialized
INFO - 2020-02-01 02:17:53 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:53 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:53 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:53 --> URI Class Initialized
INFO - 2020-02-01 02:17:53 --> Router Class Initialized
INFO - 2020-02-01 02:17:53 --> Output Class Initialized
INFO - 2020-02-01 02:17:53 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:53 --> Input Class Initialized
INFO - 2020-02-01 02:17:53 --> Language Class Initialized
INFO - 2020-02-01 02:17:53 --> Language Class Initialized
INFO - 2020-02-01 02:17:53 --> Config Class Initialized
INFO - 2020-02-01 02:17:53 --> Loader Class Initialized
INFO - 2020-02-01 02:17:53 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:53 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:53 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-01 02:17:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:53 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:53 --> Total execution time: 0.2796
INFO - 2020-02-01 02:17:53 --> Config Class Initialized
INFO - 2020-02-01 02:17:53 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:53 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:53 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:53 --> URI Class Initialized
INFO - 2020-02-01 02:17:53 --> Router Class Initialized
INFO - 2020-02-01 02:17:53 --> Output Class Initialized
INFO - 2020-02-01 02:17:53 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:53 --> Input Class Initialized
INFO - 2020-02-01 02:17:53 --> Language Class Initialized
INFO - 2020-02-01 02:17:53 --> Language Class Initialized
INFO - 2020-02-01 02:17:53 --> Config Class Initialized
INFO - 2020-02-01 02:17:53 --> Loader Class Initialized
INFO - 2020-02-01 02:17:53 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:53 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:53 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:53 --> Controller Class Initialized
INFO - 2020-02-01 02:17:54 --> Config Class Initialized
INFO - 2020-02-01 02:17:54 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:54 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:54 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:54 --> URI Class Initialized
INFO - 2020-02-01 02:17:54 --> Router Class Initialized
INFO - 2020-02-01 02:17:54 --> Output Class Initialized
INFO - 2020-02-01 02:17:54 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:54 --> Input Class Initialized
INFO - 2020-02-01 02:17:54 --> Language Class Initialized
INFO - 2020-02-01 02:17:54 --> Language Class Initialized
INFO - 2020-02-01 02:17:54 --> Config Class Initialized
INFO - 2020-02-01 02:17:54 --> Loader Class Initialized
INFO - 2020-02-01 02:17:54 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:54 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:54 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-01 02:17:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:54 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:54 --> Total execution time: 0.2702
INFO - 2020-02-01 02:17:54 --> Config Class Initialized
INFO - 2020-02-01 02:17:54 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:54 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:54 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:54 --> URI Class Initialized
INFO - 2020-02-01 02:17:54 --> Router Class Initialized
INFO - 2020-02-01 02:17:54 --> Output Class Initialized
INFO - 2020-02-01 02:17:54 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:54 --> Input Class Initialized
INFO - 2020-02-01 02:17:54 --> Language Class Initialized
INFO - 2020-02-01 02:17:54 --> Language Class Initialized
INFO - 2020-02-01 02:17:54 --> Config Class Initialized
INFO - 2020-02-01 02:17:54 --> Loader Class Initialized
INFO - 2020-02-01 02:17:54 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:54 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:54 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:54 --> Controller Class Initialized
INFO - 2020-02-01 02:17:55 --> Config Class Initialized
INFO - 2020-02-01 02:17:55 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:55 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:55 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:55 --> URI Class Initialized
INFO - 2020-02-01 02:17:55 --> Router Class Initialized
INFO - 2020-02-01 02:17:55 --> Output Class Initialized
INFO - 2020-02-01 02:17:55 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:55 --> Input Class Initialized
INFO - 2020-02-01 02:17:55 --> Language Class Initialized
INFO - 2020-02-01 02:17:55 --> Language Class Initialized
INFO - 2020-02-01 02:17:55 --> Config Class Initialized
INFO - 2020-02-01 02:17:55 --> Loader Class Initialized
INFO - 2020-02-01 02:17:55 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:55 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:55 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:55 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:55 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:55 --> Controller Class Initialized
DEBUG - 2020-02-01 02:17:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-01 02:17:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-02-01 02:17:55 --> Final output sent to browser
DEBUG - 2020-02-01 02:17:55 --> Total execution time: 0.3195
INFO - 2020-02-01 02:17:56 --> Config Class Initialized
INFO - 2020-02-01 02:17:56 --> Hooks Class Initialized
DEBUG - 2020-02-01 02:17:56 --> UTF-8 Support Enabled
INFO - 2020-02-01 02:17:56 --> Utf8 Class Initialized
INFO - 2020-02-01 02:17:56 --> URI Class Initialized
INFO - 2020-02-01 02:17:56 --> Router Class Initialized
INFO - 2020-02-01 02:17:56 --> Output Class Initialized
INFO - 2020-02-01 02:17:56 --> Security Class Initialized
DEBUG - 2020-02-01 02:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-01 02:17:56 --> Input Class Initialized
INFO - 2020-02-01 02:17:56 --> Language Class Initialized
INFO - 2020-02-01 02:17:56 --> Language Class Initialized
INFO - 2020-02-01 02:17:56 --> Config Class Initialized
INFO - 2020-02-01 02:17:56 --> Loader Class Initialized
INFO - 2020-02-01 02:17:56 --> Helper loaded: url_helper
INFO - 2020-02-01 02:17:56 --> Helper loaded: file_helper
INFO - 2020-02-01 02:17:56 --> Helper loaded: form_helper
INFO - 2020-02-01 02:17:56 --> Helper loaded: my_helper
INFO - 2020-02-01 02:17:56 --> Database Driver Class Initialized
DEBUG - 2020-02-01 02:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-01 02:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-01 02:17:56 --> Controller Class Initialized
