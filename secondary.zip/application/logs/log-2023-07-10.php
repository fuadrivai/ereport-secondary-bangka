<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-10 03:52:34 --> Config Class Initialized
INFO - 2023-07-10 03:52:34 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:34 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:34 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:34 --> URI Class Initialized
DEBUG - 2023-07-10 03:52:34 --> No URI present. Default controller set.
INFO - 2023-07-10 03:52:34 --> Router Class Initialized
INFO - 2023-07-10 03:52:34 --> Output Class Initialized
INFO - 2023-07-10 03:52:34 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:34 --> Input Class Initialized
INFO - 2023-07-10 03:52:34 --> Language Class Initialized
INFO - 2023-07-10 03:52:34 --> Language Class Initialized
INFO - 2023-07-10 03:52:34 --> Config Class Initialized
INFO - 2023-07-10 03:52:34 --> Loader Class Initialized
INFO - 2023-07-10 03:52:34 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:34 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:34 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:34 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:34 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:35 --> Controller Class Initialized
INFO - 2023-07-10 03:52:35 --> Config Class Initialized
INFO - 2023-07-10 03:52:35 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:35 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:35 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:35 --> URI Class Initialized
INFO - 2023-07-10 03:52:35 --> Router Class Initialized
INFO - 2023-07-10 03:52:35 --> Output Class Initialized
INFO - 2023-07-10 03:52:35 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:35 --> Input Class Initialized
INFO - 2023-07-10 03:52:35 --> Language Class Initialized
INFO - 2023-07-10 03:52:35 --> Language Class Initialized
INFO - 2023-07-10 03:52:35 --> Config Class Initialized
INFO - 2023-07-10 03:52:35 --> Loader Class Initialized
INFO - 2023-07-10 03:52:35 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:35 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:35 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:35 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:35 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:35 --> Controller Class Initialized
DEBUG - 2023-07-10 03:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 03:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 03:52:35 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:35 --> Total execution time: 0.1091
INFO - 2023-07-10 03:52:42 --> Config Class Initialized
INFO - 2023-07-10 03:52:42 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:42 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:42 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:42 --> URI Class Initialized
INFO - 2023-07-10 03:52:42 --> Router Class Initialized
INFO - 2023-07-10 03:52:42 --> Output Class Initialized
INFO - 2023-07-10 03:52:42 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:42 --> Input Class Initialized
INFO - 2023-07-10 03:52:42 --> Language Class Initialized
INFO - 2023-07-10 03:52:42 --> Language Class Initialized
INFO - 2023-07-10 03:52:42 --> Config Class Initialized
INFO - 2023-07-10 03:52:42 --> Loader Class Initialized
INFO - 2023-07-10 03:52:42 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:42 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:42 --> Controller Class Initialized
INFO - 2023-07-10 03:52:42 --> Helper loaded: cookie_helper
INFO - 2023-07-10 03:52:42 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:42 --> Total execution time: 0.0892
INFO - 2023-07-10 03:52:42 --> Config Class Initialized
INFO - 2023-07-10 03:52:42 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:42 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:42 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:42 --> URI Class Initialized
INFO - 2023-07-10 03:52:42 --> Router Class Initialized
INFO - 2023-07-10 03:52:42 --> Output Class Initialized
INFO - 2023-07-10 03:52:42 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:42 --> Input Class Initialized
INFO - 2023-07-10 03:52:42 --> Language Class Initialized
INFO - 2023-07-10 03:52:42 --> Language Class Initialized
INFO - 2023-07-10 03:52:42 --> Config Class Initialized
INFO - 2023-07-10 03:52:42 --> Loader Class Initialized
INFO - 2023-07-10 03:52:42 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:42 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:42 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:42 --> Controller Class Initialized
DEBUG - 2023-07-10 03:52:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-10 03:52:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 03:52:42 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:42 --> Total execution time: 0.0914
INFO - 2023-07-10 03:52:44 --> Config Class Initialized
INFO - 2023-07-10 03:52:44 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:44 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:44 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:44 --> URI Class Initialized
INFO - 2023-07-10 03:52:44 --> Router Class Initialized
INFO - 2023-07-10 03:52:44 --> Output Class Initialized
INFO - 2023-07-10 03:52:44 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:44 --> Input Class Initialized
INFO - 2023-07-10 03:52:44 --> Language Class Initialized
INFO - 2023-07-10 03:52:44 --> Language Class Initialized
INFO - 2023-07-10 03:52:44 --> Config Class Initialized
INFO - 2023-07-10 03:52:44 --> Loader Class Initialized
INFO - 2023-07-10 03:52:44 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:44 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:44 --> Controller Class Initialized
DEBUG - 2023-07-10 03:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-10 03:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 03:52:44 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:44 --> Total execution time: 0.0707
INFO - 2023-07-10 03:52:44 --> Config Class Initialized
INFO - 2023-07-10 03:52:44 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:44 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:44 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:44 --> URI Class Initialized
INFO - 2023-07-10 03:52:44 --> Router Class Initialized
INFO - 2023-07-10 03:52:44 --> Output Class Initialized
INFO - 2023-07-10 03:52:44 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:44 --> Input Class Initialized
INFO - 2023-07-10 03:52:44 --> Language Class Initialized
INFO - 2023-07-10 03:52:44 --> Language Class Initialized
INFO - 2023-07-10 03:52:44 --> Config Class Initialized
INFO - 2023-07-10 03:52:44 --> Loader Class Initialized
INFO - 2023-07-10 03:52:44 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:44 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:44 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:44 --> Controller Class Initialized
INFO - 2023-07-10 03:52:47 --> Config Class Initialized
INFO - 2023-07-10 03:52:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:47 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:47 --> URI Class Initialized
INFO - 2023-07-10 03:52:47 --> Router Class Initialized
INFO - 2023-07-10 03:52:47 --> Output Class Initialized
INFO - 2023-07-10 03:52:47 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:47 --> Input Class Initialized
INFO - 2023-07-10 03:52:47 --> Language Class Initialized
INFO - 2023-07-10 03:52:47 --> Language Class Initialized
INFO - 2023-07-10 03:52:47 --> Config Class Initialized
INFO - 2023-07-10 03:52:47 --> Loader Class Initialized
INFO - 2023-07-10 03:52:47 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:47 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:47 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:47 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:47 --> Controller Class Initialized
DEBUG - 2023-07-10 03:52:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-10 03:52:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 03:52:47 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:47 --> Total execution time: 0.0907
INFO - 2023-07-10 03:52:51 --> Config Class Initialized
INFO - 2023-07-10 03:52:51 --> Hooks Class Initialized
DEBUG - 2023-07-10 03:52:51 --> UTF-8 Support Enabled
INFO - 2023-07-10 03:52:51 --> Utf8 Class Initialized
INFO - 2023-07-10 03:52:51 --> URI Class Initialized
INFO - 2023-07-10 03:52:51 --> Router Class Initialized
INFO - 2023-07-10 03:52:51 --> Output Class Initialized
INFO - 2023-07-10 03:52:51 --> Security Class Initialized
DEBUG - 2023-07-10 03:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 03:52:51 --> Input Class Initialized
INFO - 2023-07-10 03:52:51 --> Language Class Initialized
INFO - 2023-07-10 03:52:51 --> Language Class Initialized
INFO - 2023-07-10 03:52:51 --> Config Class Initialized
INFO - 2023-07-10 03:52:51 --> Loader Class Initialized
INFO - 2023-07-10 03:52:51 --> Helper loaded: url_helper
INFO - 2023-07-10 03:52:51 --> Helper loaded: file_helper
INFO - 2023-07-10 03:52:51 --> Helper loaded: form_helper
INFO - 2023-07-10 03:52:51 --> Helper loaded: my_helper
INFO - 2023-07-10 03:52:51 --> Database Driver Class Initialized
DEBUG - 2023-07-10 03:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 03:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 03:52:51 --> Controller Class Initialized
DEBUG - 2023-07-10 03:52:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-10 03:52:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 03:52:51 --> Final output sent to browser
DEBUG - 2023-07-10 03:52:51 --> Total execution time: 0.0691
INFO - 2023-07-10 04:07:59 --> Config Class Initialized
INFO - 2023-07-10 04:07:59 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:07:59 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:07:59 --> Utf8 Class Initialized
INFO - 2023-07-10 04:07:59 --> URI Class Initialized
INFO - 2023-07-10 04:07:59 --> Router Class Initialized
INFO - 2023-07-10 04:07:59 --> Output Class Initialized
INFO - 2023-07-10 04:07:59 --> Security Class Initialized
DEBUG - 2023-07-10 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:07:59 --> Input Class Initialized
INFO - 2023-07-10 04:07:59 --> Language Class Initialized
INFO - 2023-07-10 04:07:59 --> Language Class Initialized
INFO - 2023-07-10 04:07:59 --> Config Class Initialized
INFO - 2023-07-10 04:07:59 --> Loader Class Initialized
INFO - 2023-07-10 04:07:59 --> Helper loaded: url_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: file_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: form_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: my_helper
INFO - 2023-07-10 04:07:59 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:07:59 --> Controller Class Initialized
INFO - 2023-07-10 04:07:59 --> Helper loaded: cookie_helper
INFO - 2023-07-10 04:07:59 --> Config Class Initialized
INFO - 2023-07-10 04:07:59 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:07:59 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:07:59 --> Utf8 Class Initialized
INFO - 2023-07-10 04:07:59 --> URI Class Initialized
INFO - 2023-07-10 04:07:59 --> Router Class Initialized
INFO - 2023-07-10 04:07:59 --> Output Class Initialized
INFO - 2023-07-10 04:07:59 --> Security Class Initialized
DEBUG - 2023-07-10 04:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:07:59 --> Input Class Initialized
INFO - 2023-07-10 04:07:59 --> Language Class Initialized
INFO - 2023-07-10 04:07:59 --> Language Class Initialized
INFO - 2023-07-10 04:07:59 --> Config Class Initialized
INFO - 2023-07-10 04:07:59 --> Loader Class Initialized
INFO - 2023-07-10 04:07:59 --> Helper loaded: url_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: file_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: form_helper
INFO - 2023-07-10 04:07:59 --> Helper loaded: my_helper
INFO - 2023-07-10 04:07:59 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:07:59 --> Controller Class Initialized
INFO - 2023-07-10 04:08:00 --> Config Class Initialized
INFO - 2023-07-10 04:08:00 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:08:00 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:08:00 --> Utf8 Class Initialized
INFO - 2023-07-10 04:08:00 --> URI Class Initialized
INFO - 2023-07-10 04:08:00 --> Router Class Initialized
INFO - 2023-07-10 04:08:00 --> Output Class Initialized
INFO - 2023-07-10 04:08:00 --> Security Class Initialized
DEBUG - 2023-07-10 04:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:08:00 --> Input Class Initialized
INFO - 2023-07-10 04:08:00 --> Language Class Initialized
INFO - 2023-07-10 04:08:00 --> Language Class Initialized
INFO - 2023-07-10 04:08:00 --> Config Class Initialized
INFO - 2023-07-10 04:08:00 --> Loader Class Initialized
INFO - 2023-07-10 04:08:00 --> Helper loaded: url_helper
INFO - 2023-07-10 04:08:00 --> Helper loaded: file_helper
INFO - 2023-07-10 04:08:00 --> Helper loaded: form_helper
INFO - 2023-07-10 04:08:00 --> Helper loaded: my_helper
INFO - 2023-07-10 04:08:00 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:08:00 --> Controller Class Initialized
DEBUG - 2023-07-10 04:08:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 04:08:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:08:00 --> Final output sent to browser
DEBUG - 2023-07-10 04:08:00 --> Total execution time: 0.0689
INFO - 2023-07-10 04:09:21 --> Config Class Initialized
INFO - 2023-07-10 04:09:21 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:09:21 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:09:21 --> Utf8 Class Initialized
INFO - 2023-07-10 04:09:21 --> URI Class Initialized
DEBUG - 2023-07-10 04:09:21 --> No URI present. Default controller set.
INFO - 2023-07-10 04:09:21 --> Router Class Initialized
INFO - 2023-07-10 04:09:21 --> Output Class Initialized
INFO - 2023-07-10 04:09:21 --> Security Class Initialized
DEBUG - 2023-07-10 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:09:21 --> Input Class Initialized
INFO - 2023-07-10 04:09:21 --> Language Class Initialized
INFO - 2023-07-10 04:09:21 --> Language Class Initialized
INFO - 2023-07-10 04:09:21 --> Config Class Initialized
INFO - 2023-07-10 04:09:21 --> Loader Class Initialized
INFO - 2023-07-10 04:09:21 --> Helper loaded: url_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: file_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: form_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: my_helper
INFO - 2023-07-10 04:09:21 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:09:21 --> Controller Class Initialized
INFO - 2023-07-10 04:09:21 --> Config Class Initialized
INFO - 2023-07-10 04:09:21 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:09:21 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:09:21 --> Utf8 Class Initialized
INFO - 2023-07-10 04:09:21 --> URI Class Initialized
INFO - 2023-07-10 04:09:21 --> Router Class Initialized
INFO - 2023-07-10 04:09:21 --> Output Class Initialized
INFO - 2023-07-10 04:09:21 --> Security Class Initialized
DEBUG - 2023-07-10 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:09:21 --> Input Class Initialized
INFO - 2023-07-10 04:09:21 --> Language Class Initialized
INFO - 2023-07-10 04:09:21 --> Language Class Initialized
INFO - 2023-07-10 04:09:21 --> Config Class Initialized
INFO - 2023-07-10 04:09:21 --> Loader Class Initialized
INFO - 2023-07-10 04:09:21 --> Helper loaded: url_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: file_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: form_helper
INFO - 2023-07-10 04:09:21 --> Helper loaded: my_helper
INFO - 2023-07-10 04:09:21 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:09:21 --> Controller Class Initialized
DEBUG - 2023-07-10 04:09:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 04:09:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:09:21 --> Final output sent to browser
DEBUG - 2023-07-10 04:09:21 --> Total execution time: 0.0767
INFO - 2023-07-10 04:13:23 --> Config Class Initialized
INFO - 2023-07-10 04:13:23 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:13:23 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:13:23 --> Utf8 Class Initialized
INFO - 2023-07-10 04:13:23 --> URI Class Initialized
INFO - 2023-07-10 04:13:23 --> Router Class Initialized
INFO - 2023-07-10 04:13:23 --> Output Class Initialized
INFO - 2023-07-10 04:13:23 --> Security Class Initialized
DEBUG - 2023-07-10 04:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:13:23 --> Input Class Initialized
INFO - 2023-07-10 04:13:23 --> Language Class Initialized
INFO - 2023-07-10 04:13:23 --> Language Class Initialized
INFO - 2023-07-10 04:13:23 --> Config Class Initialized
INFO - 2023-07-10 04:13:23 --> Loader Class Initialized
INFO - 2023-07-10 04:13:23 --> Helper loaded: url_helper
INFO - 2023-07-10 04:13:23 --> Helper loaded: file_helper
INFO - 2023-07-10 04:13:23 --> Helper loaded: form_helper
INFO - 2023-07-10 04:13:23 --> Helper loaded: my_helper
INFO - 2023-07-10 04:13:23 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:13:23 --> Controller Class Initialized
INFO - 2023-07-10 04:13:23 --> Helper loaded: cookie_helper
INFO - 2023-07-10 04:13:23 --> Final output sent to browser
DEBUG - 2023-07-10 04:13:23 --> Total execution time: 0.1633
INFO - 2023-07-10 04:13:23 --> Config Class Initialized
INFO - 2023-07-10 04:13:23 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:13:24 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:13:24 --> Utf8 Class Initialized
INFO - 2023-07-10 04:13:24 --> URI Class Initialized
INFO - 2023-07-10 04:13:24 --> Router Class Initialized
INFO - 2023-07-10 04:13:24 --> Output Class Initialized
INFO - 2023-07-10 04:13:24 --> Security Class Initialized
DEBUG - 2023-07-10 04:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:13:24 --> Input Class Initialized
INFO - 2023-07-10 04:13:24 --> Language Class Initialized
INFO - 2023-07-10 04:13:24 --> Language Class Initialized
INFO - 2023-07-10 04:13:24 --> Config Class Initialized
INFO - 2023-07-10 04:13:24 --> Loader Class Initialized
INFO - 2023-07-10 04:13:24 --> Helper loaded: url_helper
INFO - 2023-07-10 04:13:24 --> Helper loaded: file_helper
INFO - 2023-07-10 04:13:24 --> Helper loaded: form_helper
INFO - 2023-07-10 04:13:24 --> Helper loaded: my_helper
INFO - 2023-07-10 04:13:24 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:13:24 --> Controller Class Initialized
DEBUG - 2023-07-10 04:13:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-10 04:13:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:13:24 --> Final output sent to browser
DEBUG - 2023-07-10 04:13:24 --> Total execution time: 0.1018
INFO - 2023-07-10 04:14:27 --> Config Class Initialized
INFO - 2023-07-10 04:14:27 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:14:27 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:14:27 --> Utf8 Class Initialized
INFO - 2023-07-10 04:14:27 --> URI Class Initialized
INFO - 2023-07-10 04:14:27 --> Router Class Initialized
INFO - 2023-07-10 04:14:27 --> Output Class Initialized
INFO - 2023-07-10 04:14:27 --> Security Class Initialized
DEBUG - 2023-07-10 04:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:14:27 --> Input Class Initialized
INFO - 2023-07-10 04:14:27 --> Language Class Initialized
INFO - 2023-07-10 04:14:27 --> Language Class Initialized
INFO - 2023-07-10 04:14:27 --> Config Class Initialized
INFO - 2023-07-10 04:14:27 --> Loader Class Initialized
INFO - 2023-07-10 04:14:27 --> Helper loaded: url_helper
INFO - 2023-07-10 04:14:27 --> Helper loaded: file_helper
INFO - 2023-07-10 04:14:27 --> Helper loaded: form_helper
INFO - 2023-07-10 04:14:27 --> Helper loaded: my_helper
INFO - 2023-07-10 04:14:27 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:14:27 --> Controller Class Initialized
DEBUG - 2023-07-10 04:14:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-10 04:14:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:14:27 --> Final output sent to browser
DEBUG - 2023-07-10 04:14:27 --> Total execution time: 0.1032
INFO - 2023-07-10 04:15:54 --> Config Class Initialized
INFO - 2023-07-10 04:15:54 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:15:54 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:15:54 --> Utf8 Class Initialized
INFO - 2023-07-10 04:15:54 --> URI Class Initialized
INFO - 2023-07-10 04:15:54 --> Router Class Initialized
INFO - 2023-07-10 04:15:54 --> Output Class Initialized
INFO - 2023-07-10 04:15:54 --> Security Class Initialized
DEBUG - 2023-07-10 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:15:54 --> Input Class Initialized
INFO - 2023-07-10 04:15:54 --> Language Class Initialized
INFO - 2023-07-10 04:15:54 --> Language Class Initialized
INFO - 2023-07-10 04:15:54 --> Config Class Initialized
INFO - 2023-07-10 04:15:54 --> Loader Class Initialized
INFO - 2023-07-10 04:15:54 --> Helper loaded: url_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: file_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: form_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: my_helper
INFO - 2023-07-10 04:15:54 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:15:54 --> Controller Class Initialized
DEBUG - 2023-07-10 04:15:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-10 04:15:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:15:54 --> Final output sent to browser
DEBUG - 2023-07-10 04:15:54 --> Total execution time: 0.1011
INFO - 2023-07-10 04:15:54 --> Config Class Initialized
INFO - 2023-07-10 04:15:54 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:15:54 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:15:54 --> Utf8 Class Initialized
INFO - 2023-07-10 04:15:54 --> URI Class Initialized
INFO - 2023-07-10 04:15:54 --> Router Class Initialized
INFO - 2023-07-10 04:15:54 --> Output Class Initialized
INFO - 2023-07-10 04:15:54 --> Security Class Initialized
DEBUG - 2023-07-10 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:15:54 --> Input Class Initialized
INFO - 2023-07-10 04:15:54 --> Language Class Initialized
INFO - 2023-07-10 04:15:54 --> Language Class Initialized
INFO - 2023-07-10 04:15:54 --> Config Class Initialized
INFO - 2023-07-10 04:15:54 --> Loader Class Initialized
INFO - 2023-07-10 04:15:54 --> Helper loaded: url_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: file_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: form_helper
INFO - 2023-07-10 04:15:54 --> Helper loaded: my_helper
INFO - 2023-07-10 04:15:54 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:15:54 --> Controller Class Initialized
INFO - 2023-07-10 04:16:46 --> Config Class Initialized
INFO - 2023-07-10 04:16:46 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:16:46 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:16:46 --> Utf8 Class Initialized
INFO - 2023-07-10 04:16:46 --> URI Class Initialized
INFO - 2023-07-10 04:16:46 --> Router Class Initialized
INFO - 2023-07-10 04:16:46 --> Output Class Initialized
INFO - 2023-07-10 04:16:46 --> Security Class Initialized
DEBUG - 2023-07-10 04:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:16:46 --> Input Class Initialized
INFO - 2023-07-10 04:16:46 --> Language Class Initialized
INFO - 2023-07-10 04:16:46 --> Language Class Initialized
INFO - 2023-07-10 04:16:46 --> Config Class Initialized
INFO - 2023-07-10 04:16:46 --> Loader Class Initialized
INFO - 2023-07-10 04:16:46 --> Helper loaded: url_helper
INFO - 2023-07-10 04:16:46 --> Helper loaded: file_helper
INFO - 2023-07-10 04:16:46 --> Helper loaded: form_helper
INFO - 2023-07-10 04:16:46 --> Helper loaded: my_helper
INFO - 2023-07-10 04:16:46 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:16:46 --> Controller Class Initialized
INFO - 2023-07-10 04:16:46 --> Final output sent to browser
DEBUG - 2023-07-10 04:16:46 --> Total execution time: 0.0794
INFO - 2023-07-10 04:17:19 --> Config Class Initialized
INFO - 2023-07-10 04:17:19 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:17:19 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:17:19 --> Utf8 Class Initialized
INFO - 2023-07-10 04:17:19 --> URI Class Initialized
INFO - 2023-07-10 04:17:19 --> Router Class Initialized
INFO - 2023-07-10 04:17:19 --> Output Class Initialized
INFO - 2023-07-10 04:17:19 --> Security Class Initialized
DEBUG - 2023-07-10 04:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:17:19 --> Input Class Initialized
INFO - 2023-07-10 04:17:19 --> Language Class Initialized
INFO - 2023-07-10 04:17:19 --> Language Class Initialized
INFO - 2023-07-10 04:17:19 --> Config Class Initialized
INFO - 2023-07-10 04:17:19 --> Loader Class Initialized
INFO - 2023-07-10 04:17:19 --> Helper loaded: url_helper
INFO - 2023-07-10 04:17:19 --> Helper loaded: file_helper
INFO - 2023-07-10 04:17:19 --> Helper loaded: form_helper
INFO - 2023-07-10 04:17:19 --> Helper loaded: my_helper
INFO - 2023-07-10 04:17:19 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:17:19 --> Controller Class Initialized
INFO - 2023-07-10 04:17:19 --> Final output sent to browser
DEBUG - 2023-07-10 04:17:19 --> Total execution time: 0.0869
INFO - 2023-07-10 04:17:34 --> Config Class Initialized
INFO - 2023-07-10 04:17:34 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:17:34 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:17:34 --> Utf8 Class Initialized
INFO - 2023-07-10 04:17:34 --> URI Class Initialized
INFO - 2023-07-10 04:17:34 --> Router Class Initialized
INFO - 2023-07-10 04:17:34 --> Output Class Initialized
INFO - 2023-07-10 04:17:34 --> Security Class Initialized
DEBUG - 2023-07-10 04:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:17:34 --> Input Class Initialized
INFO - 2023-07-10 04:17:34 --> Language Class Initialized
INFO - 2023-07-10 04:17:35 --> Language Class Initialized
INFO - 2023-07-10 04:17:35 --> Config Class Initialized
INFO - 2023-07-10 04:17:35 --> Loader Class Initialized
INFO - 2023-07-10 04:17:35 --> Helper loaded: url_helper
INFO - 2023-07-10 04:17:35 --> Helper loaded: file_helper
INFO - 2023-07-10 04:17:35 --> Helper loaded: form_helper
INFO - 2023-07-10 04:17:35 --> Helper loaded: my_helper
INFO - 2023-07-10 04:17:35 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:17:35 --> Controller Class Initialized
INFO - 2023-07-10 04:17:35 --> Final output sent to browser
DEBUG - 2023-07-10 04:17:35 --> Total execution time: 0.0815
INFO - 2023-07-10 04:17:49 --> Config Class Initialized
INFO - 2023-07-10 04:17:49 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:17:49 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:17:49 --> Utf8 Class Initialized
INFO - 2023-07-10 04:17:49 --> URI Class Initialized
INFO - 2023-07-10 04:17:49 --> Router Class Initialized
INFO - 2023-07-10 04:17:49 --> Output Class Initialized
INFO - 2023-07-10 04:17:49 --> Security Class Initialized
DEBUG - 2023-07-10 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:17:49 --> Input Class Initialized
INFO - 2023-07-10 04:17:49 --> Language Class Initialized
INFO - 2023-07-10 04:17:49 --> Language Class Initialized
INFO - 2023-07-10 04:17:49 --> Config Class Initialized
INFO - 2023-07-10 04:17:49 --> Loader Class Initialized
INFO - 2023-07-10 04:17:49 --> Helper loaded: url_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: file_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: form_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: my_helper
INFO - 2023-07-10 04:17:49 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:17:49 --> Controller Class Initialized
INFO - 2023-07-10 04:17:49 --> Final output sent to browser
DEBUG - 2023-07-10 04:17:49 --> Total execution time: 0.0906
INFO - 2023-07-10 04:17:49 --> Config Class Initialized
INFO - 2023-07-10 04:17:49 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:17:49 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:17:49 --> Utf8 Class Initialized
INFO - 2023-07-10 04:17:49 --> URI Class Initialized
INFO - 2023-07-10 04:17:49 --> Router Class Initialized
INFO - 2023-07-10 04:17:49 --> Output Class Initialized
INFO - 2023-07-10 04:17:49 --> Security Class Initialized
DEBUG - 2023-07-10 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:17:49 --> Input Class Initialized
INFO - 2023-07-10 04:17:49 --> Language Class Initialized
INFO - 2023-07-10 04:17:49 --> Language Class Initialized
INFO - 2023-07-10 04:17:49 --> Config Class Initialized
INFO - 2023-07-10 04:17:49 --> Loader Class Initialized
INFO - 2023-07-10 04:17:49 --> Helper loaded: url_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: file_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: form_helper
INFO - 2023-07-10 04:17:49 --> Helper loaded: my_helper
INFO - 2023-07-10 04:17:49 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:17:49 --> Controller Class Initialized
INFO - 2023-07-10 04:18:33 --> Config Class Initialized
INFO - 2023-07-10 04:18:33 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:18:33 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:18:33 --> Utf8 Class Initialized
INFO - 2023-07-10 04:18:33 --> URI Class Initialized
INFO - 2023-07-10 04:18:33 --> Router Class Initialized
INFO - 2023-07-10 04:18:33 --> Output Class Initialized
INFO - 2023-07-10 04:18:33 --> Security Class Initialized
DEBUG - 2023-07-10 04:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:18:33 --> Input Class Initialized
INFO - 2023-07-10 04:18:33 --> Language Class Initialized
INFO - 2023-07-10 04:18:33 --> Language Class Initialized
INFO - 2023-07-10 04:18:33 --> Config Class Initialized
INFO - 2023-07-10 04:18:33 --> Loader Class Initialized
INFO - 2023-07-10 04:18:33 --> Helper loaded: url_helper
INFO - 2023-07-10 04:18:33 --> Helper loaded: file_helper
INFO - 2023-07-10 04:18:33 --> Helper loaded: form_helper
INFO - 2023-07-10 04:18:33 --> Helper loaded: my_helper
INFO - 2023-07-10 04:18:33 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:18:33 --> Controller Class Initialized
INFO - 2023-07-10 04:18:33 --> Final output sent to browser
DEBUG - 2023-07-10 04:18:33 --> Total execution time: 0.0806
INFO - 2023-07-10 04:18:55 --> Config Class Initialized
INFO - 2023-07-10 04:18:55 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:18:55 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:18:55 --> Utf8 Class Initialized
INFO - 2023-07-10 04:18:55 --> URI Class Initialized
INFO - 2023-07-10 04:18:55 --> Router Class Initialized
INFO - 2023-07-10 04:18:55 --> Output Class Initialized
INFO - 2023-07-10 04:18:55 --> Security Class Initialized
DEBUG - 2023-07-10 04:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:18:55 --> Input Class Initialized
INFO - 2023-07-10 04:18:55 --> Language Class Initialized
INFO - 2023-07-10 04:18:55 --> Language Class Initialized
INFO - 2023-07-10 04:18:55 --> Config Class Initialized
INFO - 2023-07-10 04:18:55 --> Loader Class Initialized
INFO - 2023-07-10 04:18:55 --> Helper loaded: url_helper
INFO - 2023-07-10 04:18:55 --> Helper loaded: file_helper
INFO - 2023-07-10 04:18:55 --> Helper loaded: form_helper
INFO - 2023-07-10 04:18:55 --> Helper loaded: my_helper
INFO - 2023-07-10 04:18:55 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:18:55 --> Controller Class Initialized
INFO - 2023-07-10 04:18:55 --> Final output sent to browser
DEBUG - 2023-07-10 04:18:55 --> Total execution time: 0.0858
INFO - 2023-07-10 04:19:13 --> Config Class Initialized
INFO - 2023-07-10 04:19:13 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:13 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:13 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:13 --> URI Class Initialized
INFO - 2023-07-10 04:19:13 --> Router Class Initialized
INFO - 2023-07-10 04:19:13 --> Output Class Initialized
INFO - 2023-07-10 04:19:13 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:13 --> Input Class Initialized
INFO - 2023-07-10 04:19:13 --> Language Class Initialized
INFO - 2023-07-10 04:19:13 --> Language Class Initialized
INFO - 2023-07-10 04:19:13 --> Config Class Initialized
INFO - 2023-07-10 04:19:13 --> Loader Class Initialized
INFO - 2023-07-10 04:19:13 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:13 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:13 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:13 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:13 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:13 --> Controller Class Initialized
INFO - 2023-07-10 04:19:13 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:13 --> Total execution time: 0.0936
INFO - 2023-07-10 04:19:25 --> Config Class Initialized
INFO - 2023-07-10 04:19:25 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:25 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:25 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:25 --> URI Class Initialized
INFO - 2023-07-10 04:19:25 --> Router Class Initialized
INFO - 2023-07-10 04:19:25 --> Output Class Initialized
INFO - 2023-07-10 04:19:25 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:25 --> Input Class Initialized
INFO - 2023-07-10 04:19:25 --> Language Class Initialized
INFO - 2023-07-10 04:19:25 --> Language Class Initialized
INFO - 2023-07-10 04:19:25 --> Config Class Initialized
INFO - 2023-07-10 04:19:25 --> Loader Class Initialized
INFO - 2023-07-10 04:19:25 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:25 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:25 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:25 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:25 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:25 --> Controller Class Initialized
INFO - 2023-07-10 04:19:25 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:25 --> Total execution time: 0.0923
INFO - 2023-07-10 04:19:28 --> Config Class Initialized
INFO - 2023-07-10 04:19:28 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:28 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:28 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:28 --> URI Class Initialized
INFO - 2023-07-10 04:19:28 --> Router Class Initialized
INFO - 2023-07-10 04:19:28 --> Output Class Initialized
INFO - 2023-07-10 04:19:28 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:28 --> Input Class Initialized
INFO - 2023-07-10 04:19:28 --> Language Class Initialized
INFO - 2023-07-10 04:19:28 --> Language Class Initialized
INFO - 2023-07-10 04:19:28 --> Config Class Initialized
INFO - 2023-07-10 04:19:28 --> Loader Class Initialized
INFO - 2023-07-10 04:19:28 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:28 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:28 --> Controller Class Initialized
DEBUG - 2023-07-10 04:19:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-10 04:19:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:19:28 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:28 --> Total execution time: 0.0762
INFO - 2023-07-10 04:19:28 --> Config Class Initialized
INFO - 2023-07-10 04:19:28 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:28 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:28 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:28 --> URI Class Initialized
INFO - 2023-07-10 04:19:28 --> Router Class Initialized
INFO - 2023-07-10 04:19:28 --> Output Class Initialized
INFO - 2023-07-10 04:19:28 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:28 --> Input Class Initialized
INFO - 2023-07-10 04:19:28 --> Language Class Initialized
INFO - 2023-07-10 04:19:28 --> Language Class Initialized
INFO - 2023-07-10 04:19:28 --> Config Class Initialized
INFO - 2023-07-10 04:19:28 --> Loader Class Initialized
INFO - 2023-07-10 04:19:28 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:28 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:28 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:28 --> Controller Class Initialized
INFO - 2023-07-10 04:19:29 --> Config Class Initialized
INFO - 2023-07-10 04:19:29 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:29 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:29 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:29 --> URI Class Initialized
INFO - 2023-07-10 04:19:29 --> Router Class Initialized
INFO - 2023-07-10 04:19:29 --> Output Class Initialized
INFO - 2023-07-10 04:19:29 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:29 --> Input Class Initialized
INFO - 2023-07-10 04:19:29 --> Language Class Initialized
INFO - 2023-07-10 04:19:29 --> Language Class Initialized
INFO - 2023-07-10 04:19:29 --> Config Class Initialized
INFO - 2023-07-10 04:19:29 --> Loader Class Initialized
INFO - 2023-07-10 04:19:29 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:29 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:29 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:29 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:29 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:29 --> Controller Class Initialized
INFO - 2023-07-10 04:19:29 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:29 --> Total execution time: 0.0931
INFO - 2023-07-10 04:19:39 --> Config Class Initialized
INFO - 2023-07-10 04:19:39 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:39 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:39 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:39 --> URI Class Initialized
INFO - 2023-07-10 04:19:39 --> Router Class Initialized
INFO - 2023-07-10 04:19:39 --> Output Class Initialized
INFO - 2023-07-10 04:19:39 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:39 --> Input Class Initialized
INFO - 2023-07-10 04:19:39 --> Language Class Initialized
INFO - 2023-07-10 04:19:39 --> Language Class Initialized
INFO - 2023-07-10 04:19:39 --> Config Class Initialized
INFO - 2023-07-10 04:19:39 --> Loader Class Initialized
INFO - 2023-07-10 04:19:39 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:39 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:39 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:39 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:39 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:39 --> Controller Class Initialized
INFO - 2023-07-10 04:19:39 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:39 --> Total execution time: 0.0843
INFO - 2023-07-10 04:19:42 --> Config Class Initialized
INFO - 2023-07-10 04:19:42 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:19:42 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:19:42 --> Utf8 Class Initialized
INFO - 2023-07-10 04:19:42 --> URI Class Initialized
INFO - 2023-07-10 04:19:42 --> Router Class Initialized
INFO - 2023-07-10 04:19:42 --> Output Class Initialized
INFO - 2023-07-10 04:19:42 --> Security Class Initialized
DEBUG - 2023-07-10 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:19:42 --> Input Class Initialized
INFO - 2023-07-10 04:19:42 --> Language Class Initialized
INFO - 2023-07-10 04:19:42 --> Language Class Initialized
INFO - 2023-07-10 04:19:42 --> Config Class Initialized
INFO - 2023-07-10 04:19:42 --> Loader Class Initialized
INFO - 2023-07-10 04:19:42 --> Helper loaded: url_helper
INFO - 2023-07-10 04:19:42 --> Helper loaded: file_helper
INFO - 2023-07-10 04:19:42 --> Helper loaded: form_helper
INFO - 2023-07-10 04:19:42 --> Helper loaded: my_helper
INFO - 2023-07-10 04:19:42 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:19:42 --> Controller Class Initialized
INFO - 2023-07-10 04:19:42 --> Final output sent to browser
DEBUG - 2023-07-10 04:19:42 --> Total execution time: 0.1189
INFO - 2023-07-10 04:20:19 --> Config Class Initialized
INFO - 2023-07-10 04:20:19 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:20:19 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:20:19 --> Utf8 Class Initialized
INFO - 2023-07-10 04:20:19 --> URI Class Initialized
INFO - 2023-07-10 04:20:19 --> Router Class Initialized
INFO - 2023-07-10 04:20:19 --> Output Class Initialized
INFO - 2023-07-10 04:20:19 --> Security Class Initialized
DEBUG - 2023-07-10 04:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:20:19 --> Input Class Initialized
INFO - 2023-07-10 04:20:19 --> Language Class Initialized
INFO - 2023-07-10 04:20:19 --> Language Class Initialized
INFO - 2023-07-10 04:20:19 --> Config Class Initialized
INFO - 2023-07-10 04:20:19 --> Loader Class Initialized
INFO - 2023-07-10 04:20:19 --> Helper loaded: url_helper
INFO - 2023-07-10 04:20:19 --> Helper loaded: file_helper
INFO - 2023-07-10 04:20:19 --> Helper loaded: form_helper
INFO - 2023-07-10 04:20:19 --> Helper loaded: my_helper
INFO - 2023-07-10 04:20:19 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:20:19 --> Controller Class Initialized
INFO - 2023-07-10 04:29:30 --> Config Class Initialized
INFO - 2023-07-10 04:29:30 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:29:30 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:29:30 --> Utf8 Class Initialized
INFO - 2023-07-10 04:29:30 --> URI Class Initialized
INFO - 2023-07-10 04:29:30 --> Router Class Initialized
INFO - 2023-07-10 04:29:30 --> Output Class Initialized
INFO - 2023-07-10 04:29:30 --> Security Class Initialized
DEBUG - 2023-07-10 04:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:29:30 --> Input Class Initialized
INFO - 2023-07-10 04:29:30 --> Language Class Initialized
INFO - 2023-07-10 04:29:30 --> Language Class Initialized
INFO - 2023-07-10 04:29:30 --> Config Class Initialized
INFO - 2023-07-10 04:29:30 --> Loader Class Initialized
INFO - 2023-07-10 04:29:30 --> Helper loaded: url_helper
INFO - 2023-07-10 04:29:30 --> Helper loaded: file_helper
INFO - 2023-07-10 04:29:30 --> Helper loaded: form_helper
INFO - 2023-07-10 04:29:30 --> Helper loaded: my_helper
INFO - 2023-07-10 04:29:30 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:29:30 --> Controller Class Initialized
DEBUG - 2023-07-10 04:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-07-10 04:29:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:29:30 --> Final output sent to browser
DEBUG - 2023-07-10 04:29:30 --> Total execution time: 0.1523
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:29:37 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:29:37 --> Utf8 Class Initialized
INFO - 2023-07-10 04:29:37 --> URI Class Initialized
INFO - 2023-07-10 04:29:37 --> Router Class Initialized
INFO - 2023-07-10 04:29:37 --> Output Class Initialized
INFO - 2023-07-10 04:29:37 --> Security Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:29:37 --> Input Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Loader Class Initialized
INFO - 2023-07-10 04:29:37 --> Helper loaded: url_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: file_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: form_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: my_helper
INFO - 2023-07-10 04:29:37 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:29:37 --> Controller Class Initialized
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:29:37 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:29:37 --> Utf8 Class Initialized
INFO - 2023-07-10 04:29:37 --> URI Class Initialized
INFO - 2023-07-10 04:29:37 --> Router Class Initialized
INFO - 2023-07-10 04:29:37 --> Output Class Initialized
INFO - 2023-07-10 04:29:37 --> Security Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:29:37 --> Input Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Loader Class Initialized
INFO - 2023-07-10 04:29:37 --> Helper loaded: url_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: file_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: form_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: my_helper
INFO - 2023-07-10 04:29:37 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:29:37 --> Controller Class Initialized
DEBUG - 2023-07-10 04:29:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-10 04:29:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:29:37 --> Final output sent to browser
DEBUG - 2023-07-10 04:29:37 --> Total execution time: 0.1326
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:29:37 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:29:37 --> Utf8 Class Initialized
INFO - 2023-07-10 04:29:37 --> URI Class Initialized
INFO - 2023-07-10 04:29:37 --> Router Class Initialized
INFO - 2023-07-10 04:29:37 --> Output Class Initialized
INFO - 2023-07-10 04:29:37 --> Security Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:29:37 --> Input Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Language Class Initialized
INFO - 2023-07-10 04:29:37 --> Config Class Initialized
INFO - 2023-07-10 04:29:37 --> Loader Class Initialized
INFO - 2023-07-10 04:29:37 --> Helper loaded: url_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: file_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: form_helper
INFO - 2023-07-10 04:29:37 --> Helper loaded: my_helper
INFO - 2023-07-10 04:29:37 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:29:37 --> Controller Class Initialized
INFO - 2023-07-10 04:29:43 --> Config Class Initialized
INFO - 2023-07-10 04:29:43 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:29:43 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:29:43 --> Utf8 Class Initialized
INFO - 2023-07-10 04:29:43 --> URI Class Initialized
INFO - 2023-07-10 04:29:43 --> Router Class Initialized
INFO - 2023-07-10 04:29:43 --> Output Class Initialized
INFO - 2023-07-10 04:29:43 --> Security Class Initialized
DEBUG - 2023-07-10 04:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:29:43 --> Input Class Initialized
INFO - 2023-07-10 04:29:43 --> Language Class Initialized
INFO - 2023-07-10 04:29:43 --> Language Class Initialized
INFO - 2023-07-10 04:29:43 --> Config Class Initialized
INFO - 2023-07-10 04:29:43 --> Loader Class Initialized
INFO - 2023-07-10 04:29:43 --> Helper loaded: url_helper
INFO - 2023-07-10 04:29:43 --> Helper loaded: file_helper
INFO - 2023-07-10 04:29:43 --> Helper loaded: form_helper
INFO - 2023-07-10 04:29:43 --> Helper loaded: my_helper
INFO - 2023-07-10 04:29:43 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:29:43 --> Controller Class Initialized
INFO - 2023-07-10 04:29:43 --> Final output sent to browser
DEBUG - 2023-07-10 04:29:43 --> Total execution time: 0.0918
INFO - 2023-07-10 04:30:04 --> Config Class Initialized
INFO - 2023-07-10 04:30:04 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:30:04 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:30:04 --> Utf8 Class Initialized
INFO - 2023-07-10 04:30:04 --> URI Class Initialized
INFO - 2023-07-10 04:30:04 --> Router Class Initialized
INFO - 2023-07-10 04:30:04 --> Output Class Initialized
INFO - 2023-07-10 04:30:04 --> Security Class Initialized
DEBUG - 2023-07-10 04:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:30:04 --> Input Class Initialized
INFO - 2023-07-10 04:30:04 --> Language Class Initialized
INFO - 2023-07-10 04:30:04 --> Language Class Initialized
INFO - 2023-07-10 04:30:04 --> Config Class Initialized
INFO - 2023-07-10 04:30:04 --> Loader Class Initialized
INFO - 2023-07-10 04:30:04 --> Helper loaded: url_helper
INFO - 2023-07-10 04:30:04 --> Helper loaded: file_helper
INFO - 2023-07-10 04:30:04 --> Helper loaded: form_helper
INFO - 2023-07-10 04:30:04 --> Helper loaded: my_helper
INFO - 2023-07-10 04:30:04 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:30:04 --> Controller Class Initialized
INFO - 2023-07-10 04:30:04 --> Final output sent to browser
DEBUG - 2023-07-10 04:30:04 --> Total execution time: 0.1243
INFO - 2023-07-10 04:30:05 --> Config Class Initialized
INFO - 2023-07-10 04:30:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:30:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:30:05 --> Utf8 Class Initialized
INFO - 2023-07-10 04:30:05 --> URI Class Initialized
INFO - 2023-07-10 04:30:05 --> Router Class Initialized
INFO - 2023-07-10 04:30:05 --> Output Class Initialized
INFO - 2023-07-10 04:30:05 --> Security Class Initialized
DEBUG - 2023-07-10 04:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:30:05 --> Input Class Initialized
INFO - 2023-07-10 04:30:05 --> Language Class Initialized
INFO - 2023-07-10 04:30:05 --> Language Class Initialized
INFO - 2023-07-10 04:30:05 --> Config Class Initialized
INFO - 2023-07-10 04:30:05 --> Loader Class Initialized
INFO - 2023-07-10 04:30:05 --> Helper loaded: url_helper
INFO - 2023-07-10 04:30:05 --> Helper loaded: file_helper
INFO - 2023-07-10 04:30:05 --> Helper loaded: form_helper
INFO - 2023-07-10 04:30:05 --> Helper loaded: my_helper
INFO - 2023-07-10 04:30:05 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:30:05 --> Controller Class Initialized
INFO - 2023-07-10 04:30:05 --> Final output sent to browser
DEBUG - 2023-07-10 04:30:05 --> Total execution time: 0.0988
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:02 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:02 --> URI Class Initialized
INFO - 2023-07-10 04:31:02 --> Router Class Initialized
INFO - 2023-07-10 04:31:02 --> Output Class Initialized
INFO - 2023-07-10 04:31:02 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:02 --> Input Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Loader Class Initialized
INFO - 2023-07-10 04:31:02 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:02 --> Controller Class Initialized
INFO - 2023-07-10 04:31:02 --> Helper loaded: cookie_helper
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:02 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:02 --> URI Class Initialized
INFO - 2023-07-10 04:31:02 --> Router Class Initialized
INFO - 2023-07-10 04:31:02 --> Output Class Initialized
INFO - 2023-07-10 04:31:02 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:02 --> Input Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Loader Class Initialized
INFO - 2023-07-10 04:31:02 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:02 --> Controller Class Initialized
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:02 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:02 --> URI Class Initialized
INFO - 2023-07-10 04:31:02 --> Router Class Initialized
INFO - 2023-07-10 04:31:02 --> Output Class Initialized
INFO - 2023-07-10 04:31:02 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:02 --> Input Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Language Class Initialized
INFO - 2023-07-10 04:31:02 --> Config Class Initialized
INFO - 2023-07-10 04:31:02 --> Loader Class Initialized
INFO - 2023-07-10 04:31:02 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:02 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:02 --> Controller Class Initialized
DEBUG - 2023-07-10 04:31:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 04:31:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:31:02 --> Final output sent to browser
DEBUG - 2023-07-10 04:31:02 --> Total execution time: 0.0577
INFO - 2023-07-10 04:31:16 --> Config Class Initialized
INFO - 2023-07-10 04:31:16 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:16 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:16 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:16 --> URI Class Initialized
INFO - 2023-07-10 04:31:16 --> Router Class Initialized
INFO - 2023-07-10 04:31:16 --> Output Class Initialized
INFO - 2023-07-10 04:31:16 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:16 --> Input Class Initialized
INFO - 2023-07-10 04:31:16 --> Language Class Initialized
INFO - 2023-07-10 04:31:16 --> Language Class Initialized
INFO - 2023-07-10 04:31:16 --> Config Class Initialized
INFO - 2023-07-10 04:31:16 --> Loader Class Initialized
INFO - 2023-07-10 04:31:16 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:16 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:16 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:16 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:16 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:17 --> Controller Class Initialized
INFO - 2023-07-10 04:31:17 --> Helper loaded: cookie_helper
INFO - 2023-07-10 04:31:17 --> Final output sent to browser
DEBUG - 2023-07-10 04:31:17 --> Total execution time: 0.1000
INFO - 2023-07-10 04:31:17 --> Config Class Initialized
INFO - 2023-07-10 04:31:17 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:17 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:17 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:17 --> URI Class Initialized
INFO - 2023-07-10 04:31:17 --> Router Class Initialized
INFO - 2023-07-10 04:31:17 --> Output Class Initialized
INFO - 2023-07-10 04:31:17 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:17 --> Input Class Initialized
INFO - 2023-07-10 04:31:17 --> Language Class Initialized
INFO - 2023-07-10 04:31:17 --> Language Class Initialized
INFO - 2023-07-10 04:31:17 --> Config Class Initialized
INFO - 2023-07-10 04:31:17 --> Loader Class Initialized
INFO - 2023-07-10 04:31:17 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:17 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:17 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:17 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:17 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:17 --> Controller Class Initialized
DEBUG - 2023-07-10 04:31:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-10 04:31:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:31:17 --> Final output sent to browser
DEBUG - 2023-07-10 04:31:17 --> Total execution time: 0.0981
INFO - 2023-07-10 04:31:49 --> Config Class Initialized
INFO - 2023-07-10 04:31:49 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:31:49 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:31:49 --> Utf8 Class Initialized
INFO - 2023-07-10 04:31:49 --> URI Class Initialized
INFO - 2023-07-10 04:31:49 --> Router Class Initialized
INFO - 2023-07-10 04:31:49 --> Output Class Initialized
INFO - 2023-07-10 04:31:49 --> Security Class Initialized
DEBUG - 2023-07-10 04:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:31:49 --> Input Class Initialized
INFO - 2023-07-10 04:31:49 --> Language Class Initialized
INFO - 2023-07-10 04:31:49 --> Language Class Initialized
INFO - 2023-07-10 04:31:49 --> Config Class Initialized
INFO - 2023-07-10 04:31:49 --> Loader Class Initialized
INFO - 2023-07-10 04:31:49 --> Helper loaded: url_helper
INFO - 2023-07-10 04:31:49 --> Helper loaded: file_helper
INFO - 2023-07-10 04:31:49 --> Helper loaded: form_helper
INFO - 2023-07-10 04:31:49 --> Helper loaded: my_helper
INFO - 2023-07-10 04:31:49 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:31:49 --> Controller Class Initialized
DEBUG - 2023-07-10 04:31:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_absensi/views/list.php
DEBUG - 2023-07-10 04:31:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:31:49 --> Final output sent to browser
DEBUG - 2023-07-10 04:31:49 --> Total execution time: 0.1141
INFO - 2023-07-10 04:32:06 --> Config Class Initialized
INFO - 2023-07-10 04:32:06 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:32:06 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:32:06 --> Utf8 Class Initialized
INFO - 2023-07-10 04:32:06 --> URI Class Initialized
INFO - 2023-07-10 04:32:06 --> Router Class Initialized
INFO - 2023-07-10 04:32:06 --> Output Class Initialized
INFO - 2023-07-10 04:32:06 --> Security Class Initialized
DEBUG - 2023-07-10 04:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:32:06 --> Input Class Initialized
INFO - 2023-07-10 04:32:06 --> Language Class Initialized
INFO - 2023-07-10 04:32:06 --> Language Class Initialized
INFO - 2023-07-10 04:32:06 --> Config Class Initialized
INFO - 2023-07-10 04:32:06 --> Loader Class Initialized
INFO - 2023-07-10 04:32:06 --> Helper loaded: url_helper
INFO - 2023-07-10 04:32:06 --> Helper loaded: file_helper
INFO - 2023-07-10 04:32:06 --> Helper loaded: form_helper
INFO - 2023-07-10 04:32:06 --> Helper loaded: my_helper
INFO - 2023-07-10 04:32:06 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:32:06 --> Controller Class Initialized
INFO - 2023-07-10 04:32:06 --> Final output sent to browser
DEBUG - 2023-07-10 04:32:06 --> Total execution time: 0.0854
INFO - 2023-07-10 04:32:09 --> Config Class Initialized
INFO - 2023-07-10 04:32:09 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:32:09 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:32:09 --> Utf8 Class Initialized
INFO - 2023-07-10 04:32:09 --> URI Class Initialized
INFO - 2023-07-10 04:32:09 --> Router Class Initialized
INFO - 2023-07-10 04:32:09 --> Output Class Initialized
INFO - 2023-07-10 04:32:09 --> Security Class Initialized
DEBUG - 2023-07-10 04:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:32:09 --> Input Class Initialized
INFO - 2023-07-10 04:32:09 --> Language Class Initialized
INFO - 2023-07-10 04:32:09 --> Language Class Initialized
INFO - 2023-07-10 04:32:09 --> Config Class Initialized
INFO - 2023-07-10 04:32:09 --> Loader Class Initialized
INFO - 2023-07-10 04:32:09 --> Helper loaded: url_helper
INFO - 2023-07-10 04:32:09 --> Helper loaded: file_helper
INFO - 2023-07-10 04:32:09 --> Helper loaded: form_helper
INFO - 2023-07-10 04:32:09 --> Helper loaded: my_helper
INFO - 2023-07-10 04:32:09 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:32:09 --> Controller Class Initialized
DEBUG - 2023-07-10 04:32:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-10 04:32:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:32:09 --> Final output sent to browser
DEBUG - 2023-07-10 04:32:09 --> Total execution time: 0.1016
INFO - 2023-07-10 04:33:03 --> Config Class Initialized
INFO - 2023-07-10 04:33:03 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:33:03 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:33:03 --> Utf8 Class Initialized
INFO - 2023-07-10 04:33:03 --> URI Class Initialized
INFO - 2023-07-10 04:33:03 --> Router Class Initialized
INFO - 2023-07-10 04:33:03 --> Output Class Initialized
INFO - 2023-07-10 04:33:03 --> Security Class Initialized
DEBUG - 2023-07-10 04:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:33:03 --> Input Class Initialized
INFO - 2023-07-10 04:33:03 --> Language Class Initialized
INFO - 2023-07-10 04:33:03 --> Language Class Initialized
INFO - 2023-07-10 04:33:03 --> Config Class Initialized
INFO - 2023-07-10 04:33:03 --> Loader Class Initialized
INFO - 2023-07-10 04:33:03 --> Helper loaded: url_helper
INFO - 2023-07-10 04:33:03 --> Helper loaded: file_helper
INFO - 2023-07-10 04:33:03 --> Helper loaded: form_helper
INFO - 2023-07-10 04:33:03 --> Helper loaded: my_helper
INFO - 2023-07-10 04:33:03 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:33:03 --> Controller Class Initialized
INFO - 2023-07-10 04:33:03 --> Final output sent to browser
DEBUG - 2023-07-10 04:33:03 --> Total execution time: 0.0749
INFO - 2023-07-10 04:33:47 --> Config Class Initialized
INFO - 2023-07-10 04:33:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:33:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:33:47 --> Utf8 Class Initialized
INFO - 2023-07-10 04:33:47 --> URI Class Initialized
INFO - 2023-07-10 04:33:47 --> Router Class Initialized
INFO - 2023-07-10 04:33:47 --> Output Class Initialized
INFO - 2023-07-10 04:33:47 --> Security Class Initialized
DEBUG - 2023-07-10 04:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:33:47 --> Input Class Initialized
INFO - 2023-07-10 04:33:47 --> Language Class Initialized
INFO - 2023-07-10 04:33:47 --> Language Class Initialized
INFO - 2023-07-10 04:33:47 --> Config Class Initialized
INFO - 2023-07-10 04:33:47 --> Loader Class Initialized
INFO - 2023-07-10 04:33:47 --> Helper loaded: url_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: file_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: form_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: my_helper
INFO - 2023-07-10 04:33:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:33:47 --> Controller Class Initialized
DEBUG - 2023-07-10 04:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_prestasi/views/list.php
DEBUG - 2023-07-10 04:33:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:33:47 --> Final output sent to browser
DEBUG - 2023-07-10 04:33:47 --> Total execution time: 0.0855
INFO - 2023-07-10 04:33:47 --> Config Class Initialized
INFO - 2023-07-10 04:33:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:33:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:33:47 --> Utf8 Class Initialized
INFO - 2023-07-10 04:33:47 --> URI Class Initialized
INFO - 2023-07-10 04:33:47 --> Router Class Initialized
INFO - 2023-07-10 04:33:47 --> Output Class Initialized
INFO - 2023-07-10 04:33:47 --> Security Class Initialized
DEBUG - 2023-07-10 04:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:33:47 --> Input Class Initialized
INFO - 2023-07-10 04:33:47 --> Language Class Initialized
INFO - 2023-07-10 04:33:47 --> Language Class Initialized
INFO - 2023-07-10 04:33:47 --> Config Class Initialized
INFO - 2023-07-10 04:33:47 --> Loader Class Initialized
INFO - 2023-07-10 04:33:47 --> Helper loaded: url_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: file_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: form_helper
INFO - 2023-07-10 04:33:47 --> Helper loaded: my_helper
INFO - 2023-07-10 04:33:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:33:47 --> Controller Class Initialized
INFO - 2023-07-10 04:35:03 --> Config Class Initialized
INFO - 2023-07-10 04:35:03 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:35:03 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:35:03 --> Utf8 Class Initialized
INFO - 2023-07-10 04:35:03 --> URI Class Initialized
INFO - 2023-07-10 04:35:03 --> Router Class Initialized
INFO - 2023-07-10 04:35:03 --> Output Class Initialized
INFO - 2023-07-10 04:35:03 --> Security Class Initialized
DEBUG - 2023-07-10 04:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:35:03 --> Input Class Initialized
INFO - 2023-07-10 04:35:03 --> Language Class Initialized
INFO - 2023-07-10 04:35:03 --> Language Class Initialized
INFO - 2023-07-10 04:35:03 --> Config Class Initialized
INFO - 2023-07-10 04:35:03 --> Loader Class Initialized
INFO - 2023-07-10 04:35:03 --> Helper loaded: url_helper
INFO - 2023-07-10 04:35:03 --> Helper loaded: file_helper
INFO - 2023-07-10 04:35:03 --> Helper loaded: form_helper
INFO - 2023-07-10 04:35:03 --> Helper loaded: my_helper
INFO - 2023-07-10 04:35:03 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:35:03 --> Controller Class Initialized
DEBUG - 2023-07-10 04:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-07-10 04:35:03 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:35:03 --> Final output sent to browser
DEBUG - 2023-07-10 04:35:03 --> Total execution time: 0.1392
INFO - 2023-07-10 04:35:29 --> Config Class Initialized
INFO - 2023-07-10 04:35:29 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:35:29 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:35:29 --> Utf8 Class Initialized
INFO - 2023-07-10 04:35:29 --> URI Class Initialized
INFO - 2023-07-10 04:35:29 --> Router Class Initialized
INFO - 2023-07-10 04:35:29 --> Output Class Initialized
INFO - 2023-07-10 04:35:29 --> Security Class Initialized
DEBUG - 2023-07-10 04:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:35:29 --> Input Class Initialized
INFO - 2023-07-10 04:35:29 --> Language Class Initialized
INFO - 2023-07-10 04:35:29 --> Language Class Initialized
INFO - 2023-07-10 04:35:29 --> Config Class Initialized
INFO - 2023-07-10 04:35:29 --> Loader Class Initialized
INFO - 2023-07-10 04:35:29 --> Helper loaded: url_helper
INFO - 2023-07-10 04:35:29 --> Helper loaded: file_helper
INFO - 2023-07-10 04:35:29 --> Helper loaded: form_helper
INFO - 2023-07-10 04:35:29 --> Helper loaded: my_helper
INFO - 2023-07-10 04:35:29 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:35:29 --> Controller Class Initialized
DEBUG - 2023-07-10 04:35:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-10 04:35:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:35:29 --> Final output sent to browser
DEBUG - 2023-07-10 04:35:29 --> Total execution time: 0.1042
INFO - 2023-07-10 04:35:47 --> Config Class Initialized
INFO - 2023-07-10 04:35:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:35:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:35:47 --> Utf8 Class Initialized
INFO - 2023-07-10 04:35:47 --> URI Class Initialized
INFO - 2023-07-10 04:35:47 --> Router Class Initialized
INFO - 2023-07-10 04:35:47 --> Output Class Initialized
INFO - 2023-07-10 04:35:47 --> Security Class Initialized
DEBUG - 2023-07-10 04:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:35:47 --> Input Class Initialized
INFO - 2023-07-10 04:35:47 --> Language Class Initialized
INFO - 2023-07-10 04:35:47 --> Language Class Initialized
INFO - 2023-07-10 04:35:47 --> Config Class Initialized
INFO - 2023-07-10 04:35:47 --> Loader Class Initialized
INFO - 2023-07-10 04:35:47 --> Helper loaded: url_helper
INFO - 2023-07-10 04:35:47 --> Helper loaded: file_helper
INFO - 2023-07-10 04:35:47 --> Helper loaded: form_helper
INFO - 2023-07-10 04:35:47 --> Helper loaded: my_helper
INFO - 2023-07-10 04:35:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:35:47 --> Controller Class Initialized
DEBUG - 2023-07-10 04:35:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-07-10 04:35:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:35:47 --> Final output sent to browser
DEBUG - 2023-07-10 04:35:47 --> Total execution time: 0.0976
INFO - 2023-07-10 04:37:10 --> Config Class Initialized
INFO - 2023-07-10 04:37:10 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:37:10 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:37:10 --> Utf8 Class Initialized
INFO - 2023-07-10 04:37:10 --> URI Class Initialized
INFO - 2023-07-10 04:37:10 --> Router Class Initialized
INFO - 2023-07-10 04:37:10 --> Output Class Initialized
INFO - 2023-07-10 04:37:10 --> Security Class Initialized
DEBUG - 2023-07-10 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:37:10 --> Input Class Initialized
INFO - 2023-07-10 04:37:10 --> Language Class Initialized
INFO - 2023-07-10 04:37:10 --> Language Class Initialized
INFO - 2023-07-10 04:37:10 --> Config Class Initialized
INFO - 2023-07-10 04:37:10 --> Loader Class Initialized
INFO - 2023-07-10 04:37:10 --> Helper loaded: url_helper
INFO - 2023-07-10 04:37:10 --> Helper loaded: file_helper
INFO - 2023-07-10 04:37:10 --> Helper loaded: form_helper
INFO - 2023-07-10 04:37:10 --> Helper loaded: my_helper
INFO - 2023-07-10 04:37:10 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:37:10 --> Controller Class Initialized
DEBUG - 2023-07-10 04:37:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-07-10 04:37:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:37:10 --> Final output sent to browser
DEBUG - 2023-07-10 04:37:10 --> Total execution time: 0.1097
INFO - 2023-07-10 04:37:16 --> Config Class Initialized
INFO - 2023-07-10 04:37:16 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:37:16 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:37:16 --> Utf8 Class Initialized
INFO - 2023-07-10 04:37:16 --> URI Class Initialized
INFO - 2023-07-10 04:37:16 --> Router Class Initialized
INFO - 2023-07-10 04:37:16 --> Output Class Initialized
INFO - 2023-07-10 04:37:16 --> Security Class Initialized
DEBUG - 2023-07-10 04:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:37:16 --> Input Class Initialized
INFO - 2023-07-10 04:37:16 --> Language Class Initialized
INFO - 2023-07-10 04:37:16 --> Language Class Initialized
INFO - 2023-07-10 04:37:16 --> Config Class Initialized
INFO - 2023-07-10 04:37:16 --> Loader Class Initialized
INFO - 2023-07-10 04:37:16 --> Helper loaded: url_helper
INFO - 2023-07-10 04:37:16 --> Helper loaded: file_helper
INFO - 2023-07-10 04:37:16 --> Helper loaded: form_helper
INFO - 2023-07-10 04:37:16 --> Helper loaded: my_helper
INFO - 2023-07-10 04:37:16 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:37:16 --> Controller Class Initialized
DEBUG - 2023-07-10 04:37:16 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-10 04:37:18 --> Final output sent to browser
DEBUG - 2023-07-10 04:37:18 --> Total execution time: 2.5847
INFO - 2023-07-10 04:38:52 --> Config Class Initialized
INFO - 2023-07-10 04:38:52 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:38:52 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:38:52 --> Utf8 Class Initialized
INFO - 2023-07-10 04:38:52 --> URI Class Initialized
INFO - 2023-07-10 04:38:52 --> Router Class Initialized
INFO - 2023-07-10 04:38:52 --> Output Class Initialized
INFO - 2023-07-10 04:38:52 --> Security Class Initialized
DEBUG - 2023-07-10 04:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:38:52 --> Input Class Initialized
INFO - 2023-07-10 04:38:52 --> Language Class Initialized
INFO - 2023-07-10 04:38:52 --> Language Class Initialized
INFO - 2023-07-10 04:38:52 --> Config Class Initialized
INFO - 2023-07-10 04:38:52 --> Loader Class Initialized
INFO - 2023-07-10 04:38:52 --> Helper loaded: url_helper
INFO - 2023-07-10 04:38:52 --> Helper loaded: file_helper
INFO - 2023-07-10 04:38:52 --> Helper loaded: form_helper
INFO - 2023-07-10 04:38:52 --> Helper loaded: my_helper
INFO - 2023-07-10 04:38:52 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:38:52 --> Controller Class Initialized
DEBUG - 2023-07-10 04:38:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-10 04:38:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:38:52 --> Final output sent to browser
DEBUG - 2023-07-10 04:38:52 --> Total execution time: 0.1031
INFO - 2023-07-10 04:39:05 --> Config Class Initialized
INFO - 2023-07-10 04:39:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:39:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:39:05 --> Utf8 Class Initialized
INFO - 2023-07-10 04:39:05 --> URI Class Initialized
INFO - 2023-07-10 04:39:05 --> Router Class Initialized
INFO - 2023-07-10 04:39:05 --> Output Class Initialized
INFO - 2023-07-10 04:39:05 --> Security Class Initialized
DEBUG - 2023-07-10 04:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:39:05 --> Input Class Initialized
INFO - 2023-07-10 04:39:05 --> Language Class Initialized
INFO - 2023-07-10 04:39:05 --> Language Class Initialized
INFO - 2023-07-10 04:39:05 --> Config Class Initialized
INFO - 2023-07-10 04:39:05 --> Loader Class Initialized
INFO - 2023-07-10 04:39:05 --> Helper loaded: url_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: file_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: form_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: my_helper
INFO - 2023-07-10 04:39:05 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:39:05 --> Controller Class Initialized
DEBUG - 2023-07-10 04:39:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_icb/views/list.php
DEBUG - 2023-07-10 04:39:05 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:39:05 --> Final output sent to browser
DEBUG - 2023-07-10 04:39:05 --> Total execution time: 0.0755
INFO - 2023-07-10 04:39:05 --> Config Class Initialized
INFO - 2023-07-10 04:39:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:39:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:39:05 --> Utf8 Class Initialized
INFO - 2023-07-10 04:39:05 --> URI Class Initialized
INFO - 2023-07-10 04:39:05 --> Router Class Initialized
INFO - 2023-07-10 04:39:05 --> Output Class Initialized
INFO - 2023-07-10 04:39:05 --> Security Class Initialized
DEBUG - 2023-07-10 04:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:39:05 --> Input Class Initialized
INFO - 2023-07-10 04:39:05 --> Language Class Initialized
INFO - 2023-07-10 04:39:05 --> Language Class Initialized
INFO - 2023-07-10 04:39:05 --> Config Class Initialized
INFO - 2023-07-10 04:39:05 --> Loader Class Initialized
INFO - 2023-07-10 04:39:05 --> Helper loaded: url_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: file_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: form_helper
INFO - 2023-07-10 04:39:05 --> Helper loaded: my_helper
INFO - 2023-07-10 04:39:05 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:39:05 --> Controller Class Initialized
INFO - 2023-07-10 04:39:23 --> Config Class Initialized
INFO - 2023-07-10 04:39:23 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:39:23 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:39:23 --> Utf8 Class Initialized
INFO - 2023-07-10 04:39:23 --> URI Class Initialized
INFO - 2023-07-10 04:39:23 --> Router Class Initialized
INFO - 2023-07-10 04:39:23 --> Output Class Initialized
INFO - 2023-07-10 04:39:23 --> Security Class Initialized
DEBUG - 2023-07-10 04:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:39:23 --> Input Class Initialized
INFO - 2023-07-10 04:39:23 --> Language Class Initialized
INFO - 2023-07-10 04:39:23 --> Language Class Initialized
INFO - 2023-07-10 04:39:23 --> Config Class Initialized
INFO - 2023-07-10 04:39:23 --> Loader Class Initialized
INFO - 2023-07-10 04:39:23 --> Helper loaded: url_helper
INFO - 2023-07-10 04:39:23 --> Helper loaded: file_helper
INFO - 2023-07-10 04:39:23 --> Helper loaded: form_helper
INFO - 2023-07-10 04:39:23 --> Helper loaded: my_helper
INFO - 2023-07-10 04:39:23 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:39:23 --> Controller Class Initialized
INFO - 2023-07-10 04:39:23 --> Final output sent to browser
DEBUG - 2023-07-10 04:39:23 --> Total execution time: 0.0792
INFO - 2023-07-10 04:39:31 --> Config Class Initialized
INFO - 2023-07-10 04:39:31 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:39:31 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:39:31 --> Utf8 Class Initialized
INFO - 2023-07-10 04:39:31 --> URI Class Initialized
INFO - 2023-07-10 04:39:31 --> Router Class Initialized
INFO - 2023-07-10 04:39:31 --> Output Class Initialized
INFO - 2023-07-10 04:39:31 --> Security Class Initialized
DEBUG - 2023-07-10 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:39:31 --> Input Class Initialized
INFO - 2023-07-10 04:39:31 --> Language Class Initialized
INFO - 2023-07-10 04:39:31 --> Language Class Initialized
INFO - 2023-07-10 04:39:31 --> Config Class Initialized
INFO - 2023-07-10 04:39:31 --> Loader Class Initialized
INFO - 2023-07-10 04:39:31 --> Helper loaded: url_helper
INFO - 2023-07-10 04:39:31 --> Helper loaded: file_helper
INFO - 2023-07-10 04:39:31 --> Helper loaded: form_helper
INFO - 2023-07-10 04:39:31 --> Helper loaded: my_helper
INFO - 2023-07-10 04:39:31 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:39:31 --> Controller Class Initialized
INFO - 2023-07-10 04:39:31 --> Final output sent to browser
DEBUG - 2023-07-10 04:39:31 --> Total execution time: 0.0842
INFO - 2023-07-10 04:40:45 --> Config Class Initialized
INFO - 2023-07-10 04:40:45 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:40:45 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:40:45 --> Utf8 Class Initialized
INFO - 2023-07-10 04:40:45 --> URI Class Initialized
INFO - 2023-07-10 04:40:45 --> Router Class Initialized
INFO - 2023-07-10 04:40:45 --> Output Class Initialized
INFO - 2023-07-10 04:40:45 --> Security Class Initialized
DEBUG - 2023-07-10 04:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:40:45 --> Input Class Initialized
INFO - 2023-07-10 04:40:45 --> Language Class Initialized
INFO - 2023-07-10 04:40:45 --> Language Class Initialized
INFO - 2023-07-10 04:40:45 --> Config Class Initialized
INFO - 2023-07-10 04:40:45 --> Loader Class Initialized
INFO - 2023-07-10 04:40:45 --> Helper loaded: url_helper
INFO - 2023-07-10 04:40:45 --> Helper loaded: file_helper
INFO - 2023-07-10 04:40:45 --> Helper loaded: form_helper
INFO - 2023-07-10 04:40:45 --> Helper loaded: my_helper
INFO - 2023-07-10 04:40:45 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:40:45 --> Controller Class Initialized
DEBUG - 2023-07-10 04:40:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-07-10 04:40:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:40:45 --> Final output sent to browser
DEBUG - 2023-07-10 04:40:45 --> Total execution time: 0.1501
INFO - 2023-07-10 04:40:55 --> Config Class Initialized
INFO - 2023-07-10 04:40:55 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:40:55 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:40:55 --> Utf8 Class Initialized
INFO - 2023-07-10 04:40:55 --> URI Class Initialized
INFO - 2023-07-10 04:40:55 --> Router Class Initialized
INFO - 2023-07-10 04:40:55 --> Output Class Initialized
INFO - 2023-07-10 04:40:55 --> Security Class Initialized
DEBUG - 2023-07-10 04:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:40:55 --> Input Class Initialized
INFO - 2023-07-10 04:40:55 --> Language Class Initialized
INFO - 2023-07-10 04:40:55 --> Language Class Initialized
INFO - 2023-07-10 04:40:55 --> Config Class Initialized
INFO - 2023-07-10 04:40:55 --> Loader Class Initialized
INFO - 2023-07-10 04:40:55 --> Helper loaded: url_helper
INFO - 2023-07-10 04:40:55 --> Helper loaded: file_helper
INFO - 2023-07-10 04:40:55 --> Helper loaded: form_helper
INFO - 2023-07-10 04:40:55 --> Helper loaded: my_helper
INFO - 2023-07-10 04:40:55 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:40:55 --> Controller Class Initialized
ERROR - 2023-07-10 04:40:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_homeroom SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ? until ?) jim), ?) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-07-10 04:40:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-07-10 04:41:02 --> Config Class Initialized
INFO - 2023-07-10 04:41:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:02 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:02 --> URI Class Initialized
INFO - 2023-07-10 04:41:02 --> Router Class Initialized
INFO - 2023-07-10 04:41:02 --> Output Class Initialized
INFO - 2023-07-10 04:41:02 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:02 --> Input Class Initialized
INFO - 2023-07-10 04:41:02 --> Language Class Initialized
INFO - 2023-07-10 04:41:02 --> Language Class Initialized
INFO - 2023-07-10 04:41:02 --> Config Class Initialized
INFO - 2023-07-10 04:41:02 --> Loader Class Initialized
INFO - 2023-07-10 04:41:02 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:02 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:02 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:02 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:02 --> Controller Class Initialized
DEBUG - 2023-07-10 04:41:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-10 04:41:04 --> Final output sent to browser
DEBUG - 2023-07-10 04:41:04 --> Total execution time: 1.8769
INFO - 2023-07-10 04:41:14 --> Config Class Initialized
INFO - 2023-07-10 04:41:14 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:14 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:14 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:14 --> URI Class Initialized
INFO - 2023-07-10 04:41:14 --> Router Class Initialized
INFO - 2023-07-10 04:41:14 --> Output Class Initialized
INFO - 2023-07-10 04:41:14 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:14 --> Input Class Initialized
INFO - 2023-07-10 04:41:14 --> Language Class Initialized
INFO - 2023-07-10 04:41:14 --> Language Class Initialized
INFO - 2023-07-10 04:41:14 --> Config Class Initialized
INFO - 2023-07-10 04:41:14 --> Loader Class Initialized
INFO - 2023-07-10 04:41:14 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:14 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:14 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:14 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:14 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:14 --> Controller Class Initialized
DEBUG - 2023-07-10 04:41:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-07-10 04:41:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:41:14 --> Final output sent to browser
DEBUG - 2023-07-10 04:41:14 --> Total execution time: 0.0677
INFO - 2023-07-10 04:41:24 --> Config Class Initialized
INFO - 2023-07-10 04:41:24 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:24 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:24 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:24 --> URI Class Initialized
INFO - 2023-07-10 04:41:24 --> Router Class Initialized
INFO - 2023-07-10 04:41:24 --> Output Class Initialized
INFO - 2023-07-10 04:41:24 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:24 --> Input Class Initialized
INFO - 2023-07-10 04:41:24 --> Language Class Initialized
ERROR - 2023-07-10 04:41:24 --> 404 Page Not Found: /index
INFO - 2023-07-10 04:41:27 --> Config Class Initialized
INFO - 2023-07-10 04:41:27 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:27 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:27 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:27 --> URI Class Initialized
INFO - 2023-07-10 04:41:27 --> Router Class Initialized
INFO - 2023-07-10 04:41:27 --> Output Class Initialized
INFO - 2023-07-10 04:41:27 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:27 --> Input Class Initialized
INFO - 2023-07-10 04:41:27 --> Language Class Initialized
INFO - 2023-07-10 04:41:27 --> Language Class Initialized
INFO - 2023-07-10 04:41:27 --> Config Class Initialized
INFO - 2023-07-10 04:41:27 --> Loader Class Initialized
INFO - 2023-07-10 04:41:27 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:27 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:27 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:27 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:27 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:27 --> Controller Class Initialized
ERROR - 2023-07-10 04:41:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_homeroom SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ? until ?) jim), ?) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-07-10 04:41:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-07-10 04:41:44 --> Config Class Initialized
INFO - 2023-07-10 04:41:44 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:44 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:44 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:44 --> URI Class Initialized
INFO - 2023-07-10 04:41:44 --> Router Class Initialized
INFO - 2023-07-10 04:41:44 --> Output Class Initialized
INFO - 2023-07-10 04:41:44 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:44 --> Input Class Initialized
INFO - 2023-07-10 04:41:44 --> Language Class Initialized
INFO - 2023-07-10 04:41:44 --> Language Class Initialized
INFO - 2023-07-10 04:41:44 --> Config Class Initialized
INFO - 2023-07-10 04:41:44 --> Loader Class Initialized
INFO - 2023-07-10 04:41:44 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:44 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:44 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:44 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:44 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:44 --> Controller Class Initialized
DEBUG - 2023-07-10 04:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-07-10 04:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:41:44 --> Final output sent to browser
DEBUG - 2023-07-10 04:41:44 --> Total execution time: 0.0874
INFO - 2023-07-10 04:41:44 --> Config Class Initialized
INFO - 2023-07-10 04:41:44 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:44 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:44 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:44 --> URI Class Initialized
INFO - 2023-07-10 04:41:44 --> Router Class Initialized
INFO - 2023-07-10 04:41:44 --> Output Class Initialized
INFO - 2023-07-10 04:41:44 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:44 --> Input Class Initialized
INFO - 2023-07-10 04:41:44 --> Language Class Initialized
ERROR - 2023-07-10 04:41:44 --> 404 Page Not Found: /index
INFO - 2023-07-10 04:41:51 --> Config Class Initialized
INFO - 2023-07-10 04:41:51 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:51 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:51 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:51 --> URI Class Initialized
INFO - 2023-07-10 04:41:51 --> Router Class Initialized
INFO - 2023-07-10 04:41:51 --> Output Class Initialized
INFO - 2023-07-10 04:41:51 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:51 --> Input Class Initialized
INFO - 2023-07-10 04:41:51 --> Language Class Initialized
INFO - 2023-07-10 04:41:51 --> Language Class Initialized
INFO - 2023-07-10 04:41:51 --> Config Class Initialized
INFO - 2023-07-10 04:41:51 --> Loader Class Initialized
INFO - 2023-07-10 04:41:51 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:51 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:51 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:51 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:51 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:51 --> Controller Class Initialized
INFO - 2023-07-10 04:41:51 --> Final output sent to browser
DEBUG - 2023-07-10 04:41:51 --> Total execution time: 0.0666
INFO - 2023-07-10 04:41:56 --> Config Class Initialized
INFO - 2023-07-10 04:41:56 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:41:56 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:41:56 --> Utf8 Class Initialized
INFO - 2023-07-10 04:41:56 --> URI Class Initialized
INFO - 2023-07-10 04:41:56 --> Router Class Initialized
INFO - 2023-07-10 04:41:56 --> Output Class Initialized
INFO - 2023-07-10 04:41:56 --> Security Class Initialized
DEBUG - 2023-07-10 04:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:41:56 --> Input Class Initialized
INFO - 2023-07-10 04:41:56 --> Language Class Initialized
INFO - 2023-07-10 04:41:56 --> Language Class Initialized
INFO - 2023-07-10 04:41:56 --> Config Class Initialized
INFO - 2023-07-10 04:41:56 --> Loader Class Initialized
INFO - 2023-07-10 04:41:56 --> Helper loaded: url_helper
INFO - 2023-07-10 04:41:56 --> Helper loaded: file_helper
INFO - 2023-07-10 04:41:56 --> Helper loaded: form_helper
INFO - 2023-07-10 04:41:56 --> Helper loaded: my_helper
INFO - 2023-07-10 04:41:56 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:41:56 --> Controller Class Initialized
DEBUG - 2023-07-10 04:41:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-10 04:41:58 --> Final output sent to browser
DEBUG - 2023-07-10 04:41:58 --> Total execution time: 2.1124
INFO - 2023-07-10 04:42:18 --> Config Class Initialized
INFO - 2023-07-10 04:42:18 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:42:18 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:42:18 --> Utf8 Class Initialized
INFO - 2023-07-10 04:42:18 --> URI Class Initialized
INFO - 2023-07-10 04:42:18 --> Router Class Initialized
INFO - 2023-07-10 04:42:18 --> Output Class Initialized
INFO - 2023-07-10 04:42:18 --> Security Class Initialized
DEBUG - 2023-07-10 04:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:42:18 --> Input Class Initialized
INFO - 2023-07-10 04:42:18 --> Language Class Initialized
INFO - 2023-07-10 04:42:18 --> Language Class Initialized
INFO - 2023-07-10 04:42:18 --> Config Class Initialized
INFO - 2023-07-10 04:42:18 --> Loader Class Initialized
INFO - 2023-07-10 04:42:18 --> Helper loaded: url_helper
INFO - 2023-07-10 04:42:18 --> Helper loaded: file_helper
INFO - 2023-07-10 04:42:18 --> Helper loaded: form_helper
INFO - 2023-07-10 04:42:18 --> Helper loaded: my_helper
INFO - 2023-07-10 04:42:18 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:42:18 --> Controller Class Initialized
DEBUG - 2023-07-10 04:42:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-10 04:42:18 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:42:18 --> Final output sent to browser
DEBUG - 2023-07-10 04:42:18 --> Total execution time: 0.1332
INFO - 2023-07-10 04:42:41 --> Config Class Initialized
INFO - 2023-07-10 04:42:41 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:42:41 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:42:41 --> Utf8 Class Initialized
INFO - 2023-07-10 04:42:41 --> URI Class Initialized
INFO - 2023-07-10 04:42:41 --> Router Class Initialized
INFO - 2023-07-10 04:42:41 --> Output Class Initialized
INFO - 2023-07-10 04:42:41 --> Security Class Initialized
DEBUG - 2023-07-10 04:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:42:41 --> Input Class Initialized
INFO - 2023-07-10 04:42:41 --> Language Class Initialized
INFO - 2023-07-10 04:42:41 --> Language Class Initialized
INFO - 2023-07-10 04:42:41 --> Config Class Initialized
INFO - 2023-07-10 04:42:41 --> Loader Class Initialized
INFO - 2023-07-10 04:42:41 --> Helper loaded: url_helper
INFO - 2023-07-10 04:42:41 --> Helper loaded: file_helper
INFO - 2023-07-10 04:42:41 --> Helper loaded: form_helper
INFO - 2023-07-10 04:42:41 --> Helper loaded: my_helper
INFO - 2023-07-10 04:42:41 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:42:41 --> Controller Class Initialized
DEBUG - 2023-07-10 04:42:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-10 04:42:43 --> Final output sent to browser
DEBUG - 2023-07-10 04:42:43 --> Total execution time: 1.6996
INFO - 2023-07-10 04:43:11 --> Config Class Initialized
INFO - 2023-07-10 04:43:11 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:43:11 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:43:11 --> Utf8 Class Initialized
INFO - 2023-07-10 04:43:11 --> URI Class Initialized
INFO - 2023-07-10 04:43:11 --> Router Class Initialized
INFO - 2023-07-10 04:43:11 --> Output Class Initialized
INFO - 2023-07-10 04:43:11 --> Security Class Initialized
DEBUG - 2023-07-10 04:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:43:11 --> Input Class Initialized
INFO - 2023-07-10 04:43:11 --> Language Class Initialized
INFO - 2023-07-10 04:43:11 --> Language Class Initialized
INFO - 2023-07-10 04:43:11 --> Config Class Initialized
INFO - 2023-07-10 04:43:11 --> Loader Class Initialized
INFO - 2023-07-10 04:43:11 --> Helper loaded: url_helper
INFO - 2023-07-10 04:43:11 --> Helper loaded: file_helper
INFO - 2023-07-10 04:43:11 --> Helper loaded: form_helper
INFO - 2023-07-10 04:43:11 --> Helper loaded: my_helper
INFO - 2023-07-10 04:43:11 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:43:11 --> Controller Class Initialized
DEBUG - 2023-07-10 04:43:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-07-10 04:43:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:43:11 --> Final output sent to browser
DEBUG - 2023-07-10 04:43:11 --> Total execution time: 0.0867
INFO - 2023-07-10 04:44:53 --> Config Class Initialized
INFO - 2023-07-10 04:44:53 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:44:53 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:44:53 --> Utf8 Class Initialized
INFO - 2023-07-10 04:44:53 --> URI Class Initialized
INFO - 2023-07-10 04:44:53 --> Router Class Initialized
INFO - 2023-07-10 04:44:53 --> Output Class Initialized
INFO - 2023-07-10 04:44:53 --> Security Class Initialized
DEBUG - 2023-07-10 04:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:44:53 --> Input Class Initialized
INFO - 2023-07-10 04:44:53 --> Language Class Initialized
INFO - 2023-07-10 04:44:53 --> Language Class Initialized
INFO - 2023-07-10 04:44:53 --> Config Class Initialized
INFO - 2023-07-10 04:44:53 --> Loader Class Initialized
INFO - 2023-07-10 04:44:53 --> Helper loaded: url_helper
INFO - 2023-07-10 04:44:53 --> Helper loaded: file_helper
INFO - 2023-07-10 04:44:53 --> Helper loaded: form_helper
INFO - 2023-07-10 04:44:53 --> Helper loaded: my_helper
INFO - 2023-07-10 04:44:53 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:44:53 --> Controller Class Initialized
DEBUG - 2023-07-10 04:44:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-10 04:44:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 04:44:53 --> Final output sent to browser
DEBUG - 2023-07-10 04:44:53 --> Total execution time: 0.1101
INFO - 2023-07-10 04:45:05 --> Config Class Initialized
INFO - 2023-07-10 04:45:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:45:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:45:05 --> Utf8 Class Initialized
INFO - 2023-07-10 04:45:05 --> URI Class Initialized
INFO - 2023-07-10 04:45:05 --> Router Class Initialized
INFO - 2023-07-10 04:45:05 --> Output Class Initialized
INFO - 2023-07-10 04:45:05 --> Security Class Initialized
DEBUG - 2023-07-10 04:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:45:05 --> Input Class Initialized
INFO - 2023-07-10 04:45:05 --> Language Class Initialized
INFO - 2023-07-10 04:45:05 --> Language Class Initialized
INFO - 2023-07-10 04:45:05 --> Config Class Initialized
INFO - 2023-07-10 04:45:05 --> Loader Class Initialized
INFO - 2023-07-10 04:45:05 --> Helper loaded: url_helper
INFO - 2023-07-10 04:45:05 --> Helper loaded: file_helper
INFO - 2023-07-10 04:45:05 --> Helper loaded: form_helper
INFO - 2023-07-10 04:45:05 --> Helper loaded: my_helper
INFO - 2023-07-10 04:45:05 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:45:05 --> Controller Class Initialized
INFO - 2023-07-10 04:45:05 --> Final output sent to browser
DEBUG - 2023-07-10 04:45:05 --> Total execution time: 0.1047
INFO - 2023-07-10 04:45:10 --> Config Class Initialized
INFO - 2023-07-10 04:45:10 --> Hooks Class Initialized
DEBUG - 2023-07-10 04:45:10 --> UTF-8 Support Enabled
INFO - 2023-07-10 04:45:10 --> Utf8 Class Initialized
INFO - 2023-07-10 04:45:10 --> URI Class Initialized
INFO - 2023-07-10 04:45:10 --> Router Class Initialized
INFO - 2023-07-10 04:45:10 --> Output Class Initialized
INFO - 2023-07-10 04:45:10 --> Security Class Initialized
DEBUG - 2023-07-10 04:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 04:45:10 --> Input Class Initialized
INFO - 2023-07-10 04:45:10 --> Language Class Initialized
INFO - 2023-07-10 04:45:10 --> Language Class Initialized
INFO - 2023-07-10 04:45:10 --> Config Class Initialized
INFO - 2023-07-10 04:45:10 --> Loader Class Initialized
INFO - 2023-07-10 04:45:10 --> Helper loaded: url_helper
INFO - 2023-07-10 04:45:10 --> Helper loaded: file_helper
INFO - 2023-07-10 04:45:10 --> Helper loaded: form_helper
INFO - 2023-07-10 04:45:10 --> Helper loaded: my_helper
INFO - 2023-07-10 04:45:10 --> Database Driver Class Initialized
DEBUG - 2023-07-10 04:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 04:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 04:45:10 --> Controller Class Initialized
DEBUG - 2023-07-10 04:45:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-10 04:45:12 --> Final output sent to browser
DEBUG - 2023-07-10 04:45:12 --> Total execution time: 1.8627
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:02 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:02 --> URI Class Initialized
INFO - 2023-07-10 06:59:02 --> Router Class Initialized
INFO - 2023-07-10 06:59:02 --> Output Class Initialized
INFO - 2023-07-10 06:59:02 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:02 --> Input Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Loader Class Initialized
INFO - 2023-07-10 06:59:02 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:02 --> Controller Class Initialized
INFO - 2023-07-10 06:59:02 --> Helper loaded: cookie_helper
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:02 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:02 --> URI Class Initialized
INFO - 2023-07-10 06:59:02 --> Router Class Initialized
INFO - 2023-07-10 06:59:02 --> Output Class Initialized
INFO - 2023-07-10 06:59:02 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:02 --> Input Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Loader Class Initialized
INFO - 2023-07-10 06:59:02 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:02 --> Controller Class Initialized
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:02 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:02 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:02 --> URI Class Initialized
INFO - 2023-07-10 06:59:02 --> Router Class Initialized
INFO - 2023-07-10 06:59:02 --> Output Class Initialized
INFO - 2023-07-10 06:59:02 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:02 --> Input Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Language Class Initialized
INFO - 2023-07-10 06:59:02 --> Config Class Initialized
INFO - 2023-07-10 06:59:02 --> Loader Class Initialized
INFO - 2023-07-10 06:59:02 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:02 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:02 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:02 --> Controller Class Initialized
DEBUG - 2023-07-10 06:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 06:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 06:59:02 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:02 --> Total execution time: 0.0249
INFO - 2023-07-10 06:59:05 --> Config Class Initialized
INFO - 2023-07-10 06:59:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:05 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:05 --> URI Class Initialized
INFO - 2023-07-10 06:59:05 --> Router Class Initialized
INFO - 2023-07-10 06:59:05 --> Output Class Initialized
INFO - 2023-07-10 06:59:05 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:05 --> Input Class Initialized
INFO - 2023-07-10 06:59:05 --> Language Class Initialized
INFO - 2023-07-10 06:59:05 --> Language Class Initialized
INFO - 2023-07-10 06:59:05 --> Config Class Initialized
INFO - 2023-07-10 06:59:05 --> Loader Class Initialized
INFO - 2023-07-10 06:59:05 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:05 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:05 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:05 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:05 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:05 --> Controller Class Initialized
INFO - 2023-07-10 06:59:05 --> Helper loaded: cookie_helper
INFO - 2023-07-10 06:59:05 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:05 --> Total execution time: 0.0308
INFO - 2023-07-10 06:59:05 --> Config Class Initialized
INFO - 2023-07-10 06:59:05 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:05 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:05 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:05 --> URI Class Initialized
INFO - 2023-07-10 06:59:05 --> Router Class Initialized
INFO - 2023-07-10 06:59:05 --> Output Class Initialized
INFO - 2023-07-10 06:59:05 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:05 --> Input Class Initialized
INFO - 2023-07-10 06:59:05 --> Language Class Initialized
INFO - 2023-07-10 06:59:06 --> Language Class Initialized
INFO - 2023-07-10 06:59:06 --> Config Class Initialized
INFO - 2023-07-10 06:59:06 --> Loader Class Initialized
INFO - 2023-07-10 06:59:06 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:06 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:06 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:06 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:06 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:06 --> Controller Class Initialized
DEBUG - 2023-07-10 06:59:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-07-10 06:59:06 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 06:59:06 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:06 --> Total execution time: 0.0390
INFO - 2023-07-10 06:59:07 --> Config Class Initialized
INFO - 2023-07-10 06:59:07 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:07 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:07 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:07 --> URI Class Initialized
INFO - 2023-07-10 06:59:07 --> Router Class Initialized
INFO - 2023-07-10 06:59:07 --> Output Class Initialized
INFO - 2023-07-10 06:59:07 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:07 --> Input Class Initialized
INFO - 2023-07-10 06:59:07 --> Language Class Initialized
INFO - 2023-07-10 06:59:07 --> Language Class Initialized
INFO - 2023-07-10 06:59:07 --> Config Class Initialized
INFO - 2023-07-10 06:59:07 --> Loader Class Initialized
INFO - 2023-07-10 06:59:07 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:07 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:07 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:07 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:07 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:07 --> Controller Class Initialized
DEBUG - 2023-07-10 06:59:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-10 06:59:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 06:59:07 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:07 --> Total execution time: 0.0304
INFO - 2023-07-10 06:59:08 --> Config Class Initialized
INFO - 2023-07-10 06:59:08 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:08 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:08 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:08 --> URI Class Initialized
INFO - 2023-07-10 06:59:08 --> Router Class Initialized
INFO - 2023-07-10 06:59:08 --> Output Class Initialized
INFO - 2023-07-10 06:59:08 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:08 --> Input Class Initialized
INFO - 2023-07-10 06:59:08 --> Language Class Initialized
INFO - 2023-07-10 06:59:08 --> Language Class Initialized
INFO - 2023-07-10 06:59:08 --> Config Class Initialized
INFO - 2023-07-10 06:59:08 --> Loader Class Initialized
INFO - 2023-07-10 06:59:08 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:08 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:08 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:08 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:08 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:08 --> Controller Class Initialized
INFO - 2023-07-10 06:59:11 --> Config Class Initialized
INFO - 2023-07-10 06:59:11 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:11 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:11 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:11 --> URI Class Initialized
INFO - 2023-07-10 06:59:11 --> Router Class Initialized
INFO - 2023-07-10 06:59:11 --> Output Class Initialized
INFO - 2023-07-10 06:59:11 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:11 --> Input Class Initialized
INFO - 2023-07-10 06:59:11 --> Language Class Initialized
INFO - 2023-07-10 06:59:11 --> Language Class Initialized
INFO - 2023-07-10 06:59:11 --> Config Class Initialized
INFO - 2023-07-10 06:59:11 --> Loader Class Initialized
INFO - 2023-07-10 06:59:11 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:11 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:11 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:11 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:11 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:11 --> Controller Class Initialized
DEBUG - 2023-07-10 06:59:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-10 06:59:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 06:59:11 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:11 --> Total execution time: 0.0347
INFO - 2023-07-10 06:59:12 --> Config Class Initialized
INFO - 2023-07-10 06:59:12 --> Hooks Class Initialized
DEBUG - 2023-07-10 06:59:12 --> UTF-8 Support Enabled
INFO - 2023-07-10 06:59:12 --> Utf8 Class Initialized
INFO - 2023-07-10 06:59:12 --> URI Class Initialized
INFO - 2023-07-10 06:59:12 --> Router Class Initialized
INFO - 2023-07-10 06:59:12 --> Output Class Initialized
INFO - 2023-07-10 06:59:12 --> Security Class Initialized
DEBUG - 2023-07-10 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 06:59:12 --> Input Class Initialized
INFO - 2023-07-10 06:59:12 --> Language Class Initialized
INFO - 2023-07-10 06:59:12 --> Language Class Initialized
INFO - 2023-07-10 06:59:12 --> Config Class Initialized
INFO - 2023-07-10 06:59:12 --> Loader Class Initialized
INFO - 2023-07-10 06:59:12 --> Helper loaded: url_helper
INFO - 2023-07-10 06:59:12 --> Helper loaded: file_helper
INFO - 2023-07-10 06:59:12 --> Helper loaded: form_helper
INFO - 2023-07-10 06:59:12 --> Helper loaded: my_helper
INFO - 2023-07-10 06:59:12 --> Database Driver Class Initialized
DEBUG - 2023-07-10 06:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 06:59:12 --> Controller Class Initialized
ERROR - 2023-07-10 06:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-10 06:59:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-10 06:59:12 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-07-10 06:59:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-10 06:59:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 06:59:12 --> Final output sent to browser
DEBUG - 2023-07-10 06:59:12 --> Total execution time: 0.0368
INFO - 2023-07-10 09:13:42 --> Config Class Initialized
INFO - 2023-07-10 09:13:42 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:42 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:42 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:42 --> URI Class Initialized
DEBUG - 2023-07-10 09:13:42 --> No URI present. Default controller set.
INFO - 2023-07-10 09:13:42 --> Router Class Initialized
INFO - 2023-07-10 09:13:42 --> Output Class Initialized
INFO - 2023-07-10 09:13:42 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:42 --> Input Class Initialized
INFO - 2023-07-10 09:13:42 --> Language Class Initialized
INFO - 2023-07-10 09:13:42 --> Language Class Initialized
INFO - 2023-07-10 09:13:42 --> Config Class Initialized
INFO - 2023-07-10 09:13:42 --> Loader Class Initialized
INFO - 2023-07-10 09:13:42 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:42 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:42 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:42 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:42 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:43 --> Controller Class Initialized
INFO - 2023-07-10 09:13:43 --> Config Class Initialized
INFO - 2023-07-10 09:13:43 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:43 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:43 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:43 --> URI Class Initialized
INFO - 2023-07-10 09:13:43 --> Router Class Initialized
INFO - 2023-07-10 09:13:43 --> Output Class Initialized
INFO - 2023-07-10 09:13:43 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:43 --> Input Class Initialized
INFO - 2023-07-10 09:13:43 --> Language Class Initialized
INFO - 2023-07-10 09:13:43 --> Language Class Initialized
INFO - 2023-07-10 09:13:43 --> Config Class Initialized
INFO - 2023-07-10 09:13:43 --> Loader Class Initialized
INFO - 2023-07-10 09:13:43 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:43 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:43 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:43 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:43 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:43 --> Controller Class Initialized
DEBUG - 2023-07-10 09:13:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-07-10 09:13:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 09:13:43 --> Final output sent to browser
DEBUG - 2023-07-10 09:13:43 --> Total execution time: 0.0392
INFO - 2023-07-10 09:13:47 --> Config Class Initialized
INFO - 2023-07-10 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:47 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:47 --> URI Class Initialized
INFO - 2023-07-10 09:13:47 --> Router Class Initialized
INFO - 2023-07-10 09:13:47 --> Output Class Initialized
INFO - 2023-07-10 09:13:47 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:47 --> Input Class Initialized
INFO - 2023-07-10 09:13:47 --> Language Class Initialized
INFO - 2023-07-10 09:13:47 --> Language Class Initialized
INFO - 2023-07-10 09:13:47 --> Config Class Initialized
INFO - 2023-07-10 09:13:47 --> Loader Class Initialized
INFO - 2023-07-10 09:13:47 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:47 --> Controller Class Initialized
INFO - 2023-07-10 09:13:47 --> Helper loaded: cookie_helper
INFO - 2023-07-10 09:13:47 --> Final output sent to browser
DEBUG - 2023-07-10 09:13:47 --> Total execution time: 0.0435
INFO - 2023-07-10 09:13:47 --> Config Class Initialized
INFO - 2023-07-10 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:47 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:47 --> URI Class Initialized
INFO - 2023-07-10 09:13:47 --> Router Class Initialized
INFO - 2023-07-10 09:13:47 --> Output Class Initialized
INFO - 2023-07-10 09:13:47 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:47 --> Input Class Initialized
INFO - 2023-07-10 09:13:47 --> Language Class Initialized
INFO - 2023-07-10 09:13:47 --> Language Class Initialized
INFO - 2023-07-10 09:13:47 --> Config Class Initialized
INFO - 2023-07-10 09:13:47 --> Loader Class Initialized
INFO - 2023-07-10 09:13:47 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:47 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:47 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:47 --> Controller Class Initialized
DEBUG - 2023-07-10 09:13:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-10 09:13:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 09:13:47 --> Final output sent to browser
DEBUG - 2023-07-10 09:13:47 --> Total execution time: 0.0414
INFO - 2023-07-10 09:13:49 --> Config Class Initialized
INFO - 2023-07-10 09:13:49 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:49 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:49 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:49 --> URI Class Initialized
INFO - 2023-07-10 09:13:49 --> Router Class Initialized
INFO - 2023-07-10 09:13:49 --> Output Class Initialized
INFO - 2023-07-10 09:13:49 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:49 --> Input Class Initialized
INFO - 2023-07-10 09:13:49 --> Language Class Initialized
INFO - 2023-07-10 09:13:49 --> Language Class Initialized
INFO - 2023-07-10 09:13:49 --> Config Class Initialized
INFO - 2023-07-10 09:13:49 --> Loader Class Initialized
INFO - 2023-07-10 09:13:49 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:49 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:49 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:49 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:49 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:49 --> Controller Class Initialized
DEBUG - 2023-07-10 09:13:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-10 09:13:49 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 09:13:49 --> Final output sent to browser
DEBUG - 2023-07-10 09:13:49 --> Total execution time: 0.0388
INFO - 2023-07-10 09:13:51 --> Config Class Initialized
INFO - 2023-07-10 09:13:51 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:51 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:51 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:51 --> URI Class Initialized
INFO - 2023-07-10 09:13:51 --> Router Class Initialized
INFO - 2023-07-10 09:13:51 --> Output Class Initialized
INFO - 2023-07-10 09:13:51 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:51 --> Input Class Initialized
INFO - 2023-07-10 09:13:51 --> Language Class Initialized
INFO - 2023-07-10 09:13:51 --> Language Class Initialized
INFO - 2023-07-10 09:13:51 --> Config Class Initialized
INFO - 2023-07-10 09:13:51 --> Loader Class Initialized
INFO - 2023-07-10 09:13:51 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:51 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:51 --> Controller Class Initialized
DEBUG - 2023-07-10 09:13:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-10 09:13:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-07-10 09:13:51 --> Final output sent to browser
DEBUG - 2023-07-10 09:13:51 --> Total execution time: 0.0403
INFO - 2023-07-10 09:13:51 --> Config Class Initialized
INFO - 2023-07-10 09:13:51 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:13:51 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:13:51 --> Utf8 Class Initialized
INFO - 2023-07-10 09:13:51 --> URI Class Initialized
INFO - 2023-07-10 09:13:51 --> Router Class Initialized
INFO - 2023-07-10 09:13:51 --> Output Class Initialized
INFO - 2023-07-10 09:13:51 --> Security Class Initialized
DEBUG - 2023-07-10 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:13:51 --> Input Class Initialized
INFO - 2023-07-10 09:13:51 --> Language Class Initialized
INFO - 2023-07-10 09:13:51 --> Language Class Initialized
INFO - 2023-07-10 09:13:51 --> Config Class Initialized
INFO - 2023-07-10 09:13:51 --> Loader Class Initialized
INFO - 2023-07-10 09:13:51 --> Helper loaded: url_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: file_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: form_helper
INFO - 2023-07-10 09:13:51 --> Helper loaded: my_helper
INFO - 2023-07-10 09:13:51 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:13:51 --> Controller Class Initialized
INFO - 2023-07-10 09:20:19 --> Config Class Initialized
INFO - 2023-07-10 09:20:19 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:19 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:19 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:19 --> URI Class Initialized
INFO - 2023-07-10 09:20:19 --> Router Class Initialized
INFO - 2023-07-10 09:20:19 --> Output Class Initialized
INFO - 2023-07-10 09:20:19 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:19 --> Input Class Initialized
INFO - 2023-07-10 09:20:19 --> Language Class Initialized
INFO - 2023-07-10 09:20:19 --> Language Class Initialized
INFO - 2023-07-10 09:20:19 --> Config Class Initialized
INFO - 2023-07-10 09:20:19 --> Loader Class Initialized
INFO - 2023-07-10 09:20:19 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:19 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:19 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:19 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:19 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:19 --> Controller Class Initialized
INFO - 2023-07-10 09:20:19 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:19 --> Total execution time: 0.0613
INFO - 2023-07-10 09:20:21 --> Config Class Initialized
INFO - 2023-07-10 09:20:21 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:21 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:21 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:21 --> URI Class Initialized
INFO - 2023-07-10 09:20:21 --> Router Class Initialized
INFO - 2023-07-10 09:20:21 --> Output Class Initialized
INFO - 2023-07-10 09:20:21 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:21 --> Input Class Initialized
INFO - 2023-07-10 09:20:21 --> Language Class Initialized
INFO - 2023-07-10 09:20:21 --> Language Class Initialized
INFO - 2023-07-10 09:20:21 --> Config Class Initialized
INFO - 2023-07-10 09:20:21 --> Loader Class Initialized
INFO - 2023-07-10 09:20:21 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:21 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:21 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:21 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:21 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:21 --> Controller Class Initialized
INFO - 2023-07-10 09:20:21 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:21 --> Total execution time: 0.0410
INFO - 2023-07-10 09:20:26 --> Config Class Initialized
INFO - 2023-07-10 09:20:26 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:26 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:26 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:26 --> URI Class Initialized
INFO - 2023-07-10 09:20:26 --> Router Class Initialized
INFO - 2023-07-10 09:20:26 --> Output Class Initialized
INFO - 2023-07-10 09:20:26 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:26 --> Input Class Initialized
INFO - 2023-07-10 09:20:26 --> Language Class Initialized
INFO - 2023-07-10 09:20:26 --> Language Class Initialized
INFO - 2023-07-10 09:20:26 --> Config Class Initialized
INFO - 2023-07-10 09:20:26 --> Loader Class Initialized
INFO - 2023-07-10 09:20:26 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:26 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:27 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:27 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:27 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:27 --> Controller Class Initialized
INFO - 2023-07-10 09:20:27 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:27 --> Total execution time: 0.0986
INFO - 2023-07-10 09:20:29 --> Config Class Initialized
INFO - 2023-07-10 09:20:29 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:29 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:29 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:29 --> URI Class Initialized
INFO - 2023-07-10 09:20:29 --> Router Class Initialized
INFO - 2023-07-10 09:20:29 --> Output Class Initialized
INFO - 2023-07-10 09:20:29 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:29 --> Input Class Initialized
INFO - 2023-07-10 09:20:29 --> Language Class Initialized
INFO - 2023-07-10 09:20:29 --> Language Class Initialized
INFO - 2023-07-10 09:20:29 --> Config Class Initialized
INFO - 2023-07-10 09:20:29 --> Loader Class Initialized
INFO - 2023-07-10 09:20:29 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:29 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:29 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:29 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:29 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:29 --> Controller Class Initialized
INFO - 2023-07-10 09:20:29 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:29 --> Total execution time: 0.0499
INFO - 2023-07-10 09:20:30 --> Config Class Initialized
INFO - 2023-07-10 09:20:30 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:30 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:30 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:30 --> URI Class Initialized
INFO - 2023-07-10 09:20:30 --> Router Class Initialized
INFO - 2023-07-10 09:20:30 --> Output Class Initialized
INFO - 2023-07-10 09:20:30 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:30 --> Input Class Initialized
INFO - 2023-07-10 09:20:30 --> Language Class Initialized
INFO - 2023-07-10 09:20:30 --> Language Class Initialized
INFO - 2023-07-10 09:20:30 --> Config Class Initialized
INFO - 2023-07-10 09:20:30 --> Loader Class Initialized
INFO - 2023-07-10 09:20:30 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:30 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:30 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:30 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:30 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:30 --> Controller Class Initialized
INFO - 2023-07-10 09:20:30 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:30 --> Total execution time: 0.0571
INFO - 2023-07-10 09:20:37 --> Config Class Initialized
INFO - 2023-07-10 09:20:37 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:37 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:37 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:37 --> URI Class Initialized
INFO - 2023-07-10 09:20:37 --> Router Class Initialized
INFO - 2023-07-10 09:20:37 --> Output Class Initialized
INFO - 2023-07-10 09:20:37 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:37 --> Input Class Initialized
INFO - 2023-07-10 09:20:37 --> Language Class Initialized
INFO - 2023-07-10 09:20:37 --> Language Class Initialized
INFO - 2023-07-10 09:20:37 --> Config Class Initialized
INFO - 2023-07-10 09:20:37 --> Loader Class Initialized
INFO - 2023-07-10 09:20:37 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:37 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:37 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:37 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:37 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:37 --> Controller Class Initialized
INFO - 2023-07-10 09:20:37 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:37 --> Total execution time: 0.0522
INFO - 2023-07-10 09:20:41 --> Config Class Initialized
INFO - 2023-07-10 09:20:41 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:41 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:41 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:41 --> URI Class Initialized
INFO - 2023-07-10 09:20:41 --> Router Class Initialized
INFO - 2023-07-10 09:20:41 --> Output Class Initialized
INFO - 2023-07-10 09:20:41 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:41 --> Input Class Initialized
INFO - 2023-07-10 09:20:41 --> Language Class Initialized
INFO - 2023-07-10 09:20:41 --> Language Class Initialized
INFO - 2023-07-10 09:20:41 --> Config Class Initialized
INFO - 2023-07-10 09:20:41 --> Loader Class Initialized
INFO - 2023-07-10 09:20:41 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:41 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:41 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:41 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:41 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:41 --> Controller Class Initialized
INFO - 2023-07-10 09:20:41 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:41 --> Total execution time: 0.0538
INFO - 2023-07-10 09:20:45 --> Config Class Initialized
INFO - 2023-07-10 09:20:45 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:45 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:45 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:45 --> URI Class Initialized
INFO - 2023-07-10 09:20:45 --> Router Class Initialized
INFO - 2023-07-10 09:20:45 --> Output Class Initialized
INFO - 2023-07-10 09:20:45 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:45 --> Input Class Initialized
INFO - 2023-07-10 09:20:45 --> Language Class Initialized
INFO - 2023-07-10 09:20:45 --> Language Class Initialized
INFO - 2023-07-10 09:20:45 --> Config Class Initialized
INFO - 2023-07-10 09:20:45 --> Loader Class Initialized
INFO - 2023-07-10 09:20:45 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:45 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:45 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:45 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:45 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:45 --> Controller Class Initialized
INFO - 2023-07-10 09:20:45 --> Final output sent to browser
DEBUG - 2023-07-10 09:20:45 --> Total execution time: 0.0683
INFO - 2023-07-10 09:20:59 --> Config Class Initialized
INFO - 2023-07-10 09:20:59 --> Hooks Class Initialized
DEBUG - 2023-07-10 09:20:59 --> UTF-8 Support Enabled
INFO - 2023-07-10 09:20:59 --> Utf8 Class Initialized
INFO - 2023-07-10 09:20:59 --> URI Class Initialized
INFO - 2023-07-10 09:20:59 --> Router Class Initialized
INFO - 2023-07-10 09:20:59 --> Output Class Initialized
INFO - 2023-07-10 09:20:59 --> Security Class Initialized
DEBUG - 2023-07-10 09:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-10 09:20:59 --> Input Class Initialized
INFO - 2023-07-10 09:20:59 --> Language Class Initialized
INFO - 2023-07-10 09:20:59 --> Language Class Initialized
INFO - 2023-07-10 09:20:59 --> Config Class Initialized
INFO - 2023-07-10 09:20:59 --> Loader Class Initialized
INFO - 2023-07-10 09:20:59 --> Helper loaded: url_helper
INFO - 2023-07-10 09:20:59 --> Helper loaded: file_helper
INFO - 2023-07-10 09:20:59 --> Helper loaded: form_helper
INFO - 2023-07-10 09:20:59 --> Helper loaded: my_helper
INFO - 2023-07-10 09:20:59 --> Database Driver Class Initialized
DEBUG - 2023-07-10 09:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-10 09:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-10 09:20:59 --> Controller Class Initialized
