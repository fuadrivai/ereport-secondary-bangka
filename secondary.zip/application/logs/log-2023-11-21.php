<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-21 08:12:56 --> Config Class Initialized
INFO - 2023-11-21 08:12:56 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:12:56 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:12:56 --> Utf8 Class Initialized
INFO - 2023-11-21 08:12:56 --> URI Class Initialized
INFO - 2023-11-21 08:12:56 --> Router Class Initialized
INFO - 2023-11-21 08:12:56 --> Output Class Initialized
INFO - 2023-11-21 08:12:56 --> Security Class Initialized
DEBUG - 2023-11-21 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:12:56 --> Input Class Initialized
INFO - 2023-11-21 08:12:56 --> Language Class Initialized
INFO - 2023-11-21 08:12:56 --> Language Class Initialized
INFO - 2023-11-21 08:12:56 --> Config Class Initialized
INFO - 2023-11-21 08:12:56 --> Loader Class Initialized
INFO - 2023-11-21 08:12:56 --> Helper loaded: url_helper
INFO - 2023-11-21 08:12:56 --> Helper loaded: file_helper
INFO - 2023-11-21 08:12:56 --> Helper loaded: form_helper
INFO - 2023-11-21 08:12:56 --> Helper loaded: my_helper
INFO - 2023-11-21 08:12:56 --> Database Driver Class Initialized
INFO - 2023-11-21 08:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:12:56 --> Controller Class Initialized
DEBUG - 2023-11-21 08:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 08:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:12:56 --> Final output sent to browser
DEBUG - 2023-11-21 08:12:56 --> Total execution time: 0.3309
INFO - 2023-11-21 08:40:37 --> Config Class Initialized
INFO - 2023-11-21 08:40:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:37 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:37 --> URI Class Initialized
DEBUG - 2023-11-21 08:40:37 --> No URI present. Default controller set.
INFO - 2023-11-21 08:40:37 --> Router Class Initialized
INFO - 2023-11-21 08:40:37 --> Output Class Initialized
INFO - 2023-11-21 08:40:37 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:37 --> Input Class Initialized
INFO - 2023-11-21 08:40:37 --> Language Class Initialized
INFO - 2023-11-21 08:40:37 --> Language Class Initialized
INFO - 2023-11-21 08:40:37 --> Config Class Initialized
INFO - 2023-11-21 08:40:37 --> Loader Class Initialized
INFO - 2023-11-21 08:40:37 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:37 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:37 --> Controller Class Initialized
INFO - 2023-11-21 08:40:37 --> Config Class Initialized
INFO - 2023-11-21 08:40:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:37 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:37 --> URI Class Initialized
INFO - 2023-11-21 08:40:37 --> Router Class Initialized
INFO - 2023-11-21 08:40:37 --> Output Class Initialized
INFO - 2023-11-21 08:40:37 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:37 --> Input Class Initialized
INFO - 2023-11-21 08:40:37 --> Language Class Initialized
INFO - 2023-11-21 08:40:37 --> Language Class Initialized
INFO - 2023-11-21 08:40:37 --> Config Class Initialized
INFO - 2023-11-21 08:40:37 --> Loader Class Initialized
INFO - 2023-11-21 08:40:37 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:37 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:37 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:37 --> Controller Class Initialized
DEBUG - 2023-11-21 08:40:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 08:40:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:40:37 --> Final output sent to browser
DEBUG - 2023-11-21 08:40:37 --> Total execution time: 0.0297
INFO - 2023-11-21 08:40:43 --> Config Class Initialized
INFO - 2023-11-21 08:40:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:43 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:43 --> URI Class Initialized
INFO - 2023-11-21 08:40:43 --> Router Class Initialized
INFO - 2023-11-21 08:40:43 --> Output Class Initialized
INFO - 2023-11-21 08:40:43 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:43 --> Input Class Initialized
INFO - 2023-11-21 08:40:43 --> Language Class Initialized
INFO - 2023-11-21 08:40:43 --> Language Class Initialized
INFO - 2023-11-21 08:40:43 --> Config Class Initialized
INFO - 2023-11-21 08:40:43 --> Loader Class Initialized
INFO - 2023-11-21 08:40:43 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:43 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:43 --> Controller Class Initialized
INFO - 2023-11-21 08:40:43 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:40:43 --> Final output sent to browser
DEBUG - 2023-11-21 08:40:43 --> Total execution time: 0.0486
INFO - 2023-11-21 08:40:43 --> Config Class Initialized
INFO - 2023-11-21 08:40:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:43 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:43 --> URI Class Initialized
INFO - 2023-11-21 08:40:43 --> Router Class Initialized
INFO - 2023-11-21 08:40:43 --> Output Class Initialized
INFO - 2023-11-21 08:40:43 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:43 --> Input Class Initialized
INFO - 2023-11-21 08:40:43 --> Language Class Initialized
INFO - 2023-11-21 08:40:43 --> Language Class Initialized
INFO - 2023-11-21 08:40:43 --> Config Class Initialized
INFO - 2023-11-21 08:40:43 --> Loader Class Initialized
INFO - 2023-11-21 08:40:43 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:43 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:43 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:43 --> Controller Class Initialized
DEBUG - 2023-11-21 08:40:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 08:40:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:40:43 --> Final output sent to browser
DEBUG - 2023-11-21 08:40:43 --> Total execution time: 0.1609
INFO - 2023-11-21 08:40:47 --> Config Class Initialized
INFO - 2023-11-21 08:40:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:47 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:47 --> URI Class Initialized
INFO - 2023-11-21 08:40:47 --> Router Class Initialized
INFO - 2023-11-21 08:40:47 --> Output Class Initialized
INFO - 2023-11-21 08:40:47 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:47 --> Input Class Initialized
INFO - 2023-11-21 08:40:47 --> Language Class Initialized
INFO - 2023-11-21 08:40:47 --> Language Class Initialized
INFO - 2023-11-21 08:40:47 --> Config Class Initialized
INFO - 2023-11-21 08:40:47 --> Loader Class Initialized
INFO - 2023-11-21 08:40:47 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:47 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:47 --> Controller Class Initialized
DEBUG - 2023-11-21 08:40:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 08:40:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:40:47 --> Final output sent to browser
DEBUG - 2023-11-21 08:40:47 --> Total execution time: 0.0350
INFO - 2023-11-21 08:40:47 --> Config Class Initialized
INFO - 2023-11-21 08:40:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:47 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:47 --> URI Class Initialized
INFO - 2023-11-21 08:40:47 --> Router Class Initialized
INFO - 2023-11-21 08:40:47 --> Output Class Initialized
INFO - 2023-11-21 08:40:47 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:47 --> Input Class Initialized
INFO - 2023-11-21 08:40:47 --> Language Class Initialized
ERROR - 2023-11-21 08:40:47 --> 404 Page Not Found: /index
INFO - 2023-11-21 08:40:47 --> Config Class Initialized
INFO - 2023-11-21 08:40:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:47 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:47 --> URI Class Initialized
INFO - 2023-11-21 08:40:47 --> Router Class Initialized
INFO - 2023-11-21 08:40:47 --> Output Class Initialized
INFO - 2023-11-21 08:40:47 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:47 --> Input Class Initialized
INFO - 2023-11-21 08:40:47 --> Language Class Initialized
INFO - 2023-11-21 08:40:47 --> Language Class Initialized
INFO - 2023-11-21 08:40:47 --> Config Class Initialized
INFO - 2023-11-21 08:40:47 --> Loader Class Initialized
INFO - 2023-11-21 08:40:47 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:47 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:47 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:47 --> Controller Class Initialized
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:54 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:54 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:54 --> URI Class Initialized
INFO - 2023-11-21 08:40:54 --> Router Class Initialized
INFO - 2023-11-21 08:40:54 --> Output Class Initialized
INFO - 2023-11-21 08:40:54 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:54 --> Input Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Loader Class Initialized
INFO - 2023-11-21 08:40:54 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:54 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:54 --> Controller Class Initialized
INFO - 2023-11-21 08:40:54 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:54 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:54 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:54 --> URI Class Initialized
INFO - 2023-11-21 08:40:54 --> Router Class Initialized
INFO - 2023-11-21 08:40:54 --> Output Class Initialized
INFO - 2023-11-21 08:40:54 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:54 --> Input Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Loader Class Initialized
INFO - 2023-11-21 08:40:54 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:54 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:54 --> Controller Class Initialized
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:54 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:54 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:54 --> URI Class Initialized
INFO - 2023-11-21 08:40:54 --> Router Class Initialized
INFO - 2023-11-21 08:40:54 --> Output Class Initialized
INFO - 2023-11-21 08:40:54 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:54 --> Input Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Language Class Initialized
INFO - 2023-11-21 08:40:54 --> Config Class Initialized
INFO - 2023-11-21 08:40:54 --> Loader Class Initialized
INFO - 2023-11-21 08:40:54 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:54 --> Helper loaded: my_helper
INFO - 2023-11-21 08:40:54 --> Database Driver Class Initialized
INFO - 2023-11-21 08:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:40:54 --> Controller Class Initialized
DEBUG - 2023-11-21 08:40:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 08:40:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:40:54 --> Final output sent to browser
DEBUG - 2023-11-21 08:40:54 --> Total execution time: 0.0313
INFO - 2023-11-21 08:40:59 --> Config Class Initialized
INFO - 2023-11-21 08:40:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:40:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:40:59 --> Utf8 Class Initialized
INFO - 2023-11-21 08:40:59 --> URI Class Initialized
INFO - 2023-11-21 08:40:59 --> Router Class Initialized
INFO - 2023-11-21 08:40:59 --> Output Class Initialized
INFO - 2023-11-21 08:40:59 --> Security Class Initialized
DEBUG - 2023-11-21 08:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:40:59 --> Input Class Initialized
INFO - 2023-11-21 08:40:59 --> Language Class Initialized
INFO - 2023-11-21 08:40:59 --> Language Class Initialized
INFO - 2023-11-21 08:40:59 --> Config Class Initialized
INFO - 2023-11-21 08:40:59 --> Loader Class Initialized
INFO - 2023-11-21 08:40:59 --> Helper loaded: url_helper
INFO - 2023-11-21 08:40:59 --> Helper loaded: file_helper
INFO - 2023-11-21 08:40:59 --> Helper loaded: form_helper
INFO - 2023-11-21 08:40:59 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:00 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:00 --> Controller Class Initialized
INFO - 2023-11-21 08:41:00 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:41:00 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:00 --> Total execution time: 0.2658
INFO - 2023-11-21 08:41:00 --> Config Class Initialized
INFO - 2023-11-21 08:41:00 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:00 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:00 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:00 --> URI Class Initialized
INFO - 2023-11-21 08:41:00 --> Router Class Initialized
INFO - 2023-11-21 08:41:00 --> Output Class Initialized
INFO - 2023-11-21 08:41:00 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:00 --> Input Class Initialized
INFO - 2023-11-21 08:41:00 --> Language Class Initialized
INFO - 2023-11-21 08:41:00 --> Language Class Initialized
INFO - 2023-11-21 08:41:00 --> Config Class Initialized
INFO - 2023-11-21 08:41:00 --> Loader Class Initialized
INFO - 2023-11-21 08:41:00 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:00 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:00 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:00 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:00 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:00 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 08:41:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:00 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:00 --> Total execution time: 0.0499
INFO - 2023-11-21 08:41:02 --> Config Class Initialized
INFO - 2023-11-21 08:41:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:02 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:02 --> URI Class Initialized
INFO - 2023-11-21 08:41:02 --> Router Class Initialized
INFO - 2023-11-21 08:41:02 --> Output Class Initialized
INFO - 2023-11-21 08:41:02 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:02 --> Input Class Initialized
INFO - 2023-11-21 08:41:02 --> Language Class Initialized
INFO - 2023-11-21 08:41:02 --> Language Class Initialized
INFO - 2023-11-21 08:41:02 --> Config Class Initialized
INFO - 2023-11-21 08:41:02 --> Loader Class Initialized
INFO - 2023-11-21 08:41:02 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:02 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:02 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:02 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:02 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:02 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:02 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:02 --> Total execution time: 0.0349
INFO - 2023-11-21 08:41:04 --> Config Class Initialized
INFO - 2023-11-21 08:41:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:04 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:04 --> URI Class Initialized
INFO - 2023-11-21 08:41:04 --> Router Class Initialized
INFO - 2023-11-21 08:41:04 --> Output Class Initialized
INFO - 2023-11-21 08:41:04 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:04 --> Input Class Initialized
INFO - 2023-11-21 08:41:04 --> Language Class Initialized
INFO - 2023-11-21 08:41:04 --> Language Class Initialized
INFO - 2023-11-21 08:41:04 --> Config Class Initialized
INFO - 2023-11-21 08:41:04 --> Loader Class Initialized
INFO - 2023-11-21 08:41:04 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:04 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:04 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:04 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:04 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:04 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 08:41:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:04 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:04 --> Total execution time: 0.0976
INFO - 2023-11-21 08:41:05 --> Config Class Initialized
INFO - 2023-11-21 08:41:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:05 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:05 --> URI Class Initialized
INFO - 2023-11-21 08:41:05 --> Router Class Initialized
INFO - 2023-11-21 08:41:05 --> Output Class Initialized
INFO - 2023-11-21 08:41:05 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:05 --> Input Class Initialized
INFO - 2023-11-21 08:41:05 --> Language Class Initialized
INFO - 2023-11-21 08:41:05 --> Language Class Initialized
INFO - 2023-11-21 08:41:05 --> Config Class Initialized
INFO - 2023-11-21 08:41:05 --> Loader Class Initialized
INFO - 2023-11-21 08:41:05 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:05 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:05 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:05 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:05 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:05 --> Controller Class Initialized
INFO - 2023-11-21 08:41:11 --> Config Class Initialized
INFO - 2023-11-21 08:41:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:11 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:11 --> URI Class Initialized
INFO - 2023-11-21 08:41:11 --> Router Class Initialized
INFO - 2023-11-21 08:41:11 --> Output Class Initialized
INFO - 2023-11-21 08:41:11 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:11 --> Input Class Initialized
INFO - 2023-11-21 08:41:11 --> Language Class Initialized
INFO - 2023-11-21 08:41:11 --> Language Class Initialized
INFO - 2023-11-21 08:41:11 --> Config Class Initialized
INFO - 2023-11-21 08:41:11 --> Loader Class Initialized
INFO - 2023-11-21 08:41:11 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:11 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:11 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:11 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:11 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:11 --> Controller Class Initialized
INFO - 2023-11-21 08:41:12 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:12 --> Total execution time: 0.2793
INFO - 2023-11-21 08:41:26 --> Config Class Initialized
INFO - 2023-11-21 08:41:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:26 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:26 --> URI Class Initialized
INFO - 2023-11-21 08:41:26 --> Router Class Initialized
INFO - 2023-11-21 08:41:26 --> Output Class Initialized
INFO - 2023-11-21 08:41:26 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:26 --> Input Class Initialized
INFO - 2023-11-21 08:41:26 --> Language Class Initialized
INFO - 2023-11-21 08:41:26 --> Language Class Initialized
INFO - 2023-11-21 08:41:26 --> Config Class Initialized
INFO - 2023-11-21 08:41:26 --> Loader Class Initialized
INFO - 2023-11-21 08:41:26 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:26 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:26 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:26 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:26 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:26 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:26 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:26 --> Total execution time: 0.0342
INFO - 2023-11-21 08:41:27 --> Config Class Initialized
INFO - 2023-11-21 08:41:27 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:27 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:27 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:27 --> URI Class Initialized
INFO - 2023-11-21 08:41:27 --> Router Class Initialized
INFO - 2023-11-21 08:41:27 --> Output Class Initialized
INFO - 2023-11-21 08:41:27 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:27 --> Input Class Initialized
INFO - 2023-11-21 08:41:27 --> Language Class Initialized
INFO - 2023-11-21 08:41:27 --> Language Class Initialized
INFO - 2023-11-21 08:41:27 --> Config Class Initialized
INFO - 2023-11-21 08:41:27 --> Loader Class Initialized
INFO - 2023-11-21 08:41:27 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:27 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:27 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:27 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:27 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:27 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 08:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:27 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:27 --> Total execution time: 0.0395
INFO - 2023-11-21 08:41:28 --> Config Class Initialized
INFO - 2023-11-21 08:41:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:28 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:28 --> URI Class Initialized
INFO - 2023-11-21 08:41:28 --> Router Class Initialized
INFO - 2023-11-21 08:41:28 --> Output Class Initialized
INFO - 2023-11-21 08:41:28 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:28 --> Input Class Initialized
INFO - 2023-11-21 08:41:28 --> Language Class Initialized
INFO - 2023-11-21 08:41:28 --> Language Class Initialized
INFO - 2023-11-21 08:41:28 --> Config Class Initialized
INFO - 2023-11-21 08:41:28 --> Loader Class Initialized
INFO - 2023-11-21 08:41:28 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:28 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:28 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:28 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:28 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:28 --> Controller Class Initialized
INFO - 2023-11-21 08:41:31 --> Config Class Initialized
INFO - 2023-11-21 08:41:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:31 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:31 --> URI Class Initialized
INFO - 2023-11-21 08:41:31 --> Router Class Initialized
INFO - 2023-11-21 08:41:31 --> Output Class Initialized
INFO - 2023-11-21 08:41:31 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:31 --> Input Class Initialized
INFO - 2023-11-21 08:41:31 --> Language Class Initialized
INFO - 2023-11-21 08:41:31 --> Language Class Initialized
INFO - 2023-11-21 08:41:31 --> Config Class Initialized
INFO - 2023-11-21 08:41:31 --> Loader Class Initialized
INFO - 2023-11-21 08:41:31 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:31 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:31 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:31 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:31 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:31 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:31 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:31 --> Total execution time: 0.0423
INFO - 2023-11-21 08:41:34 --> Config Class Initialized
INFO - 2023-11-21 08:41:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:34 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:34 --> URI Class Initialized
INFO - 2023-11-21 08:41:34 --> Router Class Initialized
INFO - 2023-11-21 08:41:34 --> Output Class Initialized
INFO - 2023-11-21 08:41:34 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:34 --> Input Class Initialized
INFO - 2023-11-21 08:41:34 --> Language Class Initialized
INFO - 2023-11-21 08:41:34 --> Language Class Initialized
INFO - 2023-11-21 08:41:34 --> Config Class Initialized
INFO - 2023-11-21 08:41:34 --> Loader Class Initialized
INFO - 2023-11-21 08:41:34 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:34 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:34 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:34 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:34 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:34 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-21 08:41:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:34 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:34 --> Total execution time: 0.0450
INFO - 2023-11-21 08:41:36 --> Config Class Initialized
INFO - 2023-11-21 08:41:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:36 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:36 --> URI Class Initialized
INFO - 2023-11-21 08:41:36 --> Router Class Initialized
INFO - 2023-11-21 08:41:36 --> Output Class Initialized
INFO - 2023-11-21 08:41:36 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:36 --> Input Class Initialized
INFO - 2023-11-21 08:41:36 --> Language Class Initialized
INFO - 2023-11-21 08:41:36 --> Language Class Initialized
INFO - 2023-11-21 08:41:36 --> Config Class Initialized
INFO - 2023-11-21 08:41:36 --> Loader Class Initialized
INFO - 2023-11-21 08:41:36 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:36 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:36 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:36 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:36 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:36 --> Controller Class Initialized
INFO - 2023-11-21 08:41:36 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:36 --> Total execution time: 0.0850
INFO - 2023-11-21 08:41:39 --> Config Class Initialized
INFO - 2023-11-21 08:41:39 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:39 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:39 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:39 --> URI Class Initialized
INFO - 2023-11-21 08:41:39 --> Router Class Initialized
INFO - 2023-11-21 08:41:39 --> Output Class Initialized
INFO - 2023-11-21 08:41:39 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:39 --> Input Class Initialized
INFO - 2023-11-21 08:41:39 --> Language Class Initialized
INFO - 2023-11-21 08:41:39 --> Language Class Initialized
INFO - 2023-11-21 08:41:39 --> Config Class Initialized
INFO - 2023-11-21 08:41:39 --> Loader Class Initialized
INFO - 2023-11-21 08:41:39 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:39 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:39 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:39 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:39 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:39 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:39 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:39 --> Total execution time: 0.0396
INFO - 2023-11-21 08:41:41 --> Config Class Initialized
INFO - 2023-11-21 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:41 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:41 --> URI Class Initialized
INFO - 2023-11-21 08:41:41 --> Router Class Initialized
INFO - 2023-11-21 08:41:41 --> Output Class Initialized
INFO - 2023-11-21 08:41:41 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:41 --> Input Class Initialized
INFO - 2023-11-21 08:41:41 --> Language Class Initialized
INFO - 2023-11-21 08:41:41 --> Language Class Initialized
INFO - 2023-11-21 08:41:41 --> Config Class Initialized
INFO - 2023-11-21 08:41:41 --> Loader Class Initialized
INFO - 2023-11-21 08:41:41 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:41 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:41 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:41 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:41 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:41 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-21 08:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:41 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:41 --> Total execution time: 0.0358
INFO - 2023-11-21 08:41:42 --> Config Class Initialized
INFO - 2023-11-21 08:41:42 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:42 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:42 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:42 --> URI Class Initialized
INFO - 2023-11-21 08:41:42 --> Router Class Initialized
INFO - 2023-11-21 08:41:42 --> Output Class Initialized
INFO - 2023-11-21 08:41:42 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:42 --> Input Class Initialized
INFO - 2023-11-21 08:41:42 --> Language Class Initialized
INFO - 2023-11-21 08:41:42 --> Language Class Initialized
INFO - 2023-11-21 08:41:42 --> Config Class Initialized
INFO - 2023-11-21 08:41:42 --> Loader Class Initialized
INFO - 2023-11-21 08:41:42 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:42 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:42 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:42 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:42 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:42 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:42 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:42 --> Total execution time: 0.0421
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:44 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:44 --> URI Class Initialized
INFO - 2023-11-21 08:41:44 --> Router Class Initialized
INFO - 2023-11-21 08:41:44 --> Output Class Initialized
INFO - 2023-11-21 08:41:44 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:44 --> Input Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Loader Class Initialized
INFO - 2023-11-21 08:41:44 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:44 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:44 --> Controller Class Initialized
INFO - 2023-11-21 08:41:44 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:44 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:44 --> URI Class Initialized
INFO - 2023-11-21 08:41:44 --> Router Class Initialized
INFO - 2023-11-21 08:41:44 --> Output Class Initialized
INFO - 2023-11-21 08:41:44 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:44 --> Input Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Loader Class Initialized
INFO - 2023-11-21 08:41:44 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:44 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:44 --> Controller Class Initialized
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:44 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:44 --> URI Class Initialized
INFO - 2023-11-21 08:41:44 --> Router Class Initialized
INFO - 2023-11-21 08:41:44 --> Output Class Initialized
INFO - 2023-11-21 08:41:44 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:44 --> Input Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Language Class Initialized
INFO - 2023-11-21 08:41:44 --> Config Class Initialized
INFO - 2023-11-21 08:41:44 --> Loader Class Initialized
INFO - 2023-11-21 08:41:44 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:44 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:44 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:44 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 08:41:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:44 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:44 --> Total execution time: 0.0322
INFO - 2023-11-21 08:41:51 --> Config Class Initialized
INFO - 2023-11-21 08:41:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:51 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:51 --> URI Class Initialized
INFO - 2023-11-21 08:41:51 --> Router Class Initialized
INFO - 2023-11-21 08:41:51 --> Output Class Initialized
INFO - 2023-11-21 08:41:51 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:51 --> Input Class Initialized
INFO - 2023-11-21 08:41:51 --> Language Class Initialized
INFO - 2023-11-21 08:41:51 --> Language Class Initialized
INFO - 2023-11-21 08:41:51 --> Config Class Initialized
INFO - 2023-11-21 08:41:51 --> Loader Class Initialized
INFO - 2023-11-21 08:41:51 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:51 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:51 --> Controller Class Initialized
INFO - 2023-11-21 08:41:51 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:41:51 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:51 --> Total execution time: 0.0373
INFO - 2023-11-21 08:41:51 --> Config Class Initialized
INFO - 2023-11-21 08:41:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:51 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:51 --> URI Class Initialized
INFO - 2023-11-21 08:41:51 --> Router Class Initialized
INFO - 2023-11-21 08:41:51 --> Output Class Initialized
INFO - 2023-11-21 08:41:51 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:51 --> Input Class Initialized
INFO - 2023-11-21 08:41:51 --> Language Class Initialized
INFO - 2023-11-21 08:41:51 --> Language Class Initialized
INFO - 2023-11-21 08:41:51 --> Config Class Initialized
INFO - 2023-11-21 08:41:51 --> Loader Class Initialized
INFO - 2023-11-21 08:41:51 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:51 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:51 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:51 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:51 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:51 --> Total execution time: 0.0326
INFO - 2023-11-21 08:41:53 --> Config Class Initialized
INFO - 2023-11-21 08:41:53 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:53 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:53 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:53 --> URI Class Initialized
INFO - 2023-11-21 08:41:53 --> Router Class Initialized
INFO - 2023-11-21 08:41:53 --> Output Class Initialized
INFO - 2023-11-21 08:41:53 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:53 --> Input Class Initialized
INFO - 2023-11-21 08:41:53 --> Language Class Initialized
INFO - 2023-11-21 08:41:53 --> Language Class Initialized
INFO - 2023-11-21 08:41:53 --> Config Class Initialized
INFO - 2023-11-21 08:41:53 --> Loader Class Initialized
INFO - 2023-11-21 08:41:53 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:53 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:53 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:53 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:53 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:53 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:41:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:54 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:54 --> Total execution time: 0.0674
INFO - 2023-11-21 08:41:55 --> Config Class Initialized
INFO - 2023-11-21 08:41:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:55 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:55 --> URI Class Initialized
INFO - 2023-11-21 08:41:55 --> Router Class Initialized
INFO - 2023-11-21 08:41:55 --> Output Class Initialized
INFO - 2023-11-21 08:41:55 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:55 --> Input Class Initialized
INFO - 2023-11-21 08:41:55 --> Language Class Initialized
INFO - 2023-11-21 08:41:55 --> Language Class Initialized
INFO - 2023-11-21 08:41:55 --> Config Class Initialized
INFO - 2023-11-21 08:41:55 --> Loader Class Initialized
INFO - 2023-11-21 08:41:55 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:55 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:55 --> Controller Class Initialized
DEBUG - 2023-11-21 08:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 08:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:41:55 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:55 --> Total execution time: 0.0320
INFO - 2023-11-21 08:41:55 --> Config Class Initialized
INFO - 2023-11-21 08:41:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:55 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:55 --> URI Class Initialized
INFO - 2023-11-21 08:41:55 --> Router Class Initialized
INFO - 2023-11-21 08:41:55 --> Output Class Initialized
INFO - 2023-11-21 08:41:55 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:55 --> Input Class Initialized
INFO - 2023-11-21 08:41:55 --> Language Class Initialized
INFO - 2023-11-21 08:41:55 --> Language Class Initialized
INFO - 2023-11-21 08:41:55 --> Config Class Initialized
INFO - 2023-11-21 08:41:55 --> Loader Class Initialized
INFO - 2023-11-21 08:41:55 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:55 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:55 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:55 --> Controller Class Initialized
INFO - 2023-11-21 08:41:56 --> Config Class Initialized
INFO - 2023-11-21 08:41:56 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:41:56 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:41:56 --> Utf8 Class Initialized
INFO - 2023-11-21 08:41:56 --> URI Class Initialized
INFO - 2023-11-21 08:41:56 --> Router Class Initialized
INFO - 2023-11-21 08:41:56 --> Output Class Initialized
INFO - 2023-11-21 08:41:56 --> Security Class Initialized
DEBUG - 2023-11-21 08:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:41:56 --> Input Class Initialized
INFO - 2023-11-21 08:41:56 --> Language Class Initialized
INFO - 2023-11-21 08:41:56 --> Language Class Initialized
INFO - 2023-11-21 08:41:56 --> Config Class Initialized
INFO - 2023-11-21 08:41:56 --> Loader Class Initialized
INFO - 2023-11-21 08:41:56 --> Helper loaded: url_helper
INFO - 2023-11-21 08:41:56 --> Helper loaded: file_helper
INFO - 2023-11-21 08:41:56 --> Helper loaded: form_helper
INFO - 2023-11-21 08:41:56 --> Helper loaded: my_helper
INFO - 2023-11-21 08:41:56 --> Database Driver Class Initialized
INFO - 2023-11-21 08:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:41:56 --> Controller Class Initialized
INFO - 2023-11-21 08:41:56 --> Final output sent to browser
DEBUG - 2023-11-21 08:41:56 --> Total execution time: 0.0720
INFO - 2023-11-21 08:42:00 --> Config Class Initialized
INFO - 2023-11-21 08:42:00 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:42:00 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:42:00 --> Utf8 Class Initialized
INFO - 2023-11-21 08:42:00 --> URI Class Initialized
INFO - 2023-11-21 08:42:00 --> Router Class Initialized
INFO - 2023-11-21 08:42:00 --> Output Class Initialized
INFO - 2023-11-21 08:42:00 --> Security Class Initialized
DEBUG - 2023-11-21 08:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:42:00 --> Input Class Initialized
INFO - 2023-11-21 08:42:00 --> Language Class Initialized
INFO - 2023-11-21 08:42:00 --> Language Class Initialized
INFO - 2023-11-21 08:42:00 --> Config Class Initialized
INFO - 2023-11-21 08:42:00 --> Loader Class Initialized
INFO - 2023-11-21 08:42:00 --> Helper loaded: url_helper
INFO - 2023-11-21 08:42:00 --> Helper loaded: file_helper
INFO - 2023-11-21 08:42:00 --> Helper loaded: form_helper
INFO - 2023-11-21 08:42:00 --> Helper loaded: my_helper
INFO - 2023-11-21 08:42:00 --> Database Driver Class Initialized
INFO - 2023-11-21 08:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:42:00 --> Controller Class Initialized
INFO - 2023-11-21 08:42:00 --> Final output sent to browser
DEBUG - 2023-11-21 08:42:00 --> Total execution time: 0.0323
INFO - 2023-11-21 08:42:03 --> Config Class Initialized
INFO - 2023-11-21 08:42:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:42:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:42:03 --> Utf8 Class Initialized
INFO - 2023-11-21 08:42:03 --> URI Class Initialized
INFO - 2023-11-21 08:42:03 --> Router Class Initialized
INFO - 2023-11-21 08:42:03 --> Output Class Initialized
INFO - 2023-11-21 08:42:03 --> Security Class Initialized
DEBUG - 2023-11-21 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:42:03 --> Input Class Initialized
INFO - 2023-11-21 08:42:03 --> Language Class Initialized
INFO - 2023-11-21 08:42:03 --> Language Class Initialized
INFO - 2023-11-21 08:42:03 --> Config Class Initialized
INFO - 2023-11-21 08:42:03 --> Loader Class Initialized
INFO - 2023-11-21 08:42:03 --> Helper loaded: url_helper
INFO - 2023-11-21 08:42:03 --> Helper loaded: file_helper
INFO - 2023-11-21 08:42:03 --> Helper loaded: form_helper
INFO - 2023-11-21 08:42:03 --> Helper loaded: my_helper
INFO - 2023-11-21 08:42:03 --> Database Driver Class Initialized
INFO - 2023-11-21 08:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:42:03 --> Controller Class Initialized
DEBUG - 2023-11-21 08:42:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 08:42:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:42:03 --> Final output sent to browser
DEBUG - 2023-11-21 08:42:03 --> Total execution time: 0.0352
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:42:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:42:04 --> Utf8 Class Initialized
INFO - 2023-11-21 08:42:04 --> URI Class Initialized
INFO - 2023-11-21 08:42:04 --> Router Class Initialized
INFO - 2023-11-21 08:42:04 --> Output Class Initialized
INFO - 2023-11-21 08:42:04 --> Security Class Initialized
DEBUG - 2023-11-21 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:42:04 --> Input Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Loader Class Initialized
INFO - 2023-11-21 08:42:04 --> Helper loaded: url_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: file_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: form_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: my_helper
INFO - 2023-11-21 08:42:04 --> Database Driver Class Initialized
INFO - 2023-11-21 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:42:04 --> Controller Class Initialized
INFO - 2023-11-21 08:42:04 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:42:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:42:04 --> Utf8 Class Initialized
INFO - 2023-11-21 08:42:04 --> URI Class Initialized
INFO - 2023-11-21 08:42:04 --> Router Class Initialized
INFO - 2023-11-21 08:42:04 --> Output Class Initialized
INFO - 2023-11-21 08:42:04 --> Security Class Initialized
DEBUG - 2023-11-21 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:42:04 --> Input Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Loader Class Initialized
INFO - 2023-11-21 08:42:04 --> Helper loaded: url_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: file_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: form_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: my_helper
INFO - 2023-11-21 08:42:04 --> Database Driver Class Initialized
INFO - 2023-11-21 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:42:04 --> Controller Class Initialized
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:42:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:42:04 --> Utf8 Class Initialized
INFO - 2023-11-21 08:42:04 --> URI Class Initialized
INFO - 2023-11-21 08:42:04 --> Router Class Initialized
INFO - 2023-11-21 08:42:04 --> Output Class Initialized
INFO - 2023-11-21 08:42:04 --> Security Class Initialized
DEBUG - 2023-11-21 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:42:04 --> Input Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Language Class Initialized
INFO - 2023-11-21 08:42:04 --> Config Class Initialized
INFO - 2023-11-21 08:42:04 --> Loader Class Initialized
INFO - 2023-11-21 08:42:04 --> Helper loaded: url_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: file_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: form_helper
INFO - 2023-11-21 08:42:04 --> Helper loaded: my_helper
INFO - 2023-11-21 08:42:04 --> Database Driver Class Initialized
INFO - 2023-11-21 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:42:04 --> Controller Class Initialized
DEBUG - 2023-11-21 08:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 08:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:42:04 --> Final output sent to browser
DEBUG - 2023-11-21 08:42:04 --> Total execution time: 0.0396
INFO - 2023-11-21 08:44:23 --> Config Class Initialized
INFO - 2023-11-21 08:44:23 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:23 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:23 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:23 --> URI Class Initialized
INFO - 2023-11-21 08:44:23 --> Router Class Initialized
INFO - 2023-11-21 08:44:23 --> Output Class Initialized
INFO - 2023-11-21 08:44:23 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:23 --> Input Class Initialized
INFO - 2023-11-21 08:44:23 --> Language Class Initialized
INFO - 2023-11-21 08:44:23 --> Language Class Initialized
INFO - 2023-11-21 08:44:23 --> Config Class Initialized
INFO - 2023-11-21 08:44:23 --> Loader Class Initialized
INFO - 2023-11-21 08:44:23 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:23 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:23 --> Controller Class Initialized
INFO - 2023-11-21 08:44:23 --> Helper loaded: cookie_helper
INFO - 2023-11-21 08:44:23 --> Final output sent to browser
DEBUG - 2023-11-21 08:44:23 --> Total execution time: 0.0738
INFO - 2023-11-21 08:44:23 --> Config Class Initialized
INFO - 2023-11-21 08:44:23 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:23 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:23 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:23 --> URI Class Initialized
INFO - 2023-11-21 08:44:23 --> Router Class Initialized
INFO - 2023-11-21 08:44:23 --> Output Class Initialized
INFO - 2023-11-21 08:44:23 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:23 --> Input Class Initialized
INFO - 2023-11-21 08:44:23 --> Language Class Initialized
INFO - 2023-11-21 08:44:23 --> Language Class Initialized
INFO - 2023-11-21 08:44:23 --> Config Class Initialized
INFO - 2023-11-21 08:44:23 --> Loader Class Initialized
INFO - 2023-11-21 08:44:23 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:23 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:23 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:23 --> Controller Class Initialized
DEBUG - 2023-11-21 08:44:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 08:44:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:44:23 --> Final output sent to browser
DEBUG - 2023-11-21 08:44:23 --> Total execution time: 0.0906
INFO - 2023-11-21 08:44:26 --> Config Class Initialized
INFO - 2023-11-21 08:44:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:26 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:26 --> URI Class Initialized
INFO - 2023-11-21 08:44:26 --> Router Class Initialized
INFO - 2023-11-21 08:44:26 --> Output Class Initialized
INFO - 2023-11-21 08:44:26 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:26 --> Input Class Initialized
INFO - 2023-11-21 08:44:26 --> Language Class Initialized
INFO - 2023-11-21 08:44:26 --> Language Class Initialized
INFO - 2023-11-21 08:44:26 --> Config Class Initialized
INFO - 2023-11-21 08:44:26 --> Loader Class Initialized
INFO - 2023-11-21 08:44:26 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:26 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:26 --> Controller Class Initialized
DEBUG - 2023-11-21 08:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-11-21 08:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:44:26 --> Final output sent to browser
DEBUG - 2023-11-21 08:44:26 --> Total execution time: 0.0356
INFO - 2023-11-21 08:44:26 --> Config Class Initialized
INFO - 2023-11-21 08:44:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:26 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:26 --> URI Class Initialized
INFO - 2023-11-21 08:44:26 --> Router Class Initialized
INFO - 2023-11-21 08:44:26 --> Output Class Initialized
INFO - 2023-11-21 08:44:26 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:26 --> Input Class Initialized
INFO - 2023-11-21 08:44:26 --> Language Class Initialized
ERROR - 2023-11-21 08:44:26 --> 404 Page Not Found: /index
INFO - 2023-11-21 08:44:26 --> Config Class Initialized
INFO - 2023-11-21 08:44:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:26 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:26 --> URI Class Initialized
INFO - 2023-11-21 08:44:26 --> Router Class Initialized
INFO - 2023-11-21 08:44:26 --> Output Class Initialized
INFO - 2023-11-21 08:44:26 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:26 --> Input Class Initialized
INFO - 2023-11-21 08:44:26 --> Language Class Initialized
INFO - 2023-11-21 08:44:26 --> Language Class Initialized
INFO - 2023-11-21 08:44:26 --> Config Class Initialized
INFO - 2023-11-21 08:44:26 --> Loader Class Initialized
INFO - 2023-11-21 08:44:26 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:26 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:26 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:26 --> Controller Class Initialized
INFO - 2023-11-21 08:44:35 --> Config Class Initialized
INFO - 2023-11-21 08:44:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:35 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:35 --> URI Class Initialized
INFO - 2023-11-21 08:44:35 --> Router Class Initialized
INFO - 2023-11-21 08:44:35 --> Output Class Initialized
INFO - 2023-11-21 08:44:35 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:35 --> Input Class Initialized
INFO - 2023-11-21 08:44:35 --> Language Class Initialized
INFO - 2023-11-21 08:44:35 --> Language Class Initialized
INFO - 2023-11-21 08:44:35 --> Config Class Initialized
INFO - 2023-11-21 08:44:35 --> Loader Class Initialized
INFO - 2023-11-21 08:44:35 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:35 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:35 --> Controller Class Initialized
DEBUG - 2023-11-21 08:44:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-11-21 08:44:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 08:44:35 --> Final output sent to browser
DEBUG - 2023-11-21 08:44:35 --> Total execution time: 0.0820
INFO - 2023-11-21 08:44:35 --> Config Class Initialized
INFO - 2023-11-21 08:44:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:35 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:35 --> URI Class Initialized
INFO - 2023-11-21 08:44:35 --> Router Class Initialized
INFO - 2023-11-21 08:44:35 --> Output Class Initialized
INFO - 2023-11-21 08:44:35 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:35 --> Input Class Initialized
INFO - 2023-11-21 08:44:35 --> Language Class Initialized
ERROR - 2023-11-21 08:44:35 --> 404 Page Not Found: /index
INFO - 2023-11-21 08:44:35 --> Config Class Initialized
INFO - 2023-11-21 08:44:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 08:44:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 08:44:35 --> Utf8 Class Initialized
INFO - 2023-11-21 08:44:35 --> URI Class Initialized
INFO - 2023-11-21 08:44:35 --> Router Class Initialized
INFO - 2023-11-21 08:44:35 --> Output Class Initialized
INFO - 2023-11-21 08:44:35 --> Security Class Initialized
DEBUG - 2023-11-21 08:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 08:44:35 --> Input Class Initialized
INFO - 2023-11-21 08:44:35 --> Language Class Initialized
INFO - 2023-11-21 08:44:35 --> Language Class Initialized
INFO - 2023-11-21 08:44:35 --> Config Class Initialized
INFO - 2023-11-21 08:44:35 --> Loader Class Initialized
INFO - 2023-11-21 08:44:35 --> Helper loaded: url_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: file_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: form_helper
INFO - 2023-11-21 08:44:35 --> Helper loaded: my_helper
INFO - 2023-11-21 08:44:35 --> Database Driver Class Initialized
INFO - 2023-11-21 08:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 08:44:35 --> Controller Class Initialized
INFO - 2023-11-21 09:09:25 --> Config Class Initialized
INFO - 2023-11-21 09:09:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:25 --> URI Class Initialized
DEBUG - 2023-11-21 09:09:25 --> No URI present. Default controller set.
INFO - 2023-11-21 09:09:25 --> Router Class Initialized
INFO - 2023-11-21 09:09:25 --> Output Class Initialized
INFO - 2023-11-21 09:09:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:25 --> Input Class Initialized
INFO - 2023-11-21 09:09:25 --> Language Class Initialized
INFO - 2023-11-21 09:09:25 --> Language Class Initialized
INFO - 2023-11-21 09:09:25 --> Config Class Initialized
INFO - 2023-11-21 09:09:25 --> Loader Class Initialized
INFO - 2023-11-21 09:09:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:25 --> Controller Class Initialized
INFO - 2023-11-21 09:09:25 --> Config Class Initialized
INFO - 2023-11-21 09:09:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:25 --> URI Class Initialized
INFO - 2023-11-21 09:09:25 --> Router Class Initialized
INFO - 2023-11-21 09:09:25 --> Output Class Initialized
INFO - 2023-11-21 09:09:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:25 --> Input Class Initialized
INFO - 2023-11-21 09:09:25 --> Language Class Initialized
INFO - 2023-11-21 09:09:25 --> Language Class Initialized
INFO - 2023-11-21 09:09:25 --> Config Class Initialized
INFO - 2023-11-21 09:09:25 --> Loader Class Initialized
INFO - 2023-11-21 09:09:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:25 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:09:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:25 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:25 --> Total execution time: 0.0324
INFO - 2023-11-21 09:09:34 --> Config Class Initialized
INFO - 2023-11-21 09:09:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:34 --> URI Class Initialized
INFO - 2023-11-21 09:09:34 --> Router Class Initialized
INFO - 2023-11-21 09:09:34 --> Output Class Initialized
INFO - 2023-11-21 09:09:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:34 --> Input Class Initialized
INFO - 2023-11-21 09:09:34 --> Language Class Initialized
INFO - 2023-11-21 09:09:34 --> Language Class Initialized
INFO - 2023-11-21 09:09:34 --> Config Class Initialized
INFO - 2023-11-21 09:09:34 --> Loader Class Initialized
INFO - 2023-11-21 09:09:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:34 --> Controller Class Initialized
INFO - 2023-11-21 09:09:34 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:09:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:34 --> Total execution time: 0.0494
INFO - 2023-11-21 09:09:34 --> Config Class Initialized
INFO - 2023-11-21 09:09:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:34 --> URI Class Initialized
INFO - 2023-11-21 09:09:34 --> Router Class Initialized
INFO - 2023-11-21 09:09:34 --> Output Class Initialized
INFO - 2023-11-21 09:09:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:34 --> Input Class Initialized
INFO - 2023-11-21 09:09:34 --> Language Class Initialized
INFO - 2023-11-21 09:09:34 --> Language Class Initialized
INFO - 2023-11-21 09:09:34 --> Config Class Initialized
INFO - 2023-11-21 09:09:34 --> Loader Class Initialized
INFO - 2023-11-21 09:09:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:34 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 09:09:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:34 --> Total execution time: 0.0371
INFO - 2023-11-21 09:09:36 --> Config Class Initialized
INFO - 2023-11-21 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:36 --> URI Class Initialized
INFO - 2023-11-21 09:09:36 --> Router Class Initialized
INFO - 2023-11-21 09:09:36 --> Output Class Initialized
INFO - 2023-11-21 09:09:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:36 --> Input Class Initialized
INFO - 2023-11-21 09:09:36 --> Language Class Initialized
INFO - 2023-11-21 09:09:36 --> Language Class Initialized
INFO - 2023-11-21 09:09:36 --> Config Class Initialized
INFO - 2023-11-21 09:09:36 --> Loader Class Initialized
INFO - 2023-11-21 09:09:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:36 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:36 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:36 --> Total execution time: 0.0353
INFO - 2023-11-21 09:09:36 --> Config Class Initialized
INFO - 2023-11-21 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:36 --> URI Class Initialized
INFO - 2023-11-21 09:09:36 --> Router Class Initialized
INFO - 2023-11-21 09:09:36 --> Output Class Initialized
INFO - 2023-11-21 09:09:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:36 --> Input Class Initialized
INFO - 2023-11-21 09:09:36 --> Language Class Initialized
ERROR - 2023-11-21 09:09:36 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:09:36 --> Config Class Initialized
INFO - 2023-11-21 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:36 --> URI Class Initialized
INFO - 2023-11-21 09:09:36 --> Router Class Initialized
INFO - 2023-11-21 09:09:36 --> Output Class Initialized
INFO - 2023-11-21 09:09:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:36 --> Input Class Initialized
INFO - 2023-11-21 09:09:36 --> Language Class Initialized
INFO - 2023-11-21 09:09:36 --> Language Class Initialized
INFO - 2023-11-21 09:09:36 --> Config Class Initialized
INFO - 2023-11-21 09:09:36 --> Loader Class Initialized
INFO - 2023-11-21 09:09:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:36 --> Controller Class Initialized
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:49 --> URI Class Initialized
INFO - 2023-11-21 09:09:49 --> Router Class Initialized
INFO - 2023-11-21 09:09:49 --> Output Class Initialized
INFO - 2023-11-21 09:09:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:49 --> Input Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Loader Class Initialized
INFO - 2023-11-21 09:09:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:49 --> Controller Class Initialized
INFO - 2023-11-21 09:09:49 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:49 --> URI Class Initialized
INFO - 2023-11-21 09:09:49 --> Router Class Initialized
INFO - 2023-11-21 09:09:49 --> Output Class Initialized
INFO - 2023-11-21 09:09:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:49 --> Input Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Loader Class Initialized
INFO - 2023-11-21 09:09:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:49 --> Controller Class Initialized
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:49 --> URI Class Initialized
INFO - 2023-11-21 09:09:49 --> Router Class Initialized
INFO - 2023-11-21 09:09:49 --> Output Class Initialized
INFO - 2023-11-21 09:09:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:49 --> Input Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Language Class Initialized
INFO - 2023-11-21 09:09:49 --> Config Class Initialized
INFO - 2023-11-21 09:09:49 --> Loader Class Initialized
INFO - 2023-11-21 09:09:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:49 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:09:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:49 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:49 --> Total execution time: 0.0363
INFO - 2023-11-21 09:09:53 --> Config Class Initialized
INFO - 2023-11-21 09:09:53 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:53 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:53 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:53 --> URI Class Initialized
INFO - 2023-11-21 09:09:53 --> Router Class Initialized
INFO - 2023-11-21 09:09:53 --> Output Class Initialized
INFO - 2023-11-21 09:09:53 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:53 --> Input Class Initialized
INFO - 2023-11-21 09:09:53 --> Language Class Initialized
INFO - 2023-11-21 09:09:53 --> Language Class Initialized
INFO - 2023-11-21 09:09:53 --> Config Class Initialized
INFO - 2023-11-21 09:09:53 --> Loader Class Initialized
INFO - 2023-11-21 09:09:53 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:53 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:53 --> Controller Class Initialized
INFO - 2023-11-21 09:09:53 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:09:53 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:53 --> Total execution time: 0.0363
INFO - 2023-11-21 09:09:53 --> Config Class Initialized
INFO - 2023-11-21 09:09:53 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:53 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:53 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:53 --> URI Class Initialized
INFO - 2023-11-21 09:09:53 --> Router Class Initialized
INFO - 2023-11-21 09:09:53 --> Output Class Initialized
INFO - 2023-11-21 09:09:53 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:53 --> Input Class Initialized
INFO - 2023-11-21 09:09:53 --> Language Class Initialized
INFO - 2023-11-21 09:09:53 --> Language Class Initialized
INFO - 2023-11-21 09:09:53 --> Config Class Initialized
INFO - 2023-11-21 09:09:53 --> Loader Class Initialized
INFO - 2023-11-21 09:09:53 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:53 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:53 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:53 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:53 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:53 --> Total execution time: 0.0454
INFO - 2023-11-21 09:09:59 --> Config Class Initialized
INFO - 2023-11-21 09:09:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:09:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:09:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:09:59 --> URI Class Initialized
INFO - 2023-11-21 09:09:59 --> Router Class Initialized
INFO - 2023-11-21 09:09:59 --> Output Class Initialized
INFO - 2023-11-21 09:09:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:09:59 --> Input Class Initialized
INFO - 2023-11-21 09:09:59 --> Language Class Initialized
INFO - 2023-11-21 09:09:59 --> Language Class Initialized
INFO - 2023-11-21 09:09:59 --> Config Class Initialized
INFO - 2023-11-21 09:09:59 --> Loader Class Initialized
INFO - 2023-11-21 09:09:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:09:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:09:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:09:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:09:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:09:59 --> Controller Class Initialized
DEBUG - 2023-11-21 09:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:09:59 --> Final output sent to browser
DEBUG - 2023-11-21 09:09:59 --> Total execution time: 0.0654
INFO - 2023-11-21 09:10:12 --> Config Class Initialized
INFO - 2023-11-21 09:10:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:10:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:10:12 --> Utf8 Class Initialized
INFO - 2023-11-21 09:10:12 --> URI Class Initialized
INFO - 2023-11-21 09:10:12 --> Router Class Initialized
INFO - 2023-11-21 09:10:12 --> Output Class Initialized
INFO - 2023-11-21 09:10:12 --> Security Class Initialized
DEBUG - 2023-11-21 09:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:10:12 --> Input Class Initialized
INFO - 2023-11-21 09:10:12 --> Language Class Initialized
INFO - 2023-11-21 09:10:12 --> Language Class Initialized
INFO - 2023-11-21 09:10:12 --> Config Class Initialized
INFO - 2023-11-21 09:10:12 --> Loader Class Initialized
INFO - 2023-11-21 09:10:12 --> Helper loaded: url_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: file_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: form_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: my_helper
INFO - 2023-11-21 09:10:12 --> Database Driver Class Initialized
INFO - 2023-11-21 09:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:10:12 --> Controller Class Initialized
DEBUG - 2023-11-21 09:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 09:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:10:12 --> Final output sent to browser
DEBUG - 2023-11-21 09:10:12 --> Total execution time: 0.0342
INFO - 2023-11-21 09:10:12 --> Config Class Initialized
INFO - 2023-11-21 09:10:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:10:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:10:12 --> Utf8 Class Initialized
INFO - 2023-11-21 09:10:12 --> URI Class Initialized
INFO - 2023-11-21 09:10:12 --> Router Class Initialized
INFO - 2023-11-21 09:10:12 --> Output Class Initialized
INFO - 2023-11-21 09:10:12 --> Security Class Initialized
DEBUG - 2023-11-21 09:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:10:12 --> Input Class Initialized
INFO - 2023-11-21 09:10:12 --> Language Class Initialized
INFO - 2023-11-21 09:10:12 --> Language Class Initialized
INFO - 2023-11-21 09:10:12 --> Config Class Initialized
INFO - 2023-11-21 09:10:12 --> Loader Class Initialized
INFO - 2023-11-21 09:10:12 --> Helper loaded: url_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: file_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: form_helper
INFO - 2023-11-21 09:10:12 --> Helper loaded: my_helper
INFO - 2023-11-21 09:10:12 --> Database Driver Class Initialized
INFO - 2023-11-21 09:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:10:12 --> Controller Class Initialized
INFO - 2023-11-21 09:10:30 --> Config Class Initialized
INFO - 2023-11-21 09:10:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:10:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:10:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:10:30 --> URI Class Initialized
INFO - 2023-11-21 09:10:30 --> Router Class Initialized
INFO - 2023-11-21 09:10:30 --> Output Class Initialized
INFO - 2023-11-21 09:10:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:10:30 --> Input Class Initialized
INFO - 2023-11-21 09:10:30 --> Language Class Initialized
INFO - 2023-11-21 09:10:30 --> Language Class Initialized
INFO - 2023-11-21 09:10:30 --> Config Class Initialized
INFO - 2023-11-21 09:10:30 --> Loader Class Initialized
INFO - 2023-11-21 09:10:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:10:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:10:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:10:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:10:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:10:30 --> Controller Class Initialized
INFO - 2023-11-21 09:10:30 --> Final output sent to browser
DEBUG - 2023-11-21 09:10:30 --> Total execution time: 0.0845
INFO - 2023-11-21 09:11:00 --> Config Class Initialized
INFO - 2023-11-21 09:11:00 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:11:00 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:11:00 --> Utf8 Class Initialized
INFO - 2023-11-21 09:11:00 --> URI Class Initialized
INFO - 2023-11-21 09:11:00 --> Router Class Initialized
INFO - 2023-11-21 09:11:00 --> Output Class Initialized
INFO - 2023-11-21 09:11:00 --> Security Class Initialized
DEBUG - 2023-11-21 09:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:11:00 --> Input Class Initialized
INFO - 2023-11-21 09:11:00 --> Language Class Initialized
INFO - 2023-11-21 09:11:00 --> Language Class Initialized
INFO - 2023-11-21 09:11:00 --> Config Class Initialized
INFO - 2023-11-21 09:11:00 --> Loader Class Initialized
INFO - 2023-11-21 09:11:00 --> Helper loaded: url_helper
INFO - 2023-11-21 09:11:00 --> Helper loaded: file_helper
INFO - 2023-11-21 09:11:00 --> Helper loaded: form_helper
INFO - 2023-11-21 09:11:00 --> Helper loaded: my_helper
INFO - 2023-11-21 09:11:00 --> Database Driver Class Initialized
INFO - 2023-11-21 09:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:11:00 --> Controller Class Initialized
INFO - 2023-11-21 09:11:00 --> Final output sent to browser
DEBUG - 2023-11-21 09:11:00 --> Total execution time: 0.0391
INFO - 2023-11-21 09:12:06 --> Config Class Initialized
INFO - 2023-11-21 09:12:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:12:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:12:06 --> Utf8 Class Initialized
INFO - 2023-11-21 09:12:06 --> URI Class Initialized
INFO - 2023-11-21 09:12:06 --> Router Class Initialized
INFO - 2023-11-21 09:12:06 --> Output Class Initialized
INFO - 2023-11-21 09:12:06 --> Security Class Initialized
DEBUG - 2023-11-21 09:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:12:06 --> Input Class Initialized
INFO - 2023-11-21 09:12:06 --> Language Class Initialized
INFO - 2023-11-21 09:12:06 --> Language Class Initialized
INFO - 2023-11-21 09:12:06 --> Config Class Initialized
INFO - 2023-11-21 09:12:06 --> Loader Class Initialized
INFO - 2023-11-21 09:12:06 --> Helper loaded: url_helper
INFO - 2023-11-21 09:12:06 --> Helper loaded: file_helper
INFO - 2023-11-21 09:12:06 --> Helper loaded: form_helper
INFO - 2023-11-21 09:12:06 --> Helper loaded: my_helper
INFO - 2023-11-21 09:12:06 --> Database Driver Class Initialized
INFO - 2023-11-21 09:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:12:06 --> Controller Class Initialized
INFO - 2023-11-21 09:12:06 --> Final output sent to browser
DEBUG - 2023-11-21 09:12:06 --> Total execution time: 0.0696
INFO - 2023-11-21 09:12:15 --> Config Class Initialized
INFO - 2023-11-21 09:12:15 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:12:15 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:12:15 --> Utf8 Class Initialized
INFO - 2023-11-21 09:12:15 --> URI Class Initialized
INFO - 2023-11-21 09:12:15 --> Router Class Initialized
INFO - 2023-11-21 09:12:15 --> Output Class Initialized
INFO - 2023-11-21 09:12:15 --> Security Class Initialized
DEBUG - 2023-11-21 09:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:12:15 --> Input Class Initialized
INFO - 2023-11-21 09:12:15 --> Language Class Initialized
INFO - 2023-11-21 09:12:15 --> Language Class Initialized
INFO - 2023-11-21 09:12:15 --> Config Class Initialized
INFO - 2023-11-21 09:12:15 --> Loader Class Initialized
INFO - 2023-11-21 09:12:15 --> Helper loaded: url_helper
INFO - 2023-11-21 09:12:15 --> Helper loaded: file_helper
INFO - 2023-11-21 09:12:15 --> Helper loaded: form_helper
INFO - 2023-11-21 09:12:15 --> Helper loaded: my_helper
INFO - 2023-11-21 09:12:15 --> Database Driver Class Initialized
INFO - 2023-11-21 09:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:12:15 --> Controller Class Initialized
INFO - 2023-11-21 09:12:15 --> Final output sent to browser
DEBUG - 2023-11-21 09:12:15 --> Total execution time: 0.0345
INFO - 2023-11-21 09:17:08 --> Config Class Initialized
INFO - 2023-11-21 09:17:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:17:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:17:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:17:08 --> URI Class Initialized
INFO - 2023-11-21 09:17:08 --> Router Class Initialized
INFO - 2023-11-21 09:17:08 --> Output Class Initialized
INFO - 2023-11-21 09:17:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:17:08 --> Input Class Initialized
INFO - 2023-11-21 09:17:08 --> Language Class Initialized
INFO - 2023-11-21 09:17:08 --> Language Class Initialized
INFO - 2023-11-21 09:17:08 --> Config Class Initialized
INFO - 2023-11-21 09:17:08 --> Loader Class Initialized
INFO - 2023-11-21 09:17:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:17:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:17:08 --> Controller Class Initialized
DEBUG - 2023-11-21 09:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-21 09:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:17:08 --> Final output sent to browser
DEBUG - 2023-11-21 09:17:08 --> Total execution time: 0.0784
INFO - 2023-11-21 09:17:08 --> Config Class Initialized
INFO - 2023-11-21 09:17:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:17:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:17:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:17:08 --> URI Class Initialized
INFO - 2023-11-21 09:17:08 --> Router Class Initialized
INFO - 2023-11-21 09:17:08 --> Output Class Initialized
INFO - 2023-11-21 09:17:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:17:08 --> Input Class Initialized
INFO - 2023-11-21 09:17:08 --> Language Class Initialized
ERROR - 2023-11-21 09:17:08 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:17:08 --> Config Class Initialized
INFO - 2023-11-21 09:17:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:17:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:17:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:17:08 --> URI Class Initialized
INFO - 2023-11-21 09:17:08 --> Router Class Initialized
INFO - 2023-11-21 09:17:08 --> Output Class Initialized
INFO - 2023-11-21 09:17:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:17:08 --> Input Class Initialized
INFO - 2023-11-21 09:17:08 --> Language Class Initialized
INFO - 2023-11-21 09:17:08 --> Language Class Initialized
INFO - 2023-11-21 09:17:08 --> Config Class Initialized
INFO - 2023-11-21 09:17:08 --> Loader Class Initialized
INFO - 2023-11-21 09:17:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:17:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:17:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:17:08 --> Controller Class Initialized
INFO - 2023-11-21 09:17:32 --> Config Class Initialized
INFO - 2023-11-21 09:17:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:17:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:17:32 --> Utf8 Class Initialized
INFO - 2023-11-21 09:17:32 --> URI Class Initialized
INFO - 2023-11-21 09:17:32 --> Router Class Initialized
INFO - 2023-11-21 09:17:32 --> Output Class Initialized
INFO - 2023-11-21 09:17:32 --> Security Class Initialized
DEBUG - 2023-11-21 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:17:32 --> Input Class Initialized
INFO - 2023-11-21 09:17:32 --> Language Class Initialized
INFO - 2023-11-21 09:17:32 --> Language Class Initialized
INFO - 2023-11-21 09:17:32 --> Config Class Initialized
INFO - 2023-11-21 09:17:32 --> Loader Class Initialized
INFO - 2023-11-21 09:17:32 --> Helper loaded: url_helper
INFO - 2023-11-21 09:17:32 --> Helper loaded: file_helper
INFO - 2023-11-21 09:17:32 --> Helper loaded: form_helper
INFO - 2023-11-21 09:17:32 --> Helper loaded: my_helper
INFO - 2023-11-21 09:17:32 --> Database Driver Class Initialized
INFO - 2023-11-21 09:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:17:32 --> Controller Class Initialized
INFO - 2023-11-21 09:17:32 --> Final output sent to browser
DEBUG - 2023-11-21 09:17:32 --> Total execution time: 0.0749
INFO - 2023-11-21 09:17:45 --> Config Class Initialized
INFO - 2023-11-21 09:17:45 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:17:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:17:45 --> Utf8 Class Initialized
INFO - 2023-11-21 09:17:45 --> URI Class Initialized
INFO - 2023-11-21 09:17:45 --> Router Class Initialized
INFO - 2023-11-21 09:17:45 --> Output Class Initialized
INFO - 2023-11-21 09:17:45 --> Security Class Initialized
DEBUG - 2023-11-21 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:17:45 --> Input Class Initialized
INFO - 2023-11-21 09:17:45 --> Language Class Initialized
INFO - 2023-11-21 09:17:45 --> Language Class Initialized
INFO - 2023-11-21 09:17:45 --> Config Class Initialized
INFO - 2023-11-21 09:17:45 --> Loader Class Initialized
INFO - 2023-11-21 09:17:45 --> Helper loaded: url_helper
INFO - 2023-11-21 09:17:45 --> Helper loaded: file_helper
INFO - 2023-11-21 09:17:45 --> Helper loaded: form_helper
INFO - 2023-11-21 09:17:45 --> Helper loaded: my_helper
INFO - 2023-11-21 09:17:45 --> Database Driver Class Initialized
INFO - 2023-11-21 09:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:17:45 --> Controller Class Initialized
INFO - 2023-11-21 09:17:45 --> Final output sent to browser
DEBUG - 2023-11-21 09:17:45 --> Total execution time: 0.0441
INFO - 2023-11-21 09:18:43 --> Config Class Initialized
INFO - 2023-11-21 09:18:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:18:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:18:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:18:43 --> URI Class Initialized
INFO - 2023-11-21 09:18:43 --> Router Class Initialized
INFO - 2023-11-21 09:18:43 --> Output Class Initialized
INFO - 2023-11-21 09:18:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:18:43 --> Input Class Initialized
INFO - 2023-11-21 09:18:43 --> Language Class Initialized
INFO - 2023-11-21 09:18:43 --> Language Class Initialized
INFO - 2023-11-21 09:18:43 --> Config Class Initialized
INFO - 2023-11-21 09:18:43 --> Loader Class Initialized
INFO - 2023-11-21 09:18:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:18:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:18:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:18:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:18:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:18:43 --> Controller Class Initialized
INFO - 2023-11-21 09:18:43 --> Final output sent to browser
DEBUG - 2023-11-21 09:18:43 --> Total execution time: 0.0445
INFO - 2023-11-21 09:18:45 --> Config Class Initialized
INFO - 2023-11-21 09:18:45 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:18:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:18:45 --> Utf8 Class Initialized
INFO - 2023-11-21 09:18:45 --> URI Class Initialized
INFO - 2023-11-21 09:18:45 --> Router Class Initialized
INFO - 2023-11-21 09:18:45 --> Output Class Initialized
INFO - 2023-11-21 09:18:45 --> Security Class Initialized
DEBUG - 2023-11-21 09:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:18:45 --> Input Class Initialized
INFO - 2023-11-21 09:18:45 --> Language Class Initialized
INFO - 2023-11-21 09:18:45 --> Language Class Initialized
INFO - 2023-11-21 09:18:45 --> Config Class Initialized
INFO - 2023-11-21 09:18:45 --> Loader Class Initialized
INFO - 2023-11-21 09:18:45 --> Helper loaded: url_helper
INFO - 2023-11-21 09:18:45 --> Helper loaded: file_helper
INFO - 2023-11-21 09:18:45 --> Helper loaded: form_helper
INFO - 2023-11-21 09:18:45 --> Helper loaded: my_helper
INFO - 2023-11-21 09:18:45 --> Database Driver Class Initialized
INFO - 2023-11-21 09:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:18:45 --> Controller Class Initialized
INFO - 2023-11-21 09:18:45 --> Final output sent to browser
DEBUG - 2023-11-21 09:18:45 --> Total execution time: 0.0371
INFO - 2023-11-21 09:18:51 --> Config Class Initialized
INFO - 2023-11-21 09:18:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:18:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:18:51 --> Utf8 Class Initialized
INFO - 2023-11-21 09:18:51 --> URI Class Initialized
INFO - 2023-11-21 09:18:51 --> Router Class Initialized
INFO - 2023-11-21 09:18:51 --> Output Class Initialized
INFO - 2023-11-21 09:18:51 --> Security Class Initialized
DEBUG - 2023-11-21 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:18:51 --> Input Class Initialized
INFO - 2023-11-21 09:18:51 --> Language Class Initialized
INFO - 2023-11-21 09:18:51 --> Language Class Initialized
INFO - 2023-11-21 09:18:51 --> Config Class Initialized
INFO - 2023-11-21 09:18:51 --> Loader Class Initialized
INFO - 2023-11-21 09:18:51 --> Helper loaded: url_helper
INFO - 2023-11-21 09:18:51 --> Helper loaded: file_helper
INFO - 2023-11-21 09:18:51 --> Helper loaded: form_helper
INFO - 2023-11-21 09:18:51 --> Helper loaded: my_helper
INFO - 2023-11-21 09:18:51 --> Database Driver Class Initialized
INFO - 2023-11-21 09:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:18:51 --> Controller Class Initialized
INFO - 2023-11-21 09:18:51 --> Final output sent to browser
DEBUG - 2023-11-21 09:18:51 --> Total execution time: 0.0751
INFO - 2023-11-21 09:18:57 --> Config Class Initialized
INFO - 2023-11-21 09:18:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:18:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:18:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:18:57 --> URI Class Initialized
INFO - 2023-11-21 09:18:57 --> Router Class Initialized
INFO - 2023-11-21 09:18:57 --> Output Class Initialized
INFO - 2023-11-21 09:18:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:18:57 --> Input Class Initialized
INFO - 2023-11-21 09:18:57 --> Language Class Initialized
INFO - 2023-11-21 09:18:57 --> Language Class Initialized
INFO - 2023-11-21 09:18:57 --> Config Class Initialized
INFO - 2023-11-21 09:18:57 --> Loader Class Initialized
INFO - 2023-11-21 09:18:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:18:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:18:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:18:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:18:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:18:57 --> Controller Class Initialized
DEBUG - 2023-11-21 09:18:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:18:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:18:57 --> Final output sent to browser
DEBUG - 2023-11-21 09:18:57 --> Total execution time: 0.0383
INFO - 2023-11-21 09:19:09 --> Config Class Initialized
INFO - 2023-11-21 09:19:09 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:09 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:09 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:09 --> URI Class Initialized
INFO - 2023-11-21 09:19:09 --> Router Class Initialized
INFO - 2023-11-21 09:19:09 --> Output Class Initialized
INFO - 2023-11-21 09:19:09 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:09 --> Input Class Initialized
INFO - 2023-11-21 09:19:09 --> Language Class Initialized
INFO - 2023-11-21 09:19:09 --> Language Class Initialized
INFO - 2023-11-21 09:19:09 --> Config Class Initialized
INFO - 2023-11-21 09:19:09 --> Loader Class Initialized
INFO - 2023-11-21 09:19:09 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:09 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:09 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:09 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:09 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:09 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-21 09:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:09 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:09 --> Total execution time: 0.0418
INFO - 2023-11-21 09:19:11 --> Config Class Initialized
INFO - 2023-11-21 09:19:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:11 --> URI Class Initialized
INFO - 2023-11-21 09:19:11 --> Router Class Initialized
INFO - 2023-11-21 09:19:11 --> Output Class Initialized
INFO - 2023-11-21 09:19:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:12 --> Input Class Initialized
INFO - 2023-11-21 09:19:12 --> Language Class Initialized
INFO - 2023-11-21 09:19:12 --> Language Class Initialized
INFO - 2023-11-21 09:19:12 --> Config Class Initialized
INFO - 2023-11-21 09:19:12 --> Loader Class Initialized
INFO - 2023-11-21 09:19:12 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:12 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:12 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:12 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:12 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:12 --> Controller Class Initialized
INFO - 2023-11-21 09:19:12 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:12 --> Total execution time: 0.0387
INFO - 2023-11-21 09:19:31 --> Config Class Initialized
INFO - 2023-11-21 09:19:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:31 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:31 --> URI Class Initialized
INFO - 2023-11-21 09:19:31 --> Router Class Initialized
INFO - 2023-11-21 09:19:31 --> Output Class Initialized
INFO - 2023-11-21 09:19:31 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:31 --> Input Class Initialized
INFO - 2023-11-21 09:19:31 --> Language Class Initialized
INFO - 2023-11-21 09:19:31 --> Language Class Initialized
INFO - 2023-11-21 09:19:31 --> Config Class Initialized
INFO - 2023-11-21 09:19:31 --> Loader Class Initialized
INFO - 2023-11-21 09:19:31 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:31 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:31 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:31 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:31 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:31 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:19:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:31 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:31 --> Total execution time: 0.0375
INFO - 2023-11-21 09:19:32 --> Config Class Initialized
INFO - 2023-11-21 09:19:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:32 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:32 --> URI Class Initialized
INFO - 2023-11-21 09:19:32 --> Router Class Initialized
INFO - 2023-11-21 09:19:32 --> Output Class Initialized
INFO - 2023-11-21 09:19:32 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:32 --> Input Class Initialized
INFO - 2023-11-21 09:19:32 --> Language Class Initialized
INFO - 2023-11-21 09:19:32 --> Language Class Initialized
INFO - 2023-11-21 09:19:32 --> Config Class Initialized
INFO - 2023-11-21 09:19:32 --> Loader Class Initialized
INFO - 2023-11-21 09:19:32 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:32 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:32 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:32 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:32 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:32 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-21 09:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:32 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:32 --> Total execution time: 0.0421
INFO - 2023-11-21 09:19:33 --> Config Class Initialized
INFO - 2023-11-21 09:19:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:33 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:33 --> URI Class Initialized
INFO - 2023-11-21 09:19:33 --> Router Class Initialized
INFO - 2023-11-21 09:19:33 --> Output Class Initialized
INFO - 2023-11-21 09:19:33 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:33 --> Input Class Initialized
INFO - 2023-11-21 09:19:33 --> Language Class Initialized
INFO - 2023-11-21 09:19:33 --> Language Class Initialized
INFO - 2023-11-21 09:19:33 --> Config Class Initialized
INFO - 2023-11-21 09:19:33 --> Loader Class Initialized
INFO - 2023-11-21 09:19:33 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:33 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:33 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:33 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:33 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:33 --> Controller Class Initialized
INFO - 2023-11-21 09:19:33 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:33 --> Total execution time: 0.0320
INFO - 2023-11-21 09:19:44 --> Config Class Initialized
INFO - 2023-11-21 09:19:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:44 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:44 --> URI Class Initialized
INFO - 2023-11-21 09:19:44 --> Router Class Initialized
INFO - 2023-11-21 09:19:44 --> Output Class Initialized
INFO - 2023-11-21 09:19:44 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:44 --> Input Class Initialized
INFO - 2023-11-21 09:19:44 --> Language Class Initialized
INFO - 2023-11-21 09:19:44 --> Language Class Initialized
INFO - 2023-11-21 09:19:44 --> Config Class Initialized
INFO - 2023-11-21 09:19:44 --> Loader Class Initialized
INFO - 2023-11-21 09:19:44 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:44 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:44 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:44 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:44 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:44 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:19:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:44 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:44 --> Total execution time: 0.0391
INFO - 2023-11-21 09:19:46 --> Config Class Initialized
INFO - 2023-11-21 09:19:46 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:46 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:46 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:46 --> URI Class Initialized
INFO - 2023-11-21 09:19:46 --> Router Class Initialized
INFO - 2023-11-21 09:19:46 --> Output Class Initialized
INFO - 2023-11-21 09:19:46 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:46 --> Input Class Initialized
INFO - 2023-11-21 09:19:46 --> Language Class Initialized
INFO - 2023-11-21 09:19:46 --> Language Class Initialized
INFO - 2023-11-21 09:19:46 --> Config Class Initialized
INFO - 2023-11-21 09:19:46 --> Loader Class Initialized
INFO - 2023-11-21 09:19:46 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:46 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:46 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 09:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:46 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:46 --> Total execution time: 0.0372
INFO - 2023-11-21 09:19:46 --> Config Class Initialized
INFO - 2023-11-21 09:19:46 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:46 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:46 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:46 --> URI Class Initialized
INFO - 2023-11-21 09:19:46 --> Router Class Initialized
INFO - 2023-11-21 09:19:46 --> Output Class Initialized
INFO - 2023-11-21 09:19:46 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:46 --> Input Class Initialized
INFO - 2023-11-21 09:19:46 --> Language Class Initialized
INFO - 2023-11-21 09:19:46 --> Language Class Initialized
INFO - 2023-11-21 09:19:46 --> Config Class Initialized
INFO - 2023-11-21 09:19:46 --> Loader Class Initialized
INFO - 2023-11-21 09:19:46 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:46 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:46 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:46 --> Controller Class Initialized
INFO - 2023-11-21 09:19:48 --> Config Class Initialized
INFO - 2023-11-21 09:19:48 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:48 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:48 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:48 --> URI Class Initialized
INFO - 2023-11-21 09:19:48 --> Router Class Initialized
INFO - 2023-11-21 09:19:48 --> Output Class Initialized
INFO - 2023-11-21 09:19:48 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:48 --> Input Class Initialized
INFO - 2023-11-21 09:19:48 --> Language Class Initialized
INFO - 2023-11-21 09:19:48 --> Language Class Initialized
INFO - 2023-11-21 09:19:48 --> Config Class Initialized
INFO - 2023-11-21 09:19:48 --> Loader Class Initialized
INFO - 2023-11-21 09:19:48 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:48 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:48 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:48 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:48 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:48 --> Controller Class Initialized
INFO - 2023-11-21 09:19:48 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:48 --> Total execution time: 0.0368
INFO - 2023-11-21 09:19:59 --> Config Class Initialized
INFO - 2023-11-21 09:19:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:19:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:19:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:19:59 --> URI Class Initialized
INFO - 2023-11-21 09:19:59 --> Router Class Initialized
INFO - 2023-11-21 09:19:59 --> Output Class Initialized
INFO - 2023-11-21 09:19:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:19:59 --> Input Class Initialized
INFO - 2023-11-21 09:19:59 --> Language Class Initialized
INFO - 2023-11-21 09:19:59 --> Language Class Initialized
INFO - 2023-11-21 09:19:59 --> Config Class Initialized
INFO - 2023-11-21 09:19:59 --> Loader Class Initialized
INFO - 2023-11-21 09:19:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:19:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:19:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:19:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:19:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:19:59 --> Controller Class Initialized
DEBUG - 2023-11-21 09:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:19:59 --> Final output sent to browser
DEBUG - 2023-11-21 09:19:59 --> Total execution time: 0.0307
INFO - 2023-11-21 09:20:01 --> Config Class Initialized
INFO - 2023-11-21 09:20:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:01 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:01 --> URI Class Initialized
INFO - 2023-11-21 09:20:01 --> Router Class Initialized
INFO - 2023-11-21 09:20:01 --> Output Class Initialized
INFO - 2023-11-21 09:20:01 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:01 --> Input Class Initialized
INFO - 2023-11-21 09:20:01 --> Language Class Initialized
INFO - 2023-11-21 09:20:01 --> Language Class Initialized
INFO - 2023-11-21 09:20:01 --> Config Class Initialized
INFO - 2023-11-21 09:20:01 --> Loader Class Initialized
INFO - 2023-11-21 09:20:01 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:01 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:01 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:01 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:01 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:01 --> Controller Class Initialized
DEBUG - 2023-11-21 09:20:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-11-21 09:20:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:20:01 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:01 --> Total execution time: 0.1257
INFO - 2023-11-21 09:20:02 --> Config Class Initialized
INFO - 2023-11-21 09:20:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:02 --> URI Class Initialized
INFO - 2023-11-21 09:20:02 --> Router Class Initialized
INFO - 2023-11-21 09:20:02 --> Output Class Initialized
INFO - 2023-11-21 09:20:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:02 --> Input Class Initialized
INFO - 2023-11-21 09:20:02 --> Language Class Initialized
INFO - 2023-11-21 09:20:02 --> Language Class Initialized
INFO - 2023-11-21 09:20:02 --> Config Class Initialized
INFO - 2023-11-21 09:20:02 --> Loader Class Initialized
INFO - 2023-11-21 09:20:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:02 --> Controller Class Initialized
INFO - 2023-11-21 09:20:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:02 --> Total execution time: 0.0436
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:13 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:13 --> URI Class Initialized
INFO - 2023-11-21 09:20:13 --> Router Class Initialized
INFO - 2023-11-21 09:20:13 --> Output Class Initialized
INFO - 2023-11-21 09:20:13 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:13 --> Input Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Loader Class Initialized
INFO - 2023-11-21 09:20:13 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:13 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:13 --> Controller Class Initialized
INFO - 2023-11-21 09:20:13 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:13 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:13 --> URI Class Initialized
INFO - 2023-11-21 09:20:13 --> Router Class Initialized
INFO - 2023-11-21 09:20:13 --> Output Class Initialized
INFO - 2023-11-21 09:20:13 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:13 --> Input Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Loader Class Initialized
INFO - 2023-11-21 09:20:13 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:13 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:13 --> Controller Class Initialized
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:13 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:13 --> URI Class Initialized
INFO - 2023-11-21 09:20:13 --> Router Class Initialized
INFO - 2023-11-21 09:20:13 --> Output Class Initialized
INFO - 2023-11-21 09:20:13 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:13 --> Input Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Language Class Initialized
INFO - 2023-11-21 09:20:13 --> Config Class Initialized
INFO - 2023-11-21 09:20:13 --> Loader Class Initialized
INFO - 2023-11-21 09:20:13 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:13 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:13 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:13 --> Controller Class Initialized
DEBUG - 2023-11-21 09:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:20:13 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:13 --> Total execution time: 0.0355
INFO - 2023-11-21 09:20:26 --> Config Class Initialized
INFO - 2023-11-21 09:20:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:26 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:26 --> URI Class Initialized
INFO - 2023-11-21 09:20:26 --> Router Class Initialized
INFO - 2023-11-21 09:20:26 --> Output Class Initialized
INFO - 2023-11-21 09:20:26 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:26 --> Input Class Initialized
INFO - 2023-11-21 09:20:26 --> Language Class Initialized
INFO - 2023-11-21 09:20:26 --> Language Class Initialized
INFO - 2023-11-21 09:20:26 --> Config Class Initialized
INFO - 2023-11-21 09:20:26 --> Loader Class Initialized
INFO - 2023-11-21 09:20:26 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:26 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:26 --> Controller Class Initialized
INFO - 2023-11-21 09:20:26 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:20:26 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:26 --> Total execution time: 0.0328
INFO - 2023-11-21 09:20:26 --> Config Class Initialized
INFO - 2023-11-21 09:20:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:26 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:26 --> URI Class Initialized
INFO - 2023-11-21 09:20:26 --> Router Class Initialized
INFO - 2023-11-21 09:20:26 --> Output Class Initialized
INFO - 2023-11-21 09:20:26 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:26 --> Input Class Initialized
INFO - 2023-11-21 09:20:26 --> Language Class Initialized
INFO - 2023-11-21 09:20:26 --> Language Class Initialized
INFO - 2023-11-21 09:20:26 --> Config Class Initialized
INFO - 2023-11-21 09:20:26 --> Loader Class Initialized
INFO - 2023-11-21 09:20:26 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:26 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:26 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:26 --> Controller Class Initialized
DEBUG - 2023-11-21 09:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:20:26 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:26 --> Total execution time: 0.0436
INFO - 2023-11-21 09:20:31 --> Config Class Initialized
INFO - 2023-11-21 09:20:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:31 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:31 --> URI Class Initialized
INFO - 2023-11-21 09:20:31 --> Router Class Initialized
INFO - 2023-11-21 09:20:31 --> Output Class Initialized
INFO - 2023-11-21 09:20:31 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:31 --> Input Class Initialized
INFO - 2023-11-21 09:20:31 --> Language Class Initialized
INFO - 2023-11-21 09:20:31 --> Language Class Initialized
INFO - 2023-11-21 09:20:31 --> Config Class Initialized
INFO - 2023-11-21 09:20:31 --> Loader Class Initialized
INFO - 2023-11-21 09:20:31 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:31 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:31 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:31 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:31 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:31 --> Controller Class Initialized
DEBUG - 2023-11-21 09:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:20:31 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:31 --> Total execution time: 0.0431
INFO - 2023-11-21 09:20:59 --> Config Class Initialized
INFO - 2023-11-21 09:20:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:59 --> URI Class Initialized
INFO - 2023-11-21 09:20:59 --> Router Class Initialized
INFO - 2023-11-21 09:20:59 --> Output Class Initialized
INFO - 2023-11-21 09:20:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:59 --> Input Class Initialized
INFO - 2023-11-21 09:20:59 --> Language Class Initialized
INFO - 2023-11-21 09:20:59 --> Language Class Initialized
INFO - 2023-11-21 09:20:59 --> Config Class Initialized
INFO - 2023-11-21 09:20:59 --> Loader Class Initialized
INFO - 2023-11-21 09:20:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:59 --> Controller Class Initialized
DEBUG - 2023-11-21 09:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-11-21 09:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:20:59 --> Final output sent to browser
DEBUG - 2023-11-21 09:20:59 --> Total execution time: 0.0759
INFO - 2023-11-21 09:20:59 --> Config Class Initialized
INFO - 2023-11-21 09:20:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:20:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:20:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:20:59 --> URI Class Initialized
INFO - 2023-11-21 09:20:59 --> Router Class Initialized
INFO - 2023-11-21 09:20:59 --> Output Class Initialized
INFO - 2023-11-21 09:20:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:20:59 --> Input Class Initialized
INFO - 2023-11-21 09:20:59 --> Language Class Initialized
INFO - 2023-11-21 09:20:59 --> Language Class Initialized
INFO - 2023-11-21 09:20:59 --> Config Class Initialized
INFO - 2023-11-21 09:20:59 --> Loader Class Initialized
INFO - 2023-11-21 09:20:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:20:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:20:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:20:59 --> Controller Class Initialized
INFO - 2023-11-21 09:21:02 --> Config Class Initialized
INFO - 2023-11-21 09:21:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:02 --> URI Class Initialized
INFO - 2023-11-21 09:21:02 --> Router Class Initialized
INFO - 2023-11-21 09:21:02 --> Output Class Initialized
INFO - 2023-11-21 09:21:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:02 --> Input Class Initialized
INFO - 2023-11-21 09:21:02 --> Language Class Initialized
INFO - 2023-11-21 09:21:02 --> Language Class Initialized
INFO - 2023-11-21 09:21:02 --> Config Class Initialized
INFO - 2023-11-21 09:21:02 --> Loader Class Initialized
INFO - 2023-11-21 09:21:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:02 --> Controller Class Initialized
INFO - 2023-11-21 09:21:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:02 --> Total execution time: 0.4150
INFO - 2023-11-21 09:21:03 --> Config Class Initialized
INFO - 2023-11-21 09:21:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:03 --> URI Class Initialized
INFO - 2023-11-21 09:21:03 --> Router Class Initialized
INFO - 2023-11-21 09:21:03 --> Output Class Initialized
INFO - 2023-11-21 09:21:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:03 --> Input Class Initialized
INFO - 2023-11-21 09:21:03 --> Language Class Initialized
INFO - 2023-11-21 09:21:03 --> Language Class Initialized
INFO - 2023-11-21 09:21:03 --> Config Class Initialized
INFO - 2023-11-21 09:21:03 --> Loader Class Initialized
INFO - 2023-11-21 09:21:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:03 --> Controller Class Initialized
INFO - 2023-11-21 09:21:03 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:03 --> Total execution time: 0.0604
INFO - 2023-11-21 09:21:04 --> Config Class Initialized
INFO - 2023-11-21 09:21:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:04 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:04 --> URI Class Initialized
INFO - 2023-11-21 09:21:04 --> Router Class Initialized
INFO - 2023-11-21 09:21:04 --> Output Class Initialized
INFO - 2023-11-21 09:21:04 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:04 --> Input Class Initialized
INFO - 2023-11-21 09:21:04 --> Language Class Initialized
INFO - 2023-11-21 09:21:04 --> Language Class Initialized
INFO - 2023-11-21 09:21:04 --> Config Class Initialized
INFO - 2023-11-21 09:21:04 --> Loader Class Initialized
INFO - 2023-11-21 09:21:04 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:04 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:04 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:04 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:04 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:04 --> Controller Class Initialized
INFO - 2023-11-21 09:21:04 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:04 --> Total execution time: 0.0473
INFO - 2023-11-21 09:21:05 --> Config Class Initialized
INFO - 2023-11-21 09:21:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:05 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:05 --> URI Class Initialized
INFO - 2023-11-21 09:21:05 --> Router Class Initialized
INFO - 2023-11-21 09:21:05 --> Output Class Initialized
INFO - 2023-11-21 09:21:05 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:05 --> Input Class Initialized
INFO - 2023-11-21 09:21:05 --> Language Class Initialized
INFO - 2023-11-21 09:21:05 --> Language Class Initialized
INFO - 2023-11-21 09:21:05 --> Config Class Initialized
INFO - 2023-11-21 09:21:05 --> Loader Class Initialized
INFO - 2023-11-21 09:21:05 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:05 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:05 --> Controller Class Initialized
INFO - 2023-11-21 09:21:05 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:05 --> Total execution time: 0.0468
INFO - 2023-11-21 09:21:05 --> Config Class Initialized
INFO - 2023-11-21 09:21:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:05 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:05 --> URI Class Initialized
INFO - 2023-11-21 09:21:05 --> Router Class Initialized
INFO - 2023-11-21 09:21:05 --> Output Class Initialized
INFO - 2023-11-21 09:21:05 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:05 --> Input Class Initialized
INFO - 2023-11-21 09:21:05 --> Language Class Initialized
INFO - 2023-11-21 09:21:05 --> Language Class Initialized
INFO - 2023-11-21 09:21:05 --> Config Class Initialized
INFO - 2023-11-21 09:21:05 --> Loader Class Initialized
INFO - 2023-11-21 09:21:05 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:05 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:05 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:05 --> Controller Class Initialized
INFO - 2023-11-21 09:21:05 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:05 --> Total execution time: 0.0579
INFO - 2023-11-21 09:21:06 --> Config Class Initialized
INFO - 2023-11-21 09:21:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:06 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:06 --> URI Class Initialized
INFO - 2023-11-21 09:21:06 --> Router Class Initialized
INFO - 2023-11-21 09:21:06 --> Output Class Initialized
INFO - 2023-11-21 09:21:06 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:06 --> Input Class Initialized
INFO - 2023-11-21 09:21:06 --> Language Class Initialized
INFO - 2023-11-21 09:21:06 --> Language Class Initialized
INFO - 2023-11-21 09:21:06 --> Config Class Initialized
INFO - 2023-11-21 09:21:06 --> Loader Class Initialized
INFO - 2023-11-21 09:21:06 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:06 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:06 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:06 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:06 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:06 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:06 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:06 --> Total execution time: 0.0331
INFO - 2023-11-21 09:21:10 --> Config Class Initialized
INFO - 2023-11-21 09:21:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:10 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:10 --> URI Class Initialized
INFO - 2023-11-21 09:21:10 --> Router Class Initialized
INFO - 2023-11-21 09:21:10 --> Output Class Initialized
INFO - 2023-11-21 09:21:10 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:10 --> Input Class Initialized
INFO - 2023-11-21 09:21:10 --> Language Class Initialized
INFO - 2023-11-21 09:21:10 --> Language Class Initialized
INFO - 2023-11-21 09:21:10 --> Config Class Initialized
INFO - 2023-11-21 09:21:10 --> Loader Class Initialized
INFO - 2023-11-21 09:21:10 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:10 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:10 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-11-21 09:21:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:10 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:10 --> Total execution time: 0.1548
INFO - 2023-11-21 09:21:10 --> Config Class Initialized
INFO - 2023-11-21 09:21:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:10 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:10 --> URI Class Initialized
INFO - 2023-11-21 09:21:10 --> Router Class Initialized
INFO - 2023-11-21 09:21:10 --> Output Class Initialized
INFO - 2023-11-21 09:21:10 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:10 --> Input Class Initialized
INFO - 2023-11-21 09:21:10 --> Language Class Initialized
INFO - 2023-11-21 09:21:10 --> Language Class Initialized
INFO - 2023-11-21 09:21:10 --> Config Class Initialized
INFO - 2023-11-21 09:21:10 --> Loader Class Initialized
INFO - 2023-11-21 09:21:10 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:10 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:10 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:11 --> Controller Class Initialized
INFO - 2023-11-21 09:21:14 --> Config Class Initialized
INFO - 2023-11-21 09:21:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:14 --> URI Class Initialized
INFO - 2023-11-21 09:21:14 --> Router Class Initialized
INFO - 2023-11-21 09:21:14 --> Output Class Initialized
INFO - 2023-11-21 09:21:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:14 --> Input Class Initialized
INFO - 2023-11-21 09:21:14 --> Language Class Initialized
INFO - 2023-11-21 09:21:14 --> Language Class Initialized
INFO - 2023-11-21 09:21:14 --> Config Class Initialized
INFO - 2023-11-21 09:21:14 --> Loader Class Initialized
INFO - 2023-11-21 09:21:14 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:14 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:14 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:14 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:14 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:14 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:14 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:14 --> Total execution time: 0.0304
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:19 --> URI Class Initialized
INFO - 2023-11-21 09:21:19 --> Router Class Initialized
INFO - 2023-11-21 09:21:19 --> Output Class Initialized
INFO - 2023-11-21 09:21:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:19 --> Input Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Loader Class Initialized
INFO - 2023-11-21 09:21:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:19 --> Controller Class Initialized
INFO - 2023-11-21 09:21:19 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:19 --> URI Class Initialized
INFO - 2023-11-21 09:21:19 --> Router Class Initialized
INFO - 2023-11-21 09:21:19 --> Output Class Initialized
INFO - 2023-11-21 09:21:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:19 --> Input Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Loader Class Initialized
INFO - 2023-11-21 09:21:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:19 --> Controller Class Initialized
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:19 --> URI Class Initialized
INFO - 2023-11-21 09:21:19 --> Router Class Initialized
INFO - 2023-11-21 09:21:19 --> Output Class Initialized
INFO - 2023-11-21 09:21:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:19 --> Input Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Language Class Initialized
INFO - 2023-11-21 09:21:19 --> Config Class Initialized
INFO - 2023-11-21 09:21:19 --> Loader Class Initialized
INFO - 2023-11-21 09:21:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:19 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:21:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:19 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:19 --> Total execution time: 0.0386
INFO - 2023-11-21 09:21:25 --> Config Class Initialized
INFO - 2023-11-21 09:21:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:25 --> URI Class Initialized
INFO - 2023-11-21 09:21:25 --> Router Class Initialized
INFO - 2023-11-21 09:21:25 --> Output Class Initialized
INFO - 2023-11-21 09:21:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:25 --> Input Class Initialized
INFO - 2023-11-21 09:21:25 --> Language Class Initialized
INFO - 2023-11-21 09:21:25 --> Language Class Initialized
INFO - 2023-11-21 09:21:25 --> Config Class Initialized
INFO - 2023-11-21 09:21:25 --> Loader Class Initialized
INFO - 2023-11-21 09:21:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:25 --> Controller Class Initialized
INFO - 2023-11-21 09:21:25 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:21:25 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:25 --> Total execution time: 0.0341
INFO - 2023-11-21 09:21:25 --> Config Class Initialized
INFO - 2023-11-21 09:21:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:25 --> URI Class Initialized
INFO - 2023-11-21 09:21:25 --> Router Class Initialized
INFO - 2023-11-21 09:21:25 --> Output Class Initialized
INFO - 2023-11-21 09:21:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:25 --> Input Class Initialized
INFO - 2023-11-21 09:21:25 --> Language Class Initialized
INFO - 2023-11-21 09:21:25 --> Language Class Initialized
INFO - 2023-11-21 09:21:25 --> Config Class Initialized
INFO - 2023-11-21 09:21:25 --> Loader Class Initialized
INFO - 2023-11-21 09:21:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:25 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 09:21:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:25 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:25 --> Total execution time: 0.0433
INFO - 2023-11-21 09:21:30 --> Config Class Initialized
INFO - 2023-11-21 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:30 --> URI Class Initialized
INFO - 2023-11-21 09:21:30 --> Router Class Initialized
INFO - 2023-11-21 09:21:30 --> Output Class Initialized
INFO - 2023-11-21 09:21:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:30 --> Input Class Initialized
INFO - 2023-11-21 09:21:30 --> Language Class Initialized
INFO - 2023-11-21 09:21:30 --> Language Class Initialized
INFO - 2023-11-21 09:21:30 --> Config Class Initialized
INFO - 2023-11-21 09:21:30 --> Loader Class Initialized
INFO - 2023-11-21 09:21:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:30 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-21 09:21:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:30 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:30 --> Total execution time: 0.0671
INFO - 2023-11-21 09:21:30 --> Config Class Initialized
INFO - 2023-11-21 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:30 --> URI Class Initialized
INFO - 2023-11-21 09:21:30 --> Router Class Initialized
INFO - 2023-11-21 09:21:30 --> Output Class Initialized
INFO - 2023-11-21 09:21:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:30 --> Input Class Initialized
INFO - 2023-11-21 09:21:30 --> Language Class Initialized
ERROR - 2023-11-21 09:21:30 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:21:30 --> Config Class Initialized
INFO - 2023-11-21 09:21:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:30 --> URI Class Initialized
INFO - 2023-11-21 09:21:30 --> Router Class Initialized
INFO - 2023-11-21 09:21:30 --> Output Class Initialized
INFO - 2023-11-21 09:21:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:30 --> Input Class Initialized
INFO - 2023-11-21 09:21:30 --> Language Class Initialized
INFO - 2023-11-21 09:21:30 --> Language Class Initialized
INFO - 2023-11-21 09:21:30 --> Config Class Initialized
INFO - 2023-11-21 09:21:30 --> Loader Class Initialized
INFO - 2023-11-21 09:21:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:30 --> Controller Class Initialized
INFO - 2023-11-21 09:21:33 --> Config Class Initialized
INFO - 2023-11-21 09:21:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:33 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:33 --> URI Class Initialized
INFO - 2023-11-21 09:21:33 --> Router Class Initialized
INFO - 2023-11-21 09:21:33 --> Output Class Initialized
INFO - 2023-11-21 09:21:33 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:33 --> Input Class Initialized
INFO - 2023-11-21 09:21:33 --> Language Class Initialized
INFO - 2023-11-21 09:21:33 --> Language Class Initialized
INFO - 2023-11-21 09:21:33 --> Config Class Initialized
INFO - 2023-11-21 09:21:33 --> Loader Class Initialized
INFO - 2023-11-21 09:21:33 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:33 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:33 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:33 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:33 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:33 --> Controller Class Initialized
INFO - 2023-11-21 09:21:33 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:33 --> Total execution time: 0.0920
INFO - 2023-11-21 09:21:38 --> Config Class Initialized
INFO - 2023-11-21 09:21:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:38 --> URI Class Initialized
INFO - 2023-11-21 09:21:38 --> Router Class Initialized
INFO - 2023-11-21 09:21:38 --> Output Class Initialized
INFO - 2023-11-21 09:21:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:38 --> Input Class Initialized
INFO - 2023-11-21 09:21:38 --> Language Class Initialized
INFO - 2023-11-21 09:21:38 --> Language Class Initialized
INFO - 2023-11-21 09:21:38 --> Config Class Initialized
INFO - 2023-11-21 09:21:38 --> Loader Class Initialized
INFO - 2023-11-21 09:21:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:38 --> Controller Class Initialized
INFO - 2023-11-21 09:21:47 --> Config Class Initialized
INFO - 2023-11-21 09:21:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:47 --> URI Class Initialized
INFO - 2023-11-21 09:21:47 --> Router Class Initialized
INFO - 2023-11-21 09:21:47 --> Output Class Initialized
INFO - 2023-11-21 09:21:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:47 --> Input Class Initialized
INFO - 2023-11-21 09:21:47 --> Language Class Initialized
INFO - 2023-11-21 09:21:47 --> Language Class Initialized
INFO - 2023-11-21 09:21:47 --> Config Class Initialized
INFO - 2023-11-21 09:21:47 --> Loader Class Initialized
INFO - 2023-11-21 09:21:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:47 --> Controller Class Initialized
DEBUG - 2023-11-21 09:21:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-21 09:21:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:21:47 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:47 --> Total execution time: 0.0559
INFO - 2023-11-21 09:21:47 --> Config Class Initialized
INFO - 2023-11-21 09:21:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:47 --> URI Class Initialized
INFO - 2023-11-21 09:21:47 --> Router Class Initialized
INFO - 2023-11-21 09:21:47 --> Output Class Initialized
INFO - 2023-11-21 09:21:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:47 --> Input Class Initialized
INFO - 2023-11-21 09:21:47 --> Language Class Initialized
ERROR - 2023-11-21 09:21:47 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:21:47 --> Config Class Initialized
INFO - 2023-11-21 09:21:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:47 --> URI Class Initialized
INFO - 2023-11-21 09:21:47 --> Router Class Initialized
INFO - 2023-11-21 09:21:47 --> Output Class Initialized
INFO - 2023-11-21 09:21:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:47 --> Input Class Initialized
INFO - 2023-11-21 09:21:47 --> Language Class Initialized
INFO - 2023-11-21 09:21:47 --> Language Class Initialized
INFO - 2023-11-21 09:21:47 --> Config Class Initialized
INFO - 2023-11-21 09:21:47 --> Loader Class Initialized
INFO - 2023-11-21 09:21:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:47 --> Controller Class Initialized
INFO - 2023-11-21 09:21:52 --> Config Class Initialized
INFO - 2023-11-21 09:21:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:21:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:21:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:21:52 --> URI Class Initialized
INFO - 2023-11-21 09:21:52 --> Router Class Initialized
INFO - 2023-11-21 09:21:52 --> Output Class Initialized
INFO - 2023-11-21 09:21:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:21:52 --> Input Class Initialized
INFO - 2023-11-21 09:21:52 --> Language Class Initialized
INFO - 2023-11-21 09:21:52 --> Language Class Initialized
INFO - 2023-11-21 09:21:52 --> Config Class Initialized
INFO - 2023-11-21 09:21:52 --> Loader Class Initialized
INFO - 2023-11-21 09:21:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:21:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:21:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:21:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:21:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:21:52 --> Controller Class Initialized
INFO - 2023-11-21 09:21:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:21:52 --> Total execution time: 0.0372
INFO - 2023-11-21 09:22:11 --> Config Class Initialized
INFO - 2023-11-21 09:22:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:11 --> URI Class Initialized
INFO - 2023-11-21 09:22:11 --> Router Class Initialized
INFO - 2023-11-21 09:22:11 --> Output Class Initialized
INFO - 2023-11-21 09:22:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:11 --> Input Class Initialized
INFO - 2023-11-21 09:22:11 --> Language Class Initialized
INFO - 2023-11-21 09:22:11 --> Language Class Initialized
INFO - 2023-11-21 09:22:11 --> Config Class Initialized
INFO - 2023-11-21 09:22:11 --> Loader Class Initialized
INFO - 2023-11-21 09:22:11 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:11 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:11 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:11 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:11 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:11 --> Controller Class Initialized
INFO - 2023-11-21 09:22:11 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:11 --> Total execution time: 0.0320
INFO - 2023-11-21 09:22:18 --> Config Class Initialized
INFO - 2023-11-21 09:22:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:18 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:18 --> URI Class Initialized
INFO - 2023-11-21 09:22:18 --> Router Class Initialized
INFO - 2023-11-21 09:22:18 --> Output Class Initialized
INFO - 2023-11-21 09:22:18 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:18 --> Input Class Initialized
INFO - 2023-11-21 09:22:18 --> Language Class Initialized
INFO - 2023-11-21 09:22:18 --> Language Class Initialized
INFO - 2023-11-21 09:22:18 --> Config Class Initialized
INFO - 2023-11-21 09:22:18 --> Loader Class Initialized
INFO - 2023-11-21 09:22:18 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:18 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:18 --> Controller Class Initialized
DEBUG - 2023-11-21 09:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:22:18 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:18 --> Total execution time: 0.0329
INFO - 2023-11-21 09:22:18 --> Config Class Initialized
INFO - 2023-11-21 09:22:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:18 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:18 --> URI Class Initialized
INFO - 2023-11-21 09:22:18 --> Router Class Initialized
INFO - 2023-11-21 09:22:18 --> Output Class Initialized
INFO - 2023-11-21 09:22:18 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:18 --> Input Class Initialized
INFO - 2023-11-21 09:22:18 --> Language Class Initialized
ERROR - 2023-11-21 09:22:18 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:22:18 --> Config Class Initialized
INFO - 2023-11-21 09:22:18 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:18 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:18 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:18 --> URI Class Initialized
INFO - 2023-11-21 09:22:18 --> Router Class Initialized
INFO - 2023-11-21 09:22:18 --> Output Class Initialized
INFO - 2023-11-21 09:22:18 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:18 --> Input Class Initialized
INFO - 2023-11-21 09:22:18 --> Language Class Initialized
INFO - 2023-11-21 09:22:18 --> Language Class Initialized
INFO - 2023-11-21 09:22:18 --> Config Class Initialized
INFO - 2023-11-21 09:22:18 --> Loader Class Initialized
INFO - 2023-11-21 09:22:18 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:18 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:18 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:18 --> Controller Class Initialized
INFO - 2023-11-21 09:22:19 --> Config Class Initialized
INFO - 2023-11-21 09:22:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:19 --> URI Class Initialized
INFO - 2023-11-21 09:22:19 --> Router Class Initialized
INFO - 2023-11-21 09:22:19 --> Output Class Initialized
INFO - 2023-11-21 09:22:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:19 --> Input Class Initialized
INFO - 2023-11-21 09:22:19 --> Language Class Initialized
INFO - 2023-11-21 09:22:19 --> Language Class Initialized
INFO - 2023-11-21 09:22:19 --> Config Class Initialized
INFO - 2023-11-21 09:22:19 --> Loader Class Initialized
INFO - 2023-11-21 09:22:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:19 --> Controller Class Initialized
DEBUG - 2023-11-21 09:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-21 09:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:22:19 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:19 --> Total execution time: 0.0760
INFO - 2023-11-21 09:22:35 --> Config Class Initialized
INFO - 2023-11-21 09:22:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:35 --> URI Class Initialized
INFO - 2023-11-21 09:22:35 --> Router Class Initialized
INFO - 2023-11-21 09:22:35 --> Output Class Initialized
INFO - 2023-11-21 09:22:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:35 --> Input Class Initialized
INFO - 2023-11-21 09:22:35 --> Language Class Initialized
INFO - 2023-11-21 09:22:35 --> Language Class Initialized
INFO - 2023-11-21 09:22:35 --> Config Class Initialized
INFO - 2023-11-21 09:22:35 --> Loader Class Initialized
INFO - 2023-11-21 09:22:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:35 --> Controller Class Initialized
INFO - 2023-11-21 09:22:35 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:22:36 --> Config Class Initialized
INFO - 2023-11-21 09:22:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:36 --> URI Class Initialized
INFO - 2023-11-21 09:22:36 --> Router Class Initialized
INFO - 2023-11-21 09:22:36 --> Output Class Initialized
INFO - 2023-11-21 09:22:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:36 --> Input Class Initialized
INFO - 2023-11-21 09:22:36 --> Language Class Initialized
INFO - 2023-11-21 09:22:36 --> Language Class Initialized
INFO - 2023-11-21 09:22:36 --> Config Class Initialized
INFO - 2023-11-21 09:22:36 --> Loader Class Initialized
INFO - 2023-11-21 09:22:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:36 --> Controller Class Initialized
INFO - 2023-11-21 09:22:36 --> Config Class Initialized
INFO - 2023-11-21 09:22:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:36 --> URI Class Initialized
INFO - 2023-11-21 09:22:36 --> Router Class Initialized
INFO - 2023-11-21 09:22:36 --> Output Class Initialized
INFO - 2023-11-21 09:22:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:36 --> Input Class Initialized
INFO - 2023-11-21 09:22:36 --> Language Class Initialized
INFO - 2023-11-21 09:22:36 --> Language Class Initialized
INFO - 2023-11-21 09:22:36 --> Config Class Initialized
INFO - 2023-11-21 09:22:36 --> Loader Class Initialized
INFO - 2023-11-21 09:22:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:36 --> Controller Class Initialized
DEBUG - 2023-11-21 09:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:22:36 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:36 --> Total execution time: 0.0545
INFO - 2023-11-21 09:22:52 --> Config Class Initialized
INFO - 2023-11-21 09:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:52 --> URI Class Initialized
INFO - 2023-11-21 09:22:52 --> Router Class Initialized
INFO - 2023-11-21 09:22:52 --> Output Class Initialized
INFO - 2023-11-21 09:22:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:52 --> Input Class Initialized
INFO - 2023-11-21 09:22:52 --> Language Class Initialized
INFO - 2023-11-21 09:22:52 --> Language Class Initialized
INFO - 2023-11-21 09:22:52 --> Config Class Initialized
INFO - 2023-11-21 09:22:52 --> Loader Class Initialized
INFO - 2023-11-21 09:22:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:52 --> Controller Class Initialized
INFO - 2023-11-21 09:22:52 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:22:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:52 --> Total execution time: 0.0790
INFO - 2023-11-21 09:22:52 --> Config Class Initialized
INFO - 2023-11-21 09:22:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:52 --> URI Class Initialized
INFO - 2023-11-21 09:22:52 --> Router Class Initialized
INFO - 2023-11-21 09:22:52 --> Output Class Initialized
INFO - 2023-11-21 09:22:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:52 --> Input Class Initialized
INFO - 2023-11-21 09:22:52 --> Language Class Initialized
INFO - 2023-11-21 09:22:52 --> Language Class Initialized
INFO - 2023-11-21 09:22:52 --> Config Class Initialized
INFO - 2023-11-21 09:22:52 --> Loader Class Initialized
INFO - 2023-11-21 09:22:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:52 --> Controller Class Initialized
DEBUG - 2023-11-21 09:22:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:22:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:22:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:52 --> Total execution time: 0.0309
INFO - 2023-11-21 09:22:55 --> Config Class Initialized
INFO - 2023-11-21 09:22:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:22:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:22:55 --> Utf8 Class Initialized
INFO - 2023-11-21 09:22:55 --> URI Class Initialized
INFO - 2023-11-21 09:22:55 --> Router Class Initialized
INFO - 2023-11-21 09:22:55 --> Output Class Initialized
INFO - 2023-11-21 09:22:55 --> Security Class Initialized
DEBUG - 2023-11-21 09:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:22:55 --> Input Class Initialized
INFO - 2023-11-21 09:22:55 --> Language Class Initialized
INFO - 2023-11-21 09:22:55 --> Language Class Initialized
INFO - 2023-11-21 09:22:55 --> Config Class Initialized
INFO - 2023-11-21 09:22:55 --> Loader Class Initialized
INFO - 2023-11-21 09:22:55 --> Helper loaded: url_helper
INFO - 2023-11-21 09:22:55 --> Helper loaded: file_helper
INFO - 2023-11-21 09:22:55 --> Helper loaded: form_helper
INFO - 2023-11-21 09:22:55 --> Helper loaded: my_helper
INFO - 2023-11-21 09:22:55 --> Database Driver Class Initialized
INFO - 2023-11-21 09:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:22:55 --> Controller Class Initialized
DEBUG - 2023-11-21 09:22:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:22:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:22:55 --> Final output sent to browser
DEBUG - 2023-11-21 09:22:55 --> Total execution time: 0.0639
INFO - 2023-11-21 09:23:02 --> Config Class Initialized
INFO - 2023-11-21 09:23:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:02 --> URI Class Initialized
INFO - 2023-11-21 09:23:02 --> Router Class Initialized
INFO - 2023-11-21 09:23:02 --> Output Class Initialized
INFO - 2023-11-21 09:23:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:02 --> Input Class Initialized
INFO - 2023-11-21 09:23:02 --> Language Class Initialized
INFO - 2023-11-21 09:23:02 --> Language Class Initialized
INFO - 2023-11-21 09:23:02 --> Config Class Initialized
INFO - 2023-11-21 09:23:02 --> Loader Class Initialized
INFO - 2023-11-21 09:23:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:02 --> Controller Class Initialized
DEBUG - 2023-11-21 09:23:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-11-21 09:23:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:23:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:02 --> Total execution time: 0.0397
INFO - 2023-11-21 09:23:03 --> Config Class Initialized
INFO - 2023-11-21 09:23:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:03 --> URI Class Initialized
INFO - 2023-11-21 09:23:03 --> Router Class Initialized
INFO - 2023-11-21 09:23:03 --> Output Class Initialized
INFO - 2023-11-21 09:23:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:03 --> Input Class Initialized
INFO - 2023-11-21 09:23:03 --> Language Class Initialized
INFO - 2023-11-21 09:23:03 --> Language Class Initialized
INFO - 2023-11-21 09:23:03 --> Config Class Initialized
INFO - 2023-11-21 09:23:03 --> Loader Class Initialized
INFO - 2023-11-21 09:23:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:03 --> Controller Class Initialized
INFO - 2023-11-21 09:23:08 --> Config Class Initialized
INFO - 2023-11-21 09:23:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:08 --> URI Class Initialized
INFO - 2023-11-21 09:23:08 --> Router Class Initialized
INFO - 2023-11-21 09:23:08 --> Output Class Initialized
INFO - 2023-11-21 09:23:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:08 --> Input Class Initialized
INFO - 2023-11-21 09:23:08 --> Language Class Initialized
INFO - 2023-11-21 09:23:08 --> Language Class Initialized
INFO - 2023-11-21 09:23:08 --> Config Class Initialized
INFO - 2023-11-21 09:23:08 --> Loader Class Initialized
INFO - 2023-11-21 09:23:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:08 --> Controller Class Initialized
INFO - 2023-11-21 09:23:08 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:08 --> Total execution time: 0.0643
INFO - 2023-11-21 09:23:09 --> Config Class Initialized
INFO - 2023-11-21 09:23:09 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:09 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:09 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:09 --> URI Class Initialized
INFO - 2023-11-21 09:23:09 --> Router Class Initialized
INFO - 2023-11-21 09:23:09 --> Output Class Initialized
INFO - 2023-11-21 09:23:09 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:09 --> Input Class Initialized
INFO - 2023-11-21 09:23:09 --> Language Class Initialized
INFO - 2023-11-21 09:23:09 --> Language Class Initialized
INFO - 2023-11-21 09:23:09 --> Config Class Initialized
INFO - 2023-11-21 09:23:09 --> Loader Class Initialized
INFO - 2023-11-21 09:23:09 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:09 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:09 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:09 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:09 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:09 --> Controller Class Initialized
DEBUG - 2023-11-21 09:23:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:23:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:23:09 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:09 --> Total execution time: 0.0346
INFO - 2023-11-21 09:23:12 --> Config Class Initialized
INFO - 2023-11-21 09:23:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:12 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:12 --> URI Class Initialized
INFO - 2023-11-21 09:23:12 --> Router Class Initialized
INFO - 2023-11-21 09:23:12 --> Output Class Initialized
INFO - 2023-11-21 09:23:12 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:12 --> Input Class Initialized
INFO - 2023-11-21 09:23:12 --> Language Class Initialized
INFO - 2023-11-21 09:23:12 --> Language Class Initialized
INFO - 2023-11-21 09:23:12 --> Config Class Initialized
INFO - 2023-11-21 09:23:12 --> Loader Class Initialized
INFO - 2023-11-21 09:23:12 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:12 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:12 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:12 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:12 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:12 --> Controller Class Initialized
DEBUG - 2023-11-21 09:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-11-21 09:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:23:12 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:12 --> Total execution time: 0.0557
INFO - 2023-11-21 09:23:26 --> Config Class Initialized
INFO - 2023-11-21 09:23:26 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:26 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:26 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:26 --> URI Class Initialized
INFO - 2023-11-21 09:23:26 --> Router Class Initialized
INFO - 2023-11-21 09:23:26 --> Output Class Initialized
INFO - 2023-11-21 09:23:26 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:26 --> Input Class Initialized
INFO - 2023-11-21 09:23:26 --> Language Class Initialized
INFO - 2023-11-21 09:23:26 --> Language Class Initialized
INFO - 2023-11-21 09:23:26 --> Config Class Initialized
INFO - 2023-11-21 09:23:26 --> Loader Class Initialized
INFO - 2023-11-21 09:23:26 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:26 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:26 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:26 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:26 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:26 --> Controller Class Initialized
DEBUG - 2023-11-21 09:23:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-11-21 09:23:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:23:26 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:26 --> Total execution time: 0.0471
INFO - 2023-11-21 09:23:48 --> Config Class Initialized
INFO - 2023-11-21 09:23:48 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:23:48 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:23:48 --> Utf8 Class Initialized
INFO - 2023-11-21 09:23:48 --> URI Class Initialized
INFO - 2023-11-21 09:23:48 --> Router Class Initialized
INFO - 2023-11-21 09:23:48 --> Output Class Initialized
INFO - 2023-11-21 09:23:48 --> Security Class Initialized
DEBUG - 2023-11-21 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:23:48 --> Input Class Initialized
INFO - 2023-11-21 09:23:48 --> Language Class Initialized
INFO - 2023-11-21 09:23:48 --> Language Class Initialized
INFO - 2023-11-21 09:23:48 --> Config Class Initialized
INFO - 2023-11-21 09:23:48 --> Loader Class Initialized
INFO - 2023-11-21 09:23:48 --> Helper loaded: url_helper
INFO - 2023-11-21 09:23:48 --> Helper loaded: file_helper
INFO - 2023-11-21 09:23:48 --> Helper loaded: form_helper
INFO - 2023-11-21 09:23:48 --> Helper loaded: my_helper
INFO - 2023-11-21 09:23:48 --> Database Driver Class Initialized
INFO - 2023-11-21 09:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:23:48 --> Controller Class Initialized
DEBUG - 2023-11-21 09:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-11-21 09:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:23:48 --> Final output sent to browser
DEBUG - 2023-11-21 09:23:48 --> Total execution time: 0.0967
INFO - 2023-11-21 09:24:12 --> Config Class Initialized
INFO - 2023-11-21 09:24:12 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:24:12 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:24:12 --> Utf8 Class Initialized
INFO - 2023-11-21 09:24:12 --> URI Class Initialized
INFO - 2023-11-21 09:24:12 --> Router Class Initialized
INFO - 2023-11-21 09:24:12 --> Output Class Initialized
INFO - 2023-11-21 09:24:12 --> Security Class Initialized
DEBUG - 2023-11-21 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:24:12 --> Input Class Initialized
INFO - 2023-11-21 09:24:12 --> Language Class Initialized
INFO - 2023-11-21 09:24:12 --> Language Class Initialized
INFO - 2023-11-21 09:24:12 --> Config Class Initialized
INFO - 2023-11-21 09:24:12 --> Loader Class Initialized
INFO - 2023-11-21 09:24:12 --> Helper loaded: url_helper
INFO - 2023-11-21 09:24:12 --> Helper loaded: file_helper
INFO - 2023-11-21 09:24:12 --> Helper loaded: form_helper
INFO - 2023-11-21 09:24:12 --> Helper loaded: my_helper
INFO - 2023-11-21 09:24:12 --> Database Driver Class Initialized
INFO - 2023-11-21 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:24:12 --> Controller Class Initialized
DEBUG - 2023-11-21 09:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-11-21 09:24:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:24:12 --> Final output sent to browser
DEBUG - 2023-11-21 09:24:12 --> Total execution time: 0.0448
INFO - 2023-11-21 09:24:24 --> Config Class Initialized
INFO - 2023-11-21 09:24:24 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:24:24 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:24:24 --> Utf8 Class Initialized
INFO - 2023-11-21 09:24:24 --> URI Class Initialized
INFO - 2023-11-21 09:24:24 --> Router Class Initialized
INFO - 2023-11-21 09:24:24 --> Output Class Initialized
INFO - 2023-11-21 09:24:24 --> Security Class Initialized
DEBUG - 2023-11-21 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:24:24 --> Input Class Initialized
INFO - 2023-11-21 09:24:24 --> Language Class Initialized
INFO - 2023-11-21 09:24:24 --> Language Class Initialized
INFO - 2023-11-21 09:24:24 --> Config Class Initialized
INFO - 2023-11-21 09:24:24 --> Loader Class Initialized
INFO - 2023-11-21 09:24:24 --> Helper loaded: url_helper
INFO - 2023-11-21 09:24:24 --> Helper loaded: file_helper
INFO - 2023-11-21 09:24:24 --> Helper loaded: form_helper
INFO - 2023-11-21 09:24:24 --> Helper loaded: my_helper
INFO - 2023-11-21 09:24:24 --> Database Driver Class Initialized
INFO - 2023-11-21 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:24:24 --> Controller Class Initialized
INFO - 2023-11-21 09:24:24 --> Final output sent to browser
DEBUG - 2023-11-21 09:24:24 --> Total execution time: 0.0446
INFO - 2023-11-21 09:25:35 --> Config Class Initialized
INFO - 2023-11-21 09:25:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:25:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:25:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:25:35 --> URI Class Initialized
INFO - 2023-11-21 09:25:35 --> Router Class Initialized
INFO - 2023-11-21 09:25:35 --> Output Class Initialized
INFO - 2023-11-21 09:25:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:25:35 --> Input Class Initialized
INFO - 2023-11-21 09:25:35 --> Language Class Initialized
INFO - 2023-11-21 09:25:35 --> Language Class Initialized
INFO - 2023-11-21 09:25:35 --> Config Class Initialized
INFO - 2023-11-21 09:25:35 --> Loader Class Initialized
INFO - 2023-11-21 09:25:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:25:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:25:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:25:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:25:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:25:35 --> Controller Class Initialized
DEBUG - 2023-11-21 09:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2023-11-21 09:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:25:35 --> Final output sent to browser
DEBUG - 2023-11-21 09:25:35 --> Total execution time: 0.0792
INFO - 2023-11-21 09:25:35 --> Config Class Initialized
INFO - 2023-11-21 09:25:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:25:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:25:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:25:35 --> URI Class Initialized
INFO - 2023-11-21 09:25:35 --> Router Class Initialized
INFO - 2023-11-21 09:25:35 --> Output Class Initialized
INFO - 2023-11-21 09:25:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:25:35 --> Input Class Initialized
INFO - 2023-11-21 09:25:35 --> Language Class Initialized
ERROR - 2023-11-21 09:25:35 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:25:35 --> Config Class Initialized
INFO - 2023-11-21 09:25:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:25:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:25:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:25:35 --> URI Class Initialized
INFO - 2023-11-21 09:25:35 --> Router Class Initialized
INFO - 2023-11-21 09:25:35 --> Output Class Initialized
INFO - 2023-11-21 09:25:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:25:36 --> Input Class Initialized
INFO - 2023-11-21 09:25:36 --> Language Class Initialized
INFO - 2023-11-21 09:25:36 --> Language Class Initialized
INFO - 2023-11-21 09:25:36 --> Config Class Initialized
INFO - 2023-11-21 09:25:36 --> Loader Class Initialized
INFO - 2023-11-21 09:25:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:25:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:25:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:25:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:25:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:25:36 --> Controller Class Initialized
INFO - 2023-11-21 09:25:37 --> Config Class Initialized
INFO - 2023-11-21 09:25:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:25:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:25:37 --> Utf8 Class Initialized
INFO - 2023-11-21 09:25:37 --> URI Class Initialized
INFO - 2023-11-21 09:25:37 --> Router Class Initialized
INFO - 2023-11-21 09:25:37 --> Output Class Initialized
INFO - 2023-11-21 09:25:37 --> Security Class Initialized
DEBUG - 2023-11-21 09:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:25:37 --> Input Class Initialized
INFO - 2023-11-21 09:25:37 --> Language Class Initialized
INFO - 2023-11-21 09:25:37 --> Language Class Initialized
INFO - 2023-11-21 09:25:37 --> Config Class Initialized
INFO - 2023-11-21 09:25:37 --> Loader Class Initialized
INFO - 2023-11-21 09:25:37 --> Helper loaded: url_helper
INFO - 2023-11-21 09:25:37 --> Helper loaded: file_helper
INFO - 2023-11-21 09:25:37 --> Helper loaded: form_helper
INFO - 2023-11-21 09:25:37 --> Helper loaded: my_helper
INFO - 2023-11-21 09:25:37 --> Database Driver Class Initialized
INFO - 2023-11-21 09:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:25:37 --> Controller Class Initialized
DEBUG - 2023-11-21 09:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-11-21 09:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:25:37 --> Final output sent to browser
DEBUG - 2023-11-21 09:25:37 --> Total execution time: 0.0340
INFO - 2023-11-21 09:25:38 --> Config Class Initialized
INFO - 2023-11-21 09:25:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:25:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:25:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:25:38 --> URI Class Initialized
INFO - 2023-11-21 09:25:38 --> Router Class Initialized
INFO - 2023-11-21 09:25:38 --> Output Class Initialized
INFO - 2023-11-21 09:25:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:25:38 --> Input Class Initialized
INFO - 2023-11-21 09:25:38 --> Language Class Initialized
INFO - 2023-11-21 09:25:38 --> Language Class Initialized
INFO - 2023-11-21 09:25:38 --> Config Class Initialized
INFO - 2023-11-21 09:25:38 --> Loader Class Initialized
INFO - 2023-11-21 09:25:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:25:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:25:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:25:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:25:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:25:38 --> Controller Class Initialized
INFO - 2023-11-21 09:25:38 --> Final output sent to browser
DEBUG - 2023-11-21 09:25:38 --> Total execution time: 0.0344
INFO - 2023-11-21 09:27:03 --> Config Class Initialized
INFO - 2023-11-21 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:03 --> URI Class Initialized
INFO - 2023-11-21 09:27:03 --> Router Class Initialized
INFO - 2023-11-21 09:27:03 --> Output Class Initialized
INFO - 2023-11-21 09:27:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:03 --> Input Class Initialized
INFO - 2023-11-21 09:27:03 --> Language Class Initialized
INFO - 2023-11-21 09:27:03 --> Language Class Initialized
INFO - 2023-11-21 09:27:03 --> Config Class Initialized
INFO - 2023-11-21 09:27:03 --> Loader Class Initialized
INFO - 2023-11-21 09:27:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:27:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:03 --> Controller Class Initialized
DEBUG - 2023-11-21 09:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2023-11-21 09:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:27:03 --> Final output sent to browser
DEBUG - 2023-11-21 09:27:03 --> Total execution time: 0.0659
INFO - 2023-11-21 09:27:03 --> Config Class Initialized
INFO - 2023-11-21 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:03 --> URI Class Initialized
INFO - 2023-11-21 09:27:03 --> Router Class Initialized
INFO - 2023-11-21 09:27:03 --> Output Class Initialized
INFO - 2023-11-21 09:27:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:03 --> Input Class Initialized
INFO - 2023-11-21 09:27:03 --> Language Class Initialized
ERROR - 2023-11-21 09:27:03 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:27:03 --> Config Class Initialized
INFO - 2023-11-21 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:27:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:27:03 --> URI Class Initialized
INFO - 2023-11-21 09:27:03 --> Router Class Initialized
INFO - 2023-11-21 09:27:03 --> Output Class Initialized
INFO - 2023-11-21 09:27:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:27:03 --> Input Class Initialized
INFO - 2023-11-21 09:27:03 --> Language Class Initialized
INFO - 2023-11-21 09:27:03 --> Language Class Initialized
INFO - 2023-11-21 09:27:03 --> Config Class Initialized
INFO - 2023-11-21 09:27:03 --> Loader Class Initialized
INFO - 2023-11-21 09:27:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:27:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:27:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:27:03 --> Controller Class Initialized
INFO - 2023-11-21 09:28:34 --> Config Class Initialized
INFO - 2023-11-21 09:28:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:28:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:28:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:28:34 --> URI Class Initialized
INFO - 2023-11-21 09:28:34 --> Router Class Initialized
INFO - 2023-11-21 09:28:34 --> Output Class Initialized
INFO - 2023-11-21 09:28:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:28:34 --> Input Class Initialized
INFO - 2023-11-21 09:28:34 --> Language Class Initialized
INFO - 2023-11-21 09:28:34 --> Language Class Initialized
INFO - 2023-11-21 09:28:34 --> Config Class Initialized
INFO - 2023-11-21 09:28:34 --> Loader Class Initialized
INFO - 2023-11-21 09:28:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:28:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:28:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:28:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:28:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:28:34 --> Controller Class Initialized
DEBUG - 2023-11-21 09:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-11-21 09:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:28:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:28:34 --> Total execution time: 0.0425
INFO - 2023-11-21 09:28:50 --> Config Class Initialized
INFO - 2023-11-21 09:28:50 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:28:50 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:28:50 --> Utf8 Class Initialized
INFO - 2023-11-21 09:28:50 --> URI Class Initialized
INFO - 2023-11-21 09:28:50 --> Router Class Initialized
INFO - 2023-11-21 09:28:50 --> Output Class Initialized
INFO - 2023-11-21 09:28:50 --> Security Class Initialized
DEBUG - 2023-11-21 09:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:28:50 --> Input Class Initialized
INFO - 2023-11-21 09:28:50 --> Language Class Initialized
INFO - 2023-11-21 09:28:50 --> Language Class Initialized
INFO - 2023-11-21 09:28:50 --> Config Class Initialized
INFO - 2023-11-21 09:28:50 --> Loader Class Initialized
INFO - 2023-11-21 09:28:50 --> Helper loaded: url_helper
INFO - 2023-11-21 09:28:50 --> Helper loaded: file_helper
INFO - 2023-11-21 09:28:50 --> Helper loaded: form_helper
INFO - 2023-11-21 09:28:50 --> Helper loaded: my_helper
INFO - 2023-11-21 09:28:50 --> Database Driver Class Initialized
INFO - 2023-11-21 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:28:50 --> Controller Class Initialized
DEBUG - 2023-11-21 09:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-11-21 09:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:28:50 --> Final output sent to browser
DEBUG - 2023-11-21 09:28:50 --> Total execution time: 0.0338
INFO - 2023-11-21 09:29:29 --> Config Class Initialized
INFO - 2023-11-21 09:29:29 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:29:29 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:29:29 --> Utf8 Class Initialized
INFO - 2023-11-21 09:29:29 --> URI Class Initialized
INFO - 2023-11-21 09:29:29 --> Router Class Initialized
INFO - 2023-11-21 09:29:29 --> Output Class Initialized
INFO - 2023-11-21 09:29:29 --> Security Class Initialized
DEBUG - 2023-11-21 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:29:29 --> Input Class Initialized
INFO - 2023-11-21 09:29:29 --> Language Class Initialized
INFO - 2023-11-21 09:29:29 --> Language Class Initialized
INFO - 2023-11-21 09:29:29 --> Config Class Initialized
INFO - 2023-11-21 09:29:29 --> Loader Class Initialized
INFO - 2023-11-21 09:29:29 --> Helper loaded: url_helper
INFO - 2023-11-21 09:29:29 --> Helper loaded: file_helper
INFO - 2023-11-21 09:29:29 --> Helper loaded: form_helper
INFO - 2023-11-21 09:29:29 --> Helper loaded: my_helper
INFO - 2023-11-21 09:29:29 --> Database Driver Class Initialized
INFO - 2023-11-21 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:29:29 --> Controller Class Initialized
DEBUG - 2023-11-21 09:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-21 09:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:29:29 --> Final output sent to browser
DEBUG - 2023-11-21 09:29:29 --> Total execution time: 0.0511
INFO - 2023-11-21 09:31:05 --> Config Class Initialized
INFO - 2023-11-21 09:31:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:31:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:31:05 --> Utf8 Class Initialized
INFO - 2023-11-21 09:31:05 --> URI Class Initialized
INFO - 2023-11-21 09:31:05 --> Router Class Initialized
INFO - 2023-11-21 09:31:05 --> Output Class Initialized
INFO - 2023-11-21 09:31:05 --> Security Class Initialized
DEBUG - 2023-11-21 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:31:05 --> Input Class Initialized
INFO - 2023-11-21 09:31:05 --> Language Class Initialized
INFO - 2023-11-21 09:31:05 --> Language Class Initialized
INFO - 2023-11-21 09:31:05 --> Config Class Initialized
INFO - 2023-11-21 09:31:05 --> Loader Class Initialized
INFO - 2023-11-21 09:31:05 --> Helper loaded: url_helper
INFO - 2023-11-21 09:31:05 --> Helper loaded: file_helper
INFO - 2023-11-21 09:31:05 --> Helper loaded: form_helper
INFO - 2023-11-21 09:31:05 --> Helper loaded: my_helper
INFO - 2023-11-21 09:31:05 --> Database Driver Class Initialized
INFO - 2023-11-21 09:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:31:05 --> Controller Class Initialized
DEBUG - 2023-11-21 09:31:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-11-21 09:31:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:31:05 --> Final output sent to browser
DEBUG - 2023-11-21 09:31:05 --> Total execution time: 0.0795
INFO - 2023-11-21 09:31:19 --> Config Class Initialized
INFO - 2023-11-21 09:31:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:31:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:31:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:31:19 --> URI Class Initialized
INFO - 2023-11-21 09:31:19 --> Router Class Initialized
INFO - 2023-11-21 09:31:19 --> Output Class Initialized
INFO - 2023-11-21 09:31:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:31:19 --> Input Class Initialized
INFO - 2023-11-21 09:31:19 --> Language Class Initialized
INFO - 2023-11-21 09:31:19 --> Language Class Initialized
INFO - 2023-11-21 09:31:19 --> Config Class Initialized
INFO - 2023-11-21 09:31:19 --> Loader Class Initialized
INFO - 2023-11-21 09:31:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:31:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:31:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:31:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:31:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:31:19 --> Controller Class Initialized
DEBUG - 2023-11-21 09:31:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-21 09:31:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:31:19 --> Final output sent to browser
DEBUG - 2023-11-21 09:31:19 --> Total execution time: 0.0928
INFO - 2023-11-21 09:31:29 --> Config Class Initialized
INFO - 2023-11-21 09:31:29 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:31:29 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:31:29 --> Utf8 Class Initialized
INFO - 2023-11-21 09:31:29 --> URI Class Initialized
INFO - 2023-11-21 09:31:29 --> Router Class Initialized
INFO - 2023-11-21 09:31:29 --> Output Class Initialized
INFO - 2023-11-21 09:31:29 --> Security Class Initialized
DEBUG - 2023-11-21 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:31:29 --> Input Class Initialized
INFO - 2023-11-21 09:31:29 --> Language Class Initialized
INFO - 2023-11-21 09:31:29 --> Language Class Initialized
INFO - 2023-11-21 09:31:29 --> Config Class Initialized
INFO - 2023-11-21 09:31:29 --> Loader Class Initialized
INFO - 2023-11-21 09:31:29 --> Helper loaded: url_helper
INFO - 2023-11-21 09:31:29 --> Helper loaded: file_helper
INFO - 2023-11-21 09:31:29 --> Helper loaded: form_helper
INFO - 2023-11-21 09:31:29 --> Helper loaded: my_helper
INFO - 2023-11-21 09:31:29 --> Database Driver Class Initialized
INFO - 2023-11-21 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:31:29 --> Controller Class Initialized
DEBUG - 2023-11-21 09:31:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:31:32 --> Final output sent to browser
DEBUG - 2023-11-21 09:31:32 --> Total execution time: 2.7317
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:19 --> URI Class Initialized
INFO - 2023-11-21 09:33:19 --> Router Class Initialized
INFO - 2023-11-21 09:33:19 --> Output Class Initialized
INFO - 2023-11-21 09:33:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:19 --> Input Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Loader Class Initialized
INFO - 2023-11-21 09:33:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:19 --> Controller Class Initialized
INFO - 2023-11-21 09:33:19 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:19 --> URI Class Initialized
INFO - 2023-11-21 09:33:19 --> Router Class Initialized
INFO - 2023-11-21 09:33:19 --> Output Class Initialized
INFO - 2023-11-21 09:33:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:19 --> Input Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Loader Class Initialized
INFO - 2023-11-21 09:33:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:19 --> Controller Class Initialized
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:19 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:19 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:19 --> URI Class Initialized
INFO - 2023-11-21 09:33:19 --> Router Class Initialized
INFO - 2023-11-21 09:33:19 --> Output Class Initialized
INFO - 2023-11-21 09:33:19 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:19 --> Input Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Language Class Initialized
INFO - 2023-11-21 09:33:19 --> Config Class Initialized
INFO - 2023-11-21 09:33:19 --> Loader Class Initialized
INFO - 2023-11-21 09:33:19 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:19 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:19 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:19 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:33:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:19 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:19 --> Total execution time: 0.0393
INFO - 2023-11-21 09:33:31 --> Config Class Initialized
INFO - 2023-11-21 09:33:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:31 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:31 --> URI Class Initialized
INFO - 2023-11-21 09:33:31 --> Router Class Initialized
INFO - 2023-11-21 09:33:31 --> Output Class Initialized
INFO - 2023-11-21 09:33:31 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:31 --> Input Class Initialized
INFO - 2023-11-21 09:33:31 --> Language Class Initialized
INFO - 2023-11-21 09:33:31 --> Language Class Initialized
INFO - 2023-11-21 09:33:31 --> Config Class Initialized
INFO - 2023-11-21 09:33:31 --> Loader Class Initialized
INFO - 2023-11-21 09:33:31 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:31 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:31 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:31 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:31 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:31 --> Controller Class Initialized
INFO - 2023-11-21 09:33:31 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:31 --> Total execution time: 0.0780
INFO - 2023-11-21 09:33:36 --> Config Class Initialized
INFO - 2023-11-21 09:33:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:36 --> URI Class Initialized
INFO - 2023-11-21 09:33:36 --> Router Class Initialized
INFO - 2023-11-21 09:33:36 --> Output Class Initialized
INFO - 2023-11-21 09:33:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:36 --> Input Class Initialized
INFO - 2023-11-21 09:33:36 --> Language Class Initialized
INFO - 2023-11-21 09:33:36 --> Language Class Initialized
INFO - 2023-11-21 09:33:36 --> Config Class Initialized
INFO - 2023-11-21 09:33:36 --> Loader Class Initialized
INFO - 2023-11-21 09:33:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:36 --> Controller Class Initialized
INFO - 2023-11-21 09:33:36 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:33:36 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:36 --> Total execution time: 0.0444
INFO - 2023-11-21 09:33:36 --> Config Class Initialized
INFO - 2023-11-21 09:33:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:36 --> URI Class Initialized
INFO - 2023-11-21 09:33:36 --> Router Class Initialized
INFO - 2023-11-21 09:33:36 --> Output Class Initialized
INFO - 2023-11-21 09:33:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:36 --> Input Class Initialized
INFO - 2023-11-21 09:33:36 --> Language Class Initialized
INFO - 2023-11-21 09:33:36 --> Language Class Initialized
INFO - 2023-11-21 09:33:36 --> Config Class Initialized
INFO - 2023-11-21 09:33:36 --> Loader Class Initialized
INFO - 2023-11-21 09:33:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:37 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:37 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 09:33:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:37 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:37 --> Total execution time: 0.1017
INFO - 2023-11-21 09:33:38 --> Config Class Initialized
INFO - 2023-11-21 09:33:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:38 --> URI Class Initialized
INFO - 2023-11-21 09:33:38 --> Router Class Initialized
INFO - 2023-11-21 09:33:38 --> Output Class Initialized
INFO - 2023-11-21 09:33:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:38 --> Input Class Initialized
INFO - 2023-11-21 09:33:38 --> Language Class Initialized
INFO - 2023-11-21 09:33:38 --> Language Class Initialized
INFO - 2023-11-21 09:33:38 --> Config Class Initialized
INFO - 2023-11-21 09:33:38 --> Loader Class Initialized
INFO - 2023-11-21 09:33:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:38 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-11-21 09:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:38 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:38 --> Total execution time: 0.0304
INFO - 2023-11-21 09:33:38 --> Config Class Initialized
INFO - 2023-11-21 09:33:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:38 --> URI Class Initialized
INFO - 2023-11-21 09:33:38 --> Router Class Initialized
INFO - 2023-11-21 09:33:38 --> Output Class Initialized
INFO - 2023-11-21 09:33:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:38 --> Input Class Initialized
INFO - 2023-11-21 09:33:38 --> Language Class Initialized
ERROR - 2023-11-21 09:33:38 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:33:38 --> Config Class Initialized
INFO - 2023-11-21 09:33:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:38 --> URI Class Initialized
INFO - 2023-11-21 09:33:38 --> Router Class Initialized
INFO - 2023-11-21 09:33:38 --> Output Class Initialized
INFO - 2023-11-21 09:33:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:38 --> Input Class Initialized
INFO - 2023-11-21 09:33:38 --> Language Class Initialized
INFO - 2023-11-21 09:33:38 --> Language Class Initialized
INFO - 2023-11-21 09:33:38 --> Config Class Initialized
INFO - 2023-11-21 09:33:38 --> Loader Class Initialized
INFO - 2023-11-21 09:33:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:38 --> Controller Class Initialized
INFO - 2023-11-21 09:33:42 --> Config Class Initialized
INFO - 2023-11-21 09:33:42 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:42 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:42 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:42 --> URI Class Initialized
INFO - 2023-11-21 09:33:42 --> Router Class Initialized
INFO - 2023-11-21 09:33:42 --> Output Class Initialized
INFO - 2023-11-21 09:33:42 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:42 --> Input Class Initialized
INFO - 2023-11-21 09:33:42 --> Language Class Initialized
INFO - 2023-11-21 09:33:42 --> Language Class Initialized
INFO - 2023-11-21 09:33:42 --> Config Class Initialized
INFO - 2023-11-21 09:33:42 --> Loader Class Initialized
INFO - 2023-11-21 09:33:42 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:42 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:42 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:42 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:42 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:42 --> Controller Class Initialized
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:49 --> URI Class Initialized
INFO - 2023-11-21 09:33:49 --> Router Class Initialized
INFO - 2023-11-21 09:33:49 --> Output Class Initialized
INFO - 2023-11-21 09:33:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:49 --> Input Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Loader Class Initialized
INFO - 2023-11-21 09:33:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:49 --> Controller Class Initialized
INFO - 2023-11-21 09:33:49 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:49 --> URI Class Initialized
INFO - 2023-11-21 09:33:49 --> Router Class Initialized
INFO - 2023-11-21 09:33:49 --> Output Class Initialized
INFO - 2023-11-21 09:33:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:49 --> Input Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Loader Class Initialized
INFO - 2023-11-21 09:33:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:49 --> Controller Class Initialized
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:49 --> URI Class Initialized
INFO - 2023-11-21 09:33:49 --> Router Class Initialized
INFO - 2023-11-21 09:33:49 --> Output Class Initialized
INFO - 2023-11-21 09:33:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:49 --> Input Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Language Class Initialized
INFO - 2023-11-21 09:33:49 --> Config Class Initialized
INFO - 2023-11-21 09:33:49 --> Loader Class Initialized
INFO - 2023-11-21 09:33:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:49 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:33:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:49 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:49 --> Total execution time: 0.0665
INFO - 2023-11-21 09:33:52 --> Config Class Initialized
INFO - 2023-11-21 09:33:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:52 --> URI Class Initialized
INFO - 2023-11-21 09:33:52 --> Router Class Initialized
INFO - 2023-11-21 09:33:52 --> Output Class Initialized
INFO - 2023-11-21 09:33:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:52 --> Input Class Initialized
INFO - 2023-11-21 09:33:52 --> Language Class Initialized
INFO - 2023-11-21 09:33:52 --> Language Class Initialized
INFO - 2023-11-21 09:33:52 --> Config Class Initialized
INFO - 2023-11-21 09:33:52 --> Loader Class Initialized
INFO - 2023-11-21 09:33:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:52 --> Controller Class Initialized
INFO - 2023-11-21 09:33:52 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:33:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:52 --> Total execution time: 0.0451
INFO - 2023-11-21 09:33:52 --> Config Class Initialized
INFO - 2023-11-21 09:33:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:52 --> URI Class Initialized
INFO - 2023-11-21 09:33:52 --> Router Class Initialized
INFO - 2023-11-21 09:33:52 --> Output Class Initialized
INFO - 2023-11-21 09:33:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:52 --> Input Class Initialized
INFO - 2023-11-21 09:33:52 --> Language Class Initialized
INFO - 2023-11-21 09:33:52 --> Language Class Initialized
INFO - 2023-11-21 09:33:52 --> Config Class Initialized
INFO - 2023-11-21 09:33:52 --> Loader Class Initialized
INFO - 2023-11-21 09:33:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:52 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:52 --> Total execution time: 0.0452
INFO - 2023-11-21 09:33:55 --> Config Class Initialized
INFO - 2023-11-21 09:33:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:55 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:55 --> URI Class Initialized
INFO - 2023-11-21 09:33:55 --> Router Class Initialized
INFO - 2023-11-21 09:33:55 --> Output Class Initialized
INFO - 2023-11-21 09:33:55 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:55 --> Input Class Initialized
INFO - 2023-11-21 09:33:55 --> Language Class Initialized
INFO - 2023-11-21 09:33:55 --> Language Class Initialized
INFO - 2023-11-21 09:33:55 --> Config Class Initialized
INFO - 2023-11-21 09:33:55 --> Loader Class Initialized
INFO - 2023-11-21 09:33:55 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:55 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:55 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:55 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:55 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:55 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:33:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:55 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:55 --> Total execution time: 0.0381
INFO - 2023-11-21 09:33:57 --> Config Class Initialized
INFO - 2023-11-21 09:33:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:57 --> URI Class Initialized
INFO - 2023-11-21 09:33:57 --> Router Class Initialized
INFO - 2023-11-21 09:33:57 --> Output Class Initialized
INFO - 2023-11-21 09:33:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:57 --> Input Class Initialized
INFO - 2023-11-21 09:33:57 --> Language Class Initialized
INFO - 2023-11-21 09:33:57 --> Language Class Initialized
INFO - 2023-11-21 09:33:57 --> Config Class Initialized
INFO - 2023-11-21 09:33:57 --> Loader Class Initialized
INFO - 2023-11-21 09:33:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:57 --> Controller Class Initialized
DEBUG - 2023-11-21 09:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 09:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:33:57 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:57 --> Total execution time: 0.1113
INFO - 2023-11-21 09:33:57 --> Config Class Initialized
INFO - 2023-11-21 09:33:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:57 --> URI Class Initialized
INFO - 2023-11-21 09:33:57 --> Router Class Initialized
INFO - 2023-11-21 09:33:57 --> Output Class Initialized
INFO - 2023-11-21 09:33:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:57 --> Input Class Initialized
INFO - 2023-11-21 09:33:57 --> Language Class Initialized
INFO - 2023-11-21 09:33:57 --> Language Class Initialized
INFO - 2023-11-21 09:33:57 --> Config Class Initialized
INFO - 2023-11-21 09:33:57 --> Loader Class Initialized
INFO - 2023-11-21 09:33:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:57 --> Controller Class Initialized
INFO - 2023-11-21 09:33:58 --> Config Class Initialized
INFO - 2023-11-21 09:33:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:33:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:33:58 --> Utf8 Class Initialized
INFO - 2023-11-21 09:33:58 --> URI Class Initialized
INFO - 2023-11-21 09:33:58 --> Router Class Initialized
INFO - 2023-11-21 09:33:58 --> Output Class Initialized
INFO - 2023-11-21 09:33:58 --> Security Class Initialized
DEBUG - 2023-11-21 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:33:58 --> Input Class Initialized
INFO - 2023-11-21 09:33:58 --> Language Class Initialized
INFO - 2023-11-21 09:33:58 --> Language Class Initialized
INFO - 2023-11-21 09:33:58 --> Config Class Initialized
INFO - 2023-11-21 09:33:58 --> Loader Class Initialized
INFO - 2023-11-21 09:33:58 --> Helper loaded: url_helper
INFO - 2023-11-21 09:33:58 --> Helper loaded: file_helper
INFO - 2023-11-21 09:33:58 --> Helper loaded: form_helper
INFO - 2023-11-21 09:33:58 --> Helper loaded: my_helper
INFO - 2023-11-21 09:33:58 --> Database Driver Class Initialized
INFO - 2023-11-21 09:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:33:58 --> Controller Class Initialized
INFO - 2023-11-21 09:33:58 --> Final output sent to browser
DEBUG - 2023-11-21 09:33:58 --> Total execution time: 0.0391
INFO - 2023-11-21 09:34:21 --> Config Class Initialized
INFO - 2023-11-21 09:34:21 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:34:21 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:34:21 --> Utf8 Class Initialized
INFO - 2023-11-21 09:34:21 --> URI Class Initialized
INFO - 2023-11-21 09:34:21 --> Router Class Initialized
INFO - 2023-11-21 09:34:21 --> Output Class Initialized
INFO - 2023-11-21 09:34:21 --> Security Class Initialized
DEBUG - 2023-11-21 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:34:21 --> Input Class Initialized
INFO - 2023-11-21 09:34:21 --> Language Class Initialized
INFO - 2023-11-21 09:34:21 --> Language Class Initialized
INFO - 2023-11-21 09:34:21 --> Config Class Initialized
INFO - 2023-11-21 09:34:21 --> Loader Class Initialized
INFO - 2023-11-21 09:34:21 --> Helper loaded: url_helper
INFO - 2023-11-21 09:34:21 --> Helper loaded: file_helper
INFO - 2023-11-21 09:34:21 --> Helper loaded: form_helper
INFO - 2023-11-21 09:34:21 --> Helper loaded: my_helper
INFO - 2023-11-21 09:34:21 --> Database Driver Class Initialized
INFO - 2023-11-21 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:34:21 --> Controller Class Initialized
INFO - 2023-11-21 09:34:21 --> Final output sent to browser
DEBUG - 2023-11-21 09:34:21 --> Total execution time: 0.1234
INFO - 2023-11-21 09:34:25 --> Config Class Initialized
INFO - 2023-11-21 09:34:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:34:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:34:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:34:25 --> URI Class Initialized
INFO - 2023-11-21 09:34:25 --> Router Class Initialized
INFO - 2023-11-21 09:34:25 --> Output Class Initialized
INFO - 2023-11-21 09:34:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:34:25 --> Input Class Initialized
INFO - 2023-11-21 09:34:25 --> Language Class Initialized
INFO - 2023-11-21 09:34:25 --> Language Class Initialized
INFO - 2023-11-21 09:34:25 --> Config Class Initialized
INFO - 2023-11-21 09:34:25 --> Loader Class Initialized
INFO - 2023-11-21 09:34:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:34:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:34:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:34:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:34:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:34:25 --> Controller Class Initialized
DEBUG - 2023-11-21 09:34:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:34:27 --> Final output sent to browser
DEBUG - 2023-11-21 09:34:27 --> Total execution time: 2.3513
INFO - 2023-11-21 09:34:41 --> Config Class Initialized
INFO - 2023-11-21 09:34:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:34:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:34:41 --> Utf8 Class Initialized
INFO - 2023-11-21 09:34:41 --> URI Class Initialized
INFO - 2023-11-21 09:34:41 --> Router Class Initialized
INFO - 2023-11-21 09:34:41 --> Output Class Initialized
INFO - 2023-11-21 09:34:41 --> Security Class Initialized
DEBUG - 2023-11-21 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:34:41 --> Input Class Initialized
INFO - 2023-11-21 09:34:41 --> Language Class Initialized
INFO - 2023-11-21 09:34:41 --> Language Class Initialized
INFO - 2023-11-21 09:34:41 --> Config Class Initialized
INFO - 2023-11-21 09:34:41 --> Loader Class Initialized
INFO - 2023-11-21 09:34:41 --> Helper loaded: url_helper
INFO - 2023-11-21 09:34:41 --> Helper loaded: file_helper
INFO - 2023-11-21 09:34:41 --> Helper loaded: form_helper
INFO - 2023-11-21 09:34:41 --> Helper loaded: my_helper
INFO - 2023-11-21 09:34:41 --> Database Driver Class Initialized
INFO - 2023-11-21 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:34:41 --> Controller Class Initialized
INFO - 2023-11-21 09:34:41 --> Final output sent to browser
DEBUG - 2023-11-21 09:34:41 --> Total execution time: 0.0803
INFO - 2023-11-21 09:34:43 --> Config Class Initialized
INFO - 2023-11-21 09:34:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:34:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:34:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:34:43 --> URI Class Initialized
INFO - 2023-11-21 09:34:43 --> Router Class Initialized
INFO - 2023-11-21 09:34:43 --> Output Class Initialized
INFO - 2023-11-21 09:34:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:34:43 --> Input Class Initialized
INFO - 2023-11-21 09:34:43 --> Language Class Initialized
INFO - 2023-11-21 09:34:43 --> Language Class Initialized
INFO - 2023-11-21 09:34:43 --> Config Class Initialized
INFO - 2023-11-21 09:34:43 --> Loader Class Initialized
INFO - 2023-11-21 09:34:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:34:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:34:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:34:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:34:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:34:43 --> Controller Class Initialized
DEBUG - 2023-11-21 09:34:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:34:46 --> Final output sent to browser
DEBUG - 2023-11-21 09:34:46 --> Total execution time: 2.5615
INFO - 2023-11-21 09:35:33 --> Config Class Initialized
INFO - 2023-11-21 09:35:33 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:35:33 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:35:33 --> Utf8 Class Initialized
INFO - 2023-11-21 09:35:33 --> URI Class Initialized
INFO - 2023-11-21 09:35:33 --> Router Class Initialized
INFO - 2023-11-21 09:35:33 --> Output Class Initialized
INFO - 2023-11-21 09:35:33 --> Security Class Initialized
DEBUG - 2023-11-21 09:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:35:33 --> Input Class Initialized
INFO - 2023-11-21 09:35:33 --> Language Class Initialized
INFO - 2023-11-21 09:35:33 --> Language Class Initialized
INFO - 2023-11-21 09:35:33 --> Config Class Initialized
INFO - 2023-11-21 09:35:33 --> Loader Class Initialized
INFO - 2023-11-21 09:35:33 --> Helper loaded: url_helper
INFO - 2023-11-21 09:35:33 --> Helper loaded: file_helper
INFO - 2023-11-21 09:35:33 --> Helper loaded: form_helper
INFO - 2023-11-21 09:35:33 --> Helper loaded: my_helper
INFO - 2023-11-21 09:35:33 --> Database Driver Class Initialized
INFO - 2023-11-21 09:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:35:33 --> Controller Class Initialized
INFO - 2023-11-21 09:35:33 --> Final output sent to browser
DEBUG - 2023-11-21 09:35:33 --> Total execution time: 0.1136
INFO - 2023-11-21 09:35:35 --> Config Class Initialized
INFO - 2023-11-21 09:35:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:35:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:35:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:35:35 --> URI Class Initialized
INFO - 2023-11-21 09:35:35 --> Router Class Initialized
INFO - 2023-11-21 09:35:35 --> Output Class Initialized
INFO - 2023-11-21 09:35:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:35:35 --> Input Class Initialized
INFO - 2023-11-21 09:35:35 --> Language Class Initialized
INFO - 2023-11-21 09:35:35 --> Language Class Initialized
INFO - 2023-11-21 09:35:35 --> Config Class Initialized
INFO - 2023-11-21 09:35:35 --> Loader Class Initialized
INFO - 2023-11-21 09:35:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:35:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:35:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:35:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:35:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:35:35 --> Controller Class Initialized
DEBUG - 2023-11-21 09:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:35:37 --> Final output sent to browser
DEBUG - 2023-11-21 09:35:37 --> Total execution time: 2.3387
INFO - 2023-11-21 09:35:56 --> Config Class Initialized
INFO - 2023-11-21 09:35:56 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:35:56 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:35:56 --> Utf8 Class Initialized
INFO - 2023-11-21 09:35:56 --> URI Class Initialized
INFO - 2023-11-21 09:35:57 --> Router Class Initialized
INFO - 2023-11-21 09:35:57 --> Output Class Initialized
INFO - 2023-11-21 09:35:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:35:57 --> Input Class Initialized
INFO - 2023-11-21 09:35:57 --> Language Class Initialized
INFO - 2023-11-21 09:35:57 --> Language Class Initialized
INFO - 2023-11-21 09:35:57 --> Config Class Initialized
INFO - 2023-11-21 09:35:57 --> Loader Class Initialized
INFO - 2023-11-21 09:35:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:35:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:35:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:35:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:35:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:35:57 --> Controller Class Initialized
INFO - 2023-11-21 09:35:57 --> Final output sent to browser
DEBUG - 2023-11-21 09:35:57 --> Total execution time: 0.1132
INFO - 2023-11-21 09:36:01 --> Config Class Initialized
INFO - 2023-11-21 09:36:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:36:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:36:01 --> Utf8 Class Initialized
INFO - 2023-11-21 09:36:01 --> URI Class Initialized
INFO - 2023-11-21 09:36:01 --> Router Class Initialized
INFO - 2023-11-21 09:36:01 --> Output Class Initialized
INFO - 2023-11-21 09:36:01 --> Security Class Initialized
DEBUG - 2023-11-21 09:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:36:01 --> Input Class Initialized
INFO - 2023-11-21 09:36:01 --> Language Class Initialized
INFO - 2023-11-21 09:36:01 --> Language Class Initialized
INFO - 2023-11-21 09:36:01 --> Config Class Initialized
INFO - 2023-11-21 09:36:01 --> Loader Class Initialized
INFO - 2023-11-21 09:36:01 --> Helper loaded: url_helper
INFO - 2023-11-21 09:36:01 --> Helper loaded: file_helper
INFO - 2023-11-21 09:36:01 --> Helper loaded: form_helper
INFO - 2023-11-21 09:36:01 --> Helper loaded: my_helper
INFO - 2023-11-21 09:36:01 --> Database Driver Class Initialized
INFO - 2023-11-21 09:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:36:01 --> Controller Class Initialized
DEBUG - 2023-11-21 09:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:36:04 --> Final output sent to browser
DEBUG - 2023-11-21 09:36:04 --> Total execution time: 3.5383
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:37:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:37:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:37:57 --> URI Class Initialized
INFO - 2023-11-21 09:37:57 --> Router Class Initialized
INFO - 2023-11-21 09:37:57 --> Output Class Initialized
INFO - 2023-11-21 09:37:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:37:57 --> Input Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Loader Class Initialized
INFO - 2023-11-21 09:37:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:37:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:37:57 --> Controller Class Initialized
INFO - 2023-11-21 09:37:57 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:37:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:37:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:37:57 --> URI Class Initialized
INFO - 2023-11-21 09:37:57 --> Router Class Initialized
INFO - 2023-11-21 09:37:57 --> Output Class Initialized
INFO - 2023-11-21 09:37:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:37:57 --> Input Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Loader Class Initialized
INFO - 2023-11-21 09:37:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:37:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:37:57 --> Controller Class Initialized
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:37:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:37:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:37:57 --> URI Class Initialized
INFO - 2023-11-21 09:37:57 --> Router Class Initialized
INFO - 2023-11-21 09:37:57 --> Output Class Initialized
INFO - 2023-11-21 09:37:57 --> Security Class Initialized
DEBUG - 2023-11-21 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:37:57 --> Input Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Language Class Initialized
INFO - 2023-11-21 09:37:57 --> Config Class Initialized
INFO - 2023-11-21 09:37:57 --> Loader Class Initialized
INFO - 2023-11-21 09:37:57 --> Helper loaded: url_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: file_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: form_helper
INFO - 2023-11-21 09:37:57 --> Helper loaded: my_helper
INFO - 2023-11-21 09:37:57 --> Database Driver Class Initialized
INFO - 2023-11-21 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:37:57 --> Controller Class Initialized
DEBUG - 2023-11-21 09:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:37:57 --> Final output sent to browser
DEBUG - 2023-11-21 09:37:57 --> Total execution time: 0.0306
INFO - 2023-11-21 09:38:01 --> Config Class Initialized
INFO - 2023-11-21 09:38:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:01 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:01 --> URI Class Initialized
INFO - 2023-11-21 09:38:01 --> Router Class Initialized
INFO - 2023-11-21 09:38:01 --> Output Class Initialized
INFO - 2023-11-21 09:38:01 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:01 --> Input Class Initialized
INFO - 2023-11-21 09:38:01 --> Language Class Initialized
INFO - 2023-11-21 09:38:01 --> Language Class Initialized
INFO - 2023-11-21 09:38:01 --> Config Class Initialized
INFO - 2023-11-21 09:38:01 --> Loader Class Initialized
INFO - 2023-11-21 09:38:01 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:01 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:01 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:01 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:01 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:01 --> Controller Class Initialized
INFO - 2023-11-21 09:38:01 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:38:01 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:01 --> Total execution time: 0.2151
INFO - 2023-11-21 09:38:02 --> Config Class Initialized
INFO - 2023-11-21 09:38:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:02 --> URI Class Initialized
INFO - 2023-11-21 09:38:02 --> Router Class Initialized
INFO - 2023-11-21 09:38:02 --> Output Class Initialized
INFO - 2023-11-21 09:38:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:02 --> Input Class Initialized
INFO - 2023-11-21 09:38:02 --> Language Class Initialized
INFO - 2023-11-21 09:38:02 --> Language Class Initialized
INFO - 2023-11-21 09:38:02 --> Config Class Initialized
INFO - 2023-11-21 09:38:02 --> Loader Class Initialized
INFO - 2023-11-21 09:38:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:02 --> Controller Class Initialized
DEBUG - 2023-11-21 09:38:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:38:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:38:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:02 --> Total execution time: 0.0503
INFO - 2023-11-21 09:38:08 --> Config Class Initialized
INFO - 2023-11-21 09:38:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:08 --> URI Class Initialized
INFO - 2023-11-21 09:38:08 --> Router Class Initialized
INFO - 2023-11-21 09:38:08 --> Output Class Initialized
INFO - 2023-11-21 09:38:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:08 --> Input Class Initialized
INFO - 2023-11-21 09:38:08 --> Language Class Initialized
INFO - 2023-11-21 09:38:09 --> Language Class Initialized
INFO - 2023-11-21 09:38:09 --> Config Class Initialized
INFO - 2023-11-21 09:38:09 --> Loader Class Initialized
INFO - 2023-11-21 09:38:09 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:09 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:09 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:09 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:09 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:09 --> Controller Class Initialized
DEBUG - 2023-11-21 09:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-11-21 09:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:38:09 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:09 --> Total execution time: 0.0490
INFO - 2023-11-21 09:38:20 --> Config Class Initialized
INFO - 2023-11-21 09:38:20 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:20 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:20 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:20 --> URI Class Initialized
INFO - 2023-11-21 09:38:20 --> Router Class Initialized
INFO - 2023-11-21 09:38:20 --> Output Class Initialized
INFO - 2023-11-21 09:38:20 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:20 --> Input Class Initialized
INFO - 2023-11-21 09:38:20 --> Language Class Initialized
INFO - 2023-11-21 09:38:20 --> Language Class Initialized
INFO - 2023-11-21 09:38:20 --> Config Class Initialized
INFO - 2023-11-21 09:38:20 --> Loader Class Initialized
INFO - 2023-11-21 09:38:20 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:20 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:20 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:20 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:20 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:20 --> Controller Class Initialized
INFO - 2023-11-21 09:38:20 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:20 --> Total execution time: 0.0817
INFO - 2023-11-21 09:38:23 --> Config Class Initialized
INFO - 2023-11-21 09:38:23 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:23 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:23 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:23 --> URI Class Initialized
INFO - 2023-11-21 09:38:23 --> Router Class Initialized
INFO - 2023-11-21 09:38:23 --> Output Class Initialized
INFO - 2023-11-21 09:38:23 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:23 --> Input Class Initialized
INFO - 2023-11-21 09:38:23 --> Language Class Initialized
INFO - 2023-11-21 09:38:23 --> Language Class Initialized
INFO - 2023-11-21 09:38:23 --> Config Class Initialized
INFO - 2023-11-21 09:38:23 --> Loader Class Initialized
INFO - 2023-11-21 09:38:23 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:23 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:23 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:23 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:23 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:23 --> Controller Class Initialized
DEBUG - 2023-11-21 09:38:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 09:38:26 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:26 --> Total execution time: 3.2990
INFO - 2023-11-21 09:38:44 --> Config Class Initialized
INFO - 2023-11-21 09:38:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:45 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:45 --> URI Class Initialized
INFO - 2023-11-21 09:38:45 --> Router Class Initialized
INFO - 2023-11-21 09:38:45 --> Output Class Initialized
INFO - 2023-11-21 09:38:45 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:45 --> Input Class Initialized
INFO - 2023-11-21 09:38:45 --> Language Class Initialized
INFO - 2023-11-21 09:38:45 --> Language Class Initialized
INFO - 2023-11-21 09:38:45 --> Config Class Initialized
INFO - 2023-11-21 09:38:45 --> Loader Class Initialized
INFO - 2023-11-21 09:38:45 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:45 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:45 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:45 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:45 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:45 --> Controller Class Initialized
INFO - 2023-11-21 09:38:45 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:45 --> Total execution time: 0.4488
INFO - 2023-11-21 09:38:49 --> Config Class Initialized
INFO - 2023-11-21 09:38:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:49 --> URI Class Initialized
INFO - 2023-11-21 09:38:49 --> Router Class Initialized
INFO - 2023-11-21 09:38:49 --> Output Class Initialized
INFO - 2023-11-21 09:38:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:49 --> Input Class Initialized
INFO - 2023-11-21 09:38:49 --> Language Class Initialized
INFO - 2023-11-21 09:38:49 --> Language Class Initialized
INFO - 2023-11-21 09:38:49 --> Config Class Initialized
INFO - 2023-11-21 09:38:49 --> Loader Class Initialized
INFO - 2023-11-21 09:38:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:50 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:50 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:50 --> Controller Class Initialized
DEBUG - 2023-11-21 09:38:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-21 09:38:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:38:50 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:50 --> Total execution time: 0.0530
INFO - 2023-11-21 09:38:52 --> Config Class Initialized
INFO - 2023-11-21 09:38:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:38:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:38:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:38:52 --> URI Class Initialized
INFO - 2023-11-21 09:38:52 --> Router Class Initialized
INFO - 2023-11-21 09:38:52 --> Output Class Initialized
INFO - 2023-11-21 09:38:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:38:52 --> Input Class Initialized
INFO - 2023-11-21 09:38:52 --> Language Class Initialized
INFO - 2023-11-21 09:38:52 --> Language Class Initialized
INFO - 2023-11-21 09:38:52 --> Config Class Initialized
INFO - 2023-11-21 09:38:52 --> Loader Class Initialized
INFO - 2023-11-21 09:38:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:38:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:38:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:38:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:38:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:38:52 --> Controller Class Initialized
DEBUG - 2023-11-21 09:38:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-21 09:38:58 --> Final output sent to browser
DEBUG - 2023-11-21 09:38:58 --> Total execution time: 5.8427
INFO - 2023-11-21 09:39:27 --> Config Class Initialized
INFO - 2023-11-21 09:39:27 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:39:27 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:39:27 --> Utf8 Class Initialized
INFO - 2023-11-21 09:39:27 --> URI Class Initialized
INFO - 2023-11-21 09:39:27 --> Router Class Initialized
INFO - 2023-11-21 09:39:27 --> Output Class Initialized
INFO - 2023-11-21 09:39:27 --> Security Class Initialized
DEBUG - 2023-11-21 09:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:39:27 --> Input Class Initialized
INFO - 2023-11-21 09:39:27 --> Language Class Initialized
INFO - 2023-11-21 09:39:27 --> Language Class Initialized
INFO - 2023-11-21 09:39:27 --> Config Class Initialized
INFO - 2023-11-21 09:39:27 --> Loader Class Initialized
INFO - 2023-11-21 09:39:27 --> Helper loaded: url_helper
INFO - 2023-11-21 09:39:27 --> Helper loaded: file_helper
INFO - 2023-11-21 09:39:27 --> Helper loaded: form_helper
INFO - 2023-11-21 09:39:27 --> Helper loaded: my_helper
INFO - 2023-11-21 09:39:27 --> Database Driver Class Initialized
INFO - 2023-11-21 09:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:39:27 --> Controller Class Initialized
DEBUG - 2023-11-21 09:39:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-11-21 09:39:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:39:27 --> Final output sent to browser
DEBUG - 2023-11-21 09:39:27 --> Total execution time: 0.0569
INFO - 2023-11-21 09:47:57 --> Config Class Initialized
INFO - 2023-11-21 09:47:57 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:47:57 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:47:57 --> Utf8 Class Initialized
INFO - 2023-11-21 09:47:57 --> URI Class Initialized
INFO - 2023-11-21 09:47:58 --> Router Class Initialized
INFO - 2023-11-21 09:47:58 --> Output Class Initialized
INFO - 2023-11-21 09:47:58 --> Security Class Initialized
DEBUG - 2023-11-21 09:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:47:58 --> Input Class Initialized
INFO - 2023-11-21 09:47:58 --> Language Class Initialized
INFO - 2023-11-21 09:47:58 --> Language Class Initialized
INFO - 2023-11-21 09:47:58 --> Config Class Initialized
INFO - 2023-11-21 09:47:58 --> Loader Class Initialized
INFO - 2023-11-21 09:47:58 --> Helper loaded: url_helper
INFO - 2023-11-21 09:47:58 --> Helper loaded: file_helper
INFO - 2023-11-21 09:47:58 --> Helper loaded: form_helper
INFO - 2023-11-21 09:47:58 --> Helper loaded: my_helper
INFO - 2023-11-21 09:47:58 --> Database Driver Class Initialized
INFO - 2023-11-21 09:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:47:58 --> Controller Class Initialized
INFO - 2023-11-21 09:47:58 --> Final output sent to browser
DEBUG - 2023-11-21 09:47:58 --> Total execution time: 0.5542
INFO - 2023-11-21 09:48:06 --> Config Class Initialized
INFO - 2023-11-21 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:48:06 --> Utf8 Class Initialized
INFO - 2023-11-21 09:48:06 --> URI Class Initialized
INFO - 2023-11-21 09:48:06 --> Router Class Initialized
INFO - 2023-11-21 09:48:06 --> Output Class Initialized
INFO - 2023-11-21 09:48:06 --> Security Class Initialized
DEBUG - 2023-11-21 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:48:06 --> Input Class Initialized
INFO - 2023-11-21 09:48:06 --> Language Class Initialized
INFO - 2023-11-21 09:48:06 --> Language Class Initialized
INFO - 2023-11-21 09:48:06 --> Config Class Initialized
INFO - 2023-11-21 09:48:06 --> Loader Class Initialized
INFO - 2023-11-21 09:48:06 --> Helper loaded: url_helper
INFO - 2023-11-21 09:48:06 --> Helper loaded: file_helper
INFO - 2023-11-21 09:48:06 --> Helper loaded: form_helper
INFO - 2023-11-21 09:48:06 --> Helper loaded: my_helper
INFO - 2023-11-21 09:48:06 --> Database Driver Class Initialized
INFO - 2023-11-21 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:48:06 --> Controller Class Initialized
INFO - 2023-11-21 09:48:06 --> Final output sent to browser
DEBUG - 2023-11-21 09:48:06 --> Total execution time: 0.0368
INFO - 2023-11-21 09:48:28 --> Config Class Initialized
INFO - 2023-11-21 09:48:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:48:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:48:28 --> Utf8 Class Initialized
INFO - 2023-11-21 09:48:28 --> URI Class Initialized
INFO - 2023-11-21 09:48:28 --> Router Class Initialized
INFO - 2023-11-21 09:48:28 --> Output Class Initialized
INFO - 2023-11-21 09:48:28 --> Security Class Initialized
DEBUG - 2023-11-21 09:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:48:28 --> Input Class Initialized
INFO - 2023-11-21 09:48:28 --> Language Class Initialized
INFO - 2023-11-21 09:48:28 --> Language Class Initialized
INFO - 2023-11-21 09:48:28 --> Config Class Initialized
INFO - 2023-11-21 09:48:28 --> Loader Class Initialized
INFO - 2023-11-21 09:48:28 --> Helper loaded: url_helper
INFO - 2023-11-21 09:48:28 --> Helper loaded: file_helper
INFO - 2023-11-21 09:48:28 --> Helper loaded: form_helper
INFO - 2023-11-21 09:48:28 --> Helper loaded: my_helper
INFO - 2023-11-21 09:48:28 --> Database Driver Class Initialized
INFO - 2023-11-21 09:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:48:28 --> Controller Class Initialized
INFO - 2023-11-21 09:48:28 --> Final output sent to browser
DEBUG - 2023-11-21 09:48:28 --> Total execution time: 0.0543
INFO - 2023-11-21 09:48:52 --> Config Class Initialized
INFO - 2023-11-21 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:48:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:48:52 --> URI Class Initialized
INFO - 2023-11-21 09:48:52 --> Router Class Initialized
INFO - 2023-11-21 09:48:52 --> Output Class Initialized
INFO - 2023-11-21 09:48:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:48:52 --> Input Class Initialized
INFO - 2023-11-21 09:48:52 --> Language Class Initialized
INFO - 2023-11-21 09:48:52 --> Language Class Initialized
INFO - 2023-11-21 09:48:52 --> Config Class Initialized
INFO - 2023-11-21 09:48:52 --> Loader Class Initialized
INFO - 2023-11-21 09:48:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:48:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:48:52 --> Controller Class Initialized
INFO - 2023-11-21 09:48:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:48:52 --> Total execution time: 0.3424
INFO - 2023-11-21 09:48:52 --> Config Class Initialized
INFO - 2023-11-21 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:48:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:48:52 --> URI Class Initialized
INFO - 2023-11-21 09:48:52 --> Router Class Initialized
INFO - 2023-11-21 09:48:52 --> Output Class Initialized
INFO - 2023-11-21 09:48:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:48:52 --> Input Class Initialized
INFO - 2023-11-21 09:48:52 --> Language Class Initialized
ERROR - 2023-11-21 09:48:52 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:48:52 --> Config Class Initialized
INFO - 2023-11-21 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:48:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:48:52 --> URI Class Initialized
INFO - 2023-11-21 09:48:52 --> Router Class Initialized
INFO - 2023-11-21 09:48:52 --> Output Class Initialized
INFO - 2023-11-21 09:48:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:48:52 --> Input Class Initialized
INFO - 2023-11-21 09:48:52 --> Language Class Initialized
INFO - 2023-11-21 09:48:52 --> Language Class Initialized
INFO - 2023-11-21 09:48:52 --> Config Class Initialized
INFO - 2023-11-21 09:48:52 --> Loader Class Initialized
INFO - 2023-11-21 09:48:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:48:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:48:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:48:52 --> Controller Class Initialized
INFO - 2023-11-21 09:49:02 --> Config Class Initialized
INFO - 2023-11-21 09:49:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:02 --> URI Class Initialized
INFO - 2023-11-21 09:49:02 --> Router Class Initialized
INFO - 2023-11-21 09:49:02 --> Output Class Initialized
INFO - 2023-11-21 09:49:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:02 --> Input Class Initialized
INFO - 2023-11-21 09:49:02 --> Language Class Initialized
INFO - 2023-11-21 09:49:02 --> Language Class Initialized
INFO - 2023-11-21 09:49:02 --> Config Class Initialized
INFO - 2023-11-21 09:49:02 --> Loader Class Initialized
INFO - 2023-11-21 09:49:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:02 --> Controller Class Initialized
INFO - 2023-11-21 09:49:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:49:02 --> Total execution time: 0.2551
INFO - 2023-11-21 09:49:21 --> Config Class Initialized
INFO - 2023-11-21 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:21 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:21 --> URI Class Initialized
INFO - 2023-11-21 09:49:21 --> Router Class Initialized
INFO - 2023-11-21 09:49:21 --> Output Class Initialized
INFO - 2023-11-21 09:49:21 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:21 --> Input Class Initialized
INFO - 2023-11-21 09:49:21 --> Language Class Initialized
INFO - 2023-11-21 09:49:21 --> Language Class Initialized
INFO - 2023-11-21 09:49:21 --> Config Class Initialized
INFO - 2023-11-21 09:49:21 --> Loader Class Initialized
INFO - 2023-11-21 09:49:21 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:21 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:21 --> Controller Class Initialized
INFO - 2023-11-21 09:49:21 --> Final output sent to browser
DEBUG - 2023-11-21 09:49:21 --> Total execution time: 0.0847
INFO - 2023-11-21 09:49:21 --> Config Class Initialized
INFO - 2023-11-21 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:21 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:21 --> URI Class Initialized
INFO - 2023-11-21 09:49:21 --> Router Class Initialized
INFO - 2023-11-21 09:49:21 --> Output Class Initialized
INFO - 2023-11-21 09:49:21 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:21 --> Input Class Initialized
INFO - 2023-11-21 09:49:21 --> Language Class Initialized
ERROR - 2023-11-21 09:49:21 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:49:21 --> Config Class Initialized
INFO - 2023-11-21 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:21 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:21 --> URI Class Initialized
INFO - 2023-11-21 09:49:21 --> Router Class Initialized
INFO - 2023-11-21 09:49:21 --> Output Class Initialized
INFO - 2023-11-21 09:49:21 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:21 --> Input Class Initialized
INFO - 2023-11-21 09:49:21 --> Language Class Initialized
INFO - 2023-11-21 09:49:21 --> Language Class Initialized
INFO - 2023-11-21 09:49:21 --> Config Class Initialized
INFO - 2023-11-21 09:49:21 --> Loader Class Initialized
INFO - 2023-11-21 09:49:21 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:21 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:21 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:21 --> Controller Class Initialized
INFO - 2023-11-21 09:49:28 --> Config Class Initialized
INFO - 2023-11-21 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:28 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:28 --> URI Class Initialized
INFO - 2023-11-21 09:49:28 --> Router Class Initialized
INFO - 2023-11-21 09:49:28 --> Output Class Initialized
INFO - 2023-11-21 09:49:28 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:28 --> Input Class Initialized
INFO - 2023-11-21 09:49:28 --> Language Class Initialized
INFO - 2023-11-21 09:49:28 --> Language Class Initialized
INFO - 2023-11-21 09:49:28 --> Config Class Initialized
INFO - 2023-11-21 09:49:28 --> Loader Class Initialized
INFO - 2023-11-21 09:49:28 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:28 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:28 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:28 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:28 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:28 --> Controller Class Initialized
INFO - 2023-11-21 09:49:28 --> Final output sent to browser
DEBUG - 2023-11-21 09:49:28 --> Total execution time: 0.0435
INFO - 2023-11-21 09:49:44 --> Config Class Initialized
INFO - 2023-11-21 09:49:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:44 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:44 --> URI Class Initialized
INFO - 2023-11-21 09:49:44 --> Router Class Initialized
INFO - 2023-11-21 09:49:44 --> Output Class Initialized
INFO - 2023-11-21 09:49:44 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:44 --> Input Class Initialized
INFO - 2023-11-21 09:49:44 --> Language Class Initialized
INFO - 2023-11-21 09:49:44 --> Language Class Initialized
INFO - 2023-11-21 09:49:44 --> Config Class Initialized
INFO - 2023-11-21 09:49:44 --> Loader Class Initialized
INFO - 2023-11-21 09:49:44 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:44 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:44 --> Controller Class Initialized
INFO - 2023-11-21 09:49:44 --> Final output sent to browser
DEBUG - 2023-11-21 09:49:44 --> Total execution time: 0.0982
INFO - 2023-11-21 09:49:44 --> Config Class Initialized
INFO - 2023-11-21 09:49:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:44 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:44 --> URI Class Initialized
INFO - 2023-11-21 09:49:44 --> Router Class Initialized
INFO - 2023-11-21 09:49:44 --> Output Class Initialized
INFO - 2023-11-21 09:49:44 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:44 --> Input Class Initialized
INFO - 2023-11-21 09:49:44 --> Language Class Initialized
ERROR - 2023-11-21 09:49:44 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:49:44 --> Config Class Initialized
INFO - 2023-11-21 09:49:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:44 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:44 --> URI Class Initialized
INFO - 2023-11-21 09:49:44 --> Router Class Initialized
INFO - 2023-11-21 09:49:44 --> Output Class Initialized
INFO - 2023-11-21 09:49:44 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:44 --> Input Class Initialized
INFO - 2023-11-21 09:49:44 --> Language Class Initialized
INFO - 2023-11-21 09:49:44 --> Language Class Initialized
INFO - 2023-11-21 09:49:44 --> Config Class Initialized
INFO - 2023-11-21 09:49:44 --> Loader Class Initialized
INFO - 2023-11-21 09:49:44 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:44 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:44 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:44 --> Controller Class Initialized
INFO - 2023-11-21 09:49:59 --> Config Class Initialized
INFO - 2023-11-21 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:59 --> URI Class Initialized
INFO - 2023-11-21 09:49:59 --> Router Class Initialized
INFO - 2023-11-21 09:49:59 --> Output Class Initialized
INFO - 2023-11-21 09:49:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:59 --> Input Class Initialized
INFO - 2023-11-21 09:49:59 --> Language Class Initialized
INFO - 2023-11-21 09:49:59 --> Language Class Initialized
INFO - 2023-11-21 09:49:59 --> Config Class Initialized
INFO - 2023-11-21 09:49:59 --> Loader Class Initialized
INFO - 2023-11-21 09:49:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:59 --> Controller Class Initialized
DEBUG - 2023-11-21 09:49:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:49:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:49:59 --> Final output sent to browser
DEBUG - 2023-11-21 09:49:59 --> Total execution time: 0.0437
INFO - 2023-11-21 09:49:59 --> Config Class Initialized
INFO - 2023-11-21 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:59 --> URI Class Initialized
INFO - 2023-11-21 09:49:59 --> Router Class Initialized
INFO - 2023-11-21 09:49:59 --> Output Class Initialized
INFO - 2023-11-21 09:49:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:59 --> Input Class Initialized
INFO - 2023-11-21 09:49:59 --> Language Class Initialized
ERROR - 2023-11-21 09:49:59 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:49:59 --> Config Class Initialized
INFO - 2023-11-21 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:49:59 --> Utf8 Class Initialized
INFO - 2023-11-21 09:49:59 --> URI Class Initialized
INFO - 2023-11-21 09:49:59 --> Router Class Initialized
INFO - 2023-11-21 09:49:59 --> Output Class Initialized
INFO - 2023-11-21 09:49:59 --> Security Class Initialized
DEBUG - 2023-11-21 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:49:59 --> Input Class Initialized
INFO - 2023-11-21 09:49:59 --> Language Class Initialized
INFO - 2023-11-21 09:49:59 --> Language Class Initialized
INFO - 2023-11-21 09:49:59 --> Config Class Initialized
INFO - 2023-11-21 09:49:59 --> Loader Class Initialized
INFO - 2023-11-21 09:49:59 --> Helper loaded: url_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: file_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: form_helper
INFO - 2023-11-21 09:49:59 --> Helper loaded: my_helper
INFO - 2023-11-21 09:49:59 --> Database Driver Class Initialized
INFO - 2023-11-21 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:49:59 --> Controller Class Initialized
INFO - 2023-11-21 09:50:11 --> Config Class Initialized
INFO - 2023-11-21 09:50:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:11 --> URI Class Initialized
INFO - 2023-11-21 09:50:11 --> Router Class Initialized
INFO - 2023-11-21 09:50:11 --> Output Class Initialized
INFO - 2023-11-21 09:50:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:11 --> Input Class Initialized
INFO - 2023-11-21 09:50:11 --> Language Class Initialized
INFO - 2023-11-21 09:50:11 --> Language Class Initialized
INFO - 2023-11-21 09:50:11 --> Config Class Initialized
INFO - 2023-11-21 09:50:11 --> Loader Class Initialized
INFO - 2023-11-21 09:50:11 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:11 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:11 --> Controller Class Initialized
DEBUG - 2023-11-21 09:50:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-11-21 09:50:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:50:11 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:11 --> Total execution time: 0.0308
INFO - 2023-11-21 09:50:11 --> Config Class Initialized
INFO - 2023-11-21 09:50:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:11 --> URI Class Initialized
INFO - 2023-11-21 09:50:11 --> Router Class Initialized
INFO - 2023-11-21 09:50:11 --> Output Class Initialized
INFO - 2023-11-21 09:50:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:11 --> Input Class Initialized
INFO - 2023-11-21 09:50:11 --> Language Class Initialized
ERROR - 2023-11-21 09:50:11 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:50:11 --> Config Class Initialized
INFO - 2023-11-21 09:50:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:11 --> URI Class Initialized
INFO - 2023-11-21 09:50:11 --> Router Class Initialized
INFO - 2023-11-21 09:50:11 --> Output Class Initialized
INFO - 2023-11-21 09:50:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:11 --> Input Class Initialized
INFO - 2023-11-21 09:50:11 --> Language Class Initialized
INFO - 2023-11-21 09:50:11 --> Language Class Initialized
INFO - 2023-11-21 09:50:11 --> Config Class Initialized
INFO - 2023-11-21 09:50:11 --> Loader Class Initialized
INFO - 2023-11-21 09:50:11 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:11 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:11 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:11 --> Controller Class Initialized
INFO - 2023-11-21 09:50:13 --> Config Class Initialized
INFO - 2023-11-21 09:50:13 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:13 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:13 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:13 --> URI Class Initialized
INFO - 2023-11-21 09:50:13 --> Router Class Initialized
INFO - 2023-11-21 09:50:13 --> Output Class Initialized
INFO - 2023-11-21 09:50:13 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:13 --> Input Class Initialized
INFO - 2023-11-21 09:50:13 --> Language Class Initialized
INFO - 2023-11-21 09:50:13 --> Language Class Initialized
INFO - 2023-11-21 09:50:13 --> Config Class Initialized
INFO - 2023-11-21 09:50:13 --> Loader Class Initialized
INFO - 2023-11-21 09:50:13 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:13 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:13 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:13 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:13 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:13 --> Controller Class Initialized
INFO - 2023-11-21 09:50:13 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:13 --> Total execution time: 0.0317
INFO - 2023-11-21 09:50:29 --> Config Class Initialized
INFO - 2023-11-21 09:50:29 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:29 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:29 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:29 --> URI Class Initialized
INFO - 2023-11-21 09:50:29 --> Router Class Initialized
INFO - 2023-11-21 09:50:29 --> Output Class Initialized
INFO - 2023-11-21 09:50:29 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:29 --> Input Class Initialized
INFO - 2023-11-21 09:50:29 --> Language Class Initialized
INFO - 2023-11-21 09:50:29 --> Language Class Initialized
INFO - 2023-11-21 09:50:29 --> Config Class Initialized
INFO - 2023-11-21 09:50:29 --> Loader Class Initialized
INFO - 2023-11-21 09:50:29 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:29 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:30 --> Controller Class Initialized
INFO - 2023-11-21 09:50:30 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:30 --> Total execution time: 0.0632
INFO - 2023-11-21 09:50:30 --> Config Class Initialized
INFO - 2023-11-21 09:50:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:30 --> URI Class Initialized
INFO - 2023-11-21 09:50:30 --> Router Class Initialized
INFO - 2023-11-21 09:50:30 --> Output Class Initialized
INFO - 2023-11-21 09:50:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:30 --> Input Class Initialized
INFO - 2023-11-21 09:50:30 --> Language Class Initialized
ERROR - 2023-11-21 09:50:30 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:50:30 --> Config Class Initialized
INFO - 2023-11-21 09:50:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:30 --> URI Class Initialized
INFO - 2023-11-21 09:50:30 --> Router Class Initialized
INFO - 2023-11-21 09:50:30 --> Output Class Initialized
INFO - 2023-11-21 09:50:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:30 --> Input Class Initialized
INFO - 2023-11-21 09:50:30 --> Language Class Initialized
INFO - 2023-11-21 09:50:30 --> Language Class Initialized
INFO - 2023-11-21 09:50:30 --> Config Class Initialized
INFO - 2023-11-21 09:50:30 --> Loader Class Initialized
INFO - 2023-11-21 09:50:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:30 --> Controller Class Initialized
INFO - 2023-11-21 09:50:34 --> Config Class Initialized
INFO - 2023-11-21 09:50:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:34 --> URI Class Initialized
INFO - 2023-11-21 09:50:34 --> Router Class Initialized
INFO - 2023-11-21 09:50:34 --> Output Class Initialized
INFO - 2023-11-21 09:50:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:34 --> Input Class Initialized
INFO - 2023-11-21 09:50:34 --> Language Class Initialized
INFO - 2023-11-21 09:50:34 --> Language Class Initialized
INFO - 2023-11-21 09:50:34 --> Config Class Initialized
INFO - 2023-11-21 09:50:34 --> Loader Class Initialized
INFO - 2023-11-21 09:50:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:34 --> Controller Class Initialized
INFO - 2023-11-21 09:50:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:34 --> Total execution time: 0.0357
INFO - 2023-11-21 09:50:35 --> Config Class Initialized
INFO - 2023-11-21 09:50:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:35 --> URI Class Initialized
INFO - 2023-11-21 09:50:35 --> Router Class Initialized
INFO - 2023-11-21 09:50:35 --> Output Class Initialized
INFO - 2023-11-21 09:50:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:35 --> Input Class Initialized
INFO - 2023-11-21 09:50:35 --> Language Class Initialized
INFO - 2023-11-21 09:50:35 --> Language Class Initialized
INFO - 2023-11-21 09:50:35 --> Config Class Initialized
INFO - 2023-11-21 09:50:35 --> Loader Class Initialized
INFO - 2023-11-21 09:50:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:35 --> Controller Class Initialized
INFO - 2023-11-21 09:50:35 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:35 --> Total execution time: 0.0308
INFO - 2023-11-21 09:50:35 --> Config Class Initialized
INFO - 2023-11-21 09:50:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:35 --> URI Class Initialized
INFO - 2023-11-21 09:50:35 --> Router Class Initialized
INFO - 2023-11-21 09:50:35 --> Output Class Initialized
INFO - 2023-11-21 09:50:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:35 --> Input Class Initialized
INFO - 2023-11-21 09:50:35 --> Language Class Initialized
ERROR - 2023-11-21 09:50:35 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:50:35 --> Config Class Initialized
INFO - 2023-11-21 09:50:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:35 --> URI Class Initialized
INFO - 2023-11-21 09:50:35 --> Router Class Initialized
INFO - 2023-11-21 09:50:35 --> Output Class Initialized
INFO - 2023-11-21 09:50:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:35 --> Input Class Initialized
INFO - 2023-11-21 09:50:35 --> Language Class Initialized
INFO - 2023-11-21 09:50:35 --> Language Class Initialized
INFO - 2023-11-21 09:50:35 --> Config Class Initialized
INFO - 2023-11-21 09:50:35 --> Loader Class Initialized
INFO - 2023-11-21 09:50:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:35 --> Controller Class Initialized
INFO - 2023-11-21 09:50:37 --> Config Class Initialized
INFO - 2023-11-21 09:50:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:37 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:37 --> URI Class Initialized
INFO - 2023-11-21 09:50:37 --> Router Class Initialized
INFO - 2023-11-21 09:50:37 --> Output Class Initialized
INFO - 2023-11-21 09:50:37 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:37 --> Input Class Initialized
INFO - 2023-11-21 09:50:37 --> Language Class Initialized
INFO - 2023-11-21 09:50:37 --> Language Class Initialized
INFO - 2023-11-21 09:50:37 --> Config Class Initialized
INFO - 2023-11-21 09:50:37 --> Loader Class Initialized
INFO - 2023-11-21 09:50:37 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:37 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:37 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:37 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:37 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:37 --> Controller Class Initialized
INFO - 2023-11-21 09:50:37 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:37 --> Total execution time: 0.0313
INFO - 2023-11-21 09:50:41 --> Config Class Initialized
INFO - 2023-11-21 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:41 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:41 --> URI Class Initialized
INFO - 2023-11-21 09:50:41 --> Router Class Initialized
INFO - 2023-11-21 09:50:41 --> Output Class Initialized
INFO - 2023-11-21 09:50:41 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:41 --> Input Class Initialized
INFO - 2023-11-21 09:50:41 --> Language Class Initialized
INFO - 2023-11-21 09:50:41 --> Language Class Initialized
INFO - 2023-11-21 09:50:41 --> Config Class Initialized
INFO - 2023-11-21 09:50:41 --> Loader Class Initialized
INFO - 2023-11-21 09:50:41 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:41 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:41 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:41 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:41 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:41 --> Controller Class Initialized
INFO - 2023-11-21 09:50:41 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:41 --> Total execution time: 0.0343
INFO - 2023-11-21 09:50:41 --> Config Class Initialized
INFO - 2023-11-21 09:50:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:41 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:41 --> URI Class Initialized
INFO - 2023-11-21 09:50:41 --> Router Class Initialized
INFO - 2023-11-21 09:50:41 --> Output Class Initialized
INFO - 2023-11-21 09:50:41 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:41 --> Input Class Initialized
INFO - 2023-11-21 09:50:41 --> Language Class Initialized
ERROR - 2023-11-21 09:50:41 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:50:42 --> Config Class Initialized
INFO - 2023-11-21 09:50:42 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:42 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:42 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:42 --> URI Class Initialized
INFO - 2023-11-21 09:50:42 --> Router Class Initialized
INFO - 2023-11-21 09:50:42 --> Output Class Initialized
INFO - 2023-11-21 09:50:42 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:42 --> Input Class Initialized
INFO - 2023-11-21 09:50:42 --> Language Class Initialized
INFO - 2023-11-21 09:50:42 --> Language Class Initialized
INFO - 2023-11-21 09:50:42 --> Config Class Initialized
INFO - 2023-11-21 09:50:42 --> Loader Class Initialized
INFO - 2023-11-21 09:50:42 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:42 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:42 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:42 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:42 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:42 --> Controller Class Initialized
INFO - 2023-11-21 09:50:43 --> Config Class Initialized
INFO - 2023-11-21 09:50:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:43 --> URI Class Initialized
INFO - 2023-11-21 09:50:43 --> Router Class Initialized
INFO - 2023-11-21 09:50:43 --> Output Class Initialized
INFO - 2023-11-21 09:50:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:43 --> Input Class Initialized
INFO - 2023-11-21 09:50:43 --> Language Class Initialized
INFO - 2023-11-21 09:50:43 --> Language Class Initialized
INFO - 2023-11-21 09:50:43 --> Config Class Initialized
INFO - 2023-11-21 09:50:43 --> Loader Class Initialized
INFO - 2023-11-21 09:50:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:43 --> Controller Class Initialized
INFO - 2023-11-21 09:50:43 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:43 --> Total execution time: 0.0353
INFO - 2023-11-21 09:50:47 --> Config Class Initialized
INFO - 2023-11-21 09:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:47 --> URI Class Initialized
INFO - 2023-11-21 09:50:47 --> Router Class Initialized
INFO - 2023-11-21 09:50:47 --> Output Class Initialized
INFO - 2023-11-21 09:50:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:47 --> Input Class Initialized
INFO - 2023-11-21 09:50:47 --> Language Class Initialized
INFO - 2023-11-21 09:50:47 --> Language Class Initialized
INFO - 2023-11-21 09:50:47 --> Config Class Initialized
INFO - 2023-11-21 09:50:47 --> Loader Class Initialized
INFO - 2023-11-21 09:50:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:47 --> Controller Class Initialized
INFO - 2023-11-21 09:50:47 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:47 --> Total execution time: 0.0914
INFO - 2023-11-21 09:50:47 --> Config Class Initialized
INFO - 2023-11-21 09:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:47 --> URI Class Initialized
INFO - 2023-11-21 09:50:47 --> Router Class Initialized
INFO - 2023-11-21 09:50:47 --> Output Class Initialized
INFO - 2023-11-21 09:50:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:47 --> Input Class Initialized
INFO - 2023-11-21 09:50:47 --> Language Class Initialized
ERROR - 2023-11-21 09:50:47 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:50:47 --> Config Class Initialized
INFO - 2023-11-21 09:50:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:47 --> URI Class Initialized
INFO - 2023-11-21 09:50:47 --> Router Class Initialized
INFO - 2023-11-21 09:50:47 --> Output Class Initialized
INFO - 2023-11-21 09:50:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:47 --> Input Class Initialized
INFO - 2023-11-21 09:50:47 --> Language Class Initialized
INFO - 2023-11-21 09:50:47 --> Language Class Initialized
INFO - 2023-11-21 09:50:47 --> Config Class Initialized
INFO - 2023-11-21 09:50:47 --> Loader Class Initialized
INFO - 2023-11-21 09:50:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:47 --> Controller Class Initialized
INFO - 2023-11-21 09:50:49 --> Config Class Initialized
INFO - 2023-11-21 09:50:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:50:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:50:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:50:49 --> URI Class Initialized
INFO - 2023-11-21 09:50:49 --> Router Class Initialized
INFO - 2023-11-21 09:50:49 --> Output Class Initialized
INFO - 2023-11-21 09:50:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:50:49 --> Input Class Initialized
INFO - 2023-11-21 09:50:49 --> Language Class Initialized
INFO - 2023-11-21 09:50:49 --> Language Class Initialized
INFO - 2023-11-21 09:50:49 --> Config Class Initialized
INFO - 2023-11-21 09:50:49 --> Loader Class Initialized
INFO - 2023-11-21 09:50:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:50:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:50:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:50:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:50:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:50:49 --> Controller Class Initialized
INFO - 2023-11-21 09:50:49 --> Final output sent to browser
DEBUG - 2023-11-21 09:50:49 --> Total execution time: 0.0392
INFO - 2023-11-21 09:51:34 --> Config Class Initialized
INFO - 2023-11-21 09:51:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:34 --> URI Class Initialized
INFO - 2023-11-21 09:51:34 --> Router Class Initialized
INFO - 2023-11-21 09:51:34 --> Output Class Initialized
INFO - 2023-11-21 09:51:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:34 --> Input Class Initialized
INFO - 2023-11-21 09:51:34 --> Language Class Initialized
INFO - 2023-11-21 09:51:34 --> Language Class Initialized
INFO - 2023-11-21 09:51:34 --> Config Class Initialized
INFO - 2023-11-21 09:51:34 --> Loader Class Initialized
INFO - 2023-11-21 09:51:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:34 --> Controller Class Initialized
INFO - 2023-11-21 09:51:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:51:34 --> Total execution time: 0.0361
INFO - 2023-11-21 09:51:38 --> Config Class Initialized
INFO - 2023-11-21 09:51:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:38 --> URI Class Initialized
INFO - 2023-11-21 09:51:38 --> Router Class Initialized
INFO - 2023-11-21 09:51:38 --> Output Class Initialized
INFO - 2023-11-21 09:51:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:38 --> Input Class Initialized
INFO - 2023-11-21 09:51:38 --> Language Class Initialized
INFO - 2023-11-21 09:51:38 --> Language Class Initialized
INFO - 2023-11-21 09:51:38 --> Config Class Initialized
INFO - 2023-11-21 09:51:38 --> Loader Class Initialized
INFO - 2023-11-21 09:51:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:38 --> Controller Class Initialized
INFO - 2023-11-21 09:51:38 --> Final output sent to browser
DEBUG - 2023-11-21 09:51:38 --> Total execution time: 0.0411
INFO - 2023-11-21 09:51:38 --> Config Class Initialized
INFO - 2023-11-21 09:51:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:38 --> URI Class Initialized
INFO - 2023-11-21 09:51:38 --> Router Class Initialized
INFO - 2023-11-21 09:51:38 --> Output Class Initialized
INFO - 2023-11-21 09:51:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:38 --> Input Class Initialized
INFO - 2023-11-21 09:51:38 --> Language Class Initialized
ERROR - 2023-11-21 09:51:38 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:51:38 --> Config Class Initialized
INFO - 2023-11-21 09:51:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:38 --> URI Class Initialized
INFO - 2023-11-21 09:51:38 --> Router Class Initialized
INFO - 2023-11-21 09:51:38 --> Output Class Initialized
INFO - 2023-11-21 09:51:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:38 --> Input Class Initialized
INFO - 2023-11-21 09:51:38 --> Language Class Initialized
INFO - 2023-11-21 09:51:38 --> Language Class Initialized
INFO - 2023-11-21 09:51:38 --> Config Class Initialized
INFO - 2023-11-21 09:51:38 --> Loader Class Initialized
INFO - 2023-11-21 09:51:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:38 --> Controller Class Initialized
INFO - 2023-11-21 09:51:41 --> Config Class Initialized
INFO - 2023-11-21 09:51:41 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:41 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:41 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:41 --> URI Class Initialized
INFO - 2023-11-21 09:51:41 --> Router Class Initialized
INFO - 2023-11-21 09:51:41 --> Output Class Initialized
INFO - 2023-11-21 09:51:41 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:41 --> Input Class Initialized
INFO - 2023-11-21 09:51:41 --> Language Class Initialized
INFO - 2023-11-21 09:51:41 --> Language Class Initialized
INFO - 2023-11-21 09:51:41 --> Config Class Initialized
INFO - 2023-11-21 09:51:41 --> Loader Class Initialized
INFO - 2023-11-21 09:51:41 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:41 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:41 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:41 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:41 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:41 --> Controller Class Initialized
INFO - 2023-11-21 09:51:41 --> Final output sent to browser
DEBUG - 2023-11-21 09:51:41 --> Total execution time: 0.0534
INFO - 2023-11-21 09:51:49 --> Config Class Initialized
INFO - 2023-11-21 09:51:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:49 --> URI Class Initialized
INFO - 2023-11-21 09:51:49 --> Router Class Initialized
INFO - 2023-11-21 09:51:49 --> Output Class Initialized
INFO - 2023-11-21 09:51:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:49 --> Input Class Initialized
INFO - 2023-11-21 09:51:49 --> Language Class Initialized
INFO - 2023-11-21 09:51:49 --> Language Class Initialized
INFO - 2023-11-21 09:51:49 --> Config Class Initialized
INFO - 2023-11-21 09:51:49 --> Loader Class Initialized
INFO - 2023-11-21 09:51:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:49 --> Controller Class Initialized
INFO - 2023-11-21 09:51:49 --> Final output sent to browser
DEBUG - 2023-11-21 09:51:49 --> Total execution time: 0.1012
INFO - 2023-11-21 09:51:49 --> Config Class Initialized
INFO - 2023-11-21 09:51:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:49 --> URI Class Initialized
INFO - 2023-11-21 09:51:49 --> Router Class Initialized
INFO - 2023-11-21 09:51:49 --> Output Class Initialized
INFO - 2023-11-21 09:51:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:49 --> Input Class Initialized
INFO - 2023-11-21 09:51:49 --> Language Class Initialized
ERROR - 2023-11-21 09:51:49 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:51:49 --> Config Class Initialized
INFO - 2023-11-21 09:51:49 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:49 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:49 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:49 --> URI Class Initialized
INFO - 2023-11-21 09:51:49 --> Router Class Initialized
INFO - 2023-11-21 09:51:49 --> Output Class Initialized
INFO - 2023-11-21 09:51:49 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:49 --> Input Class Initialized
INFO - 2023-11-21 09:51:49 --> Language Class Initialized
INFO - 2023-11-21 09:51:49 --> Language Class Initialized
INFO - 2023-11-21 09:51:49 --> Config Class Initialized
INFO - 2023-11-21 09:51:49 --> Loader Class Initialized
INFO - 2023-11-21 09:51:49 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:49 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:49 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:49 --> Controller Class Initialized
INFO - 2023-11-21 09:51:56 --> Config Class Initialized
INFO - 2023-11-21 09:51:56 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:51:56 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:51:56 --> Utf8 Class Initialized
INFO - 2023-11-21 09:51:56 --> URI Class Initialized
INFO - 2023-11-21 09:51:56 --> Router Class Initialized
INFO - 2023-11-21 09:51:56 --> Output Class Initialized
INFO - 2023-11-21 09:51:56 --> Security Class Initialized
DEBUG - 2023-11-21 09:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:51:56 --> Input Class Initialized
INFO - 2023-11-21 09:51:56 --> Language Class Initialized
INFO - 2023-11-21 09:51:56 --> Language Class Initialized
INFO - 2023-11-21 09:51:56 --> Config Class Initialized
INFO - 2023-11-21 09:51:56 --> Loader Class Initialized
INFO - 2023-11-21 09:51:56 --> Helper loaded: url_helper
INFO - 2023-11-21 09:51:56 --> Helper loaded: file_helper
INFO - 2023-11-21 09:51:56 --> Helper loaded: form_helper
INFO - 2023-11-21 09:51:56 --> Helper loaded: my_helper
INFO - 2023-11-21 09:51:56 --> Database Driver Class Initialized
INFO - 2023-11-21 09:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:51:56 --> Controller Class Initialized
INFO - 2023-11-21 09:51:56 --> Final output sent to browser
DEBUG - 2023-11-21 09:51:56 --> Total execution time: 0.0398
INFO - 2023-11-21 09:52:03 --> Config Class Initialized
INFO - 2023-11-21 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:03 --> URI Class Initialized
INFO - 2023-11-21 09:52:03 --> Router Class Initialized
INFO - 2023-11-21 09:52:03 --> Output Class Initialized
INFO - 2023-11-21 09:52:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:03 --> Input Class Initialized
INFO - 2023-11-21 09:52:03 --> Language Class Initialized
INFO - 2023-11-21 09:52:03 --> Language Class Initialized
INFO - 2023-11-21 09:52:03 --> Config Class Initialized
INFO - 2023-11-21 09:52:03 --> Loader Class Initialized
INFO - 2023-11-21 09:52:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:52:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:52:03 --> Controller Class Initialized
INFO - 2023-11-21 09:52:03 --> Final output sent to browser
DEBUG - 2023-11-21 09:52:03 --> Total execution time: 0.0397
INFO - 2023-11-21 09:52:03 --> Config Class Initialized
INFO - 2023-11-21 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:03 --> URI Class Initialized
INFO - 2023-11-21 09:52:03 --> Router Class Initialized
INFO - 2023-11-21 09:52:03 --> Output Class Initialized
INFO - 2023-11-21 09:52:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:03 --> Input Class Initialized
INFO - 2023-11-21 09:52:03 --> Language Class Initialized
ERROR - 2023-11-21 09:52:03 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:52:03 --> Config Class Initialized
INFO - 2023-11-21 09:52:03 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:03 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:03 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:03 --> URI Class Initialized
INFO - 2023-11-21 09:52:03 --> Router Class Initialized
INFO - 2023-11-21 09:52:03 --> Output Class Initialized
INFO - 2023-11-21 09:52:03 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:03 --> Input Class Initialized
INFO - 2023-11-21 09:52:03 --> Language Class Initialized
INFO - 2023-11-21 09:52:03 --> Language Class Initialized
INFO - 2023-11-21 09:52:03 --> Config Class Initialized
INFO - 2023-11-21 09:52:03 --> Loader Class Initialized
INFO - 2023-11-21 09:52:03 --> Helper loaded: url_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: file_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: form_helper
INFO - 2023-11-21 09:52:03 --> Helper loaded: my_helper
INFO - 2023-11-21 09:52:03 --> Database Driver Class Initialized
INFO - 2023-11-21 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:52:03 --> Controller Class Initialized
INFO - 2023-11-21 09:52:08 --> Config Class Initialized
INFO - 2023-11-21 09:52:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:08 --> URI Class Initialized
INFO - 2023-11-21 09:52:08 --> Router Class Initialized
INFO - 2023-11-21 09:52:08 --> Output Class Initialized
INFO - 2023-11-21 09:52:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:08 --> Input Class Initialized
INFO - 2023-11-21 09:52:08 --> Language Class Initialized
INFO - 2023-11-21 09:52:08 --> Language Class Initialized
INFO - 2023-11-21 09:52:08 --> Config Class Initialized
INFO - 2023-11-21 09:52:08 --> Loader Class Initialized
INFO - 2023-11-21 09:52:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:52:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:52:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:52:09 --> Helper loaded: my_helper
INFO - 2023-11-21 09:52:09 --> Database Driver Class Initialized
INFO - 2023-11-21 09:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:52:09 --> Controller Class Initialized
INFO - 2023-11-21 09:52:09 --> Final output sent to browser
DEBUG - 2023-11-21 09:52:09 --> Total execution time: 0.0470
INFO - 2023-11-21 09:52:25 --> Config Class Initialized
INFO - 2023-11-21 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:25 --> URI Class Initialized
INFO - 2023-11-21 09:52:25 --> Router Class Initialized
INFO - 2023-11-21 09:52:25 --> Output Class Initialized
INFO - 2023-11-21 09:52:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:25 --> Input Class Initialized
INFO - 2023-11-21 09:52:25 --> Language Class Initialized
INFO - 2023-11-21 09:52:25 --> Language Class Initialized
INFO - 2023-11-21 09:52:25 --> Config Class Initialized
INFO - 2023-11-21 09:52:25 --> Loader Class Initialized
INFO - 2023-11-21 09:52:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:52:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:52:25 --> Controller Class Initialized
INFO - 2023-11-21 09:52:25 --> Final output sent to browser
DEBUG - 2023-11-21 09:52:25 --> Total execution time: 0.0309
INFO - 2023-11-21 09:52:25 --> Config Class Initialized
INFO - 2023-11-21 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:25 --> URI Class Initialized
INFO - 2023-11-21 09:52:25 --> Router Class Initialized
INFO - 2023-11-21 09:52:25 --> Output Class Initialized
INFO - 2023-11-21 09:52:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:25 --> Input Class Initialized
INFO - 2023-11-21 09:52:25 --> Language Class Initialized
ERROR - 2023-11-21 09:52:25 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:52:25 --> Config Class Initialized
INFO - 2023-11-21 09:52:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:52:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:52:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:52:25 --> URI Class Initialized
INFO - 2023-11-21 09:52:25 --> Router Class Initialized
INFO - 2023-11-21 09:52:25 --> Output Class Initialized
INFO - 2023-11-21 09:52:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:52:25 --> Input Class Initialized
INFO - 2023-11-21 09:52:25 --> Language Class Initialized
INFO - 2023-11-21 09:52:25 --> Language Class Initialized
INFO - 2023-11-21 09:52:25 --> Config Class Initialized
INFO - 2023-11-21 09:52:25 --> Loader Class Initialized
INFO - 2023-11-21 09:52:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:52:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:52:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:52:25 --> Controller Class Initialized
INFO - 2023-11-21 09:53:15 --> Config Class Initialized
INFO - 2023-11-21 09:53:15 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:15 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:15 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:15 --> URI Class Initialized
INFO - 2023-11-21 09:53:15 --> Router Class Initialized
INFO - 2023-11-21 09:53:15 --> Output Class Initialized
INFO - 2023-11-21 09:53:15 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:15 --> Input Class Initialized
INFO - 2023-11-21 09:53:15 --> Language Class Initialized
INFO - 2023-11-21 09:53:15 --> Language Class Initialized
INFO - 2023-11-21 09:53:15 --> Config Class Initialized
INFO - 2023-11-21 09:53:15 --> Loader Class Initialized
INFO - 2023-11-21 09:53:15 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:15 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:15 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:15 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:15 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:15 --> Controller Class Initialized
INFO - 2023-11-21 09:53:15 --> Final output sent to browser
DEBUG - 2023-11-21 09:53:15 --> Total execution time: 0.0323
INFO - 2023-11-21 09:53:20 --> Config Class Initialized
INFO - 2023-11-21 09:53:20 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:20 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:20 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:20 --> URI Class Initialized
INFO - 2023-11-21 09:53:20 --> Router Class Initialized
INFO - 2023-11-21 09:53:20 --> Output Class Initialized
INFO - 2023-11-21 09:53:20 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:20 --> Input Class Initialized
INFO - 2023-11-21 09:53:20 --> Language Class Initialized
INFO - 2023-11-21 09:53:20 --> Language Class Initialized
INFO - 2023-11-21 09:53:20 --> Config Class Initialized
INFO - 2023-11-21 09:53:20 --> Loader Class Initialized
INFO - 2023-11-21 09:53:20 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:20 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:20 --> Controller Class Initialized
INFO - 2023-11-21 09:53:20 --> Final output sent to browser
DEBUG - 2023-11-21 09:53:20 --> Total execution time: 0.0310
INFO - 2023-11-21 09:53:20 --> Config Class Initialized
INFO - 2023-11-21 09:53:20 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:20 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:20 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:20 --> URI Class Initialized
INFO - 2023-11-21 09:53:20 --> Router Class Initialized
INFO - 2023-11-21 09:53:20 --> Output Class Initialized
INFO - 2023-11-21 09:53:20 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:20 --> Input Class Initialized
INFO - 2023-11-21 09:53:20 --> Language Class Initialized
ERROR - 2023-11-21 09:53:20 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:53:20 --> Config Class Initialized
INFO - 2023-11-21 09:53:20 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:20 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:20 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:20 --> URI Class Initialized
INFO - 2023-11-21 09:53:20 --> Router Class Initialized
INFO - 2023-11-21 09:53:20 --> Output Class Initialized
INFO - 2023-11-21 09:53:20 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:20 --> Input Class Initialized
INFO - 2023-11-21 09:53:20 --> Language Class Initialized
INFO - 2023-11-21 09:53:20 --> Language Class Initialized
INFO - 2023-11-21 09:53:20 --> Config Class Initialized
INFO - 2023-11-21 09:53:20 --> Loader Class Initialized
INFO - 2023-11-21 09:53:20 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:20 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:20 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:20 --> Controller Class Initialized
INFO - 2023-11-21 09:53:27 --> Config Class Initialized
INFO - 2023-11-21 09:53:27 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:27 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:27 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:27 --> URI Class Initialized
INFO - 2023-11-21 09:53:27 --> Router Class Initialized
INFO - 2023-11-21 09:53:27 --> Output Class Initialized
INFO - 2023-11-21 09:53:27 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:27 --> Input Class Initialized
INFO - 2023-11-21 09:53:27 --> Language Class Initialized
INFO - 2023-11-21 09:53:27 --> Language Class Initialized
INFO - 2023-11-21 09:53:27 --> Config Class Initialized
INFO - 2023-11-21 09:53:27 --> Loader Class Initialized
INFO - 2023-11-21 09:53:27 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:27 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:27 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:27 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:27 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:27 --> Controller Class Initialized
INFO - 2023-11-21 09:53:27 --> Final output sent to browser
DEBUG - 2023-11-21 09:53:27 --> Total execution time: 0.0317
INFO - 2023-11-21 09:53:40 --> Config Class Initialized
INFO - 2023-11-21 09:53:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:40 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:40 --> URI Class Initialized
INFO - 2023-11-21 09:53:40 --> Router Class Initialized
INFO - 2023-11-21 09:53:40 --> Output Class Initialized
INFO - 2023-11-21 09:53:40 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:40 --> Input Class Initialized
INFO - 2023-11-21 09:53:40 --> Language Class Initialized
INFO - 2023-11-21 09:53:40 --> Language Class Initialized
INFO - 2023-11-21 09:53:40 --> Config Class Initialized
INFO - 2023-11-21 09:53:40 --> Loader Class Initialized
INFO - 2023-11-21 09:53:40 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:40 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:40 --> Controller Class Initialized
INFO - 2023-11-21 09:53:40 --> Final output sent to browser
DEBUG - 2023-11-21 09:53:40 --> Total execution time: 0.0383
INFO - 2023-11-21 09:53:40 --> Config Class Initialized
INFO - 2023-11-21 09:53:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:40 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:40 --> URI Class Initialized
INFO - 2023-11-21 09:53:40 --> Router Class Initialized
INFO - 2023-11-21 09:53:40 --> Output Class Initialized
INFO - 2023-11-21 09:53:40 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:40 --> Input Class Initialized
INFO - 2023-11-21 09:53:40 --> Language Class Initialized
ERROR - 2023-11-21 09:53:40 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:53:40 --> Config Class Initialized
INFO - 2023-11-21 09:53:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:40 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:40 --> URI Class Initialized
INFO - 2023-11-21 09:53:40 --> Router Class Initialized
INFO - 2023-11-21 09:53:40 --> Output Class Initialized
INFO - 2023-11-21 09:53:40 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:40 --> Input Class Initialized
INFO - 2023-11-21 09:53:40 --> Language Class Initialized
INFO - 2023-11-21 09:53:40 --> Language Class Initialized
INFO - 2023-11-21 09:53:40 --> Config Class Initialized
INFO - 2023-11-21 09:53:40 --> Loader Class Initialized
INFO - 2023-11-21 09:53:40 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:40 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:40 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:40 --> Controller Class Initialized
INFO - 2023-11-21 09:53:47 --> Config Class Initialized
INFO - 2023-11-21 09:53:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:47 --> URI Class Initialized
INFO - 2023-11-21 09:53:47 --> Router Class Initialized
INFO - 2023-11-21 09:53:47 --> Output Class Initialized
INFO - 2023-11-21 09:53:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:47 --> Input Class Initialized
INFO - 2023-11-21 09:53:47 --> Language Class Initialized
INFO - 2023-11-21 09:53:47 --> Language Class Initialized
INFO - 2023-11-21 09:53:47 --> Config Class Initialized
INFO - 2023-11-21 09:53:47 --> Loader Class Initialized
INFO - 2023-11-21 09:53:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:47 --> Controller Class Initialized
DEBUG - 2023-11-21 09:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:53:47 --> Final output sent to browser
DEBUG - 2023-11-21 09:53:47 --> Total execution time: 0.0768
INFO - 2023-11-21 09:53:47 --> Config Class Initialized
INFO - 2023-11-21 09:53:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:47 --> URI Class Initialized
INFO - 2023-11-21 09:53:47 --> Router Class Initialized
INFO - 2023-11-21 09:53:47 --> Output Class Initialized
INFO - 2023-11-21 09:53:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:47 --> Input Class Initialized
INFO - 2023-11-21 09:53:47 --> Language Class Initialized
ERROR - 2023-11-21 09:53:47 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:53:47 --> Config Class Initialized
INFO - 2023-11-21 09:53:47 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:53:47 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:53:47 --> Utf8 Class Initialized
INFO - 2023-11-21 09:53:47 --> URI Class Initialized
INFO - 2023-11-21 09:53:47 --> Router Class Initialized
INFO - 2023-11-21 09:53:47 --> Output Class Initialized
INFO - 2023-11-21 09:53:47 --> Security Class Initialized
DEBUG - 2023-11-21 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:53:47 --> Input Class Initialized
INFO - 2023-11-21 09:53:47 --> Language Class Initialized
INFO - 2023-11-21 09:53:47 --> Language Class Initialized
INFO - 2023-11-21 09:53:47 --> Config Class Initialized
INFO - 2023-11-21 09:53:47 --> Loader Class Initialized
INFO - 2023-11-21 09:53:47 --> Helper loaded: url_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: file_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: form_helper
INFO - 2023-11-21 09:53:47 --> Helper loaded: my_helper
INFO - 2023-11-21 09:53:47 --> Database Driver Class Initialized
INFO - 2023-11-21 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:53:47 --> Controller Class Initialized
INFO - 2023-11-21 09:54:02 --> Config Class Initialized
INFO - 2023-11-21 09:54:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:02 --> URI Class Initialized
INFO - 2023-11-21 09:54:02 --> Router Class Initialized
INFO - 2023-11-21 09:54:02 --> Output Class Initialized
INFO - 2023-11-21 09:54:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:02 --> Input Class Initialized
INFO - 2023-11-21 09:54:02 --> Language Class Initialized
INFO - 2023-11-21 09:54:02 --> Language Class Initialized
INFO - 2023-11-21 09:54:02 --> Config Class Initialized
INFO - 2023-11-21 09:54:02 --> Loader Class Initialized
INFO - 2023-11-21 09:54:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:02 --> Controller Class Initialized
DEBUG - 2023-11-21 09:54:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-21 09:54:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:54:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:02 --> Total execution time: 0.1176
INFO - 2023-11-21 09:54:14 --> Config Class Initialized
INFO - 2023-11-21 09:54:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:14 --> URI Class Initialized
INFO - 2023-11-21 09:54:14 --> Router Class Initialized
INFO - 2023-11-21 09:54:14 --> Output Class Initialized
INFO - 2023-11-21 09:54:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:14 --> Input Class Initialized
INFO - 2023-11-21 09:54:14 --> Language Class Initialized
INFO - 2023-11-21 09:54:14 --> Language Class Initialized
INFO - 2023-11-21 09:54:14 --> Config Class Initialized
INFO - 2023-11-21 09:54:14 --> Loader Class Initialized
INFO - 2023-11-21 09:54:14 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:14 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:14 --> Controller Class Initialized
DEBUG - 2023-11-21 09:54:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-21 09:54:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:54:14 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:14 --> Total execution time: 0.0486
INFO - 2023-11-21 09:54:14 --> Config Class Initialized
INFO - 2023-11-21 09:54:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:14 --> URI Class Initialized
INFO - 2023-11-21 09:54:14 --> Router Class Initialized
INFO - 2023-11-21 09:54:14 --> Output Class Initialized
INFO - 2023-11-21 09:54:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:14 --> Input Class Initialized
INFO - 2023-11-21 09:54:14 --> Language Class Initialized
ERROR - 2023-11-21 09:54:14 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:54:14 --> Config Class Initialized
INFO - 2023-11-21 09:54:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:14 --> URI Class Initialized
INFO - 2023-11-21 09:54:14 --> Router Class Initialized
INFO - 2023-11-21 09:54:14 --> Output Class Initialized
INFO - 2023-11-21 09:54:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:14 --> Input Class Initialized
INFO - 2023-11-21 09:54:14 --> Language Class Initialized
INFO - 2023-11-21 09:54:14 --> Language Class Initialized
INFO - 2023-11-21 09:54:14 --> Config Class Initialized
INFO - 2023-11-21 09:54:14 --> Loader Class Initialized
INFO - 2023-11-21 09:54:14 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:14 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:14 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:14 --> Controller Class Initialized
INFO - 2023-11-21 09:54:22 --> Config Class Initialized
INFO - 2023-11-21 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:22 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:22 --> URI Class Initialized
INFO - 2023-11-21 09:54:22 --> Router Class Initialized
INFO - 2023-11-21 09:54:22 --> Output Class Initialized
INFO - 2023-11-21 09:54:22 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:22 --> Input Class Initialized
INFO - 2023-11-21 09:54:22 --> Language Class Initialized
INFO - 2023-11-21 09:54:22 --> Language Class Initialized
INFO - 2023-11-21 09:54:22 --> Config Class Initialized
INFO - 2023-11-21 09:54:22 --> Loader Class Initialized
INFO - 2023-11-21 09:54:22 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:22 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:22 --> Controller Class Initialized
INFO - 2023-11-21 09:54:22 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:22 --> Total execution time: 0.1067
INFO - 2023-11-21 09:54:22 --> Config Class Initialized
INFO - 2023-11-21 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:22 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:22 --> URI Class Initialized
INFO - 2023-11-21 09:54:22 --> Router Class Initialized
INFO - 2023-11-21 09:54:22 --> Output Class Initialized
INFO - 2023-11-21 09:54:22 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:22 --> Input Class Initialized
INFO - 2023-11-21 09:54:22 --> Language Class Initialized
ERROR - 2023-11-21 09:54:22 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:54:22 --> Config Class Initialized
INFO - 2023-11-21 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:22 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:22 --> URI Class Initialized
INFO - 2023-11-21 09:54:22 --> Router Class Initialized
INFO - 2023-11-21 09:54:22 --> Output Class Initialized
INFO - 2023-11-21 09:54:22 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:22 --> Input Class Initialized
INFO - 2023-11-21 09:54:22 --> Language Class Initialized
INFO - 2023-11-21 09:54:22 --> Language Class Initialized
INFO - 2023-11-21 09:54:22 --> Config Class Initialized
INFO - 2023-11-21 09:54:22 --> Loader Class Initialized
INFO - 2023-11-21 09:54:22 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:22 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:22 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:22 --> Controller Class Initialized
INFO - 2023-11-21 09:54:25 --> Config Class Initialized
INFO - 2023-11-21 09:54:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:25 --> URI Class Initialized
INFO - 2023-11-21 09:54:25 --> Router Class Initialized
INFO - 2023-11-21 09:54:25 --> Output Class Initialized
INFO - 2023-11-21 09:54:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:25 --> Input Class Initialized
INFO - 2023-11-21 09:54:25 --> Language Class Initialized
INFO - 2023-11-21 09:54:25 --> Language Class Initialized
INFO - 2023-11-21 09:54:25 --> Config Class Initialized
INFO - 2023-11-21 09:54:25 --> Loader Class Initialized
INFO - 2023-11-21 09:54:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:25 --> Controller Class Initialized
INFO - 2023-11-21 09:54:25 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:25 --> Total execution time: 0.0390
INFO - 2023-11-21 09:54:25 --> Config Class Initialized
INFO - 2023-11-21 09:54:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:25 --> URI Class Initialized
INFO - 2023-11-21 09:54:25 --> Router Class Initialized
INFO - 2023-11-21 09:54:25 --> Output Class Initialized
INFO - 2023-11-21 09:54:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:25 --> Input Class Initialized
INFO - 2023-11-21 09:54:25 --> Language Class Initialized
ERROR - 2023-11-21 09:54:25 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:54:25 --> Config Class Initialized
INFO - 2023-11-21 09:54:25 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:25 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:25 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:25 --> URI Class Initialized
INFO - 2023-11-21 09:54:25 --> Router Class Initialized
INFO - 2023-11-21 09:54:25 --> Output Class Initialized
INFO - 2023-11-21 09:54:25 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:25 --> Input Class Initialized
INFO - 2023-11-21 09:54:25 --> Language Class Initialized
INFO - 2023-11-21 09:54:25 --> Language Class Initialized
INFO - 2023-11-21 09:54:25 --> Config Class Initialized
INFO - 2023-11-21 09:54:25 --> Loader Class Initialized
INFO - 2023-11-21 09:54:25 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:25 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:25 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:25 --> Controller Class Initialized
INFO - 2023-11-21 09:54:32 --> Config Class Initialized
INFO - 2023-11-21 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:32 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:32 --> URI Class Initialized
INFO - 2023-11-21 09:54:32 --> Router Class Initialized
INFO - 2023-11-21 09:54:32 --> Output Class Initialized
INFO - 2023-11-21 09:54:32 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:32 --> Input Class Initialized
INFO - 2023-11-21 09:54:32 --> Language Class Initialized
INFO - 2023-11-21 09:54:32 --> Language Class Initialized
INFO - 2023-11-21 09:54:32 --> Config Class Initialized
INFO - 2023-11-21 09:54:32 --> Loader Class Initialized
INFO - 2023-11-21 09:54:32 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:32 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:32 --> Controller Class Initialized
INFO - 2023-11-21 09:54:32 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:32 --> Total execution time: 0.0406
INFO - 2023-11-21 09:54:32 --> Config Class Initialized
INFO - 2023-11-21 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:32 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:32 --> URI Class Initialized
INFO - 2023-11-21 09:54:32 --> Router Class Initialized
INFO - 2023-11-21 09:54:32 --> Output Class Initialized
INFO - 2023-11-21 09:54:32 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:32 --> Input Class Initialized
INFO - 2023-11-21 09:54:32 --> Language Class Initialized
ERROR - 2023-11-21 09:54:32 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:54:32 --> Config Class Initialized
INFO - 2023-11-21 09:54:32 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:32 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:32 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:32 --> URI Class Initialized
INFO - 2023-11-21 09:54:32 --> Router Class Initialized
INFO - 2023-11-21 09:54:32 --> Output Class Initialized
INFO - 2023-11-21 09:54:32 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:32 --> Input Class Initialized
INFO - 2023-11-21 09:54:32 --> Language Class Initialized
INFO - 2023-11-21 09:54:32 --> Language Class Initialized
INFO - 2023-11-21 09:54:32 --> Config Class Initialized
INFO - 2023-11-21 09:54:32 --> Loader Class Initialized
INFO - 2023-11-21 09:54:32 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:32 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:32 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:32 --> Controller Class Initialized
INFO - 2023-11-21 09:54:36 --> Config Class Initialized
INFO - 2023-11-21 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:36 --> URI Class Initialized
INFO - 2023-11-21 09:54:36 --> Router Class Initialized
INFO - 2023-11-21 09:54:36 --> Output Class Initialized
INFO - 2023-11-21 09:54:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:36 --> Input Class Initialized
INFO - 2023-11-21 09:54:36 --> Language Class Initialized
INFO - 2023-11-21 09:54:36 --> Language Class Initialized
INFO - 2023-11-21 09:54:36 --> Config Class Initialized
INFO - 2023-11-21 09:54:36 --> Loader Class Initialized
INFO - 2023-11-21 09:54:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:36 --> Controller Class Initialized
INFO - 2023-11-21 09:54:36 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:36 --> Total execution time: 0.0911
INFO - 2023-11-21 09:54:45 --> Config Class Initialized
INFO - 2023-11-21 09:54:45 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:45 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:45 --> URI Class Initialized
INFO - 2023-11-21 09:54:45 --> Router Class Initialized
INFO - 2023-11-21 09:54:45 --> Output Class Initialized
INFO - 2023-11-21 09:54:45 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:45 --> Input Class Initialized
INFO - 2023-11-21 09:54:45 --> Language Class Initialized
INFO - 2023-11-21 09:54:45 --> Language Class Initialized
INFO - 2023-11-21 09:54:45 --> Config Class Initialized
INFO - 2023-11-21 09:54:45 --> Loader Class Initialized
INFO - 2023-11-21 09:54:45 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:45 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:45 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:45 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:45 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:45 --> Controller Class Initialized
INFO - 2023-11-21 09:54:45 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:45 --> Total execution time: 0.0399
INFO - 2023-11-21 09:54:54 --> Config Class Initialized
INFO - 2023-11-21 09:54:54 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:54:54 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:54:54 --> Utf8 Class Initialized
INFO - 2023-11-21 09:54:54 --> URI Class Initialized
INFO - 2023-11-21 09:54:54 --> Router Class Initialized
INFO - 2023-11-21 09:54:54 --> Output Class Initialized
INFO - 2023-11-21 09:54:54 --> Security Class Initialized
DEBUG - 2023-11-21 09:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:54:54 --> Input Class Initialized
INFO - 2023-11-21 09:54:54 --> Language Class Initialized
INFO - 2023-11-21 09:54:54 --> Language Class Initialized
INFO - 2023-11-21 09:54:54 --> Config Class Initialized
INFO - 2023-11-21 09:54:54 --> Loader Class Initialized
INFO - 2023-11-21 09:54:54 --> Helper loaded: url_helper
INFO - 2023-11-21 09:54:54 --> Helper loaded: file_helper
INFO - 2023-11-21 09:54:54 --> Helper loaded: form_helper
INFO - 2023-11-21 09:54:54 --> Helper loaded: my_helper
INFO - 2023-11-21 09:54:54 --> Database Driver Class Initialized
INFO - 2023-11-21 09:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:54:54 --> Controller Class Initialized
INFO - 2023-11-21 09:54:54 --> Final output sent to browser
DEBUG - 2023-11-21 09:54:54 --> Total execution time: 0.0329
INFO - 2023-11-21 09:55:11 --> Config Class Initialized
INFO - 2023-11-21 09:55:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:11 --> URI Class Initialized
INFO - 2023-11-21 09:55:11 --> Router Class Initialized
INFO - 2023-11-21 09:55:11 --> Output Class Initialized
INFO - 2023-11-21 09:55:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:11 --> Input Class Initialized
INFO - 2023-11-21 09:55:11 --> Language Class Initialized
INFO - 2023-11-21 09:55:11 --> Language Class Initialized
INFO - 2023-11-21 09:55:11 --> Config Class Initialized
INFO - 2023-11-21 09:55:11 --> Loader Class Initialized
INFO - 2023-11-21 09:55:11 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:11 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:11 --> Controller Class Initialized
INFO - 2023-11-21 09:55:11 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:11 --> Total execution time: 0.0928
INFO - 2023-11-21 09:55:11 --> Config Class Initialized
INFO - 2023-11-21 09:55:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:11 --> URI Class Initialized
INFO - 2023-11-21 09:55:11 --> Router Class Initialized
INFO - 2023-11-21 09:55:11 --> Output Class Initialized
INFO - 2023-11-21 09:55:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:11 --> Input Class Initialized
INFO - 2023-11-21 09:55:11 --> Language Class Initialized
ERROR - 2023-11-21 09:55:11 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:55:11 --> Config Class Initialized
INFO - 2023-11-21 09:55:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:11 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:11 --> URI Class Initialized
INFO - 2023-11-21 09:55:11 --> Router Class Initialized
INFO - 2023-11-21 09:55:11 --> Output Class Initialized
INFO - 2023-11-21 09:55:11 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:11 --> Input Class Initialized
INFO - 2023-11-21 09:55:11 --> Language Class Initialized
INFO - 2023-11-21 09:55:11 --> Language Class Initialized
INFO - 2023-11-21 09:55:11 --> Config Class Initialized
INFO - 2023-11-21 09:55:11 --> Loader Class Initialized
INFO - 2023-11-21 09:55:11 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:11 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:11 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:11 --> Controller Class Initialized
INFO - 2023-11-21 09:55:21 --> Config Class Initialized
INFO - 2023-11-21 09:55:21 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:21 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:21 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:21 --> URI Class Initialized
INFO - 2023-11-21 09:55:21 --> Router Class Initialized
INFO - 2023-11-21 09:55:21 --> Output Class Initialized
INFO - 2023-11-21 09:55:21 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:21 --> Input Class Initialized
INFO - 2023-11-21 09:55:21 --> Language Class Initialized
INFO - 2023-11-21 09:55:21 --> Language Class Initialized
INFO - 2023-11-21 09:55:21 --> Config Class Initialized
INFO - 2023-11-21 09:55:21 --> Loader Class Initialized
INFO - 2023-11-21 09:55:21 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:21 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:21 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:21 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:21 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:21 --> Controller Class Initialized
INFO - 2023-11-21 09:55:21 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:21 --> Total execution time: 0.0359
INFO - 2023-11-21 09:55:36 --> Config Class Initialized
INFO - 2023-11-21 09:55:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:36 --> URI Class Initialized
INFO - 2023-11-21 09:55:36 --> Router Class Initialized
INFO - 2023-11-21 09:55:36 --> Output Class Initialized
INFO - 2023-11-21 09:55:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:36 --> Input Class Initialized
INFO - 2023-11-21 09:55:36 --> Language Class Initialized
INFO - 2023-11-21 09:55:36 --> Language Class Initialized
INFO - 2023-11-21 09:55:36 --> Config Class Initialized
INFO - 2023-11-21 09:55:36 --> Loader Class Initialized
INFO - 2023-11-21 09:55:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:36 --> Controller Class Initialized
INFO - 2023-11-21 09:55:36 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:36 --> Total execution time: 0.0348
INFO - 2023-11-21 09:55:36 --> Config Class Initialized
INFO - 2023-11-21 09:55:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:36 --> URI Class Initialized
INFO - 2023-11-21 09:55:36 --> Router Class Initialized
INFO - 2023-11-21 09:55:36 --> Output Class Initialized
INFO - 2023-11-21 09:55:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:36 --> Input Class Initialized
INFO - 2023-11-21 09:55:36 --> Language Class Initialized
ERROR - 2023-11-21 09:55:36 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:55:36 --> Config Class Initialized
INFO - 2023-11-21 09:55:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:36 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:36 --> URI Class Initialized
INFO - 2023-11-21 09:55:36 --> Router Class Initialized
INFO - 2023-11-21 09:55:36 --> Output Class Initialized
INFO - 2023-11-21 09:55:36 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:36 --> Input Class Initialized
INFO - 2023-11-21 09:55:36 --> Language Class Initialized
INFO - 2023-11-21 09:55:36 --> Language Class Initialized
INFO - 2023-11-21 09:55:36 --> Config Class Initialized
INFO - 2023-11-21 09:55:36 --> Loader Class Initialized
INFO - 2023-11-21 09:55:36 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:36 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:36 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:36 --> Controller Class Initialized
INFO - 2023-11-21 09:55:38 --> Config Class Initialized
INFO - 2023-11-21 09:55:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:38 --> URI Class Initialized
INFO - 2023-11-21 09:55:38 --> Router Class Initialized
INFO - 2023-11-21 09:55:38 --> Output Class Initialized
INFO - 2023-11-21 09:55:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:38 --> Input Class Initialized
INFO - 2023-11-21 09:55:38 --> Language Class Initialized
INFO - 2023-11-21 09:55:38 --> Language Class Initialized
INFO - 2023-11-21 09:55:38 --> Config Class Initialized
INFO - 2023-11-21 09:55:38 --> Loader Class Initialized
INFO - 2023-11-21 09:55:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:38 --> Controller Class Initialized
INFO - 2023-11-21 09:55:38 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:38 --> Total execution time: 0.0321
INFO - 2023-11-21 09:55:44 --> Config Class Initialized
INFO - 2023-11-21 09:55:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:44 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:44 --> URI Class Initialized
INFO - 2023-11-21 09:55:44 --> Router Class Initialized
INFO - 2023-11-21 09:55:44 --> Output Class Initialized
INFO - 2023-11-21 09:55:44 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:44 --> Input Class Initialized
INFO - 2023-11-21 09:55:44 --> Language Class Initialized
INFO - 2023-11-21 09:55:44 --> Language Class Initialized
INFO - 2023-11-21 09:55:44 --> Config Class Initialized
INFO - 2023-11-21 09:55:44 --> Loader Class Initialized
INFO - 2023-11-21 09:55:44 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:44 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:44 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:44 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:44 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:44 --> Controller Class Initialized
INFO - 2023-11-21 09:55:44 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:44 --> Total execution time: 0.0323
INFO - 2023-11-21 09:55:58 --> Config Class Initialized
INFO - 2023-11-21 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:58 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:58 --> URI Class Initialized
INFO - 2023-11-21 09:55:58 --> Router Class Initialized
INFO - 2023-11-21 09:55:58 --> Output Class Initialized
INFO - 2023-11-21 09:55:58 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:58 --> Input Class Initialized
INFO - 2023-11-21 09:55:58 --> Language Class Initialized
INFO - 2023-11-21 09:55:58 --> Language Class Initialized
INFO - 2023-11-21 09:55:58 --> Config Class Initialized
INFO - 2023-11-21 09:55:58 --> Loader Class Initialized
INFO - 2023-11-21 09:55:58 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:58 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:58 --> Controller Class Initialized
INFO - 2023-11-21 09:55:58 --> Final output sent to browser
DEBUG - 2023-11-21 09:55:58 --> Total execution time: 0.1120
INFO - 2023-11-21 09:55:58 --> Config Class Initialized
INFO - 2023-11-21 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:58 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:58 --> URI Class Initialized
INFO - 2023-11-21 09:55:58 --> Router Class Initialized
INFO - 2023-11-21 09:55:58 --> Output Class Initialized
INFO - 2023-11-21 09:55:58 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:58 --> Input Class Initialized
INFO - 2023-11-21 09:55:58 --> Language Class Initialized
ERROR - 2023-11-21 09:55:58 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:55:58 --> Config Class Initialized
INFO - 2023-11-21 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:55:58 --> Utf8 Class Initialized
INFO - 2023-11-21 09:55:58 --> URI Class Initialized
INFO - 2023-11-21 09:55:58 --> Router Class Initialized
INFO - 2023-11-21 09:55:58 --> Output Class Initialized
INFO - 2023-11-21 09:55:58 --> Security Class Initialized
DEBUG - 2023-11-21 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:55:58 --> Input Class Initialized
INFO - 2023-11-21 09:55:58 --> Language Class Initialized
INFO - 2023-11-21 09:55:58 --> Language Class Initialized
INFO - 2023-11-21 09:55:58 --> Config Class Initialized
INFO - 2023-11-21 09:55:58 --> Loader Class Initialized
INFO - 2023-11-21 09:55:58 --> Helper loaded: url_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: file_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: form_helper
INFO - 2023-11-21 09:55:58 --> Helper loaded: my_helper
INFO - 2023-11-21 09:55:58 --> Database Driver Class Initialized
INFO - 2023-11-21 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:55:58 --> Controller Class Initialized
INFO - 2023-11-21 09:56:04 --> Config Class Initialized
INFO - 2023-11-21 09:56:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:04 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:04 --> URI Class Initialized
INFO - 2023-11-21 09:56:04 --> Router Class Initialized
INFO - 2023-11-21 09:56:04 --> Output Class Initialized
INFO - 2023-11-21 09:56:04 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:04 --> Input Class Initialized
INFO - 2023-11-21 09:56:04 --> Language Class Initialized
INFO - 2023-11-21 09:56:04 --> Language Class Initialized
INFO - 2023-11-21 09:56:04 --> Config Class Initialized
INFO - 2023-11-21 09:56:04 --> Loader Class Initialized
INFO - 2023-11-21 09:56:04 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:04 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:04 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:56:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:04 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:04 --> Total execution time: 0.0631
INFO - 2023-11-21 09:56:04 --> Config Class Initialized
INFO - 2023-11-21 09:56:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:04 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:04 --> URI Class Initialized
INFO - 2023-11-21 09:56:04 --> Router Class Initialized
INFO - 2023-11-21 09:56:04 --> Output Class Initialized
INFO - 2023-11-21 09:56:04 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:04 --> Input Class Initialized
INFO - 2023-11-21 09:56:04 --> Language Class Initialized
ERROR - 2023-11-21 09:56:04 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:56:04 --> Config Class Initialized
INFO - 2023-11-21 09:56:04 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:04 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:04 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:04 --> URI Class Initialized
INFO - 2023-11-21 09:56:04 --> Router Class Initialized
INFO - 2023-11-21 09:56:04 --> Output Class Initialized
INFO - 2023-11-21 09:56:04 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:04 --> Input Class Initialized
INFO - 2023-11-21 09:56:04 --> Language Class Initialized
INFO - 2023-11-21 09:56:04 --> Language Class Initialized
INFO - 2023-11-21 09:56:04 --> Config Class Initialized
INFO - 2023-11-21 09:56:04 --> Loader Class Initialized
INFO - 2023-11-21 09:56:04 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:04 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:04 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:04 --> Controller Class Initialized
INFO - 2023-11-21 09:56:05 --> Config Class Initialized
INFO - 2023-11-21 09:56:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:05 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:05 --> URI Class Initialized
INFO - 2023-11-21 09:56:05 --> Router Class Initialized
INFO - 2023-11-21 09:56:05 --> Output Class Initialized
INFO - 2023-11-21 09:56:05 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:05 --> Input Class Initialized
INFO - 2023-11-21 09:56:05 --> Language Class Initialized
INFO - 2023-11-21 09:56:05 --> Language Class Initialized
INFO - 2023-11-21 09:56:05 --> Config Class Initialized
INFO - 2023-11-21 09:56:05 --> Loader Class Initialized
INFO - 2023-11-21 09:56:05 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:05 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:05 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:05 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:05 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:05 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-21 09:56:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:05 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:05 --> Total execution time: 0.0337
INFO - 2023-11-21 09:56:30 --> Config Class Initialized
INFO - 2023-11-21 09:56:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:30 --> URI Class Initialized
INFO - 2023-11-21 09:56:30 --> Router Class Initialized
INFO - 2023-11-21 09:56:30 --> Output Class Initialized
INFO - 2023-11-21 09:56:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:30 --> Input Class Initialized
INFO - 2023-11-21 09:56:30 --> Language Class Initialized
INFO - 2023-11-21 09:56:30 --> Language Class Initialized
INFO - 2023-11-21 09:56:30 --> Config Class Initialized
INFO - 2023-11-21 09:56:30 --> Loader Class Initialized
INFO - 2023-11-21 09:56:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:30 --> Controller Class Initialized
INFO - 2023-11-21 09:56:30 --> Config Class Initialized
INFO - 2023-11-21 09:56:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:30 --> URI Class Initialized
INFO - 2023-11-21 09:56:30 --> Router Class Initialized
INFO - 2023-11-21 09:56:30 --> Output Class Initialized
INFO - 2023-11-21 09:56:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:30 --> Input Class Initialized
INFO - 2023-11-21 09:56:30 --> Language Class Initialized
INFO - 2023-11-21 09:56:30 --> Language Class Initialized
INFO - 2023-11-21 09:56:30 --> Config Class Initialized
INFO - 2023-11-21 09:56:30 --> Loader Class Initialized
INFO - 2023-11-21 09:56:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:30 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:30 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:30 --> Total execution time: 0.0375
INFO - 2023-11-21 09:56:31 --> Config Class Initialized
INFO - 2023-11-21 09:56:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:31 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:31 --> URI Class Initialized
INFO - 2023-11-21 09:56:31 --> Router Class Initialized
INFO - 2023-11-21 09:56:31 --> Output Class Initialized
INFO - 2023-11-21 09:56:31 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:31 --> Input Class Initialized
INFO - 2023-11-21 09:56:31 --> Language Class Initialized
ERROR - 2023-11-21 09:56:31 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:56:31 --> Config Class Initialized
INFO - 2023-11-21 09:56:31 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:31 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:31 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:31 --> URI Class Initialized
INFO - 2023-11-21 09:56:31 --> Router Class Initialized
INFO - 2023-11-21 09:56:31 --> Output Class Initialized
INFO - 2023-11-21 09:56:31 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:31 --> Input Class Initialized
INFO - 2023-11-21 09:56:31 --> Language Class Initialized
INFO - 2023-11-21 09:56:31 --> Language Class Initialized
INFO - 2023-11-21 09:56:31 --> Config Class Initialized
INFO - 2023-11-21 09:56:31 --> Loader Class Initialized
INFO - 2023-11-21 09:56:31 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:31 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:31 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:31 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:31 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:31 --> Controller Class Initialized
INFO - 2023-11-21 09:56:39 --> Config Class Initialized
INFO - 2023-11-21 09:56:39 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:39 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:39 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:39 --> URI Class Initialized
INFO - 2023-11-21 09:56:39 --> Router Class Initialized
INFO - 2023-11-21 09:56:39 --> Output Class Initialized
INFO - 2023-11-21 09:56:39 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:39 --> Input Class Initialized
INFO - 2023-11-21 09:56:39 --> Language Class Initialized
INFO - 2023-11-21 09:56:39 --> Language Class Initialized
INFO - 2023-11-21 09:56:39 --> Config Class Initialized
INFO - 2023-11-21 09:56:39 --> Loader Class Initialized
INFO - 2023-11-21 09:56:39 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:39 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:39 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:39 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:39 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:39 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-21 09:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:39 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:39 --> Total execution time: 0.0312
INFO - 2023-11-21 09:56:51 --> Config Class Initialized
INFO - 2023-11-21 09:56:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:51 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:51 --> URI Class Initialized
INFO - 2023-11-21 09:56:51 --> Router Class Initialized
INFO - 2023-11-21 09:56:51 --> Output Class Initialized
INFO - 2023-11-21 09:56:51 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:51 --> Input Class Initialized
INFO - 2023-11-21 09:56:51 --> Language Class Initialized
INFO - 2023-11-21 09:56:51 --> Language Class Initialized
INFO - 2023-11-21 09:56:51 --> Config Class Initialized
INFO - 2023-11-21 09:56:51 --> Loader Class Initialized
INFO - 2023-11-21 09:56:51 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:51 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:51 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:51 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:51 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:51 --> Controller Class Initialized
INFO - 2023-11-21 09:56:52 --> Config Class Initialized
INFO - 2023-11-21 09:56:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:52 --> URI Class Initialized
INFO - 2023-11-21 09:56:52 --> Router Class Initialized
INFO - 2023-11-21 09:56:52 --> Output Class Initialized
INFO - 2023-11-21 09:56:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:52 --> Input Class Initialized
INFO - 2023-11-21 09:56:52 --> Language Class Initialized
INFO - 2023-11-21 09:56:52 --> Language Class Initialized
INFO - 2023-11-21 09:56:52 --> Config Class Initialized
INFO - 2023-11-21 09:56:52 --> Loader Class Initialized
INFO - 2023-11-21 09:56:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:52 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:52 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:52 --> Total execution time: 0.0387
INFO - 2023-11-21 09:56:52 --> Config Class Initialized
INFO - 2023-11-21 09:56:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:52 --> URI Class Initialized
INFO - 2023-11-21 09:56:52 --> Router Class Initialized
INFO - 2023-11-21 09:56:52 --> Output Class Initialized
INFO - 2023-11-21 09:56:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:52 --> Input Class Initialized
INFO - 2023-11-21 09:56:52 --> Language Class Initialized
ERROR - 2023-11-21 09:56:52 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:56:52 --> Config Class Initialized
INFO - 2023-11-21 09:56:52 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:52 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:52 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:52 --> URI Class Initialized
INFO - 2023-11-21 09:56:52 --> Router Class Initialized
INFO - 2023-11-21 09:56:52 --> Output Class Initialized
INFO - 2023-11-21 09:56:52 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:52 --> Input Class Initialized
INFO - 2023-11-21 09:56:52 --> Language Class Initialized
INFO - 2023-11-21 09:56:52 --> Language Class Initialized
INFO - 2023-11-21 09:56:52 --> Config Class Initialized
INFO - 2023-11-21 09:56:52 --> Loader Class Initialized
INFO - 2023-11-21 09:56:52 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:52 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:52 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:52 --> Controller Class Initialized
INFO - 2023-11-21 09:56:53 --> Config Class Initialized
INFO - 2023-11-21 09:56:53 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:56:53 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:56:53 --> Utf8 Class Initialized
INFO - 2023-11-21 09:56:53 --> URI Class Initialized
INFO - 2023-11-21 09:56:53 --> Router Class Initialized
INFO - 2023-11-21 09:56:53 --> Output Class Initialized
INFO - 2023-11-21 09:56:53 --> Security Class Initialized
DEBUG - 2023-11-21 09:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:56:53 --> Input Class Initialized
INFO - 2023-11-21 09:56:53 --> Language Class Initialized
INFO - 2023-11-21 09:56:53 --> Language Class Initialized
INFO - 2023-11-21 09:56:53 --> Config Class Initialized
INFO - 2023-11-21 09:56:53 --> Loader Class Initialized
INFO - 2023-11-21 09:56:53 --> Helper loaded: url_helper
INFO - 2023-11-21 09:56:53 --> Helper loaded: file_helper
INFO - 2023-11-21 09:56:53 --> Helper loaded: form_helper
INFO - 2023-11-21 09:56:53 --> Helper loaded: my_helper
INFO - 2023-11-21 09:56:53 --> Database Driver Class Initialized
INFO - 2023-11-21 09:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:56:53 --> Controller Class Initialized
DEBUG - 2023-11-21 09:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-21 09:56:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:56:53 --> Final output sent to browser
DEBUG - 2023-11-21 09:56:53 --> Total execution time: 0.0459
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:02 --> URI Class Initialized
INFO - 2023-11-21 09:57:02 --> Router Class Initialized
INFO - 2023-11-21 09:57:02 --> Output Class Initialized
INFO - 2023-11-21 09:57:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:02 --> Input Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Loader Class Initialized
INFO - 2023-11-21 09:57:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:02 --> Controller Class Initialized
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:02 --> URI Class Initialized
INFO - 2023-11-21 09:57:02 --> Router Class Initialized
INFO - 2023-11-21 09:57:02 --> Output Class Initialized
INFO - 2023-11-21 09:57:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:02 --> Input Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Loader Class Initialized
INFO - 2023-11-21 09:57:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:02 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-21 09:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:02 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:02 --> Total execution time: 0.0412
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:02 --> URI Class Initialized
INFO - 2023-11-21 09:57:02 --> Router Class Initialized
INFO - 2023-11-21 09:57:02 --> Output Class Initialized
INFO - 2023-11-21 09:57:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:02 --> Input Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
ERROR - 2023-11-21 09:57:02 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:02 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:02 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:02 --> URI Class Initialized
INFO - 2023-11-21 09:57:02 --> Router Class Initialized
INFO - 2023-11-21 09:57:02 --> Output Class Initialized
INFO - 2023-11-21 09:57:02 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:02 --> Input Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Language Class Initialized
INFO - 2023-11-21 09:57:02 --> Config Class Initialized
INFO - 2023-11-21 09:57:02 --> Loader Class Initialized
INFO - 2023-11-21 09:57:02 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:02 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:02 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:02 --> Controller Class Initialized
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:10 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:10 --> URI Class Initialized
INFO - 2023-11-21 09:57:10 --> Router Class Initialized
INFO - 2023-11-21 09:57:10 --> Output Class Initialized
INFO - 2023-11-21 09:57:10 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:10 --> Input Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Loader Class Initialized
INFO - 2023-11-21 09:57:10 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:10 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:10 --> Controller Class Initialized
INFO - 2023-11-21 09:57:10 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:10 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:10 --> URI Class Initialized
INFO - 2023-11-21 09:57:10 --> Router Class Initialized
INFO - 2023-11-21 09:57:10 --> Output Class Initialized
INFO - 2023-11-21 09:57:10 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:10 --> Input Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Loader Class Initialized
INFO - 2023-11-21 09:57:10 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:10 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:10 --> Controller Class Initialized
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:10 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:10 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:10 --> URI Class Initialized
INFO - 2023-11-21 09:57:10 --> Router Class Initialized
INFO - 2023-11-21 09:57:10 --> Output Class Initialized
INFO - 2023-11-21 09:57:10 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:10 --> Input Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Language Class Initialized
INFO - 2023-11-21 09:57:10 --> Config Class Initialized
INFO - 2023-11-21 09:57:10 --> Loader Class Initialized
INFO - 2023-11-21 09:57:10 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:10 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:10 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:10 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:10 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:10 --> Total execution time: 0.0345
INFO - 2023-11-21 09:57:14 --> Config Class Initialized
INFO - 2023-11-21 09:57:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:14 --> URI Class Initialized
INFO - 2023-11-21 09:57:14 --> Router Class Initialized
INFO - 2023-11-21 09:57:14 --> Output Class Initialized
INFO - 2023-11-21 09:57:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:14 --> Input Class Initialized
INFO - 2023-11-21 09:57:14 --> Language Class Initialized
INFO - 2023-11-21 09:57:14 --> Language Class Initialized
INFO - 2023-11-21 09:57:14 --> Config Class Initialized
INFO - 2023-11-21 09:57:14 --> Loader Class Initialized
INFO - 2023-11-21 09:57:14 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:14 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:14 --> Controller Class Initialized
INFO - 2023-11-21 09:57:14 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:57:14 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:14 --> Total execution time: 0.0404
INFO - 2023-11-21 09:57:14 --> Config Class Initialized
INFO - 2023-11-21 09:57:14 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:14 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:14 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:14 --> URI Class Initialized
INFO - 2023-11-21 09:57:14 --> Router Class Initialized
INFO - 2023-11-21 09:57:14 --> Output Class Initialized
INFO - 2023-11-21 09:57:14 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:14 --> Input Class Initialized
INFO - 2023-11-21 09:57:14 --> Language Class Initialized
INFO - 2023-11-21 09:57:14 --> Language Class Initialized
INFO - 2023-11-21 09:57:14 --> Config Class Initialized
INFO - 2023-11-21 09:57:14 --> Loader Class Initialized
INFO - 2023-11-21 09:57:14 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:14 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:14 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:14 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 09:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:14 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:14 --> Total execution time: 0.0392
INFO - 2023-11-21 09:57:17 --> Config Class Initialized
INFO - 2023-11-21 09:57:17 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:17 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:17 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:17 --> URI Class Initialized
INFO - 2023-11-21 09:57:17 --> Router Class Initialized
INFO - 2023-11-21 09:57:17 --> Output Class Initialized
INFO - 2023-11-21 09:57:17 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:17 --> Input Class Initialized
INFO - 2023-11-21 09:57:17 --> Language Class Initialized
INFO - 2023-11-21 09:57:17 --> Language Class Initialized
INFO - 2023-11-21 09:57:17 --> Config Class Initialized
INFO - 2023-11-21 09:57:17 --> Loader Class Initialized
INFO - 2023-11-21 09:57:17 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:17 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:17 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:17 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:17 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:17 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:17 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:17 --> Total execution time: 0.0341
INFO - 2023-11-21 09:57:24 --> Config Class Initialized
INFO - 2023-11-21 09:57:24 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:24 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:24 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:24 --> URI Class Initialized
INFO - 2023-11-21 09:57:24 --> Router Class Initialized
INFO - 2023-11-21 09:57:24 --> Output Class Initialized
INFO - 2023-11-21 09:57:24 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:24 --> Input Class Initialized
INFO - 2023-11-21 09:57:24 --> Language Class Initialized
INFO - 2023-11-21 09:57:24 --> Language Class Initialized
INFO - 2023-11-21 09:57:24 --> Config Class Initialized
INFO - 2023-11-21 09:57:24 --> Loader Class Initialized
INFO - 2023-11-21 09:57:24 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:24 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:24 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-11-21 09:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:24 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:24 --> Total execution time: 0.0445
INFO - 2023-11-21 09:57:24 --> Config Class Initialized
INFO - 2023-11-21 09:57:24 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:24 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:24 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:24 --> URI Class Initialized
INFO - 2023-11-21 09:57:24 --> Router Class Initialized
INFO - 2023-11-21 09:57:24 --> Output Class Initialized
INFO - 2023-11-21 09:57:24 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:24 --> Input Class Initialized
INFO - 2023-11-21 09:57:24 --> Language Class Initialized
INFO - 2023-11-21 09:57:24 --> Language Class Initialized
INFO - 2023-11-21 09:57:24 --> Config Class Initialized
INFO - 2023-11-21 09:57:24 --> Loader Class Initialized
INFO - 2023-11-21 09:57:24 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:24 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:24 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:24 --> Controller Class Initialized
INFO - 2023-11-21 09:57:30 --> Config Class Initialized
INFO - 2023-11-21 09:57:30 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:30 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:30 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:30 --> URI Class Initialized
INFO - 2023-11-21 09:57:30 --> Router Class Initialized
INFO - 2023-11-21 09:57:30 --> Output Class Initialized
INFO - 2023-11-21 09:57:30 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:30 --> Input Class Initialized
INFO - 2023-11-21 09:57:30 --> Language Class Initialized
INFO - 2023-11-21 09:57:30 --> Language Class Initialized
INFO - 2023-11-21 09:57:30 --> Config Class Initialized
INFO - 2023-11-21 09:57:30 --> Loader Class Initialized
INFO - 2023-11-21 09:57:30 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:30 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:30 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:30 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:30 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:30 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 09:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:30 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:30 --> Total execution time: 0.0441
INFO - 2023-11-21 09:57:34 --> Config Class Initialized
INFO - 2023-11-21 09:57:34 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:34 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:34 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:34 --> URI Class Initialized
INFO - 2023-11-21 09:57:34 --> Router Class Initialized
INFO - 2023-11-21 09:57:34 --> Output Class Initialized
INFO - 2023-11-21 09:57:34 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:34 --> Input Class Initialized
INFO - 2023-11-21 09:57:34 --> Language Class Initialized
INFO - 2023-11-21 09:57:34 --> Language Class Initialized
INFO - 2023-11-21 09:57:34 --> Config Class Initialized
INFO - 2023-11-21 09:57:34 --> Loader Class Initialized
INFO - 2023-11-21 09:57:34 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:34 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:34 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:34 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:34 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:34 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-11-21 09:57:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:34 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:34 --> Total execution time: 0.0361
INFO - 2023-11-21 09:57:35 --> Config Class Initialized
INFO - 2023-11-21 09:57:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:35 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:35 --> URI Class Initialized
INFO - 2023-11-21 09:57:35 --> Router Class Initialized
INFO - 2023-11-21 09:57:35 --> Output Class Initialized
INFO - 2023-11-21 09:57:35 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:35 --> Input Class Initialized
INFO - 2023-11-21 09:57:35 --> Language Class Initialized
INFO - 2023-11-21 09:57:35 --> Language Class Initialized
INFO - 2023-11-21 09:57:35 --> Config Class Initialized
INFO - 2023-11-21 09:57:35 --> Loader Class Initialized
INFO - 2023-11-21 09:57:35 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:35 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:35 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:35 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:35 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:35 --> Controller Class Initialized
INFO - 2023-11-21 09:57:35 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:35 --> Total execution time: 0.0349
INFO - 2023-11-21 09:57:37 --> Config Class Initialized
INFO - 2023-11-21 09:57:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:37 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:37 --> URI Class Initialized
INFO - 2023-11-21 09:57:37 --> Router Class Initialized
INFO - 2023-11-21 09:57:37 --> Output Class Initialized
INFO - 2023-11-21 09:57:37 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:37 --> Input Class Initialized
INFO - 2023-11-21 09:57:37 --> Language Class Initialized
INFO - 2023-11-21 09:57:37 --> Language Class Initialized
INFO - 2023-11-21 09:57:37 --> Config Class Initialized
INFO - 2023-11-21 09:57:37 --> Loader Class Initialized
INFO - 2023-11-21 09:57:37 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:37 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:37 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:37 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:37 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:37 --> Controller Class Initialized
INFO - 2023-11-21 09:57:37 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:37 --> Total execution time: 0.0457
INFO - 2023-11-21 09:57:38 --> Config Class Initialized
INFO - 2023-11-21 09:57:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:38 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:38 --> URI Class Initialized
INFO - 2023-11-21 09:57:38 --> Router Class Initialized
INFO - 2023-11-21 09:57:38 --> Output Class Initialized
INFO - 2023-11-21 09:57:38 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:38 --> Input Class Initialized
INFO - 2023-11-21 09:57:38 --> Language Class Initialized
INFO - 2023-11-21 09:57:38 --> Language Class Initialized
INFO - 2023-11-21 09:57:38 --> Config Class Initialized
INFO - 2023-11-21 09:57:38 --> Loader Class Initialized
INFO - 2023-11-21 09:57:38 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:38 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:38 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:38 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:38 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:38 --> Controller Class Initialized
INFO - 2023-11-21 09:57:38 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:38 --> Total execution time: 0.0339
INFO - 2023-11-21 09:57:39 --> Config Class Initialized
INFO - 2023-11-21 09:57:39 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:39 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:39 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:39 --> URI Class Initialized
INFO - 2023-11-21 09:57:39 --> Router Class Initialized
INFO - 2023-11-21 09:57:39 --> Output Class Initialized
INFO - 2023-11-21 09:57:39 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:39 --> Input Class Initialized
INFO - 2023-11-21 09:57:39 --> Language Class Initialized
INFO - 2023-11-21 09:57:39 --> Language Class Initialized
INFO - 2023-11-21 09:57:39 --> Config Class Initialized
INFO - 2023-11-21 09:57:39 --> Loader Class Initialized
INFO - 2023-11-21 09:57:39 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:39 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:39 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:39 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:39 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:39 --> Controller Class Initialized
INFO - 2023-11-21 09:57:39 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:39 --> Total execution time: 0.0328
INFO - 2023-11-21 09:57:40 --> Config Class Initialized
INFO - 2023-11-21 09:57:40 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:40 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:40 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:40 --> URI Class Initialized
INFO - 2023-11-21 09:57:40 --> Router Class Initialized
INFO - 2023-11-21 09:57:40 --> Output Class Initialized
INFO - 2023-11-21 09:57:40 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:40 --> Input Class Initialized
INFO - 2023-11-21 09:57:40 --> Language Class Initialized
INFO - 2023-11-21 09:57:40 --> Language Class Initialized
INFO - 2023-11-21 09:57:40 --> Config Class Initialized
INFO - 2023-11-21 09:57:40 --> Loader Class Initialized
INFO - 2023-11-21 09:57:40 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:40 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:40 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:40 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:40 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:40 --> Controller Class Initialized
INFO - 2023-11-21 09:57:40 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:40 --> Total execution time: 0.0337
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:43 --> URI Class Initialized
INFO - 2023-11-21 09:57:43 --> Router Class Initialized
INFO - 2023-11-21 09:57:43 --> Output Class Initialized
INFO - 2023-11-21 09:57:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:43 --> Input Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Loader Class Initialized
INFO - 2023-11-21 09:57:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:43 --> Controller Class Initialized
INFO - 2023-11-21 09:57:43 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:43 --> URI Class Initialized
INFO - 2023-11-21 09:57:43 --> Router Class Initialized
INFO - 2023-11-21 09:57:43 --> Output Class Initialized
INFO - 2023-11-21 09:57:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:43 --> Input Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Loader Class Initialized
INFO - 2023-11-21 09:57:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:43 --> Controller Class Initialized
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:43 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:43 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:43 --> URI Class Initialized
INFO - 2023-11-21 09:57:43 --> Router Class Initialized
INFO - 2023-11-21 09:57:43 --> Output Class Initialized
INFO - 2023-11-21 09:57:43 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:43 --> Input Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Language Class Initialized
INFO - 2023-11-21 09:57:43 --> Config Class Initialized
INFO - 2023-11-21 09:57:43 --> Loader Class Initialized
INFO - 2023-11-21 09:57:43 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:43 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:43 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:43 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:57:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:43 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:43 --> Total execution time: 0.0349
INFO - 2023-11-21 09:57:48 --> Config Class Initialized
INFO - 2023-11-21 09:57:48 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:48 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:48 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:48 --> URI Class Initialized
INFO - 2023-11-21 09:57:48 --> Router Class Initialized
INFO - 2023-11-21 09:57:48 --> Output Class Initialized
INFO - 2023-11-21 09:57:48 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:48 --> Input Class Initialized
INFO - 2023-11-21 09:57:48 --> Language Class Initialized
INFO - 2023-11-21 09:57:48 --> Language Class Initialized
INFO - 2023-11-21 09:57:48 --> Config Class Initialized
INFO - 2023-11-21 09:57:48 --> Loader Class Initialized
INFO - 2023-11-21 09:57:48 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:48 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:48 --> Controller Class Initialized
INFO - 2023-11-21 09:57:48 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:57:48 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:48 --> Total execution time: 0.1634
INFO - 2023-11-21 09:57:48 --> Config Class Initialized
INFO - 2023-11-21 09:57:48 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:48 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:48 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:48 --> URI Class Initialized
INFO - 2023-11-21 09:57:48 --> Router Class Initialized
INFO - 2023-11-21 09:57:48 --> Output Class Initialized
INFO - 2023-11-21 09:57:48 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:48 --> Input Class Initialized
INFO - 2023-11-21 09:57:48 --> Language Class Initialized
INFO - 2023-11-21 09:57:48 --> Language Class Initialized
INFO - 2023-11-21 09:57:48 --> Config Class Initialized
INFO - 2023-11-21 09:57:48 --> Loader Class Initialized
INFO - 2023-11-21 09:57:48 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:48 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:48 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:48 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-21 09:57:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:48 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:48 --> Total execution time: 0.0414
INFO - 2023-11-21 09:57:51 --> Config Class Initialized
INFO - 2023-11-21 09:57:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:51 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:51 --> URI Class Initialized
INFO - 2023-11-21 09:57:51 --> Router Class Initialized
INFO - 2023-11-21 09:57:51 --> Output Class Initialized
INFO - 2023-11-21 09:57:51 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:51 --> Input Class Initialized
INFO - 2023-11-21 09:57:51 --> Language Class Initialized
INFO - 2023-11-21 09:57:51 --> Language Class Initialized
INFO - 2023-11-21 09:57:51 --> Config Class Initialized
INFO - 2023-11-21 09:57:51 --> Loader Class Initialized
INFO - 2023-11-21 09:57:51 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:51 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:51 --> Controller Class Initialized
DEBUG - 2023-11-21 09:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-11-21 09:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:57:51 --> Final output sent to browser
DEBUG - 2023-11-21 09:57:51 --> Total execution time: 0.0417
INFO - 2023-11-21 09:57:51 --> Config Class Initialized
INFO - 2023-11-21 09:57:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:51 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:51 --> URI Class Initialized
INFO - 2023-11-21 09:57:51 --> Router Class Initialized
INFO - 2023-11-21 09:57:51 --> Output Class Initialized
INFO - 2023-11-21 09:57:51 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:51 --> Input Class Initialized
INFO - 2023-11-21 09:57:51 --> Language Class Initialized
ERROR - 2023-11-21 09:57:51 --> 404 Page Not Found: /index
INFO - 2023-11-21 09:57:51 --> Config Class Initialized
INFO - 2023-11-21 09:57:51 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:51 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:51 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:51 --> URI Class Initialized
INFO - 2023-11-21 09:57:51 --> Router Class Initialized
INFO - 2023-11-21 09:57:51 --> Output Class Initialized
INFO - 2023-11-21 09:57:51 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:51 --> Input Class Initialized
INFO - 2023-11-21 09:57:51 --> Language Class Initialized
INFO - 2023-11-21 09:57:51 --> Language Class Initialized
INFO - 2023-11-21 09:57:51 --> Config Class Initialized
INFO - 2023-11-21 09:57:51 --> Loader Class Initialized
INFO - 2023-11-21 09:57:51 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:51 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:51 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:51 --> Controller Class Initialized
INFO - 2023-11-21 09:57:55 --> Config Class Initialized
INFO - 2023-11-21 09:57:55 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:57:55 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:57:55 --> Utf8 Class Initialized
INFO - 2023-11-21 09:57:55 --> URI Class Initialized
INFO - 2023-11-21 09:57:55 --> Router Class Initialized
INFO - 2023-11-21 09:57:55 --> Output Class Initialized
INFO - 2023-11-21 09:57:55 --> Security Class Initialized
DEBUG - 2023-11-21 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:57:55 --> Input Class Initialized
INFO - 2023-11-21 09:57:55 --> Language Class Initialized
INFO - 2023-11-21 09:57:55 --> Language Class Initialized
INFO - 2023-11-21 09:57:55 --> Config Class Initialized
INFO - 2023-11-21 09:57:55 --> Loader Class Initialized
INFO - 2023-11-21 09:57:55 --> Helper loaded: url_helper
INFO - 2023-11-21 09:57:55 --> Helper loaded: file_helper
INFO - 2023-11-21 09:57:55 --> Helper loaded: form_helper
INFO - 2023-11-21 09:57:55 --> Helper loaded: my_helper
INFO - 2023-11-21 09:57:55 --> Database Driver Class Initialized
INFO - 2023-11-21 09:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:57:55 --> Controller Class Initialized
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:58:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:58:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:58:08 --> URI Class Initialized
INFO - 2023-11-21 09:58:08 --> Router Class Initialized
INFO - 2023-11-21 09:58:08 --> Output Class Initialized
INFO - 2023-11-21 09:58:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:58:08 --> Input Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Loader Class Initialized
INFO - 2023-11-21 09:58:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:58:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:58:08 --> Controller Class Initialized
INFO - 2023-11-21 09:58:08 --> Helper loaded: cookie_helper
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:58:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:58:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:58:08 --> URI Class Initialized
INFO - 2023-11-21 09:58:08 --> Router Class Initialized
INFO - 2023-11-21 09:58:08 --> Output Class Initialized
INFO - 2023-11-21 09:58:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:58:08 --> Input Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Loader Class Initialized
INFO - 2023-11-21 09:58:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:58:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:58:08 --> Controller Class Initialized
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Hooks Class Initialized
DEBUG - 2023-11-21 09:58:08 --> UTF-8 Support Enabled
INFO - 2023-11-21 09:58:08 --> Utf8 Class Initialized
INFO - 2023-11-21 09:58:08 --> URI Class Initialized
INFO - 2023-11-21 09:58:08 --> Router Class Initialized
INFO - 2023-11-21 09:58:08 --> Output Class Initialized
INFO - 2023-11-21 09:58:08 --> Security Class Initialized
DEBUG - 2023-11-21 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 09:58:08 --> Input Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Language Class Initialized
INFO - 2023-11-21 09:58:08 --> Config Class Initialized
INFO - 2023-11-21 09:58:08 --> Loader Class Initialized
INFO - 2023-11-21 09:58:08 --> Helper loaded: url_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: file_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: form_helper
INFO - 2023-11-21 09:58:08 --> Helper loaded: my_helper
INFO - 2023-11-21 09:58:08 --> Database Driver Class Initialized
INFO - 2023-11-21 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 09:58:08 --> Controller Class Initialized
DEBUG - 2023-11-21 09:58:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 09:58:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 09:58:08 --> Final output sent to browser
DEBUG - 2023-11-21 09:58:08 --> Total execution time: 0.0311
INFO - 2023-11-21 12:06:50 --> Config Class Initialized
INFO - 2023-11-21 12:06:50 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:06:50 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:06:50 --> Utf8 Class Initialized
INFO - 2023-11-21 12:06:50 --> URI Class Initialized
DEBUG - 2023-11-21 12:06:50 --> No URI present. Default controller set.
INFO - 2023-11-21 12:06:50 --> Router Class Initialized
INFO - 2023-11-21 12:06:50 --> Output Class Initialized
INFO - 2023-11-21 12:06:50 --> Security Class Initialized
DEBUG - 2023-11-21 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:06:50 --> Input Class Initialized
INFO - 2023-11-21 12:06:50 --> Language Class Initialized
INFO - 2023-11-21 12:06:50 --> Language Class Initialized
INFO - 2023-11-21 12:06:50 --> Config Class Initialized
INFO - 2023-11-21 12:06:50 --> Loader Class Initialized
INFO - 2023-11-21 12:06:50 --> Helper loaded: url_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: file_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: form_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: my_helper
INFO - 2023-11-21 12:06:50 --> Database Driver Class Initialized
INFO - 2023-11-21 12:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:06:50 --> Controller Class Initialized
INFO - 2023-11-21 12:06:50 --> Config Class Initialized
INFO - 2023-11-21 12:06:50 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:06:50 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:06:50 --> Utf8 Class Initialized
INFO - 2023-11-21 12:06:50 --> URI Class Initialized
INFO - 2023-11-21 12:06:50 --> Router Class Initialized
INFO - 2023-11-21 12:06:50 --> Output Class Initialized
INFO - 2023-11-21 12:06:50 --> Security Class Initialized
DEBUG - 2023-11-21 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:06:50 --> Input Class Initialized
INFO - 2023-11-21 12:06:50 --> Language Class Initialized
INFO - 2023-11-21 12:06:50 --> Language Class Initialized
INFO - 2023-11-21 12:06:50 --> Config Class Initialized
INFO - 2023-11-21 12:06:50 --> Loader Class Initialized
INFO - 2023-11-21 12:06:50 --> Helper loaded: url_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: file_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: form_helper
INFO - 2023-11-21 12:06:50 --> Helper loaded: my_helper
INFO - 2023-11-21 12:06:50 --> Database Driver Class Initialized
INFO - 2023-11-21 12:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:06:50 --> Controller Class Initialized
DEBUG - 2023-11-21 12:06:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 12:06:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 12:06:50 --> Final output sent to browser
DEBUG - 2023-11-21 12:06:50 --> Total execution time: 0.0341
INFO - 2023-11-21 12:07:01 --> Config Class Initialized
INFO - 2023-11-21 12:07:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:01 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:01 --> URI Class Initialized
INFO - 2023-11-21 12:07:01 --> Router Class Initialized
INFO - 2023-11-21 12:07:01 --> Output Class Initialized
INFO - 2023-11-21 12:07:01 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:01 --> Input Class Initialized
INFO - 2023-11-21 12:07:01 --> Language Class Initialized
INFO - 2023-11-21 12:07:01 --> Language Class Initialized
INFO - 2023-11-21 12:07:01 --> Config Class Initialized
INFO - 2023-11-21 12:07:01 --> Loader Class Initialized
INFO - 2023-11-21 12:07:01 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:01 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:01 --> Controller Class Initialized
INFO - 2023-11-21 12:07:01 --> Helper loaded: cookie_helper
INFO - 2023-11-21 12:07:01 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:01 --> Total execution time: 0.1984
INFO - 2023-11-21 12:07:01 --> Config Class Initialized
INFO - 2023-11-21 12:07:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:01 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:01 --> URI Class Initialized
INFO - 2023-11-21 12:07:01 --> Router Class Initialized
INFO - 2023-11-21 12:07:01 --> Output Class Initialized
INFO - 2023-11-21 12:07:01 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:01 --> Input Class Initialized
INFO - 2023-11-21 12:07:01 --> Language Class Initialized
INFO - 2023-11-21 12:07:01 --> Language Class Initialized
INFO - 2023-11-21 12:07:01 --> Config Class Initialized
INFO - 2023-11-21 12:07:01 --> Loader Class Initialized
INFO - 2023-11-21 12:07:01 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:01 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:01 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:01 --> Controller Class Initialized
DEBUG - 2023-11-21 12:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 12:07:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 12:07:01 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:01 --> Total execution time: 0.0536
INFO - 2023-11-21 12:07:05 --> Config Class Initialized
INFO - 2023-11-21 12:07:05 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:05 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:05 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:05 --> URI Class Initialized
INFO - 2023-11-21 12:07:05 --> Router Class Initialized
INFO - 2023-11-21 12:07:05 --> Output Class Initialized
INFO - 2023-11-21 12:07:05 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:05 --> Input Class Initialized
INFO - 2023-11-21 12:07:05 --> Language Class Initialized
INFO - 2023-11-21 12:07:05 --> Language Class Initialized
INFO - 2023-11-21 12:07:05 --> Config Class Initialized
INFO - 2023-11-21 12:07:05 --> Loader Class Initialized
INFO - 2023-11-21 12:07:05 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:05 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:05 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:05 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:05 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:05 --> Controller Class Initialized
DEBUG - 2023-11-21 12:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-21 12:07:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 12:07:05 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:05 --> Total execution time: 0.0463
INFO - 2023-11-21 12:07:09 --> Config Class Initialized
INFO - 2023-11-21 12:07:09 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:09 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:09 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:09 --> URI Class Initialized
INFO - 2023-11-21 12:07:09 --> Router Class Initialized
INFO - 2023-11-21 12:07:09 --> Output Class Initialized
INFO - 2023-11-21 12:07:09 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:09 --> Input Class Initialized
INFO - 2023-11-21 12:07:09 --> Language Class Initialized
INFO - 2023-11-21 12:07:09 --> Language Class Initialized
INFO - 2023-11-21 12:07:09 --> Config Class Initialized
INFO - 2023-11-21 12:07:09 --> Loader Class Initialized
INFO - 2023-11-21 12:07:09 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:09 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:09 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:09 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:09 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:09 --> Controller Class Initialized
DEBUG - 2023-11-21 12:07:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 12:07:11 --> Config Class Initialized
INFO - 2023-11-21 12:07:11 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:11 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:11 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:11 --> URI Class Initialized
INFO - 2023-11-21 12:07:11 --> Router Class Initialized
INFO - 2023-11-21 12:07:11 --> Output Class Initialized
INFO - 2023-11-21 12:07:11 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:11 --> Input Class Initialized
INFO - 2023-11-21 12:07:11 --> Language Class Initialized
INFO - 2023-11-21 12:07:11 --> Language Class Initialized
INFO - 2023-11-21 12:07:11 --> Config Class Initialized
INFO - 2023-11-21 12:07:11 --> Loader Class Initialized
INFO - 2023-11-21 12:07:11 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:11 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:11 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:11 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:11 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:12 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:12 --> Total execution time: 2.9779
INFO - 2023-11-21 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:12 --> Controller Class Initialized
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:07:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
DEBUG - 2023-11-21 12:07:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-21 12:07:17 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:17 --> Total execution time: 6.4608
INFO - 2023-11-21 12:07:44 --> Config Class Initialized
INFO - 2023-11-21 12:07:44 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:44 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:44 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:44 --> URI Class Initialized
INFO - 2023-11-21 12:07:44 --> Router Class Initialized
INFO - 2023-11-21 12:07:44 --> Output Class Initialized
INFO - 2023-11-21 12:07:44 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:44 --> Input Class Initialized
INFO - 2023-11-21 12:07:44 --> Language Class Initialized
INFO - 2023-11-21 12:07:44 --> Language Class Initialized
INFO - 2023-11-21 12:07:44 --> Config Class Initialized
INFO - 2023-11-21 12:07:44 --> Loader Class Initialized
INFO - 2023-11-21 12:07:44 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:44 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:44 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:44 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:44 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:44 --> Controller Class Initialized
DEBUG - 2023-11-21 12:07:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 12:07:45 --> Config Class Initialized
INFO - 2023-11-21 12:07:45 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:07:45 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:07:45 --> Utf8 Class Initialized
INFO - 2023-11-21 12:07:45 --> URI Class Initialized
INFO - 2023-11-21 12:07:45 --> Router Class Initialized
INFO - 2023-11-21 12:07:45 --> Output Class Initialized
INFO - 2023-11-21 12:07:45 --> Security Class Initialized
DEBUG - 2023-11-21 12:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:07:45 --> Input Class Initialized
INFO - 2023-11-21 12:07:45 --> Language Class Initialized
INFO - 2023-11-21 12:07:45 --> Language Class Initialized
INFO - 2023-11-21 12:07:45 --> Config Class Initialized
INFO - 2023-11-21 12:07:45 --> Loader Class Initialized
INFO - 2023-11-21 12:07:45 --> Helper loaded: url_helper
INFO - 2023-11-21 12:07:45 --> Helper loaded: file_helper
INFO - 2023-11-21 12:07:45 --> Helper loaded: form_helper
INFO - 2023-11-21 12:07:45 --> Helper loaded: my_helper
INFO - 2023-11-21 12:07:45 --> Database Driver Class Initialized
INFO - 2023-11-21 12:07:46 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:46 --> Total execution time: 2.1600
INFO - 2023-11-21 12:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:07:46 --> Controller Class Initialized
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:07:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:07:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
DEBUG - 2023-11-21 12:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-21 12:07:51 --> Final output sent to browser
DEBUG - 2023-11-21 12:07:51 --> Total execution time: 6.1810
INFO - 2023-11-21 12:08:06 --> Config Class Initialized
INFO - 2023-11-21 12:08:06 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:08:06 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:08:06 --> Utf8 Class Initialized
INFO - 2023-11-21 12:08:06 --> URI Class Initialized
INFO - 2023-11-21 12:08:06 --> Router Class Initialized
INFO - 2023-11-21 12:08:06 --> Output Class Initialized
INFO - 2023-11-21 12:08:06 --> Security Class Initialized
DEBUG - 2023-11-21 12:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:08:06 --> Input Class Initialized
INFO - 2023-11-21 12:08:06 --> Language Class Initialized
INFO - 2023-11-21 12:08:06 --> Language Class Initialized
INFO - 2023-11-21 12:08:06 --> Config Class Initialized
INFO - 2023-11-21 12:08:06 --> Loader Class Initialized
INFO - 2023-11-21 12:08:06 --> Helper loaded: url_helper
INFO - 2023-11-21 12:08:06 --> Helper loaded: file_helper
INFO - 2023-11-21 12:08:06 --> Helper loaded: form_helper
INFO - 2023-11-21 12:08:06 --> Helper loaded: my_helper
INFO - 2023-11-21 12:08:06 --> Database Driver Class Initialized
INFO - 2023-11-21 12:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:08:06 --> Controller Class Initialized
DEBUG - 2023-11-21 12:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-21 12:08:07 --> Config Class Initialized
INFO - 2023-11-21 12:08:07 --> Hooks Class Initialized
DEBUG - 2023-11-21 12:08:07 --> UTF-8 Support Enabled
INFO - 2023-11-21 12:08:07 --> Utf8 Class Initialized
INFO - 2023-11-21 12:08:07 --> URI Class Initialized
INFO - 2023-11-21 12:08:07 --> Router Class Initialized
INFO - 2023-11-21 12:08:07 --> Output Class Initialized
INFO - 2023-11-21 12:08:07 --> Security Class Initialized
DEBUG - 2023-11-21 12:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 12:08:07 --> Input Class Initialized
INFO - 2023-11-21 12:08:07 --> Language Class Initialized
INFO - 2023-11-21 12:08:07 --> Language Class Initialized
INFO - 2023-11-21 12:08:07 --> Config Class Initialized
INFO - 2023-11-21 12:08:07 --> Loader Class Initialized
INFO - 2023-11-21 12:08:07 --> Helper loaded: url_helper
INFO - 2023-11-21 12:08:07 --> Helper loaded: file_helper
INFO - 2023-11-21 12:08:07 --> Helper loaded: form_helper
INFO - 2023-11-21 12:08:07 --> Helper loaded: my_helper
INFO - 2023-11-21 12:08:07 --> Database Driver Class Initialized
INFO - 2023-11-21 12:08:09 --> Final output sent to browser
DEBUG - 2023-11-21 12:08:09 --> Total execution time: 3.5295
INFO - 2023-11-21 12:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 12:08:09 --> Controller Class Initialized
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:08:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-21 12:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
DEBUG - 2023-11-21 12:08:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-21 12:08:14 --> Final output sent to browser
DEBUG - 2023-11-21 12:08:14 --> Total execution time: 7.7219
INFO - 2023-11-21 15:55:28 --> Config Class Initialized
INFO - 2023-11-21 15:55:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:28 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:28 --> URI Class Initialized
INFO - 2023-11-21 15:55:28 --> Router Class Initialized
INFO - 2023-11-21 15:55:28 --> Output Class Initialized
INFO - 2023-11-21 15:55:28 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:28 --> Input Class Initialized
INFO - 2023-11-21 15:55:28 --> Language Class Initialized
INFO - 2023-11-21 15:55:28 --> Language Class Initialized
INFO - 2023-11-21 15:55:28 --> Config Class Initialized
INFO - 2023-11-21 15:55:28 --> Loader Class Initialized
INFO - 2023-11-21 15:55:28 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:28 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:28 --> Controller Class Initialized
INFO - 2023-11-21 15:55:28 --> Config Class Initialized
INFO - 2023-11-21 15:55:28 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:28 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:28 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:28 --> URI Class Initialized
INFO - 2023-11-21 15:55:28 --> Router Class Initialized
INFO - 2023-11-21 15:55:28 --> Output Class Initialized
INFO - 2023-11-21 15:55:28 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:28 --> Input Class Initialized
INFO - 2023-11-21 15:55:28 --> Language Class Initialized
INFO - 2023-11-21 15:55:28 --> Language Class Initialized
INFO - 2023-11-21 15:55:28 --> Config Class Initialized
INFO - 2023-11-21 15:55:28 --> Loader Class Initialized
INFO - 2023-11-21 15:55:28 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:28 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:28 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:28 --> Controller Class Initialized
DEBUG - 2023-11-21 15:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 15:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 15:55:28 --> Final output sent to browser
DEBUG - 2023-11-21 15:55:28 --> Total execution time: 0.0423
INFO - 2023-11-21 15:55:35 --> Config Class Initialized
INFO - 2023-11-21 15:55:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:35 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:35 --> URI Class Initialized
INFO - 2023-11-21 15:55:35 --> Router Class Initialized
INFO - 2023-11-21 15:55:35 --> Output Class Initialized
INFO - 2023-11-21 15:55:35 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:35 --> Input Class Initialized
INFO - 2023-11-21 15:55:35 --> Language Class Initialized
INFO - 2023-11-21 15:55:35 --> Language Class Initialized
INFO - 2023-11-21 15:55:35 --> Config Class Initialized
INFO - 2023-11-21 15:55:35 --> Loader Class Initialized
INFO - 2023-11-21 15:55:35 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:35 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:35 --> Controller Class Initialized
INFO - 2023-11-21 15:55:35 --> Helper loaded: cookie_helper
INFO - 2023-11-21 15:55:35 --> Final output sent to browser
DEBUG - 2023-11-21 15:55:35 --> Total execution time: 0.0956
INFO - 2023-11-21 15:55:35 --> Config Class Initialized
INFO - 2023-11-21 15:55:35 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:35 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:35 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:35 --> URI Class Initialized
INFO - 2023-11-21 15:55:35 --> Router Class Initialized
INFO - 2023-11-21 15:55:35 --> Output Class Initialized
INFO - 2023-11-21 15:55:35 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:35 --> Input Class Initialized
INFO - 2023-11-21 15:55:35 --> Language Class Initialized
INFO - 2023-11-21 15:55:35 --> Language Class Initialized
INFO - 2023-11-21 15:55:35 --> Config Class Initialized
INFO - 2023-11-21 15:55:35 --> Loader Class Initialized
INFO - 2023-11-21 15:55:35 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:35 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:35 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:35 --> Controller Class Initialized
DEBUG - 2023-11-21 15:55:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-21 15:55:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 15:55:35 --> Final output sent to browser
DEBUG - 2023-11-21 15:55:35 --> Total execution time: 0.0390
INFO - 2023-11-21 15:55:36 --> Config Class Initialized
INFO - 2023-11-21 15:55:36 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:36 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:36 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:36 --> URI Class Initialized
INFO - 2023-11-21 15:55:36 --> Router Class Initialized
INFO - 2023-11-21 15:55:36 --> Output Class Initialized
INFO - 2023-11-21 15:55:36 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:36 --> Input Class Initialized
INFO - 2023-11-21 15:55:36 --> Language Class Initialized
INFO - 2023-11-21 15:55:36 --> Language Class Initialized
INFO - 2023-11-21 15:55:36 --> Config Class Initialized
INFO - 2023-11-21 15:55:36 --> Loader Class Initialized
INFO - 2023-11-21 15:55:36 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:36 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:36 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:36 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:36 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:36 --> Controller Class Initialized
DEBUG - 2023-11-21 15:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-21 15:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 15:55:36 --> Final output sent to browser
DEBUG - 2023-11-21 15:55:36 --> Total execution time: 0.0343
INFO - 2023-11-21 15:55:37 --> Config Class Initialized
INFO - 2023-11-21 15:55:37 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:37 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:37 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:37 --> URI Class Initialized
INFO - 2023-11-21 15:55:37 --> Router Class Initialized
INFO - 2023-11-21 15:55:37 --> Output Class Initialized
INFO - 2023-11-21 15:55:37 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:37 --> Input Class Initialized
INFO - 2023-11-21 15:55:37 --> Language Class Initialized
INFO - 2023-11-21 15:55:37 --> Language Class Initialized
INFO - 2023-11-21 15:55:37 --> Config Class Initialized
INFO - 2023-11-21 15:55:37 --> Loader Class Initialized
INFO - 2023-11-21 15:55:37 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:37 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:37 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:37 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:37 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:37 --> Controller Class Initialized
DEBUG - 2023-11-21 15:55:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-21 15:55:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 15:55:38 --> Final output sent to browser
DEBUG - 2023-11-21 15:55:38 --> Total execution time: 0.2488
INFO - 2023-11-21 15:55:38 --> Config Class Initialized
INFO - 2023-11-21 15:55:38 --> Hooks Class Initialized
DEBUG - 2023-11-21 15:55:38 --> UTF-8 Support Enabled
INFO - 2023-11-21 15:55:38 --> Utf8 Class Initialized
INFO - 2023-11-21 15:55:38 --> URI Class Initialized
INFO - 2023-11-21 15:55:38 --> Router Class Initialized
INFO - 2023-11-21 15:55:38 --> Output Class Initialized
INFO - 2023-11-21 15:55:38 --> Security Class Initialized
DEBUG - 2023-11-21 15:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 15:55:38 --> Input Class Initialized
INFO - 2023-11-21 15:55:38 --> Language Class Initialized
INFO - 2023-11-21 15:55:38 --> Language Class Initialized
INFO - 2023-11-21 15:55:38 --> Config Class Initialized
INFO - 2023-11-21 15:55:38 --> Loader Class Initialized
INFO - 2023-11-21 15:55:38 --> Helper loaded: url_helper
INFO - 2023-11-21 15:55:38 --> Helper loaded: file_helper
INFO - 2023-11-21 15:55:38 --> Helper loaded: form_helper
INFO - 2023-11-21 15:55:38 --> Helper loaded: my_helper
INFO - 2023-11-21 15:55:38 --> Database Driver Class Initialized
INFO - 2023-11-21 15:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 15:55:38 --> Controller Class Initialized
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 16:00:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 16:00:01 --> Utf8 Class Initialized
INFO - 2023-11-21 16:00:01 --> URI Class Initialized
INFO - 2023-11-21 16:00:01 --> Router Class Initialized
INFO - 2023-11-21 16:00:01 --> Output Class Initialized
INFO - 2023-11-21 16:00:01 --> Security Class Initialized
DEBUG - 2023-11-21 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 16:00:01 --> Input Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Loader Class Initialized
INFO - 2023-11-21 16:00:01 --> Helper loaded: url_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: file_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: form_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: my_helper
INFO - 2023-11-21 16:00:01 --> Database Driver Class Initialized
INFO - 2023-11-21 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 16:00:01 --> Controller Class Initialized
INFO - 2023-11-21 16:00:01 --> Helper loaded: cookie_helper
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 16:00:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 16:00:01 --> Utf8 Class Initialized
INFO - 2023-11-21 16:00:01 --> URI Class Initialized
INFO - 2023-11-21 16:00:01 --> Router Class Initialized
INFO - 2023-11-21 16:00:01 --> Output Class Initialized
INFO - 2023-11-21 16:00:01 --> Security Class Initialized
DEBUG - 2023-11-21 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 16:00:01 --> Input Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Loader Class Initialized
INFO - 2023-11-21 16:00:01 --> Helper loaded: url_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: file_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: form_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: my_helper
INFO - 2023-11-21 16:00:01 --> Database Driver Class Initialized
INFO - 2023-11-21 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 16:00:01 --> Controller Class Initialized
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Hooks Class Initialized
DEBUG - 2023-11-21 16:00:01 --> UTF-8 Support Enabled
INFO - 2023-11-21 16:00:01 --> Utf8 Class Initialized
INFO - 2023-11-21 16:00:01 --> URI Class Initialized
INFO - 2023-11-21 16:00:01 --> Router Class Initialized
INFO - 2023-11-21 16:00:01 --> Output Class Initialized
INFO - 2023-11-21 16:00:01 --> Security Class Initialized
DEBUG - 2023-11-21 16:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-21 16:00:01 --> Input Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Language Class Initialized
INFO - 2023-11-21 16:00:01 --> Config Class Initialized
INFO - 2023-11-21 16:00:01 --> Loader Class Initialized
INFO - 2023-11-21 16:00:01 --> Helper loaded: url_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: file_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: form_helper
INFO - 2023-11-21 16:00:01 --> Helper loaded: my_helper
INFO - 2023-11-21 16:00:01 --> Database Driver Class Initialized
INFO - 2023-11-21 16:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-21 16:00:01 --> Controller Class Initialized
DEBUG - 2023-11-21 16:00:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-21 16:00:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-21 16:00:01 --> Final output sent to browser
DEBUG - 2023-11-21 16:00:01 --> Total execution time: 0.0712
