<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-05 08:45:45 --> Config Class Initialized
INFO - 2023-09-05 08:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:45:45 --> Utf8 Class Initialized
INFO - 2023-09-05 08:45:45 --> URI Class Initialized
DEBUG - 2023-09-05 08:45:45 --> No URI present. Default controller set.
INFO - 2023-09-05 08:45:45 --> Router Class Initialized
INFO - 2023-09-05 08:45:45 --> Output Class Initialized
INFO - 2023-09-05 08:45:45 --> Security Class Initialized
DEBUG - 2023-09-05 08:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:45:45 --> Input Class Initialized
INFO - 2023-09-05 08:45:45 --> Language Class Initialized
INFO - 2023-09-05 08:45:45 --> Language Class Initialized
INFO - 2023-09-05 08:45:45 --> Config Class Initialized
INFO - 2023-09-05 08:45:45 --> Loader Class Initialized
INFO - 2023-09-05 08:45:45 --> Helper loaded: url_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: file_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: form_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: my_helper
INFO - 2023-09-05 08:45:45 --> Database Driver Class Initialized
INFO - 2023-09-05 08:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:45:45 --> Controller Class Initialized
INFO - 2023-09-05 08:45:45 --> Config Class Initialized
INFO - 2023-09-05 08:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:45:45 --> Utf8 Class Initialized
INFO - 2023-09-05 08:45:45 --> URI Class Initialized
INFO - 2023-09-05 08:45:45 --> Router Class Initialized
INFO - 2023-09-05 08:45:45 --> Output Class Initialized
INFO - 2023-09-05 08:45:45 --> Security Class Initialized
DEBUG - 2023-09-05 08:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:45:45 --> Input Class Initialized
INFO - 2023-09-05 08:45:45 --> Language Class Initialized
INFO - 2023-09-05 08:45:45 --> Language Class Initialized
INFO - 2023-09-05 08:45:45 --> Config Class Initialized
INFO - 2023-09-05 08:45:45 --> Loader Class Initialized
INFO - 2023-09-05 08:45:45 --> Helper loaded: url_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: file_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: form_helper
INFO - 2023-09-05 08:45:45 --> Helper loaded: my_helper
INFO - 2023-09-05 08:45:45 --> Database Driver Class Initialized
INFO - 2023-09-05 08:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:45:45 --> Controller Class Initialized
DEBUG - 2023-09-05 08:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-05 08:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:45:45 --> Final output sent to browser
DEBUG - 2023-09-05 08:45:45 --> Total execution time: 0.0347
INFO - 2023-09-05 08:45:51 --> Config Class Initialized
INFO - 2023-09-05 08:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:45:51 --> Utf8 Class Initialized
INFO - 2023-09-05 08:45:51 --> URI Class Initialized
INFO - 2023-09-05 08:45:51 --> Router Class Initialized
INFO - 2023-09-05 08:45:51 --> Output Class Initialized
INFO - 2023-09-05 08:45:51 --> Security Class Initialized
DEBUG - 2023-09-05 08:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:45:51 --> Input Class Initialized
INFO - 2023-09-05 08:45:51 --> Language Class Initialized
INFO - 2023-09-05 08:45:51 --> Language Class Initialized
INFO - 2023-09-05 08:45:51 --> Config Class Initialized
INFO - 2023-09-05 08:45:51 --> Loader Class Initialized
INFO - 2023-09-05 08:45:51 --> Helper loaded: url_helper
INFO - 2023-09-05 08:45:51 --> Helper loaded: file_helper
INFO - 2023-09-05 08:45:51 --> Helper loaded: form_helper
INFO - 2023-09-05 08:45:51 --> Helper loaded: my_helper
INFO - 2023-09-05 08:45:51 --> Database Driver Class Initialized
INFO - 2023-09-05 08:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:45:51 --> Controller Class Initialized
INFO - 2023-09-05 08:45:51 --> Final output sent to browser
DEBUG - 2023-09-05 08:45:51 --> Total execution time: 0.0304
INFO - 2023-09-05 08:45:59 --> Config Class Initialized
INFO - 2023-09-05 08:45:59 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:45:59 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:45:59 --> Utf8 Class Initialized
INFO - 2023-09-05 08:45:59 --> URI Class Initialized
INFO - 2023-09-05 08:45:59 --> Router Class Initialized
INFO - 2023-09-05 08:45:59 --> Output Class Initialized
INFO - 2023-09-05 08:45:59 --> Security Class Initialized
DEBUG - 2023-09-05 08:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:45:59 --> Input Class Initialized
INFO - 2023-09-05 08:45:59 --> Language Class Initialized
INFO - 2023-09-05 08:45:59 --> Language Class Initialized
INFO - 2023-09-05 08:45:59 --> Config Class Initialized
INFO - 2023-09-05 08:45:59 --> Loader Class Initialized
INFO - 2023-09-05 08:45:59 --> Helper loaded: url_helper
INFO - 2023-09-05 08:45:59 --> Helper loaded: file_helper
INFO - 2023-09-05 08:45:59 --> Helper loaded: form_helper
INFO - 2023-09-05 08:45:59 --> Helper loaded: my_helper
INFO - 2023-09-05 08:45:59 --> Database Driver Class Initialized
INFO - 2023-09-05 08:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:45:59 --> Controller Class Initialized
INFO - 2023-09-05 08:45:59 --> Final output sent to browser
DEBUG - 2023-09-05 08:45:59 --> Total execution time: 0.0386
INFO - 2023-09-05 08:46:06 --> Config Class Initialized
INFO - 2023-09-05 08:46:06 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:06 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:06 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:06 --> URI Class Initialized
INFO - 2023-09-05 08:46:06 --> Router Class Initialized
INFO - 2023-09-05 08:46:06 --> Output Class Initialized
INFO - 2023-09-05 08:46:06 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:06 --> Input Class Initialized
INFO - 2023-09-05 08:46:06 --> Language Class Initialized
INFO - 2023-09-05 08:46:06 --> Language Class Initialized
INFO - 2023-09-05 08:46:06 --> Config Class Initialized
INFO - 2023-09-05 08:46:06 --> Loader Class Initialized
INFO - 2023-09-05 08:46:06 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:06 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:06 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:06 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:06 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:06 --> Controller Class Initialized
INFO - 2023-09-05 08:46:07 --> Helper loaded: cookie_helper
INFO - 2023-09-05 08:46:07 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:07 --> Total execution time: 0.0466
INFO - 2023-09-05 08:46:07 --> Config Class Initialized
INFO - 2023-09-05 08:46:07 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:07 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:07 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:07 --> URI Class Initialized
INFO - 2023-09-05 08:46:07 --> Router Class Initialized
INFO - 2023-09-05 08:46:07 --> Output Class Initialized
INFO - 2023-09-05 08:46:07 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:07 --> Input Class Initialized
INFO - 2023-09-05 08:46:07 --> Language Class Initialized
INFO - 2023-09-05 08:46:07 --> Language Class Initialized
INFO - 2023-09-05 08:46:07 --> Config Class Initialized
INFO - 2023-09-05 08:46:07 --> Loader Class Initialized
INFO - 2023-09-05 08:46:07 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:07 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:07 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:07 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:07 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:07 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-05 08:46:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:07 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:07 --> Total execution time: 0.0458
INFO - 2023-09-05 08:46:08 --> Config Class Initialized
INFO - 2023-09-05 08:46:08 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:08 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:08 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:08 --> URI Class Initialized
INFO - 2023-09-05 08:46:08 --> Router Class Initialized
INFO - 2023-09-05 08:46:08 --> Output Class Initialized
INFO - 2023-09-05 08:46:08 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:08 --> Input Class Initialized
INFO - 2023-09-05 08:46:08 --> Language Class Initialized
INFO - 2023-09-05 08:46:08 --> Language Class Initialized
INFO - 2023-09-05 08:46:08 --> Config Class Initialized
INFO - 2023-09-05 08:46:08 --> Loader Class Initialized
INFO - 2023-09-05 08:46:08 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:08 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:08 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-05 08:46:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:08 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:08 --> Total execution time: 0.0327
INFO - 2023-09-05 08:46:08 --> Config Class Initialized
INFO - 2023-09-05 08:46:08 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:08 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:08 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:08 --> URI Class Initialized
INFO - 2023-09-05 08:46:08 --> Router Class Initialized
INFO - 2023-09-05 08:46:08 --> Output Class Initialized
INFO - 2023-09-05 08:46:08 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:08 --> Input Class Initialized
INFO - 2023-09-05 08:46:08 --> Language Class Initialized
ERROR - 2023-09-05 08:46:08 --> 404 Page Not Found: /index
INFO - 2023-09-05 08:46:08 --> Config Class Initialized
INFO - 2023-09-05 08:46:08 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:08 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:08 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:08 --> URI Class Initialized
INFO - 2023-09-05 08:46:08 --> Router Class Initialized
INFO - 2023-09-05 08:46:08 --> Output Class Initialized
INFO - 2023-09-05 08:46:08 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:08 --> Input Class Initialized
INFO - 2023-09-05 08:46:08 --> Language Class Initialized
INFO - 2023-09-05 08:46:08 --> Language Class Initialized
INFO - 2023-09-05 08:46:08 --> Config Class Initialized
INFO - 2023-09-05 08:46:08 --> Loader Class Initialized
INFO - 2023-09-05 08:46:08 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:08 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:08 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:08 --> Controller Class Initialized
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:13 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:13 --> URI Class Initialized
INFO - 2023-09-05 08:46:13 --> Router Class Initialized
INFO - 2023-09-05 08:46:13 --> Output Class Initialized
INFO - 2023-09-05 08:46:13 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:13 --> Input Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Loader Class Initialized
INFO - 2023-09-05 08:46:13 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:13 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:13 --> Controller Class Initialized
INFO - 2023-09-05 08:46:13 --> Helper loaded: cookie_helper
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:13 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:13 --> URI Class Initialized
INFO - 2023-09-05 08:46:13 --> Router Class Initialized
INFO - 2023-09-05 08:46:13 --> Output Class Initialized
INFO - 2023-09-05 08:46:13 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:13 --> Input Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Loader Class Initialized
INFO - 2023-09-05 08:46:13 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:13 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:13 --> Controller Class Initialized
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:13 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:13 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:13 --> URI Class Initialized
INFO - 2023-09-05 08:46:13 --> Router Class Initialized
INFO - 2023-09-05 08:46:13 --> Output Class Initialized
INFO - 2023-09-05 08:46:13 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:13 --> Input Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Language Class Initialized
INFO - 2023-09-05 08:46:13 --> Config Class Initialized
INFO - 2023-09-05 08:46:13 --> Loader Class Initialized
INFO - 2023-09-05 08:46:13 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:13 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:13 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:13 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-05 08:46:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:13 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:13 --> Total execution time: 0.0361
INFO - 2023-09-05 08:46:16 --> Config Class Initialized
INFO - 2023-09-05 08:46:16 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:16 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:16 --> URI Class Initialized
INFO - 2023-09-05 08:46:16 --> Router Class Initialized
INFO - 2023-09-05 08:46:16 --> Output Class Initialized
INFO - 2023-09-05 08:46:16 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:16 --> Input Class Initialized
INFO - 2023-09-05 08:46:16 --> Language Class Initialized
INFO - 2023-09-05 08:46:16 --> Language Class Initialized
INFO - 2023-09-05 08:46:16 --> Config Class Initialized
INFO - 2023-09-05 08:46:16 --> Loader Class Initialized
INFO - 2023-09-05 08:46:16 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:16 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:16 --> Controller Class Initialized
INFO - 2023-09-05 08:46:16 --> Helper loaded: cookie_helper
INFO - 2023-09-05 08:46:16 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:16 --> Total execution time: 0.0856
INFO - 2023-09-05 08:46:16 --> Config Class Initialized
INFO - 2023-09-05 08:46:16 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:16 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:16 --> URI Class Initialized
INFO - 2023-09-05 08:46:16 --> Router Class Initialized
INFO - 2023-09-05 08:46:16 --> Output Class Initialized
INFO - 2023-09-05 08:46:16 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:16 --> Input Class Initialized
INFO - 2023-09-05 08:46:16 --> Language Class Initialized
INFO - 2023-09-05 08:46:16 --> Language Class Initialized
INFO - 2023-09-05 08:46:16 --> Config Class Initialized
INFO - 2023-09-05 08:46:16 --> Loader Class Initialized
INFO - 2023-09-05 08:46:16 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:16 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:16 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:16 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-05 08:46:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:16 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:16 --> Total execution time: 0.1077
INFO - 2023-09-05 08:46:19 --> Config Class Initialized
INFO - 2023-09-05 08:46:19 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:19 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:19 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:19 --> URI Class Initialized
INFO - 2023-09-05 08:46:19 --> Router Class Initialized
INFO - 2023-09-05 08:46:19 --> Output Class Initialized
INFO - 2023-09-05 08:46:19 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:19 --> Input Class Initialized
INFO - 2023-09-05 08:46:19 --> Language Class Initialized
INFO - 2023-09-05 08:46:19 --> Language Class Initialized
INFO - 2023-09-05 08:46:19 --> Config Class Initialized
INFO - 2023-09-05 08:46:19 --> Loader Class Initialized
INFO - 2023-09-05 08:46:19 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:19 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:19 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:19 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:19 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:19 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-05 08:46:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:19 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:19 --> Total execution time: 0.0951
INFO - 2023-09-05 08:46:21 --> Config Class Initialized
INFO - 2023-09-05 08:46:21 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:21 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:21 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:21 --> URI Class Initialized
INFO - 2023-09-05 08:46:21 --> Router Class Initialized
INFO - 2023-09-05 08:46:21 --> Output Class Initialized
INFO - 2023-09-05 08:46:21 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:21 --> Input Class Initialized
INFO - 2023-09-05 08:46:21 --> Language Class Initialized
INFO - 2023-09-05 08:46:21 --> Language Class Initialized
INFO - 2023-09-05 08:46:21 --> Config Class Initialized
INFO - 2023-09-05 08:46:21 --> Loader Class Initialized
INFO - 2023-09-05 08:46:21 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:21 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:21 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-05 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:21 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:21 --> Total execution time: 0.0456
INFO - 2023-09-05 08:46:21 --> Config Class Initialized
INFO - 2023-09-05 08:46:21 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:21 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:21 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:21 --> URI Class Initialized
INFO - 2023-09-05 08:46:21 --> Router Class Initialized
INFO - 2023-09-05 08:46:21 --> Output Class Initialized
INFO - 2023-09-05 08:46:21 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:21 --> Input Class Initialized
INFO - 2023-09-05 08:46:21 --> Language Class Initialized
INFO - 2023-09-05 08:46:21 --> Language Class Initialized
INFO - 2023-09-05 08:46:21 --> Config Class Initialized
INFO - 2023-09-05 08:46:21 --> Loader Class Initialized
INFO - 2023-09-05 08:46:21 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:21 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:21 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:21 --> Controller Class Initialized
INFO - 2023-09-05 08:46:25 --> Config Class Initialized
INFO - 2023-09-05 08:46:25 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:25 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:25 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:25 --> URI Class Initialized
INFO - 2023-09-05 08:46:25 --> Router Class Initialized
INFO - 2023-09-05 08:46:25 --> Output Class Initialized
INFO - 2023-09-05 08:46:25 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:25 --> Input Class Initialized
INFO - 2023-09-05 08:46:25 --> Language Class Initialized
INFO - 2023-09-05 08:46:25 --> Language Class Initialized
INFO - 2023-09-05 08:46:25 --> Config Class Initialized
INFO - 2023-09-05 08:46:25 --> Loader Class Initialized
INFO - 2023-09-05 08:46:25 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:25 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:25 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:25 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:25 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:25 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-05 08:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:25 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:25 --> Total execution time: 0.0420
INFO - 2023-09-05 08:46:27 --> Config Class Initialized
INFO - 2023-09-05 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:27 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:27 --> URI Class Initialized
INFO - 2023-09-05 08:46:27 --> Router Class Initialized
INFO - 2023-09-05 08:46:27 --> Output Class Initialized
INFO - 2023-09-05 08:46:27 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:27 --> Input Class Initialized
INFO - 2023-09-05 08:46:27 --> Language Class Initialized
INFO - 2023-09-05 08:46:27 --> Language Class Initialized
INFO - 2023-09-05 08:46:27 --> Config Class Initialized
INFO - 2023-09-05 08:46:27 --> Loader Class Initialized
INFO - 2023-09-05 08:46:27 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:27 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:27 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-05 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:27 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:27 --> Total execution time: 0.0414
INFO - 2023-09-05 08:46:27 --> Config Class Initialized
INFO - 2023-09-05 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:27 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:27 --> URI Class Initialized
INFO - 2023-09-05 08:46:27 --> Router Class Initialized
INFO - 2023-09-05 08:46:27 --> Output Class Initialized
INFO - 2023-09-05 08:46:27 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:27 --> Input Class Initialized
INFO - 2023-09-05 08:46:27 --> Language Class Initialized
INFO - 2023-09-05 08:46:27 --> Language Class Initialized
INFO - 2023-09-05 08:46:27 --> Config Class Initialized
INFO - 2023-09-05 08:46:27 --> Loader Class Initialized
INFO - 2023-09-05 08:46:27 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:27 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:27 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:27 --> Controller Class Initialized
INFO - 2023-09-05 08:46:31 --> Config Class Initialized
INFO - 2023-09-05 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:31 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:31 --> URI Class Initialized
INFO - 2023-09-05 08:46:31 --> Router Class Initialized
INFO - 2023-09-05 08:46:31 --> Output Class Initialized
INFO - 2023-09-05 08:46:31 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:31 --> Input Class Initialized
INFO - 2023-09-05 08:46:31 --> Language Class Initialized
INFO - 2023-09-05 08:46:31 --> Language Class Initialized
INFO - 2023-09-05 08:46:31 --> Config Class Initialized
INFO - 2023-09-05 08:46:31 --> Loader Class Initialized
INFO - 2023-09-05 08:46:31 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:31 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:31 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:31 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:31 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:31 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-05 08:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:31 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:31 --> Total execution time: 0.0312
INFO - 2023-09-05 08:46:32 --> Config Class Initialized
INFO - 2023-09-05 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:32 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:32 --> URI Class Initialized
INFO - 2023-09-05 08:46:32 --> Router Class Initialized
INFO - 2023-09-05 08:46:32 --> Output Class Initialized
INFO - 2023-09-05 08:46:32 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:32 --> Input Class Initialized
INFO - 2023-09-05 08:46:32 --> Language Class Initialized
INFO - 2023-09-05 08:46:32 --> Language Class Initialized
INFO - 2023-09-05 08:46:32 --> Config Class Initialized
INFO - 2023-09-05 08:46:32 --> Loader Class Initialized
INFO - 2023-09-05 08:46:32 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:32 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:32 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-05 08:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:32 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:32 --> Total execution time: 0.0386
INFO - 2023-09-05 08:46:32 --> Config Class Initialized
INFO - 2023-09-05 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:32 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:32 --> URI Class Initialized
INFO - 2023-09-05 08:46:32 --> Router Class Initialized
INFO - 2023-09-05 08:46:32 --> Output Class Initialized
INFO - 2023-09-05 08:46:32 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:32 --> Input Class Initialized
INFO - 2023-09-05 08:46:32 --> Language Class Initialized
INFO - 2023-09-05 08:46:32 --> Language Class Initialized
INFO - 2023-09-05 08:46:32 --> Config Class Initialized
INFO - 2023-09-05 08:46:32 --> Loader Class Initialized
INFO - 2023-09-05 08:46:32 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:32 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:32 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:32 --> Controller Class Initialized
INFO - 2023-09-05 08:46:43 --> Config Class Initialized
INFO - 2023-09-05 08:46:43 --> Hooks Class Initialized
DEBUG - 2023-09-05 08:46:43 --> UTF-8 Support Enabled
INFO - 2023-09-05 08:46:43 --> Utf8 Class Initialized
INFO - 2023-09-05 08:46:43 --> URI Class Initialized
INFO - 2023-09-05 08:46:43 --> Router Class Initialized
INFO - 2023-09-05 08:46:43 --> Output Class Initialized
INFO - 2023-09-05 08:46:43 --> Security Class Initialized
DEBUG - 2023-09-05 08:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-05 08:46:43 --> Input Class Initialized
INFO - 2023-09-05 08:46:43 --> Language Class Initialized
INFO - 2023-09-05 08:46:43 --> Language Class Initialized
INFO - 2023-09-05 08:46:43 --> Config Class Initialized
INFO - 2023-09-05 08:46:43 --> Loader Class Initialized
INFO - 2023-09-05 08:46:43 --> Helper loaded: url_helper
INFO - 2023-09-05 08:46:43 --> Helper loaded: file_helper
INFO - 2023-09-05 08:46:43 --> Helper loaded: form_helper
INFO - 2023-09-05 08:46:43 --> Helper loaded: my_helper
INFO - 2023-09-05 08:46:43 --> Database Driver Class Initialized
INFO - 2023-09-05 08:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-05 08:46:43 --> Controller Class Initialized
DEBUG - 2023-09-05 08:46:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-05 08:46:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-05 08:46:43 --> Final output sent to browser
DEBUG - 2023-09-05 08:46:43 --> Total execution time: 0.0324
