<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-16 03:01:14 --> Config Class Initialized
INFO - 2023-08-16 03:01:14 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:14 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:14 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:14 --> URI Class Initialized
DEBUG - 2023-08-16 03:01:14 --> No URI present. Default controller set.
INFO - 2023-08-16 03:01:14 --> Router Class Initialized
INFO - 2023-08-16 03:01:14 --> Output Class Initialized
INFO - 2023-08-16 03:01:14 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:14 --> Input Class Initialized
INFO - 2023-08-16 03:01:14 --> Language Class Initialized
INFO - 2023-08-16 03:01:14 --> Language Class Initialized
INFO - 2023-08-16 03:01:14 --> Config Class Initialized
INFO - 2023-08-16 03:01:14 --> Loader Class Initialized
INFO - 2023-08-16 03:01:14 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:14 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:14 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:14 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:14 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:15 --> Controller Class Initialized
INFO - 2023-08-16 03:01:15 --> Config Class Initialized
INFO - 2023-08-16 03:01:15 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:15 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:15 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:15 --> URI Class Initialized
INFO - 2023-08-16 03:01:15 --> Router Class Initialized
INFO - 2023-08-16 03:01:15 --> Output Class Initialized
INFO - 2023-08-16 03:01:15 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:15 --> Input Class Initialized
INFO - 2023-08-16 03:01:15 --> Language Class Initialized
INFO - 2023-08-16 03:01:15 --> Language Class Initialized
INFO - 2023-08-16 03:01:15 --> Config Class Initialized
INFO - 2023-08-16 03:01:15 --> Loader Class Initialized
INFO - 2023-08-16 03:01:15 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:15 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:15 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:15 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:15 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:15 --> Controller Class Initialized
DEBUG - 2023-08-16 03:01:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-16 03:01:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-16 03:01:15 --> Final output sent to browser
DEBUG - 2023-08-16 03:01:15 --> Total execution time: 0.0978
INFO - 2023-08-16 03:01:20 --> Config Class Initialized
INFO - 2023-08-16 03:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:20 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:20 --> URI Class Initialized
INFO - 2023-08-16 03:01:20 --> Router Class Initialized
INFO - 2023-08-16 03:01:20 --> Output Class Initialized
INFO - 2023-08-16 03:01:20 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:20 --> Input Class Initialized
INFO - 2023-08-16 03:01:20 --> Language Class Initialized
INFO - 2023-08-16 03:01:20 --> Language Class Initialized
INFO - 2023-08-16 03:01:20 --> Config Class Initialized
INFO - 2023-08-16 03:01:20 --> Loader Class Initialized
INFO - 2023-08-16 03:01:20 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:20 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:20 --> Controller Class Initialized
INFO - 2023-08-16 03:01:20 --> Helper loaded: cookie_helper
INFO - 2023-08-16 03:01:20 --> Final output sent to browser
DEBUG - 2023-08-16 03:01:20 --> Total execution time: 0.0817
INFO - 2023-08-16 03:01:20 --> Config Class Initialized
INFO - 2023-08-16 03:01:20 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:20 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:20 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:20 --> URI Class Initialized
INFO - 2023-08-16 03:01:20 --> Router Class Initialized
INFO - 2023-08-16 03:01:20 --> Output Class Initialized
INFO - 2023-08-16 03:01:20 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:20 --> Input Class Initialized
INFO - 2023-08-16 03:01:20 --> Language Class Initialized
INFO - 2023-08-16 03:01:20 --> Language Class Initialized
INFO - 2023-08-16 03:01:20 --> Config Class Initialized
INFO - 2023-08-16 03:01:20 --> Loader Class Initialized
INFO - 2023-08-16 03:01:20 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:20 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:20 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:20 --> Controller Class Initialized
DEBUG - 2023-08-16 03:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-16 03:01:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-16 03:01:20 --> Final output sent to browser
DEBUG - 2023-08-16 03:01:20 --> Total execution time: 0.0556
INFO - 2023-08-16 03:01:22 --> Config Class Initialized
INFO - 2023-08-16 03:01:22 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:22 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:22 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:22 --> URI Class Initialized
INFO - 2023-08-16 03:01:22 --> Router Class Initialized
INFO - 2023-08-16 03:01:22 --> Output Class Initialized
INFO - 2023-08-16 03:01:22 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:22 --> Input Class Initialized
INFO - 2023-08-16 03:01:22 --> Language Class Initialized
INFO - 2023-08-16 03:01:22 --> Language Class Initialized
INFO - 2023-08-16 03:01:22 --> Config Class Initialized
INFO - 2023-08-16 03:01:22 --> Loader Class Initialized
INFO - 2023-08-16 03:01:22 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:22 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:22 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:22 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:22 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:22 --> Controller Class Initialized
DEBUG - 2023-08-16 03:01:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-16 03:01:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-16 03:01:22 --> Final output sent to browser
DEBUG - 2023-08-16 03:01:22 --> Total execution time: 0.0814
INFO - 2023-08-16 03:01:23 --> Config Class Initialized
INFO - 2023-08-16 03:01:23 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:01:23 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:01:23 --> Utf8 Class Initialized
INFO - 2023-08-16 03:01:23 --> URI Class Initialized
INFO - 2023-08-16 03:01:23 --> Router Class Initialized
INFO - 2023-08-16 03:01:23 --> Output Class Initialized
INFO - 2023-08-16 03:01:23 --> Security Class Initialized
DEBUG - 2023-08-16 03:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:01:23 --> Input Class Initialized
INFO - 2023-08-16 03:01:23 --> Language Class Initialized
INFO - 2023-08-16 03:01:23 --> Language Class Initialized
INFO - 2023-08-16 03:01:23 --> Config Class Initialized
INFO - 2023-08-16 03:01:23 --> Loader Class Initialized
INFO - 2023-08-16 03:01:23 --> Helper loaded: url_helper
INFO - 2023-08-16 03:01:23 --> Helper loaded: file_helper
INFO - 2023-08-16 03:01:23 --> Helper loaded: form_helper
INFO - 2023-08-16 03:01:23 --> Helper loaded: my_helper
INFO - 2023-08-16 03:01:23 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:01:23 --> Controller Class Initialized
DEBUG - 2023-08-16 03:01:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-16 03:01:25 --> Final output sent to browser
DEBUG - 2023-08-16 03:01:25 --> Total execution time: 1.5874
INFO - 2023-08-16 03:44:54 --> Config Class Initialized
INFO - 2023-08-16 03:44:54 --> Hooks Class Initialized
DEBUG - 2023-08-16 03:44:54 --> UTF-8 Support Enabled
INFO - 2023-08-16 03:44:54 --> Utf8 Class Initialized
INFO - 2023-08-16 03:44:54 --> URI Class Initialized
DEBUG - 2023-08-16 03:44:54 --> No URI present. Default controller set.
INFO - 2023-08-16 03:44:54 --> Router Class Initialized
INFO - 2023-08-16 03:44:54 --> Output Class Initialized
INFO - 2023-08-16 03:44:54 --> Security Class Initialized
DEBUG - 2023-08-16 03:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 03:44:54 --> Input Class Initialized
INFO - 2023-08-16 03:44:54 --> Language Class Initialized
INFO - 2023-08-16 03:44:54 --> Language Class Initialized
INFO - 2023-08-16 03:44:54 --> Config Class Initialized
INFO - 2023-08-16 03:44:54 --> Loader Class Initialized
INFO - 2023-08-16 03:44:54 --> Helper loaded: url_helper
INFO - 2023-08-16 03:44:54 --> Helper loaded: file_helper
INFO - 2023-08-16 03:44:54 --> Helper loaded: form_helper
INFO - 2023-08-16 03:44:54 --> Helper loaded: my_helper
INFO - 2023-08-16 03:44:54 --> Database Driver Class Initialized
DEBUG - 2023-08-16 03:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 03:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 03:44:54 --> Controller Class Initialized
DEBUG - 2023-08-16 03:44:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-16 03:44:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-16 03:44:54 --> Final output sent to browser
DEBUG - 2023-08-16 03:44:54 --> Total execution time: 0.0425
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:01:17 --> Utf8 Class Initialized
INFO - 2023-08-16 04:01:17 --> URI Class Initialized
INFO - 2023-08-16 04:01:17 --> Router Class Initialized
INFO - 2023-08-16 04:01:17 --> Output Class Initialized
INFO - 2023-08-16 04:01:17 --> Security Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:01:17 --> Input Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Loader Class Initialized
INFO - 2023-08-16 04:01:17 --> Helper loaded: url_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: file_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: form_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: my_helper
INFO - 2023-08-16 04:01:17 --> Database Driver Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:01:17 --> Controller Class Initialized
INFO - 2023-08-16 04:01:17 --> Helper loaded: cookie_helper
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:01:17 --> Utf8 Class Initialized
INFO - 2023-08-16 04:01:17 --> URI Class Initialized
INFO - 2023-08-16 04:01:17 --> Router Class Initialized
INFO - 2023-08-16 04:01:17 --> Output Class Initialized
INFO - 2023-08-16 04:01:17 --> Security Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:01:17 --> Input Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Loader Class Initialized
INFO - 2023-08-16 04:01:17 --> Helper loaded: url_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: file_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: form_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: my_helper
INFO - 2023-08-16 04:01:17 --> Database Driver Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:01:17 --> Controller Class Initialized
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Hooks Class Initialized
DEBUG - 2023-08-16 04:01:17 --> UTF-8 Support Enabled
INFO - 2023-08-16 04:01:17 --> Utf8 Class Initialized
INFO - 2023-08-16 04:01:17 --> URI Class Initialized
INFO - 2023-08-16 04:01:17 --> Router Class Initialized
INFO - 2023-08-16 04:01:17 --> Output Class Initialized
INFO - 2023-08-16 04:01:17 --> Security Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 04:01:17 --> Input Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Language Class Initialized
INFO - 2023-08-16 04:01:17 --> Config Class Initialized
INFO - 2023-08-16 04:01:17 --> Loader Class Initialized
INFO - 2023-08-16 04:01:17 --> Helper loaded: url_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: file_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: form_helper
INFO - 2023-08-16 04:01:17 --> Helper loaded: my_helper
INFO - 2023-08-16 04:01:17 --> Database Driver Class Initialized
DEBUG - 2023-08-16 04:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 04:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 04:01:17 --> Controller Class Initialized
DEBUG - 2023-08-16 04:01:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-16 04:01:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-16 04:01:17 --> Final output sent to browser
DEBUG - 2023-08-16 04:01:17 --> Total execution time: 0.0235
