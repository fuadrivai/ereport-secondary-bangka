<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-25 08:48:43 --> Config Class Initialized
INFO - 2024-10-25 08:48:43 --> Hooks Class Initialized
DEBUG - 2024-10-25 08:48:43 --> UTF-8 Support Enabled
INFO - 2024-10-25 08:48:43 --> Utf8 Class Initialized
INFO - 2024-10-25 08:48:43 --> URI Class Initialized
INFO - 2024-10-25 08:48:43 --> Router Class Initialized
INFO - 2024-10-25 08:48:43 --> Output Class Initialized
INFO - 2024-10-25 08:48:43 --> Security Class Initialized
DEBUG - 2024-10-25 08:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 08:48:43 --> Input Class Initialized
INFO - 2024-10-25 08:48:43 --> Language Class Initialized
INFO - 2024-10-25 08:48:43 --> Language Class Initialized
INFO - 2024-10-25 08:48:43 --> Config Class Initialized
INFO - 2024-10-25 08:48:43 --> Loader Class Initialized
INFO - 2024-10-25 08:48:43 --> Helper loaded: url_helper
INFO - 2024-10-25 08:48:43 --> Helper loaded: file_helper
INFO - 2024-10-25 08:48:43 --> Helper loaded: form_helper
INFO - 2024-10-25 08:48:43 --> Helper loaded: my_helper
INFO - 2024-10-25 08:48:43 --> Database Driver Class Initialized
INFO - 2024-10-25 08:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 08:48:43 --> Controller Class Initialized
INFO - 2024-10-25 08:48:43 --> Helper loaded: cookie_helper
INFO - 2024-10-25 08:48:43 --> Final output sent to browser
DEBUG - 2024-10-25 08:48:43 --> Total execution time: 0.0675
INFO - 2024-10-25 08:48:44 --> Config Class Initialized
INFO - 2024-10-25 08:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 08:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 08:48:44 --> Utf8 Class Initialized
INFO - 2024-10-25 08:48:44 --> URI Class Initialized
INFO - 2024-10-25 08:48:44 --> Router Class Initialized
INFO - 2024-10-25 08:48:44 --> Output Class Initialized
INFO - 2024-10-25 08:48:44 --> Security Class Initialized
DEBUG - 2024-10-25 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 08:48:44 --> Input Class Initialized
INFO - 2024-10-25 08:48:44 --> Language Class Initialized
INFO - 2024-10-25 08:48:44 --> Language Class Initialized
INFO - 2024-10-25 08:48:44 --> Config Class Initialized
INFO - 2024-10-25 08:48:44 --> Loader Class Initialized
INFO - 2024-10-25 08:48:44 --> Helper loaded: url_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: file_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: form_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: my_helper
INFO - 2024-10-25 08:48:44 --> Database Driver Class Initialized
INFO - 2024-10-25 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 08:48:44 --> Controller Class Initialized
INFO - 2024-10-25 08:48:44 --> Helper loaded: cookie_helper
INFO - 2024-10-25 08:48:44 --> Config Class Initialized
INFO - 2024-10-25 08:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 08:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 08:48:44 --> Utf8 Class Initialized
INFO - 2024-10-25 08:48:44 --> URI Class Initialized
INFO - 2024-10-25 08:48:44 --> Router Class Initialized
INFO - 2024-10-25 08:48:44 --> Output Class Initialized
INFO - 2024-10-25 08:48:44 --> Security Class Initialized
DEBUG - 2024-10-25 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 08:48:44 --> Input Class Initialized
INFO - 2024-10-25 08:48:44 --> Language Class Initialized
INFO - 2024-10-25 08:48:44 --> Language Class Initialized
INFO - 2024-10-25 08:48:44 --> Config Class Initialized
INFO - 2024-10-25 08:48:44 --> Loader Class Initialized
INFO - 2024-10-25 08:48:44 --> Helper loaded: url_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: file_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: form_helper
INFO - 2024-10-25 08:48:44 --> Helper loaded: my_helper
INFO - 2024-10-25 08:48:44 --> Database Driver Class Initialized
INFO - 2024-10-25 08:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 08:48:44 --> Controller Class Initialized
DEBUG - 2024-10-25 08:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-25 08:48:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 08:48:44 --> Final output sent to browser
DEBUG - 2024-10-25 08:48:44 --> Total execution time: 0.0455
INFO - 2024-10-25 08:48:53 --> Config Class Initialized
INFO - 2024-10-25 08:48:53 --> Hooks Class Initialized
DEBUG - 2024-10-25 08:48:53 --> UTF-8 Support Enabled
INFO - 2024-10-25 08:48:53 --> Utf8 Class Initialized
INFO - 2024-10-25 08:48:53 --> URI Class Initialized
INFO - 2024-10-25 08:48:53 --> Router Class Initialized
INFO - 2024-10-25 08:48:53 --> Output Class Initialized
INFO - 2024-10-25 08:48:53 --> Security Class Initialized
DEBUG - 2024-10-25 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 08:48:53 --> Input Class Initialized
INFO - 2024-10-25 08:48:53 --> Language Class Initialized
INFO - 2024-10-25 08:48:53 --> Language Class Initialized
INFO - 2024-10-25 08:48:53 --> Config Class Initialized
INFO - 2024-10-25 08:48:53 --> Loader Class Initialized
INFO - 2024-10-25 08:48:53 --> Helper loaded: url_helper
INFO - 2024-10-25 08:48:53 --> Helper loaded: file_helper
INFO - 2024-10-25 08:48:53 --> Helper loaded: form_helper
INFO - 2024-10-25 08:48:53 --> Helper loaded: my_helper
INFO - 2024-10-25 08:48:53 --> Database Driver Class Initialized
INFO - 2024-10-25 08:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 08:48:53 --> Controller Class Initialized
DEBUG - 2024-10-25 08:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 08:48:55 --> Final output sent to browser
DEBUG - 2024-10-25 08:48:55 --> Total execution time: 2.8818
INFO - 2024-10-25 09:08:46 --> Config Class Initialized
INFO - 2024-10-25 09:08:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 09:08:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 09:08:46 --> Utf8 Class Initialized
INFO - 2024-10-25 09:08:46 --> URI Class Initialized
INFO - 2024-10-25 09:08:46 --> Router Class Initialized
INFO - 2024-10-25 09:08:46 --> Output Class Initialized
INFO - 2024-10-25 09:08:46 --> Security Class Initialized
DEBUG - 2024-10-25 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 09:08:46 --> Input Class Initialized
INFO - 2024-10-25 09:08:46 --> Language Class Initialized
INFO - 2024-10-25 09:08:46 --> Language Class Initialized
INFO - 2024-10-25 09:08:46 --> Config Class Initialized
INFO - 2024-10-25 09:08:46 --> Loader Class Initialized
INFO - 2024-10-25 09:08:46 --> Helper loaded: url_helper
INFO - 2024-10-25 09:08:46 --> Helper loaded: file_helper
INFO - 2024-10-25 09:08:46 --> Helper loaded: form_helper
INFO - 2024-10-25 09:08:46 --> Helper loaded: my_helper
INFO - 2024-10-25 09:08:46 --> Database Driver Class Initialized
INFO - 2024-10-25 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 09:08:46 --> Controller Class Initialized
ERROR - 2024-10-25 09:08:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2392
DEBUG - 2024-10-25 09:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-25 09:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 09:08:46 --> Final output sent to browser
DEBUG - 2024-10-25 09:08:46 --> Total execution time: 0.0388
INFO - 2024-10-25 10:14:47 --> Config Class Initialized
INFO - 2024-10-25 10:14:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:14:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:14:47 --> Utf8 Class Initialized
INFO - 2024-10-25 10:14:47 --> URI Class Initialized
INFO - 2024-10-25 10:14:47 --> Router Class Initialized
INFO - 2024-10-25 10:14:47 --> Output Class Initialized
INFO - 2024-10-25 10:14:47 --> Security Class Initialized
DEBUG - 2024-10-25 10:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:14:47 --> Input Class Initialized
INFO - 2024-10-25 10:14:47 --> Language Class Initialized
INFO - 2024-10-25 10:14:47 --> Language Class Initialized
INFO - 2024-10-25 10:14:47 --> Config Class Initialized
INFO - 2024-10-25 10:14:47 --> Loader Class Initialized
INFO - 2024-10-25 10:14:47 --> Helper loaded: url_helper
INFO - 2024-10-25 10:14:47 --> Helper loaded: file_helper
INFO - 2024-10-25 10:14:47 --> Helper loaded: form_helper
INFO - 2024-10-25 10:14:47 --> Helper loaded: my_helper
INFO - 2024-10-25 10:14:47 --> Database Driver Class Initialized
INFO - 2024-10-25 10:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:14:47 --> Controller Class Initialized
DEBUG - 2024-10-25 10:14:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-25 10:14:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 10:14:47 --> Final output sent to browser
DEBUG - 2024-10-25 10:14:47 --> Total execution time: 0.0517
INFO - 2024-10-25 10:14:56 --> Config Class Initialized
INFO - 2024-10-25 10:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:14:56 --> Utf8 Class Initialized
INFO - 2024-10-25 10:14:56 --> URI Class Initialized
INFO - 2024-10-25 10:14:56 --> Router Class Initialized
INFO - 2024-10-25 10:14:56 --> Output Class Initialized
INFO - 2024-10-25 10:14:56 --> Security Class Initialized
DEBUG - 2024-10-25 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:14:56 --> Input Class Initialized
INFO - 2024-10-25 10:14:56 --> Language Class Initialized
INFO - 2024-10-25 10:14:56 --> Language Class Initialized
INFO - 2024-10-25 10:14:56 --> Config Class Initialized
INFO - 2024-10-25 10:14:56 --> Loader Class Initialized
INFO - 2024-10-25 10:14:56 --> Helper loaded: url_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: file_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: form_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: my_helper
INFO - 2024-10-25 10:14:56 --> Database Driver Class Initialized
INFO - 2024-10-25 10:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:14:56 --> Controller Class Initialized
INFO - 2024-10-25 10:14:56 --> Helper loaded: cookie_helper
INFO - 2024-10-25 10:14:56 --> Final output sent to browser
DEBUG - 2024-10-25 10:14:56 --> Total execution time: 0.0423
INFO - 2024-10-25 10:14:56 --> Config Class Initialized
INFO - 2024-10-25 10:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:14:56 --> Utf8 Class Initialized
INFO - 2024-10-25 10:14:56 --> URI Class Initialized
INFO - 2024-10-25 10:14:56 --> Router Class Initialized
INFO - 2024-10-25 10:14:56 --> Output Class Initialized
INFO - 2024-10-25 10:14:56 --> Security Class Initialized
DEBUG - 2024-10-25 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:14:56 --> Input Class Initialized
INFO - 2024-10-25 10:14:56 --> Language Class Initialized
INFO - 2024-10-25 10:14:56 --> Language Class Initialized
INFO - 2024-10-25 10:14:56 --> Config Class Initialized
INFO - 2024-10-25 10:14:56 --> Loader Class Initialized
INFO - 2024-10-25 10:14:56 --> Helper loaded: url_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: file_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: form_helper
INFO - 2024-10-25 10:14:56 --> Helper loaded: my_helper
INFO - 2024-10-25 10:14:56 --> Database Driver Class Initialized
INFO - 2024-10-25 10:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:14:56 --> Controller Class Initialized
DEBUG - 2024-10-25 10:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-25 10:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 10:14:56 --> Final output sent to browser
DEBUG - 2024-10-25 10:14:56 --> Total execution time: 0.0320
INFO - 2024-10-25 10:15:02 --> Config Class Initialized
INFO - 2024-10-25 10:15:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:15:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:15:02 --> Utf8 Class Initialized
INFO - 2024-10-25 10:15:02 --> URI Class Initialized
INFO - 2024-10-25 10:15:02 --> Router Class Initialized
INFO - 2024-10-25 10:15:02 --> Output Class Initialized
INFO - 2024-10-25 10:15:02 --> Security Class Initialized
DEBUG - 2024-10-25 10:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:15:02 --> Input Class Initialized
INFO - 2024-10-25 10:15:02 --> Language Class Initialized
INFO - 2024-10-25 10:15:02 --> Language Class Initialized
INFO - 2024-10-25 10:15:02 --> Config Class Initialized
INFO - 2024-10-25 10:15:02 --> Loader Class Initialized
INFO - 2024-10-25 10:15:02 --> Helper loaded: url_helper
INFO - 2024-10-25 10:15:02 --> Helper loaded: file_helper
INFO - 2024-10-25 10:15:02 --> Helper loaded: form_helper
INFO - 2024-10-25 10:15:02 --> Helper loaded: my_helper
INFO - 2024-10-25 10:15:02 --> Database Driver Class Initialized
INFO - 2024-10-25 10:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:15:02 --> Controller Class Initialized
DEBUG - 2024-10-25 10:15:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-25 10:15:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 10:15:02 --> Final output sent to browser
DEBUG - 2024-10-25 10:15:02 --> Total execution time: 0.0443
INFO - 2024-10-25 10:15:05 --> Config Class Initialized
INFO - 2024-10-25 10:15:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:15:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:15:05 --> Utf8 Class Initialized
INFO - 2024-10-25 10:15:05 --> URI Class Initialized
INFO - 2024-10-25 10:15:05 --> Router Class Initialized
INFO - 2024-10-25 10:15:05 --> Output Class Initialized
INFO - 2024-10-25 10:15:05 --> Security Class Initialized
DEBUG - 2024-10-25 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:15:05 --> Input Class Initialized
INFO - 2024-10-25 10:15:05 --> Language Class Initialized
INFO - 2024-10-25 10:15:05 --> Language Class Initialized
INFO - 2024-10-25 10:15:05 --> Config Class Initialized
INFO - 2024-10-25 10:15:05 --> Loader Class Initialized
INFO - 2024-10-25 10:15:05 --> Helper loaded: url_helper
INFO - 2024-10-25 10:15:05 --> Helper loaded: file_helper
INFO - 2024-10-25 10:15:05 --> Helper loaded: form_helper
INFO - 2024-10-25 10:15:05 --> Helper loaded: my_helper
INFO - 2024-10-25 10:15:05 --> Database Driver Class Initialized
INFO - 2024-10-25 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:15:05 --> Controller Class Initialized
DEBUG - 2024-10-25 10:15:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:15:08 --> Final output sent to browser
DEBUG - 2024-10-25 10:15:08 --> Total execution time: 3.3857
INFO - 2024-10-25 10:16:57 --> Config Class Initialized
INFO - 2024-10-25 10:16:57 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:16:57 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:16:57 --> Utf8 Class Initialized
INFO - 2024-10-25 10:16:57 --> URI Class Initialized
INFO - 2024-10-25 10:16:57 --> Router Class Initialized
INFO - 2024-10-25 10:16:57 --> Output Class Initialized
INFO - 2024-10-25 10:16:57 --> Security Class Initialized
DEBUG - 2024-10-25 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:16:57 --> Input Class Initialized
INFO - 2024-10-25 10:16:57 --> Language Class Initialized
INFO - 2024-10-25 10:16:57 --> Language Class Initialized
INFO - 2024-10-25 10:16:57 --> Config Class Initialized
INFO - 2024-10-25 10:16:57 --> Loader Class Initialized
INFO - 2024-10-25 10:16:57 --> Helper loaded: url_helper
INFO - 2024-10-25 10:16:57 --> Helper loaded: file_helper
INFO - 2024-10-25 10:16:57 --> Helper loaded: form_helper
INFO - 2024-10-25 10:16:57 --> Helper loaded: my_helper
INFO - 2024-10-25 10:16:57 --> Database Driver Class Initialized
INFO - 2024-10-25 10:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:16:57 --> Controller Class Initialized
DEBUG - 2024-10-25 10:16:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:17:00 --> Final output sent to browser
DEBUG - 2024-10-25 10:17:00 --> Total execution time: 3.2784
INFO - 2024-10-25 10:19:18 --> Config Class Initialized
INFO - 2024-10-25 10:19:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:19:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:19:18 --> Utf8 Class Initialized
INFO - 2024-10-25 10:19:18 --> URI Class Initialized
INFO - 2024-10-25 10:19:18 --> Router Class Initialized
INFO - 2024-10-25 10:19:18 --> Output Class Initialized
INFO - 2024-10-25 10:19:18 --> Security Class Initialized
DEBUG - 2024-10-25 10:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:19:18 --> Input Class Initialized
INFO - 2024-10-25 10:19:18 --> Language Class Initialized
INFO - 2024-10-25 10:19:18 --> Language Class Initialized
INFO - 2024-10-25 10:19:18 --> Config Class Initialized
INFO - 2024-10-25 10:19:18 --> Loader Class Initialized
INFO - 2024-10-25 10:19:18 --> Helper loaded: url_helper
INFO - 2024-10-25 10:19:18 --> Helper loaded: file_helper
INFO - 2024-10-25 10:19:18 --> Helper loaded: form_helper
INFO - 2024-10-25 10:19:18 --> Helper loaded: my_helper
INFO - 2024-10-25 10:19:18 --> Database Driver Class Initialized
INFO - 2024-10-25 10:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:19:18 --> Controller Class Initialized
DEBUG - 2024-10-25 10:19:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:19:21 --> Final output sent to browser
DEBUG - 2024-10-25 10:19:21 --> Total execution time: 3.3842
INFO - 2024-10-25 10:20:01 --> Config Class Initialized
INFO - 2024-10-25 10:20:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:20:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:20:01 --> Utf8 Class Initialized
INFO - 2024-10-25 10:20:01 --> URI Class Initialized
INFO - 2024-10-25 10:20:01 --> Router Class Initialized
INFO - 2024-10-25 10:20:01 --> Output Class Initialized
INFO - 2024-10-25 10:20:01 --> Security Class Initialized
DEBUG - 2024-10-25 10:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:20:01 --> Input Class Initialized
INFO - 2024-10-25 10:20:01 --> Language Class Initialized
INFO - 2024-10-25 10:20:01 --> Language Class Initialized
INFO - 2024-10-25 10:20:01 --> Config Class Initialized
INFO - 2024-10-25 10:20:01 --> Loader Class Initialized
INFO - 2024-10-25 10:20:01 --> Helper loaded: url_helper
INFO - 2024-10-25 10:20:01 --> Helper loaded: file_helper
INFO - 2024-10-25 10:20:01 --> Helper loaded: form_helper
INFO - 2024-10-25 10:20:01 --> Helper loaded: my_helper
INFO - 2024-10-25 10:20:01 --> Database Driver Class Initialized
INFO - 2024-10-25 10:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:20:01 --> Controller Class Initialized
DEBUG - 2024-10-25 10:20:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:20:05 --> Final output sent to browser
DEBUG - 2024-10-25 10:20:05 --> Total execution time: 4.5684
INFO - 2024-10-25 10:24:44 --> Config Class Initialized
INFO - 2024-10-25 10:24:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:24:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:24:44 --> Utf8 Class Initialized
INFO - 2024-10-25 10:24:44 --> URI Class Initialized
INFO - 2024-10-25 10:24:44 --> Router Class Initialized
INFO - 2024-10-25 10:24:44 --> Output Class Initialized
INFO - 2024-10-25 10:24:44 --> Security Class Initialized
DEBUG - 2024-10-25 10:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:24:44 --> Input Class Initialized
INFO - 2024-10-25 10:24:44 --> Language Class Initialized
INFO - 2024-10-25 10:24:44 --> Language Class Initialized
INFO - 2024-10-25 10:24:44 --> Config Class Initialized
INFO - 2024-10-25 10:24:44 --> Loader Class Initialized
INFO - 2024-10-25 10:24:44 --> Helper loaded: url_helper
INFO - 2024-10-25 10:24:44 --> Helper loaded: file_helper
INFO - 2024-10-25 10:24:44 --> Helper loaded: form_helper
INFO - 2024-10-25 10:24:44 --> Helper loaded: my_helper
INFO - 2024-10-25 10:24:44 --> Database Driver Class Initialized
INFO - 2024-10-25 10:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:24:44 --> Controller Class Initialized
DEBUG - 2024-10-25 10:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:24:47 --> Final output sent to browser
DEBUG - 2024-10-25 10:24:47 --> Total execution time: 2.8109
INFO - 2024-10-25 10:25:12 --> Config Class Initialized
INFO - 2024-10-25 10:25:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:25:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:25:12 --> Utf8 Class Initialized
INFO - 2024-10-25 10:25:12 --> URI Class Initialized
INFO - 2024-10-25 10:25:12 --> Router Class Initialized
INFO - 2024-10-25 10:25:12 --> Output Class Initialized
INFO - 2024-10-25 10:25:12 --> Security Class Initialized
DEBUG - 2024-10-25 10:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:25:12 --> Input Class Initialized
INFO - 2024-10-25 10:25:12 --> Language Class Initialized
INFO - 2024-10-25 10:25:12 --> Language Class Initialized
INFO - 2024-10-25 10:25:12 --> Config Class Initialized
INFO - 2024-10-25 10:25:12 --> Loader Class Initialized
INFO - 2024-10-25 10:25:12 --> Helper loaded: url_helper
INFO - 2024-10-25 10:25:12 --> Helper loaded: file_helper
INFO - 2024-10-25 10:25:12 --> Helper loaded: form_helper
INFO - 2024-10-25 10:25:12 --> Helper loaded: my_helper
INFO - 2024-10-25 10:25:12 --> Database Driver Class Initialized
INFO - 2024-10-25 10:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:25:12 --> Controller Class Initialized
DEBUG - 2024-10-25 10:25:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:25:15 --> Final output sent to browser
DEBUG - 2024-10-25 10:25:15 --> Total execution time: 2.8365
INFO - 2024-10-25 10:28:27 --> Config Class Initialized
INFO - 2024-10-25 10:28:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:28:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:28:27 --> Utf8 Class Initialized
INFO - 2024-10-25 10:28:27 --> URI Class Initialized
INFO - 2024-10-25 10:28:27 --> Router Class Initialized
INFO - 2024-10-25 10:28:27 --> Output Class Initialized
INFO - 2024-10-25 10:28:27 --> Security Class Initialized
DEBUG - 2024-10-25 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:28:27 --> Input Class Initialized
INFO - 2024-10-25 10:28:27 --> Language Class Initialized
INFO - 2024-10-25 10:28:27 --> Language Class Initialized
INFO - 2024-10-25 10:28:27 --> Config Class Initialized
INFO - 2024-10-25 10:28:27 --> Loader Class Initialized
INFO - 2024-10-25 10:28:27 --> Helper loaded: url_helper
INFO - 2024-10-25 10:28:27 --> Helper loaded: file_helper
INFO - 2024-10-25 10:28:27 --> Helper loaded: form_helper
INFO - 2024-10-25 10:28:27 --> Helper loaded: my_helper
INFO - 2024-10-25 10:28:27 --> Database Driver Class Initialized
INFO - 2024-10-25 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:28:27 --> Controller Class Initialized
DEBUG - 2024-10-25 10:28:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:28:31 --> Final output sent to browser
DEBUG - 2024-10-25 10:28:31 --> Total execution time: 3.1540
INFO - 2024-10-25 10:28:51 --> Config Class Initialized
INFO - 2024-10-25 10:28:51 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:28:51 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:28:51 --> Utf8 Class Initialized
INFO - 2024-10-25 10:28:51 --> URI Class Initialized
INFO - 2024-10-25 10:28:51 --> Router Class Initialized
INFO - 2024-10-25 10:28:51 --> Output Class Initialized
INFO - 2024-10-25 10:28:51 --> Security Class Initialized
DEBUG - 2024-10-25 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:28:51 --> Input Class Initialized
INFO - 2024-10-25 10:28:51 --> Language Class Initialized
INFO - 2024-10-25 10:28:51 --> Language Class Initialized
INFO - 2024-10-25 10:28:51 --> Config Class Initialized
INFO - 2024-10-25 10:28:51 --> Loader Class Initialized
INFO - 2024-10-25 10:28:51 --> Helper loaded: url_helper
INFO - 2024-10-25 10:28:51 --> Helper loaded: file_helper
INFO - 2024-10-25 10:28:51 --> Helper loaded: form_helper
INFO - 2024-10-25 10:28:51 --> Helper loaded: my_helper
INFO - 2024-10-25 10:28:51 --> Database Driver Class Initialized
INFO - 2024-10-25 10:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:28:51 --> Controller Class Initialized
DEBUG - 2024-10-25 10:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:28:54 --> Final output sent to browser
DEBUG - 2024-10-25 10:28:54 --> Total execution time: 3.1762
INFO - 2024-10-25 10:31:58 --> Config Class Initialized
INFO - 2024-10-25 10:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:31:58 --> Utf8 Class Initialized
INFO - 2024-10-25 10:31:58 --> URI Class Initialized
INFO - 2024-10-25 10:31:58 --> Router Class Initialized
INFO - 2024-10-25 10:31:58 --> Output Class Initialized
INFO - 2024-10-25 10:31:58 --> Security Class Initialized
DEBUG - 2024-10-25 10:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:31:58 --> Input Class Initialized
INFO - 2024-10-25 10:31:58 --> Language Class Initialized
INFO - 2024-10-25 10:31:58 --> Language Class Initialized
INFO - 2024-10-25 10:31:58 --> Config Class Initialized
INFO - 2024-10-25 10:31:58 --> Loader Class Initialized
INFO - 2024-10-25 10:31:58 --> Helper loaded: url_helper
INFO - 2024-10-25 10:31:58 --> Helper loaded: file_helper
INFO - 2024-10-25 10:31:58 --> Helper loaded: form_helper
INFO - 2024-10-25 10:31:58 --> Helper loaded: my_helper
INFO - 2024-10-25 10:31:58 --> Database Driver Class Initialized
INFO - 2024-10-25 10:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:31:58 --> Controller Class Initialized
DEBUG - 2024-10-25 10:31:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:32:01 --> Final output sent to browser
DEBUG - 2024-10-25 10:32:01 --> Total execution time: 2.9247
INFO - 2024-10-25 10:32:19 --> Config Class Initialized
INFO - 2024-10-25 10:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:32:19 --> Utf8 Class Initialized
INFO - 2024-10-25 10:32:19 --> URI Class Initialized
INFO - 2024-10-25 10:32:19 --> Router Class Initialized
INFO - 2024-10-25 10:32:19 --> Output Class Initialized
INFO - 2024-10-25 10:32:19 --> Security Class Initialized
DEBUG - 2024-10-25 10:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:32:19 --> Input Class Initialized
INFO - 2024-10-25 10:32:19 --> Language Class Initialized
INFO - 2024-10-25 10:32:19 --> Language Class Initialized
INFO - 2024-10-25 10:32:19 --> Config Class Initialized
INFO - 2024-10-25 10:32:19 --> Loader Class Initialized
INFO - 2024-10-25 10:32:19 --> Helper loaded: url_helper
INFO - 2024-10-25 10:32:19 --> Helper loaded: file_helper
INFO - 2024-10-25 10:32:19 --> Helper loaded: form_helper
INFO - 2024-10-25 10:32:19 --> Helper loaded: my_helper
INFO - 2024-10-25 10:32:19 --> Database Driver Class Initialized
INFO - 2024-10-25 10:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:32:19 --> Controller Class Initialized
DEBUG - 2024-10-25 10:32:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:32:22 --> Final output sent to browser
DEBUG - 2024-10-25 10:32:22 --> Total execution time: 2.9134
INFO - 2024-10-25 10:32:47 --> Config Class Initialized
INFO - 2024-10-25 10:32:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:32:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:32:47 --> Utf8 Class Initialized
INFO - 2024-10-25 10:32:47 --> URI Class Initialized
INFO - 2024-10-25 10:32:47 --> Router Class Initialized
INFO - 2024-10-25 10:32:47 --> Output Class Initialized
INFO - 2024-10-25 10:32:47 --> Security Class Initialized
DEBUG - 2024-10-25 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:32:47 --> Input Class Initialized
INFO - 2024-10-25 10:32:47 --> Language Class Initialized
INFO - 2024-10-25 10:32:47 --> Language Class Initialized
INFO - 2024-10-25 10:32:47 --> Config Class Initialized
INFO - 2024-10-25 10:32:47 --> Loader Class Initialized
INFO - 2024-10-25 10:32:47 --> Helper loaded: url_helper
INFO - 2024-10-25 10:32:47 --> Helper loaded: file_helper
INFO - 2024-10-25 10:32:47 --> Helper loaded: form_helper
INFO - 2024-10-25 10:32:47 --> Helper loaded: my_helper
INFO - 2024-10-25 10:32:47 --> Database Driver Class Initialized
INFO - 2024-10-25 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:32:47 --> Controller Class Initialized
DEBUG - 2024-10-25 10:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:32:50 --> Final output sent to browser
DEBUG - 2024-10-25 10:32:50 --> Total execution time: 2.9155
INFO - 2024-10-25 10:36:33 --> Config Class Initialized
INFO - 2024-10-25 10:36:33 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:36:33 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:36:33 --> Utf8 Class Initialized
INFO - 2024-10-25 10:36:33 --> URI Class Initialized
INFO - 2024-10-25 10:36:33 --> Router Class Initialized
INFO - 2024-10-25 10:36:33 --> Output Class Initialized
INFO - 2024-10-25 10:36:33 --> Security Class Initialized
DEBUG - 2024-10-25 10:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:36:33 --> Input Class Initialized
INFO - 2024-10-25 10:36:33 --> Language Class Initialized
INFO - 2024-10-25 10:36:33 --> Language Class Initialized
INFO - 2024-10-25 10:36:33 --> Config Class Initialized
INFO - 2024-10-25 10:36:33 --> Loader Class Initialized
INFO - 2024-10-25 10:36:33 --> Helper loaded: url_helper
INFO - 2024-10-25 10:36:33 --> Helper loaded: file_helper
INFO - 2024-10-25 10:36:33 --> Helper loaded: form_helper
INFO - 2024-10-25 10:36:33 --> Helper loaded: my_helper
INFO - 2024-10-25 10:36:33 --> Database Driver Class Initialized
INFO - 2024-10-25 10:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:36:33 --> Controller Class Initialized
DEBUG - 2024-10-25 10:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:36:36 --> Final output sent to browser
DEBUG - 2024-10-25 10:36:36 --> Total execution time: 2.8248
INFO - 2024-10-25 10:36:51 --> Config Class Initialized
INFO - 2024-10-25 10:36:51 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:36:51 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:36:51 --> Utf8 Class Initialized
INFO - 2024-10-25 10:36:51 --> URI Class Initialized
INFO - 2024-10-25 10:36:51 --> Router Class Initialized
INFO - 2024-10-25 10:36:51 --> Output Class Initialized
INFO - 2024-10-25 10:36:51 --> Security Class Initialized
DEBUG - 2024-10-25 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:36:51 --> Input Class Initialized
INFO - 2024-10-25 10:36:51 --> Language Class Initialized
INFO - 2024-10-25 10:36:51 --> Language Class Initialized
INFO - 2024-10-25 10:36:51 --> Config Class Initialized
INFO - 2024-10-25 10:36:51 --> Loader Class Initialized
INFO - 2024-10-25 10:36:51 --> Helper loaded: url_helper
INFO - 2024-10-25 10:36:51 --> Helper loaded: file_helper
INFO - 2024-10-25 10:36:51 --> Helper loaded: form_helper
INFO - 2024-10-25 10:36:51 --> Helper loaded: my_helper
INFO - 2024-10-25 10:36:51 --> Database Driver Class Initialized
INFO - 2024-10-25 10:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:36:51 --> Controller Class Initialized
DEBUG - 2024-10-25 10:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:36:54 --> Final output sent to browser
DEBUG - 2024-10-25 10:36:54 --> Total execution time: 2.7409
INFO - 2024-10-25 10:37:07 --> Config Class Initialized
INFO - 2024-10-25 10:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:37:07 --> Utf8 Class Initialized
INFO - 2024-10-25 10:37:07 --> URI Class Initialized
INFO - 2024-10-25 10:37:07 --> Router Class Initialized
INFO - 2024-10-25 10:37:07 --> Output Class Initialized
INFO - 2024-10-25 10:37:07 --> Security Class Initialized
DEBUG - 2024-10-25 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:37:07 --> Input Class Initialized
INFO - 2024-10-25 10:37:07 --> Language Class Initialized
INFO - 2024-10-25 10:37:07 --> Language Class Initialized
INFO - 2024-10-25 10:37:07 --> Config Class Initialized
INFO - 2024-10-25 10:37:07 --> Loader Class Initialized
INFO - 2024-10-25 10:37:07 --> Helper loaded: url_helper
INFO - 2024-10-25 10:37:07 --> Helper loaded: file_helper
INFO - 2024-10-25 10:37:07 --> Helper loaded: form_helper
INFO - 2024-10-25 10:37:07 --> Helper loaded: my_helper
INFO - 2024-10-25 10:37:07 --> Database Driver Class Initialized
INFO - 2024-10-25 10:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:37:07 --> Controller Class Initialized
DEBUG - 2024-10-25 10:37:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:37:10 --> Final output sent to browser
DEBUG - 2024-10-25 10:37:10 --> Total execution time: 3.0264
INFO - 2024-10-25 10:38:34 --> Config Class Initialized
INFO - 2024-10-25 10:38:34 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:38:34 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:38:34 --> Utf8 Class Initialized
INFO - 2024-10-25 10:38:34 --> URI Class Initialized
INFO - 2024-10-25 10:38:34 --> Router Class Initialized
INFO - 2024-10-25 10:38:34 --> Output Class Initialized
INFO - 2024-10-25 10:38:34 --> Security Class Initialized
DEBUG - 2024-10-25 10:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:38:34 --> Input Class Initialized
INFO - 2024-10-25 10:38:34 --> Language Class Initialized
INFO - 2024-10-25 10:38:34 --> Language Class Initialized
INFO - 2024-10-25 10:38:34 --> Config Class Initialized
INFO - 2024-10-25 10:38:34 --> Loader Class Initialized
INFO - 2024-10-25 10:38:34 --> Helper loaded: url_helper
INFO - 2024-10-25 10:38:34 --> Helper loaded: file_helper
INFO - 2024-10-25 10:38:34 --> Helper loaded: form_helper
INFO - 2024-10-25 10:38:34 --> Helper loaded: my_helper
INFO - 2024-10-25 10:38:34 --> Database Driver Class Initialized
INFO - 2024-10-25 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:38:34 --> Controller Class Initialized
DEBUG - 2024-10-25 10:38:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:38:37 --> Final output sent to browser
DEBUG - 2024-10-25 10:38:37 --> Total execution time: 3.0379
INFO - 2024-10-25 10:49:56 --> Config Class Initialized
INFO - 2024-10-25 10:49:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:49:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:49:56 --> Utf8 Class Initialized
INFO - 2024-10-25 10:49:56 --> URI Class Initialized
INFO - 2024-10-25 10:49:56 --> Router Class Initialized
INFO - 2024-10-25 10:49:56 --> Output Class Initialized
INFO - 2024-10-25 10:49:56 --> Security Class Initialized
DEBUG - 2024-10-25 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:49:56 --> Input Class Initialized
INFO - 2024-10-25 10:49:56 --> Language Class Initialized
INFO - 2024-10-25 10:49:56 --> Language Class Initialized
INFO - 2024-10-25 10:49:56 --> Config Class Initialized
INFO - 2024-10-25 10:49:56 --> Loader Class Initialized
INFO - 2024-10-25 10:49:56 --> Helper loaded: url_helper
INFO - 2024-10-25 10:49:56 --> Helper loaded: file_helper
INFO - 2024-10-25 10:49:56 --> Helper loaded: form_helper
INFO - 2024-10-25 10:49:56 --> Helper loaded: my_helper
INFO - 2024-10-25 10:49:56 --> Database Driver Class Initialized
INFO - 2024-10-25 10:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:49:56 --> Controller Class Initialized
DEBUG - 2024-10-25 10:49:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:49:59 --> Final output sent to browser
DEBUG - 2024-10-25 10:49:59 --> Total execution time: 2.9049
INFO - 2024-10-25 10:50:15 --> Config Class Initialized
INFO - 2024-10-25 10:50:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:50:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:50:15 --> Utf8 Class Initialized
INFO - 2024-10-25 10:50:15 --> URI Class Initialized
INFO - 2024-10-25 10:50:15 --> Router Class Initialized
INFO - 2024-10-25 10:50:15 --> Output Class Initialized
INFO - 2024-10-25 10:50:15 --> Security Class Initialized
DEBUG - 2024-10-25 10:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:50:15 --> Input Class Initialized
INFO - 2024-10-25 10:50:15 --> Language Class Initialized
INFO - 2024-10-25 10:50:15 --> Language Class Initialized
INFO - 2024-10-25 10:50:15 --> Config Class Initialized
INFO - 2024-10-25 10:50:15 --> Loader Class Initialized
INFO - 2024-10-25 10:50:15 --> Helper loaded: url_helper
INFO - 2024-10-25 10:50:15 --> Helper loaded: file_helper
INFO - 2024-10-25 10:50:15 --> Helper loaded: form_helper
INFO - 2024-10-25 10:50:15 --> Helper loaded: my_helper
INFO - 2024-10-25 10:50:15 --> Database Driver Class Initialized
INFO - 2024-10-25 10:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:50:15 --> Controller Class Initialized
DEBUG - 2024-10-25 10:50:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:50:18 --> Final output sent to browser
DEBUG - 2024-10-25 10:50:18 --> Total execution time: 2.9856
INFO - 2024-10-25 10:50:39 --> Config Class Initialized
INFO - 2024-10-25 10:50:39 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:50:39 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:50:39 --> Utf8 Class Initialized
INFO - 2024-10-25 10:50:39 --> URI Class Initialized
INFO - 2024-10-25 10:50:39 --> Router Class Initialized
INFO - 2024-10-25 10:50:39 --> Output Class Initialized
INFO - 2024-10-25 10:50:39 --> Security Class Initialized
DEBUG - 2024-10-25 10:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:50:39 --> Input Class Initialized
INFO - 2024-10-25 10:50:39 --> Language Class Initialized
INFO - 2024-10-25 10:50:39 --> Language Class Initialized
INFO - 2024-10-25 10:50:39 --> Config Class Initialized
INFO - 2024-10-25 10:50:39 --> Loader Class Initialized
INFO - 2024-10-25 10:50:39 --> Helper loaded: url_helper
INFO - 2024-10-25 10:50:39 --> Helper loaded: file_helper
INFO - 2024-10-25 10:50:39 --> Helper loaded: form_helper
INFO - 2024-10-25 10:50:39 --> Helper loaded: my_helper
INFO - 2024-10-25 10:50:39 --> Database Driver Class Initialized
INFO - 2024-10-25 10:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:50:39 --> Controller Class Initialized
DEBUG - 2024-10-25 10:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:50:43 --> Final output sent to browser
DEBUG - 2024-10-25 10:50:43 --> Total execution time: 3.2449
INFO - 2024-10-25 10:51:35 --> Config Class Initialized
INFO - 2024-10-25 10:51:35 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:51:35 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:51:35 --> Utf8 Class Initialized
INFO - 2024-10-25 10:51:35 --> URI Class Initialized
INFO - 2024-10-25 10:51:35 --> Router Class Initialized
INFO - 2024-10-25 10:51:35 --> Output Class Initialized
INFO - 2024-10-25 10:51:35 --> Security Class Initialized
DEBUG - 2024-10-25 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:51:35 --> Input Class Initialized
INFO - 2024-10-25 10:51:35 --> Language Class Initialized
INFO - 2024-10-25 10:51:35 --> Language Class Initialized
INFO - 2024-10-25 10:51:35 --> Config Class Initialized
INFO - 2024-10-25 10:51:35 --> Loader Class Initialized
INFO - 2024-10-25 10:51:35 --> Helper loaded: url_helper
INFO - 2024-10-25 10:51:35 --> Helper loaded: file_helper
INFO - 2024-10-25 10:51:35 --> Helper loaded: form_helper
INFO - 2024-10-25 10:51:35 --> Helper loaded: my_helper
INFO - 2024-10-25 10:51:35 --> Database Driver Class Initialized
INFO - 2024-10-25 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:51:35 --> Controller Class Initialized
DEBUG - 2024-10-25 10:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:51:38 --> Final output sent to browser
DEBUG - 2024-10-25 10:51:38 --> Total execution time: 3.0620
INFO - 2024-10-25 10:53:54 --> Config Class Initialized
INFO - 2024-10-25 10:53:54 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:53:54 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:53:54 --> Utf8 Class Initialized
INFO - 2024-10-25 10:53:54 --> URI Class Initialized
INFO - 2024-10-25 10:53:54 --> Router Class Initialized
INFO - 2024-10-25 10:53:54 --> Output Class Initialized
INFO - 2024-10-25 10:53:54 --> Security Class Initialized
DEBUG - 2024-10-25 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:53:54 --> Input Class Initialized
INFO - 2024-10-25 10:53:54 --> Language Class Initialized
INFO - 2024-10-25 10:53:54 --> Language Class Initialized
INFO - 2024-10-25 10:53:54 --> Config Class Initialized
INFO - 2024-10-25 10:53:54 --> Loader Class Initialized
INFO - 2024-10-25 10:53:54 --> Helper loaded: url_helper
INFO - 2024-10-25 10:53:54 --> Helper loaded: file_helper
INFO - 2024-10-25 10:53:54 --> Helper loaded: form_helper
INFO - 2024-10-25 10:53:54 --> Helper loaded: my_helper
INFO - 2024-10-25 10:53:54 --> Database Driver Class Initialized
INFO - 2024-10-25 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:53:54 --> Controller Class Initialized
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 10:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 10:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 10:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
ERROR - 2024-10-25 10:53:54 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
DEBUG - 2024-10-25 10:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 10:53:57 --> Final output sent to browser
DEBUG - 2024-10-25 10:53:57 --> Total execution time: 3.1095
INFO - 2024-10-25 11:01:03 --> Config Class Initialized
INFO - 2024-10-25 11:01:03 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:03 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:03 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:03 --> URI Class Initialized
INFO - 2024-10-25 11:01:03 --> Router Class Initialized
INFO - 2024-10-25 11:01:03 --> Output Class Initialized
INFO - 2024-10-25 11:01:03 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:03 --> Input Class Initialized
INFO - 2024-10-25 11:01:03 --> Language Class Initialized
INFO - 2024-10-25 11:01:03 --> Language Class Initialized
INFO - 2024-10-25 11:01:03 --> Config Class Initialized
INFO - 2024-10-25 11:01:03 --> Loader Class Initialized
INFO - 2024-10-25 11:01:04 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:04 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:04 --> Controller Class Initialized
INFO - 2024-10-25 11:01:04 --> Helper loaded: cookie_helper
INFO - 2024-10-25 11:01:04 --> Config Class Initialized
INFO - 2024-10-25 11:01:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:04 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:04 --> URI Class Initialized
INFO - 2024-10-25 11:01:04 --> Router Class Initialized
INFO - 2024-10-25 11:01:04 --> Output Class Initialized
INFO - 2024-10-25 11:01:04 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:04 --> Input Class Initialized
INFO - 2024-10-25 11:01:04 --> Language Class Initialized
INFO - 2024-10-25 11:01:04 --> Language Class Initialized
INFO - 2024-10-25 11:01:04 --> Config Class Initialized
INFO - 2024-10-25 11:01:04 --> Loader Class Initialized
INFO - 2024-10-25 11:01:04 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:04 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:04 --> Controller Class Initialized
INFO - 2024-10-25 11:01:04 --> Config Class Initialized
INFO - 2024-10-25 11:01:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:04 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:04 --> URI Class Initialized
INFO - 2024-10-25 11:01:04 --> Router Class Initialized
INFO - 2024-10-25 11:01:04 --> Output Class Initialized
INFO - 2024-10-25 11:01:04 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:04 --> Input Class Initialized
INFO - 2024-10-25 11:01:04 --> Language Class Initialized
INFO - 2024-10-25 11:01:04 --> Language Class Initialized
INFO - 2024-10-25 11:01:04 --> Config Class Initialized
INFO - 2024-10-25 11:01:04 --> Loader Class Initialized
INFO - 2024-10-25 11:01:04 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:04 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:04 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:04 --> Controller Class Initialized
DEBUG - 2024-10-25 11:01:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-25 11:01:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 11:01:04 --> Final output sent to browser
DEBUG - 2024-10-25 11:01:04 --> Total execution time: 0.0825
INFO - 2024-10-25 11:01:13 --> Config Class Initialized
INFO - 2024-10-25 11:01:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:13 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:13 --> URI Class Initialized
INFO - 2024-10-25 11:01:13 --> Router Class Initialized
INFO - 2024-10-25 11:01:13 --> Output Class Initialized
INFO - 2024-10-25 11:01:13 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:13 --> Input Class Initialized
INFO - 2024-10-25 11:01:13 --> Language Class Initialized
INFO - 2024-10-25 11:01:13 --> Language Class Initialized
INFO - 2024-10-25 11:01:13 --> Config Class Initialized
INFO - 2024-10-25 11:01:13 --> Loader Class Initialized
INFO - 2024-10-25 11:01:13 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:13 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:13 --> Controller Class Initialized
INFO - 2024-10-25 11:01:13 --> Helper loaded: cookie_helper
INFO - 2024-10-25 11:01:13 --> Final output sent to browser
DEBUG - 2024-10-25 11:01:13 --> Total execution time: 0.2361
INFO - 2024-10-25 11:01:13 --> Config Class Initialized
INFO - 2024-10-25 11:01:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:13 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:13 --> URI Class Initialized
INFO - 2024-10-25 11:01:13 --> Router Class Initialized
INFO - 2024-10-25 11:01:13 --> Output Class Initialized
INFO - 2024-10-25 11:01:13 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:13 --> Input Class Initialized
INFO - 2024-10-25 11:01:13 --> Language Class Initialized
INFO - 2024-10-25 11:01:13 --> Language Class Initialized
INFO - 2024-10-25 11:01:13 --> Config Class Initialized
INFO - 2024-10-25 11:01:13 --> Loader Class Initialized
INFO - 2024-10-25 11:01:13 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:13 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:13 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:13 --> Controller Class Initialized
DEBUG - 2024-10-25 11:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-25 11:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 11:01:14 --> Final output sent to browser
DEBUG - 2024-10-25 11:01:14 --> Total execution time: 0.1382
INFO - 2024-10-25 11:01:23 --> Config Class Initialized
INFO - 2024-10-25 11:01:23 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:23 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:23 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:23 --> URI Class Initialized
INFO - 2024-10-25 11:01:23 --> Router Class Initialized
INFO - 2024-10-25 11:01:23 --> Output Class Initialized
INFO - 2024-10-25 11:01:23 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:23 --> Input Class Initialized
INFO - 2024-10-25 11:01:23 --> Language Class Initialized
INFO - 2024-10-25 11:01:23 --> Language Class Initialized
INFO - 2024-10-25 11:01:23 --> Config Class Initialized
INFO - 2024-10-25 11:01:23 --> Loader Class Initialized
INFO - 2024-10-25 11:01:23 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:23 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:23 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:23 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:23 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:23 --> Controller Class Initialized
DEBUG - 2024-10-25 11:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-25 11:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 11:01:23 --> Final output sent to browser
DEBUG - 2024-10-25 11:01:23 --> Total execution time: 0.1342
INFO - 2024-10-25 11:01:25 --> Config Class Initialized
INFO - 2024-10-25 11:01:25 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:01:25 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:01:25 --> Utf8 Class Initialized
INFO - 2024-10-25 11:01:25 --> URI Class Initialized
INFO - 2024-10-25 11:01:25 --> Router Class Initialized
INFO - 2024-10-25 11:01:25 --> Output Class Initialized
INFO - 2024-10-25 11:01:25 --> Security Class Initialized
DEBUG - 2024-10-25 11:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:01:25 --> Input Class Initialized
INFO - 2024-10-25 11:01:25 --> Language Class Initialized
INFO - 2024-10-25 11:01:25 --> Language Class Initialized
INFO - 2024-10-25 11:01:25 --> Config Class Initialized
INFO - 2024-10-25 11:01:25 --> Loader Class Initialized
INFO - 2024-10-25 11:01:25 --> Helper loaded: url_helper
INFO - 2024-10-25 11:01:25 --> Helper loaded: file_helper
INFO - 2024-10-25 11:01:25 --> Helper loaded: form_helper
INFO - 2024-10-25 11:01:25 --> Helper loaded: my_helper
INFO - 2024-10-25 11:01:25 --> Database Driver Class Initialized
INFO - 2024-10-25 11:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:01:25 --> Controller Class Initialized
DEBUG - 2024-10-25 11:01:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:01:32 --> Final output sent to browser
DEBUG - 2024-10-25 11:01:32 --> Total execution time: 6.9868
INFO - 2024-10-25 11:21:53 --> Config Class Initialized
INFO - 2024-10-25 11:21:53 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:21:53 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:21:53 --> Utf8 Class Initialized
INFO - 2024-10-25 11:21:53 --> URI Class Initialized
INFO - 2024-10-25 11:21:53 --> Router Class Initialized
INFO - 2024-10-25 11:21:53 --> Output Class Initialized
INFO - 2024-10-25 11:21:53 --> Security Class Initialized
DEBUG - 2024-10-25 11:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:21:53 --> Input Class Initialized
INFO - 2024-10-25 11:21:53 --> Language Class Initialized
INFO - 2024-10-25 11:21:53 --> Language Class Initialized
INFO - 2024-10-25 11:21:53 --> Config Class Initialized
INFO - 2024-10-25 11:21:53 --> Loader Class Initialized
INFO - 2024-10-25 11:21:53 --> Helper loaded: url_helper
INFO - 2024-10-25 11:21:53 --> Helper loaded: file_helper
INFO - 2024-10-25 11:21:53 --> Helper loaded: form_helper
INFO - 2024-10-25 11:21:53 --> Helper loaded: my_helper
INFO - 2024-10-25 11:21:53 --> Database Driver Class Initialized
INFO - 2024-10-25 11:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:21:53 --> Controller Class Initialized
DEBUG - 2024-10-25 11:21:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:21:56 --> Final output sent to browser
DEBUG - 2024-10-25 11:21:56 --> Total execution time: 3.0054
INFO - 2024-10-25 11:22:27 --> Config Class Initialized
INFO - 2024-10-25 11:22:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:22:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:22:27 --> Utf8 Class Initialized
INFO - 2024-10-25 11:22:27 --> URI Class Initialized
INFO - 2024-10-25 11:22:27 --> Router Class Initialized
INFO - 2024-10-25 11:22:27 --> Output Class Initialized
INFO - 2024-10-25 11:22:27 --> Security Class Initialized
DEBUG - 2024-10-25 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:22:27 --> Input Class Initialized
INFO - 2024-10-25 11:22:27 --> Language Class Initialized
INFO - 2024-10-25 11:22:27 --> Language Class Initialized
INFO - 2024-10-25 11:22:27 --> Config Class Initialized
INFO - 2024-10-25 11:22:27 --> Loader Class Initialized
INFO - 2024-10-25 11:22:27 --> Helper loaded: url_helper
INFO - 2024-10-25 11:22:27 --> Helper loaded: file_helper
INFO - 2024-10-25 11:22:27 --> Helper loaded: form_helper
INFO - 2024-10-25 11:22:27 --> Helper loaded: my_helper
INFO - 2024-10-25 11:22:27 --> Database Driver Class Initialized
INFO - 2024-10-25 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:22:27 --> Controller Class Initialized
DEBUG - 2024-10-25 11:22:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:22:30 --> Final output sent to browser
DEBUG - 2024-10-25 11:22:30 --> Total execution time: 3.1250
INFO - 2024-10-25 11:22:48 --> Config Class Initialized
INFO - 2024-10-25 11:22:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:22:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:22:48 --> Utf8 Class Initialized
INFO - 2024-10-25 11:22:48 --> URI Class Initialized
INFO - 2024-10-25 11:22:48 --> Router Class Initialized
INFO - 2024-10-25 11:22:48 --> Output Class Initialized
INFO - 2024-10-25 11:22:48 --> Security Class Initialized
DEBUG - 2024-10-25 11:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:22:48 --> Input Class Initialized
INFO - 2024-10-25 11:22:48 --> Language Class Initialized
INFO - 2024-10-25 11:22:48 --> Language Class Initialized
INFO - 2024-10-25 11:22:48 --> Config Class Initialized
INFO - 2024-10-25 11:22:48 --> Loader Class Initialized
INFO - 2024-10-25 11:22:48 --> Helper loaded: url_helper
INFO - 2024-10-25 11:22:48 --> Helper loaded: file_helper
INFO - 2024-10-25 11:22:48 --> Helper loaded: form_helper
INFO - 2024-10-25 11:22:48 --> Helper loaded: my_helper
INFO - 2024-10-25 11:22:48 --> Database Driver Class Initialized
INFO - 2024-10-25 11:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:22:48 --> Controller Class Initialized
DEBUG - 2024-10-25 11:22:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:22:51 --> Final output sent to browser
DEBUG - 2024-10-25 11:22:51 --> Total execution time: 3.1344
INFO - 2024-10-25 11:30:49 --> Config Class Initialized
INFO - 2024-10-25 11:30:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:30:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:30:49 --> Utf8 Class Initialized
INFO - 2024-10-25 11:30:49 --> URI Class Initialized
INFO - 2024-10-25 11:30:49 --> Router Class Initialized
INFO - 2024-10-25 11:30:49 --> Output Class Initialized
INFO - 2024-10-25 11:30:49 --> Security Class Initialized
DEBUG - 2024-10-25 11:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:30:49 --> Input Class Initialized
INFO - 2024-10-25 11:30:49 --> Language Class Initialized
INFO - 2024-10-25 11:30:49 --> Language Class Initialized
INFO - 2024-10-25 11:30:49 --> Config Class Initialized
INFO - 2024-10-25 11:30:49 --> Loader Class Initialized
INFO - 2024-10-25 11:30:49 --> Helper loaded: url_helper
INFO - 2024-10-25 11:30:49 --> Helper loaded: file_helper
INFO - 2024-10-25 11:30:49 --> Helper loaded: form_helper
INFO - 2024-10-25 11:30:49 --> Helper loaded: my_helper
INFO - 2024-10-25 11:30:49 --> Database Driver Class Initialized
INFO - 2024-10-25 11:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:30:49 --> Controller Class Initialized
DEBUG - 2024-10-25 11:30:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:30:52 --> Final output sent to browser
DEBUG - 2024-10-25 11:30:52 --> Total execution time: 3.4359
INFO - 2024-10-25 11:31:28 --> Config Class Initialized
INFO - 2024-10-25 11:31:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:31:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:31:28 --> Utf8 Class Initialized
INFO - 2024-10-25 11:31:28 --> URI Class Initialized
INFO - 2024-10-25 11:31:28 --> Router Class Initialized
INFO - 2024-10-25 11:31:28 --> Output Class Initialized
INFO - 2024-10-25 11:31:28 --> Security Class Initialized
DEBUG - 2024-10-25 11:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:31:28 --> Input Class Initialized
INFO - 2024-10-25 11:31:28 --> Language Class Initialized
INFO - 2024-10-25 11:31:29 --> Language Class Initialized
INFO - 2024-10-25 11:31:29 --> Config Class Initialized
INFO - 2024-10-25 11:31:29 --> Loader Class Initialized
INFO - 2024-10-25 11:31:29 --> Helper loaded: url_helper
INFO - 2024-10-25 11:31:29 --> Helper loaded: file_helper
INFO - 2024-10-25 11:31:29 --> Helper loaded: form_helper
INFO - 2024-10-25 11:31:29 --> Helper loaded: my_helper
INFO - 2024-10-25 11:31:29 --> Database Driver Class Initialized
INFO - 2024-10-25 11:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:31:29 --> Controller Class Initialized
DEBUG - 2024-10-25 11:31:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:31:32 --> Final output sent to browser
DEBUG - 2024-10-25 11:31:32 --> Total execution time: 3.3849
INFO - 2024-10-25 11:31:48 --> Config Class Initialized
INFO - 2024-10-25 11:31:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:31:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:31:48 --> Utf8 Class Initialized
INFO - 2024-10-25 11:31:48 --> URI Class Initialized
INFO - 2024-10-25 11:31:48 --> Router Class Initialized
INFO - 2024-10-25 11:31:48 --> Output Class Initialized
INFO - 2024-10-25 11:31:48 --> Security Class Initialized
DEBUG - 2024-10-25 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:31:48 --> Input Class Initialized
INFO - 2024-10-25 11:31:48 --> Language Class Initialized
INFO - 2024-10-25 11:31:48 --> Language Class Initialized
INFO - 2024-10-25 11:31:48 --> Config Class Initialized
INFO - 2024-10-25 11:31:48 --> Loader Class Initialized
INFO - 2024-10-25 11:31:48 --> Helper loaded: url_helper
INFO - 2024-10-25 11:31:48 --> Helper loaded: file_helper
INFO - 2024-10-25 11:31:48 --> Helper loaded: form_helper
INFO - 2024-10-25 11:31:48 --> Helper loaded: my_helper
INFO - 2024-10-25 11:31:48 --> Database Driver Class Initialized
INFO - 2024-10-25 11:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:31:48 --> Controller Class Initialized
DEBUG - 2024-10-25 11:31:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:31:51 --> Final output sent to browser
DEBUG - 2024-10-25 11:31:51 --> Total execution time: 3.5396
INFO - 2024-10-25 11:34:08 --> Config Class Initialized
INFO - 2024-10-25 11:34:08 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:34:08 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:34:08 --> Utf8 Class Initialized
INFO - 2024-10-25 11:34:08 --> URI Class Initialized
INFO - 2024-10-25 11:34:08 --> Router Class Initialized
INFO - 2024-10-25 11:34:08 --> Output Class Initialized
INFO - 2024-10-25 11:34:08 --> Security Class Initialized
DEBUG - 2024-10-25 11:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:34:08 --> Input Class Initialized
INFO - 2024-10-25 11:34:08 --> Language Class Initialized
INFO - 2024-10-25 11:34:08 --> Language Class Initialized
INFO - 2024-10-25 11:34:08 --> Config Class Initialized
INFO - 2024-10-25 11:34:08 --> Loader Class Initialized
INFO - 2024-10-25 11:34:08 --> Helper loaded: url_helper
INFO - 2024-10-25 11:34:08 --> Helper loaded: file_helper
INFO - 2024-10-25 11:34:08 --> Helper loaded: form_helper
INFO - 2024-10-25 11:34:08 --> Helper loaded: my_helper
INFO - 2024-10-25 11:34:08 --> Database Driver Class Initialized
INFO - 2024-10-25 11:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:34:08 --> Controller Class Initialized
DEBUG - 2024-10-25 11:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:34:11 --> Final output sent to browser
DEBUG - 2024-10-25 11:34:11 --> Total execution time: 2.8705
INFO - 2024-10-25 11:34:27 --> Config Class Initialized
INFO - 2024-10-25 11:34:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:34:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:34:27 --> Utf8 Class Initialized
INFO - 2024-10-25 11:34:27 --> URI Class Initialized
INFO - 2024-10-25 11:34:27 --> Router Class Initialized
INFO - 2024-10-25 11:34:27 --> Output Class Initialized
INFO - 2024-10-25 11:34:27 --> Security Class Initialized
DEBUG - 2024-10-25 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:34:27 --> Input Class Initialized
INFO - 2024-10-25 11:34:27 --> Language Class Initialized
INFO - 2024-10-25 11:34:27 --> Language Class Initialized
INFO - 2024-10-25 11:34:27 --> Config Class Initialized
INFO - 2024-10-25 11:34:27 --> Loader Class Initialized
INFO - 2024-10-25 11:34:27 --> Helper loaded: url_helper
INFO - 2024-10-25 11:34:27 --> Helper loaded: file_helper
INFO - 2024-10-25 11:34:27 --> Helper loaded: form_helper
INFO - 2024-10-25 11:34:27 --> Helper loaded: my_helper
INFO - 2024-10-25 11:34:27 --> Database Driver Class Initialized
INFO - 2024-10-25 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:34:27 --> Controller Class Initialized
DEBUG - 2024-10-25 11:34:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:34:31 --> Final output sent to browser
DEBUG - 2024-10-25 11:34:31 --> Total execution time: 3.4642
INFO - 2024-10-25 11:39:12 --> Config Class Initialized
INFO - 2024-10-25 11:39:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:39:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:39:12 --> Utf8 Class Initialized
INFO - 2024-10-25 11:39:12 --> URI Class Initialized
INFO - 2024-10-25 11:39:12 --> Router Class Initialized
INFO - 2024-10-25 11:39:12 --> Output Class Initialized
INFO - 2024-10-25 11:39:12 --> Security Class Initialized
DEBUG - 2024-10-25 11:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:39:12 --> Input Class Initialized
INFO - 2024-10-25 11:39:12 --> Language Class Initialized
INFO - 2024-10-25 11:39:12 --> Language Class Initialized
INFO - 2024-10-25 11:39:12 --> Config Class Initialized
INFO - 2024-10-25 11:39:12 --> Loader Class Initialized
INFO - 2024-10-25 11:39:12 --> Helper loaded: url_helper
INFO - 2024-10-25 11:39:12 --> Helper loaded: file_helper
INFO - 2024-10-25 11:39:12 --> Helper loaded: form_helper
INFO - 2024-10-25 11:39:12 --> Helper loaded: my_helper
INFO - 2024-10-25 11:39:12 --> Database Driver Class Initialized
INFO - 2024-10-25 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:39:12 --> Controller Class Initialized
DEBUG - 2024-10-25 11:39:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:39:15 --> Final output sent to browser
DEBUG - 2024-10-25 11:39:15 --> Total execution time: 3.0219
INFO - 2024-10-25 11:39:48 --> Config Class Initialized
INFO - 2024-10-25 11:39:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:39:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:39:48 --> Utf8 Class Initialized
INFO - 2024-10-25 11:39:48 --> URI Class Initialized
INFO - 2024-10-25 11:39:48 --> Router Class Initialized
INFO - 2024-10-25 11:39:48 --> Output Class Initialized
INFO - 2024-10-25 11:39:48 --> Security Class Initialized
DEBUG - 2024-10-25 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:39:48 --> Input Class Initialized
INFO - 2024-10-25 11:39:48 --> Language Class Initialized
INFO - 2024-10-25 11:39:48 --> Language Class Initialized
INFO - 2024-10-25 11:39:48 --> Config Class Initialized
INFO - 2024-10-25 11:39:48 --> Loader Class Initialized
INFO - 2024-10-25 11:39:48 --> Helper loaded: url_helper
INFO - 2024-10-25 11:39:48 --> Helper loaded: file_helper
INFO - 2024-10-25 11:39:48 --> Helper loaded: form_helper
INFO - 2024-10-25 11:39:48 --> Helper loaded: my_helper
INFO - 2024-10-25 11:39:48 --> Database Driver Class Initialized
INFO - 2024-10-25 11:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:39:48 --> Controller Class Initialized
DEBUG - 2024-10-25 11:39:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:39:51 --> Final output sent to browser
DEBUG - 2024-10-25 11:39:51 --> Total execution time: 3.2419
INFO - 2024-10-25 11:40:21 --> Config Class Initialized
INFO - 2024-10-25 11:40:21 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:40:21 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:40:21 --> Utf8 Class Initialized
INFO - 2024-10-25 11:40:21 --> URI Class Initialized
INFO - 2024-10-25 11:40:21 --> Router Class Initialized
INFO - 2024-10-25 11:40:21 --> Output Class Initialized
INFO - 2024-10-25 11:40:21 --> Security Class Initialized
DEBUG - 2024-10-25 11:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:40:21 --> Input Class Initialized
INFO - 2024-10-25 11:40:21 --> Language Class Initialized
INFO - 2024-10-25 11:40:21 --> Language Class Initialized
INFO - 2024-10-25 11:40:21 --> Config Class Initialized
INFO - 2024-10-25 11:40:21 --> Loader Class Initialized
INFO - 2024-10-25 11:40:21 --> Helper loaded: url_helper
INFO - 2024-10-25 11:40:21 --> Helper loaded: file_helper
INFO - 2024-10-25 11:40:21 --> Helper loaded: form_helper
INFO - 2024-10-25 11:40:21 --> Helper loaded: my_helper
INFO - 2024-10-25 11:40:21 --> Database Driver Class Initialized
INFO - 2024-10-25 11:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:40:21 --> Controller Class Initialized
DEBUG - 2024-10-25 11:40:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:40:24 --> Final output sent to browser
DEBUG - 2024-10-25 11:40:24 --> Total execution time: 2.9242
INFO - 2024-10-25 11:46:00 --> Config Class Initialized
INFO - 2024-10-25 11:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:46:00 --> Utf8 Class Initialized
INFO - 2024-10-25 11:46:00 --> URI Class Initialized
INFO - 2024-10-25 11:46:00 --> Router Class Initialized
INFO - 2024-10-25 11:46:00 --> Output Class Initialized
INFO - 2024-10-25 11:46:00 --> Security Class Initialized
DEBUG - 2024-10-25 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:46:00 --> Input Class Initialized
INFO - 2024-10-25 11:46:00 --> Language Class Initialized
INFO - 2024-10-25 11:46:00 --> Language Class Initialized
INFO - 2024-10-25 11:46:00 --> Config Class Initialized
INFO - 2024-10-25 11:46:00 --> Loader Class Initialized
INFO - 2024-10-25 11:46:00 --> Helper loaded: url_helper
INFO - 2024-10-25 11:46:00 --> Helper loaded: file_helper
INFO - 2024-10-25 11:46:00 --> Helper loaded: form_helper
INFO - 2024-10-25 11:46:00 --> Helper loaded: my_helper
INFO - 2024-10-25 11:46:00 --> Database Driver Class Initialized
INFO - 2024-10-25 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:46:00 --> Controller Class Initialized
DEBUG - 2024-10-25 11:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:46:03 --> Final output sent to browser
DEBUG - 2024-10-25 11:46:03 --> Total execution time: 3.8656
INFO - 2024-10-25 11:46:20 --> Config Class Initialized
INFO - 2024-10-25 11:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:46:20 --> Utf8 Class Initialized
INFO - 2024-10-25 11:46:20 --> URI Class Initialized
INFO - 2024-10-25 11:46:20 --> Router Class Initialized
INFO - 2024-10-25 11:46:20 --> Output Class Initialized
INFO - 2024-10-25 11:46:20 --> Security Class Initialized
DEBUG - 2024-10-25 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:46:20 --> Input Class Initialized
INFO - 2024-10-25 11:46:20 --> Language Class Initialized
INFO - 2024-10-25 11:46:20 --> Language Class Initialized
INFO - 2024-10-25 11:46:20 --> Config Class Initialized
INFO - 2024-10-25 11:46:20 --> Loader Class Initialized
INFO - 2024-10-25 11:46:20 --> Helper loaded: url_helper
INFO - 2024-10-25 11:46:20 --> Helper loaded: file_helper
INFO - 2024-10-25 11:46:20 --> Helper loaded: form_helper
INFO - 2024-10-25 11:46:20 --> Helper loaded: my_helper
INFO - 2024-10-25 11:46:20 --> Database Driver Class Initialized
INFO - 2024-10-25 11:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:46:20 --> Controller Class Initialized
DEBUG - 2024-10-25 11:46:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:46:23 --> Final output sent to browser
DEBUG - 2024-10-25 11:46:23 --> Total execution time: 2.9159
INFO - 2024-10-25 11:46:38 --> Config Class Initialized
INFO - 2024-10-25 11:46:38 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:46:38 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:46:38 --> Utf8 Class Initialized
INFO - 2024-10-25 11:46:38 --> URI Class Initialized
INFO - 2024-10-25 11:46:38 --> Router Class Initialized
INFO - 2024-10-25 11:46:38 --> Output Class Initialized
INFO - 2024-10-25 11:46:38 --> Security Class Initialized
DEBUG - 2024-10-25 11:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:46:38 --> Input Class Initialized
INFO - 2024-10-25 11:46:38 --> Language Class Initialized
INFO - 2024-10-25 11:46:38 --> Language Class Initialized
INFO - 2024-10-25 11:46:38 --> Config Class Initialized
INFO - 2024-10-25 11:46:38 --> Loader Class Initialized
INFO - 2024-10-25 11:46:38 --> Helper loaded: url_helper
INFO - 2024-10-25 11:46:38 --> Helper loaded: file_helper
INFO - 2024-10-25 11:46:38 --> Helper loaded: form_helper
INFO - 2024-10-25 11:46:38 --> Helper loaded: my_helper
INFO - 2024-10-25 11:46:38 --> Database Driver Class Initialized
INFO - 2024-10-25 11:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:46:38 --> Controller Class Initialized
DEBUG - 2024-10-25 11:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:46:41 --> Final output sent to browser
DEBUG - 2024-10-25 11:46:41 --> Total execution time: 3.2883
INFO - 2024-10-25 11:47:11 --> Config Class Initialized
INFO - 2024-10-25 11:47:11 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:47:11 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:47:11 --> Utf8 Class Initialized
INFO - 2024-10-25 11:47:11 --> URI Class Initialized
INFO - 2024-10-25 11:47:11 --> Router Class Initialized
INFO - 2024-10-25 11:47:11 --> Output Class Initialized
INFO - 2024-10-25 11:47:11 --> Security Class Initialized
DEBUG - 2024-10-25 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:47:11 --> Input Class Initialized
INFO - 2024-10-25 11:47:11 --> Language Class Initialized
INFO - 2024-10-25 11:47:11 --> Language Class Initialized
INFO - 2024-10-25 11:47:11 --> Config Class Initialized
INFO - 2024-10-25 11:47:11 --> Loader Class Initialized
INFO - 2024-10-25 11:47:11 --> Helper loaded: url_helper
INFO - 2024-10-25 11:47:11 --> Helper loaded: file_helper
INFO - 2024-10-25 11:47:11 --> Helper loaded: form_helper
INFO - 2024-10-25 11:47:11 --> Helper loaded: my_helper
INFO - 2024-10-25 11:47:11 --> Database Driver Class Initialized
INFO - 2024-10-25 11:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:47:11 --> Controller Class Initialized
DEBUG - 2024-10-25 11:47:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:47:14 --> Final output sent to browser
DEBUG - 2024-10-25 11:47:14 --> Total execution time: 2.8865
INFO - 2024-10-25 11:47:36 --> Config Class Initialized
INFO - 2024-10-25 11:47:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 11:47:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 11:47:36 --> Utf8 Class Initialized
INFO - 2024-10-25 11:47:36 --> URI Class Initialized
INFO - 2024-10-25 11:47:36 --> Router Class Initialized
INFO - 2024-10-25 11:47:36 --> Output Class Initialized
INFO - 2024-10-25 11:47:36 --> Security Class Initialized
DEBUG - 2024-10-25 11:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 11:47:36 --> Input Class Initialized
INFO - 2024-10-25 11:47:36 --> Language Class Initialized
INFO - 2024-10-25 11:47:36 --> Language Class Initialized
INFO - 2024-10-25 11:47:36 --> Config Class Initialized
INFO - 2024-10-25 11:47:36 --> Loader Class Initialized
INFO - 2024-10-25 11:47:36 --> Helper loaded: url_helper
INFO - 2024-10-25 11:47:36 --> Helper loaded: file_helper
INFO - 2024-10-25 11:47:36 --> Helper loaded: form_helper
INFO - 2024-10-25 11:47:36 --> Helper loaded: my_helper
INFO - 2024-10-25 11:47:36 --> Database Driver Class Initialized
INFO - 2024-10-25 11:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 11:47:36 --> Controller Class Initialized
DEBUG - 2024-10-25 11:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 11:47:40 --> Final output sent to browser
DEBUG - 2024-10-25 11:47:40 --> Total execution time: 3.4295
INFO - 2024-10-25 12:04:45 --> Config Class Initialized
INFO - 2024-10-25 12:04:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:04:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:04:45 --> Utf8 Class Initialized
INFO - 2024-10-25 12:04:45 --> URI Class Initialized
INFO - 2024-10-25 12:04:45 --> Router Class Initialized
INFO - 2024-10-25 12:04:45 --> Output Class Initialized
INFO - 2024-10-25 12:04:45 --> Security Class Initialized
DEBUG - 2024-10-25 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:04:45 --> Input Class Initialized
INFO - 2024-10-25 12:04:45 --> Language Class Initialized
INFO - 2024-10-25 12:04:45 --> Language Class Initialized
INFO - 2024-10-25 12:04:45 --> Config Class Initialized
INFO - 2024-10-25 12:04:45 --> Loader Class Initialized
INFO - 2024-10-25 12:04:45 --> Helper loaded: url_helper
INFO - 2024-10-25 12:04:45 --> Helper loaded: file_helper
INFO - 2024-10-25 12:04:45 --> Helper loaded: form_helper
INFO - 2024-10-25 12:04:45 --> Helper loaded: my_helper
INFO - 2024-10-25 12:04:45 --> Database Driver Class Initialized
INFO - 2024-10-25 12:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:04:46 --> Controller Class Initialized
INFO - 2024-10-25 12:04:46 --> Helper loaded: cookie_helper
INFO - 2024-10-25 12:04:46 --> Final output sent to browser
DEBUG - 2024-10-25 12:04:46 --> Total execution time: 0.0574
INFO - 2024-10-25 12:04:46 --> Config Class Initialized
INFO - 2024-10-25 12:04:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:04:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:04:46 --> Utf8 Class Initialized
INFO - 2024-10-25 12:04:46 --> URI Class Initialized
INFO - 2024-10-25 12:04:46 --> Router Class Initialized
INFO - 2024-10-25 12:04:46 --> Output Class Initialized
INFO - 2024-10-25 12:04:46 --> Security Class Initialized
DEBUG - 2024-10-25 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:04:46 --> Input Class Initialized
INFO - 2024-10-25 12:04:46 --> Language Class Initialized
INFO - 2024-10-25 12:04:46 --> Language Class Initialized
INFO - 2024-10-25 12:04:46 --> Config Class Initialized
INFO - 2024-10-25 12:04:46 --> Loader Class Initialized
INFO - 2024-10-25 12:04:46 --> Helper loaded: url_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: file_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: form_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: my_helper
INFO - 2024-10-25 12:04:46 --> Database Driver Class Initialized
INFO - 2024-10-25 12:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:04:46 --> Controller Class Initialized
INFO - 2024-10-25 12:04:46 --> Helper loaded: cookie_helper
INFO - 2024-10-25 12:04:46 --> Config Class Initialized
INFO - 2024-10-25 12:04:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:04:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:04:46 --> Utf8 Class Initialized
INFO - 2024-10-25 12:04:46 --> URI Class Initialized
INFO - 2024-10-25 12:04:46 --> Router Class Initialized
INFO - 2024-10-25 12:04:46 --> Output Class Initialized
INFO - 2024-10-25 12:04:46 --> Security Class Initialized
DEBUG - 2024-10-25 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:04:46 --> Input Class Initialized
INFO - 2024-10-25 12:04:46 --> Language Class Initialized
INFO - 2024-10-25 12:04:46 --> Language Class Initialized
INFO - 2024-10-25 12:04:46 --> Config Class Initialized
INFO - 2024-10-25 12:04:46 --> Loader Class Initialized
INFO - 2024-10-25 12:04:46 --> Helper loaded: url_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: file_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: form_helper
INFO - 2024-10-25 12:04:46 --> Helper loaded: my_helper
INFO - 2024-10-25 12:04:46 --> Database Driver Class Initialized
INFO - 2024-10-25 12:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:04:46 --> Controller Class Initialized
DEBUG - 2024-10-25 12:04:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-25 12:04:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 12:04:46 --> Final output sent to browser
DEBUG - 2024-10-25 12:04:46 --> Total execution time: 0.0330
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:30:34 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:30:34 --> Utf8 Class Initialized
INFO - 2024-10-25 12:30:34 --> URI Class Initialized
INFO - 2024-10-25 12:30:34 --> Router Class Initialized
INFO - 2024-10-25 12:30:34 --> Output Class Initialized
INFO - 2024-10-25 12:30:34 --> Security Class Initialized
DEBUG - 2024-10-25 12:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:30:34 --> Input Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Loader Class Initialized
INFO - 2024-10-25 12:30:34 --> Helper loaded: url_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: file_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: form_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: my_helper
INFO - 2024-10-25 12:30:34 --> Database Driver Class Initialized
INFO - 2024-10-25 12:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:30:34 --> Controller Class Initialized
INFO - 2024-10-25 12:30:34 --> Helper loaded: cookie_helper
INFO - 2024-10-25 12:30:34 --> Final output sent to browser
DEBUG - 2024-10-25 12:30:34 --> Total execution time: 0.0748
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:30:34 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:30:34 --> Utf8 Class Initialized
INFO - 2024-10-25 12:30:34 --> URI Class Initialized
INFO - 2024-10-25 12:30:34 --> Router Class Initialized
INFO - 2024-10-25 12:30:34 --> Output Class Initialized
INFO - 2024-10-25 12:30:34 --> Security Class Initialized
DEBUG - 2024-10-25 12:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:30:34 --> Input Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Loader Class Initialized
INFO - 2024-10-25 12:30:34 --> Helper loaded: url_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: file_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: form_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: my_helper
INFO - 2024-10-25 12:30:34 --> Database Driver Class Initialized
INFO - 2024-10-25 12:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:30:34 --> Controller Class Initialized
INFO - 2024-10-25 12:30:34 --> Helper loaded: cookie_helper
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:30:34 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:30:34 --> Utf8 Class Initialized
INFO - 2024-10-25 12:30:34 --> URI Class Initialized
INFO - 2024-10-25 12:30:34 --> Router Class Initialized
INFO - 2024-10-25 12:30:34 --> Output Class Initialized
INFO - 2024-10-25 12:30:34 --> Security Class Initialized
DEBUG - 2024-10-25 12:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:30:34 --> Input Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Language Class Initialized
INFO - 2024-10-25 12:30:34 --> Config Class Initialized
INFO - 2024-10-25 12:30:34 --> Loader Class Initialized
INFO - 2024-10-25 12:30:34 --> Helper loaded: url_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: file_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: form_helper
INFO - 2024-10-25 12:30:34 --> Helper loaded: my_helper
INFO - 2024-10-25 12:30:34 --> Database Driver Class Initialized
INFO - 2024-10-25 12:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:30:34 --> Controller Class Initialized
DEBUG - 2024-10-25 12:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-25 12:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 12:30:34 --> Final output sent to browser
DEBUG - 2024-10-25 12:30:34 --> Total execution time: 0.0333
INFO - 2024-10-25 12:30:36 --> Config Class Initialized
INFO - 2024-10-25 12:30:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 12:30:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 12:30:36 --> Utf8 Class Initialized
INFO - 2024-10-25 12:30:36 --> URI Class Initialized
INFO - 2024-10-25 12:30:36 --> Router Class Initialized
INFO - 2024-10-25 12:30:36 --> Output Class Initialized
INFO - 2024-10-25 12:30:36 --> Security Class Initialized
DEBUG - 2024-10-25 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 12:30:36 --> Input Class Initialized
INFO - 2024-10-25 12:30:36 --> Language Class Initialized
INFO - 2024-10-25 12:30:36 --> Language Class Initialized
INFO - 2024-10-25 12:30:36 --> Config Class Initialized
INFO - 2024-10-25 12:30:36 --> Loader Class Initialized
INFO - 2024-10-25 12:30:36 --> Helper loaded: url_helper
INFO - 2024-10-25 12:30:36 --> Helper loaded: file_helper
INFO - 2024-10-25 12:30:36 --> Helper loaded: form_helper
INFO - 2024-10-25 12:30:36 --> Helper loaded: my_helper
INFO - 2024-10-25 12:30:36 --> Database Driver Class Initialized
INFO - 2024-10-25 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 12:30:36 --> Controller Class Initialized
DEBUG - 2024-10-25 12:30:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 12:30:40 --> Final output sent to browser
DEBUG - 2024-10-25 12:30:40 --> Total execution time: 3.7983
INFO - 2024-10-25 13:54:11 --> Config Class Initialized
INFO - 2024-10-25 13:54:11 --> Hooks Class Initialized
DEBUG - 2024-10-25 13:54:11 --> UTF-8 Support Enabled
INFO - 2024-10-25 13:54:11 --> Utf8 Class Initialized
INFO - 2024-10-25 13:54:11 --> URI Class Initialized
INFO - 2024-10-25 13:54:11 --> Router Class Initialized
INFO - 2024-10-25 13:54:11 --> Output Class Initialized
INFO - 2024-10-25 13:54:11 --> Security Class Initialized
DEBUG - 2024-10-25 13:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 13:54:11 --> Input Class Initialized
INFO - 2024-10-25 13:54:11 --> Language Class Initialized
INFO - 2024-10-25 13:54:11 --> Language Class Initialized
INFO - 2024-10-25 13:54:11 --> Config Class Initialized
INFO - 2024-10-25 13:54:11 --> Loader Class Initialized
INFO - 2024-10-25 13:54:11 --> Helper loaded: url_helper
INFO - 2024-10-25 13:54:11 --> Helper loaded: file_helper
INFO - 2024-10-25 13:54:11 --> Helper loaded: form_helper
INFO - 2024-10-25 13:54:11 --> Helper loaded: my_helper
INFO - 2024-10-25 13:54:11 --> Database Driver Class Initialized
INFO - 2024-10-25 13:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 13:54:11 --> Controller Class Initialized
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 13:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1697
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 13:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1734
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 13:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1772
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1830
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
ERROR - 2024-10-25 13:54:11 --> Severity: Notice --> Undefined variable: lang_mapel /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1911
DEBUG - 2024-10-25 13:54:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-25 13:54:14 --> Final output sent to browser
DEBUG - 2024-10-25 13:54:14 --> Total execution time: 3.2404
INFO - 2024-10-25 14:54:40 --> Config Class Initialized
INFO - 2024-10-25 14:54:40 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:54:40 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:54:40 --> Utf8 Class Initialized
INFO - 2024-10-25 14:54:40 --> URI Class Initialized
INFO - 2024-10-25 14:54:40 --> Router Class Initialized
INFO - 2024-10-25 14:54:40 --> Output Class Initialized
INFO - 2024-10-25 14:54:40 --> Security Class Initialized
DEBUG - 2024-10-25 14:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:54:40 --> Input Class Initialized
INFO - 2024-10-25 14:54:40 --> Language Class Initialized
INFO - 2024-10-25 14:54:40 --> Language Class Initialized
INFO - 2024-10-25 14:54:40 --> Config Class Initialized
INFO - 2024-10-25 14:54:40 --> Loader Class Initialized
INFO - 2024-10-25 14:54:40 --> Helper loaded: url_helper
INFO - 2024-10-25 14:54:40 --> Helper loaded: file_helper
INFO - 2024-10-25 14:54:40 --> Helper loaded: form_helper
INFO - 2024-10-25 14:54:40 --> Helper loaded: my_helper
INFO - 2024-10-25 14:54:40 --> Database Driver Class Initialized
INFO - 2024-10-25 14:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 14:54:40 --> Controller Class Initialized
DEBUG - 2024-10-25 14:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-25 14:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 14:54:40 --> Final output sent to browser
DEBUG - 2024-10-25 14:54:40 --> Total execution time: 0.0471
INFO - 2024-10-25 14:54:54 --> Config Class Initialized
INFO - 2024-10-25 14:54:54 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:54:54 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:54:54 --> Utf8 Class Initialized
INFO - 2024-10-25 14:54:54 --> URI Class Initialized
INFO - 2024-10-25 14:54:54 --> Router Class Initialized
INFO - 2024-10-25 14:54:54 --> Output Class Initialized
INFO - 2024-10-25 14:54:54 --> Security Class Initialized
DEBUG - 2024-10-25 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:54:54 --> Input Class Initialized
INFO - 2024-10-25 14:54:54 --> Language Class Initialized
INFO - 2024-10-25 14:54:54 --> Language Class Initialized
INFO - 2024-10-25 14:54:54 --> Config Class Initialized
INFO - 2024-10-25 14:54:54 --> Loader Class Initialized
INFO - 2024-10-25 14:54:54 --> Helper loaded: url_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: file_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: form_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: my_helper
INFO - 2024-10-25 14:54:54 --> Database Driver Class Initialized
INFO - 2024-10-25 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 14:54:54 --> Controller Class Initialized
INFO - 2024-10-25 14:54:54 --> Helper loaded: cookie_helper
INFO - 2024-10-25 14:54:54 --> Final output sent to browser
DEBUG - 2024-10-25 14:54:54 --> Total execution time: 0.0281
INFO - 2024-10-25 14:54:54 --> Config Class Initialized
INFO - 2024-10-25 14:54:54 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:54:54 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:54:54 --> Utf8 Class Initialized
INFO - 2024-10-25 14:54:54 --> URI Class Initialized
INFO - 2024-10-25 14:54:54 --> Router Class Initialized
INFO - 2024-10-25 14:54:54 --> Output Class Initialized
INFO - 2024-10-25 14:54:54 --> Security Class Initialized
DEBUG - 2024-10-25 14:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:54:54 --> Input Class Initialized
INFO - 2024-10-25 14:54:54 --> Language Class Initialized
INFO - 2024-10-25 14:54:54 --> Language Class Initialized
INFO - 2024-10-25 14:54:54 --> Config Class Initialized
INFO - 2024-10-25 14:54:54 --> Loader Class Initialized
INFO - 2024-10-25 14:54:54 --> Helper loaded: url_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: file_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: form_helper
INFO - 2024-10-25 14:54:54 --> Helper loaded: my_helper
INFO - 2024-10-25 14:54:54 --> Database Driver Class Initialized
INFO - 2024-10-25 14:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 14:54:54 --> Controller Class Initialized
DEBUG - 2024-10-25 14:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-25 14:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 14:54:55 --> Final output sent to browser
DEBUG - 2024-10-25 14:54:55 --> Total execution time: 0.2365
INFO - 2024-10-25 15:01:06 --> Config Class Initialized
INFO - 2024-10-25 15:01:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:06 --> URI Class Initialized
DEBUG - 2024-10-25 15:01:06 --> No URI present. Default controller set.
INFO - 2024-10-25 15:01:06 --> Router Class Initialized
INFO - 2024-10-25 15:01:06 --> Output Class Initialized
INFO - 2024-10-25 15:01:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:06 --> Input Class Initialized
INFO - 2024-10-25 15:01:06 --> Language Class Initialized
INFO - 2024-10-25 15:01:06 --> Language Class Initialized
INFO - 2024-10-25 15:01:06 --> Config Class Initialized
INFO - 2024-10-25 15:01:06 --> Loader Class Initialized
INFO - 2024-10-25 15:01:06 --> Helper loaded: url_helper
INFO - 2024-10-25 15:01:06 --> Helper loaded: file_helper
INFO - 2024-10-25 15:01:06 --> Helper loaded: form_helper
INFO - 2024-10-25 15:01:06 --> Helper loaded: my_helper
INFO - 2024-10-25 15:01:06 --> Database Driver Class Initialized
INFO - 2024-10-25 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:01:06 --> Controller Class Initialized
DEBUG - 2024-10-25 15:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-25 15:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:01:06 --> Final output sent to browser
DEBUG - 2024-10-25 15:01:06 --> Total execution time: 0.0311
INFO - 2024-10-25 15:01:12 --> Config Class Initialized
INFO - 2024-10-25 15:01:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:12 --> URI Class Initialized
INFO - 2024-10-25 15:01:12 --> Router Class Initialized
INFO - 2024-10-25 15:01:12 --> Output Class Initialized
INFO - 2024-10-25 15:01:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:12 --> Input Class Initialized
INFO - 2024-10-25 15:01:12 --> Language Class Initialized
INFO - 2024-10-25 15:01:12 --> Language Class Initialized
INFO - 2024-10-25 15:01:12 --> Config Class Initialized
INFO - 2024-10-25 15:01:12 --> Loader Class Initialized
INFO - 2024-10-25 15:01:12 --> Helper loaded: url_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: file_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: form_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: my_helper
INFO - 2024-10-25 15:01:12 --> Database Driver Class Initialized
INFO - 2024-10-25 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:01:12 --> Controller Class Initialized
DEBUG - 2024-10-25 15:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:01:12 --> Final output sent to browser
DEBUG - 2024-10-25 15:01:12 --> Total execution time: 0.0337
INFO - 2024-10-25 15:01:12 --> Config Class Initialized
INFO - 2024-10-25 15:01:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:12 --> URI Class Initialized
INFO - 2024-10-25 15:01:12 --> Router Class Initialized
INFO - 2024-10-25 15:01:12 --> Output Class Initialized
INFO - 2024-10-25 15:01:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:12 --> Input Class Initialized
INFO - 2024-10-25 15:01:12 --> Language Class Initialized
ERROR - 2024-10-25 15:01:12 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:01:12 --> Config Class Initialized
INFO - 2024-10-25 15:01:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:12 --> URI Class Initialized
INFO - 2024-10-25 15:01:12 --> Router Class Initialized
INFO - 2024-10-25 15:01:12 --> Output Class Initialized
INFO - 2024-10-25 15:01:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:12 --> Input Class Initialized
INFO - 2024-10-25 15:01:12 --> Language Class Initialized
INFO - 2024-10-25 15:01:12 --> Language Class Initialized
INFO - 2024-10-25 15:01:12 --> Config Class Initialized
INFO - 2024-10-25 15:01:12 --> Loader Class Initialized
INFO - 2024-10-25 15:01:12 --> Helper loaded: url_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: file_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: form_helper
INFO - 2024-10-25 15:01:12 --> Helper loaded: my_helper
INFO - 2024-10-25 15:01:12 --> Database Driver Class Initialized
INFO - 2024-10-25 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:01:12 --> Controller Class Initialized
INFO - 2024-10-25 15:01:49 --> Config Class Initialized
INFO - 2024-10-25 15:01:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:49 --> URI Class Initialized
INFO - 2024-10-25 15:01:49 --> Router Class Initialized
INFO - 2024-10-25 15:01:49 --> Output Class Initialized
INFO - 2024-10-25 15:01:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:49 --> Input Class Initialized
INFO - 2024-10-25 15:01:49 --> Language Class Initialized
INFO - 2024-10-25 15:01:49 --> Language Class Initialized
INFO - 2024-10-25 15:01:49 --> Config Class Initialized
INFO - 2024-10-25 15:01:49 --> Loader Class Initialized
INFO - 2024-10-25 15:01:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:01:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:01:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:01:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:01:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:01:49 --> Controller Class Initialized
INFO - 2024-10-25 15:01:57 --> Config Class Initialized
INFO - 2024-10-25 15:01:57 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:01:57 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:01:57 --> Utf8 Class Initialized
INFO - 2024-10-25 15:01:57 --> URI Class Initialized
INFO - 2024-10-25 15:01:57 --> Router Class Initialized
INFO - 2024-10-25 15:01:57 --> Output Class Initialized
INFO - 2024-10-25 15:01:57 --> Security Class Initialized
DEBUG - 2024-10-25 15:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:01:57 --> Input Class Initialized
INFO - 2024-10-25 15:01:57 --> Language Class Initialized
INFO - 2024-10-25 15:01:57 --> Language Class Initialized
INFO - 2024-10-25 15:01:57 --> Config Class Initialized
INFO - 2024-10-25 15:01:57 --> Loader Class Initialized
INFO - 2024-10-25 15:01:57 --> Helper loaded: url_helper
INFO - 2024-10-25 15:01:57 --> Helper loaded: file_helper
INFO - 2024-10-25 15:01:57 --> Helper loaded: form_helper
INFO - 2024-10-25 15:01:57 --> Helper loaded: my_helper
INFO - 2024-10-25 15:01:57 --> Database Driver Class Initialized
INFO - 2024-10-25 15:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:01:57 --> Controller Class Initialized
INFO - 2024-10-25 15:03:04 --> Config Class Initialized
INFO - 2024-10-25 15:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:04 --> URI Class Initialized
INFO - 2024-10-25 15:03:04 --> Router Class Initialized
INFO - 2024-10-25 15:03:04 --> Output Class Initialized
INFO - 2024-10-25 15:03:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:04 --> Input Class Initialized
INFO - 2024-10-25 15:03:04 --> Language Class Initialized
INFO - 2024-10-25 15:03:04 --> Language Class Initialized
INFO - 2024-10-25 15:03:04 --> Config Class Initialized
INFO - 2024-10-25 15:03:04 --> Loader Class Initialized
INFO - 2024-10-25 15:03:04 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:04 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:04 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:04 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:04 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:04 --> Controller Class Initialized
ERROR - 2024-10-25 15:03:04 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:03:04 --> Final output sent to browser
DEBUG - 2024-10-25 15:03:04 --> Total execution time: 0.0984
INFO - 2024-10-25 15:03:19 --> Config Class Initialized
INFO - 2024-10-25 15:03:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:19 --> URI Class Initialized
INFO - 2024-10-25 15:03:19 --> Router Class Initialized
INFO - 2024-10-25 15:03:19 --> Output Class Initialized
INFO - 2024-10-25 15:03:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:19 --> Input Class Initialized
INFO - 2024-10-25 15:03:19 --> Language Class Initialized
INFO - 2024-10-25 15:03:19 --> Language Class Initialized
INFO - 2024-10-25 15:03:19 --> Config Class Initialized
INFO - 2024-10-25 15:03:19 --> Loader Class Initialized
INFO - 2024-10-25 15:03:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:19 --> Controller Class Initialized
DEBUG - 2024-10-25 15:03:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:03:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:03:19 --> Final output sent to browser
DEBUG - 2024-10-25 15:03:19 --> Total execution time: 0.0306
INFO - 2024-10-25 15:03:19 --> Config Class Initialized
INFO - 2024-10-25 15:03:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:19 --> URI Class Initialized
INFO - 2024-10-25 15:03:19 --> Router Class Initialized
INFO - 2024-10-25 15:03:19 --> Output Class Initialized
INFO - 2024-10-25 15:03:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:19 --> Input Class Initialized
INFO - 2024-10-25 15:03:19 --> Language Class Initialized
INFO - 2024-10-25 15:03:19 --> Language Class Initialized
INFO - 2024-10-25 15:03:19 --> Config Class Initialized
INFO - 2024-10-25 15:03:19 --> Loader Class Initialized
INFO - 2024-10-25 15:03:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:19 --> Controller Class Initialized
INFO - 2024-10-25 15:03:24 --> Config Class Initialized
INFO - 2024-10-25 15:03:24 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:24 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:24 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:24 --> URI Class Initialized
INFO - 2024-10-25 15:03:24 --> Router Class Initialized
INFO - 2024-10-25 15:03:24 --> Output Class Initialized
INFO - 2024-10-25 15:03:24 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:24 --> Input Class Initialized
INFO - 2024-10-25 15:03:24 --> Language Class Initialized
INFO - 2024-10-25 15:03:24 --> Language Class Initialized
INFO - 2024-10-25 15:03:24 --> Config Class Initialized
INFO - 2024-10-25 15:03:24 --> Loader Class Initialized
INFO - 2024-10-25 15:03:24 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:24 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:24 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:24 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:24 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:24 --> Controller Class Initialized
INFO - 2024-10-25 15:03:27 --> Config Class Initialized
INFO - 2024-10-25 15:03:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:27 --> URI Class Initialized
INFO - 2024-10-25 15:03:27 --> Router Class Initialized
INFO - 2024-10-25 15:03:27 --> Output Class Initialized
INFO - 2024-10-25 15:03:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:27 --> Input Class Initialized
INFO - 2024-10-25 15:03:27 --> Language Class Initialized
INFO - 2024-10-25 15:03:27 --> Language Class Initialized
INFO - 2024-10-25 15:03:27 --> Config Class Initialized
INFO - 2024-10-25 15:03:27 --> Loader Class Initialized
INFO - 2024-10-25 15:03:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:27 --> Controller Class Initialized
INFO - 2024-10-25 15:03:33 --> Config Class Initialized
INFO - 2024-10-25 15:03:33 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:33 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:33 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:33 --> URI Class Initialized
INFO - 2024-10-25 15:03:33 --> Router Class Initialized
INFO - 2024-10-25 15:03:33 --> Output Class Initialized
INFO - 2024-10-25 15:03:33 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:33 --> Input Class Initialized
INFO - 2024-10-25 15:03:33 --> Language Class Initialized
INFO - 2024-10-25 15:03:33 --> Language Class Initialized
INFO - 2024-10-25 15:03:33 --> Config Class Initialized
INFO - 2024-10-25 15:03:33 --> Loader Class Initialized
INFO - 2024-10-25 15:03:34 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:34 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:34 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:34 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:34 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:34 --> Controller Class Initialized
INFO - 2024-10-25 15:03:57 --> Config Class Initialized
INFO - 2024-10-25 15:03:57 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:03:57 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:03:57 --> Utf8 Class Initialized
INFO - 2024-10-25 15:03:57 --> URI Class Initialized
INFO - 2024-10-25 15:03:57 --> Router Class Initialized
INFO - 2024-10-25 15:03:57 --> Output Class Initialized
INFO - 2024-10-25 15:03:57 --> Security Class Initialized
DEBUG - 2024-10-25 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:03:57 --> Input Class Initialized
INFO - 2024-10-25 15:03:57 --> Language Class Initialized
INFO - 2024-10-25 15:03:57 --> Language Class Initialized
INFO - 2024-10-25 15:03:57 --> Config Class Initialized
INFO - 2024-10-25 15:03:57 --> Loader Class Initialized
INFO - 2024-10-25 15:03:57 --> Helper loaded: url_helper
INFO - 2024-10-25 15:03:57 --> Helper loaded: file_helper
INFO - 2024-10-25 15:03:57 --> Helper loaded: form_helper
INFO - 2024-10-25 15:03:57 --> Helper loaded: my_helper
INFO - 2024-10-25 15:03:57 --> Database Driver Class Initialized
INFO - 2024-10-25 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:03:57 --> Controller Class Initialized
ERROR - 2024-10-25 15:03:57 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:03:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:03:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:03:57 --> Final output sent to browser
DEBUG - 2024-10-25 15:03:57 --> Total execution time: 0.0355
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:04:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:04:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:04:28 --> URI Class Initialized
INFO - 2024-10-25 15:04:28 --> Router Class Initialized
INFO - 2024-10-25 15:04:28 --> Output Class Initialized
INFO - 2024-10-25 15:04:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:04:28 --> Input Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Loader Class Initialized
INFO - 2024-10-25 15:04:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:04:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:04:28 --> Controller Class Initialized
INFO - 2024-10-25 15:04:28 --> Upload Class Initialized
INFO - 2024-10-25 15:04:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:04:28 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:04:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:04:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:04:28 --> URI Class Initialized
INFO - 2024-10-25 15:04:28 --> Router Class Initialized
INFO - 2024-10-25 15:04:28 --> Output Class Initialized
INFO - 2024-10-25 15:04:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:04:28 --> Input Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Loader Class Initialized
INFO - 2024-10-25 15:04:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:04:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:04:28 --> Controller Class Initialized
DEBUG - 2024-10-25 15:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:04:28 --> Final output sent to browser
DEBUG - 2024-10-25 15:04:28 --> Total execution time: 0.0425
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:04:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:04:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:04:28 --> URI Class Initialized
INFO - 2024-10-25 15:04:28 --> Router Class Initialized
INFO - 2024-10-25 15:04:28 --> Output Class Initialized
INFO - 2024-10-25 15:04:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:04:28 --> Input Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
ERROR - 2024-10-25 15:04:28 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:04:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:04:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:04:28 --> URI Class Initialized
INFO - 2024-10-25 15:04:28 --> Router Class Initialized
INFO - 2024-10-25 15:04:28 --> Output Class Initialized
INFO - 2024-10-25 15:04:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:04:28 --> Input Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Language Class Initialized
INFO - 2024-10-25 15:04:28 --> Config Class Initialized
INFO - 2024-10-25 15:04:28 --> Loader Class Initialized
INFO - 2024-10-25 15:04:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:04:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:04:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:04:28 --> Controller Class Initialized
INFO - 2024-10-25 15:04:44 --> Config Class Initialized
INFO - 2024-10-25 15:04:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:04:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:04:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:04:44 --> URI Class Initialized
INFO - 2024-10-25 15:04:44 --> Router Class Initialized
INFO - 2024-10-25 15:04:44 --> Output Class Initialized
INFO - 2024-10-25 15:04:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:04:44 --> Input Class Initialized
INFO - 2024-10-25 15:04:44 --> Language Class Initialized
INFO - 2024-10-25 15:04:44 --> Language Class Initialized
INFO - 2024-10-25 15:04:44 --> Config Class Initialized
INFO - 2024-10-25 15:04:44 --> Loader Class Initialized
INFO - 2024-10-25 15:04:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:04:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:04:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:04:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:04:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:04:44 --> Controller Class Initialized
INFO - 2024-10-25 15:05:06 --> Config Class Initialized
INFO - 2024-10-25 15:05:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:06 --> URI Class Initialized
INFO - 2024-10-25 15:05:06 --> Router Class Initialized
INFO - 2024-10-25 15:05:06 --> Output Class Initialized
INFO - 2024-10-25 15:05:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:06 --> Input Class Initialized
INFO - 2024-10-25 15:05:06 --> Language Class Initialized
INFO - 2024-10-25 15:05:06 --> Language Class Initialized
INFO - 2024-10-25 15:05:06 --> Config Class Initialized
INFO - 2024-10-25 15:05:06 --> Loader Class Initialized
INFO - 2024-10-25 15:05:06 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:06 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:06 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:06 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:06 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:06 --> Controller Class Initialized
ERROR - 2024-10-25 15:05:06 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:05:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:05:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:05:06 --> Final output sent to browser
DEBUG - 2024-10-25 15:05:06 --> Total execution time: 0.0743
INFO - 2024-10-25 15:05:36 --> Config Class Initialized
INFO - 2024-10-25 15:05:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:36 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:36 --> URI Class Initialized
INFO - 2024-10-25 15:05:36 --> Router Class Initialized
INFO - 2024-10-25 15:05:36 --> Output Class Initialized
INFO - 2024-10-25 15:05:36 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:36 --> Input Class Initialized
INFO - 2024-10-25 15:05:36 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Loader Class Initialized
INFO - 2024-10-25 15:05:37 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:37 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:37 --> Controller Class Initialized
INFO - 2024-10-25 15:05:37 --> Upload Class Initialized
INFO - 2024-10-25 15:05:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:05:37 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:37 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:37 --> URI Class Initialized
INFO - 2024-10-25 15:05:37 --> Router Class Initialized
INFO - 2024-10-25 15:05:37 --> Output Class Initialized
INFO - 2024-10-25 15:05:37 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:37 --> Input Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Loader Class Initialized
INFO - 2024-10-25 15:05:37 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:37 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:37 --> Controller Class Initialized
DEBUG - 2024-10-25 15:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:05:37 --> Final output sent to browser
DEBUG - 2024-10-25 15:05:37 --> Total execution time: 0.0515
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:37 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:37 --> URI Class Initialized
INFO - 2024-10-25 15:05:37 --> Router Class Initialized
INFO - 2024-10-25 15:05:37 --> Output Class Initialized
INFO - 2024-10-25 15:05:37 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:37 --> Input Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
ERROR - 2024-10-25 15:05:37 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:37 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:37 --> URI Class Initialized
INFO - 2024-10-25 15:05:37 --> Router Class Initialized
INFO - 2024-10-25 15:05:37 --> Output Class Initialized
INFO - 2024-10-25 15:05:37 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:37 --> Input Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Language Class Initialized
INFO - 2024-10-25 15:05:37 --> Config Class Initialized
INFO - 2024-10-25 15:05:37 --> Loader Class Initialized
INFO - 2024-10-25 15:05:37 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:37 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:37 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:37 --> Controller Class Initialized
INFO - 2024-10-25 15:05:48 --> Config Class Initialized
INFO - 2024-10-25 15:05:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:48 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:48 --> URI Class Initialized
INFO - 2024-10-25 15:05:48 --> Router Class Initialized
INFO - 2024-10-25 15:05:48 --> Output Class Initialized
INFO - 2024-10-25 15:05:48 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:48 --> Input Class Initialized
INFO - 2024-10-25 15:05:48 --> Language Class Initialized
INFO - 2024-10-25 15:05:48 --> Language Class Initialized
INFO - 2024-10-25 15:05:48 --> Config Class Initialized
INFO - 2024-10-25 15:05:48 --> Loader Class Initialized
INFO - 2024-10-25 15:05:48 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:48 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:48 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:48 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:48 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:48 --> Controller Class Initialized
INFO - 2024-10-25 15:05:49 --> Config Class Initialized
INFO - 2024-10-25 15:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:49 --> URI Class Initialized
INFO - 2024-10-25 15:05:49 --> Router Class Initialized
INFO - 2024-10-25 15:05:49 --> Output Class Initialized
INFO - 2024-10-25 15:05:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:49 --> Input Class Initialized
INFO - 2024-10-25 15:05:49 --> Language Class Initialized
INFO - 2024-10-25 15:05:49 --> Language Class Initialized
INFO - 2024-10-25 15:05:49 --> Config Class Initialized
INFO - 2024-10-25 15:05:49 --> Loader Class Initialized
INFO - 2024-10-25 15:05:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:49 --> Controller Class Initialized
INFO - 2024-10-25 15:05:49 --> Config Class Initialized
INFO - 2024-10-25 15:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:49 --> URI Class Initialized
INFO - 2024-10-25 15:05:49 --> Router Class Initialized
INFO - 2024-10-25 15:05:49 --> Output Class Initialized
INFO - 2024-10-25 15:05:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:49 --> Input Class Initialized
INFO - 2024-10-25 15:05:49 --> Language Class Initialized
INFO - 2024-10-25 15:05:49 --> Language Class Initialized
INFO - 2024-10-25 15:05:49 --> Config Class Initialized
INFO - 2024-10-25 15:05:49 --> Loader Class Initialized
INFO - 2024-10-25 15:05:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:50 --> Controller Class Initialized
INFO - 2024-10-25 15:05:50 --> Config Class Initialized
INFO - 2024-10-25 15:05:50 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:50 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:50 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:50 --> URI Class Initialized
INFO - 2024-10-25 15:05:50 --> Router Class Initialized
INFO - 2024-10-25 15:05:50 --> Output Class Initialized
INFO - 2024-10-25 15:05:50 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:50 --> Input Class Initialized
INFO - 2024-10-25 15:05:50 --> Language Class Initialized
INFO - 2024-10-25 15:05:50 --> Language Class Initialized
INFO - 2024-10-25 15:05:50 --> Config Class Initialized
INFO - 2024-10-25 15:05:50 --> Loader Class Initialized
INFO - 2024-10-25 15:05:50 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:50 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:50 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:50 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:50 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:50 --> Controller Class Initialized
INFO - 2024-10-25 15:05:55 --> Config Class Initialized
INFO - 2024-10-25 15:05:55 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:05:55 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:05:55 --> Utf8 Class Initialized
INFO - 2024-10-25 15:05:55 --> URI Class Initialized
INFO - 2024-10-25 15:05:55 --> Router Class Initialized
INFO - 2024-10-25 15:05:55 --> Output Class Initialized
INFO - 2024-10-25 15:05:55 --> Security Class Initialized
DEBUG - 2024-10-25 15:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:05:55 --> Input Class Initialized
INFO - 2024-10-25 15:05:55 --> Language Class Initialized
INFO - 2024-10-25 15:05:55 --> Language Class Initialized
INFO - 2024-10-25 15:05:55 --> Config Class Initialized
INFO - 2024-10-25 15:05:55 --> Loader Class Initialized
INFO - 2024-10-25 15:05:55 --> Helper loaded: url_helper
INFO - 2024-10-25 15:05:55 --> Helper loaded: file_helper
INFO - 2024-10-25 15:05:55 --> Helper loaded: form_helper
INFO - 2024-10-25 15:05:55 --> Helper loaded: my_helper
INFO - 2024-10-25 15:05:55 --> Database Driver Class Initialized
INFO - 2024-10-25 15:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:05:55 --> Controller Class Initialized
ERROR - 2024-10-25 15:05:55 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:05:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:05:55 --> Final output sent to browser
DEBUG - 2024-10-25 15:05:55 --> Total execution time: 0.0317
INFO - 2024-10-25 15:06:31 --> Config Class Initialized
INFO - 2024-10-25 15:06:31 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:31 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:31 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:31 --> URI Class Initialized
INFO - 2024-10-25 15:06:31 --> Router Class Initialized
INFO - 2024-10-25 15:06:31 --> Output Class Initialized
INFO - 2024-10-25 15:06:31 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:31 --> Input Class Initialized
INFO - 2024-10-25 15:06:31 --> Language Class Initialized
INFO - 2024-10-25 15:06:31 --> Language Class Initialized
INFO - 2024-10-25 15:06:31 --> Config Class Initialized
INFO - 2024-10-25 15:06:31 --> Loader Class Initialized
INFO - 2024-10-25 15:06:31 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:31 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:31 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:31 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:31 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:31 --> Controller Class Initialized
INFO - 2024-10-25 15:06:31 --> Upload Class Initialized
INFO - 2024-10-25 15:06:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:06:31 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:06:32 --> Config Class Initialized
INFO - 2024-10-25 15:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:32 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:32 --> URI Class Initialized
INFO - 2024-10-25 15:06:32 --> Router Class Initialized
INFO - 2024-10-25 15:06:32 --> Output Class Initialized
INFO - 2024-10-25 15:06:32 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:32 --> Input Class Initialized
INFO - 2024-10-25 15:06:32 --> Language Class Initialized
INFO - 2024-10-25 15:06:32 --> Language Class Initialized
INFO - 2024-10-25 15:06:32 --> Config Class Initialized
INFO - 2024-10-25 15:06:32 --> Loader Class Initialized
INFO - 2024-10-25 15:06:32 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:32 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:32 --> Controller Class Initialized
DEBUG - 2024-10-25 15:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:06:32 --> Final output sent to browser
DEBUG - 2024-10-25 15:06:32 --> Total execution time: 0.0405
INFO - 2024-10-25 15:06:32 --> Config Class Initialized
INFO - 2024-10-25 15:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:32 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:32 --> URI Class Initialized
INFO - 2024-10-25 15:06:32 --> Router Class Initialized
INFO - 2024-10-25 15:06:32 --> Output Class Initialized
INFO - 2024-10-25 15:06:32 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:32 --> Input Class Initialized
INFO - 2024-10-25 15:06:32 --> Language Class Initialized
ERROR - 2024-10-25 15:06:32 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:06:32 --> Config Class Initialized
INFO - 2024-10-25 15:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:32 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:32 --> URI Class Initialized
INFO - 2024-10-25 15:06:32 --> Router Class Initialized
INFO - 2024-10-25 15:06:32 --> Output Class Initialized
INFO - 2024-10-25 15:06:32 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:32 --> Input Class Initialized
INFO - 2024-10-25 15:06:32 --> Language Class Initialized
INFO - 2024-10-25 15:06:32 --> Language Class Initialized
INFO - 2024-10-25 15:06:32 --> Config Class Initialized
INFO - 2024-10-25 15:06:32 --> Loader Class Initialized
INFO - 2024-10-25 15:06:32 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:32 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:32 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:32 --> Controller Class Initialized
INFO - 2024-10-25 15:06:41 --> Config Class Initialized
INFO - 2024-10-25 15:06:41 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:41 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:41 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:41 --> URI Class Initialized
INFO - 2024-10-25 15:06:41 --> Router Class Initialized
INFO - 2024-10-25 15:06:41 --> Output Class Initialized
INFO - 2024-10-25 15:06:41 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:41 --> Input Class Initialized
INFO - 2024-10-25 15:06:41 --> Language Class Initialized
INFO - 2024-10-25 15:06:41 --> Language Class Initialized
INFO - 2024-10-25 15:06:41 --> Config Class Initialized
INFO - 2024-10-25 15:06:41 --> Loader Class Initialized
INFO - 2024-10-25 15:06:41 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:41 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:41 --> Controller Class Initialized
INFO - 2024-10-25 15:06:41 --> Config Class Initialized
INFO - 2024-10-25 15:06:41 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:41 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:41 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:41 --> URI Class Initialized
INFO - 2024-10-25 15:06:41 --> Router Class Initialized
INFO - 2024-10-25 15:06:41 --> Output Class Initialized
INFO - 2024-10-25 15:06:41 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:41 --> Input Class Initialized
INFO - 2024-10-25 15:06:41 --> Language Class Initialized
INFO - 2024-10-25 15:06:41 --> Language Class Initialized
INFO - 2024-10-25 15:06:41 --> Config Class Initialized
INFO - 2024-10-25 15:06:41 --> Loader Class Initialized
INFO - 2024-10-25 15:06:41 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:41 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:41 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:41 --> Controller Class Initialized
INFO - 2024-10-25 15:06:42 --> Config Class Initialized
INFO - 2024-10-25 15:06:42 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:42 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:42 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:42 --> URI Class Initialized
INFO - 2024-10-25 15:06:42 --> Router Class Initialized
INFO - 2024-10-25 15:06:42 --> Output Class Initialized
INFO - 2024-10-25 15:06:42 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:42 --> Input Class Initialized
INFO - 2024-10-25 15:06:42 --> Language Class Initialized
INFO - 2024-10-25 15:06:42 --> Language Class Initialized
INFO - 2024-10-25 15:06:42 --> Config Class Initialized
INFO - 2024-10-25 15:06:42 --> Loader Class Initialized
INFO - 2024-10-25 15:06:42 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:42 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:42 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:42 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:42 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:42 --> Controller Class Initialized
INFO - 2024-10-25 15:06:44 --> Config Class Initialized
INFO - 2024-10-25 15:06:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:06:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:06:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:06:44 --> URI Class Initialized
INFO - 2024-10-25 15:06:44 --> Router Class Initialized
INFO - 2024-10-25 15:06:44 --> Output Class Initialized
INFO - 2024-10-25 15:06:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:06:44 --> Input Class Initialized
INFO - 2024-10-25 15:06:44 --> Language Class Initialized
INFO - 2024-10-25 15:06:44 --> Language Class Initialized
INFO - 2024-10-25 15:06:44 --> Config Class Initialized
INFO - 2024-10-25 15:06:44 --> Loader Class Initialized
INFO - 2024-10-25 15:06:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:06:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:06:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:06:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:06:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:06:44 --> Controller Class Initialized
ERROR - 2024-10-25 15:06:44 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:06:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:06:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:06:44 --> Final output sent to browser
DEBUG - 2024-10-25 15:06:44 --> Total execution time: 0.0343
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:13 --> URI Class Initialized
INFO - 2024-10-25 15:07:13 --> Router Class Initialized
INFO - 2024-10-25 15:07:13 --> Output Class Initialized
INFO - 2024-10-25 15:07:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:13 --> Input Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Loader Class Initialized
INFO - 2024-10-25 15:07:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:13 --> Controller Class Initialized
INFO - 2024-10-25 15:07:13 --> Upload Class Initialized
INFO - 2024-10-25 15:07:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:07:13 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:13 --> URI Class Initialized
INFO - 2024-10-25 15:07:13 --> Router Class Initialized
INFO - 2024-10-25 15:07:13 --> Output Class Initialized
INFO - 2024-10-25 15:07:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:13 --> Input Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Loader Class Initialized
INFO - 2024-10-25 15:07:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:13 --> Controller Class Initialized
DEBUG - 2024-10-25 15:07:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:07:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:07:13 --> Final output sent to browser
DEBUG - 2024-10-25 15:07:13 --> Total execution time: 0.0337
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:13 --> URI Class Initialized
INFO - 2024-10-25 15:07:13 --> Router Class Initialized
INFO - 2024-10-25 15:07:13 --> Output Class Initialized
INFO - 2024-10-25 15:07:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:13 --> Input Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
ERROR - 2024-10-25 15:07:13 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:13 --> URI Class Initialized
INFO - 2024-10-25 15:07:13 --> Router Class Initialized
INFO - 2024-10-25 15:07:13 --> Output Class Initialized
INFO - 2024-10-25 15:07:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:13 --> Input Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Language Class Initialized
INFO - 2024-10-25 15:07:13 --> Config Class Initialized
INFO - 2024-10-25 15:07:13 --> Loader Class Initialized
INFO - 2024-10-25 15:07:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:13 --> Controller Class Initialized
INFO - 2024-10-25 15:07:46 --> Config Class Initialized
INFO - 2024-10-25 15:07:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:46 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:46 --> URI Class Initialized
INFO - 2024-10-25 15:07:46 --> Router Class Initialized
INFO - 2024-10-25 15:07:46 --> Output Class Initialized
INFO - 2024-10-25 15:07:46 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:46 --> Input Class Initialized
INFO - 2024-10-25 15:07:46 --> Language Class Initialized
INFO - 2024-10-25 15:07:46 --> Language Class Initialized
INFO - 2024-10-25 15:07:46 --> Config Class Initialized
INFO - 2024-10-25 15:07:46 --> Loader Class Initialized
INFO - 2024-10-25 15:07:46 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:46 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:46 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:46 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:46 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:46 --> Controller Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:47 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:47 --> URI Class Initialized
INFO - 2024-10-25 15:07:47 --> Router Class Initialized
INFO - 2024-10-25 15:07:47 --> Output Class Initialized
INFO - 2024-10-25 15:07:47 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:47 --> Input Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Loader Class Initialized
INFO - 2024-10-25 15:07:47 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:47 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:47 --> Controller Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:47 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:47 --> URI Class Initialized
INFO - 2024-10-25 15:07:47 --> Router Class Initialized
INFO - 2024-10-25 15:07:47 --> Output Class Initialized
INFO - 2024-10-25 15:07:47 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:47 --> Input Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Loader Class Initialized
INFO - 2024-10-25 15:07:47 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:47 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:47 --> Controller Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:47 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:47 --> URI Class Initialized
INFO - 2024-10-25 15:07:47 --> Router Class Initialized
INFO - 2024-10-25 15:07:47 --> Output Class Initialized
INFO - 2024-10-25 15:07:47 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:47 --> Input Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Language Class Initialized
INFO - 2024-10-25 15:07:47 --> Config Class Initialized
INFO - 2024-10-25 15:07:47 --> Loader Class Initialized
INFO - 2024-10-25 15:07:47 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:47 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:47 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:47 --> Controller Class Initialized
INFO - 2024-10-25 15:07:50 --> Config Class Initialized
INFO - 2024-10-25 15:07:50 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:07:50 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:07:50 --> Utf8 Class Initialized
INFO - 2024-10-25 15:07:50 --> URI Class Initialized
INFO - 2024-10-25 15:07:50 --> Router Class Initialized
INFO - 2024-10-25 15:07:50 --> Output Class Initialized
INFO - 2024-10-25 15:07:50 --> Security Class Initialized
DEBUG - 2024-10-25 15:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:07:50 --> Input Class Initialized
INFO - 2024-10-25 15:07:50 --> Language Class Initialized
INFO - 2024-10-25 15:07:50 --> Language Class Initialized
INFO - 2024-10-25 15:07:50 --> Config Class Initialized
INFO - 2024-10-25 15:07:50 --> Loader Class Initialized
INFO - 2024-10-25 15:07:50 --> Helper loaded: url_helper
INFO - 2024-10-25 15:07:50 --> Helper loaded: file_helper
INFO - 2024-10-25 15:07:50 --> Helper loaded: form_helper
INFO - 2024-10-25 15:07:50 --> Helper loaded: my_helper
INFO - 2024-10-25 15:07:50 --> Database Driver Class Initialized
INFO - 2024-10-25 15:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:07:50 --> Controller Class Initialized
ERROR - 2024-10-25 15:07:50 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:07:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:07:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:07:50 --> Final output sent to browser
DEBUG - 2024-10-25 15:07:50 --> Total execution time: 0.0321
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:15 --> URI Class Initialized
INFO - 2024-10-25 15:08:15 --> Router Class Initialized
INFO - 2024-10-25 15:08:15 --> Output Class Initialized
INFO - 2024-10-25 15:08:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:15 --> Input Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Loader Class Initialized
INFO - 2024-10-25 15:08:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:15 --> Controller Class Initialized
INFO - 2024-10-25 15:08:15 --> Upload Class Initialized
INFO - 2024-10-25 15:08:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:08:15 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:15 --> URI Class Initialized
INFO - 2024-10-25 15:08:15 --> Router Class Initialized
INFO - 2024-10-25 15:08:15 --> Output Class Initialized
INFO - 2024-10-25 15:08:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:15 --> Input Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Loader Class Initialized
INFO - 2024-10-25 15:08:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:15 --> Controller Class Initialized
DEBUG - 2024-10-25 15:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:08:15 --> Final output sent to browser
DEBUG - 2024-10-25 15:08:15 --> Total execution time: 0.0945
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:15 --> URI Class Initialized
INFO - 2024-10-25 15:08:15 --> Router Class Initialized
INFO - 2024-10-25 15:08:15 --> Output Class Initialized
INFO - 2024-10-25 15:08:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:15 --> Input Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
ERROR - 2024-10-25 15:08:15 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:15 --> URI Class Initialized
INFO - 2024-10-25 15:08:15 --> Router Class Initialized
INFO - 2024-10-25 15:08:15 --> Output Class Initialized
INFO - 2024-10-25 15:08:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:15 --> Input Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Language Class Initialized
INFO - 2024-10-25 15:08:15 --> Config Class Initialized
INFO - 2024-10-25 15:08:15 --> Loader Class Initialized
INFO - 2024-10-25 15:08:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:15 --> Controller Class Initialized
INFO - 2024-10-25 15:08:19 --> Config Class Initialized
INFO - 2024-10-25 15:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:19 --> URI Class Initialized
INFO - 2024-10-25 15:08:19 --> Router Class Initialized
INFO - 2024-10-25 15:08:19 --> Output Class Initialized
INFO - 2024-10-25 15:08:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:19 --> Input Class Initialized
INFO - 2024-10-25 15:08:19 --> Language Class Initialized
INFO - 2024-10-25 15:08:19 --> Language Class Initialized
INFO - 2024-10-25 15:08:19 --> Config Class Initialized
INFO - 2024-10-25 15:08:19 --> Loader Class Initialized
INFO - 2024-10-25 15:08:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:19 --> Controller Class Initialized
INFO - 2024-10-25 15:08:19 --> Config Class Initialized
INFO - 2024-10-25 15:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:19 --> URI Class Initialized
INFO - 2024-10-25 15:08:19 --> Router Class Initialized
INFO - 2024-10-25 15:08:19 --> Output Class Initialized
INFO - 2024-10-25 15:08:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:19 --> Input Class Initialized
INFO - 2024-10-25 15:08:19 --> Language Class Initialized
INFO - 2024-10-25 15:08:19 --> Language Class Initialized
INFO - 2024-10-25 15:08:19 --> Config Class Initialized
INFO - 2024-10-25 15:08:19 --> Loader Class Initialized
INFO - 2024-10-25 15:08:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:19 --> Controller Class Initialized
INFO - 2024-10-25 15:08:20 --> Config Class Initialized
INFO - 2024-10-25 15:08:20 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:20 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:20 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:20 --> URI Class Initialized
INFO - 2024-10-25 15:08:20 --> Router Class Initialized
INFO - 2024-10-25 15:08:20 --> Output Class Initialized
INFO - 2024-10-25 15:08:20 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:20 --> Input Class Initialized
INFO - 2024-10-25 15:08:20 --> Language Class Initialized
INFO - 2024-10-25 15:08:20 --> Language Class Initialized
INFO - 2024-10-25 15:08:20 --> Config Class Initialized
INFO - 2024-10-25 15:08:20 --> Loader Class Initialized
INFO - 2024-10-25 15:08:20 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:20 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:20 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:20 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:20 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:20 --> Controller Class Initialized
INFO - 2024-10-25 15:08:26 --> Config Class Initialized
INFO - 2024-10-25 15:08:26 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:08:26 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:08:26 --> Utf8 Class Initialized
INFO - 2024-10-25 15:08:26 --> URI Class Initialized
INFO - 2024-10-25 15:08:26 --> Router Class Initialized
INFO - 2024-10-25 15:08:26 --> Output Class Initialized
INFO - 2024-10-25 15:08:26 --> Security Class Initialized
DEBUG - 2024-10-25 15:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:08:26 --> Input Class Initialized
INFO - 2024-10-25 15:08:26 --> Language Class Initialized
INFO - 2024-10-25 15:08:26 --> Language Class Initialized
INFO - 2024-10-25 15:08:26 --> Config Class Initialized
INFO - 2024-10-25 15:08:26 --> Loader Class Initialized
INFO - 2024-10-25 15:08:26 --> Helper loaded: url_helper
INFO - 2024-10-25 15:08:26 --> Helper loaded: file_helper
INFO - 2024-10-25 15:08:26 --> Helper loaded: form_helper
INFO - 2024-10-25 15:08:26 --> Helper loaded: my_helper
INFO - 2024-10-25 15:08:26 --> Database Driver Class Initialized
INFO - 2024-10-25 15:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:08:26 --> Controller Class Initialized
ERROR - 2024-10-25 15:08:26 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:08:26 --> Final output sent to browser
DEBUG - 2024-10-25 15:08:26 --> Total execution time: 0.0437
INFO - 2024-10-25 15:12:59 --> Config Class Initialized
INFO - 2024-10-25 15:12:59 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:12:59 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:12:59 --> Utf8 Class Initialized
INFO - 2024-10-25 15:12:59 --> URI Class Initialized
INFO - 2024-10-25 15:12:59 --> Router Class Initialized
INFO - 2024-10-25 15:12:59 --> Output Class Initialized
INFO - 2024-10-25 15:12:59 --> Security Class Initialized
DEBUG - 2024-10-25 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:12:59 --> Input Class Initialized
INFO - 2024-10-25 15:12:59 --> Language Class Initialized
INFO - 2024-10-25 15:12:59 --> Language Class Initialized
INFO - 2024-10-25 15:12:59 --> Config Class Initialized
INFO - 2024-10-25 15:12:59 --> Loader Class Initialized
INFO - 2024-10-25 15:12:59 --> Helper loaded: url_helper
INFO - 2024-10-25 15:12:59 --> Helper loaded: file_helper
INFO - 2024-10-25 15:12:59 --> Helper loaded: form_helper
INFO - 2024-10-25 15:12:59 --> Helper loaded: my_helper
INFO - 2024-10-25 15:12:59 --> Database Driver Class Initialized
INFO - 2024-10-25 15:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:12:59 --> Controller Class Initialized
INFO - 2024-10-25 15:12:59 --> Upload Class Initialized
INFO - 2024-10-25 15:12:59 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:12:59 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:13:00 --> Config Class Initialized
INFO - 2024-10-25 15:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:00 --> URI Class Initialized
INFO - 2024-10-25 15:13:00 --> Router Class Initialized
INFO - 2024-10-25 15:13:00 --> Output Class Initialized
INFO - 2024-10-25 15:13:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:00 --> Input Class Initialized
INFO - 2024-10-25 15:13:00 --> Language Class Initialized
INFO - 2024-10-25 15:13:00 --> Language Class Initialized
INFO - 2024-10-25 15:13:00 --> Config Class Initialized
INFO - 2024-10-25 15:13:00 --> Loader Class Initialized
INFO - 2024-10-25 15:13:00 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:00 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:00 --> Controller Class Initialized
DEBUG - 2024-10-25 15:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:13:00 --> Final output sent to browser
DEBUG - 2024-10-25 15:13:00 --> Total execution time: 0.0354
INFO - 2024-10-25 15:13:00 --> Config Class Initialized
INFO - 2024-10-25 15:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:00 --> URI Class Initialized
INFO - 2024-10-25 15:13:00 --> Router Class Initialized
INFO - 2024-10-25 15:13:00 --> Output Class Initialized
INFO - 2024-10-25 15:13:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:00 --> Input Class Initialized
INFO - 2024-10-25 15:13:00 --> Language Class Initialized
ERROR - 2024-10-25 15:13:00 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:13:00 --> Config Class Initialized
INFO - 2024-10-25 15:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:00 --> URI Class Initialized
INFO - 2024-10-25 15:13:00 --> Router Class Initialized
INFO - 2024-10-25 15:13:00 --> Output Class Initialized
INFO - 2024-10-25 15:13:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:00 --> Input Class Initialized
INFO - 2024-10-25 15:13:00 --> Language Class Initialized
INFO - 2024-10-25 15:13:00 --> Language Class Initialized
INFO - 2024-10-25 15:13:00 --> Config Class Initialized
INFO - 2024-10-25 15:13:00 --> Loader Class Initialized
INFO - 2024-10-25 15:13:00 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:00 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:00 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:00 --> Controller Class Initialized
INFO - 2024-10-25 15:13:04 --> Config Class Initialized
INFO - 2024-10-25 15:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:04 --> URI Class Initialized
INFO - 2024-10-25 15:13:04 --> Router Class Initialized
INFO - 2024-10-25 15:13:04 --> Output Class Initialized
INFO - 2024-10-25 15:13:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:04 --> Input Class Initialized
INFO - 2024-10-25 15:13:04 --> Language Class Initialized
INFO - 2024-10-25 15:13:04 --> Language Class Initialized
INFO - 2024-10-25 15:13:04 --> Config Class Initialized
INFO - 2024-10-25 15:13:04 --> Loader Class Initialized
INFO - 2024-10-25 15:13:04 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:04 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:04 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:04 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:04 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:04 --> Controller Class Initialized
INFO - 2024-10-25 15:13:05 --> Config Class Initialized
INFO - 2024-10-25 15:13:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:05 --> URI Class Initialized
INFO - 2024-10-25 15:13:05 --> Router Class Initialized
INFO - 2024-10-25 15:13:05 --> Output Class Initialized
INFO - 2024-10-25 15:13:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:05 --> Input Class Initialized
INFO - 2024-10-25 15:13:05 --> Language Class Initialized
INFO - 2024-10-25 15:13:05 --> Language Class Initialized
INFO - 2024-10-25 15:13:05 --> Config Class Initialized
INFO - 2024-10-25 15:13:05 --> Loader Class Initialized
INFO - 2024-10-25 15:13:05 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:05 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:05 --> Controller Class Initialized
INFO - 2024-10-25 15:13:05 --> Config Class Initialized
INFO - 2024-10-25 15:13:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:05 --> URI Class Initialized
INFO - 2024-10-25 15:13:05 --> Router Class Initialized
INFO - 2024-10-25 15:13:05 --> Output Class Initialized
INFO - 2024-10-25 15:13:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:05 --> Input Class Initialized
INFO - 2024-10-25 15:13:05 --> Language Class Initialized
INFO - 2024-10-25 15:13:05 --> Language Class Initialized
INFO - 2024-10-25 15:13:05 --> Config Class Initialized
INFO - 2024-10-25 15:13:05 --> Loader Class Initialized
INFO - 2024-10-25 15:13:05 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:05 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:05 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:05 --> Controller Class Initialized
INFO - 2024-10-25 15:13:45 --> Config Class Initialized
INFO - 2024-10-25 15:13:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:13:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:13:45 --> Utf8 Class Initialized
INFO - 2024-10-25 15:13:45 --> URI Class Initialized
INFO - 2024-10-25 15:13:45 --> Router Class Initialized
INFO - 2024-10-25 15:13:45 --> Output Class Initialized
INFO - 2024-10-25 15:13:45 --> Security Class Initialized
DEBUG - 2024-10-25 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:13:45 --> Input Class Initialized
INFO - 2024-10-25 15:13:45 --> Language Class Initialized
INFO - 2024-10-25 15:13:45 --> Language Class Initialized
INFO - 2024-10-25 15:13:45 --> Config Class Initialized
INFO - 2024-10-25 15:13:45 --> Loader Class Initialized
INFO - 2024-10-25 15:13:45 --> Helper loaded: url_helper
INFO - 2024-10-25 15:13:45 --> Helper loaded: file_helper
INFO - 2024-10-25 15:13:45 --> Helper loaded: form_helper
INFO - 2024-10-25 15:13:45 --> Helper loaded: my_helper
INFO - 2024-10-25 15:13:45 --> Database Driver Class Initialized
INFO - 2024-10-25 15:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:13:45 --> Controller Class Initialized
ERROR - 2024-10-25 15:13:45 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:13:45 --> Final output sent to browser
DEBUG - 2024-10-25 15:13:45 --> Total execution time: 0.0354
INFO - 2024-10-25 15:14:12 --> Config Class Initialized
INFO - 2024-10-25 15:14:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:12 --> URI Class Initialized
INFO - 2024-10-25 15:14:12 --> Router Class Initialized
INFO - 2024-10-25 15:14:12 --> Output Class Initialized
INFO - 2024-10-25 15:14:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:12 --> Input Class Initialized
INFO - 2024-10-25 15:14:12 --> Language Class Initialized
INFO - 2024-10-25 15:14:12 --> Language Class Initialized
INFO - 2024-10-25 15:14:12 --> Config Class Initialized
INFO - 2024-10-25 15:14:12 --> Loader Class Initialized
INFO - 2024-10-25 15:14:12 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:12 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:12 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:12 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:12 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:12 --> Controller Class Initialized
INFO - 2024-10-25 15:14:12 --> Upload Class Initialized
INFO - 2024-10-25 15:14:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:14:12 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:14:12 --> Config Class Initialized
INFO - 2024-10-25 15:14:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:12 --> URI Class Initialized
INFO - 2024-10-25 15:14:12 --> Router Class Initialized
INFO - 2024-10-25 15:14:12 --> Output Class Initialized
INFO - 2024-10-25 15:14:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:12 --> Input Class Initialized
INFO - 2024-10-25 15:14:13 --> Language Class Initialized
INFO - 2024-10-25 15:14:13 --> Language Class Initialized
INFO - 2024-10-25 15:14:13 --> Config Class Initialized
INFO - 2024-10-25 15:14:13 --> Loader Class Initialized
INFO - 2024-10-25 15:14:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:13 --> Controller Class Initialized
DEBUG - 2024-10-25 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:14:13 --> Final output sent to browser
DEBUG - 2024-10-25 15:14:13 --> Total execution time: 0.0300
INFO - 2024-10-25 15:14:13 --> Config Class Initialized
INFO - 2024-10-25 15:14:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:13 --> URI Class Initialized
INFO - 2024-10-25 15:14:13 --> Router Class Initialized
INFO - 2024-10-25 15:14:13 --> Output Class Initialized
INFO - 2024-10-25 15:14:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:13 --> Input Class Initialized
INFO - 2024-10-25 15:14:13 --> Language Class Initialized
ERROR - 2024-10-25 15:14:13 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:14:13 --> Config Class Initialized
INFO - 2024-10-25 15:14:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:13 --> URI Class Initialized
INFO - 2024-10-25 15:14:13 --> Router Class Initialized
INFO - 2024-10-25 15:14:13 --> Output Class Initialized
INFO - 2024-10-25 15:14:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:13 --> Input Class Initialized
INFO - 2024-10-25 15:14:13 --> Language Class Initialized
INFO - 2024-10-25 15:14:13 --> Language Class Initialized
INFO - 2024-10-25 15:14:13 --> Config Class Initialized
INFO - 2024-10-25 15:14:13 --> Loader Class Initialized
INFO - 2024-10-25 15:14:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:13 --> Controller Class Initialized
INFO - 2024-10-25 15:14:24 --> Config Class Initialized
INFO - 2024-10-25 15:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:24 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:24 --> URI Class Initialized
INFO - 2024-10-25 15:14:24 --> Router Class Initialized
INFO - 2024-10-25 15:14:24 --> Output Class Initialized
INFO - 2024-10-25 15:14:24 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:24 --> Input Class Initialized
INFO - 2024-10-25 15:14:24 --> Language Class Initialized
INFO - 2024-10-25 15:14:24 --> Language Class Initialized
INFO - 2024-10-25 15:14:24 --> Config Class Initialized
INFO - 2024-10-25 15:14:24 --> Loader Class Initialized
INFO - 2024-10-25 15:14:24 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:24 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:24 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:24 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:24 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:24 --> Controller Class Initialized
INFO - 2024-10-25 15:14:25 --> Config Class Initialized
INFO - 2024-10-25 15:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:25 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:25 --> URI Class Initialized
INFO - 2024-10-25 15:14:25 --> Router Class Initialized
INFO - 2024-10-25 15:14:25 --> Output Class Initialized
INFO - 2024-10-25 15:14:25 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:25 --> Input Class Initialized
INFO - 2024-10-25 15:14:25 --> Language Class Initialized
INFO - 2024-10-25 15:14:25 --> Language Class Initialized
INFO - 2024-10-25 15:14:25 --> Config Class Initialized
INFO - 2024-10-25 15:14:25 --> Loader Class Initialized
INFO - 2024-10-25 15:14:25 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:25 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:25 --> Controller Class Initialized
INFO - 2024-10-25 15:14:25 --> Config Class Initialized
INFO - 2024-10-25 15:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:25 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:25 --> URI Class Initialized
INFO - 2024-10-25 15:14:25 --> Router Class Initialized
INFO - 2024-10-25 15:14:25 --> Output Class Initialized
INFO - 2024-10-25 15:14:25 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:25 --> Input Class Initialized
INFO - 2024-10-25 15:14:25 --> Language Class Initialized
INFO - 2024-10-25 15:14:25 --> Language Class Initialized
INFO - 2024-10-25 15:14:25 --> Config Class Initialized
INFO - 2024-10-25 15:14:25 --> Loader Class Initialized
INFO - 2024-10-25 15:14:25 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:25 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:25 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:25 --> Controller Class Initialized
INFO - 2024-10-25 15:14:27 --> Config Class Initialized
INFO - 2024-10-25 15:14:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:27 --> URI Class Initialized
INFO - 2024-10-25 15:14:27 --> Router Class Initialized
INFO - 2024-10-25 15:14:27 --> Output Class Initialized
INFO - 2024-10-25 15:14:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:27 --> Input Class Initialized
INFO - 2024-10-25 15:14:27 --> Language Class Initialized
INFO - 2024-10-25 15:14:27 --> Language Class Initialized
INFO - 2024-10-25 15:14:27 --> Config Class Initialized
INFO - 2024-10-25 15:14:27 --> Loader Class Initialized
INFO - 2024-10-25 15:14:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:27 --> Controller Class Initialized
ERROR - 2024-10-25 15:14:27 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:14:27 --> Final output sent to browser
DEBUG - 2024-10-25 15:14:27 --> Total execution time: 0.0401
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:44 --> URI Class Initialized
INFO - 2024-10-25 15:14:44 --> Router Class Initialized
INFO - 2024-10-25 15:14:44 --> Output Class Initialized
INFO - 2024-10-25 15:14:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:44 --> Input Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Loader Class Initialized
INFO - 2024-10-25 15:14:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:44 --> Controller Class Initialized
INFO - 2024-10-25 15:14:44 --> Upload Class Initialized
INFO - 2024-10-25 15:14:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:14:44 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:44 --> URI Class Initialized
INFO - 2024-10-25 15:14:44 --> Router Class Initialized
INFO - 2024-10-25 15:14:44 --> Output Class Initialized
INFO - 2024-10-25 15:14:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:44 --> Input Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Loader Class Initialized
INFO - 2024-10-25 15:14:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:44 --> Controller Class Initialized
DEBUG - 2024-10-25 15:14:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:14:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:14:44 --> Final output sent to browser
DEBUG - 2024-10-25 15:14:44 --> Total execution time: 0.0476
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:44 --> URI Class Initialized
INFO - 2024-10-25 15:14:44 --> Router Class Initialized
INFO - 2024-10-25 15:14:44 --> Output Class Initialized
INFO - 2024-10-25 15:14:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:44 --> Input Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
ERROR - 2024-10-25 15:14:44 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:44 --> URI Class Initialized
INFO - 2024-10-25 15:14:44 --> Router Class Initialized
INFO - 2024-10-25 15:14:44 --> Output Class Initialized
INFO - 2024-10-25 15:14:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:44 --> Input Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Language Class Initialized
INFO - 2024-10-25 15:14:44 --> Config Class Initialized
INFO - 2024-10-25 15:14:44 --> Loader Class Initialized
INFO - 2024-10-25 15:14:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:44 --> Controller Class Initialized
INFO - 2024-10-25 15:14:54 --> Config Class Initialized
INFO - 2024-10-25 15:14:54 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:54 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:54 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:54 --> URI Class Initialized
INFO - 2024-10-25 15:14:54 --> Router Class Initialized
INFO - 2024-10-25 15:14:54 --> Output Class Initialized
INFO - 2024-10-25 15:14:54 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:54 --> Input Class Initialized
INFO - 2024-10-25 15:14:54 --> Language Class Initialized
INFO - 2024-10-25 15:14:54 --> Language Class Initialized
INFO - 2024-10-25 15:14:54 --> Config Class Initialized
INFO - 2024-10-25 15:14:54 --> Loader Class Initialized
INFO - 2024-10-25 15:14:54 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:54 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:54 --> Controller Class Initialized
INFO - 2024-10-25 15:14:54 --> Config Class Initialized
INFO - 2024-10-25 15:14:54 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:54 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:54 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:54 --> URI Class Initialized
INFO - 2024-10-25 15:14:54 --> Router Class Initialized
INFO - 2024-10-25 15:14:54 --> Output Class Initialized
INFO - 2024-10-25 15:14:54 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:54 --> Input Class Initialized
INFO - 2024-10-25 15:14:54 --> Language Class Initialized
INFO - 2024-10-25 15:14:54 --> Language Class Initialized
INFO - 2024-10-25 15:14:54 --> Config Class Initialized
INFO - 2024-10-25 15:14:54 --> Loader Class Initialized
INFO - 2024-10-25 15:14:54 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:54 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:54 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:54 --> Controller Class Initialized
INFO - 2024-10-25 15:14:56 --> Config Class Initialized
INFO - 2024-10-25 15:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:14:56 --> Utf8 Class Initialized
INFO - 2024-10-25 15:14:56 --> URI Class Initialized
INFO - 2024-10-25 15:14:56 --> Router Class Initialized
INFO - 2024-10-25 15:14:56 --> Output Class Initialized
INFO - 2024-10-25 15:14:56 --> Security Class Initialized
DEBUG - 2024-10-25 15:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:14:56 --> Input Class Initialized
INFO - 2024-10-25 15:14:56 --> Language Class Initialized
INFO - 2024-10-25 15:14:56 --> Language Class Initialized
INFO - 2024-10-25 15:14:56 --> Config Class Initialized
INFO - 2024-10-25 15:14:56 --> Loader Class Initialized
INFO - 2024-10-25 15:14:56 --> Helper loaded: url_helper
INFO - 2024-10-25 15:14:56 --> Helper loaded: file_helper
INFO - 2024-10-25 15:14:56 --> Helper loaded: form_helper
INFO - 2024-10-25 15:14:56 --> Helper loaded: my_helper
INFO - 2024-10-25 15:14:56 --> Database Driver Class Initialized
INFO - 2024-10-25 15:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:14:56 --> Controller Class Initialized
ERROR - 2024-10-25 15:14:56 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:14:56 --> Final output sent to browser
DEBUG - 2024-10-25 15:14:56 --> Total execution time: 0.0318
INFO - 2024-10-25 15:15:26 --> Config Class Initialized
INFO - 2024-10-25 15:15:26 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:26 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:26 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:26 --> URI Class Initialized
INFO - 2024-10-25 15:15:26 --> Router Class Initialized
INFO - 2024-10-25 15:15:26 --> Output Class Initialized
INFO - 2024-10-25 15:15:26 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:26 --> Input Class Initialized
INFO - 2024-10-25 15:15:26 --> Language Class Initialized
INFO - 2024-10-25 15:15:26 --> Language Class Initialized
INFO - 2024-10-25 15:15:26 --> Config Class Initialized
INFO - 2024-10-25 15:15:26 --> Loader Class Initialized
INFO - 2024-10-25 15:15:26 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:26 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:26 --> Controller Class Initialized
INFO - 2024-10-25 15:15:26 --> Upload Class Initialized
INFO - 2024-10-25 15:15:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:15:26 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:15:26 --> Config Class Initialized
INFO - 2024-10-25 15:15:26 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:26 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:26 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:26 --> URI Class Initialized
INFO - 2024-10-25 15:15:26 --> Router Class Initialized
INFO - 2024-10-25 15:15:26 --> Output Class Initialized
INFO - 2024-10-25 15:15:26 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:26 --> Input Class Initialized
INFO - 2024-10-25 15:15:26 --> Language Class Initialized
INFO - 2024-10-25 15:15:26 --> Language Class Initialized
INFO - 2024-10-25 15:15:26 --> Config Class Initialized
INFO - 2024-10-25 15:15:26 --> Loader Class Initialized
INFO - 2024-10-25 15:15:26 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:26 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:26 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:26 --> Controller Class Initialized
DEBUG - 2024-10-25 15:15:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:15:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:15:26 --> Final output sent to browser
DEBUG - 2024-10-25 15:15:26 --> Total execution time: 0.0307
INFO - 2024-10-25 15:15:27 --> Config Class Initialized
INFO - 2024-10-25 15:15:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:27 --> URI Class Initialized
INFO - 2024-10-25 15:15:27 --> Router Class Initialized
INFO - 2024-10-25 15:15:27 --> Output Class Initialized
INFO - 2024-10-25 15:15:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:27 --> Input Class Initialized
INFO - 2024-10-25 15:15:27 --> Language Class Initialized
ERROR - 2024-10-25 15:15:27 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:15:27 --> Config Class Initialized
INFO - 2024-10-25 15:15:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:27 --> URI Class Initialized
INFO - 2024-10-25 15:15:27 --> Router Class Initialized
INFO - 2024-10-25 15:15:27 --> Output Class Initialized
INFO - 2024-10-25 15:15:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:27 --> Input Class Initialized
INFO - 2024-10-25 15:15:27 --> Language Class Initialized
INFO - 2024-10-25 15:15:27 --> Language Class Initialized
INFO - 2024-10-25 15:15:27 --> Config Class Initialized
INFO - 2024-10-25 15:15:27 --> Loader Class Initialized
INFO - 2024-10-25 15:15:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:27 --> Controller Class Initialized
INFO - 2024-10-25 15:15:36 --> Config Class Initialized
INFO - 2024-10-25 15:15:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:36 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:36 --> URI Class Initialized
INFO - 2024-10-25 15:15:36 --> Router Class Initialized
INFO - 2024-10-25 15:15:36 --> Output Class Initialized
INFO - 2024-10-25 15:15:36 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:36 --> Input Class Initialized
INFO - 2024-10-25 15:15:36 --> Language Class Initialized
INFO - 2024-10-25 15:15:36 --> Language Class Initialized
INFO - 2024-10-25 15:15:36 --> Config Class Initialized
INFO - 2024-10-25 15:15:36 --> Loader Class Initialized
INFO - 2024-10-25 15:15:36 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:36 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:36 --> Controller Class Initialized
INFO - 2024-10-25 15:15:36 --> Config Class Initialized
INFO - 2024-10-25 15:15:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:36 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:36 --> URI Class Initialized
INFO - 2024-10-25 15:15:36 --> Router Class Initialized
INFO - 2024-10-25 15:15:36 --> Output Class Initialized
INFO - 2024-10-25 15:15:36 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:36 --> Input Class Initialized
INFO - 2024-10-25 15:15:36 --> Language Class Initialized
INFO - 2024-10-25 15:15:36 --> Language Class Initialized
INFO - 2024-10-25 15:15:36 --> Config Class Initialized
INFO - 2024-10-25 15:15:36 --> Loader Class Initialized
INFO - 2024-10-25 15:15:36 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:36 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:36 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:36 --> Controller Class Initialized
INFO - 2024-10-25 15:15:37 --> Config Class Initialized
INFO - 2024-10-25 15:15:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:37 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:37 --> URI Class Initialized
INFO - 2024-10-25 15:15:37 --> Router Class Initialized
INFO - 2024-10-25 15:15:37 --> Output Class Initialized
INFO - 2024-10-25 15:15:37 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:37 --> Input Class Initialized
INFO - 2024-10-25 15:15:37 --> Language Class Initialized
INFO - 2024-10-25 15:15:37 --> Language Class Initialized
INFO - 2024-10-25 15:15:37 --> Config Class Initialized
INFO - 2024-10-25 15:15:37 --> Loader Class Initialized
INFO - 2024-10-25 15:15:37 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:37 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:37 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:37 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:37 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:37 --> Controller Class Initialized
INFO - 2024-10-25 15:15:39 --> Config Class Initialized
INFO - 2024-10-25 15:15:39 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:15:39 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:15:39 --> Utf8 Class Initialized
INFO - 2024-10-25 15:15:39 --> URI Class Initialized
INFO - 2024-10-25 15:15:39 --> Router Class Initialized
INFO - 2024-10-25 15:15:39 --> Output Class Initialized
INFO - 2024-10-25 15:15:39 --> Security Class Initialized
DEBUG - 2024-10-25 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:15:39 --> Input Class Initialized
INFO - 2024-10-25 15:15:39 --> Language Class Initialized
INFO - 2024-10-25 15:15:39 --> Language Class Initialized
INFO - 2024-10-25 15:15:39 --> Config Class Initialized
INFO - 2024-10-25 15:15:39 --> Loader Class Initialized
INFO - 2024-10-25 15:15:39 --> Helper loaded: url_helper
INFO - 2024-10-25 15:15:39 --> Helper loaded: file_helper
INFO - 2024-10-25 15:15:39 --> Helper loaded: form_helper
INFO - 2024-10-25 15:15:39 --> Helper loaded: my_helper
INFO - 2024-10-25 15:15:39 --> Database Driver Class Initialized
INFO - 2024-10-25 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:15:39 --> Controller Class Initialized
ERROR - 2024-10-25 15:15:39 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:15:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:15:39 --> Final output sent to browser
DEBUG - 2024-10-25 15:15:39 --> Total execution time: 0.0358
INFO - 2024-10-25 15:16:14 --> Config Class Initialized
INFO - 2024-10-25 15:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:16:14 --> Utf8 Class Initialized
INFO - 2024-10-25 15:16:14 --> URI Class Initialized
INFO - 2024-10-25 15:16:14 --> Router Class Initialized
INFO - 2024-10-25 15:16:14 --> Output Class Initialized
INFO - 2024-10-25 15:16:14 --> Security Class Initialized
DEBUG - 2024-10-25 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:16:14 --> Input Class Initialized
INFO - 2024-10-25 15:16:14 --> Language Class Initialized
INFO - 2024-10-25 15:16:14 --> Language Class Initialized
INFO - 2024-10-25 15:16:14 --> Config Class Initialized
INFO - 2024-10-25 15:16:14 --> Loader Class Initialized
INFO - 2024-10-25 15:16:14 --> Helper loaded: url_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: file_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: form_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: my_helper
INFO - 2024-10-25 15:16:14 --> Database Driver Class Initialized
INFO - 2024-10-25 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:16:14 --> Controller Class Initialized
INFO - 2024-10-25 15:16:14 --> Upload Class Initialized
INFO - 2024-10-25 15:16:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:16:14 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:16:14 --> Config Class Initialized
INFO - 2024-10-25 15:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:16:14 --> Utf8 Class Initialized
INFO - 2024-10-25 15:16:14 --> URI Class Initialized
INFO - 2024-10-25 15:16:14 --> Router Class Initialized
INFO - 2024-10-25 15:16:14 --> Output Class Initialized
INFO - 2024-10-25 15:16:14 --> Security Class Initialized
DEBUG - 2024-10-25 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:16:14 --> Input Class Initialized
INFO - 2024-10-25 15:16:14 --> Language Class Initialized
INFO - 2024-10-25 15:16:14 --> Language Class Initialized
INFO - 2024-10-25 15:16:14 --> Config Class Initialized
INFO - 2024-10-25 15:16:14 --> Loader Class Initialized
INFO - 2024-10-25 15:16:14 --> Helper loaded: url_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: file_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: form_helper
INFO - 2024-10-25 15:16:14 --> Helper loaded: my_helper
INFO - 2024-10-25 15:16:14 --> Database Driver Class Initialized
INFO - 2024-10-25 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:16:14 --> Controller Class Initialized
DEBUG - 2024-10-25 15:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:16:14 --> Final output sent to browser
DEBUG - 2024-10-25 15:16:14 --> Total execution time: 0.0776
INFO - 2024-10-25 15:16:14 --> Config Class Initialized
INFO - 2024-10-25 15:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:16:14 --> Utf8 Class Initialized
INFO - 2024-10-25 15:16:14 --> URI Class Initialized
INFO - 2024-10-25 15:16:14 --> Router Class Initialized
INFO - 2024-10-25 15:16:14 --> Output Class Initialized
INFO - 2024-10-25 15:16:14 --> Security Class Initialized
DEBUG - 2024-10-25 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:16:14 --> Input Class Initialized
INFO - 2024-10-25 15:16:14 --> Language Class Initialized
ERROR - 2024-10-25 15:16:14 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:16:15 --> Config Class Initialized
INFO - 2024-10-25 15:16:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:16:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:16:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:16:15 --> URI Class Initialized
INFO - 2024-10-25 15:16:15 --> Router Class Initialized
INFO - 2024-10-25 15:16:15 --> Output Class Initialized
INFO - 2024-10-25 15:16:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:16:15 --> Input Class Initialized
INFO - 2024-10-25 15:16:15 --> Language Class Initialized
INFO - 2024-10-25 15:16:15 --> Language Class Initialized
INFO - 2024-10-25 15:16:15 --> Config Class Initialized
INFO - 2024-10-25 15:16:15 --> Loader Class Initialized
INFO - 2024-10-25 15:16:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:16:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:16:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:16:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:16:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:16:15 --> Controller Class Initialized
INFO - 2024-10-25 15:23:08 --> Config Class Initialized
INFO - 2024-10-25 15:23:08 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:08 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:08 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:08 --> URI Class Initialized
INFO - 2024-10-25 15:23:08 --> Router Class Initialized
INFO - 2024-10-25 15:23:08 --> Output Class Initialized
INFO - 2024-10-25 15:23:08 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:08 --> Input Class Initialized
INFO - 2024-10-25 15:23:08 --> Language Class Initialized
INFO - 2024-10-25 15:23:08 --> Language Class Initialized
INFO - 2024-10-25 15:23:08 --> Config Class Initialized
INFO - 2024-10-25 15:23:08 --> Loader Class Initialized
INFO - 2024-10-25 15:23:08 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:08 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:08 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:08 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:08 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:08 --> Controller Class Initialized
INFO - 2024-10-25 15:23:09 --> Config Class Initialized
INFO - 2024-10-25 15:23:09 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:09 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:09 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:09 --> URI Class Initialized
INFO - 2024-10-25 15:23:09 --> Router Class Initialized
INFO - 2024-10-25 15:23:09 --> Output Class Initialized
INFO - 2024-10-25 15:23:09 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:09 --> Input Class Initialized
INFO - 2024-10-25 15:23:09 --> Language Class Initialized
INFO - 2024-10-25 15:23:09 --> Language Class Initialized
INFO - 2024-10-25 15:23:09 --> Config Class Initialized
INFO - 2024-10-25 15:23:09 --> Loader Class Initialized
INFO - 2024-10-25 15:23:09 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:09 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:09 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:09 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:09 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:09 --> Controller Class Initialized
INFO - 2024-10-25 15:23:17 --> Config Class Initialized
INFO - 2024-10-25 15:23:17 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:17 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:17 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:17 --> URI Class Initialized
INFO - 2024-10-25 15:23:17 --> Router Class Initialized
INFO - 2024-10-25 15:23:17 --> Output Class Initialized
INFO - 2024-10-25 15:23:17 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:17 --> Input Class Initialized
INFO - 2024-10-25 15:23:17 --> Language Class Initialized
INFO - 2024-10-25 15:23:17 --> Language Class Initialized
INFO - 2024-10-25 15:23:17 --> Config Class Initialized
INFO - 2024-10-25 15:23:17 --> Loader Class Initialized
INFO - 2024-10-25 15:23:18 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:18 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:18 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:18 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:18 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:18 --> Controller Class Initialized
ERROR - 2024-10-25 15:23:18 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:23:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:23:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:23:18 --> Final output sent to browser
DEBUG - 2024-10-25 15:23:18 --> Total execution time: 0.0410
INFO - 2024-10-25 15:23:23 --> Config Class Initialized
INFO - 2024-10-25 15:23:23 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:23 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:23 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:23 --> URI Class Initialized
INFO - 2024-10-25 15:23:23 --> Router Class Initialized
INFO - 2024-10-25 15:23:23 --> Output Class Initialized
INFO - 2024-10-25 15:23:23 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:23 --> Input Class Initialized
INFO - 2024-10-25 15:23:23 --> Language Class Initialized
INFO - 2024-10-25 15:23:23 --> Language Class Initialized
INFO - 2024-10-25 15:23:23 --> Config Class Initialized
INFO - 2024-10-25 15:23:23 --> Loader Class Initialized
INFO - 2024-10-25 15:23:23 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:23 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:23 --> Controller Class Initialized
DEBUG - 2024-10-25 15:23:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:23:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:23:23 --> Final output sent to browser
DEBUG - 2024-10-25 15:23:23 --> Total execution time: 0.0317
INFO - 2024-10-25 15:23:23 --> Config Class Initialized
INFO - 2024-10-25 15:23:23 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:23 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:23 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:23 --> URI Class Initialized
INFO - 2024-10-25 15:23:23 --> Router Class Initialized
INFO - 2024-10-25 15:23:23 --> Output Class Initialized
INFO - 2024-10-25 15:23:23 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:23 --> Input Class Initialized
INFO - 2024-10-25 15:23:23 --> Language Class Initialized
INFO - 2024-10-25 15:23:23 --> Language Class Initialized
INFO - 2024-10-25 15:23:23 --> Config Class Initialized
INFO - 2024-10-25 15:23:23 --> Loader Class Initialized
INFO - 2024-10-25 15:23:23 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:23 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:23 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:23 --> Controller Class Initialized
INFO - 2024-10-25 15:23:28 --> Config Class Initialized
INFO - 2024-10-25 15:23:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:28 --> URI Class Initialized
INFO - 2024-10-25 15:23:28 --> Router Class Initialized
INFO - 2024-10-25 15:23:28 --> Output Class Initialized
INFO - 2024-10-25 15:23:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:28 --> Input Class Initialized
INFO - 2024-10-25 15:23:28 --> Language Class Initialized
INFO - 2024-10-25 15:23:28 --> Language Class Initialized
INFO - 2024-10-25 15:23:28 --> Config Class Initialized
INFO - 2024-10-25 15:23:28 --> Loader Class Initialized
INFO - 2024-10-25 15:23:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:28 --> Controller Class Initialized
INFO - 2024-10-25 15:23:28 --> Config Class Initialized
INFO - 2024-10-25 15:23:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:28 --> URI Class Initialized
INFO - 2024-10-25 15:23:28 --> Router Class Initialized
INFO - 2024-10-25 15:23:28 --> Output Class Initialized
INFO - 2024-10-25 15:23:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:28 --> Input Class Initialized
INFO - 2024-10-25 15:23:28 --> Language Class Initialized
INFO - 2024-10-25 15:23:28 --> Language Class Initialized
INFO - 2024-10-25 15:23:28 --> Config Class Initialized
INFO - 2024-10-25 15:23:28 --> Loader Class Initialized
INFO - 2024-10-25 15:23:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:28 --> Controller Class Initialized
INFO - 2024-10-25 15:23:29 --> Config Class Initialized
INFO - 2024-10-25 15:23:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:29 --> URI Class Initialized
INFO - 2024-10-25 15:23:29 --> Router Class Initialized
INFO - 2024-10-25 15:23:29 --> Output Class Initialized
INFO - 2024-10-25 15:23:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:29 --> Input Class Initialized
INFO - 2024-10-25 15:23:29 --> Language Class Initialized
INFO - 2024-10-25 15:23:29 --> Language Class Initialized
INFO - 2024-10-25 15:23:29 --> Config Class Initialized
INFO - 2024-10-25 15:23:29 --> Loader Class Initialized
INFO - 2024-10-25 15:23:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:29 --> Controller Class Initialized
INFO - 2024-10-25 15:23:29 --> Config Class Initialized
INFO - 2024-10-25 15:23:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:29 --> URI Class Initialized
INFO - 2024-10-25 15:23:29 --> Router Class Initialized
INFO - 2024-10-25 15:23:29 --> Output Class Initialized
INFO - 2024-10-25 15:23:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:29 --> Input Class Initialized
INFO - 2024-10-25 15:23:29 --> Language Class Initialized
INFO - 2024-10-25 15:23:29 --> Language Class Initialized
INFO - 2024-10-25 15:23:29 --> Config Class Initialized
INFO - 2024-10-25 15:23:29 --> Loader Class Initialized
INFO - 2024-10-25 15:23:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:29 --> Controller Class Initialized
INFO - 2024-10-25 15:23:31 --> Config Class Initialized
INFO - 2024-10-25 15:23:31 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:23:31 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:23:31 --> Utf8 Class Initialized
INFO - 2024-10-25 15:23:31 --> URI Class Initialized
INFO - 2024-10-25 15:23:31 --> Router Class Initialized
INFO - 2024-10-25 15:23:31 --> Output Class Initialized
INFO - 2024-10-25 15:23:31 --> Security Class Initialized
DEBUG - 2024-10-25 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:23:31 --> Input Class Initialized
INFO - 2024-10-25 15:23:31 --> Language Class Initialized
INFO - 2024-10-25 15:23:31 --> Language Class Initialized
INFO - 2024-10-25 15:23:31 --> Config Class Initialized
INFO - 2024-10-25 15:23:31 --> Loader Class Initialized
INFO - 2024-10-25 15:23:31 --> Helper loaded: url_helper
INFO - 2024-10-25 15:23:31 --> Helper loaded: file_helper
INFO - 2024-10-25 15:23:31 --> Helper loaded: form_helper
INFO - 2024-10-25 15:23:31 --> Helper loaded: my_helper
INFO - 2024-10-25 15:23:31 --> Database Driver Class Initialized
INFO - 2024-10-25 15:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:23:31 --> Controller Class Initialized
ERROR - 2024-10-25 15:23:31 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:23:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:23:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:23:31 --> Final output sent to browser
DEBUG - 2024-10-25 15:23:31 --> Total execution time: 0.0347
INFO - 2024-10-25 15:24:15 --> Config Class Initialized
INFO - 2024-10-25 15:24:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:15 --> URI Class Initialized
INFO - 2024-10-25 15:24:15 --> Router Class Initialized
INFO - 2024-10-25 15:24:15 --> Output Class Initialized
INFO - 2024-10-25 15:24:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:15 --> Input Class Initialized
INFO - 2024-10-25 15:24:15 --> Language Class Initialized
INFO - 2024-10-25 15:24:15 --> Language Class Initialized
INFO - 2024-10-25 15:24:15 --> Config Class Initialized
INFO - 2024-10-25 15:24:15 --> Loader Class Initialized
INFO - 2024-10-25 15:24:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:15 --> Controller Class Initialized
INFO - 2024-10-25 15:24:15 --> Upload Class Initialized
INFO - 2024-10-25 15:24:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:24:15 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:24:15 --> Config Class Initialized
INFO - 2024-10-25 15:24:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:15 --> URI Class Initialized
INFO - 2024-10-25 15:24:15 --> Router Class Initialized
INFO - 2024-10-25 15:24:15 --> Output Class Initialized
INFO - 2024-10-25 15:24:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:15 --> Input Class Initialized
INFO - 2024-10-25 15:24:15 --> Language Class Initialized
INFO - 2024-10-25 15:24:15 --> Language Class Initialized
INFO - 2024-10-25 15:24:15 --> Config Class Initialized
INFO - 2024-10-25 15:24:15 --> Loader Class Initialized
INFO - 2024-10-25 15:24:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:15 --> Controller Class Initialized
DEBUG - 2024-10-25 15:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:24:15 --> Final output sent to browser
DEBUG - 2024-10-25 15:24:15 --> Total execution time: 0.0534
INFO - 2024-10-25 15:24:15 --> Config Class Initialized
INFO - 2024-10-25 15:24:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:15 --> URI Class Initialized
INFO - 2024-10-25 15:24:15 --> Router Class Initialized
INFO - 2024-10-25 15:24:15 --> Output Class Initialized
INFO - 2024-10-25 15:24:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:15 --> Input Class Initialized
INFO - 2024-10-25 15:24:15 --> Language Class Initialized
ERROR - 2024-10-25 15:24:15 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:24:16 --> Config Class Initialized
INFO - 2024-10-25 15:24:16 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:16 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:16 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:16 --> URI Class Initialized
INFO - 2024-10-25 15:24:16 --> Router Class Initialized
INFO - 2024-10-25 15:24:16 --> Output Class Initialized
INFO - 2024-10-25 15:24:16 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:16 --> Input Class Initialized
INFO - 2024-10-25 15:24:16 --> Language Class Initialized
INFO - 2024-10-25 15:24:16 --> Language Class Initialized
INFO - 2024-10-25 15:24:16 --> Config Class Initialized
INFO - 2024-10-25 15:24:16 --> Loader Class Initialized
INFO - 2024-10-25 15:24:16 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:16 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:16 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:16 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:16 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:16 --> Controller Class Initialized
INFO - 2024-10-25 15:24:25 --> Config Class Initialized
INFO - 2024-10-25 15:24:25 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:25 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:25 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:25 --> URI Class Initialized
INFO - 2024-10-25 15:24:25 --> Router Class Initialized
INFO - 2024-10-25 15:24:25 --> Output Class Initialized
INFO - 2024-10-25 15:24:25 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:25 --> Input Class Initialized
INFO - 2024-10-25 15:24:25 --> Language Class Initialized
INFO - 2024-10-25 15:24:25 --> Language Class Initialized
INFO - 2024-10-25 15:24:25 --> Config Class Initialized
INFO - 2024-10-25 15:24:25 --> Loader Class Initialized
INFO - 2024-10-25 15:24:25 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:25 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:25 --> Controller Class Initialized
INFO - 2024-10-25 15:24:25 --> Config Class Initialized
INFO - 2024-10-25 15:24:25 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:25 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:25 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:25 --> URI Class Initialized
INFO - 2024-10-25 15:24:25 --> Router Class Initialized
INFO - 2024-10-25 15:24:25 --> Output Class Initialized
INFO - 2024-10-25 15:24:25 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:25 --> Input Class Initialized
INFO - 2024-10-25 15:24:25 --> Language Class Initialized
INFO - 2024-10-25 15:24:25 --> Language Class Initialized
INFO - 2024-10-25 15:24:25 --> Config Class Initialized
INFO - 2024-10-25 15:24:25 --> Loader Class Initialized
INFO - 2024-10-25 15:24:25 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:25 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:25 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:25 --> Controller Class Initialized
INFO - 2024-10-25 15:24:26 --> Config Class Initialized
INFO - 2024-10-25 15:24:26 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:26 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:26 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:26 --> URI Class Initialized
INFO - 2024-10-25 15:24:26 --> Router Class Initialized
INFO - 2024-10-25 15:24:26 --> Output Class Initialized
INFO - 2024-10-25 15:24:26 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:26 --> Input Class Initialized
INFO - 2024-10-25 15:24:26 --> Language Class Initialized
INFO - 2024-10-25 15:24:26 --> Language Class Initialized
INFO - 2024-10-25 15:24:26 --> Config Class Initialized
INFO - 2024-10-25 15:24:26 --> Loader Class Initialized
INFO - 2024-10-25 15:24:26 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:26 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:26 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:26 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:26 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:26 --> Controller Class Initialized
INFO - 2024-10-25 15:24:27 --> Config Class Initialized
INFO - 2024-10-25 15:24:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:27 --> URI Class Initialized
INFO - 2024-10-25 15:24:27 --> Router Class Initialized
INFO - 2024-10-25 15:24:27 --> Output Class Initialized
INFO - 2024-10-25 15:24:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:27 --> Input Class Initialized
INFO - 2024-10-25 15:24:27 --> Language Class Initialized
INFO - 2024-10-25 15:24:27 --> Language Class Initialized
INFO - 2024-10-25 15:24:27 --> Config Class Initialized
INFO - 2024-10-25 15:24:27 --> Loader Class Initialized
INFO - 2024-10-25 15:24:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:27 --> Controller Class Initialized
ERROR - 2024-10-25 15:24:27 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:24:27 --> Final output sent to browser
DEBUG - 2024-10-25 15:24:27 --> Total execution time: 0.0504
INFO - 2024-10-25 15:24:49 --> Config Class Initialized
INFO - 2024-10-25 15:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:49 --> URI Class Initialized
INFO - 2024-10-25 15:24:49 --> Router Class Initialized
INFO - 2024-10-25 15:24:49 --> Output Class Initialized
INFO - 2024-10-25 15:24:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:49 --> Input Class Initialized
INFO - 2024-10-25 15:24:49 --> Language Class Initialized
INFO - 2024-10-25 15:24:49 --> Language Class Initialized
INFO - 2024-10-25 15:24:49 --> Config Class Initialized
INFO - 2024-10-25 15:24:49 --> Loader Class Initialized
INFO - 2024-10-25 15:24:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:49 --> Controller Class Initialized
INFO - 2024-10-25 15:24:49 --> Upload Class Initialized
INFO - 2024-10-25 15:24:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:24:49 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:24:49 --> Config Class Initialized
INFO - 2024-10-25 15:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:49 --> URI Class Initialized
INFO - 2024-10-25 15:24:49 --> Router Class Initialized
INFO - 2024-10-25 15:24:49 --> Output Class Initialized
INFO - 2024-10-25 15:24:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:49 --> Input Class Initialized
INFO - 2024-10-25 15:24:49 --> Language Class Initialized
INFO - 2024-10-25 15:24:49 --> Language Class Initialized
INFO - 2024-10-25 15:24:49 --> Config Class Initialized
INFO - 2024-10-25 15:24:49 --> Loader Class Initialized
INFO - 2024-10-25 15:24:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:49 --> Controller Class Initialized
DEBUG - 2024-10-25 15:24:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:24:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:24:49 --> Final output sent to browser
DEBUG - 2024-10-25 15:24:49 --> Total execution time: 0.0325
INFO - 2024-10-25 15:24:50 --> Config Class Initialized
INFO - 2024-10-25 15:24:50 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:50 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:50 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:50 --> URI Class Initialized
INFO - 2024-10-25 15:24:50 --> Router Class Initialized
INFO - 2024-10-25 15:24:50 --> Output Class Initialized
INFO - 2024-10-25 15:24:50 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:50 --> Input Class Initialized
INFO - 2024-10-25 15:24:50 --> Language Class Initialized
ERROR - 2024-10-25 15:24:50 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:24:50 --> Config Class Initialized
INFO - 2024-10-25 15:24:50 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:24:50 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:24:50 --> Utf8 Class Initialized
INFO - 2024-10-25 15:24:50 --> URI Class Initialized
INFO - 2024-10-25 15:24:50 --> Router Class Initialized
INFO - 2024-10-25 15:24:50 --> Output Class Initialized
INFO - 2024-10-25 15:24:50 --> Security Class Initialized
DEBUG - 2024-10-25 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:24:50 --> Input Class Initialized
INFO - 2024-10-25 15:24:50 --> Language Class Initialized
INFO - 2024-10-25 15:24:50 --> Language Class Initialized
INFO - 2024-10-25 15:24:50 --> Config Class Initialized
INFO - 2024-10-25 15:24:50 --> Loader Class Initialized
INFO - 2024-10-25 15:24:50 --> Helper loaded: url_helper
INFO - 2024-10-25 15:24:50 --> Helper loaded: file_helper
INFO - 2024-10-25 15:24:50 --> Helper loaded: form_helper
INFO - 2024-10-25 15:24:50 --> Helper loaded: my_helper
INFO - 2024-10-25 15:24:50 --> Database Driver Class Initialized
INFO - 2024-10-25 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:24:50 --> Controller Class Initialized
INFO - 2024-10-25 15:29:05 --> Config Class Initialized
INFO - 2024-10-25 15:29:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:05 --> URI Class Initialized
INFO - 2024-10-25 15:29:05 --> Router Class Initialized
INFO - 2024-10-25 15:29:05 --> Output Class Initialized
INFO - 2024-10-25 15:29:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:05 --> Input Class Initialized
INFO - 2024-10-25 15:29:05 --> Language Class Initialized
INFO - 2024-10-25 15:29:05 --> Language Class Initialized
INFO - 2024-10-25 15:29:05 --> Config Class Initialized
INFO - 2024-10-25 15:29:05 --> Loader Class Initialized
INFO - 2024-10-25 15:29:05 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:05 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:05 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:05 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:05 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:06 --> Controller Class Initialized
DEBUG - 2024-10-25 15:29:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:29:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:29:06 --> Final output sent to browser
DEBUG - 2024-10-25 15:29:06 --> Total execution time: 0.0283
INFO - 2024-10-25 15:29:06 --> Config Class Initialized
INFO - 2024-10-25 15:29:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:06 --> URI Class Initialized
INFO - 2024-10-25 15:29:06 --> Router Class Initialized
INFO - 2024-10-25 15:29:06 --> Output Class Initialized
INFO - 2024-10-25 15:29:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:06 --> Input Class Initialized
INFO - 2024-10-25 15:29:06 --> Language Class Initialized
ERROR - 2024-10-25 15:29:06 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:29:06 --> Config Class Initialized
INFO - 2024-10-25 15:29:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:06 --> URI Class Initialized
INFO - 2024-10-25 15:29:06 --> Router Class Initialized
INFO - 2024-10-25 15:29:06 --> Output Class Initialized
INFO - 2024-10-25 15:29:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:06 --> Input Class Initialized
INFO - 2024-10-25 15:29:06 --> Language Class Initialized
INFO - 2024-10-25 15:29:06 --> Language Class Initialized
INFO - 2024-10-25 15:29:06 --> Config Class Initialized
INFO - 2024-10-25 15:29:06 --> Loader Class Initialized
INFO - 2024-10-25 15:29:06 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:06 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:06 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:06 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:06 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:06 --> Controller Class Initialized
INFO - 2024-10-25 15:29:14 --> Config Class Initialized
INFO - 2024-10-25 15:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:14 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:14 --> URI Class Initialized
INFO - 2024-10-25 15:29:14 --> Router Class Initialized
INFO - 2024-10-25 15:29:14 --> Output Class Initialized
INFO - 2024-10-25 15:29:14 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:14 --> Input Class Initialized
INFO - 2024-10-25 15:29:14 --> Language Class Initialized
INFO - 2024-10-25 15:29:14 --> Language Class Initialized
INFO - 2024-10-25 15:29:14 --> Config Class Initialized
INFO - 2024-10-25 15:29:14 --> Loader Class Initialized
INFO - 2024-10-25 15:29:14 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:14 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:14 --> Controller Class Initialized
INFO - 2024-10-25 15:29:14 --> Config Class Initialized
INFO - 2024-10-25 15:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:14 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:14 --> URI Class Initialized
INFO - 2024-10-25 15:29:14 --> Router Class Initialized
INFO - 2024-10-25 15:29:14 --> Output Class Initialized
INFO - 2024-10-25 15:29:14 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:14 --> Input Class Initialized
INFO - 2024-10-25 15:29:14 --> Language Class Initialized
INFO - 2024-10-25 15:29:14 --> Language Class Initialized
INFO - 2024-10-25 15:29:14 --> Config Class Initialized
INFO - 2024-10-25 15:29:14 --> Loader Class Initialized
INFO - 2024-10-25 15:29:14 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:14 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:14 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:14 --> Controller Class Initialized
INFO - 2024-10-25 15:29:15 --> Config Class Initialized
INFO - 2024-10-25 15:29:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:15 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:15 --> URI Class Initialized
INFO - 2024-10-25 15:29:15 --> Router Class Initialized
INFO - 2024-10-25 15:29:15 --> Output Class Initialized
INFO - 2024-10-25 15:29:15 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:15 --> Input Class Initialized
INFO - 2024-10-25 15:29:15 --> Language Class Initialized
INFO - 2024-10-25 15:29:15 --> Language Class Initialized
INFO - 2024-10-25 15:29:15 --> Config Class Initialized
INFO - 2024-10-25 15:29:15 --> Loader Class Initialized
INFO - 2024-10-25 15:29:15 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:15 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:15 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:15 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:15 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:15 --> Controller Class Initialized
INFO - 2024-10-25 15:29:18 --> Config Class Initialized
INFO - 2024-10-25 15:29:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:18 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:18 --> URI Class Initialized
INFO - 2024-10-25 15:29:18 --> Router Class Initialized
INFO - 2024-10-25 15:29:18 --> Output Class Initialized
INFO - 2024-10-25 15:29:18 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:18 --> Input Class Initialized
INFO - 2024-10-25 15:29:18 --> Language Class Initialized
INFO - 2024-10-25 15:29:18 --> Language Class Initialized
INFO - 2024-10-25 15:29:18 --> Config Class Initialized
INFO - 2024-10-25 15:29:18 --> Loader Class Initialized
INFO - 2024-10-25 15:29:18 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:18 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:18 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:18 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:18 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:18 --> Controller Class Initialized
ERROR - 2024-10-25 15:29:18 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:29:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:29:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:29:18 --> Final output sent to browser
DEBUG - 2024-10-25 15:29:18 --> Total execution time: 0.0352
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:44 --> URI Class Initialized
INFO - 2024-10-25 15:29:44 --> Router Class Initialized
INFO - 2024-10-25 15:29:44 --> Output Class Initialized
INFO - 2024-10-25 15:29:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:44 --> Input Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Loader Class Initialized
INFO - 2024-10-25 15:29:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:44 --> Controller Class Initialized
INFO - 2024-10-25 15:29:44 --> Upload Class Initialized
INFO - 2024-10-25 15:29:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:29:44 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:44 --> URI Class Initialized
INFO - 2024-10-25 15:29:44 --> Router Class Initialized
INFO - 2024-10-25 15:29:44 --> Output Class Initialized
INFO - 2024-10-25 15:29:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:44 --> Input Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Loader Class Initialized
INFO - 2024-10-25 15:29:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:44 --> Controller Class Initialized
DEBUG - 2024-10-25 15:29:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:29:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:29:44 --> Final output sent to browser
DEBUG - 2024-10-25 15:29:44 --> Total execution time: 0.0307
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:44 --> URI Class Initialized
INFO - 2024-10-25 15:29:44 --> Router Class Initialized
INFO - 2024-10-25 15:29:44 --> Output Class Initialized
INFO - 2024-10-25 15:29:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:44 --> Input Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
ERROR - 2024-10-25 15:29:44 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:44 --> URI Class Initialized
INFO - 2024-10-25 15:29:44 --> Router Class Initialized
INFO - 2024-10-25 15:29:44 --> Output Class Initialized
INFO - 2024-10-25 15:29:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:44 --> Input Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Language Class Initialized
INFO - 2024-10-25 15:29:44 --> Config Class Initialized
INFO - 2024-10-25 15:29:44 --> Loader Class Initialized
INFO - 2024-10-25 15:29:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:45 --> Controller Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:56 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:56 --> URI Class Initialized
INFO - 2024-10-25 15:29:56 --> Router Class Initialized
INFO - 2024-10-25 15:29:56 --> Output Class Initialized
INFO - 2024-10-25 15:29:56 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:56 --> Input Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:56 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:56 --> URI Class Initialized
INFO - 2024-10-25 15:29:56 --> Router Class Initialized
INFO - 2024-10-25 15:29:56 --> Output Class Initialized
INFO - 2024-10-25 15:29:56 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:56 --> Input Class Initialized
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Loader Class Initialized
INFO - 2024-10-25 15:29:56 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Loader Class Initialized
INFO - 2024-10-25 15:29:56 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:56 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:56 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:56 --> Controller Class Initialized
INFO - 2024-10-25 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:56 --> Controller Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:29:56 --> Utf8 Class Initialized
INFO - 2024-10-25 15:29:56 --> URI Class Initialized
INFO - 2024-10-25 15:29:56 --> Router Class Initialized
INFO - 2024-10-25 15:29:56 --> Output Class Initialized
INFO - 2024-10-25 15:29:56 --> Security Class Initialized
DEBUG - 2024-10-25 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:29:56 --> Input Class Initialized
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Language Class Initialized
INFO - 2024-10-25 15:29:56 --> Config Class Initialized
INFO - 2024-10-25 15:29:56 --> Loader Class Initialized
INFO - 2024-10-25 15:29:56 --> Helper loaded: url_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: file_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: form_helper
INFO - 2024-10-25 15:29:56 --> Helper loaded: my_helper
INFO - 2024-10-25 15:29:56 --> Database Driver Class Initialized
INFO - 2024-10-25 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:29:56 --> Controller Class Initialized
INFO - 2024-10-25 15:30:01 --> Config Class Initialized
INFO - 2024-10-25 15:30:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:01 --> URI Class Initialized
INFO - 2024-10-25 15:30:01 --> Router Class Initialized
INFO - 2024-10-25 15:30:01 --> Output Class Initialized
INFO - 2024-10-25 15:30:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:01 --> Input Class Initialized
INFO - 2024-10-25 15:30:01 --> Language Class Initialized
INFO - 2024-10-25 15:30:01 --> Language Class Initialized
INFO - 2024-10-25 15:30:01 --> Config Class Initialized
INFO - 2024-10-25 15:30:01 --> Loader Class Initialized
INFO - 2024-10-25 15:30:01 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:01 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:01 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:01 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:01 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:01 --> Controller Class Initialized
ERROR - 2024-10-25 15:30:01 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:30:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:30:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:30:01 --> Final output sent to browser
DEBUG - 2024-10-25 15:30:01 --> Total execution time: 0.1207
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:29 --> URI Class Initialized
INFO - 2024-10-25 15:30:29 --> Router Class Initialized
INFO - 2024-10-25 15:30:29 --> Output Class Initialized
INFO - 2024-10-25 15:30:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:29 --> Input Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Loader Class Initialized
INFO - 2024-10-25 15:30:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:29 --> Controller Class Initialized
INFO - 2024-10-25 15:30:29 --> Upload Class Initialized
INFO - 2024-10-25 15:30:29 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:30:29 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:29 --> URI Class Initialized
INFO - 2024-10-25 15:30:29 --> Router Class Initialized
INFO - 2024-10-25 15:30:29 --> Output Class Initialized
INFO - 2024-10-25 15:30:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:29 --> Input Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Loader Class Initialized
INFO - 2024-10-25 15:30:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:29 --> Controller Class Initialized
DEBUG - 2024-10-25 15:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:30:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:30:29 --> Final output sent to browser
DEBUG - 2024-10-25 15:30:29 --> Total execution time: 0.0302
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:29 --> URI Class Initialized
INFO - 2024-10-25 15:30:29 --> Router Class Initialized
INFO - 2024-10-25 15:30:29 --> Output Class Initialized
INFO - 2024-10-25 15:30:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:29 --> Input Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
ERROR - 2024-10-25 15:30:29 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:29 --> URI Class Initialized
INFO - 2024-10-25 15:30:29 --> Router Class Initialized
INFO - 2024-10-25 15:30:29 --> Output Class Initialized
INFO - 2024-10-25 15:30:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:29 --> Input Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Language Class Initialized
INFO - 2024-10-25 15:30:29 --> Config Class Initialized
INFO - 2024-10-25 15:30:29 --> Loader Class Initialized
INFO - 2024-10-25 15:30:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:29 --> Controller Class Initialized
INFO - 2024-10-25 15:30:44 --> Config Class Initialized
INFO - 2024-10-25 15:30:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:44 --> URI Class Initialized
INFO - 2024-10-25 15:30:44 --> Router Class Initialized
INFO - 2024-10-25 15:30:44 --> Output Class Initialized
INFO - 2024-10-25 15:30:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:44 --> Input Class Initialized
INFO - 2024-10-25 15:30:44 --> Language Class Initialized
INFO - 2024-10-25 15:30:44 --> Language Class Initialized
INFO - 2024-10-25 15:30:44 --> Config Class Initialized
INFO - 2024-10-25 15:30:44 --> Loader Class Initialized
INFO - 2024-10-25 15:30:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:44 --> Controller Class Initialized
INFO - 2024-10-25 15:30:44 --> Config Class Initialized
INFO - 2024-10-25 15:30:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:44 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:44 --> URI Class Initialized
INFO - 2024-10-25 15:30:44 --> Router Class Initialized
INFO - 2024-10-25 15:30:44 --> Output Class Initialized
INFO - 2024-10-25 15:30:44 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:44 --> Input Class Initialized
INFO - 2024-10-25 15:30:44 --> Language Class Initialized
INFO - 2024-10-25 15:30:44 --> Language Class Initialized
INFO - 2024-10-25 15:30:44 --> Config Class Initialized
INFO - 2024-10-25 15:30:44 --> Loader Class Initialized
INFO - 2024-10-25 15:30:44 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:44 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:44 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:44 --> Controller Class Initialized
INFO - 2024-10-25 15:30:45 --> Config Class Initialized
INFO - 2024-10-25 15:30:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:45 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:45 --> URI Class Initialized
INFO - 2024-10-25 15:30:45 --> Router Class Initialized
INFO - 2024-10-25 15:30:45 --> Output Class Initialized
INFO - 2024-10-25 15:30:45 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:45 --> Input Class Initialized
INFO - 2024-10-25 15:30:45 --> Language Class Initialized
INFO - 2024-10-25 15:30:45 --> Language Class Initialized
INFO - 2024-10-25 15:30:45 --> Config Class Initialized
INFO - 2024-10-25 15:30:45 --> Loader Class Initialized
INFO - 2024-10-25 15:30:45 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:45 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:45 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:45 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:45 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:45 --> Controller Class Initialized
INFO - 2024-10-25 15:30:46 --> Config Class Initialized
INFO - 2024-10-25 15:30:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:30:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:30:46 --> Utf8 Class Initialized
INFO - 2024-10-25 15:30:46 --> URI Class Initialized
INFO - 2024-10-25 15:30:46 --> Router Class Initialized
INFO - 2024-10-25 15:30:46 --> Output Class Initialized
INFO - 2024-10-25 15:30:46 --> Security Class Initialized
DEBUG - 2024-10-25 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:30:46 --> Input Class Initialized
INFO - 2024-10-25 15:30:46 --> Language Class Initialized
INFO - 2024-10-25 15:30:46 --> Language Class Initialized
INFO - 2024-10-25 15:30:46 --> Config Class Initialized
INFO - 2024-10-25 15:30:46 --> Loader Class Initialized
INFO - 2024-10-25 15:30:46 --> Helper loaded: url_helper
INFO - 2024-10-25 15:30:46 --> Helper loaded: file_helper
INFO - 2024-10-25 15:30:46 --> Helper loaded: form_helper
INFO - 2024-10-25 15:30:46 --> Helper loaded: my_helper
INFO - 2024-10-25 15:30:46 --> Database Driver Class Initialized
INFO - 2024-10-25 15:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:30:46 --> Controller Class Initialized
ERROR - 2024-10-25 15:30:46 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:30:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:30:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:30:46 --> Final output sent to browser
DEBUG - 2024-10-25 15:30:46 --> Total execution time: 0.0346
INFO - 2024-10-25 15:31:12 --> Config Class Initialized
INFO - 2024-10-25 15:31:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:12 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:12 --> URI Class Initialized
INFO - 2024-10-25 15:31:12 --> Router Class Initialized
INFO - 2024-10-25 15:31:12 --> Output Class Initialized
INFO - 2024-10-25 15:31:12 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:12 --> Input Class Initialized
INFO - 2024-10-25 15:31:12 --> Language Class Initialized
INFO - 2024-10-25 15:31:12 --> Language Class Initialized
INFO - 2024-10-25 15:31:12 --> Config Class Initialized
INFO - 2024-10-25 15:31:12 --> Loader Class Initialized
INFO - 2024-10-25 15:31:12 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:12 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:12 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:12 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:12 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:12 --> Controller Class Initialized
INFO - 2024-10-25 15:31:12 --> Upload Class Initialized
INFO - 2024-10-25 15:31:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:31:12 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:31:13 --> Config Class Initialized
INFO - 2024-10-25 15:31:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:13 --> URI Class Initialized
INFO - 2024-10-25 15:31:13 --> Router Class Initialized
INFO - 2024-10-25 15:31:13 --> Output Class Initialized
INFO - 2024-10-25 15:31:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:13 --> Input Class Initialized
INFO - 2024-10-25 15:31:13 --> Language Class Initialized
INFO - 2024-10-25 15:31:13 --> Language Class Initialized
INFO - 2024-10-25 15:31:13 --> Config Class Initialized
INFO - 2024-10-25 15:31:13 --> Loader Class Initialized
INFO - 2024-10-25 15:31:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:13 --> Controller Class Initialized
DEBUG - 2024-10-25 15:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:31:13 --> Final output sent to browser
DEBUG - 2024-10-25 15:31:13 --> Total execution time: 0.0261
INFO - 2024-10-25 15:31:13 --> Config Class Initialized
INFO - 2024-10-25 15:31:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:13 --> URI Class Initialized
INFO - 2024-10-25 15:31:13 --> Router Class Initialized
INFO - 2024-10-25 15:31:13 --> Output Class Initialized
INFO - 2024-10-25 15:31:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:13 --> Input Class Initialized
INFO - 2024-10-25 15:31:13 --> Language Class Initialized
ERROR - 2024-10-25 15:31:13 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:31:13 --> Config Class Initialized
INFO - 2024-10-25 15:31:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:13 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:13 --> URI Class Initialized
INFO - 2024-10-25 15:31:13 --> Router Class Initialized
INFO - 2024-10-25 15:31:13 --> Output Class Initialized
INFO - 2024-10-25 15:31:13 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:13 --> Input Class Initialized
INFO - 2024-10-25 15:31:13 --> Language Class Initialized
INFO - 2024-10-25 15:31:13 --> Language Class Initialized
INFO - 2024-10-25 15:31:13 --> Config Class Initialized
INFO - 2024-10-25 15:31:13 --> Loader Class Initialized
INFO - 2024-10-25 15:31:13 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:13 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:13 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:13 --> Controller Class Initialized
INFO - 2024-10-25 15:31:20 --> Config Class Initialized
INFO - 2024-10-25 15:31:20 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:20 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:20 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:20 --> URI Class Initialized
INFO - 2024-10-25 15:31:20 --> Router Class Initialized
INFO - 2024-10-25 15:31:20 --> Output Class Initialized
INFO - 2024-10-25 15:31:20 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:20 --> Input Class Initialized
INFO - 2024-10-25 15:31:20 --> Language Class Initialized
INFO - 2024-10-25 15:31:20 --> Language Class Initialized
INFO - 2024-10-25 15:31:20 --> Config Class Initialized
INFO - 2024-10-25 15:31:20 --> Loader Class Initialized
INFO - 2024-10-25 15:31:20 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:20 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:20 --> Controller Class Initialized
INFO - 2024-10-25 15:31:20 --> Config Class Initialized
INFO - 2024-10-25 15:31:20 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:20 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:20 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:20 --> URI Class Initialized
INFO - 2024-10-25 15:31:20 --> Router Class Initialized
INFO - 2024-10-25 15:31:20 --> Output Class Initialized
INFO - 2024-10-25 15:31:20 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:20 --> Input Class Initialized
INFO - 2024-10-25 15:31:20 --> Language Class Initialized
INFO - 2024-10-25 15:31:20 --> Language Class Initialized
INFO - 2024-10-25 15:31:20 --> Config Class Initialized
INFO - 2024-10-25 15:31:20 --> Loader Class Initialized
INFO - 2024-10-25 15:31:20 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:20 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:20 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:20 --> Controller Class Initialized
INFO - 2024-10-25 15:31:21 --> Config Class Initialized
INFO - 2024-10-25 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:21 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:21 --> URI Class Initialized
INFO - 2024-10-25 15:31:21 --> Router Class Initialized
INFO - 2024-10-25 15:31:21 --> Output Class Initialized
INFO - 2024-10-25 15:31:21 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:21 --> Input Class Initialized
INFO - 2024-10-25 15:31:21 --> Language Class Initialized
INFO - 2024-10-25 15:31:21 --> Language Class Initialized
INFO - 2024-10-25 15:31:21 --> Config Class Initialized
INFO - 2024-10-25 15:31:21 --> Loader Class Initialized
INFO - 2024-10-25 15:31:21 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:21 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:21 --> Controller Class Initialized
INFO - 2024-10-25 15:31:21 --> Config Class Initialized
INFO - 2024-10-25 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:21 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:21 --> URI Class Initialized
INFO - 2024-10-25 15:31:21 --> Router Class Initialized
INFO - 2024-10-25 15:31:21 --> Output Class Initialized
INFO - 2024-10-25 15:31:21 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:21 --> Input Class Initialized
INFO - 2024-10-25 15:31:21 --> Language Class Initialized
INFO - 2024-10-25 15:31:21 --> Language Class Initialized
INFO - 2024-10-25 15:31:21 --> Config Class Initialized
INFO - 2024-10-25 15:31:21 --> Loader Class Initialized
INFO - 2024-10-25 15:31:21 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:21 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:21 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:21 --> Controller Class Initialized
INFO - 2024-10-25 15:31:22 --> Config Class Initialized
INFO - 2024-10-25 15:31:22 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:22 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:22 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:22 --> URI Class Initialized
INFO - 2024-10-25 15:31:22 --> Router Class Initialized
INFO - 2024-10-25 15:31:22 --> Output Class Initialized
INFO - 2024-10-25 15:31:22 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:22 --> Input Class Initialized
INFO - 2024-10-25 15:31:22 --> Language Class Initialized
INFO - 2024-10-25 15:31:22 --> Language Class Initialized
INFO - 2024-10-25 15:31:22 --> Config Class Initialized
INFO - 2024-10-25 15:31:22 --> Loader Class Initialized
INFO - 2024-10-25 15:31:22 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:22 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:22 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:22 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:22 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:22 --> Controller Class Initialized
INFO - 2024-10-25 15:31:24 --> Config Class Initialized
INFO - 2024-10-25 15:31:24 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:24 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:24 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:24 --> URI Class Initialized
INFO - 2024-10-25 15:31:24 --> Router Class Initialized
INFO - 2024-10-25 15:31:24 --> Output Class Initialized
INFO - 2024-10-25 15:31:24 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:24 --> Input Class Initialized
INFO - 2024-10-25 15:31:24 --> Language Class Initialized
INFO - 2024-10-25 15:31:24 --> Language Class Initialized
INFO - 2024-10-25 15:31:24 --> Config Class Initialized
INFO - 2024-10-25 15:31:24 --> Loader Class Initialized
INFO - 2024-10-25 15:31:24 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:24 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:24 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:24 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:24 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:24 --> Controller Class Initialized
ERROR - 2024-10-25 15:31:24 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:31:24 --> Final output sent to browser
DEBUG - 2024-10-25 15:31:24 --> Total execution time: 0.0334
INFO - 2024-10-25 15:31:48 --> Config Class Initialized
INFO - 2024-10-25 15:31:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:48 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:48 --> URI Class Initialized
INFO - 2024-10-25 15:31:48 --> Router Class Initialized
INFO - 2024-10-25 15:31:48 --> Output Class Initialized
INFO - 2024-10-25 15:31:48 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:48 --> Input Class Initialized
INFO - 2024-10-25 15:31:48 --> Language Class Initialized
INFO - 2024-10-25 15:31:48 --> Language Class Initialized
INFO - 2024-10-25 15:31:48 --> Config Class Initialized
INFO - 2024-10-25 15:31:48 --> Loader Class Initialized
INFO - 2024-10-25 15:31:48 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:48 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:48 --> Controller Class Initialized
INFO - 2024-10-25 15:31:48 --> Upload Class Initialized
INFO - 2024-10-25 15:31:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:31:48 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:31:48 --> Config Class Initialized
INFO - 2024-10-25 15:31:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:48 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:48 --> URI Class Initialized
INFO - 2024-10-25 15:31:48 --> Router Class Initialized
INFO - 2024-10-25 15:31:48 --> Output Class Initialized
INFO - 2024-10-25 15:31:48 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:48 --> Input Class Initialized
INFO - 2024-10-25 15:31:48 --> Language Class Initialized
INFO - 2024-10-25 15:31:48 --> Language Class Initialized
INFO - 2024-10-25 15:31:48 --> Config Class Initialized
INFO - 2024-10-25 15:31:48 --> Loader Class Initialized
INFO - 2024-10-25 15:31:48 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:48 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:48 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:48 --> Controller Class Initialized
DEBUG - 2024-10-25 15:31:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:31:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:31:48 --> Final output sent to browser
DEBUG - 2024-10-25 15:31:48 --> Total execution time: 0.0276
INFO - 2024-10-25 15:31:49 --> Config Class Initialized
INFO - 2024-10-25 15:31:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:49 --> URI Class Initialized
INFO - 2024-10-25 15:31:49 --> Router Class Initialized
INFO - 2024-10-25 15:31:49 --> Output Class Initialized
INFO - 2024-10-25 15:31:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:49 --> Input Class Initialized
INFO - 2024-10-25 15:31:49 --> Language Class Initialized
ERROR - 2024-10-25 15:31:49 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:31:49 --> Config Class Initialized
INFO - 2024-10-25 15:31:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:49 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:49 --> URI Class Initialized
INFO - 2024-10-25 15:31:49 --> Router Class Initialized
INFO - 2024-10-25 15:31:49 --> Output Class Initialized
INFO - 2024-10-25 15:31:49 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:49 --> Input Class Initialized
INFO - 2024-10-25 15:31:49 --> Language Class Initialized
INFO - 2024-10-25 15:31:49 --> Language Class Initialized
INFO - 2024-10-25 15:31:49 --> Config Class Initialized
INFO - 2024-10-25 15:31:49 --> Loader Class Initialized
INFO - 2024-10-25 15:31:49 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:49 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:49 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:49 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:49 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:49 --> Controller Class Initialized
INFO - 2024-10-25 15:31:58 --> Config Class Initialized
INFO - 2024-10-25 15:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:58 --> URI Class Initialized
INFO - 2024-10-25 15:31:58 --> Router Class Initialized
INFO - 2024-10-25 15:31:58 --> Output Class Initialized
INFO - 2024-10-25 15:31:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:58 --> Input Class Initialized
INFO - 2024-10-25 15:31:58 --> Language Class Initialized
INFO - 2024-10-25 15:31:58 --> Language Class Initialized
INFO - 2024-10-25 15:31:58 --> Config Class Initialized
INFO - 2024-10-25 15:31:58 --> Loader Class Initialized
INFO - 2024-10-25 15:31:58 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:58 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:58 --> Controller Class Initialized
INFO - 2024-10-25 15:31:58 --> Config Class Initialized
INFO - 2024-10-25 15:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:58 --> URI Class Initialized
INFO - 2024-10-25 15:31:58 --> Router Class Initialized
INFO - 2024-10-25 15:31:58 --> Output Class Initialized
INFO - 2024-10-25 15:31:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:58 --> Input Class Initialized
INFO - 2024-10-25 15:31:58 --> Language Class Initialized
INFO - 2024-10-25 15:31:58 --> Language Class Initialized
INFO - 2024-10-25 15:31:58 --> Config Class Initialized
INFO - 2024-10-25 15:31:58 --> Loader Class Initialized
INFO - 2024-10-25 15:31:58 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:58 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:58 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:58 --> Controller Class Initialized
INFO - 2024-10-25 15:31:59 --> Config Class Initialized
INFO - 2024-10-25 15:31:59 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:31:59 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:31:59 --> Utf8 Class Initialized
INFO - 2024-10-25 15:31:59 --> URI Class Initialized
INFO - 2024-10-25 15:31:59 --> Router Class Initialized
INFO - 2024-10-25 15:31:59 --> Output Class Initialized
INFO - 2024-10-25 15:31:59 --> Security Class Initialized
DEBUG - 2024-10-25 15:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:31:59 --> Input Class Initialized
INFO - 2024-10-25 15:31:59 --> Language Class Initialized
INFO - 2024-10-25 15:31:59 --> Language Class Initialized
INFO - 2024-10-25 15:31:59 --> Config Class Initialized
INFO - 2024-10-25 15:31:59 --> Loader Class Initialized
INFO - 2024-10-25 15:31:59 --> Helper loaded: url_helper
INFO - 2024-10-25 15:31:59 --> Helper loaded: file_helper
INFO - 2024-10-25 15:31:59 --> Helper loaded: form_helper
INFO - 2024-10-25 15:31:59 --> Helper loaded: my_helper
INFO - 2024-10-25 15:31:59 --> Database Driver Class Initialized
INFO - 2024-10-25 15:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:31:59 --> Controller Class Initialized
INFO - 2024-10-25 15:32:00 --> Config Class Initialized
INFO - 2024-10-25 15:32:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:00 --> URI Class Initialized
INFO - 2024-10-25 15:32:00 --> Router Class Initialized
INFO - 2024-10-25 15:32:00 --> Output Class Initialized
INFO - 2024-10-25 15:32:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:00 --> Input Class Initialized
INFO - 2024-10-25 15:32:00 --> Language Class Initialized
INFO - 2024-10-25 15:32:00 --> Language Class Initialized
INFO - 2024-10-25 15:32:00 --> Config Class Initialized
INFO - 2024-10-25 15:32:00 --> Loader Class Initialized
INFO - 2024-10-25 15:32:00 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:00 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:00 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:00 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:00 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:00 --> Controller Class Initialized
ERROR - 2024-10-25 15:32:00 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:32:00 --> Final output sent to browser
DEBUG - 2024-10-25 15:32:00 --> Total execution time: 0.0309
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:19 --> URI Class Initialized
INFO - 2024-10-25 15:32:19 --> Router Class Initialized
INFO - 2024-10-25 15:32:19 --> Output Class Initialized
INFO - 2024-10-25 15:32:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:19 --> Input Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Loader Class Initialized
INFO - 2024-10-25 15:32:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:19 --> Controller Class Initialized
INFO - 2024-10-25 15:32:19 --> Upload Class Initialized
INFO - 2024-10-25 15:32:19 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:32:19 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:19 --> URI Class Initialized
INFO - 2024-10-25 15:32:19 --> Router Class Initialized
INFO - 2024-10-25 15:32:19 --> Output Class Initialized
INFO - 2024-10-25 15:32:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:19 --> Input Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Loader Class Initialized
INFO - 2024-10-25 15:32:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:19 --> Controller Class Initialized
DEBUG - 2024-10-25 15:32:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:32:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:32:19 --> Final output sent to browser
DEBUG - 2024-10-25 15:32:19 --> Total execution time: 0.0497
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:19 --> URI Class Initialized
INFO - 2024-10-25 15:32:19 --> Router Class Initialized
INFO - 2024-10-25 15:32:19 --> Output Class Initialized
INFO - 2024-10-25 15:32:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:19 --> Input Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
ERROR - 2024-10-25 15:32:19 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:19 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:19 --> URI Class Initialized
INFO - 2024-10-25 15:32:19 --> Router Class Initialized
INFO - 2024-10-25 15:32:19 --> Output Class Initialized
INFO - 2024-10-25 15:32:19 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:19 --> Input Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Language Class Initialized
INFO - 2024-10-25 15:32:19 --> Config Class Initialized
INFO - 2024-10-25 15:32:19 --> Loader Class Initialized
INFO - 2024-10-25 15:32:19 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:19 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:19 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:19 --> Controller Class Initialized
INFO - 2024-10-25 15:32:27 --> Config Class Initialized
INFO - 2024-10-25 15:32:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:27 --> URI Class Initialized
INFO - 2024-10-25 15:32:27 --> Router Class Initialized
INFO - 2024-10-25 15:32:27 --> Output Class Initialized
INFO - 2024-10-25 15:32:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:27 --> Input Class Initialized
INFO - 2024-10-25 15:32:27 --> Language Class Initialized
INFO - 2024-10-25 15:32:27 --> Language Class Initialized
INFO - 2024-10-25 15:32:27 --> Config Class Initialized
INFO - 2024-10-25 15:32:27 --> Loader Class Initialized
INFO - 2024-10-25 15:32:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:27 --> Controller Class Initialized
INFO - 2024-10-25 15:32:27 --> Config Class Initialized
INFO - 2024-10-25 15:32:27 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:27 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:27 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:27 --> URI Class Initialized
INFO - 2024-10-25 15:32:27 --> Router Class Initialized
INFO - 2024-10-25 15:32:27 --> Output Class Initialized
INFO - 2024-10-25 15:32:27 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:27 --> Input Class Initialized
INFO - 2024-10-25 15:32:27 --> Language Class Initialized
INFO - 2024-10-25 15:32:27 --> Language Class Initialized
INFO - 2024-10-25 15:32:27 --> Config Class Initialized
INFO - 2024-10-25 15:32:27 --> Loader Class Initialized
INFO - 2024-10-25 15:32:27 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:27 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:27 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:27 --> Controller Class Initialized
INFO - 2024-10-25 15:32:28 --> Config Class Initialized
INFO - 2024-10-25 15:32:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:28 --> URI Class Initialized
INFO - 2024-10-25 15:32:28 --> Router Class Initialized
INFO - 2024-10-25 15:32:28 --> Output Class Initialized
INFO - 2024-10-25 15:32:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:28 --> Input Class Initialized
INFO - 2024-10-25 15:32:28 --> Language Class Initialized
INFO - 2024-10-25 15:32:28 --> Language Class Initialized
INFO - 2024-10-25 15:32:28 --> Config Class Initialized
INFO - 2024-10-25 15:32:28 --> Loader Class Initialized
INFO - 2024-10-25 15:32:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:28 --> Controller Class Initialized
INFO - 2024-10-25 15:32:28 --> Config Class Initialized
INFO - 2024-10-25 15:32:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:28 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:28 --> URI Class Initialized
INFO - 2024-10-25 15:32:28 --> Router Class Initialized
INFO - 2024-10-25 15:32:28 --> Output Class Initialized
INFO - 2024-10-25 15:32:28 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:28 --> Input Class Initialized
INFO - 2024-10-25 15:32:28 --> Language Class Initialized
INFO - 2024-10-25 15:32:28 --> Language Class Initialized
INFO - 2024-10-25 15:32:28 --> Config Class Initialized
INFO - 2024-10-25 15:32:28 --> Loader Class Initialized
INFO - 2024-10-25 15:32:28 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:28 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:28 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:28 --> Controller Class Initialized
INFO - 2024-10-25 15:32:29 --> Config Class Initialized
INFO - 2024-10-25 15:32:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:29 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:29 --> URI Class Initialized
INFO - 2024-10-25 15:32:29 --> Router Class Initialized
INFO - 2024-10-25 15:32:29 --> Output Class Initialized
INFO - 2024-10-25 15:32:29 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:29 --> Input Class Initialized
INFO - 2024-10-25 15:32:29 --> Language Class Initialized
INFO - 2024-10-25 15:32:29 --> Language Class Initialized
INFO - 2024-10-25 15:32:29 --> Config Class Initialized
INFO - 2024-10-25 15:32:29 --> Loader Class Initialized
INFO - 2024-10-25 15:32:29 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:29 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:29 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:29 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:29 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:29 --> Controller Class Initialized
INFO - 2024-10-25 15:32:31 --> Config Class Initialized
INFO - 2024-10-25 15:32:31 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:31 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:31 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:31 --> URI Class Initialized
INFO - 2024-10-25 15:32:31 --> Router Class Initialized
INFO - 2024-10-25 15:32:31 --> Output Class Initialized
INFO - 2024-10-25 15:32:31 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:31 --> Input Class Initialized
INFO - 2024-10-25 15:32:31 --> Language Class Initialized
INFO - 2024-10-25 15:32:31 --> Language Class Initialized
INFO - 2024-10-25 15:32:31 --> Config Class Initialized
INFO - 2024-10-25 15:32:31 --> Loader Class Initialized
INFO - 2024-10-25 15:32:31 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:31 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:31 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:31 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:31 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:31 --> Controller Class Initialized
ERROR - 2024-10-25 15:32:31 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:32:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:32:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:32:31 --> Final output sent to browser
DEBUG - 2024-10-25 15:32:31 --> Total execution time: 0.0348
INFO - 2024-10-25 15:32:47 --> Config Class Initialized
INFO - 2024-10-25 15:32:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:47 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:47 --> URI Class Initialized
INFO - 2024-10-25 15:32:47 --> Router Class Initialized
INFO - 2024-10-25 15:32:47 --> Output Class Initialized
INFO - 2024-10-25 15:32:47 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:47 --> Input Class Initialized
INFO - 2024-10-25 15:32:47 --> Language Class Initialized
INFO - 2024-10-25 15:32:47 --> Language Class Initialized
INFO - 2024-10-25 15:32:47 --> Config Class Initialized
INFO - 2024-10-25 15:32:47 --> Loader Class Initialized
INFO - 2024-10-25 15:32:47 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:47 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:47 --> Controller Class Initialized
INFO - 2024-10-25 15:32:47 --> Upload Class Initialized
INFO - 2024-10-25 15:32:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 15:32:47 --> The upload path does not appear to be valid.
INFO - 2024-10-25 15:32:47 --> Config Class Initialized
INFO - 2024-10-25 15:32:47 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:47 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:47 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:47 --> URI Class Initialized
INFO - 2024-10-25 15:32:47 --> Router Class Initialized
INFO - 2024-10-25 15:32:47 --> Output Class Initialized
INFO - 2024-10-25 15:32:47 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:47 --> Input Class Initialized
INFO - 2024-10-25 15:32:47 --> Language Class Initialized
INFO - 2024-10-25 15:32:47 --> Language Class Initialized
INFO - 2024-10-25 15:32:47 --> Config Class Initialized
INFO - 2024-10-25 15:32:47 --> Loader Class Initialized
INFO - 2024-10-25 15:32:47 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:47 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:47 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:47 --> Controller Class Initialized
DEBUG - 2024-10-25 15:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 15:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:32:47 --> Final output sent to browser
DEBUG - 2024-10-25 15:32:47 --> Total execution time: 0.0417
INFO - 2024-10-25 15:32:48 --> Config Class Initialized
INFO - 2024-10-25 15:32:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:48 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:48 --> URI Class Initialized
INFO - 2024-10-25 15:32:48 --> Router Class Initialized
INFO - 2024-10-25 15:32:48 --> Output Class Initialized
INFO - 2024-10-25 15:32:48 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:48 --> Input Class Initialized
INFO - 2024-10-25 15:32:48 --> Language Class Initialized
ERROR - 2024-10-25 15:32:48 --> 404 Page Not Found: /index
INFO - 2024-10-25 15:32:48 --> Config Class Initialized
INFO - 2024-10-25 15:32:48 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:48 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:48 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:48 --> URI Class Initialized
INFO - 2024-10-25 15:32:48 --> Router Class Initialized
INFO - 2024-10-25 15:32:48 --> Output Class Initialized
INFO - 2024-10-25 15:32:48 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:48 --> Input Class Initialized
INFO - 2024-10-25 15:32:48 --> Language Class Initialized
INFO - 2024-10-25 15:32:48 --> Language Class Initialized
INFO - 2024-10-25 15:32:48 --> Config Class Initialized
INFO - 2024-10-25 15:32:48 --> Loader Class Initialized
INFO - 2024-10-25 15:32:48 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:48 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:48 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:48 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:48 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:48 --> Controller Class Initialized
INFO - 2024-10-25 15:32:55 --> Config Class Initialized
INFO - 2024-10-25 15:32:55 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:55 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:55 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:55 --> URI Class Initialized
INFO - 2024-10-25 15:32:55 --> Router Class Initialized
INFO - 2024-10-25 15:32:55 --> Config Class Initialized
INFO - 2024-10-25 15:32:55 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:32:55 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:32:55 --> Utf8 Class Initialized
INFO - 2024-10-25 15:32:55 --> URI Class Initialized
INFO - 2024-10-25 15:32:55 --> Router Class Initialized
INFO - 2024-10-25 15:32:55 --> Output Class Initialized
INFO - 2024-10-25 15:32:55 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:55 --> Input Class Initialized
INFO - 2024-10-25 15:32:55 --> Language Class Initialized
INFO - 2024-10-25 15:32:55 --> Language Class Initialized
INFO - 2024-10-25 15:32:55 --> Config Class Initialized
INFO - 2024-10-25 15:32:55 --> Loader Class Initialized
INFO - 2024-10-25 15:32:55 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:55 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:55 --> Output Class Initialized
INFO - 2024-10-25 15:32:55 --> Security Class Initialized
DEBUG - 2024-10-25 15:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:32:55 --> Input Class Initialized
INFO - 2024-10-25 15:32:55 --> Language Class Initialized
INFO - 2024-10-25 15:32:55 --> Language Class Initialized
INFO - 2024-10-25 15:32:55 --> Config Class Initialized
INFO - 2024-10-25 15:32:55 --> Loader Class Initialized
INFO - 2024-10-25 15:32:55 --> Helper loaded: url_helper
INFO - 2024-10-25 15:32:55 --> Helper loaded: file_helper
INFO - 2024-10-25 15:32:55 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:55 --> Helper loaded: form_helper
INFO - 2024-10-25 15:32:55 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:55 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:55 --> Helper loaded: my_helper
INFO - 2024-10-25 15:32:55 --> Database Driver Class Initialized
INFO - 2024-10-25 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:55 --> Controller Class Initialized
INFO - 2024-10-25 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:32:55 --> Controller Class Initialized
INFO - 2024-10-25 15:33:00 --> Config Class Initialized
INFO - 2024-10-25 15:33:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:33:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:33:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:33:00 --> URI Class Initialized
INFO - 2024-10-25 15:33:00 --> Router Class Initialized
INFO - 2024-10-25 15:33:00 --> Output Class Initialized
INFO - 2024-10-25 15:33:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:33:00 --> Input Class Initialized
INFO - 2024-10-25 15:33:00 --> Language Class Initialized
INFO - 2024-10-25 15:33:00 --> Language Class Initialized
INFO - 2024-10-25 15:33:00 --> Config Class Initialized
INFO - 2024-10-25 15:33:00 --> Loader Class Initialized
INFO - 2024-10-25 15:33:00 --> Helper loaded: url_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: file_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: form_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: my_helper
INFO - 2024-10-25 15:33:00 --> Database Driver Class Initialized
INFO - 2024-10-25 15:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:33:00 --> Controller Class Initialized
INFO - 2024-10-25 15:33:00 --> Config Class Initialized
INFO - 2024-10-25 15:33:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:33:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:33:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:33:00 --> URI Class Initialized
INFO - 2024-10-25 15:33:00 --> Router Class Initialized
INFO - 2024-10-25 15:33:00 --> Output Class Initialized
INFO - 2024-10-25 15:33:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:33:00 --> Input Class Initialized
INFO - 2024-10-25 15:33:00 --> Language Class Initialized
INFO - 2024-10-25 15:33:00 --> Language Class Initialized
INFO - 2024-10-25 15:33:00 --> Config Class Initialized
INFO - 2024-10-25 15:33:00 --> Loader Class Initialized
INFO - 2024-10-25 15:33:00 --> Helper loaded: url_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: file_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: form_helper
INFO - 2024-10-25 15:33:00 --> Helper loaded: my_helper
INFO - 2024-10-25 15:33:00 --> Database Driver Class Initialized
INFO - 2024-10-25 15:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:33:00 --> Controller Class Initialized
INFO - 2024-10-25 15:33:02 --> Config Class Initialized
INFO - 2024-10-25 15:33:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:33:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:33:02 --> Utf8 Class Initialized
INFO - 2024-10-25 15:33:02 --> URI Class Initialized
INFO - 2024-10-25 15:33:02 --> Router Class Initialized
INFO - 2024-10-25 15:33:02 --> Output Class Initialized
INFO - 2024-10-25 15:33:02 --> Security Class Initialized
DEBUG - 2024-10-25 15:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:33:02 --> Input Class Initialized
INFO - 2024-10-25 15:33:02 --> Language Class Initialized
INFO - 2024-10-25 15:33:02 --> Language Class Initialized
INFO - 2024-10-25 15:33:02 --> Config Class Initialized
INFO - 2024-10-25 15:33:02 --> Loader Class Initialized
INFO - 2024-10-25 15:33:02 --> Helper loaded: url_helper
INFO - 2024-10-25 15:33:02 --> Helper loaded: file_helper
INFO - 2024-10-25 15:33:02 --> Helper loaded: form_helper
INFO - 2024-10-25 15:33:02 --> Helper loaded: my_helper
INFO - 2024-10-25 15:33:02 --> Database Driver Class Initialized
INFO - 2024-10-25 15:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:33:02 --> Controller Class Initialized
ERROR - 2024-10-25 15:33:02 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 15:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 15:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 15:33:02 --> Final output sent to browser
DEBUG - 2024-10-25 15:33:02 --> Total execution time: 0.0326
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:18 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:18 --> URI Class Initialized
INFO - 2024-10-25 16:45:18 --> Router Class Initialized
INFO - 2024-10-25 16:45:18 --> Output Class Initialized
INFO - 2024-10-25 16:45:18 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:18 --> Input Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Loader Class Initialized
INFO - 2024-10-25 16:45:18 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:18 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:18 --> Controller Class Initialized
INFO - 2024-10-25 16:45:18 --> Upload Class Initialized
INFO - 2024-10-25 16:45:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 16:45:18 --> The upload path does not appear to be valid.
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:18 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:18 --> URI Class Initialized
INFO - 2024-10-25 16:45:18 --> Router Class Initialized
INFO - 2024-10-25 16:45:18 --> Output Class Initialized
INFO - 2024-10-25 16:45:18 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:18 --> Input Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Loader Class Initialized
INFO - 2024-10-25 16:45:18 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:18 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:18 --> Controller Class Initialized
DEBUG - 2024-10-25 16:45:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 16:45:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 16:45:18 --> Final output sent to browser
DEBUG - 2024-10-25 16:45:18 --> Total execution time: 0.0315
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:18 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:18 --> URI Class Initialized
INFO - 2024-10-25 16:45:18 --> Router Class Initialized
INFO - 2024-10-25 16:45:18 --> Output Class Initialized
INFO - 2024-10-25 16:45:18 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:18 --> Input Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
ERROR - 2024-10-25 16:45:18 --> 404 Page Not Found: /index
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:18 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:18 --> URI Class Initialized
INFO - 2024-10-25 16:45:18 --> Router Class Initialized
INFO - 2024-10-25 16:45:18 --> Output Class Initialized
INFO - 2024-10-25 16:45:18 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:18 --> Input Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Language Class Initialized
INFO - 2024-10-25 16:45:18 --> Config Class Initialized
INFO - 2024-10-25 16:45:18 --> Loader Class Initialized
INFO - 2024-10-25 16:45:18 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:18 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:18 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:18 --> Controller Class Initialized
INFO - 2024-10-25 16:45:28 --> Config Class Initialized
INFO - 2024-10-25 16:45:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:28 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:28 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:28 --> URI Class Initialized
INFO - 2024-10-25 16:45:28 --> Router Class Initialized
INFO - 2024-10-25 16:45:28 --> Output Class Initialized
INFO - 2024-10-25 16:45:28 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:28 --> Input Class Initialized
INFO - 2024-10-25 16:45:28 --> Language Class Initialized
INFO - 2024-10-25 16:45:28 --> Language Class Initialized
INFO - 2024-10-25 16:45:28 --> Config Class Initialized
INFO - 2024-10-25 16:45:28 --> Loader Class Initialized
INFO - 2024-10-25 16:45:28 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:28 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:28 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:28 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:28 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:28 --> Controller Class Initialized
INFO - 2024-10-25 16:45:28 --> Config Class Initialized
INFO - 2024-10-25 16:45:28 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:29 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:29 --> URI Class Initialized
INFO - 2024-10-25 16:45:29 --> Router Class Initialized
INFO - 2024-10-25 16:45:29 --> Output Class Initialized
INFO - 2024-10-25 16:45:29 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:29 --> Input Class Initialized
INFO - 2024-10-25 16:45:29 --> Language Class Initialized
INFO - 2024-10-25 16:45:29 --> Language Class Initialized
INFO - 2024-10-25 16:45:29 --> Config Class Initialized
INFO - 2024-10-25 16:45:29 --> Loader Class Initialized
INFO - 2024-10-25 16:45:29 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:29 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:29 --> Controller Class Initialized
INFO - 2024-10-25 16:45:29 --> Config Class Initialized
INFO - 2024-10-25 16:45:29 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:29 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:29 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:29 --> URI Class Initialized
INFO - 2024-10-25 16:45:29 --> Router Class Initialized
INFO - 2024-10-25 16:45:29 --> Output Class Initialized
INFO - 2024-10-25 16:45:29 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:29 --> Input Class Initialized
INFO - 2024-10-25 16:45:29 --> Language Class Initialized
INFO - 2024-10-25 16:45:29 --> Language Class Initialized
INFO - 2024-10-25 16:45:29 --> Config Class Initialized
INFO - 2024-10-25 16:45:29 --> Loader Class Initialized
INFO - 2024-10-25 16:45:29 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:29 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:29 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:29 --> Controller Class Initialized
INFO - 2024-10-25 16:45:30 --> Config Class Initialized
INFO - 2024-10-25 16:45:30 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:30 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:30 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:30 --> URI Class Initialized
INFO - 2024-10-25 16:45:30 --> Router Class Initialized
INFO - 2024-10-25 16:45:30 --> Output Class Initialized
INFO - 2024-10-25 16:45:30 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:30 --> Input Class Initialized
INFO - 2024-10-25 16:45:30 --> Language Class Initialized
INFO - 2024-10-25 16:45:30 --> Language Class Initialized
INFO - 2024-10-25 16:45:30 --> Config Class Initialized
INFO - 2024-10-25 16:45:30 --> Loader Class Initialized
INFO - 2024-10-25 16:45:30 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:30 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:30 --> Controller Class Initialized
INFO - 2024-10-25 16:45:30 --> Config Class Initialized
INFO - 2024-10-25 16:45:30 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:30 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:30 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:30 --> URI Class Initialized
INFO - 2024-10-25 16:45:30 --> Router Class Initialized
INFO - 2024-10-25 16:45:30 --> Output Class Initialized
INFO - 2024-10-25 16:45:30 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:30 --> Input Class Initialized
INFO - 2024-10-25 16:45:30 --> Language Class Initialized
INFO - 2024-10-25 16:45:30 --> Language Class Initialized
INFO - 2024-10-25 16:45:30 --> Config Class Initialized
INFO - 2024-10-25 16:45:30 --> Loader Class Initialized
INFO - 2024-10-25 16:45:30 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:30 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:30 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:30 --> Controller Class Initialized
INFO - 2024-10-25 16:45:31 --> Config Class Initialized
INFO - 2024-10-25 16:45:31 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:31 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:31 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:31 --> URI Class Initialized
INFO - 2024-10-25 16:45:31 --> Router Class Initialized
INFO - 2024-10-25 16:45:31 --> Output Class Initialized
INFO - 2024-10-25 16:45:31 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:31 --> Input Class Initialized
INFO - 2024-10-25 16:45:31 --> Language Class Initialized
INFO - 2024-10-25 16:45:31 --> Language Class Initialized
INFO - 2024-10-25 16:45:31 --> Config Class Initialized
INFO - 2024-10-25 16:45:31 --> Loader Class Initialized
INFO - 2024-10-25 16:45:31 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:31 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:31 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:31 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:31 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:31 --> Controller Class Initialized
INFO - 2024-10-25 16:45:33 --> Config Class Initialized
INFO - 2024-10-25 16:45:33 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:45:33 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:45:33 --> Utf8 Class Initialized
INFO - 2024-10-25 16:45:33 --> URI Class Initialized
INFO - 2024-10-25 16:45:33 --> Router Class Initialized
INFO - 2024-10-25 16:45:33 --> Output Class Initialized
INFO - 2024-10-25 16:45:33 --> Security Class Initialized
DEBUG - 2024-10-25 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:45:33 --> Input Class Initialized
INFO - 2024-10-25 16:45:33 --> Language Class Initialized
INFO - 2024-10-25 16:45:33 --> Language Class Initialized
INFO - 2024-10-25 16:45:33 --> Config Class Initialized
INFO - 2024-10-25 16:45:33 --> Loader Class Initialized
INFO - 2024-10-25 16:45:33 --> Helper loaded: url_helper
INFO - 2024-10-25 16:45:33 --> Helper loaded: file_helper
INFO - 2024-10-25 16:45:33 --> Helper loaded: form_helper
INFO - 2024-10-25 16:45:33 --> Helper loaded: my_helper
INFO - 2024-10-25 16:45:33 --> Database Driver Class Initialized
INFO - 2024-10-25 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:45:33 --> Controller Class Initialized
ERROR - 2024-10-25 16:45:33 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-25 16:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-25 16:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 16:45:33 --> Final output sent to browser
DEBUG - 2024-10-25 16:45:33 --> Total execution time: 0.0378
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:46:00 --> Utf8 Class Initialized
INFO - 2024-10-25 16:46:00 --> URI Class Initialized
INFO - 2024-10-25 16:46:00 --> Router Class Initialized
INFO - 2024-10-25 16:46:00 --> Output Class Initialized
INFO - 2024-10-25 16:46:00 --> Security Class Initialized
DEBUG - 2024-10-25 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:46:00 --> Input Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Loader Class Initialized
INFO - 2024-10-25 16:46:00 --> Helper loaded: url_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: file_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: form_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: my_helper
INFO - 2024-10-25 16:46:00 --> Database Driver Class Initialized
INFO - 2024-10-25 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:46:00 --> Controller Class Initialized
INFO - 2024-10-25 16:46:00 --> Upload Class Initialized
INFO - 2024-10-25 16:46:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-25 16:46:00 --> The upload path does not appear to be valid.
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:46:00 --> Utf8 Class Initialized
INFO - 2024-10-25 16:46:00 --> URI Class Initialized
INFO - 2024-10-25 16:46:00 --> Router Class Initialized
INFO - 2024-10-25 16:46:00 --> Output Class Initialized
INFO - 2024-10-25 16:46:00 --> Security Class Initialized
DEBUG - 2024-10-25 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:46:00 --> Input Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Loader Class Initialized
INFO - 2024-10-25 16:46:00 --> Helper loaded: url_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: file_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: form_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: my_helper
INFO - 2024-10-25 16:46:00 --> Database Driver Class Initialized
INFO - 2024-10-25 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:46:00 --> Controller Class Initialized
DEBUG - 2024-10-25 16:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-25 16:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-25 16:46:00 --> Final output sent to browser
DEBUG - 2024-10-25 16:46:00 --> Total execution time: 0.0297
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:46:00 --> Utf8 Class Initialized
INFO - 2024-10-25 16:46:00 --> URI Class Initialized
INFO - 2024-10-25 16:46:00 --> Router Class Initialized
INFO - 2024-10-25 16:46:00 --> Output Class Initialized
INFO - 2024-10-25 16:46:00 --> Security Class Initialized
DEBUG - 2024-10-25 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:46:00 --> Input Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
ERROR - 2024-10-25 16:46:00 --> 404 Page Not Found: /index
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:46:00 --> Utf8 Class Initialized
INFO - 2024-10-25 16:46:00 --> URI Class Initialized
INFO - 2024-10-25 16:46:00 --> Router Class Initialized
INFO - 2024-10-25 16:46:00 --> Output Class Initialized
INFO - 2024-10-25 16:46:00 --> Security Class Initialized
DEBUG - 2024-10-25 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:46:00 --> Input Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Language Class Initialized
INFO - 2024-10-25 16:46:00 --> Config Class Initialized
INFO - 2024-10-25 16:46:00 --> Loader Class Initialized
INFO - 2024-10-25 16:46:00 --> Helper loaded: url_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: file_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: form_helper
INFO - 2024-10-25 16:46:00 --> Helper loaded: my_helper
INFO - 2024-10-25 16:46:00 --> Database Driver Class Initialized
INFO - 2024-10-25 16:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:46:00 --> Controller Class Initialized
