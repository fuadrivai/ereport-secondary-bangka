<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-02 06:21:00 --> Config Class Initialized
INFO - 2020-02-02 06:21:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:21:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:21:00 --> Utf8 Class Initialized
INFO - 2020-02-02 06:21:00 --> URI Class Initialized
DEBUG - 2020-02-02 06:21:00 --> No URI present. Default controller set.
INFO - 2020-02-02 06:21:00 --> Router Class Initialized
INFO - 2020-02-02 06:21:00 --> Output Class Initialized
INFO - 2020-02-02 06:21:00 --> Security Class Initialized
DEBUG - 2020-02-02 06:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:21:00 --> Input Class Initialized
INFO - 2020-02-02 06:21:00 --> Language Class Initialized
INFO - 2020-02-02 06:21:00 --> Language Class Initialized
INFO - 2020-02-02 06:21:00 --> Config Class Initialized
INFO - 2020-02-02 06:21:00 --> Loader Class Initialized
INFO - 2020-02-02 06:21:00 --> Helper loaded: url_helper
INFO - 2020-02-02 06:21:00 --> Helper loaded: file_helper
INFO - 2020-02-02 06:21:00 --> Helper loaded: form_helper
INFO - 2020-02-02 06:21:01 --> Helper loaded: my_helper
INFO - 2020-02-02 06:21:01 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:21:01 --> Controller Class Initialized
INFO - 2020-02-02 06:21:45 --> Config Class Initialized
INFO - 2020-02-02 06:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:21:46 --> Utf8 Class Initialized
INFO - 2020-02-02 06:21:46 --> URI Class Initialized
DEBUG - 2020-02-02 06:21:46 --> No URI present. Default controller set.
INFO - 2020-02-02 06:21:46 --> Router Class Initialized
INFO - 2020-02-02 06:21:46 --> Output Class Initialized
INFO - 2020-02-02 06:21:46 --> Security Class Initialized
DEBUG - 2020-02-02 06:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:21:46 --> Input Class Initialized
INFO - 2020-02-02 06:21:46 --> Language Class Initialized
INFO - 2020-02-02 06:21:46 --> Language Class Initialized
INFO - 2020-02-02 06:21:46 --> Config Class Initialized
INFO - 2020-02-02 06:21:46 --> Loader Class Initialized
INFO - 2020-02-02 06:21:46 --> Helper loaded: url_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: file_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: form_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: my_helper
INFO - 2020-02-02 06:21:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:21:46 --> Controller Class Initialized
INFO - 2020-02-02 06:21:46 --> Config Class Initialized
INFO - 2020-02-02 06:21:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:21:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:21:46 --> Utf8 Class Initialized
INFO - 2020-02-02 06:21:46 --> URI Class Initialized
INFO - 2020-02-02 06:21:46 --> Router Class Initialized
INFO - 2020-02-02 06:21:46 --> Output Class Initialized
INFO - 2020-02-02 06:21:46 --> Security Class Initialized
DEBUG - 2020-02-02 06:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:21:46 --> Input Class Initialized
INFO - 2020-02-02 06:21:46 --> Language Class Initialized
INFO - 2020-02-02 06:21:46 --> Language Class Initialized
INFO - 2020-02-02 06:21:46 --> Config Class Initialized
INFO - 2020-02-02 06:21:46 --> Loader Class Initialized
INFO - 2020-02-02 06:21:46 --> Helper loaded: url_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: file_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: form_helper
INFO - 2020-02-02 06:21:46 --> Helper loaded: my_helper
INFO - 2020-02-02 06:21:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:21:46 --> Controller Class Initialized
DEBUG - 2020-02-02 06:21:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-02 06:21:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:21:46 --> Final output sent to browser
DEBUG - 2020-02-02 06:21:46 --> Total execution time: 0.2491
INFO - 2020-02-02 06:22:13 --> Config Class Initialized
INFO - 2020-02-02 06:22:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:22:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:22:13 --> Utf8 Class Initialized
INFO - 2020-02-02 06:22:13 --> URI Class Initialized
INFO - 2020-02-02 06:22:13 --> Router Class Initialized
INFO - 2020-02-02 06:22:13 --> Output Class Initialized
INFO - 2020-02-02 06:22:13 --> Security Class Initialized
DEBUG - 2020-02-02 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:22:13 --> Input Class Initialized
INFO - 2020-02-02 06:22:13 --> Language Class Initialized
INFO - 2020-02-02 06:22:13 --> Language Class Initialized
INFO - 2020-02-02 06:22:13 --> Config Class Initialized
INFO - 2020-02-02 06:22:13 --> Loader Class Initialized
INFO - 2020-02-02 06:22:13 --> Helper loaded: url_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: file_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: form_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: my_helper
INFO - 2020-02-02 06:22:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:22:13 --> Controller Class Initialized
INFO - 2020-02-02 06:22:13 --> Helper loaded: cookie_helper
INFO - 2020-02-02 06:22:13 --> Final output sent to browser
DEBUG - 2020-02-02 06:22:13 --> Total execution time: 0.2738
INFO - 2020-02-02 06:22:13 --> Config Class Initialized
INFO - 2020-02-02 06:22:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:22:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:22:13 --> Utf8 Class Initialized
INFO - 2020-02-02 06:22:13 --> URI Class Initialized
INFO - 2020-02-02 06:22:13 --> Router Class Initialized
INFO - 2020-02-02 06:22:13 --> Output Class Initialized
INFO - 2020-02-02 06:22:13 --> Security Class Initialized
DEBUG - 2020-02-02 06:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:22:13 --> Input Class Initialized
INFO - 2020-02-02 06:22:13 --> Language Class Initialized
INFO - 2020-02-02 06:22:13 --> Language Class Initialized
INFO - 2020-02-02 06:22:13 --> Config Class Initialized
INFO - 2020-02-02 06:22:13 --> Loader Class Initialized
INFO - 2020-02-02 06:22:13 --> Helper loaded: url_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: file_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: form_helper
INFO - 2020-02-02 06:22:13 --> Helper loaded: my_helper
INFO - 2020-02-02 06:22:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:22:13 --> Controller Class Initialized
DEBUG - 2020-02-02 06:22:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:22:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:22:13 --> Final output sent to browser
DEBUG - 2020-02-02 06:22:13 --> Total execution time: 0.4027
INFO - 2020-02-02 06:24:32 --> Config Class Initialized
INFO - 2020-02-02 06:24:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:24:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:24:32 --> Utf8 Class Initialized
INFO - 2020-02-02 06:24:32 --> URI Class Initialized
INFO - 2020-02-02 06:24:32 --> Router Class Initialized
INFO - 2020-02-02 06:24:32 --> Output Class Initialized
INFO - 2020-02-02 06:24:32 --> Security Class Initialized
DEBUG - 2020-02-02 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:24:32 --> Input Class Initialized
INFO - 2020-02-02 06:24:32 --> Language Class Initialized
INFO - 2020-02-02 06:24:32 --> Language Class Initialized
INFO - 2020-02-02 06:24:32 --> Config Class Initialized
INFO - 2020-02-02 06:24:32 --> Loader Class Initialized
INFO - 2020-02-02 06:24:32 --> Helper loaded: url_helper
INFO - 2020-02-02 06:24:32 --> Helper loaded: file_helper
INFO - 2020-02-02 06:24:32 --> Helper loaded: form_helper
INFO - 2020-02-02 06:24:32 --> Helper loaded: my_helper
INFO - 2020-02-02 06:24:32 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:24:32 --> Controller Class Initialized
DEBUG - 2020-02-02 06:24:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:24:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:24:32 --> Final output sent to browser
DEBUG - 2020-02-02 06:24:32 --> Total execution time: 0.3192
INFO - 2020-02-02 06:24:42 --> Config Class Initialized
INFO - 2020-02-02 06:24:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:24:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:24:42 --> Utf8 Class Initialized
INFO - 2020-02-02 06:24:42 --> URI Class Initialized
INFO - 2020-02-02 06:24:42 --> Router Class Initialized
INFO - 2020-02-02 06:24:42 --> Output Class Initialized
INFO - 2020-02-02 06:24:42 --> Security Class Initialized
DEBUG - 2020-02-02 06:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:24:42 --> Input Class Initialized
INFO - 2020-02-02 06:24:42 --> Language Class Initialized
INFO - 2020-02-02 06:24:42 --> Language Class Initialized
INFO - 2020-02-02 06:24:42 --> Config Class Initialized
INFO - 2020-02-02 06:24:42 --> Loader Class Initialized
INFO - 2020-02-02 06:24:42 --> Helper loaded: url_helper
INFO - 2020-02-02 06:24:42 --> Helper loaded: file_helper
INFO - 2020-02-02 06:24:42 --> Helper loaded: form_helper
INFO - 2020-02-02 06:24:42 --> Helper loaded: my_helper
INFO - 2020-02-02 06:24:42 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:24:42 --> Controller Class Initialized
DEBUG - 2020-02-02 06:24:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:24:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:24:42 --> Final output sent to browser
DEBUG - 2020-02-02 06:24:43 --> Total execution time: 0.3322
INFO - 2020-02-02 06:25:20 --> Config Class Initialized
INFO - 2020-02-02 06:25:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:25:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:25:20 --> Utf8 Class Initialized
INFO - 2020-02-02 06:25:20 --> URI Class Initialized
INFO - 2020-02-02 06:25:20 --> Router Class Initialized
INFO - 2020-02-02 06:25:20 --> Output Class Initialized
INFO - 2020-02-02 06:25:20 --> Security Class Initialized
DEBUG - 2020-02-02 06:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:25:20 --> Input Class Initialized
INFO - 2020-02-02 06:25:20 --> Language Class Initialized
INFO - 2020-02-02 06:25:20 --> Language Class Initialized
INFO - 2020-02-02 06:25:20 --> Config Class Initialized
INFO - 2020-02-02 06:25:20 --> Loader Class Initialized
INFO - 2020-02-02 06:25:20 --> Helper loaded: url_helper
INFO - 2020-02-02 06:25:20 --> Helper loaded: file_helper
INFO - 2020-02-02 06:25:20 --> Helper loaded: form_helper
INFO - 2020-02-02 06:25:20 --> Helper loaded: my_helper
INFO - 2020-02-02 06:25:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:25:20 --> Controller Class Initialized
DEBUG - 2020-02-02 06:25:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:25:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:25:20 --> Final output sent to browser
DEBUG - 2020-02-02 06:25:20 --> Total execution time: 0.4036
INFO - 2020-02-02 06:27:06 --> Config Class Initialized
INFO - 2020-02-02 06:27:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:27:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:27:06 --> Utf8 Class Initialized
INFO - 2020-02-02 06:27:06 --> URI Class Initialized
INFO - 2020-02-02 06:27:06 --> Router Class Initialized
INFO - 2020-02-02 06:27:06 --> Output Class Initialized
INFO - 2020-02-02 06:27:06 --> Security Class Initialized
DEBUG - 2020-02-02 06:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:27:06 --> Input Class Initialized
INFO - 2020-02-02 06:27:06 --> Language Class Initialized
INFO - 2020-02-02 06:27:06 --> Language Class Initialized
INFO - 2020-02-02 06:27:06 --> Config Class Initialized
INFO - 2020-02-02 06:27:06 --> Loader Class Initialized
INFO - 2020-02-02 06:27:06 --> Helper loaded: url_helper
INFO - 2020-02-02 06:27:06 --> Helper loaded: file_helper
INFO - 2020-02-02 06:27:06 --> Helper loaded: form_helper
INFO - 2020-02-02 06:27:06 --> Helper loaded: my_helper
INFO - 2020-02-02 06:27:06 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:27:06 --> Controller Class Initialized
DEBUG - 2020-02-02 06:27:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:27:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:27:06 --> Final output sent to browser
DEBUG - 2020-02-02 06:27:06 --> Total execution time: 0.3419
INFO - 2020-02-02 06:27:13 --> Config Class Initialized
INFO - 2020-02-02 06:27:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:27:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:27:13 --> Utf8 Class Initialized
INFO - 2020-02-02 06:27:13 --> URI Class Initialized
INFO - 2020-02-02 06:27:13 --> Router Class Initialized
INFO - 2020-02-02 06:27:13 --> Output Class Initialized
INFO - 2020-02-02 06:27:13 --> Security Class Initialized
DEBUG - 2020-02-02 06:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:27:13 --> Input Class Initialized
INFO - 2020-02-02 06:27:13 --> Language Class Initialized
INFO - 2020-02-02 06:27:13 --> Language Class Initialized
INFO - 2020-02-02 06:27:13 --> Config Class Initialized
INFO - 2020-02-02 06:27:13 --> Loader Class Initialized
INFO - 2020-02-02 06:27:13 --> Helper loaded: url_helper
INFO - 2020-02-02 06:27:13 --> Helper loaded: file_helper
INFO - 2020-02-02 06:27:13 --> Helper loaded: form_helper
INFO - 2020-02-02 06:27:13 --> Helper loaded: my_helper
INFO - 2020-02-02 06:27:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:27:13 --> Controller Class Initialized
DEBUG - 2020-02-02 06:27:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:27:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:27:13 --> Final output sent to browser
DEBUG - 2020-02-02 06:27:13 --> Total execution time: 0.3313
INFO - 2020-02-02 06:27:26 --> Config Class Initialized
INFO - 2020-02-02 06:27:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:27:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:27:26 --> Utf8 Class Initialized
INFO - 2020-02-02 06:27:26 --> URI Class Initialized
INFO - 2020-02-02 06:27:26 --> Router Class Initialized
INFO - 2020-02-02 06:27:26 --> Output Class Initialized
INFO - 2020-02-02 06:27:26 --> Security Class Initialized
DEBUG - 2020-02-02 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:27:26 --> Input Class Initialized
INFO - 2020-02-02 06:27:26 --> Language Class Initialized
INFO - 2020-02-02 06:27:26 --> Language Class Initialized
INFO - 2020-02-02 06:27:27 --> Config Class Initialized
INFO - 2020-02-02 06:27:27 --> Loader Class Initialized
INFO - 2020-02-02 06:27:27 --> Helper loaded: url_helper
INFO - 2020-02-02 06:27:27 --> Helper loaded: file_helper
INFO - 2020-02-02 06:27:27 --> Helper loaded: form_helper
INFO - 2020-02-02 06:27:27 --> Helper loaded: my_helper
INFO - 2020-02-02 06:27:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:27:27 --> Controller Class Initialized
DEBUG - 2020-02-02 06:27:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:27:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:27:27 --> Final output sent to browser
DEBUG - 2020-02-02 06:27:27 --> Total execution time: 0.3292
INFO - 2020-02-02 06:28:07 --> Config Class Initialized
INFO - 2020-02-02 06:28:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:28:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:28:07 --> Utf8 Class Initialized
INFO - 2020-02-02 06:28:07 --> URI Class Initialized
INFO - 2020-02-02 06:28:07 --> Router Class Initialized
INFO - 2020-02-02 06:28:07 --> Output Class Initialized
INFO - 2020-02-02 06:28:07 --> Security Class Initialized
DEBUG - 2020-02-02 06:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:28:07 --> Input Class Initialized
INFO - 2020-02-02 06:28:07 --> Language Class Initialized
INFO - 2020-02-02 06:28:07 --> Language Class Initialized
INFO - 2020-02-02 06:28:07 --> Config Class Initialized
INFO - 2020-02-02 06:28:07 --> Loader Class Initialized
INFO - 2020-02-02 06:28:07 --> Helper loaded: url_helper
INFO - 2020-02-02 06:28:07 --> Helper loaded: file_helper
INFO - 2020-02-02 06:28:07 --> Helper loaded: form_helper
INFO - 2020-02-02 06:28:07 --> Helper loaded: my_helper
INFO - 2020-02-02 06:28:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:28:07 --> Controller Class Initialized
DEBUG - 2020-02-02 06:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:28:07 --> Final output sent to browser
DEBUG - 2020-02-02 06:28:07 --> Total execution time: 0.3647
INFO - 2020-02-02 06:28:11 --> Config Class Initialized
INFO - 2020-02-02 06:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:28:11 --> Utf8 Class Initialized
INFO - 2020-02-02 06:28:11 --> URI Class Initialized
INFO - 2020-02-02 06:28:11 --> Router Class Initialized
INFO - 2020-02-02 06:28:11 --> Output Class Initialized
INFO - 2020-02-02 06:28:11 --> Security Class Initialized
DEBUG - 2020-02-02 06:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:28:11 --> Input Class Initialized
INFO - 2020-02-02 06:28:11 --> Language Class Initialized
INFO - 2020-02-02 06:28:11 --> Language Class Initialized
INFO - 2020-02-02 06:28:11 --> Config Class Initialized
INFO - 2020-02-02 06:28:11 --> Loader Class Initialized
INFO - 2020-02-02 06:28:11 --> Helper loaded: url_helper
INFO - 2020-02-02 06:28:11 --> Helper loaded: file_helper
INFO - 2020-02-02 06:28:11 --> Helper loaded: form_helper
INFO - 2020-02-02 06:28:11 --> Helper loaded: my_helper
INFO - 2020-02-02 06:28:11 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:28:11 --> Controller Class Initialized
DEBUG - 2020-02-02 06:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:28:11 --> Final output sent to browser
DEBUG - 2020-02-02 06:28:11 --> Total execution time: 0.3447
INFO - 2020-02-02 06:28:25 --> Config Class Initialized
INFO - 2020-02-02 06:28:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:28:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:28:25 --> Utf8 Class Initialized
INFO - 2020-02-02 06:28:25 --> URI Class Initialized
INFO - 2020-02-02 06:28:25 --> Router Class Initialized
INFO - 2020-02-02 06:28:25 --> Output Class Initialized
INFO - 2020-02-02 06:28:25 --> Security Class Initialized
DEBUG - 2020-02-02 06:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:28:25 --> Input Class Initialized
INFO - 2020-02-02 06:28:25 --> Language Class Initialized
INFO - 2020-02-02 06:28:25 --> Language Class Initialized
INFO - 2020-02-02 06:28:25 --> Config Class Initialized
INFO - 2020-02-02 06:28:25 --> Loader Class Initialized
INFO - 2020-02-02 06:28:25 --> Helper loaded: url_helper
INFO - 2020-02-02 06:28:25 --> Helper loaded: file_helper
INFO - 2020-02-02 06:28:25 --> Helper loaded: form_helper
INFO - 2020-02-02 06:28:25 --> Helper loaded: my_helper
INFO - 2020-02-02 06:28:25 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:28:25 --> Controller Class Initialized
DEBUG - 2020-02-02 06:28:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:28:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:28:25 --> Final output sent to browser
DEBUG - 2020-02-02 06:28:25 --> Total execution time: 0.3645
INFO - 2020-02-02 06:30:00 --> Config Class Initialized
INFO - 2020-02-02 06:30:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:30:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:30:00 --> Utf8 Class Initialized
INFO - 2020-02-02 06:30:00 --> URI Class Initialized
INFO - 2020-02-02 06:30:00 --> Router Class Initialized
INFO - 2020-02-02 06:30:00 --> Output Class Initialized
INFO - 2020-02-02 06:30:00 --> Security Class Initialized
DEBUG - 2020-02-02 06:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:30:00 --> Input Class Initialized
INFO - 2020-02-02 06:30:00 --> Language Class Initialized
INFO - 2020-02-02 06:30:00 --> Language Class Initialized
INFO - 2020-02-02 06:30:00 --> Config Class Initialized
INFO - 2020-02-02 06:30:00 --> Loader Class Initialized
INFO - 2020-02-02 06:30:00 --> Helper loaded: url_helper
INFO - 2020-02-02 06:30:00 --> Helper loaded: file_helper
INFO - 2020-02-02 06:30:00 --> Helper loaded: form_helper
INFO - 2020-02-02 06:30:00 --> Helper loaded: my_helper
INFO - 2020-02-02 06:30:00 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:30:01 --> Controller Class Initialized
DEBUG - 2020-02-02 06:30:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:30:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:30:01 --> Final output sent to browser
DEBUG - 2020-02-02 06:30:01 --> Total execution time: 0.3753
INFO - 2020-02-02 06:31:26 --> Config Class Initialized
INFO - 2020-02-02 06:31:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:31:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:31:26 --> Utf8 Class Initialized
INFO - 2020-02-02 06:31:26 --> URI Class Initialized
INFO - 2020-02-02 06:31:26 --> Router Class Initialized
INFO - 2020-02-02 06:31:26 --> Output Class Initialized
INFO - 2020-02-02 06:31:26 --> Security Class Initialized
DEBUG - 2020-02-02 06:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:31:26 --> Input Class Initialized
INFO - 2020-02-02 06:31:26 --> Language Class Initialized
INFO - 2020-02-02 06:31:26 --> Language Class Initialized
INFO - 2020-02-02 06:31:26 --> Config Class Initialized
INFO - 2020-02-02 06:31:26 --> Loader Class Initialized
INFO - 2020-02-02 06:31:26 --> Helper loaded: url_helper
INFO - 2020-02-02 06:31:26 --> Helper loaded: file_helper
INFO - 2020-02-02 06:31:26 --> Helper loaded: form_helper
INFO - 2020-02-02 06:31:26 --> Helper loaded: my_helper
INFO - 2020-02-02 06:31:26 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:31:26 --> Controller Class Initialized
DEBUG - 2020-02-02 06:31:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:31:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:31:26 --> Final output sent to browser
DEBUG - 2020-02-02 06:31:26 --> Total execution time: 0.3121
INFO - 2020-02-02 06:31:27 --> Config Class Initialized
INFO - 2020-02-02 06:31:27 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:31:27 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:31:27 --> Utf8 Class Initialized
INFO - 2020-02-02 06:31:27 --> URI Class Initialized
INFO - 2020-02-02 06:31:27 --> Router Class Initialized
INFO - 2020-02-02 06:31:27 --> Output Class Initialized
INFO - 2020-02-02 06:31:27 --> Security Class Initialized
DEBUG - 2020-02-02 06:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:31:27 --> Input Class Initialized
INFO - 2020-02-02 06:31:27 --> Language Class Initialized
INFO - 2020-02-02 06:31:27 --> Language Class Initialized
INFO - 2020-02-02 06:31:27 --> Config Class Initialized
INFO - 2020-02-02 06:31:27 --> Loader Class Initialized
INFO - 2020-02-02 06:31:27 --> Helper loaded: url_helper
INFO - 2020-02-02 06:31:27 --> Helper loaded: file_helper
INFO - 2020-02-02 06:31:27 --> Helper loaded: form_helper
INFO - 2020-02-02 06:31:27 --> Helper loaded: my_helper
INFO - 2020-02-02 06:31:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:31:27 --> Controller Class Initialized
DEBUG - 2020-02-02 06:31:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:31:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:31:27 --> Final output sent to browser
DEBUG - 2020-02-02 06:31:27 --> Total execution time: 0.3057
INFO - 2020-02-02 06:31:58 --> Config Class Initialized
INFO - 2020-02-02 06:31:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:31:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:31:58 --> Utf8 Class Initialized
INFO - 2020-02-02 06:31:58 --> URI Class Initialized
INFO - 2020-02-02 06:31:58 --> Router Class Initialized
INFO - 2020-02-02 06:31:58 --> Output Class Initialized
INFO - 2020-02-02 06:31:58 --> Security Class Initialized
DEBUG - 2020-02-02 06:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:31:58 --> Input Class Initialized
INFO - 2020-02-02 06:31:58 --> Language Class Initialized
INFO - 2020-02-02 06:31:58 --> Language Class Initialized
INFO - 2020-02-02 06:31:58 --> Config Class Initialized
INFO - 2020-02-02 06:31:58 --> Loader Class Initialized
INFO - 2020-02-02 06:31:58 --> Helper loaded: url_helper
INFO - 2020-02-02 06:31:58 --> Helper loaded: file_helper
INFO - 2020-02-02 06:31:58 --> Helper loaded: form_helper
INFO - 2020-02-02 06:31:59 --> Helper loaded: my_helper
INFO - 2020-02-02 06:31:59 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:31:59 --> Controller Class Initialized
DEBUG - 2020-02-02 06:31:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:31:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:31:59 --> Final output sent to browser
DEBUG - 2020-02-02 06:31:59 --> Total execution time: 0.3245
INFO - 2020-02-02 06:32:00 --> Config Class Initialized
INFO - 2020-02-02 06:32:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:32:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:32:00 --> Utf8 Class Initialized
INFO - 2020-02-02 06:32:00 --> URI Class Initialized
INFO - 2020-02-02 06:32:00 --> Router Class Initialized
INFO - 2020-02-02 06:32:00 --> Output Class Initialized
INFO - 2020-02-02 06:32:00 --> Security Class Initialized
DEBUG - 2020-02-02 06:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:32:00 --> Input Class Initialized
INFO - 2020-02-02 06:32:00 --> Language Class Initialized
INFO - 2020-02-02 06:32:00 --> Language Class Initialized
INFO - 2020-02-02 06:32:00 --> Config Class Initialized
INFO - 2020-02-02 06:32:00 --> Loader Class Initialized
INFO - 2020-02-02 06:32:00 --> Helper loaded: url_helper
INFO - 2020-02-02 06:32:00 --> Helper loaded: file_helper
INFO - 2020-02-02 06:32:00 --> Helper loaded: form_helper
INFO - 2020-02-02 06:32:00 --> Helper loaded: my_helper
INFO - 2020-02-02 06:32:00 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:32:00 --> Controller Class Initialized
DEBUG - 2020-02-02 06:32:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:32:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:32:00 --> Final output sent to browser
DEBUG - 2020-02-02 06:32:00 --> Total execution time: 0.4546
INFO - 2020-02-02 06:32:32 --> Config Class Initialized
INFO - 2020-02-02 06:32:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:32:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:32:32 --> Utf8 Class Initialized
INFO - 2020-02-02 06:32:32 --> URI Class Initialized
INFO - 2020-02-02 06:32:32 --> Router Class Initialized
INFO - 2020-02-02 06:32:32 --> Output Class Initialized
INFO - 2020-02-02 06:32:32 --> Security Class Initialized
DEBUG - 2020-02-02 06:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:32:32 --> Input Class Initialized
INFO - 2020-02-02 06:32:32 --> Language Class Initialized
INFO - 2020-02-02 06:32:32 --> Language Class Initialized
INFO - 2020-02-02 06:32:32 --> Config Class Initialized
INFO - 2020-02-02 06:32:32 --> Loader Class Initialized
INFO - 2020-02-02 06:32:32 --> Helper loaded: url_helper
INFO - 2020-02-02 06:32:32 --> Helper loaded: file_helper
INFO - 2020-02-02 06:32:32 --> Helper loaded: form_helper
INFO - 2020-02-02 06:32:32 --> Helper loaded: my_helper
INFO - 2020-02-02 06:32:32 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:32:32 --> Controller Class Initialized
DEBUG - 2020-02-02 06:32:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:32:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:32:33 --> Final output sent to browser
DEBUG - 2020-02-02 06:32:33 --> Total execution time: 0.3327
INFO - 2020-02-02 06:32:33 --> Config Class Initialized
INFO - 2020-02-02 06:32:33 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:32:33 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:32:33 --> Utf8 Class Initialized
INFO - 2020-02-02 06:32:33 --> URI Class Initialized
INFO - 2020-02-02 06:32:33 --> Router Class Initialized
INFO - 2020-02-02 06:32:33 --> Output Class Initialized
INFO - 2020-02-02 06:32:33 --> Security Class Initialized
DEBUG - 2020-02-02 06:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:32:33 --> Input Class Initialized
INFO - 2020-02-02 06:32:33 --> Language Class Initialized
INFO - 2020-02-02 06:32:33 --> Language Class Initialized
INFO - 2020-02-02 06:32:33 --> Config Class Initialized
INFO - 2020-02-02 06:32:33 --> Loader Class Initialized
INFO - 2020-02-02 06:32:33 --> Helper loaded: url_helper
INFO - 2020-02-02 06:32:33 --> Helper loaded: file_helper
INFO - 2020-02-02 06:32:33 --> Helper loaded: form_helper
INFO - 2020-02-02 06:32:33 --> Helper loaded: my_helper
INFO - 2020-02-02 06:32:33 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:32:34 --> Controller Class Initialized
DEBUG - 2020-02-02 06:32:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:32:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:32:34 --> Final output sent to browser
DEBUG - 2020-02-02 06:32:34 --> Total execution time: 0.3273
INFO - 2020-02-02 06:32:35 --> Config Class Initialized
INFO - 2020-02-02 06:32:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:32:35 --> Utf8 Class Initialized
INFO - 2020-02-02 06:32:35 --> URI Class Initialized
INFO - 2020-02-02 06:32:35 --> Router Class Initialized
INFO - 2020-02-02 06:32:35 --> Output Class Initialized
INFO - 2020-02-02 06:32:35 --> Security Class Initialized
DEBUG - 2020-02-02 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:32:35 --> Input Class Initialized
INFO - 2020-02-02 06:32:35 --> Language Class Initialized
INFO - 2020-02-02 06:32:35 --> Language Class Initialized
INFO - 2020-02-02 06:32:35 --> Config Class Initialized
INFO - 2020-02-02 06:32:35 --> Loader Class Initialized
INFO - 2020-02-02 06:32:35 --> Helper loaded: url_helper
INFO - 2020-02-02 06:32:35 --> Helper loaded: file_helper
INFO - 2020-02-02 06:32:35 --> Helper loaded: form_helper
INFO - 2020-02-02 06:32:35 --> Helper loaded: my_helper
INFO - 2020-02-02 06:32:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:32:35 --> Controller Class Initialized
DEBUG - 2020-02-02 06:32:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:32:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:32:35 --> Final output sent to browser
DEBUG - 2020-02-02 06:32:35 --> Total execution time: 0.4322
INFO - 2020-02-02 06:32:45 --> Config Class Initialized
INFO - 2020-02-02 06:32:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:32:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:32:45 --> Utf8 Class Initialized
INFO - 2020-02-02 06:32:45 --> URI Class Initialized
INFO - 2020-02-02 06:32:45 --> Router Class Initialized
INFO - 2020-02-02 06:32:45 --> Output Class Initialized
INFO - 2020-02-02 06:32:45 --> Security Class Initialized
DEBUG - 2020-02-02 06:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:32:45 --> Input Class Initialized
INFO - 2020-02-02 06:32:45 --> Language Class Initialized
INFO - 2020-02-02 06:32:45 --> Language Class Initialized
INFO - 2020-02-02 06:32:45 --> Config Class Initialized
INFO - 2020-02-02 06:32:45 --> Loader Class Initialized
INFO - 2020-02-02 06:32:45 --> Helper loaded: url_helper
INFO - 2020-02-02 06:32:45 --> Helper loaded: file_helper
INFO - 2020-02-02 06:32:45 --> Helper loaded: form_helper
INFO - 2020-02-02 06:32:45 --> Helper loaded: my_helper
INFO - 2020-02-02 06:32:45 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:32:45 --> Controller Class Initialized
DEBUG - 2020-02-02 06:32:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:32:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:32:45 --> Final output sent to browser
DEBUG - 2020-02-02 06:32:45 --> Total execution time: 0.3468
INFO - 2020-02-02 06:33:22 --> Config Class Initialized
INFO - 2020-02-02 06:33:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:33:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:33:22 --> Utf8 Class Initialized
INFO - 2020-02-02 06:33:22 --> URI Class Initialized
INFO - 2020-02-02 06:33:22 --> Router Class Initialized
INFO - 2020-02-02 06:33:22 --> Output Class Initialized
INFO - 2020-02-02 06:33:23 --> Security Class Initialized
DEBUG - 2020-02-02 06:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:33:23 --> Input Class Initialized
INFO - 2020-02-02 06:33:23 --> Language Class Initialized
INFO - 2020-02-02 06:33:23 --> Language Class Initialized
INFO - 2020-02-02 06:33:23 --> Config Class Initialized
INFO - 2020-02-02 06:33:23 --> Loader Class Initialized
INFO - 2020-02-02 06:33:23 --> Helper loaded: url_helper
INFO - 2020-02-02 06:33:23 --> Helper loaded: file_helper
INFO - 2020-02-02 06:33:23 --> Helper loaded: form_helper
INFO - 2020-02-02 06:33:23 --> Helper loaded: my_helper
INFO - 2020-02-02 06:33:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:33:23 --> Controller Class Initialized
DEBUG - 2020-02-02 06:33:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:33:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:33:23 --> Final output sent to browser
DEBUG - 2020-02-02 06:33:23 --> Total execution time: 0.3382
INFO - 2020-02-02 06:35:23 --> Config Class Initialized
INFO - 2020-02-02 06:35:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:35:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:35:23 --> Utf8 Class Initialized
INFO - 2020-02-02 06:35:23 --> URI Class Initialized
INFO - 2020-02-02 06:35:23 --> Router Class Initialized
INFO - 2020-02-02 06:35:23 --> Output Class Initialized
INFO - 2020-02-02 06:35:23 --> Security Class Initialized
DEBUG - 2020-02-02 06:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:35:23 --> Input Class Initialized
INFO - 2020-02-02 06:35:23 --> Language Class Initialized
INFO - 2020-02-02 06:35:23 --> Language Class Initialized
INFO - 2020-02-02 06:35:23 --> Config Class Initialized
INFO - 2020-02-02 06:35:23 --> Loader Class Initialized
INFO - 2020-02-02 06:35:23 --> Helper loaded: url_helper
INFO - 2020-02-02 06:35:23 --> Helper loaded: file_helper
INFO - 2020-02-02 06:35:23 --> Helper loaded: form_helper
INFO - 2020-02-02 06:35:23 --> Helper loaded: my_helper
INFO - 2020-02-02 06:35:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:35:23 --> Controller Class Initialized
DEBUG - 2020-02-02 06:35:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:35:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:35:23 --> Final output sent to browser
DEBUG - 2020-02-02 06:35:23 --> Total execution time: 0.3617
INFO - 2020-02-02 06:35:41 --> Config Class Initialized
INFO - 2020-02-02 06:35:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:35:41 --> Utf8 Class Initialized
INFO - 2020-02-02 06:35:41 --> URI Class Initialized
INFO - 2020-02-02 06:35:41 --> Router Class Initialized
INFO - 2020-02-02 06:35:41 --> Output Class Initialized
INFO - 2020-02-02 06:35:41 --> Security Class Initialized
DEBUG - 2020-02-02 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:35:41 --> Input Class Initialized
INFO - 2020-02-02 06:35:41 --> Language Class Initialized
INFO - 2020-02-02 06:35:41 --> Language Class Initialized
INFO - 2020-02-02 06:35:41 --> Config Class Initialized
INFO - 2020-02-02 06:35:41 --> Loader Class Initialized
INFO - 2020-02-02 06:35:41 --> Helper loaded: url_helper
INFO - 2020-02-02 06:35:41 --> Helper loaded: file_helper
INFO - 2020-02-02 06:35:41 --> Helper loaded: form_helper
INFO - 2020-02-02 06:35:41 --> Helper loaded: my_helper
INFO - 2020-02-02 06:35:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:35:41 --> Controller Class Initialized
DEBUG - 2020-02-02 06:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:35:41 --> Final output sent to browser
DEBUG - 2020-02-02 06:35:42 --> Total execution time: 0.3563
INFO - 2020-02-02 06:39:42 --> Config Class Initialized
INFO - 2020-02-02 06:39:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:39:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:39:42 --> Utf8 Class Initialized
INFO - 2020-02-02 06:39:42 --> URI Class Initialized
INFO - 2020-02-02 06:39:42 --> Router Class Initialized
INFO - 2020-02-02 06:39:42 --> Output Class Initialized
INFO - 2020-02-02 06:39:42 --> Security Class Initialized
DEBUG - 2020-02-02 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:39:42 --> Input Class Initialized
INFO - 2020-02-02 06:39:42 --> Language Class Initialized
INFO - 2020-02-02 06:39:42 --> Language Class Initialized
INFO - 2020-02-02 06:39:42 --> Config Class Initialized
INFO - 2020-02-02 06:39:42 --> Loader Class Initialized
INFO - 2020-02-02 06:39:42 --> Helper loaded: url_helper
INFO - 2020-02-02 06:39:42 --> Helper loaded: file_helper
INFO - 2020-02-02 06:39:42 --> Helper loaded: form_helper
INFO - 2020-02-02 06:39:42 --> Helper loaded: my_helper
INFO - 2020-02-02 06:39:42 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:39:42 --> Controller Class Initialized
DEBUG - 2020-02-02 06:39:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:39:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:39:42 --> Final output sent to browser
DEBUG - 2020-02-02 06:39:42 --> Total execution time: 0.3491
INFO - 2020-02-02 06:40:44 --> Config Class Initialized
INFO - 2020-02-02 06:40:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:40:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:40:44 --> Utf8 Class Initialized
INFO - 2020-02-02 06:40:44 --> URI Class Initialized
INFO - 2020-02-02 06:40:44 --> Router Class Initialized
INFO - 2020-02-02 06:40:44 --> Output Class Initialized
INFO - 2020-02-02 06:40:44 --> Security Class Initialized
DEBUG - 2020-02-02 06:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:40:44 --> Input Class Initialized
INFO - 2020-02-02 06:40:44 --> Language Class Initialized
INFO - 2020-02-02 06:40:44 --> Language Class Initialized
INFO - 2020-02-02 06:40:44 --> Config Class Initialized
INFO - 2020-02-02 06:40:44 --> Loader Class Initialized
INFO - 2020-02-02 06:40:44 --> Helper loaded: url_helper
INFO - 2020-02-02 06:40:44 --> Helper loaded: file_helper
INFO - 2020-02-02 06:40:44 --> Helper loaded: form_helper
INFO - 2020-02-02 06:40:44 --> Helper loaded: my_helper
INFO - 2020-02-02 06:40:44 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:40:44 --> Controller Class Initialized
DEBUG - 2020-02-02 06:40:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:40:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:40:44 --> Final output sent to browser
DEBUG - 2020-02-02 06:40:44 --> Total execution time: 0.3617
INFO - 2020-02-02 06:40:47 --> Config Class Initialized
INFO - 2020-02-02 06:40:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:40:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:40:47 --> Utf8 Class Initialized
INFO - 2020-02-02 06:40:47 --> URI Class Initialized
INFO - 2020-02-02 06:40:47 --> Router Class Initialized
INFO - 2020-02-02 06:40:47 --> Output Class Initialized
INFO - 2020-02-02 06:40:47 --> Security Class Initialized
DEBUG - 2020-02-02 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:40:47 --> Input Class Initialized
INFO - 2020-02-02 06:40:47 --> Language Class Initialized
INFO - 2020-02-02 06:40:47 --> Language Class Initialized
INFO - 2020-02-02 06:40:47 --> Config Class Initialized
INFO - 2020-02-02 06:40:47 --> Loader Class Initialized
INFO - 2020-02-02 06:40:47 --> Helper loaded: url_helper
INFO - 2020-02-02 06:40:47 --> Helper loaded: file_helper
INFO - 2020-02-02 06:40:47 --> Helper loaded: form_helper
INFO - 2020-02-02 06:40:47 --> Helper loaded: my_helper
INFO - 2020-02-02 06:40:47 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:40:47 --> Controller Class Initialized
DEBUG - 2020-02-02 06:40:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:40:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:40:47 --> Final output sent to browser
DEBUG - 2020-02-02 06:40:47 --> Total execution time: 0.3867
INFO - 2020-02-02 06:41:12 --> Config Class Initialized
INFO - 2020-02-02 06:41:12 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:41:12 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:41:12 --> Utf8 Class Initialized
INFO - 2020-02-02 06:41:12 --> URI Class Initialized
INFO - 2020-02-02 06:41:12 --> Router Class Initialized
INFO - 2020-02-02 06:41:12 --> Output Class Initialized
INFO - 2020-02-02 06:41:12 --> Security Class Initialized
DEBUG - 2020-02-02 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:41:12 --> Input Class Initialized
INFO - 2020-02-02 06:41:12 --> Language Class Initialized
INFO - 2020-02-02 06:41:12 --> Language Class Initialized
INFO - 2020-02-02 06:41:12 --> Config Class Initialized
INFO - 2020-02-02 06:41:12 --> Loader Class Initialized
INFO - 2020-02-02 06:41:12 --> Helper loaded: url_helper
INFO - 2020-02-02 06:41:12 --> Helper loaded: file_helper
INFO - 2020-02-02 06:41:12 --> Helper loaded: form_helper
INFO - 2020-02-02 06:41:12 --> Helper loaded: my_helper
INFO - 2020-02-02 06:41:12 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:41:12 --> Controller Class Initialized
DEBUG - 2020-02-02 06:41:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:41:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:41:12 --> Final output sent to browser
DEBUG - 2020-02-02 06:41:12 --> Total execution time: 0.3660
INFO - 2020-02-02 06:41:15 --> Config Class Initialized
INFO - 2020-02-02 06:41:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:41:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:41:15 --> Utf8 Class Initialized
INFO - 2020-02-02 06:41:15 --> URI Class Initialized
INFO - 2020-02-02 06:41:15 --> Router Class Initialized
INFO - 2020-02-02 06:41:15 --> Output Class Initialized
INFO - 2020-02-02 06:41:15 --> Security Class Initialized
DEBUG - 2020-02-02 06:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:41:15 --> Input Class Initialized
INFO - 2020-02-02 06:41:15 --> Language Class Initialized
INFO - 2020-02-02 06:41:15 --> Language Class Initialized
INFO - 2020-02-02 06:41:15 --> Config Class Initialized
INFO - 2020-02-02 06:41:15 --> Loader Class Initialized
INFO - 2020-02-02 06:41:15 --> Helper loaded: url_helper
INFO - 2020-02-02 06:41:15 --> Helper loaded: file_helper
INFO - 2020-02-02 06:41:15 --> Helper loaded: form_helper
INFO - 2020-02-02 06:41:15 --> Helper loaded: my_helper
INFO - 2020-02-02 06:41:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:41:15 --> Controller Class Initialized
DEBUG - 2020-02-02 06:41:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:41:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:41:15 --> Final output sent to browser
DEBUG - 2020-02-02 06:41:15 --> Total execution time: 0.3743
INFO - 2020-02-02 06:42:43 --> Config Class Initialized
INFO - 2020-02-02 06:42:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:42:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:42:43 --> Utf8 Class Initialized
INFO - 2020-02-02 06:42:43 --> URI Class Initialized
INFO - 2020-02-02 06:42:43 --> Router Class Initialized
INFO - 2020-02-02 06:42:43 --> Output Class Initialized
INFO - 2020-02-02 06:42:43 --> Security Class Initialized
DEBUG - 2020-02-02 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:42:43 --> Input Class Initialized
INFO - 2020-02-02 06:42:43 --> Language Class Initialized
INFO - 2020-02-02 06:42:43 --> Language Class Initialized
INFO - 2020-02-02 06:42:43 --> Config Class Initialized
INFO - 2020-02-02 06:42:43 --> Loader Class Initialized
INFO - 2020-02-02 06:42:43 --> Helper loaded: url_helper
INFO - 2020-02-02 06:42:43 --> Helper loaded: file_helper
INFO - 2020-02-02 06:42:43 --> Helper loaded: form_helper
INFO - 2020-02-02 06:42:43 --> Helper loaded: my_helper
INFO - 2020-02-02 06:42:43 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:42:43 --> Controller Class Initialized
DEBUG - 2020-02-02 06:42:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:42:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:42:43 --> Final output sent to browser
DEBUG - 2020-02-02 06:42:43 --> Total execution time: 0.3717
INFO - 2020-02-02 06:42:45 --> Config Class Initialized
INFO - 2020-02-02 06:42:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:42:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:42:45 --> Utf8 Class Initialized
INFO - 2020-02-02 06:42:45 --> URI Class Initialized
INFO - 2020-02-02 06:42:45 --> Router Class Initialized
INFO - 2020-02-02 06:42:45 --> Output Class Initialized
INFO - 2020-02-02 06:42:45 --> Security Class Initialized
DEBUG - 2020-02-02 06:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:42:46 --> Input Class Initialized
INFO - 2020-02-02 06:42:46 --> Language Class Initialized
INFO - 2020-02-02 06:42:46 --> Language Class Initialized
INFO - 2020-02-02 06:42:46 --> Config Class Initialized
INFO - 2020-02-02 06:42:46 --> Loader Class Initialized
INFO - 2020-02-02 06:42:46 --> Helper loaded: url_helper
INFO - 2020-02-02 06:42:46 --> Helper loaded: file_helper
INFO - 2020-02-02 06:42:46 --> Helper loaded: form_helper
INFO - 2020-02-02 06:42:46 --> Helper loaded: my_helper
INFO - 2020-02-02 06:42:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:42:46 --> Controller Class Initialized
DEBUG - 2020-02-02 06:42:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:42:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:42:46 --> Final output sent to browser
DEBUG - 2020-02-02 06:42:46 --> Total execution time: 0.3750
INFO - 2020-02-02 06:42:48 --> Config Class Initialized
INFO - 2020-02-02 06:42:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:42:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:42:48 --> Utf8 Class Initialized
INFO - 2020-02-02 06:42:48 --> URI Class Initialized
INFO - 2020-02-02 06:42:48 --> Router Class Initialized
INFO - 2020-02-02 06:42:48 --> Output Class Initialized
INFO - 2020-02-02 06:42:48 --> Security Class Initialized
DEBUG - 2020-02-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:42:48 --> Input Class Initialized
INFO - 2020-02-02 06:42:48 --> Language Class Initialized
INFO - 2020-02-02 06:42:48 --> Language Class Initialized
INFO - 2020-02-02 06:42:48 --> Config Class Initialized
INFO - 2020-02-02 06:42:48 --> Loader Class Initialized
INFO - 2020-02-02 06:42:48 --> Helper loaded: url_helper
INFO - 2020-02-02 06:42:48 --> Helper loaded: file_helper
INFO - 2020-02-02 06:42:48 --> Helper loaded: form_helper
INFO - 2020-02-02 06:42:48 --> Helper loaded: my_helper
INFO - 2020-02-02 06:42:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:42:48 --> Controller Class Initialized
DEBUG - 2020-02-02 06:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:42:48 --> Final output sent to browser
DEBUG - 2020-02-02 06:42:48 --> Total execution time: 0.3657
INFO - 2020-02-02 06:43:25 --> Config Class Initialized
INFO - 2020-02-02 06:43:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:43:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:43:25 --> Utf8 Class Initialized
INFO - 2020-02-02 06:43:25 --> URI Class Initialized
INFO - 2020-02-02 06:43:25 --> Router Class Initialized
INFO - 2020-02-02 06:43:25 --> Output Class Initialized
INFO - 2020-02-02 06:43:25 --> Security Class Initialized
DEBUG - 2020-02-02 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:43:25 --> Input Class Initialized
INFO - 2020-02-02 06:43:25 --> Language Class Initialized
INFO - 2020-02-02 06:43:25 --> Language Class Initialized
INFO - 2020-02-02 06:43:25 --> Config Class Initialized
INFO - 2020-02-02 06:43:25 --> Loader Class Initialized
INFO - 2020-02-02 06:43:25 --> Helper loaded: url_helper
INFO - 2020-02-02 06:43:25 --> Helper loaded: file_helper
INFO - 2020-02-02 06:43:25 --> Helper loaded: form_helper
INFO - 2020-02-02 06:43:25 --> Helper loaded: my_helper
INFO - 2020-02-02 06:43:25 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:43:25 --> Controller Class Initialized
DEBUG - 2020-02-02 06:43:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:43:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:43:25 --> Final output sent to browser
DEBUG - 2020-02-02 06:43:25 --> Total execution time: 0.3588
INFO - 2020-02-02 06:44:48 --> Config Class Initialized
INFO - 2020-02-02 06:44:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:44:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:44:48 --> Utf8 Class Initialized
INFO - 2020-02-02 06:44:48 --> URI Class Initialized
INFO - 2020-02-02 06:44:49 --> Router Class Initialized
INFO - 2020-02-02 06:44:49 --> Output Class Initialized
INFO - 2020-02-02 06:44:49 --> Security Class Initialized
DEBUG - 2020-02-02 06:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:44:49 --> Input Class Initialized
INFO - 2020-02-02 06:44:49 --> Language Class Initialized
INFO - 2020-02-02 06:44:49 --> Language Class Initialized
INFO - 2020-02-02 06:44:49 --> Config Class Initialized
INFO - 2020-02-02 06:44:49 --> Loader Class Initialized
INFO - 2020-02-02 06:44:49 --> Helper loaded: url_helper
INFO - 2020-02-02 06:44:49 --> Helper loaded: file_helper
INFO - 2020-02-02 06:44:49 --> Helper loaded: form_helper
INFO - 2020-02-02 06:44:49 --> Helper loaded: my_helper
INFO - 2020-02-02 06:44:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:44:49 --> Controller Class Initialized
DEBUG - 2020-02-02 06:44:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:44:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:44:49 --> Final output sent to browser
DEBUG - 2020-02-02 06:44:49 --> Total execution time: 0.4042
INFO - 2020-02-02 06:44:51 --> Config Class Initialized
INFO - 2020-02-02 06:44:51 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:44:51 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:44:51 --> Utf8 Class Initialized
INFO - 2020-02-02 06:44:51 --> URI Class Initialized
INFO - 2020-02-02 06:44:51 --> Router Class Initialized
INFO - 2020-02-02 06:44:51 --> Output Class Initialized
INFO - 2020-02-02 06:44:51 --> Security Class Initialized
DEBUG - 2020-02-02 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:44:51 --> Input Class Initialized
INFO - 2020-02-02 06:44:51 --> Language Class Initialized
INFO - 2020-02-02 06:44:51 --> Language Class Initialized
INFO - 2020-02-02 06:44:51 --> Config Class Initialized
INFO - 2020-02-02 06:44:51 --> Loader Class Initialized
INFO - 2020-02-02 06:44:51 --> Helper loaded: url_helper
INFO - 2020-02-02 06:44:51 --> Helper loaded: file_helper
INFO - 2020-02-02 06:44:51 --> Helper loaded: form_helper
INFO - 2020-02-02 06:44:51 --> Helper loaded: my_helper
INFO - 2020-02-02 06:44:51 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:44:51 --> Controller Class Initialized
DEBUG - 2020-02-02 06:44:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:44:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:44:51 --> Final output sent to browser
DEBUG - 2020-02-02 06:44:51 --> Total execution time: 0.3834
INFO - 2020-02-02 06:44:53 --> Config Class Initialized
INFO - 2020-02-02 06:44:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:44:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:44:53 --> Utf8 Class Initialized
INFO - 2020-02-02 06:44:53 --> URI Class Initialized
INFO - 2020-02-02 06:44:53 --> Router Class Initialized
INFO - 2020-02-02 06:44:53 --> Output Class Initialized
INFO - 2020-02-02 06:44:53 --> Security Class Initialized
DEBUG - 2020-02-02 06:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:44:53 --> Input Class Initialized
INFO - 2020-02-02 06:44:53 --> Language Class Initialized
INFO - 2020-02-02 06:44:53 --> Language Class Initialized
INFO - 2020-02-02 06:44:53 --> Config Class Initialized
INFO - 2020-02-02 06:44:53 --> Loader Class Initialized
INFO - 2020-02-02 06:44:53 --> Helper loaded: url_helper
INFO - 2020-02-02 06:44:53 --> Helper loaded: file_helper
INFO - 2020-02-02 06:44:53 --> Helper loaded: form_helper
INFO - 2020-02-02 06:44:53 --> Helper loaded: my_helper
INFO - 2020-02-02 06:44:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:44:53 --> Controller Class Initialized
DEBUG - 2020-02-02 06:44:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:44:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:44:53 --> Final output sent to browser
DEBUG - 2020-02-02 06:44:53 --> Total execution time: 0.3854
INFO - 2020-02-02 06:44:55 --> Config Class Initialized
INFO - 2020-02-02 06:44:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:44:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:44:55 --> Utf8 Class Initialized
INFO - 2020-02-02 06:44:55 --> URI Class Initialized
INFO - 2020-02-02 06:44:55 --> Router Class Initialized
INFO - 2020-02-02 06:44:55 --> Output Class Initialized
INFO - 2020-02-02 06:44:55 --> Security Class Initialized
DEBUG - 2020-02-02 06:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:44:55 --> Input Class Initialized
INFO - 2020-02-02 06:44:55 --> Language Class Initialized
INFO - 2020-02-02 06:44:55 --> Language Class Initialized
INFO - 2020-02-02 06:44:55 --> Config Class Initialized
INFO - 2020-02-02 06:44:55 --> Loader Class Initialized
INFO - 2020-02-02 06:44:55 --> Helper loaded: url_helper
INFO - 2020-02-02 06:44:55 --> Helper loaded: file_helper
INFO - 2020-02-02 06:44:55 --> Helper loaded: form_helper
INFO - 2020-02-02 06:44:55 --> Helper loaded: my_helper
INFO - 2020-02-02 06:44:55 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:44:56 --> Controller Class Initialized
DEBUG - 2020-02-02 06:44:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:44:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:44:56 --> Final output sent to browser
DEBUG - 2020-02-02 06:44:56 --> Total execution time: 0.4712
INFO - 2020-02-02 06:45:07 --> Config Class Initialized
INFO - 2020-02-02 06:45:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:45:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:45:07 --> Utf8 Class Initialized
INFO - 2020-02-02 06:45:07 --> URI Class Initialized
INFO - 2020-02-02 06:45:07 --> Router Class Initialized
INFO - 2020-02-02 06:45:07 --> Output Class Initialized
INFO - 2020-02-02 06:45:08 --> Security Class Initialized
DEBUG - 2020-02-02 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:45:08 --> Input Class Initialized
INFO - 2020-02-02 06:45:08 --> Language Class Initialized
INFO - 2020-02-02 06:45:08 --> Language Class Initialized
INFO - 2020-02-02 06:45:08 --> Config Class Initialized
INFO - 2020-02-02 06:45:08 --> Loader Class Initialized
INFO - 2020-02-02 06:45:08 --> Helper loaded: url_helper
INFO - 2020-02-02 06:45:08 --> Helper loaded: file_helper
INFO - 2020-02-02 06:45:08 --> Helper loaded: form_helper
INFO - 2020-02-02 06:45:08 --> Helper loaded: my_helper
INFO - 2020-02-02 06:45:08 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:45:08 --> Controller Class Initialized
DEBUG - 2020-02-02 06:45:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:45:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:45:08 --> Final output sent to browser
DEBUG - 2020-02-02 06:45:08 --> Total execution time: 0.3556
INFO - 2020-02-02 06:45:10 --> Config Class Initialized
INFO - 2020-02-02 06:45:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:45:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:45:10 --> Utf8 Class Initialized
INFO - 2020-02-02 06:45:10 --> URI Class Initialized
INFO - 2020-02-02 06:45:10 --> Router Class Initialized
INFO - 2020-02-02 06:45:10 --> Output Class Initialized
INFO - 2020-02-02 06:45:10 --> Security Class Initialized
DEBUG - 2020-02-02 06:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:45:10 --> Input Class Initialized
INFO - 2020-02-02 06:45:10 --> Language Class Initialized
INFO - 2020-02-02 06:45:10 --> Language Class Initialized
INFO - 2020-02-02 06:45:10 --> Config Class Initialized
INFO - 2020-02-02 06:45:10 --> Loader Class Initialized
INFO - 2020-02-02 06:45:10 --> Helper loaded: url_helper
INFO - 2020-02-02 06:45:10 --> Helper loaded: file_helper
INFO - 2020-02-02 06:45:10 --> Helper loaded: form_helper
INFO - 2020-02-02 06:45:10 --> Helper loaded: my_helper
INFO - 2020-02-02 06:45:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:45:10 --> Controller Class Initialized
DEBUG - 2020-02-02 06:45:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:45:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:45:10 --> Final output sent to browser
DEBUG - 2020-02-02 06:45:10 --> Total execution time: 0.3712
INFO - 2020-02-02 06:45:12 --> Config Class Initialized
INFO - 2020-02-02 06:45:12 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:45:12 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:45:12 --> Utf8 Class Initialized
INFO - 2020-02-02 06:45:12 --> URI Class Initialized
INFO - 2020-02-02 06:45:12 --> Router Class Initialized
INFO - 2020-02-02 06:45:12 --> Output Class Initialized
INFO - 2020-02-02 06:45:12 --> Security Class Initialized
DEBUG - 2020-02-02 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:45:12 --> Input Class Initialized
INFO - 2020-02-02 06:45:12 --> Language Class Initialized
INFO - 2020-02-02 06:45:12 --> Language Class Initialized
INFO - 2020-02-02 06:45:12 --> Config Class Initialized
INFO - 2020-02-02 06:45:12 --> Loader Class Initialized
INFO - 2020-02-02 06:45:12 --> Helper loaded: url_helper
INFO - 2020-02-02 06:45:12 --> Helper loaded: file_helper
INFO - 2020-02-02 06:45:12 --> Helper loaded: form_helper
INFO - 2020-02-02 06:45:12 --> Helper loaded: my_helper
INFO - 2020-02-02 06:45:12 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:45:12 --> Controller Class Initialized
DEBUG - 2020-02-02 06:45:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:45:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:45:12 --> Final output sent to browser
DEBUG - 2020-02-02 06:45:12 --> Total execution time: 0.3907
INFO - 2020-02-02 06:45:15 --> Config Class Initialized
INFO - 2020-02-02 06:45:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:45:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:45:15 --> Utf8 Class Initialized
INFO - 2020-02-02 06:45:15 --> URI Class Initialized
INFO - 2020-02-02 06:45:15 --> Router Class Initialized
INFO - 2020-02-02 06:45:15 --> Output Class Initialized
INFO - 2020-02-02 06:45:15 --> Security Class Initialized
DEBUG - 2020-02-02 06:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:45:15 --> Input Class Initialized
INFO - 2020-02-02 06:45:15 --> Language Class Initialized
INFO - 2020-02-02 06:45:15 --> Language Class Initialized
INFO - 2020-02-02 06:45:15 --> Config Class Initialized
INFO - 2020-02-02 06:45:15 --> Loader Class Initialized
INFO - 2020-02-02 06:45:15 --> Helper loaded: url_helper
INFO - 2020-02-02 06:45:15 --> Helper loaded: file_helper
INFO - 2020-02-02 06:45:15 --> Helper loaded: form_helper
INFO - 2020-02-02 06:45:15 --> Helper loaded: my_helper
INFO - 2020-02-02 06:45:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:45:15 --> Controller Class Initialized
DEBUG - 2020-02-02 06:45:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:45:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:45:15 --> Final output sent to browser
DEBUG - 2020-02-02 06:45:15 --> Total execution time: 0.4781
INFO - 2020-02-02 06:48:35 --> Config Class Initialized
INFO - 2020-02-02 06:48:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:48:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:48:35 --> Utf8 Class Initialized
INFO - 2020-02-02 06:48:35 --> URI Class Initialized
INFO - 2020-02-02 06:48:35 --> Router Class Initialized
INFO - 2020-02-02 06:48:35 --> Output Class Initialized
INFO - 2020-02-02 06:48:35 --> Security Class Initialized
DEBUG - 2020-02-02 06:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:48:35 --> Input Class Initialized
INFO - 2020-02-02 06:48:35 --> Language Class Initialized
INFO - 2020-02-02 06:48:35 --> Language Class Initialized
INFO - 2020-02-02 06:48:35 --> Config Class Initialized
INFO - 2020-02-02 06:48:35 --> Loader Class Initialized
INFO - 2020-02-02 06:48:35 --> Helper loaded: url_helper
INFO - 2020-02-02 06:48:35 --> Helper loaded: file_helper
INFO - 2020-02-02 06:48:35 --> Helper loaded: form_helper
INFO - 2020-02-02 06:48:35 --> Helper loaded: my_helper
INFO - 2020-02-02 06:48:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:48:35 --> Controller Class Initialized
DEBUG - 2020-02-02 06:48:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:48:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:48:35 --> Final output sent to browser
DEBUG - 2020-02-02 06:48:35 --> Total execution time: 0.3880
INFO - 2020-02-02 06:48:37 --> Config Class Initialized
INFO - 2020-02-02 06:48:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:48:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:48:37 --> Utf8 Class Initialized
INFO - 2020-02-02 06:48:38 --> URI Class Initialized
INFO - 2020-02-02 06:48:38 --> Router Class Initialized
INFO - 2020-02-02 06:48:38 --> Output Class Initialized
INFO - 2020-02-02 06:48:38 --> Security Class Initialized
DEBUG - 2020-02-02 06:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:48:38 --> Input Class Initialized
INFO - 2020-02-02 06:48:38 --> Language Class Initialized
INFO - 2020-02-02 06:48:38 --> Language Class Initialized
INFO - 2020-02-02 06:48:38 --> Config Class Initialized
INFO - 2020-02-02 06:48:38 --> Loader Class Initialized
INFO - 2020-02-02 06:48:38 --> Helper loaded: url_helper
INFO - 2020-02-02 06:48:38 --> Helper loaded: file_helper
INFO - 2020-02-02 06:48:38 --> Helper loaded: form_helper
INFO - 2020-02-02 06:48:38 --> Helper loaded: my_helper
INFO - 2020-02-02 06:48:38 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:48:38 --> Controller Class Initialized
DEBUG - 2020-02-02 06:48:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:48:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:48:38 --> Final output sent to browser
DEBUG - 2020-02-02 06:48:38 --> Total execution time: 0.4183
INFO - 2020-02-02 06:53:11 --> Config Class Initialized
INFO - 2020-02-02 06:53:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:53:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:53:11 --> Utf8 Class Initialized
INFO - 2020-02-02 06:53:11 --> URI Class Initialized
INFO - 2020-02-02 06:53:11 --> Router Class Initialized
INFO - 2020-02-02 06:53:11 --> Output Class Initialized
INFO - 2020-02-02 06:53:11 --> Security Class Initialized
DEBUG - 2020-02-02 06:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:53:11 --> Input Class Initialized
INFO - 2020-02-02 06:53:11 --> Language Class Initialized
INFO - 2020-02-02 06:53:11 --> Language Class Initialized
INFO - 2020-02-02 06:53:11 --> Config Class Initialized
INFO - 2020-02-02 06:53:11 --> Loader Class Initialized
INFO - 2020-02-02 06:53:11 --> Helper loaded: url_helper
INFO - 2020-02-02 06:53:11 --> Helper loaded: file_helper
INFO - 2020-02-02 06:53:11 --> Helper loaded: form_helper
INFO - 2020-02-02 06:53:11 --> Helper loaded: my_helper
INFO - 2020-02-02 06:53:11 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:53:11 --> Controller Class Initialized
DEBUG - 2020-02-02 06:53:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:53:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:53:11 --> Final output sent to browser
DEBUG - 2020-02-02 06:53:11 --> Total execution time: 0.3657
INFO - 2020-02-02 06:53:23 --> Config Class Initialized
INFO - 2020-02-02 06:53:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:53:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:53:23 --> Utf8 Class Initialized
INFO - 2020-02-02 06:53:23 --> URI Class Initialized
INFO - 2020-02-02 06:53:23 --> Router Class Initialized
INFO - 2020-02-02 06:53:23 --> Output Class Initialized
INFO - 2020-02-02 06:53:23 --> Security Class Initialized
DEBUG - 2020-02-02 06:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:53:23 --> Input Class Initialized
INFO - 2020-02-02 06:53:23 --> Language Class Initialized
INFO - 2020-02-02 06:53:23 --> Language Class Initialized
INFO - 2020-02-02 06:53:23 --> Config Class Initialized
INFO - 2020-02-02 06:53:23 --> Loader Class Initialized
INFO - 2020-02-02 06:53:23 --> Helper loaded: url_helper
INFO - 2020-02-02 06:53:23 --> Helper loaded: file_helper
INFO - 2020-02-02 06:53:23 --> Helper loaded: form_helper
INFO - 2020-02-02 06:53:23 --> Helper loaded: my_helper
INFO - 2020-02-02 06:53:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:53:23 --> Controller Class Initialized
DEBUG - 2020-02-02 06:53:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:53:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:53:24 --> Final output sent to browser
DEBUG - 2020-02-02 06:53:24 --> Total execution time: 0.3875
INFO - 2020-02-02 06:53:45 --> Config Class Initialized
INFO - 2020-02-02 06:53:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:53:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:53:45 --> Utf8 Class Initialized
INFO - 2020-02-02 06:53:45 --> URI Class Initialized
INFO - 2020-02-02 06:53:45 --> Router Class Initialized
INFO - 2020-02-02 06:53:45 --> Output Class Initialized
INFO - 2020-02-02 06:53:45 --> Security Class Initialized
DEBUG - 2020-02-02 06:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:53:45 --> Input Class Initialized
INFO - 2020-02-02 06:53:45 --> Language Class Initialized
INFO - 2020-02-02 06:53:45 --> Language Class Initialized
INFO - 2020-02-02 06:53:45 --> Config Class Initialized
INFO - 2020-02-02 06:53:45 --> Loader Class Initialized
INFO - 2020-02-02 06:53:45 --> Helper loaded: url_helper
INFO - 2020-02-02 06:53:45 --> Helper loaded: file_helper
INFO - 2020-02-02 06:53:45 --> Helper loaded: form_helper
INFO - 2020-02-02 06:53:45 --> Helper loaded: my_helper
INFO - 2020-02-02 06:53:45 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:53:45 --> Controller Class Initialized
DEBUG - 2020-02-02 06:53:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:53:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:53:45 --> Final output sent to browser
DEBUG - 2020-02-02 06:53:45 --> Total execution time: 0.3839
INFO - 2020-02-02 06:53:58 --> Config Class Initialized
INFO - 2020-02-02 06:53:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:53:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:53:58 --> Utf8 Class Initialized
INFO - 2020-02-02 06:53:58 --> URI Class Initialized
INFO - 2020-02-02 06:53:58 --> Router Class Initialized
INFO - 2020-02-02 06:53:58 --> Output Class Initialized
INFO - 2020-02-02 06:53:58 --> Security Class Initialized
DEBUG - 2020-02-02 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:53:58 --> Input Class Initialized
INFO - 2020-02-02 06:53:59 --> Language Class Initialized
INFO - 2020-02-02 06:53:59 --> Language Class Initialized
INFO - 2020-02-02 06:53:59 --> Config Class Initialized
INFO - 2020-02-02 06:53:59 --> Loader Class Initialized
INFO - 2020-02-02 06:53:59 --> Helper loaded: url_helper
INFO - 2020-02-02 06:53:59 --> Helper loaded: file_helper
INFO - 2020-02-02 06:53:59 --> Helper loaded: form_helper
INFO - 2020-02-02 06:53:59 --> Helper loaded: my_helper
INFO - 2020-02-02 06:53:59 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:53:59 --> Controller Class Initialized
DEBUG - 2020-02-02 06:53:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:53:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:53:59 --> Final output sent to browser
DEBUG - 2020-02-02 06:53:59 --> Total execution time: 0.3755
INFO - 2020-02-02 06:54:15 --> Config Class Initialized
INFO - 2020-02-02 06:54:16 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:54:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:54:16 --> Utf8 Class Initialized
INFO - 2020-02-02 06:54:16 --> URI Class Initialized
INFO - 2020-02-02 06:54:16 --> Router Class Initialized
INFO - 2020-02-02 06:54:16 --> Output Class Initialized
INFO - 2020-02-02 06:54:16 --> Security Class Initialized
DEBUG - 2020-02-02 06:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:54:16 --> Input Class Initialized
INFO - 2020-02-02 06:54:16 --> Language Class Initialized
INFO - 2020-02-02 06:54:16 --> Language Class Initialized
INFO - 2020-02-02 06:54:16 --> Config Class Initialized
INFO - 2020-02-02 06:54:16 --> Loader Class Initialized
INFO - 2020-02-02 06:54:16 --> Helper loaded: url_helper
INFO - 2020-02-02 06:54:16 --> Helper loaded: file_helper
INFO - 2020-02-02 06:54:16 --> Helper loaded: form_helper
INFO - 2020-02-02 06:54:16 --> Helper loaded: my_helper
INFO - 2020-02-02 06:54:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:54:16 --> Controller Class Initialized
DEBUG - 2020-02-02 06:54:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:54:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:54:16 --> Final output sent to browser
DEBUG - 2020-02-02 06:54:16 --> Total execution time: 0.3835
INFO - 2020-02-02 06:55:24 --> Config Class Initialized
INFO - 2020-02-02 06:55:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:55:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:55:24 --> Utf8 Class Initialized
INFO - 2020-02-02 06:55:24 --> URI Class Initialized
INFO - 2020-02-02 06:55:24 --> Router Class Initialized
INFO - 2020-02-02 06:55:24 --> Output Class Initialized
INFO - 2020-02-02 06:55:24 --> Security Class Initialized
DEBUG - 2020-02-02 06:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:55:24 --> Input Class Initialized
INFO - 2020-02-02 06:55:24 --> Language Class Initialized
INFO - 2020-02-02 06:55:24 --> Language Class Initialized
INFO - 2020-02-02 06:55:24 --> Config Class Initialized
INFO - 2020-02-02 06:55:24 --> Loader Class Initialized
INFO - 2020-02-02 06:55:24 --> Helper loaded: url_helper
INFO - 2020-02-02 06:55:24 --> Helper loaded: file_helper
INFO - 2020-02-02 06:55:24 --> Helper loaded: form_helper
INFO - 2020-02-02 06:55:24 --> Helper loaded: my_helper
INFO - 2020-02-02 06:55:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:55:24 --> Controller Class Initialized
DEBUG - 2020-02-02 06:55:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:55:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:55:24 --> Final output sent to browser
DEBUG - 2020-02-02 06:55:24 --> Total execution time: 0.3796
INFO - 2020-02-02 06:55:31 --> Config Class Initialized
INFO - 2020-02-02 06:55:31 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:55:31 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:55:31 --> Utf8 Class Initialized
INFO - 2020-02-02 06:55:31 --> URI Class Initialized
INFO - 2020-02-02 06:55:31 --> Router Class Initialized
INFO - 2020-02-02 06:55:31 --> Output Class Initialized
INFO - 2020-02-02 06:55:31 --> Security Class Initialized
DEBUG - 2020-02-02 06:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:55:31 --> Input Class Initialized
INFO - 2020-02-02 06:55:31 --> Language Class Initialized
INFO - 2020-02-02 06:55:31 --> Language Class Initialized
INFO - 2020-02-02 06:55:31 --> Config Class Initialized
INFO - 2020-02-02 06:55:31 --> Loader Class Initialized
INFO - 2020-02-02 06:55:31 --> Helper loaded: url_helper
INFO - 2020-02-02 06:55:31 --> Helper loaded: file_helper
INFO - 2020-02-02 06:55:31 --> Helper loaded: form_helper
INFO - 2020-02-02 06:55:31 --> Helper loaded: my_helper
INFO - 2020-02-02 06:55:31 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:55:31 --> Controller Class Initialized
DEBUG - 2020-02-02 06:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:55:31 --> Final output sent to browser
DEBUG - 2020-02-02 06:55:31 --> Total execution time: 0.3814
INFO - 2020-02-02 06:55:48 --> Config Class Initialized
INFO - 2020-02-02 06:55:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:55:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:55:48 --> Utf8 Class Initialized
INFO - 2020-02-02 06:55:48 --> URI Class Initialized
INFO - 2020-02-02 06:55:48 --> Router Class Initialized
INFO - 2020-02-02 06:55:48 --> Output Class Initialized
INFO - 2020-02-02 06:55:48 --> Security Class Initialized
DEBUG - 2020-02-02 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:55:48 --> Input Class Initialized
INFO - 2020-02-02 06:55:48 --> Language Class Initialized
INFO - 2020-02-02 06:55:48 --> Language Class Initialized
INFO - 2020-02-02 06:55:48 --> Config Class Initialized
INFO - 2020-02-02 06:55:48 --> Loader Class Initialized
INFO - 2020-02-02 06:55:48 --> Helper loaded: url_helper
INFO - 2020-02-02 06:55:48 --> Helper loaded: file_helper
INFO - 2020-02-02 06:55:48 --> Helper loaded: form_helper
INFO - 2020-02-02 06:55:48 --> Helper loaded: my_helper
INFO - 2020-02-02 06:55:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:55:49 --> Controller Class Initialized
DEBUG - 2020-02-02 06:55:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:55:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:55:49 --> Final output sent to browser
DEBUG - 2020-02-02 06:55:49 --> Total execution time: 0.3940
INFO - 2020-02-02 06:56:05 --> Config Class Initialized
INFO - 2020-02-02 06:56:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:05 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:05 --> URI Class Initialized
INFO - 2020-02-02 06:56:05 --> Router Class Initialized
INFO - 2020-02-02 06:56:05 --> Output Class Initialized
INFO - 2020-02-02 06:56:05 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:05 --> Input Class Initialized
INFO - 2020-02-02 06:56:05 --> Language Class Initialized
INFO - 2020-02-02 06:56:05 --> Language Class Initialized
INFO - 2020-02-02 06:56:05 --> Config Class Initialized
INFO - 2020-02-02 06:56:05 --> Loader Class Initialized
INFO - 2020-02-02 06:56:05 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:05 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:05 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:05 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:05 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:05 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:05 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:05 --> Total execution time: 0.3807
INFO - 2020-02-02 06:56:15 --> Config Class Initialized
INFO - 2020-02-02 06:56:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:15 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:15 --> URI Class Initialized
INFO - 2020-02-02 06:56:15 --> Router Class Initialized
INFO - 2020-02-02 06:56:15 --> Output Class Initialized
INFO - 2020-02-02 06:56:15 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:15 --> Input Class Initialized
INFO - 2020-02-02 06:56:15 --> Language Class Initialized
INFO - 2020-02-02 06:56:15 --> Language Class Initialized
INFO - 2020-02-02 06:56:15 --> Config Class Initialized
INFO - 2020-02-02 06:56:15 --> Loader Class Initialized
INFO - 2020-02-02 06:56:15 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:15 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:15 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:15 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:15 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:15 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:15 --> Total execution time: 0.3870
INFO - 2020-02-02 06:56:22 --> Config Class Initialized
INFO - 2020-02-02 06:56:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:22 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:22 --> URI Class Initialized
INFO - 2020-02-02 06:56:22 --> Router Class Initialized
INFO - 2020-02-02 06:56:22 --> Output Class Initialized
INFO - 2020-02-02 06:56:22 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:22 --> Input Class Initialized
INFO - 2020-02-02 06:56:22 --> Language Class Initialized
INFO - 2020-02-02 06:56:22 --> Language Class Initialized
INFO - 2020-02-02 06:56:22 --> Config Class Initialized
INFO - 2020-02-02 06:56:22 --> Loader Class Initialized
INFO - 2020-02-02 06:56:22 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:22 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:22 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:22 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:22 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:22 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:22 --> Total execution time: 0.3830
INFO - 2020-02-02 06:56:34 --> Config Class Initialized
INFO - 2020-02-02 06:56:34 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:34 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:34 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:34 --> URI Class Initialized
INFO - 2020-02-02 06:56:34 --> Router Class Initialized
INFO - 2020-02-02 06:56:34 --> Output Class Initialized
INFO - 2020-02-02 06:56:34 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:34 --> Input Class Initialized
INFO - 2020-02-02 06:56:34 --> Language Class Initialized
INFO - 2020-02-02 06:56:34 --> Language Class Initialized
INFO - 2020-02-02 06:56:34 --> Config Class Initialized
INFO - 2020-02-02 06:56:34 --> Loader Class Initialized
INFO - 2020-02-02 06:56:34 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:34 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:34 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:34 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:34 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:34 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:34 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:34 --> Total execution time: 0.3706
INFO - 2020-02-02 06:56:39 --> Config Class Initialized
INFO - 2020-02-02 06:56:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:39 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:39 --> URI Class Initialized
INFO - 2020-02-02 06:56:39 --> Router Class Initialized
INFO - 2020-02-02 06:56:39 --> Output Class Initialized
INFO - 2020-02-02 06:56:39 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:39 --> Input Class Initialized
INFO - 2020-02-02 06:56:39 --> Language Class Initialized
INFO - 2020-02-02 06:56:39 --> Language Class Initialized
INFO - 2020-02-02 06:56:39 --> Config Class Initialized
INFO - 2020-02-02 06:56:39 --> Loader Class Initialized
INFO - 2020-02-02 06:56:39 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:40 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:40 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:40 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:40 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:40 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:40 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:40 --> Total execution time: 0.3742
INFO - 2020-02-02 06:56:44 --> Config Class Initialized
INFO - 2020-02-02 06:56:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:44 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:44 --> URI Class Initialized
INFO - 2020-02-02 06:56:44 --> Router Class Initialized
INFO - 2020-02-02 06:56:44 --> Output Class Initialized
INFO - 2020-02-02 06:56:44 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:44 --> Input Class Initialized
INFO - 2020-02-02 06:56:44 --> Language Class Initialized
INFO - 2020-02-02 06:56:44 --> Language Class Initialized
INFO - 2020-02-02 06:56:44 --> Config Class Initialized
INFO - 2020-02-02 06:56:44 --> Loader Class Initialized
INFO - 2020-02-02 06:56:44 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:44 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:44 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:44 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:44 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:44 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:44 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:44 --> Total execution time: 0.3905
INFO - 2020-02-02 06:56:54 --> Config Class Initialized
INFO - 2020-02-02 06:56:54 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:56:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:56:54 --> Utf8 Class Initialized
INFO - 2020-02-02 06:56:54 --> URI Class Initialized
INFO - 2020-02-02 06:56:54 --> Router Class Initialized
INFO - 2020-02-02 06:56:54 --> Output Class Initialized
INFO - 2020-02-02 06:56:54 --> Security Class Initialized
DEBUG - 2020-02-02 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:56:54 --> Input Class Initialized
INFO - 2020-02-02 06:56:54 --> Language Class Initialized
INFO - 2020-02-02 06:56:54 --> Language Class Initialized
INFO - 2020-02-02 06:56:54 --> Config Class Initialized
INFO - 2020-02-02 06:56:54 --> Loader Class Initialized
INFO - 2020-02-02 06:56:54 --> Helper loaded: url_helper
INFO - 2020-02-02 06:56:54 --> Helper loaded: file_helper
INFO - 2020-02-02 06:56:54 --> Helper loaded: form_helper
INFO - 2020-02-02 06:56:54 --> Helper loaded: my_helper
INFO - 2020-02-02 06:56:54 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:56:54 --> Controller Class Initialized
DEBUG - 2020-02-02 06:56:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:56:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:56:54 --> Final output sent to browser
DEBUG - 2020-02-02 06:56:54 --> Total execution time: 0.3889
INFO - 2020-02-02 06:57:08 --> Config Class Initialized
INFO - 2020-02-02 06:57:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:57:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:57:08 --> Utf8 Class Initialized
INFO - 2020-02-02 06:57:08 --> URI Class Initialized
INFO - 2020-02-02 06:57:08 --> Router Class Initialized
INFO - 2020-02-02 06:57:08 --> Output Class Initialized
INFO - 2020-02-02 06:57:08 --> Security Class Initialized
DEBUG - 2020-02-02 06:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:57:08 --> Input Class Initialized
INFO - 2020-02-02 06:57:08 --> Language Class Initialized
INFO - 2020-02-02 06:57:08 --> Language Class Initialized
INFO - 2020-02-02 06:57:08 --> Config Class Initialized
INFO - 2020-02-02 06:57:08 --> Loader Class Initialized
INFO - 2020-02-02 06:57:08 --> Helper loaded: url_helper
INFO - 2020-02-02 06:57:08 --> Helper loaded: file_helper
INFO - 2020-02-02 06:57:08 --> Helper loaded: form_helper
INFO - 2020-02-02 06:57:08 --> Helper loaded: my_helper
INFO - 2020-02-02 06:57:08 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:57:08 --> Controller Class Initialized
DEBUG - 2020-02-02 06:57:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:57:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:57:08 --> Final output sent to browser
DEBUG - 2020-02-02 06:57:08 --> Total execution time: 0.4014
INFO - 2020-02-02 06:58:40 --> Config Class Initialized
INFO - 2020-02-02 06:58:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 06:58:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 06:58:40 --> Utf8 Class Initialized
INFO - 2020-02-02 06:58:40 --> URI Class Initialized
INFO - 2020-02-02 06:58:40 --> Router Class Initialized
INFO - 2020-02-02 06:58:40 --> Output Class Initialized
INFO - 2020-02-02 06:58:40 --> Security Class Initialized
DEBUG - 2020-02-02 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 06:58:40 --> Input Class Initialized
INFO - 2020-02-02 06:58:40 --> Language Class Initialized
INFO - 2020-02-02 06:58:40 --> Language Class Initialized
INFO - 2020-02-02 06:58:40 --> Config Class Initialized
INFO - 2020-02-02 06:58:40 --> Loader Class Initialized
INFO - 2020-02-02 06:58:40 --> Helper loaded: url_helper
INFO - 2020-02-02 06:58:40 --> Helper loaded: file_helper
INFO - 2020-02-02 06:58:40 --> Helper loaded: form_helper
INFO - 2020-02-02 06:58:40 --> Helper loaded: my_helper
INFO - 2020-02-02 06:58:40 --> Database Driver Class Initialized
DEBUG - 2020-02-02 06:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 06:58:40 --> Controller Class Initialized
DEBUG - 2020-02-02 06:58:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 06:58:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 06:58:40 --> Final output sent to browser
DEBUG - 2020-02-02 06:58:40 --> Total execution time: 0.4006
INFO - 2020-02-02 07:00:36 --> Config Class Initialized
INFO - 2020-02-02 07:00:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:00:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:00:36 --> Utf8 Class Initialized
INFO - 2020-02-02 07:00:36 --> URI Class Initialized
INFO - 2020-02-02 07:00:36 --> Router Class Initialized
INFO - 2020-02-02 07:00:36 --> Output Class Initialized
INFO - 2020-02-02 07:00:36 --> Security Class Initialized
DEBUG - 2020-02-02 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:00:36 --> Input Class Initialized
INFO - 2020-02-02 07:00:36 --> Language Class Initialized
INFO - 2020-02-02 07:00:36 --> Language Class Initialized
INFO - 2020-02-02 07:00:36 --> Config Class Initialized
INFO - 2020-02-02 07:00:36 --> Loader Class Initialized
INFO - 2020-02-02 07:00:36 --> Helper loaded: url_helper
INFO - 2020-02-02 07:00:36 --> Helper loaded: file_helper
INFO - 2020-02-02 07:00:36 --> Helper loaded: form_helper
INFO - 2020-02-02 07:00:36 --> Helper loaded: my_helper
INFO - 2020-02-02 07:00:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:00:36 --> Controller Class Initialized
DEBUG - 2020-02-02 07:00:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:00:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:00:36 --> Final output sent to browser
DEBUG - 2020-02-02 07:00:36 --> Total execution time: 0.4035
INFO - 2020-02-02 07:00:46 --> Config Class Initialized
INFO - 2020-02-02 07:00:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:00:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:00:46 --> Utf8 Class Initialized
INFO - 2020-02-02 07:00:46 --> URI Class Initialized
INFO - 2020-02-02 07:00:46 --> Router Class Initialized
INFO - 2020-02-02 07:00:46 --> Output Class Initialized
INFO - 2020-02-02 07:00:47 --> Security Class Initialized
DEBUG - 2020-02-02 07:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:00:47 --> Input Class Initialized
INFO - 2020-02-02 07:00:47 --> Language Class Initialized
INFO - 2020-02-02 07:00:47 --> Language Class Initialized
INFO - 2020-02-02 07:00:47 --> Config Class Initialized
INFO - 2020-02-02 07:00:47 --> Loader Class Initialized
INFO - 2020-02-02 07:00:47 --> Helper loaded: url_helper
INFO - 2020-02-02 07:00:47 --> Helper loaded: file_helper
INFO - 2020-02-02 07:00:47 --> Helper loaded: form_helper
INFO - 2020-02-02 07:00:47 --> Helper loaded: my_helper
INFO - 2020-02-02 07:00:47 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:00:47 --> Controller Class Initialized
DEBUG - 2020-02-02 07:00:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:00:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:00:47 --> Final output sent to browser
DEBUG - 2020-02-02 07:00:47 --> Total execution time: 0.3839
INFO - 2020-02-02 07:01:31 --> Config Class Initialized
INFO - 2020-02-02 07:01:31 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:01:31 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:01:31 --> Utf8 Class Initialized
INFO - 2020-02-02 07:01:31 --> URI Class Initialized
INFO - 2020-02-02 07:01:31 --> Router Class Initialized
INFO - 2020-02-02 07:01:31 --> Output Class Initialized
INFO - 2020-02-02 07:01:31 --> Security Class Initialized
DEBUG - 2020-02-02 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:01:31 --> Input Class Initialized
INFO - 2020-02-02 07:01:31 --> Language Class Initialized
INFO - 2020-02-02 07:01:31 --> Language Class Initialized
INFO - 2020-02-02 07:01:31 --> Config Class Initialized
INFO - 2020-02-02 07:01:31 --> Loader Class Initialized
INFO - 2020-02-02 07:01:31 --> Helper loaded: url_helper
INFO - 2020-02-02 07:01:31 --> Helper loaded: file_helper
INFO - 2020-02-02 07:01:31 --> Helper loaded: form_helper
INFO - 2020-02-02 07:01:31 --> Helper loaded: my_helper
INFO - 2020-02-02 07:01:32 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:01:32 --> Controller Class Initialized
DEBUG - 2020-02-02 07:01:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:01:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:01:32 --> Final output sent to browser
DEBUG - 2020-02-02 07:01:32 --> Total execution time: 0.4043
INFO - 2020-02-02 07:04:10 --> Config Class Initialized
INFO - 2020-02-02 07:04:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:10 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:10 --> URI Class Initialized
INFO - 2020-02-02 07:04:10 --> Router Class Initialized
INFO - 2020-02-02 07:04:10 --> Output Class Initialized
INFO - 2020-02-02 07:04:10 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:10 --> Input Class Initialized
INFO - 2020-02-02 07:04:10 --> Language Class Initialized
INFO - 2020-02-02 07:04:10 --> Language Class Initialized
INFO - 2020-02-02 07:04:10 --> Config Class Initialized
INFO - 2020-02-02 07:04:10 --> Loader Class Initialized
INFO - 2020-02-02 07:04:10 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:10 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:10 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:10 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:10 --> Controller Class Initialized
DEBUG - 2020-02-02 07:04:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:04:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:04:10 --> Final output sent to browser
DEBUG - 2020-02-02 07:04:10 --> Total execution time: 0.3842
INFO - 2020-02-02 07:04:30 --> Config Class Initialized
INFO - 2020-02-02 07:04:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:30 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:30 --> URI Class Initialized
INFO - 2020-02-02 07:04:30 --> Router Class Initialized
INFO - 2020-02-02 07:04:30 --> Output Class Initialized
INFO - 2020-02-02 07:04:30 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:30 --> Input Class Initialized
INFO - 2020-02-02 07:04:30 --> Language Class Initialized
INFO - 2020-02-02 07:04:30 --> Language Class Initialized
INFO - 2020-02-02 07:04:30 --> Config Class Initialized
INFO - 2020-02-02 07:04:30 --> Loader Class Initialized
INFO - 2020-02-02 07:04:30 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:30 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:31 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:31 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:31 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:31 --> Controller Class Initialized
DEBUG - 2020-02-02 07:04:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:04:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:04:31 --> Final output sent to browser
DEBUG - 2020-02-02 07:04:31 --> Total execution time: 0.3989
INFO - 2020-02-02 07:04:41 --> Config Class Initialized
INFO - 2020-02-02 07:04:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:41 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:41 --> URI Class Initialized
INFO - 2020-02-02 07:04:41 --> Router Class Initialized
INFO - 2020-02-02 07:04:41 --> Output Class Initialized
INFO - 2020-02-02 07:04:41 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:41 --> Input Class Initialized
INFO - 2020-02-02 07:04:41 --> Language Class Initialized
INFO - 2020-02-02 07:04:41 --> Language Class Initialized
INFO - 2020-02-02 07:04:41 --> Config Class Initialized
INFO - 2020-02-02 07:04:41 --> Loader Class Initialized
INFO - 2020-02-02 07:04:41 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:41 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:41 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:41 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:41 --> Controller Class Initialized
DEBUG - 2020-02-02 07:04:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:04:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:04:41 --> Final output sent to browser
DEBUG - 2020-02-02 07:04:41 --> Total execution time: 0.4065
INFO - 2020-02-02 07:04:46 --> Config Class Initialized
INFO - 2020-02-02 07:04:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:46 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:46 --> URI Class Initialized
INFO - 2020-02-02 07:04:46 --> Router Class Initialized
INFO - 2020-02-02 07:04:46 --> Output Class Initialized
INFO - 2020-02-02 07:04:46 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:46 --> Input Class Initialized
INFO - 2020-02-02 07:04:46 --> Language Class Initialized
INFO - 2020-02-02 07:04:46 --> Language Class Initialized
INFO - 2020-02-02 07:04:46 --> Config Class Initialized
INFO - 2020-02-02 07:04:46 --> Loader Class Initialized
INFO - 2020-02-02 07:04:46 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:46 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:46 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:46 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:46 --> Controller Class Initialized
DEBUG - 2020-02-02 07:04:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:04:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:04:46 --> Final output sent to browser
DEBUG - 2020-02-02 07:04:46 --> Total execution time: 0.3876
INFO - 2020-02-02 07:04:53 --> Config Class Initialized
INFO - 2020-02-02 07:04:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:53 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:53 --> URI Class Initialized
INFO - 2020-02-02 07:04:53 --> Router Class Initialized
INFO - 2020-02-02 07:04:53 --> Output Class Initialized
INFO - 2020-02-02 07:04:53 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:53 --> Input Class Initialized
INFO - 2020-02-02 07:04:53 --> Language Class Initialized
INFO - 2020-02-02 07:04:53 --> Language Class Initialized
INFO - 2020-02-02 07:04:53 --> Config Class Initialized
INFO - 2020-02-02 07:04:53 --> Loader Class Initialized
INFO - 2020-02-02 07:04:53 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:53 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:53 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:53 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:54 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:54 --> Controller Class Initialized
INFO - 2020-02-02 07:04:54 --> Helper loaded: cookie_helper
INFO - 2020-02-02 07:04:54 --> Config Class Initialized
INFO - 2020-02-02 07:04:54 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:54 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:54 --> URI Class Initialized
INFO - 2020-02-02 07:04:54 --> Router Class Initialized
INFO - 2020-02-02 07:04:54 --> Output Class Initialized
INFO - 2020-02-02 07:04:54 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:54 --> Input Class Initialized
INFO - 2020-02-02 07:04:54 --> Language Class Initialized
INFO - 2020-02-02 07:04:54 --> Language Class Initialized
INFO - 2020-02-02 07:04:54 --> Config Class Initialized
INFO - 2020-02-02 07:04:54 --> Loader Class Initialized
INFO - 2020-02-02 07:04:54 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:54 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:54 --> Controller Class Initialized
INFO - 2020-02-02 07:04:54 --> Config Class Initialized
INFO - 2020-02-02 07:04:54 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:04:54 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:04:54 --> Utf8 Class Initialized
INFO - 2020-02-02 07:04:54 --> URI Class Initialized
INFO - 2020-02-02 07:04:54 --> Router Class Initialized
INFO - 2020-02-02 07:04:54 --> Output Class Initialized
INFO - 2020-02-02 07:04:54 --> Security Class Initialized
DEBUG - 2020-02-02 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:04:54 --> Input Class Initialized
INFO - 2020-02-02 07:04:54 --> Language Class Initialized
INFO - 2020-02-02 07:04:54 --> Language Class Initialized
INFO - 2020-02-02 07:04:54 --> Config Class Initialized
INFO - 2020-02-02 07:04:54 --> Loader Class Initialized
INFO - 2020-02-02 07:04:54 --> Helper loaded: url_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: file_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: form_helper
INFO - 2020-02-02 07:04:54 --> Helper loaded: my_helper
INFO - 2020-02-02 07:04:54 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:04:54 --> Controller Class Initialized
DEBUG - 2020-02-02 07:04:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-02 07:04:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:04:54 --> Final output sent to browser
DEBUG - 2020-02-02 07:04:54 --> Total execution time: 0.3243
INFO - 2020-02-02 07:05:01 --> Config Class Initialized
INFO - 2020-02-02 07:05:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:05:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:05:01 --> Utf8 Class Initialized
INFO - 2020-02-02 07:05:01 --> URI Class Initialized
INFO - 2020-02-02 07:05:01 --> Router Class Initialized
INFO - 2020-02-02 07:05:01 --> Output Class Initialized
INFO - 2020-02-02 07:05:01 --> Security Class Initialized
DEBUG - 2020-02-02 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:05:01 --> Input Class Initialized
INFO - 2020-02-02 07:05:01 --> Language Class Initialized
INFO - 2020-02-02 07:05:01 --> Language Class Initialized
INFO - 2020-02-02 07:05:01 --> Config Class Initialized
INFO - 2020-02-02 07:05:01 --> Loader Class Initialized
INFO - 2020-02-02 07:05:01 --> Helper loaded: url_helper
INFO - 2020-02-02 07:05:01 --> Helper loaded: file_helper
INFO - 2020-02-02 07:05:01 --> Helper loaded: form_helper
INFO - 2020-02-02 07:05:01 --> Helper loaded: my_helper
INFO - 2020-02-02 07:05:01 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:05:01 --> Controller Class Initialized
INFO - 2020-02-02 07:05:01 --> Helper loaded: cookie_helper
INFO - 2020-02-02 07:05:01 --> Final output sent to browser
DEBUG - 2020-02-02 07:05:01 --> Total execution time: 0.3874
INFO - 2020-02-02 07:05:01 --> Config Class Initialized
INFO - 2020-02-02 07:05:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:05:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:05:01 --> Utf8 Class Initialized
INFO - 2020-02-02 07:05:01 --> URI Class Initialized
INFO - 2020-02-02 07:05:01 --> Router Class Initialized
INFO - 2020-02-02 07:05:01 --> Output Class Initialized
INFO - 2020-02-02 07:05:01 --> Security Class Initialized
DEBUG - 2020-02-02 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:05:02 --> Input Class Initialized
INFO - 2020-02-02 07:05:02 --> Language Class Initialized
INFO - 2020-02-02 07:05:02 --> Language Class Initialized
INFO - 2020-02-02 07:05:02 --> Config Class Initialized
INFO - 2020-02-02 07:05:02 --> Loader Class Initialized
INFO - 2020-02-02 07:05:02 --> Helper loaded: url_helper
INFO - 2020-02-02 07:05:02 --> Helper loaded: file_helper
INFO - 2020-02-02 07:05:02 --> Helper loaded: form_helper
INFO - 2020-02-02 07:05:02 --> Helper loaded: my_helper
INFO - 2020-02-02 07:05:02 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:05:02 --> Controller Class Initialized
DEBUG - 2020-02-02 07:05:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:05:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:05:02 --> Final output sent to browser
DEBUG - 2020-02-02 07:05:02 --> Total execution time: 0.4722
INFO - 2020-02-02 07:05:24 --> Config Class Initialized
INFO - 2020-02-02 07:05:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:05:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:05:24 --> Utf8 Class Initialized
INFO - 2020-02-02 07:05:24 --> URI Class Initialized
INFO - 2020-02-02 07:05:24 --> Router Class Initialized
INFO - 2020-02-02 07:05:24 --> Output Class Initialized
INFO - 2020-02-02 07:05:24 --> Security Class Initialized
DEBUG - 2020-02-02 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:05:24 --> Input Class Initialized
INFO - 2020-02-02 07:05:24 --> Language Class Initialized
INFO - 2020-02-02 07:05:24 --> Language Class Initialized
INFO - 2020-02-02 07:05:24 --> Config Class Initialized
INFO - 2020-02-02 07:05:24 --> Loader Class Initialized
INFO - 2020-02-02 07:05:24 --> Helper loaded: url_helper
INFO - 2020-02-02 07:05:24 --> Helper loaded: file_helper
INFO - 2020-02-02 07:05:24 --> Helper loaded: form_helper
INFO - 2020-02-02 07:05:24 --> Helper loaded: my_helper
INFO - 2020-02-02 07:05:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:05:24 --> Controller Class Initialized
DEBUG - 2020-02-02 07:05:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:05:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:05:24 --> Final output sent to browser
DEBUG - 2020-02-02 07:05:24 --> Total execution time: 0.3960
INFO - 2020-02-02 07:05:47 --> Config Class Initialized
INFO - 2020-02-02 07:05:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:05:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:05:47 --> Utf8 Class Initialized
INFO - 2020-02-02 07:05:47 --> URI Class Initialized
INFO - 2020-02-02 07:05:47 --> Router Class Initialized
INFO - 2020-02-02 07:05:47 --> Output Class Initialized
INFO - 2020-02-02 07:05:47 --> Security Class Initialized
DEBUG - 2020-02-02 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:05:47 --> Input Class Initialized
INFO - 2020-02-02 07:05:47 --> Language Class Initialized
INFO - 2020-02-02 07:05:47 --> Language Class Initialized
INFO - 2020-02-02 07:05:47 --> Config Class Initialized
INFO - 2020-02-02 07:05:47 --> Loader Class Initialized
INFO - 2020-02-02 07:05:48 --> Helper loaded: url_helper
INFO - 2020-02-02 07:05:48 --> Helper loaded: file_helper
INFO - 2020-02-02 07:05:48 --> Helper loaded: form_helper
INFO - 2020-02-02 07:05:48 --> Helper loaded: my_helper
INFO - 2020-02-02 07:05:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:05:48 --> Controller Class Initialized
DEBUG - 2020-02-02 07:05:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:05:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:05:48 --> Final output sent to browser
DEBUG - 2020-02-02 07:05:48 --> Total execution time: 0.4000
INFO - 2020-02-02 07:05:58 --> Config Class Initialized
INFO - 2020-02-02 07:05:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:05:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:05:58 --> Utf8 Class Initialized
INFO - 2020-02-02 07:05:58 --> URI Class Initialized
INFO - 2020-02-02 07:05:58 --> Router Class Initialized
INFO - 2020-02-02 07:05:58 --> Output Class Initialized
INFO - 2020-02-02 07:05:58 --> Security Class Initialized
DEBUG - 2020-02-02 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:05:58 --> Input Class Initialized
INFO - 2020-02-02 07:05:58 --> Language Class Initialized
INFO - 2020-02-02 07:05:58 --> Language Class Initialized
INFO - 2020-02-02 07:05:58 --> Config Class Initialized
INFO - 2020-02-02 07:05:58 --> Loader Class Initialized
INFO - 2020-02-02 07:05:58 --> Helper loaded: url_helper
INFO - 2020-02-02 07:05:58 --> Helper loaded: file_helper
INFO - 2020-02-02 07:05:58 --> Helper loaded: form_helper
INFO - 2020-02-02 07:05:58 --> Helper loaded: my_helper
INFO - 2020-02-02 07:05:58 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:05:58 --> Controller Class Initialized
DEBUG - 2020-02-02 07:05:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:05:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:05:59 --> Final output sent to browser
DEBUG - 2020-02-02 07:05:59 --> Total execution time: 0.4946
INFO - 2020-02-02 07:06:37 --> Config Class Initialized
INFO - 2020-02-02 07:06:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:06:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:06:37 --> Utf8 Class Initialized
INFO - 2020-02-02 07:06:37 --> URI Class Initialized
INFO - 2020-02-02 07:06:37 --> Router Class Initialized
INFO - 2020-02-02 07:06:37 --> Output Class Initialized
INFO - 2020-02-02 07:06:37 --> Security Class Initialized
DEBUG - 2020-02-02 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:06:37 --> Input Class Initialized
INFO - 2020-02-02 07:06:37 --> Language Class Initialized
INFO - 2020-02-02 07:06:37 --> Language Class Initialized
INFO - 2020-02-02 07:06:37 --> Config Class Initialized
INFO - 2020-02-02 07:06:37 --> Loader Class Initialized
INFO - 2020-02-02 07:06:37 --> Helper loaded: url_helper
INFO - 2020-02-02 07:06:37 --> Helper loaded: file_helper
INFO - 2020-02-02 07:06:37 --> Helper loaded: form_helper
INFO - 2020-02-02 07:06:37 --> Helper loaded: my_helper
INFO - 2020-02-02 07:06:37 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:06:37 --> Controller Class Initialized
DEBUG - 2020-02-02 07:06:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:06:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:06:37 --> Final output sent to browser
DEBUG - 2020-02-02 07:06:37 --> Total execution time: 0.4617
INFO - 2020-02-02 07:07:52 --> Config Class Initialized
INFO - 2020-02-02 07:07:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:07:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:07:52 --> Utf8 Class Initialized
INFO - 2020-02-02 07:07:52 --> URI Class Initialized
INFO - 2020-02-02 07:07:52 --> Router Class Initialized
INFO - 2020-02-02 07:07:52 --> Output Class Initialized
INFO - 2020-02-02 07:07:52 --> Security Class Initialized
DEBUG - 2020-02-02 07:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:07:52 --> Input Class Initialized
INFO - 2020-02-02 07:07:52 --> Language Class Initialized
INFO - 2020-02-02 07:07:52 --> Language Class Initialized
INFO - 2020-02-02 07:07:52 --> Config Class Initialized
INFO - 2020-02-02 07:07:52 --> Loader Class Initialized
INFO - 2020-02-02 07:07:52 --> Helper loaded: url_helper
INFO - 2020-02-02 07:07:52 --> Helper loaded: file_helper
INFO - 2020-02-02 07:07:52 --> Helper loaded: form_helper
INFO - 2020-02-02 07:07:52 --> Helper loaded: my_helper
INFO - 2020-02-02 07:07:52 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:07:52 --> Controller Class Initialized
DEBUG - 2020-02-02 07:07:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:07:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:07:52 --> Final output sent to browser
DEBUG - 2020-02-02 07:07:52 --> Total execution time: 0.4130
INFO - 2020-02-02 07:08:07 --> Config Class Initialized
INFO - 2020-02-02 07:08:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:08:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:08:07 --> Utf8 Class Initialized
INFO - 2020-02-02 07:08:07 --> URI Class Initialized
INFO - 2020-02-02 07:08:07 --> Router Class Initialized
INFO - 2020-02-02 07:08:07 --> Output Class Initialized
INFO - 2020-02-02 07:08:07 --> Security Class Initialized
DEBUG - 2020-02-02 07:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:08:07 --> Input Class Initialized
INFO - 2020-02-02 07:08:07 --> Language Class Initialized
INFO - 2020-02-02 07:08:07 --> Language Class Initialized
INFO - 2020-02-02 07:08:07 --> Config Class Initialized
INFO - 2020-02-02 07:08:07 --> Loader Class Initialized
INFO - 2020-02-02 07:08:07 --> Helper loaded: url_helper
INFO - 2020-02-02 07:08:07 --> Helper loaded: file_helper
INFO - 2020-02-02 07:08:07 --> Helper loaded: form_helper
INFO - 2020-02-02 07:08:07 --> Helper loaded: my_helper
INFO - 2020-02-02 07:08:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:08:07 --> Controller Class Initialized
DEBUG - 2020-02-02 07:08:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:08:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:08:07 --> Final output sent to browser
DEBUG - 2020-02-02 07:08:07 --> Total execution time: 0.4552
INFO - 2020-02-02 07:08:31 --> Config Class Initialized
INFO - 2020-02-02 07:08:31 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:08:31 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:08:31 --> Utf8 Class Initialized
INFO - 2020-02-02 07:08:31 --> URI Class Initialized
INFO - 2020-02-02 07:08:31 --> Router Class Initialized
INFO - 2020-02-02 07:08:31 --> Output Class Initialized
INFO - 2020-02-02 07:08:31 --> Security Class Initialized
DEBUG - 2020-02-02 07:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:08:31 --> Input Class Initialized
INFO - 2020-02-02 07:08:31 --> Language Class Initialized
INFO - 2020-02-02 07:08:31 --> Language Class Initialized
INFO - 2020-02-02 07:08:31 --> Config Class Initialized
INFO - 2020-02-02 07:08:31 --> Loader Class Initialized
INFO - 2020-02-02 07:08:31 --> Helper loaded: url_helper
INFO - 2020-02-02 07:08:31 --> Helper loaded: file_helper
INFO - 2020-02-02 07:08:31 --> Helper loaded: form_helper
INFO - 2020-02-02 07:08:31 --> Helper loaded: my_helper
INFO - 2020-02-02 07:08:31 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:08:31 --> Controller Class Initialized
DEBUG - 2020-02-02 07:08:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:08:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:08:31 --> Final output sent to browser
DEBUG - 2020-02-02 07:08:31 --> Total execution time: 0.4183
INFO - 2020-02-02 07:08:36 --> Config Class Initialized
INFO - 2020-02-02 07:08:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:08:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:08:36 --> Utf8 Class Initialized
INFO - 2020-02-02 07:08:36 --> URI Class Initialized
INFO - 2020-02-02 07:08:36 --> Router Class Initialized
INFO - 2020-02-02 07:08:36 --> Output Class Initialized
INFO - 2020-02-02 07:08:36 --> Security Class Initialized
DEBUG - 2020-02-02 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:08:36 --> Input Class Initialized
INFO - 2020-02-02 07:08:36 --> Language Class Initialized
INFO - 2020-02-02 07:08:36 --> Language Class Initialized
INFO - 2020-02-02 07:08:36 --> Config Class Initialized
INFO - 2020-02-02 07:08:36 --> Loader Class Initialized
INFO - 2020-02-02 07:08:36 --> Helper loaded: url_helper
INFO - 2020-02-02 07:08:36 --> Helper loaded: file_helper
INFO - 2020-02-02 07:08:36 --> Helper loaded: form_helper
INFO - 2020-02-02 07:08:36 --> Helper loaded: my_helper
INFO - 2020-02-02 07:08:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:08:36 --> Controller Class Initialized
DEBUG - 2020-02-02 07:08:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:08:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:08:36 --> Final output sent to browser
DEBUG - 2020-02-02 07:08:36 --> Total execution time: 0.3993
INFO - 2020-02-02 07:10:20 --> Config Class Initialized
INFO - 2020-02-02 07:10:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:10:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:10:20 --> Utf8 Class Initialized
INFO - 2020-02-02 07:10:20 --> URI Class Initialized
INFO - 2020-02-02 07:10:20 --> Router Class Initialized
INFO - 2020-02-02 07:10:20 --> Output Class Initialized
INFO - 2020-02-02 07:10:20 --> Security Class Initialized
DEBUG - 2020-02-02 07:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:10:20 --> Input Class Initialized
INFO - 2020-02-02 07:10:20 --> Language Class Initialized
INFO - 2020-02-02 07:10:20 --> Language Class Initialized
INFO - 2020-02-02 07:10:20 --> Config Class Initialized
INFO - 2020-02-02 07:10:20 --> Loader Class Initialized
INFO - 2020-02-02 07:10:20 --> Helper loaded: url_helper
INFO - 2020-02-02 07:10:20 --> Helper loaded: file_helper
INFO - 2020-02-02 07:10:20 --> Helper loaded: form_helper
INFO - 2020-02-02 07:10:20 --> Helper loaded: my_helper
INFO - 2020-02-02 07:10:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:10:20 --> Controller Class Initialized
DEBUG - 2020-02-02 07:10:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:10:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:10:21 --> Final output sent to browser
DEBUG - 2020-02-02 07:10:21 --> Total execution time: 0.3780
INFO - 2020-02-02 07:10:39 --> Config Class Initialized
INFO - 2020-02-02 07:10:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:10:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:10:39 --> Utf8 Class Initialized
INFO - 2020-02-02 07:10:39 --> URI Class Initialized
INFO - 2020-02-02 07:10:39 --> Router Class Initialized
INFO - 2020-02-02 07:10:39 --> Output Class Initialized
INFO - 2020-02-02 07:10:39 --> Security Class Initialized
DEBUG - 2020-02-02 07:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:10:39 --> Input Class Initialized
INFO - 2020-02-02 07:10:39 --> Language Class Initialized
INFO - 2020-02-02 07:10:39 --> Language Class Initialized
INFO - 2020-02-02 07:10:40 --> Config Class Initialized
INFO - 2020-02-02 07:10:40 --> Loader Class Initialized
INFO - 2020-02-02 07:10:40 --> Helper loaded: url_helper
INFO - 2020-02-02 07:10:40 --> Helper loaded: file_helper
INFO - 2020-02-02 07:10:40 --> Helper loaded: form_helper
INFO - 2020-02-02 07:10:40 --> Helper loaded: my_helper
INFO - 2020-02-02 07:10:40 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:10:40 --> Controller Class Initialized
DEBUG - 2020-02-02 07:10:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:10:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:10:40 --> Final output sent to browser
DEBUG - 2020-02-02 07:10:40 --> Total execution time: 0.3787
INFO - 2020-02-02 07:11:03 --> Config Class Initialized
INFO - 2020-02-02 07:11:03 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:11:03 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:11:03 --> Utf8 Class Initialized
INFO - 2020-02-02 07:11:03 --> URI Class Initialized
INFO - 2020-02-02 07:11:03 --> Router Class Initialized
INFO - 2020-02-02 07:11:03 --> Output Class Initialized
INFO - 2020-02-02 07:11:03 --> Security Class Initialized
DEBUG - 2020-02-02 07:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:11:03 --> Input Class Initialized
INFO - 2020-02-02 07:11:03 --> Language Class Initialized
INFO - 2020-02-02 07:11:03 --> Language Class Initialized
INFO - 2020-02-02 07:11:03 --> Config Class Initialized
INFO - 2020-02-02 07:11:03 --> Loader Class Initialized
INFO - 2020-02-02 07:11:03 --> Helper loaded: url_helper
INFO - 2020-02-02 07:11:03 --> Helper loaded: file_helper
INFO - 2020-02-02 07:11:03 --> Helper loaded: form_helper
INFO - 2020-02-02 07:11:03 --> Helper loaded: my_helper
INFO - 2020-02-02 07:11:03 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:11:03 --> Controller Class Initialized
DEBUG - 2020-02-02 07:11:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:11:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:11:04 --> Final output sent to browser
DEBUG - 2020-02-02 07:11:04 --> Total execution time: 0.3805
INFO - 2020-02-02 07:11:10 --> Config Class Initialized
INFO - 2020-02-02 07:11:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:11:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:11:10 --> Utf8 Class Initialized
INFO - 2020-02-02 07:11:10 --> URI Class Initialized
INFO - 2020-02-02 07:11:10 --> Router Class Initialized
INFO - 2020-02-02 07:11:10 --> Output Class Initialized
INFO - 2020-02-02 07:11:10 --> Security Class Initialized
DEBUG - 2020-02-02 07:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:11:10 --> Input Class Initialized
INFO - 2020-02-02 07:11:10 --> Language Class Initialized
INFO - 2020-02-02 07:11:10 --> Language Class Initialized
INFO - 2020-02-02 07:11:10 --> Config Class Initialized
INFO - 2020-02-02 07:11:10 --> Loader Class Initialized
INFO - 2020-02-02 07:11:10 --> Helper loaded: url_helper
INFO - 2020-02-02 07:11:10 --> Helper loaded: file_helper
INFO - 2020-02-02 07:11:10 --> Helper loaded: form_helper
INFO - 2020-02-02 07:11:10 --> Helper loaded: my_helper
INFO - 2020-02-02 07:11:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:11:10 --> Controller Class Initialized
DEBUG - 2020-02-02 07:11:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:11:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:11:10 --> Final output sent to browser
DEBUG - 2020-02-02 07:11:10 --> Total execution time: 0.3787
INFO - 2020-02-02 07:11:26 --> Config Class Initialized
INFO - 2020-02-02 07:11:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:11:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:11:26 --> Utf8 Class Initialized
INFO - 2020-02-02 07:11:26 --> URI Class Initialized
INFO - 2020-02-02 07:11:26 --> Router Class Initialized
INFO - 2020-02-02 07:11:26 --> Output Class Initialized
INFO - 2020-02-02 07:11:26 --> Security Class Initialized
DEBUG - 2020-02-02 07:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:11:26 --> Input Class Initialized
INFO - 2020-02-02 07:11:26 --> Language Class Initialized
INFO - 2020-02-02 07:11:26 --> Language Class Initialized
INFO - 2020-02-02 07:11:26 --> Config Class Initialized
INFO - 2020-02-02 07:11:26 --> Loader Class Initialized
INFO - 2020-02-02 07:11:26 --> Helper loaded: url_helper
INFO - 2020-02-02 07:11:26 --> Helper loaded: file_helper
INFO - 2020-02-02 07:11:26 --> Helper loaded: form_helper
INFO - 2020-02-02 07:11:26 --> Helper loaded: my_helper
INFO - 2020-02-02 07:11:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:11:27 --> Controller Class Initialized
DEBUG - 2020-02-02 07:11:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:11:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:11:27 --> Final output sent to browser
DEBUG - 2020-02-02 07:11:27 --> Total execution time: 0.4050
INFO - 2020-02-02 07:11:48 --> Config Class Initialized
INFO - 2020-02-02 07:11:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:11:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:11:48 --> Utf8 Class Initialized
INFO - 2020-02-02 07:11:48 --> URI Class Initialized
INFO - 2020-02-02 07:11:48 --> Router Class Initialized
INFO - 2020-02-02 07:11:48 --> Output Class Initialized
INFO - 2020-02-02 07:11:48 --> Security Class Initialized
DEBUG - 2020-02-02 07:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:11:48 --> Input Class Initialized
INFO - 2020-02-02 07:11:48 --> Language Class Initialized
INFO - 2020-02-02 07:11:48 --> Language Class Initialized
INFO - 2020-02-02 07:11:48 --> Config Class Initialized
INFO - 2020-02-02 07:11:48 --> Loader Class Initialized
INFO - 2020-02-02 07:11:48 --> Helper loaded: url_helper
INFO - 2020-02-02 07:11:48 --> Helper loaded: file_helper
INFO - 2020-02-02 07:11:48 --> Helper loaded: form_helper
INFO - 2020-02-02 07:11:48 --> Helper loaded: my_helper
INFO - 2020-02-02 07:11:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:11:48 --> Controller Class Initialized
DEBUG - 2020-02-02 07:11:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:11:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:11:48 --> Final output sent to browser
DEBUG - 2020-02-02 07:11:48 --> Total execution time: 0.4194
INFO - 2020-02-02 07:12:22 --> Config Class Initialized
INFO - 2020-02-02 07:12:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:12:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:12:22 --> Utf8 Class Initialized
INFO - 2020-02-02 07:12:22 --> URI Class Initialized
INFO - 2020-02-02 07:12:22 --> Router Class Initialized
INFO - 2020-02-02 07:12:22 --> Output Class Initialized
INFO - 2020-02-02 07:12:22 --> Security Class Initialized
DEBUG - 2020-02-02 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:12:22 --> Input Class Initialized
INFO - 2020-02-02 07:12:22 --> Language Class Initialized
INFO - 2020-02-02 07:12:22 --> Language Class Initialized
INFO - 2020-02-02 07:12:22 --> Config Class Initialized
INFO - 2020-02-02 07:12:22 --> Loader Class Initialized
INFO - 2020-02-02 07:12:22 --> Helper loaded: url_helper
INFO - 2020-02-02 07:12:22 --> Helper loaded: file_helper
INFO - 2020-02-02 07:12:22 --> Helper loaded: form_helper
INFO - 2020-02-02 07:12:22 --> Helper loaded: my_helper
INFO - 2020-02-02 07:12:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:12:22 --> Controller Class Initialized
DEBUG - 2020-02-02 07:12:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:12:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:12:22 --> Final output sent to browser
DEBUG - 2020-02-02 07:12:22 --> Total execution time: 0.3837
INFO - 2020-02-02 07:12:41 --> Config Class Initialized
INFO - 2020-02-02 07:12:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:12:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:12:41 --> Utf8 Class Initialized
INFO - 2020-02-02 07:12:41 --> URI Class Initialized
INFO - 2020-02-02 07:12:41 --> Router Class Initialized
INFO - 2020-02-02 07:12:41 --> Output Class Initialized
INFO - 2020-02-02 07:12:41 --> Security Class Initialized
DEBUG - 2020-02-02 07:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:12:41 --> Input Class Initialized
INFO - 2020-02-02 07:12:41 --> Language Class Initialized
INFO - 2020-02-02 07:12:41 --> Language Class Initialized
INFO - 2020-02-02 07:12:41 --> Config Class Initialized
INFO - 2020-02-02 07:12:41 --> Loader Class Initialized
INFO - 2020-02-02 07:12:41 --> Helper loaded: url_helper
INFO - 2020-02-02 07:12:41 --> Helper loaded: file_helper
INFO - 2020-02-02 07:12:41 --> Helper loaded: form_helper
INFO - 2020-02-02 07:12:41 --> Helper loaded: my_helper
INFO - 2020-02-02 07:12:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:12:41 --> Controller Class Initialized
DEBUG - 2020-02-02 07:12:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:12:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:12:41 --> Final output sent to browser
DEBUG - 2020-02-02 07:12:41 --> Total execution time: 0.3866
INFO - 2020-02-02 07:13:00 --> Config Class Initialized
INFO - 2020-02-02 07:13:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:13:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:13:01 --> Utf8 Class Initialized
INFO - 2020-02-02 07:13:01 --> URI Class Initialized
INFO - 2020-02-02 07:13:01 --> Router Class Initialized
INFO - 2020-02-02 07:13:01 --> Output Class Initialized
INFO - 2020-02-02 07:13:01 --> Security Class Initialized
DEBUG - 2020-02-02 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:13:01 --> Input Class Initialized
INFO - 2020-02-02 07:13:01 --> Language Class Initialized
INFO - 2020-02-02 07:13:01 --> Language Class Initialized
INFO - 2020-02-02 07:13:01 --> Config Class Initialized
INFO - 2020-02-02 07:13:01 --> Loader Class Initialized
INFO - 2020-02-02 07:13:01 --> Helper loaded: url_helper
INFO - 2020-02-02 07:13:01 --> Helper loaded: file_helper
INFO - 2020-02-02 07:13:01 --> Helper loaded: form_helper
INFO - 2020-02-02 07:13:01 --> Helper loaded: my_helper
INFO - 2020-02-02 07:13:01 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:13:01 --> Controller Class Initialized
DEBUG - 2020-02-02 07:13:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:13:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:13:01 --> Final output sent to browser
DEBUG - 2020-02-02 07:13:01 --> Total execution time: 0.4923
INFO - 2020-02-02 07:15:20 --> Config Class Initialized
INFO - 2020-02-02 07:15:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:15:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:15:20 --> Utf8 Class Initialized
INFO - 2020-02-02 07:15:20 --> URI Class Initialized
INFO - 2020-02-02 07:15:20 --> Router Class Initialized
INFO - 2020-02-02 07:15:20 --> Output Class Initialized
INFO - 2020-02-02 07:15:20 --> Security Class Initialized
DEBUG - 2020-02-02 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:15:20 --> Input Class Initialized
INFO - 2020-02-02 07:15:20 --> Language Class Initialized
INFO - 2020-02-02 07:15:20 --> Language Class Initialized
INFO - 2020-02-02 07:15:20 --> Config Class Initialized
INFO - 2020-02-02 07:15:20 --> Loader Class Initialized
INFO - 2020-02-02 07:15:20 --> Helper loaded: url_helper
INFO - 2020-02-02 07:15:20 --> Helper loaded: file_helper
INFO - 2020-02-02 07:15:20 --> Helper loaded: form_helper
INFO - 2020-02-02 07:15:20 --> Helper loaded: my_helper
INFO - 2020-02-02 07:15:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:15:20 --> Controller Class Initialized
DEBUG - 2020-02-02 07:15:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:15:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:15:20 --> Final output sent to browser
DEBUG - 2020-02-02 07:15:20 --> Total execution time: 0.4013
INFO - 2020-02-02 07:15:25 --> Config Class Initialized
INFO - 2020-02-02 07:15:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:15:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:15:25 --> Utf8 Class Initialized
INFO - 2020-02-02 07:15:25 --> URI Class Initialized
INFO - 2020-02-02 07:15:25 --> Router Class Initialized
INFO - 2020-02-02 07:15:25 --> Output Class Initialized
INFO - 2020-02-02 07:15:25 --> Security Class Initialized
DEBUG - 2020-02-02 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:15:25 --> Input Class Initialized
INFO - 2020-02-02 07:15:25 --> Language Class Initialized
INFO - 2020-02-02 07:15:25 --> Language Class Initialized
INFO - 2020-02-02 07:15:25 --> Config Class Initialized
INFO - 2020-02-02 07:15:25 --> Loader Class Initialized
INFO - 2020-02-02 07:15:25 --> Helper loaded: url_helper
INFO - 2020-02-02 07:15:25 --> Helper loaded: file_helper
INFO - 2020-02-02 07:15:25 --> Helper loaded: form_helper
INFO - 2020-02-02 07:15:25 --> Helper loaded: my_helper
INFO - 2020-02-02 07:15:25 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:15:25 --> Controller Class Initialized
DEBUG - 2020-02-02 07:15:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:15:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:15:25 --> Final output sent to browser
DEBUG - 2020-02-02 07:15:25 --> Total execution time: 0.4304
INFO - 2020-02-02 07:16:07 --> Config Class Initialized
INFO - 2020-02-02 07:16:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:16:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:16:07 --> Utf8 Class Initialized
INFO - 2020-02-02 07:16:07 --> URI Class Initialized
INFO - 2020-02-02 07:16:07 --> Router Class Initialized
INFO - 2020-02-02 07:16:07 --> Output Class Initialized
INFO - 2020-02-02 07:16:07 --> Security Class Initialized
DEBUG - 2020-02-02 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:16:07 --> Input Class Initialized
INFO - 2020-02-02 07:16:07 --> Language Class Initialized
INFO - 2020-02-02 07:16:07 --> Language Class Initialized
INFO - 2020-02-02 07:16:07 --> Config Class Initialized
INFO - 2020-02-02 07:16:07 --> Loader Class Initialized
INFO - 2020-02-02 07:16:07 --> Helper loaded: url_helper
INFO - 2020-02-02 07:16:07 --> Helper loaded: file_helper
INFO - 2020-02-02 07:16:07 --> Helper loaded: form_helper
INFO - 2020-02-02 07:16:07 --> Helper loaded: my_helper
INFO - 2020-02-02 07:16:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:16:07 --> Controller Class Initialized
DEBUG - 2020-02-02 07:16:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:16:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:16:07 --> Final output sent to browser
DEBUG - 2020-02-02 07:16:07 --> Total execution time: 0.4020
INFO - 2020-02-02 07:16:20 --> Config Class Initialized
INFO - 2020-02-02 07:16:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:16:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:16:20 --> Utf8 Class Initialized
INFO - 2020-02-02 07:16:20 --> URI Class Initialized
INFO - 2020-02-02 07:16:20 --> Router Class Initialized
INFO - 2020-02-02 07:16:20 --> Output Class Initialized
INFO - 2020-02-02 07:16:20 --> Security Class Initialized
DEBUG - 2020-02-02 07:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:16:20 --> Input Class Initialized
INFO - 2020-02-02 07:16:20 --> Language Class Initialized
INFO - 2020-02-02 07:16:20 --> Language Class Initialized
INFO - 2020-02-02 07:16:20 --> Config Class Initialized
INFO - 2020-02-02 07:16:20 --> Loader Class Initialized
INFO - 2020-02-02 07:16:20 --> Helper loaded: url_helper
INFO - 2020-02-02 07:16:20 --> Helper loaded: file_helper
INFO - 2020-02-02 07:16:20 --> Helper loaded: form_helper
INFO - 2020-02-02 07:16:20 --> Helper loaded: my_helper
INFO - 2020-02-02 07:16:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:16:20 --> Controller Class Initialized
DEBUG - 2020-02-02 07:16:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:16:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:16:20 --> Final output sent to browser
DEBUG - 2020-02-02 07:16:20 --> Total execution time: 0.3894
INFO - 2020-02-02 07:16:30 --> Config Class Initialized
INFO - 2020-02-02 07:16:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:16:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:16:30 --> Utf8 Class Initialized
INFO - 2020-02-02 07:16:30 --> URI Class Initialized
INFO - 2020-02-02 07:16:30 --> Router Class Initialized
INFO - 2020-02-02 07:16:30 --> Output Class Initialized
INFO - 2020-02-02 07:16:30 --> Security Class Initialized
DEBUG - 2020-02-02 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:16:30 --> Input Class Initialized
INFO - 2020-02-02 07:16:30 --> Language Class Initialized
INFO - 2020-02-02 07:16:30 --> Language Class Initialized
INFO - 2020-02-02 07:16:30 --> Config Class Initialized
INFO - 2020-02-02 07:16:30 --> Loader Class Initialized
INFO - 2020-02-02 07:16:30 --> Helper loaded: url_helper
INFO - 2020-02-02 07:16:30 --> Helper loaded: file_helper
INFO - 2020-02-02 07:16:30 --> Helper loaded: form_helper
INFO - 2020-02-02 07:16:30 --> Helper loaded: my_helper
INFO - 2020-02-02 07:16:30 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:16:30 --> Controller Class Initialized
DEBUG - 2020-02-02 07:16:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:16:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:16:30 --> Final output sent to browser
DEBUG - 2020-02-02 07:16:30 --> Total execution time: 0.4230
INFO - 2020-02-02 07:16:49 --> Config Class Initialized
INFO - 2020-02-02 07:16:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:16:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:16:49 --> Utf8 Class Initialized
INFO - 2020-02-02 07:16:49 --> URI Class Initialized
INFO - 2020-02-02 07:16:49 --> Router Class Initialized
INFO - 2020-02-02 07:16:49 --> Output Class Initialized
INFO - 2020-02-02 07:16:49 --> Security Class Initialized
DEBUG - 2020-02-02 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:16:49 --> Input Class Initialized
INFO - 2020-02-02 07:16:49 --> Language Class Initialized
INFO - 2020-02-02 07:16:49 --> Language Class Initialized
INFO - 2020-02-02 07:16:49 --> Config Class Initialized
INFO - 2020-02-02 07:16:49 --> Loader Class Initialized
INFO - 2020-02-02 07:16:49 --> Helper loaded: url_helper
INFO - 2020-02-02 07:16:49 --> Helper loaded: file_helper
INFO - 2020-02-02 07:16:49 --> Helper loaded: form_helper
INFO - 2020-02-02 07:16:49 --> Helper loaded: my_helper
INFO - 2020-02-02 07:16:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:16:49 --> Controller Class Initialized
DEBUG - 2020-02-02 07:16:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:16:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:16:49 --> Final output sent to browser
DEBUG - 2020-02-02 07:16:49 --> Total execution time: 0.3934
INFO - 2020-02-02 07:17:10 --> Config Class Initialized
INFO - 2020-02-02 07:17:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:17:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:17:10 --> Utf8 Class Initialized
INFO - 2020-02-02 07:17:10 --> URI Class Initialized
INFO - 2020-02-02 07:17:10 --> Router Class Initialized
INFO - 2020-02-02 07:17:10 --> Output Class Initialized
INFO - 2020-02-02 07:17:10 --> Security Class Initialized
DEBUG - 2020-02-02 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:17:10 --> Input Class Initialized
INFO - 2020-02-02 07:17:10 --> Language Class Initialized
INFO - 2020-02-02 07:17:10 --> Language Class Initialized
INFO - 2020-02-02 07:17:10 --> Config Class Initialized
INFO - 2020-02-02 07:17:10 --> Loader Class Initialized
INFO - 2020-02-02 07:17:10 --> Helper loaded: url_helper
INFO - 2020-02-02 07:17:10 --> Helper loaded: file_helper
INFO - 2020-02-02 07:17:10 --> Helper loaded: form_helper
INFO - 2020-02-02 07:17:10 --> Helper loaded: my_helper
INFO - 2020-02-02 07:17:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:17:10 --> Controller Class Initialized
DEBUG - 2020-02-02 07:17:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:17:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:17:11 --> Final output sent to browser
DEBUG - 2020-02-02 07:17:11 --> Total execution time: 0.4396
INFO - 2020-02-02 07:17:20 --> Config Class Initialized
INFO - 2020-02-02 07:17:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:17:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:17:20 --> Utf8 Class Initialized
INFO - 2020-02-02 07:17:20 --> URI Class Initialized
INFO - 2020-02-02 07:17:20 --> Router Class Initialized
INFO - 2020-02-02 07:17:20 --> Output Class Initialized
INFO - 2020-02-02 07:17:20 --> Security Class Initialized
DEBUG - 2020-02-02 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:17:20 --> Input Class Initialized
INFO - 2020-02-02 07:17:20 --> Language Class Initialized
INFO - 2020-02-02 07:17:20 --> Language Class Initialized
INFO - 2020-02-02 07:17:20 --> Config Class Initialized
INFO - 2020-02-02 07:17:20 --> Loader Class Initialized
INFO - 2020-02-02 07:17:20 --> Helper loaded: url_helper
INFO - 2020-02-02 07:17:20 --> Helper loaded: file_helper
INFO - 2020-02-02 07:17:20 --> Helper loaded: form_helper
INFO - 2020-02-02 07:17:20 --> Helper loaded: my_helper
INFO - 2020-02-02 07:17:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:17:20 --> Controller Class Initialized
DEBUG - 2020-02-02 07:17:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:17:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:17:20 --> Final output sent to browser
DEBUG - 2020-02-02 07:17:20 --> Total execution time: 0.4209
INFO - 2020-02-02 07:18:26 --> Config Class Initialized
INFO - 2020-02-02 07:18:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:18:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:18:26 --> Utf8 Class Initialized
INFO - 2020-02-02 07:18:26 --> URI Class Initialized
INFO - 2020-02-02 07:18:26 --> Router Class Initialized
INFO - 2020-02-02 07:18:26 --> Output Class Initialized
INFO - 2020-02-02 07:18:26 --> Security Class Initialized
DEBUG - 2020-02-02 07:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:18:26 --> Input Class Initialized
INFO - 2020-02-02 07:18:26 --> Language Class Initialized
INFO - 2020-02-02 07:18:26 --> Language Class Initialized
INFO - 2020-02-02 07:18:26 --> Config Class Initialized
INFO - 2020-02-02 07:18:26 --> Loader Class Initialized
INFO - 2020-02-02 07:18:26 --> Helper loaded: url_helper
INFO - 2020-02-02 07:18:26 --> Helper loaded: file_helper
INFO - 2020-02-02 07:18:26 --> Helper loaded: form_helper
INFO - 2020-02-02 07:18:26 --> Helper loaded: my_helper
INFO - 2020-02-02 07:18:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:18:27 --> Controller Class Initialized
DEBUG - 2020-02-02 07:18:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:18:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:18:27 --> Final output sent to browser
DEBUG - 2020-02-02 07:18:27 --> Total execution time: 0.4065
INFO - 2020-02-02 07:18:55 --> Config Class Initialized
INFO - 2020-02-02 07:18:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:18:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:18:55 --> Utf8 Class Initialized
INFO - 2020-02-02 07:18:55 --> URI Class Initialized
INFO - 2020-02-02 07:18:55 --> Router Class Initialized
INFO - 2020-02-02 07:18:55 --> Output Class Initialized
INFO - 2020-02-02 07:18:55 --> Security Class Initialized
DEBUG - 2020-02-02 07:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:18:55 --> Input Class Initialized
INFO - 2020-02-02 07:18:55 --> Language Class Initialized
INFO - 2020-02-02 07:18:55 --> Language Class Initialized
INFO - 2020-02-02 07:18:55 --> Config Class Initialized
INFO - 2020-02-02 07:18:55 --> Loader Class Initialized
INFO - 2020-02-02 07:18:55 --> Helper loaded: url_helper
INFO - 2020-02-02 07:18:55 --> Helper loaded: file_helper
INFO - 2020-02-02 07:18:55 --> Helper loaded: form_helper
INFO - 2020-02-02 07:18:55 --> Helper loaded: my_helper
INFO - 2020-02-02 07:18:55 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:18:55 --> Controller Class Initialized
DEBUG - 2020-02-02 07:18:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:18:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:18:55 --> Final output sent to browser
DEBUG - 2020-02-02 07:18:55 --> Total execution time: 0.3937
INFO - 2020-02-02 07:19:06 --> Config Class Initialized
INFO - 2020-02-02 07:19:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:19:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:19:06 --> Utf8 Class Initialized
INFO - 2020-02-02 07:19:06 --> URI Class Initialized
INFO - 2020-02-02 07:19:06 --> Router Class Initialized
INFO - 2020-02-02 07:19:06 --> Output Class Initialized
INFO - 2020-02-02 07:19:06 --> Security Class Initialized
DEBUG - 2020-02-02 07:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:19:06 --> Input Class Initialized
INFO - 2020-02-02 07:19:06 --> Language Class Initialized
INFO - 2020-02-02 07:19:06 --> Language Class Initialized
INFO - 2020-02-02 07:19:06 --> Config Class Initialized
INFO - 2020-02-02 07:19:06 --> Loader Class Initialized
INFO - 2020-02-02 07:19:06 --> Helper loaded: url_helper
INFO - 2020-02-02 07:19:06 --> Helper loaded: file_helper
INFO - 2020-02-02 07:19:06 --> Helper loaded: form_helper
INFO - 2020-02-02 07:19:06 --> Helper loaded: my_helper
INFO - 2020-02-02 07:19:06 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:19:06 --> Controller Class Initialized
DEBUG - 2020-02-02 07:19:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:19:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:19:06 --> Final output sent to browser
DEBUG - 2020-02-02 07:19:06 --> Total execution time: 0.4116
INFO - 2020-02-02 07:19:15 --> Config Class Initialized
INFO - 2020-02-02 07:19:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:19:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:19:15 --> Utf8 Class Initialized
INFO - 2020-02-02 07:19:15 --> URI Class Initialized
INFO - 2020-02-02 07:19:15 --> Router Class Initialized
INFO - 2020-02-02 07:19:15 --> Output Class Initialized
INFO - 2020-02-02 07:19:15 --> Security Class Initialized
DEBUG - 2020-02-02 07:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:19:15 --> Input Class Initialized
INFO - 2020-02-02 07:19:15 --> Language Class Initialized
INFO - 2020-02-02 07:19:15 --> Language Class Initialized
INFO - 2020-02-02 07:19:15 --> Config Class Initialized
INFO - 2020-02-02 07:19:15 --> Loader Class Initialized
INFO - 2020-02-02 07:19:15 --> Helper loaded: url_helper
INFO - 2020-02-02 07:19:15 --> Helper loaded: file_helper
INFO - 2020-02-02 07:19:15 --> Helper loaded: form_helper
INFO - 2020-02-02 07:19:15 --> Helper loaded: my_helper
INFO - 2020-02-02 07:19:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:19:15 --> Controller Class Initialized
DEBUG - 2020-02-02 07:19:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:19:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:19:15 --> Final output sent to browser
DEBUG - 2020-02-02 07:19:15 --> Total execution time: 0.4048
INFO - 2020-02-02 07:19:26 --> Config Class Initialized
INFO - 2020-02-02 07:19:26 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:19:26 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:19:26 --> Utf8 Class Initialized
INFO - 2020-02-02 07:19:26 --> URI Class Initialized
INFO - 2020-02-02 07:19:26 --> Router Class Initialized
INFO - 2020-02-02 07:19:26 --> Output Class Initialized
INFO - 2020-02-02 07:19:26 --> Security Class Initialized
DEBUG - 2020-02-02 07:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:19:26 --> Input Class Initialized
INFO - 2020-02-02 07:19:26 --> Language Class Initialized
INFO - 2020-02-02 07:19:26 --> Language Class Initialized
INFO - 2020-02-02 07:19:26 --> Config Class Initialized
INFO - 2020-02-02 07:19:26 --> Loader Class Initialized
INFO - 2020-02-02 07:19:26 --> Helper loaded: url_helper
INFO - 2020-02-02 07:19:26 --> Helper loaded: file_helper
INFO - 2020-02-02 07:19:26 --> Helper loaded: form_helper
INFO - 2020-02-02 07:19:26 --> Helper loaded: my_helper
INFO - 2020-02-02 07:19:26 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:19:26 --> Controller Class Initialized
DEBUG - 2020-02-02 07:19:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:19:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:19:26 --> Final output sent to browser
DEBUG - 2020-02-02 07:19:26 --> Total execution time: 0.4068
INFO - 2020-02-02 07:20:22 --> Config Class Initialized
INFO - 2020-02-02 07:20:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:20:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:20:22 --> Utf8 Class Initialized
INFO - 2020-02-02 07:20:22 --> URI Class Initialized
INFO - 2020-02-02 07:20:22 --> Router Class Initialized
INFO - 2020-02-02 07:20:22 --> Output Class Initialized
INFO - 2020-02-02 07:20:22 --> Security Class Initialized
DEBUG - 2020-02-02 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:20:22 --> Input Class Initialized
INFO - 2020-02-02 07:20:22 --> Language Class Initialized
INFO - 2020-02-02 07:20:22 --> Language Class Initialized
INFO - 2020-02-02 07:20:22 --> Config Class Initialized
INFO - 2020-02-02 07:20:22 --> Loader Class Initialized
INFO - 2020-02-02 07:20:22 --> Helper loaded: url_helper
INFO - 2020-02-02 07:20:22 --> Helper loaded: file_helper
INFO - 2020-02-02 07:20:22 --> Helper loaded: form_helper
INFO - 2020-02-02 07:20:22 --> Helper loaded: my_helper
INFO - 2020-02-02 07:20:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:20:22 --> Controller Class Initialized
DEBUG - 2020-02-02 07:20:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:20:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:20:22 --> Final output sent to browser
DEBUG - 2020-02-02 07:20:22 --> Total execution time: 0.3926
INFO - 2020-02-02 07:20:32 --> Config Class Initialized
INFO - 2020-02-02 07:20:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:20:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:20:32 --> Utf8 Class Initialized
INFO - 2020-02-02 07:20:32 --> URI Class Initialized
INFO - 2020-02-02 07:20:32 --> Router Class Initialized
INFO - 2020-02-02 07:20:32 --> Output Class Initialized
INFO - 2020-02-02 07:20:32 --> Security Class Initialized
DEBUG - 2020-02-02 07:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:20:32 --> Input Class Initialized
INFO - 2020-02-02 07:20:32 --> Language Class Initialized
INFO - 2020-02-02 07:20:32 --> Language Class Initialized
INFO - 2020-02-02 07:20:32 --> Config Class Initialized
INFO - 2020-02-02 07:20:32 --> Loader Class Initialized
INFO - 2020-02-02 07:20:32 --> Helper loaded: url_helper
INFO - 2020-02-02 07:20:32 --> Helper loaded: file_helper
INFO - 2020-02-02 07:20:32 --> Helper loaded: form_helper
INFO - 2020-02-02 07:20:33 --> Helper loaded: my_helper
INFO - 2020-02-02 07:20:33 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:20:33 --> Controller Class Initialized
DEBUG - 2020-02-02 07:20:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:20:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:20:33 --> Final output sent to browser
DEBUG - 2020-02-02 07:20:33 --> Total execution time: 0.4647
INFO - 2020-02-02 07:21:30 --> Config Class Initialized
INFO - 2020-02-02 07:21:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:21:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:21:30 --> Utf8 Class Initialized
INFO - 2020-02-02 07:21:30 --> URI Class Initialized
INFO - 2020-02-02 07:21:30 --> Router Class Initialized
INFO - 2020-02-02 07:21:30 --> Output Class Initialized
INFO - 2020-02-02 07:21:30 --> Security Class Initialized
DEBUG - 2020-02-02 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:21:30 --> Input Class Initialized
INFO - 2020-02-02 07:21:30 --> Language Class Initialized
INFO - 2020-02-02 07:21:30 --> Language Class Initialized
INFO - 2020-02-02 07:21:30 --> Config Class Initialized
INFO - 2020-02-02 07:21:30 --> Loader Class Initialized
INFO - 2020-02-02 07:21:30 --> Helper loaded: url_helper
INFO - 2020-02-02 07:21:30 --> Helper loaded: file_helper
INFO - 2020-02-02 07:21:30 --> Helper loaded: form_helper
INFO - 2020-02-02 07:21:30 --> Helper loaded: my_helper
INFO - 2020-02-02 07:21:30 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:21:30 --> Controller Class Initialized
DEBUG - 2020-02-02 07:21:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-02 07:21:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:21:30 --> Final output sent to browser
DEBUG - 2020-02-02 07:21:30 --> Total execution time: 0.3601
INFO - 2020-02-02 07:21:35 --> Config Class Initialized
INFO - 2020-02-02 07:21:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:21:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:21:35 --> Utf8 Class Initialized
INFO - 2020-02-02 07:21:35 --> URI Class Initialized
INFO - 2020-02-02 07:21:35 --> Router Class Initialized
INFO - 2020-02-02 07:21:35 --> Output Class Initialized
INFO - 2020-02-02 07:21:35 --> Security Class Initialized
DEBUG - 2020-02-02 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:21:35 --> Input Class Initialized
INFO - 2020-02-02 07:21:35 --> Language Class Initialized
INFO - 2020-02-02 07:21:35 --> Language Class Initialized
INFO - 2020-02-02 07:21:35 --> Config Class Initialized
INFO - 2020-02-02 07:21:35 --> Loader Class Initialized
INFO - 2020-02-02 07:21:35 --> Helper loaded: url_helper
INFO - 2020-02-02 07:21:35 --> Helper loaded: file_helper
INFO - 2020-02-02 07:21:35 --> Helper loaded: form_helper
INFO - 2020-02-02 07:21:35 --> Helper loaded: my_helper
INFO - 2020-02-02 07:21:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:21:36 --> Controller Class Initialized
DEBUG - 2020-02-02 07:21:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:21:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:21:36 --> Final output sent to browser
DEBUG - 2020-02-02 07:21:36 --> Total execution time: 0.3914
INFO - 2020-02-02 07:21:41 --> Config Class Initialized
INFO - 2020-02-02 07:21:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:21:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:21:41 --> Utf8 Class Initialized
INFO - 2020-02-02 07:21:41 --> URI Class Initialized
INFO - 2020-02-02 07:21:41 --> Router Class Initialized
INFO - 2020-02-02 07:21:41 --> Output Class Initialized
INFO - 2020-02-02 07:21:41 --> Security Class Initialized
DEBUG - 2020-02-02 07:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:21:41 --> Input Class Initialized
INFO - 2020-02-02 07:21:41 --> Language Class Initialized
INFO - 2020-02-02 07:21:41 --> Language Class Initialized
INFO - 2020-02-02 07:21:41 --> Config Class Initialized
INFO - 2020-02-02 07:21:41 --> Loader Class Initialized
INFO - 2020-02-02 07:21:41 --> Helper loaded: url_helper
INFO - 2020-02-02 07:21:41 --> Helper loaded: file_helper
INFO - 2020-02-02 07:21:41 --> Helper loaded: form_helper
INFO - 2020-02-02 07:21:41 --> Helper loaded: my_helper
INFO - 2020-02-02 07:21:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:21:41 --> Controller Class Initialized
DEBUG - 2020-02-02 07:21:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:21:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:21:41 --> Final output sent to browser
DEBUG - 2020-02-02 07:21:41 --> Total execution time: 0.3965
INFO - 2020-02-02 07:22:04 --> Config Class Initialized
INFO - 2020-02-02 07:22:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:04 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:04 --> URI Class Initialized
INFO - 2020-02-02 07:22:04 --> Router Class Initialized
INFO - 2020-02-02 07:22:04 --> Output Class Initialized
INFO - 2020-02-02 07:22:04 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:04 --> Input Class Initialized
INFO - 2020-02-02 07:22:04 --> Language Class Initialized
INFO - 2020-02-02 07:22:04 --> Language Class Initialized
INFO - 2020-02-02 07:22:04 --> Config Class Initialized
INFO - 2020-02-02 07:22:04 --> Loader Class Initialized
INFO - 2020-02-02 07:22:04 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:04 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:04 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:04 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:04 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:04 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:04 --> Total execution time: 0.3587
INFO - 2020-02-02 07:22:08 --> Config Class Initialized
INFO - 2020-02-02 07:22:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:08 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:08 --> URI Class Initialized
INFO - 2020-02-02 07:22:08 --> Router Class Initialized
INFO - 2020-02-02 07:22:08 --> Output Class Initialized
INFO - 2020-02-02 07:22:08 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:08 --> Input Class Initialized
INFO - 2020-02-02 07:22:08 --> Language Class Initialized
INFO - 2020-02-02 07:22:08 --> Language Class Initialized
INFO - 2020-02-02 07:22:08 --> Config Class Initialized
INFO - 2020-02-02 07:22:08 --> Loader Class Initialized
INFO - 2020-02-02 07:22:09 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:09 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:09 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:09 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:09 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:09 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:09 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:09 --> Total execution time: 0.3895
INFO - 2020-02-02 07:22:14 --> Config Class Initialized
INFO - 2020-02-02 07:22:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:14 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:14 --> URI Class Initialized
INFO - 2020-02-02 07:22:14 --> Router Class Initialized
INFO - 2020-02-02 07:22:14 --> Output Class Initialized
INFO - 2020-02-02 07:22:14 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:14 --> Input Class Initialized
INFO - 2020-02-02 07:22:14 --> Language Class Initialized
INFO - 2020-02-02 07:22:14 --> Language Class Initialized
INFO - 2020-02-02 07:22:14 --> Config Class Initialized
INFO - 2020-02-02 07:22:14 --> Loader Class Initialized
INFO - 2020-02-02 07:22:14 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:14 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:14 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:14 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:14 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:14 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:14 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:14 --> Total execution time: 0.3959
INFO - 2020-02-02 07:22:16 --> Config Class Initialized
INFO - 2020-02-02 07:22:16 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:16 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:16 --> URI Class Initialized
INFO - 2020-02-02 07:22:16 --> Router Class Initialized
INFO - 2020-02-02 07:22:16 --> Output Class Initialized
INFO - 2020-02-02 07:22:16 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:16 --> Input Class Initialized
INFO - 2020-02-02 07:22:16 --> Language Class Initialized
INFO - 2020-02-02 07:22:16 --> Language Class Initialized
INFO - 2020-02-02 07:22:16 --> Config Class Initialized
INFO - 2020-02-02 07:22:16 --> Loader Class Initialized
INFO - 2020-02-02 07:22:16 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:16 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:16 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:16 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:16 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:16 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:16 --> Total execution time: 0.3766
INFO - 2020-02-02 07:22:17 --> Config Class Initialized
INFO - 2020-02-02 07:22:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:17 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:17 --> URI Class Initialized
INFO - 2020-02-02 07:22:17 --> Router Class Initialized
INFO - 2020-02-02 07:22:17 --> Output Class Initialized
INFO - 2020-02-02 07:22:17 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:17 --> Input Class Initialized
INFO - 2020-02-02 07:22:17 --> Language Class Initialized
INFO - 2020-02-02 07:22:17 --> Language Class Initialized
INFO - 2020-02-02 07:22:17 --> Config Class Initialized
INFO - 2020-02-02 07:22:17 --> Loader Class Initialized
INFO - 2020-02-02 07:22:17 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:17 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:17 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:17 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:17 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:17 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:17 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:17 --> Total execution time: 0.3833
INFO - 2020-02-02 07:22:17 --> Config Class Initialized
INFO - 2020-02-02 07:22:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:17 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:17 --> URI Class Initialized
INFO - 2020-02-02 07:22:17 --> Router Class Initialized
INFO - 2020-02-02 07:22:18 --> Output Class Initialized
INFO - 2020-02-02 07:22:18 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:18 --> Input Class Initialized
INFO - 2020-02-02 07:22:18 --> Language Class Initialized
INFO - 2020-02-02 07:22:18 --> Language Class Initialized
INFO - 2020-02-02 07:22:18 --> Config Class Initialized
INFO - 2020-02-02 07:22:18 --> Loader Class Initialized
INFO - 2020-02-02 07:22:18 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:18 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:18 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:18 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:18 --> Total execution time: 0.3786
INFO - 2020-02-02 07:22:18 --> Config Class Initialized
INFO - 2020-02-02 07:22:18 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:18 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:18 --> URI Class Initialized
INFO - 2020-02-02 07:22:18 --> Router Class Initialized
INFO - 2020-02-02 07:22:18 --> Output Class Initialized
INFO - 2020-02-02 07:22:18 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:18 --> Input Class Initialized
INFO - 2020-02-02 07:22:18 --> Language Class Initialized
INFO - 2020-02-02 07:22:18 --> Language Class Initialized
INFO - 2020-02-02 07:22:18 --> Config Class Initialized
INFO - 2020-02-02 07:22:18 --> Loader Class Initialized
INFO - 2020-02-02 07:22:18 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:18 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:18 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:18 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:19 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:19 --> Total execution time: 0.4094
INFO - 2020-02-02 07:22:22 --> Config Class Initialized
INFO - 2020-02-02 07:22:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:22 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:22 --> URI Class Initialized
INFO - 2020-02-02 07:22:22 --> Router Class Initialized
INFO - 2020-02-02 07:22:22 --> Output Class Initialized
INFO - 2020-02-02 07:22:22 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:22 --> Input Class Initialized
INFO - 2020-02-02 07:22:22 --> Language Class Initialized
INFO - 2020-02-02 07:22:22 --> Language Class Initialized
INFO - 2020-02-02 07:22:22 --> Config Class Initialized
INFO - 2020-02-02 07:22:22 --> Loader Class Initialized
INFO - 2020-02-02 07:22:22 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:22 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:22 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:22 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:22 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:22 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:22 --> Total execution time: 0.4564
INFO - 2020-02-02 07:22:23 --> Config Class Initialized
INFO - 2020-02-02 07:22:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:24 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:24 --> URI Class Initialized
INFO - 2020-02-02 07:22:24 --> Router Class Initialized
INFO - 2020-02-02 07:22:24 --> Output Class Initialized
INFO - 2020-02-02 07:22:24 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:24 --> Input Class Initialized
INFO - 2020-02-02 07:22:24 --> Language Class Initialized
INFO - 2020-02-02 07:22:24 --> Language Class Initialized
INFO - 2020-02-02 07:22:24 --> Config Class Initialized
INFO - 2020-02-02 07:22:24 --> Loader Class Initialized
INFO - 2020-02-02 07:22:24 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:24 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:24 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:24 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:24 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:24 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:24 --> Total execution time: 0.3955
INFO - 2020-02-02 07:22:29 --> Config Class Initialized
INFO - 2020-02-02 07:22:29 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:22:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:22:29 --> Utf8 Class Initialized
INFO - 2020-02-02 07:22:29 --> URI Class Initialized
INFO - 2020-02-02 07:22:29 --> Router Class Initialized
INFO - 2020-02-02 07:22:29 --> Output Class Initialized
INFO - 2020-02-02 07:22:29 --> Security Class Initialized
DEBUG - 2020-02-02 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:22:29 --> Input Class Initialized
INFO - 2020-02-02 07:22:29 --> Language Class Initialized
INFO - 2020-02-02 07:22:29 --> Language Class Initialized
INFO - 2020-02-02 07:22:29 --> Config Class Initialized
INFO - 2020-02-02 07:22:29 --> Loader Class Initialized
INFO - 2020-02-02 07:22:29 --> Helper loaded: url_helper
INFO - 2020-02-02 07:22:29 --> Helper loaded: file_helper
INFO - 2020-02-02 07:22:29 --> Helper loaded: form_helper
INFO - 2020-02-02 07:22:29 --> Helper loaded: my_helper
INFO - 2020-02-02 07:22:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:22:29 --> Controller Class Initialized
DEBUG - 2020-02-02 07:22:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 07:22:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:22:29 --> Final output sent to browser
DEBUG - 2020-02-02 07:22:29 --> Total execution time: 0.3798
INFO - 2020-02-02 07:30:08 --> Config Class Initialized
INFO - 2020-02-02 07:30:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:08 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:08 --> URI Class Initialized
DEBUG - 2020-02-02 07:30:08 --> No URI present. Default controller set.
INFO - 2020-02-02 07:30:08 --> Router Class Initialized
INFO - 2020-02-02 07:30:08 --> Output Class Initialized
INFO - 2020-02-02 07:30:08 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:08 --> Input Class Initialized
INFO - 2020-02-02 07:30:08 --> Language Class Initialized
INFO - 2020-02-02 07:30:08 --> Language Class Initialized
INFO - 2020-02-02 07:30:08 --> Config Class Initialized
INFO - 2020-02-02 07:30:08 --> Loader Class Initialized
INFO - 2020-02-02 07:30:09 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:09 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:09 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:09 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:09 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:09 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:30:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:09 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:09 --> Total execution time: 0.4436
INFO - 2020-02-02 07:30:11 --> Config Class Initialized
INFO - 2020-02-02 07:30:11 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:11 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:11 --> URI Class Initialized
INFO - 2020-02-02 07:30:11 --> Router Class Initialized
INFO - 2020-02-02 07:30:11 --> Output Class Initialized
INFO - 2020-02-02 07:30:11 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:11 --> Input Class Initialized
INFO - 2020-02-02 07:30:11 --> Language Class Initialized
INFO - 2020-02-02 07:30:11 --> Language Class Initialized
INFO - 2020-02-02 07:30:11 --> Config Class Initialized
INFO - 2020-02-02 07:30:11 --> Loader Class Initialized
INFO - 2020-02-02 07:30:11 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:11 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:11 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:11 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:11 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:11 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-02 07:30:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:11 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:11 --> Total execution time: 0.3666
INFO - 2020-02-02 07:30:13 --> Config Class Initialized
INFO - 2020-02-02 07:30:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:14 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:14 --> URI Class Initialized
DEBUG - 2020-02-02 07:30:14 --> No URI present. Default controller set.
INFO - 2020-02-02 07:30:14 --> Router Class Initialized
INFO - 2020-02-02 07:30:14 --> Output Class Initialized
INFO - 2020-02-02 07:30:14 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:14 --> Input Class Initialized
INFO - 2020-02-02 07:30:14 --> Language Class Initialized
INFO - 2020-02-02 07:30:14 --> Language Class Initialized
INFO - 2020-02-02 07:30:14 --> Config Class Initialized
INFO - 2020-02-02 07:30:14 --> Loader Class Initialized
INFO - 2020-02-02 07:30:14 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:14 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:14 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:14 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:14 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:14 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:30:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:14 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:14 --> Total execution time: 0.4605
INFO - 2020-02-02 07:30:23 --> Config Class Initialized
INFO - 2020-02-02 07:30:23 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:23 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:23 --> URI Class Initialized
INFO - 2020-02-02 07:30:23 --> Router Class Initialized
INFO - 2020-02-02 07:30:23 --> Output Class Initialized
INFO - 2020-02-02 07:30:24 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:24 --> Input Class Initialized
INFO - 2020-02-02 07:30:24 --> Language Class Initialized
INFO - 2020-02-02 07:30:24 --> Language Class Initialized
INFO - 2020-02-02 07:30:24 --> Config Class Initialized
INFO - 2020-02-02 07:30:24 --> Loader Class Initialized
INFO - 2020-02-02 07:30:24 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:24 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:24 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:24 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:24 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-02 07:30:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:24 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:24 --> Total execution time: 0.5355
INFO - 2020-02-02 07:30:27 --> Config Class Initialized
INFO - 2020-02-02 07:30:27 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:27 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:27 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:27 --> URI Class Initialized
INFO - 2020-02-02 07:30:27 --> Router Class Initialized
INFO - 2020-02-02 07:30:27 --> Output Class Initialized
INFO - 2020-02-02 07:30:28 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:28 --> Input Class Initialized
INFO - 2020-02-02 07:30:28 --> Language Class Initialized
INFO - 2020-02-02 07:30:28 --> Language Class Initialized
INFO - 2020-02-02 07:30:28 --> Config Class Initialized
INFO - 2020-02-02 07:30:28 --> Loader Class Initialized
INFO - 2020-02-02 07:30:28 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:28 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:28 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:28 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:28 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:28 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-02 07:30:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:28 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:28 --> Total execution time: 0.4572
INFO - 2020-02-02 07:30:29 --> Config Class Initialized
INFO - 2020-02-02 07:30:29 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:29 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:29 --> URI Class Initialized
INFO - 2020-02-02 07:30:29 --> Router Class Initialized
INFO - 2020-02-02 07:30:29 --> Output Class Initialized
INFO - 2020-02-02 07:30:29 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:29 --> Input Class Initialized
INFO - 2020-02-02 07:30:29 --> Language Class Initialized
INFO - 2020-02-02 07:30:29 --> Language Class Initialized
INFO - 2020-02-02 07:30:29 --> Config Class Initialized
INFO - 2020-02-02 07:30:29 --> Loader Class Initialized
INFO - 2020-02-02 07:30:29 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:29 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:29 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:29 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:29 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-02 07:30:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:29 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:29 --> Total execution time: 0.4345
INFO - 2020-02-02 07:30:30 --> Config Class Initialized
INFO - 2020-02-02 07:30:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:30 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:30 --> URI Class Initialized
INFO - 2020-02-02 07:30:30 --> Router Class Initialized
INFO - 2020-02-02 07:30:30 --> Output Class Initialized
INFO - 2020-02-02 07:30:30 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:30 --> Input Class Initialized
INFO - 2020-02-02 07:30:30 --> Language Class Initialized
INFO - 2020-02-02 07:30:30 --> Language Class Initialized
INFO - 2020-02-02 07:30:30 --> Config Class Initialized
INFO - 2020-02-02 07:30:30 --> Loader Class Initialized
INFO - 2020-02-02 07:30:30 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:30 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:30 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:30 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:30 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:30 --> Controller Class Initialized
INFO - 2020-02-02 07:30:35 --> Config Class Initialized
INFO - 2020-02-02 07:30:35 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:30:35 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:30:35 --> Utf8 Class Initialized
INFO - 2020-02-02 07:30:35 --> URI Class Initialized
DEBUG - 2020-02-02 07:30:35 --> No URI present. Default controller set.
INFO - 2020-02-02 07:30:35 --> Router Class Initialized
INFO - 2020-02-02 07:30:35 --> Output Class Initialized
INFO - 2020-02-02 07:30:35 --> Security Class Initialized
DEBUG - 2020-02-02 07:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:30:35 --> Input Class Initialized
INFO - 2020-02-02 07:30:35 --> Language Class Initialized
INFO - 2020-02-02 07:30:35 --> Language Class Initialized
INFO - 2020-02-02 07:30:35 --> Config Class Initialized
INFO - 2020-02-02 07:30:35 --> Loader Class Initialized
INFO - 2020-02-02 07:30:35 --> Helper loaded: url_helper
INFO - 2020-02-02 07:30:35 --> Helper loaded: file_helper
INFO - 2020-02-02 07:30:35 --> Helper loaded: form_helper
INFO - 2020-02-02 07:30:35 --> Helper loaded: my_helper
INFO - 2020-02-02 07:30:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:30:35 --> Controller Class Initialized
DEBUG - 2020-02-02 07:30:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 07:30:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:30:35 --> Final output sent to browser
DEBUG - 2020-02-02 07:30:35 --> Total execution time: 0.4227
INFO - 2020-02-02 07:35:41 --> Config Class Initialized
INFO - 2020-02-02 07:35:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:35:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:35:41 --> Utf8 Class Initialized
INFO - 2020-02-02 07:35:41 --> URI Class Initialized
DEBUG - 2020-02-02 07:35:41 --> No URI present. Default controller set.
INFO - 2020-02-02 07:35:41 --> Router Class Initialized
INFO - 2020-02-02 07:35:41 --> Output Class Initialized
INFO - 2020-02-02 07:35:41 --> Security Class Initialized
DEBUG - 2020-02-02 07:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:35:41 --> Input Class Initialized
INFO - 2020-02-02 07:35:41 --> Language Class Initialized
INFO - 2020-02-02 07:35:41 --> Language Class Initialized
INFO - 2020-02-02 07:35:41 --> Config Class Initialized
INFO - 2020-02-02 07:35:41 --> Loader Class Initialized
INFO - 2020-02-02 07:35:41 --> Helper loaded: url_helper
INFO - 2020-02-02 07:35:41 --> Helper loaded: file_helper
INFO - 2020-02-02 07:35:41 --> Helper loaded: form_helper
INFO - 2020-02-02 07:35:41 --> Helper loaded: my_helper
INFO - 2020-02-02 07:35:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:35:41 --> Controller Class Initialized
DEBUG - 2020-02-02 07:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:35:41 --> Final output sent to browser
DEBUG - 2020-02-02 07:35:41 --> Total execution time: 0.4265
INFO - 2020-02-02 07:37:03 --> Config Class Initialized
INFO - 2020-02-02 07:37:03 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:37:03 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:37:03 --> Utf8 Class Initialized
INFO - 2020-02-02 07:37:03 --> URI Class Initialized
DEBUG - 2020-02-02 07:37:03 --> No URI present. Default controller set.
INFO - 2020-02-02 07:37:03 --> Router Class Initialized
INFO - 2020-02-02 07:37:03 --> Output Class Initialized
INFO - 2020-02-02 07:37:03 --> Security Class Initialized
DEBUG - 2020-02-02 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:37:03 --> Input Class Initialized
INFO - 2020-02-02 07:37:03 --> Language Class Initialized
INFO - 2020-02-02 07:37:03 --> Language Class Initialized
INFO - 2020-02-02 07:37:03 --> Config Class Initialized
INFO - 2020-02-02 07:37:03 --> Loader Class Initialized
INFO - 2020-02-02 07:37:03 --> Helper loaded: url_helper
INFO - 2020-02-02 07:37:03 --> Helper loaded: file_helper
INFO - 2020-02-02 07:37:03 --> Helper loaded: form_helper
INFO - 2020-02-02 07:37:03 --> Helper loaded: my_helper
INFO - 2020-02-02 07:37:03 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:37:03 --> Controller Class Initialized
DEBUG - 2020-02-02 07:37:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:37:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:37:03 --> Final output sent to browser
DEBUG - 2020-02-02 07:37:03 --> Total execution time: 0.4845
INFO - 2020-02-02 07:37:15 --> Config Class Initialized
INFO - 2020-02-02 07:37:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:37:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:37:15 --> Utf8 Class Initialized
INFO - 2020-02-02 07:37:15 --> URI Class Initialized
DEBUG - 2020-02-02 07:37:15 --> No URI present. Default controller set.
INFO - 2020-02-02 07:37:15 --> Router Class Initialized
INFO - 2020-02-02 07:37:15 --> Output Class Initialized
INFO - 2020-02-02 07:37:15 --> Security Class Initialized
DEBUG - 2020-02-02 07:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:37:15 --> Input Class Initialized
INFO - 2020-02-02 07:37:15 --> Language Class Initialized
INFO - 2020-02-02 07:37:15 --> Language Class Initialized
INFO - 2020-02-02 07:37:15 --> Config Class Initialized
INFO - 2020-02-02 07:37:15 --> Loader Class Initialized
INFO - 2020-02-02 07:37:15 --> Helper loaded: url_helper
INFO - 2020-02-02 07:37:15 --> Helper loaded: file_helper
INFO - 2020-02-02 07:37:15 --> Helper loaded: form_helper
INFO - 2020-02-02 07:37:15 --> Helper loaded: my_helper
INFO - 2020-02-02 07:37:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:37:15 --> Controller Class Initialized
DEBUG - 2020-02-02 07:37:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:37:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:37:15 --> Final output sent to browser
DEBUG - 2020-02-02 07:37:15 --> Total execution time: 0.4293
INFO - 2020-02-02 07:37:48 --> Config Class Initialized
INFO - 2020-02-02 07:37:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:37:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:37:48 --> Utf8 Class Initialized
INFO - 2020-02-02 07:37:48 --> URI Class Initialized
DEBUG - 2020-02-02 07:37:48 --> No URI present. Default controller set.
INFO - 2020-02-02 07:37:48 --> Router Class Initialized
INFO - 2020-02-02 07:37:48 --> Output Class Initialized
INFO - 2020-02-02 07:37:48 --> Security Class Initialized
DEBUG - 2020-02-02 07:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:37:48 --> Input Class Initialized
INFO - 2020-02-02 07:37:48 --> Language Class Initialized
INFO - 2020-02-02 07:37:48 --> Language Class Initialized
INFO - 2020-02-02 07:37:48 --> Config Class Initialized
INFO - 2020-02-02 07:37:48 --> Loader Class Initialized
INFO - 2020-02-02 07:37:48 --> Helper loaded: url_helper
INFO - 2020-02-02 07:37:48 --> Helper loaded: file_helper
INFO - 2020-02-02 07:37:48 --> Helper loaded: form_helper
INFO - 2020-02-02 07:37:49 --> Helper loaded: my_helper
INFO - 2020-02-02 07:37:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:37:49 --> Controller Class Initialized
DEBUG - 2020-02-02 07:37:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:37:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:37:49 --> Final output sent to browser
DEBUG - 2020-02-02 07:37:49 --> Total execution time: 0.4482
INFO - 2020-02-02 07:39:13 --> Config Class Initialized
INFO - 2020-02-02 07:39:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:39:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:39:13 --> Utf8 Class Initialized
INFO - 2020-02-02 07:39:13 --> URI Class Initialized
DEBUG - 2020-02-02 07:39:13 --> No URI present. Default controller set.
INFO - 2020-02-02 07:39:13 --> Router Class Initialized
INFO - 2020-02-02 07:39:13 --> Output Class Initialized
INFO - 2020-02-02 07:39:13 --> Security Class Initialized
DEBUG - 2020-02-02 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:39:13 --> Input Class Initialized
INFO - 2020-02-02 07:39:13 --> Language Class Initialized
INFO - 2020-02-02 07:39:13 --> Language Class Initialized
INFO - 2020-02-02 07:39:13 --> Config Class Initialized
INFO - 2020-02-02 07:39:13 --> Loader Class Initialized
INFO - 2020-02-02 07:39:13 --> Helper loaded: url_helper
INFO - 2020-02-02 07:39:13 --> Helper loaded: file_helper
INFO - 2020-02-02 07:39:13 --> Helper loaded: form_helper
INFO - 2020-02-02 07:39:13 --> Helper loaded: my_helper
INFO - 2020-02-02 07:39:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:39:13 --> Controller Class Initialized
DEBUG - 2020-02-02 07:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:39:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:39:13 --> Final output sent to browser
DEBUG - 2020-02-02 07:39:13 --> Total execution time: 0.4328
INFO - 2020-02-02 07:40:45 --> Config Class Initialized
INFO - 2020-02-02 07:40:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:40:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:40:45 --> Utf8 Class Initialized
INFO - 2020-02-02 07:40:45 --> URI Class Initialized
DEBUG - 2020-02-02 07:40:45 --> No URI present. Default controller set.
INFO - 2020-02-02 07:40:45 --> Router Class Initialized
INFO - 2020-02-02 07:40:45 --> Output Class Initialized
INFO - 2020-02-02 07:40:45 --> Security Class Initialized
DEBUG - 2020-02-02 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:40:45 --> Input Class Initialized
INFO - 2020-02-02 07:40:45 --> Language Class Initialized
INFO - 2020-02-02 07:40:45 --> Language Class Initialized
INFO - 2020-02-02 07:40:45 --> Config Class Initialized
INFO - 2020-02-02 07:40:45 --> Loader Class Initialized
INFO - 2020-02-02 07:40:45 --> Helper loaded: url_helper
INFO - 2020-02-02 07:40:45 --> Helper loaded: file_helper
INFO - 2020-02-02 07:40:45 --> Helper loaded: form_helper
INFO - 2020-02-02 07:40:45 --> Helper loaded: my_helper
INFO - 2020-02-02 07:40:45 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:40:45 --> Controller Class Initialized
DEBUG - 2020-02-02 07:40:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:40:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:40:45 --> Final output sent to browser
DEBUG - 2020-02-02 07:40:45 --> Total execution time: 0.3961
INFO - 2020-02-02 07:41:13 --> Config Class Initialized
INFO - 2020-02-02 07:41:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:41:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:41:13 --> Utf8 Class Initialized
INFO - 2020-02-02 07:41:13 --> URI Class Initialized
DEBUG - 2020-02-02 07:41:13 --> No URI present. Default controller set.
INFO - 2020-02-02 07:41:13 --> Router Class Initialized
INFO - 2020-02-02 07:41:13 --> Output Class Initialized
INFO - 2020-02-02 07:41:13 --> Security Class Initialized
DEBUG - 2020-02-02 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:41:13 --> Input Class Initialized
INFO - 2020-02-02 07:41:13 --> Language Class Initialized
INFO - 2020-02-02 07:41:13 --> Language Class Initialized
INFO - 2020-02-02 07:41:13 --> Config Class Initialized
INFO - 2020-02-02 07:41:14 --> Loader Class Initialized
INFO - 2020-02-02 07:41:14 --> Helper loaded: url_helper
INFO - 2020-02-02 07:41:14 --> Helper loaded: file_helper
INFO - 2020-02-02 07:41:14 --> Helper loaded: form_helper
INFO - 2020-02-02 07:41:14 --> Helper loaded: my_helper
INFO - 2020-02-02 07:41:14 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:41:14 --> Controller Class Initialized
DEBUG - 2020-02-02 07:41:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:41:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:41:14 --> Final output sent to browser
DEBUG - 2020-02-02 07:41:14 --> Total execution time: 0.4712
INFO - 2020-02-02 07:41:27 --> Config Class Initialized
INFO - 2020-02-02 07:41:27 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:41:27 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:41:27 --> Utf8 Class Initialized
INFO - 2020-02-02 07:41:27 --> URI Class Initialized
DEBUG - 2020-02-02 07:41:27 --> No URI present. Default controller set.
INFO - 2020-02-02 07:41:27 --> Router Class Initialized
INFO - 2020-02-02 07:41:27 --> Output Class Initialized
INFO - 2020-02-02 07:41:27 --> Security Class Initialized
DEBUG - 2020-02-02 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:41:27 --> Input Class Initialized
INFO - 2020-02-02 07:41:27 --> Language Class Initialized
INFO - 2020-02-02 07:41:27 --> Language Class Initialized
INFO - 2020-02-02 07:41:27 --> Config Class Initialized
INFO - 2020-02-02 07:41:27 --> Loader Class Initialized
INFO - 2020-02-02 07:41:27 --> Helper loaded: url_helper
INFO - 2020-02-02 07:41:27 --> Helper loaded: file_helper
INFO - 2020-02-02 07:41:27 --> Helper loaded: form_helper
INFO - 2020-02-02 07:41:27 --> Helper loaded: my_helper
INFO - 2020-02-02 07:41:27 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:41:27 --> Controller Class Initialized
DEBUG - 2020-02-02 07:41:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:41:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:41:27 --> Final output sent to browser
DEBUG - 2020-02-02 07:41:27 --> Total execution time: 0.4449
INFO - 2020-02-02 07:42:31 --> Config Class Initialized
INFO - 2020-02-02 07:42:31 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:42:31 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:42:31 --> Utf8 Class Initialized
INFO - 2020-02-02 07:42:31 --> URI Class Initialized
DEBUG - 2020-02-02 07:42:31 --> No URI present. Default controller set.
INFO - 2020-02-02 07:42:31 --> Router Class Initialized
INFO - 2020-02-02 07:42:31 --> Output Class Initialized
INFO - 2020-02-02 07:42:31 --> Security Class Initialized
DEBUG - 2020-02-02 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:42:31 --> Input Class Initialized
INFO - 2020-02-02 07:42:31 --> Language Class Initialized
INFO - 2020-02-02 07:42:31 --> Language Class Initialized
INFO - 2020-02-02 07:42:31 --> Config Class Initialized
INFO - 2020-02-02 07:42:31 --> Loader Class Initialized
INFO - 2020-02-02 07:42:31 --> Helper loaded: url_helper
INFO - 2020-02-02 07:42:31 --> Helper loaded: file_helper
INFO - 2020-02-02 07:42:31 --> Helper loaded: form_helper
INFO - 2020-02-02 07:42:31 --> Helper loaded: my_helper
INFO - 2020-02-02 07:42:31 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:42:31 --> Controller Class Initialized
DEBUG - 2020-02-02 07:42:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:42:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:42:31 --> Final output sent to browser
DEBUG - 2020-02-02 07:42:31 --> Total execution time: 0.3903
INFO - 2020-02-02 07:42:37 --> Config Class Initialized
INFO - 2020-02-02 07:42:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:42:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:42:37 --> Utf8 Class Initialized
INFO - 2020-02-02 07:42:37 --> URI Class Initialized
DEBUG - 2020-02-02 07:42:37 --> No URI present. Default controller set.
INFO - 2020-02-02 07:42:37 --> Router Class Initialized
INFO - 2020-02-02 07:42:37 --> Output Class Initialized
INFO - 2020-02-02 07:42:37 --> Security Class Initialized
DEBUG - 2020-02-02 07:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:42:37 --> Input Class Initialized
INFO - 2020-02-02 07:42:37 --> Language Class Initialized
INFO - 2020-02-02 07:42:37 --> Language Class Initialized
INFO - 2020-02-02 07:42:37 --> Config Class Initialized
INFO - 2020-02-02 07:42:37 --> Loader Class Initialized
INFO - 2020-02-02 07:42:37 --> Helper loaded: url_helper
INFO - 2020-02-02 07:42:37 --> Helper loaded: file_helper
INFO - 2020-02-02 07:42:37 --> Helper loaded: form_helper
INFO - 2020-02-02 07:42:37 --> Helper loaded: my_helper
INFO - 2020-02-02 07:42:37 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:42:37 --> Controller Class Initialized
DEBUG - 2020-02-02 07:42:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:42:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:42:37 --> Final output sent to browser
DEBUG - 2020-02-02 07:42:37 --> Total execution time: 0.4122
INFO - 2020-02-02 07:43:06 --> Config Class Initialized
INFO - 2020-02-02 07:43:06 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:43:06 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:43:06 --> Utf8 Class Initialized
INFO - 2020-02-02 07:43:06 --> URI Class Initialized
DEBUG - 2020-02-02 07:43:06 --> No URI present. Default controller set.
INFO - 2020-02-02 07:43:06 --> Router Class Initialized
INFO - 2020-02-02 07:43:06 --> Output Class Initialized
INFO - 2020-02-02 07:43:06 --> Security Class Initialized
DEBUG - 2020-02-02 07:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:43:06 --> Input Class Initialized
INFO - 2020-02-02 07:43:06 --> Language Class Initialized
INFO - 2020-02-02 07:43:06 --> Language Class Initialized
INFO - 2020-02-02 07:43:06 --> Config Class Initialized
INFO - 2020-02-02 07:43:06 --> Loader Class Initialized
INFO - 2020-02-02 07:43:06 --> Helper loaded: url_helper
INFO - 2020-02-02 07:43:06 --> Helper loaded: file_helper
INFO - 2020-02-02 07:43:06 --> Helper loaded: form_helper
INFO - 2020-02-02 07:43:06 --> Helper loaded: my_helper
INFO - 2020-02-02 07:43:06 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:43:06 --> Controller Class Initialized
DEBUG - 2020-02-02 07:43:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:43:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:43:06 --> Final output sent to browser
DEBUG - 2020-02-02 07:43:07 --> Total execution time: 0.4264
INFO - 2020-02-02 07:43:58 --> Config Class Initialized
INFO - 2020-02-02 07:43:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:43:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:43:58 --> Utf8 Class Initialized
INFO - 2020-02-02 07:43:58 --> URI Class Initialized
DEBUG - 2020-02-02 07:43:58 --> No URI present. Default controller set.
INFO - 2020-02-02 07:43:58 --> Router Class Initialized
INFO - 2020-02-02 07:43:58 --> Output Class Initialized
INFO - 2020-02-02 07:43:58 --> Security Class Initialized
DEBUG - 2020-02-02 07:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:43:58 --> Input Class Initialized
INFO - 2020-02-02 07:43:58 --> Language Class Initialized
INFO - 2020-02-02 07:43:59 --> Language Class Initialized
INFO - 2020-02-02 07:43:59 --> Config Class Initialized
INFO - 2020-02-02 07:43:59 --> Loader Class Initialized
INFO - 2020-02-02 07:43:59 --> Helper loaded: url_helper
INFO - 2020-02-02 07:43:59 --> Helper loaded: file_helper
INFO - 2020-02-02 07:43:59 --> Helper loaded: form_helper
INFO - 2020-02-02 07:43:59 --> Helper loaded: my_helper
INFO - 2020-02-02 07:43:59 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:43:59 --> Controller Class Initialized
ERROR - 2020-02-02 07:43:59 --> Severity: Notice --> Undefined variable: wali_kelas E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 21
DEBUG - 2020-02-02 07:43:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:43:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:43:59 --> Final output sent to browser
DEBUG - 2020-02-02 07:43:59 --> Total execution time: 0.4481
INFO - 2020-02-02 07:44:18 --> Config Class Initialized
INFO - 2020-02-02 07:44:18 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:44:18 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:44:18 --> Utf8 Class Initialized
INFO - 2020-02-02 07:44:18 --> URI Class Initialized
DEBUG - 2020-02-02 07:44:18 --> No URI present. Default controller set.
INFO - 2020-02-02 07:44:19 --> Router Class Initialized
INFO - 2020-02-02 07:44:19 --> Output Class Initialized
INFO - 2020-02-02 07:44:19 --> Security Class Initialized
DEBUG - 2020-02-02 07:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:44:19 --> Input Class Initialized
INFO - 2020-02-02 07:44:19 --> Language Class Initialized
INFO - 2020-02-02 07:44:19 --> Language Class Initialized
INFO - 2020-02-02 07:44:19 --> Config Class Initialized
INFO - 2020-02-02 07:44:19 --> Loader Class Initialized
INFO - 2020-02-02 07:44:19 --> Helper loaded: url_helper
INFO - 2020-02-02 07:44:19 --> Helper loaded: file_helper
INFO - 2020-02-02 07:44:19 --> Helper loaded: form_helper
INFO - 2020-02-02 07:44:19 --> Helper loaded: my_helper
INFO - 2020-02-02 07:44:19 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:44:19 --> Controller Class Initialized
ERROR - 2020-02-02 07:44:19 --> Severity: Notice --> Undefined variable: wali_kelas E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 21
DEBUG - 2020-02-02 07:44:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:44:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:44:19 --> Final output sent to browser
DEBUG - 2020-02-02 07:44:19 --> Total execution time: 0.4276
INFO - 2020-02-02 07:44:44 --> Config Class Initialized
INFO - 2020-02-02 07:44:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:44:44 --> Utf8 Class Initialized
INFO - 2020-02-02 07:44:44 --> URI Class Initialized
DEBUG - 2020-02-02 07:44:44 --> No URI present. Default controller set.
INFO - 2020-02-02 07:44:44 --> Router Class Initialized
INFO - 2020-02-02 07:44:44 --> Output Class Initialized
INFO - 2020-02-02 07:44:44 --> Security Class Initialized
DEBUG - 2020-02-02 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:44:44 --> Input Class Initialized
INFO - 2020-02-02 07:44:44 --> Language Class Initialized
INFO - 2020-02-02 07:44:44 --> Language Class Initialized
INFO - 2020-02-02 07:44:45 --> Config Class Initialized
INFO - 2020-02-02 07:44:45 --> Loader Class Initialized
INFO - 2020-02-02 07:44:45 --> Helper loaded: url_helper
INFO - 2020-02-02 07:44:45 --> Helper loaded: file_helper
INFO - 2020-02-02 07:44:45 --> Helper loaded: form_helper
INFO - 2020-02-02 07:44:45 --> Helper loaded: my_helper
INFO - 2020-02-02 07:44:45 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:44:45 --> Controller Class Initialized
DEBUG - 2020-02-02 07:44:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:44:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:44:45 --> Final output sent to browser
DEBUG - 2020-02-02 07:44:45 --> Total execution time: 0.4230
INFO - 2020-02-02 07:53:44 --> Config Class Initialized
INFO - 2020-02-02 07:53:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:53:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:53:44 --> Utf8 Class Initialized
INFO - 2020-02-02 07:53:44 --> URI Class Initialized
DEBUG - 2020-02-02 07:53:44 --> No URI present. Default controller set.
INFO - 2020-02-02 07:53:44 --> Router Class Initialized
INFO - 2020-02-02 07:53:44 --> Output Class Initialized
INFO - 2020-02-02 07:53:44 --> Security Class Initialized
DEBUG - 2020-02-02 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:53:44 --> Input Class Initialized
INFO - 2020-02-02 07:53:44 --> Language Class Initialized
INFO - 2020-02-02 07:53:44 --> Language Class Initialized
INFO - 2020-02-02 07:53:44 --> Config Class Initialized
INFO - 2020-02-02 07:53:44 --> Loader Class Initialized
INFO - 2020-02-02 07:53:44 --> Helper loaded: url_helper
INFO - 2020-02-02 07:53:44 --> Helper loaded: file_helper
INFO - 2020-02-02 07:53:44 --> Helper loaded: form_helper
INFO - 2020-02-02 07:53:44 --> Helper loaded: my_helper
INFO - 2020-02-02 07:53:44 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:53:44 --> Controller Class Initialized
ERROR - 2020-02-02 07:53:44 --> Severity: Notice --> Undefined variable: wali_kelas E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 21
ERROR - 2020-02-02 07:53:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:53:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:54:10 --> Config Class Initialized
INFO - 2020-02-02 07:54:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:54:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:54:10 --> Utf8 Class Initialized
INFO - 2020-02-02 07:54:10 --> URI Class Initialized
DEBUG - 2020-02-02 07:54:10 --> No URI present. Default controller set.
INFO - 2020-02-02 07:54:10 --> Router Class Initialized
INFO - 2020-02-02 07:54:10 --> Output Class Initialized
INFO - 2020-02-02 07:54:10 --> Security Class Initialized
DEBUG - 2020-02-02 07:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:54:10 --> Input Class Initialized
INFO - 2020-02-02 07:54:10 --> Language Class Initialized
INFO - 2020-02-02 07:54:10 --> Language Class Initialized
INFO - 2020-02-02 07:54:10 --> Config Class Initialized
INFO - 2020-02-02 07:54:11 --> Loader Class Initialized
INFO - 2020-02-02 07:54:11 --> Helper loaded: url_helper
INFO - 2020-02-02 07:54:11 --> Helper loaded: file_helper
INFO - 2020-02-02 07:54:11 --> Helper loaded: form_helper
INFO - 2020-02-02 07:54:11 --> Helper loaded: my_helper
INFO - 2020-02-02 07:54:11 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:54:11 --> Controller Class Initialized
ERROR - 2020-02-02 07:54:11 --> Severity: Notice --> Undefined index: id_guru E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
ERROR - 2020-02-02 07:54:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:54:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:54:29 --> Config Class Initialized
INFO - 2020-02-02 07:54:29 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:54:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:54:29 --> Utf8 Class Initialized
INFO - 2020-02-02 07:54:29 --> URI Class Initialized
DEBUG - 2020-02-02 07:54:29 --> No URI present. Default controller set.
INFO - 2020-02-02 07:54:29 --> Router Class Initialized
INFO - 2020-02-02 07:54:29 --> Output Class Initialized
INFO - 2020-02-02 07:54:29 --> Security Class Initialized
DEBUG - 2020-02-02 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:54:29 --> Input Class Initialized
INFO - 2020-02-02 07:54:29 --> Language Class Initialized
INFO - 2020-02-02 07:54:29 --> Language Class Initialized
INFO - 2020-02-02 07:54:29 --> Config Class Initialized
INFO - 2020-02-02 07:54:29 --> Loader Class Initialized
INFO - 2020-02-02 07:54:29 --> Helper loaded: url_helper
INFO - 2020-02-02 07:54:29 --> Helper loaded: file_helper
INFO - 2020-02-02 07:54:29 --> Helper loaded: form_helper
INFO - 2020-02-02 07:54:29 --> Helper loaded: my_helper
INFO - 2020-02-02 07:54:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:54:29 --> Controller Class Initialized
ERROR - 2020-02-02 07:54:29 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
ERROR - 2020-02-02 07:54:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:54:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:55:09 --> Config Class Initialized
INFO - 2020-02-02 07:55:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:55:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:55:09 --> Utf8 Class Initialized
INFO - 2020-02-02 07:55:09 --> URI Class Initialized
DEBUG - 2020-02-02 07:55:09 --> No URI present. Default controller set.
INFO - 2020-02-02 07:55:09 --> Router Class Initialized
INFO - 2020-02-02 07:55:09 --> Output Class Initialized
INFO - 2020-02-02 07:55:09 --> Security Class Initialized
DEBUG - 2020-02-02 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:55:09 --> Input Class Initialized
INFO - 2020-02-02 07:55:09 --> Language Class Initialized
INFO - 2020-02-02 07:55:09 --> Language Class Initialized
INFO - 2020-02-02 07:55:09 --> Config Class Initialized
INFO - 2020-02-02 07:55:09 --> Loader Class Initialized
INFO - 2020-02-02 07:55:09 --> Helper loaded: url_helper
INFO - 2020-02-02 07:55:09 --> Helper loaded: file_helper
INFO - 2020-02-02 07:55:10 --> Helper loaded: form_helper
INFO - 2020-02-02 07:55:10 --> Helper loaded: my_helper
INFO - 2020-02-02 07:55:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:55:10 --> Controller Class Initialized
ERROR - 2020-02-02 07:55:10 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
ERROR - 2020-02-02 07:55:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:55:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:55:15 --> Config Class Initialized
INFO - 2020-02-02 07:55:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:55:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:55:15 --> Utf8 Class Initialized
INFO - 2020-02-02 07:55:15 --> URI Class Initialized
DEBUG - 2020-02-02 07:55:15 --> No URI present. Default controller set.
INFO - 2020-02-02 07:55:15 --> Router Class Initialized
INFO - 2020-02-02 07:55:15 --> Output Class Initialized
INFO - 2020-02-02 07:55:15 --> Security Class Initialized
DEBUG - 2020-02-02 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:55:15 --> Input Class Initialized
INFO - 2020-02-02 07:55:15 --> Language Class Initialized
INFO - 2020-02-02 07:55:15 --> Language Class Initialized
INFO - 2020-02-02 07:55:15 --> Config Class Initialized
INFO - 2020-02-02 07:55:15 --> Loader Class Initialized
INFO - 2020-02-02 07:55:15 --> Helper loaded: url_helper
INFO - 2020-02-02 07:55:15 --> Helper loaded: file_helper
INFO - 2020-02-02 07:55:15 --> Helper loaded: form_helper
INFO - 2020-02-02 07:55:15 --> Helper loaded: my_helper
INFO - 2020-02-02 07:55:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:55:15 --> Controller Class Initialized
ERROR - 2020-02-02 07:55:15 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
ERROR - 2020-02-02 07:55:15 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 21
ERROR - 2020-02-02 07:55:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:55:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:55:43 --> Config Class Initialized
INFO - 2020-02-02 07:55:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:55:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:55:43 --> Utf8 Class Initialized
INFO - 2020-02-02 07:55:43 --> URI Class Initialized
DEBUG - 2020-02-02 07:55:43 --> No URI present. Default controller set.
INFO - 2020-02-02 07:55:43 --> Router Class Initialized
INFO - 2020-02-02 07:55:43 --> Output Class Initialized
INFO - 2020-02-02 07:55:43 --> Security Class Initialized
DEBUG - 2020-02-02 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:55:43 --> Input Class Initialized
INFO - 2020-02-02 07:55:43 --> Language Class Initialized
INFO - 2020-02-02 07:55:43 --> Language Class Initialized
INFO - 2020-02-02 07:55:43 --> Config Class Initialized
INFO - 2020-02-02 07:55:43 --> Loader Class Initialized
INFO - 2020-02-02 07:55:43 --> Helper loaded: url_helper
INFO - 2020-02-02 07:55:43 --> Helper loaded: file_helper
INFO - 2020-02-02 07:55:43 --> Helper loaded: form_helper
INFO - 2020-02-02 07:55:43 --> Helper loaded: my_helper
INFO - 2020-02-02 07:55:43 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:55:43 --> Controller Class Initialized
ERROR - 2020-02-02 07:55:43 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
DEBUG - 2020-02-02 07:55:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:55:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:55:43 --> Final output sent to browser
DEBUG - 2020-02-02 07:55:44 --> Total execution time: 0.5120
INFO - 2020-02-02 07:56:04 --> Config Class Initialized
INFO - 2020-02-02 07:56:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:56:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:56:04 --> Utf8 Class Initialized
INFO - 2020-02-02 07:56:04 --> URI Class Initialized
DEBUG - 2020-02-02 07:56:04 --> No URI present. Default controller set.
INFO - 2020-02-02 07:56:04 --> Router Class Initialized
INFO - 2020-02-02 07:56:04 --> Output Class Initialized
INFO - 2020-02-02 07:56:04 --> Security Class Initialized
DEBUG - 2020-02-02 07:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:56:04 --> Input Class Initialized
INFO - 2020-02-02 07:56:04 --> Language Class Initialized
INFO - 2020-02-02 07:56:04 --> Language Class Initialized
INFO - 2020-02-02 07:56:04 --> Config Class Initialized
INFO - 2020-02-02 07:56:04 --> Loader Class Initialized
INFO - 2020-02-02 07:56:04 --> Helper loaded: url_helper
INFO - 2020-02-02 07:56:04 --> Helper loaded: file_helper
INFO - 2020-02-02 07:56:04 --> Helper loaded: form_helper
INFO - 2020-02-02 07:56:04 --> Helper loaded: my_helper
INFO - 2020-02-02 07:56:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:56:04 --> Controller Class Initialized
ERROR - 2020-02-02 07:56:04 --> Severity: Notice --> Undefined variable: id E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 18
DEBUG - 2020-02-02 07:56:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:56:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:56:04 --> Final output sent to browser
DEBUG - 2020-02-02 07:56:04 --> Total execution time: 0.4248
INFO - 2020-02-02 07:57:57 --> Config Class Initialized
INFO - 2020-02-02 07:57:57 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:57:57 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:57:57 --> Utf8 Class Initialized
INFO - 2020-02-02 07:57:57 --> URI Class Initialized
DEBUG - 2020-02-02 07:57:57 --> No URI present. Default controller set.
INFO - 2020-02-02 07:57:57 --> Router Class Initialized
INFO - 2020-02-02 07:57:57 --> Output Class Initialized
INFO - 2020-02-02 07:57:57 --> Security Class Initialized
DEBUG - 2020-02-02 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:57:58 --> Input Class Initialized
INFO - 2020-02-02 07:57:58 --> Language Class Initialized
ERROR - 2020-02-02 07:57:58 --> Severity: Parsing Error --> syntax error, unexpected ']' E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 37
INFO - 2020-02-02 07:58:08 --> Config Class Initialized
INFO - 2020-02-02 07:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:58:08 --> Utf8 Class Initialized
INFO - 2020-02-02 07:58:08 --> URI Class Initialized
DEBUG - 2020-02-02 07:58:08 --> No URI present. Default controller set.
INFO - 2020-02-02 07:58:08 --> Router Class Initialized
INFO - 2020-02-02 07:58:08 --> Output Class Initialized
INFO - 2020-02-02 07:58:08 --> Security Class Initialized
DEBUG - 2020-02-02 07:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:58:08 --> Input Class Initialized
INFO - 2020-02-02 07:58:08 --> Language Class Initialized
INFO - 2020-02-02 07:58:08 --> Language Class Initialized
INFO - 2020-02-02 07:58:08 --> Config Class Initialized
INFO - 2020-02-02 07:58:08 --> Loader Class Initialized
INFO - 2020-02-02 07:58:08 --> Helper loaded: url_helper
INFO - 2020-02-02 07:58:08 --> Helper loaded: file_helper
INFO - 2020-02-02 07:58:08 --> Helper loaded: form_helper
INFO - 2020-02-02 07:58:08 --> Helper loaded: my_helper
INFO - 2020-02-02 07:58:08 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:58:08 --> Controller Class Initialized
ERROR - 2020-02-02 07:58:08 --> Severity: Notice --> Undefined variable: id_guru E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 46
ERROR - 2020-02-02 07:58:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM t_guru_mapel where id_guru = 
INFO - 2020-02-02 07:58:08 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 07:58:20 --> Config Class Initialized
INFO - 2020-02-02 07:58:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:58:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:58:20 --> Utf8 Class Initialized
INFO - 2020-02-02 07:58:20 --> URI Class Initialized
DEBUG - 2020-02-02 07:58:20 --> No URI present. Default controller set.
INFO - 2020-02-02 07:58:20 --> Router Class Initialized
INFO - 2020-02-02 07:58:20 --> Output Class Initialized
INFO - 2020-02-02 07:58:20 --> Security Class Initialized
DEBUG - 2020-02-02 07:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:58:20 --> Input Class Initialized
INFO - 2020-02-02 07:58:20 --> Language Class Initialized
INFO - 2020-02-02 07:58:20 --> Language Class Initialized
INFO - 2020-02-02 07:58:20 --> Config Class Initialized
INFO - 2020-02-02 07:58:20 --> Loader Class Initialized
INFO - 2020-02-02 07:58:20 --> Helper loaded: url_helper
INFO - 2020-02-02 07:58:20 --> Helper loaded: file_helper
INFO - 2020-02-02 07:58:20 --> Helper loaded: form_helper
INFO - 2020-02-02 07:58:21 --> Helper loaded: my_helper
INFO - 2020-02-02 07:58:21 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:58:21 --> Controller Class Initialized
ERROR - 2020-02-02 07:58:21 --> Severity: Notice --> Undefined variable: id_guru E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 46
DEBUG - 2020-02-02 07:58:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:58:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:58:21 --> Final output sent to browser
DEBUG - 2020-02-02 07:58:21 --> Total execution time: 0.4280
INFO - 2020-02-02 07:59:14 --> Config Class Initialized
INFO - 2020-02-02 07:59:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 07:59:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 07:59:14 --> Utf8 Class Initialized
INFO - 2020-02-02 07:59:14 --> URI Class Initialized
DEBUG - 2020-02-02 07:59:14 --> No URI present. Default controller set.
INFO - 2020-02-02 07:59:14 --> Router Class Initialized
INFO - 2020-02-02 07:59:14 --> Output Class Initialized
INFO - 2020-02-02 07:59:14 --> Security Class Initialized
DEBUG - 2020-02-02 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 07:59:14 --> Input Class Initialized
INFO - 2020-02-02 07:59:14 --> Language Class Initialized
INFO - 2020-02-02 07:59:14 --> Language Class Initialized
INFO - 2020-02-02 07:59:14 --> Config Class Initialized
INFO - 2020-02-02 07:59:14 --> Loader Class Initialized
INFO - 2020-02-02 07:59:14 --> Helper loaded: url_helper
INFO - 2020-02-02 07:59:14 --> Helper loaded: file_helper
INFO - 2020-02-02 07:59:14 --> Helper loaded: form_helper
INFO - 2020-02-02 07:59:14 --> Helper loaded: my_helper
INFO - 2020-02-02 07:59:14 --> Database Driver Class Initialized
DEBUG - 2020-02-02 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 07:59:14 --> Controller Class Initialized
ERROR - 2020-02-02 07:59:14 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 07:59:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 07:59:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 07:59:15 --> Final output sent to browser
DEBUG - 2020-02-02 07:59:15 --> Total execution time: 0.4348
INFO - 2020-02-02 08:01:22 --> Config Class Initialized
INFO - 2020-02-02 08:01:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:01:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:01:22 --> Utf8 Class Initialized
INFO - 2020-02-02 08:01:22 --> URI Class Initialized
DEBUG - 2020-02-02 08:01:22 --> No URI present. Default controller set.
INFO - 2020-02-02 08:01:22 --> Router Class Initialized
INFO - 2020-02-02 08:01:22 --> Output Class Initialized
INFO - 2020-02-02 08:01:22 --> Security Class Initialized
DEBUG - 2020-02-02 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:01:22 --> Input Class Initialized
INFO - 2020-02-02 08:01:22 --> Language Class Initialized
INFO - 2020-02-02 08:01:22 --> Language Class Initialized
INFO - 2020-02-02 08:01:22 --> Config Class Initialized
INFO - 2020-02-02 08:01:22 --> Loader Class Initialized
INFO - 2020-02-02 08:01:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:01:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:01:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:01:22 --> Helper loaded: my_helper
INFO - 2020-02-02 08:01:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:01:22 --> Controller Class Initialized
ERROR - 2020-02-02 08:01:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''20182' at line 3 - Invalid query: SELECT 
                                         count(*) FROM t_guru_mapel 
                                         where id_guru = '8' and tasm = '20182 
INFO - 2020-02-02 08:01:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 08:01:37 --> Config Class Initialized
INFO - 2020-02-02 08:01:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:01:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:01:37 --> Utf8 Class Initialized
INFO - 2020-02-02 08:01:37 --> URI Class Initialized
DEBUG - 2020-02-02 08:01:37 --> No URI present. Default controller set.
INFO - 2020-02-02 08:01:37 --> Router Class Initialized
INFO - 2020-02-02 08:01:37 --> Output Class Initialized
INFO - 2020-02-02 08:01:37 --> Security Class Initialized
DEBUG - 2020-02-02 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:01:37 --> Input Class Initialized
INFO - 2020-02-02 08:01:37 --> Language Class Initialized
INFO - 2020-02-02 08:01:37 --> Language Class Initialized
INFO - 2020-02-02 08:01:37 --> Config Class Initialized
INFO - 2020-02-02 08:01:37 --> Loader Class Initialized
INFO - 2020-02-02 08:01:37 --> Helper loaded: url_helper
INFO - 2020-02-02 08:01:37 --> Helper loaded: file_helper
INFO - 2020-02-02 08:01:37 --> Helper loaded: form_helper
INFO - 2020-02-02 08:01:37 --> Helper loaded: my_helper
INFO - 2020-02-02 08:01:37 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:01:38 --> Controller Class Initialized
ERROR - 2020-02-02 08:01:38 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:01:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:01:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:01:38 --> Final output sent to browser
DEBUG - 2020-02-02 08:01:38 --> Total execution time: 0.4252
INFO - 2020-02-02 08:02:13 --> Config Class Initialized
INFO - 2020-02-02 08:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:02:13 --> Utf8 Class Initialized
INFO - 2020-02-02 08:02:13 --> URI Class Initialized
DEBUG - 2020-02-02 08:02:13 --> No URI present. Default controller set.
INFO - 2020-02-02 08:02:13 --> Router Class Initialized
INFO - 2020-02-02 08:02:13 --> Output Class Initialized
INFO - 2020-02-02 08:02:13 --> Security Class Initialized
DEBUG - 2020-02-02 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:02:13 --> Input Class Initialized
INFO - 2020-02-02 08:02:13 --> Language Class Initialized
INFO - 2020-02-02 08:02:13 --> Language Class Initialized
INFO - 2020-02-02 08:02:13 --> Config Class Initialized
INFO - 2020-02-02 08:02:13 --> Loader Class Initialized
INFO - 2020-02-02 08:02:13 --> Helper loaded: url_helper
INFO - 2020-02-02 08:02:13 --> Helper loaded: file_helper
INFO - 2020-02-02 08:02:13 --> Helper loaded: form_helper
INFO - 2020-02-02 08:02:13 --> Helper loaded: my_helper
INFO - 2020-02-02 08:02:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:02:13 --> Controller Class Initialized
ERROR - 2020-02-02 08:02:13 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:02:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:02:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:02:13 --> Final output sent to browser
DEBUG - 2020-02-02 08:02:13 --> Total execution time: 0.4396
INFO - 2020-02-02 08:02:48 --> Config Class Initialized
INFO - 2020-02-02 08:02:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:02:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:02:48 --> Utf8 Class Initialized
INFO - 2020-02-02 08:02:48 --> URI Class Initialized
DEBUG - 2020-02-02 08:02:48 --> No URI present. Default controller set.
INFO - 2020-02-02 08:02:48 --> Router Class Initialized
INFO - 2020-02-02 08:02:48 --> Output Class Initialized
INFO - 2020-02-02 08:02:48 --> Security Class Initialized
DEBUG - 2020-02-02 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:02:48 --> Input Class Initialized
INFO - 2020-02-02 08:02:48 --> Language Class Initialized
INFO - 2020-02-02 08:02:48 --> Language Class Initialized
INFO - 2020-02-02 08:02:48 --> Config Class Initialized
INFO - 2020-02-02 08:02:48 --> Loader Class Initialized
INFO - 2020-02-02 08:02:48 --> Helper loaded: url_helper
INFO - 2020-02-02 08:02:48 --> Helper loaded: file_helper
INFO - 2020-02-02 08:02:48 --> Helper loaded: form_helper
INFO - 2020-02-02 08:02:49 --> Helper loaded: my_helper
INFO - 2020-02-02 08:02:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:02:49 --> Controller Class Initialized
ERROR - 2020-02-02 08:02:49 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 51
ERROR - 2020-02-02 08:02:49 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:02:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:02:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:02:49 --> Final output sent to browser
DEBUG - 2020-02-02 08:02:49 --> Total execution time: 0.4560
INFO - 2020-02-02 08:03:15 --> Config Class Initialized
INFO - 2020-02-02 08:03:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:03:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:03:15 --> Utf8 Class Initialized
INFO - 2020-02-02 08:03:15 --> URI Class Initialized
DEBUG - 2020-02-02 08:03:15 --> No URI present. Default controller set.
INFO - 2020-02-02 08:03:15 --> Router Class Initialized
INFO - 2020-02-02 08:03:15 --> Output Class Initialized
INFO - 2020-02-02 08:03:15 --> Security Class Initialized
DEBUG - 2020-02-02 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:03:15 --> Input Class Initialized
INFO - 2020-02-02 08:03:15 --> Language Class Initialized
INFO - 2020-02-02 08:03:15 --> Language Class Initialized
INFO - 2020-02-02 08:03:15 --> Config Class Initialized
INFO - 2020-02-02 08:03:15 --> Loader Class Initialized
INFO - 2020-02-02 08:03:15 --> Helper loaded: url_helper
INFO - 2020-02-02 08:03:15 --> Helper loaded: file_helper
INFO - 2020-02-02 08:03:15 --> Helper loaded: form_helper
INFO - 2020-02-02 08:03:15 --> Helper loaded: my_helper
INFO - 2020-02-02 08:03:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:03:15 --> Controller Class Initialized
ERROR - 2020-02-02 08:03:15 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 51
ERROR - 2020-02-02 08:03:15 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:03:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:03:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:03:15 --> Final output sent to browser
DEBUG - 2020-02-02 08:03:15 --> Total execution time: 0.4455
INFO - 2020-02-02 08:03:41 --> Config Class Initialized
INFO - 2020-02-02 08:03:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:03:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:03:42 --> Utf8 Class Initialized
INFO - 2020-02-02 08:03:42 --> URI Class Initialized
DEBUG - 2020-02-02 08:03:42 --> No URI present. Default controller set.
INFO - 2020-02-02 08:03:42 --> Router Class Initialized
INFO - 2020-02-02 08:03:42 --> Output Class Initialized
INFO - 2020-02-02 08:03:42 --> Security Class Initialized
DEBUG - 2020-02-02 08:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:03:42 --> Input Class Initialized
INFO - 2020-02-02 08:03:42 --> Language Class Initialized
INFO - 2020-02-02 08:03:42 --> Language Class Initialized
INFO - 2020-02-02 08:03:42 --> Config Class Initialized
INFO - 2020-02-02 08:03:42 --> Loader Class Initialized
INFO - 2020-02-02 08:03:42 --> Helper loaded: url_helper
INFO - 2020-02-02 08:03:42 --> Helper loaded: file_helper
INFO - 2020-02-02 08:03:42 --> Helper loaded: form_helper
INFO - 2020-02-02 08:03:42 --> Helper loaded: my_helper
INFO - 2020-02-02 08:03:42 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:03:42 --> Controller Class Initialized
ERROR - 2020-02-02 08:03:42 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 51
ERROR - 2020-02-02 08:03:42 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:03:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:03:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:03:42 --> Final output sent to browser
DEBUG - 2020-02-02 08:03:42 --> Total execution time: 0.4528
INFO - 2020-02-02 08:04:09 --> Config Class Initialized
INFO - 2020-02-02 08:04:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:04:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:04:09 --> Utf8 Class Initialized
INFO - 2020-02-02 08:04:09 --> URI Class Initialized
DEBUG - 2020-02-02 08:04:09 --> No URI present. Default controller set.
INFO - 2020-02-02 08:04:09 --> Router Class Initialized
INFO - 2020-02-02 08:04:09 --> Output Class Initialized
INFO - 2020-02-02 08:04:09 --> Security Class Initialized
DEBUG - 2020-02-02 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:04:10 --> Input Class Initialized
INFO - 2020-02-02 08:04:10 --> Language Class Initialized
INFO - 2020-02-02 08:04:10 --> Language Class Initialized
INFO - 2020-02-02 08:04:10 --> Config Class Initialized
INFO - 2020-02-02 08:04:10 --> Loader Class Initialized
INFO - 2020-02-02 08:04:10 --> Helper loaded: url_helper
INFO - 2020-02-02 08:04:10 --> Helper loaded: file_helper
INFO - 2020-02-02 08:04:10 --> Helper loaded: form_helper
INFO - 2020-02-02 08:04:10 --> Helper loaded: my_helper
INFO - 2020-02-02 08:04:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:04:10 --> Controller Class Initialized
ERROR - 2020-02-02 08:04:10 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 54
ERROR - 2020-02-02 08:04:10 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 27
DEBUG - 2020-02-02 08:04:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:04:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:04:10 --> Final output sent to browser
DEBUG - 2020-02-02 08:04:10 --> Total execution time: 0.4592
INFO - 2020-02-02 08:04:55 --> Config Class Initialized
INFO - 2020-02-02 08:04:55 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:04:55 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:04:55 --> Utf8 Class Initialized
INFO - 2020-02-02 08:04:55 --> URI Class Initialized
DEBUG - 2020-02-02 08:04:55 --> No URI present. Default controller set.
INFO - 2020-02-02 08:04:55 --> Router Class Initialized
INFO - 2020-02-02 08:04:55 --> Output Class Initialized
INFO - 2020-02-02 08:04:55 --> Security Class Initialized
DEBUG - 2020-02-02 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:04:56 --> Input Class Initialized
INFO - 2020-02-02 08:04:56 --> Language Class Initialized
INFO - 2020-02-02 08:04:56 --> Language Class Initialized
INFO - 2020-02-02 08:04:56 --> Config Class Initialized
INFO - 2020-02-02 08:04:56 --> Loader Class Initialized
INFO - 2020-02-02 08:04:56 --> Helper loaded: url_helper
INFO - 2020-02-02 08:04:56 --> Helper loaded: file_helper
INFO - 2020-02-02 08:04:56 --> Helper loaded: form_helper
INFO - 2020-02-02 08:04:56 --> Helper loaded: my_helper
INFO - 2020-02-02 08:04:56 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:04:56 --> Controller Class Initialized
ERROR - 2020-02-02 08:04:56 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 52
DEBUG - 2020-02-02 08:04:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:04:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:04:56 --> Final output sent to browser
DEBUG - 2020-02-02 08:04:56 --> Total execution time: 0.4498
INFO - 2020-02-02 08:05:12 --> Config Class Initialized
INFO - 2020-02-02 08:05:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:05:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:05:13 --> Utf8 Class Initialized
INFO - 2020-02-02 08:05:13 --> URI Class Initialized
DEBUG - 2020-02-02 08:05:13 --> No URI present. Default controller set.
INFO - 2020-02-02 08:05:13 --> Router Class Initialized
INFO - 2020-02-02 08:05:13 --> Output Class Initialized
INFO - 2020-02-02 08:05:13 --> Security Class Initialized
DEBUG - 2020-02-02 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:05:13 --> Input Class Initialized
INFO - 2020-02-02 08:05:13 --> Language Class Initialized
INFO - 2020-02-02 08:05:13 --> Language Class Initialized
INFO - 2020-02-02 08:05:13 --> Config Class Initialized
INFO - 2020-02-02 08:05:13 --> Loader Class Initialized
INFO - 2020-02-02 08:05:13 --> Helper loaded: url_helper
INFO - 2020-02-02 08:05:13 --> Helper loaded: file_helper
INFO - 2020-02-02 08:05:13 --> Helper loaded: form_helper
INFO - 2020-02-02 08:05:13 --> Helper loaded: my_helper
INFO - 2020-02-02 08:05:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:05:13 --> Controller Class Initialized
DEBUG - 2020-02-02 08:05:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:05:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:05:13 --> Final output sent to browser
DEBUG - 2020-02-02 08:05:13 --> Total execution time: 0.4211
INFO - 2020-02-02 08:05:30 --> Config Class Initialized
INFO - 2020-02-02 08:05:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:05:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:05:30 --> Utf8 Class Initialized
INFO - 2020-02-02 08:05:30 --> URI Class Initialized
DEBUG - 2020-02-02 08:05:30 --> No URI present. Default controller set.
INFO - 2020-02-02 08:05:30 --> Router Class Initialized
INFO - 2020-02-02 08:05:30 --> Output Class Initialized
INFO - 2020-02-02 08:05:30 --> Security Class Initialized
DEBUG - 2020-02-02 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:05:30 --> Input Class Initialized
INFO - 2020-02-02 08:05:30 --> Language Class Initialized
INFO - 2020-02-02 08:05:30 --> Language Class Initialized
INFO - 2020-02-02 08:05:30 --> Config Class Initialized
INFO - 2020-02-02 08:05:30 --> Loader Class Initialized
INFO - 2020-02-02 08:05:30 --> Helper loaded: url_helper
INFO - 2020-02-02 08:05:31 --> Helper loaded: file_helper
INFO - 2020-02-02 08:05:31 --> Helper loaded: form_helper
INFO - 2020-02-02 08:05:31 --> Helper loaded: my_helper
INFO - 2020-02-02 08:05:31 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:05:31 --> Controller Class Initialized
DEBUG - 2020-02-02 08:05:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:05:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:05:31 --> Final output sent to browser
DEBUG - 2020-02-02 08:05:31 --> Total execution time: 0.4124
INFO - 2020-02-02 08:05:48 --> Config Class Initialized
INFO - 2020-02-02 08:05:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:05:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:05:48 --> Utf8 Class Initialized
INFO - 2020-02-02 08:05:48 --> URI Class Initialized
DEBUG - 2020-02-02 08:05:48 --> No URI present. Default controller set.
INFO - 2020-02-02 08:05:48 --> Router Class Initialized
INFO - 2020-02-02 08:05:48 --> Output Class Initialized
INFO - 2020-02-02 08:05:48 --> Security Class Initialized
DEBUG - 2020-02-02 08:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:05:48 --> Input Class Initialized
INFO - 2020-02-02 08:05:48 --> Language Class Initialized
INFO - 2020-02-02 08:05:48 --> Language Class Initialized
INFO - 2020-02-02 08:05:48 --> Config Class Initialized
INFO - 2020-02-02 08:05:48 --> Loader Class Initialized
INFO - 2020-02-02 08:05:48 --> Helper loaded: url_helper
INFO - 2020-02-02 08:05:48 --> Helper loaded: file_helper
INFO - 2020-02-02 08:05:48 --> Helper loaded: form_helper
INFO - 2020-02-02 08:05:48 --> Helper loaded: my_helper
INFO - 2020-02-02 08:05:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:05:48 --> Controller Class Initialized
DEBUG - 2020-02-02 08:05:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:05:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:05:49 --> Final output sent to browser
DEBUG - 2020-02-02 08:05:49 --> Total execution time: 0.4346
INFO - 2020-02-02 08:05:56 --> Config Class Initialized
INFO - 2020-02-02 08:05:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:05:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:05:56 --> Utf8 Class Initialized
INFO - 2020-02-02 08:05:56 --> URI Class Initialized
DEBUG - 2020-02-02 08:05:56 --> No URI present. Default controller set.
INFO - 2020-02-02 08:05:57 --> Router Class Initialized
INFO - 2020-02-02 08:05:57 --> Output Class Initialized
INFO - 2020-02-02 08:05:57 --> Security Class Initialized
DEBUG - 2020-02-02 08:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:05:57 --> Input Class Initialized
INFO - 2020-02-02 08:05:57 --> Language Class Initialized
INFO - 2020-02-02 08:05:57 --> Language Class Initialized
INFO - 2020-02-02 08:05:57 --> Config Class Initialized
INFO - 2020-02-02 08:05:57 --> Loader Class Initialized
INFO - 2020-02-02 08:05:57 --> Helper loaded: url_helper
INFO - 2020-02-02 08:05:57 --> Helper loaded: file_helper
INFO - 2020-02-02 08:05:57 --> Helper loaded: form_helper
INFO - 2020-02-02 08:05:57 --> Helper loaded: my_helper
INFO - 2020-02-02 08:05:57 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:05:57 --> Controller Class Initialized
DEBUG - 2020-02-02 08:05:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:05:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:05:57 --> Final output sent to browser
DEBUG - 2020-02-02 08:05:57 --> Total execution time: 0.4262
INFO - 2020-02-02 08:06:52 --> Config Class Initialized
INFO - 2020-02-02 08:06:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:06:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:06:52 --> Utf8 Class Initialized
INFO - 2020-02-02 08:06:52 --> URI Class Initialized
DEBUG - 2020-02-02 08:06:52 --> No URI present. Default controller set.
INFO - 2020-02-02 08:06:52 --> Router Class Initialized
INFO - 2020-02-02 08:06:52 --> Output Class Initialized
INFO - 2020-02-02 08:06:52 --> Security Class Initialized
DEBUG - 2020-02-02 08:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:06:52 --> Input Class Initialized
INFO - 2020-02-02 08:06:52 --> Language Class Initialized
INFO - 2020-02-02 08:06:52 --> Language Class Initialized
INFO - 2020-02-02 08:06:52 --> Config Class Initialized
INFO - 2020-02-02 08:06:52 --> Loader Class Initialized
INFO - 2020-02-02 08:06:52 --> Helper loaded: url_helper
INFO - 2020-02-02 08:06:52 --> Helper loaded: file_helper
INFO - 2020-02-02 08:06:52 --> Helper loaded: form_helper
INFO - 2020-02-02 08:06:52 --> Helper loaded: my_helper
INFO - 2020-02-02 08:06:52 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:06:52 --> Controller Class Initialized
ERROR - 2020-02-02 08:06:52 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 36
DEBUG - 2020-02-02 08:06:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:06:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:06:52 --> Final output sent to browser
DEBUG - 2020-02-02 08:06:52 --> Total execution time: 0.4692
INFO - 2020-02-02 08:06:58 --> Config Class Initialized
INFO - 2020-02-02 08:06:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:06:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:06:58 --> Utf8 Class Initialized
INFO - 2020-02-02 08:06:58 --> URI Class Initialized
DEBUG - 2020-02-02 08:06:58 --> No URI present. Default controller set.
INFO - 2020-02-02 08:06:58 --> Router Class Initialized
INFO - 2020-02-02 08:06:58 --> Output Class Initialized
INFO - 2020-02-02 08:06:58 --> Security Class Initialized
DEBUG - 2020-02-02 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:06:58 --> Input Class Initialized
INFO - 2020-02-02 08:06:58 --> Language Class Initialized
INFO - 2020-02-02 08:06:58 --> Language Class Initialized
INFO - 2020-02-02 08:06:58 --> Config Class Initialized
INFO - 2020-02-02 08:06:58 --> Loader Class Initialized
INFO - 2020-02-02 08:06:58 --> Helper loaded: url_helper
INFO - 2020-02-02 08:06:58 --> Helper loaded: file_helper
INFO - 2020-02-02 08:06:58 --> Helper loaded: form_helper
INFO - 2020-02-02 08:06:58 --> Helper loaded: my_helper
INFO - 2020-02-02 08:06:58 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:06:58 --> Controller Class Initialized
ERROR - 2020-02-02 08:06:58 --> Severity: Notice --> Undefined index: P E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 36
DEBUG - 2020-02-02 08:06:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:06:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:06:58 --> Final output sent to browser
DEBUG - 2020-02-02 08:06:58 --> Total execution time: 0.4493
INFO - 2020-02-02 08:07:04 --> Config Class Initialized
INFO - 2020-02-02 08:07:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:07:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:07:04 --> Utf8 Class Initialized
INFO - 2020-02-02 08:07:04 --> URI Class Initialized
DEBUG - 2020-02-02 08:07:04 --> No URI present. Default controller set.
INFO - 2020-02-02 08:07:04 --> Router Class Initialized
INFO - 2020-02-02 08:07:04 --> Output Class Initialized
INFO - 2020-02-02 08:07:04 --> Security Class Initialized
DEBUG - 2020-02-02 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:07:04 --> Input Class Initialized
INFO - 2020-02-02 08:07:04 --> Language Class Initialized
INFO - 2020-02-02 08:07:04 --> Language Class Initialized
INFO - 2020-02-02 08:07:04 --> Config Class Initialized
INFO - 2020-02-02 08:07:04 --> Loader Class Initialized
INFO - 2020-02-02 08:07:04 --> Helper loaded: url_helper
INFO - 2020-02-02 08:07:04 --> Helper loaded: file_helper
INFO - 2020-02-02 08:07:04 --> Helper loaded: form_helper
INFO - 2020-02-02 08:07:04 --> Helper loaded: my_helper
INFO - 2020-02-02 08:07:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:07:04 --> Controller Class Initialized
ERROR - 2020-02-02 08:07:04 --> Severity: Notice --> Undefined index: L E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 36
DEBUG - 2020-02-02 08:07:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:07:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:07:04 --> Final output sent to browser
DEBUG - 2020-02-02 08:07:04 --> Total execution time: 0.4576
INFO - 2020-02-02 08:07:28 --> Config Class Initialized
INFO - 2020-02-02 08:07:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:07:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:07:29 --> Utf8 Class Initialized
INFO - 2020-02-02 08:07:29 --> URI Class Initialized
DEBUG - 2020-02-02 08:07:29 --> No URI present. Default controller set.
INFO - 2020-02-02 08:07:29 --> Router Class Initialized
INFO - 2020-02-02 08:07:29 --> Output Class Initialized
INFO - 2020-02-02 08:07:29 --> Security Class Initialized
DEBUG - 2020-02-02 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:07:29 --> Input Class Initialized
INFO - 2020-02-02 08:07:29 --> Language Class Initialized
INFO - 2020-02-02 08:07:29 --> Language Class Initialized
INFO - 2020-02-02 08:07:29 --> Config Class Initialized
INFO - 2020-02-02 08:07:29 --> Loader Class Initialized
INFO - 2020-02-02 08:07:29 --> Helper loaded: url_helper
INFO - 2020-02-02 08:07:29 --> Helper loaded: file_helper
INFO - 2020-02-02 08:07:29 --> Helper loaded: form_helper
INFO - 2020-02-02 08:07:29 --> Helper loaded: my_helper
INFO - 2020-02-02 08:07:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:07:29 --> Controller Class Initialized
ERROR - 2020-02-02 08:07:29 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 45
ERROR - 2020-02-02 08:07:29 --> Severity: Notice --> Undefined index: L E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 36
DEBUG - 2020-02-02 08:07:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:07:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:07:29 --> Final output sent to browser
DEBUG - 2020-02-02 08:07:29 --> Total execution time: 0.4762
INFO - 2020-02-02 08:07:53 --> Config Class Initialized
INFO - 2020-02-02 08:07:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:07:53 --> Utf8 Class Initialized
INFO - 2020-02-02 08:07:53 --> URI Class Initialized
DEBUG - 2020-02-02 08:07:53 --> No URI present. Default controller set.
INFO - 2020-02-02 08:07:53 --> Router Class Initialized
INFO - 2020-02-02 08:07:53 --> Output Class Initialized
INFO - 2020-02-02 08:07:53 --> Security Class Initialized
DEBUG - 2020-02-02 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:07:53 --> Input Class Initialized
INFO - 2020-02-02 08:07:53 --> Language Class Initialized
INFO - 2020-02-02 08:07:53 --> Language Class Initialized
INFO - 2020-02-02 08:07:53 --> Config Class Initialized
INFO - 2020-02-02 08:07:53 --> Loader Class Initialized
INFO - 2020-02-02 08:07:53 --> Helper loaded: url_helper
INFO - 2020-02-02 08:07:53 --> Helper loaded: file_helper
INFO - 2020-02-02 08:07:53 --> Helper loaded: form_helper
INFO - 2020-02-02 08:07:53 --> Helper loaded: my_helper
INFO - 2020-02-02 08:07:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:07:53 --> Controller Class Initialized
ERROR - 2020-02-02 08:07:53 --> Severity: Notice --> Undefined index: L E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 36
DEBUG - 2020-02-02 08:07:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:07:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:07:53 --> Final output sent to browser
DEBUG - 2020-02-02 08:07:53 --> Total execution time: 0.4370
INFO - 2020-02-02 08:08:08 --> Config Class Initialized
INFO - 2020-02-02 08:08:08 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:08:08 --> Utf8 Class Initialized
INFO - 2020-02-02 08:08:08 --> URI Class Initialized
DEBUG - 2020-02-02 08:08:08 --> No URI present. Default controller set.
INFO - 2020-02-02 08:08:08 --> Router Class Initialized
INFO - 2020-02-02 08:08:08 --> Output Class Initialized
INFO - 2020-02-02 08:08:08 --> Security Class Initialized
DEBUG - 2020-02-02 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:08:09 --> Input Class Initialized
INFO - 2020-02-02 08:08:09 --> Language Class Initialized
INFO - 2020-02-02 08:08:09 --> Language Class Initialized
INFO - 2020-02-02 08:08:09 --> Config Class Initialized
INFO - 2020-02-02 08:08:09 --> Loader Class Initialized
INFO - 2020-02-02 08:08:09 --> Helper loaded: url_helper
INFO - 2020-02-02 08:08:09 --> Helper loaded: file_helper
INFO - 2020-02-02 08:08:09 --> Helper loaded: form_helper
INFO - 2020-02-02 08:08:09 --> Helper loaded: my_helper
INFO - 2020-02-02 08:08:09 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:08:09 --> Controller Class Initialized
DEBUG - 2020-02-02 08:08:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:08:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:08:09 --> Final output sent to browser
DEBUG - 2020-02-02 08:08:09 --> Total execution time: 0.4367
INFO - 2020-02-02 08:08:22 --> Config Class Initialized
INFO - 2020-02-02 08:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:08:22 --> Utf8 Class Initialized
INFO - 2020-02-02 08:08:22 --> URI Class Initialized
DEBUG - 2020-02-02 08:08:22 --> No URI present. Default controller set.
INFO - 2020-02-02 08:08:22 --> Router Class Initialized
INFO - 2020-02-02 08:08:22 --> Output Class Initialized
INFO - 2020-02-02 08:08:22 --> Security Class Initialized
DEBUG - 2020-02-02 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:08:22 --> Input Class Initialized
INFO - 2020-02-02 08:08:22 --> Language Class Initialized
INFO - 2020-02-02 08:08:22 --> Language Class Initialized
INFO - 2020-02-02 08:08:22 --> Config Class Initialized
INFO - 2020-02-02 08:08:22 --> Loader Class Initialized
INFO - 2020-02-02 08:08:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:08:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:08:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:08:22 --> Helper loaded: my_helper
INFO - 2020-02-02 08:08:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:08:22 --> Controller Class Initialized
DEBUG - 2020-02-02 08:08:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:08:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:08:22 --> Final output sent to browser
DEBUG - 2020-02-02 08:08:22 --> Total execution time: 0.4260
INFO - 2020-02-02 08:08:44 --> Config Class Initialized
INFO - 2020-02-02 08:08:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:08:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:08:44 --> Utf8 Class Initialized
INFO - 2020-02-02 08:08:45 --> URI Class Initialized
DEBUG - 2020-02-02 08:08:45 --> No URI present. Default controller set.
INFO - 2020-02-02 08:08:45 --> Router Class Initialized
INFO - 2020-02-02 08:08:45 --> Output Class Initialized
INFO - 2020-02-02 08:08:45 --> Security Class Initialized
DEBUG - 2020-02-02 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:08:45 --> Input Class Initialized
INFO - 2020-02-02 08:08:45 --> Language Class Initialized
INFO - 2020-02-02 08:08:45 --> Language Class Initialized
INFO - 2020-02-02 08:08:45 --> Config Class Initialized
INFO - 2020-02-02 08:08:45 --> Loader Class Initialized
INFO - 2020-02-02 08:08:45 --> Helper loaded: url_helper
INFO - 2020-02-02 08:08:45 --> Helper loaded: file_helper
INFO - 2020-02-02 08:08:45 --> Helper loaded: form_helper
INFO - 2020-02-02 08:08:45 --> Helper loaded: my_helper
INFO - 2020-02-02 08:08:45 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:08:45 --> Controller Class Initialized
DEBUG - 2020-02-02 08:08:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:08:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:08:45 --> Final output sent to browser
DEBUG - 2020-02-02 08:08:45 --> Total execution time: 0.4534
INFO - 2020-02-02 08:10:05 --> Config Class Initialized
INFO - 2020-02-02 08:10:05 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:10:05 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:10:05 --> Utf8 Class Initialized
INFO - 2020-02-02 08:10:05 --> URI Class Initialized
DEBUG - 2020-02-02 08:10:05 --> No URI present. Default controller set.
INFO - 2020-02-02 08:10:05 --> Router Class Initialized
INFO - 2020-02-02 08:10:05 --> Output Class Initialized
INFO - 2020-02-02 08:10:05 --> Security Class Initialized
DEBUG - 2020-02-02 08:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:10:05 --> Input Class Initialized
INFO - 2020-02-02 08:10:05 --> Language Class Initialized
INFO - 2020-02-02 08:10:05 --> Language Class Initialized
INFO - 2020-02-02 08:10:05 --> Config Class Initialized
INFO - 2020-02-02 08:10:05 --> Loader Class Initialized
INFO - 2020-02-02 08:10:05 --> Helper loaded: url_helper
INFO - 2020-02-02 08:10:06 --> Helper loaded: file_helper
INFO - 2020-02-02 08:10:06 --> Helper loaded: form_helper
INFO - 2020-02-02 08:10:06 --> Helper loaded: my_helper
INFO - 2020-02-02 08:10:06 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:10:06 --> Controller Class Initialized
DEBUG - 2020-02-02 08:10:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:10:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:10:06 --> Final output sent to browser
DEBUG - 2020-02-02 08:10:06 --> Total execution time: 0.4525
INFO - 2020-02-02 08:14:22 --> Config Class Initialized
INFO - 2020-02-02 08:14:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:14:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:14:22 --> Utf8 Class Initialized
INFO - 2020-02-02 08:14:22 --> URI Class Initialized
DEBUG - 2020-02-02 08:14:22 --> No URI present. Default controller set.
INFO - 2020-02-02 08:14:22 --> Router Class Initialized
INFO - 2020-02-02 08:14:22 --> Output Class Initialized
INFO - 2020-02-02 08:14:22 --> Security Class Initialized
DEBUG - 2020-02-02 08:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:14:22 --> Input Class Initialized
INFO - 2020-02-02 08:14:22 --> Language Class Initialized
INFO - 2020-02-02 08:14:22 --> Language Class Initialized
INFO - 2020-02-02 08:14:22 --> Config Class Initialized
INFO - 2020-02-02 08:14:22 --> Loader Class Initialized
INFO - 2020-02-02 08:14:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:14:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:14:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:14:22 --> Helper loaded: my_helper
INFO - 2020-02-02 08:14:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:14:22 --> Controller Class Initialized
ERROR - 2020-02-02 08:14:22 --> Severity: Notice --> Undefined index: tgl_raport E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 13
ERROR - 2020-02-02 08:14:22 --> Severity: Notice --> Undefined variable: tgl_raport E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home_guru.php 45
DEBUG - 2020-02-02 08:14:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:14:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:14:22 --> Final output sent to browser
DEBUG - 2020-02-02 08:14:22 --> Total execution time: 0.4671
INFO - 2020-02-02 08:14:34 --> Config Class Initialized
INFO - 2020-02-02 08:14:34 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:14:34 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:14:34 --> Utf8 Class Initialized
INFO - 2020-02-02 08:14:34 --> URI Class Initialized
DEBUG - 2020-02-02 08:14:34 --> No URI present. Default controller set.
INFO - 2020-02-02 08:14:34 --> Router Class Initialized
INFO - 2020-02-02 08:14:34 --> Output Class Initialized
INFO - 2020-02-02 08:14:34 --> Security Class Initialized
DEBUG - 2020-02-02 08:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:14:34 --> Input Class Initialized
INFO - 2020-02-02 08:14:35 --> Language Class Initialized
INFO - 2020-02-02 08:14:35 --> Language Class Initialized
INFO - 2020-02-02 08:14:35 --> Config Class Initialized
INFO - 2020-02-02 08:14:35 --> Loader Class Initialized
INFO - 2020-02-02 08:14:35 --> Helper loaded: url_helper
INFO - 2020-02-02 08:14:35 --> Helper loaded: file_helper
INFO - 2020-02-02 08:14:35 --> Helper loaded: form_helper
INFO - 2020-02-02 08:14:35 --> Helper loaded: my_helper
INFO - 2020-02-02 08:14:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:14:35 --> Controller Class Initialized
ERROR - 2020-02-02 08:14:35 --> Severity: Notice --> Undefined index: tgl_raport E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 13
DEBUG - 2020-02-02 08:14:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:14:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:14:35 --> Final output sent to browser
DEBUG - 2020-02-02 08:14:35 --> Total execution time: 0.4362
INFO - 2020-02-02 08:15:01 --> Config Class Initialized
INFO - 2020-02-02 08:15:01 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:15:01 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:15:02 --> Utf8 Class Initialized
INFO - 2020-02-02 08:15:02 --> URI Class Initialized
DEBUG - 2020-02-02 08:15:02 --> No URI present. Default controller set.
INFO - 2020-02-02 08:15:02 --> Router Class Initialized
INFO - 2020-02-02 08:15:02 --> Output Class Initialized
INFO - 2020-02-02 08:15:02 --> Security Class Initialized
DEBUG - 2020-02-02 08:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:15:02 --> Input Class Initialized
INFO - 2020-02-02 08:15:02 --> Language Class Initialized
INFO - 2020-02-02 08:15:02 --> Language Class Initialized
INFO - 2020-02-02 08:15:02 --> Config Class Initialized
INFO - 2020-02-02 08:15:02 --> Loader Class Initialized
INFO - 2020-02-02 08:15:02 --> Helper loaded: url_helper
INFO - 2020-02-02 08:15:02 --> Helper loaded: file_helper
INFO - 2020-02-02 08:15:02 --> Helper loaded: form_helper
INFO - 2020-02-02 08:15:02 --> Helper loaded: my_helper
INFO - 2020-02-02 08:15:02 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:15:02 --> Controller Class Initialized
ERROR - 2020-02-02 08:15:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM tahun WHERE aktif = 'Y'' at line 1 - Invalid query: SELECT * from FROM tahun WHERE aktif = 'Y'
INFO - 2020-02-02 08:15:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-02 08:15:10 --> Config Class Initialized
INFO - 2020-02-02 08:15:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:15:11 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:15:11 --> Utf8 Class Initialized
INFO - 2020-02-02 08:15:11 --> URI Class Initialized
DEBUG - 2020-02-02 08:15:11 --> No URI present. Default controller set.
INFO - 2020-02-02 08:15:11 --> Router Class Initialized
INFO - 2020-02-02 08:15:11 --> Output Class Initialized
INFO - 2020-02-02 08:15:11 --> Security Class Initialized
DEBUG - 2020-02-02 08:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:15:11 --> Input Class Initialized
INFO - 2020-02-02 08:15:11 --> Language Class Initialized
INFO - 2020-02-02 08:15:11 --> Language Class Initialized
INFO - 2020-02-02 08:15:11 --> Config Class Initialized
INFO - 2020-02-02 08:15:11 --> Loader Class Initialized
INFO - 2020-02-02 08:15:11 --> Helper loaded: url_helper
INFO - 2020-02-02 08:15:11 --> Helper loaded: file_helper
INFO - 2020-02-02 08:15:11 --> Helper loaded: form_helper
INFO - 2020-02-02 08:15:11 --> Helper loaded: my_helper
INFO - 2020-02-02 08:15:11 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:15:11 --> Controller Class Initialized
DEBUG - 2020-02-02 08:15:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:15:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:15:11 --> Final output sent to browser
DEBUG - 2020-02-02 08:15:11 --> Total execution time: 0.4514
INFO - 2020-02-02 08:15:22 --> Config Class Initialized
INFO - 2020-02-02 08:15:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:15:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:15:22 --> Utf8 Class Initialized
INFO - 2020-02-02 08:15:22 --> URI Class Initialized
DEBUG - 2020-02-02 08:15:22 --> No URI present. Default controller set.
INFO - 2020-02-02 08:15:22 --> Router Class Initialized
INFO - 2020-02-02 08:15:22 --> Output Class Initialized
INFO - 2020-02-02 08:15:22 --> Security Class Initialized
DEBUG - 2020-02-02 08:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:15:22 --> Input Class Initialized
INFO - 2020-02-02 08:15:22 --> Language Class Initialized
INFO - 2020-02-02 08:15:22 --> Language Class Initialized
INFO - 2020-02-02 08:15:22 --> Config Class Initialized
INFO - 2020-02-02 08:15:22 --> Loader Class Initialized
INFO - 2020-02-02 08:15:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:15:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:15:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:15:23 --> Helper loaded: my_helper
INFO - 2020-02-02 08:15:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:15:23 --> Controller Class Initialized
DEBUG - 2020-02-02 08:15:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:15:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:15:23 --> Final output sent to browser
DEBUG - 2020-02-02 08:15:23 --> Total execution time: 0.4458
INFO - 2020-02-02 08:16:02 --> Config Class Initialized
INFO - 2020-02-02 08:16:02 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:16:02 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:16:02 --> Utf8 Class Initialized
INFO - 2020-02-02 08:16:02 --> URI Class Initialized
DEBUG - 2020-02-02 08:16:02 --> No URI present. Default controller set.
INFO - 2020-02-02 08:16:02 --> Router Class Initialized
INFO - 2020-02-02 08:16:02 --> Output Class Initialized
INFO - 2020-02-02 08:16:02 --> Security Class Initialized
DEBUG - 2020-02-02 08:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:16:02 --> Input Class Initialized
INFO - 2020-02-02 08:16:02 --> Language Class Initialized
INFO - 2020-02-02 08:16:02 --> Language Class Initialized
INFO - 2020-02-02 08:16:02 --> Config Class Initialized
INFO - 2020-02-02 08:16:02 --> Loader Class Initialized
INFO - 2020-02-02 08:16:02 --> Helper loaded: url_helper
INFO - 2020-02-02 08:16:02 --> Helper loaded: file_helper
INFO - 2020-02-02 08:16:02 --> Helper loaded: form_helper
INFO - 2020-02-02 08:16:02 --> Helper loaded: my_helper
INFO - 2020-02-02 08:16:02 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:16:02 --> Controller Class Initialized
DEBUG - 2020-02-02 08:16:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:16:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:16:02 --> Final output sent to browser
DEBUG - 2020-02-02 08:16:03 --> Total execution time: 0.5597
INFO - 2020-02-02 08:17:04 --> Config Class Initialized
INFO - 2020-02-02 08:17:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:17:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:17:04 --> Utf8 Class Initialized
INFO - 2020-02-02 08:17:04 --> URI Class Initialized
DEBUG - 2020-02-02 08:17:04 --> No URI present. Default controller set.
INFO - 2020-02-02 08:17:04 --> Router Class Initialized
INFO - 2020-02-02 08:17:04 --> Output Class Initialized
INFO - 2020-02-02 08:17:04 --> Security Class Initialized
DEBUG - 2020-02-02 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:17:04 --> Input Class Initialized
INFO - 2020-02-02 08:17:04 --> Language Class Initialized
INFO - 2020-02-02 08:17:04 --> Language Class Initialized
INFO - 2020-02-02 08:17:04 --> Config Class Initialized
INFO - 2020-02-02 08:17:04 --> Loader Class Initialized
INFO - 2020-02-02 08:17:04 --> Helper loaded: url_helper
INFO - 2020-02-02 08:17:04 --> Helper loaded: file_helper
INFO - 2020-02-02 08:17:04 --> Helper loaded: form_helper
INFO - 2020-02-02 08:17:04 --> Helper loaded: my_helper
INFO - 2020-02-02 08:17:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:17:04 --> Controller Class Initialized
DEBUG - 2020-02-02 08:17:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:17:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:17:04 --> Final output sent to browser
DEBUG - 2020-02-02 08:17:04 --> Total execution time: 0.4877
INFO - 2020-02-02 08:17:28 --> Config Class Initialized
INFO - 2020-02-02 08:17:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:17:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:17:28 --> Utf8 Class Initialized
INFO - 2020-02-02 08:17:28 --> URI Class Initialized
DEBUG - 2020-02-02 08:17:28 --> No URI present. Default controller set.
INFO - 2020-02-02 08:17:28 --> Router Class Initialized
INFO - 2020-02-02 08:17:28 --> Output Class Initialized
INFO - 2020-02-02 08:17:28 --> Security Class Initialized
DEBUG - 2020-02-02 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:17:28 --> Input Class Initialized
INFO - 2020-02-02 08:17:28 --> Language Class Initialized
INFO - 2020-02-02 08:17:28 --> Language Class Initialized
INFO - 2020-02-02 08:17:28 --> Config Class Initialized
INFO - 2020-02-02 08:17:28 --> Loader Class Initialized
INFO - 2020-02-02 08:17:28 --> Helper loaded: url_helper
INFO - 2020-02-02 08:17:28 --> Helper loaded: file_helper
INFO - 2020-02-02 08:17:28 --> Helper loaded: form_helper
INFO - 2020-02-02 08:17:28 --> Helper loaded: my_helper
INFO - 2020-02-02 08:17:28 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:17:28 --> Controller Class Initialized
DEBUG - 2020-02-02 08:17:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:17:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:17:28 --> Final output sent to browser
DEBUG - 2020-02-02 08:17:28 --> Total execution time: 0.4508
INFO - 2020-02-02 08:18:03 --> Config Class Initialized
INFO - 2020-02-02 08:18:03 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:18:03 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:18:03 --> Utf8 Class Initialized
INFO - 2020-02-02 08:18:03 --> URI Class Initialized
DEBUG - 2020-02-02 08:18:03 --> No URI present. Default controller set.
INFO - 2020-02-02 08:18:03 --> Router Class Initialized
INFO - 2020-02-02 08:18:03 --> Output Class Initialized
INFO - 2020-02-02 08:18:03 --> Security Class Initialized
DEBUG - 2020-02-02 08:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:18:03 --> Input Class Initialized
INFO - 2020-02-02 08:18:03 --> Language Class Initialized
INFO - 2020-02-02 08:18:03 --> Language Class Initialized
INFO - 2020-02-02 08:18:03 --> Config Class Initialized
INFO - 2020-02-02 08:18:03 --> Loader Class Initialized
INFO - 2020-02-02 08:18:04 --> Helper loaded: url_helper
INFO - 2020-02-02 08:18:04 --> Helper loaded: file_helper
INFO - 2020-02-02 08:18:04 --> Helper loaded: form_helper
INFO - 2020-02-02 08:18:04 --> Helper loaded: my_helper
INFO - 2020-02-02 08:18:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:18:04 --> Controller Class Initialized
DEBUG - 2020-02-02 08:18:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:18:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:18:04 --> Final output sent to browser
DEBUG - 2020-02-02 08:18:04 --> Total execution time: 0.4410
INFO - 2020-02-02 08:18:28 --> Config Class Initialized
INFO - 2020-02-02 08:18:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:18:29 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:18:29 --> Utf8 Class Initialized
INFO - 2020-02-02 08:18:29 --> URI Class Initialized
DEBUG - 2020-02-02 08:18:29 --> No URI present. Default controller set.
INFO - 2020-02-02 08:18:29 --> Router Class Initialized
INFO - 2020-02-02 08:18:29 --> Output Class Initialized
INFO - 2020-02-02 08:18:29 --> Security Class Initialized
DEBUG - 2020-02-02 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:18:29 --> Input Class Initialized
INFO - 2020-02-02 08:18:29 --> Language Class Initialized
INFO - 2020-02-02 08:18:29 --> Language Class Initialized
INFO - 2020-02-02 08:18:29 --> Config Class Initialized
INFO - 2020-02-02 08:18:29 --> Loader Class Initialized
INFO - 2020-02-02 08:18:29 --> Helper loaded: url_helper
INFO - 2020-02-02 08:18:29 --> Helper loaded: file_helper
INFO - 2020-02-02 08:18:29 --> Helper loaded: form_helper
INFO - 2020-02-02 08:18:29 --> Helper loaded: my_helper
INFO - 2020-02-02 08:18:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:18:29 --> Controller Class Initialized
DEBUG - 2020-02-02 08:18:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:18:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:18:29 --> Final output sent to browser
DEBUG - 2020-02-02 08:18:29 --> Total execution time: 0.4691
INFO - 2020-02-02 08:18:32 --> Config Class Initialized
INFO - 2020-02-02 08:18:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:18:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:18:32 --> Utf8 Class Initialized
INFO - 2020-02-02 08:18:32 --> URI Class Initialized
DEBUG - 2020-02-02 08:18:32 --> No URI present. Default controller set.
INFO - 2020-02-02 08:18:32 --> Router Class Initialized
INFO - 2020-02-02 08:18:32 --> Output Class Initialized
INFO - 2020-02-02 08:18:32 --> Security Class Initialized
DEBUG - 2020-02-02 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:18:32 --> Input Class Initialized
INFO - 2020-02-02 08:18:32 --> Language Class Initialized
INFO - 2020-02-02 08:18:32 --> Language Class Initialized
INFO - 2020-02-02 08:18:32 --> Config Class Initialized
INFO - 2020-02-02 08:18:32 --> Loader Class Initialized
INFO - 2020-02-02 08:18:32 --> Helper loaded: url_helper
INFO - 2020-02-02 08:18:32 --> Helper loaded: file_helper
INFO - 2020-02-02 08:18:32 --> Helper loaded: form_helper
INFO - 2020-02-02 08:18:32 --> Helper loaded: my_helper
INFO - 2020-02-02 08:18:32 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:18:33 --> Controller Class Initialized
DEBUG - 2020-02-02 08:18:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:18:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:18:33 --> Final output sent to browser
DEBUG - 2020-02-02 08:18:33 --> Total execution time: 0.5216
INFO - 2020-02-02 08:19:53 --> Config Class Initialized
INFO - 2020-02-02 08:19:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:19:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:19:53 --> Utf8 Class Initialized
INFO - 2020-02-02 08:19:53 --> URI Class Initialized
DEBUG - 2020-02-02 08:19:53 --> No URI present. Default controller set.
INFO - 2020-02-02 08:19:53 --> Router Class Initialized
INFO - 2020-02-02 08:19:53 --> Output Class Initialized
INFO - 2020-02-02 08:19:53 --> Security Class Initialized
DEBUG - 2020-02-02 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:19:53 --> Input Class Initialized
INFO - 2020-02-02 08:19:53 --> Language Class Initialized
INFO - 2020-02-02 08:19:53 --> Language Class Initialized
INFO - 2020-02-02 08:19:53 --> Config Class Initialized
INFO - 2020-02-02 08:19:53 --> Loader Class Initialized
INFO - 2020-02-02 08:19:53 --> Helper loaded: url_helper
INFO - 2020-02-02 08:19:53 --> Helper loaded: file_helper
INFO - 2020-02-02 08:19:53 --> Helper loaded: form_helper
INFO - 2020-02-02 08:19:53 --> Helper loaded: my_helper
INFO - 2020-02-02 08:19:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:19:53 --> Controller Class Initialized
DEBUG - 2020-02-02 08:19:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:19:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:19:53 --> Final output sent to browser
DEBUG - 2020-02-02 08:19:53 --> Total execution time: 0.4556
INFO - 2020-02-02 08:20:00 --> Config Class Initialized
INFO - 2020-02-02 08:20:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:20:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:20:00 --> Utf8 Class Initialized
INFO - 2020-02-02 08:20:00 --> URI Class Initialized
DEBUG - 2020-02-02 08:20:00 --> No URI present. Default controller set.
INFO - 2020-02-02 08:20:00 --> Router Class Initialized
INFO - 2020-02-02 08:20:00 --> Output Class Initialized
INFO - 2020-02-02 08:20:00 --> Security Class Initialized
DEBUG - 2020-02-02 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:20:00 --> Input Class Initialized
INFO - 2020-02-02 08:20:00 --> Language Class Initialized
INFO - 2020-02-02 08:20:00 --> Language Class Initialized
INFO - 2020-02-02 08:20:01 --> Config Class Initialized
INFO - 2020-02-02 08:20:01 --> Loader Class Initialized
INFO - 2020-02-02 08:20:01 --> Helper loaded: url_helper
INFO - 2020-02-02 08:20:01 --> Helper loaded: file_helper
INFO - 2020-02-02 08:20:01 --> Helper loaded: form_helper
INFO - 2020-02-02 08:20:01 --> Helper loaded: my_helper
INFO - 2020-02-02 08:20:01 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:20:01 --> Controller Class Initialized
DEBUG - 2020-02-02 08:20:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:20:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:20:01 --> Final output sent to browser
DEBUG - 2020-02-02 08:20:01 --> Total execution time: 0.5138
INFO - 2020-02-02 08:20:09 --> Config Class Initialized
INFO - 2020-02-02 08:20:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:20:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:20:09 --> Utf8 Class Initialized
INFO - 2020-02-02 08:20:09 --> URI Class Initialized
DEBUG - 2020-02-02 08:20:09 --> No URI present. Default controller set.
INFO - 2020-02-02 08:20:09 --> Router Class Initialized
INFO - 2020-02-02 08:20:09 --> Output Class Initialized
INFO - 2020-02-02 08:20:09 --> Security Class Initialized
DEBUG - 2020-02-02 08:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:20:09 --> Input Class Initialized
INFO - 2020-02-02 08:20:09 --> Language Class Initialized
INFO - 2020-02-02 08:20:09 --> Language Class Initialized
INFO - 2020-02-02 08:20:09 --> Config Class Initialized
INFO - 2020-02-02 08:20:09 --> Loader Class Initialized
INFO - 2020-02-02 08:20:09 --> Helper loaded: url_helper
INFO - 2020-02-02 08:20:09 --> Helper loaded: file_helper
INFO - 2020-02-02 08:20:09 --> Helper loaded: form_helper
INFO - 2020-02-02 08:20:09 --> Helper loaded: my_helper
INFO - 2020-02-02 08:20:09 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:20:09 --> Controller Class Initialized
DEBUG - 2020-02-02 08:20:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:20:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:20:10 --> Final output sent to browser
DEBUG - 2020-02-02 08:20:10 --> Total execution time: 0.4460
INFO - 2020-02-02 08:20:16 --> Config Class Initialized
INFO - 2020-02-02 08:20:16 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:20:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:20:16 --> Utf8 Class Initialized
INFO - 2020-02-02 08:20:16 --> URI Class Initialized
DEBUG - 2020-02-02 08:20:16 --> No URI present. Default controller set.
INFO - 2020-02-02 08:20:16 --> Router Class Initialized
INFO - 2020-02-02 08:20:16 --> Output Class Initialized
INFO - 2020-02-02 08:20:16 --> Security Class Initialized
DEBUG - 2020-02-02 08:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:20:16 --> Input Class Initialized
INFO - 2020-02-02 08:20:16 --> Language Class Initialized
INFO - 2020-02-02 08:20:16 --> Language Class Initialized
INFO - 2020-02-02 08:20:16 --> Config Class Initialized
INFO - 2020-02-02 08:20:16 --> Loader Class Initialized
INFO - 2020-02-02 08:20:16 --> Helper loaded: url_helper
INFO - 2020-02-02 08:20:16 --> Helper loaded: file_helper
INFO - 2020-02-02 08:20:16 --> Helper loaded: form_helper
INFO - 2020-02-02 08:20:16 --> Helper loaded: my_helper
INFO - 2020-02-02 08:20:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:20:16 --> Controller Class Initialized
DEBUG - 2020-02-02 08:20:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:20:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:20:16 --> Final output sent to browser
DEBUG - 2020-02-02 08:20:16 --> Total execution time: 0.4367
INFO - 2020-02-02 08:20:36 --> Config Class Initialized
INFO - 2020-02-02 08:20:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:20:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:20:36 --> Utf8 Class Initialized
INFO - 2020-02-02 08:20:36 --> URI Class Initialized
DEBUG - 2020-02-02 08:20:36 --> No URI present. Default controller set.
INFO - 2020-02-02 08:20:36 --> Router Class Initialized
INFO - 2020-02-02 08:20:36 --> Output Class Initialized
INFO - 2020-02-02 08:20:36 --> Security Class Initialized
DEBUG - 2020-02-02 08:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:20:36 --> Input Class Initialized
INFO - 2020-02-02 08:20:36 --> Language Class Initialized
INFO - 2020-02-02 08:20:36 --> Language Class Initialized
INFO - 2020-02-02 08:20:36 --> Config Class Initialized
INFO - 2020-02-02 08:20:36 --> Loader Class Initialized
INFO - 2020-02-02 08:20:36 --> Helper loaded: url_helper
INFO - 2020-02-02 08:20:36 --> Helper loaded: file_helper
INFO - 2020-02-02 08:20:36 --> Helper loaded: form_helper
INFO - 2020-02-02 08:20:36 --> Helper loaded: my_helper
INFO - 2020-02-02 08:20:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:20:36 --> Controller Class Initialized
DEBUG - 2020-02-02 08:20:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:20:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:20:36 --> Final output sent to browser
DEBUG - 2020-02-02 08:20:36 --> Total execution time: 0.4543
INFO - 2020-02-02 08:21:10 --> Config Class Initialized
INFO - 2020-02-02 08:21:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:21:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:21:10 --> Utf8 Class Initialized
INFO - 2020-02-02 08:21:10 --> URI Class Initialized
DEBUG - 2020-02-02 08:21:10 --> No URI present. Default controller set.
INFO - 2020-02-02 08:21:10 --> Router Class Initialized
INFO - 2020-02-02 08:21:10 --> Output Class Initialized
INFO - 2020-02-02 08:21:10 --> Security Class Initialized
DEBUG - 2020-02-02 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:21:10 --> Input Class Initialized
INFO - 2020-02-02 08:21:10 --> Language Class Initialized
INFO - 2020-02-02 08:21:10 --> Language Class Initialized
INFO - 2020-02-02 08:21:10 --> Config Class Initialized
INFO - 2020-02-02 08:21:10 --> Loader Class Initialized
INFO - 2020-02-02 08:21:10 --> Helper loaded: url_helper
INFO - 2020-02-02 08:21:10 --> Helper loaded: file_helper
INFO - 2020-02-02 08:21:10 --> Helper loaded: form_helper
INFO - 2020-02-02 08:21:10 --> Helper loaded: my_helper
INFO - 2020-02-02 08:21:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:21:10 --> Controller Class Initialized
DEBUG - 2020-02-02 08:21:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:21:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:21:10 --> Final output sent to browser
DEBUG - 2020-02-02 08:21:10 --> Total execution time: 0.4581
INFO - 2020-02-02 08:21:36 --> Config Class Initialized
INFO - 2020-02-02 08:21:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:21:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:21:36 --> Utf8 Class Initialized
INFO - 2020-02-02 08:21:36 --> URI Class Initialized
DEBUG - 2020-02-02 08:21:36 --> No URI present. Default controller set.
INFO - 2020-02-02 08:21:36 --> Router Class Initialized
INFO - 2020-02-02 08:21:36 --> Output Class Initialized
INFO - 2020-02-02 08:21:36 --> Security Class Initialized
DEBUG - 2020-02-02 08:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:21:36 --> Input Class Initialized
INFO - 2020-02-02 08:21:36 --> Language Class Initialized
INFO - 2020-02-02 08:21:36 --> Language Class Initialized
INFO - 2020-02-02 08:21:36 --> Config Class Initialized
INFO - 2020-02-02 08:21:36 --> Loader Class Initialized
INFO - 2020-02-02 08:21:36 --> Helper loaded: url_helper
INFO - 2020-02-02 08:21:36 --> Helper loaded: file_helper
INFO - 2020-02-02 08:21:36 --> Helper loaded: form_helper
INFO - 2020-02-02 08:21:36 --> Helper loaded: my_helper
INFO - 2020-02-02 08:21:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:21:36 --> Controller Class Initialized
DEBUG - 2020-02-02 08:21:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:21:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:21:36 --> Final output sent to browser
DEBUG - 2020-02-02 08:21:36 --> Total execution time: 0.4584
INFO - 2020-02-02 08:21:48 --> Config Class Initialized
INFO - 2020-02-02 08:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:21:48 --> Utf8 Class Initialized
INFO - 2020-02-02 08:21:48 --> URI Class Initialized
DEBUG - 2020-02-02 08:21:48 --> No URI present. Default controller set.
INFO - 2020-02-02 08:21:48 --> Router Class Initialized
INFO - 2020-02-02 08:21:48 --> Output Class Initialized
INFO - 2020-02-02 08:21:48 --> Security Class Initialized
DEBUG - 2020-02-02 08:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:21:49 --> Input Class Initialized
INFO - 2020-02-02 08:21:49 --> Language Class Initialized
INFO - 2020-02-02 08:21:49 --> Language Class Initialized
INFO - 2020-02-02 08:21:49 --> Config Class Initialized
INFO - 2020-02-02 08:21:49 --> Loader Class Initialized
INFO - 2020-02-02 08:21:49 --> Helper loaded: url_helper
INFO - 2020-02-02 08:21:49 --> Helper loaded: file_helper
INFO - 2020-02-02 08:21:49 --> Helper loaded: form_helper
INFO - 2020-02-02 08:21:49 --> Helper loaded: my_helper
INFO - 2020-02-02 08:21:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:21:49 --> Controller Class Initialized
DEBUG - 2020-02-02 08:21:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:21:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:21:49 --> Final output sent to browser
DEBUG - 2020-02-02 08:21:49 --> Total execution time: 0.4457
INFO - 2020-02-02 08:22:02 --> Config Class Initialized
INFO - 2020-02-02 08:22:02 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:22:02 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:22:02 --> Utf8 Class Initialized
INFO - 2020-02-02 08:22:02 --> URI Class Initialized
DEBUG - 2020-02-02 08:22:02 --> No URI present. Default controller set.
INFO - 2020-02-02 08:22:02 --> Router Class Initialized
INFO - 2020-02-02 08:22:02 --> Output Class Initialized
INFO - 2020-02-02 08:22:02 --> Security Class Initialized
DEBUG - 2020-02-02 08:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:22:02 --> Input Class Initialized
INFO - 2020-02-02 08:22:03 --> Language Class Initialized
INFO - 2020-02-02 08:22:03 --> Language Class Initialized
INFO - 2020-02-02 08:22:03 --> Config Class Initialized
INFO - 2020-02-02 08:22:03 --> Loader Class Initialized
INFO - 2020-02-02 08:22:03 --> Helper loaded: url_helper
INFO - 2020-02-02 08:22:03 --> Helper loaded: file_helper
INFO - 2020-02-02 08:22:03 --> Helper loaded: form_helper
INFO - 2020-02-02 08:22:03 --> Helper loaded: my_helper
INFO - 2020-02-02 08:22:03 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:22:03 --> Controller Class Initialized
DEBUG - 2020-02-02 08:22:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:22:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:22:03 --> Final output sent to browser
DEBUG - 2020-02-02 08:22:03 --> Total execution time: 0.5070
INFO - 2020-02-02 08:22:20 --> Config Class Initialized
INFO - 2020-02-02 08:22:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:22:20 --> Utf8 Class Initialized
INFO - 2020-02-02 08:22:20 --> URI Class Initialized
INFO - 2020-02-02 08:22:20 --> Router Class Initialized
INFO - 2020-02-02 08:22:20 --> Output Class Initialized
INFO - 2020-02-02 08:22:20 --> Security Class Initialized
DEBUG - 2020-02-02 08:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:22:20 --> Input Class Initialized
INFO - 2020-02-02 08:22:20 --> Language Class Initialized
INFO - 2020-02-02 08:22:20 --> Language Class Initialized
INFO - 2020-02-02 08:22:20 --> Config Class Initialized
INFO - 2020-02-02 08:22:20 --> Loader Class Initialized
INFO - 2020-02-02 08:22:20 --> Helper loaded: url_helper
INFO - 2020-02-02 08:22:20 --> Helper loaded: file_helper
INFO - 2020-02-02 08:22:20 --> Helper loaded: form_helper
INFO - 2020-02-02 08:22:20 --> Helper loaded: my_helper
INFO - 2020-02-02 08:22:20 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:22:20 --> Controller Class Initialized
DEBUG - 2020-02-02 08:22:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-02 08:22:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:22:20 --> Final output sent to browser
DEBUG - 2020-02-02 08:22:20 --> Total execution time: 0.4346
INFO - 2020-02-02 08:23:00 --> Config Class Initialized
INFO - 2020-02-02 08:23:00 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:23:00 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:23:00 --> Utf8 Class Initialized
INFO - 2020-02-02 08:23:00 --> URI Class Initialized
DEBUG - 2020-02-02 08:23:00 --> No URI present. Default controller set.
INFO - 2020-02-02 08:23:00 --> Router Class Initialized
INFO - 2020-02-02 08:23:00 --> Output Class Initialized
INFO - 2020-02-02 08:23:00 --> Security Class Initialized
DEBUG - 2020-02-02 08:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:23:00 --> Input Class Initialized
INFO - 2020-02-02 08:23:00 --> Language Class Initialized
INFO - 2020-02-02 08:23:00 --> Language Class Initialized
INFO - 2020-02-02 08:23:00 --> Config Class Initialized
INFO - 2020-02-02 08:23:00 --> Loader Class Initialized
INFO - 2020-02-02 08:23:00 --> Helper loaded: url_helper
INFO - 2020-02-02 08:23:00 --> Helper loaded: file_helper
INFO - 2020-02-02 08:23:00 --> Helper loaded: form_helper
INFO - 2020-02-02 08:23:00 --> Helper loaded: my_helper
INFO - 2020-02-02 08:23:00 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:23:00 --> Controller Class Initialized
DEBUG - 2020-02-02 08:23:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:23:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:23:00 --> Final output sent to browser
DEBUG - 2020-02-02 08:23:00 --> Total execution time: 0.5330
INFO - 2020-02-02 08:23:41 --> Config Class Initialized
INFO - 2020-02-02 08:23:41 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:23:41 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:23:41 --> Utf8 Class Initialized
INFO - 2020-02-02 08:23:41 --> URI Class Initialized
DEBUG - 2020-02-02 08:23:41 --> No URI present. Default controller set.
INFO - 2020-02-02 08:23:41 --> Router Class Initialized
INFO - 2020-02-02 08:23:41 --> Output Class Initialized
INFO - 2020-02-02 08:23:41 --> Security Class Initialized
DEBUG - 2020-02-02 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:23:41 --> Input Class Initialized
INFO - 2020-02-02 08:23:41 --> Language Class Initialized
INFO - 2020-02-02 08:23:41 --> Language Class Initialized
INFO - 2020-02-02 08:23:41 --> Config Class Initialized
INFO - 2020-02-02 08:23:41 --> Loader Class Initialized
INFO - 2020-02-02 08:23:41 --> Helper loaded: url_helper
INFO - 2020-02-02 08:23:41 --> Helper loaded: file_helper
INFO - 2020-02-02 08:23:41 --> Helper loaded: form_helper
INFO - 2020-02-02 08:23:41 --> Helper loaded: my_helper
INFO - 2020-02-02 08:23:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:23:41 --> Controller Class Initialized
DEBUG - 2020-02-02 08:23:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:23:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:23:41 --> Final output sent to browser
DEBUG - 2020-02-02 08:23:41 --> Total execution time: 0.4830
INFO - 2020-02-02 08:34:39 --> Config Class Initialized
INFO - 2020-02-02 08:34:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:34:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:34:39 --> Utf8 Class Initialized
INFO - 2020-02-02 08:34:39 --> URI Class Initialized
INFO - 2020-02-02 08:34:39 --> Router Class Initialized
INFO - 2020-02-02 08:34:39 --> Output Class Initialized
INFO - 2020-02-02 08:34:39 --> Security Class Initialized
DEBUG - 2020-02-02 08:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:34:39 --> Input Class Initialized
INFO - 2020-02-02 08:34:39 --> Language Class Initialized
INFO - 2020-02-02 08:34:39 --> Language Class Initialized
INFO - 2020-02-02 08:34:39 --> Config Class Initialized
INFO - 2020-02-02 08:34:39 --> Loader Class Initialized
INFO - 2020-02-02 08:34:39 --> Helper loaded: url_helper
INFO - 2020-02-02 08:34:39 --> Helper loaded: file_helper
INFO - 2020-02-02 08:34:39 --> Helper loaded: form_helper
INFO - 2020-02-02 08:34:39 --> Helper loaded: my_helper
INFO - 2020-02-02 08:34:39 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:34:39 --> Controller Class Initialized
DEBUG - 2020-02-02 08:34:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-02 08:34:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:34:39 --> Final output sent to browser
DEBUG - 2020-02-02 08:34:39 --> Total execution time: 0.4147
INFO - 2020-02-02 08:34:39 --> Config Class Initialized
INFO - 2020-02-02 08:34:39 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:34:39 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:34:39 --> Utf8 Class Initialized
INFO - 2020-02-02 08:34:39 --> URI Class Initialized
INFO - 2020-02-02 08:34:39 --> Router Class Initialized
INFO - 2020-02-02 08:34:39 --> Output Class Initialized
INFO - 2020-02-02 08:34:39 --> Security Class Initialized
DEBUG - 2020-02-02 08:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:34:39 --> Input Class Initialized
INFO - 2020-02-02 08:34:40 --> Language Class Initialized
INFO - 2020-02-02 08:34:40 --> Language Class Initialized
INFO - 2020-02-02 08:34:40 --> Config Class Initialized
INFO - 2020-02-02 08:34:40 --> Loader Class Initialized
INFO - 2020-02-02 08:34:40 --> Helper loaded: url_helper
INFO - 2020-02-02 08:34:40 --> Helper loaded: file_helper
INFO - 2020-02-02 08:34:40 --> Helper loaded: form_helper
INFO - 2020-02-02 08:34:40 --> Helper loaded: my_helper
INFO - 2020-02-02 08:34:40 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:34:40 --> Controller Class Initialized
INFO - 2020-02-02 08:34:44 --> Config Class Initialized
INFO - 2020-02-02 08:34:44 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:34:44 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:34:44 --> Utf8 Class Initialized
INFO - 2020-02-02 08:34:44 --> URI Class Initialized
DEBUG - 2020-02-02 08:34:44 --> No URI present. Default controller set.
INFO - 2020-02-02 08:34:44 --> Router Class Initialized
INFO - 2020-02-02 08:34:44 --> Output Class Initialized
INFO - 2020-02-02 08:34:44 --> Security Class Initialized
DEBUG - 2020-02-02 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:34:44 --> Input Class Initialized
INFO - 2020-02-02 08:34:44 --> Language Class Initialized
INFO - 2020-02-02 08:34:44 --> Language Class Initialized
INFO - 2020-02-02 08:34:44 --> Config Class Initialized
INFO - 2020-02-02 08:34:44 --> Loader Class Initialized
INFO - 2020-02-02 08:34:44 --> Helper loaded: url_helper
INFO - 2020-02-02 08:34:44 --> Helper loaded: file_helper
INFO - 2020-02-02 08:34:44 --> Helper loaded: form_helper
INFO - 2020-02-02 08:34:44 --> Helper loaded: my_helper
INFO - 2020-02-02 08:34:44 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:34:44 --> Controller Class Initialized
DEBUG - 2020-02-02 08:34:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:34:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:34:44 --> Final output sent to browser
DEBUG - 2020-02-02 08:34:45 --> Total execution time: 0.5481
INFO - 2020-02-02 08:35:40 --> Config Class Initialized
INFO - 2020-02-02 08:35:40 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:35:40 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:35:40 --> Utf8 Class Initialized
INFO - 2020-02-02 08:35:40 --> URI Class Initialized
DEBUG - 2020-02-02 08:35:40 --> No URI present. Default controller set.
INFO - 2020-02-02 08:35:40 --> Router Class Initialized
INFO - 2020-02-02 08:35:41 --> Output Class Initialized
INFO - 2020-02-02 08:35:41 --> Security Class Initialized
DEBUG - 2020-02-02 08:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:35:41 --> Input Class Initialized
INFO - 2020-02-02 08:35:41 --> Language Class Initialized
INFO - 2020-02-02 08:35:41 --> Language Class Initialized
INFO - 2020-02-02 08:35:41 --> Config Class Initialized
INFO - 2020-02-02 08:35:41 --> Loader Class Initialized
INFO - 2020-02-02 08:35:41 --> Helper loaded: url_helper
INFO - 2020-02-02 08:35:41 --> Helper loaded: file_helper
INFO - 2020-02-02 08:35:41 --> Helper loaded: form_helper
INFO - 2020-02-02 08:35:41 --> Helper loaded: my_helper
INFO - 2020-02-02 08:35:41 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:35:41 --> Controller Class Initialized
DEBUG - 2020-02-02 08:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:35:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:35:41 --> Final output sent to browser
DEBUG - 2020-02-02 08:35:41 --> Total execution time: 0.5103
INFO - 2020-02-02 08:35:49 --> Config Class Initialized
INFO - 2020-02-02 08:35:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:35:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:35:49 --> Utf8 Class Initialized
INFO - 2020-02-02 08:35:49 --> URI Class Initialized
INFO - 2020-02-02 08:35:49 --> Router Class Initialized
INFO - 2020-02-02 08:35:49 --> Output Class Initialized
INFO - 2020-02-02 08:35:49 --> Security Class Initialized
DEBUG - 2020-02-02 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:35:49 --> Input Class Initialized
INFO - 2020-02-02 08:35:49 --> Language Class Initialized
INFO - 2020-02-02 08:35:49 --> Language Class Initialized
INFO - 2020-02-02 08:35:49 --> Config Class Initialized
INFO - 2020-02-02 08:35:49 --> Loader Class Initialized
INFO - 2020-02-02 08:35:49 --> Helper loaded: url_helper
INFO - 2020-02-02 08:35:49 --> Helper loaded: file_helper
INFO - 2020-02-02 08:35:49 --> Helper loaded: form_helper
INFO - 2020-02-02 08:35:49 --> Helper loaded: my_helper
INFO - 2020-02-02 08:35:49 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:35:49 --> Controller Class Initialized
DEBUG - 2020-02-02 08:35:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-02 08:35:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:35:49 --> Final output sent to browser
DEBUG - 2020-02-02 08:35:49 --> Total execution time: 0.4371
INFO - 2020-02-02 08:35:49 --> Config Class Initialized
INFO - 2020-02-02 08:35:49 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:35:49 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:35:49 --> Utf8 Class Initialized
INFO - 2020-02-02 08:35:49 --> URI Class Initialized
INFO - 2020-02-02 08:35:49 --> Router Class Initialized
INFO - 2020-02-02 08:35:49 --> Output Class Initialized
INFO - 2020-02-02 08:35:50 --> Security Class Initialized
DEBUG - 2020-02-02 08:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:35:50 --> Input Class Initialized
INFO - 2020-02-02 08:35:50 --> Language Class Initialized
INFO - 2020-02-02 08:35:50 --> Language Class Initialized
INFO - 2020-02-02 08:35:50 --> Config Class Initialized
INFO - 2020-02-02 08:35:50 --> Loader Class Initialized
INFO - 2020-02-02 08:35:50 --> Helper loaded: url_helper
INFO - 2020-02-02 08:35:50 --> Helper loaded: file_helper
INFO - 2020-02-02 08:35:50 --> Helper loaded: form_helper
INFO - 2020-02-02 08:35:50 --> Helper loaded: my_helper
INFO - 2020-02-02 08:35:50 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:35:50 --> Controller Class Initialized
INFO - 2020-02-02 08:35:52 --> Config Class Initialized
INFO - 2020-02-02 08:35:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:35:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:35:52 --> Utf8 Class Initialized
INFO - 2020-02-02 08:35:52 --> URI Class Initialized
DEBUG - 2020-02-02 08:35:52 --> No URI present. Default controller set.
INFO - 2020-02-02 08:35:52 --> Router Class Initialized
INFO - 2020-02-02 08:35:52 --> Output Class Initialized
INFO - 2020-02-02 08:35:52 --> Security Class Initialized
DEBUG - 2020-02-02 08:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:35:52 --> Input Class Initialized
INFO - 2020-02-02 08:35:52 --> Language Class Initialized
INFO - 2020-02-02 08:35:52 --> Language Class Initialized
INFO - 2020-02-02 08:35:52 --> Config Class Initialized
INFO - 2020-02-02 08:35:52 --> Loader Class Initialized
INFO - 2020-02-02 08:35:52 --> Helper loaded: url_helper
INFO - 2020-02-02 08:35:52 --> Helper loaded: file_helper
INFO - 2020-02-02 08:35:52 --> Helper loaded: form_helper
INFO - 2020-02-02 08:35:52 --> Helper loaded: my_helper
INFO - 2020-02-02 08:35:52 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:35:52 --> Controller Class Initialized
DEBUG - 2020-02-02 08:35:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:35:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:35:52 --> Final output sent to browser
DEBUG - 2020-02-02 08:35:53 --> Total execution time: 0.6675
INFO - 2020-02-02 08:36:20 --> Config Class Initialized
INFO - 2020-02-02 08:36:20 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:20 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:20 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:20 --> URI Class Initialized
DEBUG - 2020-02-02 08:36:20 --> No URI present. Default controller set.
INFO - 2020-02-02 08:36:20 --> Router Class Initialized
INFO - 2020-02-02 08:36:20 --> Output Class Initialized
INFO - 2020-02-02 08:36:20 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:20 --> Input Class Initialized
INFO - 2020-02-02 08:36:20 --> Language Class Initialized
INFO - 2020-02-02 08:36:20 --> Language Class Initialized
INFO - 2020-02-02 08:36:20 --> Config Class Initialized
INFO - 2020-02-02 08:36:20 --> Loader Class Initialized
INFO - 2020-02-02 08:36:20 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:20 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:20 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:21 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:21 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:21 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:36:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:21 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:21 --> Total execution time: 0.4855
INFO - 2020-02-02 08:36:22 --> Config Class Initialized
INFO - 2020-02-02 08:36:22 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:22 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:22 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:22 --> URI Class Initialized
INFO - 2020-02-02 08:36:22 --> Router Class Initialized
INFO - 2020-02-02 08:36:23 --> Output Class Initialized
INFO - 2020-02-02 08:36:23 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:23 --> Input Class Initialized
INFO - 2020-02-02 08:36:23 --> Language Class Initialized
INFO - 2020-02-02 08:36:23 --> Language Class Initialized
INFO - 2020-02-02 08:36:23 --> Config Class Initialized
INFO - 2020-02-02 08:36:23 --> Loader Class Initialized
INFO - 2020-02-02 08:36:23 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:23 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:23 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:23 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:23 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:23 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-02 08:36:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:23 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:23 --> Total execution time: 0.4573
INFO - 2020-02-02 08:36:30 --> Config Class Initialized
INFO - 2020-02-02 08:36:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:30 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:30 --> URI Class Initialized
DEBUG - 2020-02-02 08:36:30 --> No URI present. Default controller set.
INFO - 2020-02-02 08:36:30 --> Router Class Initialized
INFO - 2020-02-02 08:36:30 --> Output Class Initialized
INFO - 2020-02-02 08:36:30 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:30 --> Input Class Initialized
INFO - 2020-02-02 08:36:30 --> Language Class Initialized
INFO - 2020-02-02 08:36:30 --> Language Class Initialized
INFO - 2020-02-02 08:36:30 --> Config Class Initialized
INFO - 2020-02-02 08:36:30 --> Loader Class Initialized
INFO - 2020-02-02 08:36:30 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:30 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:30 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:30 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:30 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:30 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:36:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:30 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:30 --> Total execution time: 0.5262
INFO - 2020-02-02 08:36:33 --> Config Class Initialized
INFO - 2020-02-02 08:36:33 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:33 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:33 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:33 --> URI Class Initialized
INFO - 2020-02-02 08:36:33 --> Router Class Initialized
INFO - 2020-02-02 08:36:33 --> Output Class Initialized
INFO - 2020-02-02 08:36:33 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:33 --> Input Class Initialized
INFO - 2020-02-02 08:36:33 --> Language Class Initialized
INFO - 2020-02-02 08:36:34 --> Language Class Initialized
INFO - 2020-02-02 08:36:34 --> Config Class Initialized
INFO - 2020-02-02 08:36:34 --> Loader Class Initialized
INFO - 2020-02-02 08:36:34 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:34 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:34 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:34 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:34 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:34 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-02 08:36:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:34 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:34 --> Total execution time: 0.4375
INFO - 2020-02-02 08:36:36 --> Config Class Initialized
INFO - 2020-02-02 08:36:36 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:36 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:36 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:36 --> URI Class Initialized
DEBUG - 2020-02-02 08:36:36 --> No URI present. Default controller set.
INFO - 2020-02-02 08:36:36 --> Router Class Initialized
INFO - 2020-02-02 08:36:36 --> Output Class Initialized
INFO - 2020-02-02 08:36:36 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:36 --> Input Class Initialized
INFO - 2020-02-02 08:36:36 --> Language Class Initialized
INFO - 2020-02-02 08:36:36 --> Language Class Initialized
INFO - 2020-02-02 08:36:36 --> Config Class Initialized
INFO - 2020-02-02 08:36:36 --> Loader Class Initialized
INFO - 2020-02-02 08:36:36 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:36 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:36 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:36 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:36 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:37 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:36:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:37 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:37 --> Total execution time: 0.5537
INFO - 2020-02-02 08:36:43 --> Config Class Initialized
INFO - 2020-02-02 08:36:43 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:43 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:43 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:43 --> URI Class Initialized
INFO - 2020-02-02 08:36:43 --> Router Class Initialized
INFO - 2020-02-02 08:36:43 --> Output Class Initialized
INFO - 2020-02-02 08:36:43 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:44 --> Input Class Initialized
INFO - 2020-02-02 08:36:44 --> Language Class Initialized
INFO - 2020-02-02 08:36:44 --> Language Class Initialized
INFO - 2020-02-02 08:36:44 --> Config Class Initialized
INFO - 2020-02-02 08:36:44 --> Loader Class Initialized
INFO - 2020-02-02 08:36:44 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:44 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:44 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:44 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:44 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:44 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-02 08:36:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:44 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:44 --> Total execution time: 0.4181
INFO - 2020-02-02 08:36:46 --> Config Class Initialized
INFO - 2020-02-02 08:36:46 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:46 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:46 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:46 --> URI Class Initialized
DEBUG - 2020-02-02 08:36:46 --> No URI present. Default controller set.
INFO - 2020-02-02 08:36:46 --> Router Class Initialized
INFO - 2020-02-02 08:36:46 --> Output Class Initialized
INFO - 2020-02-02 08:36:46 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:46 --> Input Class Initialized
INFO - 2020-02-02 08:36:46 --> Language Class Initialized
INFO - 2020-02-02 08:36:46 --> Language Class Initialized
INFO - 2020-02-02 08:36:46 --> Config Class Initialized
INFO - 2020-02-02 08:36:46 --> Loader Class Initialized
INFO - 2020-02-02 08:36:46 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:46 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:47 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:47 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:47 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:47 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:36:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:47 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:47 --> Total execution time: 0.6056
INFO - 2020-02-02 08:36:50 --> Config Class Initialized
INFO - 2020-02-02 08:36:50 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:50 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:50 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:50 --> URI Class Initialized
DEBUG - 2020-02-02 08:36:50 --> No URI present. Default controller set.
INFO - 2020-02-02 08:36:50 --> Router Class Initialized
INFO - 2020-02-02 08:36:50 --> Output Class Initialized
INFO - 2020-02-02 08:36:50 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:50 --> Input Class Initialized
INFO - 2020-02-02 08:36:50 --> Language Class Initialized
INFO - 2020-02-02 08:36:50 --> Language Class Initialized
INFO - 2020-02-02 08:36:50 --> Config Class Initialized
INFO - 2020-02-02 08:36:50 --> Loader Class Initialized
INFO - 2020-02-02 08:36:50 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:50 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:50 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:50 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:50 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:50 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-02 08:36:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:50 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:50 --> Total execution time: 0.5008
INFO - 2020-02-02 08:36:52 --> Config Class Initialized
INFO - 2020-02-02 08:36:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:52 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:52 --> URI Class Initialized
INFO - 2020-02-02 08:36:52 --> Router Class Initialized
INFO - 2020-02-02 08:36:52 --> Output Class Initialized
INFO - 2020-02-02 08:36:52 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:52 --> Input Class Initialized
INFO - 2020-02-02 08:36:52 --> Language Class Initialized
INFO - 2020-02-02 08:36:52 --> Language Class Initialized
INFO - 2020-02-02 08:36:52 --> Config Class Initialized
INFO - 2020-02-02 08:36:52 --> Loader Class Initialized
INFO - 2020-02-02 08:36:52 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:52 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:52 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:52 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:52 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:52 --> Controller Class Initialized
INFO - 2020-02-02 08:36:52 --> Helper loaded: cookie_helper
INFO - 2020-02-02 08:36:52 --> Config Class Initialized
INFO - 2020-02-02 08:36:52 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:52 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:52 --> URI Class Initialized
INFO - 2020-02-02 08:36:52 --> Router Class Initialized
INFO - 2020-02-02 08:36:52 --> Output Class Initialized
INFO - 2020-02-02 08:36:53 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:53 --> Input Class Initialized
INFO - 2020-02-02 08:36:53 --> Language Class Initialized
INFO - 2020-02-02 08:36:53 --> Language Class Initialized
INFO - 2020-02-02 08:36:53 --> Config Class Initialized
INFO - 2020-02-02 08:36:53 --> Loader Class Initialized
INFO - 2020-02-02 08:36:53 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:53 --> Controller Class Initialized
INFO - 2020-02-02 08:36:53 --> Config Class Initialized
INFO - 2020-02-02 08:36:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:53 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:53 --> URI Class Initialized
INFO - 2020-02-02 08:36:53 --> Router Class Initialized
INFO - 2020-02-02 08:36:53 --> Output Class Initialized
INFO - 2020-02-02 08:36:53 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:53 --> Input Class Initialized
INFO - 2020-02-02 08:36:53 --> Language Class Initialized
INFO - 2020-02-02 08:36:53 --> Language Class Initialized
INFO - 2020-02-02 08:36:53 --> Config Class Initialized
INFO - 2020-02-02 08:36:53 --> Loader Class Initialized
INFO - 2020-02-02 08:36:53 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:53 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:53 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-02 08:36:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:53 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:53 --> Total execution time: 0.4160
INFO - 2020-02-02 08:36:57 --> Config Class Initialized
INFO - 2020-02-02 08:36:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:58 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:58 --> URI Class Initialized
INFO - 2020-02-02 08:36:58 --> Router Class Initialized
INFO - 2020-02-02 08:36:58 --> Output Class Initialized
INFO - 2020-02-02 08:36:58 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:58 --> Input Class Initialized
INFO - 2020-02-02 08:36:58 --> Language Class Initialized
INFO - 2020-02-02 08:36:58 --> Language Class Initialized
INFO - 2020-02-02 08:36:58 --> Config Class Initialized
INFO - 2020-02-02 08:36:58 --> Loader Class Initialized
INFO - 2020-02-02 08:36:58 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:58 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:58 --> Controller Class Initialized
INFO - 2020-02-02 08:36:58 --> Helper loaded: cookie_helper
INFO - 2020-02-02 08:36:58 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:58 --> Total execution time: 0.4364
INFO - 2020-02-02 08:36:58 --> Config Class Initialized
INFO - 2020-02-02 08:36:58 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:36:58 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:36:58 --> Utf8 Class Initialized
INFO - 2020-02-02 08:36:58 --> URI Class Initialized
INFO - 2020-02-02 08:36:58 --> Router Class Initialized
INFO - 2020-02-02 08:36:58 --> Output Class Initialized
INFO - 2020-02-02 08:36:58 --> Security Class Initialized
DEBUG - 2020-02-02 08:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:36:58 --> Input Class Initialized
INFO - 2020-02-02 08:36:58 --> Language Class Initialized
INFO - 2020-02-02 08:36:58 --> Language Class Initialized
INFO - 2020-02-02 08:36:58 --> Config Class Initialized
INFO - 2020-02-02 08:36:58 --> Loader Class Initialized
INFO - 2020-02-02 08:36:58 --> Helper loaded: url_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: file_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: form_helper
INFO - 2020-02-02 08:36:58 --> Helper loaded: my_helper
INFO - 2020-02-02 08:36:58 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:36:58 --> Controller Class Initialized
DEBUG - 2020-02-02 08:36:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:36:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:36:58 --> Final output sent to browser
DEBUG - 2020-02-02 08:36:58 --> Total execution time: 0.4621
INFO - 2020-02-02 08:37:10 --> Config Class Initialized
INFO - 2020-02-02 08:37:10 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:10 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:10 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:10 --> URI Class Initialized
INFO - 2020-02-02 08:37:10 --> Router Class Initialized
INFO - 2020-02-02 08:37:10 --> Output Class Initialized
INFO - 2020-02-02 08:37:10 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:10 --> Input Class Initialized
INFO - 2020-02-02 08:37:10 --> Language Class Initialized
INFO - 2020-02-02 08:37:10 --> Language Class Initialized
INFO - 2020-02-02 08:37:10 --> Config Class Initialized
INFO - 2020-02-02 08:37:10 --> Loader Class Initialized
INFO - 2020-02-02 08:37:10 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:10 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:10 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:10 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:10 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-02 08:37:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:10 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:10 --> Total execution time: 0.4258
INFO - 2020-02-02 08:37:12 --> Config Class Initialized
INFO - 2020-02-02 08:37:12 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:12 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:12 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:12 --> URI Class Initialized
INFO - 2020-02-02 08:37:12 --> Router Class Initialized
INFO - 2020-02-02 08:37:12 --> Output Class Initialized
INFO - 2020-02-02 08:37:12 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:12 --> Input Class Initialized
INFO - 2020-02-02 08:37:12 --> Language Class Initialized
INFO - 2020-02-02 08:37:12 --> Language Class Initialized
INFO - 2020-02-02 08:37:12 --> Config Class Initialized
INFO - 2020-02-02 08:37:12 --> Loader Class Initialized
INFO - 2020-02-02 08:37:12 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:12 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:12 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:12 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:12 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:13 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-02 08:37:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:13 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:13 --> Total execution time: 0.4749
INFO - 2020-02-02 08:37:13 --> Config Class Initialized
INFO - 2020-02-02 08:37:13 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:13 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:13 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:13 --> URI Class Initialized
INFO - 2020-02-02 08:37:13 --> Router Class Initialized
INFO - 2020-02-02 08:37:13 --> Output Class Initialized
INFO - 2020-02-02 08:37:13 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:13 --> Input Class Initialized
INFO - 2020-02-02 08:37:13 --> Language Class Initialized
INFO - 2020-02-02 08:37:13 --> Language Class Initialized
INFO - 2020-02-02 08:37:13 --> Config Class Initialized
INFO - 2020-02-02 08:37:13 --> Loader Class Initialized
INFO - 2020-02-02 08:37:13 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:13 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:13 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:13 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:13 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:13 --> Controller Class Initialized
INFO - 2020-02-02 08:37:15 --> Config Class Initialized
INFO - 2020-02-02 08:37:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:15 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:15 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:15 --> URI Class Initialized
INFO - 2020-02-02 08:37:15 --> Router Class Initialized
INFO - 2020-02-02 08:37:15 --> Output Class Initialized
INFO - 2020-02-02 08:37:15 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:15 --> Input Class Initialized
INFO - 2020-02-02 08:37:15 --> Language Class Initialized
INFO - 2020-02-02 08:37:15 --> Language Class Initialized
INFO - 2020-02-02 08:37:15 --> Config Class Initialized
INFO - 2020-02-02 08:37:15 --> Loader Class Initialized
INFO - 2020-02-02 08:37:15 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:15 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:15 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:15 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:15 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-02 08:37:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:15 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:15 --> Total execution time: 0.4984
INFO - 2020-02-02 08:37:15 --> Config Class Initialized
INFO - 2020-02-02 08:37:15 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:16 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:16 --> URI Class Initialized
INFO - 2020-02-02 08:37:16 --> Router Class Initialized
INFO - 2020-02-02 08:37:16 --> Output Class Initialized
INFO - 2020-02-02 08:37:16 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:16 --> Input Class Initialized
INFO - 2020-02-02 08:37:16 --> Language Class Initialized
INFO - 2020-02-02 08:37:16 --> Language Class Initialized
INFO - 2020-02-02 08:37:16 --> Config Class Initialized
INFO - 2020-02-02 08:37:16 --> Loader Class Initialized
INFO - 2020-02-02 08:37:16 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:16 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:16 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:16 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:16 --> Controller Class Initialized
INFO - 2020-02-02 08:37:17 --> Config Class Initialized
INFO - 2020-02-02 08:37:18 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:18 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:18 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:18 --> URI Class Initialized
INFO - 2020-02-02 08:37:18 --> Router Class Initialized
INFO - 2020-02-02 08:37:18 --> Output Class Initialized
INFO - 2020-02-02 08:37:18 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:18 --> Input Class Initialized
INFO - 2020-02-02 08:37:18 --> Language Class Initialized
INFO - 2020-02-02 08:37:18 --> Language Class Initialized
INFO - 2020-02-02 08:37:18 --> Config Class Initialized
INFO - 2020-02-02 08:37:18 --> Loader Class Initialized
INFO - 2020-02-02 08:37:18 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:18 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:18 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-02 08:37:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:18 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:18 --> Total execution time: 0.4415
INFO - 2020-02-02 08:37:18 --> Config Class Initialized
INFO - 2020-02-02 08:37:18 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:18 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:18 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:18 --> URI Class Initialized
INFO - 2020-02-02 08:37:18 --> Router Class Initialized
INFO - 2020-02-02 08:37:18 --> Output Class Initialized
INFO - 2020-02-02 08:37:18 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:18 --> Input Class Initialized
INFO - 2020-02-02 08:37:18 --> Language Class Initialized
INFO - 2020-02-02 08:37:18 --> Language Class Initialized
INFO - 2020-02-02 08:37:18 --> Config Class Initialized
INFO - 2020-02-02 08:37:18 --> Loader Class Initialized
INFO - 2020-02-02 08:37:18 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:18 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:18 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:18 --> Controller Class Initialized
INFO - 2020-02-02 08:37:21 --> Config Class Initialized
INFO - 2020-02-02 08:37:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:21 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:21 --> URI Class Initialized
DEBUG - 2020-02-02 08:37:21 --> No URI present. Default controller set.
INFO - 2020-02-02 08:37:21 --> Router Class Initialized
INFO - 2020-02-02 08:37:21 --> Output Class Initialized
INFO - 2020-02-02 08:37:21 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:21 --> Input Class Initialized
INFO - 2020-02-02 08:37:22 --> Language Class Initialized
INFO - 2020-02-02 08:37:22 --> Language Class Initialized
INFO - 2020-02-02 08:37:22 --> Config Class Initialized
INFO - 2020-02-02 08:37:22 --> Loader Class Initialized
INFO - 2020-02-02 08:37:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:22 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:22 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:37:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:22 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:22 --> Total execution time: 0.5117
INFO - 2020-02-02 08:37:56 --> Config Class Initialized
INFO - 2020-02-02 08:37:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:37:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:37:56 --> Utf8 Class Initialized
INFO - 2020-02-02 08:37:56 --> URI Class Initialized
DEBUG - 2020-02-02 08:37:56 --> No URI present. Default controller set.
INFO - 2020-02-02 08:37:56 --> Router Class Initialized
INFO - 2020-02-02 08:37:56 --> Output Class Initialized
INFO - 2020-02-02 08:37:56 --> Security Class Initialized
DEBUG - 2020-02-02 08:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:37:56 --> Input Class Initialized
INFO - 2020-02-02 08:37:56 --> Language Class Initialized
INFO - 2020-02-02 08:37:56 --> Language Class Initialized
INFO - 2020-02-02 08:37:56 --> Config Class Initialized
INFO - 2020-02-02 08:37:57 --> Loader Class Initialized
INFO - 2020-02-02 08:37:57 --> Helper loaded: url_helper
INFO - 2020-02-02 08:37:57 --> Helper loaded: file_helper
INFO - 2020-02-02 08:37:57 --> Helper loaded: form_helper
INFO - 2020-02-02 08:37:57 --> Helper loaded: my_helper
INFO - 2020-02-02 08:37:57 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:37:57 --> Controller Class Initialized
DEBUG - 2020-02-02 08:37:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:37:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:37:57 --> Final output sent to browser
DEBUG - 2020-02-02 08:37:57 --> Total execution time: 0.4764
INFO - 2020-02-02 08:38:09 --> Config Class Initialized
INFO - 2020-02-02 08:38:09 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:38:09 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:38:09 --> Utf8 Class Initialized
INFO - 2020-02-02 08:38:09 --> URI Class Initialized
DEBUG - 2020-02-02 08:38:09 --> No URI present. Default controller set.
INFO - 2020-02-02 08:38:09 --> Router Class Initialized
INFO - 2020-02-02 08:38:10 --> Output Class Initialized
INFO - 2020-02-02 08:38:10 --> Security Class Initialized
DEBUG - 2020-02-02 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:38:10 --> Input Class Initialized
INFO - 2020-02-02 08:38:10 --> Language Class Initialized
INFO - 2020-02-02 08:38:10 --> Language Class Initialized
INFO - 2020-02-02 08:38:10 --> Config Class Initialized
INFO - 2020-02-02 08:38:10 --> Loader Class Initialized
INFO - 2020-02-02 08:38:10 --> Helper loaded: url_helper
INFO - 2020-02-02 08:38:10 --> Helper loaded: file_helper
INFO - 2020-02-02 08:38:10 --> Helper loaded: form_helper
INFO - 2020-02-02 08:38:10 --> Helper loaded: my_helper
INFO - 2020-02-02 08:38:10 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:38:10 --> Controller Class Initialized
ERROR - 2020-02-02 08:38:10 --> Severity: Notice --> Undefined variable: mapel_diampuh E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 27
DEBUG - 2020-02-02 08:38:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:38:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:38:10 --> Final output sent to browser
DEBUG - 2020-02-02 08:38:10 --> Total execution time: 0.5445
INFO - 2020-02-02 08:39:45 --> Config Class Initialized
INFO - 2020-02-02 08:39:45 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:39:45 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:39:45 --> Utf8 Class Initialized
INFO - 2020-02-02 08:39:45 --> URI Class Initialized
DEBUG - 2020-02-02 08:39:45 --> No URI present. Default controller set.
INFO - 2020-02-02 08:39:45 --> Router Class Initialized
INFO - 2020-02-02 08:39:45 --> Output Class Initialized
INFO - 2020-02-02 08:39:45 --> Security Class Initialized
DEBUG - 2020-02-02 08:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:39:46 --> Input Class Initialized
INFO - 2020-02-02 08:39:46 --> Language Class Initialized
INFO - 2020-02-02 08:39:46 --> Language Class Initialized
INFO - 2020-02-02 08:39:46 --> Config Class Initialized
INFO - 2020-02-02 08:39:46 --> Loader Class Initialized
INFO - 2020-02-02 08:39:46 --> Helper loaded: url_helper
INFO - 2020-02-02 08:39:46 --> Helper loaded: file_helper
INFO - 2020-02-02 08:39:46 --> Helper loaded: form_helper
INFO - 2020-02-02 08:39:46 --> Helper loaded: my_helper
INFO - 2020-02-02 08:39:46 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:39:46 --> Controller Class Initialized
ERROR - 2020-02-02 08:39:46 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 27
DEBUG - 2020-02-02 08:39:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:39:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:39:46 --> Final output sent to browser
DEBUG - 2020-02-02 08:39:46 --> Total execution time: 0.4813
INFO - 2020-02-02 08:39:56 --> Config Class Initialized
INFO - 2020-02-02 08:39:56 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:39:56 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:39:56 --> Utf8 Class Initialized
INFO - 2020-02-02 08:39:56 --> URI Class Initialized
DEBUG - 2020-02-02 08:39:56 --> No URI present. Default controller set.
INFO - 2020-02-02 08:39:56 --> Router Class Initialized
INFO - 2020-02-02 08:39:56 --> Output Class Initialized
INFO - 2020-02-02 08:39:56 --> Security Class Initialized
DEBUG - 2020-02-02 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:39:56 --> Input Class Initialized
INFO - 2020-02-02 08:39:56 --> Language Class Initialized
INFO - 2020-02-02 08:39:56 --> Language Class Initialized
INFO - 2020-02-02 08:39:56 --> Config Class Initialized
INFO - 2020-02-02 08:39:56 --> Loader Class Initialized
INFO - 2020-02-02 08:39:56 --> Helper loaded: url_helper
INFO - 2020-02-02 08:39:56 --> Helper loaded: file_helper
INFO - 2020-02-02 08:39:56 --> Helper loaded: form_helper
INFO - 2020-02-02 08:39:56 --> Helper loaded: my_helper
INFO - 2020-02-02 08:39:56 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:39:56 --> Controller Class Initialized
DEBUG - 2020-02-02 08:39:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:39:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:39:56 --> Final output sent to browser
DEBUG - 2020-02-02 08:39:56 --> Total execution time: 0.4691
INFO - 2020-02-02 08:40:37 --> Config Class Initialized
INFO - 2020-02-02 08:40:37 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:40:37 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:40:37 --> Utf8 Class Initialized
INFO - 2020-02-02 08:40:37 --> URI Class Initialized
DEBUG - 2020-02-02 08:40:37 --> No URI present. Default controller set.
INFO - 2020-02-02 08:40:37 --> Router Class Initialized
INFO - 2020-02-02 08:40:37 --> Output Class Initialized
INFO - 2020-02-02 08:40:37 --> Security Class Initialized
DEBUG - 2020-02-02 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:40:37 --> Input Class Initialized
INFO - 2020-02-02 08:40:37 --> Language Class Initialized
INFO - 2020-02-02 08:40:37 --> Language Class Initialized
INFO - 2020-02-02 08:40:37 --> Config Class Initialized
INFO - 2020-02-02 08:40:37 --> Loader Class Initialized
INFO - 2020-02-02 08:40:37 --> Helper loaded: url_helper
INFO - 2020-02-02 08:40:37 --> Helper loaded: file_helper
INFO - 2020-02-02 08:40:37 --> Helper loaded: form_helper
INFO - 2020-02-02 08:40:37 --> Helper loaded: my_helper
INFO - 2020-02-02 08:40:38 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:40:38 --> Controller Class Initialized
ERROR - 2020-02-02 08:40:38 --> Severity: Notice --> Undefined variable: q_jml_gurup E:\xampp\htdocs\_2020\myraport\application\modules\home\controllers\Home.php 37
DEBUG - 2020-02-02 08:40:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:40:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:40:38 --> Final output sent to browser
DEBUG - 2020-02-02 08:40:38 --> Total execution time: 0.4877
INFO - 2020-02-02 08:40:50 --> Config Class Initialized
INFO - 2020-02-02 08:40:50 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:40:50 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:40:50 --> Utf8 Class Initialized
INFO - 2020-02-02 08:40:50 --> URI Class Initialized
DEBUG - 2020-02-02 08:40:50 --> No URI present. Default controller set.
INFO - 2020-02-02 08:40:50 --> Router Class Initialized
INFO - 2020-02-02 08:40:50 --> Output Class Initialized
INFO - 2020-02-02 08:40:50 --> Security Class Initialized
DEBUG - 2020-02-02 08:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:40:50 --> Input Class Initialized
INFO - 2020-02-02 08:40:50 --> Language Class Initialized
INFO - 2020-02-02 08:40:50 --> Language Class Initialized
INFO - 2020-02-02 08:40:50 --> Config Class Initialized
INFO - 2020-02-02 08:40:50 --> Loader Class Initialized
INFO - 2020-02-02 08:40:50 --> Helper loaded: url_helper
INFO - 2020-02-02 08:40:50 --> Helper loaded: file_helper
INFO - 2020-02-02 08:40:50 --> Helper loaded: form_helper
INFO - 2020-02-02 08:40:50 --> Helper loaded: my_helper
INFO - 2020-02-02 08:40:50 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:40:50 --> Controller Class Initialized
DEBUG - 2020-02-02 08:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:40:50 --> Final output sent to browser
DEBUG - 2020-02-02 08:40:50 --> Total execution time: 0.4846
INFO - 2020-02-02 08:41:07 --> Config Class Initialized
INFO - 2020-02-02 08:41:07 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:41:07 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:41:07 --> Utf8 Class Initialized
INFO - 2020-02-02 08:41:07 --> URI Class Initialized
DEBUG - 2020-02-02 08:41:07 --> No URI present. Default controller set.
INFO - 2020-02-02 08:41:07 --> Router Class Initialized
INFO - 2020-02-02 08:41:07 --> Output Class Initialized
INFO - 2020-02-02 08:41:07 --> Security Class Initialized
DEBUG - 2020-02-02 08:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:41:07 --> Input Class Initialized
INFO - 2020-02-02 08:41:07 --> Language Class Initialized
INFO - 2020-02-02 08:41:07 --> Language Class Initialized
INFO - 2020-02-02 08:41:07 --> Config Class Initialized
INFO - 2020-02-02 08:41:07 --> Loader Class Initialized
INFO - 2020-02-02 08:41:07 --> Helper loaded: url_helper
INFO - 2020-02-02 08:41:07 --> Helper loaded: file_helper
INFO - 2020-02-02 08:41:07 --> Helper loaded: form_helper
INFO - 2020-02-02 08:41:07 --> Helper loaded: my_helper
INFO - 2020-02-02 08:41:07 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:41:07 --> Controller Class Initialized
DEBUG - 2020-02-02 08:41:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:41:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:41:07 --> Final output sent to browser
DEBUG - 2020-02-02 08:41:07 --> Total execution time: 0.4752
INFO - 2020-02-02 08:41:16 --> Config Class Initialized
INFO - 2020-02-02 08:41:16 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:41:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:41:16 --> Utf8 Class Initialized
INFO - 2020-02-02 08:41:16 --> URI Class Initialized
DEBUG - 2020-02-02 08:41:16 --> No URI present. Default controller set.
INFO - 2020-02-02 08:41:16 --> Router Class Initialized
INFO - 2020-02-02 08:41:16 --> Output Class Initialized
INFO - 2020-02-02 08:41:16 --> Security Class Initialized
DEBUG - 2020-02-02 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:41:16 --> Input Class Initialized
INFO - 2020-02-02 08:41:16 --> Language Class Initialized
INFO - 2020-02-02 08:41:16 --> Language Class Initialized
INFO - 2020-02-02 08:41:16 --> Config Class Initialized
INFO - 2020-02-02 08:41:16 --> Loader Class Initialized
INFO - 2020-02-02 08:41:16 --> Helper loaded: url_helper
INFO - 2020-02-02 08:41:16 --> Helper loaded: file_helper
INFO - 2020-02-02 08:41:16 --> Helper loaded: form_helper
INFO - 2020-02-02 08:41:16 --> Helper loaded: my_helper
INFO - 2020-02-02 08:41:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:41:16 --> Controller Class Initialized
DEBUG - 2020-02-02 08:41:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:41:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:41:16 --> Final output sent to browser
DEBUG - 2020-02-02 08:41:16 --> Total execution time: 0.4840
INFO - 2020-02-02 08:41:53 --> Config Class Initialized
INFO - 2020-02-02 08:41:53 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:41:53 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:41:53 --> Utf8 Class Initialized
INFO - 2020-02-02 08:41:53 --> URI Class Initialized
DEBUG - 2020-02-02 08:41:53 --> No URI present. Default controller set.
INFO - 2020-02-02 08:41:53 --> Router Class Initialized
INFO - 2020-02-02 08:41:53 --> Output Class Initialized
INFO - 2020-02-02 08:41:53 --> Security Class Initialized
DEBUG - 2020-02-02 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:41:53 --> Input Class Initialized
INFO - 2020-02-02 08:41:53 --> Language Class Initialized
INFO - 2020-02-02 08:41:53 --> Language Class Initialized
INFO - 2020-02-02 08:41:53 --> Config Class Initialized
INFO - 2020-02-02 08:41:53 --> Loader Class Initialized
INFO - 2020-02-02 08:41:53 --> Helper loaded: url_helper
INFO - 2020-02-02 08:41:53 --> Helper loaded: file_helper
INFO - 2020-02-02 08:41:53 --> Helper loaded: form_helper
INFO - 2020-02-02 08:41:53 --> Helper loaded: my_helper
INFO - 2020-02-02 08:41:53 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:41:53 --> Controller Class Initialized
ERROR - 2020-02-02 08:41:54 --> Severity: Notice --> Undefined variable: stat_kelas E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 45
ERROR - 2020-02-02 08:41:54 --> Severity: Notice --> Undefined variable: stat_kelas E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 45
DEBUG - 2020-02-02 08:41:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:41:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:41:54 --> Final output sent to browser
DEBUG - 2020-02-02 08:41:54 --> Total execution time: 0.5384
INFO - 2020-02-02 08:42:25 --> Config Class Initialized
INFO - 2020-02-02 08:42:25 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:42:25 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:42:25 --> Utf8 Class Initialized
INFO - 2020-02-02 08:42:25 --> URI Class Initialized
DEBUG - 2020-02-02 08:42:25 --> No URI present. Default controller set.
INFO - 2020-02-02 08:42:25 --> Router Class Initialized
INFO - 2020-02-02 08:42:25 --> Output Class Initialized
INFO - 2020-02-02 08:42:25 --> Security Class Initialized
DEBUG - 2020-02-02 08:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:42:25 --> Input Class Initialized
INFO - 2020-02-02 08:42:25 --> Language Class Initialized
INFO - 2020-02-02 08:42:25 --> Language Class Initialized
INFO - 2020-02-02 08:42:26 --> Config Class Initialized
INFO - 2020-02-02 08:42:26 --> Loader Class Initialized
INFO - 2020-02-02 08:42:26 --> Helper loaded: url_helper
INFO - 2020-02-02 08:42:26 --> Helper loaded: file_helper
INFO - 2020-02-02 08:42:26 --> Helper loaded: form_helper
INFO - 2020-02-02 08:42:26 --> Helper loaded: my_helper
INFO - 2020-02-02 08:42:26 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:42:26 --> Controller Class Initialized
ERROR - 2020-02-02 08:42:26 --> Severity: Notice --> Undefined index: jmlk_l E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 45
ERROR - 2020-02-02 08:42:26 --> Severity: Notice --> Undefined index: jmlk_p E:\xampp\htdocs\_2020\myraport\application\modules\home\views\v_home.php 45
DEBUG - 2020-02-02 08:42:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:42:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:42:26 --> Final output sent to browser
DEBUG - 2020-02-02 08:42:26 --> Total execution time: 0.5068
INFO - 2020-02-02 08:42:38 --> Config Class Initialized
INFO - 2020-02-02 08:42:38 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:42:38 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:42:38 --> Utf8 Class Initialized
INFO - 2020-02-02 08:42:38 --> URI Class Initialized
DEBUG - 2020-02-02 08:42:38 --> No URI present. Default controller set.
INFO - 2020-02-02 08:42:38 --> Router Class Initialized
INFO - 2020-02-02 08:42:38 --> Output Class Initialized
INFO - 2020-02-02 08:42:38 --> Security Class Initialized
DEBUG - 2020-02-02 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:42:38 --> Input Class Initialized
INFO - 2020-02-02 08:42:38 --> Language Class Initialized
INFO - 2020-02-02 08:42:38 --> Language Class Initialized
INFO - 2020-02-02 08:42:38 --> Config Class Initialized
INFO - 2020-02-02 08:42:38 --> Loader Class Initialized
INFO - 2020-02-02 08:42:38 --> Helper loaded: url_helper
INFO - 2020-02-02 08:42:38 --> Helper loaded: file_helper
INFO - 2020-02-02 08:42:38 --> Helper loaded: form_helper
INFO - 2020-02-02 08:42:38 --> Helper loaded: my_helper
INFO - 2020-02-02 08:42:38 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:42:38 --> Controller Class Initialized
DEBUG - 2020-02-02 08:42:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:42:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:42:38 --> Final output sent to browser
DEBUG - 2020-02-02 08:42:38 --> Total execution time: 0.4828
INFO - 2020-02-02 08:42:47 --> Config Class Initialized
INFO - 2020-02-02 08:42:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:42:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:42:47 --> Utf8 Class Initialized
INFO - 2020-02-02 08:42:47 --> URI Class Initialized
DEBUG - 2020-02-02 08:42:47 --> No URI present. Default controller set.
INFO - 2020-02-02 08:42:47 --> Router Class Initialized
INFO - 2020-02-02 08:42:47 --> Output Class Initialized
INFO - 2020-02-02 08:42:47 --> Security Class Initialized
DEBUG - 2020-02-02 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:42:47 --> Input Class Initialized
INFO - 2020-02-02 08:42:48 --> Language Class Initialized
INFO - 2020-02-02 08:42:48 --> Language Class Initialized
INFO - 2020-02-02 08:42:48 --> Config Class Initialized
INFO - 2020-02-02 08:42:48 --> Loader Class Initialized
INFO - 2020-02-02 08:42:48 --> Helper loaded: url_helper
INFO - 2020-02-02 08:42:48 --> Helper loaded: file_helper
INFO - 2020-02-02 08:42:48 --> Helper loaded: form_helper
INFO - 2020-02-02 08:42:48 --> Helper loaded: my_helper
INFO - 2020-02-02 08:42:48 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:42:48 --> Controller Class Initialized
DEBUG - 2020-02-02 08:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:42:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:42:48 --> Final output sent to browser
DEBUG - 2020-02-02 08:42:48 --> Total execution time: 0.4949
INFO - 2020-02-02 08:43:03 --> Config Class Initialized
INFO - 2020-02-02 08:43:03 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:43:03 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:43:03 --> Utf8 Class Initialized
INFO - 2020-02-02 08:43:03 --> URI Class Initialized
DEBUG - 2020-02-02 08:43:03 --> No URI present. Default controller set.
INFO - 2020-02-02 08:43:03 --> Router Class Initialized
INFO - 2020-02-02 08:43:03 --> Output Class Initialized
INFO - 2020-02-02 08:43:03 --> Security Class Initialized
DEBUG - 2020-02-02 08:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:43:03 --> Input Class Initialized
INFO - 2020-02-02 08:43:03 --> Language Class Initialized
INFO - 2020-02-02 08:43:03 --> Language Class Initialized
INFO - 2020-02-02 08:43:03 --> Config Class Initialized
INFO - 2020-02-02 08:43:03 --> Loader Class Initialized
INFO - 2020-02-02 08:43:03 --> Helper loaded: url_helper
INFO - 2020-02-02 08:43:03 --> Helper loaded: file_helper
INFO - 2020-02-02 08:43:03 --> Helper loaded: form_helper
INFO - 2020-02-02 08:43:03 --> Helper loaded: my_helper
INFO - 2020-02-02 08:43:03 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:43:03 --> Controller Class Initialized
DEBUG - 2020-02-02 08:43:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:43:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:43:03 --> Final output sent to browser
DEBUG - 2020-02-02 08:43:04 --> Total execution time: 0.5377
INFO - 2020-02-02 08:43:30 --> Config Class Initialized
INFO - 2020-02-02 08:43:30 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:43:30 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:43:30 --> Utf8 Class Initialized
INFO - 2020-02-02 08:43:30 --> URI Class Initialized
DEBUG - 2020-02-02 08:43:30 --> No URI present. Default controller set.
INFO - 2020-02-02 08:43:30 --> Router Class Initialized
INFO - 2020-02-02 08:43:30 --> Output Class Initialized
INFO - 2020-02-02 08:43:30 --> Security Class Initialized
DEBUG - 2020-02-02 08:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:43:30 --> Input Class Initialized
INFO - 2020-02-02 08:43:30 --> Language Class Initialized
INFO - 2020-02-02 08:43:30 --> Language Class Initialized
INFO - 2020-02-02 08:43:30 --> Config Class Initialized
INFO - 2020-02-02 08:43:30 --> Loader Class Initialized
INFO - 2020-02-02 08:43:30 --> Helper loaded: url_helper
INFO - 2020-02-02 08:43:30 --> Helper loaded: file_helper
INFO - 2020-02-02 08:43:30 --> Helper loaded: form_helper
INFO - 2020-02-02 08:43:30 --> Helper loaded: my_helper
INFO - 2020-02-02 08:43:30 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:43:30 --> Controller Class Initialized
DEBUG - 2020-02-02 08:43:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:43:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:43:30 --> Final output sent to browser
DEBUG - 2020-02-02 08:43:31 --> Total execution time: 0.5360
INFO - 2020-02-02 08:43:42 --> Config Class Initialized
INFO - 2020-02-02 08:43:42 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:43:42 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:43:42 --> Utf8 Class Initialized
INFO - 2020-02-02 08:43:42 --> URI Class Initialized
DEBUG - 2020-02-02 08:43:42 --> No URI present. Default controller set.
INFO - 2020-02-02 08:43:42 --> Router Class Initialized
INFO - 2020-02-02 08:43:42 --> Output Class Initialized
INFO - 2020-02-02 08:43:42 --> Security Class Initialized
DEBUG - 2020-02-02 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:43:42 --> Input Class Initialized
INFO - 2020-02-02 08:43:42 --> Language Class Initialized
INFO - 2020-02-02 08:43:42 --> Language Class Initialized
INFO - 2020-02-02 08:43:42 --> Config Class Initialized
INFO - 2020-02-02 08:43:42 --> Loader Class Initialized
INFO - 2020-02-02 08:43:42 --> Helper loaded: url_helper
INFO - 2020-02-02 08:43:42 --> Helper loaded: file_helper
INFO - 2020-02-02 08:43:42 --> Helper loaded: form_helper
INFO - 2020-02-02 08:43:42 --> Helper loaded: my_helper
INFO - 2020-02-02 08:43:42 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:43:42 --> Controller Class Initialized
DEBUG - 2020-02-02 08:43:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:43:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:43:42 --> Final output sent to browser
DEBUG - 2020-02-02 08:43:42 --> Total execution time: 0.4812
INFO - 2020-02-02 08:45:14 --> Config Class Initialized
INFO - 2020-02-02 08:45:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:45:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:45:14 --> Utf8 Class Initialized
INFO - 2020-02-02 08:45:14 --> URI Class Initialized
DEBUG - 2020-02-02 08:45:14 --> No URI present. Default controller set.
INFO - 2020-02-02 08:45:14 --> Router Class Initialized
INFO - 2020-02-02 08:45:14 --> Output Class Initialized
INFO - 2020-02-02 08:45:14 --> Security Class Initialized
DEBUG - 2020-02-02 08:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:45:14 --> Input Class Initialized
INFO - 2020-02-02 08:45:14 --> Language Class Initialized
INFO - 2020-02-02 08:45:14 --> Language Class Initialized
INFO - 2020-02-02 08:45:14 --> Config Class Initialized
INFO - 2020-02-02 08:45:14 --> Loader Class Initialized
INFO - 2020-02-02 08:45:14 --> Helper loaded: url_helper
INFO - 2020-02-02 08:45:14 --> Helper loaded: file_helper
INFO - 2020-02-02 08:45:14 --> Helper loaded: form_helper
INFO - 2020-02-02 08:45:14 --> Helper loaded: my_helper
INFO - 2020-02-02 08:45:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:45:15 --> Controller Class Initialized
DEBUG - 2020-02-02 08:45:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:45:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:45:15 --> Final output sent to browser
DEBUG - 2020-02-02 08:45:15 --> Total execution time: 0.4934
INFO - 2020-02-02 08:45:32 --> Config Class Initialized
INFO - 2020-02-02 08:45:32 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:45:32 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:45:32 --> Utf8 Class Initialized
INFO - 2020-02-02 08:45:32 --> URI Class Initialized
DEBUG - 2020-02-02 08:45:32 --> No URI present. Default controller set.
INFO - 2020-02-02 08:45:32 --> Router Class Initialized
INFO - 2020-02-02 08:45:32 --> Output Class Initialized
INFO - 2020-02-02 08:45:32 --> Security Class Initialized
DEBUG - 2020-02-02 08:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:45:32 --> Input Class Initialized
INFO - 2020-02-02 08:45:32 --> Language Class Initialized
INFO - 2020-02-02 08:45:32 --> Language Class Initialized
INFO - 2020-02-02 08:45:32 --> Config Class Initialized
INFO - 2020-02-02 08:45:32 --> Loader Class Initialized
INFO - 2020-02-02 08:45:32 --> Helper loaded: url_helper
INFO - 2020-02-02 08:45:32 --> Helper loaded: file_helper
INFO - 2020-02-02 08:45:32 --> Helper loaded: form_helper
INFO - 2020-02-02 08:45:32 --> Helper loaded: my_helper
INFO - 2020-02-02 08:45:32 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:45:32 --> Controller Class Initialized
DEBUG - 2020-02-02 08:45:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:45:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:45:32 --> Final output sent to browser
DEBUG - 2020-02-02 08:45:32 --> Total execution time: 0.4741
INFO - 2020-02-02 08:47:04 --> Config Class Initialized
INFO - 2020-02-02 08:47:04 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:04 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:04 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:04 --> URI Class Initialized
DEBUG - 2020-02-02 08:47:04 --> No URI present. Default controller set.
INFO - 2020-02-02 08:47:04 --> Router Class Initialized
INFO - 2020-02-02 08:47:04 --> Output Class Initialized
INFO - 2020-02-02 08:47:04 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:04 --> Input Class Initialized
INFO - 2020-02-02 08:47:04 --> Language Class Initialized
INFO - 2020-02-02 08:47:04 --> Language Class Initialized
INFO - 2020-02-02 08:47:04 --> Config Class Initialized
INFO - 2020-02-02 08:47:04 --> Loader Class Initialized
INFO - 2020-02-02 08:47:04 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:04 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:04 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:04 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:04 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:04 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:47:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:04 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:04 --> Total execution time: 0.5452
INFO - 2020-02-02 08:47:14 --> Config Class Initialized
INFO - 2020-02-02 08:47:14 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:14 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:14 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:14 --> URI Class Initialized
DEBUG - 2020-02-02 08:47:14 --> No URI present. Default controller set.
INFO - 2020-02-02 08:47:14 --> Router Class Initialized
INFO - 2020-02-02 08:47:14 --> Output Class Initialized
INFO - 2020-02-02 08:47:14 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:14 --> Input Class Initialized
INFO - 2020-02-02 08:47:14 --> Language Class Initialized
INFO - 2020-02-02 08:47:14 --> Language Class Initialized
INFO - 2020-02-02 08:47:14 --> Config Class Initialized
INFO - 2020-02-02 08:47:14 --> Loader Class Initialized
INFO - 2020-02-02 08:47:15 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:15 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:15 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:15 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:15 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:15 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:47:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:15 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:15 --> Total execution time: 0.5608
INFO - 2020-02-02 08:47:16 --> Config Class Initialized
INFO - 2020-02-02 08:47:16 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:16 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:16 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:16 --> URI Class Initialized
INFO - 2020-02-02 08:47:16 --> Router Class Initialized
INFO - 2020-02-02 08:47:16 --> Output Class Initialized
INFO - 2020-02-02 08:47:16 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:16 --> Input Class Initialized
INFO - 2020-02-02 08:47:16 --> Language Class Initialized
INFO - 2020-02-02 08:47:16 --> Language Class Initialized
INFO - 2020-02-02 08:47:16 --> Config Class Initialized
INFO - 2020-02-02 08:47:16 --> Loader Class Initialized
INFO - 2020-02-02 08:47:16 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:16 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:16 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:16 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:16 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:17 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-02 08:47:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:17 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:17 --> Total execution time: 0.4762
INFO - 2020-02-02 08:47:17 --> Config Class Initialized
INFO - 2020-02-02 08:47:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:17 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:17 --> URI Class Initialized
INFO - 2020-02-02 08:47:17 --> Router Class Initialized
INFO - 2020-02-02 08:47:17 --> Output Class Initialized
INFO - 2020-02-02 08:47:17 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:17 --> Input Class Initialized
INFO - 2020-02-02 08:47:17 --> Language Class Initialized
INFO - 2020-02-02 08:47:17 --> Language Class Initialized
INFO - 2020-02-02 08:47:17 --> Config Class Initialized
INFO - 2020-02-02 08:47:17 --> Loader Class Initialized
INFO - 2020-02-02 08:47:17 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:17 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:17 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:17 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:17 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:17 --> Controller Class Initialized
INFO - 2020-02-02 08:47:21 --> Config Class Initialized
INFO - 2020-02-02 08:47:21 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:21 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:21 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:21 --> URI Class Initialized
DEBUG - 2020-02-02 08:47:21 --> No URI present. Default controller set.
INFO - 2020-02-02 08:47:21 --> Router Class Initialized
INFO - 2020-02-02 08:47:21 --> Output Class Initialized
INFO - 2020-02-02 08:47:21 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:21 --> Input Class Initialized
INFO - 2020-02-02 08:47:21 --> Language Class Initialized
INFO - 2020-02-02 08:47:21 --> Language Class Initialized
INFO - 2020-02-02 08:47:22 --> Config Class Initialized
INFO - 2020-02-02 08:47:22 --> Loader Class Initialized
INFO - 2020-02-02 08:47:22 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:22 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:22 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:22 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:22 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:22 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:47:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:22 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:22 --> Total execution time: 0.5527
INFO - 2020-02-02 08:47:28 --> Config Class Initialized
INFO - 2020-02-02 08:47:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:28 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:28 --> URI Class Initialized
INFO - 2020-02-02 08:47:28 --> Router Class Initialized
INFO - 2020-02-02 08:47:28 --> Output Class Initialized
INFO - 2020-02-02 08:47:28 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:28 --> Input Class Initialized
INFO - 2020-02-02 08:47:28 --> Language Class Initialized
INFO - 2020-02-02 08:47:28 --> Language Class Initialized
INFO - 2020-02-02 08:47:28 --> Config Class Initialized
INFO - 2020-02-02 08:47:28 --> Loader Class Initialized
INFO - 2020-02-02 08:47:28 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:28 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:28 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:28 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:28 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:28 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-02 08:47:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:28 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:28 --> Total execution time: 0.4832
INFO - 2020-02-02 08:47:28 --> Config Class Initialized
INFO - 2020-02-02 08:47:28 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:28 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:28 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:28 --> URI Class Initialized
INFO - 2020-02-02 08:47:29 --> Router Class Initialized
INFO - 2020-02-02 08:47:29 --> Output Class Initialized
INFO - 2020-02-02 08:47:29 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:29 --> Input Class Initialized
INFO - 2020-02-02 08:47:29 --> Language Class Initialized
INFO - 2020-02-02 08:47:29 --> Language Class Initialized
INFO - 2020-02-02 08:47:29 --> Config Class Initialized
INFO - 2020-02-02 08:47:29 --> Loader Class Initialized
INFO - 2020-02-02 08:47:29 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:29 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:29 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:29 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:29 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:29 --> Controller Class Initialized
INFO - 2020-02-02 08:47:34 --> Config Class Initialized
INFO - 2020-02-02 08:47:34 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:34 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:34 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:35 --> URI Class Initialized
DEBUG - 2020-02-02 08:47:35 --> No URI present. Default controller set.
INFO - 2020-02-02 08:47:35 --> Router Class Initialized
INFO - 2020-02-02 08:47:35 --> Output Class Initialized
INFO - 2020-02-02 08:47:35 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:35 --> Input Class Initialized
INFO - 2020-02-02 08:47:35 --> Language Class Initialized
INFO - 2020-02-02 08:47:35 --> Language Class Initialized
INFO - 2020-02-02 08:47:35 --> Config Class Initialized
INFO - 2020-02-02 08:47:35 --> Loader Class Initialized
INFO - 2020-02-02 08:47:35 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:35 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:35 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:35 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:35 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:35 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:47:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:35 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:35 --> Total execution time: 0.4816
INFO - 2020-02-02 08:47:47 --> Config Class Initialized
INFO - 2020-02-02 08:47:47 --> Hooks Class Initialized
DEBUG - 2020-02-02 08:47:47 --> UTF-8 Support Enabled
INFO - 2020-02-02 08:47:47 --> Utf8 Class Initialized
INFO - 2020-02-02 08:47:47 --> URI Class Initialized
DEBUG - 2020-02-02 08:47:47 --> No URI present. Default controller set.
INFO - 2020-02-02 08:47:47 --> Router Class Initialized
INFO - 2020-02-02 08:47:47 --> Output Class Initialized
INFO - 2020-02-02 08:47:47 --> Security Class Initialized
DEBUG - 2020-02-02 08:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 08:47:47 --> Input Class Initialized
INFO - 2020-02-02 08:47:47 --> Language Class Initialized
INFO - 2020-02-02 08:47:47 --> Language Class Initialized
INFO - 2020-02-02 08:47:47 --> Config Class Initialized
INFO - 2020-02-02 08:47:47 --> Loader Class Initialized
INFO - 2020-02-02 08:47:47 --> Helper loaded: url_helper
INFO - 2020-02-02 08:47:47 --> Helper loaded: file_helper
INFO - 2020-02-02 08:47:47 --> Helper loaded: form_helper
INFO - 2020-02-02 08:47:47 --> Helper loaded: my_helper
INFO - 2020-02-02 08:47:47 --> Database Driver Class Initialized
DEBUG - 2020-02-02 08:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 08:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 08:47:47 --> Controller Class Initialized
DEBUG - 2020-02-02 08:47:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-02 08:47:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 08:47:48 --> Final output sent to browser
DEBUG - 2020-02-02 08:47:48 --> Total execution time: 0.4840
INFO - 2020-02-02 14:05:17 --> Config Class Initialized
INFO - 2020-02-02 14:05:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 14:05:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 14:05:17 --> Utf8 Class Initialized
INFO - 2020-02-02 14:05:17 --> URI Class Initialized
INFO - 2020-02-02 14:05:17 --> Router Class Initialized
INFO - 2020-02-02 14:05:17 --> Output Class Initialized
INFO - 2020-02-02 14:05:17 --> Security Class Initialized
DEBUG - 2020-02-02 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 14:05:17 --> Input Class Initialized
INFO - 2020-02-02 14:05:17 --> Language Class Initialized
INFO - 2020-02-02 14:05:17 --> Language Class Initialized
INFO - 2020-02-02 14:05:17 --> Config Class Initialized
INFO - 2020-02-02 14:05:17 --> Loader Class Initialized
INFO - 2020-02-02 14:05:17 --> Helper loaded: url_helper
INFO - 2020-02-02 14:05:17 --> Helper loaded: file_helper
INFO - 2020-02-02 14:05:17 --> Helper loaded: form_helper
INFO - 2020-02-02 14:05:17 --> Helper loaded: my_helper
INFO - 2020-02-02 14:05:17 --> Database Driver Class Initialized
DEBUG - 2020-02-02 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 14:05:17 --> Controller Class Initialized
INFO - 2020-02-02 14:05:17 --> Config Class Initialized
INFO - 2020-02-02 14:05:17 --> Hooks Class Initialized
DEBUG - 2020-02-02 14:05:17 --> UTF-8 Support Enabled
INFO - 2020-02-02 14:05:17 --> Utf8 Class Initialized
INFO - 2020-02-02 14:05:17 --> URI Class Initialized
INFO - 2020-02-02 14:05:17 --> Router Class Initialized
INFO - 2020-02-02 14:05:17 --> Output Class Initialized
INFO - 2020-02-02 14:05:17 --> Security Class Initialized
DEBUG - 2020-02-02 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 14:05:17 --> Input Class Initialized
INFO - 2020-02-02 14:05:18 --> Language Class Initialized
INFO - 2020-02-02 14:05:18 --> Language Class Initialized
INFO - 2020-02-02 14:05:18 --> Config Class Initialized
INFO - 2020-02-02 14:05:18 --> Loader Class Initialized
INFO - 2020-02-02 14:05:18 --> Helper loaded: url_helper
INFO - 2020-02-02 14:05:18 --> Helper loaded: file_helper
INFO - 2020-02-02 14:05:18 --> Helper loaded: form_helper
INFO - 2020-02-02 14:05:18 --> Helper loaded: my_helper
INFO - 2020-02-02 14:05:18 --> Database Driver Class Initialized
DEBUG - 2020-02-02 14:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 14:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 14:05:18 --> Controller Class Initialized
DEBUG - 2020-02-02 14:05:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/unauthorized_access/views/no_akses.php
DEBUG - 2020-02-02 14:05:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 14:05:18 --> Final output sent to browser
DEBUG - 2020-02-02 14:05:18 --> Total execution time: 0.4552
INFO - 2020-02-02 14:05:24 --> Config Class Initialized
INFO - 2020-02-02 14:05:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 14:05:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 14:05:24 --> Utf8 Class Initialized
INFO - 2020-02-02 14:05:24 --> URI Class Initialized
DEBUG - 2020-02-02 14:05:24 --> No URI present. Default controller set.
INFO - 2020-02-02 14:05:24 --> Router Class Initialized
INFO - 2020-02-02 14:05:24 --> Output Class Initialized
INFO - 2020-02-02 14:05:24 --> Security Class Initialized
DEBUG - 2020-02-02 14:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 14:05:24 --> Input Class Initialized
INFO - 2020-02-02 14:05:24 --> Language Class Initialized
INFO - 2020-02-02 14:05:24 --> Language Class Initialized
INFO - 2020-02-02 14:05:24 --> Config Class Initialized
INFO - 2020-02-02 14:05:24 --> Loader Class Initialized
INFO - 2020-02-02 14:05:24 --> Helper loaded: url_helper
INFO - 2020-02-02 14:05:24 --> Helper loaded: file_helper
INFO - 2020-02-02 14:05:24 --> Helper loaded: form_helper
INFO - 2020-02-02 14:05:24 --> Helper loaded: my_helper
INFO - 2020-02-02 14:05:24 --> Database Driver Class Initialized
DEBUG - 2020-02-02 14:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 14:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 14:05:24 --> Controller Class Initialized
INFO - 2020-02-02 14:05:24 --> Config Class Initialized
INFO - 2020-02-02 14:05:24 --> Hooks Class Initialized
DEBUG - 2020-02-02 14:05:24 --> UTF-8 Support Enabled
INFO - 2020-02-02 14:05:24 --> Utf8 Class Initialized
INFO - 2020-02-02 14:05:24 --> URI Class Initialized
INFO - 2020-02-02 14:05:24 --> Router Class Initialized
INFO - 2020-02-02 14:05:24 --> Output Class Initialized
INFO - 2020-02-02 14:05:24 --> Security Class Initialized
DEBUG - 2020-02-02 14:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-02 14:05:25 --> Input Class Initialized
INFO - 2020-02-02 14:05:25 --> Language Class Initialized
INFO - 2020-02-02 14:05:25 --> Language Class Initialized
INFO - 2020-02-02 14:05:25 --> Config Class Initialized
INFO - 2020-02-02 14:05:25 --> Loader Class Initialized
INFO - 2020-02-02 14:05:25 --> Helper loaded: url_helper
INFO - 2020-02-02 14:05:25 --> Helper loaded: file_helper
INFO - 2020-02-02 14:05:25 --> Helper loaded: form_helper
INFO - 2020-02-02 14:05:25 --> Helper loaded: my_helper
INFO - 2020-02-02 14:05:25 --> Database Driver Class Initialized
DEBUG - 2020-02-02 14:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-02 14:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-02 14:05:25 --> Controller Class Initialized
DEBUG - 2020-02-02 14:05:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-02 14:05:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-02 14:05:25 --> Final output sent to browser
DEBUG - 2020-02-02 14:05:25 --> Total execution time: 0.4435
