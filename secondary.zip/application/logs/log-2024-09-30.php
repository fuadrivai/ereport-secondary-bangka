<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-30 07:48:51 --> Config Class Initialized
INFO - 2024-09-30 07:48:52 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:48:52 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:48:52 --> Utf8 Class Initialized
INFO - 2024-09-30 07:48:52 --> URI Class Initialized
INFO - 2024-09-30 07:48:52 --> Router Class Initialized
INFO - 2024-09-30 07:48:52 --> Output Class Initialized
INFO - 2024-09-30 07:48:52 --> Security Class Initialized
DEBUG - 2024-09-30 07:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:48:52 --> Input Class Initialized
INFO - 2024-09-30 07:48:52 --> Language Class Initialized
INFO - 2024-09-30 07:48:52 --> Language Class Initialized
INFO - 2024-09-30 07:48:52 --> Config Class Initialized
INFO - 2024-09-30 07:48:52 --> Loader Class Initialized
INFO - 2024-09-30 07:48:52 --> Helper loaded: url_helper
INFO - 2024-09-30 07:48:52 --> Helper loaded: file_helper
INFO - 2024-09-30 07:48:52 --> Helper loaded: form_helper
INFO - 2024-09-30 07:48:52 --> Helper loaded: my_helper
INFO - 2024-09-30 07:48:52 --> Database Driver Class Initialized
ERROR - 2024-09-30 07:48:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-09-30 07:48:52 --> Unable to connect to the database
INFO - 2024-09-30 07:48:52 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-30 07:50:26 --> Config Class Initialized
INFO - 2024-09-30 07:50:26 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:50:26 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:50:26 --> Utf8 Class Initialized
INFO - 2024-09-30 07:50:26 --> URI Class Initialized
INFO - 2024-09-30 07:50:26 --> Router Class Initialized
INFO - 2024-09-30 07:50:26 --> Output Class Initialized
INFO - 2024-09-30 07:50:26 --> Security Class Initialized
DEBUG - 2024-09-30 07:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:50:26 --> Input Class Initialized
INFO - 2024-09-30 07:50:26 --> Language Class Initialized
INFO - 2024-09-30 07:50:26 --> Language Class Initialized
INFO - 2024-09-30 07:50:26 --> Config Class Initialized
INFO - 2024-09-30 07:50:26 --> Loader Class Initialized
INFO - 2024-09-30 07:50:26 --> Helper loaded: url_helper
INFO - 2024-09-30 07:50:26 --> Helper loaded: file_helper
INFO - 2024-09-30 07:50:26 --> Helper loaded: form_helper
INFO - 2024-09-30 07:50:26 --> Helper loaded: my_helper
INFO - 2024-09-30 07:50:26 --> Database Driver Class Initialized
ERROR - 2024-09-30 07:50:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-09-30 07:50:26 --> Unable to connect to the database
INFO - 2024-09-30 07:50:26 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-30 07:52:40 --> Config Class Initialized
INFO - 2024-09-30 07:52:40 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:52:40 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:52:40 --> Utf8 Class Initialized
INFO - 2024-09-30 07:52:40 --> URI Class Initialized
INFO - 2024-09-30 07:52:40 --> Router Class Initialized
INFO - 2024-09-30 07:52:40 --> Output Class Initialized
INFO - 2024-09-30 07:52:40 --> Security Class Initialized
DEBUG - 2024-09-30 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:52:40 --> Input Class Initialized
INFO - 2024-09-30 07:52:40 --> Language Class Initialized
INFO - 2024-09-30 07:52:40 --> Language Class Initialized
INFO - 2024-09-30 07:52:40 --> Config Class Initialized
INFO - 2024-09-30 07:52:40 --> Loader Class Initialized
INFO - 2024-09-30 07:52:40 --> Helper loaded: url_helper
INFO - 2024-09-30 07:52:40 --> Helper loaded: file_helper
INFO - 2024-09-30 07:52:40 --> Helper loaded: form_helper
INFO - 2024-09-30 07:52:40 --> Helper loaded: my_helper
INFO - 2024-09-30 07:52:40 --> Database Driver Class Initialized
INFO - 2024-09-30 07:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:52:40 --> Controller Class Initialized
DEBUG - 2024-09-30 07:52:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-30 07:52:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:52:40 --> Final output sent to browser
DEBUG - 2024-09-30 07:52:40 --> Total execution time: 0.0499
INFO - 2024-09-30 07:52:49 --> Config Class Initialized
INFO - 2024-09-30 07:52:49 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:52:49 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:52:49 --> Utf8 Class Initialized
INFO - 2024-09-30 07:52:49 --> URI Class Initialized
INFO - 2024-09-30 07:52:49 --> Router Class Initialized
INFO - 2024-09-30 07:52:49 --> Output Class Initialized
INFO - 2024-09-30 07:52:49 --> Security Class Initialized
DEBUG - 2024-09-30 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:52:49 --> Input Class Initialized
INFO - 2024-09-30 07:52:49 --> Language Class Initialized
INFO - 2024-09-30 07:52:49 --> Language Class Initialized
INFO - 2024-09-30 07:52:49 --> Config Class Initialized
INFO - 2024-09-30 07:52:49 --> Loader Class Initialized
INFO - 2024-09-30 07:52:49 --> Helper loaded: url_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: file_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: form_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: my_helper
INFO - 2024-09-30 07:52:49 --> Database Driver Class Initialized
INFO - 2024-09-30 07:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:52:49 --> Controller Class Initialized
INFO - 2024-09-30 07:52:49 --> Helper loaded: cookie_helper
INFO - 2024-09-30 07:52:49 --> Final output sent to browser
DEBUG - 2024-09-30 07:52:49 --> Total execution time: 0.0411
INFO - 2024-09-30 07:52:49 --> Config Class Initialized
INFO - 2024-09-30 07:52:49 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:52:49 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:52:49 --> Utf8 Class Initialized
INFO - 2024-09-30 07:52:49 --> URI Class Initialized
INFO - 2024-09-30 07:52:49 --> Router Class Initialized
INFO - 2024-09-30 07:52:49 --> Output Class Initialized
INFO - 2024-09-30 07:52:49 --> Security Class Initialized
DEBUG - 2024-09-30 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:52:49 --> Input Class Initialized
INFO - 2024-09-30 07:52:49 --> Language Class Initialized
INFO - 2024-09-30 07:52:49 --> Language Class Initialized
INFO - 2024-09-30 07:52:49 --> Config Class Initialized
INFO - 2024-09-30 07:52:49 --> Loader Class Initialized
INFO - 2024-09-30 07:52:49 --> Helper loaded: url_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: file_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: form_helper
INFO - 2024-09-30 07:52:49 --> Helper loaded: my_helper
INFO - 2024-09-30 07:52:49 --> Database Driver Class Initialized
INFO - 2024-09-30 07:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:52:49 --> Controller Class Initialized
DEBUG - 2024-09-30 07:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-30 07:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:52:49 --> Final output sent to browser
DEBUG - 2024-09-30 07:52:49 --> Total execution time: 0.0442
INFO - 2024-09-30 07:53:54 --> Config Class Initialized
INFO - 2024-09-30 07:53:54 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:53:54 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:53:54 --> Utf8 Class Initialized
INFO - 2024-09-30 07:53:54 --> URI Class Initialized
INFO - 2024-09-30 07:53:54 --> Router Class Initialized
INFO - 2024-09-30 07:53:54 --> Output Class Initialized
INFO - 2024-09-30 07:53:54 --> Security Class Initialized
DEBUG - 2024-09-30 07:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:53:54 --> Input Class Initialized
INFO - 2024-09-30 07:53:54 --> Language Class Initialized
INFO - 2024-09-30 07:53:54 --> Language Class Initialized
INFO - 2024-09-30 07:53:54 --> Config Class Initialized
INFO - 2024-09-30 07:53:54 --> Loader Class Initialized
INFO - 2024-09-30 07:53:54 --> Helper loaded: url_helper
INFO - 2024-09-30 07:53:54 --> Helper loaded: file_helper
INFO - 2024-09-30 07:53:54 --> Helper loaded: form_helper
INFO - 2024-09-30 07:53:54 --> Helper loaded: my_helper
INFO - 2024-09-30 07:53:54 --> Database Driver Class Initialized
INFO - 2024-09-30 07:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:53:54 --> Controller Class Initialized
DEBUG - 2024-09-30 07:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:53:54 --> Final output sent to browser
DEBUG - 2024-09-30 07:53:54 --> Total execution time: 0.0298
INFO - 2024-09-30 07:54:08 --> Config Class Initialized
INFO - 2024-09-30 07:54:08 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:08 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:08 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:08 --> URI Class Initialized
INFO - 2024-09-30 07:54:08 --> Router Class Initialized
INFO - 2024-09-30 07:54:08 --> Output Class Initialized
INFO - 2024-09-30 07:54:08 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:08 --> Input Class Initialized
INFO - 2024-09-30 07:54:08 --> Language Class Initialized
INFO - 2024-09-30 07:54:08 --> Language Class Initialized
INFO - 2024-09-30 07:54:08 --> Config Class Initialized
INFO - 2024-09-30 07:54:08 --> Loader Class Initialized
INFO - 2024-09-30 07:54:08 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:08 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:08 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-09-30 07:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:08 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:08 --> Total execution time: 0.1262
INFO - 2024-09-30 07:54:08 --> Config Class Initialized
INFO - 2024-09-30 07:54:08 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:08 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:08 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:08 --> URI Class Initialized
INFO - 2024-09-30 07:54:08 --> Router Class Initialized
INFO - 2024-09-30 07:54:08 --> Output Class Initialized
INFO - 2024-09-30 07:54:08 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:08 --> Input Class Initialized
INFO - 2024-09-30 07:54:08 --> Language Class Initialized
INFO - 2024-09-30 07:54:08 --> Language Class Initialized
INFO - 2024-09-30 07:54:08 --> Config Class Initialized
INFO - 2024-09-30 07:54:08 --> Loader Class Initialized
INFO - 2024-09-30 07:54:08 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:08 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:08 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:08 --> Controller Class Initialized
INFO - 2024-09-30 07:54:13 --> Config Class Initialized
INFO - 2024-09-30 07:54:13 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:13 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:13 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:13 --> URI Class Initialized
INFO - 2024-09-30 07:54:13 --> Router Class Initialized
INFO - 2024-09-30 07:54:13 --> Output Class Initialized
INFO - 2024-09-30 07:54:13 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:13 --> Input Class Initialized
INFO - 2024-09-30 07:54:13 --> Language Class Initialized
INFO - 2024-09-30 07:54:13 --> Language Class Initialized
INFO - 2024-09-30 07:54:13 --> Config Class Initialized
INFO - 2024-09-30 07:54:13 --> Loader Class Initialized
INFO - 2024-09-30 07:54:13 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:13 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:13 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:13 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:13 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:13 --> Controller Class Initialized
INFO - 2024-09-30 07:54:13 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:13 --> Total execution time: 0.0477
INFO - 2024-09-30 07:54:15 --> Config Class Initialized
INFO - 2024-09-30 07:54:15 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:15 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:15 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:15 --> URI Class Initialized
INFO - 2024-09-30 07:54:15 --> Router Class Initialized
INFO - 2024-09-30 07:54:15 --> Output Class Initialized
INFO - 2024-09-30 07:54:15 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:15 --> Input Class Initialized
INFO - 2024-09-30 07:54:15 --> Language Class Initialized
INFO - 2024-09-30 07:54:15 --> Language Class Initialized
INFO - 2024-09-30 07:54:15 --> Config Class Initialized
INFO - 2024-09-30 07:54:15 --> Loader Class Initialized
INFO - 2024-09-30 07:54:15 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:15 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:15 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:15 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:15 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:15 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-30 07:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:15 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:15 --> Total execution time: 0.0271
INFO - 2024-09-30 07:54:18 --> Config Class Initialized
INFO - 2024-09-30 07:54:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:18 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:18 --> URI Class Initialized
INFO - 2024-09-30 07:54:18 --> Router Class Initialized
INFO - 2024-09-30 07:54:18 --> Output Class Initialized
INFO - 2024-09-30 07:54:18 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:18 --> Input Class Initialized
INFO - 2024-09-30 07:54:18 --> Language Class Initialized
INFO - 2024-09-30 07:54:18 --> Language Class Initialized
INFO - 2024-09-30 07:54:18 --> Config Class Initialized
INFO - 2024-09-30 07:54:18 --> Loader Class Initialized
INFO - 2024-09-30 07:54:18 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:18 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:18 --> Controller Class Initialized
INFO - 2024-09-30 07:54:18 --> Helper loaded: cookie_helper
INFO - 2024-09-30 07:54:18 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:18 --> Total execution time: 0.0316
INFO - 2024-09-30 07:54:18 --> Config Class Initialized
INFO - 2024-09-30 07:54:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:18 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:18 --> URI Class Initialized
INFO - 2024-09-30 07:54:18 --> Router Class Initialized
INFO - 2024-09-30 07:54:18 --> Output Class Initialized
INFO - 2024-09-30 07:54:18 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:18 --> Input Class Initialized
INFO - 2024-09-30 07:54:18 --> Language Class Initialized
INFO - 2024-09-30 07:54:18 --> Language Class Initialized
INFO - 2024-09-30 07:54:18 --> Config Class Initialized
INFO - 2024-09-30 07:54:18 --> Loader Class Initialized
INFO - 2024-09-30 07:54:18 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:18 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:18 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:18 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-30 07:54:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:18 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:18 --> Total execution time: 0.0284
INFO - 2024-09-30 07:54:25 --> Config Class Initialized
INFO - 2024-09-30 07:54:25 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:25 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:25 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:25 --> URI Class Initialized
INFO - 2024-09-30 07:54:25 --> Router Class Initialized
INFO - 2024-09-30 07:54:25 --> Output Class Initialized
INFO - 2024-09-30 07:54:25 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:25 --> Input Class Initialized
INFO - 2024-09-30 07:54:25 --> Language Class Initialized
INFO - 2024-09-30 07:54:25 --> Language Class Initialized
INFO - 2024-09-30 07:54:25 --> Config Class Initialized
INFO - 2024-09-30 07:54:25 --> Loader Class Initialized
INFO - 2024-09-30 07:54:25 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:25 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:25 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:25 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:25 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:25 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:25 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:25 --> Total execution time: 0.0514
INFO - 2024-09-30 07:54:31 --> Config Class Initialized
INFO - 2024-09-30 07:54:31 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:31 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:31 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:31 --> URI Class Initialized
INFO - 2024-09-30 07:54:31 --> Router Class Initialized
INFO - 2024-09-30 07:54:31 --> Output Class Initialized
INFO - 2024-09-30 07:54:31 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:31 --> Input Class Initialized
INFO - 2024-09-30 07:54:31 --> Language Class Initialized
INFO - 2024-09-30 07:54:31 --> Language Class Initialized
INFO - 2024-09-30 07:54:31 --> Config Class Initialized
INFO - 2024-09-30 07:54:31 --> Loader Class Initialized
INFO - 2024-09-30 07:54:31 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:31 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:31 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-09-30 07:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:31 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:31 --> Total execution time: 0.0332
INFO - 2024-09-30 07:54:31 --> Config Class Initialized
INFO - 2024-09-30 07:54:31 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:31 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:31 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:31 --> URI Class Initialized
INFO - 2024-09-30 07:54:31 --> Router Class Initialized
INFO - 2024-09-30 07:54:31 --> Output Class Initialized
INFO - 2024-09-30 07:54:31 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:31 --> Input Class Initialized
INFO - 2024-09-30 07:54:31 --> Language Class Initialized
INFO - 2024-09-30 07:54:31 --> Language Class Initialized
INFO - 2024-09-30 07:54:31 --> Config Class Initialized
INFO - 2024-09-30 07:54:31 --> Loader Class Initialized
INFO - 2024-09-30 07:54:31 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:31 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:31 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:31 --> Controller Class Initialized
INFO - 2024-09-30 07:54:34 --> Config Class Initialized
INFO - 2024-09-30 07:54:34 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:34 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:34 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:34 --> URI Class Initialized
INFO - 2024-09-30 07:54:34 --> Router Class Initialized
INFO - 2024-09-30 07:54:34 --> Output Class Initialized
INFO - 2024-09-30 07:54:34 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:34 --> Input Class Initialized
INFO - 2024-09-30 07:54:34 --> Language Class Initialized
INFO - 2024-09-30 07:54:34 --> Language Class Initialized
INFO - 2024-09-30 07:54:34 --> Config Class Initialized
INFO - 2024-09-30 07:54:34 --> Loader Class Initialized
INFO - 2024-09-30 07:54:34 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:34 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:34 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:34 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:34 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:34 --> Controller Class Initialized
INFO - 2024-09-30 07:54:34 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:34 --> Total execution time: 0.0418
INFO - 2024-09-30 07:54:48 --> Config Class Initialized
INFO - 2024-09-30 07:54:48 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:48 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:48 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:48 --> URI Class Initialized
INFO - 2024-09-30 07:54:48 --> Router Class Initialized
INFO - 2024-09-30 07:54:48 --> Output Class Initialized
INFO - 2024-09-30 07:54:48 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:48 --> Input Class Initialized
INFO - 2024-09-30 07:54:48 --> Language Class Initialized
INFO - 2024-09-30 07:54:48 --> Language Class Initialized
INFO - 2024-09-30 07:54:48 --> Config Class Initialized
INFO - 2024-09-30 07:54:48 --> Loader Class Initialized
INFO - 2024-09-30 07:54:48 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:48 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:48 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:48 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:48 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:48 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:54:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:48 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:48 --> Total execution time: 0.0323
INFO - 2024-09-30 07:54:49 --> Config Class Initialized
INFO - 2024-09-30 07:54:49 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:49 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:49 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:49 --> URI Class Initialized
INFO - 2024-09-30 07:54:49 --> Router Class Initialized
INFO - 2024-09-30 07:54:49 --> Output Class Initialized
INFO - 2024-09-30 07:54:49 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:49 --> Input Class Initialized
INFO - 2024-09-30 07:54:49 --> Language Class Initialized
INFO - 2024-09-30 07:54:49 --> Language Class Initialized
INFO - 2024-09-30 07:54:49 --> Config Class Initialized
INFO - 2024-09-30 07:54:49 --> Loader Class Initialized
INFO - 2024-09-30 07:54:49 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:49 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:49 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:49 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:49 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:49 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:49 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:49 --> Total execution time: 0.0952
INFO - 2024-09-30 07:54:51 --> Config Class Initialized
INFO - 2024-09-30 07:54:51 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:51 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:51 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:51 --> URI Class Initialized
INFO - 2024-09-30 07:54:51 --> Router Class Initialized
INFO - 2024-09-30 07:54:51 --> Output Class Initialized
INFO - 2024-09-30 07:54:51 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:51 --> Input Class Initialized
INFO - 2024-09-30 07:54:51 --> Language Class Initialized
INFO - 2024-09-30 07:54:51 --> Language Class Initialized
INFO - 2024-09-30 07:54:51 --> Config Class Initialized
INFO - 2024-09-30 07:54:51 --> Loader Class Initialized
INFO - 2024-09-30 07:54:51 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:51 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:51 --> Controller Class Initialized
DEBUG - 2024-09-30 07:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 07:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:54:51 --> Final output sent to browser
DEBUG - 2024-09-30 07:54:51 --> Total execution time: 0.0312
INFO - 2024-09-30 07:54:51 --> Config Class Initialized
INFO - 2024-09-30 07:54:51 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:54:51 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:54:51 --> Utf8 Class Initialized
INFO - 2024-09-30 07:54:51 --> URI Class Initialized
INFO - 2024-09-30 07:54:51 --> Router Class Initialized
INFO - 2024-09-30 07:54:51 --> Output Class Initialized
INFO - 2024-09-30 07:54:51 --> Security Class Initialized
DEBUG - 2024-09-30 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:54:51 --> Input Class Initialized
INFO - 2024-09-30 07:54:51 --> Language Class Initialized
INFO - 2024-09-30 07:54:51 --> Language Class Initialized
INFO - 2024-09-30 07:54:51 --> Config Class Initialized
INFO - 2024-09-30 07:54:51 --> Loader Class Initialized
INFO - 2024-09-30 07:54:51 --> Helper loaded: url_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: file_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: form_helper
INFO - 2024-09-30 07:54:51 --> Helper loaded: my_helper
INFO - 2024-09-30 07:54:51 --> Database Driver Class Initialized
INFO - 2024-09-30 07:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:54:51 --> Controller Class Initialized
INFO - 2024-09-30 07:55:00 --> Config Class Initialized
INFO - 2024-09-30 07:55:00 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:00 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:00 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:00 --> URI Class Initialized
INFO - 2024-09-30 07:55:00 --> Router Class Initialized
INFO - 2024-09-30 07:55:00 --> Output Class Initialized
INFO - 2024-09-30 07:55:00 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:00 --> Input Class Initialized
INFO - 2024-09-30 07:55:00 --> Language Class Initialized
INFO - 2024-09-30 07:55:00 --> Language Class Initialized
INFO - 2024-09-30 07:55:00 --> Config Class Initialized
INFO - 2024-09-30 07:55:00 --> Loader Class Initialized
INFO - 2024-09-30 07:55:00 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:00 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:00 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 07:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:00 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:00 --> Total execution time: 0.0352
INFO - 2024-09-30 07:55:00 --> Config Class Initialized
INFO - 2024-09-30 07:55:00 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:00 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:00 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:00 --> URI Class Initialized
INFO - 2024-09-30 07:55:00 --> Router Class Initialized
INFO - 2024-09-30 07:55:00 --> Output Class Initialized
INFO - 2024-09-30 07:55:00 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:00 --> Input Class Initialized
INFO - 2024-09-30 07:55:00 --> Language Class Initialized
INFO - 2024-09-30 07:55:00 --> Language Class Initialized
INFO - 2024-09-30 07:55:00 --> Config Class Initialized
INFO - 2024-09-30 07:55:00 --> Loader Class Initialized
INFO - 2024-09-30 07:55:00 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:00 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:00 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:00 --> Controller Class Initialized
INFO - 2024-09-30 07:55:03 --> Config Class Initialized
INFO - 2024-09-30 07:55:03 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:03 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:03 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:03 --> URI Class Initialized
INFO - 2024-09-30 07:55:04 --> Router Class Initialized
INFO - 2024-09-30 07:55:04 --> Output Class Initialized
INFO - 2024-09-30 07:55:04 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:04 --> Input Class Initialized
INFO - 2024-09-30 07:55:04 --> Language Class Initialized
INFO - 2024-09-30 07:55:04 --> Language Class Initialized
INFO - 2024-09-30 07:55:04 --> Config Class Initialized
INFO - 2024-09-30 07:55:04 --> Loader Class Initialized
INFO - 2024-09-30 07:55:04 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:04 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:04 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:04 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:04 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:04 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:04 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:04 --> Total execution time: 0.0328
INFO - 2024-09-30 07:55:06 --> Config Class Initialized
INFO - 2024-09-30 07:55:06 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:06 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:06 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:06 --> URI Class Initialized
INFO - 2024-09-30 07:55:06 --> Router Class Initialized
INFO - 2024-09-30 07:55:06 --> Output Class Initialized
INFO - 2024-09-30 07:55:06 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:06 --> Input Class Initialized
INFO - 2024-09-30 07:55:06 --> Language Class Initialized
INFO - 2024-09-30 07:55:06 --> Language Class Initialized
INFO - 2024-09-30 07:55:06 --> Config Class Initialized
INFO - 2024-09-30 07:55:06 --> Loader Class Initialized
INFO - 2024-09-30 07:55:06 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:06 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:06 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 07:55:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:06 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:06 --> Total execution time: 0.0793
INFO - 2024-09-30 07:55:06 --> Config Class Initialized
INFO - 2024-09-30 07:55:06 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:06 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:06 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:06 --> URI Class Initialized
INFO - 2024-09-30 07:55:06 --> Router Class Initialized
INFO - 2024-09-30 07:55:06 --> Output Class Initialized
INFO - 2024-09-30 07:55:06 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:06 --> Input Class Initialized
INFO - 2024-09-30 07:55:06 --> Language Class Initialized
INFO - 2024-09-30 07:55:06 --> Language Class Initialized
INFO - 2024-09-30 07:55:06 --> Config Class Initialized
INFO - 2024-09-30 07:55:06 --> Loader Class Initialized
INFO - 2024-09-30 07:55:06 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:06 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:06 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:06 --> Controller Class Initialized
INFO - 2024-09-30 07:55:09 --> Config Class Initialized
INFO - 2024-09-30 07:55:09 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:09 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:09 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:09 --> URI Class Initialized
INFO - 2024-09-30 07:55:09 --> Router Class Initialized
INFO - 2024-09-30 07:55:09 --> Output Class Initialized
INFO - 2024-09-30 07:55:09 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:09 --> Input Class Initialized
INFO - 2024-09-30 07:55:09 --> Language Class Initialized
INFO - 2024-09-30 07:55:09 --> Language Class Initialized
INFO - 2024-09-30 07:55:09 --> Config Class Initialized
INFO - 2024-09-30 07:55:09 --> Loader Class Initialized
INFO - 2024-09-30 07:55:09 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:09 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:09 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:09 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:09 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:09 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:09 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:09 --> Total execution time: 0.0292
INFO - 2024-09-30 07:55:11 --> Config Class Initialized
INFO - 2024-09-30 07:55:11 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:11 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:11 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:11 --> URI Class Initialized
INFO - 2024-09-30 07:55:11 --> Router Class Initialized
INFO - 2024-09-30 07:55:11 --> Output Class Initialized
INFO - 2024-09-30 07:55:11 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:11 --> Input Class Initialized
INFO - 2024-09-30 07:55:11 --> Language Class Initialized
INFO - 2024-09-30 07:55:11 --> Language Class Initialized
INFO - 2024-09-30 07:55:11 --> Config Class Initialized
INFO - 2024-09-30 07:55:11 --> Loader Class Initialized
INFO - 2024-09-30 07:55:11 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:11 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:11 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 07:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:11 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:11 --> Total execution time: 0.0312
INFO - 2024-09-30 07:55:11 --> Config Class Initialized
INFO - 2024-09-30 07:55:11 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:11 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:11 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:11 --> URI Class Initialized
INFO - 2024-09-30 07:55:11 --> Router Class Initialized
INFO - 2024-09-30 07:55:11 --> Output Class Initialized
INFO - 2024-09-30 07:55:11 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:11 --> Input Class Initialized
INFO - 2024-09-30 07:55:11 --> Language Class Initialized
INFO - 2024-09-30 07:55:11 --> Language Class Initialized
INFO - 2024-09-30 07:55:11 --> Config Class Initialized
INFO - 2024-09-30 07:55:11 --> Loader Class Initialized
INFO - 2024-09-30 07:55:11 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:11 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:11 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:11 --> Controller Class Initialized
INFO - 2024-09-30 07:55:14 --> Config Class Initialized
INFO - 2024-09-30 07:55:14 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:14 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:14 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:14 --> URI Class Initialized
INFO - 2024-09-30 07:55:14 --> Router Class Initialized
INFO - 2024-09-30 07:55:14 --> Output Class Initialized
INFO - 2024-09-30 07:55:14 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:14 --> Input Class Initialized
INFO - 2024-09-30 07:55:14 --> Language Class Initialized
INFO - 2024-09-30 07:55:14 --> Language Class Initialized
INFO - 2024-09-30 07:55:14 --> Config Class Initialized
INFO - 2024-09-30 07:55:14 --> Loader Class Initialized
INFO - 2024-09-30 07:55:14 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:14 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:14 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:14 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:14 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:14 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:14 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:14 --> Total execution time: 0.0366
INFO - 2024-09-30 07:55:24 --> Config Class Initialized
INFO - 2024-09-30 07:55:24 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:24 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:24 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:24 --> URI Class Initialized
INFO - 2024-09-30 07:55:24 --> Router Class Initialized
INFO - 2024-09-30 07:55:24 --> Output Class Initialized
INFO - 2024-09-30 07:55:24 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:24 --> Input Class Initialized
INFO - 2024-09-30 07:55:24 --> Language Class Initialized
INFO - 2024-09-30 07:55:24 --> Language Class Initialized
INFO - 2024-09-30 07:55:24 --> Config Class Initialized
INFO - 2024-09-30 07:55:24 --> Loader Class Initialized
INFO - 2024-09-30 07:55:24 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:24 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:24 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:24 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:24 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:24 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:24 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:24 --> Total execution time: 0.0302
INFO - 2024-09-30 07:55:27 --> Config Class Initialized
INFO - 2024-09-30 07:55:27 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:27 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:27 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:27 --> URI Class Initialized
INFO - 2024-09-30 07:55:27 --> Router Class Initialized
INFO - 2024-09-30 07:55:27 --> Output Class Initialized
INFO - 2024-09-30 07:55:27 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:27 --> Input Class Initialized
INFO - 2024-09-30 07:55:27 --> Language Class Initialized
INFO - 2024-09-30 07:55:27 --> Language Class Initialized
INFO - 2024-09-30 07:55:27 --> Config Class Initialized
INFO - 2024-09-30 07:55:27 --> Loader Class Initialized
INFO - 2024-09-30 07:55:27 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:27 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:27 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 07:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:27 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:27 --> Total execution time: 0.0354
INFO - 2024-09-30 07:55:27 --> Config Class Initialized
INFO - 2024-09-30 07:55:27 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:27 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:27 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:27 --> URI Class Initialized
INFO - 2024-09-30 07:55:27 --> Router Class Initialized
INFO - 2024-09-30 07:55:27 --> Output Class Initialized
INFO - 2024-09-30 07:55:27 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:27 --> Input Class Initialized
INFO - 2024-09-30 07:55:27 --> Language Class Initialized
INFO - 2024-09-30 07:55:27 --> Language Class Initialized
INFO - 2024-09-30 07:55:27 --> Config Class Initialized
INFO - 2024-09-30 07:55:27 --> Loader Class Initialized
INFO - 2024-09-30 07:55:27 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:27 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:27 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:27 --> Controller Class Initialized
INFO - 2024-09-30 07:55:32 --> Config Class Initialized
INFO - 2024-09-30 07:55:32 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:32 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:32 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:32 --> URI Class Initialized
DEBUG - 2024-09-30 07:55:32 --> No URI present. Default controller set.
INFO - 2024-09-30 07:55:32 --> Router Class Initialized
INFO - 2024-09-30 07:55:32 --> Output Class Initialized
INFO - 2024-09-30 07:55:32 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:32 --> Input Class Initialized
INFO - 2024-09-30 07:55:32 --> Language Class Initialized
INFO - 2024-09-30 07:55:32 --> Language Class Initialized
INFO - 2024-09-30 07:55:32 --> Config Class Initialized
INFO - 2024-09-30 07:55:32 --> Loader Class Initialized
INFO - 2024-09-30 07:55:32 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:32 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:32 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:32 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:32 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:32 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-30 07:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:32 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:32 --> Total execution time: 0.0274
INFO - 2024-09-30 07:55:33 --> Config Class Initialized
INFO - 2024-09-30 07:55:33 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:33 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:33 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:33 --> URI Class Initialized
INFO - 2024-09-30 07:55:33 --> Router Class Initialized
INFO - 2024-09-30 07:55:33 --> Output Class Initialized
INFO - 2024-09-30 07:55:33 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:33 --> Input Class Initialized
INFO - 2024-09-30 07:55:33 --> Language Class Initialized
INFO - 2024-09-30 07:55:33 --> Language Class Initialized
INFO - 2024-09-30 07:55:33 --> Config Class Initialized
INFO - 2024-09-30 07:55:33 --> Loader Class Initialized
INFO - 2024-09-30 07:55:33 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:33 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:33 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:33 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:33 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:33 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:33 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:33 --> Total execution time: 0.0296
INFO - 2024-09-30 07:55:39 --> Config Class Initialized
INFO - 2024-09-30 07:55:39 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:39 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:39 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:39 --> URI Class Initialized
INFO - 2024-09-30 07:55:39 --> Router Class Initialized
INFO - 2024-09-30 07:55:39 --> Output Class Initialized
INFO - 2024-09-30 07:55:39 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:39 --> Input Class Initialized
INFO - 2024-09-30 07:55:39 --> Language Class Initialized
INFO - 2024-09-30 07:55:39 --> Language Class Initialized
INFO - 2024-09-30 07:55:39 --> Config Class Initialized
INFO - 2024-09-30 07:55:39 --> Loader Class Initialized
INFO - 2024-09-30 07:55:39 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:39 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:39 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:39 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:39 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:39 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-09-30 07:55:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:39 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:39 --> Total execution time: 0.0558
INFO - 2024-09-30 07:55:52 --> Config Class Initialized
INFO - 2024-09-30 07:55:52 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:55:52 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:55:52 --> Utf8 Class Initialized
INFO - 2024-09-30 07:55:52 --> URI Class Initialized
INFO - 2024-09-30 07:55:52 --> Router Class Initialized
INFO - 2024-09-30 07:55:52 --> Output Class Initialized
INFO - 2024-09-30 07:55:52 --> Security Class Initialized
DEBUG - 2024-09-30 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:55:52 --> Input Class Initialized
INFO - 2024-09-30 07:55:52 --> Language Class Initialized
INFO - 2024-09-30 07:55:52 --> Language Class Initialized
INFO - 2024-09-30 07:55:52 --> Config Class Initialized
INFO - 2024-09-30 07:55:52 --> Loader Class Initialized
INFO - 2024-09-30 07:55:52 --> Helper loaded: url_helper
INFO - 2024-09-30 07:55:52 --> Helper loaded: file_helper
INFO - 2024-09-30 07:55:52 --> Helper loaded: form_helper
INFO - 2024-09-30 07:55:52 --> Helper loaded: my_helper
INFO - 2024-09-30 07:55:52 --> Database Driver Class Initialized
INFO - 2024-09-30 07:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:55:52 --> Controller Class Initialized
DEBUG - 2024-09-30 07:55:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:55:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:55:52 --> Final output sent to browser
DEBUG - 2024-09-30 07:55:52 --> Total execution time: 0.0351
INFO - 2024-09-30 07:56:00 --> Config Class Initialized
INFO - 2024-09-30 07:56:00 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:00 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:00 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:00 --> URI Class Initialized
INFO - 2024-09-30 07:56:00 --> Router Class Initialized
INFO - 2024-09-30 07:56:00 --> Output Class Initialized
INFO - 2024-09-30 07:56:00 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:00 --> Input Class Initialized
INFO - 2024-09-30 07:56:00 --> Language Class Initialized
INFO - 2024-09-30 07:56:00 --> Language Class Initialized
INFO - 2024-09-30 07:56:00 --> Config Class Initialized
INFO - 2024-09-30 07:56:00 --> Loader Class Initialized
INFO - 2024-09-30 07:56:00 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:00 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:00 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:00 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:00 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:00 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-09-30 07:56:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:00 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:00 --> Total execution time: 0.0438
INFO - 2024-09-30 07:56:06 --> Config Class Initialized
INFO - 2024-09-30 07:56:06 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:06 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:06 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:06 --> URI Class Initialized
INFO - 2024-09-30 07:56:06 --> Router Class Initialized
INFO - 2024-09-30 07:56:06 --> Output Class Initialized
INFO - 2024-09-30 07:56:06 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:06 --> Input Class Initialized
INFO - 2024-09-30 07:56:06 --> Language Class Initialized
INFO - 2024-09-30 07:56:06 --> Language Class Initialized
INFO - 2024-09-30 07:56:06 --> Config Class Initialized
INFO - 2024-09-30 07:56:06 --> Loader Class Initialized
INFO - 2024-09-30 07:56:06 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:06 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:06 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-09-30 07:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:06 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:06 --> Total execution time: 0.0319
INFO - 2024-09-30 07:56:06 --> Config Class Initialized
INFO - 2024-09-30 07:56:06 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:06 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:06 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:06 --> URI Class Initialized
INFO - 2024-09-30 07:56:06 --> Router Class Initialized
INFO - 2024-09-30 07:56:06 --> Output Class Initialized
INFO - 2024-09-30 07:56:06 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:06 --> Input Class Initialized
INFO - 2024-09-30 07:56:06 --> Language Class Initialized
INFO - 2024-09-30 07:56:06 --> Language Class Initialized
INFO - 2024-09-30 07:56:06 --> Config Class Initialized
INFO - 2024-09-30 07:56:06 --> Loader Class Initialized
INFO - 2024-09-30 07:56:06 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:06 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:06 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:06 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2024-09-30 07:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:06 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:06 --> Total execution time: 0.0358
INFO - 2024-09-30 07:56:12 --> Config Class Initialized
INFO - 2024-09-30 07:56:12 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:12 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:12 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:12 --> URI Class Initialized
INFO - 2024-09-30 07:56:12 --> Router Class Initialized
INFO - 2024-09-30 07:56:12 --> Output Class Initialized
INFO - 2024-09-30 07:56:12 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:12 --> Input Class Initialized
INFO - 2024-09-30 07:56:12 --> Language Class Initialized
INFO - 2024-09-30 07:56:12 --> Language Class Initialized
INFO - 2024-09-30 07:56:12 --> Config Class Initialized
INFO - 2024-09-30 07:56:12 --> Loader Class Initialized
INFO - 2024-09-30 07:56:12 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:12 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:12 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:12 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:12 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:12 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-09-30 07:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:12 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:12 --> Total execution time: 0.0334
INFO - 2024-09-30 07:56:12 --> Config Class Initialized
INFO - 2024-09-30 07:56:12 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:12 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:12 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:12 --> URI Class Initialized
INFO - 2024-09-30 07:56:12 --> Router Class Initialized
INFO - 2024-09-30 07:56:12 --> Output Class Initialized
INFO - 2024-09-30 07:56:12 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:12 --> Input Class Initialized
INFO - 2024-09-30 07:56:12 --> Language Class Initialized
ERROR - 2024-09-30 07:56:12 --> 404 Page Not Found: /index
INFO - 2024-09-30 07:56:12 --> Config Class Initialized
INFO - 2024-09-30 07:56:12 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:13 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:13 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:13 --> URI Class Initialized
INFO - 2024-09-30 07:56:13 --> Router Class Initialized
INFO - 2024-09-30 07:56:13 --> Output Class Initialized
INFO - 2024-09-30 07:56:13 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:13 --> Input Class Initialized
INFO - 2024-09-30 07:56:13 --> Language Class Initialized
INFO - 2024-09-30 07:56:13 --> Language Class Initialized
INFO - 2024-09-30 07:56:13 --> Config Class Initialized
INFO - 2024-09-30 07:56:13 --> Loader Class Initialized
INFO - 2024-09-30 07:56:13 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:13 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:13 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:13 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:13 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:13 --> Controller Class Initialized
INFO - 2024-09-30 07:56:15 --> Config Class Initialized
INFO - 2024-09-30 07:56:15 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:15 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:15 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:15 --> URI Class Initialized
INFO - 2024-09-30 07:56:15 --> Router Class Initialized
INFO - 2024-09-30 07:56:15 --> Output Class Initialized
INFO - 2024-09-30 07:56:15 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:15 --> Input Class Initialized
INFO - 2024-09-30 07:56:15 --> Language Class Initialized
INFO - 2024-09-30 07:56:15 --> Language Class Initialized
INFO - 2024-09-30 07:56:15 --> Config Class Initialized
INFO - 2024-09-30 07:56:15 --> Loader Class Initialized
INFO - 2024-09-30 07:56:15 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:15 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:15 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:15 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:15 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:15 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2024-09-30 07:56:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:15 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:15 --> Total execution time: 0.0309
INFO - 2024-09-30 07:56:16 --> Config Class Initialized
INFO - 2024-09-30 07:56:16 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:16 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:16 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:16 --> URI Class Initialized
INFO - 2024-09-30 07:56:16 --> Router Class Initialized
INFO - 2024-09-30 07:56:16 --> Output Class Initialized
INFO - 2024-09-30 07:56:16 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:16 --> Input Class Initialized
INFO - 2024-09-30 07:56:16 --> Language Class Initialized
INFO - 2024-09-30 07:56:16 --> Language Class Initialized
INFO - 2024-09-30 07:56:16 --> Config Class Initialized
INFO - 2024-09-30 07:56:16 --> Loader Class Initialized
INFO - 2024-09-30 07:56:16 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:16 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:16 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:16 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:16 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:16 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-09-30 07:56:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:16 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:16 --> Total execution time: 0.0262
INFO - 2024-09-30 07:56:23 --> Config Class Initialized
INFO - 2024-09-30 07:56:23 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:23 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:23 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:23 --> URI Class Initialized
INFO - 2024-09-30 07:56:23 --> Router Class Initialized
INFO - 2024-09-30 07:56:23 --> Output Class Initialized
INFO - 2024-09-30 07:56:23 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:23 --> Input Class Initialized
INFO - 2024-09-30 07:56:23 --> Language Class Initialized
INFO - 2024-09-30 07:56:23 --> Language Class Initialized
INFO - 2024-09-30 07:56:23 --> Config Class Initialized
INFO - 2024-09-30 07:56:23 --> Loader Class Initialized
INFO - 2024-09-30 07:56:23 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:23 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:23 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:23 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:23 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:23 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-09-30 07:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:23 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:23 --> Total execution time: 0.0332
INFO - 2024-09-30 07:56:24 --> Config Class Initialized
INFO - 2024-09-30 07:56:24 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:24 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:24 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:24 --> URI Class Initialized
INFO - 2024-09-30 07:56:24 --> Router Class Initialized
INFO - 2024-09-30 07:56:24 --> Output Class Initialized
INFO - 2024-09-30 07:56:24 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:24 --> Input Class Initialized
INFO - 2024-09-30 07:56:24 --> Language Class Initialized
INFO - 2024-09-30 07:56:24 --> Language Class Initialized
INFO - 2024-09-30 07:56:24 --> Config Class Initialized
INFO - 2024-09-30 07:56:24 --> Loader Class Initialized
INFO - 2024-09-30 07:56:24 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:24 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:24 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:24 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:24 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:24 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-09-30 07:56:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:24 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:24 --> Total execution time: 0.0303
INFO - 2024-09-30 07:56:32 --> Config Class Initialized
INFO - 2024-09-30 07:56:32 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:32 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:32 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:32 --> URI Class Initialized
INFO - 2024-09-30 07:56:32 --> Router Class Initialized
INFO - 2024-09-30 07:56:32 --> Output Class Initialized
INFO - 2024-09-30 07:56:32 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:32 --> Input Class Initialized
INFO - 2024-09-30 07:56:32 --> Language Class Initialized
INFO - 2024-09-30 07:56:32 --> Language Class Initialized
INFO - 2024-09-30 07:56:32 --> Config Class Initialized
INFO - 2024-09-30 07:56:32 --> Loader Class Initialized
INFO - 2024-09-30 07:56:32 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:32 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:32 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:32 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:32 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:32 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-09-30 07:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:32 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:32 --> Total execution time: 0.0333
INFO - 2024-09-30 07:56:34 --> Config Class Initialized
INFO - 2024-09-30 07:56:34 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:34 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:34 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:34 --> URI Class Initialized
INFO - 2024-09-30 07:56:34 --> Router Class Initialized
INFO - 2024-09-30 07:56:34 --> Output Class Initialized
INFO - 2024-09-30 07:56:34 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:34 --> Input Class Initialized
INFO - 2024-09-30 07:56:34 --> Language Class Initialized
INFO - 2024-09-30 07:56:34 --> Language Class Initialized
INFO - 2024-09-30 07:56:34 --> Config Class Initialized
INFO - 2024-09-30 07:56:34 --> Loader Class Initialized
INFO - 2024-09-30 07:56:34 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:34 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:34 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-09-30 07:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:34 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:34 --> Total execution time: 0.0286
INFO - 2024-09-30 07:56:34 --> Config Class Initialized
INFO - 2024-09-30 07:56:34 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:34 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:34 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:34 --> URI Class Initialized
INFO - 2024-09-30 07:56:34 --> Router Class Initialized
INFO - 2024-09-30 07:56:34 --> Output Class Initialized
INFO - 2024-09-30 07:56:34 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:34 --> Input Class Initialized
INFO - 2024-09-30 07:56:34 --> Language Class Initialized
ERROR - 2024-09-30 07:56:34 --> 404 Page Not Found: /index
INFO - 2024-09-30 07:56:34 --> Config Class Initialized
INFO - 2024-09-30 07:56:34 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:34 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:34 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:34 --> URI Class Initialized
INFO - 2024-09-30 07:56:34 --> Router Class Initialized
INFO - 2024-09-30 07:56:34 --> Output Class Initialized
INFO - 2024-09-30 07:56:34 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:34 --> Input Class Initialized
INFO - 2024-09-30 07:56:34 --> Language Class Initialized
INFO - 2024-09-30 07:56:34 --> Language Class Initialized
INFO - 2024-09-30 07:56:34 --> Config Class Initialized
INFO - 2024-09-30 07:56:34 --> Loader Class Initialized
INFO - 2024-09-30 07:56:34 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:34 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:34 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:34 --> Controller Class Initialized
INFO - 2024-09-30 07:56:39 --> Config Class Initialized
INFO - 2024-09-30 07:56:39 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:39 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:39 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:39 --> URI Class Initialized
INFO - 2024-09-30 07:56:39 --> Router Class Initialized
INFO - 2024-09-30 07:56:39 --> Output Class Initialized
INFO - 2024-09-30 07:56:39 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:39 --> Input Class Initialized
INFO - 2024-09-30 07:56:39 --> Language Class Initialized
INFO - 2024-09-30 07:56:39 --> Language Class Initialized
INFO - 2024-09-30 07:56:39 --> Config Class Initialized
INFO - 2024-09-30 07:56:39 --> Loader Class Initialized
INFO - 2024-09-30 07:56:39 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:39 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:39 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:39 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:39 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:39 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-09-30 07:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:39 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:39 --> Total execution time: 0.0327
INFO - 2024-09-30 07:56:43 --> Config Class Initialized
INFO - 2024-09-30 07:56:43 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:43 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:43 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:43 --> URI Class Initialized
INFO - 2024-09-30 07:56:43 --> Router Class Initialized
INFO - 2024-09-30 07:56:43 --> Output Class Initialized
INFO - 2024-09-30 07:56:43 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:43 --> Input Class Initialized
INFO - 2024-09-30 07:56:43 --> Language Class Initialized
INFO - 2024-09-30 07:56:43 --> Language Class Initialized
INFO - 2024-09-30 07:56:43 --> Config Class Initialized
INFO - 2024-09-30 07:56:43 --> Loader Class Initialized
INFO - 2024-09-30 07:56:43 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:43 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:43 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:43 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:43 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:43 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:43 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:43 --> Total execution time: 0.0274
INFO - 2024-09-30 07:56:46 --> Config Class Initialized
INFO - 2024-09-30 07:56:46 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:46 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:46 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:46 --> URI Class Initialized
INFO - 2024-09-30 07:56:46 --> Router Class Initialized
INFO - 2024-09-30 07:56:46 --> Output Class Initialized
INFO - 2024-09-30 07:56:46 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:46 --> Input Class Initialized
INFO - 2024-09-30 07:56:46 --> Language Class Initialized
INFO - 2024-09-30 07:56:46 --> Language Class Initialized
INFO - 2024-09-30 07:56:46 --> Config Class Initialized
INFO - 2024-09-30 07:56:46 --> Loader Class Initialized
INFO - 2024-09-30 07:56:46 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:46 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:46 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:46 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:46 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:46 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-30 07:56:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:46 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:46 --> Total execution time: 0.0306
INFO - 2024-09-30 07:56:50 --> Config Class Initialized
INFO - 2024-09-30 07:56:50 --> Hooks Class Initialized
DEBUG - 2024-09-30 07:56:50 --> UTF-8 Support Enabled
INFO - 2024-09-30 07:56:50 --> Utf8 Class Initialized
INFO - 2024-09-30 07:56:50 --> URI Class Initialized
INFO - 2024-09-30 07:56:50 --> Router Class Initialized
INFO - 2024-09-30 07:56:50 --> Output Class Initialized
INFO - 2024-09-30 07:56:50 --> Security Class Initialized
DEBUG - 2024-09-30 07:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 07:56:50 --> Input Class Initialized
INFO - 2024-09-30 07:56:50 --> Language Class Initialized
INFO - 2024-09-30 07:56:50 --> Language Class Initialized
INFO - 2024-09-30 07:56:50 --> Config Class Initialized
INFO - 2024-09-30 07:56:50 --> Loader Class Initialized
INFO - 2024-09-30 07:56:50 --> Helper loaded: url_helper
INFO - 2024-09-30 07:56:50 --> Helper loaded: file_helper
INFO - 2024-09-30 07:56:50 --> Helper loaded: form_helper
INFO - 2024-09-30 07:56:50 --> Helper loaded: my_helper
INFO - 2024-09-30 07:56:50 --> Database Driver Class Initialized
INFO - 2024-09-30 07:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 07:56:50 --> Controller Class Initialized
DEBUG - 2024-09-30 07:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 07:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 07:56:50 --> Final output sent to browser
DEBUG - 2024-09-30 07:56:50 --> Total execution time: 0.0277
INFO - 2024-09-30 10:19:16 --> Config Class Initialized
INFO - 2024-09-30 10:19:16 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:19:16 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:19:16 --> Utf8 Class Initialized
INFO - 2024-09-30 10:19:16 --> URI Class Initialized
INFO - 2024-09-30 10:19:16 --> Router Class Initialized
INFO - 2024-09-30 10:19:16 --> Output Class Initialized
INFO - 2024-09-30 10:19:16 --> Security Class Initialized
DEBUG - 2024-09-30 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:19:16 --> Input Class Initialized
INFO - 2024-09-30 10:19:16 --> Language Class Initialized
INFO - 2024-09-30 10:19:16 --> Language Class Initialized
INFO - 2024-09-30 10:19:16 --> Config Class Initialized
INFO - 2024-09-30 10:19:16 --> Loader Class Initialized
INFO - 2024-09-30 10:19:16 --> Helper loaded: url_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: file_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: form_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: my_helper
INFO - 2024-09-30 10:19:16 --> Database Driver Class Initialized
INFO - 2024-09-30 10:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:19:16 --> Controller Class Initialized
INFO - 2024-09-30 10:19:16 --> Config Class Initialized
INFO - 2024-09-30 10:19:16 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:19:16 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:19:16 --> Utf8 Class Initialized
INFO - 2024-09-30 10:19:16 --> URI Class Initialized
INFO - 2024-09-30 10:19:16 --> Router Class Initialized
INFO - 2024-09-30 10:19:16 --> Output Class Initialized
INFO - 2024-09-30 10:19:16 --> Security Class Initialized
DEBUG - 2024-09-30 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:19:16 --> Input Class Initialized
INFO - 2024-09-30 10:19:16 --> Language Class Initialized
INFO - 2024-09-30 10:19:16 --> Language Class Initialized
INFO - 2024-09-30 10:19:16 --> Config Class Initialized
INFO - 2024-09-30 10:19:16 --> Loader Class Initialized
INFO - 2024-09-30 10:19:16 --> Helper loaded: url_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: file_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: form_helper
INFO - 2024-09-30 10:19:16 --> Helper loaded: my_helper
INFO - 2024-09-30 10:19:16 --> Database Driver Class Initialized
INFO - 2024-09-30 10:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:19:16 --> Controller Class Initialized
DEBUG - 2024-09-30 10:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-30 10:19:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 10:19:16 --> Final output sent to browser
DEBUG - 2024-09-30 10:19:16 --> Total execution time: 0.0312
INFO - 2024-09-30 10:31:12 --> Config Class Initialized
INFO - 2024-09-30 10:31:12 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:31:12 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:31:12 --> Utf8 Class Initialized
INFO - 2024-09-30 10:31:12 --> URI Class Initialized
INFO - 2024-09-30 10:31:12 --> Router Class Initialized
INFO - 2024-09-30 10:31:12 --> Output Class Initialized
INFO - 2024-09-30 10:31:12 --> Security Class Initialized
DEBUG - 2024-09-30 10:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:31:12 --> Input Class Initialized
INFO - 2024-09-30 10:31:12 --> Language Class Initialized
INFO - 2024-09-30 10:31:12 --> Language Class Initialized
INFO - 2024-09-30 10:31:12 --> Config Class Initialized
INFO - 2024-09-30 10:31:12 --> Loader Class Initialized
INFO - 2024-09-30 10:31:12 --> Helper loaded: url_helper
INFO - 2024-09-30 10:31:12 --> Helper loaded: file_helper
INFO - 2024-09-30 10:31:12 --> Helper loaded: form_helper
INFO - 2024-09-30 10:31:12 --> Helper loaded: my_helper
INFO - 2024-09-30 10:31:12 --> Database Driver Class Initialized
INFO - 2024-09-30 10:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:31:12 --> Controller Class Initialized
DEBUG - 2024-09-30 10:31:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-30 10:31:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 10:31:12 --> Final output sent to browser
DEBUG - 2024-09-30 10:31:12 --> Total execution time: 0.0309
INFO - 2024-09-30 10:31:14 --> Config Class Initialized
INFO - 2024-09-30 10:31:14 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:31:14 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:31:14 --> Utf8 Class Initialized
INFO - 2024-09-30 10:31:14 --> URI Class Initialized
INFO - 2024-09-30 10:31:14 --> Router Class Initialized
INFO - 2024-09-30 10:31:14 --> Output Class Initialized
INFO - 2024-09-30 10:31:14 --> Security Class Initialized
DEBUG - 2024-09-30 10:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:31:14 --> Input Class Initialized
INFO - 2024-09-30 10:31:14 --> Language Class Initialized
INFO - 2024-09-30 10:31:14 --> Language Class Initialized
INFO - 2024-09-30 10:31:14 --> Config Class Initialized
INFO - 2024-09-30 10:31:14 --> Loader Class Initialized
INFO - 2024-09-30 10:31:14 --> Helper loaded: url_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: file_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: form_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: my_helper
INFO - 2024-09-30 10:31:14 --> Database Driver Class Initialized
INFO - 2024-09-30 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:31:14 --> Controller Class Initialized
INFO - 2024-09-30 10:31:14 --> Helper loaded: cookie_helper
INFO - 2024-09-30 10:31:14 --> Final output sent to browser
DEBUG - 2024-09-30 10:31:14 --> Total execution time: 0.0519
INFO - 2024-09-30 10:31:14 --> Config Class Initialized
INFO - 2024-09-30 10:31:14 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:31:14 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:31:14 --> Utf8 Class Initialized
INFO - 2024-09-30 10:31:14 --> URI Class Initialized
INFO - 2024-09-30 10:31:14 --> Router Class Initialized
INFO - 2024-09-30 10:31:14 --> Output Class Initialized
INFO - 2024-09-30 10:31:14 --> Security Class Initialized
DEBUG - 2024-09-30 10:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:31:14 --> Input Class Initialized
INFO - 2024-09-30 10:31:14 --> Language Class Initialized
INFO - 2024-09-30 10:31:14 --> Language Class Initialized
INFO - 2024-09-30 10:31:14 --> Config Class Initialized
INFO - 2024-09-30 10:31:14 --> Loader Class Initialized
INFO - 2024-09-30 10:31:14 --> Helper loaded: url_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: file_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: form_helper
INFO - 2024-09-30 10:31:14 --> Helper loaded: my_helper
INFO - 2024-09-30 10:31:14 --> Database Driver Class Initialized
INFO - 2024-09-30 10:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:31:14 --> Controller Class Initialized
DEBUG - 2024-09-30 10:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-30 10:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 10:31:14 --> Final output sent to browser
DEBUG - 2024-09-30 10:31:14 --> Total execution time: 0.0309
INFO - 2024-09-30 10:33:24 --> Config Class Initialized
INFO - 2024-09-30 10:33:24 --> Hooks Class Initialized
DEBUG - 2024-09-30 10:33:24 --> UTF-8 Support Enabled
INFO - 2024-09-30 10:33:24 --> Utf8 Class Initialized
INFO - 2024-09-30 10:33:24 --> URI Class Initialized
INFO - 2024-09-30 10:33:24 --> Router Class Initialized
INFO - 2024-09-30 10:33:24 --> Output Class Initialized
INFO - 2024-09-30 10:33:24 --> Security Class Initialized
DEBUG - 2024-09-30 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 10:33:24 --> Input Class Initialized
INFO - 2024-09-30 10:33:24 --> Language Class Initialized
INFO - 2024-09-30 10:33:24 --> Language Class Initialized
INFO - 2024-09-30 10:33:24 --> Config Class Initialized
INFO - 2024-09-30 10:33:24 --> Loader Class Initialized
INFO - 2024-09-30 10:33:24 --> Helper loaded: url_helper
INFO - 2024-09-30 10:33:24 --> Helper loaded: file_helper
INFO - 2024-09-30 10:33:24 --> Helper loaded: form_helper
INFO - 2024-09-30 10:33:24 --> Helper loaded: my_helper
INFO - 2024-09-30 10:33:24 --> Database Driver Class Initialized
INFO - 2024-09-30 10:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 10:33:24 --> Controller Class Initialized
DEBUG - 2024-09-30 10:33:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-09-30 10:33:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 10:33:24 --> Final output sent to browser
DEBUG - 2024-09-30 10:33:24 --> Total execution time: 0.0488
INFO - 2024-09-30 11:32:55 --> Config Class Initialized
INFO - 2024-09-30 11:32:55 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:32:55 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:32:55 --> Utf8 Class Initialized
INFO - 2024-09-30 11:32:55 --> URI Class Initialized
INFO - 2024-09-30 11:32:55 --> Router Class Initialized
INFO - 2024-09-30 11:32:55 --> Output Class Initialized
INFO - 2024-09-30 11:32:55 --> Security Class Initialized
DEBUG - 2024-09-30 11:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:32:55 --> Input Class Initialized
INFO - 2024-09-30 11:32:55 --> Language Class Initialized
INFO - 2024-09-30 11:32:55 --> Language Class Initialized
INFO - 2024-09-30 11:32:55 --> Config Class Initialized
INFO - 2024-09-30 11:32:55 --> Loader Class Initialized
INFO - 2024-09-30 11:32:55 --> Helper loaded: url_helper
INFO - 2024-09-30 11:32:55 --> Helper loaded: file_helper
INFO - 2024-09-30 11:32:55 --> Helper loaded: form_helper
INFO - 2024-09-30 11:32:55 --> Helper loaded: my_helper
INFO - 2024-09-30 11:32:55 --> Database Driver Class Initialized
INFO - 2024-09-30 11:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:32:55 --> Controller Class Initialized
INFO - 2024-09-30 11:32:55 --> Final output sent to browser
DEBUG - 2024-09-30 11:32:55 --> Total execution time: 0.0934
INFO - 2024-09-30 11:33:02 --> Config Class Initialized
INFO - 2024-09-30 11:33:02 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:33:02 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:33:02 --> Utf8 Class Initialized
INFO - 2024-09-30 11:33:02 --> URI Class Initialized
INFO - 2024-09-30 11:33:02 --> Router Class Initialized
INFO - 2024-09-30 11:33:02 --> Output Class Initialized
INFO - 2024-09-30 11:33:02 --> Security Class Initialized
DEBUG - 2024-09-30 11:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:33:02 --> Input Class Initialized
INFO - 2024-09-30 11:33:02 --> Language Class Initialized
INFO - 2024-09-30 11:33:02 --> Language Class Initialized
INFO - 2024-09-30 11:33:02 --> Config Class Initialized
INFO - 2024-09-30 11:33:02 --> Loader Class Initialized
INFO - 2024-09-30 11:33:02 --> Helper loaded: url_helper
INFO - 2024-09-30 11:33:02 --> Helper loaded: file_helper
INFO - 2024-09-30 11:33:02 --> Helper loaded: form_helper
INFO - 2024-09-30 11:33:02 --> Helper loaded: my_helper
INFO - 2024-09-30 11:33:02 --> Database Driver Class Initialized
INFO - 2024-09-30 11:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:33:02 --> Controller Class Initialized
DEBUG - 2024-09-30 11:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 11:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:33:02 --> Final output sent to browser
DEBUG - 2024-09-30 11:33:02 --> Total execution time: 0.0418
INFO - 2024-09-30 11:33:05 --> Config Class Initialized
INFO - 2024-09-30 11:33:05 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:33:05 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:33:05 --> Utf8 Class Initialized
INFO - 2024-09-30 11:33:05 --> URI Class Initialized
INFO - 2024-09-30 11:33:05 --> Router Class Initialized
INFO - 2024-09-30 11:33:05 --> Output Class Initialized
INFO - 2024-09-30 11:33:05 --> Security Class Initialized
DEBUG - 2024-09-30 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:33:05 --> Input Class Initialized
INFO - 2024-09-30 11:33:05 --> Language Class Initialized
INFO - 2024-09-30 11:33:05 --> Language Class Initialized
INFO - 2024-09-30 11:33:05 --> Config Class Initialized
INFO - 2024-09-30 11:33:05 --> Loader Class Initialized
INFO - 2024-09-30 11:33:05 --> Helper loaded: url_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: file_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: form_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: my_helper
INFO - 2024-09-30 11:33:05 --> Database Driver Class Initialized
INFO - 2024-09-30 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:33:05 --> Controller Class Initialized
DEBUG - 2024-09-30 11:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:33:05 --> Final output sent to browser
DEBUG - 2024-09-30 11:33:05 --> Total execution time: 0.0299
INFO - 2024-09-30 11:33:05 --> Config Class Initialized
INFO - 2024-09-30 11:33:05 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:33:05 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:33:05 --> Utf8 Class Initialized
INFO - 2024-09-30 11:33:05 --> URI Class Initialized
INFO - 2024-09-30 11:33:05 --> Router Class Initialized
INFO - 2024-09-30 11:33:05 --> Output Class Initialized
INFO - 2024-09-30 11:33:05 --> Security Class Initialized
DEBUG - 2024-09-30 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:33:05 --> Input Class Initialized
INFO - 2024-09-30 11:33:05 --> Language Class Initialized
INFO - 2024-09-30 11:33:05 --> Language Class Initialized
INFO - 2024-09-30 11:33:05 --> Config Class Initialized
INFO - 2024-09-30 11:33:05 --> Loader Class Initialized
INFO - 2024-09-30 11:33:05 --> Helper loaded: url_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: file_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: form_helper
INFO - 2024-09-30 11:33:05 --> Helper loaded: my_helper
INFO - 2024-09-30 11:33:05 --> Database Driver Class Initialized
INFO - 2024-09-30 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:33:05 --> Controller Class Initialized
INFO - 2024-09-30 11:33:26 --> Config Class Initialized
INFO - 2024-09-30 11:33:26 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:33:26 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:33:26 --> Utf8 Class Initialized
INFO - 2024-09-30 11:33:26 --> URI Class Initialized
INFO - 2024-09-30 11:33:26 --> Router Class Initialized
INFO - 2024-09-30 11:33:26 --> Output Class Initialized
INFO - 2024-09-30 11:33:26 --> Security Class Initialized
DEBUG - 2024-09-30 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:33:26 --> Input Class Initialized
INFO - 2024-09-30 11:33:26 --> Language Class Initialized
INFO - 2024-09-30 11:33:26 --> Language Class Initialized
INFO - 2024-09-30 11:33:26 --> Config Class Initialized
INFO - 2024-09-30 11:33:26 --> Loader Class Initialized
INFO - 2024-09-30 11:33:26 --> Helper loaded: url_helper
INFO - 2024-09-30 11:33:26 --> Helper loaded: file_helper
INFO - 2024-09-30 11:33:26 --> Helper loaded: form_helper
INFO - 2024-09-30 11:33:26 --> Helper loaded: my_helper
INFO - 2024-09-30 11:33:26 --> Database Driver Class Initialized
INFO - 2024-09-30 11:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:33:26 --> Controller Class Initialized
INFO - 2024-09-30 11:33:26 --> Final output sent to browser
DEBUG - 2024-09-30 11:33:26 --> Total execution time: 0.0359
INFO - 2024-09-30 11:33:59 --> Config Class Initialized
INFO - 2024-09-30 11:33:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:33:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:33:59 --> Utf8 Class Initialized
INFO - 2024-09-30 11:33:59 --> URI Class Initialized
INFO - 2024-09-30 11:33:59 --> Router Class Initialized
INFO - 2024-09-30 11:33:59 --> Output Class Initialized
INFO - 2024-09-30 11:33:59 --> Security Class Initialized
DEBUG - 2024-09-30 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:33:59 --> Input Class Initialized
INFO - 2024-09-30 11:33:59 --> Language Class Initialized
INFO - 2024-09-30 11:33:59 --> Language Class Initialized
INFO - 2024-09-30 11:33:59 --> Config Class Initialized
INFO - 2024-09-30 11:33:59 --> Loader Class Initialized
INFO - 2024-09-30 11:33:59 --> Helper loaded: url_helper
INFO - 2024-09-30 11:33:59 --> Helper loaded: file_helper
INFO - 2024-09-30 11:33:59 --> Helper loaded: form_helper
INFO - 2024-09-30 11:33:59 --> Helper loaded: my_helper
INFO - 2024-09-30 11:33:59 --> Database Driver Class Initialized
INFO - 2024-09-30 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:33:59 --> Controller Class Initialized
ERROR - 2024-09-30 11:33:59 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:33:59 --> Final output sent to browser
DEBUG - 2024-09-30 11:33:59 --> Total execution time: 0.0314
INFO - 2024-09-30 11:34:18 --> Config Class Initialized
INFO - 2024-09-30 11:34:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:18 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:18 --> URI Class Initialized
INFO - 2024-09-30 11:34:18 --> Router Class Initialized
INFO - 2024-09-30 11:34:18 --> Output Class Initialized
INFO - 2024-09-30 11:34:18 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:18 --> Input Class Initialized
INFO - 2024-09-30 11:34:18 --> Language Class Initialized
INFO - 2024-09-30 11:34:18 --> Language Class Initialized
INFO - 2024-09-30 11:34:18 --> Config Class Initialized
INFO - 2024-09-30 11:34:18 --> Loader Class Initialized
INFO - 2024-09-30 11:34:18 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:18 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:18 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:18 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:18 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:18 --> Controller Class Initialized
INFO - 2024-09-30 11:34:18 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:18 --> Total execution time: 0.0290
INFO - 2024-09-30 11:34:31 --> Config Class Initialized
INFO - 2024-09-30 11:34:31 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:31 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:31 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:31 --> URI Class Initialized
INFO - 2024-09-30 11:34:31 --> Router Class Initialized
INFO - 2024-09-30 11:34:31 --> Output Class Initialized
INFO - 2024-09-30 11:34:31 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:31 --> Input Class Initialized
INFO - 2024-09-30 11:34:31 --> Language Class Initialized
INFO - 2024-09-30 11:34:31 --> Language Class Initialized
INFO - 2024-09-30 11:34:31 --> Config Class Initialized
INFO - 2024-09-30 11:34:31 --> Loader Class Initialized
INFO - 2024-09-30 11:34:31 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:31 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:31 --> Controller Class Initialized
DEBUG - 2024-09-30 11:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:34:31 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:31 --> Total execution time: 0.0438
INFO - 2024-09-30 11:34:31 --> Config Class Initialized
INFO - 2024-09-30 11:34:31 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:31 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:31 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:31 --> URI Class Initialized
INFO - 2024-09-30 11:34:31 --> Router Class Initialized
INFO - 2024-09-30 11:34:31 --> Output Class Initialized
INFO - 2024-09-30 11:34:31 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:31 --> Input Class Initialized
INFO - 2024-09-30 11:34:31 --> Language Class Initialized
INFO - 2024-09-30 11:34:31 --> Language Class Initialized
INFO - 2024-09-30 11:34:31 --> Config Class Initialized
INFO - 2024-09-30 11:34:31 --> Loader Class Initialized
INFO - 2024-09-30 11:34:31 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:31 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:31 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:31 --> Controller Class Initialized
INFO - 2024-09-30 11:34:32 --> Config Class Initialized
INFO - 2024-09-30 11:34:32 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:32 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:32 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:32 --> URI Class Initialized
INFO - 2024-09-30 11:34:32 --> Router Class Initialized
INFO - 2024-09-30 11:34:32 --> Output Class Initialized
INFO - 2024-09-30 11:34:32 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:32 --> Input Class Initialized
INFO - 2024-09-30 11:34:32 --> Language Class Initialized
INFO - 2024-09-30 11:34:32 --> Language Class Initialized
INFO - 2024-09-30 11:34:32 --> Config Class Initialized
INFO - 2024-09-30 11:34:32 --> Loader Class Initialized
INFO - 2024-09-30 11:34:32 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:32 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:32 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:33 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:33 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:33 --> Controller Class Initialized
INFO - 2024-09-30 11:34:33 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:33 --> Total execution time: 0.0302
INFO - 2024-09-30 11:34:52 --> Config Class Initialized
INFO - 2024-09-30 11:34:52 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:52 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:52 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:52 --> URI Class Initialized
INFO - 2024-09-30 11:34:52 --> Router Class Initialized
INFO - 2024-09-30 11:34:52 --> Output Class Initialized
INFO - 2024-09-30 11:34:52 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:52 --> Input Class Initialized
INFO - 2024-09-30 11:34:52 --> Language Class Initialized
INFO - 2024-09-30 11:34:52 --> Language Class Initialized
INFO - 2024-09-30 11:34:52 --> Config Class Initialized
INFO - 2024-09-30 11:34:52 --> Loader Class Initialized
INFO - 2024-09-30 11:34:52 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:52 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:52 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:52 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:52 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:52 --> Controller Class Initialized
ERROR - 2024-09-30 11:34:52 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:34:52 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:52 --> Total execution time: 0.0323
INFO - 2024-09-30 11:34:57 --> Config Class Initialized
INFO - 2024-09-30 11:34:57 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:57 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:57 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:57 --> URI Class Initialized
INFO - 2024-09-30 11:34:57 --> Router Class Initialized
INFO - 2024-09-30 11:34:57 --> Output Class Initialized
INFO - 2024-09-30 11:34:57 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:57 --> Input Class Initialized
INFO - 2024-09-30 11:34:57 --> Language Class Initialized
INFO - 2024-09-30 11:34:57 --> Language Class Initialized
INFO - 2024-09-30 11:34:57 --> Config Class Initialized
INFO - 2024-09-30 11:34:57 --> Loader Class Initialized
INFO - 2024-09-30 11:34:57 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:57 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:57 --> Controller Class Initialized
DEBUG - 2024-09-30 11:34:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:34:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:34:57 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:57 --> Total execution time: 0.0358
INFO - 2024-09-30 11:34:57 --> Config Class Initialized
INFO - 2024-09-30 11:34:57 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:57 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:57 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:57 --> URI Class Initialized
INFO - 2024-09-30 11:34:57 --> Router Class Initialized
INFO - 2024-09-30 11:34:57 --> Output Class Initialized
INFO - 2024-09-30 11:34:57 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:57 --> Input Class Initialized
INFO - 2024-09-30 11:34:57 --> Language Class Initialized
INFO - 2024-09-30 11:34:57 --> Language Class Initialized
INFO - 2024-09-30 11:34:57 --> Config Class Initialized
INFO - 2024-09-30 11:34:57 --> Loader Class Initialized
INFO - 2024-09-30 11:34:57 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:57 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:57 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:57 --> Controller Class Initialized
INFO - 2024-09-30 11:34:59 --> Config Class Initialized
INFO - 2024-09-30 11:34:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:34:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:34:59 --> Utf8 Class Initialized
INFO - 2024-09-30 11:34:59 --> URI Class Initialized
INFO - 2024-09-30 11:34:59 --> Router Class Initialized
INFO - 2024-09-30 11:34:59 --> Output Class Initialized
INFO - 2024-09-30 11:34:59 --> Security Class Initialized
DEBUG - 2024-09-30 11:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:34:59 --> Input Class Initialized
INFO - 2024-09-30 11:34:59 --> Language Class Initialized
INFO - 2024-09-30 11:34:59 --> Language Class Initialized
INFO - 2024-09-30 11:34:59 --> Config Class Initialized
INFO - 2024-09-30 11:34:59 --> Loader Class Initialized
INFO - 2024-09-30 11:34:59 --> Helper loaded: url_helper
INFO - 2024-09-30 11:34:59 --> Helper loaded: file_helper
INFO - 2024-09-30 11:34:59 --> Helper loaded: form_helper
INFO - 2024-09-30 11:34:59 --> Helper loaded: my_helper
INFO - 2024-09-30 11:34:59 --> Database Driver Class Initialized
INFO - 2024-09-30 11:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:34:59 --> Controller Class Initialized
INFO - 2024-09-30 11:34:59 --> Final output sent to browser
DEBUG - 2024-09-30 11:34:59 --> Total execution time: 0.0284
INFO - 2024-09-30 11:35:19 --> Config Class Initialized
INFO - 2024-09-30 11:35:19 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:19 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:19 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:19 --> URI Class Initialized
INFO - 2024-09-30 11:35:19 --> Router Class Initialized
INFO - 2024-09-30 11:35:19 --> Output Class Initialized
INFO - 2024-09-30 11:35:19 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:19 --> Input Class Initialized
INFO - 2024-09-30 11:35:19 --> Language Class Initialized
INFO - 2024-09-30 11:35:19 --> Language Class Initialized
INFO - 2024-09-30 11:35:19 --> Config Class Initialized
INFO - 2024-09-30 11:35:19 --> Loader Class Initialized
INFO - 2024-09-30 11:35:19 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:19 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:19 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:19 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:19 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:19 --> Controller Class Initialized
ERROR - 2024-09-30 11:35:19 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:35:19 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:19 --> Total execution time: 0.0312
INFO - 2024-09-30 11:35:24 --> Config Class Initialized
INFO - 2024-09-30 11:35:24 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:24 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:24 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:24 --> URI Class Initialized
INFO - 2024-09-30 11:35:24 --> Router Class Initialized
INFO - 2024-09-30 11:35:24 --> Output Class Initialized
INFO - 2024-09-30 11:35:24 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:24 --> Input Class Initialized
INFO - 2024-09-30 11:35:24 --> Language Class Initialized
INFO - 2024-09-30 11:35:24 --> Language Class Initialized
INFO - 2024-09-30 11:35:24 --> Config Class Initialized
INFO - 2024-09-30 11:35:24 --> Loader Class Initialized
INFO - 2024-09-30 11:35:24 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:24 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:24 --> Controller Class Initialized
DEBUG - 2024-09-30 11:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:35:24 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:24 --> Total execution time: 0.0306
INFO - 2024-09-30 11:35:24 --> Config Class Initialized
INFO - 2024-09-30 11:35:24 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:24 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:24 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:24 --> URI Class Initialized
INFO - 2024-09-30 11:35:24 --> Router Class Initialized
INFO - 2024-09-30 11:35:24 --> Output Class Initialized
INFO - 2024-09-30 11:35:24 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:24 --> Input Class Initialized
INFO - 2024-09-30 11:35:24 --> Language Class Initialized
INFO - 2024-09-30 11:35:24 --> Language Class Initialized
INFO - 2024-09-30 11:35:24 --> Config Class Initialized
INFO - 2024-09-30 11:35:24 --> Loader Class Initialized
INFO - 2024-09-30 11:35:24 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:24 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:24 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:24 --> Controller Class Initialized
INFO - 2024-09-30 11:35:27 --> Config Class Initialized
INFO - 2024-09-30 11:35:27 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:27 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:27 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:27 --> URI Class Initialized
INFO - 2024-09-30 11:35:27 --> Router Class Initialized
INFO - 2024-09-30 11:35:27 --> Output Class Initialized
INFO - 2024-09-30 11:35:27 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:27 --> Input Class Initialized
INFO - 2024-09-30 11:35:27 --> Language Class Initialized
INFO - 2024-09-30 11:35:27 --> Language Class Initialized
INFO - 2024-09-30 11:35:27 --> Config Class Initialized
INFO - 2024-09-30 11:35:27 --> Loader Class Initialized
INFO - 2024-09-30 11:35:27 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:27 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:27 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:27 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:27 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:27 --> Controller Class Initialized
INFO - 2024-09-30 11:35:27 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:27 --> Total execution time: 0.0286
INFO - 2024-09-30 11:35:46 --> Config Class Initialized
INFO - 2024-09-30 11:35:46 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:46 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:46 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:46 --> URI Class Initialized
INFO - 2024-09-30 11:35:46 --> Router Class Initialized
INFO - 2024-09-30 11:35:46 --> Output Class Initialized
INFO - 2024-09-30 11:35:46 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:46 --> Input Class Initialized
INFO - 2024-09-30 11:35:46 --> Language Class Initialized
INFO - 2024-09-30 11:35:46 --> Language Class Initialized
INFO - 2024-09-30 11:35:46 --> Config Class Initialized
INFO - 2024-09-30 11:35:46 --> Loader Class Initialized
INFO - 2024-09-30 11:35:46 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:46 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:46 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:46 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:46 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:47 --> Controller Class Initialized
ERROR - 2024-09-30 11:35:47 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:35:47 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:47 --> Total execution time: 0.0318
INFO - 2024-09-30 11:35:50 --> Config Class Initialized
INFO - 2024-09-30 11:35:50 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:50 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:50 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:50 --> URI Class Initialized
INFO - 2024-09-30 11:35:50 --> Router Class Initialized
INFO - 2024-09-30 11:35:50 --> Output Class Initialized
INFO - 2024-09-30 11:35:50 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:50 --> Input Class Initialized
INFO - 2024-09-30 11:35:50 --> Language Class Initialized
INFO - 2024-09-30 11:35:50 --> Language Class Initialized
INFO - 2024-09-30 11:35:50 --> Config Class Initialized
INFO - 2024-09-30 11:35:50 --> Loader Class Initialized
INFO - 2024-09-30 11:35:50 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:50 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:50 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:50 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:50 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:51 --> Controller Class Initialized
DEBUG - 2024-09-30 11:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:35:51 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:51 --> Total execution time: 0.0907
INFO - 2024-09-30 11:35:51 --> Config Class Initialized
INFO - 2024-09-30 11:35:51 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:51 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:51 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:51 --> URI Class Initialized
INFO - 2024-09-30 11:35:51 --> Router Class Initialized
INFO - 2024-09-30 11:35:51 --> Output Class Initialized
INFO - 2024-09-30 11:35:51 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:51 --> Input Class Initialized
INFO - 2024-09-30 11:35:51 --> Language Class Initialized
INFO - 2024-09-30 11:35:51 --> Language Class Initialized
INFO - 2024-09-30 11:35:51 --> Config Class Initialized
INFO - 2024-09-30 11:35:51 --> Loader Class Initialized
INFO - 2024-09-30 11:35:51 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:51 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:51 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:51 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:51 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:51 --> Controller Class Initialized
INFO - 2024-09-30 11:35:52 --> Config Class Initialized
INFO - 2024-09-30 11:35:52 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:52 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:52 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:52 --> URI Class Initialized
INFO - 2024-09-30 11:35:52 --> Router Class Initialized
INFO - 2024-09-30 11:35:52 --> Output Class Initialized
INFO - 2024-09-30 11:35:52 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:52 --> Input Class Initialized
INFO - 2024-09-30 11:35:52 --> Language Class Initialized
INFO - 2024-09-30 11:35:52 --> Language Class Initialized
INFO - 2024-09-30 11:35:52 --> Config Class Initialized
INFO - 2024-09-30 11:35:52 --> Loader Class Initialized
INFO - 2024-09-30 11:35:52 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:52 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:52 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:52 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:52 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:52 --> Controller Class Initialized
INFO - 2024-09-30 11:35:52 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:52 --> Total execution time: 0.0244
INFO - 2024-09-30 11:35:57 --> Config Class Initialized
INFO - 2024-09-30 11:35:57 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:35:57 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:35:57 --> Utf8 Class Initialized
INFO - 2024-09-30 11:35:57 --> URI Class Initialized
INFO - 2024-09-30 11:35:57 --> Router Class Initialized
INFO - 2024-09-30 11:35:57 --> Output Class Initialized
INFO - 2024-09-30 11:35:57 --> Security Class Initialized
DEBUG - 2024-09-30 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:35:57 --> Input Class Initialized
INFO - 2024-09-30 11:35:57 --> Language Class Initialized
INFO - 2024-09-30 11:35:57 --> Language Class Initialized
INFO - 2024-09-30 11:35:57 --> Config Class Initialized
INFO - 2024-09-30 11:35:57 --> Loader Class Initialized
INFO - 2024-09-30 11:35:57 --> Helper loaded: url_helper
INFO - 2024-09-30 11:35:57 --> Helper loaded: file_helper
INFO - 2024-09-30 11:35:57 --> Helper loaded: form_helper
INFO - 2024-09-30 11:35:57 --> Helper loaded: my_helper
INFO - 2024-09-30 11:35:57 --> Database Driver Class Initialized
INFO - 2024-09-30 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:35:57 --> Controller Class Initialized
ERROR - 2024-09-30 11:35:57 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2024-09-30 11:35:57 --> Final output sent to browser
DEBUG - 2024-09-30 11:35:57 --> Total execution time: 0.0340
INFO - 2024-09-30 11:36:01 --> Config Class Initialized
INFO - 2024-09-30 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:01 --> URI Class Initialized
INFO - 2024-09-30 11:36:01 --> Router Class Initialized
INFO - 2024-09-30 11:36:01 --> Output Class Initialized
INFO - 2024-09-30 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:01 --> Input Class Initialized
INFO - 2024-09-30 11:36:01 --> Language Class Initialized
INFO - 2024-09-30 11:36:01 --> Language Class Initialized
INFO - 2024-09-30 11:36:01 --> Config Class Initialized
INFO - 2024-09-30 11:36:01 --> Loader Class Initialized
INFO - 2024-09-30 11:36:01 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:01 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:01 --> Controller Class Initialized
DEBUG - 2024-09-30 11:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:36:01 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:01 --> Total execution time: 0.0333
INFO - 2024-09-30 11:36:01 --> Config Class Initialized
INFO - 2024-09-30 11:36:01 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:01 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:01 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:01 --> URI Class Initialized
INFO - 2024-09-30 11:36:01 --> Router Class Initialized
INFO - 2024-09-30 11:36:01 --> Output Class Initialized
INFO - 2024-09-30 11:36:01 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:01 --> Input Class Initialized
INFO - 2024-09-30 11:36:01 --> Language Class Initialized
INFO - 2024-09-30 11:36:01 --> Language Class Initialized
INFO - 2024-09-30 11:36:01 --> Config Class Initialized
INFO - 2024-09-30 11:36:01 --> Loader Class Initialized
INFO - 2024-09-30 11:36:01 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:01 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:01 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:01 --> Controller Class Initialized
INFO - 2024-09-30 11:36:03 --> Config Class Initialized
INFO - 2024-09-30 11:36:03 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:03 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:03 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:03 --> URI Class Initialized
INFO - 2024-09-30 11:36:03 --> Router Class Initialized
INFO - 2024-09-30 11:36:03 --> Output Class Initialized
INFO - 2024-09-30 11:36:03 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:03 --> Input Class Initialized
INFO - 2024-09-30 11:36:03 --> Language Class Initialized
INFO - 2024-09-30 11:36:03 --> Language Class Initialized
INFO - 2024-09-30 11:36:03 --> Config Class Initialized
INFO - 2024-09-30 11:36:03 --> Loader Class Initialized
INFO - 2024-09-30 11:36:03 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:03 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:03 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:03 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:03 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:03 --> Controller Class Initialized
INFO - 2024-09-30 11:36:03 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:03 --> Total execution time: 0.0341
INFO - 2024-09-30 11:36:06 --> Config Class Initialized
INFO - 2024-09-30 11:36:06 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:06 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:06 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:06 --> URI Class Initialized
INFO - 2024-09-30 11:36:06 --> Router Class Initialized
INFO - 2024-09-30 11:36:06 --> Output Class Initialized
INFO - 2024-09-30 11:36:06 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:06 --> Input Class Initialized
INFO - 2024-09-30 11:36:06 --> Language Class Initialized
INFO - 2024-09-30 11:36:06 --> Language Class Initialized
INFO - 2024-09-30 11:36:06 --> Config Class Initialized
INFO - 2024-09-30 11:36:06 --> Loader Class Initialized
INFO - 2024-09-30 11:36:06 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:06 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:06 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:06 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:07 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:07 --> Controller Class Initialized
ERROR - 2024-09-30 11:36:07 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2024-09-30 11:36:07 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:07 --> Total execution time: 0.0762
INFO - 2024-09-30 11:36:11 --> Config Class Initialized
INFO - 2024-09-30 11:36:11 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:11 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:11 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:11 --> URI Class Initialized
INFO - 2024-09-30 11:36:11 --> Router Class Initialized
INFO - 2024-09-30 11:36:11 --> Output Class Initialized
INFO - 2024-09-30 11:36:11 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:11 --> Input Class Initialized
INFO - 2024-09-30 11:36:11 --> Language Class Initialized
INFO - 2024-09-30 11:36:11 --> Language Class Initialized
INFO - 2024-09-30 11:36:11 --> Config Class Initialized
INFO - 2024-09-30 11:36:11 --> Loader Class Initialized
INFO - 2024-09-30 11:36:11 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:11 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:11 --> Controller Class Initialized
DEBUG - 2024-09-30 11:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:36:11 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:11 --> Total execution time: 0.0311
INFO - 2024-09-30 11:36:11 --> Config Class Initialized
INFO - 2024-09-30 11:36:11 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:11 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:11 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:11 --> URI Class Initialized
INFO - 2024-09-30 11:36:11 --> Router Class Initialized
INFO - 2024-09-30 11:36:11 --> Output Class Initialized
INFO - 2024-09-30 11:36:11 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:11 --> Input Class Initialized
INFO - 2024-09-30 11:36:11 --> Language Class Initialized
INFO - 2024-09-30 11:36:11 --> Language Class Initialized
INFO - 2024-09-30 11:36:11 --> Config Class Initialized
INFO - 2024-09-30 11:36:11 --> Loader Class Initialized
INFO - 2024-09-30 11:36:11 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:11 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:11 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:11 --> Controller Class Initialized
INFO - 2024-09-30 11:36:13 --> Config Class Initialized
INFO - 2024-09-30 11:36:13 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:13 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:13 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:13 --> URI Class Initialized
INFO - 2024-09-30 11:36:13 --> Router Class Initialized
INFO - 2024-09-30 11:36:13 --> Output Class Initialized
INFO - 2024-09-30 11:36:13 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:13 --> Input Class Initialized
INFO - 2024-09-30 11:36:13 --> Language Class Initialized
INFO - 2024-09-30 11:36:13 --> Language Class Initialized
INFO - 2024-09-30 11:36:13 --> Config Class Initialized
INFO - 2024-09-30 11:36:13 --> Loader Class Initialized
INFO - 2024-09-30 11:36:13 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:13 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:13 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:13 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:13 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:13 --> Controller Class Initialized
INFO - 2024-09-30 11:36:13 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:13 --> Total execution time: 0.0517
INFO - 2024-09-30 11:36:17 --> Config Class Initialized
INFO - 2024-09-30 11:36:17 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:17 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:17 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:17 --> URI Class Initialized
INFO - 2024-09-30 11:36:17 --> Router Class Initialized
INFO - 2024-09-30 11:36:17 --> Output Class Initialized
INFO - 2024-09-30 11:36:17 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:17 --> Input Class Initialized
INFO - 2024-09-30 11:36:17 --> Language Class Initialized
INFO - 2024-09-30 11:36:17 --> Language Class Initialized
INFO - 2024-09-30 11:36:17 --> Config Class Initialized
INFO - 2024-09-30 11:36:17 --> Loader Class Initialized
INFO - 2024-09-30 11:36:17 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:17 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:17 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:17 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:17 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:17 --> Controller Class Initialized
ERROR - 2024-09-30 11:36:17 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2024-09-30 11:36:17 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:17 --> Total execution time: 0.0384
INFO - 2024-09-30 11:36:23 --> Config Class Initialized
INFO - 2024-09-30 11:36:23 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:23 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:23 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:23 --> URI Class Initialized
INFO - 2024-09-30 11:36:23 --> Router Class Initialized
INFO - 2024-09-30 11:36:23 --> Output Class Initialized
INFO - 2024-09-30 11:36:23 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:23 --> Input Class Initialized
INFO - 2024-09-30 11:36:23 --> Language Class Initialized
INFO - 2024-09-30 11:36:23 --> Language Class Initialized
INFO - 2024-09-30 11:36:23 --> Config Class Initialized
INFO - 2024-09-30 11:36:23 --> Loader Class Initialized
INFO - 2024-09-30 11:36:23 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:23 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:23 --> Controller Class Initialized
DEBUG - 2024-09-30 11:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:36:23 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:23 --> Total execution time: 0.0319
INFO - 2024-09-30 11:36:23 --> Config Class Initialized
INFO - 2024-09-30 11:36:23 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:23 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:23 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:23 --> URI Class Initialized
INFO - 2024-09-30 11:36:23 --> Router Class Initialized
INFO - 2024-09-30 11:36:23 --> Output Class Initialized
INFO - 2024-09-30 11:36:23 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:23 --> Input Class Initialized
INFO - 2024-09-30 11:36:23 --> Language Class Initialized
INFO - 2024-09-30 11:36:23 --> Language Class Initialized
INFO - 2024-09-30 11:36:23 --> Config Class Initialized
INFO - 2024-09-30 11:36:23 --> Loader Class Initialized
INFO - 2024-09-30 11:36:23 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:23 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:23 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:23 --> Controller Class Initialized
INFO - 2024-09-30 11:36:26 --> Config Class Initialized
INFO - 2024-09-30 11:36:26 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:26 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:26 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:26 --> URI Class Initialized
INFO - 2024-09-30 11:36:26 --> Router Class Initialized
INFO - 2024-09-30 11:36:26 --> Output Class Initialized
INFO - 2024-09-30 11:36:26 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:26 --> Input Class Initialized
INFO - 2024-09-30 11:36:26 --> Language Class Initialized
INFO - 2024-09-30 11:36:26 --> Language Class Initialized
INFO - 2024-09-30 11:36:26 --> Config Class Initialized
INFO - 2024-09-30 11:36:26 --> Loader Class Initialized
INFO - 2024-09-30 11:36:26 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:26 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:26 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:26 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:26 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:26 --> Controller Class Initialized
INFO - 2024-09-30 11:36:26 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:26 --> Total execution time: 0.0282
INFO - 2024-09-30 11:36:40 --> Config Class Initialized
INFO - 2024-09-30 11:36:40 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:40 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:40 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:40 --> URI Class Initialized
INFO - 2024-09-30 11:36:40 --> Router Class Initialized
INFO - 2024-09-30 11:36:40 --> Output Class Initialized
INFO - 2024-09-30 11:36:40 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:40 --> Input Class Initialized
INFO - 2024-09-30 11:36:40 --> Language Class Initialized
INFO - 2024-09-30 11:36:40 --> Language Class Initialized
INFO - 2024-09-30 11:36:40 --> Config Class Initialized
INFO - 2024-09-30 11:36:40 --> Loader Class Initialized
INFO - 2024-09-30 11:36:40 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:40 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:40 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:40 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:40 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:40 --> Controller Class Initialized
ERROR - 2024-09-30 11:36:40 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:36:40 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:40 --> Total execution time: 0.0300
INFO - 2024-09-30 11:36:43 --> Config Class Initialized
INFO - 2024-09-30 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:43 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:43 --> URI Class Initialized
INFO - 2024-09-30 11:36:43 --> Router Class Initialized
INFO - 2024-09-30 11:36:43 --> Output Class Initialized
INFO - 2024-09-30 11:36:43 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:43 --> Input Class Initialized
INFO - 2024-09-30 11:36:43 --> Language Class Initialized
INFO - 2024-09-30 11:36:43 --> Language Class Initialized
INFO - 2024-09-30 11:36:43 --> Config Class Initialized
INFO - 2024-09-30 11:36:43 --> Loader Class Initialized
INFO - 2024-09-30 11:36:43 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:43 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:43 --> Controller Class Initialized
DEBUG - 2024-09-30 11:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 11:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 11:36:43 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:43 --> Total execution time: 0.0296
INFO - 2024-09-30 11:36:43 --> Config Class Initialized
INFO - 2024-09-30 11:36:43 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:43 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:43 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:43 --> URI Class Initialized
INFO - 2024-09-30 11:36:43 --> Router Class Initialized
INFO - 2024-09-30 11:36:43 --> Output Class Initialized
INFO - 2024-09-30 11:36:43 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:43 --> Input Class Initialized
INFO - 2024-09-30 11:36:43 --> Language Class Initialized
INFO - 2024-09-30 11:36:43 --> Language Class Initialized
INFO - 2024-09-30 11:36:43 --> Config Class Initialized
INFO - 2024-09-30 11:36:43 --> Loader Class Initialized
INFO - 2024-09-30 11:36:43 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:43 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:43 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:43 --> Controller Class Initialized
INFO - 2024-09-30 11:36:45 --> Config Class Initialized
INFO - 2024-09-30 11:36:45 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:36:45 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:36:45 --> Utf8 Class Initialized
INFO - 2024-09-30 11:36:45 --> URI Class Initialized
INFO - 2024-09-30 11:36:45 --> Router Class Initialized
INFO - 2024-09-30 11:36:45 --> Output Class Initialized
INFO - 2024-09-30 11:36:45 --> Security Class Initialized
DEBUG - 2024-09-30 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:36:45 --> Input Class Initialized
INFO - 2024-09-30 11:36:45 --> Language Class Initialized
INFO - 2024-09-30 11:36:45 --> Language Class Initialized
INFO - 2024-09-30 11:36:45 --> Config Class Initialized
INFO - 2024-09-30 11:36:45 --> Loader Class Initialized
INFO - 2024-09-30 11:36:45 --> Helper loaded: url_helper
INFO - 2024-09-30 11:36:45 --> Helper loaded: file_helper
INFO - 2024-09-30 11:36:45 --> Helper loaded: form_helper
INFO - 2024-09-30 11:36:45 --> Helper loaded: my_helper
INFO - 2024-09-30 11:36:45 --> Database Driver Class Initialized
INFO - 2024-09-30 11:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:36:45 --> Controller Class Initialized
INFO - 2024-09-30 11:36:45 --> Final output sent to browser
DEBUG - 2024-09-30 11:36:45 --> Total execution time: 0.0273
INFO - 2024-09-30 11:37:12 --> Config Class Initialized
INFO - 2024-09-30 11:37:12 --> Hooks Class Initialized
DEBUG - 2024-09-30 11:37:12 --> UTF-8 Support Enabled
INFO - 2024-09-30 11:37:12 --> Utf8 Class Initialized
INFO - 2024-09-30 11:37:12 --> URI Class Initialized
INFO - 2024-09-30 11:37:12 --> Router Class Initialized
INFO - 2024-09-30 11:37:12 --> Output Class Initialized
INFO - 2024-09-30 11:37:12 --> Security Class Initialized
DEBUG - 2024-09-30 11:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 11:37:12 --> Input Class Initialized
INFO - 2024-09-30 11:37:12 --> Language Class Initialized
INFO - 2024-09-30 11:37:12 --> Language Class Initialized
INFO - 2024-09-30 11:37:12 --> Config Class Initialized
INFO - 2024-09-30 11:37:12 --> Loader Class Initialized
INFO - 2024-09-30 11:37:12 --> Helper loaded: url_helper
INFO - 2024-09-30 11:37:12 --> Helper loaded: file_helper
INFO - 2024-09-30 11:37:12 --> Helper loaded: form_helper
INFO - 2024-09-30 11:37:12 --> Helper loaded: my_helper
INFO - 2024-09-30 11:37:12 --> Database Driver Class Initialized
INFO - 2024-09-30 11:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 11:37:12 --> Controller Class Initialized
ERROR - 2024-09-30 11:37:12 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 11:37:12 --> Final output sent to browser
DEBUG - 2024-09-30 11:37:12 --> Total execution time: 0.0726
INFO - 2024-09-30 12:18:48 --> Config Class Initialized
INFO - 2024-09-30 12:18:48 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:18:48 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:18:48 --> Utf8 Class Initialized
INFO - 2024-09-30 12:18:48 --> URI Class Initialized
INFO - 2024-09-30 12:18:48 --> Router Class Initialized
INFO - 2024-09-30 12:18:48 --> Output Class Initialized
INFO - 2024-09-30 12:18:48 --> Security Class Initialized
DEBUG - 2024-09-30 12:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:18:48 --> Input Class Initialized
INFO - 2024-09-30 12:18:48 --> Language Class Initialized
INFO - 2024-09-30 12:18:48 --> Language Class Initialized
INFO - 2024-09-30 12:18:48 --> Config Class Initialized
INFO - 2024-09-30 12:18:48 --> Loader Class Initialized
INFO - 2024-09-30 12:18:48 --> Helper loaded: url_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: file_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: form_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: my_helper
INFO - 2024-09-30 12:18:48 --> Database Driver Class Initialized
INFO - 2024-09-30 12:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:18:48 --> Controller Class Initialized
DEBUG - 2024-09-30 12:18:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-09-30 12:18:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:18:48 --> Final output sent to browser
DEBUG - 2024-09-30 12:18:48 --> Total execution time: 0.2352
INFO - 2024-09-30 12:18:48 --> Config Class Initialized
INFO - 2024-09-30 12:18:48 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:18:48 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:18:48 --> Utf8 Class Initialized
INFO - 2024-09-30 12:18:48 --> URI Class Initialized
INFO - 2024-09-30 12:18:48 --> Router Class Initialized
INFO - 2024-09-30 12:18:48 --> Output Class Initialized
INFO - 2024-09-30 12:18:48 --> Security Class Initialized
DEBUG - 2024-09-30 12:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:18:48 --> Input Class Initialized
INFO - 2024-09-30 12:18:48 --> Language Class Initialized
INFO - 2024-09-30 12:18:48 --> Language Class Initialized
INFO - 2024-09-30 12:18:48 --> Config Class Initialized
INFO - 2024-09-30 12:18:48 --> Loader Class Initialized
INFO - 2024-09-30 12:18:48 --> Helper loaded: url_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: file_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: form_helper
INFO - 2024-09-30 12:18:48 --> Helper loaded: my_helper
INFO - 2024-09-30 12:18:48 --> Database Driver Class Initialized
INFO - 2024-09-30 12:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:18:48 --> Controller Class Initialized
INFO - 2024-09-30 12:20:53 --> Config Class Initialized
INFO - 2024-09-30 12:20:53 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:20:53 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:20:53 --> Utf8 Class Initialized
INFO - 2024-09-30 12:20:53 --> URI Class Initialized
INFO - 2024-09-30 12:20:53 --> Router Class Initialized
INFO - 2024-09-30 12:20:53 --> Output Class Initialized
INFO - 2024-09-30 12:20:53 --> Security Class Initialized
DEBUG - 2024-09-30 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:20:53 --> Input Class Initialized
INFO - 2024-09-30 12:20:53 --> Language Class Initialized
INFO - 2024-09-30 12:20:53 --> Language Class Initialized
INFO - 2024-09-30 12:20:53 --> Config Class Initialized
INFO - 2024-09-30 12:20:53 --> Loader Class Initialized
INFO - 2024-09-30 12:20:53 --> Helper loaded: url_helper
INFO - 2024-09-30 12:20:53 --> Helper loaded: file_helper
INFO - 2024-09-30 12:20:53 --> Helper loaded: form_helper
INFO - 2024-09-30 12:20:53 --> Helper loaded: my_helper
INFO - 2024-09-30 12:20:53 --> Database Driver Class Initialized
INFO - 2024-09-30 12:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:20:53 --> Controller Class Initialized
DEBUG - 2024-09-30 12:20:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 12:20:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:20:53 --> Final output sent to browser
DEBUG - 2024-09-30 12:20:53 --> Total execution time: 0.0289
INFO - 2024-09-30 12:20:59 --> Config Class Initialized
INFO - 2024-09-30 12:20:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:20:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:20:59 --> Utf8 Class Initialized
INFO - 2024-09-30 12:20:59 --> URI Class Initialized
INFO - 2024-09-30 12:20:59 --> Router Class Initialized
INFO - 2024-09-30 12:20:59 --> Output Class Initialized
INFO - 2024-09-30 12:20:59 --> Security Class Initialized
DEBUG - 2024-09-30 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:20:59 --> Input Class Initialized
INFO - 2024-09-30 12:20:59 --> Language Class Initialized
INFO - 2024-09-30 12:20:59 --> Language Class Initialized
INFO - 2024-09-30 12:20:59 --> Config Class Initialized
INFO - 2024-09-30 12:20:59 --> Loader Class Initialized
INFO - 2024-09-30 12:20:59 --> Helper loaded: url_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: file_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: form_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: my_helper
INFO - 2024-09-30 12:20:59 --> Database Driver Class Initialized
INFO - 2024-09-30 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:20:59 --> Controller Class Initialized
DEBUG - 2024-09-30 12:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:20:59 --> Final output sent to browser
DEBUG - 2024-09-30 12:20:59 --> Total execution time: 0.0456
INFO - 2024-09-30 12:20:59 --> Config Class Initialized
INFO - 2024-09-30 12:20:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:20:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:20:59 --> Utf8 Class Initialized
INFO - 2024-09-30 12:20:59 --> URI Class Initialized
INFO - 2024-09-30 12:20:59 --> Router Class Initialized
INFO - 2024-09-30 12:20:59 --> Output Class Initialized
INFO - 2024-09-30 12:20:59 --> Security Class Initialized
DEBUG - 2024-09-30 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:20:59 --> Input Class Initialized
INFO - 2024-09-30 12:20:59 --> Language Class Initialized
INFO - 2024-09-30 12:20:59 --> Language Class Initialized
INFO - 2024-09-30 12:20:59 --> Config Class Initialized
INFO - 2024-09-30 12:20:59 --> Loader Class Initialized
INFO - 2024-09-30 12:20:59 --> Helper loaded: url_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: file_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: form_helper
INFO - 2024-09-30 12:20:59 --> Helper loaded: my_helper
INFO - 2024-09-30 12:20:59 --> Database Driver Class Initialized
INFO - 2024-09-30 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:20:59 --> Controller Class Initialized
INFO - 2024-09-30 12:21:00 --> Config Class Initialized
INFO - 2024-09-30 12:21:00 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:00 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:00 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:00 --> URI Class Initialized
INFO - 2024-09-30 12:21:00 --> Router Class Initialized
INFO - 2024-09-30 12:21:00 --> Output Class Initialized
INFO - 2024-09-30 12:21:00 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:00 --> Input Class Initialized
INFO - 2024-09-30 12:21:00 --> Language Class Initialized
INFO - 2024-09-30 12:21:00 --> Language Class Initialized
INFO - 2024-09-30 12:21:00 --> Config Class Initialized
INFO - 2024-09-30 12:21:00 --> Loader Class Initialized
INFO - 2024-09-30 12:21:00 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:00 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:00 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:00 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:00 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:00 --> Controller Class Initialized
INFO - 2024-09-30 12:21:00 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:00 --> Total execution time: 0.0376
INFO - 2024-09-30 12:21:14 --> Config Class Initialized
INFO - 2024-09-30 12:21:14 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:14 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:14 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:14 --> URI Class Initialized
INFO - 2024-09-30 12:21:14 --> Router Class Initialized
INFO - 2024-09-30 12:21:14 --> Output Class Initialized
INFO - 2024-09-30 12:21:14 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:14 --> Input Class Initialized
INFO - 2024-09-30 12:21:14 --> Language Class Initialized
INFO - 2024-09-30 12:21:14 --> Language Class Initialized
INFO - 2024-09-30 12:21:14 --> Config Class Initialized
INFO - 2024-09-30 12:21:14 --> Loader Class Initialized
INFO - 2024-09-30 12:21:14 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:14 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:14 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:14 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:14 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:14 --> Controller Class Initialized
ERROR - 2024-09-30 12:21:14 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 12:21:14 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:14 --> Total execution time: 0.0437
INFO - 2024-09-30 12:21:18 --> Config Class Initialized
INFO - 2024-09-30 12:21:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:18 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:18 --> URI Class Initialized
INFO - 2024-09-30 12:21:18 --> Router Class Initialized
INFO - 2024-09-30 12:21:18 --> Output Class Initialized
INFO - 2024-09-30 12:21:18 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:18 --> Input Class Initialized
INFO - 2024-09-30 12:21:18 --> Language Class Initialized
INFO - 2024-09-30 12:21:18 --> Language Class Initialized
INFO - 2024-09-30 12:21:18 --> Config Class Initialized
INFO - 2024-09-30 12:21:18 --> Loader Class Initialized
INFO - 2024-09-30 12:21:18 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:18 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:18 --> Controller Class Initialized
DEBUG - 2024-09-30 12:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:21:18 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:18 --> Total execution time: 0.0311
INFO - 2024-09-30 12:21:18 --> Config Class Initialized
INFO - 2024-09-30 12:21:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:18 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:18 --> URI Class Initialized
INFO - 2024-09-30 12:21:18 --> Router Class Initialized
INFO - 2024-09-30 12:21:18 --> Output Class Initialized
INFO - 2024-09-30 12:21:18 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:18 --> Input Class Initialized
INFO - 2024-09-30 12:21:18 --> Language Class Initialized
INFO - 2024-09-30 12:21:18 --> Language Class Initialized
INFO - 2024-09-30 12:21:18 --> Config Class Initialized
INFO - 2024-09-30 12:21:18 --> Loader Class Initialized
INFO - 2024-09-30 12:21:18 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:18 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:18 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:18 --> Controller Class Initialized
INFO - 2024-09-30 12:21:20 --> Config Class Initialized
INFO - 2024-09-30 12:21:20 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:20 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:20 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:20 --> URI Class Initialized
INFO - 2024-09-30 12:21:20 --> Router Class Initialized
INFO - 2024-09-30 12:21:20 --> Output Class Initialized
INFO - 2024-09-30 12:21:20 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:20 --> Input Class Initialized
INFO - 2024-09-30 12:21:20 --> Language Class Initialized
INFO - 2024-09-30 12:21:20 --> Language Class Initialized
INFO - 2024-09-30 12:21:20 --> Config Class Initialized
INFO - 2024-09-30 12:21:20 --> Loader Class Initialized
INFO - 2024-09-30 12:21:20 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:20 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:20 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:20 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:20 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:20 --> Controller Class Initialized
INFO - 2024-09-30 12:21:20 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:20 --> Total execution time: 0.0365
INFO - 2024-09-30 12:21:44 --> Config Class Initialized
INFO - 2024-09-30 12:21:44 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:44 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:44 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:44 --> URI Class Initialized
INFO - 2024-09-30 12:21:44 --> Router Class Initialized
INFO - 2024-09-30 12:21:44 --> Output Class Initialized
INFO - 2024-09-30 12:21:44 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:44 --> Input Class Initialized
INFO - 2024-09-30 12:21:44 --> Language Class Initialized
INFO - 2024-09-30 12:21:44 --> Language Class Initialized
INFO - 2024-09-30 12:21:44 --> Config Class Initialized
INFO - 2024-09-30 12:21:44 --> Loader Class Initialized
INFO - 2024-09-30 12:21:44 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:44 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:44 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:44 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:44 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:44 --> Controller Class Initialized
ERROR - 2024-09-30 12:21:44 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 12:21:44 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:44 --> Total execution time: 0.0314
INFO - 2024-09-30 12:21:46 --> Config Class Initialized
INFO - 2024-09-30 12:21:46 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:46 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:46 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:46 --> URI Class Initialized
INFO - 2024-09-30 12:21:46 --> Router Class Initialized
INFO - 2024-09-30 12:21:46 --> Output Class Initialized
INFO - 2024-09-30 12:21:46 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:46 --> Input Class Initialized
INFO - 2024-09-30 12:21:46 --> Language Class Initialized
INFO - 2024-09-30 12:21:46 --> Language Class Initialized
INFO - 2024-09-30 12:21:46 --> Config Class Initialized
INFO - 2024-09-30 12:21:46 --> Loader Class Initialized
INFO - 2024-09-30 12:21:46 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:46 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:46 --> Controller Class Initialized
DEBUG - 2024-09-30 12:21:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:21:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:21:46 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:46 --> Total execution time: 0.0564
INFO - 2024-09-30 12:21:46 --> Config Class Initialized
INFO - 2024-09-30 12:21:46 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:46 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:46 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:46 --> URI Class Initialized
INFO - 2024-09-30 12:21:46 --> Router Class Initialized
INFO - 2024-09-30 12:21:46 --> Output Class Initialized
INFO - 2024-09-30 12:21:46 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:46 --> Input Class Initialized
INFO - 2024-09-30 12:21:46 --> Language Class Initialized
INFO - 2024-09-30 12:21:46 --> Language Class Initialized
INFO - 2024-09-30 12:21:46 --> Config Class Initialized
INFO - 2024-09-30 12:21:46 --> Loader Class Initialized
INFO - 2024-09-30 12:21:46 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:46 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:46 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:46 --> Controller Class Initialized
INFO - 2024-09-30 12:21:48 --> Config Class Initialized
INFO - 2024-09-30 12:21:48 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:21:48 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:21:48 --> Utf8 Class Initialized
INFO - 2024-09-30 12:21:48 --> URI Class Initialized
INFO - 2024-09-30 12:21:48 --> Router Class Initialized
INFO - 2024-09-30 12:21:48 --> Output Class Initialized
INFO - 2024-09-30 12:21:48 --> Security Class Initialized
DEBUG - 2024-09-30 12:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:21:48 --> Input Class Initialized
INFO - 2024-09-30 12:21:48 --> Language Class Initialized
INFO - 2024-09-30 12:21:48 --> Language Class Initialized
INFO - 2024-09-30 12:21:48 --> Config Class Initialized
INFO - 2024-09-30 12:21:48 --> Loader Class Initialized
INFO - 2024-09-30 12:21:48 --> Helper loaded: url_helper
INFO - 2024-09-30 12:21:48 --> Helper loaded: file_helper
INFO - 2024-09-30 12:21:48 --> Helper loaded: form_helper
INFO - 2024-09-30 12:21:48 --> Helper loaded: my_helper
INFO - 2024-09-30 12:21:48 --> Database Driver Class Initialized
INFO - 2024-09-30 12:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:21:48 --> Controller Class Initialized
INFO - 2024-09-30 12:21:48 --> Final output sent to browser
DEBUG - 2024-09-30 12:21:48 --> Total execution time: 0.0244
INFO - 2024-09-30 12:22:02 --> Config Class Initialized
INFO - 2024-09-30 12:22:02 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:02 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:02 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:02 --> URI Class Initialized
INFO - 2024-09-30 12:22:02 --> Router Class Initialized
INFO - 2024-09-30 12:22:02 --> Output Class Initialized
INFO - 2024-09-30 12:22:02 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:02 --> Input Class Initialized
INFO - 2024-09-30 12:22:02 --> Language Class Initialized
INFO - 2024-09-30 12:22:02 --> Language Class Initialized
INFO - 2024-09-30 12:22:02 --> Config Class Initialized
INFO - 2024-09-30 12:22:02 --> Loader Class Initialized
INFO - 2024-09-30 12:22:02 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:02 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:02 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:02 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:02 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:02 --> Controller Class Initialized
ERROR - 2024-09-30 12:22:02 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 12:22:02 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:02 --> Total execution time: 0.1074
INFO - 2024-09-30 12:22:20 --> Config Class Initialized
INFO - 2024-09-30 12:22:20 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:20 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:20 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:20 --> URI Class Initialized
INFO - 2024-09-30 12:22:20 --> Router Class Initialized
INFO - 2024-09-30 12:22:20 --> Output Class Initialized
INFO - 2024-09-30 12:22:20 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:20 --> Input Class Initialized
INFO - 2024-09-30 12:22:20 --> Language Class Initialized
INFO - 2024-09-30 12:22:20 --> Language Class Initialized
INFO - 2024-09-30 12:22:20 --> Config Class Initialized
INFO - 2024-09-30 12:22:20 --> Loader Class Initialized
INFO - 2024-09-30 12:22:20 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:20 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:20 --> Controller Class Initialized
DEBUG - 2024-09-30 12:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:22:20 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:20 --> Total execution time: 0.0925
INFO - 2024-09-30 12:22:20 --> Config Class Initialized
INFO - 2024-09-30 12:22:20 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:20 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:20 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:20 --> URI Class Initialized
INFO - 2024-09-30 12:22:20 --> Router Class Initialized
INFO - 2024-09-30 12:22:20 --> Output Class Initialized
INFO - 2024-09-30 12:22:20 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:20 --> Input Class Initialized
INFO - 2024-09-30 12:22:20 --> Language Class Initialized
INFO - 2024-09-30 12:22:20 --> Language Class Initialized
INFO - 2024-09-30 12:22:20 --> Config Class Initialized
INFO - 2024-09-30 12:22:20 --> Loader Class Initialized
INFO - 2024-09-30 12:22:20 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:20 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:20 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:20 --> Controller Class Initialized
INFO - 2024-09-30 12:22:22 --> Config Class Initialized
INFO - 2024-09-30 12:22:22 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:22 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:22 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:22 --> URI Class Initialized
INFO - 2024-09-30 12:22:22 --> Router Class Initialized
INFO - 2024-09-30 12:22:22 --> Output Class Initialized
INFO - 2024-09-30 12:22:22 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:22 --> Input Class Initialized
INFO - 2024-09-30 12:22:22 --> Language Class Initialized
INFO - 2024-09-30 12:22:22 --> Language Class Initialized
INFO - 2024-09-30 12:22:22 --> Config Class Initialized
INFO - 2024-09-30 12:22:22 --> Loader Class Initialized
INFO - 2024-09-30 12:22:22 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:22 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:22 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:22 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:22 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:22 --> Controller Class Initialized
INFO - 2024-09-30 12:22:22 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:22 --> Total execution time: 0.0290
INFO - 2024-09-30 12:22:49 --> Config Class Initialized
INFO - 2024-09-30 12:22:49 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:49 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:49 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:49 --> URI Class Initialized
INFO - 2024-09-30 12:22:49 --> Router Class Initialized
INFO - 2024-09-30 12:22:49 --> Output Class Initialized
INFO - 2024-09-30 12:22:49 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:49 --> Input Class Initialized
INFO - 2024-09-30 12:22:49 --> Language Class Initialized
INFO - 2024-09-30 12:22:49 --> Language Class Initialized
INFO - 2024-09-30 12:22:49 --> Config Class Initialized
INFO - 2024-09-30 12:22:49 --> Loader Class Initialized
INFO - 2024-09-30 12:22:49 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:49 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:49 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:49 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:49 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:49 --> Controller Class Initialized
ERROR - 2024-09-30 12:22:49 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 12:22:49 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:49 --> Total execution time: 0.0398
INFO - 2024-09-30 12:22:54 --> Config Class Initialized
INFO - 2024-09-30 12:22:54 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:54 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:54 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:54 --> URI Class Initialized
INFO - 2024-09-30 12:22:54 --> Router Class Initialized
INFO - 2024-09-30 12:22:54 --> Output Class Initialized
INFO - 2024-09-30 12:22:54 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:54 --> Input Class Initialized
INFO - 2024-09-30 12:22:54 --> Language Class Initialized
INFO - 2024-09-30 12:22:54 --> Language Class Initialized
INFO - 2024-09-30 12:22:54 --> Config Class Initialized
INFO - 2024-09-30 12:22:54 --> Loader Class Initialized
INFO - 2024-09-30 12:22:54 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:54 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:54 --> Controller Class Initialized
DEBUG - 2024-09-30 12:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:22:54 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:54 --> Total execution time: 0.0340
INFO - 2024-09-30 12:22:54 --> Config Class Initialized
INFO - 2024-09-30 12:22:54 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:54 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:54 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:54 --> URI Class Initialized
INFO - 2024-09-30 12:22:54 --> Router Class Initialized
INFO - 2024-09-30 12:22:54 --> Output Class Initialized
INFO - 2024-09-30 12:22:54 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:54 --> Input Class Initialized
INFO - 2024-09-30 12:22:54 --> Language Class Initialized
INFO - 2024-09-30 12:22:54 --> Language Class Initialized
INFO - 2024-09-30 12:22:54 --> Config Class Initialized
INFO - 2024-09-30 12:22:54 --> Loader Class Initialized
INFO - 2024-09-30 12:22:54 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:54 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:54 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:54 --> Controller Class Initialized
INFO - 2024-09-30 12:22:56 --> Config Class Initialized
INFO - 2024-09-30 12:22:56 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:22:56 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:22:56 --> Utf8 Class Initialized
INFO - 2024-09-30 12:22:56 --> URI Class Initialized
INFO - 2024-09-30 12:22:56 --> Router Class Initialized
INFO - 2024-09-30 12:22:56 --> Output Class Initialized
INFO - 2024-09-30 12:22:56 --> Security Class Initialized
DEBUG - 2024-09-30 12:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:22:56 --> Input Class Initialized
INFO - 2024-09-30 12:22:56 --> Language Class Initialized
INFO - 2024-09-30 12:22:56 --> Language Class Initialized
INFO - 2024-09-30 12:22:56 --> Config Class Initialized
INFO - 2024-09-30 12:22:56 --> Loader Class Initialized
INFO - 2024-09-30 12:22:56 --> Helper loaded: url_helper
INFO - 2024-09-30 12:22:56 --> Helper loaded: file_helper
INFO - 2024-09-30 12:22:56 --> Helper loaded: form_helper
INFO - 2024-09-30 12:22:56 --> Helper loaded: my_helper
INFO - 2024-09-30 12:22:56 --> Database Driver Class Initialized
INFO - 2024-09-30 12:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:22:56 --> Controller Class Initialized
INFO - 2024-09-30 12:22:56 --> Final output sent to browser
DEBUG - 2024-09-30 12:22:56 --> Total execution time: 0.0285
INFO - 2024-09-30 12:23:01 --> Config Class Initialized
INFO - 2024-09-30 12:23:01 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:23:01 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:23:01 --> Utf8 Class Initialized
INFO - 2024-09-30 12:23:01 --> URI Class Initialized
INFO - 2024-09-30 12:23:01 --> Router Class Initialized
INFO - 2024-09-30 12:23:01 --> Output Class Initialized
INFO - 2024-09-30 12:23:01 --> Security Class Initialized
DEBUG - 2024-09-30 12:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:23:01 --> Input Class Initialized
INFO - 2024-09-30 12:23:01 --> Language Class Initialized
INFO - 2024-09-30 12:23:01 --> Language Class Initialized
INFO - 2024-09-30 12:23:01 --> Config Class Initialized
INFO - 2024-09-30 12:23:01 --> Loader Class Initialized
INFO - 2024-09-30 12:23:01 --> Helper loaded: url_helper
INFO - 2024-09-30 12:23:01 --> Helper loaded: file_helper
INFO - 2024-09-30 12:23:01 --> Helper loaded: form_helper
INFO - 2024-09-30 12:23:01 --> Helper loaded: my_helper
INFO - 2024-09-30 12:23:01 --> Database Driver Class Initialized
INFO - 2024-09-30 12:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:23:01 --> Controller Class Initialized
ERROR - 2024-09-30 12:23:01 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2024-09-30 12:23:01 --> Final output sent to browser
DEBUG - 2024-09-30 12:23:01 --> Total execution time: 0.1105
INFO - 2024-09-30 12:23:16 --> Config Class Initialized
INFO - 2024-09-30 12:23:16 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:23:16 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:23:16 --> Utf8 Class Initialized
INFO - 2024-09-30 12:23:16 --> URI Class Initialized
INFO - 2024-09-30 12:23:16 --> Router Class Initialized
INFO - 2024-09-30 12:23:16 --> Output Class Initialized
INFO - 2024-09-30 12:23:16 --> Security Class Initialized
DEBUG - 2024-09-30 12:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:23:16 --> Input Class Initialized
INFO - 2024-09-30 12:23:16 --> Language Class Initialized
INFO - 2024-09-30 12:23:16 --> Language Class Initialized
INFO - 2024-09-30 12:23:16 --> Config Class Initialized
INFO - 2024-09-30 12:23:16 --> Loader Class Initialized
INFO - 2024-09-30 12:23:16 --> Helper loaded: url_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: file_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: form_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: my_helper
INFO - 2024-09-30 12:23:16 --> Database Driver Class Initialized
INFO - 2024-09-30 12:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:23:16 --> Controller Class Initialized
DEBUG - 2024-09-30 12:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:23:16 --> Final output sent to browser
DEBUG - 2024-09-30 12:23:16 --> Total execution time: 0.0291
INFO - 2024-09-30 12:23:16 --> Config Class Initialized
INFO - 2024-09-30 12:23:16 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:23:16 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:23:16 --> Utf8 Class Initialized
INFO - 2024-09-30 12:23:16 --> URI Class Initialized
INFO - 2024-09-30 12:23:16 --> Router Class Initialized
INFO - 2024-09-30 12:23:16 --> Output Class Initialized
INFO - 2024-09-30 12:23:16 --> Security Class Initialized
DEBUG - 2024-09-30 12:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:23:16 --> Input Class Initialized
INFO - 2024-09-30 12:23:16 --> Language Class Initialized
INFO - 2024-09-30 12:23:16 --> Language Class Initialized
INFO - 2024-09-30 12:23:16 --> Config Class Initialized
INFO - 2024-09-30 12:23:16 --> Loader Class Initialized
INFO - 2024-09-30 12:23:16 --> Helper loaded: url_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: file_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: form_helper
INFO - 2024-09-30 12:23:16 --> Helper loaded: my_helper
INFO - 2024-09-30 12:23:16 --> Database Driver Class Initialized
INFO - 2024-09-30 12:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:23:16 --> Controller Class Initialized
INFO - 2024-09-30 12:23:18 --> Config Class Initialized
INFO - 2024-09-30 12:23:18 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:23:18 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:23:18 --> Utf8 Class Initialized
INFO - 2024-09-30 12:23:18 --> URI Class Initialized
INFO - 2024-09-30 12:23:18 --> Router Class Initialized
INFO - 2024-09-30 12:23:18 --> Output Class Initialized
INFO - 2024-09-30 12:23:18 --> Security Class Initialized
DEBUG - 2024-09-30 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:23:18 --> Input Class Initialized
INFO - 2024-09-30 12:23:18 --> Language Class Initialized
INFO - 2024-09-30 12:23:18 --> Language Class Initialized
INFO - 2024-09-30 12:23:18 --> Config Class Initialized
INFO - 2024-09-30 12:23:18 --> Loader Class Initialized
INFO - 2024-09-30 12:23:18 --> Helper loaded: url_helper
INFO - 2024-09-30 12:23:18 --> Helper loaded: file_helper
INFO - 2024-09-30 12:23:18 --> Helper loaded: form_helper
INFO - 2024-09-30 12:23:18 --> Helper loaded: my_helper
INFO - 2024-09-30 12:23:18 --> Database Driver Class Initialized
INFO - 2024-09-30 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:23:18 --> Controller Class Initialized
INFO - 2024-09-30 12:23:18 --> Final output sent to browser
DEBUG - 2024-09-30 12:23:18 --> Total execution time: 0.0299
INFO - 2024-09-30 12:23:46 --> Config Class Initialized
INFO - 2024-09-30 12:23:46 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:23:46 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:23:46 --> Utf8 Class Initialized
INFO - 2024-09-30 12:23:46 --> URI Class Initialized
INFO - 2024-09-30 12:23:46 --> Router Class Initialized
INFO - 2024-09-30 12:23:46 --> Output Class Initialized
INFO - 2024-09-30 12:23:46 --> Security Class Initialized
DEBUG - 2024-09-30 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:23:46 --> Input Class Initialized
INFO - 2024-09-30 12:23:46 --> Language Class Initialized
INFO - 2024-09-30 12:23:46 --> Language Class Initialized
INFO - 2024-09-30 12:23:46 --> Config Class Initialized
INFO - 2024-09-30 12:23:46 --> Loader Class Initialized
INFO - 2024-09-30 12:23:46 --> Helper loaded: url_helper
INFO - 2024-09-30 12:23:46 --> Helper loaded: file_helper
INFO - 2024-09-30 12:23:46 --> Helper loaded: form_helper
INFO - 2024-09-30 12:23:46 --> Helper loaded: my_helper
INFO - 2024-09-30 12:23:46 --> Database Driver Class Initialized
INFO - 2024-09-30 12:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:23:46 --> Controller Class Initialized
ERROR - 2024-09-30 12:23:46 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-09-30 12:23:46 --> Final output sent to browser
DEBUG - 2024-09-30 12:23:46 --> Total execution time: 0.0408
INFO - 2024-09-30 12:24:03 --> Config Class Initialized
INFO - 2024-09-30 12:24:03 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:24:03 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:24:03 --> Utf8 Class Initialized
INFO - 2024-09-30 12:24:03 --> URI Class Initialized
INFO - 2024-09-30 12:24:03 --> Router Class Initialized
INFO - 2024-09-30 12:24:03 --> Output Class Initialized
INFO - 2024-09-30 12:24:03 --> Security Class Initialized
DEBUG - 2024-09-30 12:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:24:03 --> Input Class Initialized
INFO - 2024-09-30 12:24:03 --> Language Class Initialized
INFO - 2024-09-30 12:24:03 --> Language Class Initialized
INFO - 2024-09-30 12:24:03 --> Config Class Initialized
INFO - 2024-09-30 12:24:03 --> Loader Class Initialized
INFO - 2024-09-30 12:24:03 --> Helper loaded: url_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: file_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: form_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: my_helper
INFO - 2024-09-30 12:24:03 --> Database Driver Class Initialized
INFO - 2024-09-30 12:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:24:03 --> Controller Class Initialized
DEBUG - 2024-09-30 12:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-09-30 12:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:24:03 --> Final output sent to browser
DEBUG - 2024-09-30 12:24:03 --> Total execution time: 0.0345
INFO - 2024-09-30 12:24:03 --> Config Class Initialized
INFO - 2024-09-30 12:24:03 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:24:03 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:24:03 --> Utf8 Class Initialized
INFO - 2024-09-30 12:24:03 --> URI Class Initialized
INFO - 2024-09-30 12:24:03 --> Router Class Initialized
INFO - 2024-09-30 12:24:03 --> Output Class Initialized
INFO - 2024-09-30 12:24:03 --> Security Class Initialized
DEBUG - 2024-09-30 12:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:24:03 --> Input Class Initialized
INFO - 2024-09-30 12:24:03 --> Language Class Initialized
INFO - 2024-09-30 12:24:03 --> Language Class Initialized
INFO - 2024-09-30 12:24:03 --> Config Class Initialized
INFO - 2024-09-30 12:24:03 --> Loader Class Initialized
INFO - 2024-09-30 12:24:03 --> Helper loaded: url_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: file_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: form_helper
INFO - 2024-09-30 12:24:03 --> Helper loaded: my_helper
INFO - 2024-09-30 12:24:03 --> Database Driver Class Initialized
INFO - 2024-09-30 12:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:24:03 --> Controller Class Initialized
INFO - 2024-09-30 12:28:34 --> Config Class Initialized
INFO - 2024-09-30 12:28:34 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:34 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:34 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:34 --> URI Class Initialized
INFO - 2024-09-30 12:28:34 --> Router Class Initialized
INFO - 2024-09-30 12:28:34 --> Output Class Initialized
INFO - 2024-09-30 12:28:34 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:34 --> Input Class Initialized
INFO - 2024-09-30 12:28:34 --> Language Class Initialized
INFO - 2024-09-30 12:28:34 --> Language Class Initialized
INFO - 2024-09-30 12:28:34 --> Config Class Initialized
INFO - 2024-09-30 12:28:34 --> Loader Class Initialized
INFO - 2024-09-30 12:28:34 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:34 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:34 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:34 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:34 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:34 --> Controller Class Initialized
INFO - 2024-09-30 12:28:34 --> Final output sent to browser
DEBUG - 2024-09-30 12:28:34 --> Total execution time: 0.0587
INFO - 2024-09-30 12:28:39 --> Config Class Initialized
INFO - 2024-09-30 12:28:39 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:39 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:39 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:39 --> URI Class Initialized
INFO - 2024-09-30 12:28:39 --> Router Class Initialized
INFO - 2024-09-30 12:28:39 --> Output Class Initialized
INFO - 2024-09-30 12:28:39 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:39 --> Input Class Initialized
INFO - 2024-09-30 12:28:39 --> Language Class Initialized
INFO - 2024-09-30 12:28:39 --> Language Class Initialized
INFO - 2024-09-30 12:28:39 --> Config Class Initialized
INFO - 2024-09-30 12:28:39 --> Loader Class Initialized
INFO - 2024-09-30 12:28:39 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:39 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:39 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:39 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:39 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:39 --> Controller Class Initialized
DEBUG - 2024-09-30 12:28:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 12:28:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:28:39 --> Final output sent to browser
DEBUG - 2024-09-30 12:28:39 --> Total execution time: 0.0354
INFO - 2024-09-30 12:28:42 --> Config Class Initialized
INFO - 2024-09-30 12:28:42 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:42 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:42 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:42 --> URI Class Initialized
INFO - 2024-09-30 12:28:42 --> Router Class Initialized
INFO - 2024-09-30 12:28:42 --> Output Class Initialized
INFO - 2024-09-30 12:28:42 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:42 --> Input Class Initialized
INFO - 2024-09-30 12:28:42 --> Language Class Initialized
INFO - 2024-09-30 12:28:42 --> Language Class Initialized
INFO - 2024-09-30 12:28:42 --> Config Class Initialized
INFO - 2024-09-30 12:28:42 --> Loader Class Initialized
INFO - 2024-09-30 12:28:42 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:42 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:42 --> Controller Class Initialized
DEBUG - 2024-09-30 12:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-30 12:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:28:42 --> Final output sent to browser
DEBUG - 2024-09-30 12:28:42 --> Total execution time: 0.0341
INFO - 2024-09-30 12:28:42 --> Config Class Initialized
INFO - 2024-09-30 12:28:42 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:42 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:42 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:42 --> URI Class Initialized
INFO - 2024-09-30 12:28:42 --> Router Class Initialized
INFO - 2024-09-30 12:28:42 --> Output Class Initialized
INFO - 2024-09-30 12:28:42 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:42 --> Input Class Initialized
INFO - 2024-09-30 12:28:42 --> Language Class Initialized
INFO - 2024-09-30 12:28:42 --> Language Class Initialized
INFO - 2024-09-30 12:28:42 --> Config Class Initialized
INFO - 2024-09-30 12:28:42 --> Loader Class Initialized
INFO - 2024-09-30 12:28:42 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:42 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:42 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:42 --> Controller Class Initialized
INFO - 2024-09-30 12:28:43 --> Config Class Initialized
INFO - 2024-09-30 12:28:43 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:43 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:43 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:43 --> URI Class Initialized
INFO - 2024-09-30 12:28:43 --> Router Class Initialized
INFO - 2024-09-30 12:28:43 --> Output Class Initialized
INFO - 2024-09-30 12:28:43 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:43 --> Input Class Initialized
INFO - 2024-09-30 12:28:43 --> Language Class Initialized
INFO - 2024-09-30 12:28:43 --> Language Class Initialized
INFO - 2024-09-30 12:28:43 --> Config Class Initialized
INFO - 2024-09-30 12:28:43 --> Loader Class Initialized
INFO - 2024-09-30 12:28:43 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:43 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:43 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:43 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:43 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:43 --> Controller Class Initialized
DEBUG - 2024-09-30 12:28:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 12:28:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:28:43 --> Final output sent to browser
DEBUG - 2024-09-30 12:28:43 --> Total execution time: 0.0548
INFO - 2024-09-30 12:28:44 --> Config Class Initialized
INFO - 2024-09-30 12:28:44 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:44 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:44 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:44 --> URI Class Initialized
INFO - 2024-09-30 12:28:44 --> Router Class Initialized
INFO - 2024-09-30 12:28:44 --> Output Class Initialized
INFO - 2024-09-30 12:28:44 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:44 --> Input Class Initialized
INFO - 2024-09-30 12:28:44 --> Language Class Initialized
INFO - 2024-09-30 12:28:44 --> Language Class Initialized
INFO - 2024-09-30 12:28:44 --> Config Class Initialized
INFO - 2024-09-30 12:28:44 --> Loader Class Initialized
INFO - 2024-09-30 12:28:44 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:44 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:44 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:44 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:44 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:44 --> Controller Class Initialized
DEBUG - 2024-09-30 12:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-30 12:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:28:44 --> Final output sent to browser
DEBUG - 2024-09-30 12:28:44 --> Total execution time: 0.0328
INFO - 2024-09-30 12:28:47 --> Config Class Initialized
INFO - 2024-09-30 12:28:47 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:28:47 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:28:47 --> Utf8 Class Initialized
INFO - 2024-09-30 12:28:47 --> URI Class Initialized
INFO - 2024-09-30 12:28:47 --> Router Class Initialized
INFO - 2024-09-30 12:28:47 --> Output Class Initialized
INFO - 2024-09-30 12:28:47 --> Security Class Initialized
DEBUG - 2024-09-30 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:28:47 --> Input Class Initialized
INFO - 2024-09-30 12:28:47 --> Language Class Initialized
INFO - 2024-09-30 12:28:47 --> Language Class Initialized
INFO - 2024-09-30 12:28:47 --> Config Class Initialized
INFO - 2024-09-30 12:28:47 --> Loader Class Initialized
INFO - 2024-09-30 12:28:47 --> Helper loaded: url_helper
INFO - 2024-09-30 12:28:47 --> Helper loaded: file_helper
INFO - 2024-09-30 12:28:47 --> Helper loaded: form_helper
INFO - 2024-09-30 12:28:47 --> Helper loaded: my_helper
INFO - 2024-09-30 12:28:47 --> Database Driver Class Initialized
INFO - 2024-09-30 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:28:47 --> Controller Class Initialized
INFO - 2024-09-30 12:34:59 --> Config Class Initialized
INFO - 2024-09-30 12:34:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:34:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:34:59 --> Utf8 Class Initialized
INFO - 2024-09-30 12:34:59 --> URI Class Initialized
INFO - 2024-09-30 12:34:59 --> Router Class Initialized
INFO - 2024-09-30 12:34:59 --> Output Class Initialized
INFO - 2024-09-30 12:34:59 --> Security Class Initialized
DEBUG - 2024-09-30 12:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:34:59 --> Input Class Initialized
INFO - 2024-09-30 12:34:59 --> Language Class Initialized
INFO - 2024-09-30 12:34:59 --> Language Class Initialized
INFO - 2024-09-30 12:34:59 --> Config Class Initialized
INFO - 2024-09-30 12:34:59 --> Loader Class Initialized
INFO - 2024-09-30 12:34:59 --> Helper loaded: url_helper
INFO - 2024-09-30 12:34:59 --> Helper loaded: file_helper
INFO - 2024-09-30 12:34:59 --> Helper loaded: form_helper
INFO - 2024-09-30 12:34:59 --> Helper loaded: my_helper
INFO - 2024-09-30 12:34:59 --> Database Driver Class Initialized
INFO - 2024-09-30 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:34:59 --> Controller Class Initialized
DEBUG - 2024-09-30 12:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-09-30 12:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:34:59 --> Final output sent to browser
DEBUG - 2024-09-30 12:34:59 --> Total execution time: 0.0461
INFO - 2024-09-30 12:35:05 --> Config Class Initialized
INFO - 2024-09-30 12:35:05 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:35:05 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:35:05 --> Utf8 Class Initialized
INFO - 2024-09-30 12:35:05 --> URI Class Initialized
INFO - 2024-09-30 12:35:05 --> Router Class Initialized
INFO - 2024-09-30 12:35:05 --> Output Class Initialized
INFO - 2024-09-30 12:35:05 --> Security Class Initialized
DEBUG - 2024-09-30 12:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:35:05 --> Input Class Initialized
INFO - 2024-09-30 12:35:05 --> Language Class Initialized
INFO - 2024-09-30 12:35:05 --> Language Class Initialized
INFO - 2024-09-30 12:35:05 --> Config Class Initialized
INFO - 2024-09-30 12:35:05 --> Loader Class Initialized
INFO - 2024-09-30 12:35:05 --> Helper loaded: url_helper
INFO - 2024-09-30 12:35:05 --> Helper loaded: file_helper
INFO - 2024-09-30 12:35:05 --> Helper loaded: form_helper
INFO - 2024-09-30 12:35:05 --> Helper loaded: my_helper
INFO - 2024-09-30 12:35:05 --> Database Driver Class Initialized
INFO - 2024-09-30 12:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:35:05 --> Controller Class Initialized
INFO - 2024-09-30 12:35:05 --> Config Class Initialized
INFO - 2024-09-30 12:35:05 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:35:05 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:35:05 --> Utf8 Class Initialized
INFO - 2024-09-30 12:35:05 --> URI Class Initialized
INFO - 2024-09-30 12:35:05 --> Router Class Initialized
INFO - 2024-09-30 12:35:05 --> Output Class Initialized
INFO - 2024-09-30 12:35:05 --> Security Class Initialized
DEBUG - 2024-09-30 12:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:35:05 --> Input Class Initialized
INFO - 2024-09-30 12:35:05 --> Language Class Initialized
INFO - 2024-09-30 12:35:05 --> Language Class Initialized
INFO - 2024-09-30 12:35:05 --> Config Class Initialized
INFO - 2024-09-30 12:35:05 --> Loader Class Initialized
INFO - 2024-09-30 12:35:06 --> Helper loaded: url_helper
INFO - 2024-09-30 12:35:06 --> Helper loaded: file_helper
INFO - 2024-09-30 12:35:06 --> Helper loaded: form_helper
INFO - 2024-09-30 12:35:06 --> Helper loaded: my_helper
INFO - 2024-09-30 12:35:06 --> Database Driver Class Initialized
INFO - 2024-09-30 12:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:35:06 --> Controller Class Initialized
DEBUG - 2024-09-30 12:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-30 12:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:35:06 --> Final output sent to browser
DEBUG - 2024-09-30 12:35:06 --> Total execution time: 0.0454
INFO - 2024-09-30 12:35:07 --> Config Class Initialized
INFO - 2024-09-30 12:35:07 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:35:07 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:35:07 --> Utf8 Class Initialized
INFO - 2024-09-30 12:35:07 --> URI Class Initialized
INFO - 2024-09-30 12:35:07 --> Router Class Initialized
INFO - 2024-09-30 12:35:07 --> Output Class Initialized
INFO - 2024-09-30 12:35:07 --> Security Class Initialized
DEBUG - 2024-09-30 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:35:07 --> Input Class Initialized
INFO - 2024-09-30 12:35:07 --> Language Class Initialized
INFO - 2024-09-30 12:35:07 --> Language Class Initialized
INFO - 2024-09-30 12:35:07 --> Config Class Initialized
INFO - 2024-09-30 12:35:07 --> Loader Class Initialized
INFO - 2024-09-30 12:35:07 --> Helper loaded: url_helper
INFO - 2024-09-30 12:35:07 --> Helper loaded: file_helper
INFO - 2024-09-30 12:35:07 --> Helper loaded: form_helper
INFO - 2024-09-30 12:35:07 --> Helper loaded: my_helper
INFO - 2024-09-30 12:35:07 --> Database Driver Class Initialized
INFO - 2024-09-30 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:35:07 --> Controller Class Initialized
INFO - 2024-09-30 12:35:07 --> Final output sent to browser
DEBUG - 2024-09-30 12:35:07 --> Total execution time: 0.0512
INFO - 2024-09-30 12:35:13 --> Config Class Initialized
INFO - 2024-09-30 12:35:13 --> Hooks Class Initialized
DEBUG - 2024-09-30 12:35:13 --> UTF-8 Support Enabled
INFO - 2024-09-30 12:35:13 --> Utf8 Class Initialized
INFO - 2024-09-30 12:35:13 --> URI Class Initialized
INFO - 2024-09-30 12:35:13 --> Router Class Initialized
INFO - 2024-09-30 12:35:13 --> Output Class Initialized
INFO - 2024-09-30 12:35:13 --> Security Class Initialized
DEBUG - 2024-09-30 12:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 12:35:13 --> Input Class Initialized
INFO - 2024-09-30 12:35:13 --> Language Class Initialized
INFO - 2024-09-30 12:35:13 --> Language Class Initialized
INFO - 2024-09-30 12:35:13 --> Config Class Initialized
INFO - 2024-09-30 12:35:13 --> Loader Class Initialized
INFO - 2024-09-30 12:35:13 --> Helper loaded: url_helper
INFO - 2024-09-30 12:35:13 --> Helper loaded: file_helper
INFO - 2024-09-30 12:35:13 --> Helper loaded: form_helper
INFO - 2024-09-30 12:35:13 --> Helper loaded: my_helper
INFO - 2024-09-30 12:35:13 --> Database Driver Class Initialized
INFO - 2024-09-30 12:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 12:35:13 --> Controller Class Initialized
DEBUG - 2024-09-30 12:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 12:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 12:35:13 --> Final output sent to browser
DEBUG - 2024-09-30 12:35:13 --> Total execution time: 0.0301
INFO - 2024-09-30 14:00:57 --> Config Class Initialized
INFO - 2024-09-30 14:00:57 --> Hooks Class Initialized
DEBUG - 2024-09-30 14:00:57 --> UTF-8 Support Enabled
INFO - 2024-09-30 14:00:57 --> Utf8 Class Initialized
INFO - 2024-09-30 14:00:57 --> URI Class Initialized
INFO - 2024-09-30 14:00:57 --> Router Class Initialized
INFO - 2024-09-30 14:00:57 --> Output Class Initialized
INFO - 2024-09-30 14:00:57 --> Security Class Initialized
DEBUG - 2024-09-30 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 14:00:57 --> Input Class Initialized
INFO - 2024-09-30 14:00:57 --> Language Class Initialized
INFO - 2024-09-30 14:00:57 --> Language Class Initialized
INFO - 2024-09-30 14:00:57 --> Config Class Initialized
INFO - 2024-09-30 14:00:57 --> Loader Class Initialized
INFO - 2024-09-30 14:00:57 --> Helper loaded: url_helper
INFO - 2024-09-30 14:00:57 --> Helper loaded: file_helper
INFO - 2024-09-30 14:00:57 --> Helper loaded: form_helper
INFO - 2024-09-30 14:00:57 --> Helper loaded: my_helper
INFO - 2024-09-30 14:00:57 --> Database Driver Class Initialized
INFO - 2024-09-30 14:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 14:00:57 --> Controller Class Initialized
DEBUG - 2024-09-30 14:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-30 14:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 14:00:57 --> Final output sent to browser
DEBUG - 2024-09-30 14:00:57 --> Total execution time: 0.0618
INFO - 2024-09-30 14:00:59 --> Config Class Initialized
INFO - 2024-09-30 14:00:59 --> Hooks Class Initialized
DEBUG - 2024-09-30 14:00:59 --> UTF-8 Support Enabled
INFO - 2024-09-30 14:00:59 --> Utf8 Class Initialized
INFO - 2024-09-30 14:00:59 --> URI Class Initialized
INFO - 2024-09-30 14:00:59 --> Router Class Initialized
INFO - 2024-09-30 14:00:59 --> Output Class Initialized
INFO - 2024-09-30 14:00:59 --> Security Class Initialized
DEBUG - 2024-09-30 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 14:00:59 --> Input Class Initialized
INFO - 2024-09-30 14:00:59 --> Language Class Initialized
INFO - 2024-09-30 14:00:59 --> Language Class Initialized
INFO - 2024-09-30 14:00:59 --> Config Class Initialized
INFO - 2024-09-30 14:00:59 --> Loader Class Initialized
INFO - 2024-09-30 14:00:59 --> Helper loaded: url_helper
INFO - 2024-09-30 14:00:59 --> Helper loaded: file_helper
INFO - 2024-09-30 14:00:59 --> Helper loaded: form_helper
INFO - 2024-09-30 14:00:59 --> Helper loaded: my_helper
INFO - 2024-09-30 14:00:59 --> Database Driver Class Initialized
INFO - 2024-09-30 14:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 14:00:59 --> Controller Class Initialized
INFO - 2024-09-30 14:00:59 --> Final output sent to browser
DEBUG - 2024-09-30 14:00:59 --> Total execution time: 0.0736
INFO - 2024-09-30 14:01:01 --> Config Class Initialized
INFO - 2024-09-30 14:01:01 --> Hooks Class Initialized
DEBUG - 2024-09-30 14:01:01 --> UTF-8 Support Enabled
INFO - 2024-09-30 14:01:01 --> Utf8 Class Initialized
INFO - 2024-09-30 14:01:01 --> URI Class Initialized
INFO - 2024-09-30 14:01:01 --> Router Class Initialized
INFO - 2024-09-30 14:01:01 --> Output Class Initialized
INFO - 2024-09-30 14:01:01 --> Security Class Initialized
DEBUG - 2024-09-30 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 14:01:01 --> Input Class Initialized
INFO - 2024-09-30 14:01:01 --> Language Class Initialized
INFO - 2024-09-30 14:01:01 --> Language Class Initialized
INFO - 2024-09-30 14:01:01 --> Config Class Initialized
INFO - 2024-09-30 14:01:01 --> Loader Class Initialized
INFO - 2024-09-30 14:01:01 --> Helper loaded: url_helper
INFO - 2024-09-30 14:01:01 --> Helper loaded: file_helper
INFO - 2024-09-30 14:01:01 --> Helper loaded: form_helper
INFO - 2024-09-30 14:01:01 --> Helper loaded: my_helper
INFO - 2024-09-30 14:01:01 --> Database Driver Class Initialized
INFO - 2024-09-30 14:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 14:01:01 --> Controller Class Initialized
DEBUG - 2024-09-30 14:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-30 14:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 14:01:01 --> Final output sent to browser
DEBUG - 2024-09-30 14:01:01 --> Total execution time: 0.1315
INFO - 2024-09-30 17:44:57 --> Config Class Initialized
INFO - 2024-09-30 17:44:57 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:44:57 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:44:57 --> Utf8 Class Initialized
INFO - 2024-09-30 17:44:57 --> URI Class Initialized
INFO - 2024-09-30 17:44:57 --> Router Class Initialized
INFO - 2024-09-30 17:44:57 --> Output Class Initialized
INFO - 2024-09-30 17:44:57 --> Security Class Initialized
DEBUG - 2024-09-30 17:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:44:57 --> Input Class Initialized
INFO - 2024-09-30 17:44:57 --> Language Class Initialized
INFO - 2024-09-30 17:44:57 --> Language Class Initialized
INFO - 2024-09-30 17:44:57 --> Config Class Initialized
INFO - 2024-09-30 17:44:57 --> Loader Class Initialized
INFO - 2024-09-30 17:44:57 --> Helper loaded: url_helper
INFO - 2024-09-30 17:44:57 --> Helper loaded: file_helper
INFO - 2024-09-30 17:44:57 --> Helper loaded: form_helper
INFO - 2024-09-30 17:44:57 --> Helper loaded: my_helper
INFO - 2024-09-30 17:44:57 --> Database Driver Class Initialized
INFO - 2024-09-30 17:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:44:57 --> Controller Class Initialized
INFO - 2024-09-30 17:44:57 --> Helper loaded: cookie_helper
INFO - 2024-09-30 17:44:57 --> Final output sent to browser
DEBUG - 2024-09-30 17:44:57 --> Total execution time: 0.1056
INFO - 2024-09-30 17:44:58 --> Config Class Initialized
INFO - 2024-09-30 17:44:58 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:44:58 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:44:58 --> Utf8 Class Initialized
INFO - 2024-09-30 17:44:58 --> URI Class Initialized
INFO - 2024-09-30 17:44:58 --> Router Class Initialized
INFO - 2024-09-30 17:44:58 --> Output Class Initialized
INFO - 2024-09-30 17:44:58 --> Security Class Initialized
DEBUG - 2024-09-30 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:44:58 --> Input Class Initialized
INFO - 2024-09-30 17:44:58 --> Language Class Initialized
INFO - 2024-09-30 17:44:58 --> Language Class Initialized
INFO - 2024-09-30 17:44:58 --> Config Class Initialized
INFO - 2024-09-30 17:44:58 --> Loader Class Initialized
INFO - 2024-09-30 17:44:58 --> Helper loaded: url_helper
INFO - 2024-09-30 17:44:58 --> Helper loaded: file_helper
INFO - 2024-09-30 17:44:58 --> Helper loaded: form_helper
INFO - 2024-09-30 17:44:58 --> Helper loaded: my_helper
INFO - 2024-09-30 17:44:58 --> Database Driver Class Initialized
INFO - 2024-09-30 17:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:44:58 --> Controller Class Initialized
INFO - 2024-09-30 17:44:58 --> Helper loaded: cookie_helper
INFO - 2024-09-30 17:44:58 --> Config Class Initialized
INFO - 2024-09-30 17:44:58 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:44:58 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:44:58 --> Utf8 Class Initialized
INFO - 2024-09-30 17:44:58 --> URI Class Initialized
INFO - 2024-09-30 17:44:58 --> Router Class Initialized
INFO - 2024-09-30 17:44:58 --> Output Class Initialized
INFO - 2024-09-30 17:44:58 --> Security Class Initialized
DEBUG - 2024-09-30 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:44:58 --> Input Class Initialized
INFO - 2024-09-30 17:44:58 --> Language Class Initialized
INFO - 2024-09-30 17:44:59 --> Language Class Initialized
INFO - 2024-09-30 17:44:59 --> Config Class Initialized
INFO - 2024-09-30 17:44:59 --> Loader Class Initialized
INFO - 2024-09-30 17:44:59 --> Helper loaded: url_helper
INFO - 2024-09-30 17:44:59 --> Helper loaded: file_helper
INFO - 2024-09-30 17:44:59 --> Helper loaded: form_helper
INFO - 2024-09-30 17:44:59 --> Helper loaded: my_helper
INFO - 2024-09-30 17:44:59 --> Database Driver Class Initialized
INFO - 2024-09-30 17:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:44:59 --> Controller Class Initialized
DEBUG - 2024-09-30 17:44:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-30 17:44:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 17:44:59 --> Final output sent to browser
DEBUG - 2024-09-30 17:44:59 --> Total execution time: 0.0794
INFO - 2024-09-30 17:45:09 --> Config Class Initialized
INFO - 2024-09-30 17:45:09 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:45:09 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:45:09 --> Utf8 Class Initialized
INFO - 2024-09-30 17:45:09 --> URI Class Initialized
INFO - 2024-09-30 17:45:09 --> Router Class Initialized
INFO - 2024-09-30 17:45:09 --> Output Class Initialized
INFO - 2024-09-30 17:45:09 --> Security Class Initialized
DEBUG - 2024-09-30 17:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:45:09 --> Input Class Initialized
INFO - 2024-09-30 17:45:09 --> Language Class Initialized
INFO - 2024-09-30 17:45:09 --> Language Class Initialized
INFO - 2024-09-30 17:45:09 --> Config Class Initialized
INFO - 2024-09-30 17:45:09 --> Loader Class Initialized
INFO - 2024-09-30 17:45:09 --> Helper loaded: url_helper
INFO - 2024-09-30 17:45:09 --> Helper loaded: file_helper
INFO - 2024-09-30 17:45:09 --> Helper loaded: form_helper
INFO - 2024-09-30 17:45:09 --> Helper loaded: my_helper
INFO - 2024-09-30 17:45:09 --> Database Driver Class Initialized
INFO - 2024-09-30 17:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:45:09 --> Controller Class Initialized
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-30 17:45:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-30 17:45:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-30 17:45:12 --> Final output sent to browser
DEBUG - 2024-09-30 17:45:12 --> Total execution time: 3.0515
INFO - 2024-09-30 17:45:29 --> Config Class Initialized
INFO - 2024-09-30 17:45:29 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:45:29 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:45:29 --> Utf8 Class Initialized
INFO - 2024-09-30 17:45:29 --> URI Class Initialized
INFO - 2024-09-30 17:45:29 --> Router Class Initialized
INFO - 2024-09-30 17:45:29 --> Output Class Initialized
INFO - 2024-09-30 17:45:29 --> Security Class Initialized
DEBUG - 2024-09-30 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:45:29 --> Input Class Initialized
INFO - 2024-09-30 17:45:29 --> Language Class Initialized
INFO - 2024-09-30 17:45:29 --> Language Class Initialized
INFO - 2024-09-30 17:45:29 --> Config Class Initialized
INFO - 2024-09-30 17:45:29 --> Loader Class Initialized
INFO - 2024-09-30 17:45:29 --> Helper loaded: url_helper
INFO - 2024-09-30 17:45:29 --> Helper loaded: file_helper
INFO - 2024-09-30 17:45:29 --> Helper loaded: form_helper
INFO - 2024-09-30 17:45:29 --> Helper loaded: my_helper
INFO - 2024-09-30 17:45:29 --> Database Driver Class Initialized
INFO - 2024-09-30 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:45:30 --> Controller Class Initialized
INFO - 2024-09-30 17:45:30 --> Helper loaded: cookie_helper
INFO - 2024-09-30 17:45:30 --> Final output sent to browser
DEBUG - 2024-09-30 17:45:30 --> Total execution time: 0.0567
INFO - 2024-09-30 17:45:30 --> Config Class Initialized
INFO - 2024-09-30 17:45:30 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:45:30 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:45:30 --> Utf8 Class Initialized
INFO - 2024-09-30 17:45:30 --> URI Class Initialized
INFO - 2024-09-30 17:45:30 --> Router Class Initialized
INFO - 2024-09-30 17:45:30 --> Output Class Initialized
INFO - 2024-09-30 17:45:30 --> Security Class Initialized
DEBUG - 2024-09-30 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:45:30 --> Input Class Initialized
INFO - 2024-09-30 17:45:30 --> Language Class Initialized
INFO - 2024-09-30 17:45:30 --> Language Class Initialized
INFO - 2024-09-30 17:45:30 --> Config Class Initialized
INFO - 2024-09-30 17:45:30 --> Loader Class Initialized
INFO - 2024-09-30 17:45:30 --> Helper loaded: url_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: file_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: form_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: my_helper
INFO - 2024-09-30 17:45:30 --> Database Driver Class Initialized
INFO - 2024-09-30 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:45:30 --> Controller Class Initialized
INFO - 2024-09-30 17:45:30 --> Helper loaded: cookie_helper
INFO - 2024-09-30 17:45:30 --> Config Class Initialized
INFO - 2024-09-30 17:45:30 --> Hooks Class Initialized
DEBUG - 2024-09-30 17:45:30 --> UTF-8 Support Enabled
INFO - 2024-09-30 17:45:30 --> Utf8 Class Initialized
INFO - 2024-09-30 17:45:30 --> URI Class Initialized
INFO - 2024-09-30 17:45:30 --> Router Class Initialized
INFO - 2024-09-30 17:45:30 --> Output Class Initialized
INFO - 2024-09-30 17:45:30 --> Security Class Initialized
DEBUG - 2024-09-30 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-30 17:45:30 --> Input Class Initialized
INFO - 2024-09-30 17:45:30 --> Language Class Initialized
INFO - 2024-09-30 17:45:30 --> Language Class Initialized
INFO - 2024-09-30 17:45:30 --> Config Class Initialized
INFO - 2024-09-30 17:45:30 --> Loader Class Initialized
INFO - 2024-09-30 17:45:30 --> Helper loaded: url_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: file_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: form_helper
INFO - 2024-09-30 17:45:30 --> Helper loaded: my_helper
INFO - 2024-09-30 17:45:30 --> Database Driver Class Initialized
INFO - 2024-09-30 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-30 17:45:30 --> Controller Class Initialized
DEBUG - 2024-09-30 17:45:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-30 17:45:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-30 17:45:30 --> Final output sent to browser
DEBUG - 2024-09-30 17:45:30 --> Total execution time: 0.0510
