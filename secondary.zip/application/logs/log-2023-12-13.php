<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-13 08:29:55 --> Config Class Initialized
INFO - 2023-12-13 08:29:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:29:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:29:55 --> Utf8 Class Initialized
INFO - 2023-12-13 08:29:55 --> URI Class Initialized
DEBUG - 2023-12-13 08:29:55 --> No URI present. Default controller set.
INFO - 2023-12-13 08:29:55 --> Router Class Initialized
INFO - 2023-12-13 08:29:55 --> Output Class Initialized
INFO - 2023-12-13 08:29:55 --> Security Class Initialized
DEBUG - 2023-12-13 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:29:55 --> Input Class Initialized
INFO - 2023-12-13 08:29:55 --> Language Class Initialized
INFO - 2023-12-13 08:29:55 --> Language Class Initialized
INFO - 2023-12-13 08:29:55 --> Config Class Initialized
INFO - 2023-12-13 08:29:55 --> Loader Class Initialized
INFO - 2023-12-13 08:29:55 --> Helper loaded: url_helper
INFO - 2023-12-13 08:29:55 --> Helper loaded: file_helper
INFO - 2023-12-13 08:29:55 --> Helper loaded: form_helper
INFO - 2023-12-13 08:29:55 --> Helper loaded: my_helper
INFO - 2023-12-13 08:29:56 --> Database Driver Class Initialized
INFO - 2023-12-13 08:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:29:56 --> Controller Class Initialized
INFO - 2023-12-13 08:29:56 --> Config Class Initialized
INFO - 2023-12-13 08:29:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:29:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:29:56 --> Utf8 Class Initialized
INFO - 2023-12-13 08:29:56 --> URI Class Initialized
INFO - 2023-12-13 08:29:56 --> Router Class Initialized
INFO - 2023-12-13 08:29:56 --> Output Class Initialized
INFO - 2023-12-13 08:29:56 --> Security Class Initialized
DEBUG - 2023-12-13 08:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:29:56 --> Input Class Initialized
INFO - 2023-12-13 08:29:56 --> Language Class Initialized
INFO - 2023-12-13 08:29:56 --> Language Class Initialized
INFO - 2023-12-13 08:29:56 --> Config Class Initialized
INFO - 2023-12-13 08:29:56 --> Loader Class Initialized
INFO - 2023-12-13 08:29:56 --> Helper loaded: url_helper
INFO - 2023-12-13 08:29:56 --> Helper loaded: file_helper
INFO - 2023-12-13 08:29:56 --> Helper loaded: form_helper
INFO - 2023-12-13 08:29:56 --> Helper loaded: my_helper
INFO - 2023-12-13 08:29:56 --> Database Driver Class Initialized
INFO - 2023-12-13 08:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:29:56 --> Controller Class Initialized
DEBUG - 2023-12-13 08:29:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:29:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:29:56 --> Final output sent to browser
DEBUG - 2023-12-13 08:29:56 --> Total execution time: 0.0682
INFO - 2023-12-13 08:30:09 --> Config Class Initialized
INFO - 2023-12-13 08:30:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:09 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:09 --> URI Class Initialized
INFO - 2023-12-13 08:30:09 --> Router Class Initialized
INFO - 2023-12-13 08:30:09 --> Output Class Initialized
INFO - 2023-12-13 08:30:09 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:09 --> Input Class Initialized
INFO - 2023-12-13 08:30:09 --> Language Class Initialized
INFO - 2023-12-13 08:30:09 --> Language Class Initialized
INFO - 2023-12-13 08:30:09 --> Config Class Initialized
INFO - 2023-12-13 08:30:09 --> Loader Class Initialized
INFO - 2023-12-13 08:30:09 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:09 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:09 --> Controller Class Initialized
INFO - 2023-12-13 08:30:09 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:30:09 --> Final output sent to browser
DEBUG - 2023-12-13 08:30:09 --> Total execution time: 0.0455
INFO - 2023-12-13 08:30:09 --> Config Class Initialized
INFO - 2023-12-13 08:30:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:09 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:09 --> URI Class Initialized
INFO - 2023-12-13 08:30:09 --> Router Class Initialized
INFO - 2023-12-13 08:30:09 --> Output Class Initialized
INFO - 2023-12-13 08:30:09 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:09 --> Input Class Initialized
INFO - 2023-12-13 08:30:09 --> Language Class Initialized
INFO - 2023-12-13 08:30:09 --> Language Class Initialized
INFO - 2023-12-13 08:30:09 --> Config Class Initialized
INFO - 2023-12-13 08:30:09 --> Loader Class Initialized
INFO - 2023-12-13 08:30:09 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:09 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:09 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:09 --> Controller Class Initialized
DEBUG - 2023-12-13 08:30:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:30:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:30:09 --> Final output sent to browser
DEBUG - 2023-12-13 08:30:09 --> Total execution time: 0.0422
INFO - 2023-12-13 08:30:17 --> Config Class Initialized
INFO - 2023-12-13 08:30:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:17 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:17 --> URI Class Initialized
INFO - 2023-12-13 08:30:17 --> Router Class Initialized
INFO - 2023-12-13 08:30:17 --> Output Class Initialized
INFO - 2023-12-13 08:30:17 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:17 --> Input Class Initialized
INFO - 2023-12-13 08:30:17 --> Language Class Initialized
INFO - 2023-12-13 08:30:17 --> Language Class Initialized
INFO - 2023-12-13 08:30:17 --> Config Class Initialized
INFO - 2023-12-13 08:30:17 --> Loader Class Initialized
INFO - 2023-12-13 08:30:17 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:17 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:17 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:17 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:17 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:17 --> Controller Class Initialized
DEBUG - 2023-12-13 08:30:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 08:30:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:30:17 --> Final output sent to browser
DEBUG - 2023-12-13 08:30:17 --> Total execution time: 0.0480
INFO - 2023-12-13 08:30:39 --> Config Class Initialized
INFO - 2023-12-13 08:30:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:39 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:39 --> URI Class Initialized
INFO - 2023-12-13 08:30:39 --> Router Class Initialized
INFO - 2023-12-13 08:30:39 --> Output Class Initialized
INFO - 2023-12-13 08:30:39 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:39 --> Input Class Initialized
INFO - 2023-12-13 08:30:39 --> Language Class Initialized
INFO - 2023-12-13 08:30:39 --> Language Class Initialized
INFO - 2023-12-13 08:30:39 --> Config Class Initialized
INFO - 2023-12-13 08:30:39 --> Loader Class Initialized
INFO - 2023-12-13 08:30:39 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:39 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:39 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:39 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:39 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:39 --> Controller Class Initialized
DEBUG - 2023-12-13 08:30:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-13 08:30:42 --> Final output sent to browser
DEBUG - 2023-12-13 08:30:42 --> Total execution time: 3.0031
INFO - 2023-12-13 08:30:43 --> Config Class Initialized
INFO - 2023-12-13 08:30:43 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:43 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:43 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:43 --> URI Class Initialized
INFO - 2023-12-13 08:30:43 --> Router Class Initialized
INFO - 2023-12-13 08:30:43 --> Output Class Initialized
INFO - 2023-12-13 08:30:43 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:43 --> Input Class Initialized
INFO - 2023-12-13 08:30:43 --> Language Class Initialized
INFO - 2023-12-13 08:30:43 --> Language Class Initialized
INFO - 2023-12-13 08:30:43 --> Config Class Initialized
INFO - 2023-12-13 08:30:43 --> Loader Class Initialized
INFO - 2023-12-13 08:30:43 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:43 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:43 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:43 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:43 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:43 --> Controller Class Initialized
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-13 08:30:43 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-13 08:30:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-13 08:30:45 --> Config Class Initialized
INFO - 2023-12-13 08:30:45 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:45 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:45 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:45 --> URI Class Initialized
INFO - 2023-12-13 08:30:45 --> Router Class Initialized
INFO - 2023-12-13 08:30:45 --> Output Class Initialized
INFO - 2023-12-13 08:30:45 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:45 --> Input Class Initialized
INFO - 2023-12-13 08:30:45 --> Language Class Initialized
INFO - 2023-12-13 08:30:45 --> Language Class Initialized
INFO - 2023-12-13 08:30:45 --> Config Class Initialized
INFO - 2023-12-13 08:30:45 --> Loader Class Initialized
INFO - 2023-12-13 08:30:45 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:45 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:45 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:45 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:45 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:50 --> Config Class Initialized
INFO - 2023-12-13 08:30:50 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:30:50 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:30:50 --> Utf8 Class Initialized
INFO - 2023-12-13 08:30:50 --> URI Class Initialized
INFO - 2023-12-13 08:30:50 --> Router Class Initialized
INFO - 2023-12-13 08:30:50 --> Output Class Initialized
INFO - 2023-12-13 08:30:50 --> Security Class Initialized
DEBUG - 2023-12-13 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:30:50 --> Input Class Initialized
INFO - 2023-12-13 08:30:50 --> Language Class Initialized
INFO - 2023-12-13 08:30:50 --> Language Class Initialized
INFO - 2023-12-13 08:30:50 --> Config Class Initialized
INFO - 2023-12-13 08:30:50 --> Loader Class Initialized
INFO - 2023-12-13 08:30:50 --> Helper loaded: url_helper
INFO - 2023-12-13 08:30:50 --> Helper loaded: file_helper
INFO - 2023-12-13 08:30:50 --> Helper loaded: form_helper
INFO - 2023-12-13 08:30:50 --> Helper loaded: my_helper
INFO - 2023-12-13 08:30:50 --> Database Driver Class Initialized
INFO - 2023-12-13 08:30:53 --> Final output sent to browser
DEBUG - 2023-12-13 08:30:53 --> Total execution time: 10.8760
INFO - 2023-12-13 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:30:53 --> Controller Class Initialized
DEBUG - 2023-12-13 08:30:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 08:31:02 --> Final output sent to browser
DEBUG - 2023-12-13 08:31:02 --> Total execution time: 16.3364
INFO - 2023-12-13 08:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:31:02 --> Controller Class Initialized
DEBUG - 2023-12-13 08:31:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-13 08:31:10 --> Final output sent to browser
DEBUG - 2023-12-13 08:31:10 --> Total execution time: 20.8429
INFO - 2023-12-13 08:36:54 --> Config Class Initialized
INFO - 2023-12-13 08:36:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:36:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:36:54 --> Utf8 Class Initialized
INFO - 2023-12-13 08:36:54 --> URI Class Initialized
INFO - 2023-12-13 08:36:55 --> Router Class Initialized
INFO - 2023-12-13 08:36:55 --> Output Class Initialized
INFO - 2023-12-13 08:36:55 --> Security Class Initialized
DEBUG - 2023-12-13 08:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:36:55 --> Input Class Initialized
INFO - 2023-12-13 08:36:55 --> Language Class Initialized
INFO - 2023-12-13 08:36:55 --> Language Class Initialized
INFO - 2023-12-13 08:36:55 --> Config Class Initialized
INFO - 2023-12-13 08:36:55 --> Loader Class Initialized
INFO - 2023-12-13 08:36:55 --> Helper loaded: url_helper
INFO - 2023-12-13 08:36:55 --> Helper loaded: file_helper
INFO - 2023-12-13 08:36:55 --> Helper loaded: form_helper
INFO - 2023-12-13 08:36:55 --> Helper loaded: my_helper
INFO - 2023-12-13 08:36:55 --> Database Driver Class Initialized
INFO - 2023-12-13 08:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:36:55 --> Controller Class Initialized
DEBUG - 2023-12-13 08:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:36:55 --> Final output sent to browser
DEBUG - 2023-12-13 08:36:55 --> Total execution time: 0.2521
INFO - 2023-12-13 08:36:56 --> Config Class Initialized
INFO - 2023-12-13 08:36:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:36:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:36:56 --> Utf8 Class Initialized
INFO - 2023-12-13 08:36:56 --> URI Class Initialized
INFO - 2023-12-13 08:36:56 --> Router Class Initialized
INFO - 2023-12-13 08:36:56 --> Output Class Initialized
INFO - 2023-12-13 08:36:56 --> Security Class Initialized
DEBUG - 2023-12-13 08:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:36:56 --> Input Class Initialized
INFO - 2023-12-13 08:36:56 --> Language Class Initialized
INFO - 2023-12-13 08:36:56 --> Language Class Initialized
INFO - 2023-12-13 08:36:56 --> Config Class Initialized
INFO - 2023-12-13 08:36:56 --> Loader Class Initialized
INFO - 2023-12-13 08:36:56 --> Helper loaded: url_helper
INFO - 2023-12-13 08:36:56 --> Helper loaded: file_helper
INFO - 2023-12-13 08:36:56 --> Helper loaded: form_helper
INFO - 2023-12-13 08:36:56 --> Helper loaded: my_helper
INFO - 2023-12-13 08:36:56 --> Database Driver Class Initialized
INFO - 2023-12-13 08:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:36:56 --> Controller Class Initialized
INFO - 2023-12-13 08:37:05 --> Config Class Initialized
INFO - 2023-12-13 08:37:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:05 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:05 --> URI Class Initialized
INFO - 2023-12-13 08:37:05 --> Router Class Initialized
INFO - 2023-12-13 08:37:06 --> Output Class Initialized
INFO - 2023-12-13 08:37:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:06 --> Input Class Initialized
INFO - 2023-12-13 08:37:06 --> Language Class Initialized
INFO - 2023-12-13 08:37:06 --> Language Class Initialized
INFO - 2023-12-13 08:37:06 --> Config Class Initialized
INFO - 2023-12-13 08:37:06 --> Loader Class Initialized
INFO - 2023-12-13 08:37:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:06 --> Controller Class Initialized
INFO - 2023-12-13 08:37:06 --> Config Class Initialized
INFO - 2023-12-13 08:37:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:06 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:06 --> URI Class Initialized
INFO - 2023-12-13 08:37:06 --> Router Class Initialized
INFO - 2023-12-13 08:37:06 --> Output Class Initialized
INFO - 2023-12-13 08:37:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:06 --> Input Class Initialized
INFO - 2023-12-13 08:37:06 --> Language Class Initialized
INFO - 2023-12-13 08:37:06 --> Language Class Initialized
INFO - 2023-12-13 08:37:06 --> Config Class Initialized
INFO - 2023-12-13 08:37:06 --> Loader Class Initialized
INFO - 2023-12-13 08:37:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:06 --> Controller Class Initialized
DEBUG - 2023-12-13 08:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:37:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:37:06 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:06 --> Total execution time: 0.2054
INFO - 2023-12-13 08:37:09 --> Config Class Initialized
INFO - 2023-12-13 08:37:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:09 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:09 --> URI Class Initialized
INFO - 2023-12-13 08:37:09 --> Router Class Initialized
INFO - 2023-12-13 08:37:09 --> Output Class Initialized
INFO - 2023-12-13 08:37:09 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:09 --> Input Class Initialized
INFO - 2023-12-13 08:37:09 --> Language Class Initialized
INFO - 2023-12-13 08:37:09 --> Language Class Initialized
INFO - 2023-12-13 08:37:09 --> Config Class Initialized
INFO - 2023-12-13 08:37:09 --> Loader Class Initialized
INFO - 2023-12-13 08:37:09 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:09 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:09 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:09 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:09 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:09 --> Controller Class Initialized
INFO - 2023-12-13 08:37:09 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:37:09 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:09 --> Total execution time: 0.2589
INFO - 2023-12-13 08:37:10 --> Config Class Initialized
INFO - 2023-12-13 08:37:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:10 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:10 --> URI Class Initialized
INFO - 2023-12-13 08:37:10 --> Router Class Initialized
INFO - 2023-12-13 08:37:10 --> Output Class Initialized
INFO - 2023-12-13 08:37:10 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:10 --> Input Class Initialized
INFO - 2023-12-13 08:37:10 --> Language Class Initialized
INFO - 2023-12-13 08:37:10 --> Language Class Initialized
INFO - 2023-12-13 08:37:10 --> Config Class Initialized
INFO - 2023-12-13 08:37:10 --> Loader Class Initialized
INFO - 2023-12-13 08:37:10 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:10 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:10 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:10 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:10 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:10 --> Controller Class Initialized
DEBUG - 2023-12-13 08:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:37:10 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:10 --> Total execution time: 0.3759
INFO - 2023-12-13 08:37:41 --> Config Class Initialized
INFO - 2023-12-13 08:37:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:41 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:41 --> URI Class Initialized
INFO - 2023-12-13 08:37:41 --> Router Class Initialized
INFO - 2023-12-13 08:37:41 --> Output Class Initialized
INFO - 2023-12-13 08:37:41 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:41 --> Input Class Initialized
INFO - 2023-12-13 08:37:41 --> Language Class Initialized
INFO - 2023-12-13 08:37:41 --> Language Class Initialized
INFO - 2023-12-13 08:37:41 --> Config Class Initialized
INFO - 2023-12-13 08:37:41 --> Loader Class Initialized
INFO - 2023-12-13 08:37:41 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:41 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:41 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:41 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:41 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:41 --> Controller Class Initialized
DEBUG - 2023-12-13 08:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:37:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:37:41 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:41 --> Total execution time: 0.2134
INFO - 2023-12-13 08:37:46 --> Config Class Initialized
INFO - 2023-12-13 08:37:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:46 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:46 --> URI Class Initialized
INFO - 2023-12-13 08:37:46 --> Router Class Initialized
INFO - 2023-12-13 08:37:46 --> Output Class Initialized
INFO - 2023-12-13 08:37:46 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:46 --> Input Class Initialized
INFO - 2023-12-13 08:37:46 --> Language Class Initialized
INFO - 2023-12-13 08:37:46 --> Language Class Initialized
INFO - 2023-12-13 08:37:46 --> Config Class Initialized
INFO - 2023-12-13 08:37:46 --> Loader Class Initialized
INFO - 2023-12-13 08:37:46 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:46 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:46 --> Controller Class Initialized
DEBUG - 2023-12-13 08:37:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:37:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:37:46 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:46 --> Total execution time: 0.2468
INFO - 2023-12-13 08:37:46 --> Config Class Initialized
INFO - 2023-12-13 08:37:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:46 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:46 --> URI Class Initialized
INFO - 2023-12-13 08:37:46 --> Router Class Initialized
INFO - 2023-12-13 08:37:46 --> Output Class Initialized
INFO - 2023-12-13 08:37:46 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:46 --> Input Class Initialized
INFO - 2023-12-13 08:37:46 --> Language Class Initialized
INFO - 2023-12-13 08:37:46 --> Language Class Initialized
INFO - 2023-12-13 08:37:46 --> Config Class Initialized
INFO - 2023-12-13 08:37:46 --> Loader Class Initialized
INFO - 2023-12-13 08:37:46 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:46 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:46 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:46 --> Controller Class Initialized
INFO - 2023-12-13 08:37:49 --> Config Class Initialized
INFO - 2023-12-13 08:37:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:49 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:49 --> URI Class Initialized
INFO - 2023-12-13 08:37:49 --> Router Class Initialized
INFO - 2023-12-13 08:37:49 --> Output Class Initialized
INFO - 2023-12-13 08:37:49 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:49 --> Input Class Initialized
INFO - 2023-12-13 08:37:49 --> Language Class Initialized
INFO - 2023-12-13 08:37:49 --> Language Class Initialized
INFO - 2023-12-13 08:37:49 --> Config Class Initialized
INFO - 2023-12-13 08:37:49 --> Loader Class Initialized
INFO - 2023-12-13 08:37:49 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:49 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:49 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:49 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:49 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:49 --> Controller Class Initialized
INFO - 2023-12-13 08:37:49 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:49 --> Total execution time: 0.2373
INFO - 2023-12-13 08:37:54 --> Config Class Initialized
INFO - 2023-12-13 08:37:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:37:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:37:54 --> Utf8 Class Initialized
INFO - 2023-12-13 08:37:54 --> URI Class Initialized
INFO - 2023-12-13 08:37:54 --> Router Class Initialized
INFO - 2023-12-13 08:37:54 --> Output Class Initialized
INFO - 2023-12-13 08:37:54 --> Security Class Initialized
DEBUG - 2023-12-13 08:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:37:54 --> Input Class Initialized
INFO - 2023-12-13 08:37:54 --> Language Class Initialized
INFO - 2023-12-13 08:37:54 --> Language Class Initialized
INFO - 2023-12-13 08:37:54 --> Config Class Initialized
INFO - 2023-12-13 08:37:54 --> Loader Class Initialized
INFO - 2023-12-13 08:37:54 --> Helper loaded: url_helper
INFO - 2023-12-13 08:37:54 --> Helper loaded: file_helper
INFO - 2023-12-13 08:37:54 --> Helper loaded: form_helper
INFO - 2023-12-13 08:37:54 --> Helper loaded: my_helper
INFO - 2023-12-13 08:37:54 --> Database Driver Class Initialized
INFO - 2023-12-13 08:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:37:54 --> Controller Class Initialized
INFO - 2023-12-13 08:37:54 --> Final output sent to browser
DEBUG - 2023-12-13 08:37:54 --> Total execution time: 0.1128
INFO - 2023-12-13 08:38:05 --> Config Class Initialized
INFO - 2023-12-13 08:38:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:38:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:38:05 --> Utf8 Class Initialized
INFO - 2023-12-13 08:38:05 --> URI Class Initialized
INFO - 2023-12-13 08:38:05 --> Router Class Initialized
INFO - 2023-12-13 08:38:05 --> Output Class Initialized
INFO - 2023-12-13 08:38:05 --> Security Class Initialized
DEBUG - 2023-12-13 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:38:05 --> Input Class Initialized
INFO - 2023-12-13 08:38:05 --> Language Class Initialized
INFO - 2023-12-13 08:38:05 --> Language Class Initialized
INFO - 2023-12-13 08:38:05 --> Config Class Initialized
INFO - 2023-12-13 08:38:05 --> Loader Class Initialized
INFO - 2023-12-13 08:38:05 --> Helper loaded: url_helper
INFO - 2023-12-13 08:38:05 --> Helper loaded: file_helper
INFO - 2023-12-13 08:38:05 --> Helper loaded: form_helper
INFO - 2023-12-13 08:38:05 --> Helper loaded: my_helper
INFO - 2023-12-13 08:38:05 --> Database Driver Class Initialized
INFO - 2023-12-13 08:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:38:05 --> Controller Class Initialized
DEBUG - 2023-12-13 08:38:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:38:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:38:05 --> Final output sent to browser
DEBUG - 2023-12-13 08:38:05 --> Total execution time: 0.0424
INFO - 2023-12-13 08:38:08 --> Config Class Initialized
INFO - 2023-12-13 08:38:08 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:38:08 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:38:08 --> Utf8 Class Initialized
INFO - 2023-12-13 08:38:08 --> URI Class Initialized
INFO - 2023-12-13 08:38:08 --> Router Class Initialized
INFO - 2023-12-13 08:38:08 --> Output Class Initialized
INFO - 2023-12-13 08:38:08 --> Security Class Initialized
DEBUG - 2023-12-13 08:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:38:08 --> Input Class Initialized
INFO - 2023-12-13 08:38:08 --> Language Class Initialized
INFO - 2023-12-13 08:38:08 --> Language Class Initialized
INFO - 2023-12-13 08:38:08 --> Config Class Initialized
INFO - 2023-12-13 08:38:08 --> Loader Class Initialized
INFO - 2023-12-13 08:38:08 --> Helper loaded: url_helper
INFO - 2023-12-13 08:38:08 --> Helper loaded: file_helper
INFO - 2023-12-13 08:38:08 --> Helper loaded: form_helper
INFO - 2023-12-13 08:38:08 --> Helper loaded: my_helper
INFO - 2023-12-13 08:38:08 --> Database Driver Class Initialized
INFO - 2023-12-13 08:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:38:08 --> Controller Class Initialized
DEBUG - 2023-12-13 08:38:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 08:38:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:38:08 --> Final output sent to browser
DEBUG - 2023-12-13 08:38:08 --> Total execution time: 0.0377
INFO - 2023-12-13 08:38:10 --> Config Class Initialized
INFO - 2023-12-13 08:38:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:38:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:38:10 --> Utf8 Class Initialized
INFO - 2023-12-13 08:38:10 --> URI Class Initialized
INFO - 2023-12-13 08:38:10 --> Router Class Initialized
INFO - 2023-12-13 08:38:10 --> Output Class Initialized
INFO - 2023-12-13 08:38:10 --> Security Class Initialized
DEBUG - 2023-12-13 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:38:10 --> Input Class Initialized
INFO - 2023-12-13 08:38:10 --> Language Class Initialized
INFO - 2023-12-13 08:38:10 --> Language Class Initialized
INFO - 2023-12-13 08:38:10 --> Config Class Initialized
INFO - 2023-12-13 08:38:10 --> Loader Class Initialized
INFO - 2023-12-13 08:38:10 --> Helper loaded: url_helper
INFO - 2023-12-13 08:38:10 --> Helper loaded: file_helper
INFO - 2023-12-13 08:38:10 --> Helper loaded: form_helper
INFO - 2023-12-13 08:38:10 --> Helper loaded: my_helper
INFO - 2023-12-13 08:38:10 --> Database Driver Class Initialized
INFO - 2023-12-13 08:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:38:10 --> Controller Class Initialized
INFO - 2023-12-13 08:38:10 --> Final output sent to browser
DEBUG - 2023-12-13 08:38:10 --> Total execution time: 0.0389
INFO - 2023-12-13 08:40:22 --> Config Class Initialized
INFO - 2023-12-13 08:40:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:22 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:22 --> URI Class Initialized
INFO - 2023-12-13 08:40:22 --> Router Class Initialized
INFO - 2023-12-13 08:40:22 --> Output Class Initialized
INFO - 2023-12-13 08:40:23 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:23 --> Input Class Initialized
INFO - 2023-12-13 08:40:23 --> Language Class Initialized
INFO - 2023-12-13 08:40:23 --> Language Class Initialized
INFO - 2023-12-13 08:40:23 --> Config Class Initialized
INFO - 2023-12-13 08:40:23 --> Loader Class Initialized
INFO - 2023-12-13 08:40:23 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:23 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:23 --> Controller Class Initialized
INFO - 2023-12-13 08:40:23 --> Config Class Initialized
INFO - 2023-12-13 08:40:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:23 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:23 --> URI Class Initialized
INFO - 2023-12-13 08:40:23 --> Router Class Initialized
INFO - 2023-12-13 08:40:23 --> Output Class Initialized
INFO - 2023-12-13 08:40:23 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:23 --> Input Class Initialized
INFO - 2023-12-13 08:40:23 --> Language Class Initialized
INFO - 2023-12-13 08:40:23 --> Language Class Initialized
INFO - 2023-12-13 08:40:23 --> Config Class Initialized
INFO - 2023-12-13 08:40:23 --> Loader Class Initialized
INFO - 2023-12-13 08:40:23 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:23 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:23 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:23 --> Controller Class Initialized
DEBUG - 2023-12-13 08:40:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:40:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:40:23 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:23 --> Total execution time: 0.0393
INFO - 2023-12-13 08:40:28 --> Config Class Initialized
INFO - 2023-12-13 08:40:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:28 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:28 --> URI Class Initialized
INFO - 2023-12-13 08:40:28 --> Router Class Initialized
INFO - 2023-12-13 08:40:28 --> Output Class Initialized
INFO - 2023-12-13 08:40:28 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:28 --> Input Class Initialized
INFO - 2023-12-13 08:40:28 --> Language Class Initialized
INFO - 2023-12-13 08:40:28 --> Language Class Initialized
INFO - 2023-12-13 08:40:28 --> Config Class Initialized
INFO - 2023-12-13 08:40:28 --> Loader Class Initialized
INFO - 2023-12-13 08:40:28 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:28 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:28 --> Controller Class Initialized
INFO - 2023-12-13 08:40:28 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:40:28 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:28 --> Total execution time: 0.0721
INFO - 2023-12-13 08:40:28 --> Config Class Initialized
INFO - 2023-12-13 08:40:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:28 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:28 --> URI Class Initialized
INFO - 2023-12-13 08:40:28 --> Router Class Initialized
INFO - 2023-12-13 08:40:28 --> Output Class Initialized
INFO - 2023-12-13 08:40:28 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:28 --> Input Class Initialized
INFO - 2023-12-13 08:40:28 --> Language Class Initialized
INFO - 2023-12-13 08:40:28 --> Language Class Initialized
INFO - 2023-12-13 08:40:28 --> Config Class Initialized
INFO - 2023-12-13 08:40:28 --> Loader Class Initialized
INFO - 2023-12-13 08:40:28 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:28 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:28 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:28 --> Controller Class Initialized
DEBUG - 2023-12-13 08:40:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:40:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:40:28 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:28 --> Total execution time: 0.0860
INFO - 2023-12-13 08:40:32 --> Config Class Initialized
INFO - 2023-12-13 08:40:32 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:32 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:32 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:32 --> URI Class Initialized
INFO - 2023-12-13 08:40:32 --> Router Class Initialized
INFO - 2023-12-13 08:40:32 --> Output Class Initialized
INFO - 2023-12-13 08:40:32 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:32 --> Input Class Initialized
INFO - 2023-12-13 08:40:32 --> Language Class Initialized
INFO - 2023-12-13 08:40:32 --> Language Class Initialized
INFO - 2023-12-13 08:40:32 --> Config Class Initialized
INFO - 2023-12-13 08:40:32 --> Loader Class Initialized
INFO - 2023-12-13 08:40:32 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:32 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:32 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:32 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:32 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:32 --> Controller Class Initialized
DEBUG - 2023-12-13 08:40:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:40:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:40:32 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:32 --> Total execution time: 0.0746
INFO - 2023-12-13 08:40:36 --> Config Class Initialized
INFO - 2023-12-13 08:40:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:36 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:36 --> URI Class Initialized
INFO - 2023-12-13 08:40:36 --> Router Class Initialized
INFO - 2023-12-13 08:40:36 --> Output Class Initialized
INFO - 2023-12-13 08:40:36 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:36 --> Input Class Initialized
INFO - 2023-12-13 08:40:36 --> Language Class Initialized
INFO - 2023-12-13 08:40:36 --> Language Class Initialized
INFO - 2023-12-13 08:40:36 --> Config Class Initialized
INFO - 2023-12-13 08:40:36 --> Loader Class Initialized
INFO - 2023-12-13 08:40:36 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:36 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:36 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:36 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:36 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:36 --> Controller Class Initialized
DEBUG - 2023-12-13 08:40:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 08:40:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:40:36 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:36 --> Total execution time: 0.0649
INFO - 2023-12-13 08:40:41 --> Config Class Initialized
INFO - 2023-12-13 08:40:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:40:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:40:41 --> Utf8 Class Initialized
INFO - 2023-12-13 08:40:41 --> URI Class Initialized
INFO - 2023-12-13 08:40:41 --> Router Class Initialized
INFO - 2023-12-13 08:40:41 --> Output Class Initialized
INFO - 2023-12-13 08:40:41 --> Security Class Initialized
DEBUG - 2023-12-13 08:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:40:41 --> Input Class Initialized
INFO - 2023-12-13 08:40:41 --> Language Class Initialized
INFO - 2023-12-13 08:40:41 --> Language Class Initialized
INFO - 2023-12-13 08:40:41 --> Config Class Initialized
INFO - 2023-12-13 08:40:41 --> Loader Class Initialized
INFO - 2023-12-13 08:40:41 --> Helper loaded: url_helper
INFO - 2023-12-13 08:40:41 --> Helper loaded: file_helper
INFO - 2023-12-13 08:40:41 --> Helper loaded: form_helper
INFO - 2023-12-13 08:40:41 --> Helper loaded: my_helper
INFO - 2023-12-13 08:40:42 --> Database Driver Class Initialized
INFO - 2023-12-13 08:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:40:42 --> Controller Class Initialized
INFO - 2023-12-13 08:40:42 --> Final output sent to browser
DEBUG - 2023-12-13 08:40:42 --> Total execution time: 0.1717
INFO - 2023-12-13 08:46:10 --> Config Class Initialized
INFO - 2023-12-13 08:46:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:10 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:10 --> URI Class Initialized
DEBUG - 2023-12-13 08:46:10 --> No URI present. Default controller set.
INFO - 2023-12-13 08:46:10 --> Router Class Initialized
INFO - 2023-12-13 08:46:10 --> Output Class Initialized
INFO - 2023-12-13 08:46:10 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:10 --> Input Class Initialized
INFO - 2023-12-13 08:46:10 --> Language Class Initialized
INFO - 2023-12-13 08:46:10 --> Language Class Initialized
INFO - 2023-12-13 08:46:10 --> Config Class Initialized
INFO - 2023-12-13 08:46:10 --> Loader Class Initialized
INFO - 2023-12-13 08:46:10 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:10 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:10 --> Controller Class Initialized
INFO - 2023-12-13 08:46:10 --> Config Class Initialized
INFO - 2023-12-13 08:46:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:10 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:10 --> URI Class Initialized
INFO - 2023-12-13 08:46:10 --> Router Class Initialized
INFO - 2023-12-13 08:46:10 --> Output Class Initialized
INFO - 2023-12-13 08:46:10 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:10 --> Input Class Initialized
INFO - 2023-12-13 08:46:10 --> Language Class Initialized
INFO - 2023-12-13 08:46:10 --> Language Class Initialized
INFO - 2023-12-13 08:46:10 --> Config Class Initialized
INFO - 2023-12-13 08:46:10 --> Loader Class Initialized
INFO - 2023-12-13 08:46:10 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:10 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:10 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:11 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:11 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:11 --> Total execution time: 0.2545
INFO - 2023-12-13 08:46:16 --> Config Class Initialized
INFO - 2023-12-13 08:46:16 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:16 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:16 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:16 --> URI Class Initialized
INFO - 2023-12-13 08:46:16 --> Router Class Initialized
INFO - 2023-12-13 08:46:16 --> Output Class Initialized
INFO - 2023-12-13 08:46:16 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:16 --> Input Class Initialized
INFO - 2023-12-13 08:46:16 --> Language Class Initialized
INFO - 2023-12-13 08:46:16 --> Language Class Initialized
INFO - 2023-12-13 08:46:16 --> Config Class Initialized
INFO - 2023-12-13 08:46:16 --> Loader Class Initialized
INFO - 2023-12-13 08:46:16 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:16 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:16 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:16 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:16 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:16 --> Controller Class Initialized
INFO - 2023-12-13 08:46:16 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:16 --> Total execution time: 0.2607
INFO - 2023-12-13 08:46:20 --> Config Class Initialized
INFO - 2023-12-13 08:46:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:20 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:20 --> URI Class Initialized
INFO - 2023-12-13 08:46:20 --> Router Class Initialized
INFO - 2023-12-13 08:46:20 --> Output Class Initialized
INFO - 2023-12-13 08:46:20 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:20 --> Input Class Initialized
INFO - 2023-12-13 08:46:20 --> Language Class Initialized
INFO - 2023-12-13 08:46:20 --> Language Class Initialized
INFO - 2023-12-13 08:46:20 --> Config Class Initialized
INFO - 2023-12-13 08:46:20 --> Loader Class Initialized
INFO - 2023-12-13 08:46:20 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:20 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:20 --> Controller Class Initialized
INFO - 2023-12-13 08:46:20 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:46:20 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:20 --> Total execution time: 0.3198
INFO - 2023-12-13 08:46:20 --> Config Class Initialized
INFO - 2023-12-13 08:46:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:20 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:20 --> URI Class Initialized
INFO - 2023-12-13 08:46:20 --> Router Class Initialized
INFO - 2023-12-13 08:46:20 --> Output Class Initialized
INFO - 2023-12-13 08:46:20 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:20 --> Input Class Initialized
INFO - 2023-12-13 08:46:20 --> Language Class Initialized
INFO - 2023-12-13 08:46:20 --> Language Class Initialized
INFO - 2023-12-13 08:46:20 --> Config Class Initialized
INFO - 2023-12-13 08:46:20 --> Loader Class Initialized
INFO - 2023-12-13 08:46:20 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:20 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:21 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:21 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-13 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:21 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:21 --> Total execution time: 0.2791
INFO - 2023-12-13 08:46:27 --> Config Class Initialized
INFO - 2023-12-13 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:27 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:27 --> URI Class Initialized
INFO - 2023-12-13 08:46:27 --> Router Class Initialized
INFO - 2023-12-13 08:46:27 --> Output Class Initialized
INFO - 2023-12-13 08:46:27 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:27 --> Input Class Initialized
INFO - 2023-12-13 08:46:27 --> Language Class Initialized
INFO - 2023-12-13 08:46:27 --> Language Class Initialized
INFO - 2023-12-13 08:46:27 --> Config Class Initialized
INFO - 2023-12-13 08:46:27 --> Loader Class Initialized
INFO - 2023-12-13 08:46:27 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:27 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:27 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-12-13 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:27 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:27 --> Total execution time: 0.2433
INFO - 2023-12-13 08:46:27 --> Config Class Initialized
INFO - 2023-12-13 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:27 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:27 --> URI Class Initialized
INFO - 2023-12-13 08:46:27 --> Router Class Initialized
INFO - 2023-12-13 08:46:27 --> Output Class Initialized
INFO - 2023-12-13 08:46:27 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:27 --> Input Class Initialized
INFO - 2023-12-13 08:46:27 --> Language Class Initialized
ERROR - 2023-12-13 08:46:27 --> 404 Page Not Found: /index
INFO - 2023-12-13 08:46:27 --> Config Class Initialized
INFO - 2023-12-13 08:46:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:27 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:27 --> URI Class Initialized
INFO - 2023-12-13 08:46:27 --> Router Class Initialized
INFO - 2023-12-13 08:46:27 --> Output Class Initialized
INFO - 2023-12-13 08:46:27 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:27 --> Input Class Initialized
INFO - 2023-12-13 08:46:27 --> Language Class Initialized
INFO - 2023-12-13 08:46:27 --> Language Class Initialized
INFO - 2023-12-13 08:46:27 --> Config Class Initialized
INFO - 2023-12-13 08:46:27 --> Loader Class Initialized
INFO - 2023-12-13 08:46:27 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:27 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:27 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:27 --> Controller Class Initialized
INFO - 2023-12-13 08:46:31 --> Config Class Initialized
INFO - 2023-12-13 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:31 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:31 --> URI Class Initialized
INFO - 2023-12-13 08:46:31 --> Router Class Initialized
INFO - 2023-12-13 08:46:31 --> Output Class Initialized
INFO - 2023-12-13 08:46:31 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:31 --> Input Class Initialized
INFO - 2023-12-13 08:46:31 --> Language Class Initialized
INFO - 2023-12-13 08:46:31 --> Language Class Initialized
INFO - 2023-12-13 08:46:31 --> Config Class Initialized
INFO - 2023-12-13 08:46:31 --> Loader Class Initialized
INFO - 2023-12-13 08:46:31 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:31 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:31 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:31 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:31 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:31 --> Controller Class Initialized
INFO - 2023-12-13 08:46:31 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:46:31 --> Config Class Initialized
INFO - 2023-12-13 08:46:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:31 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:31 --> URI Class Initialized
INFO - 2023-12-13 08:46:32 --> Router Class Initialized
INFO - 2023-12-13 08:46:32 --> Output Class Initialized
INFO - 2023-12-13 08:46:32 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:32 --> Input Class Initialized
INFO - 2023-12-13 08:46:32 --> Language Class Initialized
INFO - 2023-12-13 08:46:32 --> Language Class Initialized
INFO - 2023-12-13 08:46:32 --> Config Class Initialized
INFO - 2023-12-13 08:46:32 --> Loader Class Initialized
INFO - 2023-12-13 08:46:32 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:32 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:32 --> Controller Class Initialized
INFO - 2023-12-13 08:46:32 --> Config Class Initialized
INFO - 2023-12-13 08:46:32 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:32 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:32 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:32 --> URI Class Initialized
INFO - 2023-12-13 08:46:32 --> Router Class Initialized
INFO - 2023-12-13 08:46:32 --> Output Class Initialized
INFO - 2023-12-13 08:46:32 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:32 --> Input Class Initialized
INFO - 2023-12-13 08:46:32 --> Language Class Initialized
INFO - 2023-12-13 08:46:32 --> Language Class Initialized
INFO - 2023-12-13 08:46:32 --> Config Class Initialized
INFO - 2023-12-13 08:46:32 --> Loader Class Initialized
INFO - 2023-12-13 08:46:32 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:32 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:32 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:32 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:32 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:32 --> Total execution time: 0.1704
INFO - 2023-12-13 08:46:35 --> Config Class Initialized
INFO - 2023-12-13 08:46:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:35 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:35 --> URI Class Initialized
INFO - 2023-12-13 08:46:35 --> Router Class Initialized
INFO - 2023-12-13 08:46:35 --> Output Class Initialized
INFO - 2023-12-13 08:46:35 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:35 --> Input Class Initialized
INFO - 2023-12-13 08:46:35 --> Language Class Initialized
INFO - 2023-12-13 08:46:35 --> Language Class Initialized
INFO - 2023-12-13 08:46:35 --> Config Class Initialized
INFO - 2023-12-13 08:46:35 --> Loader Class Initialized
INFO - 2023-12-13 08:46:35 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:35 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:35 --> Controller Class Initialized
INFO - 2023-12-13 08:46:35 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:46:35 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:35 --> Total execution time: 0.2113
INFO - 2023-12-13 08:46:35 --> Config Class Initialized
INFO - 2023-12-13 08:46:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:35 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:35 --> URI Class Initialized
INFO - 2023-12-13 08:46:35 --> Router Class Initialized
INFO - 2023-12-13 08:46:35 --> Output Class Initialized
INFO - 2023-12-13 08:46:35 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:35 --> Input Class Initialized
INFO - 2023-12-13 08:46:35 --> Language Class Initialized
INFO - 2023-12-13 08:46:35 --> Language Class Initialized
INFO - 2023-12-13 08:46:35 --> Config Class Initialized
INFO - 2023-12-13 08:46:35 --> Loader Class Initialized
INFO - 2023-12-13 08:46:35 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:35 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:35 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:35 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:35 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:35 --> Total execution time: 0.2571
INFO - 2023-12-13 08:46:37 --> Config Class Initialized
INFO - 2023-12-13 08:46:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:37 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:37 --> URI Class Initialized
INFO - 2023-12-13 08:46:37 --> Router Class Initialized
INFO - 2023-12-13 08:46:37 --> Output Class Initialized
INFO - 2023-12-13 08:46:37 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:37 --> Input Class Initialized
INFO - 2023-12-13 08:46:37 --> Language Class Initialized
INFO - 2023-12-13 08:46:37 --> Language Class Initialized
INFO - 2023-12-13 08:46:37 --> Config Class Initialized
INFO - 2023-12-13 08:46:37 --> Loader Class Initialized
INFO - 2023-12-13 08:46:37 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:37 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:37 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:37 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:37 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:37 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:46:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:37 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:37 --> Total execution time: 0.2104
INFO - 2023-12-13 08:46:38 --> Config Class Initialized
INFO - 2023-12-13 08:46:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:38 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:38 --> URI Class Initialized
INFO - 2023-12-13 08:46:38 --> Router Class Initialized
INFO - 2023-12-13 08:46:38 --> Output Class Initialized
INFO - 2023-12-13 08:46:38 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:38 --> Input Class Initialized
INFO - 2023-12-13 08:46:38 --> Language Class Initialized
INFO - 2023-12-13 08:46:39 --> Language Class Initialized
INFO - 2023-12-13 08:46:39 --> Config Class Initialized
INFO - 2023-12-13 08:46:39 --> Loader Class Initialized
INFO - 2023-12-13 08:46:39 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:39 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:39 --> Controller Class Initialized
DEBUG - 2023-12-13 08:46:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:46:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:46:39 --> Final output sent to browser
DEBUG - 2023-12-13 08:46:39 --> Total execution time: 0.1770
INFO - 2023-12-13 08:46:39 --> Config Class Initialized
INFO - 2023-12-13 08:46:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:46:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:46:39 --> Utf8 Class Initialized
INFO - 2023-12-13 08:46:39 --> URI Class Initialized
INFO - 2023-12-13 08:46:39 --> Router Class Initialized
INFO - 2023-12-13 08:46:39 --> Output Class Initialized
INFO - 2023-12-13 08:46:39 --> Security Class Initialized
DEBUG - 2023-12-13 08:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:46:39 --> Input Class Initialized
INFO - 2023-12-13 08:46:39 --> Language Class Initialized
INFO - 2023-12-13 08:46:39 --> Language Class Initialized
INFO - 2023-12-13 08:46:39 --> Config Class Initialized
INFO - 2023-12-13 08:46:39 --> Loader Class Initialized
INFO - 2023-12-13 08:46:39 --> Helper loaded: url_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: file_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: form_helper
INFO - 2023-12-13 08:46:39 --> Helper loaded: my_helper
INFO - 2023-12-13 08:46:39 --> Database Driver Class Initialized
INFO - 2023-12-13 08:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:46:39 --> Controller Class Initialized
INFO - 2023-12-13 08:47:14 --> Config Class Initialized
INFO - 2023-12-13 08:47:14 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:47:14 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:47:14 --> Utf8 Class Initialized
INFO - 2023-12-13 08:47:14 --> URI Class Initialized
INFO - 2023-12-13 08:47:14 --> Router Class Initialized
INFO - 2023-12-13 08:47:14 --> Output Class Initialized
INFO - 2023-12-13 08:47:14 --> Security Class Initialized
DEBUG - 2023-12-13 08:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:47:14 --> Input Class Initialized
INFO - 2023-12-13 08:47:14 --> Language Class Initialized
INFO - 2023-12-13 08:47:14 --> Language Class Initialized
INFO - 2023-12-13 08:47:14 --> Config Class Initialized
INFO - 2023-12-13 08:47:14 --> Loader Class Initialized
INFO - 2023-12-13 08:47:14 --> Helper loaded: url_helper
INFO - 2023-12-13 08:47:14 --> Helper loaded: file_helper
INFO - 2023-12-13 08:47:14 --> Helper loaded: form_helper
INFO - 2023-12-13 08:47:14 --> Helper loaded: my_helper
INFO - 2023-12-13 08:47:14 --> Database Driver Class Initialized
INFO - 2023-12-13 08:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:47:14 --> Controller Class Initialized
INFO - 2023-12-13 08:47:14 --> Final output sent to browser
DEBUG - 2023-12-13 08:47:14 --> Total execution time: 0.0356
INFO - 2023-12-13 08:50:00 --> Config Class Initialized
INFO - 2023-12-13 08:50:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:00 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:00 --> URI Class Initialized
INFO - 2023-12-13 08:50:00 --> Router Class Initialized
INFO - 2023-12-13 08:50:00 --> Output Class Initialized
INFO - 2023-12-13 08:50:00 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:00 --> Input Class Initialized
INFO - 2023-12-13 08:50:00 --> Language Class Initialized
INFO - 2023-12-13 08:50:00 --> Language Class Initialized
INFO - 2023-12-13 08:50:00 --> Config Class Initialized
INFO - 2023-12-13 08:50:00 --> Loader Class Initialized
INFO - 2023-12-13 08:50:00 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:00 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:00 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:00 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:00 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:00 --> Controller Class Initialized
DEBUG - 2023-12-13 08:50:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:50:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:50:00 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:00 --> Total execution time: 0.1527
INFO - 2023-12-13 08:50:06 --> Config Class Initialized
INFO - 2023-12-13 08:50:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:06 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:06 --> URI Class Initialized
INFO - 2023-12-13 08:50:06 --> Router Class Initialized
INFO - 2023-12-13 08:50:06 --> Output Class Initialized
INFO - 2023-12-13 08:50:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:06 --> Input Class Initialized
INFO - 2023-12-13 08:50:06 --> Language Class Initialized
INFO - 2023-12-13 08:50:06 --> Language Class Initialized
INFO - 2023-12-13 08:50:06 --> Config Class Initialized
INFO - 2023-12-13 08:50:06 --> Loader Class Initialized
INFO - 2023-12-13 08:50:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:06 --> Controller Class Initialized
DEBUG - 2023-12-13 08:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:50:06 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:06 --> Total execution time: 0.0352
INFO - 2023-12-13 08:50:12 --> Config Class Initialized
INFO - 2023-12-13 08:50:12 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:12 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:12 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:12 --> URI Class Initialized
INFO - 2023-12-13 08:50:12 --> Router Class Initialized
INFO - 2023-12-13 08:50:12 --> Output Class Initialized
INFO - 2023-12-13 08:50:12 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:12 --> Input Class Initialized
INFO - 2023-12-13 08:50:12 --> Language Class Initialized
INFO - 2023-12-13 08:50:12 --> Language Class Initialized
INFO - 2023-12-13 08:50:12 --> Config Class Initialized
INFO - 2023-12-13 08:50:12 --> Loader Class Initialized
INFO - 2023-12-13 08:50:12 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:12 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:12 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:12 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:12 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:12 --> Controller Class Initialized
DEBUG - 2023-12-13 08:50:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:50:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:50:12 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:12 --> Total execution time: 0.0516
INFO - 2023-12-13 08:50:13 --> Config Class Initialized
INFO - 2023-12-13 08:50:13 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:13 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:13 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:13 --> URI Class Initialized
INFO - 2023-12-13 08:50:13 --> Router Class Initialized
INFO - 2023-12-13 08:50:13 --> Output Class Initialized
INFO - 2023-12-13 08:50:13 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:13 --> Input Class Initialized
INFO - 2023-12-13 08:50:13 --> Language Class Initialized
INFO - 2023-12-13 08:50:13 --> Language Class Initialized
INFO - 2023-12-13 08:50:13 --> Config Class Initialized
INFO - 2023-12-13 08:50:13 --> Loader Class Initialized
INFO - 2023-12-13 08:50:13 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:13 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:13 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:13 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:13 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:13 --> Controller Class Initialized
INFO - 2023-12-13 08:50:16 --> Config Class Initialized
INFO - 2023-12-13 08:50:16 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:16 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:16 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:16 --> URI Class Initialized
INFO - 2023-12-13 08:50:16 --> Router Class Initialized
INFO - 2023-12-13 08:50:16 --> Output Class Initialized
INFO - 2023-12-13 08:50:16 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:16 --> Input Class Initialized
INFO - 2023-12-13 08:50:16 --> Language Class Initialized
INFO - 2023-12-13 08:50:16 --> Language Class Initialized
INFO - 2023-12-13 08:50:16 --> Config Class Initialized
INFO - 2023-12-13 08:50:16 --> Loader Class Initialized
INFO - 2023-12-13 08:50:16 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:16 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:16 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:16 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:16 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:16 --> Controller Class Initialized
INFO - 2023-12-13 08:50:16 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:16 --> Total execution time: 0.0997
INFO - 2023-12-13 08:50:19 --> Config Class Initialized
INFO - 2023-12-13 08:50:19 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:19 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:19 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:19 --> URI Class Initialized
INFO - 2023-12-13 08:50:19 --> Router Class Initialized
INFO - 2023-12-13 08:50:19 --> Output Class Initialized
INFO - 2023-12-13 08:50:19 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:19 --> Input Class Initialized
INFO - 2023-12-13 08:50:19 --> Language Class Initialized
INFO - 2023-12-13 08:50:19 --> Language Class Initialized
INFO - 2023-12-13 08:50:19 --> Config Class Initialized
INFO - 2023-12-13 08:50:19 --> Loader Class Initialized
INFO - 2023-12-13 08:50:19 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:19 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:19 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:19 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:19 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:19 --> Controller Class Initialized
DEBUG - 2023-12-13 08:50:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:50:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:50:19 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:19 --> Total execution time: 0.0885
INFO - 2023-12-13 08:50:21 --> Config Class Initialized
INFO - 2023-12-13 08:50:21 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:21 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:21 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:21 --> URI Class Initialized
INFO - 2023-12-13 08:50:21 --> Router Class Initialized
INFO - 2023-12-13 08:50:21 --> Output Class Initialized
INFO - 2023-12-13 08:50:21 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:21 --> Input Class Initialized
INFO - 2023-12-13 08:50:21 --> Language Class Initialized
INFO - 2023-12-13 08:50:21 --> Language Class Initialized
INFO - 2023-12-13 08:50:21 --> Config Class Initialized
INFO - 2023-12-13 08:50:21 --> Loader Class Initialized
INFO - 2023-12-13 08:50:21 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:21 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:21 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:21 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:21 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:21 --> Controller Class Initialized
DEBUG - 2023-12-13 08:50:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 08:50:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:50:21 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:21 --> Total execution time: 0.1691
INFO - 2023-12-13 08:50:23 --> Config Class Initialized
INFO - 2023-12-13 08:50:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:23 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:23 --> URI Class Initialized
INFO - 2023-12-13 08:50:23 --> Router Class Initialized
INFO - 2023-12-13 08:50:23 --> Output Class Initialized
INFO - 2023-12-13 08:50:23 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:23 --> Input Class Initialized
INFO - 2023-12-13 08:50:23 --> Language Class Initialized
INFO - 2023-12-13 08:50:23 --> Language Class Initialized
INFO - 2023-12-13 08:50:23 --> Config Class Initialized
INFO - 2023-12-13 08:50:23 --> Loader Class Initialized
INFO - 2023-12-13 08:50:23 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:23 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:23 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:23 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:24 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:24 --> Controller Class Initialized
INFO - 2023-12-13 08:50:24 --> Final output sent to browser
DEBUG - 2023-12-13 08:50:24 --> Total execution time: 0.1668
INFO - 2023-12-13 08:50:26 --> Config Class Initialized
INFO - 2023-12-13 08:50:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:26 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:26 --> URI Class Initialized
INFO - 2023-12-13 08:50:26 --> Router Class Initialized
INFO - 2023-12-13 08:50:26 --> Output Class Initialized
INFO - 2023-12-13 08:50:26 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:26 --> Input Class Initialized
INFO - 2023-12-13 08:50:26 --> Language Class Initialized
INFO - 2023-12-13 08:50:26 --> Language Class Initialized
INFO - 2023-12-13 08:50:26 --> Config Class Initialized
INFO - 2023-12-13 08:50:26 --> Loader Class Initialized
INFO - 2023-12-13 08:50:26 --> Config Class Initialized
INFO - 2023-12-13 08:50:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:50:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:50:26 --> Utf8 Class Initialized
INFO - 2023-12-13 08:50:26 --> URI Class Initialized
INFO - 2023-12-13 08:50:26 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:26 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:26 --> Router Class Initialized
INFO - 2023-12-13 08:50:26 --> Output Class Initialized
INFO - 2023-12-13 08:50:26 --> Security Class Initialized
DEBUG - 2023-12-13 08:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:50:26 --> Input Class Initialized
INFO - 2023-12-13 08:50:26 --> Language Class Initialized
INFO - 2023-12-13 08:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:26 --> Controller Class Initialized
INFO - 2023-12-13 08:50:26 --> Language Class Initialized
INFO - 2023-12-13 08:50:26 --> Config Class Initialized
INFO - 2023-12-13 08:50:26 --> Loader Class Initialized
INFO - 2023-12-13 08:50:26 --> Helper loaded: url_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: file_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: form_helper
INFO - 2023-12-13 08:50:26 --> Helper loaded: my_helper
INFO - 2023-12-13 08:50:26 --> Database Driver Class Initialized
INFO - 2023-12-13 08:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:50:27 --> Controller Class Initialized
INFO - 2023-12-13 08:54:32 --> Config Class Initialized
INFO - 2023-12-13 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:32 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:32 --> URI Class Initialized
INFO - 2023-12-13 08:54:32 --> Router Class Initialized
INFO - 2023-12-13 08:54:32 --> Output Class Initialized
INFO - 2023-12-13 08:54:32 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:32 --> Input Class Initialized
INFO - 2023-12-13 08:54:32 --> Language Class Initialized
INFO - 2023-12-13 08:54:32 --> Language Class Initialized
INFO - 2023-12-13 08:54:32 --> Config Class Initialized
INFO - 2023-12-13 08:54:32 --> Loader Class Initialized
INFO - 2023-12-13 08:54:32 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:32 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:32 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:32 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:32 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:32 --> Controller Class Initialized
DEBUG - 2023-12-13 08:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:54:32 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:32 --> Total execution time: 0.0463
INFO - 2023-12-13 08:54:35 --> Config Class Initialized
INFO - 2023-12-13 08:54:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:35 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:35 --> URI Class Initialized
INFO - 2023-12-13 08:54:35 --> Router Class Initialized
INFO - 2023-12-13 08:54:35 --> Output Class Initialized
INFO - 2023-12-13 08:54:35 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:35 --> Input Class Initialized
INFO - 2023-12-13 08:54:35 --> Language Class Initialized
INFO - 2023-12-13 08:54:35 --> Language Class Initialized
INFO - 2023-12-13 08:54:35 --> Config Class Initialized
INFO - 2023-12-13 08:54:35 --> Loader Class Initialized
INFO - 2023-12-13 08:54:35 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:35 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:35 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:35 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:35 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:35 --> Controller Class Initialized
INFO - 2023-12-13 08:54:35 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:54:36 --> Config Class Initialized
INFO - 2023-12-13 08:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:36 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:36 --> URI Class Initialized
INFO - 2023-12-13 08:54:36 --> Router Class Initialized
INFO - 2023-12-13 08:54:36 --> Output Class Initialized
INFO - 2023-12-13 08:54:36 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:36 --> Input Class Initialized
INFO - 2023-12-13 08:54:36 --> Language Class Initialized
INFO - 2023-12-13 08:54:36 --> Language Class Initialized
INFO - 2023-12-13 08:54:36 --> Config Class Initialized
INFO - 2023-12-13 08:54:36 --> Loader Class Initialized
INFO - 2023-12-13 08:54:36 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:36 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:36 --> Controller Class Initialized
INFO - 2023-12-13 08:54:36 --> Config Class Initialized
INFO - 2023-12-13 08:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:36 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:36 --> URI Class Initialized
INFO - 2023-12-13 08:54:36 --> Router Class Initialized
INFO - 2023-12-13 08:54:36 --> Output Class Initialized
INFO - 2023-12-13 08:54:36 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:36 --> Input Class Initialized
INFO - 2023-12-13 08:54:36 --> Language Class Initialized
INFO - 2023-12-13 08:54:36 --> Language Class Initialized
INFO - 2023-12-13 08:54:36 --> Config Class Initialized
INFO - 2023-12-13 08:54:36 --> Loader Class Initialized
INFO - 2023-12-13 08:54:36 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:36 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:36 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:36 --> Controller Class Initialized
DEBUG - 2023-12-13 08:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:54:36 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:36 --> Total execution time: 0.0402
INFO - 2023-12-13 08:54:38 --> Config Class Initialized
INFO - 2023-12-13 08:54:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:38 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:38 --> URI Class Initialized
INFO - 2023-12-13 08:54:38 --> Router Class Initialized
INFO - 2023-12-13 08:54:38 --> Output Class Initialized
INFO - 2023-12-13 08:54:38 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:38 --> Input Class Initialized
INFO - 2023-12-13 08:54:38 --> Language Class Initialized
INFO - 2023-12-13 08:54:38 --> Language Class Initialized
INFO - 2023-12-13 08:54:38 --> Config Class Initialized
INFO - 2023-12-13 08:54:38 --> Loader Class Initialized
INFO - 2023-12-13 08:54:38 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:38 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:38 --> Controller Class Initialized
INFO - 2023-12-13 08:54:38 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:54:38 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:38 --> Total execution time: 0.0789
INFO - 2023-12-13 08:54:38 --> Config Class Initialized
INFO - 2023-12-13 08:54:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:38 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:38 --> URI Class Initialized
INFO - 2023-12-13 08:54:38 --> Router Class Initialized
INFO - 2023-12-13 08:54:38 --> Output Class Initialized
INFO - 2023-12-13 08:54:38 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:38 --> Input Class Initialized
INFO - 2023-12-13 08:54:38 --> Language Class Initialized
INFO - 2023-12-13 08:54:38 --> Language Class Initialized
INFO - 2023-12-13 08:54:38 --> Config Class Initialized
INFO - 2023-12-13 08:54:38 --> Loader Class Initialized
INFO - 2023-12-13 08:54:38 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:38 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:38 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:38 --> Controller Class Initialized
DEBUG - 2023-12-13 08:54:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 08:54:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:54:38 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:38 --> Total execution time: 0.0684
INFO - 2023-12-13 08:54:39 --> Config Class Initialized
INFO - 2023-12-13 08:54:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:39 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:39 --> URI Class Initialized
INFO - 2023-12-13 08:54:39 --> Router Class Initialized
INFO - 2023-12-13 08:54:39 --> Output Class Initialized
INFO - 2023-12-13 08:54:39 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:39 --> Input Class Initialized
INFO - 2023-12-13 08:54:39 --> Language Class Initialized
INFO - 2023-12-13 08:54:39 --> Language Class Initialized
INFO - 2023-12-13 08:54:39 --> Config Class Initialized
INFO - 2023-12-13 08:54:39 --> Loader Class Initialized
INFO - 2023-12-13 08:54:39 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:39 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:39 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:39 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:39 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:39 --> Controller Class Initialized
DEBUG - 2023-12-13 08:54:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:54:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:54:39 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:39 --> Total execution time: 0.0714
INFO - 2023-12-13 08:54:42 --> Config Class Initialized
INFO - 2023-12-13 08:54:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:42 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:42 --> URI Class Initialized
INFO - 2023-12-13 08:54:42 --> Router Class Initialized
INFO - 2023-12-13 08:54:42 --> Output Class Initialized
INFO - 2023-12-13 08:54:42 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:42 --> Input Class Initialized
INFO - 2023-12-13 08:54:42 --> Language Class Initialized
INFO - 2023-12-13 08:54:42 --> Language Class Initialized
INFO - 2023-12-13 08:54:42 --> Config Class Initialized
INFO - 2023-12-13 08:54:42 --> Loader Class Initialized
INFO - 2023-12-13 08:54:42 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:42 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:42 --> Controller Class Initialized
DEBUG - 2023-12-13 08:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:54:42 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:42 --> Total execution time: 0.1085
INFO - 2023-12-13 08:54:42 --> Config Class Initialized
INFO - 2023-12-13 08:54:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:42 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:42 --> URI Class Initialized
INFO - 2023-12-13 08:54:42 --> Router Class Initialized
INFO - 2023-12-13 08:54:42 --> Output Class Initialized
INFO - 2023-12-13 08:54:42 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:42 --> Input Class Initialized
INFO - 2023-12-13 08:54:42 --> Language Class Initialized
INFO - 2023-12-13 08:54:42 --> Language Class Initialized
INFO - 2023-12-13 08:54:42 --> Config Class Initialized
INFO - 2023-12-13 08:54:42 --> Loader Class Initialized
INFO - 2023-12-13 08:54:42 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:42 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:42 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:42 --> Controller Class Initialized
INFO - 2023-12-13 08:54:43 --> Config Class Initialized
INFO - 2023-12-13 08:54:43 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:43 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:43 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:43 --> URI Class Initialized
INFO - 2023-12-13 08:54:43 --> Router Class Initialized
INFO - 2023-12-13 08:54:43 --> Output Class Initialized
INFO - 2023-12-13 08:54:43 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:43 --> Input Class Initialized
INFO - 2023-12-13 08:54:43 --> Language Class Initialized
INFO - 2023-12-13 08:54:43 --> Language Class Initialized
INFO - 2023-12-13 08:54:43 --> Config Class Initialized
INFO - 2023-12-13 08:54:43 --> Loader Class Initialized
INFO - 2023-12-13 08:54:43 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:43 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:43 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:43 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:43 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:44 --> Controller Class Initialized
INFO - 2023-12-13 08:54:44 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:44 --> Total execution time: 0.2351
INFO - 2023-12-13 08:54:57 --> Config Class Initialized
INFO - 2023-12-13 08:54:57 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:54:57 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:54:57 --> Utf8 Class Initialized
INFO - 2023-12-13 08:54:57 --> URI Class Initialized
INFO - 2023-12-13 08:54:57 --> Router Class Initialized
INFO - 2023-12-13 08:54:57 --> Output Class Initialized
INFO - 2023-12-13 08:54:57 --> Security Class Initialized
DEBUG - 2023-12-13 08:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:54:57 --> Input Class Initialized
INFO - 2023-12-13 08:54:57 --> Language Class Initialized
INFO - 2023-12-13 08:54:57 --> Language Class Initialized
INFO - 2023-12-13 08:54:57 --> Config Class Initialized
INFO - 2023-12-13 08:54:57 --> Loader Class Initialized
INFO - 2023-12-13 08:54:57 --> Helper loaded: url_helper
INFO - 2023-12-13 08:54:57 --> Helper loaded: file_helper
INFO - 2023-12-13 08:54:57 --> Helper loaded: form_helper
INFO - 2023-12-13 08:54:57 --> Helper loaded: my_helper
INFO - 2023-12-13 08:54:57 --> Database Driver Class Initialized
INFO - 2023-12-13 08:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:54:57 --> Controller Class Initialized
INFO - 2023-12-13 08:54:58 --> Final output sent to browser
DEBUG - 2023-12-13 08:54:58 --> Total execution time: 0.2967
INFO - 2023-12-13 08:55:02 --> Config Class Initialized
INFO - 2023-12-13 08:55:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:02 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:02 --> URI Class Initialized
INFO - 2023-12-13 08:55:02 --> Router Class Initialized
INFO - 2023-12-13 08:55:02 --> Output Class Initialized
INFO - 2023-12-13 08:55:02 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:02 --> Input Class Initialized
INFO - 2023-12-13 08:55:02 --> Language Class Initialized
INFO - 2023-12-13 08:55:02 --> Language Class Initialized
INFO - 2023-12-13 08:55:02 --> Config Class Initialized
INFO - 2023-12-13 08:55:02 --> Loader Class Initialized
INFO - 2023-12-13 08:55:02 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:02 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:02 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:02 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:02 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:02 --> Controller Class Initialized
INFO - 2023-12-13 08:55:02 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:02 --> Total execution time: 0.2603
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:06 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:06 --> URI Class Initialized
INFO - 2023-12-13 08:55:06 --> Router Class Initialized
INFO - 2023-12-13 08:55:06 --> Output Class Initialized
INFO - 2023-12-13 08:55:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:06 --> Input Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Loader Class Initialized
INFO - 2023-12-13 08:55:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:06 --> Controller Class Initialized
INFO - 2023-12-13 08:55:06 --> Helper loaded: cookie_helper
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:06 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:06 --> URI Class Initialized
INFO - 2023-12-13 08:55:06 --> Router Class Initialized
INFO - 2023-12-13 08:55:06 --> Output Class Initialized
INFO - 2023-12-13 08:55:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:06 --> Input Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Loader Class Initialized
INFO - 2023-12-13 08:55:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:06 --> Controller Class Initialized
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:06 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:06 --> URI Class Initialized
INFO - 2023-12-13 08:55:06 --> Router Class Initialized
INFO - 2023-12-13 08:55:06 --> Output Class Initialized
INFO - 2023-12-13 08:55:06 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:06 --> Input Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Language Class Initialized
INFO - 2023-12-13 08:55:06 --> Config Class Initialized
INFO - 2023-12-13 08:55:06 --> Loader Class Initialized
INFO - 2023-12-13 08:55:06 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:06 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:06 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:06 --> Controller Class Initialized
DEBUG - 2023-12-13 08:55:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 08:55:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:55:06 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:06 --> Total execution time: 0.1079
INFO - 2023-12-13 08:55:11 --> Config Class Initialized
INFO - 2023-12-13 08:55:11 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:11 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:11 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:11 --> URI Class Initialized
INFO - 2023-12-13 08:55:11 --> Router Class Initialized
INFO - 2023-12-13 08:55:11 --> Output Class Initialized
INFO - 2023-12-13 08:55:11 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:11 --> Input Class Initialized
INFO - 2023-12-13 08:55:11 --> Language Class Initialized
INFO - 2023-12-13 08:55:11 --> Language Class Initialized
INFO - 2023-12-13 08:55:11 --> Config Class Initialized
INFO - 2023-12-13 08:55:11 --> Loader Class Initialized
INFO - 2023-12-13 08:55:11 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:11 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:11 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:11 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:11 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:11 --> Controller Class Initialized
INFO - 2023-12-13 08:55:12 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:12 --> Total execution time: 0.3805
INFO - 2023-12-13 08:55:14 --> Config Class Initialized
INFO - 2023-12-13 08:55:14 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:14 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:14 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:14 --> URI Class Initialized
INFO - 2023-12-13 08:55:14 --> Router Class Initialized
INFO - 2023-12-13 08:55:14 --> Output Class Initialized
INFO - 2023-12-13 08:55:14 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:14 --> Input Class Initialized
INFO - 2023-12-13 08:55:14 --> Language Class Initialized
INFO - 2023-12-13 08:55:14 --> Language Class Initialized
INFO - 2023-12-13 08:55:14 --> Config Class Initialized
INFO - 2023-12-13 08:55:14 --> Loader Class Initialized
INFO - 2023-12-13 08:55:14 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:14 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:14 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:14 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:14 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:14 --> Controller Class Initialized
INFO - 2023-12-13 08:55:14 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:14 --> Total execution time: 0.0736
INFO - 2023-12-13 08:55:15 --> Config Class Initialized
INFO - 2023-12-13 08:55:15 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:15 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:15 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:15 --> URI Class Initialized
INFO - 2023-12-13 08:55:15 --> Router Class Initialized
INFO - 2023-12-13 08:55:15 --> Output Class Initialized
INFO - 2023-12-13 08:55:15 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:15 --> Input Class Initialized
INFO - 2023-12-13 08:55:15 --> Language Class Initialized
INFO - 2023-12-13 08:55:15 --> Language Class Initialized
INFO - 2023-12-13 08:55:15 --> Config Class Initialized
INFO - 2023-12-13 08:55:15 --> Loader Class Initialized
INFO - 2023-12-13 08:55:15 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:15 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:15 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:15 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:15 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:15 --> Controller Class Initialized
INFO - 2023-12-13 08:55:15 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:15 --> Total execution time: 0.0455
INFO - 2023-12-13 08:55:24 --> Config Class Initialized
INFO - 2023-12-13 08:55:24 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:24 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:24 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:24 --> URI Class Initialized
INFO - 2023-12-13 08:55:24 --> Router Class Initialized
INFO - 2023-12-13 08:55:24 --> Output Class Initialized
INFO - 2023-12-13 08:55:24 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:24 --> Input Class Initialized
INFO - 2023-12-13 08:55:24 --> Language Class Initialized
INFO - 2023-12-13 08:55:24 --> Language Class Initialized
INFO - 2023-12-13 08:55:24 --> Config Class Initialized
INFO - 2023-12-13 08:55:24 --> Loader Class Initialized
INFO - 2023-12-13 08:55:24 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:24 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:24 --> Controller Class Initialized
INFO - 2023-12-13 08:55:24 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:24 --> Total execution time: 0.1015
INFO - 2023-12-13 08:55:24 --> Config Class Initialized
INFO - 2023-12-13 08:55:24 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:24 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:24 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:24 --> URI Class Initialized
INFO - 2023-12-13 08:55:24 --> Router Class Initialized
INFO - 2023-12-13 08:55:24 --> Output Class Initialized
INFO - 2023-12-13 08:55:24 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:24 --> Input Class Initialized
INFO - 2023-12-13 08:55:24 --> Language Class Initialized
INFO - 2023-12-13 08:55:24 --> Language Class Initialized
INFO - 2023-12-13 08:55:24 --> Config Class Initialized
INFO - 2023-12-13 08:55:24 --> Loader Class Initialized
INFO - 2023-12-13 08:55:24 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:24 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:25 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:25 --> Controller Class Initialized
INFO - 2023-12-13 08:55:25 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:25 --> Total execution time: 0.1159
INFO - 2023-12-13 08:55:30 --> Config Class Initialized
INFO - 2023-12-13 08:55:30 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:30 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:30 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:30 --> URI Class Initialized
INFO - 2023-12-13 08:55:30 --> Router Class Initialized
INFO - 2023-12-13 08:55:30 --> Output Class Initialized
INFO - 2023-12-13 08:55:30 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:30 --> Input Class Initialized
INFO - 2023-12-13 08:55:30 --> Language Class Initialized
INFO - 2023-12-13 08:55:30 --> Language Class Initialized
INFO - 2023-12-13 08:55:30 --> Config Class Initialized
INFO - 2023-12-13 08:55:30 --> Loader Class Initialized
INFO - 2023-12-13 08:55:30 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:30 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:30 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:30 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:30 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:30 --> Controller Class Initialized
INFO - 2023-12-13 08:55:30 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:30 --> Total execution time: 0.0579
INFO - 2023-12-13 08:55:36 --> Config Class Initialized
INFO - 2023-12-13 08:55:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:36 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:36 --> URI Class Initialized
INFO - 2023-12-13 08:55:36 --> Router Class Initialized
INFO - 2023-12-13 08:55:36 --> Output Class Initialized
INFO - 2023-12-13 08:55:36 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:36 --> Input Class Initialized
INFO - 2023-12-13 08:55:36 --> Language Class Initialized
INFO - 2023-12-13 08:55:36 --> Language Class Initialized
INFO - 2023-12-13 08:55:36 --> Config Class Initialized
INFO - 2023-12-13 08:55:36 --> Loader Class Initialized
INFO - 2023-12-13 08:55:36 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:36 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:36 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:36 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:36 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:36 --> Controller Class Initialized
INFO - 2023-12-13 08:55:36 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:36 --> Total execution time: 0.1245
INFO - 2023-12-13 08:55:41 --> Config Class Initialized
INFO - 2023-12-13 08:55:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:41 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:41 --> URI Class Initialized
INFO - 2023-12-13 08:55:41 --> Router Class Initialized
INFO - 2023-12-13 08:55:41 --> Output Class Initialized
INFO - 2023-12-13 08:55:41 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:41 --> Input Class Initialized
INFO - 2023-12-13 08:55:41 --> Language Class Initialized
INFO - 2023-12-13 08:55:41 --> Language Class Initialized
INFO - 2023-12-13 08:55:41 --> Config Class Initialized
INFO - 2023-12-13 08:55:41 --> Loader Class Initialized
INFO - 2023-12-13 08:55:41 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:41 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:41 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:41 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:41 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:41 --> Controller Class Initialized
INFO - 2023-12-13 08:55:41 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:41 --> Total execution time: 0.1299
INFO - 2023-12-13 08:55:45 --> Config Class Initialized
INFO - 2023-12-13 08:55:45 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:45 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:45 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:45 --> URI Class Initialized
INFO - 2023-12-13 08:55:45 --> Router Class Initialized
INFO - 2023-12-13 08:55:45 --> Output Class Initialized
INFO - 2023-12-13 08:55:45 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:45 --> Input Class Initialized
INFO - 2023-12-13 08:55:45 --> Language Class Initialized
INFO - 2023-12-13 08:55:45 --> Language Class Initialized
INFO - 2023-12-13 08:55:45 --> Config Class Initialized
INFO - 2023-12-13 08:55:45 --> Loader Class Initialized
INFO - 2023-12-13 08:55:45 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:45 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:45 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:45 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:45 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:45 --> Controller Class Initialized
INFO - 2023-12-13 08:55:45 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:45 --> Total execution time: 0.1323
INFO - 2023-12-13 08:55:48 --> Config Class Initialized
INFO - 2023-12-13 08:55:48 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:48 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:48 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:48 --> URI Class Initialized
INFO - 2023-12-13 08:55:48 --> Router Class Initialized
INFO - 2023-12-13 08:55:48 --> Output Class Initialized
INFO - 2023-12-13 08:55:48 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:48 --> Input Class Initialized
INFO - 2023-12-13 08:55:48 --> Language Class Initialized
INFO - 2023-12-13 08:55:48 --> Language Class Initialized
INFO - 2023-12-13 08:55:48 --> Config Class Initialized
INFO - 2023-12-13 08:55:48 --> Loader Class Initialized
INFO - 2023-12-13 08:55:48 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:48 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:48 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:48 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:48 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:48 --> Controller Class Initialized
INFO - 2023-12-13 08:55:48 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:48 --> Total execution time: 0.1151
INFO - 2023-12-13 08:55:52 --> Config Class Initialized
INFO - 2023-12-13 08:55:52 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:52 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:52 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:52 --> URI Class Initialized
INFO - 2023-12-13 08:55:52 --> Router Class Initialized
INFO - 2023-12-13 08:55:52 --> Output Class Initialized
INFO - 2023-12-13 08:55:52 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:52 --> Input Class Initialized
INFO - 2023-12-13 08:55:52 --> Language Class Initialized
INFO - 2023-12-13 08:55:52 --> Language Class Initialized
INFO - 2023-12-13 08:55:52 --> Config Class Initialized
INFO - 2023-12-13 08:55:52 --> Loader Class Initialized
INFO - 2023-12-13 08:55:52 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:52 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:52 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:52 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:52 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:52 --> Controller Class Initialized
DEBUG - 2023-12-13 08:55:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:55:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:55:52 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:52 --> Total execution time: 0.0324
INFO - 2023-12-13 08:55:54 --> Config Class Initialized
INFO - 2023-12-13 08:55:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:54 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:54 --> URI Class Initialized
INFO - 2023-12-13 08:55:54 --> Router Class Initialized
INFO - 2023-12-13 08:55:54 --> Output Class Initialized
INFO - 2023-12-13 08:55:54 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:54 --> Input Class Initialized
INFO - 2023-12-13 08:55:54 --> Language Class Initialized
INFO - 2023-12-13 08:55:54 --> Language Class Initialized
INFO - 2023-12-13 08:55:54 --> Config Class Initialized
INFO - 2023-12-13 08:55:54 --> Loader Class Initialized
INFO - 2023-12-13 08:55:54 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:54 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:54 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:54 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:54 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:54 --> Controller Class Initialized
DEBUG - 2023-12-13 08:55:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 08:55:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:55:54 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:54 --> Total execution time: 0.0896
INFO - 2023-12-13 08:55:55 --> Config Class Initialized
INFO - 2023-12-13 08:55:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:55 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:55 --> URI Class Initialized
INFO - 2023-12-13 08:55:55 --> Router Class Initialized
INFO - 2023-12-13 08:55:55 --> Output Class Initialized
INFO - 2023-12-13 08:55:55 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:55 --> Input Class Initialized
INFO - 2023-12-13 08:55:55 --> Language Class Initialized
INFO - 2023-12-13 08:55:55 --> Language Class Initialized
INFO - 2023-12-13 08:55:55 --> Config Class Initialized
INFO - 2023-12-13 08:55:55 --> Loader Class Initialized
INFO - 2023-12-13 08:55:55 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:55 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:55 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:55 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:55 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:55 --> Controller Class Initialized
INFO - 2023-12-13 08:55:58 --> Config Class Initialized
INFO - 2023-12-13 08:55:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:55:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:55:58 --> Utf8 Class Initialized
INFO - 2023-12-13 08:55:58 --> URI Class Initialized
INFO - 2023-12-13 08:55:58 --> Router Class Initialized
INFO - 2023-12-13 08:55:58 --> Output Class Initialized
INFO - 2023-12-13 08:55:58 --> Security Class Initialized
DEBUG - 2023-12-13 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:55:58 --> Input Class Initialized
INFO - 2023-12-13 08:55:58 --> Language Class Initialized
INFO - 2023-12-13 08:55:58 --> Language Class Initialized
INFO - 2023-12-13 08:55:58 --> Config Class Initialized
INFO - 2023-12-13 08:55:58 --> Loader Class Initialized
INFO - 2023-12-13 08:55:58 --> Helper loaded: url_helper
INFO - 2023-12-13 08:55:58 --> Helper loaded: file_helper
INFO - 2023-12-13 08:55:58 --> Helper loaded: form_helper
INFO - 2023-12-13 08:55:58 --> Helper loaded: my_helper
INFO - 2023-12-13 08:55:58 --> Database Driver Class Initialized
INFO - 2023-12-13 08:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:55:58 --> Controller Class Initialized
INFO - 2023-12-13 08:55:58 --> Final output sent to browser
DEBUG - 2023-12-13 08:55:58 --> Total execution time: 0.1402
INFO - 2023-12-13 08:56:05 --> Config Class Initialized
INFO - 2023-12-13 08:56:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:05 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:05 --> URI Class Initialized
INFO - 2023-12-13 08:56:05 --> Router Class Initialized
INFO - 2023-12-13 08:56:05 --> Output Class Initialized
INFO - 2023-12-13 08:56:05 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:05 --> Input Class Initialized
INFO - 2023-12-13 08:56:05 --> Language Class Initialized
INFO - 2023-12-13 08:56:05 --> Language Class Initialized
INFO - 2023-12-13 08:56:05 --> Config Class Initialized
INFO - 2023-12-13 08:56:05 --> Loader Class Initialized
INFO - 2023-12-13 08:56:05 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:05 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:05 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:05 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:05 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:05 --> Controller Class Initialized
INFO - 2023-12-13 08:56:05 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:05 --> Total execution time: 0.1230
INFO - 2023-12-13 08:56:08 --> Config Class Initialized
INFO - 2023-12-13 08:56:08 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:08 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:08 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:08 --> URI Class Initialized
INFO - 2023-12-13 08:56:08 --> Router Class Initialized
INFO - 2023-12-13 08:56:08 --> Output Class Initialized
INFO - 2023-12-13 08:56:08 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:08 --> Input Class Initialized
INFO - 2023-12-13 08:56:08 --> Language Class Initialized
INFO - 2023-12-13 08:56:08 --> Language Class Initialized
INFO - 2023-12-13 08:56:08 --> Config Class Initialized
INFO - 2023-12-13 08:56:08 --> Loader Class Initialized
INFO - 2023-12-13 08:56:08 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:08 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:08 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:08 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:08 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:08 --> Controller Class Initialized
INFO - 2023-12-13 08:56:08 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:08 --> Total execution time: 0.1070
INFO - 2023-12-13 08:56:23 --> Config Class Initialized
INFO - 2023-12-13 08:56:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:23 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:23 --> URI Class Initialized
INFO - 2023-12-13 08:56:23 --> Router Class Initialized
INFO - 2023-12-13 08:56:23 --> Output Class Initialized
INFO - 2023-12-13 08:56:23 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:23 --> Input Class Initialized
INFO - 2023-12-13 08:56:23 --> Language Class Initialized
INFO - 2023-12-13 08:56:23 --> Language Class Initialized
INFO - 2023-12-13 08:56:23 --> Config Class Initialized
INFO - 2023-12-13 08:56:23 --> Loader Class Initialized
INFO - 2023-12-13 08:56:23 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:23 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:23 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:23 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:23 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:23 --> Controller Class Initialized
INFO - 2023-12-13 08:56:23 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:23 --> Total execution time: 0.1034
INFO - 2023-12-13 08:56:27 --> Config Class Initialized
INFO - 2023-12-13 08:56:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:27 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:27 --> URI Class Initialized
INFO - 2023-12-13 08:56:27 --> Router Class Initialized
INFO - 2023-12-13 08:56:27 --> Output Class Initialized
INFO - 2023-12-13 08:56:27 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:27 --> Input Class Initialized
INFO - 2023-12-13 08:56:27 --> Language Class Initialized
INFO - 2023-12-13 08:56:27 --> Language Class Initialized
INFO - 2023-12-13 08:56:27 --> Config Class Initialized
INFO - 2023-12-13 08:56:27 --> Loader Class Initialized
INFO - 2023-12-13 08:56:27 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:27 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:27 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:27 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:27 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:27 --> Controller Class Initialized
INFO - 2023-12-13 08:56:27 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:27 --> Total execution time: 0.0365
INFO - 2023-12-13 08:56:45 --> Config Class Initialized
INFO - 2023-12-13 08:56:45 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:45 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:45 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:45 --> URI Class Initialized
INFO - 2023-12-13 08:56:45 --> Router Class Initialized
INFO - 2023-12-13 08:56:45 --> Output Class Initialized
INFO - 2023-12-13 08:56:45 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:45 --> Input Class Initialized
INFO - 2023-12-13 08:56:45 --> Language Class Initialized
INFO - 2023-12-13 08:56:45 --> Language Class Initialized
INFO - 2023-12-13 08:56:45 --> Config Class Initialized
INFO - 2023-12-13 08:56:45 --> Loader Class Initialized
INFO - 2023-12-13 08:56:45 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:45 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:45 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:45 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:45 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:45 --> Controller Class Initialized
INFO - 2023-12-13 08:56:45 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:45 --> Total execution time: 0.1052
INFO - 2023-12-13 08:56:49 --> Config Class Initialized
INFO - 2023-12-13 08:56:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:49 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:49 --> URI Class Initialized
INFO - 2023-12-13 08:56:49 --> Router Class Initialized
INFO - 2023-12-13 08:56:49 --> Output Class Initialized
INFO - 2023-12-13 08:56:49 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:49 --> Input Class Initialized
INFO - 2023-12-13 08:56:49 --> Language Class Initialized
INFO - 2023-12-13 08:56:49 --> Language Class Initialized
INFO - 2023-12-13 08:56:49 --> Config Class Initialized
INFO - 2023-12-13 08:56:49 --> Loader Class Initialized
INFO - 2023-12-13 08:56:49 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:49 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:49 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:49 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:49 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:49 --> Controller Class Initialized
INFO - 2023-12-13 08:56:49 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:49 --> Total execution time: 0.0386
INFO - 2023-12-13 08:56:53 --> Config Class Initialized
INFO - 2023-12-13 08:56:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:53 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:53 --> URI Class Initialized
INFO - 2023-12-13 08:56:53 --> Router Class Initialized
INFO - 2023-12-13 08:56:53 --> Output Class Initialized
INFO - 2023-12-13 08:56:53 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:53 --> Input Class Initialized
INFO - 2023-12-13 08:56:53 --> Language Class Initialized
INFO - 2023-12-13 08:56:53 --> Language Class Initialized
INFO - 2023-12-13 08:56:53 --> Config Class Initialized
INFO - 2023-12-13 08:56:53 --> Loader Class Initialized
INFO - 2023-12-13 08:56:53 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:53 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:53 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:53 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:53 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:53 --> Controller Class Initialized
INFO - 2023-12-13 08:56:54 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:54 --> Total execution time: 0.1329
INFO - 2023-12-13 08:56:58 --> Config Class Initialized
INFO - 2023-12-13 08:56:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:56:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:56:58 --> Utf8 Class Initialized
INFO - 2023-12-13 08:56:58 --> URI Class Initialized
INFO - 2023-12-13 08:56:58 --> Router Class Initialized
INFO - 2023-12-13 08:56:58 --> Output Class Initialized
INFO - 2023-12-13 08:56:58 --> Security Class Initialized
DEBUG - 2023-12-13 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:56:58 --> Input Class Initialized
INFO - 2023-12-13 08:56:58 --> Language Class Initialized
INFO - 2023-12-13 08:56:58 --> Language Class Initialized
INFO - 2023-12-13 08:56:58 --> Config Class Initialized
INFO - 2023-12-13 08:56:58 --> Loader Class Initialized
INFO - 2023-12-13 08:56:58 --> Helper loaded: url_helper
INFO - 2023-12-13 08:56:58 --> Helper loaded: file_helper
INFO - 2023-12-13 08:56:58 --> Helper loaded: form_helper
INFO - 2023-12-13 08:56:58 --> Helper loaded: my_helper
INFO - 2023-12-13 08:56:58 --> Database Driver Class Initialized
INFO - 2023-12-13 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:56:58 --> Controller Class Initialized
INFO - 2023-12-13 08:56:58 --> Final output sent to browser
DEBUG - 2023-12-13 08:56:58 --> Total execution time: 0.0452
INFO - 2023-12-13 08:57:09 --> Config Class Initialized
INFO - 2023-12-13 08:57:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:09 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:09 --> URI Class Initialized
INFO - 2023-12-13 08:57:09 --> Router Class Initialized
INFO - 2023-12-13 08:57:09 --> Output Class Initialized
INFO - 2023-12-13 08:57:09 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:09 --> Input Class Initialized
INFO - 2023-12-13 08:57:09 --> Language Class Initialized
INFO - 2023-12-13 08:57:09 --> Language Class Initialized
INFO - 2023-12-13 08:57:09 --> Config Class Initialized
INFO - 2023-12-13 08:57:09 --> Loader Class Initialized
INFO - 2023-12-13 08:57:09 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:09 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:09 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:09 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:09 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:09 --> Controller Class Initialized
INFO - 2023-12-13 08:57:10 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:10 --> Total execution time: 0.4834
INFO - 2023-12-13 08:57:13 --> Config Class Initialized
INFO - 2023-12-13 08:57:13 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:13 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:13 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:13 --> URI Class Initialized
INFO - 2023-12-13 08:57:13 --> Router Class Initialized
INFO - 2023-12-13 08:57:14 --> Output Class Initialized
INFO - 2023-12-13 08:57:14 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:14 --> Input Class Initialized
INFO - 2023-12-13 08:57:14 --> Language Class Initialized
INFO - 2023-12-13 08:57:14 --> Language Class Initialized
INFO - 2023-12-13 08:57:14 --> Config Class Initialized
INFO - 2023-12-13 08:57:14 --> Loader Class Initialized
INFO - 2023-12-13 08:57:14 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:14 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:14 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:14 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:14 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:14 --> Controller Class Initialized
INFO - 2023-12-13 08:57:14 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:14 --> Total execution time: 0.0762
INFO - 2023-12-13 08:57:22 --> Config Class Initialized
INFO - 2023-12-13 08:57:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:22 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:22 --> URI Class Initialized
INFO - 2023-12-13 08:57:22 --> Router Class Initialized
INFO - 2023-12-13 08:57:22 --> Output Class Initialized
INFO - 2023-12-13 08:57:22 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:22 --> Input Class Initialized
INFO - 2023-12-13 08:57:22 --> Language Class Initialized
INFO - 2023-12-13 08:57:22 --> Language Class Initialized
INFO - 2023-12-13 08:57:22 --> Config Class Initialized
INFO - 2023-12-13 08:57:22 --> Loader Class Initialized
INFO - 2023-12-13 08:57:22 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:22 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:22 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:22 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:22 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:22 --> Controller Class Initialized
INFO - 2023-12-13 08:57:22 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:22 --> Total execution time: 0.1246
INFO - 2023-12-13 08:57:25 --> Config Class Initialized
INFO - 2023-12-13 08:57:25 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:25 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:25 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:25 --> URI Class Initialized
INFO - 2023-12-13 08:57:25 --> Router Class Initialized
INFO - 2023-12-13 08:57:25 --> Output Class Initialized
INFO - 2023-12-13 08:57:25 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:25 --> Input Class Initialized
INFO - 2023-12-13 08:57:25 --> Language Class Initialized
INFO - 2023-12-13 08:57:25 --> Language Class Initialized
INFO - 2023-12-13 08:57:25 --> Config Class Initialized
INFO - 2023-12-13 08:57:25 --> Loader Class Initialized
INFO - 2023-12-13 08:57:25 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:25 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:25 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:25 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:25 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:25 --> Controller Class Initialized
INFO - 2023-12-13 08:57:25 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:25 --> Total execution time: 0.1547
INFO - 2023-12-13 08:57:30 --> Config Class Initialized
INFO - 2023-12-13 08:57:30 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:30 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:30 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:30 --> URI Class Initialized
INFO - 2023-12-13 08:57:30 --> Router Class Initialized
INFO - 2023-12-13 08:57:30 --> Output Class Initialized
INFO - 2023-12-13 08:57:30 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:30 --> Input Class Initialized
INFO - 2023-12-13 08:57:30 --> Language Class Initialized
INFO - 2023-12-13 08:57:30 --> Language Class Initialized
INFO - 2023-12-13 08:57:30 --> Config Class Initialized
INFO - 2023-12-13 08:57:30 --> Loader Class Initialized
INFO - 2023-12-13 08:57:30 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:30 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:30 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:30 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:30 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:30 --> Controller Class Initialized
INFO - 2023-12-13 08:57:30 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:30 --> Total execution time: 0.0645
INFO - 2023-12-13 08:57:43 --> Config Class Initialized
INFO - 2023-12-13 08:57:43 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:43 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:43 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:43 --> URI Class Initialized
INFO - 2023-12-13 08:57:43 --> Router Class Initialized
INFO - 2023-12-13 08:57:43 --> Output Class Initialized
INFO - 2023-12-13 08:57:43 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:43 --> Input Class Initialized
INFO - 2023-12-13 08:57:43 --> Language Class Initialized
INFO - 2023-12-13 08:57:43 --> Language Class Initialized
INFO - 2023-12-13 08:57:43 --> Config Class Initialized
INFO - 2023-12-13 08:57:43 --> Loader Class Initialized
INFO - 2023-12-13 08:57:43 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:43 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:43 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:43 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:43 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:43 --> Controller Class Initialized
INFO - 2023-12-13 08:57:43 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:43 --> Total execution time: 0.1015
INFO - 2023-12-13 08:57:46 --> Config Class Initialized
INFO - 2023-12-13 08:57:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:46 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:46 --> URI Class Initialized
INFO - 2023-12-13 08:57:46 --> Router Class Initialized
INFO - 2023-12-13 08:57:46 --> Output Class Initialized
INFO - 2023-12-13 08:57:46 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:46 --> Input Class Initialized
INFO - 2023-12-13 08:57:46 --> Language Class Initialized
INFO - 2023-12-13 08:57:46 --> Language Class Initialized
INFO - 2023-12-13 08:57:46 --> Config Class Initialized
INFO - 2023-12-13 08:57:46 --> Loader Class Initialized
INFO - 2023-12-13 08:57:46 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:46 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:46 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:46 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:46 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:46 --> Controller Class Initialized
INFO - 2023-12-13 08:57:46 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:46 --> Total execution time: 0.0424
INFO - 2023-12-13 08:57:50 --> Config Class Initialized
INFO - 2023-12-13 08:57:50 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:50 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:50 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:50 --> URI Class Initialized
INFO - 2023-12-13 08:57:50 --> Router Class Initialized
INFO - 2023-12-13 08:57:50 --> Output Class Initialized
INFO - 2023-12-13 08:57:50 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:50 --> Input Class Initialized
INFO - 2023-12-13 08:57:50 --> Language Class Initialized
INFO - 2023-12-13 08:57:50 --> Language Class Initialized
INFO - 2023-12-13 08:57:50 --> Config Class Initialized
INFO - 2023-12-13 08:57:50 --> Loader Class Initialized
INFO - 2023-12-13 08:57:50 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:50 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:50 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:50 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:50 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:50 --> Controller Class Initialized
INFO - 2023-12-13 08:57:50 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:50 --> Total execution time: 0.0384
INFO - 2023-12-13 08:57:55 --> Config Class Initialized
INFO - 2023-12-13 08:57:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:57:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:57:55 --> Utf8 Class Initialized
INFO - 2023-12-13 08:57:55 --> URI Class Initialized
INFO - 2023-12-13 08:57:55 --> Router Class Initialized
INFO - 2023-12-13 08:57:55 --> Output Class Initialized
INFO - 2023-12-13 08:57:55 --> Security Class Initialized
DEBUG - 2023-12-13 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:57:55 --> Input Class Initialized
INFO - 2023-12-13 08:57:55 --> Language Class Initialized
INFO - 2023-12-13 08:57:55 --> Language Class Initialized
INFO - 2023-12-13 08:57:55 --> Config Class Initialized
INFO - 2023-12-13 08:57:55 --> Loader Class Initialized
INFO - 2023-12-13 08:57:55 --> Helper loaded: url_helper
INFO - 2023-12-13 08:57:55 --> Helper loaded: file_helper
INFO - 2023-12-13 08:57:55 --> Helper loaded: form_helper
INFO - 2023-12-13 08:57:55 --> Helper loaded: my_helper
INFO - 2023-12-13 08:57:55 --> Database Driver Class Initialized
INFO - 2023-12-13 08:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:57:55 --> Controller Class Initialized
INFO - 2023-12-13 08:57:55 --> Final output sent to browser
DEBUG - 2023-12-13 08:57:55 --> Total execution time: 0.0342
INFO - 2023-12-13 08:58:00 --> Config Class Initialized
INFO - 2023-12-13 08:58:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:58:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:58:00 --> Utf8 Class Initialized
INFO - 2023-12-13 08:58:00 --> URI Class Initialized
INFO - 2023-12-13 08:58:00 --> Router Class Initialized
INFO - 2023-12-13 08:58:00 --> Output Class Initialized
INFO - 2023-12-13 08:58:00 --> Security Class Initialized
DEBUG - 2023-12-13 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:58:00 --> Input Class Initialized
INFO - 2023-12-13 08:58:00 --> Language Class Initialized
INFO - 2023-12-13 08:58:00 --> Language Class Initialized
INFO - 2023-12-13 08:58:00 --> Config Class Initialized
INFO - 2023-12-13 08:58:00 --> Loader Class Initialized
INFO - 2023-12-13 08:58:00 --> Helper loaded: url_helper
INFO - 2023-12-13 08:58:00 --> Helper loaded: file_helper
INFO - 2023-12-13 08:58:00 --> Helper loaded: form_helper
INFO - 2023-12-13 08:58:00 --> Helper loaded: my_helper
INFO - 2023-12-13 08:58:00 --> Database Driver Class Initialized
INFO - 2023-12-13 08:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:58:00 --> Controller Class Initialized
INFO - 2023-12-13 08:58:00 --> Final output sent to browser
DEBUG - 2023-12-13 08:58:00 --> Total execution time: 0.3681
INFO - 2023-12-13 08:58:15 --> Config Class Initialized
INFO - 2023-12-13 08:58:15 --> Hooks Class Initialized
DEBUG - 2023-12-13 08:58:15 --> UTF-8 Support Enabled
INFO - 2023-12-13 08:58:15 --> Utf8 Class Initialized
INFO - 2023-12-13 08:58:15 --> URI Class Initialized
INFO - 2023-12-13 08:58:15 --> Router Class Initialized
INFO - 2023-12-13 08:58:15 --> Output Class Initialized
INFO - 2023-12-13 08:58:15 --> Security Class Initialized
DEBUG - 2023-12-13 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 08:58:15 --> Input Class Initialized
INFO - 2023-12-13 08:58:15 --> Language Class Initialized
INFO - 2023-12-13 08:58:15 --> Language Class Initialized
INFO - 2023-12-13 08:58:15 --> Config Class Initialized
INFO - 2023-12-13 08:58:15 --> Loader Class Initialized
INFO - 2023-12-13 08:58:15 --> Helper loaded: url_helper
INFO - 2023-12-13 08:58:15 --> Helper loaded: file_helper
INFO - 2023-12-13 08:58:15 --> Helper loaded: form_helper
INFO - 2023-12-13 08:58:15 --> Helper loaded: my_helper
INFO - 2023-12-13 08:58:15 --> Database Driver Class Initialized
INFO - 2023-12-13 08:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 08:58:15 --> Controller Class Initialized
DEBUG - 2023-12-13 08:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 08:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 08:58:15 --> Final output sent to browser
DEBUG - 2023-12-13 08:58:15 --> Total execution time: 0.1546
INFO - 2023-12-13 09:04:23 --> Config Class Initialized
INFO - 2023-12-13 09:04:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:04:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:04:23 --> Utf8 Class Initialized
INFO - 2023-12-13 09:04:23 --> URI Class Initialized
INFO - 2023-12-13 09:04:23 --> Router Class Initialized
INFO - 2023-12-13 09:04:23 --> Output Class Initialized
INFO - 2023-12-13 09:04:23 --> Security Class Initialized
DEBUG - 2023-12-13 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:04:23 --> Input Class Initialized
INFO - 2023-12-13 09:04:23 --> Language Class Initialized
INFO - 2023-12-13 09:04:23 --> Language Class Initialized
INFO - 2023-12-13 09:04:23 --> Config Class Initialized
INFO - 2023-12-13 09:04:23 --> Loader Class Initialized
INFO - 2023-12-13 09:04:23 --> Helper loaded: url_helper
INFO - 2023-12-13 09:04:23 --> Helper loaded: file_helper
INFO - 2023-12-13 09:04:23 --> Helper loaded: form_helper
INFO - 2023-12-13 09:04:23 --> Helper loaded: my_helper
INFO - 2023-12-13 09:04:23 --> Database Driver Class Initialized
INFO - 2023-12-13 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:04:23 --> Controller Class Initialized
DEBUG - 2023-12-13 09:04:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 09:04:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:04:23 --> Final output sent to browser
DEBUG - 2023-12-13 09:04:23 --> Total execution time: 0.5001
INFO - 2023-12-13 09:04:28 --> Config Class Initialized
INFO - 2023-12-13 09:04:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:04:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:04:28 --> Utf8 Class Initialized
INFO - 2023-12-13 09:04:28 --> URI Class Initialized
INFO - 2023-12-13 09:04:28 --> Router Class Initialized
INFO - 2023-12-13 09:04:28 --> Output Class Initialized
INFO - 2023-12-13 09:04:28 --> Security Class Initialized
DEBUG - 2023-12-13 09:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:04:28 --> Input Class Initialized
INFO - 2023-12-13 09:04:28 --> Language Class Initialized
INFO - 2023-12-13 09:04:28 --> Language Class Initialized
INFO - 2023-12-13 09:04:28 --> Config Class Initialized
INFO - 2023-12-13 09:04:28 --> Loader Class Initialized
INFO - 2023-12-13 09:04:28 --> Helper loaded: url_helper
INFO - 2023-12-13 09:04:28 --> Helper loaded: file_helper
INFO - 2023-12-13 09:04:28 --> Helper loaded: form_helper
INFO - 2023-12-13 09:04:28 --> Helper loaded: my_helper
INFO - 2023-12-13 09:04:28 --> Database Driver Class Initialized
INFO - 2023-12-13 09:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:04:28 --> Controller Class Initialized
DEBUG - 2023-12-13 09:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 09:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:04:28 --> Final output sent to browser
DEBUG - 2023-12-13 09:04:28 --> Total execution time: 0.3604
INFO - 2023-12-13 09:04:29 --> Config Class Initialized
INFO - 2023-12-13 09:04:29 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:04:29 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:04:29 --> Utf8 Class Initialized
INFO - 2023-12-13 09:04:29 --> URI Class Initialized
INFO - 2023-12-13 09:04:29 --> Router Class Initialized
INFO - 2023-12-13 09:04:29 --> Output Class Initialized
INFO - 2023-12-13 09:04:29 --> Security Class Initialized
DEBUG - 2023-12-13 09:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:04:29 --> Input Class Initialized
INFO - 2023-12-13 09:04:29 --> Language Class Initialized
INFO - 2023-12-13 09:04:29 --> Language Class Initialized
INFO - 2023-12-13 09:04:29 --> Config Class Initialized
INFO - 2023-12-13 09:04:29 --> Loader Class Initialized
INFO - 2023-12-13 09:04:29 --> Helper loaded: url_helper
INFO - 2023-12-13 09:04:29 --> Helper loaded: file_helper
INFO - 2023-12-13 09:04:29 --> Helper loaded: form_helper
INFO - 2023-12-13 09:04:29 --> Helper loaded: my_helper
INFO - 2023-12-13 09:04:29 --> Database Driver Class Initialized
INFO - 2023-12-13 09:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:04:29 --> Controller Class Initialized
INFO - 2023-12-13 09:04:34 --> Config Class Initialized
INFO - 2023-12-13 09:04:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:04:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:04:34 --> Utf8 Class Initialized
INFO - 2023-12-13 09:04:34 --> URI Class Initialized
INFO - 2023-12-13 09:04:34 --> Router Class Initialized
INFO - 2023-12-13 09:04:34 --> Output Class Initialized
INFO - 2023-12-13 09:04:34 --> Security Class Initialized
DEBUG - 2023-12-13 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:04:34 --> Input Class Initialized
INFO - 2023-12-13 09:04:34 --> Language Class Initialized
INFO - 2023-12-13 09:04:34 --> Language Class Initialized
INFO - 2023-12-13 09:04:34 --> Config Class Initialized
INFO - 2023-12-13 09:04:34 --> Loader Class Initialized
INFO - 2023-12-13 09:04:34 --> Helper loaded: url_helper
INFO - 2023-12-13 09:04:34 --> Helper loaded: file_helper
INFO - 2023-12-13 09:04:34 --> Helper loaded: form_helper
INFO - 2023-12-13 09:04:34 --> Helper loaded: my_helper
INFO - 2023-12-13 09:04:34 --> Database Driver Class Initialized
INFO - 2023-12-13 09:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:04:34 --> Controller Class Initialized
INFO - 2023-12-13 09:04:34 --> Final output sent to browser
DEBUG - 2023-12-13 09:04:34 --> Total execution time: 0.2862
INFO - 2023-12-13 09:04:42 --> Config Class Initialized
INFO - 2023-12-13 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:04:42 --> Utf8 Class Initialized
INFO - 2023-12-13 09:04:42 --> URI Class Initialized
INFO - 2023-12-13 09:04:42 --> Router Class Initialized
INFO - 2023-12-13 09:04:43 --> Output Class Initialized
INFO - 2023-12-13 09:04:43 --> Security Class Initialized
DEBUG - 2023-12-13 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:04:43 --> Input Class Initialized
INFO - 2023-12-13 09:04:43 --> Language Class Initialized
INFO - 2023-12-13 09:04:43 --> Language Class Initialized
INFO - 2023-12-13 09:04:43 --> Config Class Initialized
INFO - 2023-12-13 09:04:43 --> Loader Class Initialized
INFO - 2023-12-13 09:04:43 --> Helper loaded: url_helper
INFO - 2023-12-13 09:04:43 --> Helper loaded: file_helper
INFO - 2023-12-13 09:04:43 --> Helper loaded: form_helper
INFO - 2023-12-13 09:04:43 --> Helper loaded: my_helper
INFO - 2023-12-13 09:04:43 --> Database Driver Class Initialized
INFO - 2023-12-13 09:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:04:43 --> Controller Class Initialized
INFO - 2023-12-13 09:04:43 --> Final output sent to browser
DEBUG - 2023-12-13 09:04:43 --> Total execution time: 0.2146
INFO - 2023-12-13 09:05:00 --> Config Class Initialized
INFO - 2023-12-13 09:05:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:05:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:05:00 --> Utf8 Class Initialized
INFO - 2023-12-13 09:05:00 --> URI Class Initialized
INFO - 2023-12-13 09:05:00 --> Router Class Initialized
INFO - 2023-12-13 09:05:00 --> Output Class Initialized
INFO - 2023-12-13 09:05:00 --> Security Class Initialized
DEBUG - 2023-12-13 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:05:00 --> Input Class Initialized
INFO - 2023-12-13 09:05:00 --> Language Class Initialized
INFO - 2023-12-13 09:05:00 --> Language Class Initialized
INFO - 2023-12-13 09:05:00 --> Config Class Initialized
INFO - 2023-12-13 09:05:00 --> Loader Class Initialized
INFO - 2023-12-13 09:05:00 --> Helper loaded: url_helper
INFO - 2023-12-13 09:05:00 --> Helper loaded: file_helper
INFO - 2023-12-13 09:05:00 --> Helper loaded: form_helper
INFO - 2023-12-13 09:05:00 --> Helper loaded: my_helper
INFO - 2023-12-13 09:05:00 --> Database Driver Class Initialized
INFO - 2023-12-13 09:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:05:00 --> Controller Class Initialized
INFO - 2023-12-13 09:08:35 --> Config Class Initialized
INFO - 2023-12-13 09:08:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:08:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:08:35 --> Utf8 Class Initialized
INFO - 2023-12-13 09:08:35 --> URI Class Initialized
INFO - 2023-12-13 09:08:35 --> Router Class Initialized
INFO - 2023-12-13 09:08:35 --> Output Class Initialized
INFO - 2023-12-13 09:08:35 --> Security Class Initialized
DEBUG - 2023-12-13 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:08:35 --> Input Class Initialized
INFO - 2023-12-13 09:08:35 --> Language Class Initialized
INFO - 2023-12-13 09:08:35 --> Language Class Initialized
INFO - 2023-12-13 09:08:35 --> Config Class Initialized
INFO - 2023-12-13 09:08:35 --> Loader Class Initialized
INFO - 2023-12-13 09:08:35 --> Helper loaded: url_helper
INFO - 2023-12-13 09:08:35 --> Helper loaded: file_helper
INFO - 2023-12-13 09:08:35 --> Helper loaded: form_helper
INFO - 2023-12-13 09:08:35 --> Helper loaded: my_helper
INFO - 2023-12-13 09:08:35 --> Database Driver Class Initialized
INFO - 2023-12-13 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:08:35 --> Controller Class Initialized
DEBUG - 2023-12-13 09:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-12-13 09:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:08:35 --> Final output sent to browser
DEBUG - 2023-12-13 09:08:35 --> Total execution time: 0.4735
INFO - 2023-12-13 09:08:46 --> Config Class Initialized
INFO - 2023-12-13 09:08:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:08:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:08:46 --> Utf8 Class Initialized
INFO - 2023-12-13 09:08:46 --> URI Class Initialized
INFO - 2023-12-13 09:08:46 --> Router Class Initialized
INFO - 2023-12-13 09:08:46 --> Output Class Initialized
INFO - 2023-12-13 09:08:46 --> Security Class Initialized
DEBUG - 2023-12-13 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:08:46 --> Input Class Initialized
INFO - 2023-12-13 09:08:46 --> Language Class Initialized
INFO - 2023-12-13 09:08:46 --> Language Class Initialized
INFO - 2023-12-13 09:08:46 --> Config Class Initialized
INFO - 2023-12-13 09:08:46 --> Loader Class Initialized
INFO - 2023-12-13 09:08:46 --> Helper loaded: url_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: file_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: form_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: my_helper
INFO - 2023-12-13 09:08:46 --> Database Driver Class Initialized
INFO - 2023-12-13 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:08:46 --> Controller Class Initialized
INFO - 2023-12-13 09:08:46 --> Config Class Initialized
INFO - 2023-12-13 09:08:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:08:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:08:46 --> Utf8 Class Initialized
INFO - 2023-12-13 09:08:46 --> URI Class Initialized
INFO - 2023-12-13 09:08:46 --> Router Class Initialized
INFO - 2023-12-13 09:08:46 --> Output Class Initialized
INFO - 2023-12-13 09:08:46 --> Security Class Initialized
DEBUG - 2023-12-13 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:08:46 --> Input Class Initialized
INFO - 2023-12-13 09:08:46 --> Language Class Initialized
INFO - 2023-12-13 09:08:46 --> Language Class Initialized
INFO - 2023-12-13 09:08:46 --> Config Class Initialized
INFO - 2023-12-13 09:08:46 --> Loader Class Initialized
INFO - 2023-12-13 09:08:46 --> Helper loaded: url_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: file_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: form_helper
INFO - 2023-12-13 09:08:46 --> Helper loaded: my_helper
INFO - 2023-12-13 09:08:46 --> Database Driver Class Initialized
INFO - 2023-12-13 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:08:46 --> Controller Class Initialized
DEBUG - 2023-12-13 09:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 09:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:08:46 --> Final output sent to browser
DEBUG - 2023-12-13 09:08:46 --> Total execution time: 0.0675
INFO - 2023-12-13 09:08:55 --> Config Class Initialized
INFO - 2023-12-13 09:08:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:08:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:08:55 --> Utf8 Class Initialized
INFO - 2023-12-13 09:08:55 --> URI Class Initialized
INFO - 2023-12-13 09:08:55 --> Router Class Initialized
INFO - 2023-12-13 09:08:55 --> Output Class Initialized
INFO - 2023-12-13 09:08:55 --> Security Class Initialized
DEBUG - 2023-12-13 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:08:55 --> Input Class Initialized
INFO - 2023-12-13 09:08:55 --> Language Class Initialized
INFO - 2023-12-13 09:08:55 --> Language Class Initialized
INFO - 2023-12-13 09:08:55 --> Config Class Initialized
INFO - 2023-12-13 09:08:55 --> Loader Class Initialized
INFO - 2023-12-13 09:08:55 --> Helper loaded: url_helper
INFO - 2023-12-13 09:08:55 --> Helper loaded: file_helper
INFO - 2023-12-13 09:08:55 --> Helper loaded: form_helper
INFO - 2023-12-13 09:08:55 --> Helper loaded: my_helper
INFO - 2023-12-13 09:08:55 --> Database Driver Class Initialized
INFO - 2023-12-13 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:08:55 --> Controller Class Initialized
INFO - 2023-12-13 09:08:55 --> Final output sent to browser
DEBUG - 2023-12-13 09:08:55 --> Total execution time: 0.0418
INFO - 2023-12-13 09:10:59 --> Config Class Initialized
INFO - 2023-12-13 09:10:59 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:10:59 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:10:59 --> Utf8 Class Initialized
INFO - 2023-12-13 09:10:59 --> URI Class Initialized
INFO - 2023-12-13 09:10:59 --> Router Class Initialized
INFO - 2023-12-13 09:10:59 --> Output Class Initialized
INFO - 2023-12-13 09:10:59 --> Security Class Initialized
DEBUG - 2023-12-13 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:10:59 --> Input Class Initialized
INFO - 2023-12-13 09:10:59 --> Language Class Initialized
INFO - 2023-12-13 09:10:59 --> Language Class Initialized
INFO - 2023-12-13 09:10:59 --> Config Class Initialized
INFO - 2023-12-13 09:10:59 --> Loader Class Initialized
INFO - 2023-12-13 09:10:59 --> Helper loaded: url_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: file_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: form_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: my_helper
INFO - 2023-12-13 09:10:59 --> Database Driver Class Initialized
INFO - 2023-12-13 09:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:10:59 --> Controller Class Initialized
DEBUG - 2023-12-13 09:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 09:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:10:59 --> Final output sent to browser
DEBUG - 2023-12-13 09:10:59 --> Total execution time: 0.0447
INFO - 2023-12-13 09:10:59 --> Config Class Initialized
INFO - 2023-12-13 09:10:59 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:10:59 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:10:59 --> Utf8 Class Initialized
INFO - 2023-12-13 09:10:59 --> URI Class Initialized
INFO - 2023-12-13 09:10:59 --> Router Class Initialized
INFO - 2023-12-13 09:10:59 --> Output Class Initialized
INFO - 2023-12-13 09:10:59 --> Security Class Initialized
DEBUG - 2023-12-13 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:10:59 --> Input Class Initialized
INFO - 2023-12-13 09:10:59 --> Language Class Initialized
INFO - 2023-12-13 09:10:59 --> Language Class Initialized
INFO - 2023-12-13 09:10:59 --> Config Class Initialized
INFO - 2023-12-13 09:10:59 --> Loader Class Initialized
INFO - 2023-12-13 09:10:59 --> Helper loaded: url_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: file_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: form_helper
INFO - 2023-12-13 09:10:59 --> Helper loaded: my_helper
INFO - 2023-12-13 09:10:59 --> Database Driver Class Initialized
INFO - 2023-12-13 09:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:10:59 --> Controller Class Initialized
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:02 --> URI Class Initialized
INFO - 2023-12-13 09:11:02 --> Router Class Initialized
INFO - 2023-12-13 09:11:02 --> Output Class Initialized
INFO - 2023-12-13 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:02 --> Input Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Loader Class Initialized
INFO - 2023-12-13 09:11:02 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:02 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:02 --> Controller Class Initialized
INFO - 2023-12-13 09:11:02 --> Helper loaded: cookie_helper
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:02 --> URI Class Initialized
INFO - 2023-12-13 09:11:02 --> Router Class Initialized
INFO - 2023-12-13 09:11:02 --> Output Class Initialized
INFO - 2023-12-13 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:02 --> Input Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Loader Class Initialized
INFO - 2023-12-13 09:11:02 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:02 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:02 --> Controller Class Initialized
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:02 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:02 --> URI Class Initialized
INFO - 2023-12-13 09:11:02 --> Router Class Initialized
INFO - 2023-12-13 09:11:02 --> Output Class Initialized
INFO - 2023-12-13 09:11:02 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:02 --> Input Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Language Class Initialized
INFO - 2023-12-13 09:11:02 --> Config Class Initialized
INFO - 2023-12-13 09:11:02 --> Loader Class Initialized
INFO - 2023-12-13 09:11:02 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:02 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:02 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:02 --> Controller Class Initialized
DEBUG - 2023-12-13 09:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 09:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:11:02 --> Final output sent to browser
DEBUG - 2023-12-13 09:11:02 --> Total execution time: 0.0772
INFO - 2023-12-13 09:11:08 --> Config Class Initialized
INFO - 2023-12-13 09:11:08 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:08 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:08 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:08 --> URI Class Initialized
INFO - 2023-12-13 09:11:08 --> Router Class Initialized
INFO - 2023-12-13 09:11:08 --> Output Class Initialized
INFO - 2023-12-13 09:11:08 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:08 --> Input Class Initialized
INFO - 2023-12-13 09:11:08 --> Language Class Initialized
INFO - 2023-12-13 09:11:08 --> Language Class Initialized
INFO - 2023-12-13 09:11:08 --> Config Class Initialized
INFO - 2023-12-13 09:11:08 --> Loader Class Initialized
INFO - 2023-12-13 09:11:08 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:08 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:08 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:08 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:08 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:08 --> Controller Class Initialized
INFO - 2023-12-13 09:11:08 --> Final output sent to browser
DEBUG - 2023-12-13 09:11:08 --> Total execution time: 0.0720
INFO - 2023-12-13 09:11:24 --> Config Class Initialized
INFO - 2023-12-13 09:11:24 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:24 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:24 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:24 --> URI Class Initialized
INFO - 2023-12-13 09:11:24 --> Router Class Initialized
INFO - 2023-12-13 09:11:24 --> Output Class Initialized
INFO - 2023-12-13 09:11:24 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:24 --> Input Class Initialized
INFO - 2023-12-13 09:11:24 --> Language Class Initialized
INFO - 2023-12-13 09:11:24 --> Language Class Initialized
INFO - 2023-12-13 09:11:24 --> Config Class Initialized
INFO - 2023-12-13 09:11:24 --> Loader Class Initialized
INFO - 2023-12-13 09:11:24 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:24 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:24 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:24 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:24 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:24 --> Controller Class Initialized
INFO - 2023-12-13 09:11:24 --> Final output sent to browser
DEBUG - 2023-12-13 09:11:24 --> Total execution time: 0.0663
INFO - 2023-12-13 09:11:57 --> Config Class Initialized
INFO - 2023-12-13 09:11:57 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:57 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:57 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:57 --> URI Class Initialized
INFO - 2023-12-13 09:11:57 --> Router Class Initialized
INFO - 2023-12-13 09:11:57 --> Output Class Initialized
INFO - 2023-12-13 09:11:57 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:57 --> Input Class Initialized
INFO - 2023-12-13 09:11:57 --> Language Class Initialized
INFO - 2023-12-13 09:11:57 --> Language Class Initialized
INFO - 2023-12-13 09:11:57 --> Config Class Initialized
INFO - 2023-12-13 09:11:57 --> Loader Class Initialized
INFO - 2023-12-13 09:11:57 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:57 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:57 --> Controller Class Initialized
DEBUG - 2023-12-13 09:11:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 09:11:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:11:57 --> Final output sent to browser
DEBUG - 2023-12-13 09:11:57 --> Total execution time: 0.0357
INFO - 2023-12-13 09:11:57 --> Config Class Initialized
INFO - 2023-12-13 09:11:57 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:11:57 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:11:57 --> Utf8 Class Initialized
INFO - 2023-12-13 09:11:57 --> URI Class Initialized
INFO - 2023-12-13 09:11:57 --> Router Class Initialized
INFO - 2023-12-13 09:11:57 --> Output Class Initialized
INFO - 2023-12-13 09:11:57 --> Security Class Initialized
DEBUG - 2023-12-13 09:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:11:57 --> Input Class Initialized
INFO - 2023-12-13 09:11:57 --> Language Class Initialized
INFO - 2023-12-13 09:11:57 --> Language Class Initialized
INFO - 2023-12-13 09:11:57 --> Config Class Initialized
INFO - 2023-12-13 09:11:57 --> Loader Class Initialized
INFO - 2023-12-13 09:11:57 --> Helper loaded: url_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: file_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: form_helper
INFO - 2023-12-13 09:11:57 --> Helper loaded: my_helper
INFO - 2023-12-13 09:11:57 --> Database Driver Class Initialized
INFO - 2023-12-13 09:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:11:57 --> Controller Class Initialized
INFO - 2023-12-13 09:12:09 --> Config Class Initialized
INFO - 2023-12-13 09:12:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:09 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:09 --> URI Class Initialized
INFO - 2023-12-13 09:12:09 --> Router Class Initialized
INFO - 2023-12-13 09:12:09 --> Output Class Initialized
INFO - 2023-12-13 09:12:09 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:09 --> Input Class Initialized
INFO - 2023-12-13 09:12:09 --> Language Class Initialized
INFO - 2023-12-13 09:12:09 --> Language Class Initialized
INFO - 2023-12-13 09:12:09 --> Config Class Initialized
INFO - 2023-12-13 09:12:09 --> Loader Class Initialized
INFO - 2023-12-13 09:12:09 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:09 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:09 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:09 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:09 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:09 --> Controller Class Initialized
INFO - 2023-12-13 09:12:09 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:09 --> Total execution time: 0.0755
INFO - 2023-12-13 09:12:15 --> Config Class Initialized
INFO - 2023-12-13 09:12:15 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:15 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:15 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:15 --> URI Class Initialized
INFO - 2023-12-13 09:12:15 --> Router Class Initialized
INFO - 2023-12-13 09:12:15 --> Output Class Initialized
INFO - 2023-12-13 09:12:15 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:15 --> Input Class Initialized
INFO - 2023-12-13 09:12:15 --> Language Class Initialized
INFO - 2023-12-13 09:12:15 --> Language Class Initialized
INFO - 2023-12-13 09:12:15 --> Config Class Initialized
INFO - 2023-12-13 09:12:15 --> Loader Class Initialized
INFO - 2023-12-13 09:12:15 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:15 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:15 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:15 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:15 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:15 --> Controller Class Initialized
INFO - 2023-12-13 09:12:15 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:15 --> Total execution time: 0.1057
INFO - 2023-12-13 09:12:20 --> Config Class Initialized
INFO - 2023-12-13 09:12:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:20 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:20 --> URI Class Initialized
INFO - 2023-12-13 09:12:20 --> Router Class Initialized
INFO - 2023-12-13 09:12:20 --> Output Class Initialized
INFO - 2023-12-13 09:12:20 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:20 --> Input Class Initialized
INFO - 2023-12-13 09:12:20 --> Language Class Initialized
INFO - 2023-12-13 09:12:20 --> Language Class Initialized
INFO - 2023-12-13 09:12:20 --> Config Class Initialized
INFO - 2023-12-13 09:12:20 --> Loader Class Initialized
INFO - 2023-12-13 09:12:20 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:20 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:20 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:20 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:20 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:20 --> Controller Class Initialized
INFO - 2023-12-13 09:12:20 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:20 --> Total execution time: 0.0352
INFO - 2023-12-13 09:12:23 --> Config Class Initialized
INFO - 2023-12-13 09:12:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:23 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:23 --> URI Class Initialized
INFO - 2023-12-13 09:12:23 --> Router Class Initialized
INFO - 2023-12-13 09:12:23 --> Output Class Initialized
INFO - 2023-12-13 09:12:23 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:23 --> Input Class Initialized
INFO - 2023-12-13 09:12:23 --> Language Class Initialized
INFO - 2023-12-13 09:12:23 --> Language Class Initialized
INFO - 2023-12-13 09:12:23 --> Config Class Initialized
INFO - 2023-12-13 09:12:23 --> Loader Class Initialized
INFO - 2023-12-13 09:12:23 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:23 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:23 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:23 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:23 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:23 --> Controller Class Initialized
INFO - 2023-12-13 09:12:23 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:23 --> Total execution time: 0.1507
INFO - 2023-12-13 09:12:26 --> Config Class Initialized
INFO - 2023-12-13 09:12:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:26 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:26 --> URI Class Initialized
INFO - 2023-12-13 09:12:26 --> Router Class Initialized
INFO - 2023-12-13 09:12:26 --> Output Class Initialized
INFO - 2023-12-13 09:12:26 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:26 --> Input Class Initialized
INFO - 2023-12-13 09:12:26 --> Language Class Initialized
INFO - 2023-12-13 09:12:26 --> Language Class Initialized
INFO - 2023-12-13 09:12:26 --> Config Class Initialized
INFO - 2023-12-13 09:12:26 --> Loader Class Initialized
INFO - 2023-12-13 09:12:26 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:26 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:26 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:26 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:26 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:26 --> Controller Class Initialized
INFO - 2023-12-13 09:12:26 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:26 --> Total execution time: 0.0377
INFO - 2023-12-13 09:12:31 --> Config Class Initialized
INFO - 2023-12-13 09:12:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:31 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:31 --> URI Class Initialized
INFO - 2023-12-13 09:12:31 --> Router Class Initialized
INFO - 2023-12-13 09:12:31 --> Output Class Initialized
INFO - 2023-12-13 09:12:31 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:31 --> Input Class Initialized
INFO - 2023-12-13 09:12:31 --> Language Class Initialized
INFO - 2023-12-13 09:12:31 --> Language Class Initialized
INFO - 2023-12-13 09:12:31 --> Config Class Initialized
INFO - 2023-12-13 09:12:31 --> Loader Class Initialized
INFO - 2023-12-13 09:12:31 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:31 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:31 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:31 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:31 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:31 --> Controller Class Initialized
INFO - 2023-12-13 09:12:31 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:31 --> Total execution time: 0.1083
INFO - 2023-12-13 09:12:34 --> Config Class Initialized
INFO - 2023-12-13 09:12:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:34 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:34 --> URI Class Initialized
INFO - 2023-12-13 09:12:34 --> Router Class Initialized
INFO - 2023-12-13 09:12:34 --> Output Class Initialized
INFO - 2023-12-13 09:12:34 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:34 --> Input Class Initialized
INFO - 2023-12-13 09:12:34 --> Language Class Initialized
INFO - 2023-12-13 09:12:34 --> Language Class Initialized
INFO - 2023-12-13 09:12:34 --> Config Class Initialized
INFO - 2023-12-13 09:12:34 --> Loader Class Initialized
INFO - 2023-12-13 09:12:34 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:34 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:34 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:34 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:34 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:34 --> Controller Class Initialized
INFO - 2023-12-13 09:12:34 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:34 --> Total execution time: 0.0707
INFO - 2023-12-13 09:12:38 --> Config Class Initialized
INFO - 2023-12-13 09:12:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:38 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:38 --> URI Class Initialized
INFO - 2023-12-13 09:12:38 --> Router Class Initialized
INFO - 2023-12-13 09:12:38 --> Output Class Initialized
INFO - 2023-12-13 09:12:38 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:38 --> Input Class Initialized
INFO - 2023-12-13 09:12:38 --> Language Class Initialized
INFO - 2023-12-13 09:12:38 --> Language Class Initialized
INFO - 2023-12-13 09:12:38 --> Config Class Initialized
INFO - 2023-12-13 09:12:38 --> Loader Class Initialized
INFO - 2023-12-13 09:12:38 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:38 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:38 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:38 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:38 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:38 --> Controller Class Initialized
INFO - 2023-12-13 09:12:38 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:38 --> Total execution time: 0.3452
INFO - 2023-12-13 09:12:41 --> Config Class Initialized
INFO - 2023-12-13 09:12:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:41 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:41 --> URI Class Initialized
INFO - 2023-12-13 09:12:41 --> Router Class Initialized
INFO - 2023-12-13 09:12:41 --> Output Class Initialized
INFO - 2023-12-13 09:12:41 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:41 --> Input Class Initialized
INFO - 2023-12-13 09:12:41 --> Language Class Initialized
INFO - 2023-12-13 09:12:41 --> Language Class Initialized
INFO - 2023-12-13 09:12:41 --> Config Class Initialized
INFO - 2023-12-13 09:12:41 --> Loader Class Initialized
INFO - 2023-12-13 09:12:41 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:41 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:41 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:41 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:41 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:41 --> Controller Class Initialized
INFO - 2023-12-13 09:12:41 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:41 --> Total execution time: 0.0341
INFO - 2023-12-13 09:12:44 --> Config Class Initialized
INFO - 2023-12-13 09:12:44 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:44 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:44 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:44 --> URI Class Initialized
INFO - 2023-12-13 09:12:44 --> Router Class Initialized
INFO - 2023-12-13 09:12:44 --> Output Class Initialized
INFO - 2023-12-13 09:12:44 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:44 --> Input Class Initialized
INFO - 2023-12-13 09:12:44 --> Language Class Initialized
INFO - 2023-12-13 09:12:44 --> Language Class Initialized
INFO - 2023-12-13 09:12:44 --> Config Class Initialized
INFO - 2023-12-13 09:12:44 --> Loader Class Initialized
INFO - 2023-12-13 09:12:44 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:44 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:44 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:44 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:44 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:44 --> Controller Class Initialized
INFO - 2023-12-13 09:12:45 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:45 --> Total execution time: 0.1635
INFO - 2023-12-13 09:12:48 --> Config Class Initialized
INFO - 2023-12-13 09:12:48 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:48 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:48 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:48 --> URI Class Initialized
INFO - 2023-12-13 09:12:48 --> Router Class Initialized
INFO - 2023-12-13 09:12:48 --> Output Class Initialized
INFO - 2023-12-13 09:12:48 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:48 --> Input Class Initialized
INFO - 2023-12-13 09:12:48 --> Language Class Initialized
INFO - 2023-12-13 09:12:48 --> Language Class Initialized
INFO - 2023-12-13 09:12:48 --> Config Class Initialized
INFO - 2023-12-13 09:12:48 --> Loader Class Initialized
INFO - 2023-12-13 09:12:48 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:48 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:48 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:48 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:48 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:48 --> Controller Class Initialized
INFO - 2023-12-13 09:12:48 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:48 --> Total execution time: 0.1076
INFO - 2023-12-13 09:12:54 --> Config Class Initialized
INFO - 2023-12-13 09:12:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:12:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:12:54 --> Utf8 Class Initialized
INFO - 2023-12-13 09:12:54 --> URI Class Initialized
INFO - 2023-12-13 09:12:54 --> Router Class Initialized
INFO - 2023-12-13 09:12:54 --> Output Class Initialized
INFO - 2023-12-13 09:12:54 --> Security Class Initialized
DEBUG - 2023-12-13 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:12:54 --> Input Class Initialized
INFO - 2023-12-13 09:12:54 --> Language Class Initialized
INFO - 2023-12-13 09:12:55 --> Language Class Initialized
INFO - 2023-12-13 09:12:55 --> Config Class Initialized
INFO - 2023-12-13 09:12:55 --> Loader Class Initialized
INFO - 2023-12-13 09:12:55 --> Helper loaded: url_helper
INFO - 2023-12-13 09:12:55 --> Helper loaded: file_helper
INFO - 2023-12-13 09:12:55 --> Helper loaded: form_helper
INFO - 2023-12-13 09:12:55 --> Helper loaded: my_helper
INFO - 2023-12-13 09:12:55 --> Database Driver Class Initialized
INFO - 2023-12-13 09:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:12:55 --> Controller Class Initialized
INFO - 2023-12-13 09:12:55 --> Final output sent to browser
DEBUG - 2023-12-13 09:12:55 --> Total execution time: 0.5796
INFO - 2023-12-13 09:13:41 --> Config Class Initialized
INFO - 2023-12-13 09:13:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:13:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:13:41 --> Utf8 Class Initialized
INFO - 2023-12-13 09:13:41 --> URI Class Initialized
INFO - 2023-12-13 09:13:41 --> Router Class Initialized
INFO - 2023-12-13 09:13:41 --> Output Class Initialized
INFO - 2023-12-13 09:13:41 --> Security Class Initialized
DEBUG - 2023-12-13 09:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:13:41 --> Input Class Initialized
INFO - 2023-12-13 09:13:41 --> Language Class Initialized
INFO - 2023-12-13 09:13:41 --> Language Class Initialized
INFO - 2023-12-13 09:13:41 --> Config Class Initialized
INFO - 2023-12-13 09:13:41 --> Loader Class Initialized
INFO - 2023-12-13 09:13:41 --> Helper loaded: url_helper
INFO - 2023-12-13 09:13:41 --> Helper loaded: file_helper
INFO - 2023-12-13 09:13:41 --> Helper loaded: form_helper
INFO - 2023-12-13 09:13:41 --> Helper loaded: my_helper
INFO - 2023-12-13 09:13:41 --> Database Driver Class Initialized
INFO - 2023-12-13 09:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:13:41 --> Controller Class Initialized
DEBUG - 2023-12-13 09:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-13 09:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:13:41 --> Final output sent to browser
DEBUG - 2023-12-13 09:13:41 --> Total execution time: 0.1576
INFO - 2023-12-13 09:13:58 --> Config Class Initialized
INFO - 2023-12-13 09:13:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:13:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:13:58 --> Utf8 Class Initialized
INFO - 2023-12-13 09:13:58 --> URI Class Initialized
INFO - 2023-12-13 09:13:58 --> Router Class Initialized
INFO - 2023-12-13 09:13:58 --> Output Class Initialized
INFO - 2023-12-13 09:13:58 --> Security Class Initialized
DEBUG - 2023-12-13 09:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:13:58 --> Input Class Initialized
INFO - 2023-12-13 09:13:58 --> Language Class Initialized
INFO - 2023-12-13 09:13:58 --> Language Class Initialized
INFO - 2023-12-13 09:13:58 --> Config Class Initialized
INFO - 2023-12-13 09:13:58 --> Loader Class Initialized
INFO - 2023-12-13 09:13:58 --> Helper loaded: url_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: file_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: form_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: my_helper
INFO - 2023-12-13 09:13:58 --> Database Driver Class Initialized
INFO - 2023-12-13 09:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:13:58 --> Controller Class Initialized
INFO - 2023-12-13 09:13:58 --> Config Class Initialized
INFO - 2023-12-13 09:13:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:13:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:13:58 --> Utf8 Class Initialized
INFO - 2023-12-13 09:13:58 --> URI Class Initialized
INFO - 2023-12-13 09:13:58 --> Router Class Initialized
INFO - 2023-12-13 09:13:58 --> Output Class Initialized
INFO - 2023-12-13 09:13:58 --> Security Class Initialized
DEBUG - 2023-12-13 09:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:13:58 --> Input Class Initialized
INFO - 2023-12-13 09:13:58 --> Language Class Initialized
INFO - 2023-12-13 09:13:58 --> Language Class Initialized
INFO - 2023-12-13 09:13:58 --> Config Class Initialized
INFO - 2023-12-13 09:13:58 --> Loader Class Initialized
INFO - 2023-12-13 09:13:58 --> Helper loaded: url_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: file_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: form_helper
INFO - 2023-12-13 09:13:58 --> Helper loaded: my_helper
INFO - 2023-12-13 09:13:58 --> Database Driver Class Initialized
INFO - 2023-12-13 09:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:13:58 --> Controller Class Initialized
DEBUG - 2023-12-13 09:13:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 09:13:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:13:58 --> Final output sent to browser
DEBUG - 2023-12-13 09:13:58 --> Total execution time: 0.0742
INFO - 2023-12-13 09:13:59 --> Config Class Initialized
INFO - 2023-12-13 09:13:59 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:13:59 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:13:59 --> Utf8 Class Initialized
INFO - 2023-12-13 09:13:59 --> URI Class Initialized
INFO - 2023-12-13 09:13:59 --> Router Class Initialized
INFO - 2023-12-13 09:13:59 --> Output Class Initialized
INFO - 2023-12-13 09:13:59 --> Security Class Initialized
DEBUG - 2023-12-13 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:13:59 --> Input Class Initialized
INFO - 2023-12-13 09:13:59 --> Language Class Initialized
INFO - 2023-12-13 09:13:59 --> Language Class Initialized
INFO - 2023-12-13 09:13:59 --> Config Class Initialized
INFO - 2023-12-13 09:13:59 --> Loader Class Initialized
INFO - 2023-12-13 09:13:59 --> Helper loaded: url_helper
INFO - 2023-12-13 09:13:59 --> Helper loaded: file_helper
INFO - 2023-12-13 09:13:59 --> Helper loaded: form_helper
INFO - 2023-12-13 09:13:59 --> Helper loaded: my_helper
INFO - 2023-12-13 09:13:59 --> Database Driver Class Initialized
INFO - 2023-12-13 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:13:59 --> Controller Class Initialized
INFO - 2023-12-13 09:14:23 --> Config Class Initialized
INFO - 2023-12-13 09:14:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:14:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:14:23 --> Utf8 Class Initialized
INFO - 2023-12-13 09:14:23 --> URI Class Initialized
INFO - 2023-12-13 09:14:23 --> Router Class Initialized
INFO - 2023-12-13 09:14:23 --> Output Class Initialized
INFO - 2023-12-13 09:14:23 --> Security Class Initialized
DEBUG - 2023-12-13 09:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:14:23 --> Input Class Initialized
INFO - 2023-12-13 09:14:23 --> Language Class Initialized
INFO - 2023-12-13 09:14:23 --> Language Class Initialized
INFO - 2023-12-13 09:14:23 --> Config Class Initialized
INFO - 2023-12-13 09:14:23 --> Loader Class Initialized
INFO - 2023-12-13 09:14:23 --> Helper loaded: url_helper
INFO - 2023-12-13 09:14:23 --> Helper loaded: file_helper
INFO - 2023-12-13 09:14:23 --> Helper loaded: form_helper
INFO - 2023-12-13 09:14:23 --> Helper loaded: my_helper
INFO - 2023-12-13 09:14:23 --> Database Driver Class Initialized
INFO - 2023-12-13 09:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:14:23 --> Controller Class Initialized
INFO - 2023-12-13 09:14:23 --> Final output sent to browser
DEBUG - 2023-12-13 09:14:23 --> Total execution time: 0.0629
INFO - 2023-12-13 09:37:59 --> Config Class Initialized
INFO - 2023-12-13 09:37:59 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:37:59 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:37:59 --> Utf8 Class Initialized
INFO - 2023-12-13 09:37:59 --> URI Class Initialized
INFO - 2023-12-13 09:37:59 --> Router Class Initialized
INFO - 2023-12-13 09:37:59 --> Output Class Initialized
INFO - 2023-12-13 09:37:59 --> Security Class Initialized
DEBUG - 2023-12-13 09:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:37:59 --> Input Class Initialized
INFO - 2023-12-13 09:37:59 --> Language Class Initialized
INFO - 2023-12-13 09:37:59 --> Language Class Initialized
INFO - 2023-12-13 09:37:59 --> Config Class Initialized
INFO - 2023-12-13 09:37:59 --> Loader Class Initialized
INFO - 2023-12-13 09:38:00 --> Helper loaded: url_helper
INFO - 2023-12-13 09:38:00 --> Helper loaded: file_helper
INFO - 2023-12-13 09:38:00 --> Helper loaded: form_helper
INFO - 2023-12-13 09:38:00 --> Helper loaded: my_helper
INFO - 2023-12-13 09:38:00 --> Database Driver Class Initialized
INFO - 2023-12-13 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:38:00 --> Controller Class Initialized
DEBUG - 2023-12-13 09:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-12-13 09:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:38:00 --> Final output sent to browser
DEBUG - 2023-12-13 09:38:00 --> Total execution time: 0.6464
INFO - 2023-12-13 09:40:06 --> Config Class Initialized
INFO - 2023-12-13 09:40:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:40:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:40:06 --> Utf8 Class Initialized
INFO - 2023-12-13 09:40:06 --> URI Class Initialized
INFO - 2023-12-13 09:40:06 --> Router Class Initialized
INFO - 2023-12-13 09:40:06 --> Output Class Initialized
INFO - 2023-12-13 09:40:06 --> Security Class Initialized
DEBUG - 2023-12-13 09:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:40:06 --> Input Class Initialized
INFO - 2023-12-13 09:40:06 --> Language Class Initialized
INFO - 2023-12-13 09:40:06 --> Language Class Initialized
INFO - 2023-12-13 09:40:06 --> Config Class Initialized
INFO - 2023-12-13 09:40:06 --> Loader Class Initialized
INFO - 2023-12-13 09:40:06 --> Helper loaded: url_helper
INFO - 2023-12-13 09:40:06 --> Helper loaded: file_helper
INFO - 2023-12-13 09:40:06 --> Helper loaded: form_helper
INFO - 2023-12-13 09:40:06 --> Helper loaded: my_helper
INFO - 2023-12-13 09:40:06 --> Database Driver Class Initialized
INFO - 2023-12-13 09:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:40:06 --> Controller Class Initialized
INFO - 2023-12-13 09:40:06 --> Final output sent to browser
DEBUG - 2023-12-13 09:40:06 --> Total execution time: 0.0499
INFO - 2023-12-13 09:41:09 --> Config Class Initialized
INFO - 2023-12-13 09:41:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:41:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:41:09 --> Utf8 Class Initialized
INFO - 2023-12-13 09:41:09 --> URI Class Initialized
INFO - 2023-12-13 09:41:09 --> Router Class Initialized
INFO - 2023-12-13 09:41:09 --> Output Class Initialized
INFO - 2023-12-13 09:41:09 --> Security Class Initialized
DEBUG - 2023-12-13 09:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:41:09 --> Input Class Initialized
INFO - 2023-12-13 09:41:09 --> Language Class Initialized
INFO - 2023-12-13 09:41:09 --> Language Class Initialized
INFO - 2023-12-13 09:41:09 --> Config Class Initialized
INFO - 2023-12-13 09:41:09 --> Loader Class Initialized
INFO - 2023-12-13 09:41:09 --> Helper loaded: url_helper
INFO - 2023-12-13 09:41:09 --> Helper loaded: file_helper
INFO - 2023-12-13 09:41:09 --> Helper loaded: form_helper
INFO - 2023-12-13 09:41:09 --> Helper loaded: my_helper
INFO - 2023-12-13 09:41:09 --> Database Driver Class Initialized
INFO - 2023-12-13 09:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:41:09 --> Controller Class Initialized
INFO - 2023-12-13 09:41:09 --> Final output sent to browser
DEBUG - 2023-12-13 09:41:09 --> Total execution time: 0.0466
INFO - 2023-12-13 09:42:02 --> Config Class Initialized
INFO - 2023-12-13 09:42:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 09:42:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 09:42:02 --> Utf8 Class Initialized
INFO - 2023-12-13 09:42:02 --> URI Class Initialized
INFO - 2023-12-13 09:42:02 --> Router Class Initialized
INFO - 2023-12-13 09:42:02 --> Output Class Initialized
INFO - 2023-12-13 09:42:02 --> Security Class Initialized
DEBUG - 2023-12-13 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 09:42:02 --> Input Class Initialized
INFO - 2023-12-13 09:42:02 --> Language Class Initialized
INFO - 2023-12-13 09:42:02 --> Language Class Initialized
INFO - 2023-12-13 09:42:02 --> Config Class Initialized
INFO - 2023-12-13 09:42:02 --> Loader Class Initialized
INFO - 2023-12-13 09:42:02 --> Helper loaded: url_helper
INFO - 2023-12-13 09:42:02 --> Helper loaded: file_helper
INFO - 2023-12-13 09:42:02 --> Helper loaded: form_helper
INFO - 2023-12-13 09:42:02 --> Helper loaded: my_helper
INFO - 2023-12-13 09:42:02 --> Database Driver Class Initialized
INFO - 2023-12-13 09:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 09:42:02 --> Controller Class Initialized
DEBUG - 2023-12-13 09:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-12-13 09:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 09:42:02 --> Final output sent to browser
DEBUG - 2023-12-13 09:42:02 --> Total execution time: 0.0430
INFO - 2023-12-13 10:16:10 --> Config Class Initialized
INFO - 2023-12-13 10:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:10 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:10 --> URI Class Initialized
DEBUG - 2023-12-13 10:16:10 --> No URI present. Default controller set.
INFO - 2023-12-13 10:16:10 --> Router Class Initialized
INFO - 2023-12-13 10:16:10 --> Output Class Initialized
INFO - 2023-12-13 10:16:10 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:10 --> Input Class Initialized
INFO - 2023-12-13 10:16:10 --> Language Class Initialized
INFO - 2023-12-13 10:16:10 --> Language Class Initialized
INFO - 2023-12-13 10:16:10 --> Config Class Initialized
INFO - 2023-12-13 10:16:10 --> Loader Class Initialized
INFO - 2023-12-13 10:16:10 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:10 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:10 --> Controller Class Initialized
INFO - 2023-12-13 10:16:10 --> Config Class Initialized
INFO - 2023-12-13 10:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:10 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:10 --> URI Class Initialized
INFO - 2023-12-13 10:16:10 --> Router Class Initialized
INFO - 2023-12-13 10:16:10 --> Output Class Initialized
INFO - 2023-12-13 10:16:10 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:10 --> Input Class Initialized
INFO - 2023-12-13 10:16:10 --> Language Class Initialized
INFO - 2023-12-13 10:16:10 --> Language Class Initialized
INFO - 2023-12-13 10:16:10 --> Config Class Initialized
INFO - 2023-12-13 10:16:10 --> Loader Class Initialized
INFO - 2023-12-13 10:16:10 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:10 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:10 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:10 --> Controller Class Initialized
DEBUG - 2023-12-13 10:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 10:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:16:10 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:10 --> Total execution time: 0.0377
INFO - 2023-12-13 10:16:12 --> Config Class Initialized
INFO - 2023-12-13 10:16:12 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:12 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:12 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:12 --> URI Class Initialized
INFO - 2023-12-13 10:16:12 --> Router Class Initialized
INFO - 2023-12-13 10:16:12 --> Output Class Initialized
INFO - 2023-12-13 10:16:12 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:12 --> Input Class Initialized
INFO - 2023-12-13 10:16:12 --> Language Class Initialized
INFO - 2023-12-13 10:16:12 --> Language Class Initialized
INFO - 2023-12-13 10:16:12 --> Config Class Initialized
INFO - 2023-12-13 10:16:12 --> Loader Class Initialized
INFO - 2023-12-13 10:16:12 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:12 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:12 --> Controller Class Initialized
INFO - 2023-12-13 10:16:12 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:16:12 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:12 --> Total execution time: 0.0405
INFO - 2023-12-13 10:16:12 --> Config Class Initialized
INFO - 2023-12-13 10:16:12 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:12 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:12 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:12 --> URI Class Initialized
INFO - 2023-12-13 10:16:12 --> Router Class Initialized
INFO - 2023-12-13 10:16:12 --> Output Class Initialized
INFO - 2023-12-13 10:16:12 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:12 --> Input Class Initialized
INFO - 2023-12-13 10:16:12 --> Language Class Initialized
INFO - 2023-12-13 10:16:12 --> Language Class Initialized
INFO - 2023-12-13 10:16:12 --> Config Class Initialized
INFO - 2023-12-13 10:16:12 --> Loader Class Initialized
INFO - 2023-12-13 10:16:12 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:12 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:12 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:12 --> Controller Class Initialized
DEBUG - 2023-12-13 10:16:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 10:16:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:16:12 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:12 --> Total execution time: 0.0414
INFO - 2023-12-13 10:16:14 --> Config Class Initialized
INFO - 2023-12-13 10:16:14 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:14 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:14 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:14 --> URI Class Initialized
INFO - 2023-12-13 10:16:14 --> Router Class Initialized
INFO - 2023-12-13 10:16:14 --> Output Class Initialized
INFO - 2023-12-13 10:16:14 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:14 --> Input Class Initialized
INFO - 2023-12-13 10:16:14 --> Language Class Initialized
INFO - 2023-12-13 10:16:14 --> Language Class Initialized
INFO - 2023-12-13 10:16:14 --> Config Class Initialized
INFO - 2023-12-13 10:16:14 --> Loader Class Initialized
INFO - 2023-12-13 10:16:14 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:14 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:14 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:14 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:14 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:15 --> Controller Class Initialized
DEBUG - 2023-12-13 10:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 10:16:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:16:15 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:15 --> Total execution time: 0.1402
INFO - 2023-12-13 10:16:16 --> Config Class Initialized
INFO - 2023-12-13 10:16:16 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:16 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:16 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:16 --> URI Class Initialized
INFO - 2023-12-13 10:16:16 --> Router Class Initialized
INFO - 2023-12-13 10:16:16 --> Output Class Initialized
INFO - 2023-12-13 10:16:16 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:16 --> Input Class Initialized
INFO - 2023-12-13 10:16:16 --> Language Class Initialized
INFO - 2023-12-13 10:16:16 --> Language Class Initialized
INFO - 2023-12-13 10:16:16 --> Config Class Initialized
INFO - 2023-12-13 10:16:16 --> Loader Class Initialized
INFO - 2023-12-13 10:16:16 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:16 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:16 --> Controller Class Initialized
DEBUG - 2023-12-13 10:16:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 10:16:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:16:16 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:16 --> Total execution time: 0.0388
INFO - 2023-12-13 10:16:16 --> Config Class Initialized
INFO - 2023-12-13 10:16:16 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:16 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:16 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:16 --> URI Class Initialized
INFO - 2023-12-13 10:16:16 --> Router Class Initialized
INFO - 2023-12-13 10:16:16 --> Output Class Initialized
INFO - 2023-12-13 10:16:16 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:16 --> Input Class Initialized
INFO - 2023-12-13 10:16:16 --> Language Class Initialized
INFO - 2023-12-13 10:16:16 --> Language Class Initialized
INFO - 2023-12-13 10:16:16 --> Config Class Initialized
INFO - 2023-12-13 10:16:16 --> Loader Class Initialized
INFO - 2023-12-13 10:16:16 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:16 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:16 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:16 --> Controller Class Initialized
INFO - 2023-12-13 10:16:21 --> Config Class Initialized
INFO - 2023-12-13 10:16:21 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:16:21 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:16:21 --> Utf8 Class Initialized
INFO - 2023-12-13 10:16:21 --> URI Class Initialized
INFO - 2023-12-13 10:16:21 --> Router Class Initialized
INFO - 2023-12-13 10:16:21 --> Output Class Initialized
INFO - 2023-12-13 10:16:21 --> Security Class Initialized
DEBUG - 2023-12-13 10:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:16:21 --> Input Class Initialized
INFO - 2023-12-13 10:16:21 --> Language Class Initialized
INFO - 2023-12-13 10:16:21 --> Language Class Initialized
INFO - 2023-12-13 10:16:21 --> Config Class Initialized
INFO - 2023-12-13 10:16:21 --> Loader Class Initialized
INFO - 2023-12-13 10:16:21 --> Helper loaded: url_helper
INFO - 2023-12-13 10:16:21 --> Helper loaded: file_helper
INFO - 2023-12-13 10:16:21 --> Helper loaded: form_helper
INFO - 2023-12-13 10:16:21 --> Helper loaded: my_helper
INFO - 2023-12-13 10:16:21 --> Database Driver Class Initialized
INFO - 2023-12-13 10:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:16:21 --> Controller Class Initialized
DEBUG - 2023-12-13 10:16:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-13 10:16:21 --> Final output sent to browser
DEBUG - 2023-12-13 10:16:21 --> Total execution time: 0.1246
INFO - 2023-12-13 10:21:38 --> Config Class Initialized
INFO - 2023-12-13 10:21:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:38 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:38 --> URI Class Initialized
INFO - 2023-12-13 10:21:38 --> Router Class Initialized
INFO - 2023-12-13 10:21:38 --> Output Class Initialized
INFO - 2023-12-13 10:21:38 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:38 --> Input Class Initialized
INFO - 2023-12-13 10:21:38 --> Language Class Initialized
INFO - 2023-12-13 10:21:38 --> Language Class Initialized
INFO - 2023-12-13 10:21:38 --> Config Class Initialized
INFO - 2023-12-13 10:21:38 --> Loader Class Initialized
INFO - 2023-12-13 10:21:38 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:38 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:38 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:38 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:38 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:38 --> Controller Class Initialized
INFO - 2023-12-13 10:21:38 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:38 --> Total execution time: 0.0993
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:49 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:49 --> URI Class Initialized
INFO - 2023-12-13 10:21:49 --> Router Class Initialized
INFO - 2023-12-13 10:21:49 --> Output Class Initialized
INFO - 2023-12-13 10:21:49 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:49 --> Input Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Loader Class Initialized
INFO - 2023-12-13 10:21:49 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:49 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:49 --> Controller Class Initialized
INFO - 2023-12-13 10:21:49 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:49 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:49 --> URI Class Initialized
INFO - 2023-12-13 10:21:49 --> Router Class Initialized
INFO - 2023-12-13 10:21:49 --> Output Class Initialized
INFO - 2023-12-13 10:21:49 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:49 --> Input Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Loader Class Initialized
INFO - 2023-12-13 10:21:49 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:49 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:49 --> Controller Class Initialized
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:49 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:49 --> URI Class Initialized
INFO - 2023-12-13 10:21:49 --> Router Class Initialized
INFO - 2023-12-13 10:21:49 --> Output Class Initialized
INFO - 2023-12-13 10:21:49 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:49 --> Input Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Language Class Initialized
INFO - 2023-12-13 10:21:49 --> Config Class Initialized
INFO - 2023-12-13 10:21:49 --> Loader Class Initialized
INFO - 2023-12-13 10:21:49 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:49 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:49 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:49 --> Controller Class Initialized
DEBUG - 2023-12-13 10:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 10:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:21:49 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:49 --> Total execution time: 0.0330
INFO - 2023-12-13 10:21:50 --> Config Class Initialized
INFO - 2023-12-13 10:21:50 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:50 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:50 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:50 --> URI Class Initialized
INFO - 2023-12-13 10:21:50 --> Router Class Initialized
INFO - 2023-12-13 10:21:50 --> Output Class Initialized
INFO - 2023-12-13 10:21:50 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:50 --> Input Class Initialized
INFO - 2023-12-13 10:21:50 --> Language Class Initialized
INFO - 2023-12-13 10:21:50 --> Language Class Initialized
INFO - 2023-12-13 10:21:50 --> Config Class Initialized
INFO - 2023-12-13 10:21:50 --> Loader Class Initialized
INFO - 2023-12-13 10:21:50 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:50 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:50 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:50 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:50 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:50 --> Controller Class Initialized
DEBUG - 2023-12-13 10:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 10:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:21:50 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:50 --> Total execution time: 0.0547
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:53 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:53 --> URI Class Initialized
INFO - 2023-12-13 10:21:53 --> Router Class Initialized
INFO - 2023-12-13 10:21:53 --> Output Class Initialized
INFO - 2023-12-13 10:21:53 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:53 --> Input Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Loader Class Initialized
INFO - 2023-12-13 10:21:53 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:53 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:53 --> Controller Class Initialized
INFO - 2023-12-13 10:21:53 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:21:53 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:53 --> Total execution time: 0.0356
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:53 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:53 --> URI Class Initialized
INFO - 2023-12-13 10:21:53 --> Router Class Initialized
INFO - 2023-12-13 10:21:53 --> Output Class Initialized
INFO - 2023-12-13 10:21:53 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:53 --> Input Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Loader Class Initialized
INFO - 2023-12-13 10:21:53 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:53 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:53 --> Controller Class Initialized
DEBUG - 2023-12-13 10:21:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 10:21:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:21:53 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:53 --> Total execution time: 0.0349
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:53 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:53 --> URI Class Initialized
INFO - 2023-12-13 10:21:53 --> Router Class Initialized
INFO - 2023-12-13 10:21:53 --> Output Class Initialized
INFO - 2023-12-13 10:21:53 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:53 --> Input Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Language Class Initialized
INFO - 2023-12-13 10:21:53 --> Config Class Initialized
INFO - 2023-12-13 10:21:53 --> Loader Class Initialized
INFO - 2023-12-13 10:21:53 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:53 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:54 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:54 --> Controller Class Initialized
DEBUG - 2023-12-13 10:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 10:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:21:54 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:54 --> Total execution time: 0.1108
INFO - 2023-12-13 10:21:54 --> Config Class Initialized
INFO - 2023-12-13 10:21:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:54 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:54 --> URI Class Initialized
INFO - 2023-12-13 10:21:54 --> Router Class Initialized
INFO - 2023-12-13 10:21:54 --> Output Class Initialized
INFO - 2023-12-13 10:21:54 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:54 --> Input Class Initialized
INFO - 2023-12-13 10:21:54 --> Language Class Initialized
INFO - 2023-12-13 10:21:54 --> Language Class Initialized
INFO - 2023-12-13 10:21:54 --> Config Class Initialized
INFO - 2023-12-13 10:21:54 --> Loader Class Initialized
INFO - 2023-12-13 10:21:54 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:54 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:54 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:54 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:54 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:54 --> Controller Class Initialized
INFO - 2023-12-13 10:21:55 --> Config Class Initialized
INFO - 2023-12-13 10:21:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:55 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:55 --> URI Class Initialized
INFO - 2023-12-13 10:21:55 --> Router Class Initialized
INFO - 2023-12-13 10:21:55 --> Output Class Initialized
INFO - 2023-12-13 10:21:55 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:55 --> Input Class Initialized
INFO - 2023-12-13 10:21:55 --> Language Class Initialized
INFO - 2023-12-13 10:21:55 --> Language Class Initialized
INFO - 2023-12-13 10:21:55 --> Config Class Initialized
INFO - 2023-12-13 10:21:55 --> Loader Class Initialized
INFO - 2023-12-13 10:21:56 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:56 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:56 --> Controller Class Initialized
INFO - 2023-12-13 10:21:56 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:56 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:56 --> URI Class Initialized
INFO - 2023-12-13 10:21:56 --> Router Class Initialized
INFO - 2023-12-13 10:21:56 --> Output Class Initialized
INFO - 2023-12-13 10:21:56 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:56 --> Input Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Loader Class Initialized
INFO - 2023-12-13 10:21:56 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:56 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:56 --> Controller Class Initialized
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:56 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:56 --> URI Class Initialized
INFO - 2023-12-13 10:21:56 --> Router Class Initialized
INFO - 2023-12-13 10:21:56 --> Output Class Initialized
INFO - 2023-12-13 10:21:56 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:56 --> Input Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Loader Class Initialized
INFO - 2023-12-13 10:21:56 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:56 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:56 --> Controller Class Initialized
DEBUG - 2023-12-13 10:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 10:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:21:56 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:56 --> Total execution time: 0.1012
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:21:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:21:56 --> Utf8 Class Initialized
INFO - 2023-12-13 10:21:56 --> URI Class Initialized
INFO - 2023-12-13 10:21:56 --> Router Class Initialized
INFO - 2023-12-13 10:21:56 --> Output Class Initialized
INFO - 2023-12-13 10:21:56 --> Security Class Initialized
DEBUG - 2023-12-13 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:21:56 --> Input Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Language Class Initialized
INFO - 2023-12-13 10:21:56 --> Config Class Initialized
INFO - 2023-12-13 10:21:56 --> Loader Class Initialized
INFO - 2023-12-13 10:21:56 --> Helper loaded: url_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: file_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: form_helper
INFO - 2023-12-13 10:21:56 --> Helper loaded: my_helper
INFO - 2023-12-13 10:21:56 --> Database Driver Class Initialized
INFO - 2023-12-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:21:56 --> Controller Class Initialized
INFO - 2023-12-13 10:21:56 --> Final output sent to browser
DEBUG - 2023-12-13 10:21:56 --> Total execution time: 0.1205
INFO - 2023-12-13 10:22:00 --> Config Class Initialized
INFO - 2023-12-13 10:22:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:00 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:00 --> URI Class Initialized
INFO - 2023-12-13 10:22:00 --> Router Class Initialized
INFO - 2023-12-13 10:22:00 --> Output Class Initialized
INFO - 2023-12-13 10:22:00 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:00 --> Input Class Initialized
INFO - 2023-12-13 10:22:00 --> Language Class Initialized
INFO - 2023-12-13 10:22:00 --> Language Class Initialized
INFO - 2023-12-13 10:22:00 --> Config Class Initialized
INFO - 2023-12-13 10:22:00 --> Loader Class Initialized
INFO - 2023-12-13 10:22:00 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:00 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:00 --> Controller Class Initialized
INFO - 2023-12-13 10:22:00 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:22:00 --> Final output sent to browser
DEBUG - 2023-12-13 10:22:00 --> Total execution time: 0.1134
INFO - 2023-12-13 10:22:00 --> Config Class Initialized
INFO - 2023-12-13 10:22:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:00 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:00 --> URI Class Initialized
INFO - 2023-12-13 10:22:00 --> Router Class Initialized
INFO - 2023-12-13 10:22:00 --> Output Class Initialized
INFO - 2023-12-13 10:22:00 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:00 --> Input Class Initialized
INFO - 2023-12-13 10:22:00 --> Language Class Initialized
INFO - 2023-12-13 10:22:00 --> Language Class Initialized
INFO - 2023-12-13 10:22:00 --> Config Class Initialized
INFO - 2023-12-13 10:22:00 --> Loader Class Initialized
INFO - 2023-12-13 10:22:00 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:00 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:00 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:00 --> Controller Class Initialized
DEBUG - 2023-12-13 10:22:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 10:22:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:22:00 --> Final output sent to browser
DEBUG - 2023-12-13 10:22:00 --> Total execution time: 0.1022
INFO - 2023-12-13 10:22:02 --> Config Class Initialized
INFO - 2023-12-13 10:22:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:02 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:02 --> URI Class Initialized
INFO - 2023-12-13 10:22:02 --> Router Class Initialized
INFO - 2023-12-13 10:22:02 --> Output Class Initialized
INFO - 2023-12-13 10:22:02 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:02 --> Input Class Initialized
INFO - 2023-12-13 10:22:02 --> Language Class Initialized
INFO - 2023-12-13 10:22:02 --> Language Class Initialized
INFO - 2023-12-13 10:22:02 --> Config Class Initialized
INFO - 2023-12-13 10:22:02 --> Loader Class Initialized
INFO - 2023-12-13 10:22:02 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:02 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:02 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:02 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:02 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:02 --> Controller Class Initialized
DEBUG - 2023-12-13 10:22:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 10:22:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:22:02 --> Final output sent to browser
DEBUG - 2023-12-13 10:22:02 --> Total execution time: 0.1485
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:05 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:05 --> URI Class Initialized
INFO - 2023-12-13 10:22:05 --> Router Class Initialized
INFO - 2023-12-13 10:22:05 --> Output Class Initialized
INFO - 2023-12-13 10:22:05 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:05 --> Input Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Loader Class Initialized
INFO - 2023-12-13 10:22:05 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:05 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:05 --> Controller Class Initialized
INFO - 2023-12-13 10:22:05 --> Helper loaded: cookie_helper
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:05 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:05 --> URI Class Initialized
INFO - 2023-12-13 10:22:05 --> Router Class Initialized
INFO - 2023-12-13 10:22:05 --> Output Class Initialized
INFO - 2023-12-13 10:22:05 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:05 --> Input Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Loader Class Initialized
INFO - 2023-12-13 10:22:05 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:05 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:05 --> Controller Class Initialized
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:22:05 --> Utf8 Class Initialized
INFO - 2023-12-13 10:22:05 --> URI Class Initialized
INFO - 2023-12-13 10:22:05 --> Router Class Initialized
INFO - 2023-12-13 10:22:05 --> Output Class Initialized
INFO - 2023-12-13 10:22:05 --> Security Class Initialized
DEBUG - 2023-12-13 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:22:05 --> Input Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Language Class Initialized
INFO - 2023-12-13 10:22:05 --> Config Class Initialized
INFO - 2023-12-13 10:22:05 --> Loader Class Initialized
INFO - 2023-12-13 10:22:05 --> Helper loaded: url_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: file_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: form_helper
INFO - 2023-12-13 10:22:05 --> Helper loaded: my_helper
INFO - 2023-12-13 10:22:05 --> Database Driver Class Initialized
INFO - 2023-12-13 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:22:05 --> Controller Class Initialized
DEBUG - 2023-12-13 10:22:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 10:22:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:22:05 --> Final output sent to browser
DEBUG - 2023-12-13 10:22:05 --> Total execution time: 0.1434
INFO - 2023-12-13 10:27:18 --> Config Class Initialized
INFO - 2023-12-13 10:27:18 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:18 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:18 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:18 --> URI Class Initialized
INFO - 2023-12-13 10:27:18 --> Router Class Initialized
INFO - 2023-12-13 10:27:18 --> Output Class Initialized
INFO - 2023-12-13 10:27:18 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:18 --> Input Class Initialized
INFO - 2023-12-13 10:27:18 --> Language Class Initialized
INFO - 2023-12-13 10:27:18 --> Language Class Initialized
INFO - 2023-12-13 10:27:18 --> Config Class Initialized
INFO - 2023-12-13 10:27:18 --> Loader Class Initialized
INFO - 2023-12-13 10:27:18 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:18 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:18 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:18 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:18 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:18 --> Controller Class Initialized
DEBUG - 2023-12-13 10:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2023-12-13 10:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:27:18 --> Final output sent to browser
DEBUG - 2023-12-13 10:27:18 --> Total execution time: 0.1520
INFO - 2023-12-13 10:27:22 --> Config Class Initialized
INFO - 2023-12-13 10:27:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:22 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:22 --> URI Class Initialized
INFO - 2023-12-13 10:27:22 --> Router Class Initialized
INFO - 2023-12-13 10:27:22 --> Output Class Initialized
INFO - 2023-12-13 10:27:22 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:22 --> Input Class Initialized
INFO - 2023-12-13 10:27:22 --> Language Class Initialized
INFO - 2023-12-13 10:27:22 --> Language Class Initialized
INFO - 2023-12-13 10:27:22 --> Config Class Initialized
INFO - 2023-12-13 10:27:22 --> Loader Class Initialized
INFO - 2023-12-13 10:27:22 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:22 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:22 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:22 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:22 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:22 --> Controller Class Initialized
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:22 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 136
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 137
ERROR - 2023-12-13 10:27:23 --> Severity: Warning --> A non-numeric value encountered /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/controllers/Cetak_leger.php 138
DEBUG - 2023-12-13 10:27:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/cetak.php
INFO - 2023-12-13 10:27:23 --> Final output sent to browser
DEBUG - 2023-12-13 10:27:23 --> Total execution time: 1.5733
INFO - 2023-12-13 10:27:36 --> Config Class Initialized
INFO - 2023-12-13 10:27:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:36 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:36 --> URI Class Initialized
INFO - 2023-12-13 10:27:36 --> Router Class Initialized
INFO - 2023-12-13 10:27:36 --> Output Class Initialized
INFO - 2023-12-13 10:27:36 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:36 --> Input Class Initialized
INFO - 2023-12-13 10:27:36 --> Language Class Initialized
INFO - 2023-12-13 10:27:36 --> Language Class Initialized
INFO - 2023-12-13 10:27:36 --> Config Class Initialized
INFO - 2023-12-13 10:27:36 --> Loader Class Initialized
INFO - 2023-12-13 10:27:36 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:36 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:36 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:36 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:36 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:36 --> Controller Class Initialized
DEBUG - 2023-12-13 10:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 10:27:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:27:36 --> Final output sent to browser
DEBUG - 2023-12-13 10:27:36 --> Total execution time: 0.0650
INFO - 2023-12-13 10:27:45 --> Config Class Initialized
INFO - 2023-12-13 10:27:45 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:45 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:45 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:45 --> URI Class Initialized
INFO - 2023-12-13 10:27:45 --> Router Class Initialized
INFO - 2023-12-13 10:27:45 --> Output Class Initialized
INFO - 2023-12-13 10:27:45 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:45 --> Input Class Initialized
INFO - 2023-12-13 10:27:45 --> Language Class Initialized
INFO - 2023-12-13 10:27:45 --> Language Class Initialized
INFO - 2023-12-13 10:27:45 --> Config Class Initialized
INFO - 2023-12-13 10:27:45 --> Loader Class Initialized
INFO - 2023-12-13 10:27:45 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:45 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:45 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:45 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:45 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:45 --> Controller Class Initialized
DEBUG - 2023-12-13 10:27:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:27:49 --> Config Class Initialized
INFO - 2023-12-13 10:27:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:49 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:49 --> URI Class Initialized
INFO - 2023-12-13 10:27:49 --> Router Class Initialized
INFO - 2023-12-13 10:27:49 --> Output Class Initialized
INFO - 2023-12-13 10:27:49 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:49 --> Input Class Initialized
INFO - 2023-12-13 10:27:49 --> Language Class Initialized
INFO - 2023-12-13 10:27:49 --> Language Class Initialized
INFO - 2023-12-13 10:27:49 --> Config Class Initialized
INFO - 2023-12-13 10:27:49 --> Loader Class Initialized
INFO - 2023-12-13 10:27:49 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:49 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:49 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:49 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:49 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:51 --> Config Class Initialized
INFO - 2023-12-13 10:27:51 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:51 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:51 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:51 --> URI Class Initialized
INFO - 2023-12-13 10:27:51 --> Router Class Initialized
INFO - 2023-12-13 10:27:51 --> Output Class Initialized
INFO - 2023-12-13 10:27:51 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:51 --> Input Class Initialized
INFO - 2023-12-13 10:27:51 --> Language Class Initialized
INFO - 2023-12-13 10:27:51 --> Language Class Initialized
INFO - 2023-12-13 10:27:51 --> Config Class Initialized
INFO - 2023-12-13 10:27:51 --> Loader Class Initialized
INFO - 2023-12-13 10:27:51 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:51 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:51 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:51 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:51 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:52 --> Final output sent to browser
DEBUG - 2023-12-13 10:27:52 --> Total execution time: 6.4793
INFO - 2023-12-13 10:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:52 --> Controller Class Initialized
DEBUG - 2023-12-13 10:27:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:27:53 --> Config Class Initialized
INFO - 2023-12-13 10:27:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:53 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:53 --> URI Class Initialized
INFO - 2023-12-13 10:27:53 --> Router Class Initialized
INFO - 2023-12-13 10:27:53 --> Output Class Initialized
INFO - 2023-12-13 10:27:53 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:53 --> Input Class Initialized
INFO - 2023-12-13 10:27:53 --> Language Class Initialized
INFO - 2023-12-13 10:27:53 --> Language Class Initialized
INFO - 2023-12-13 10:27:53 --> Config Class Initialized
INFO - 2023-12-13 10:27:53 --> Loader Class Initialized
INFO - 2023-12-13 10:27:53 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:53 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:53 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:53 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:53 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:58 --> Config Class Initialized
INFO - 2023-12-13 10:27:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:58 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:58 --> URI Class Initialized
INFO - 2023-12-13 10:27:58 --> Router Class Initialized
INFO - 2023-12-13 10:27:58 --> Config Class Initialized
INFO - 2023-12-13 10:27:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:27:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:27:58 --> Utf8 Class Initialized
INFO - 2023-12-13 10:27:58 --> URI Class Initialized
INFO - 2023-12-13 10:27:58 --> Router Class Initialized
INFO - 2023-12-13 10:27:58 --> Output Class Initialized
INFO - 2023-12-13 10:27:58 --> Output Class Initialized
INFO - 2023-12-13 10:27:58 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:58 --> Input Class Initialized
INFO - 2023-12-13 10:27:58 --> Language Class Initialized
INFO - 2023-12-13 10:27:58 --> Security Class Initialized
DEBUG - 2023-12-13 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:27:58 --> Input Class Initialized
INFO - 2023-12-13 10:27:58 --> Language Class Initialized
INFO - 2023-12-13 10:27:58 --> Language Class Initialized
INFO - 2023-12-13 10:27:58 --> Config Class Initialized
INFO - 2023-12-13 10:27:58 --> Loader Class Initialized
INFO - 2023-12-13 10:27:58 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:58 --> Language Class Initialized
INFO - 2023-12-13 10:27:58 --> Config Class Initialized
INFO - 2023-12-13 10:27:58 --> Loader Class Initialized
INFO - 2023-12-13 10:27:58 --> Helper loaded: url_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: file_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: form_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:58 --> Helper loaded: my_helper
INFO - 2023-12-13 10:27:58 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:58 --> Database Driver Class Initialized
INFO - 2023-12-13 10:27:58 --> Final output sent to browser
DEBUG - 2023-12-13 10:27:58 --> Total execution time: 8.7987
INFO - 2023-12-13 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:27:58 --> Controller Class Initialized
DEBUG - 2023-12-13 10:27:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:28:00 --> Config Class Initialized
INFO - 2023-12-13 10:28:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:00 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:00 --> URI Class Initialized
INFO - 2023-12-13 10:28:00 --> Router Class Initialized
INFO - 2023-12-13 10:28:00 --> Output Class Initialized
INFO - 2023-12-13 10:28:00 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:00 --> Input Class Initialized
INFO - 2023-12-13 10:28:00 --> Language Class Initialized
INFO - 2023-12-13 10:28:00 --> Language Class Initialized
INFO - 2023-12-13 10:28:00 --> Config Class Initialized
INFO - 2023-12-13 10:28:00 --> Loader Class Initialized
INFO - 2023-12-13 10:28:00 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:00 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:00 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:00 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:00 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:02 --> Config Class Initialized
INFO - 2023-12-13 10:28:02 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:02 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:02 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:02 --> URI Class Initialized
INFO - 2023-12-13 10:28:02 --> Router Class Initialized
INFO - 2023-12-13 10:28:02 --> Output Class Initialized
INFO - 2023-12-13 10:28:02 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:02 --> Input Class Initialized
INFO - 2023-12-13 10:28:02 --> Language Class Initialized
INFO - 2023-12-13 10:28:02 --> Language Class Initialized
INFO - 2023-12-13 10:28:02 --> Config Class Initialized
INFO - 2023-12-13 10:28:02 --> Loader Class Initialized
INFO - 2023-12-13 10:28:02 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:02 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:02 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:02 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:02 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:05 --> Config Class Initialized
INFO - 2023-12-13 10:28:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:05 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:05 --> URI Class Initialized
INFO - 2023-12-13 10:28:05 --> Router Class Initialized
INFO - 2023-12-13 10:28:05 --> Output Class Initialized
INFO - 2023-12-13 10:28:05 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:05 --> Input Class Initialized
INFO - 2023-12-13 10:28:05 --> Language Class Initialized
INFO - 2023-12-13 10:28:05 --> Language Class Initialized
INFO - 2023-12-13 10:28:05 --> Config Class Initialized
INFO - 2023-12-13 10:28:05 --> Loader Class Initialized
INFO - 2023-12-13 10:28:05 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:05 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:05 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:05 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:05 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:07 --> Config Class Initialized
INFO - 2023-12-13 10:28:07 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:07 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:07 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:07 --> URI Class Initialized
INFO - 2023-12-13 10:28:07 --> Router Class Initialized
INFO - 2023-12-13 10:28:07 --> Output Class Initialized
INFO - 2023-12-13 10:28:07 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:07 --> Input Class Initialized
INFO - 2023-12-13 10:28:07 --> Language Class Initialized
INFO - 2023-12-13 10:28:07 --> Language Class Initialized
INFO - 2023-12-13 10:28:07 --> Config Class Initialized
INFO - 2023-12-13 10:28:07 --> Loader Class Initialized
INFO - 2023-12-13 10:28:07 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:07 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:07 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:07 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:07 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:11 --> Final output sent to browser
DEBUG - 2023-12-13 10:28:11 --> Total execution time: 19.4177
INFO - 2023-12-13 10:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:28:11 --> Controller Class Initialized
DEBUG - 2023-12-13 10:28:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:28:12 --> Config Class Initialized
INFO - 2023-12-13 10:28:12 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:12 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:12 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:12 --> URI Class Initialized
INFO - 2023-12-13 10:28:12 --> Router Class Initialized
INFO - 2023-12-13 10:28:12 --> Output Class Initialized
INFO - 2023-12-13 10:28:12 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:12 --> Input Class Initialized
INFO - 2023-12-13 10:28:12 --> Language Class Initialized
INFO - 2023-12-13 10:28:12 --> Language Class Initialized
INFO - 2023-12-13 10:28:12 --> Config Class Initialized
INFO - 2023-12-13 10:28:12 --> Loader Class Initialized
INFO - 2023-12-13 10:28:12 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:12 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:12 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:12 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:12 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:15 --> Config Class Initialized
INFO - 2023-12-13 10:28:15 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:15 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:15 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:15 --> URI Class Initialized
INFO - 2023-12-13 10:28:15 --> Router Class Initialized
INFO - 2023-12-13 10:28:15 --> Output Class Initialized
INFO - 2023-12-13 10:28:15 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:15 --> Input Class Initialized
INFO - 2023-12-13 10:28:15 --> Language Class Initialized
INFO - 2023-12-13 10:28:15 --> Language Class Initialized
INFO - 2023-12-13 10:28:15 --> Config Class Initialized
INFO - 2023-12-13 10:28:15 --> Loader Class Initialized
INFO - 2023-12-13 10:28:15 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:15 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:15 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:15 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:15 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:17 --> Config Class Initialized
INFO - 2023-12-13 10:28:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:17 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:17 --> URI Class Initialized
INFO - 2023-12-13 10:28:17 --> Router Class Initialized
INFO - 2023-12-13 10:28:17 --> Output Class Initialized
INFO - 2023-12-13 10:28:17 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:17 --> Input Class Initialized
INFO - 2023-12-13 10:28:17 --> Language Class Initialized
INFO - 2023-12-13 10:28:17 --> Language Class Initialized
INFO - 2023-12-13 10:28:17 --> Config Class Initialized
INFO - 2023-12-13 10:28:17 --> Loader Class Initialized
INFO - 2023-12-13 10:28:17 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:17 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:17 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:17 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:17 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:17 --> Final output sent to browser
DEBUG - 2023-12-13 10:28:17 --> Total execution time: 24.3448
INFO - 2023-12-13 10:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:28:17 --> Controller Class Initialized
DEBUG - 2023-12-13 10:28:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:28:20 --> Config Class Initialized
INFO - 2023-12-13 10:28:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:20 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:20 --> URI Class Initialized
INFO - 2023-12-13 10:28:20 --> Router Class Initialized
INFO - 2023-12-13 10:28:20 --> Output Class Initialized
INFO - 2023-12-13 10:28:20 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:20 --> Input Class Initialized
INFO - 2023-12-13 10:28:20 --> Language Class Initialized
INFO - 2023-12-13 10:28:20 --> Language Class Initialized
INFO - 2023-12-13 10:28:20 --> Config Class Initialized
INFO - 2023-12-13 10:28:20 --> Loader Class Initialized
INFO - 2023-12-13 10:28:20 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:20 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:20 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:20 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:20 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:22 --> Config Class Initialized
INFO - 2023-12-13 10:28:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:22 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:22 --> URI Class Initialized
INFO - 2023-12-13 10:28:22 --> Router Class Initialized
INFO - 2023-12-13 10:28:22 --> Output Class Initialized
INFO - 2023-12-13 10:28:22 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:22 --> Input Class Initialized
INFO - 2023-12-13 10:28:22 --> Language Class Initialized
INFO - 2023-12-13 10:28:22 --> Language Class Initialized
INFO - 2023-12-13 10:28:22 --> Config Class Initialized
INFO - 2023-12-13 10:28:22 --> Loader Class Initialized
INFO - 2023-12-13 10:28:22 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:22 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:22 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:22 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:22 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:24 --> Config Class Initialized
INFO - 2023-12-13 10:28:24 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:28:24 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:28:24 --> Utf8 Class Initialized
INFO - 2023-12-13 10:28:24 --> URI Class Initialized
INFO - 2023-12-13 10:28:24 --> Router Class Initialized
INFO - 2023-12-13 10:28:24 --> Output Class Initialized
INFO - 2023-12-13 10:28:24 --> Security Class Initialized
DEBUG - 2023-12-13 10:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:28:24 --> Input Class Initialized
INFO - 2023-12-13 10:28:24 --> Language Class Initialized
INFO - 2023-12-13 10:28:24 --> Language Class Initialized
INFO - 2023-12-13 10:28:24 --> Config Class Initialized
INFO - 2023-12-13 10:28:24 --> Loader Class Initialized
INFO - 2023-12-13 10:28:24 --> Helper loaded: url_helper
INFO - 2023-12-13 10:28:24 --> Helper loaded: file_helper
INFO - 2023-12-13 10:28:24 --> Helper loaded: form_helper
INFO - 2023-12-13 10:28:24 --> Helper loaded: my_helper
INFO - 2023-12-13 10:28:24 --> Database Driver Class Initialized
INFO - 2023-12-13 10:28:24 --> Final output sent to browser
DEBUG - 2023-12-13 10:28:24 --> Total execution time: 26.5296
INFO - 2023-12-13 10:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:28:24 --> Controller Class Initialized
DEBUG - 2023-12-13 10:28:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:28:35 --> Final output sent to browser
DEBUG - 2023-12-13 10:28:35 --> Total execution time: 37.2079
INFO - 2023-12-13 10:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:28:35 --> Controller Class Initialized
DEBUG - 2023-12-13 10:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:28:54 --> Final output sent to browser
DEBUG - 2023-12-13 10:28:54 --> Total execution time: 49.7003
INFO - 2023-12-13 10:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:28:54 --> Controller Class Initialized
DEBUG - 2023-12-13 10:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:11 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:11 --> Total execution time: 70.7459
INFO - 2023-12-13 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:11 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:22 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:22 --> Total execution time: 80.0722
INFO - 2023-12-13 10:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:22 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:31 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:31 --> Total execution time: 79.1541
INFO - 2023-12-13 10:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:31 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:37 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:37 --> Total execution time: 90.0693
INFO - 2023-12-13 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:37 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:46 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:46 --> Total execution time: 82.2832
INFO - 2023-12-13 10:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:46 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:29:54 --> Final output sent to browser
DEBUG - 2023-12-13 10:29:54 --> Total execution time: 99.4924
INFO - 2023-12-13 10:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:29:54 --> Controller Class Initialized
DEBUG - 2023-12-13 10:29:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:30:01 --> Final output sent to browser
DEBUG - 2023-12-13 10:30:01 --> Total execution time: 103.2075
INFO - 2023-12-13 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:30:01 --> Controller Class Initialized
DEBUG - 2023-12-13 10:30:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:30:24 --> Config Class Initialized
INFO - 2023-12-13 10:30:24 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:30:24 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:30:24 --> Utf8 Class Initialized
INFO - 2023-12-13 10:30:24 --> URI Class Initialized
INFO - 2023-12-13 10:30:24 --> Router Class Initialized
INFO - 2023-12-13 10:30:24 --> Output Class Initialized
INFO - 2023-12-13 10:30:24 --> Security Class Initialized
DEBUG - 2023-12-13 10:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:30:24 --> Input Class Initialized
INFO - 2023-12-13 10:30:24 --> Language Class Initialized
INFO - 2023-12-13 10:30:24 --> Language Class Initialized
INFO - 2023-12-13 10:30:24 --> Config Class Initialized
INFO - 2023-12-13 10:30:24 --> Loader Class Initialized
INFO - 2023-12-13 10:30:24 --> Helper loaded: url_helper
INFO - 2023-12-13 10:30:24 --> Helper loaded: file_helper
INFO - 2023-12-13 10:30:24 --> Helper loaded: form_helper
INFO - 2023-12-13 10:30:24 --> Helper loaded: my_helper
INFO - 2023-12-13 10:30:24 --> Database Driver Class Initialized
INFO - 2023-12-13 10:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:30:24 --> Controller Class Initialized
DEBUG - 2023-12-13 10:30:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:30:25 --> Config Class Initialized
INFO - 2023-12-13 10:30:25 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:30:25 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:30:25 --> Utf8 Class Initialized
INFO - 2023-12-13 10:30:25 --> URI Class Initialized
INFO - 2023-12-13 10:30:25 --> Router Class Initialized
INFO - 2023-12-13 10:30:25 --> Output Class Initialized
INFO - 2023-12-13 10:30:25 --> Security Class Initialized
DEBUG - 2023-12-13 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:30:25 --> Input Class Initialized
INFO - 2023-12-13 10:30:25 --> Language Class Initialized
INFO - 2023-12-13 10:30:25 --> Language Class Initialized
INFO - 2023-12-13 10:30:25 --> Config Class Initialized
INFO - 2023-12-13 10:30:25 --> Loader Class Initialized
INFO - 2023-12-13 10:30:25 --> Helper loaded: url_helper
INFO - 2023-12-13 10:30:25 --> Helper loaded: file_helper
INFO - 2023-12-13 10:30:25 --> Helper loaded: form_helper
INFO - 2023-12-13 10:30:25 --> Helper loaded: my_helper
INFO - 2023-12-13 10:30:25 --> Database Driver Class Initialized
INFO - 2023-12-13 10:30:31 --> Final output sent to browser
DEBUG - 2023-12-13 10:30:31 --> Total execution time: 7.4586
INFO - 2023-12-13 10:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:30:31 --> Controller Class Initialized
DEBUG - 2023-12-13 10:30:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 10:30:53 --> Final output sent to browser
DEBUG - 2023-12-13 10:30:53 --> Total execution time: 28.3478
INFO - 2023-12-13 10:56:11 --> Config Class Initialized
INFO - 2023-12-13 10:56:11 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:11 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:11 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:11 --> URI Class Initialized
INFO - 2023-12-13 10:56:11 --> Router Class Initialized
INFO - 2023-12-13 10:56:11 --> Output Class Initialized
INFO - 2023-12-13 10:56:11 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:11 --> Input Class Initialized
INFO - 2023-12-13 10:56:11 --> Language Class Initialized
INFO - 2023-12-13 10:56:11 --> Language Class Initialized
INFO - 2023-12-13 10:56:11 --> Config Class Initialized
INFO - 2023-12-13 10:56:11 --> Loader Class Initialized
INFO - 2023-12-13 10:56:11 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:11 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:11 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:11 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:11 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:11 --> Controller Class Initialized
DEBUG - 2023-12-13 10:56:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 10:56:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:56:11 --> Final output sent to browser
DEBUG - 2023-12-13 10:56:11 --> Total execution time: 0.0549
INFO - 2023-12-13 10:56:13 --> Config Class Initialized
INFO - 2023-12-13 10:56:13 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:13 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:13 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:13 --> URI Class Initialized
INFO - 2023-12-13 10:56:13 --> Router Class Initialized
INFO - 2023-12-13 10:56:13 --> Output Class Initialized
INFO - 2023-12-13 10:56:13 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:13 --> Input Class Initialized
INFO - 2023-12-13 10:56:13 --> Language Class Initialized
INFO - 2023-12-13 10:56:13 --> Language Class Initialized
INFO - 2023-12-13 10:56:13 --> Config Class Initialized
INFO - 2023-12-13 10:56:13 --> Loader Class Initialized
INFO - 2023-12-13 10:56:13 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:13 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:13 --> Controller Class Initialized
DEBUG - 2023-12-13 10:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 10:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:56:13 --> Final output sent to browser
DEBUG - 2023-12-13 10:56:13 --> Total execution time: 0.0761
INFO - 2023-12-13 10:56:13 --> Config Class Initialized
INFO - 2023-12-13 10:56:13 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:13 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:13 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:13 --> URI Class Initialized
INFO - 2023-12-13 10:56:13 --> Router Class Initialized
INFO - 2023-12-13 10:56:13 --> Output Class Initialized
INFO - 2023-12-13 10:56:13 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:13 --> Input Class Initialized
INFO - 2023-12-13 10:56:13 --> Language Class Initialized
INFO - 2023-12-13 10:56:13 --> Language Class Initialized
INFO - 2023-12-13 10:56:13 --> Config Class Initialized
INFO - 2023-12-13 10:56:13 --> Loader Class Initialized
INFO - 2023-12-13 10:56:13 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:13 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:13 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:13 --> Controller Class Initialized
INFO - 2023-12-13 10:56:17 --> Config Class Initialized
INFO - 2023-12-13 10:56:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:17 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:17 --> URI Class Initialized
INFO - 2023-12-13 10:56:17 --> Router Class Initialized
INFO - 2023-12-13 10:56:17 --> Output Class Initialized
INFO - 2023-12-13 10:56:17 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:17 --> Input Class Initialized
INFO - 2023-12-13 10:56:17 --> Language Class Initialized
INFO - 2023-12-13 10:56:17 --> Language Class Initialized
INFO - 2023-12-13 10:56:17 --> Config Class Initialized
INFO - 2023-12-13 10:56:17 --> Loader Class Initialized
INFO - 2023-12-13 10:56:17 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:17 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:17 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:17 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:17 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:17 --> Controller Class Initialized
DEBUG - 2023-12-13 10:56:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 10:56:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:56:17 --> Final output sent to browser
DEBUG - 2023-12-13 10:56:17 --> Total execution time: 0.0920
INFO - 2023-12-13 10:56:23 --> Config Class Initialized
INFO - 2023-12-13 10:56:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:23 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:23 --> URI Class Initialized
INFO - 2023-12-13 10:56:23 --> Router Class Initialized
INFO - 2023-12-13 10:56:23 --> Output Class Initialized
INFO - 2023-12-13 10:56:23 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:23 --> Input Class Initialized
INFO - 2023-12-13 10:56:23 --> Language Class Initialized
INFO - 2023-12-13 10:56:23 --> Language Class Initialized
INFO - 2023-12-13 10:56:23 --> Config Class Initialized
INFO - 2023-12-13 10:56:23 --> Loader Class Initialized
INFO - 2023-12-13 10:56:23 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:23 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:23 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:23 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:23 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:23 --> Controller Class Initialized
DEBUG - 2023-12-13 10:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-12-13 10:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 10:56:23 --> Final output sent to browser
DEBUG - 2023-12-13 10:56:23 --> Total execution time: 0.1156
INFO - 2023-12-13 10:56:40 --> Config Class Initialized
INFO - 2023-12-13 10:56:40 --> Hooks Class Initialized
DEBUG - 2023-12-13 10:56:40 --> UTF-8 Support Enabled
INFO - 2023-12-13 10:56:40 --> Utf8 Class Initialized
INFO - 2023-12-13 10:56:40 --> URI Class Initialized
INFO - 2023-12-13 10:56:40 --> Router Class Initialized
INFO - 2023-12-13 10:56:40 --> Output Class Initialized
INFO - 2023-12-13 10:56:40 --> Security Class Initialized
DEBUG - 2023-12-13 10:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 10:56:40 --> Input Class Initialized
INFO - 2023-12-13 10:56:40 --> Language Class Initialized
INFO - 2023-12-13 10:56:40 --> Language Class Initialized
INFO - 2023-12-13 10:56:40 --> Config Class Initialized
INFO - 2023-12-13 10:56:40 --> Loader Class Initialized
INFO - 2023-12-13 10:56:40 --> Helper loaded: url_helper
INFO - 2023-12-13 10:56:40 --> Helper loaded: file_helper
INFO - 2023-12-13 10:56:40 --> Helper loaded: form_helper
INFO - 2023-12-13 10:56:40 --> Helper loaded: my_helper
INFO - 2023-12-13 10:56:40 --> Database Driver Class Initialized
INFO - 2023-12-13 10:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 10:56:41 --> Controller Class Initialized
INFO - 2023-12-13 10:56:41 --> Final output sent to browser
DEBUG - 2023-12-13 10:56:41 --> Total execution time: 0.5208
INFO - 2023-12-13 11:05:50 --> Config Class Initialized
INFO - 2023-12-13 11:05:50 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:05:50 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:05:50 --> Utf8 Class Initialized
INFO - 2023-12-13 11:05:50 --> URI Class Initialized
INFO - 2023-12-13 11:05:50 --> Router Class Initialized
INFO - 2023-12-13 11:05:50 --> Output Class Initialized
INFO - 2023-12-13 11:05:50 --> Security Class Initialized
DEBUG - 2023-12-13 11:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:05:50 --> Input Class Initialized
INFO - 2023-12-13 11:05:50 --> Language Class Initialized
INFO - 2023-12-13 11:05:50 --> Language Class Initialized
INFO - 2023-12-13 11:05:50 --> Config Class Initialized
INFO - 2023-12-13 11:05:50 --> Loader Class Initialized
INFO - 2023-12-13 11:05:50 --> Helper loaded: url_helper
INFO - 2023-12-13 11:05:50 --> Helper loaded: file_helper
INFO - 2023-12-13 11:05:50 --> Helper loaded: form_helper
INFO - 2023-12-13 11:05:50 --> Helper loaded: my_helper
INFO - 2023-12-13 11:05:50 --> Database Driver Class Initialized
INFO - 2023-12-13 11:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:05:50 --> Controller Class Initialized
INFO - 2023-12-13 11:05:50 --> Final output sent to browser
DEBUG - 2023-12-13 11:05:50 --> Total execution time: 0.7985
INFO - 2023-12-13 11:06:54 --> Config Class Initialized
INFO - 2023-12-13 11:06:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:06:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:06:54 --> Utf8 Class Initialized
INFO - 2023-12-13 11:06:54 --> URI Class Initialized
INFO - 2023-12-13 11:06:54 --> Router Class Initialized
INFO - 2023-12-13 11:06:54 --> Output Class Initialized
INFO - 2023-12-13 11:06:54 --> Security Class Initialized
DEBUG - 2023-12-13 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:06:54 --> Input Class Initialized
INFO - 2023-12-13 11:06:54 --> Language Class Initialized
INFO - 2023-12-13 11:06:54 --> Language Class Initialized
INFO - 2023-12-13 11:06:54 --> Config Class Initialized
INFO - 2023-12-13 11:06:54 --> Loader Class Initialized
INFO - 2023-12-13 11:06:54 --> Helper loaded: url_helper
INFO - 2023-12-13 11:06:54 --> Helper loaded: file_helper
INFO - 2023-12-13 11:06:54 --> Helper loaded: form_helper
INFO - 2023-12-13 11:06:54 --> Helper loaded: my_helper
INFO - 2023-12-13 11:06:54 --> Database Driver Class Initialized
INFO - 2023-12-13 11:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:06:54 --> Controller Class Initialized
INFO - 2023-12-13 11:06:54 --> Final output sent to browser
DEBUG - 2023-12-13 11:06:54 --> Total execution time: 0.7237
INFO - 2023-12-13 11:08:42 --> Config Class Initialized
INFO - 2023-12-13 11:08:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:08:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:08:42 --> Utf8 Class Initialized
INFO - 2023-12-13 11:08:42 --> URI Class Initialized
INFO - 2023-12-13 11:08:42 --> Router Class Initialized
INFO - 2023-12-13 11:08:42 --> Output Class Initialized
INFO - 2023-12-13 11:08:42 --> Security Class Initialized
DEBUG - 2023-12-13 11:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:08:42 --> Input Class Initialized
INFO - 2023-12-13 11:08:42 --> Language Class Initialized
INFO - 2023-12-13 11:08:42 --> Language Class Initialized
INFO - 2023-12-13 11:08:42 --> Config Class Initialized
INFO - 2023-12-13 11:08:42 --> Loader Class Initialized
INFO - 2023-12-13 11:08:42 --> Helper loaded: url_helper
INFO - 2023-12-13 11:08:42 --> Helper loaded: file_helper
INFO - 2023-12-13 11:08:42 --> Helper loaded: form_helper
INFO - 2023-12-13 11:08:42 --> Helper loaded: my_helper
INFO - 2023-12-13 11:08:42 --> Database Driver Class Initialized
INFO - 2023-12-13 11:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:08:42 --> Controller Class Initialized
INFO - 2023-12-13 11:08:42 --> Final output sent to browser
DEBUG - 2023-12-13 11:08:42 --> Total execution time: 0.7142
INFO - 2023-12-13 11:09:56 --> Config Class Initialized
INFO - 2023-12-13 11:09:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:09:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:09:56 --> Utf8 Class Initialized
INFO - 2023-12-13 11:09:56 --> URI Class Initialized
INFO - 2023-12-13 11:09:56 --> Router Class Initialized
INFO - 2023-12-13 11:09:56 --> Output Class Initialized
INFO - 2023-12-13 11:09:56 --> Security Class Initialized
DEBUG - 2023-12-13 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:09:56 --> Input Class Initialized
INFO - 2023-12-13 11:09:56 --> Language Class Initialized
INFO - 2023-12-13 11:09:56 --> Language Class Initialized
INFO - 2023-12-13 11:09:56 --> Config Class Initialized
INFO - 2023-12-13 11:09:56 --> Loader Class Initialized
INFO - 2023-12-13 11:09:56 --> Helper loaded: url_helper
INFO - 2023-12-13 11:09:56 --> Helper loaded: file_helper
INFO - 2023-12-13 11:09:56 --> Helper loaded: form_helper
INFO - 2023-12-13 11:09:56 --> Helper loaded: my_helper
INFO - 2023-12-13 11:09:56 --> Database Driver Class Initialized
INFO - 2023-12-13 11:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:09:56 --> Controller Class Initialized
INFO - 2023-12-13 11:09:56 --> Final output sent to browser
DEBUG - 2023-12-13 11:09:56 --> Total execution time: 0.4329
INFO - 2023-12-13 11:10:37 --> Config Class Initialized
INFO - 2023-12-13 11:10:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:10:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:10:37 --> Utf8 Class Initialized
INFO - 2023-12-13 11:10:37 --> URI Class Initialized
INFO - 2023-12-13 11:10:37 --> Router Class Initialized
INFO - 2023-12-13 11:10:37 --> Output Class Initialized
INFO - 2023-12-13 11:10:37 --> Security Class Initialized
DEBUG - 2023-12-13 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:10:37 --> Input Class Initialized
INFO - 2023-12-13 11:10:37 --> Language Class Initialized
INFO - 2023-12-13 11:10:38 --> Language Class Initialized
INFO - 2023-12-13 11:10:38 --> Config Class Initialized
INFO - 2023-12-13 11:10:38 --> Loader Class Initialized
INFO - 2023-12-13 11:10:38 --> Helper loaded: url_helper
INFO - 2023-12-13 11:10:38 --> Helper loaded: file_helper
INFO - 2023-12-13 11:10:38 --> Helper loaded: form_helper
INFO - 2023-12-13 11:10:38 --> Helper loaded: my_helper
INFO - 2023-12-13 11:10:38 --> Database Driver Class Initialized
INFO - 2023-12-13 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:10:38 --> Controller Class Initialized
DEBUG - 2023-12-13 11:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-12-13 11:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:10:38 --> Final output sent to browser
DEBUG - 2023-12-13 11:10:38 --> Total execution time: 0.0659
INFO - 2023-12-13 11:23:18 --> Config Class Initialized
INFO - 2023-12-13 11:23:18 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:23:18 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:23:18 --> Utf8 Class Initialized
INFO - 2023-12-13 11:23:18 --> URI Class Initialized
INFO - 2023-12-13 11:23:18 --> Router Class Initialized
INFO - 2023-12-13 11:23:18 --> Output Class Initialized
INFO - 2023-12-13 11:23:18 --> Security Class Initialized
DEBUG - 2023-12-13 11:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:23:18 --> Input Class Initialized
INFO - 2023-12-13 11:23:18 --> Language Class Initialized
INFO - 2023-12-13 11:23:18 --> Language Class Initialized
INFO - 2023-12-13 11:23:18 --> Config Class Initialized
INFO - 2023-12-13 11:23:18 --> Loader Class Initialized
INFO - 2023-12-13 11:23:18 --> Helper loaded: url_helper
INFO - 2023-12-13 11:23:18 --> Helper loaded: file_helper
INFO - 2023-12-13 11:23:18 --> Helper loaded: form_helper
INFO - 2023-12-13 11:23:18 --> Helper loaded: my_helper
INFO - 2023-12-13 11:23:19 --> Database Driver Class Initialized
INFO - 2023-12-13 11:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:23:19 --> Controller Class Initialized
INFO - 2023-12-13 11:23:19 --> Final output sent to browser
DEBUG - 2023-12-13 11:23:19 --> Total execution time: 0.7605
INFO - 2023-12-13 11:23:30 --> Config Class Initialized
INFO - 2023-12-13 11:23:30 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:23:30 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:23:30 --> Utf8 Class Initialized
INFO - 2023-12-13 11:23:30 --> URI Class Initialized
INFO - 2023-12-13 11:23:30 --> Router Class Initialized
INFO - 2023-12-13 11:23:30 --> Output Class Initialized
INFO - 2023-12-13 11:23:30 --> Security Class Initialized
DEBUG - 2023-12-13 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:23:30 --> Input Class Initialized
INFO - 2023-12-13 11:23:30 --> Language Class Initialized
INFO - 2023-12-13 11:23:30 --> Language Class Initialized
INFO - 2023-12-13 11:23:30 --> Config Class Initialized
INFO - 2023-12-13 11:23:30 --> Loader Class Initialized
INFO - 2023-12-13 11:23:30 --> Helper loaded: url_helper
INFO - 2023-12-13 11:23:30 --> Helper loaded: file_helper
INFO - 2023-12-13 11:23:30 --> Helper loaded: form_helper
INFO - 2023-12-13 11:23:30 --> Helper loaded: my_helper
INFO - 2023-12-13 11:23:30 --> Database Driver Class Initialized
INFO - 2023-12-13 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:23:30 --> Controller Class Initialized
DEBUG - 2023-12-13 11:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 11:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:23:30 --> Final output sent to browser
DEBUG - 2023-12-13 11:23:30 --> Total execution time: 0.1910
INFO - 2023-12-13 11:23:34 --> Config Class Initialized
INFO - 2023-12-13 11:23:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:23:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:23:34 --> Utf8 Class Initialized
INFO - 2023-12-13 11:23:34 --> URI Class Initialized
INFO - 2023-12-13 11:23:34 --> Router Class Initialized
INFO - 2023-12-13 11:23:34 --> Output Class Initialized
INFO - 2023-12-13 11:23:34 --> Security Class Initialized
DEBUG - 2023-12-13 11:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:23:34 --> Input Class Initialized
INFO - 2023-12-13 11:23:34 --> Language Class Initialized
INFO - 2023-12-13 11:23:34 --> Language Class Initialized
INFO - 2023-12-13 11:23:34 --> Config Class Initialized
INFO - 2023-12-13 11:23:34 --> Loader Class Initialized
INFO - 2023-12-13 11:23:34 --> Helper loaded: url_helper
INFO - 2023-12-13 11:23:34 --> Helper loaded: file_helper
INFO - 2023-12-13 11:23:34 --> Helper loaded: form_helper
INFO - 2023-12-13 11:23:34 --> Helper loaded: my_helper
INFO - 2023-12-13 11:23:34 --> Database Driver Class Initialized
INFO - 2023-12-13 11:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:23:34 --> Controller Class Initialized
DEBUG - 2023-12-13 11:23:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-13 11:23:46 --> Final output sent to browser
DEBUG - 2023-12-13 11:23:46 --> Total execution time: 11.3392
INFO - 2023-12-13 11:24:06 --> Config Class Initialized
INFO - 2023-12-13 11:24:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:24:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:24:06 --> Utf8 Class Initialized
INFO - 2023-12-13 11:24:06 --> URI Class Initialized
INFO - 2023-12-13 11:24:06 --> Router Class Initialized
INFO - 2023-12-13 11:24:06 --> Output Class Initialized
INFO - 2023-12-13 11:24:06 --> Security Class Initialized
DEBUG - 2023-12-13 11:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:24:06 --> Input Class Initialized
INFO - 2023-12-13 11:24:06 --> Language Class Initialized
INFO - 2023-12-13 11:24:06 --> Language Class Initialized
INFO - 2023-12-13 11:24:06 --> Config Class Initialized
INFO - 2023-12-13 11:24:06 --> Loader Class Initialized
INFO - 2023-12-13 11:24:06 --> Helper loaded: url_helper
INFO - 2023-12-13 11:24:06 --> Helper loaded: file_helper
INFO - 2023-12-13 11:24:06 --> Helper loaded: form_helper
INFO - 2023-12-13 11:24:06 --> Helper loaded: my_helper
INFO - 2023-12-13 11:24:06 --> Database Driver Class Initialized
INFO - 2023-12-13 11:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:24:06 --> Controller Class Initialized
DEBUG - 2023-12-13 11:24:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:24:34 --> Final output sent to browser
DEBUG - 2023-12-13 11:24:34 --> Total execution time: 27.9352
INFO - 2023-12-13 11:26:08 --> Config Class Initialized
INFO - 2023-12-13 11:26:08 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:26:08 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:26:08 --> Utf8 Class Initialized
INFO - 2023-12-13 11:26:08 --> URI Class Initialized
INFO - 2023-12-13 11:26:08 --> Router Class Initialized
INFO - 2023-12-13 11:26:08 --> Output Class Initialized
INFO - 2023-12-13 11:26:08 --> Security Class Initialized
DEBUG - 2023-12-13 11:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:26:08 --> Input Class Initialized
INFO - 2023-12-13 11:26:08 --> Language Class Initialized
INFO - 2023-12-13 11:26:08 --> Language Class Initialized
INFO - 2023-12-13 11:26:08 --> Config Class Initialized
INFO - 2023-12-13 11:26:08 --> Loader Class Initialized
INFO - 2023-12-13 11:26:08 --> Helper loaded: url_helper
INFO - 2023-12-13 11:26:08 --> Helper loaded: file_helper
INFO - 2023-12-13 11:26:08 --> Helper loaded: form_helper
INFO - 2023-12-13 11:26:08 --> Helper loaded: my_helper
INFO - 2023-12-13 11:26:08 --> Database Driver Class Initialized
INFO - 2023-12-13 11:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:26:09 --> Controller Class Initialized
DEBUG - 2023-12-13 11:26:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 11:26:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:26:09 --> Final output sent to browser
DEBUG - 2023-12-13 11:26:09 --> Total execution time: 0.3029
INFO - 2023-12-13 11:26:09 --> Config Class Initialized
INFO - 2023-12-13 11:26:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:26:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:26:09 --> Utf8 Class Initialized
INFO - 2023-12-13 11:26:09 --> URI Class Initialized
INFO - 2023-12-13 11:26:09 --> Router Class Initialized
INFO - 2023-12-13 11:26:09 --> Output Class Initialized
INFO - 2023-12-13 11:26:09 --> Security Class Initialized
DEBUG - 2023-12-13 11:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:26:09 --> Input Class Initialized
INFO - 2023-12-13 11:26:09 --> Language Class Initialized
INFO - 2023-12-13 11:26:09 --> Language Class Initialized
INFO - 2023-12-13 11:26:09 --> Config Class Initialized
INFO - 2023-12-13 11:26:09 --> Loader Class Initialized
INFO - 2023-12-13 11:26:09 --> Helper loaded: url_helper
INFO - 2023-12-13 11:26:09 --> Helper loaded: file_helper
INFO - 2023-12-13 11:26:09 --> Helper loaded: form_helper
INFO - 2023-12-13 11:26:09 --> Helper loaded: my_helper
INFO - 2023-12-13 11:26:09 --> Database Driver Class Initialized
INFO - 2023-12-13 11:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:26:09 --> Controller Class Initialized
INFO - 2023-12-13 11:27:17 --> Config Class Initialized
INFO - 2023-12-13 11:27:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:17 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:17 --> URI Class Initialized
DEBUG - 2023-12-13 11:27:17 --> No URI present. Default controller set.
INFO - 2023-12-13 11:27:17 --> Router Class Initialized
INFO - 2023-12-13 11:27:17 --> Output Class Initialized
INFO - 2023-12-13 11:27:17 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:17 --> Input Class Initialized
INFO - 2023-12-13 11:27:17 --> Language Class Initialized
INFO - 2023-12-13 11:27:17 --> Language Class Initialized
INFO - 2023-12-13 11:27:17 --> Config Class Initialized
INFO - 2023-12-13 11:27:17 --> Loader Class Initialized
INFO - 2023-12-13 11:27:17 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:17 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:17 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:17 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:17 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:17 --> Controller Class Initialized
INFO - 2023-12-13 11:27:18 --> Config Class Initialized
INFO - 2023-12-13 11:27:18 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:18 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:18 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:18 --> URI Class Initialized
INFO - 2023-12-13 11:27:18 --> Router Class Initialized
INFO - 2023-12-13 11:27:18 --> Output Class Initialized
INFO - 2023-12-13 11:27:18 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:18 --> Input Class Initialized
INFO - 2023-12-13 11:27:18 --> Language Class Initialized
INFO - 2023-12-13 11:27:18 --> Language Class Initialized
INFO - 2023-12-13 11:27:18 --> Config Class Initialized
INFO - 2023-12-13 11:27:18 --> Loader Class Initialized
INFO - 2023-12-13 11:27:18 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:18 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:18 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:18 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:18 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:18 --> Controller Class Initialized
DEBUG - 2023-12-13 11:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 11:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:27:18 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:18 --> Total execution time: 0.2458
INFO - 2023-12-13 11:27:21 --> Config Class Initialized
INFO - 2023-12-13 11:27:21 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:21 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:21 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:21 --> URI Class Initialized
INFO - 2023-12-13 11:27:21 --> Router Class Initialized
INFO - 2023-12-13 11:27:21 --> Output Class Initialized
INFO - 2023-12-13 11:27:21 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:21 --> Input Class Initialized
INFO - 2023-12-13 11:27:21 --> Language Class Initialized
INFO - 2023-12-13 11:27:21 --> Language Class Initialized
INFO - 2023-12-13 11:27:21 --> Config Class Initialized
INFO - 2023-12-13 11:27:21 --> Loader Class Initialized
INFO - 2023-12-13 11:27:21 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:21 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:21 --> Controller Class Initialized
INFO - 2023-12-13 11:27:21 --> Helper loaded: cookie_helper
INFO - 2023-12-13 11:27:21 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:21 --> Total execution time: 0.4372
INFO - 2023-12-13 11:27:21 --> Config Class Initialized
INFO - 2023-12-13 11:27:21 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:21 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:21 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:21 --> URI Class Initialized
INFO - 2023-12-13 11:27:21 --> Router Class Initialized
INFO - 2023-12-13 11:27:21 --> Output Class Initialized
INFO - 2023-12-13 11:27:21 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:21 --> Input Class Initialized
INFO - 2023-12-13 11:27:21 --> Language Class Initialized
INFO - 2023-12-13 11:27:21 --> Language Class Initialized
INFO - 2023-12-13 11:27:21 --> Config Class Initialized
INFO - 2023-12-13 11:27:21 --> Loader Class Initialized
INFO - 2023-12-13 11:27:21 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:21 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:21 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:21 --> Controller Class Initialized
DEBUG - 2023-12-13 11:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 11:27:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:27:22 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:22 --> Total execution time: 0.4211
INFO - 2023-12-13 11:27:23 --> Config Class Initialized
INFO - 2023-12-13 11:27:23 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:23 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:23 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:24 --> URI Class Initialized
INFO - 2023-12-13 11:27:24 --> Router Class Initialized
INFO - 2023-12-13 11:27:24 --> Output Class Initialized
INFO - 2023-12-13 11:27:24 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:24 --> Input Class Initialized
INFO - 2023-12-13 11:27:24 --> Language Class Initialized
INFO - 2023-12-13 11:27:24 --> Language Class Initialized
INFO - 2023-12-13 11:27:24 --> Config Class Initialized
INFO - 2023-12-13 11:27:24 --> Loader Class Initialized
INFO - 2023-12-13 11:27:24 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:24 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:24 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:24 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:24 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:24 --> Controller Class Initialized
DEBUG - 2023-12-13 11:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 11:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:27:24 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:24 --> Total execution time: 0.4574
INFO - 2023-12-13 11:27:27 --> Config Class Initialized
INFO - 2023-12-13 11:27:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:27 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:27 --> URI Class Initialized
INFO - 2023-12-13 11:27:27 --> Router Class Initialized
INFO - 2023-12-13 11:27:27 --> Output Class Initialized
INFO - 2023-12-13 11:27:27 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:27 --> Input Class Initialized
INFO - 2023-12-13 11:27:27 --> Language Class Initialized
INFO - 2023-12-13 11:27:27 --> Language Class Initialized
INFO - 2023-12-13 11:27:27 --> Config Class Initialized
INFO - 2023-12-13 11:27:27 --> Loader Class Initialized
INFO - 2023-12-13 11:27:27 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:27 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:27 --> Controller Class Initialized
DEBUG - 2023-12-13 11:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 11:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:27:27 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:27 --> Total execution time: 0.3709
INFO - 2023-12-13 11:27:27 --> Config Class Initialized
INFO - 2023-12-13 11:27:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:27 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:27 --> URI Class Initialized
INFO - 2023-12-13 11:27:27 --> Router Class Initialized
INFO - 2023-12-13 11:27:27 --> Output Class Initialized
INFO - 2023-12-13 11:27:27 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:27 --> Input Class Initialized
INFO - 2023-12-13 11:27:27 --> Language Class Initialized
INFO - 2023-12-13 11:27:27 --> Language Class Initialized
INFO - 2023-12-13 11:27:27 --> Config Class Initialized
INFO - 2023-12-13 11:27:27 --> Loader Class Initialized
INFO - 2023-12-13 11:27:27 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:27 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:28 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:28 --> Controller Class Initialized
INFO - 2023-12-13 11:27:30 --> Config Class Initialized
INFO - 2023-12-13 11:27:30 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:30 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:30 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:30 --> URI Class Initialized
INFO - 2023-12-13 11:27:30 --> Router Class Initialized
INFO - 2023-12-13 11:27:30 --> Output Class Initialized
INFO - 2023-12-13 11:27:30 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:30 --> Input Class Initialized
INFO - 2023-12-13 11:27:30 --> Language Class Initialized
INFO - 2023-12-13 11:27:31 --> Language Class Initialized
INFO - 2023-12-13 11:27:31 --> Config Class Initialized
INFO - 2023-12-13 11:27:31 --> Loader Class Initialized
INFO - 2023-12-13 11:27:31 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:31 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:31 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:31 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:31 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:31 --> Controller Class Initialized
INFO - 2023-12-13 11:27:31 --> Final output sent to browser
DEBUG - 2023-12-13 11:27:31 --> Total execution time: 0.4493
INFO - 2023-12-13 11:27:37 --> Config Class Initialized
INFO - 2023-12-13 11:27:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:27:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:27:37 --> Utf8 Class Initialized
INFO - 2023-12-13 11:27:37 --> URI Class Initialized
INFO - 2023-12-13 11:27:37 --> Router Class Initialized
INFO - 2023-12-13 11:27:37 --> Output Class Initialized
INFO - 2023-12-13 11:27:37 --> Security Class Initialized
DEBUG - 2023-12-13 11:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:27:37 --> Input Class Initialized
INFO - 2023-12-13 11:27:37 --> Language Class Initialized
INFO - 2023-12-13 11:27:37 --> Language Class Initialized
INFO - 2023-12-13 11:27:37 --> Config Class Initialized
INFO - 2023-12-13 11:27:37 --> Loader Class Initialized
INFO - 2023-12-13 11:27:37 --> Helper loaded: url_helper
INFO - 2023-12-13 11:27:37 --> Helper loaded: file_helper
INFO - 2023-12-13 11:27:37 --> Helper loaded: form_helper
INFO - 2023-12-13 11:27:37 --> Helper loaded: my_helper
INFO - 2023-12-13 11:27:38 --> Database Driver Class Initialized
INFO - 2023-12-13 11:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:27:38 --> Controller Class Initialized
INFO - 2023-12-13 11:29:31 --> Config Class Initialized
INFO - 2023-12-13 11:29:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:29:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:29:31 --> Utf8 Class Initialized
INFO - 2023-12-13 11:29:31 --> URI Class Initialized
INFO - 2023-12-13 11:29:31 --> Router Class Initialized
INFO - 2023-12-13 11:29:31 --> Output Class Initialized
INFO - 2023-12-13 11:29:31 --> Security Class Initialized
DEBUG - 2023-12-13 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:29:31 --> Input Class Initialized
INFO - 2023-12-13 11:29:31 --> Language Class Initialized
INFO - 2023-12-13 11:29:31 --> Language Class Initialized
INFO - 2023-12-13 11:29:31 --> Config Class Initialized
INFO - 2023-12-13 11:29:31 --> Loader Class Initialized
INFO - 2023-12-13 11:29:31 --> Helper loaded: url_helper
INFO - 2023-12-13 11:29:31 --> Helper loaded: file_helper
INFO - 2023-12-13 11:29:31 --> Helper loaded: form_helper
INFO - 2023-12-13 11:29:31 --> Helper loaded: my_helper
INFO - 2023-12-13 11:29:31 --> Database Driver Class Initialized
INFO - 2023-12-13 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:29:31 --> Controller Class Initialized
DEBUG - 2023-12-13 11:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-13 11:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:29:31 --> Final output sent to browser
DEBUG - 2023-12-13 11:29:31 --> Total execution time: 0.4651
INFO - 2023-12-13 11:29:41 --> Config Class Initialized
INFO - 2023-12-13 11:29:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:29:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:29:41 --> Utf8 Class Initialized
INFO - 2023-12-13 11:29:41 --> URI Class Initialized
INFO - 2023-12-13 11:29:41 --> Router Class Initialized
INFO - 2023-12-13 11:29:41 --> Output Class Initialized
INFO - 2023-12-13 11:29:41 --> Security Class Initialized
DEBUG - 2023-12-13 11:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:29:41 --> Input Class Initialized
INFO - 2023-12-13 11:29:41 --> Language Class Initialized
INFO - 2023-12-13 11:29:41 --> Language Class Initialized
INFO - 2023-12-13 11:29:41 --> Config Class Initialized
INFO - 2023-12-13 11:29:41 --> Loader Class Initialized
INFO - 2023-12-13 11:29:41 --> Helper loaded: url_helper
INFO - 2023-12-13 11:29:41 --> Helper loaded: file_helper
INFO - 2023-12-13 11:29:41 --> Helper loaded: form_helper
INFO - 2023-12-13 11:29:41 --> Helper loaded: my_helper
INFO - 2023-12-13 11:29:41 --> Database Driver Class Initialized
INFO - 2023-12-13 11:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:29:41 --> Controller Class Initialized
INFO - 2023-12-13 11:29:42 --> Config Class Initialized
INFO - 2023-12-13 11:29:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:29:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:29:42 --> Utf8 Class Initialized
INFO - 2023-12-13 11:29:42 --> URI Class Initialized
INFO - 2023-12-13 11:29:42 --> Router Class Initialized
INFO - 2023-12-13 11:29:42 --> Output Class Initialized
INFO - 2023-12-13 11:29:42 --> Security Class Initialized
DEBUG - 2023-12-13 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:29:42 --> Input Class Initialized
INFO - 2023-12-13 11:29:42 --> Language Class Initialized
INFO - 2023-12-13 11:29:42 --> Language Class Initialized
INFO - 2023-12-13 11:29:42 --> Config Class Initialized
INFO - 2023-12-13 11:29:42 --> Loader Class Initialized
INFO - 2023-12-13 11:29:42 --> Helper loaded: url_helper
INFO - 2023-12-13 11:29:42 --> Helper loaded: file_helper
INFO - 2023-12-13 11:29:42 --> Helper loaded: form_helper
INFO - 2023-12-13 11:29:42 --> Helper loaded: my_helper
INFO - 2023-12-13 11:29:42 --> Database Driver Class Initialized
INFO - 2023-12-13 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:29:42 --> Controller Class Initialized
DEBUG - 2023-12-13 11:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 11:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 11:29:42 --> Final output sent to browser
DEBUG - 2023-12-13 11:29:42 --> Total execution time: 0.1790
INFO - 2023-12-13 11:29:43 --> Config Class Initialized
INFO - 2023-12-13 11:29:43 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:29:43 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:29:43 --> Utf8 Class Initialized
INFO - 2023-12-13 11:29:43 --> URI Class Initialized
INFO - 2023-12-13 11:29:43 --> Router Class Initialized
INFO - 2023-12-13 11:29:43 --> Output Class Initialized
INFO - 2023-12-13 11:29:43 --> Security Class Initialized
DEBUG - 2023-12-13 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:29:43 --> Input Class Initialized
INFO - 2023-12-13 11:29:43 --> Language Class Initialized
INFO - 2023-12-13 11:29:43 --> Language Class Initialized
INFO - 2023-12-13 11:29:43 --> Config Class Initialized
INFO - 2023-12-13 11:29:43 --> Loader Class Initialized
INFO - 2023-12-13 11:29:43 --> Helper loaded: url_helper
INFO - 2023-12-13 11:29:43 --> Helper loaded: file_helper
INFO - 2023-12-13 11:29:43 --> Helper loaded: form_helper
INFO - 2023-12-13 11:29:43 --> Helper loaded: my_helper
INFO - 2023-12-13 11:29:43 --> Database Driver Class Initialized
INFO - 2023-12-13 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:29:43 --> Controller Class Initialized
INFO - 2023-12-13 11:31:46 --> Config Class Initialized
INFO - 2023-12-13 11:31:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:31:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:31:46 --> Utf8 Class Initialized
INFO - 2023-12-13 11:31:46 --> URI Class Initialized
INFO - 2023-12-13 11:31:46 --> Router Class Initialized
INFO - 2023-12-13 11:31:46 --> Output Class Initialized
INFO - 2023-12-13 11:31:46 --> Security Class Initialized
DEBUG - 2023-12-13 11:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:31:46 --> Input Class Initialized
INFO - 2023-12-13 11:31:46 --> Language Class Initialized
INFO - 2023-12-13 11:31:47 --> Language Class Initialized
INFO - 2023-12-13 11:31:47 --> Config Class Initialized
INFO - 2023-12-13 11:31:47 --> Loader Class Initialized
INFO - 2023-12-13 11:31:47 --> Helper loaded: url_helper
INFO - 2023-12-13 11:31:47 --> Helper loaded: file_helper
INFO - 2023-12-13 11:31:47 --> Helper loaded: form_helper
INFO - 2023-12-13 11:31:47 --> Helper loaded: my_helper
INFO - 2023-12-13 11:31:47 --> Database Driver Class Initialized
INFO - 2023-12-13 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:31:47 --> Controller Class Initialized
DEBUG - 2023-12-13 11:31:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:31:52 --> Config Class Initialized
INFO - 2023-12-13 11:31:52 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:31:52 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:31:52 --> Utf8 Class Initialized
INFO - 2023-12-13 11:31:52 --> URI Class Initialized
INFO - 2023-12-13 11:31:52 --> Router Class Initialized
INFO - 2023-12-13 11:31:52 --> Output Class Initialized
INFO - 2023-12-13 11:31:52 --> Security Class Initialized
DEBUG - 2023-12-13 11:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:31:52 --> Input Class Initialized
INFO - 2023-12-13 11:31:52 --> Language Class Initialized
INFO - 2023-12-13 11:31:52 --> Language Class Initialized
INFO - 2023-12-13 11:31:52 --> Config Class Initialized
INFO - 2023-12-13 11:31:52 --> Loader Class Initialized
INFO - 2023-12-13 11:31:52 --> Helper loaded: url_helper
INFO - 2023-12-13 11:31:52 --> Helper loaded: file_helper
INFO - 2023-12-13 11:31:52 --> Helper loaded: form_helper
INFO - 2023-12-13 11:31:52 --> Helper loaded: my_helper
INFO - 2023-12-13 11:31:52 --> Database Driver Class Initialized
INFO - 2023-12-13 11:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:31:52 --> Controller Class Initialized
DEBUG - 2023-12-13 11:31:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:31:54 --> Config Class Initialized
INFO - 2023-12-13 11:31:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:31:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:31:54 --> Utf8 Class Initialized
INFO - 2023-12-13 11:31:54 --> URI Class Initialized
INFO - 2023-12-13 11:31:54 --> Router Class Initialized
INFO - 2023-12-13 11:31:54 --> Output Class Initialized
INFO - 2023-12-13 11:31:54 --> Security Class Initialized
DEBUG - 2023-12-13 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:31:54 --> Input Class Initialized
INFO - 2023-12-13 11:31:54 --> Language Class Initialized
INFO - 2023-12-13 11:31:54 --> Language Class Initialized
INFO - 2023-12-13 11:31:54 --> Config Class Initialized
INFO - 2023-12-13 11:31:54 --> Loader Class Initialized
INFO - 2023-12-13 11:31:54 --> Helper loaded: url_helper
INFO - 2023-12-13 11:31:54 --> Helper loaded: file_helper
INFO - 2023-12-13 11:31:54 --> Helper loaded: form_helper
INFO - 2023-12-13 11:31:54 --> Helper loaded: my_helper
INFO - 2023-12-13 11:31:54 --> Database Driver Class Initialized
INFO - 2023-12-13 11:31:56 --> Config Class Initialized
INFO - 2023-12-13 11:31:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:31:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:31:56 --> Utf8 Class Initialized
INFO - 2023-12-13 11:31:56 --> URI Class Initialized
INFO - 2023-12-13 11:31:56 --> Router Class Initialized
INFO - 2023-12-13 11:31:56 --> Output Class Initialized
INFO - 2023-12-13 11:31:56 --> Security Class Initialized
DEBUG - 2023-12-13 11:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:31:56 --> Input Class Initialized
INFO - 2023-12-13 11:31:56 --> Language Class Initialized
INFO - 2023-12-13 11:31:56 --> Language Class Initialized
INFO - 2023-12-13 11:31:56 --> Config Class Initialized
INFO - 2023-12-13 11:31:56 --> Loader Class Initialized
INFO - 2023-12-13 11:31:56 --> Helper loaded: url_helper
INFO - 2023-12-13 11:31:56 --> Helper loaded: file_helper
INFO - 2023-12-13 11:31:56 --> Helper loaded: form_helper
INFO - 2023-12-13 11:31:56 --> Helper loaded: my_helper
INFO - 2023-12-13 11:31:56 --> Database Driver Class Initialized
INFO - 2023-12-13 11:32:12 --> Final output sent to browser
DEBUG - 2023-12-13 11:32:12 --> Total execution time: 26.0227
INFO - 2023-12-13 11:32:17 --> Final output sent to browser
DEBUG - 2023-12-13 11:32:17 --> Total execution time: 25.1970
INFO - 2023-12-13 11:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:32:17 --> Controller Class Initialized
DEBUG - 2023-12-13 11:32:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:32:23 --> Final output sent to browser
DEBUG - 2023-12-13 11:32:23 --> Total execution time: 29.0390
INFO - 2023-12-13 11:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:32:23 --> Controller Class Initialized
DEBUG - 2023-12-13 11:32:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:32:30 --> Final output sent to browser
DEBUG - 2023-12-13 11:32:30 --> Total execution time: 33.3853
INFO - 2023-12-13 11:33:26 --> Config Class Initialized
INFO - 2023-12-13 11:33:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 11:33:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 11:33:26 --> Utf8 Class Initialized
INFO - 2023-12-13 11:33:26 --> URI Class Initialized
INFO - 2023-12-13 11:33:26 --> Router Class Initialized
INFO - 2023-12-13 11:33:26 --> Output Class Initialized
INFO - 2023-12-13 11:33:26 --> Security Class Initialized
DEBUG - 2023-12-13 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 11:33:26 --> Input Class Initialized
INFO - 2023-12-13 11:33:27 --> Language Class Initialized
INFO - 2023-12-13 11:33:27 --> Language Class Initialized
INFO - 2023-12-13 11:33:27 --> Config Class Initialized
INFO - 2023-12-13 11:33:27 --> Loader Class Initialized
INFO - 2023-12-13 11:33:27 --> Helper loaded: url_helper
INFO - 2023-12-13 11:33:27 --> Helper loaded: file_helper
INFO - 2023-12-13 11:33:27 --> Helper loaded: form_helper
INFO - 2023-12-13 11:33:27 --> Helper loaded: my_helper
INFO - 2023-12-13 11:33:27 --> Database Driver Class Initialized
INFO - 2023-12-13 11:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 11:33:27 --> Controller Class Initialized
DEBUG - 2023-12-13 11:33:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 11:34:01 --> Final output sent to browser
DEBUG - 2023-12-13 11:34:01 --> Total execution time: 34.2659
INFO - 2023-12-13 13:20:46 --> Config Class Initialized
INFO - 2023-12-13 13:20:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:46 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:46 --> URI Class Initialized
INFO - 2023-12-13 13:20:46 --> Router Class Initialized
INFO - 2023-12-13 13:20:46 --> Output Class Initialized
INFO - 2023-12-13 13:20:46 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:46 --> Input Class Initialized
INFO - 2023-12-13 13:20:46 --> Language Class Initialized
INFO - 2023-12-13 13:20:46 --> Language Class Initialized
INFO - 2023-12-13 13:20:46 --> Config Class Initialized
INFO - 2023-12-13 13:20:46 --> Loader Class Initialized
INFO - 2023-12-13 13:20:46 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:46 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:46 --> Controller Class Initialized
DEBUG - 2023-12-13 13:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 13:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:20:46 --> Final output sent to browser
DEBUG - 2023-12-13 13:20:46 --> Total execution time: 0.0744
INFO - 2023-12-13 13:20:46 --> Config Class Initialized
INFO - 2023-12-13 13:20:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:46 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:46 --> URI Class Initialized
INFO - 2023-12-13 13:20:46 --> Router Class Initialized
INFO - 2023-12-13 13:20:46 --> Output Class Initialized
INFO - 2023-12-13 13:20:46 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:46 --> Input Class Initialized
INFO - 2023-12-13 13:20:46 --> Language Class Initialized
INFO - 2023-12-13 13:20:46 --> Language Class Initialized
INFO - 2023-12-13 13:20:46 --> Config Class Initialized
INFO - 2023-12-13 13:20:46 --> Loader Class Initialized
INFO - 2023-12-13 13:20:46 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:46 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:46 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:46 --> Controller Class Initialized
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:49 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:49 --> URI Class Initialized
INFO - 2023-12-13 13:20:49 --> Router Class Initialized
INFO - 2023-12-13 13:20:49 --> Output Class Initialized
INFO - 2023-12-13 13:20:49 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:49 --> Input Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Loader Class Initialized
INFO - 2023-12-13 13:20:49 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:49 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:49 --> Controller Class Initialized
INFO - 2023-12-13 13:20:49 --> Helper loaded: cookie_helper
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:49 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:49 --> URI Class Initialized
INFO - 2023-12-13 13:20:49 --> Router Class Initialized
INFO - 2023-12-13 13:20:49 --> Output Class Initialized
INFO - 2023-12-13 13:20:49 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:49 --> Input Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Loader Class Initialized
INFO - 2023-12-13 13:20:49 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:49 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:49 --> Controller Class Initialized
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:49 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:49 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:49 --> URI Class Initialized
INFO - 2023-12-13 13:20:49 --> Router Class Initialized
INFO - 2023-12-13 13:20:49 --> Output Class Initialized
INFO - 2023-12-13 13:20:49 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:49 --> Input Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Language Class Initialized
INFO - 2023-12-13 13:20:49 --> Config Class Initialized
INFO - 2023-12-13 13:20:49 --> Loader Class Initialized
INFO - 2023-12-13 13:20:49 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:49 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:49 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:49 --> Controller Class Initialized
DEBUG - 2023-12-13 13:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 13:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:20:49 --> Final output sent to browser
DEBUG - 2023-12-13 13:20:49 --> Total execution time: 0.0346
INFO - 2023-12-13 13:20:54 --> Config Class Initialized
INFO - 2023-12-13 13:20:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:20:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:20:54 --> Utf8 Class Initialized
INFO - 2023-12-13 13:20:54 --> URI Class Initialized
INFO - 2023-12-13 13:20:54 --> Router Class Initialized
INFO - 2023-12-13 13:20:54 --> Output Class Initialized
INFO - 2023-12-13 13:20:54 --> Security Class Initialized
DEBUG - 2023-12-13 13:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:20:54 --> Input Class Initialized
INFO - 2023-12-13 13:20:54 --> Language Class Initialized
INFO - 2023-12-13 13:20:54 --> Language Class Initialized
INFO - 2023-12-13 13:20:54 --> Config Class Initialized
INFO - 2023-12-13 13:20:54 --> Loader Class Initialized
INFO - 2023-12-13 13:20:54 --> Helper loaded: url_helper
INFO - 2023-12-13 13:20:54 --> Helper loaded: file_helper
INFO - 2023-12-13 13:20:54 --> Helper loaded: form_helper
INFO - 2023-12-13 13:20:54 --> Helper loaded: my_helper
INFO - 2023-12-13 13:20:54 --> Database Driver Class Initialized
INFO - 2023-12-13 13:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:20:54 --> Controller Class Initialized
INFO - 2023-12-13 13:20:54 --> Final output sent to browser
DEBUG - 2023-12-13 13:20:54 --> Total execution time: 0.0377
INFO - 2023-12-13 13:21:00 --> Config Class Initialized
INFO - 2023-12-13 13:21:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:21:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:21:00 --> Utf8 Class Initialized
INFO - 2023-12-13 13:21:00 --> URI Class Initialized
INFO - 2023-12-13 13:21:00 --> Router Class Initialized
INFO - 2023-12-13 13:21:00 --> Output Class Initialized
INFO - 2023-12-13 13:21:00 --> Security Class Initialized
DEBUG - 2023-12-13 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:21:00 --> Input Class Initialized
INFO - 2023-12-13 13:21:00 --> Language Class Initialized
INFO - 2023-12-13 13:21:00 --> Language Class Initialized
INFO - 2023-12-13 13:21:00 --> Config Class Initialized
INFO - 2023-12-13 13:21:00 --> Loader Class Initialized
INFO - 2023-12-13 13:21:00 --> Helper loaded: url_helper
INFO - 2023-12-13 13:21:00 --> Helper loaded: file_helper
INFO - 2023-12-13 13:21:00 --> Helper loaded: form_helper
INFO - 2023-12-13 13:21:00 --> Helper loaded: my_helper
INFO - 2023-12-13 13:21:00 --> Database Driver Class Initialized
INFO - 2023-12-13 13:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:21:00 --> Controller Class Initialized
DEBUG - 2023-12-13 13:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 13:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:21:00 --> Final output sent to browser
DEBUG - 2023-12-13 13:21:00 --> Total execution time: 0.0721
INFO - 2023-12-13 13:21:08 --> Config Class Initialized
INFO - 2023-12-13 13:21:08 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:21:08 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:21:08 --> Utf8 Class Initialized
INFO - 2023-12-13 13:21:08 --> URI Class Initialized
INFO - 2023-12-13 13:21:08 --> Router Class Initialized
INFO - 2023-12-13 13:21:08 --> Output Class Initialized
INFO - 2023-12-13 13:21:08 --> Security Class Initialized
DEBUG - 2023-12-13 13:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:21:08 --> Input Class Initialized
INFO - 2023-12-13 13:21:08 --> Language Class Initialized
INFO - 2023-12-13 13:21:08 --> Language Class Initialized
INFO - 2023-12-13 13:21:08 --> Config Class Initialized
INFO - 2023-12-13 13:21:08 --> Loader Class Initialized
INFO - 2023-12-13 13:21:08 --> Helper loaded: url_helper
INFO - 2023-12-13 13:21:08 --> Helper loaded: file_helper
INFO - 2023-12-13 13:21:08 --> Helper loaded: form_helper
INFO - 2023-12-13 13:21:08 --> Helper loaded: my_helper
INFO - 2023-12-13 13:21:08 --> Database Driver Class Initialized
INFO - 2023-12-13 13:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:21:08 --> Controller Class Initialized
INFO - 2023-12-13 13:21:08 --> Final output sent to browser
DEBUG - 2023-12-13 13:21:08 --> Total execution time: 0.0352
INFO - 2023-12-13 13:43:36 --> Config Class Initialized
INFO - 2023-12-13 13:43:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:36 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:36 --> URI Class Initialized
DEBUG - 2023-12-13 13:43:36 --> No URI present. Default controller set.
INFO - 2023-12-13 13:43:36 --> Router Class Initialized
INFO - 2023-12-13 13:43:36 --> Output Class Initialized
INFO - 2023-12-13 13:43:36 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:36 --> Input Class Initialized
INFO - 2023-12-13 13:43:36 --> Language Class Initialized
INFO - 2023-12-13 13:43:36 --> Language Class Initialized
INFO - 2023-12-13 13:43:36 --> Config Class Initialized
INFO - 2023-12-13 13:43:36 --> Loader Class Initialized
INFO - 2023-12-13 13:43:36 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:36 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:36 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:36 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:36 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:36 --> Controller Class Initialized
INFO - 2023-12-13 13:43:37 --> Config Class Initialized
INFO - 2023-12-13 13:43:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:37 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:37 --> URI Class Initialized
INFO - 2023-12-13 13:43:37 --> Router Class Initialized
INFO - 2023-12-13 13:43:37 --> Output Class Initialized
INFO - 2023-12-13 13:43:37 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:37 --> Input Class Initialized
INFO - 2023-12-13 13:43:37 --> Language Class Initialized
INFO - 2023-12-13 13:43:37 --> Language Class Initialized
INFO - 2023-12-13 13:43:37 --> Config Class Initialized
INFO - 2023-12-13 13:43:37 --> Loader Class Initialized
INFO - 2023-12-13 13:43:37 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:37 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:37 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:37 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:37 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:37 --> Controller Class Initialized
DEBUG - 2023-12-13 13:43:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 13:43:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:43:37 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:37 --> Total execution time: 0.1386
INFO - 2023-12-13 13:43:39 --> Config Class Initialized
INFO - 2023-12-13 13:43:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:39 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:39 --> URI Class Initialized
INFO - 2023-12-13 13:43:39 --> Router Class Initialized
INFO - 2023-12-13 13:43:39 --> Output Class Initialized
INFO - 2023-12-13 13:43:39 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:39 --> Input Class Initialized
INFO - 2023-12-13 13:43:39 --> Language Class Initialized
INFO - 2023-12-13 13:43:39 --> Language Class Initialized
INFO - 2023-12-13 13:43:39 --> Config Class Initialized
INFO - 2023-12-13 13:43:39 --> Loader Class Initialized
INFO - 2023-12-13 13:43:39 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:39 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:39 --> Controller Class Initialized
INFO - 2023-12-13 13:43:39 --> Helper loaded: cookie_helper
INFO - 2023-12-13 13:43:39 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:39 --> Total execution time: 0.2363
INFO - 2023-12-13 13:43:39 --> Config Class Initialized
INFO - 2023-12-13 13:43:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:39 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:39 --> URI Class Initialized
INFO - 2023-12-13 13:43:39 --> Router Class Initialized
INFO - 2023-12-13 13:43:39 --> Output Class Initialized
INFO - 2023-12-13 13:43:39 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:39 --> Input Class Initialized
INFO - 2023-12-13 13:43:39 --> Language Class Initialized
INFO - 2023-12-13 13:43:39 --> Language Class Initialized
INFO - 2023-12-13 13:43:39 --> Config Class Initialized
INFO - 2023-12-13 13:43:39 --> Loader Class Initialized
INFO - 2023-12-13 13:43:39 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:39 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:39 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:39 --> Controller Class Initialized
DEBUG - 2023-12-13 13:43:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 13:43:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:43:39 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:39 --> Total execution time: 0.1446
INFO - 2023-12-13 13:43:42 --> Config Class Initialized
INFO - 2023-12-13 13:43:42 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:42 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:42 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:42 --> URI Class Initialized
INFO - 2023-12-13 13:43:42 --> Router Class Initialized
INFO - 2023-12-13 13:43:42 --> Output Class Initialized
INFO - 2023-12-13 13:43:42 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:42 --> Input Class Initialized
INFO - 2023-12-13 13:43:42 --> Language Class Initialized
INFO - 2023-12-13 13:43:42 --> Language Class Initialized
INFO - 2023-12-13 13:43:42 --> Config Class Initialized
INFO - 2023-12-13 13:43:42 --> Loader Class Initialized
INFO - 2023-12-13 13:43:42 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:42 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:42 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:42 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:42 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:42 --> Controller Class Initialized
DEBUG - 2023-12-13 13:43:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 13:43:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:43:42 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:42 --> Total execution time: 0.2021
INFO - 2023-12-13 13:43:44 --> Config Class Initialized
INFO - 2023-12-13 13:43:44 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:44 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:44 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:44 --> URI Class Initialized
INFO - 2023-12-13 13:43:44 --> Router Class Initialized
INFO - 2023-12-13 13:43:44 --> Output Class Initialized
INFO - 2023-12-13 13:43:44 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:44 --> Input Class Initialized
INFO - 2023-12-13 13:43:44 --> Language Class Initialized
INFO - 2023-12-13 13:43:44 --> Language Class Initialized
INFO - 2023-12-13 13:43:44 --> Config Class Initialized
INFO - 2023-12-13 13:43:44 --> Loader Class Initialized
INFO - 2023-12-13 13:43:44 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:44 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:44 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:44 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:44 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:44 --> Controller Class Initialized
DEBUG - 2023-12-13 13:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 13:43:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 13:43:44 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:44 --> Total execution time: 0.2453
INFO - 2023-12-13 13:43:45 --> Config Class Initialized
INFO - 2023-12-13 13:43:45 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:45 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:45 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:45 --> URI Class Initialized
INFO - 2023-12-13 13:43:45 --> Router Class Initialized
INFO - 2023-12-13 13:43:45 --> Output Class Initialized
INFO - 2023-12-13 13:43:45 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:45 --> Input Class Initialized
INFO - 2023-12-13 13:43:45 --> Language Class Initialized
INFO - 2023-12-13 13:43:45 --> Language Class Initialized
INFO - 2023-12-13 13:43:45 --> Config Class Initialized
INFO - 2023-12-13 13:43:45 --> Loader Class Initialized
INFO - 2023-12-13 13:43:45 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:45 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:45 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:45 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:45 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:45 --> Controller Class Initialized
INFO - 2023-12-13 13:43:48 --> Config Class Initialized
INFO - 2023-12-13 13:43:48 --> Hooks Class Initialized
DEBUG - 2023-12-13 13:43:48 --> UTF-8 Support Enabled
INFO - 2023-12-13 13:43:48 --> Utf8 Class Initialized
INFO - 2023-12-13 13:43:48 --> URI Class Initialized
INFO - 2023-12-13 13:43:48 --> Router Class Initialized
INFO - 2023-12-13 13:43:48 --> Output Class Initialized
INFO - 2023-12-13 13:43:48 --> Security Class Initialized
DEBUG - 2023-12-13 13:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 13:43:48 --> Input Class Initialized
INFO - 2023-12-13 13:43:48 --> Language Class Initialized
INFO - 2023-12-13 13:43:48 --> Language Class Initialized
INFO - 2023-12-13 13:43:48 --> Config Class Initialized
INFO - 2023-12-13 13:43:48 --> Loader Class Initialized
INFO - 2023-12-13 13:43:48 --> Helper loaded: url_helper
INFO - 2023-12-13 13:43:48 --> Helper loaded: file_helper
INFO - 2023-12-13 13:43:48 --> Helper loaded: form_helper
INFO - 2023-12-13 13:43:48 --> Helper loaded: my_helper
INFO - 2023-12-13 13:43:48 --> Database Driver Class Initialized
INFO - 2023-12-13 13:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 13:43:48 --> Controller Class Initialized
DEBUG - 2023-12-13 13:43:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-13 13:43:48 --> Final output sent to browser
DEBUG - 2023-12-13 13:43:48 --> Total execution time: 0.1249
INFO - 2023-12-13 14:29:19 --> Config Class Initialized
INFO - 2023-12-13 14:29:19 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:19 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:19 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:19 --> URI Class Initialized
INFO - 2023-12-13 14:29:19 --> Router Class Initialized
INFO - 2023-12-13 14:29:19 --> Output Class Initialized
INFO - 2023-12-13 14:29:19 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:19 --> Input Class Initialized
INFO - 2023-12-13 14:29:19 --> Language Class Initialized
INFO - 2023-12-13 14:29:19 --> Language Class Initialized
INFO - 2023-12-13 14:29:19 --> Config Class Initialized
INFO - 2023-12-13 14:29:19 --> Loader Class Initialized
INFO - 2023-12-13 14:29:19 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:19 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:19 --> Controller Class Initialized
INFO - 2023-12-13 14:29:19 --> Config Class Initialized
INFO - 2023-12-13 14:29:19 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:19 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:19 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:19 --> URI Class Initialized
INFO - 2023-12-13 14:29:19 --> Router Class Initialized
INFO - 2023-12-13 14:29:19 --> Output Class Initialized
INFO - 2023-12-13 14:29:19 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:19 --> Input Class Initialized
INFO - 2023-12-13 14:29:19 --> Language Class Initialized
INFO - 2023-12-13 14:29:19 --> Language Class Initialized
INFO - 2023-12-13 14:29:19 --> Config Class Initialized
INFO - 2023-12-13 14:29:19 --> Loader Class Initialized
INFO - 2023-12-13 14:29:19 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:19 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:19 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:19 --> Controller Class Initialized
DEBUG - 2023-12-13 14:29:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 14:29:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:29:19 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:19 --> Total execution time: 0.1180
INFO - 2023-12-13 14:29:22 --> Config Class Initialized
INFO - 2023-12-13 14:29:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:22 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:22 --> URI Class Initialized
INFO - 2023-12-13 14:29:22 --> Router Class Initialized
INFO - 2023-12-13 14:29:22 --> Output Class Initialized
INFO - 2023-12-13 14:29:22 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:22 --> Input Class Initialized
INFO - 2023-12-13 14:29:22 --> Language Class Initialized
INFO - 2023-12-13 14:29:22 --> Language Class Initialized
INFO - 2023-12-13 14:29:22 --> Config Class Initialized
INFO - 2023-12-13 14:29:22 --> Loader Class Initialized
INFO - 2023-12-13 14:29:22 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:22 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:22 --> Controller Class Initialized
INFO - 2023-12-13 14:29:22 --> Helper loaded: cookie_helper
INFO - 2023-12-13 14:29:22 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:22 --> Total execution time: 0.1524
INFO - 2023-12-13 14:29:22 --> Config Class Initialized
INFO - 2023-12-13 14:29:22 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:22 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:22 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:22 --> URI Class Initialized
INFO - 2023-12-13 14:29:22 --> Router Class Initialized
INFO - 2023-12-13 14:29:22 --> Output Class Initialized
INFO - 2023-12-13 14:29:22 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:22 --> Input Class Initialized
INFO - 2023-12-13 14:29:22 --> Language Class Initialized
INFO - 2023-12-13 14:29:22 --> Language Class Initialized
INFO - 2023-12-13 14:29:22 --> Config Class Initialized
INFO - 2023-12-13 14:29:22 --> Loader Class Initialized
INFO - 2023-12-13 14:29:22 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:22 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:22 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:22 --> Controller Class Initialized
DEBUG - 2023-12-13 14:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 14:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:29:22 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:22 --> Total execution time: 0.1665
INFO - 2023-12-13 14:29:26 --> Config Class Initialized
INFO - 2023-12-13 14:29:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:26 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:26 --> URI Class Initialized
INFO - 2023-12-13 14:29:26 --> Router Class Initialized
INFO - 2023-12-13 14:29:26 --> Output Class Initialized
INFO - 2023-12-13 14:29:26 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:26 --> Input Class Initialized
INFO - 2023-12-13 14:29:26 --> Language Class Initialized
INFO - 2023-12-13 14:29:26 --> Language Class Initialized
INFO - 2023-12-13 14:29:26 --> Config Class Initialized
INFO - 2023-12-13 14:29:26 --> Loader Class Initialized
INFO - 2023-12-13 14:29:26 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:26 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:26 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:26 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:26 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:26 --> Controller Class Initialized
DEBUG - 2023-12-13 14:29:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 14:29:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:29:26 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:26 --> Total execution time: 0.1099
INFO - 2023-12-13 14:29:29 --> Config Class Initialized
INFO - 2023-12-13 14:29:29 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:29 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:29 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:29 --> URI Class Initialized
INFO - 2023-12-13 14:29:29 --> Router Class Initialized
INFO - 2023-12-13 14:29:29 --> Output Class Initialized
INFO - 2023-12-13 14:29:29 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:29 --> Input Class Initialized
INFO - 2023-12-13 14:29:29 --> Language Class Initialized
INFO - 2023-12-13 14:29:29 --> Language Class Initialized
INFO - 2023-12-13 14:29:29 --> Config Class Initialized
INFO - 2023-12-13 14:29:29 --> Loader Class Initialized
INFO - 2023-12-13 14:29:29 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:29 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:29 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:29 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:29 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:29 --> Controller Class Initialized
DEBUG - 2023-12-13 14:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 14:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:29:29 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:29 --> Total execution time: 0.0460
INFO - 2023-12-13 14:29:37 --> Config Class Initialized
INFO - 2023-12-13 14:29:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:29:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:29:37 --> Utf8 Class Initialized
INFO - 2023-12-13 14:29:37 --> URI Class Initialized
INFO - 2023-12-13 14:29:37 --> Router Class Initialized
INFO - 2023-12-13 14:29:37 --> Output Class Initialized
INFO - 2023-12-13 14:29:37 --> Security Class Initialized
DEBUG - 2023-12-13 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:29:37 --> Input Class Initialized
INFO - 2023-12-13 14:29:37 --> Language Class Initialized
INFO - 2023-12-13 14:29:37 --> Language Class Initialized
INFO - 2023-12-13 14:29:37 --> Config Class Initialized
INFO - 2023-12-13 14:29:37 --> Loader Class Initialized
INFO - 2023-12-13 14:29:37 --> Helper loaded: url_helper
INFO - 2023-12-13 14:29:37 --> Helper loaded: file_helper
INFO - 2023-12-13 14:29:37 --> Helper loaded: form_helper
INFO - 2023-12-13 14:29:37 --> Helper loaded: my_helper
INFO - 2023-12-13 14:29:37 --> Database Driver Class Initialized
INFO - 2023-12-13 14:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:29:37 --> Controller Class Initialized
INFO - 2023-12-13 14:29:37 --> Final output sent to browser
DEBUG - 2023-12-13 14:29:37 --> Total execution time: 0.0988
INFO - 2023-12-13 14:30:19 --> Config Class Initialized
INFO - 2023-12-13 14:30:19 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:19 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:19 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:19 --> URI Class Initialized
DEBUG - 2023-12-13 14:30:19 --> No URI present. Default controller set.
INFO - 2023-12-13 14:30:19 --> Router Class Initialized
INFO - 2023-12-13 14:30:19 --> Output Class Initialized
INFO - 2023-12-13 14:30:19 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:19 --> Input Class Initialized
INFO - 2023-12-13 14:30:19 --> Language Class Initialized
INFO - 2023-12-13 14:30:19 --> Language Class Initialized
INFO - 2023-12-13 14:30:19 --> Config Class Initialized
INFO - 2023-12-13 14:30:19 --> Loader Class Initialized
INFO - 2023-12-13 14:30:19 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:19 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:19 --> Controller Class Initialized
INFO - 2023-12-13 14:30:19 --> Config Class Initialized
INFO - 2023-12-13 14:30:19 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:19 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:19 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:19 --> URI Class Initialized
INFO - 2023-12-13 14:30:19 --> Router Class Initialized
INFO - 2023-12-13 14:30:19 --> Output Class Initialized
INFO - 2023-12-13 14:30:19 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:19 --> Input Class Initialized
INFO - 2023-12-13 14:30:19 --> Language Class Initialized
INFO - 2023-12-13 14:30:19 --> Language Class Initialized
INFO - 2023-12-13 14:30:19 --> Config Class Initialized
INFO - 2023-12-13 14:30:19 --> Loader Class Initialized
INFO - 2023-12-13 14:30:19 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:19 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:19 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:19 --> Controller Class Initialized
DEBUG - 2023-12-13 14:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 14:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:30:19 --> Final output sent to browser
DEBUG - 2023-12-13 14:30:19 --> Total execution time: 0.0601
INFO - 2023-12-13 14:30:28 --> Config Class Initialized
INFO - 2023-12-13 14:30:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:28 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:28 --> URI Class Initialized
INFO - 2023-12-13 14:30:28 --> Router Class Initialized
INFO - 2023-12-13 14:30:28 --> Output Class Initialized
INFO - 2023-12-13 14:30:28 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:28 --> Input Class Initialized
INFO - 2023-12-13 14:30:28 --> Language Class Initialized
INFO - 2023-12-13 14:30:28 --> Language Class Initialized
INFO - 2023-12-13 14:30:28 --> Config Class Initialized
INFO - 2023-12-13 14:30:28 --> Loader Class Initialized
INFO - 2023-12-13 14:30:28 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:28 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:28 --> Controller Class Initialized
INFO - 2023-12-13 14:30:28 --> Helper loaded: cookie_helper
INFO - 2023-12-13 14:30:28 --> Final output sent to browser
DEBUG - 2023-12-13 14:30:28 --> Total execution time: 0.0480
INFO - 2023-12-13 14:30:28 --> Config Class Initialized
INFO - 2023-12-13 14:30:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:28 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:28 --> URI Class Initialized
INFO - 2023-12-13 14:30:28 --> Router Class Initialized
INFO - 2023-12-13 14:30:28 --> Output Class Initialized
INFO - 2023-12-13 14:30:28 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:28 --> Input Class Initialized
INFO - 2023-12-13 14:30:28 --> Language Class Initialized
INFO - 2023-12-13 14:30:28 --> Language Class Initialized
INFO - 2023-12-13 14:30:28 --> Config Class Initialized
INFO - 2023-12-13 14:30:28 --> Loader Class Initialized
INFO - 2023-12-13 14:30:28 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:28 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:28 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:28 --> Controller Class Initialized
DEBUG - 2023-12-13 14:30:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 14:30:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:30:28 --> Final output sent to browser
DEBUG - 2023-12-13 14:30:28 --> Total execution time: 0.0736
INFO - 2023-12-13 14:30:34 --> Config Class Initialized
INFO - 2023-12-13 14:30:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:34 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:34 --> URI Class Initialized
INFO - 2023-12-13 14:30:34 --> Router Class Initialized
INFO - 2023-12-13 14:30:34 --> Output Class Initialized
INFO - 2023-12-13 14:30:34 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:34 --> Input Class Initialized
INFO - 2023-12-13 14:30:34 --> Language Class Initialized
INFO - 2023-12-13 14:30:34 --> Language Class Initialized
INFO - 2023-12-13 14:30:34 --> Config Class Initialized
INFO - 2023-12-13 14:30:34 --> Loader Class Initialized
INFO - 2023-12-13 14:30:34 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:34 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:34 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:34 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:34 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:34 --> Controller Class Initialized
DEBUG - 2023-12-13 14:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 14:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:30:34 --> Final output sent to browser
DEBUG - 2023-12-13 14:30:34 --> Total execution time: 0.4113
INFO - 2023-12-13 14:30:36 --> Config Class Initialized
INFO - 2023-12-13 14:30:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:36 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:36 --> URI Class Initialized
INFO - 2023-12-13 14:30:36 --> Router Class Initialized
INFO - 2023-12-13 14:30:36 --> Output Class Initialized
INFO - 2023-12-13 14:30:36 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:36 --> Input Class Initialized
INFO - 2023-12-13 14:30:36 --> Language Class Initialized
INFO - 2023-12-13 14:30:36 --> Language Class Initialized
INFO - 2023-12-13 14:30:36 --> Config Class Initialized
INFO - 2023-12-13 14:30:36 --> Loader Class Initialized
INFO - 2023-12-13 14:30:36 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:36 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:36 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:36 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:36 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:37 --> Controller Class Initialized
DEBUG - 2023-12-13 14:30:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-13 14:30:38 --> Config Class Initialized
INFO - 2023-12-13 14:30:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:38 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:38 --> URI Class Initialized
INFO - 2023-12-13 14:30:38 --> Router Class Initialized
INFO - 2023-12-13 14:30:38 --> Output Class Initialized
INFO - 2023-12-13 14:30:38 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:38 --> Input Class Initialized
INFO - 2023-12-13 14:30:38 --> Language Class Initialized
INFO - 2023-12-13 14:30:39 --> Language Class Initialized
INFO - 2023-12-13 14:30:39 --> Config Class Initialized
INFO - 2023-12-13 14:30:39 --> Loader Class Initialized
INFO - 2023-12-13 14:30:39 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:39 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:39 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:39 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:39 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:44 --> Config Class Initialized
INFO - 2023-12-13 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:44 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:44 --> URI Class Initialized
INFO - 2023-12-13 14:30:44 --> Router Class Initialized
INFO - 2023-12-13 14:30:44 --> Output Class Initialized
INFO - 2023-12-13 14:30:44 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:44 --> Input Class Initialized
INFO - 2023-12-13 14:30:44 --> Language Class Initialized
INFO - 2023-12-13 14:30:44 --> Language Class Initialized
INFO - 2023-12-13 14:30:44 --> Config Class Initialized
INFO - 2023-12-13 14:30:44 --> Loader Class Initialized
INFO - 2023-12-13 14:30:44 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:44 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:44 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:44 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:44 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:46 --> Config Class Initialized
INFO - 2023-12-13 14:30:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:30:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:30:46 --> Utf8 Class Initialized
INFO - 2023-12-13 14:30:46 --> URI Class Initialized
INFO - 2023-12-13 14:30:46 --> Router Class Initialized
INFO - 2023-12-13 14:30:46 --> Output Class Initialized
INFO - 2023-12-13 14:30:46 --> Security Class Initialized
DEBUG - 2023-12-13 14:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:30:46 --> Input Class Initialized
INFO - 2023-12-13 14:30:46 --> Language Class Initialized
INFO - 2023-12-13 14:30:46 --> Language Class Initialized
INFO - 2023-12-13 14:30:46 --> Config Class Initialized
INFO - 2023-12-13 14:30:46 --> Loader Class Initialized
INFO - 2023-12-13 14:30:46 --> Helper loaded: url_helper
INFO - 2023-12-13 14:30:46 --> Helper loaded: file_helper
INFO - 2023-12-13 14:30:46 --> Helper loaded: form_helper
INFO - 2023-12-13 14:30:46 --> Helper loaded: my_helper
INFO - 2023-12-13 14:30:46 --> Database Driver Class Initialized
INFO - 2023-12-13 14:30:58 --> Final output sent to browser
DEBUG - 2023-12-13 14:30:58 --> Total execution time: 21.4877
INFO - 2023-12-13 14:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:30:58 --> Controller Class Initialized
DEBUG - 2023-12-13 14:30:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:31:38 --> Final output sent to browser
DEBUG - 2023-12-13 14:31:38 --> Total execution time: 59.7591
INFO - 2023-12-13 14:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:31:38 --> Controller Class Initialized
DEBUG - 2023-12-13 14:31:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-13 14:31:50 --> Final output sent to browser
DEBUG - 2023-12-13 14:31:50 --> Total execution time: 66.1193
INFO - 2023-12-13 14:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:31:50 --> Controller Class Initialized
DEBUG - 2023-12-13 14:31:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:32:17 --> Config Class Initialized
INFO - 2023-12-13 14:32:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:32:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:32:17 --> Utf8 Class Initialized
INFO - 2023-12-13 14:32:17 --> URI Class Initialized
INFO - 2023-12-13 14:32:17 --> Router Class Initialized
INFO - 2023-12-13 14:32:17 --> Output Class Initialized
INFO - 2023-12-13 14:32:17 --> Security Class Initialized
DEBUG - 2023-12-13 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:32:17 --> Input Class Initialized
INFO - 2023-12-13 14:32:17 --> Language Class Initialized
INFO - 2023-12-13 14:32:17 --> Language Class Initialized
INFO - 2023-12-13 14:32:17 --> Config Class Initialized
INFO - 2023-12-13 14:32:17 --> Loader Class Initialized
INFO - 2023-12-13 14:32:17 --> Helper loaded: url_helper
INFO - 2023-12-13 14:32:17 --> Helper loaded: file_helper
INFO - 2023-12-13 14:32:17 --> Helper loaded: form_helper
INFO - 2023-12-13 14:32:17 --> Helper loaded: my_helper
INFO - 2023-12-13 14:32:17 --> Database Driver Class Initialized
INFO - 2023-12-13 14:32:26 --> Final output sent to browser
DEBUG - 2023-12-13 14:32:26 --> Total execution time: 99.7078
INFO - 2023-12-13 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:32:26 --> Controller Class Initialized
DEBUG - 2023-12-13 14:32:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:32:35 --> Final output sent to browser
DEBUG - 2023-12-13 14:32:35 --> Total execution time: 17.9864
INFO - 2023-12-13 14:32:55 --> Config Class Initialized
INFO - 2023-12-13 14:32:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:32:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:32:55 --> Utf8 Class Initialized
INFO - 2023-12-13 14:32:55 --> URI Class Initialized
INFO - 2023-12-13 14:32:55 --> Router Class Initialized
INFO - 2023-12-13 14:32:55 --> Output Class Initialized
INFO - 2023-12-13 14:32:55 --> Security Class Initialized
DEBUG - 2023-12-13 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:32:55 --> Input Class Initialized
INFO - 2023-12-13 14:32:55 --> Language Class Initialized
INFO - 2023-12-13 14:32:55 --> Language Class Initialized
INFO - 2023-12-13 14:32:55 --> Config Class Initialized
INFO - 2023-12-13 14:32:55 --> Loader Class Initialized
INFO - 2023-12-13 14:32:55 --> Helper loaded: url_helper
INFO - 2023-12-13 14:32:55 --> Helper loaded: file_helper
INFO - 2023-12-13 14:32:55 --> Helper loaded: form_helper
INFO - 2023-12-13 14:32:55 --> Helper loaded: my_helper
INFO - 2023-12-13 14:32:55 --> Database Driver Class Initialized
INFO - 2023-12-13 14:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:32:55 --> Controller Class Initialized
DEBUG - 2023-12-13 14:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:33:05 --> Final output sent to browser
DEBUG - 2023-12-13 14:33:05 --> Total execution time: 10.4030
INFO - 2023-12-13 14:33:46 --> Config Class Initialized
INFO - 2023-12-13 14:33:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:33:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:33:46 --> Utf8 Class Initialized
INFO - 2023-12-13 14:33:46 --> URI Class Initialized
INFO - 2023-12-13 14:33:46 --> Router Class Initialized
INFO - 2023-12-13 14:33:46 --> Output Class Initialized
INFO - 2023-12-13 14:33:46 --> Security Class Initialized
DEBUG - 2023-12-13 14:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:33:46 --> Input Class Initialized
INFO - 2023-12-13 14:33:46 --> Language Class Initialized
INFO - 2023-12-13 14:33:46 --> Language Class Initialized
INFO - 2023-12-13 14:33:46 --> Config Class Initialized
INFO - 2023-12-13 14:33:46 --> Loader Class Initialized
INFO - 2023-12-13 14:33:46 --> Helper loaded: url_helper
INFO - 2023-12-13 14:33:46 --> Helper loaded: file_helper
INFO - 2023-12-13 14:33:46 --> Helper loaded: form_helper
INFO - 2023-12-13 14:33:46 --> Helper loaded: my_helper
INFO - 2023-12-13 14:33:46 --> Database Driver Class Initialized
INFO - 2023-12-13 14:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:33:46 --> Controller Class Initialized
ERROR - 2023-12-13 14:33:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:33:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:06 --> Config Class Initialized
INFO - 2023-12-13 14:34:06 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:06 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:06 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:06 --> URI Class Initialized
INFO - 2023-12-13 14:34:06 --> Router Class Initialized
INFO - 2023-12-13 14:34:06 --> Output Class Initialized
INFO - 2023-12-13 14:34:06 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:06 --> Input Class Initialized
INFO - 2023-12-13 14:34:06 --> Language Class Initialized
INFO - 2023-12-13 14:34:06 --> Language Class Initialized
INFO - 2023-12-13 14:34:06 --> Config Class Initialized
INFO - 2023-12-13 14:34:06 --> Loader Class Initialized
INFO - 2023-12-13 14:34:06 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:06 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:06 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:06 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:06 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:06 --> Controller Class Initialized
ERROR - 2023-12-13 14:34:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:34:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:10 --> Config Class Initialized
INFO - 2023-12-13 14:34:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:10 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:10 --> URI Class Initialized
INFO - 2023-12-13 14:34:10 --> Router Class Initialized
INFO - 2023-12-13 14:34:10 --> Output Class Initialized
INFO - 2023-12-13 14:34:10 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:10 --> Input Class Initialized
INFO - 2023-12-13 14:34:10 --> Language Class Initialized
INFO - 2023-12-13 14:34:10 --> Language Class Initialized
INFO - 2023-12-13 14:34:10 --> Config Class Initialized
INFO - 2023-12-13 14:34:10 --> Loader Class Initialized
INFO - 2023-12-13 14:34:10 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:10 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:10 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:10 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:10 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:10 --> Controller Class Initialized
ERROR - 2023-12-13 14:34:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:34:10 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:43 --> Config Class Initialized
INFO - 2023-12-13 14:34:43 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:43 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:43 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:43 --> URI Class Initialized
INFO - 2023-12-13 14:34:43 --> Router Class Initialized
INFO - 2023-12-13 14:34:43 --> Output Class Initialized
INFO - 2023-12-13 14:34:43 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:43 --> Input Class Initialized
INFO - 2023-12-13 14:34:43 --> Language Class Initialized
INFO - 2023-12-13 14:34:43 --> Language Class Initialized
INFO - 2023-12-13 14:34:43 --> Config Class Initialized
INFO - 2023-12-13 14:34:43 --> Loader Class Initialized
INFO - 2023-12-13 14:34:43 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:43 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:43 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:43 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:43 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:43 --> Controller Class Initialized
ERROR - 2023-12-13 14:34:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:34:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:44 --> Config Class Initialized
INFO - 2023-12-13 14:34:44 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:44 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:44 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:44 --> URI Class Initialized
INFO - 2023-12-13 14:34:44 --> Router Class Initialized
INFO - 2023-12-13 14:34:44 --> Output Class Initialized
INFO - 2023-12-13 14:34:44 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:44 --> Input Class Initialized
INFO - 2023-12-13 14:34:44 --> Language Class Initialized
INFO - 2023-12-13 14:34:44 --> Language Class Initialized
INFO - 2023-12-13 14:34:44 --> Config Class Initialized
INFO - 2023-12-13 14:34:44 --> Loader Class Initialized
INFO - 2023-12-13 14:34:44 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:44 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:44 --> Controller Class Initialized
INFO - 2023-12-13 14:34:44 --> Config Class Initialized
INFO - 2023-12-13 14:34:44 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:44 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:44 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:44 --> URI Class Initialized
INFO - 2023-12-13 14:34:44 --> Router Class Initialized
INFO - 2023-12-13 14:34:44 --> Output Class Initialized
INFO - 2023-12-13 14:34:44 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:44 --> Input Class Initialized
INFO - 2023-12-13 14:34:44 --> Language Class Initialized
ERROR - 2023-12-13 14:34:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:34:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:44 --> Language Class Initialized
INFO - 2023-12-13 14:34:44 --> Config Class Initialized
INFO - 2023-12-13 14:34:44 --> Loader Class Initialized
INFO - 2023-12-13 14:34:44 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:44 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:44 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:44 --> Controller Class Initialized
ERROR - 2023-12-13 14:34:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:34:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:34:47 --> Config Class Initialized
INFO - 2023-12-13 14:34:47 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:47 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:47 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:47 --> URI Class Initialized
INFO - 2023-12-13 14:34:47 --> Router Class Initialized
INFO - 2023-12-13 14:34:47 --> Output Class Initialized
INFO - 2023-12-13 14:34:47 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:47 --> Input Class Initialized
INFO - 2023-12-13 14:34:47 --> Language Class Initialized
INFO - 2023-12-13 14:34:47 --> Language Class Initialized
INFO - 2023-12-13 14:34:47 --> Config Class Initialized
INFO - 2023-12-13 14:34:47 --> Loader Class Initialized
INFO - 2023-12-13 14:34:47 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:47 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:47 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:47 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:47 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:47 --> Controller Class Initialized
DEBUG - 2023-12-13 14:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 14:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:34:47 --> Final output sent to browser
DEBUG - 2023-12-13 14:34:47 --> Total execution time: 0.2473
INFO - 2023-12-13 14:34:58 --> Config Class Initialized
INFO - 2023-12-13 14:34:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:34:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:34:58 --> Utf8 Class Initialized
INFO - 2023-12-13 14:34:58 --> URI Class Initialized
INFO - 2023-12-13 14:34:58 --> Router Class Initialized
INFO - 2023-12-13 14:34:58 --> Output Class Initialized
INFO - 2023-12-13 14:34:58 --> Security Class Initialized
DEBUG - 2023-12-13 14:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:34:58 --> Input Class Initialized
INFO - 2023-12-13 14:34:58 --> Language Class Initialized
INFO - 2023-12-13 14:34:58 --> Language Class Initialized
INFO - 2023-12-13 14:34:58 --> Config Class Initialized
INFO - 2023-12-13 14:34:58 --> Loader Class Initialized
INFO - 2023-12-13 14:34:58 --> Helper loaded: url_helper
INFO - 2023-12-13 14:34:58 --> Helper loaded: file_helper
INFO - 2023-12-13 14:34:58 --> Helper loaded: form_helper
INFO - 2023-12-13 14:34:58 --> Helper loaded: my_helper
INFO - 2023-12-13 14:34:58 --> Database Driver Class Initialized
INFO - 2023-12-13 14:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:34:58 --> Controller Class Initialized
INFO - 2023-12-13 14:34:58 --> Final output sent to browser
DEBUG - 2023-12-13 14:34:58 --> Total execution time: 0.1674
INFO - 2023-12-13 14:35:05 --> Config Class Initialized
INFO - 2023-12-13 14:35:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:35:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:35:05 --> Utf8 Class Initialized
INFO - 2023-12-13 14:35:05 --> URI Class Initialized
INFO - 2023-12-13 14:35:05 --> Router Class Initialized
INFO - 2023-12-13 14:35:05 --> Output Class Initialized
INFO - 2023-12-13 14:35:05 --> Security Class Initialized
DEBUG - 2023-12-13 14:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:35:05 --> Input Class Initialized
INFO - 2023-12-13 14:35:05 --> Language Class Initialized
INFO - 2023-12-13 14:35:05 --> Language Class Initialized
INFO - 2023-12-13 14:35:05 --> Config Class Initialized
INFO - 2023-12-13 14:35:05 --> Loader Class Initialized
INFO - 2023-12-13 14:35:05 --> Helper loaded: url_helper
INFO - 2023-12-13 14:35:05 --> Helper loaded: file_helper
INFO - 2023-12-13 14:35:05 --> Helper loaded: form_helper
INFO - 2023-12-13 14:35:05 --> Helper loaded: my_helper
INFO - 2023-12-13 14:35:05 --> Database Driver Class Initialized
INFO - 2023-12-13 14:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:35:05 --> Controller Class Initialized
ERROR - 2023-12-13 14:35:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:35:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:35:21 --> Config Class Initialized
INFO - 2023-12-13 14:35:21 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:35:21 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:35:21 --> Utf8 Class Initialized
INFO - 2023-12-13 14:35:21 --> URI Class Initialized
INFO - 2023-12-13 14:35:21 --> Router Class Initialized
INFO - 2023-12-13 14:35:21 --> Output Class Initialized
INFO - 2023-12-13 14:35:21 --> Security Class Initialized
DEBUG - 2023-12-13 14:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:35:21 --> Input Class Initialized
INFO - 2023-12-13 14:35:21 --> Language Class Initialized
INFO - 2023-12-13 14:35:21 --> Language Class Initialized
INFO - 2023-12-13 14:35:21 --> Config Class Initialized
INFO - 2023-12-13 14:35:21 --> Loader Class Initialized
INFO - 2023-12-13 14:35:21 --> Helper loaded: url_helper
INFO - 2023-12-13 14:35:21 --> Helper loaded: file_helper
INFO - 2023-12-13 14:35:21 --> Helper loaded: form_helper
INFO - 2023-12-13 14:35:21 --> Helper loaded: my_helper
INFO - 2023-12-13 14:35:21 --> Database Driver Class Initialized
INFO - 2023-12-13 14:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:35:21 --> Controller Class Initialized
DEBUG - 2023-12-13 14:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 14:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:35:21 --> Final output sent to browser
DEBUG - 2023-12-13 14:35:21 --> Total execution time: 0.1096
INFO - 2023-12-13 14:35:26 --> Config Class Initialized
INFO - 2023-12-13 14:35:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:35:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:35:26 --> Utf8 Class Initialized
INFO - 2023-12-13 14:35:26 --> URI Class Initialized
INFO - 2023-12-13 14:35:26 --> Config Class Initialized
INFO - 2023-12-13 14:35:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:35:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:35:26 --> Utf8 Class Initialized
INFO - 2023-12-13 14:35:26 --> URI Class Initialized
INFO - 2023-12-13 14:35:26 --> Router Class Initialized
INFO - 2023-12-13 14:35:26 --> Output Class Initialized
INFO - 2023-12-13 14:35:26 --> Security Class Initialized
DEBUG - 2023-12-13 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:35:26 --> Input Class Initialized
INFO - 2023-12-13 14:35:26 --> Language Class Initialized
INFO - 2023-12-13 14:35:26 --> Router Class Initialized
INFO - 2023-12-13 14:35:26 --> Output Class Initialized
INFO - 2023-12-13 14:35:26 --> Security Class Initialized
DEBUG - 2023-12-13 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:35:26 --> Input Class Initialized
INFO - 2023-12-13 14:35:26 --> Language Class Initialized
INFO - 2023-12-13 14:35:26 --> Language Class Initialized
INFO - 2023-12-13 14:35:26 --> Config Class Initialized
INFO - 2023-12-13 14:35:26 --> Loader Class Initialized
INFO - 2023-12-13 14:35:26 --> Language Class Initialized
INFO - 2023-12-13 14:35:26 --> Config Class Initialized
INFO - 2023-12-13 14:35:26 --> Loader Class Initialized
INFO - 2023-12-13 14:35:26 --> Helper loaded: url_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: file_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: form_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: url_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: file_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: form_helper
INFO - 2023-12-13 14:35:26 --> Helper loaded: my_helper
INFO - 2023-12-13 14:35:26 --> Database Driver Class Initialized
INFO - 2023-12-13 14:35:26 --> Helper loaded: my_helper
INFO - 2023-12-13 14:35:26 --> Database Driver Class Initialized
INFO - 2023-12-13 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:35:26 --> Controller Class Initialized
DEBUG - 2023-12-13 14:35:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:35:40 --> Final output sent to browser
DEBUG - 2023-12-13 14:35:40 --> Total execution time: 14.2864
INFO - 2023-12-13 14:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:35:40 --> Controller Class Initialized
DEBUG - 2023-12-13 14:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 14:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:35:40 --> Final output sent to browser
DEBUG - 2023-12-13 14:35:40 --> Total execution time: 14.3234
INFO - 2023-12-13 14:36:07 --> Config Class Initialized
INFO - 2023-12-13 14:36:07 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:07 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:07 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:07 --> URI Class Initialized
INFO - 2023-12-13 14:36:07 --> Router Class Initialized
INFO - 2023-12-13 14:36:07 --> Output Class Initialized
INFO - 2023-12-13 14:36:07 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:07 --> Input Class Initialized
INFO - 2023-12-13 14:36:07 --> Language Class Initialized
INFO - 2023-12-13 14:36:07 --> Language Class Initialized
INFO - 2023-12-13 14:36:07 --> Config Class Initialized
INFO - 2023-12-13 14:36:07 --> Loader Class Initialized
INFO - 2023-12-13 14:36:07 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:07 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:07 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:07 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:07 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:07 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:35 --> Config Class Initialized
INFO - 2023-12-13 14:36:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:35 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:35 --> URI Class Initialized
INFO - 2023-12-13 14:36:35 --> Router Class Initialized
INFO - 2023-12-13 14:36:35 --> Output Class Initialized
INFO - 2023-12-13 14:36:35 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:35 --> Input Class Initialized
INFO - 2023-12-13 14:36:35 --> Language Class Initialized
INFO - 2023-12-13 14:36:35 --> Language Class Initialized
INFO - 2023-12-13 14:36:35 --> Config Class Initialized
INFO - 2023-12-13 14:36:35 --> Loader Class Initialized
INFO - 2023-12-13 14:36:35 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:35 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:35 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:35 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:35 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:35 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:37 --> Config Class Initialized
INFO - 2023-12-13 14:36:37 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:37 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:37 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:37 --> URI Class Initialized
INFO - 2023-12-13 14:36:37 --> Router Class Initialized
INFO - 2023-12-13 14:36:37 --> Output Class Initialized
INFO - 2023-12-13 14:36:37 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:37 --> Input Class Initialized
INFO - 2023-12-13 14:36:37 --> Language Class Initialized
INFO - 2023-12-13 14:36:37 --> Language Class Initialized
INFO - 2023-12-13 14:36:37 --> Config Class Initialized
INFO - 2023-12-13 14:36:37 --> Loader Class Initialized
INFO - 2023-12-13 14:36:37 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:37 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:37 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:37 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:37 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:37 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:37 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:38 --> Config Class Initialized
INFO - 2023-12-13 14:36:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:38 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:38 --> URI Class Initialized
INFO - 2023-12-13 14:36:38 --> Router Class Initialized
INFO - 2023-12-13 14:36:38 --> Output Class Initialized
INFO - 2023-12-13 14:36:38 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:38 --> Input Class Initialized
INFO - 2023-12-13 14:36:38 --> Language Class Initialized
INFO - 2023-12-13 14:36:38 --> Language Class Initialized
INFO - 2023-12-13 14:36:38 --> Config Class Initialized
INFO - 2023-12-13 14:36:38 --> Loader Class Initialized
INFO - 2023-12-13 14:36:38 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:38 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:38 --> Controller Class Initialized
INFO - 2023-12-13 14:36:38 --> Config Class Initialized
INFO - 2023-12-13 14:36:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:38 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:38 --> URI Class Initialized
INFO - 2023-12-13 14:36:38 --> Router Class Initialized
INFO - 2023-12-13 14:36:38 --> Output Class Initialized
INFO - 2023-12-13 14:36:38 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:38 --> Input Class Initialized
INFO - 2023-12-13 14:36:38 --> Language Class Initialized
INFO - 2023-12-13 14:36:38 --> Language Class Initialized
INFO - 2023-12-13 14:36:38 --> Config Class Initialized
INFO - 2023-12-13 14:36:38 --> Loader Class Initialized
INFO - 2023-12-13 14:36:38 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:38 --> Helper loaded: my_helper
ERROR - 2023-12-13 14:36:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:38 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:38 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:39 --> Config Class Initialized
INFO - 2023-12-13 14:36:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:39 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:39 --> URI Class Initialized
INFO - 2023-12-13 14:36:39 --> Router Class Initialized
INFO - 2023-12-13 14:36:39 --> Output Class Initialized
INFO - 2023-12-13 14:36:39 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:39 --> Input Class Initialized
INFO - 2023-12-13 14:36:39 --> Language Class Initialized
INFO - 2023-12-13 14:36:39 --> Language Class Initialized
INFO - 2023-12-13 14:36:39 --> Config Class Initialized
INFO - 2023-12-13 14:36:39 --> Loader Class Initialized
INFO - 2023-12-13 14:36:39 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:39 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:39 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:39 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:39 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:39 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:39 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:40 --> Config Class Initialized
INFO - 2023-12-13 14:36:40 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:40 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:40 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:40 --> URI Class Initialized
INFO - 2023-12-13 14:36:40 --> Router Class Initialized
INFO - 2023-12-13 14:36:40 --> Output Class Initialized
INFO - 2023-12-13 14:36:40 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:40 --> Input Class Initialized
INFO - 2023-12-13 14:36:40 --> Language Class Initialized
INFO - 2023-12-13 14:36:40 --> Language Class Initialized
INFO - 2023-12-13 14:36:40 --> Config Class Initialized
INFO - 2023-12-13 14:36:40 --> Loader Class Initialized
INFO - 2023-12-13 14:36:40 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:40 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:40 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:40 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:40 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:40 --> Controller Class Initialized
ERROR - 2023-12-13 14:36:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 14:36:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 14:36:47 --> Config Class Initialized
INFO - 2023-12-13 14:36:47 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:36:47 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:36:47 --> Utf8 Class Initialized
INFO - 2023-12-13 14:36:47 --> URI Class Initialized
INFO - 2023-12-13 14:36:47 --> Router Class Initialized
INFO - 2023-12-13 14:36:47 --> Output Class Initialized
INFO - 2023-12-13 14:36:47 --> Security Class Initialized
DEBUG - 2023-12-13 14:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:36:47 --> Input Class Initialized
INFO - 2023-12-13 14:36:47 --> Language Class Initialized
INFO - 2023-12-13 14:36:47 --> Language Class Initialized
INFO - 2023-12-13 14:36:47 --> Config Class Initialized
INFO - 2023-12-13 14:36:47 --> Loader Class Initialized
INFO - 2023-12-13 14:36:47 --> Helper loaded: url_helper
INFO - 2023-12-13 14:36:47 --> Helper loaded: file_helper
INFO - 2023-12-13 14:36:47 --> Helper loaded: form_helper
INFO - 2023-12-13 14:36:47 --> Helper loaded: my_helper
INFO - 2023-12-13 14:36:47 --> Database Driver Class Initialized
INFO - 2023-12-13 14:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:36:47 --> Controller Class Initialized
INFO - 2023-12-13 14:37:31 --> Config Class Initialized
INFO - 2023-12-13 14:37:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:37:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:37:31 --> Utf8 Class Initialized
INFO - 2023-12-13 14:37:31 --> URI Class Initialized
INFO - 2023-12-13 14:37:31 --> Router Class Initialized
INFO - 2023-12-13 14:37:31 --> Output Class Initialized
INFO - 2023-12-13 14:37:31 --> Security Class Initialized
DEBUG - 2023-12-13 14:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:37:31 --> Input Class Initialized
INFO - 2023-12-13 14:37:31 --> Language Class Initialized
INFO - 2023-12-13 14:37:31 --> Language Class Initialized
INFO - 2023-12-13 14:37:31 --> Config Class Initialized
INFO - 2023-12-13 14:37:31 --> Loader Class Initialized
INFO - 2023-12-13 14:37:31 --> Helper loaded: url_helper
INFO - 2023-12-13 14:37:31 --> Helper loaded: file_helper
INFO - 2023-12-13 14:37:31 --> Helper loaded: form_helper
INFO - 2023-12-13 14:37:31 --> Helper loaded: my_helper
INFO - 2023-12-13 14:37:31 --> Database Driver Class Initialized
INFO - 2023-12-13 14:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:37:31 --> Controller Class Initialized
DEBUG - 2023-12-13 14:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-12-13 14:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:37:32 --> Final output sent to browser
DEBUG - 2023-12-13 14:37:32 --> Total execution time: 0.3229
INFO - 2023-12-13 14:37:47 --> Config Class Initialized
INFO - 2023-12-13 14:37:47 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:37:47 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:37:47 --> Utf8 Class Initialized
INFO - 2023-12-13 14:37:47 --> URI Class Initialized
INFO - 2023-12-13 14:37:48 --> Router Class Initialized
INFO - 2023-12-13 14:37:48 --> Output Class Initialized
INFO - 2023-12-13 14:37:48 --> Security Class Initialized
DEBUG - 2023-12-13 14:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:37:48 --> Input Class Initialized
INFO - 2023-12-13 14:37:48 --> Language Class Initialized
INFO - 2023-12-13 14:37:48 --> Language Class Initialized
INFO - 2023-12-13 14:37:48 --> Config Class Initialized
INFO - 2023-12-13 14:37:48 --> Loader Class Initialized
INFO - 2023-12-13 14:37:48 --> Helper loaded: url_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: file_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: form_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: my_helper
INFO - 2023-12-13 14:37:48 --> Database Driver Class Initialized
INFO - 2023-12-13 14:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:37:48 --> Controller Class Initialized
INFO - 2023-12-13 14:37:48 --> Config Class Initialized
INFO - 2023-12-13 14:37:48 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:37:48 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:37:48 --> Utf8 Class Initialized
INFO - 2023-12-13 14:37:48 --> URI Class Initialized
INFO - 2023-12-13 14:37:48 --> Router Class Initialized
INFO - 2023-12-13 14:37:48 --> Output Class Initialized
INFO - 2023-12-13 14:37:48 --> Security Class Initialized
DEBUG - 2023-12-13 14:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:37:48 --> Input Class Initialized
INFO - 2023-12-13 14:37:48 --> Language Class Initialized
INFO - 2023-12-13 14:37:48 --> Language Class Initialized
INFO - 2023-12-13 14:37:48 --> Config Class Initialized
INFO - 2023-12-13 14:37:48 --> Loader Class Initialized
INFO - 2023-12-13 14:37:48 --> Helper loaded: url_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: file_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: form_helper
INFO - 2023-12-13 14:37:48 --> Helper loaded: my_helper
INFO - 2023-12-13 14:37:48 --> Database Driver Class Initialized
INFO - 2023-12-13 14:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:37:48 --> Controller Class Initialized
DEBUG - 2023-12-13 14:37:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 14:37:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:37:48 --> Final output sent to browser
DEBUG - 2023-12-13 14:37:48 --> Total execution time: 0.2355
INFO - 2023-12-13 14:37:54 --> Config Class Initialized
INFO - 2023-12-13 14:37:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:37:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:37:54 --> Utf8 Class Initialized
INFO - 2023-12-13 14:37:54 --> URI Class Initialized
INFO - 2023-12-13 14:37:54 --> Router Class Initialized
INFO - 2023-12-13 14:37:54 --> Output Class Initialized
INFO - 2023-12-13 14:37:54 --> Security Class Initialized
DEBUG - 2023-12-13 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:37:54 --> Input Class Initialized
INFO - 2023-12-13 14:37:54 --> Language Class Initialized
INFO - 2023-12-13 14:37:54 --> Language Class Initialized
INFO - 2023-12-13 14:37:54 --> Config Class Initialized
INFO - 2023-12-13 14:37:54 --> Loader Class Initialized
INFO - 2023-12-13 14:37:54 --> Helper loaded: url_helper
INFO - 2023-12-13 14:37:54 --> Helper loaded: file_helper
INFO - 2023-12-13 14:37:54 --> Helper loaded: form_helper
INFO - 2023-12-13 14:37:54 --> Helper loaded: my_helper
INFO - 2023-12-13 14:37:54 --> Database Driver Class Initialized
INFO - 2023-12-13 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:37:54 --> Controller Class Initialized
INFO - 2023-12-13 14:37:54 --> Final output sent to browser
DEBUG - 2023-12-13 14:37:54 --> Total execution time: 0.1363
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:09 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:09 --> URI Class Initialized
INFO - 2023-12-13 14:38:09 --> Router Class Initialized
INFO - 2023-12-13 14:38:09 --> Output Class Initialized
INFO - 2023-12-13 14:38:09 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:09 --> Input Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Loader Class Initialized
INFO - 2023-12-13 14:38:09 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:09 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:09 --> Controller Class Initialized
INFO - 2023-12-13 14:38:09 --> Helper loaded: cookie_helper
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:09 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:09 --> URI Class Initialized
INFO - 2023-12-13 14:38:09 --> Router Class Initialized
INFO - 2023-12-13 14:38:09 --> Output Class Initialized
INFO - 2023-12-13 14:38:09 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:09 --> Input Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Loader Class Initialized
INFO - 2023-12-13 14:38:09 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:09 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:09 --> Controller Class Initialized
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:09 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:09 --> URI Class Initialized
INFO - 2023-12-13 14:38:09 --> Router Class Initialized
INFO - 2023-12-13 14:38:09 --> Output Class Initialized
INFO - 2023-12-13 14:38:09 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:09 --> Input Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Language Class Initialized
INFO - 2023-12-13 14:38:09 --> Config Class Initialized
INFO - 2023-12-13 14:38:09 --> Loader Class Initialized
INFO - 2023-12-13 14:38:09 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:09 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:09 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:09 --> Controller Class Initialized
DEBUG - 2023-12-13 14:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 14:38:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:38:09 --> Final output sent to browser
DEBUG - 2023-12-13 14:38:09 --> Total execution time: 0.1525
INFO - 2023-12-13 14:38:17 --> Config Class Initialized
INFO - 2023-12-13 14:38:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:17 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:17 --> URI Class Initialized
INFO - 2023-12-13 14:38:17 --> Router Class Initialized
INFO - 2023-12-13 14:38:17 --> Output Class Initialized
INFO - 2023-12-13 14:38:17 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:17 --> Input Class Initialized
INFO - 2023-12-13 14:38:17 --> Language Class Initialized
INFO - 2023-12-13 14:38:17 --> Language Class Initialized
INFO - 2023-12-13 14:38:17 --> Config Class Initialized
INFO - 2023-12-13 14:38:17 --> Loader Class Initialized
INFO - 2023-12-13 14:38:17 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:17 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:17 --> Controller Class Initialized
INFO - 2023-12-13 14:38:17 --> Helper loaded: cookie_helper
INFO - 2023-12-13 14:38:17 --> Final output sent to browser
DEBUG - 2023-12-13 14:38:17 --> Total execution time: 0.2152
INFO - 2023-12-13 14:38:17 --> Config Class Initialized
INFO - 2023-12-13 14:38:17 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:17 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:17 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:17 --> URI Class Initialized
INFO - 2023-12-13 14:38:17 --> Router Class Initialized
INFO - 2023-12-13 14:38:17 --> Output Class Initialized
INFO - 2023-12-13 14:38:17 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:17 --> Input Class Initialized
INFO - 2023-12-13 14:38:17 --> Language Class Initialized
INFO - 2023-12-13 14:38:17 --> Language Class Initialized
INFO - 2023-12-13 14:38:17 --> Config Class Initialized
INFO - 2023-12-13 14:38:17 --> Loader Class Initialized
INFO - 2023-12-13 14:38:17 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:17 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:17 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:17 --> Controller Class Initialized
DEBUG - 2023-12-13 14:38:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 14:38:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:38:17 --> Final output sent to browser
DEBUG - 2023-12-13 14:38:17 --> Total execution time: 0.2226
INFO - 2023-12-13 14:38:25 --> Config Class Initialized
INFO - 2023-12-13 14:38:25 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:25 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:25 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:25 --> URI Class Initialized
INFO - 2023-12-13 14:38:25 --> Router Class Initialized
INFO - 2023-12-13 14:38:25 --> Output Class Initialized
INFO - 2023-12-13 14:38:25 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:25 --> Input Class Initialized
INFO - 2023-12-13 14:38:25 --> Language Class Initialized
INFO - 2023-12-13 14:38:25 --> Language Class Initialized
INFO - 2023-12-13 14:38:25 --> Config Class Initialized
INFO - 2023-12-13 14:38:25 --> Loader Class Initialized
INFO - 2023-12-13 14:38:25 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:25 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:25 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:25 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:25 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:25 --> Controller Class Initialized
DEBUG - 2023-12-13 14:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-13 14:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 14:38:25 --> Final output sent to browser
DEBUG - 2023-12-13 14:38:25 --> Total execution time: 0.1771
INFO - 2023-12-13 14:38:28 --> Config Class Initialized
INFO - 2023-12-13 14:38:28 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:38:28 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:38:28 --> Utf8 Class Initialized
INFO - 2023-12-13 14:38:28 --> URI Class Initialized
INFO - 2023-12-13 14:38:28 --> Router Class Initialized
INFO - 2023-12-13 14:38:28 --> Output Class Initialized
INFO - 2023-12-13 14:38:28 --> Security Class Initialized
DEBUG - 2023-12-13 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:38:28 --> Input Class Initialized
INFO - 2023-12-13 14:38:28 --> Language Class Initialized
INFO - 2023-12-13 14:38:29 --> Language Class Initialized
INFO - 2023-12-13 14:38:29 --> Config Class Initialized
INFO - 2023-12-13 14:38:29 --> Loader Class Initialized
INFO - 2023-12-13 14:38:29 --> Helper loaded: url_helper
INFO - 2023-12-13 14:38:29 --> Helper loaded: file_helper
INFO - 2023-12-13 14:38:29 --> Helper loaded: form_helper
INFO - 2023-12-13 14:38:29 --> Helper loaded: my_helper
INFO - 2023-12-13 14:38:29 --> Database Driver Class Initialized
INFO - 2023-12-13 14:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:38:29 --> Controller Class Initialized
DEBUG - 2023-12-13 14:38:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:38:45 --> Final output sent to browser
DEBUG - 2023-12-13 14:38:45 --> Total execution time: 16.1567
INFO - 2023-12-13 14:39:00 --> Config Class Initialized
INFO - 2023-12-13 14:39:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:39:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:39:00 --> Utf8 Class Initialized
INFO - 2023-12-13 14:39:00 --> URI Class Initialized
INFO - 2023-12-13 14:39:00 --> Config Class Initialized
INFO - 2023-12-13 14:39:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:39:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:39:00 --> Utf8 Class Initialized
INFO - 2023-12-13 14:39:00 --> URI Class Initialized
INFO - 2023-12-13 14:39:00 --> Router Class Initialized
INFO - 2023-12-13 14:39:00 --> Output Class Initialized
INFO - 2023-12-13 14:39:00 --> Security Class Initialized
DEBUG - 2023-12-13 14:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:39:00 --> Input Class Initialized
INFO - 2023-12-13 14:39:00 --> Language Class Initialized
INFO - 2023-12-13 14:39:00 --> Router Class Initialized
INFO - 2023-12-13 14:39:00 --> Output Class Initialized
INFO - 2023-12-13 14:39:00 --> Security Class Initialized
DEBUG - 2023-12-13 14:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:39:00 --> Input Class Initialized
INFO - 2023-12-13 14:39:00 --> Language Class Initialized
INFO - 2023-12-13 14:39:00 --> Language Class Initialized
INFO - 2023-12-13 14:39:00 --> Config Class Initialized
INFO - 2023-12-13 14:39:00 --> Loader Class Initialized
INFO - 2023-12-13 14:39:00 --> Helper loaded: url_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: file_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: form_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: my_helper
INFO - 2023-12-13 14:39:00 --> Language Class Initialized
INFO - 2023-12-13 14:39:00 --> Config Class Initialized
INFO - 2023-12-13 14:39:00 --> Loader Class Initialized
INFO - 2023-12-13 14:39:00 --> Helper loaded: url_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: file_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: form_helper
INFO - 2023-12-13 14:39:00 --> Helper loaded: my_helper
INFO - 2023-12-13 14:39:00 --> Database Driver Class Initialized
INFO - 2023-12-13 14:39:00 --> Database Driver Class Initialized
INFO - 2023-12-13 14:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:39:00 --> Controller Class Initialized
DEBUG - 2023-12-13 14:39:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:39:10 --> Final output sent to browser
DEBUG - 2023-12-13 14:39:10 --> Total execution time: 10.4180
INFO - 2023-12-13 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:39:10 --> Controller Class Initialized
DEBUG - 2023-12-13 14:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:39:19 --> Final output sent to browser
DEBUG - 2023-12-13 14:39:19 --> Total execution time: 19.5909
INFO - 2023-12-13 14:39:38 --> Config Class Initialized
INFO - 2023-12-13 14:39:38 --> Hooks Class Initialized
DEBUG - 2023-12-13 14:39:38 --> UTF-8 Support Enabled
INFO - 2023-12-13 14:39:38 --> Utf8 Class Initialized
INFO - 2023-12-13 14:39:38 --> URI Class Initialized
INFO - 2023-12-13 14:39:38 --> Router Class Initialized
INFO - 2023-12-13 14:39:38 --> Output Class Initialized
INFO - 2023-12-13 14:39:38 --> Security Class Initialized
DEBUG - 2023-12-13 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 14:39:38 --> Input Class Initialized
INFO - 2023-12-13 14:39:38 --> Language Class Initialized
INFO - 2023-12-13 14:39:38 --> Language Class Initialized
INFO - 2023-12-13 14:39:38 --> Config Class Initialized
INFO - 2023-12-13 14:39:38 --> Loader Class Initialized
INFO - 2023-12-13 14:39:38 --> Helper loaded: url_helper
INFO - 2023-12-13 14:39:38 --> Helper loaded: file_helper
INFO - 2023-12-13 14:39:38 --> Helper loaded: form_helper
INFO - 2023-12-13 14:39:38 --> Helper loaded: my_helper
INFO - 2023-12-13 14:39:38 --> Database Driver Class Initialized
INFO - 2023-12-13 14:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 14:39:38 --> Controller Class Initialized
DEBUG - 2023-12-13 14:39:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-13 14:39:46 --> Final output sent to browser
DEBUG - 2023-12-13 14:39:46 --> Total execution time: 7.7373
INFO - 2023-12-13 15:43:35 --> Config Class Initialized
INFO - 2023-12-13 15:43:35 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:43:35 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:43:35 --> Utf8 Class Initialized
INFO - 2023-12-13 15:43:35 --> URI Class Initialized
INFO - 2023-12-13 15:43:35 --> Router Class Initialized
INFO - 2023-12-13 15:43:35 --> Output Class Initialized
INFO - 2023-12-13 15:43:35 --> Security Class Initialized
DEBUG - 2023-12-13 15:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:43:35 --> Input Class Initialized
INFO - 2023-12-13 15:43:35 --> Language Class Initialized
INFO - 2023-12-13 15:43:35 --> Language Class Initialized
INFO - 2023-12-13 15:43:35 --> Config Class Initialized
INFO - 2023-12-13 15:43:35 --> Loader Class Initialized
INFO - 2023-12-13 15:43:35 --> Helper loaded: url_helper
INFO - 2023-12-13 15:43:35 --> Helper loaded: file_helper
INFO - 2023-12-13 15:43:35 --> Helper loaded: form_helper
INFO - 2023-12-13 15:43:35 --> Helper loaded: my_helper
INFO - 2023-12-13 15:43:35 --> Database Driver Class Initialized
INFO - 2023-12-13 15:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:43:35 --> Controller Class Initialized
ERROR - 2023-12-13 15:43:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-13 15:43:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-13 15:47:31 --> Config Class Initialized
INFO - 2023-12-13 15:47:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:31 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:31 --> URI Class Initialized
DEBUG - 2023-12-13 15:47:31 --> No URI present. Default controller set.
INFO - 2023-12-13 15:47:31 --> Router Class Initialized
INFO - 2023-12-13 15:47:31 --> Output Class Initialized
INFO - 2023-12-13 15:47:31 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:31 --> Input Class Initialized
INFO - 2023-12-13 15:47:31 --> Language Class Initialized
INFO - 2023-12-13 15:47:31 --> Language Class Initialized
INFO - 2023-12-13 15:47:31 --> Config Class Initialized
INFO - 2023-12-13 15:47:31 --> Loader Class Initialized
INFO - 2023-12-13 15:47:31 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:31 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:31 --> Controller Class Initialized
INFO - 2023-12-13 15:47:31 --> Config Class Initialized
INFO - 2023-12-13 15:47:31 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:31 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:31 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:31 --> URI Class Initialized
INFO - 2023-12-13 15:47:31 --> Router Class Initialized
INFO - 2023-12-13 15:47:31 --> Output Class Initialized
INFO - 2023-12-13 15:47:31 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:31 --> Input Class Initialized
INFO - 2023-12-13 15:47:31 --> Language Class Initialized
INFO - 2023-12-13 15:47:31 --> Language Class Initialized
INFO - 2023-12-13 15:47:31 --> Config Class Initialized
INFO - 2023-12-13 15:47:31 --> Loader Class Initialized
INFO - 2023-12-13 15:47:31 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:31 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:31 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:31 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 15:47:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:31 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:31 --> Total execution time: 0.0470
INFO - 2023-12-13 15:47:34 --> Config Class Initialized
INFO - 2023-12-13 15:47:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:34 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:34 --> URI Class Initialized
INFO - 2023-12-13 15:47:34 --> Router Class Initialized
INFO - 2023-12-13 15:47:34 --> Output Class Initialized
INFO - 2023-12-13 15:47:34 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:34 --> Input Class Initialized
INFO - 2023-12-13 15:47:34 --> Language Class Initialized
INFO - 2023-12-13 15:47:34 --> Language Class Initialized
INFO - 2023-12-13 15:47:34 --> Config Class Initialized
INFO - 2023-12-13 15:47:34 --> Loader Class Initialized
INFO - 2023-12-13 15:47:34 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:34 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:34 --> Controller Class Initialized
INFO - 2023-12-13 15:47:34 --> Helper loaded: cookie_helper
INFO - 2023-12-13 15:47:34 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:34 --> Total execution time: 0.0394
INFO - 2023-12-13 15:47:34 --> Config Class Initialized
INFO - 2023-12-13 15:47:34 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:34 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:34 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:34 --> URI Class Initialized
INFO - 2023-12-13 15:47:34 --> Router Class Initialized
INFO - 2023-12-13 15:47:34 --> Output Class Initialized
INFO - 2023-12-13 15:47:34 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:34 --> Input Class Initialized
INFO - 2023-12-13 15:47:34 --> Language Class Initialized
INFO - 2023-12-13 15:47:34 --> Language Class Initialized
INFO - 2023-12-13 15:47:34 --> Config Class Initialized
INFO - 2023-12-13 15:47:34 --> Loader Class Initialized
INFO - 2023-12-13 15:47:34 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:34 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:34 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:34 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 15:47:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:34 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:34 --> Total execution time: 0.0471
INFO - 2023-12-13 15:47:36 --> Config Class Initialized
INFO - 2023-12-13 15:47:36 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:36 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:36 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:36 --> URI Class Initialized
INFO - 2023-12-13 15:47:36 --> Router Class Initialized
INFO - 2023-12-13 15:47:36 --> Output Class Initialized
INFO - 2023-12-13 15:47:36 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:36 --> Input Class Initialized
INFO - 2023-12-13 15:47:36 --> Language Class Initialized
INFO - 2023-12-13 15:47:36 --> Language Class Initialized
INFO - 2023-12-13 15:47:36 --> Config Class Initialized
INFO - 2023-12-13 15:47:36 --> Loader Class Initialized
INFO - 2023-12-13 15:47:36 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:36 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:36 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:36 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:36 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:36 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 15:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:36 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:36 --> Total execution time: 0.1430
INFO - 2023-12-13 15:47:39 --> Config Class Initialized
INFO - 2023-12-13 15:47:39 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:39 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:39 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:39 --> URI Class Initialized
INFO - 2023-12-13 15:47:39 --> Router Class Initialized
INFO - 2023-12-13 15:47:39 --> Output Class Initialized
INFO - 2023-12-13 15:47:39 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:39 --> Input Class Initialized
INFO - 2023-12-13 15:47:39 --> Language Class Initialized
INFO - 2023-12-13 15:47:39 --> Language Class Initialized
INFO - 2023-12-13 15:47:39 --> Config Class Initialized
INFO - 2023-12-13 15:47:39 --> Loader Class Initialized
INFO - 2023-12-13 15:47:39 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:39 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:39 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:39 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:39 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:39 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 15:47:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:39 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:39 --> Total execution time: 0.1368
INFO - 2023-12-13 15:47:41 --> Config Class Initialized
INFO - 2023-12-13 15:47:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:41 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:41 --> URI Class Initialized
INFO - 2023-12-13 15:47:41 --> Router Class Initialized
INFO - 2023-12-13 15:47:41 --> Output Class Initialized
INFO - 2023-12-13 15:47:41 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:41 --> Input Class Initialized
INFO - 2023-12-13 15:47:41 --> Language Class Initialized
INFO - 2023-12-13 15:47:41 --> Language Class Initialized
INFO - 2023-12-13 15:47:41 --> Config Class Initialized
INFO - 2023-12-13 15:47:41 --> Loader Class Initialized
INFO - 2023-12-13 15:47:41 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:41 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:41 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:41 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:41 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:41 --> Controller Class Initialized
INFO - 2023-12-13 15:47:41 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:41 --> Total execution time: 0.1671
INFO - 2023-12-13 15:47:52 --> Config Class Initialized
INFO - 2023-12-13 15:47:52 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:52 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:52 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:52 --> URI Class Initialized
INFO - 2023-12-13 15:47:52 --> Router Class Initialized
INFO - 2023-12-13 15:47:52 --> Output Class Initialized
INFO - 2023-12-13 15:47:52 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:52 --> Input Class Initialized
INFO - 2023-12-13 15:47:52 --> Language Class Initialized
INFO - 2023-12-13 15:47:52 --> Language Class Initialized
INFO - 2023-12-13 15:47:52 --> Config Class Initialized
INFO - 2023-12-13 15:47:52 --> Loader Class Initialized
INFO - 2023-12-13 15:47:52 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:52 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:52 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:52 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:52 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:52 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 15:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:52 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:52 --> Total execution time: 0.2767
INFO - 2023-12-13 15:47:54 --> Config Class Initialized
INFO - 2023-12-13 15:47:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:54 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:54 --> URI Class Initialized
INFO - 2023-12-13 15:47:54 --> Router Class Initialized
INFO - 2023-12-13 15:47:54 --> Output Class Initialized
INFO - 2023-12-13 15:47:54 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:54 --> Input Class Initialized
INFO - 2023-12-13 15:47:54 --> Language Class Initialized
INFO - 2023-12-13 15:47:54 --> Language Class Initialized
INFO - 2023-12-13 15:47:54 --> Config Class Initialized
INFO - 2023-12-13 15:47:54 --> Loader Class Initialized
INFO - 2023-12-13 15:47:54 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:54 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:54 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:54 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:54 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:55 --> Controller Class Initialized
DEBUG - 2023-12-13 15:47:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 15:47:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 15:47:55 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:55 --> Total execution time: 0.4063
INFO - 2023-12-13 15:47:55 --> Config Class Initialized
INFO - 2023-12-13 15:47:55 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:55 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:55 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:55 --> URI Class Initialized
INFO - 2023-12-13 15:47:55 --> Router Class Initialized
INFO - 2023-12-13 15:47:55 --> Output Class Initialized
INFO - 2023-12-13 15:47:55 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:55 --> Input Class Initialized
INFO - 2023-12-13 15:47:55 --> Language Class Initialized
INFO - 2023-12-13 15:47:55 --> Language Class Initialized
INFO - 2023-12-13 15:47:55 --> Config Class Initialized
INFO - 2023-12-13 15:47:55 --> Loader Class Initialized
INFO - 2023-12-13 15:47:55 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:55 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:55 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:55 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:55 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:55 --> Controller Class Initialized
INFO - 2023-12-13 15:47:58 --> Config Class Initialized
INFO - 2023-12-13 15:47:58 --> Hooks Class Initialized
DEBUG - 2023-12-13 15:47:58 --> UTF-8 Support Enabled
INFO - 2023-12-13 15:47:58 --> Utf8 Class Initialized
INFO - 2023-12-13 15:47:58 --> URI Class Initialized
INFO - 2023-12-13 15:47:58 --> Router Class Initialized
INFO - 2023-12-13 15:47:58 --> Output Class Initialized
INFO - 2023-12-13 15:47:58 --> Security Class Initialized
DEBUG - 2023-12-13 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 15:47:58 --> Input Class Initialized
INFO - 2023-12-13 15:47:58 --> Language Class Initialized
INFO - 2023-12-13 15:47:58 --> Language Class Initialized
INFO - 2023-12-13 15:47:58 --> Config Class Initialized
INFO - 2023-12-13 15:47:58 --> Loader Class Initialized
INFO - 2023-12-13 15:47:58 --> Helper loaded: url_helper
INFO - 2023-12-13 15:47:58 --> Helper loaded: file_helper
INFO - 2023-12-13 15:47:58 --> Helper loaded: form_helper
INFO - 2023-12-13 15:47:58 --> Helper loaded: my_helper
INFO - 2023-12-13 15:47:58 --> Database Driver Class Initialized
INFO - 2023-12-13 15:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 15:47:58 --> Controller Class Initialized
INFO - 2023-12-13 15:47:58 --> Final output sent to browser
DEBUG - 2023-12-13 15:47:58 --> Total execution time: 0.2572
INFO - 2023-12-13 16:55:41 --> Config Class Initialized
INFO - 2023-12-13 16:55:41 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:55:41 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:55:41 --> Utf8 Class Initialized
INFO - 2023-12-13 16:55:41 --> URI Class Initialized
INFO - 2023-12-13 16:55:41 --> Router Class Initialized
INFO - 2023-12-13 16:55:41 --> Output Class Initialized
INFO - 2023-12-13 16:55:41 --> Security Class Initialized
DEBUG - 2023-12-13 16:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:55:41 --> Input Class Initialized
INFO - 2023-12-13 16:55:41 --> Language Class Initialized
INFO - 2023-12-13 16:55:41 --> Language Class Initialized
INFO - 2023-12-13 16:55:41 --> Config Class Initialized
INFO - 2023-12-13 16:55:41 --> Loader Class Initialized
INFO - 2023-12-13 16:55:41 --> Helper loaded: url_helper
INFO - 2023-12-13 16:55:41 --> Helper loaded: file_helper
INFO - 2023-12-13 16:55:41 --> Helper loaded: form_helper
INFO - 2023-12-13 16:55:41 --> Helper loaded: my_helper
INFO - 2023-12-13 16:55:41 --> Database Driver Class Initialized
INFO - 2023-12-13 16:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:55:42 --> Controller Class Initialized
DEBUG - 2023-12-13 16:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 16:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:55:42 --> Final output sent to browser
DEBUG - 2023-12-13 16:55:42 --> Total execution time: 0.7085
INFO - 2023-12-13 16:55:52 --> Config Class Initialized
INFO - 2023-12-13 16:55:52 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:55:52 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:55:52 --> Utf8 Class Initialized
INFO - 2023-12-13 16:55:53 --> URI Class Initialized
INFO - 2023-12-13 16:55:53 --> Router Class Initialized
INFO - 2023-12-13 16:55:53 --> Output Class Initialized
INFO - 2023-12-13 16:55:53 --> Security Class Initialized
DEBUG - 2023-12-13 16:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:55:53 --> Input Class Initialized
INFO - 2023-12-13 16:55:53 --> Language Class Initialized
INFO - 2023-12-13 16:55:53 --> Language Class Initialized
INFO - 2023-12-13 16:55:53 --> Config Class Initialized
INFO - 2023-12-13 16:55:53 --> Loader Class Initialized
INFO - 2023-12-13 16:55:53 --> Helper loaded: url_helper
INFO - 2023-12-13 16:55:53 --> Helper loaded: file_helper
INFO - 2023-12-13 16:55:53 --> Helper loaded: form_helper
INFO - 2023-12-13 16:55:53 --> Helper loaded: my_helper
INFO - 2023-12-13 16:55:53 --> Database Driver Class Initialized
INFO - 2023-12-13 16:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:55:53 --> Controller Class Initialized
INFO - 2023-12-13 16:55:53 --> Helper loaded: cookie_helper
INFO - 2023-12-13 16:55:53 --> Final output sent to browser
DEBUG - 2023-12-13 16:55:53 --> Total execution time: 0.9599
INFO - 2023-12-13 16:55:54 --> Config Class Initialized
INFO - 2023-12-13 16:55:54 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:55:54 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:55:54 --> Utf8 Class Initialized
INFO - 2023-12-13 16:55:54 --> URI Class Initialized
INFO - 2023-12-13 16:55:54 --> Router Class Initialized
INFO - 2023-12-13 16:55:54 --> Output Class Initialized
INFO - 2023-12-13 16:55:54 --> Security Class Initialized
DEBUG - 2023-12-13 16:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:55:54 --> Input Class Initialized
INFO - 2023-12-13 16:55:54 --> Language Class Initialized
INFO - 2023-12-13 16:55:54 --> Language Class Initialized
INFO - 2023-12-13 16:55:54 --> Config Class Initialized
INFO - 2023-12-13 16:55:54 --> Loader Class Initialized
INFO - 2023-12-13 16:55:54 --> Helper loaded: url_helper
INFO - 2023-12-13 16:55:54 --> Helper loaded: file_helper
INFO - 2023-12-13 16:55:54 --> Helper loaded: form_helper
INFO - 2023-12-13 16:55:54 --> Helper loaded: my_helper
INFO - 2023-12-13 16:55:54 --> Database Driver Class Initialized
INFO - 2023-12-13 16:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:55:54 --> Controller Class Initialized
DEBUG - 2023-12-13 16:55:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 16:55:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:55:54 --> Final output sent to browser
DEBUG - 2023-12-13 16:55:54 --> Total execution time: 0.6621
INFO - 2023-12-13 16:56:00 --> Config Class Initialized
INFO - 2023-12-13 16:56:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:56:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:56:00 --> Utf8 Class Initialized
INFO - 2023-12-13 16:56:00 --> URI Class Initialized
INFO - 2023-12-13 16:56:00 --> Router Class Initialized
INFO - 2023-12-13 16:56:00 --> Output Class Initialized
INFO - 2023-12-13 16:56:00 --> Security Class Initialized
DEBUG - 2023-12-13 16:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:56:00 --> Input Class Initialized
INFO - 2023-12-13 16:56:00 --> Language Class Initialized
INFO - 2023-12-13 16:56:00 --> Language Class Initialized
INFO - 2023-12-13 16:56:00 --> Config Class Initialized
INFO - 2023-12-13 16:56:00 --> Loader Class Initialized
INFO - 2023-12-13 16:56:00 --> Helper loaded: url_helper
INFO - 2023-12-13 16:56:00 --> Helper loaded: file_helper
INFO - 2023-12-13 16:56:00 --> Helper loaded: form_helper
INFO - 2023-12-13 16:56:00 --> Helper loaded: my_helper
INFO - 2023-12-13 16:56:01 --> Database Driver Class Initialized
INFO - 2023-12-13 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:56:01 --> Controller Class Initialized
DEBUG - 2023-12-13 16:56:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 16:56:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:56:01 --> Final output sent to browser
DEBUG - 2023-12-13 16:56:01 --> Total execution time: 1.2048
INFO - 2023-12-13 16:56:48 --> Config Class Initialized
INFO - 2023-12-13 16:56:48 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:56:48 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:56:48 --> Utf8 Class Initialized
INFO - 2023-12-13 16:56:48 --> URI Class Initialized
INFO - 2023-12-13 16:56:48 --> Router Class Initialized
INFO - 2023-12-13 16:56:48 --> Output Class Initialized
INFO - 2023-12-13 16:56:48 --> Security Class Initialized
DEBUG - 2023-12-13 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:56:48 --> Input Class Initialized
INFO - 2023-12-13 16:56:48 --> Language Class Initialized
INFO - 2023-12-13 16:56:48 --> Language Class Initialized
INFO - 2023-12-13 16:56:48 --> Config Class Initialized
INFO - 2023-12-13 16:56:48 --> Loader Class Initialized
INFO - 2023-12-13 16:56:48 --> Helper loaded: url_helper
INFO - 2023-12-13 16:56:48 --> Helper loaded: file_helper
INFO - 2023-12-13 16:56:48 --> Helper loaded: form_helper
INFO - 2023-12-13 16:56:48 --> Helper loaded: my_helper
INFO - 2023-12-13 16:56:48 --> Database Driver Class Initialized
INFO - 2023-12-13 16:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:56:48 --> Controller Class Initialized
DEBUG - 2023-12-13 16:56:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 16:56:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:56:49 --> Final output sent to browser
DEBUG - 2023-12-13 16:56:49 --> Total execution time: 0.6350
INFO - 2023-12-13 16:56:50 --> Config Class Initialized
INFO - 2023-12-13 16:56:50 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:56:50 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:56:50 --> Utf8 Class Initialized
INFO - 2023-12-13 16:56:50 --> URI Class Initialized
INFO - 2023-12-13 16:56:50 --> Router Class Initialized
INFO - 2023-12-13 16:56:50 --> Output Class Initialized
INFO - 2023-12-13 16:56:50 --> Security Class Initialized
DEBUG - 2023-12-13 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:56:50 --> Input Class Initialized
INFO - 2023-12-13 16:56:50 --> Language Class Initialized
INFO - 2023-12-13 16:56:50 --> Language Class Initialized
INFO - 2023-12-13 16:56:50 --> Config Class Initialized
INFO - 2023-12-13 16:56:50 --> Loader Class Initialized
INFO - 2023-12-13 16:56:50 --> Helper loaded: url_helper
INFO - 2023-12-13 16:56:50 --> Helper loaded: file_helper
INFO - 2023-12-13 16:56:50 --> Helper loaded: form_helper
INFO - 2023-12-13 16:56:50 --> Helper loaded: my_helper
INFO - 2023-12-13 16:56:50 --> Database Driver Class Initialized
INFO - 2023-12-13 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:56:50 --> Controller Class Initialized
INFO - 2023-12-13 16:56:59 --> Config Class Initialized
INFO - 2023-12-13 16:56:59 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:56:59 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:56:59 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:00 --> URI Class Initialized
INFO - 2023-12-13 16:57:00 --> Router Class Initialized
INFO - 2023-12-13 16:57:00 --> Output Class Initialized
INFO - 2023-12-13 16:57:00 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:00 --> Input Class Initialized
INFO - 2023-12-13 16:57:00 --> Language Class Initialized
INFO - 2023-12-13 16:57:00 --> Language Class Initialized
INFO - 2023-12-13 16:57:00 --> Config Class Initialized
INFO - 2023-12-13 16:57:00 --> Loader Class Initialized
INFO - 2023-12-13 16:57:00 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:00 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:00 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:00 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:00 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:01 --> Controller Class Initialized
INFO - 2023-12-13 16:57:01 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:01 --> Total execution time: 2.0297
INFO - 2023-12-13 16:57:10 --> Config Class Initialized
INFO - 2023-12-13 16:57:10 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:10 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:10 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:10 --> URI Class Initialized
INFO - 2023-12-13 16:57:10 --> Router Class Initialized
INFO - 2023-12-13 16:57:10 --> Output Class Initialized
INFO - 2023-12-13 16:57:10 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:10 --> Input Class Initialized
INFO - 2023-12-13 16:57:10 --> Language Class Initialized
INFO - 2023-12-13 16:57:10 --> Language Class Initialized
INFO - 2023-12-13 16:57:10 --> Config Class Initialized
INFO - 2023-12-13 16:57:10 --> Loader Class Initialized
INFO - 2023-12-13 16:57:10 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:10 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:10 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:10 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:10 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:10 --> Controller Class Initialized
INFO - 2023-12-13 16:57:11 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:11 --> Total execution time: 1.0855
INFO - 2023-12-13 16:57:15 --> Config Class Initialized
INFO - 2023-12-13 16:57:15 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:15 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:15 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:15 --> URI Class Initialized
INFO - 2023-12-13 16:57:15 --> Router Class Initialized
INFO - 2023-12-13 16:57:15 --> Output Class Initialized
INFO - 2023-12-13 16:57:15 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:15 --> Input Class Initialized
INFO - 2023-12-13 16:57:15 --> Language Class Initialized
INFO - 2023-12-13 16:57:15 --> Language Class Initialized
INFO - 2023-12-13 16:57:15 --> Config Class Initialized
INFO - 2023-12-13 16:57:15 --> Loader Class Initialized
INFO - 2023-12-13 16:57:15 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:15 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:15 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:15 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:15 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:16 --> Controller Class Initialized
INFO - 2023-12-13 16:57:16 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:16 --> Total execution time: 0.8869
INFO - 2023-12-13 16:57:20 --> Config Class Initialized
INFO - 2023-12-13 16:57:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:20 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:20 --> URI Class Initialized
INFO - 2023-12-13 16:57:20 --> Router Class Initialized
INFO - 2023-12-13 16:57:20 --> Output Class Initialized
INFO - 2023-12-13 16:57:20 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:20 --> Input Class Initialized
INFO - 2023-12-13 16:57:20 --> Language Class Initialized
INFO - 2023-12-13 16:57:20 --> Language Class Initialized
INFO - 2023-12-13 16:57:20 --> Config Class Initialized
INFO - 2023-12-13 16:57:20 --> Loader Class Initialized
INFO - 2023-12-13 16:57:20 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:20 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:20 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:20 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:20 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:20 --> Controller Class Initialized
INFO - 2023-12-13 16:57:20 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:20 --> Total execution time: 0.5672
INFO - 2023-12-13 16:57:25 --> Config Class Initialized
INFO - 2023-12-13 16:57:25 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:25 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:25 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:25 --> URI Class Initialized
INFO - 2023-12-13 16:57:25 --> Router Class Initialized
INFO - 2023-12-13 16:57:25 --> Output Class Initialized
INFO - 2023-12-13 16:57:25 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:25 --> Input Class Initialized
INFO - 2023-12-13 16:57:25 --> Language Class Initialized
INFO - 2023-12-13 16:57:25 --> Language Class Initialized
INFO - 2023-12-13 16:57:25 --> Config Class Initialized
INFO - 2023-12-13 16:57:25 --> Loader Class Initialized
INFO - 2023-12-13 16:57:25 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:25 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:25 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:25 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:25 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:25 --> Controller Class Initialized
INFO - 2023-12-13 16:57:26 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:26 --> Total execution time: 0.6030
INFO - 2023-12-13 16:57:27 --> Config Class Initialized
INFO - 2023-12-13 16:57:27 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:27 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:27 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:27 --> URI Class Initialized
INFO - 2023-12-13 16:57:27 --> Router Class Initialized
INFO - 2023-12-13 16:57:27 --> Output Class Initialized
INFO - 2023-12-13 16:57:27 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:27 --> Input Class Initialized
INFO - 2023-12-13 16:57:27 --> Language Class Initialized
INFO - 2023-12-13 16:57:27 --> Language Class Initialized
INFO - 2023-12-13 16:57:27 --> Config Class Initialized
INFO - 2023-12-13 16:57:27 --> Loader Class Initialized
INFO - 2023-12-13 16:57:27 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:27 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:27 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:27 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:27 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:27 --> Controller Class Initialized
INFO - 2023-12-13 16:57:27 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:27 --> Total execution time: 0.3858
INFO - 2023-12-13 16:57:32 --> Config Class Initialized
INFO - 2023-12-13 16:57:32 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:32 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:32 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:32 --> URI Class Initialized
INFO - 2023-12-13 16:57:32 --> Router Class Initialized
INFO - 2023-12-13 16:57:32 --> Output Class Initialized
INFO - 2023-12-13 16:57:32 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:32 --> Input Class Initialized
INFO - 2023-12-13 16:57:32 --> Language Class Initialized
INFO - 2023-12-13 16:57:32 --> Language Class Initialized
INFO - 2023-12-13 16:57:32 --> Config Class Initialized
INFO - 2023-12-13 16:57:32 --> Loader Class Initialized
INFO - 2023-12-13 16:57:32 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:32 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:32 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:32 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:32 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:32 --> Controller Class Initialized
INFO - 2023-12-13 16:57:32 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:32 --> Total execution time: 0.4477
INFO - 2023-12-13 16:57:46 --> Config Class Initialized
INFO - 2023-12-13 16:57:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:46 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:46 --> URI Class Initialized
INFO - 2023-12-13 16:57:46 --> Router Class Initialized
INFO - 2023-12-13 16:57:46 --> Output Class Initialized
INFO - 2023-12-13 16:57:46 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:46 --> Input Class Initialized
INFO - 2023-12-13 16:57:46 --> Language Class Initialized
INFO - 2023-12-13 16:57:46 --> Language Class Initialized
INFO - 2023-12-13 16:57:46 --> Config Class Initialized
INFO - 2023-12-13 16:57:46 --> Loader Class Initialized
INFO - 2023-12-13 16:57:46 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:46 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:46 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:46 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:46 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:46 --> Controller Class Initialized
DEBUG - 2023-12-13 16:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 16:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:57:46 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:46 --> Total execution time: 0.5957
INFO - 2023-12-13 16:57:51 --> Config Class Initialized
INFO - 2023-12-13 16:57:51 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:51 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:51 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:51 --> URI Class Initialized
INFO - 2023-12-13 16:57:51 --> Router Class Initialized
INFO - 2023-12-13 16:57:51 --> Output Class Initialized
INFO - 2023-12-13 16:57:51 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:51 --> Input Class Initialized
INFO - 2023-12-13 16:57:51 --> Language Class Initialized
INFO - 2023-12-13 16:57:51 --> Language Class Initialized
INFO - 2023-12-13 16:57:51 --> Config Class Initialized
INFO - 2023-12-13 16:57:51 --> Loader Class Initialized
INFO - 2023-12-13 16:57:51 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:51 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:51 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:51 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:51 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:51 --> Controller Class Initialized
DEBUG - 2023-12-13 16:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 16:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 16:57:51 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:51 --> Total execution time: 0.6956
INFO - 2023-12-13 16:57:53 --> Config Class Initialized
INFO - 2023-12-13 16:57:53 --> Hooks Class Initialized
DEBUG - 2023-12-13 16:57:53 --> UTF-8 Support Enabled
INFO - 2023-12-13 16:57:53 --> Utf8 Class Initialized
INFO - 2023-12-13 16:57:53 --> URI Class Initialized
INFO - 2023-12-13 16:57:54 --> Router Class Initialized
INFO - 2023-12-13 16:57:54 --> Output Class Initialized
INFO - 2023-12-13 16:57:54 --> Security Class Initialized
DEBUG - 2023-12-13 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 16:57:54 --> Input Class Initialized
INFO - 2023-12-13 16:57:54 --> Language Class Initialized
INFO - 2023-12-13 16:57:54 --> Language Class Initialized
INFO - 2023-12-13 16:57:54 --> Config Class Initialized
INFO - 2023-12-13 16:57:54 --> Loader Class Initialized
INFO - 2023-12-13 16:57:54 --> Helper loaded: url_helper
INFO - 2023-12-13 16:57:54 --> Helper loaded: file_helper
INFO - 2023-12-13 16:57:54 --> Helper loaded: form_helper
INFO - 2023-12-13 16:57:54 --> Helper loaded: my_helper
INFO - 2023-12-13 16:57:54 --> Database Driver Class Initialized
INFO - 2023-12-13 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 16:57:54 --> Controller Class Initialized
INFO - 2023-12-13 16:57:54 --> Final output sent to browser
DEBUG - 2023-12-13 16:57:54 --> Total execution time: 0.5457
INFO - 2023-12-13 17:24:46 --> Config Class Initialized
INFO - 2023-12-13 17:24:46 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:24:46 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:24:46 --> Utf8 Class Initialized
INFO - 2023-12-13 17:24:46 --> URI Class Initialized
INFO - 2023-12-13 17:24:47 --> Router Class Initialized
INFO - 2023-12-13 17:24:47 --> Output Class Initialized
INFO - 2023-12-13 17:24:47 --> Security Class Initialized
DEBUG - 2023-12-13 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:24:47 --> Input Class Initialized
INFO - 2023-12-13 17:24:47 --> Language Class Initialized
INFO - 2023-12-13 17:24:47 --> Language Class Initialized
INFO - 2023-12-13 17:24:47 --> Config Class Initialized
INFO - 2023-12-13 17:24:47 --> Loader Class Initialized
INFO - 2023-12-13 17:24:47 --> Helper loaded: url_helper
INFO - 2023-12-13 17:24:47 --> Helper loaded: file_helper
INFO - 2023-12-13 17:24:47 --> Helper loaded: form_helper
INFO - 2023-12-13 17:24:47 --> Helper loaded: my_helper
INFO - 2023-12-13 17:24:47 --> Database Driver Class Initialized
INFO - 2023-12-13 17:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:24:47 --> Controller Class Initialized
DEBUG - 2023-12-13 17:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-13 17:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:24:47 --> Final output sent to browser
DEBUG - 2023-12-13 17:24:47 --> Total execution time: 0.5436
INFO - 2023-12-13 17:24:56 --> Config Class Initialized
INFO - 2023-12-13 17:24:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:24:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:24:56 --> Utf8 Class Initialized
INFO - 2023-12-13 17:24:56 --> URI Class Initialized
INFO - 2023-12-13 17:24:56 --> Router Class Initialized
INFO - 2023-12-13 17:24:56 --> Output Class Initialized
INFO - 2023-12-13 17:24:56 --> Security Class Initialized
DEBUG - 2023-12-13 17:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:24:56 --> Input Class Initialized
INFO - 2023-12-13 17:24:56 --> Language Class Initialized
INFO - 2023-12-13 17:24:56 --> Language Class Initialized
INFO - 2023-12-13 17:24:56 --> Config Class Initialized
INFO - 2023-12-13 17:24:56 --> Loader Class Initialized
INFO - 2023-12-13 17:24:56 --> Helper loaded: url_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: file_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: form_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: my_helper
INFO - 2023-12-13 17:24:56 --> Database Driver Class Initialized
INFO - 2023-12-13 17:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:24:56 --> Controller Class Initialized
INFO - 2023-12-13 17:24:56 --> Helper loaded: cookie_helper
INFO - 2023-12-13 17:24:56 --> Final output sent to browser
DEBUG - 2023-12-13 17:24:56 --> Total execution time: 0.3122
INFO - 2023-12-13 17:24:56 --> Config Class Initialized
INFO - 2023-12-13 17:24:56 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:24:56 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:24:56 --> Utf8 Class Initialized
INFO - 2023-12-13 17:24:56 --> URI Class Initialized
INFO - 2023-12-13 17:24:56 --> Router Class Initialized
INFO - 2023-12-13 17:24:56 --> Output Class Initialized
INFO - 2023-12-13 17:24:56 --> Security Class Initialized
DEBUG - 2023-12-13 17:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:24:56 --> Input Class Initialized
INFO - 2023-12-13 17:24:56 --> Language Class Initialized
INFO - 2023-12-13 17:24:56 --> Language Class Initialized
INFO - 2023-12-13 17:24:56 --> Config Class Initialized
INFO - 2023-12-13 17:24:56 --> Loader Class Initialized
INFO - 2023-12-13 17:24:56 --> Helper loaded: url_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: file_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: form_helper
INFO - 2023-12-13 17:24:56 --> Helper loaded: my_helper
INFO - 2023-12-13 17:24:56 --> Database Driver Class Initialized
INFO - 2023-12-13 17:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:24:56 --> Controller Class Initialized
DEBUG - 2023-12-13 17:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-13 17:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:24:56 --> Final output sent to browser
DEBUG - 2023-12-13 17:24:56 --> Total execution time: 0.1813
INFO - 2023-12-13 17:25:00 --> Config Class Initialized
INFO - 2023-12-13 17:25:00 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:00 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:00 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:00 --> URI Class Initialized
INFO - 2023-12-13 17:25:00 --> Router Class Initialized
INFO - 2023-12-13 17:25:00 --> Output Class Initialized
INFO - 2023-12-13 17:25:00 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:00 --> Input Class Initialized
INFO - 2023-12-13 17:25:00 --> Language Class Initialized
INFO - 2023-12-13 17:25:00 --> Language Class Initialized
INFO - 2023-12-13 17:25:00 --> Config Class Initialized
INFO - 2023-12-13 17:25:00 --> Loader Class Initialized
INFO - 2023-12-13 17:25:00 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:00 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:00 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:00 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:00 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:00 --> Controller Class Initialized
DEBUG - 2023-12-13 17:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 17:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:25:00 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:00 --> Total execution time: 0.2415
INFO - 2023-12-13 17:25:05 --> Config Class Initialized
INFO - 2023-12-13 17:25:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:05 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:05 --> URI Class Initialized
INFO - 2023-12-13 17:25:05 --> Router Class Initialized
INFO - 2023-12-13 17:25:05 --> Output Class Initialized
INFO - 2023-12-13 17:25:05 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:05 --> Input Class Initialized
INFO - 2023-12-13 17:25:05 --> Language Class Initialized
INFO - 2023-12-13 17:25:05 --> Language Class Initialized
INFO - 2023-12-13 17:25:05 --> Config Class Initialized
INFO - 2023-12-13 17:25:05 --> Loader Class Initialized
INFO - 2023-12-13 17:25:05 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:05 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:05 --> Controller Class Initialized
DEBUG - 2023-12-13 17:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-13 17:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:25:05 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:05 --> Total execution time: 0.2914
INFO - 2023-12-13 17:25:05 --> Config Class Initialized
INFO - 2023-12-13 17:25:05 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:05 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:05 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:05 --> URI Class Initialized
INFO - 2023-12-13 17:25:05 --> Router Class Initialized
INFO - 2023-12-13 17:25:05 --> Output Class Initialized
INFO - 2023-12-13 17:25:05 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:05 --> Input Class Initialized
INFO - 2023-12-13 17:25:05 --> Language Class Initialized
INFO - 2023-12-13 17:25:05 --> Language Class Initialized
INFO - 2023-12-13 17:25:05 --> Config Class Initialized
INFO - 2023-12-13 17:25:05 --> Loader Class Initialized
INFO - 2023-12-13 17:25:05 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:05 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:06 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:06 --> Controller Class Initialized
INFO - 2023-12-13 17:25:09 --> Config Class Initialized
INFO - 2023-12-13 17:25:09 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:09 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:09 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:09 --> URI Class Initialized
INFO - 2023-12-13 17:25:09 --> Router Class Initialized
INFO - 2023-12-13 17:25:09 --> Output Class Initialized
INFO - 2023-12-13 17:25:09 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:09 --> Input Class Initialized
INFO - 2023-12-13 17:25:09 --> Language Class Initialized
INFO - 2023-12-13 17:25:10 --> Language Class Initialized
INFO - 2023-12-13 17:25:10 --> Config Class Initialized
INFO - 2023-12-13 17:25:10 --> Loader Class Initialized
INFO - 2023-12-13 17:25:10 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:10 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:10 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:10 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:10 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:10 --> Controller Class Initialized
INFO - 2023-12-13 17:25:10 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:10 --> Total execution time: 0.2658
INFO - 2023-12-13 17:25:12 --> Config Class Initialized
INFO - 2023-12-13 17:25:12 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:12 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:12 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:12 --> URI Class Initialized
INFO - 2023-12-13 17:25:12 --> Router Class Initialized
INFO - 2023-12-13 17:25:12 --> Output Class Initialized
INFO - 2023-12-13 17:25:12 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:12 --> Input Class Initialized
INFO - 2023-12-13 17:25:12 --> Language Class Initialized
INFO - 2023-12-13 17:25:12 --> Language Class Initialized
INFO - 2023-12-13 17:25:12 --> Config Class Initialized
INFO - 2023-12-13 17:25:12 --> Loader Class Initialized
INFO - 2023-12-13 17:25:12 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:12 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:12 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:12 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:12 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:12 --> Controller Class Initialized
INFO - 2023-12-13 17:25:12 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:12 --> Total execution time: 0.3206
INFO - 2023-12-13 17:25:16 --> Config Class Initialized
INFO - 2023-12-13 17:25:16 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:16 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:16 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:16 --> URI Class Initialized
INFO - 2023-12-13 17:25:17 --> Router Class Initialized
INFO - 2023-12-13 17:25:17 --> Output Class Initialized
INFO - 2023-12-13 17:25:17 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:17 --> Input Class Initialized
INFO - 2023-12-13 17:25:17 --> Language Class Initialized
INFO - 2023-12-13 17:25:17 --> Language Class Initialized
INFO - 2023-12-13 17:25:17 --> Config Class Initialized
INFO - 2023-12-13 17:25:17 --> Loader Class Initialized
INFO - 2023-12-13 17:25:17 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:17 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:17 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:17 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:17 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:17 --> Controller Class Initialized
DEBUG - 2023-12-13 17:25:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-13 17:25:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:25:17 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:17 --> Total execution time: 0.2859
INFO - 2023-12-13 17:25:20 --> Config Class Initialized
INFO - 2023-12-13 17:25:20 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:20 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:20 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:20 --> URI Class Initialized
INFO - 2023-12-13 17:25:20 --> Router Class Initialized
INFO - 2023-12-13 17:25:20 --> Output Class Initialized
INFO - 2023-12-13 17:25:20 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:20 --> Input Class Initialized
INFO - 2023-12-13 17:25:20 --> Language Class Initialized
INFO - 2023-12-13 17:25:20 --> Language Class Initialized
INFO - 2023-12-13 17:25:20 --> Config Class Initialized
INFO - 2023-12-13 17:25:20 --> Loader Class Initialized
INFO - 2023-12-13 17:25:20 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:20 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:20 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:20 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:20 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:20 --> Controller Class Initialized
DEBUG - 2023-12-13 17:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-13 17:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-13 17:25:20 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:20 --> Total execution time: 0.3198
INFO - 2023-12-13 17:25:26 --> Config Class Initialized
INFO - 2023-12-13 17:25:26 --> Hooks Class Initialized
DEBUG - 2023-12-13 17:25:26 --> UTF-8 Support Enabled
INFO - 2023-12-13 17:25:26 --> Utf8 Class Initialized
INFO - 2023-12-13 17:25:26 --> URI Class Initialized
INFO - 2023-12-13 17:25:26 --> Router Class Initialized
INFO - 2023-12-13 17:25:26 --> Output Class Initialized
INFO - 2023-12-13 17:25:26 --> Security Class Initialized
DEBUG - 2023-12-13 17:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-13 17:25:26 --> Input Class Initialized
INFO - 2023-12-13 17:25:26 --> Language Class Initialized
INFO - 2023-12-13 17:25:26 --> Language Class Initialized
INFO - 2023-12-13 17:25:26 --> Config Class Initialized
INFO - 2023-12-13 17:25:26 --> Loader Class Initialized
INFO - 2023-12-13 17:25:26 --> Helper loaded: url_helper
INFO - 2023-12-13 17:25:26 --> Helper loaded: file_helper
INFO - 2023-12-13 17:25:26 --> Helper loaded: form_helper
INFO - 2023-12-13 17:25:26 --> Helper loaded: my_helper
INFO - 2023-12-13 17:25:26 --> Database Driver Class Initialized
INFO - 2023-12-13 17:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-13 17:25:26 --> Controller Class Initialized
INFO - 2023-12-13 17:25:26 --> Final output sent to browser
DEBUG - 2023-12-13 17:25:26 --> Total execution time: 0.1778
