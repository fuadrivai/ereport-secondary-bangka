<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-08 08:54:54 --> Config Class Initialized
INFO - 2024-10-08 08:54:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:54:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:54:54 --> Utf8 Class Initialized
INFO - 2024-10-08 08:54:54 --> URI Class Initialized
INFO - 2024-10-08 08:54:54 --> Router Class Initialized
INFO - 2024-10-08 08:54:54 --> Output Class Initialized
INFO - 2024-10-08 08:54:54 --> Security Class Initialized
DEBUG - 2024-10-08 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:54:54 --> Input Class Initialized
INFO - 2024-10-08 08:54:54 --> Language Class Initialized
INFO - 2024-10-08 08:54:54 --> Language Class Initialized
INFO - 2024-10-08 08:54:54 --> Config Class Initialized
INFO - 2024-10-08 08:54:54 --> Loader Class Initialized
INFO - 2024-10-08 08:54:54 --> Helper loaded: url_helper
INFO - 2024-10-08 08:54:54 --> Helper loaded: file_helper
INFO - 2024-10-08 08:54:54 --> Helper loaded: form_helper
INFO - 2024-10-08 08:54:54 --> Helper loaded: my_helper
INFO - 2024-10-08 08:54:54 --> Database Driver Class Initialized
INFO - 2024-10-08 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:54:54 --> Controller Class Initialized
DEBUG - 2024-10-08 08:54:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 08:54:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 08:54:54 --> Final output sent to browser
DEBUG - 2024-10-08 08:54:54 --> Total execution time: 0.0511
INFO - 2024-10-08 08:55:18 --> Config Class Initialized
INFO - 2024-10-08 08:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:18 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:18 --> URI Class Initialized
INFO - 2024-10-08 08:55:18 --> Router Class Initialized
INFO - 2024-10-08 08:55:18 --> Output Class Initialized
INFO - 2024-10-08 08:55:18 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:18 --> Input Class Initialized
INFO - 2024-10-08 08:55:18 --> Language Class Initialized
INFO - 2024-10-08 08:55:18 --> Language Class Initialized
INFO - 2024-10-08 08:55:18 --> Config Class Initialized
INFO - 2024-10-08 08:55:18 --> Loader Class Initialized
INFO - 2024-10-08 08:55:18 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:18 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:18 --> Controller Class Initialized
INFO - 2024-10-08 08:55:18 --> Helper loaded: cookie_helper
INFO - 2024-10-08 08:55:18 --> Final output sent to browser
DEBUG - 2024-10-08 08:55:18 --> Total execution time: 0.0357
INFO - 2024-10-08 08:55:18 --> Config Class Initialized
INFO - 2024-10-08 08:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:18 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:18 --> URI Class Initialized
INFO - 2024-10-08 08:55:18 --> Router Class Initialized
INFO - 2024-10-08 08:55:18 --> Output Class Initialized
INFO - 2024-10-08 08:55:18 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:18 --> Input Class Initialized
INFO - 2024-10-08 08:55:18 --> Language Class Initialized
INFO - 2024-10-08 08:55:18 --> Language Class Initialized
INFO - 2024-10-08 08:55:18 --> Config Class Initialized
INFO - 2024-10-08 08:55:18 --> Loader Class Initialized
INFO - 2024-10-08 08:55:18 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:18 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:18 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:18 --> Controller Class Initialized
DEBUG - 2024-10-08 08:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 08:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 08:55:18 --> Final output sent to browser
DEBUG - 2024-10-08 08:55:18 --> Total execution time: 0.0462
INFO - 2024-10-08 08:55:20 --> Config Class Initialized
INFO - 2024-10-08 08:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:20 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:20 --> URI Class Initialized
INFO - 2024-10-08 08:55:20 --> Router Class Initialized
INFO - 2024-10-08 08:55:20 --> Output Class Initialized
INFO - 2024-10-08 08:55:20 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:20 --> Input Class Initialized
INFO - 2024-10-08 08:55:20 --> Language Class Initialized
INFO - 2024-10-08 08:55:20 --> Language Class Initialized
INFO - 2024-10-08 08:55:20 --> Config Class Initialized
INFO - 2024-10-08 08:55:20 --> Loader Class Initialized
INFO - 2024-10-08 08:55:20 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:20 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:20 --> Controller Class Initialized
DEBUG - 2024-10-08 08:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 08:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 08:55:20 --> Final output sent to browser
DEBUG - 2024-10-08 08:55:20 --> Total execution time: 0.0363
INFO - 2024-10-08 08:55:20 --> Config Class Initialized
INFO - 2024-10-08 08:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:20 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:20 --> URI Class Initialized
INFO - 2024-10-08 08:55:20 --> Router Class Initialized
INFO - 2024-10-08 08:55:20 --> Output Class Initialized
INFO - 2024-10-08 08:55:20 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:20 --> Input Class Initialized
INFO - 2024-10-08 08:55:20 --> Language Class Initialized
ERROR - 2024-10-08 08:55:20 --> 404 Page Not Found: /index
INFO - 2024-10-08 08:55:20 --> Config Class Initialized
INFO - 2024-10-08 08:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:20 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:20 --> URI Class Initialized
INFO - 2024-10-08 08:55:20 --> Router Class Initialized
INFO - 2024-10-08 08:55:20 --> Output Class Initialized
INFO - 2024-10-08 08:55:20 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:20 --> Input Class Initialized
INFO - 2024-10-08 08:55:20 --> Language Class Initialized
INFO - 2024-10-08 08:55:20 --> Language Class Initialized
INFO - 2024-10-08 08:55:20 --> Config Class Initialized
INFO - 2024-10-08 08:55:20 --> Loader Class Initialized
INFO - 2024-10-08 08:55:20 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:20 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:20 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:20 --> Controller Class Initialized
INFO - 2024-10-08 08:55:23 --> Config Class Initialized
INFO - 2024-10-08 08:55:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:23 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:23 --> URI Class Initialized
INFO - 2024-10-08 08:55:23 --> Router Class Initialized
INFO - 2024-10-08 08:55:23 --> Output Class Initialized
INFO - 2024-10-08 08:55:23 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:23 --> Input Class Initialized
INFO - 2024-10-08 08:55:23 --> Language Class Initialized
INFO - 2024-10-08 08:55:23 --> Language Class Initialized
INFO - 2024-10-08 08:55:23 --> Config Class Initialized
INFO - 2024-10-08 08:55:23 --> Loader Class Initialized
INFO - 2024-10-08 08:55:23 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:23 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:23 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:23 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:23 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:23 --> Controller Class Initialized
INFO - 2024-10-08 08:55:24 --> Config Class Initialized
INFO - 2024-10-08 08:55:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:24 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:24 --> URI Class Initialized
INFO - 2024-10-08 08:55:24 --> Router Class Initialized
INFO - 2024-10-08 08:55:24 --> Output Class Initialized
INFO - 2024-10-08 08:55:24 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:24 --> Input Class Initialized
INFO - 2024-10-08 08:55:24 --> Language Class Initialized
INFO - 2024-10-08 08:55:24 --> Language Class Initialized
INFO - 2024-10-08 08:55:24 --> Config Class Initialized
INFO - 2024-10-08 08:55:24 --> Loader Class Initialized
INFO - 2024-10-08 08:55:24 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:24 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:24 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:24 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:24 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:24 --> Controller Class Initialized
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:32 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:32 --> URI Class Initialized
INFO - 2024-10-08 08:55:32 --> Router Class Initialized
INFO - 2024-10-08 08:55:32 --> Output Class Initialized
INFO - 2024-10-08 08:55:32 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:32 --> Input Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Loader Class Initialized
INFO - 2024-10-08 08:55:32 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:32 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:32 --> Controller Class Initialized
INFO - 2024-10-08 08:55:32 --> Helper loaded: cookie_helper
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:32 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:32 --> URI Class Initialized
INFO - 2024-10-08 08:55:32 --> Router Class Initialized
INFO - 2024-10-08 08:55:32 --> Output Class Initialized
INFO - 2024-10-08 08:55:32 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:32 --> Input Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Loader Class Initialized
INFO - 2024-10-08 08:55:32 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:32 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:32 --> Controller Class Initialized
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 08:55:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 08:55:32 --> Utf8 Class Initialized
INFO - 2024-10-08 08:55:32 --> URI Class Initialized
INFO - 2024-10-08 08:55:32 --> Router Class Initialized
INFO - 2024-10-08 08:55:32 --> Output Class Initialized
INFO - 2024-10-08 08:55:32 --> Security Class Initialized
DEBUG - 2024-10-08 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 08:55:32 --> Input Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Language Class Initialized
INFO - 2024-10-08 08:55:32 --> Config Class Initialized
INFO - 2024-10-08 08:55:32 --> Loader Class Initialized
INFO - 2024-10-08 08:55:32 --> Helper loaded: url_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: file_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: form_helper
INFO - 2024-10-08 08:55:32 --> Helper loaded: my_helper
INFO - 2024-10-08 08:55:32 --> Database Driver Class Initialized
INFO - 2024-10-08 08:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 08:55:32 --> Controller Class Initialized
DEBUG - 2024-10-08 08:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 08:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 08:55:32 --> Final output sent to browser
DEBUG - 2024-10-08 08:55:32 --> Total execution time: 0.0299
INFO - 2024-10-08 09:02:38 --> Config Class Initialized
INFO - 2024-10-08 09:02:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:38 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:38 --> URI Class Initialized
INFO - 2024-10-08 09:02:38 --> Router Class Initialized
INFO - 2024-10-08 09:02:38 --> Output Class Initialized
INFO - 2024-10-08 09:02:38 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:38 --> Input Class Initialized
INFO - 2024-10-08 09:02:38 --> Language Class Initialized
INFO - 2024-10-08 09:02:38 --> Language Class Initialized
INFO - 2024-10-08 09:02:38 --> Config Class Initialized
INFO - 2024-10-08 09:02:38 --> Loader Class Initialized
INFO - 2024-10-08 09:02:38 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:38 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:38 --> Controller Class Initialized
INFO - 2024-10-08 09:02:38 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:02:38 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:38 --> Total execution time: 0.0792
INFO - 2024-10-08 09:02:38 --> Config Class Initialized
INFO - 2024-10-08 09:02:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:38 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:38 --> URI Class Initialized
INFO - 2024-10-08 09:02:38 --> Router Class Initialized
INFO - 2024-10-08 09:02:38 --> Output Class Initialized
INFO - 2024-10-08 09:02:38 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:38 --> Input Class Initialized
INFO - 2024-10-08 09:02:38 --> Language Class Initialized
INFO - 2024-10-08 09:02:38 --> Language Class Initialized
INFO - 2024-10-08 09:02:38 --> Config Class Initialized
INFO - 2024-10-08 09:02:38 --> Loader Class Initialized
INFO - 2024-10-08 09:02:38 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:38 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:38 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:38 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 09:02:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:02:38 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:38 --> Total execution time: 0.0393
INFO - 2024-10-08 09:02:44 --> Config Class Initialized
INFO - 2024-10-08 09:02:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:44 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:44 --> URI Class Initialized
INFO - 2024-10-08 09:02:44 --> Router Class Initialized
INFO - 2024-10-08 09:02:44 --> Output Class Initialized
INFO - 2024-10-08 09:02:44 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:44 --> Input Class Initialized
INFO - 2024-10-08 09:02:44 --> Language Class Initialized
INFO - 2024-10-08 09:02:44 --> Language Class Initialized
INFO - 2024-10-08 09:02:44 --> Config Class Initialized
INFO - 2024-10-08 09:02:44 --> Loader Class Initialized
INFO - 2024-10-08 09:02:44 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:45 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:45 --> Controller Class Initialized
INFO - 2024-10-08 09:02:45 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:02:45 --> Config Class Initialized
INFO - 2024-10-08 09:02:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:45 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:45 --> URI Class Initialized
INFO - 2024-10-08 09:02:45 --> Router Class Initialized
INFO - 2024-10-08 09:02:45 --> Output Class Initialized
INFO - 2024-10-08 09:02:45 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:45 --> Input Class Initialized
INFO - 2024-10-08 09:02:45 --> Language Class Initialized
INFO - 2024-10-08 09:02:45 --> Language Class Initialized
INFO - 2024-10-08 09:02:45 --> Config Class Initialized
INFO - 2024-10-08 09:02:45 --> Loader Class Initialized
INFO - 2024-10-08 09:02:45 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:45 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:45 --> Controller Class Initialized
INFO - 2024-10-08 09:02:45 --> Config Class Initialized
INFO - 2024-10-08 09:02:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:45 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:45 --> URI Class Initialized
INFO - 2024-10-08 09:02:45 --> Router Class Initialized
INFO - 2024-10-08 09:02:45 --> Output Class Initialized
INFO - 2024-10-08 09:02:45 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:45 --> Input Class Initialized
INFO - 2024-10-08 09:02:45 --> Language Class Initialized
INFO - 2024-10-08 09:02:45 --> Language Class Initialized
INFO - 2024-10-08 09:02:45 --> Config Class Initialized
INFO - 2024-10-08 09:02:45 --> Loader Class Initialized
INFO - 2024-10-08 09:02:45 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:45 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:45 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:45 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 09:02:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:02:45 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:45 --> Total execution time: 0.0473
INFO - 2024-10-08 09:02:56 --> Config Class Initialized
INFO - 2024-10-08 09:02:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:56 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:56 --> URI Class Initialized
INFO - 2024-10-08 09:02:56 --> Router Class Initialized
INFO - 2024-10-08 09:02:56 --> Output Class Initialized
INFO - 2024-10-08 09:02:56 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:56 --> Input Class Initialized
INFO - 2024-10-08 09:02:56 --> Language Class Initialized
INFO - 2024-10-08 09:02:56 --> Language Class Initialized
INFO - 2024-10-08 09:02:56 --> Config Class Initialized
INFO - 2024-10-08 09:02:56 --> Loader Class Initialized
INFO - 2024-10-08 09:02:56 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:56 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:56 --> Controller Class Initialized
INFO - 2024-10-08 09:02:56 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:02:56 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:56 --> Total execution time: 0.4912
INFO - 2024-10-08 09:02:56 --> Config Class Initialized
INFO - 2024-10-08 09:02:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:56 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:56 --> URI Class Initialized
INFO - 2024-10-08 09:02:56 --> Router Class Initialized
INFO - 2024-10-08 09:02:56 --> Output Class Initialized
INFO - 2024-10-08 09:02:56 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:56 --> Input Class Initialized
INFO - 2024-10-08 09:02:56 --> Language Class Initialized
INFO - 2024-10-08 09:02:56 --> Language Class Initialized
INFO - 2024-10-08 09:02:56 --> Config Class Initialized
INFO - 2024-10-08 09:02:56 --> Loader Class Initialized
INFO - 2024-10-08 09:02:56 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:56 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:56 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:56 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 09:02:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:02:56 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:56 --> Total execution time: 0.1011
INFO - 2024-10-08 09:02:57 --> Config Class Initialized
INFO - 2024-10-08 09:02:57 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:57 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:57 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:57 --> URI Class Initialized
INFO - 2024-10-08 09:02:57 --> Router Class Initialized
INFO - 2024-10-08 09:02:57 --> Output Class Initialized
INFO - 2024-10-08 09:02:57 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:57 --> Input Class Initialized
INFO - 2024-10-08 09:02:57 --> Language Class Initialized
INFO - 2024-10-08 09:02:57 --> Language Class Initialized
INFO - 2024-10-08 09:02:57 --> Config Class Initialized
INFO - 2024-10-08 09:02:57 --> Loader Class Initialized
INFO - 2024-10-08 09:02:57 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:57 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:57 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:57 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:57 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:57 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 09:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:02:57 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:57 --> Total execution time: 0.0330
INFO - 2024-10-08 09:02:59 --> Config Class Initialized
INFO - 2024-10-08 09:02:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:02:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:02:59 --> Utf8 Class Initialized
INFO - 2024-10-08 09:02:59 --> URI Class Initialized
INFO - 2024-10-08 09:02:59 --> Router Class Initialized
INFO - 2024-10-08 09:02:59 --> Output Class Initialized
INFO - 2024-10-08 09:02:59 --> Security Class Initialized
DEBUG - 2024-10-08 09:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:02:59 --> Input Class Initialized
INFO - 2024-10-08 09:02:59 --> Language Class Initialized
INFO - 2024-10-08 09:02:59 --> Language Class Initialized
INFO - 2024-10-08 09:02:59 --> Config Class Initialized
INFO - 2024-10-08 09:02:59 --> Loader Class Initialized
INFO - 2024-10-08 09:02:59 --> Helper loaded: url_helper
INFO - 2024-10-08 09:02:59 --> Helper loaded: file_helper
INFO - 2024-10-08 09:02:59 --> Helper loaded: form_helper
INFO - 2024-10-08 09:02:59 --> Helper loaded: my_helper
INFO - 2024-10-08 09:02:59 --> Database Driver Class Initialized
INFO - 2024-10-08 09:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:02:59 --> Controller Class Initialized
DEBUG - 2024-10-08 09:02:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 09:02:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:02:59 --> Final output sent to browser
DEBUG - 2024-10-08 09:02:59 --> Total execution time: 0.0376
INFO - 2024-10-08 09:03:01 --> Config Class Initialized
INFO - 2024-10-08 09:03:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:01 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:01 --> URI Class Initialized
INFO - 2024-10-08 09:03:01 --> Router Class Initialized
INFO - 2024-10-08 09:03:01 --> Output Class Initialized
INFO - 2024-10-08 09:03:01 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:01 --> Input Class Initialized
INFO - 2024-10-08 09:03:01 --> Language Class Initialized
INFO - 2024-10-08 09:03:01 --> Language Class Initialized
INFO - 2024-10-08 09:03:01 --> Config Class Initialized
INFO - 2024-10-08 09:03:01 --> Loader Class Initialized
INFO - 2024-10-08 09:03:01 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:01 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:01 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:01 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:01 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:01 --> Controller Class Initialized
INFO - 2024-10-08 09:03:01 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:01 --> Total execution time: 0.0434
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:33 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:33 --> URI Class Initialized
INFO - 2024-10-08 09:03:33 --> Router Class Initialized
INFO - 2024-10-08 09:03:33 --> Output Class Initialized
INFO - 2024-10-08 09:03:33 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:33 --> Input Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Loader Class Initialized
INFO - 2024-10-08 09:03:33 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:33 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:33 --> Controller Class Initialized
INFO - 2024-10-08 09:03:33 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:33 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:33 --> URI Class Initialized
INFO - 2024-10-08 09:03:33 --> Router Class Initialized
INFO - 2024-10-08 09:03:33 --> Output Class Initialized
INFO - 2024-10-08 09:03:33 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:33 --> Input Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Loader Class Initialized
INFO - 2024-10-08 09:03:33 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:33 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:33 --> Controller Class Initialized
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:33 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:33 --> URI Class Initialized
INFO - 2024-10-08 09:03:33 --> Router Class Initialized
INFO - 2024-10-08 09:03:33 --> Output Class Initialized
INFO - 2024-10-08 09:03:33 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:33 --> Input Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Language Class Initialized
INFO - 2024-10-08 09:03:33 --> Config Class Initialized
INFO - 2024-10-08 09:03:33 --> Loader Class Initialized
INFO - 2024-10-08 09:03:33 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:33 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:33 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:33 --> Controller Class Initialized
DEBUG - 2024-10-08 09:03:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 09:03:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:03:33 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:33 --> Total execution time: 0.0328
INFO - 2024-10-08 09:03:39 --> Config Class Initialized
INFO - 2024-10-08 09:03:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:39 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:39 --> URI Class Initialized
INFO - 2024-10-08 09:03:39 --> Router Class Initialized
INFO - 2024-10-08 09:03:39 --> Output Class Initialized
INFO - 2024-10-08 09:03:39 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:39 --> Input Class Initialized
INFO - 2024-10-08 09:03:39 --> Language Class Initialized
INFO - 2024-10-08 09:03:39 --> Language Class Initialized
INFO - 2024-10-08 09:03:39 --> Config Class Initialized
INFO - 2024-10-08 09:03:39 --> Loader Class Initialized
INFO - 2024-10-08 09:03:39 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:39 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:39 --> Controller Class Initialized
INFO - 2024-10-08 09:03:39 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:03:39 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:39 --> Total execution time: 0.0310
INFO - 2024-10-08 09:03:39 --> Config Class Initialized
INFO - 2024-10-08 09:03:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:39 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:39 --> URI Class Initialized
INFO - 2024-10-08 09:03:39 --> Router Class Initialized
INFO - 2024-10-08 09:03:39 --> Output Class Initialized
INFO - 2024-10-08 09:03:39 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:39 --> Input Class Initialized
INFO - 2024-10-08 09:03:39 --> Language Class Initialized
INFO - 2024-10-08 09:03:39 --> Language Class Initialized
INFO - 2024-10-08 09:03:39 --> Config Class Initialized
INFO - 2024-10-08 09:03:39 --> Loader Class Initialized
INFO - 2024-10-08 09:03:39 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:39 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:39 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:39 --> Controller Class Initialized
DEBUG - 2024-10-08 09:03:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 09:03:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:03:39 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:39 --> Total execution time: 0.0386
INFO - 2024-10-08 09:03:42 --> Config Class Initialized
INFO - 2024-10-08 09:03:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:42 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:42 --> URI Class Initialized
INFO - 2024-10-08 09:03:42 --> Router Class Initialized
INFO - 2024-10-08 09:03:42 --> Output Class Initialized
INFO - 2024-10-08 09:03:42 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:42 --> Input Class Initialized
INFO - 2024-10-08 09:03:42 --> Language Class Initialized
INFO - 2024-10-08 09:03:42 --> Language Class Initialized
INFO - 2024-10-08 09:03:42 --> Config Class Initialized
INFO - 2024-10-08 09:03:42 --> Loader Class Initialized
INFO - 2024-10-08 09:03:42 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:42 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:42 --> Controller Class Initialized
DEBUG - 2024-10-08 09:03:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-10-08 09:03:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:03:42 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:42 --> Total execution time: 0.0350
INFO - 2024-10-08 09:03:42 --> Config Class Initialized
INFO - 2024-10-08 09:03:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:42 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:42 --> URI Class Initialized
INFO - 2024-10-08 09:03:42 --> Router Class Initialized
INFO - 2024-10-08 09:03:42 --> Output Class Initialized
INFO - 2024-10-08 09:03:42 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:42 --> Input Class Initialized
INFO - 2024-10-08 09:03:42 --> Language Class Initialized
ERROR - 2024-10-08 09:03:42 --> 404 Page Not Found: /index
INFO - 2024-10-08 09:03:42 --> Config Class Initialized
INFO - 2024-10-08 09:03:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:42 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:42 --> URI Class Initialized
INFO - 2024-10-08 09:03:42 --> Router Class Initialized
INFO - 2024-10-08 09:03:42 --> Output Class Initialized
INFO - 2024-10-08 09:03:42 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:42 --> Input Class Initialized
INFO - 2024-10-08 09:03:42 --> Language Class Initialized
INFO - 2024-10-08 09:03:42 --> Language Class Initialized
INFO - 2024-10-08 09:03:42 --> Config Class Initialized
INFO - 2024-10-08 09:03:42 --> Loader Class Initialized
INFO - 2024-10-08 09:03:42 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:42 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:42 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:42 --> Controller Class Initialized
INFO - 2024-10-08 09:03:49 --> Config Class Initialized
INFO - 2024-10-08 09:03:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:49 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:49 --> URI Class Initialized
INFO - 2024-10-08 09:03:49 --> Router Class Initialized
INFO - 2024-10-08 09:03:49 --> Output Class Initialized
INFO - 2024-10-08 09:03:49 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:49 --> Input Class Initialized
INFO - 2024-10-08 09:03:49 --> Language Class Initialized
INFO - 2024-10-08 09:03:49 --> Language Class Initialized
INFO - 2024-10-08 09:03:49 --> Config Class Initialized
INFO - 2024-10-08 09:03:49 --> Loader Class Initialized
INFO - 2024-10-08 09:03:49 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:49 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:49 --> Controller Class Initialized
DEBUG - 2024-10-08 09:03:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 09:03:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:03:49 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:49 --> Total execution time: 0.1199
INFO - 2024-10-08 09:03:49 --> Config Class Initialized
INFO - 2024-10-08 09:03:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:49 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:49 --> URI Class Initialized
INFO - 2024-10-08 09:03:49 --> Router Class Initialized
INFO - 2024-10-08 09:03:49 --> Output Class Initialized
INFO - 2024-10-08 09:03:49 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:49 --> Input Class Initialized
INFO - 2024-10-08 09:03:49 --> Language Class Initialized
ERROR - 2024-10-08 09:03:49 --> 404 Page Not Found: /index
INFO - 2024-10-08 09:03:49 --> Config Class Initialized
INFO - 2024-10-08 09:03:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:49 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:49 --> URI Class Initialized
INFO - 2024-10-08 09:03:49 --> Router Class Initialized
INFO - 2024-10-08 09:03:49 --> Output Class Initialized
INFO - 2024-10-08 09:03:49 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:49 --> Input Class Initialized
INFO - 2024-10-08 09:03:49 --> Language Class Initialized
INFO - 2024-10-08 09:03:49 --> Language Class Initialized
INFO - 2024-10-08 09:03:49 --> Config Class Initialized
INFO - 2024-10-08 09:03:49 --> Loader Class Initialized
INFO - 2024-10-08 09:03:49 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:49 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:49 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:49 --> Controller Class Initialized
INFO - 2024-10-08 09:03:51 --> Config Class Initialized
INFO - 2024-10-08 09:03:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:51 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:51 --> URI Class Initialized
INFO - 2024-10-08 09:03:51 --> Router Class Initialized
INFO - 2024-10-08 09:03:51 --> Output Class Initialized
INFO - 2024-10-08 09:03:51 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:51 --> Input Class Initialized
INFO - 2024-10-08 09:03:51 --> Language Class Initialized
INFO - 2024-10-08 09:03:51 --> Language Class Initialized
INFO - 2024-10-08 09:03:51 --> Config Class Initialized
INFO - 2024-10-08 09:03:51 --> Loader Class Initialized
INFO - 2024-10-08 09:03:51 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:51 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:51 --> Controller Class Initialized
INFO - 2024-10-08 09:03:51 --> Config Class Initialized
INFO - 2024-10-08 09:03:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:51 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:51 --> URI Class Initialized
INFO - 2024-10-08 09:03:51 --> Router Class Initialized
INFO - 2024-10-08 09:03:51 --> Output Class Initialized
INFO - 2024-10-08 09:03:51 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:51 --> Input Class Initialized
INFO - 2024-10-08 09:03:51 --> Language Class Initialized
INFO - 2024-10-08 09:03:51 --> Language Class Initialized
INFO - 2024-10-08 09:03:51 --> Config Class Initialized
INFO - 2024-10-08 09:03:51 --> Loader Class Initialized
INFO - 2024-10-08 09:03:51 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:51 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:52 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:52 --> Controller Class Initialized
INFO - 2024-10-08 09:03:52 --> Config Class Initialized
INFO - 2024-10-08 09:03:52 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:52 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:52 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:52 --> URI Class Initialized
INFO - 2024-10-08 09:03:52 --> Router Class Initialized
INFO - 2024-10-08 09:03:52 --> Output Class Initialized
INFO - 2024-10-08 09:03:52 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:52 --> Input Class Initialized
INFO - 2024-10-08 09:03:52 --> Language Class Initialized
INFO - 2024-10-08 09:03:52 --> Language Class Initialized
INFO - 2024-10-08 09:03:52 --> Config Class Initialized
INFO - 2024-10-08 09:03:52 --> Loader Class Initialized
INFO - 2024-10-08 09:03:52 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:52 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:52 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:52 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:52 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:52 --> Controller Class Initialized
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:54 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:54 --> URI Class Initialized
INFO - 2024-10-08 09:03:54 --> Router Class Initialized
INFO - 2024-10-08 09:03:54 --> Output Class Initialized
INFO - 2024-10-08 09:03:54 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:54 --> Input Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Loader Class Initialized
INFO - 2024-10-08 09:03:54 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:54 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:54 --> Controller Class Initialized
INFO - 2024-10-08 09:03:54 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:54 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:54 --> URI Class Initialized
INFO - 2024-10-08 09:03:54 --> Router Class Initialized
INFO - 2024-10-08 09:03:54 --> Output Class Initialized
INFO - 2024-10-08 09:03:54 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:54 --> Input Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Loader Class Initialized
INFO - 2024-10-08 09:03:54 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:54 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:54 --> Controller Class Initialized
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:03:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:03:54 --> Utf8 Class Initialized
INFO - 2024-10-08 09:03:54 --> URI Class Initialized
INFO - 2024-10-08 09:03:54 --> Router Class Initialized
INFO - 2024-10-08 09:03:54 --> Output Class Initialized
INFO - 2024-10-08 09:03:54 --> Security Class Initialized
DEBUG - 2024-10-08 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:03:54 --> Input Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Language Class Initialized
INFO - 2024-10-08 09:03:54 --> Config Class Initialized
INFO - 2024-10-08 09:03:54 --> Loader Class Initialized
INFO - 2024-10-08 09:03:54 --> Helper loaded: url_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: file_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: form_helper
INFO - 2024-10-08 09:03:54 --> Helper loaded: my_helper
INFO - 2024-10-08 09:03:54 --> Database Driver Class Initialized
INFO - 2024-10-08 09:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:03:54 --> Controller Class Initialized
DEBUG - 2024-10-08 09:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 09:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:03:54 --> Final output sent to browser
DEBUG - 2024-10-08 09:03:54 --> Total execution time: 0.0389
INFO - 2024-10-08 09:04:00 --> Config Class Initialized
INFO - 2024-10-08 09:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:04:00 --> Utf8 Class Initialized
INFO - 2024-10-08 09:04:00 --> URI Class Initialized
INFO - 2024-10-08 09:04:00 --> Router Class Initialized
INFO - 2024-10-08 09:04:00 --> Output Class Initialized
INFO - 2024-10-08 09:04:00 --> Security Class Initialized
DEBUG - 2024-10-08 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:04:00 --> Input Class Initialized
INFO - 2024-10-08 09:04:00 --> Language Class Initialized
INFO - 2024-10-08 09:04:00 --> Language Class Initialized
INFO - 2024-10-08 09:04:00 --> Config Class Initialized
INFO - 2024-10-08 09:04:00 --> Loader Class Initialized
INFO - 2024-10-08 09:04:00 --> Helper loaded: url_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: file_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: form_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: my_helper
INFO - 2024-10-08 09:04:00 --> Database Driver Class Initialized
INFO - 2024-10-08 09:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:04:00 --> Controller Class Initialized
INFO - 2024-10-08 09:04:00 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:04:00 --> Final output sent to browser
DEBUG - 2024-10-08 09:04:00 --> Total execution time: 0.0402
INFO - 2024-10-08 09:04:00 --> Config Class Initialized
INFO - 2024-10-08 09:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:04:00 --> Utf8 Class Initialized
INFO - 2024-10-08 09:04:00 --> URI Class Initialized
INFO - 2024-10-08 09:04:00 --> Router Class Initialized
INFO - 2024-10-08 09:04:00 --> Output Class Initialized
INFO - 2024-10-08 09:04:00 --> Security Class Initialized
DEBUG - 2024-10-08 09:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:04:00 --> Input Class Initialized
INFO - 2024-10-08 09:04:00 --> Language Class Initialized
INFO - 2024-10-08 09:04:00 --> Language Class Initialized
INFO - 2024-10-08 09:04:00 --> Config Class Initialized
INFO - 2024-10-08 09:04:00 --> Loader Class Initialized
INFO - 2024-10-08 09:04:00 --> Helper loaded: url_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: file_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: form_helper
INFO - 2024-10-08 09:04:00 --> Helper loaded: my_helper
INFO - 2024-10-08 09:04:00 --> Database Driver Class Initialized
INFO - 2024-10-08 09:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:04:00 --> Controller Class Initialized
DEBUG - 2024-10-08 09:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 09:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:04:00 --> Final output sent to browser
DEBUG - 2024-10-08 09:04:00 --> Total execution time: 0.0745
INFO - 2024-10-08 09:04:20 --> Config Class Initialized
INFO - 2024-10-08 09:04:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:04:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:04:20 --> Utf8 Class Initialized
INFO - 2024-10-08 09:04:20 --> URI Class Initialized
INFO - 2024-10-08 09:04:20 --> Router Class Initialized
INFO - 2024-10-08 09:04:20 --> Output Class Initialized
INFO - 2024-10-08 09:04:20 --> Security Class Initialized
DEBUG - 2024-10-08 09:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:04:20 --> Input Class Initialized
INFO - 2024-10-08 09:04:20 --> Language Class Initialized
INFO - 2024-10-08 09:04:20 --> Language Class Initialized
INFO - 2024-10-08 09:04:20 --> Config Class Initialized
INFO - 2024-10-08 09:04:20 --> Loader Class Initialized
INFO - 2024-10-08 09:04:20 --> Helper loaded: url_helper
INFO - 2024-10-08 09:04:20 --> Helper loaded: file_helper
INFO - 2024-10-08 09:04:20 --> Helper loaded: form_helper
INFO - 2024-10-08 09:04:20 --> Helper loaded: my_helper
INFO - 2024-10-08 09:04:20 --> Database Driver Class Initialized
INFO - 2024-10-08 09:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:04:20 --> Controller Class Initialized
DEBUG - 2024-10-08 09:04:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-08 09:04:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:04:20 --> Final output sent to browser
DEBUG - 2024-10-08 09:04:20 --> Total execution time: 0.0542
INFO - 2024-10-08 09:25:30 --> Config Class Initialized
INFO - 2024-10-08 09:25:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:30 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:30 --> URI Class Initialized
INFO - 2024-10-08 09:25:30 --> Router Class Initialized
INFO - 2024-10-08 09:25:30 --> Output Class Initialized
INFO - 2024-10-08 09:25:30 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:30 --> Input Class Initialized
INFO - 2024-10-08 09:25:30 --> Language Class Initialized
INFO - 2024-10-08 09:25:30 --> Language Class Initialized
INFO - 2024-10-08 09:25:30 --> Config Class Initialized
INFO - 2024-10-08 09:25:30 --> Loader Class Initialized
INFO - 2024-10-08 09:25:30 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:30 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:30 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:30 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:30 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:30 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:30 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:31 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:31 --> URI Class Initialized
INFO - 2024-10-08 09:25:31 --> Router Class Initialized
INFO - 2024-10-08 09:25:31 --> Output Class Initialized
INFO - 2024-10-08 09:25:31 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:31 --> Input Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Loader Class Initialized
INFO - 2024-10-08 09:25:31 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:31 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:31 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:31 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:31 --> URI Class Initialized
INFO - 2024-10-08 09:25:31 --> Router Class Initialized
INFO - 2024-10-08 09:25:31 --> Output Class Initialized
INFO - 2024-10-08 09:25:31 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:31 --> Input Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Loader Class Initialized
INFO - 2024-10-08 09:25:31 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:31 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:31 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:31 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:31 --> URI Class Initialized
INFO - 2024-10-08 09:25:31 --> Router Class Initialized
INFO - 2024-10-08 09:25:31 --> Output Class Initialized
INFO - 2024-10-08 09:25:31 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:31 --> Input Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Loader Class Initialized
INFO - 2024-10-08 09:25:31 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:31 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:31 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:31 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:31 --> URI Class Initialized
INFO - 2024-10-08 09:25:31 --> Router Class Initialized
INFO - 2024-10-08 09:25:31 --> Output Class Initialized
INFO - 2024-10-08 09:25:31 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:31 --> Input Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Loader Class Initialized
INFO - 2024-10-08 09:25:31 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:31 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:31 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:31 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:31 --> URI Class Initialized
INFO - 2024-10-08 09:25:31 --> Router Class Initialized
INFO - 2024-10-08 09:25:31 --> Output Class Initialized
INFO - 2024-10-08 09:25:31 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:31 --> Input Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Language Class Initialized
INFO - 2024-10-08 09:25:31 --> Config Class Initialized
INFO - 2024-10-08 09:25:31 --> Loader Class Initialized
INFO - 2024-10-08 09:25:31 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:31 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:32 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:32 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:32 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:25:32 --> Config Class Initialized
INFO - 2024-10-08 09:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:25:32 --> Utf8 Class Initialized
INFO - 2024-10-08 09:25:32 --> URI Class Initialized
INFO - 2024-10-08 09:25:32 --> Router Class Initialized
INFO - 2024-10-08 09:25:32 --> Output Class Initialized
INFO - 2024-10-08 09:25:32 --> Security Class Initialized
DEBUG - 2024-10-08 09:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:25:32 --> Input Class Initialized
INFO - 2024-10-08 09:25:32 --> Language Class Initialized
INFO - 2024-10-08 09:25:32 --> Language Class Initialized
INFO - 2024-10-08 09:25:32 --> Config Class Initialized
INFO - 2024-10-08 09:25:32 --> Loader Class Initialized
INFO - 2024-10-08 09:25:32 --> Helper loaded: url_helper
INFO - 2024-10-08 09:25:32 --> Helper loaded: file_helper
INFO - 2024-10-08 09:25:32 --> Helper loaded: form_helper
INFO - 2024-10-08 09:25:32 --> Helper loaded: my_helper
INFO - 2024-10-08 09:25:32 --> Database Driver Class Initialized
INFO - 2024-10-08 09:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:25:32 --> Controller Class Initialized
ERROR - 2024-10-08 09:25:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 've learned will deepen your understanding.')' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '79', '8', '53', '-', 'You need to focus on strengthening his application of science concepts to real-world problems. Encouraging you to think beyond the classroom and apply what you've learned will deepen your understanding.')
INFO - 2024-10-08 09:25:32 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-08 09:52:39 --> Config Class Initialized
INFO - 2024-10-08 09:52:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:39 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:39 --> URI Class Initialized
INFO - 2024-10-08 09:52:39 --> Router Class Initialized
INFO - 2024-10-08 09:52:39 --> Output Class Initialized
INFO - 2024-10-08 09:52:39 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:39 --> Input Class Initialized
INFO - 2024-10-08 09:52:39 --> Language Class Initialized
INFO - 2024-10-08 09:52:39 --> Language Class Initialized
INFO - 2024-10-08 09:52:39 --> Config Class Initialized
INFO - 2024-10-08 09:52:39 --> Loader Class Initialized
INFO - 2024-10-08 09:52:39 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:39 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:39 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:39 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:39 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:39 --> Controller Class Initialized
DEBUG - 2024-10-08 09:52:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 09:52:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:52:39 --> Final output sent to browser
DEBUG - 2024-10-08 09:52:39 --> Total execution time: 0.0770
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:50 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:50 --> URI Class Initialized
INFO - 2024-10-08 09:52:50 --> Router Class Initialized
INFO - 2024-10-08 09:52:50 --> Output Class Initialized
INFO - 2024-10-08 09:52:50 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:50 --> Input Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Loader Class Initialized
INFO - 2024-10-08 09:52:50 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:50 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:50 --> Controller Class Initialized
INFO - 2024-10-08 09:52:50 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:50 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:50 --> URI Class Initialized
INFO - 2024-10-08 09:52:50 --> Router Class Initialized
INFO - 2024-10-08 09:52:50 --> Output Class Initialized
INFO - 2024-10-08 09:52:50 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:50 --> Input Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Loader Class Initialized
INFO - 2024-10-08 09:52:50 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:50 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:50 --> Controller Class Initialized
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:50 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:50 --> URI Class Initialized
INFO - 2024-10-08 09:52:50 --> Router Class Initialized
INFO - 2024-10-08 09:52:50 --> Output Class Initialized
INFO - 2024-10-08 09:52:50 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:50 --> Input Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Language Class Initialized
INFO - 2024-10-08 09:52:50 --> Config Class Initialized
INFO - 2024-10-08 09:52:50 --> Loader Class Initialized
INFO - 2024-10-08 09:52:50 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:50 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:50 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:50 --> Controller Class Initialized
DEBUG - 2024-10-08 09:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 09:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:52:50 --> Final output sent to browser
DEBUG - 2024-10-08 09:52:50 --> Total execution time: 0.0393
INFO - 2024-10-08 09:52:51 --> Config Class Initialized
INFO - 2024-10-08 09:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:51 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:51 --> URI Class Initialized
INFO - 2024-10-08 09:52:51 --> Router Class Initialized
INFO - 2024-10-08 09:52:51 --> Output Class Initialized
INFO - 2024-10-08 09:52:51 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:51 --> Input Class Initialized
INFO - 2024-10-08 09:52:51 --> Language Class Initialized
INFO - 2024-10-08 09:52:51 --> Language Class Initialized
INFO - 2024-10-08 09:52:51 --> Config Class Initialized
INFO - 2024-10-08 09:52:51 --> Loader Class Initialized
INFO - 2024-10-08 09:52:51 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:51 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:51 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:51 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:51 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:51 --> Controller Class Initialized
INFO - 2024-10-08 09:52:51 --> Helper loaded: cookie_helper
INFO - 2024-10-08 09:52:51 --> Final output sent to browser
DEBUG - 2024-10-08 09:52:51 --> Total execution time: 0.0395
INFO - 2024-10-08 09:52:51 --> Config Class Initialized
INFO - 2024-10-08 09:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:52:51 --> Utf8 Class Initialized
INFO - 2024-10-08 09:52:51 --> URI Class Initialized
INFO - 2024-10-08 09:52:51 --> Router Class Initialized
INFO - 2024-10-08 09:52:52 --> Output Class Initialized
INFO - 2024-10-08 09:52:52 --> Security Class Initialized
DEBUG - 2024-10-08 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:52:52 --> Input Class Initialized
INFO - 2024-10-08 09:52:52 --> Language Class Initialized
INFO - 2024-10-08 09:52:52 --> Language Class Initialized
INFO - 2024-10-08 09:52:52 --> Config Class Initialized
INFO - 2024-10-08 09:52:52 --> Loader Class Initialized
INFO - 2024-10-08 09:52:52 --> Helper loaded: url_helper
INFO - 2024-10-08 09:52:52 --> Helper loaded: file_helper
INFO - 2024-10-08 09:52:52 --> Helper loaded: form_helper
INFO - 2024-10-08 09:52:52 --> Helper loaded: my_helper
INFO - 2024-10-08 09:52:52 --> Database Driver Class Initialized
INFO - 2024-10-08 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:52:52 --> Controller Class Initialized
DEBUG - 2024-10-08 09:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 09:52:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:52:52 --> Final output sent to browser
DEBUG - 2024-10-08 09:52:52 --> Total execution time: 0.0424
INFO - 2024-10-08 09:53:03 --> Config Class Initialized
INFO - 2024-10-08 09:53:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:53:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:53:03 --> Utf8 Class Initialized
INFO - 2024-10-08 09:53:03 --> URI Class Initialized
INFO - 2024-10-08 09:53:03 --> Router Class Initialized
INFO - 2024-10-08 09:53:03 --> Output Class Initialized
INFO - 2024-10-08 09:53:03 --> Security Class Initialized
DEBUG - 2024-10-08 09:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:53:03 --> Input Class Initialized
INFO - 2024-10-08 09:53:03 --> Language Class Initialized
INFO - 2024-10-08 09:53:03 --> Language Class Initialized
INFO - 2024-10-08 09:53:03 --> Config Class Initialized
INFO - 2024-10-08 09:53:03 --> Loader Class Initialized
INFO - 2024-10-08 09:53:03 --> Helper loaded: url_helper
INFO - 2024-10-08 09:53:03 --> Helper loaded: file_helper
INFO - 2024-10-08 09:53:03 --> Helper loaded: form_helper
INFO - 2024-10-08 09:53:03 --> Helper loaded: my_helper
INFO - 2024-10-08 09:53:03 --> Database Driver Class Initialized
INFO - 2024-10-08 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:53:03 --> Controller Class Initialized
DEBUG - 2024-10-08 09:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 09:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 09:53:03 --> Final output sent to browser
DEBUG - 2024-10-08 09:53:03 --> Total execution time: 0.0438
INFO - 2024-10-08 09:53:13 --> Config Class Initialized
INFO - 2024-10-08 09:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 09:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 09:53:13 --> Utf8 Class Initialized
INFO - 2024-10-08 09:53:13 --> URI Class Initialized
INFO - 2024-10-08 09:53:13 --> Router Class Initialized
INFO - 2024-10-08 09:53:13 --> Output Class Initialized
INFO - 2024-10-08 09:53:13 --> Security Class Initialized
DEBUG - 2024-10-08 09:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 09:53:13 --> Input Class Initialized
INFO - 2024-10-08 09:53:13 --> Language Class Initialized
INFO - 2024-10-08 09:53:13 --> Language Class Initialized
INFO - 2024-10-08 09:53:13 --> Config Class Initialized
INFO - 2024-10-08 09:53:13 --> Loader Class Initialized
INFO - 2024-10-08 09:53:13 --> Helper loaded: url_helper
INFO - 2024-10-08 09:53:13 --> Helper loaded: file_helper
INFO - 2024-10-08 09:53:13 --> Helper loaded: form_helper
INFO - 2024-10-08 09:53:13 --> Helper loaded: my_helper
INFO - 2024-10-08 09:53:13 --> Database Driver Class Initialized
INFO - 2024-10-08 09:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 09:53:13 --> Controller Class Initialized
DEBUG - 2024-10-08 09:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 09:53:16 --> Final output sent to browser
DEBUG - 2024-10-08 09:53:16 --> Total execution time: 3.0169
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:05:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:05:40 --> Utf8 Class Initialized
INFO - 2024-10-08 10:05:40 --> URI Class Initialized
INFO - 2024-10-08 10:05:40 --> Router Class Initialized
INFO - 2024-10-08 10:05:40 --> Output Class Initialized
INFO - 2024-10-08 10:05:40 --> Security Class Initialized
DEBUG - 2024-10-08 10:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:05:40 --> Input Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Loader Class Initialized
INFO - 2024-10-08 10:05:40 --> Helper loaded: url_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: file_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: form_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: my_helper
INFO - 2024-10-08 10:05:40 --> Database Driver Class Initialized
INFO - 2024-10-08 10:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:05:40 --> Controller Class Initialized
INFO - 2024-10-08 10:05:40 --> Helper loaded: cookie_helper
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:05:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:05:40 --> Utf8 Class Initialized
INFO - 2024-10-08 10:05:40 --> URI Class Initialized
INFO - 2024-10-08 10:05:40 --> Router Class Initialized
INFO - 2024-10-08 10:05:40 --> Output Class Initialized
INFO - 2024-10-08 10:05:40 --> Security Class Initialized
DEBUG - 2024-10-08 10:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:05:40 --> Input Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Loader Class Initialized
INFO - 2024-10-08 10:05:40 --> Helper loaded: url_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: file_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: form_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: my_helper
INFO - 2024-10-08 10:05:40 --> Database Driver Class Initialized
INFO - 2024-10-08 10:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:05:40 --> Controller Class Initialized
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:05:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:05:40 --> Utf8 Class Initialized
INFO - 2024-10-08 10:05:40 --> URI Class Initialized
INFO - 2024-10-08 10:05:40 --> Router Class Initialized
INFO - 2024-10-08 10:05:40 --> Output Class Initialized
INFO - 2024-10-08 10:05:40 --> Security Class Initialized
DEBUG - 2024-10-08 10:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:05:40 --> Input Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Language Class Initialized
INFO - 2024-10-08 10:05:40 --> Config Class Initialized
INFO - 2024-10-08 10:05:40 --> Loader Class Initialized
INFO - 2024-10-08 10:05:40 --> Helper loaded: url_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: file_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: form_helper
INFO - 2024-10-08 10:05:40 --> Helper loaded: my_helper
INFO - 2024-10-08 10:05:40 --> Database Driver Class Initialized
INFO - 2024-10-08 10:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:05:40 --> Controller Class Initialized
DEBUG - 2024-10-08 10:05:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 10:05:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:05:40 --> Final output sent to browser
DEBUG - 2024-10-08 10:05:40 --> Total execution time: 0.0327
INFO - 2024-10-08 10:31:13 --> Config Class Initialized
INFO - 2024-10-08 10:31:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:31:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:31:13 --> Utf8 Class Initialized
INFO - 2024-10-08 10:31:13 --> URI Class Initialized
DEBUG - 2024-10-08 10:31:13 --> No URI present. Default controller set.
INFO - 2024-10-08 10:31:13 --> Router Class Initialized
INFO - 2024-10-08 10:31:13 --> Output Class Initialized
INFO - 2024-10-08 10:31:13 --> Security Class Initialized
DEBUG - 2024-10-08 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:31:13 --> Input Class Initialized
INFO - 2024-10-08 10:31:13 --> Language Class Initialized
INFO - 2024-10-08 10:31:13 --> Language Class Initialized
INFO - 2024-10-08 10:31:13 --> Config Class Initialized
INFO - 2024-10-08 10:31:13 --> Loader Class Initialized
INFO - 2024-10-08 10:31:13 --> Helper loaded: url_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: file_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: form_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: my_helper
INFO - 2024-10-08 10:31:13 --> Database Driver Class Initialized
INFO - 2024-10-08 10:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:31:13 --> Controller Class Initialized
INFO - 2024-10-08 10:31:13 --> Config Class Initialized
INFO - 2024-10-08 10:31:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:31:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:31:13 --> Utf8 Class Initialized
INFO - 2024-10-08 10:31:13 --> URI Class Initialized
INFO - 2024-10-08 10:31:13 --> Router Class Initialized
INFO - 2024-10-08 10:31:13 --> Output Class Initialized
INFO - 2024-10-08 10:31:13 --> Security Class Initialized
DEBUG - 2024-10-08 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:31:13 --> Input Class Initialized
INFO - 2024-10-08 10:31:13 --> Language Class Initialized
INFO - 2024-10-08 10:31:13 --> Language Class Initialized
INFO - 2024-10-08 10:31:13 --> Config Class Initialized
INFO - 2024-10-08 10:31:13 --> Loader Class Initialized
INFO - 2024-10-08 10:31:13 --> Helper loaded: url_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: file_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: form_helper
INFO - 2024-10-08 10:31:13 --> Helper loaded: my_helper
INFO - 2024-10-08 10:31:13 --> Database Driver Class Initialized
INFO - 2024-10-08 10:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:31:13 --> Controller Class Initialized
DEBUG - 2024-10-08 10:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 10:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:31:13 --> Final output sent to browser
DEBUG - 2024-10-08 10:31:13 --> Total execution time: 0.0398
INFO - 2024-10-08 10:31:17 --> Config Class Initialized
INFO - 2024-10-08 10:31:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:31:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:31:17 --> Utf8 Class Initialized
INFO - 2024-10-08 10:31:17 --> URI Class Initialized
INFO - 2024-10-08 10:31:17 --> Router Class Initialized
INFO - 2024-10-08 10:31:17 --> Output Class Initialized
INFO - 2024-10-08 10:31:17 --> Security Class Initialized
DEBUG - 2024-10-08 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:31:17 --> Input Class Initialized
INFO - 2024-10-08 10:31:17 --> Language Class Initialized
INFO - 2024-10-08 10:31:17 --> Language Class Initialized
INFO - 2024-10-08 10:31:17 --> Config Class Initialized
INFO - 2024-10-08 10:31:17 --> Loader Class Initialized
INFO - 2024-10-08 10:31:17 --> Helper loaded: url_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: file_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: form_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: my_helper
INFO - 2024-10-08 10:31:17 --> Database Driver Class Initialized
INFO - 2024-10-08 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:31:17 --> Controller Class Initialized
INFO - 2024-10-08 10:31:17 --> Helper loaded: cookie_helper
INFO - 2024-10-08 10:31:17 --> Final output sent to browser
DEBUG - 2024-10-08 10:31:17 --> Total execution time: 0.0395
INFO - 2024-10-08 10:31:17 --> Config Class Initialized
INFO - 2024-10-08 10:31:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:31:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:31:17 --> Utf8 Class Initialized
INFO - 2024-10-08 10:31:17 --> URI Class Initialized
INFO - 2024-10-08 10:31:17 --> Router Class Initialized
INFO - 2024-10-08 10:31:17 --> Output Class Initialized
INFO - 2024-10-08 10:31:17 --> Security Class Initialized
DEBUG - 2024-10-08 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:31:17 --> Input Class Initialized
INFO - 2024-10-08 10:31:17 --> Language Class Initialized
INFO - 2024-10-08 10:31:17 --> Language Class Initialized
INFO - 2024-10-08 10:31:17 --> Config Class Initialized
INFO - 2024-10-08 10:31:17 --> Loader Class Initialized
INFO - 2024-10-08 10:31:17 --> Helper loaded: url_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: file_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: form_helper
INFO - 2024-10-08 10:31:17 --> Helper loaded: my_helper
INFO - 2024-10-08 10:31:17 --> Database Driver Class Initialized
INFO - 2024-10-08 10:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:31:17 --> Controller Class Initialized
DEBUG - 2024-10-08 10:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 10:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:31:17 --> Final output sent to browser
DEBUG - 2024-10-08 10:31:17 --> Total execution time: 0.0386
INFO - 2024-10-08 10:31:34 --> Config Class Initialized
INFO - 2024-10-08 10:31:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:31:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:31:34 --> Utf8 Class Initialized
INFO - 2024-10-08 10:31:34 --> URI Class Initialized
INFO - 2024-10-08 10:31:34 --> Router Class Initialized
INFO - 2024-10-08 10:31:34 --> Output Class Initialized
INFO - 2024-10-08 10:31:34 --> Security Class Initialized
DEBUG - 2024-10-08 10:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:31:34 --> Input Class Initialized
INFO - 2024-10-08 10:31:34 --> Language Class Initialized
INFO - 2024-10-08 10:31:34 --> Language Class Initialized
INFO - 2024-10-08 10:31:34 --> Config Class Initialized
INFO - 2024-10-08 10:31:34 --> Loader Class Initialized
INFO - 2024-10-08 10:31:34 --> Helper loaded: url_helper
INFO - 2024-10-08 10:31:34 --> Helper loaded: file_helper
INFO - 2024-10-08 10:31:34 --> Helper loaded: form_helper
INFO - 2024-10-08 10:31:34 --> Helper loaded: my_helper
INFO - 2024-10-08 10:31:34 --> Database Driver Class Initialized
INFO - 2024-10-08 10:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:31:34 --> Controller Class Initialized
DEBUG - 2024-10-08 10:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 10:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:31:34 --> Final output sent to browser
DEBUG - 2024-10-08 10:31:34 --> Total execution time: 0.0392
INFO - 2024-10-08 10:33:48 --> Config Class Initialized
INFO - 2024-10-08 10:33:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:33:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:33:48 --> Utf8 Class Initialized
INFO - 2024-10-08 10:33:48 --> URI Class Initialized
INFO - 2024-10-08 10:33:48 --> Router Class Initialized
INFO - 2024-10-08 10:33:48 --> Output Class Initialized
INFO - 2024-10-08 10:33:48 --> Security Class Initialized
DEBUG - 2024-10-08 10:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:33:48 --> Input Class Initialized
INFO - 2024-10-08 10:33:48 --> Language Class Initialized
INFO - 2024-10-08 10:33:48 --> Language Class Initialized
INFO - 2024-10-08 10:33:48 --> Config Class Initialized
INFO - 2024-10-08 10:33:48 --> Loader Class Initialized
INFO - 2024-10-08 10:33:48 --> Helper loaded: url_helper
INFO - 2024-10-08 10:33:48 --> Helper loaded: file_helper
INFO - 2024-10-08 10:33:48 --> Helper loaded: form_helper
INFO - 2024-10-08 10:33:48 --> Helper loaded: my_helper
INFO - 2024-10-08 10:33:48 --> Database Driver Class Initialized
INFO - 2024-10-08 10:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:33:48 --> Controller Class Initialized
DEBUG - 2024-10-08 10:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 10:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:33:48 --> Final output sent to browser
DEBUG - 2024-10-08 10:33:48 --> Total execution time: 0.0465
INFO - 2024-10-08 10:41:37 --> Config Class Initialized
INFO - 2024-10-08 10:41:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:37 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:37 --> URI Class Initialized
DEBUG - 2024-10-08 10:41:37 --> No URI present. Default controller set.
INFO - 2024-10-08 10:41:37 --> Router Class Initialized
INFO - 2024-10-08 10:41:37 --> Output Class Initialized
INFO - 2024-10-08 10:41:37 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:37 --> Input Class Initialized
INFO - 2024-10-08 10:41:37 --> Language Class Initialized
INFO - 2024-10-08 10:41:37 --> Language Class Initialized
INFO - 2024-10-08 10:41:37 --> Config Class Initialized
INFO - 2024-10-08 10:41:37 --> Loader Class Initialized
INFO - 2024-10-08 10:41:37 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:37 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:37 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:37 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:37 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:37 --> Controller Class Initialized
DEBUG - 2024-10-08 10:41:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 10:41:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:41:37 --> Final output sent to browser
DEBUG - 2024-10-08 10:41:37 --> Total execution time: 0.0347
INFO - 2024-10-08 10:41:38 --> Config Class Initialized
INFO - 2024-10-08 10:41:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:38 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:38 --> URI Class Initialized
INFO - 2024-10-08 10:41:38 --> Router Class Initialized
INFO - 2024-10-08 10:41:38 --> Output Class Initialized
INFO - 2024-10-08 10:41:38 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:38 --> Input Class Initialized
INFO - 2024-10-08 10:41:38 --> Language Class Initialized
INFO - 2024-10-08 10:41:38 --> Language Class Initialized
INFO - 2024-10-08 10:41:38 --> Config Class Initialized
INFO - 2024-10-08 10:41:38 --> Loader Class Initialized
INFO - 2024-10-08 10:41:38 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:38 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:38 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:38 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:38 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:38 --> Controller Class Initialized
DEBUG - 2024-10-08 10:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 10:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:41:38 --> Final output sent to browser
DEBUG - 2024-10-08 10:41:38 --> Total execution time: 0.0327
INFO - 2024-10-08 10:41:42 --> Config Class Initialized
INFO - 2024-10-08 10:41:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:42 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:42 --> URI Class Initialized
INFO - 2024-10-08 10:41:42 --> Router Class Initialized
INFO - 2024-10-08 10:41:42 --> Output Class Initialized
INFO - 2024-10-08 10:41:42 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:42 --> Input Class Initialized
INFO - 2024-10-08 10:41:42 --> Language Class Initialized
INFO - 2024-10-08 10:41:42 --> Language Class Initialized
INFO - 2024-10-08 10:41:42 --> Config Class Initialized
INFO - 2024-10-08 10:41:42 --> Loader Class Initialized
INFO - 2024-10-08 10:41:42 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:42 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:42 --> Controller Class Initialized
DEBUG - 2024-10-08 10:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 10:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:41:42 --> Final output sent to browser
DEBUG - 2024-10-08 10:41:42 --> Total execution time: 0.0403
INFO - 2024-10-08 10:41:42 --> Config Class Initialized
INFO - 2024-10-08 10:41:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:42 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:42 --> URI Class Initialized
INFO - 2024-10-08 10:41:42 --> Router Class Initialized
INFO - 2024-10-08 10:41:42 --> Output Class Initialized
INFO - 2024-10-08 10:41:42 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:42 --> Input Class Initialized
INFO - 2024-10-08 10:41:42 --> Language Class Initialized
INFO - 2024-10-08 10:41:42 --> Language Class Initialized
INFO - 2024-10-08 10:41:42 --> Config Class Initialized
INFO - 2024-10-08 10:41:42 --> Loader Class Initialized
INFO - 2024-10-08 10:41:42 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:42 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:42 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:42 --> Controller Class Initialized
INFO - 2024-10-08 10:41:46 --> Config Class Initialized
INFO - 2024-10-08 10:41:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:46 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:46 --> URI Class Initialized
INFO - 2024-10-08 10:41:46 --> Router Class Initialized
INFO - 2024-10-08 10:41:46 --> Output Class Initialized
INFO - 2024-10-08 10:41:46 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:46 --> Input Class Initialized
INFO - 2024-10-08 10:41:46 --> Language Class Initialized
INFO - 2024-10-08 10:41:46 --> Language Class Initialized
INFO - 2024-10-08 10:41:46 --> Config Class Initialized
INFO - 2024-10-08 10:41:46 --> Loader Class Initialized
INFO - 2024-10-08 10:41:46 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:46 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:46 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:46 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:46 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:46 --> Controller Class Initialized
INFO - 2024-10-08 10:41:46 --> Final output sent to browser
DEBUG - 2024-10-08 10:41:46 --> Total execution time: 0.0375
INFO - 2024-10-08 10:41:47 --> Config Class Initialized
INFO - 2024-10-08 10:41:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:41:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:41:47 --> Utf8 Class Initialized
INFO - 2024-10-08 10:41:47 --> URI Class Initialized
INFO - 2024-10-08 10:41:47 --> Router Class Initialized
INFO - 2024-10-08 10:41:47 --> Output Class Initialized
INFO - 2024-10-08 10:41:47 --> Security Class Initialized
DEBUG - 2024-10-08 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:41:47 --> Input Class Initialized
INFO - 2024-10-08 10:41:47 --> Language Class Initialized
INFO - 2024-10-08 10:41:47 --> Language Class Initialized
INFO - 2024-10-08 10:41:47 --> Config Class Initialized
INFO - 2024-10-08 10:41:47 --> Loader Class Initialized
INFO - 2024-10-08 10:41:47 --> Helper loaded: url_helper
INFO - 2024-10-08 10:41:47 --> Helper loaded: file_helper
INFO - 2024-10-08 10:41:47 --> Helper loaded: form_helper
INFO - 2024-10-08 10:41:47 --> Helper loaded: my_helper
INFO - 2024-10-08 10:41:47 --> Database Driver Class Initialized
INFO - 2024-10-08 10:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:41:47 --> Controller Class Initialized
INFO - 2024-10-08 10:41:47 --> Final output sent to browser
DEBUG - 2024-10-08 10:41:47 --> Total execution time: 0.0348
INFO - 2024-10-08 10:42:00 --> Config Class Initialized
INFO - 2024-10-08 10:42:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:42:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:42:00 --> Utf8 Class Initialized
INFO - 2024-10-08 10:42:00 --> URI Class Initialized
INFO - 2024-10-08 10:42:00 --> Router Class Initialized
INFO - 2024-10-08 10:42:00 --> Output Class Initialized
INFO - 2024-10-08 10:42:00 --> Security Class Initialized
DEBUG - 2024-10-08 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:42:00 --> Input Class Initialized
INFO - 2024-10-08 10:42:00 --> Language Class Initialized
INFO - 2024-10-08 10:42:00 --> Language Class Initialized
INFO - 2024-10-08 10:42:00 --> Config Class Initialized
INFO - 2024-10-08 10:42:00 --> Loader Class Initialized
INFO - 2024-10-08 10:42:00 --> Helper loaded: url_helper
INFO - 2024-10-08 10:42:00 --> Helper loaded: file_helper
INFO - 2024-10-08 10:42:00 --> Helper loaded: form_helper
INFO - 2024-10-08 10:42:00 --> Helper loaded: my_helper
INFO - 2024-10-08 10:42:00 --> Database Driver Class Initialized
INFO - 2024-10-08 10:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:42:00 --> Controller Class Initialized
DEBUG - 2024-10-08 10:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 10:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:42:00 --> Final output sent to browser
DEBUG - 2024-10-08 10:42:00 --> Total execution time: 0.0356
INFO - 2024-10-08 10:42:03 --> Config Class Initialized
INFO - 2024-10-08 10:42:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:42:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:42:03 --> Utf8 Class Initialized
INFO - 2024-10-08 10:42:03 --> URI Class Initialized
INFO - 2024-10-08 10:42:03 --> Router Class Initialized
INFO - 2024-10-08 10:42:03 --> Output Class Initialized
INFO - 2024-10-08 10:42:03 --> Security Class Initialized
DEBUG - 2024-10-08 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:42:03 --> Input Class Initialized
INFO - 2024-10-08 10:42:03 --> Language Class Initialized
INFO - 2024-10-08 10:42:03 --> Language Class Initialized
INFO - 2024-10-08 10:42:03 --> Config Class Initialized
INFO - 2024-10-08 10:42:03 --> Loader Class Initialized
INFO - 2024-10-08 10:42:03 --> Helper loaded: url_helper
INFO - 2024-10-08 10:42:03 --> Helper loaded: file_helper
INFO - 2024-10-08 10:42:04 --> Helper loaded: form_helper
INFO - 2024-10-08 10:42:04 --> Helper loaded: my_helper
INFO - 2024-10-08 10:42:04 --> Database Driver Class Initialized
INFO - 2024-10-08 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:42:04 --> Controller Class Initialized
DEBUG - 2024-10-08 10:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 10:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 10:42:04 --> Final output sent to browser
DEBUG - 2024-10-08 10:42:04 --> Total execution time: 0.3397
INFO - 2024-10-08 10:50:05 --> Config Class Initialized
INFO - 2024-10-08 10:50:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 10:50:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 10:50:05 --> Utf8 Class Initialized
INFO - 2024-10-08 10:50:05 --> URI Class Initialized
INFO - 2024-10-08 10:50:05 --> Router Class Initialized
INFO - 2024-10-08 10:50:05 --> Output Class Initialized
INFO - 2024-10-08 10:50:05 --> Security Class Initialized
DEBUG - 2024-10-08 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 10:50:05 --> Input Class Initialized
INFO - 2024-10-08 10:50:05 --> Language Class Initialized
INFO - 2024-10-08 10:50:05 --> Language Class Initialized
INFO - 2024-10-08 10:50:05 --> Config Class Initialized
INFO - 2024-10-08 10:50:05 --> Loader Class Initialized
INFO - 2024-10-08 10:50:05 --> Helper loaded: url_helper
INFO - 2024-10-08 10:50:05 --> Helper loaded: file_helper
INFO - 2024-10-08 10:50:05 --> Helper loaded: form_helper
INFO - 2024-10-08 10:50:05 --> Helper loaded: my_helper
INFO - 2024-10-08 10:50:05 --> Database Driver Class Initialized
INFO - 2024-10-08 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 10:50:05 --> Controller Class Initialized
DEBUG - 2024-10-08 10:50:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 10:50:08 --> Final output sent to browser
DEBUG - 2024-10-08 10:50:08 --> Total execution time: 3.4830
INFO - 2024-10-08 12:13:30 --> Config Class Initialized
INFO - 2024-10-08 12:13:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:30 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:30 --> URI Class Initialized
INFO - 2024-10-08 12:13:30 --> Router Class Initialized
INFO - 2024-10-08 12:13:30 --> Output Class Initialized
INFO - 2024-10-08 12:13:30 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:30 --> Input Class Initialized
INFO - 2024-10-08 12:13:30 --> Language Class Initialized
INFO - 2024-10-08 12:13:30 --> Language Class Initialized
INFO - 2024-10-08 12:13:30 --> Config Class Initialized
INFO - 2024-10-08 12:13:30 --> Loader Class Initialized
INFO - 2024-10-08 12:13:30 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:30 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:30 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:30 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:30 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:30 --> Controller Class Initialized
DEBUG - 2024-10-08 12:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 12:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:13:30 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:30 --> Total execution time: 0.0520
INFO - 2024-10-08 12:13:39 --> Config Class Initialized
INFO - 2024-10-08 12:13:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:39 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:39 --> URI Class Initialized
INFO - 2024-10-08 12:13:39 --> Router Class Initialized
INFO - 2024-10-08 12:13:39 --> Output Class Initialized
INFO - 2024-10-08 12:13:39 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:39 --> Input Class Initialized
INFO - 2024-10-08 12:13:39 --> Language Class Initialized
INFO - 2024-10-08 12:13:39 --> Language Class Initialized
INFO - 2024-10-08 12:13:39 --> Config Class Initialized
INFO - 2024-10-08 12:13:39 --> Loader Class Initialized
INFO - 2024-10-08 12:13:39 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:39 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:39 --> Controller Class Initialized
INFO - 2024-10-08 12:13:39 --> Helper loaded: cookie_helper
INFO - 2024-10-08 12:13:39 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:39 --> Total execution time: 0.1669
INFO - 2024-10-08 12:13:39 --> Config Class Initialized
INFO - 2024-10-08 12:13:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:39 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:39 --> URI Class Initialized
INFO - 2024-10-08 12:13:39 --> Router Class Initialized
INFO - 2024-10-08 12:13:39 --> Output Class Initialized
INFO - 2024-10-08 12:13:39 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:39 --> Input Class Initialized
INFO - 2024-10-08 12:13:39 --> Language Class Initialized
INFO - 2024-10-08 12:13:39 --> Language Class Initialized
INFO - 2024-10-08 12:13:39 --> Config Class Initialized
INFO - 2024-10-08 12:13:39 --> Loader Class Initialized
INFO - 2024-10-08 12:13:39 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:39 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:40 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:40 --> Controller Class Initialized
DEBUG - 2024-10-08 12:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 12:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:13:40 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:40 --> Total execution time: 0.0428
INFO - 2024-10-08 12:13:43 --> Config Class Initialized
INFO - 2024-10-08 12:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:43 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:43 --> URI Class Initialized
INFO - 2024-10-08 12:13:43 --> Router Class Initialized
INFO - 2024-10-08 12:13:43 --> Output Class Initialized
INFO - 2024-10-08 12:13:43 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:43 --> Input Class Initialized
INFO - 2024-10-08 12:13:43 --> Language Class Initialized
INFO - 2024-10-08 12:13:43 --> Language Class Initialized
INFO - 2024-10-08 12:13:43 --> Config Class Initialized
INFO - 2024-10-08 12:13:43 --> Loader Class Initialized
INFO - 2024-10-08 12:13:43 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:43 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:43 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:43 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:43 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:43 --> Controller Class Initialized
DEBUG - 2024-10-08 12:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 12:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:13:43 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:43 --> Total execution time: 0.0381
INFO - 2024-10-08 12:13:48 --> Config Class Initialized
INFO - 2024-10-08 12:13:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:48 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:48 --> URI Class Initialized
INFO - 2024-10-08 12:13:48 --> Router Class Initialized
INFO - 2024-10-08 12:13:48 --> Output Class Initialized
INFO - 2024-10-08 12:13:48 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:48 --> Input Class Initialized
INFO - 2024-10-08 12:13:48 --> Language Class Initialized
INFO - 2024-10-08 12:13:48 --> Language Class Initialized
INFO - 2024-10-08 12:13:48 --> Config Class Initialized
INFO - 2024-10-08 12:13:48 --> Loader Class Initialized
INFO - 2024-10-08 12:13:48 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:48 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:48 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:48 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:48 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:48 --> Controller Class Initialized
DEBUG - 2024-10-08 12:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 12:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:13:48 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:48 --> Total execution time: 0.0362
INFO - 2024-10-08 12:13:51 --> Config Class Initialized
INFO - 2024-10-08 12:13:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:13:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:13:51 --> Utf8 Class Initialized
INFO - 2024-10-08 12:13:51 --> URI Class Initialized
INFO - 2024-10-08 12:13:51 --> Router Class Initialized
INFO - 2024-10-08 12:13:51 --> Output Class Initialized
INFO - 2024-10-08 12:13:51 --> Security Class Initialized
DEBUG - 2024-10-08 12:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:13:51 --> Input Class Initialized
INFO - 2024-10-08 12:13:51 --> Language Class Initialized
INFO - 2024-10-08 12:13:51 --> Language Class Initialized
INFO - 2024-10-08 12:13:51 --> Config Class Initialized
INFO - 2024-10-08 12:13:51 --> Loader Class Initialized
INFO - 2024-10-08 12:13:51 --> Helper loaded: url_helper
INFO - 2024-10-08 12:13:51 --> Helper loaded: file_helper
INFO - 2024-10-08 12:13:51 --> Helper loaded: form_helper
INFO - 2024-10-08 12:13:51 --> Helper loaded: my_helper
INFO - 2024-10-08 12:13:51 --> Database Driver Class Initialized
INFO - 2024-10-08 12:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:13:51 --> Controller Class Initialized
DEBUG - 2024-10-08 12:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 12:13:55 --> Final output sent to browser
DEBUG - 2024-10-08 12:13:55 --> Total execution time: 3.2897
INFO - 2024-10-08 12:14:16 --> Config Class Initialized
INFO - 2024-10-08 12:14:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:16 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:16 --> URI Class Initialized
DEBUG - 2024-10-08 12:14:16 --> No URI present. Default controller set.
INFO - 2024-10-08 12:14:16 --> Router Class Initialized
INFO - 2024-10-08 12:14:16 --> Output Class Initialized
INFO - 2024-10-08 12:14:16 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:16 --> Input Class Initialized
INFO - 2024-10-08 12:14:16 --> Language Class Initialized
INFO - 2024-10-08 12:14:16 --> Language Class Initialized
INFO - 2024-10-08 12:14:16 --> Config Class Initialized
INFO - 2024-10-08 12:14:16 --> Loader Class Initialized
INFO - 2024-10-08 12:14:16 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:16 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:16 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:16 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:16 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:16 --> Controller Class Initialized
DEBUG - 2024-10-08 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:14:16 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:16 --> Total execution time: 0.0575
INFO - 2024-10-08 12:14:18 --> Config Class Initialized
INFO - 2024-10-08 12:14:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:18 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:18 --> URI Class Initialized
INFO - 2024-10-08 12:14:18 --> Router Class Initialized
INFO - 2024-10-08 12:14:18 --> Output Class Initialized
INFO - 2024-10-08 12:14:18 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:18 --> Input Class Initialized
INFO - 2024-10-08 12:14:18 --> Language Class Initialized
INFO - 2024-10-08 12:14:18 --> Language Class Initialized
INFO - 2024-10-08 12:14:18 --> Config Class Initialized
INFO - 2024-10-08 12:14:18 --> Loader Class Initialized
INFO - 2024-10-08 12:14:18 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:18 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:18 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:18 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:18 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:18 --> Controller Class Initialized
DEBUG - 2024-10-08 12:14:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 12:14:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:14:18 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:18 --> Total execution time: 0.0296
INFO - 2024-10-08 12:14:24 --> Config Class Initialized
INFO - 2024-10-08 12:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:24 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:24 --> URI Class Initialized
INFO - 2024-10-08 12:14:24 --> Router Class Initialized
INFO - 2024-10-08 12:14:24 --> Output Class Initialized
INFO - 2024-10-08 12:14:24 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:24 --> Input Class Initialized
INFO - 2024-10-08 12:14:24 --> Language Class Initialized
INFO - 2024-10-08 12:14:24 --> Language Class Initialized
INFO - 2024-10-08 12:14:24 --> Config Class Initialized
INFO - 2024-10-08 12:14:24 --> Loader Class Initialized
INFO - 2024-10-08 12:14:24 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:24 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:24 --> Controller Class Initialized
DEBUG - 2024-10-08 12:14:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 12:14:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:14:24 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:24 --> Total execution time: 0.1016
INFO - 2024-10-08 12:14:24 --> Config Class Initialized
INFO - 2024-10-08 12:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:24 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:24 --> URI Class Initialized
INFO - 2024-10-08 12:14:24 --> Router Class Initialized
INFO - 2024-10-08 12:14:24 --> Output Class Initialized
INFO - 2024-10-08 12:14:24 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:24 --> Input Class Initialized
INFO - 2024-10-08 12:14:24 --> Language Class Initialized
INFO - 2024-10-08 12:14:24 --> Language Class Initialized
INFO - 2024-10-08 12:14:24 --> Config Class Initialized
INFO - 2024-10-08 12:14:24 --> Loader Class Initialized
INFO - 2024-10-08 12:14:24 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:24 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:24 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:24 --> Controller Class Initialized
INFO - 2024-10-08 12:14:27 --> Config Class Initialized
INFO - 2024-10-08 12:14:27 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:27 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:27 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:27 --> URI Class Initialized
INFO - 2024-10-08 12:14:27 --> Router Class Initialized
INFO - 2024-10-08 12:14:27 --> Output Class Initialized
INFO - 2024-10-08 12:14:27 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:27 --> Input Class Initialized
INFO - 2024-10-08 12:14:27 --> Language Class Initialized
INFO - 2024-10-08 12:14:27 --> Language Class Initialized
INFO - 2024-10-08 12:14:27 --> Config Class Initialized
INFO - 2024-10-08 12:14:27 --> Loader Class Initialized
INFO - 2024-10-08 12:14:27 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:27 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:27 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:27 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:27 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:28 --> Controller Class Initialized
INFO - 2024-10-08 12:14:28 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:28 --> Total execution time: 0.0339
INFO - 2024-10-08 12:14:30 --> Config Class Initialized
INFO - 2024-10-08 12:14:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:30 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:30 --> URI Class Initialized
INFO - 2024-10-08 12:14:30 --> Router Class Initialized
INFO - 2024-10-08 12:14:30 --> Output Class Initialized
INFO - 2024-10-08 12:14:30 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:30 --> Input Class Initialized
INFO - 2024-10-08 12:14:30 --> Language Class Initialized
INFO - 2024-10-08 12:14:30 --> Language Class Initialized
INFO - 2024-10-08 12:14:30 --> Config Class Initialized
INFO - 2024-10-08 12:14:30 --> Loader Class Initialized
INFO - 2024-10-08 12:14:30 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:30 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:30 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:30 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:30 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:30 --> Controller Class Initialized
DEBUG - 2024-10-08 12:14:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 12:14:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:14:30 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:30 --> Total execution time: 0.0326
INFO - 2024-10-08 12:14:33 --> Config Class Initialized
INFO - 2024-10-08 12:14:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:33 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:33 --> URI Class Initialized
INFO - 2024-10-08 12:14:33 --> Router Class Initialized
INFO - 2024-10-08 12:14:33 --> Output Class Initialized
INFO - 2024-10-08 12:14:33 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:33 --> Input Class Initialized
INFO - 2024-10-08 12:14:33 --> Language Class Initialized
INFO - 2024-10-08 12:14:33 --> Language Class Initialized
INFO - 2024-10-08 12:14:33 --> Config Class Initialized
INFO - 2024-10-08 12:14:33 --> Loader Class Initialized
INFO - 2024-10-08 12:14:33 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:33 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:33 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:33 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:33 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:33 --> Controller Class Initialized
DEBUG - 2024-10-08 12:14:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 12:14:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:14:33 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:33 --> Total execution time: 0.0337
INFO - 2024-10-08 12:14:36 --> Config Class Initialized
INFO - 2024-10-08 12:14:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:36 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:36 --> URI Class Initialized
INFO - 2024-10-08 12:14:36 --> Router Class Initialized
INFO - 2024-10-08 12:14:36 --> Output Class Initialized
INFO - 2024-10-08 12:14:36 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:36 --> Input Class Initialized
INFO - 2024-10-08 12:14:36 --> Language Class Initialized
INFO - 2024-10-08 12:14:36 --> Language Class Initialized
INFO - 2024-10-08 12:14:36 --> Config Class Initialized
INFO - 2024-10-08 12:14:36 --> Loader Class Initialized
INFO - 2024-10-08 12:14:36 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:36 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:36 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:36 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:36 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:36 --> Controller Class Initialized
INFO - 2024-10-08 12:14:36 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:36 --> Total execution time: 0.0312
INFO - 2024-10-08 12:14:51 --> Config Class Initialized
INFO - 2024-10-08 12:14:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:14:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:14:51 --> Utf8 Class Initialized
INFO - 2024-10-08 12:14:51 --> URI Class Initialized
INFO - 2024-10-08 12:14:51 --> Router Class Initialized
INFO - 2024-10-08 12:14:51 --> Output Class Initialized
INFO - 2024-10-08 12:14:51 --> Security Class Initialized
DEBUG - 2024-10-08 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:14:51 --> Input Class Initialized
INFO - 2024-10-08 12:14:51 --> Language Class Initialized
INFO - 2024-10-08 12:14:51 --> Language Class Initialized
INFO - 2024-10-08 12:14:51 --> Config Class Initialized
INFO - 2024-10-08 12:14:51 --> Loader Class Initialized
INFO - 2024-10-08 12:14:51 --> Helper loaded: url_helper
INFO - 2024-10-08 12:14:51 --> Helper loaded: file_helper
INFO - 2024-10-08 12:14:51 --> Helper loaded: form_helper
INFO - 2024-10-08 12:14:51 --> Helper loaded: my_helper
INFO - 2024-10-08 12:14:51 --> Database Driver Class Initialized
INFO - 2024-10-08 12:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:14:51 --> Controller Class Initialized
INFO - 2024-10-08 12:14:51 --> Final output sent to browser
DEBUG - 2024-10-08 12:14:51 --> Total execution time: 0.0852
INFO - 2024-10-08 12:15:29 --> Config Class Initialized
INFO - 2024-10-08 12:15:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:15:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:15:29 --> Utf8 Class Initialized
INFO - 2024-10-08 12:15:29 --> URI Class Initialized
INFO - 2024-10-08 12:15:29 --> Router Class Initialized
INFO - 2024-10-08 12:15:29 --> Output Class Initialized
INFO - 2024-10-08 12:15:29 --> Security Class Initialized
DEBUG - 2024-10-08 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:15:29 --> Input Class Initialized
INFO - 2024-10-08 12:15:29 --> Language Class Initialized
INFO - 2024-10-08 12:15:29 --> Language Class Initialized
INFO - 2024-10-08 12:15:29 --> Config Class Initialized
INFO - 2024-10-08 12:15:29 --> Loader Class Initialized
INFO - 2024-10-08 12:15:29 --> Helper loaded: url_helper
INFO - 2024-10-08 12:15:29 --> Helper loaded: file_helper
INFO - 2024-10-08 12:15:29 --> Helper loaded: form_helper
INFO - 2024-10-08 12:15:29 --> Helper loaded: my_helper
INFO - 2024-10-08 12:15:29 --> Database Driver Class Initialized
INFO - 2024-10-08 12:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:15:29 --> Controller Class Initialized
DEBUG - 2024-10-08 12:15:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 12:15:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:15:29 --> Final output sent to browser
DEBUG - 2024-10-08 12:15:29 --> Total execution time: 0.0373
INFO - 2024-10-08 12:15:35 --> Config Class Initialized
INFO - 2024-10-08 12:15:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:15:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:15:35 --> Utf8 Class Initialized
INFO - 2024-10-08 12:15:35 --> URI Class Initialized
INFO - 2024-10-08 12:15:35 --> Router Class Initialized
INFO - 2024-10-08 12:15:35 --> Output Class Initialized
INFO - 2024-10-08 12:15:35 --> Security Class Initialized
DEBUG - 2024-10-08 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:15:35 --> Input Class Initialized
INFO - 2024-10-08 12:15:35 --> Language Class Initialized
INFO - 2024-10-08 12:15:35 --> Language Class Initialized
INFO - 2024-10-08 12:15:35 --> Config Class Initialized
INFO - 2024-10-08 12:15:35 --> Loader Class Initialized
INFO - 2024-10-08 12:15:35 --> Helper loaded: url_helper
INFO - 2024-10-08 12:15:35 --> Helper loaded: file_helper
INFO - 2024-10-08 12:15:35 --> Helper loaded: form_helper
INFO - 2024-10-08 12:15:35 --> Helper loaded: my_helper
INFO - 2024-10-08 12:15:35 --> Database Driver Class Initialized
INFO - 2024-10-08 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:15:35 --> Controller Class Initialized
DEBUG - 2024-10-08 12:15:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 12:15:37 --> Final output sent to browser
DEBUG - 2024-10-08 12:15:37 --> Total execution time: 2.8385
INFO - 2024-10-08 12:15:40 --> Config Class Initialized
INFO - 2024-10-08 12:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:15:40 --> Utf8 Class Initialized
INFO - 2024-10-08 12:15:40 --> URI Class Initialized
INFO - 2024-10-08 12:15:40 --> Router Class Initialized
INFO - 2024-10-08 12:15:40 --> Output Class Initialized
INFO - 2024-10-08 12:15:40 --> Security Class Initialized
DEBUG - 2024-10-08 12:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:15:40 --> Input Class Initialized
INFO - 2024-10-08 12:15:40 --> Language Class Initialized
INFO - 2024-10-08 12:15:40 --> Language Class Initialized
INFO - 2024-10-08 12:15:40 --> Config Class Initialized
INFO - 2024-10-08 12:15:40 --> Loader Class Initialized
INFO - 2024-10-08 12:15:40 --> Helper loaded: url_helper
INFO - 2024-10-08 12:15:40 --> Helper loaded: file_helper
INFO - 2024-10-08 12:15:40 --> Helper loaded: form_helper
INFO - 2024-10-08 12:15:40 --> Helper loaded: my_helper
INFO - 2024-10-08 12:15:40 --> Database Driver Class Initialized
INFO - 2024-10-08 12:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:15:40 --> Controller Class Initialized
DEBUG - 2024-10-08 12:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 12:15:42 --> Config Class Initialized
INFO - 2024-10-08 12:15:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:15:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:15:42 --> Utf8 Class Initialized
INFO - 2024-10-08 12:15:42 --> URI Class Initialized
INFO - 2024-10-08 12:15:42 --> Router Class Initialized
INFO - 2024-10-08 12:15:42 --> Output Class Initialized
INFO - 2024-10-08 12:15:42 --> Security Class Initialized
DEBUG - 2024-10-08 12:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:15:42 --> Input Class Initialized
INFO - 2024-10-08 12:15:42 --> Language Class Initialized
INFO - 2024-10-08 12:15:42 --> Language Class Initialized
INFO - 2024-10-08 12:15:42 --> Config Class Initialized
INFO - 2024-10-08 12:15:42 --> Loader Class Initialized
INFO - 2024-10-08 12:15:42 --> Helper loaded: url_helper
INFO - 2024-10-08 12:15:42 --> Helper loaded: file_helper
INFO - 2024-10-08 12:15:42 --> Helper loaded: form_helper
INFO - 2024-10-08 12:15:42 --> Helper loaded: my_helper
INFO - 2024-10-08 12:15:42 --> Database Driver Class Initialized
INFO - 2024-10-08 12:15:42 --> Final output sent to browser
DEBUG - 2024-10-08 12:15:42 --> Total execution time: 2.6738
INFO - 2024-10-08 12:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:15:42 --> Controller Class Initialized
DEBUG - 2024-10-08 12:15:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 12:15:45 --> Final output sent to browser
DEBUG - 2024-10-08 12:15:45 --> Total execution time: 2.8651
INFO - 2024-10-08 12:16:25 --> Config Class Initialized
INFO - 2024-10-08 12:16:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:16:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:16:25 --> Utf8 Class Initialized
INFO - 2024-10-08 12:16:25 --> URI Class Initialized
DEBUG - 2024-10-08 12:16:25 --> No URI present. Default controller set.
INFO - 2024-10-08 12:16:25 --> Router Class Initialized
INFO - 2024-10-08 12:16:25 --> Output Class Initialized
INFO - 2024-10-08 12:16:25 --> Security Class Initialized
DEBUG - 2024-10-08 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:16:25 --> Input Class Initialized
INFO - 2024-10-08 12:16:25 --> Language Class Initialized
INFO - 2024-10-08 12:16:25 --> Language Class Initialized
INFO - 2024-10-08 12:16:25 --> Config Class Initialized
INFO - 2024-10-08 12:16:25 --> Loader Class Initialized
INFO - 2024-10-08 12:16:25 --> Helper loaded: url_helper
INFO - 2024-10-08 12:16:25 --> Helper loaded: file_helper
INFO - 2024-10-08 12:16:25 --> Helper loaded: form_helper
INFO - 2024-10-08 12:16:25 --> Helper loaded: my_helper
INFO - 2024-10-08 12:16:25 --> Database Driver Class Initialized
INFO - 2024-10-08 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:16:25 --> Controller Class Initialized
DEBUG - 2024-10-08 12:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 12:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:16:25 --> Final output sent to browser
DEBUG - 2024-10-08 12:16:25 --> Total execution time: 0.0883
INFO - 2024-10-08 12:16:27 --> Config Class Initialized
INFO - 2024-10-08 12:16:27 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:16:27 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:16:27 --> Utf8 Class Initialized
INFO - 2024-10-08 12:16:27 --> URI Class Initialized
INFO - 2024-10-08 12:16:27 --> Router Class Initialized
INFO - 2024-10-08 12:16:27 --> Output Class Initialized
INFO - 2024-10-08 12:16:27 --> Security Class Initialized
DEBUG - 2024-10-08 12:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:16:27 --> Input Class Initialized
INFO - 2024-10-08 12:16:27 --> Language Class Initialized
INFO - 2024-10-08 12:16:27 --> Language Class Initialized
INFO - 2024-10-08 12:16:27 --> Config Class Initialized
INFO - 2024-10-08 12:16:27 --> Loader Class Initialized
INFO - 2024-10-08 12:16:27 --> Helper loaded: url_helper
INFO - 2024-10-08 12:16:27 --> Helper loaded: file_helper
INFO - 2024-10-08 12:16:27 --> Helper loaded: form_helper
INFO - 2024-10-08 12:16:27 --> Helper loaded: my_helper
INFO - 2024-10-08 12:16:27 --> Database Driver Class Initialized
INFO - 2024-10-08 12:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:16:27 --> Controller Class Initialized
DEBUG - 2024-10-08 12:16:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 12:16:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:16:27 --> Final output sent to browser
DEBUG - 2024-10-08 12:16:27 --> Total execution time: 0.0307
INFO - 2024-10-08 12:16:30 --> Config Class Initialized
INFO - 2024-10-08 12:16:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:16:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:16:30 --> Utf8 Class Initialized
INFO - 2024-10-08 12:16:30 --> URI Class Initialized
INFO - 2024-10-08 12:16:30 --> Router Class Initialized
INFO - 2024-10-08 12:16:30 --> Output Class Initialized
INFO - 2024-10-08 12:16:30 --> Security Class Initialized
DEBUG - 2024-10-08 12:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:16:30 --> Input Class Initialized
INFO - 2024-10-08 12:16:30 --> Language Class Initialized
INFO - 2024-10-08 12:16:30 --> Language Class Initialized
INFO - 2024-10-08 12:16:30 --> Config Class Initialized
INFO - 2024-10-08 12:16:30 --> Loader Class Initialized
INFO - 2024-10-08 12:16:30 --> Helper loaded: url_helper
INFO - 2024-10-08 12:16:30 --> Helper loaded: file_helper
INFO - 2024-10-08 12:16:30 --> Helper loaded: form_helper
INFO - 2024-10-08 12:16:30 --> Helper loaded: my_helper
INFO - 2024-10-08 12:16:30 --> Database Driver Class Initialized
INFO - 2024-10-08 12:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:16:30 --> Controller Class Initialized
DEBUG - 2024-10-08 12:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 12:16:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 12:16:30 --> Final output sent to browser
DEBUG - 2024-10-08 12:16:30 --> Total execution time: 0.0719
INFO - 2024-10-08 12:16:33 --> Config Class Initialized
INFO - 2024-10-08 12:16:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:16:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:16:33 --> Utf8 Class Initialized
INFO - 2024-10-08 12:16:33 --> URI Class Initialized
INFO - 2024-10-08 12:16:33 --> Router Class Initialized
INFO - 2024-10-08 12:16:33 --> Output Class Initialized
INFO - 2024-10-08 12:16:33 --> Security Class Initialized
DEBUG - 2024-10-08 12:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:16:33 --> Input Class Initialized
INFO - 2024-10-08 12:16:33 --> Language Class Initialized
INFO - 2024-10-08 12:16:33 --> Language Class Initialized
INFO - 2024-10-08 12:16:33 --> Config Class Initialized
INFO - 2024-10-08 12:16:33 --> Loader Class Initialized
INFO - 2024-10-08 12:16:33 --> Helper loaded: url_helper
INFO - 2024-10-08 12:16:33 --> Helper loaded: file_helper
INFO - 2024-10-08 12:16:33 --> Helper loaded: form_helper
INFO - 2024-10-08 12:16:33 --> Helper loaded: my_helper
INFO - 2024-10-08 12:16:33 --> Database Driver Class Initialized
INFO - 2024-10-08 12:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:16:33 --> Controller Class Initialized
INFO - 2024-10-08 12:16:33 --> Final output sent to browser
DEBUG - 2024-10-08 12:16:33 --> Total execution time: 0.0390
INFO - 2024-10-08 12:17:51 --> Config Class Initialized
INFO - 2024-10-08 12:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 12:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 12:17:51 --> Utf8 Class Initialized
INFO - 2024-10-08 12:17:51 --> URI Class Initialized
INFO - 2024-10-08 12:17:51 --> Router Class Initialized
INFO - 2024-10-08 12:17:51 --> Output Class Initialized
INFO - 2024-10-08 12:17:51 --> Security Class Initialized
DEBUG - 2024-10-08 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 12:17:51 --> Input Class Initialized
INFO - 2024-10-08 12:17:51 --> Language Class Initialized
INFO - 2024-10-08 12:17:51 --> Language Class Initialized
INFO - 2024-10-08 12:17:51 --> Config Class Initialized
INFO - 2024-10-08 12:17:51 --> Loader Class Initialized
INFO - 2024-10-08 12:17:51 --> Helper loaded: url_helper
INFO - 2024-10-08 12:17:51 --> Helper loaded: file_helper
INFO - 2024-10-08 12:17:51 --> Helper loaded: form_helper
INFO - 2024-10-08 12:17:51 --> Helper loaded: my_helper
INFO - 2024-10-08 12:17:51 --> Database Driver Class Initialized
INFO - 2024-10-08 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 12:17:51 --> Controller Class Initialized
INFO - 2024-10-08 12:17:51 --> Final output sent to browser
DEBUG - 2024-10-08 12:17:51 --> Total execution time: 0.0738
INFO - 2024-10-08 13:38:13 --> Config Class Initialized
INFO - 2024-10-08 13:38:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 13:38:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 13:38:13 --> Utf8 Class Initialized
INFO - 2024-10-08 13:38:13 --> URI Class Initialized
INFO - 2024-10-08 13:38:13 --> Router Class Initialized
INFO - 2024-10-08 13:38:13 --> Output Class Initialized
INFO - 2024-10-08 13:38:14 --> Security Class Initialized
DEBUG - 2024-10-08 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 13:38:14 --> Input Class Initialized
INFO - 2024-10-08 13:38:14 --> Language Class Initialized
INFO - 2024-10-08 13:38:14 --> Language Class Initialized
INFO - 2024-10-08 13:38:14 --> Config Class Initialized
INFO - 2024-10-08 13:38:14 --> Loader Class Initialized
INFO - 2024-10-08 13:38:14 --> Helper loaded: url_helper
INFO - 2024-10-08 13:38:14 --> Helper loaded: file_helper
INFO - 2024-10-08 13:38:14 --> Helper loaded: form_helper
INFO - 2024-10-08 13:38:14 --> Helper loaded: my_helper
INFO - 2024-10-08 13:38:14 --> Database Driver Class Initialized
INFO - 2024-10-08 13:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 13:38:14 --> Controller Class Initialized
DEBUG - 2024-10-08 13:38:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 13:38:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 13:38:14 --> Final output sent to browser
DEBUG - 2024-10-08 13:38:14 --> Total execution time: 0.2919
INFO - 2024-10-08 13:38:19 --> Config Class Initialized
INFO - 2024-10-08 13:38:19 --> Hooks Class Initialized
DEBUG - 2024-10-08 13:38:19 --> UTF-8 Support Enabled
INFO - 2024-10-08 13:38:19 --> Utf8 Class Initialized
INFO - 2024-10-08 13:38:19 --> URI Class Initialized
INFO - 2024-10-08 13:38:19 --> Router Class Initialized
INFO - 2024-10-08 13:38:19 --> Output Class Initialized
INFO - 2024-10-08 13:38:19 --> Security Class Initialized
DEBUG - 2024-10-08 13:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 13:38:19 --> Input Class Initialized
INFO - 2024-10-08 13:38:19 --> Language Class Initialized
INFO - 2024-10-08 13:38:19 --> Language Class Initialized
INFO - 2024-10-08 13:38:19 --> Config Class Initialized
INFO - 2024-10-08 13:38:19 --> Loader Class Initialized
INFO - 2024-10-08 13:38:19 --> Helper loaded: url_helper
INFO - 2024-10-08 13:38:19 --> Helper loaded: file_helper
INFO - 2024-10-08 13:38:19 --> Helper loaded: form_helper
INFO - 2024-10-08 13:38:19 --> Helper loaded: my_helper
INFO - 2024-10-08 13:38:19 --> Database Driver Class Initialized
INFO - 2024-10-08 13:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 13:38:19 --> Controller Class Initialized
DEBUG - 2024-10-08 13:38:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 13:38:22 --> Final output sent to browser
DEBUG - 2024-10-08 13:38:22 --> Total execution time: 2.9763
INFO - 2024-10-08 14:18:10 --> Config Class Initialized
INFO - 2024-10-08 14:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:10 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:10 --> URI Class Initialized
INFO - 2024-10-08 14:18:10 --> Router Class Initialized
INFO - 2024-10-08 14:18:10 --> Output Class Initialized
INFO - 2024-10-08 14:18:10 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:10 --> Input Class Initialized
INFO - 2024-10-08 14:18:10 --> Language Class Initialized
INFO - 2024-10-08 14:18:10 --> Language Class Initialized
INFO - 2024-10-08 14:18:10 --> Config Class Initialized
INFO - 2024-10-08 14:18:10 --> Loader Class Initialized
INFO - 2024-10-08 14:18:10 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:10 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:10 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:10 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:10 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:10 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:10 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:10 --> Total execution time: 0.0544
INFO - 2024-10-08 14:18:16 --> Config Class Initialized
INFO - 2024-10-08 14:18:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:16 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:16 --> URI Class Initialized
INFO - 2024-10-08 14:18:16 --> Router Class Initialized
INFO - 2024-10-08 14:18:16 --> Output Class Initialized
INFO - 2024-10-08 14:18:16 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:16 --> Input Class Initialized
INFO - 2024-10-08 14:18:16 --> Language Class Initialized
INFO - 2024-10-08 14:18:16 --> Language Class Initialized
INFO - 2024-10-08 14:18:16 --> Config Class Initialized
INFO - 2024-10-08 14:18:16 --> Loader Class Initialized
INFO - 2024-10-08 14:18:16 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:16 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:16 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:16 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:16 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:16 --> Controller Class Initialized
INFO - 2024-10-08 14:18:17 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:18:17 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:17 --> Total execution time: 0.0767
INFO - 2024-10-08 14:18:17 --> Config Class Initialized
INFO - 2024-10-08 14:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:17 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:17 --> URI Class Initialized
INFO - 2024-10-08 14:18:17 --> Router Class Initialized
INFO - 2024-10-08 14:18:17 --> Output Class Initialized
INFO - 2024-10-08 14:18:17 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:17 --> Input Class Initialized
INFO - 2024-10-08 14:18:17 --> Language Class Initialized
INFO - 2024-10-08 14:18:17 --> Language Class Initialized
INFO - 2024-10-08 14:18:17 --> Config Class Initialized
INFO - 2024-10-08 14:18:17 --> Loader Class Initialized
INFO - 2024-10-08 14:18:17 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:17 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:17 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:17 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:17 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:17 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 14:18:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:17 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:17 --> Total execution time: 0.0526
INFO - 2024-10-08 14:18:18 --> Config Class Initialized
INFO - 2024-10-08 14:18:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:18 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:18 --> URI Class Initialized
INFO - 2024-10-08 14:18:18 --> Router Class Initialized
INFO - 2024-10-08 14:18:18 --> Output Class Initialized
INFO - 2024-10-08 14:18:18 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:18 --> Input Class Initialized
INFO - 2024-10-08 14:18:18 --> Language Class Initialized
INFO - 2024-10-08 14:18:18 --> Language Class Initialized
INFO - 2024-10-08 14:18:18 --> Config Class Initialized
INFO - 2024-10-08 14:18:18 --> Loader Class Initialized
INFO - 2024-10-08 14:18:18 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:18 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:18 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 14:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:18 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:18 --> Total execution time: 0.0377
INFO - 2024-10-08 14:18:18 --> Config Class Initialized
INFO - 2024-10-08 14:18:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:18 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:18 --> URI Class Initialized
INFO - 2024-10-08 14:18:18 --> Router Class Initialized
INFO - 2024-10-08 14:18:18 --> Output Class Initialized
INFO - 2024-10-08 14:18:18 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:18 --> Input Class Initialized
INFO - 2024-10-08 14:18:18 --> Language Class Initialized
ERROR - 2024-10-08 14:18:18 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:18:18 --> Config Class Initialized
INFO - 2024-10-08 14:18:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:18 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:18 --> URI Class Initialized
INFO - 2024-10-08 14:18:18 --> Router Class Initialized
INFO - 2024-10-08 14:18:18 --> Output Class Initialized
INFO - 2024-10-08 14:18:18 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:18 --> Input Class Initialized
INFO - 2024-10-08 14:18:18 --> Language Class Initialized
INFO - 2024-10-08 14:18:18 --> Language Class Initialized
INFO - 2024-10-08 14:18:18 --> Config Class Initialized
INFO - 2024-10-08 14:18:18 --> Loader Class Initialized
INFO - 2024-10-08 14:18:18 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:18 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:18 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:18 --> Controller Class Initialized
INFO - 2024-10-08 14:18:20 --> Config Class Initialized
INFO - 2024-10-08 14:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:20 --> URI Class Initialized
INFO - 2024-10-08 14:18:20 --> Router Class Initialized
INFO - 2024-10-08 14:18:20 --> Output Class Initialized
INFO - 2024-10-08 14:18:20 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:20 --> Input Class Initialized
INFO - 2024-10-08 14:18:20 --> Language Class Initialized
INFO - 2024-10-08 14:18:20 --> Language Class Initialized
INFO - 2024-10-08 14:18:20 --> Config Class Initialized
INFO - 2024-10-08 14:18:20 --> Loader Class Initialized
INFO - 2024-10-08 14:18:20 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:20 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:20 --> Controller Class Initialized
INFO - 2024-10-08 14:18:20 --> Config Class Initialized
INFO - 2024-10-08 14:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:20 --> URI Class Initialized
INFO - 2024-10-08 14:18:20 --> Router Class Initialized
INFO - 2024-10-08 14:18:20 --> Output Class Initialized
INFO - 2024-10-08 14:18:20 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:20 --> Input Class Initialized
INFO - 2024-10-08 14:18:20 --> Language Class Initialized
INFO - 2024-10-08 14:18:20 --> Language Class Initialized
INFO - 2024-10-08 14:18:20 --> Config Class Initialized
INFO - 2024-10-08 14:18:20 --> Loader Class Initialized
INFO - 2024-10-08 14:18:20 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:20 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:20 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:20 --> Controller Class Initialized
INFO - 2024-10-08 14:18:21 --> Config Class Initialized
INFO - 2024-10-08 14:18:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:21 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:21 --> URI Class Initialized
INFO - 2024-10-08 14:18:21 --> Router Class Initialized
INFO - 2024-10-08 14:18:21 --> Output Class Initialized
INFO - 2024-10-08 14:18:21 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:21 --> Input Class Initialized
INFO - 2024-10-08 14:18:21 --> Language Class Initialized
INFO - 2024-10-08 14:18:21 --> Language Class Initialized
INFO - 2024-10-08 14:18:21 --> Config Class Initialized
INFO - 2024-10-08 14:18:21 --> Loader Class Initialized
INFO - 2024-10-08 14:18:21 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:21 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:21 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:21 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:21 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:21 --> Controller Class Initialized
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:24 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:24 --> URI Class Initialized
INFO - 2024-10-08 14:18:24 --> Router Class Initialized
INFO - 2024-10-08 14:18:24 --> Output Class Initialized
INFO - 2024-10-08 14:18:24 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:24 --> Input Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Loader Class Initialized
INFO - 2024-10-08 14:18:24 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:24 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:24 --> Controller Class Initialized
INFO - 2024-10-08 14:18:24 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:24 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:24 --> URI Class Initialized
INFO - 2024-10-08 14:18:24 --> Router Class Initialized
INFO - 2024-10-08 14:18:24 --> Output Class Initialized
INFO - 2024-10-08 14:18:24 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:24 --> Input Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Loader Class Initialized
INFO - 2024-10-08 14:18:24 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:24 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:24 --> Controller Class Initialized
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:24 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:24 --> URI Class Initialized
INFO - 2024-10-08 14:18:24 --> Router Class Initialized
INFO - 2024-10-08 14:18:24 --> Output Class Initialized
INFO - 2024-10-08 14:18:24 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:24 --> Input Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Language Class Initialized
INFO - 2024-10-08 14:18:24 --> Config Class Initialized
INFO - 2024-10-08 14:18:24 --> Loader Class Initialized
INFO - 2024-10-08 14:18:24 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:24 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:24 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:24 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:24 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:24 --> Total execution time: 0.0313
INFO - 2024-10-08 14:18:29 --> Config Class Initialized
INFO - 2024-10-08 14:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:29 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:29 --> URI Class Initialized
INFO - 2024-10-08 14:18:29 --> Router Class Initialized
INFO - 2024-10-08 14:18:29 --> Output Class Initialized
INFO - 2024-10-08 14:18:29 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:29 --> Input Class Initialized
INFO - 2024-10-08 14:18:29 --> Language Class Initialized
INFO - 2024-10-08 14:18:29 --> Language Class Initialized
INFO - 2024-10-08 14:18:29 --> Config Class Initialized
INFO - 2024-10-08 14:18:29 --> Loader Class Initialized
INFO - 2024-10-08 14:18:29 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:29 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:29 --> Controller Class Initialized
INFO - 2024-10-08 14:18:29 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:18:29 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:29 --> Total execution time: 0.0343
INFO - 2024-10-08 14:18:29 --> Config Class Initialized
INFO - 2024-10-08 14:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:29 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:29 --> URI Class Initialized
INFO - 2024-10-08 14:18:29 --> Router Class Initialized
INFO - 2024-10-08 14:18:29 --> Output Class Initialized
INFO - 2024-10-08 14:18:29 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:29 --> Input Class Initialized
INFO - 2024-10-08 14:18:29 --> Language Class Initialized
INFO - 2024-10-08 14:18:29 --> Language Class Initialized
INFO - 2024-10-08 14:18:29 --> Config Class Initialized
INFO - 2024-10-08 14:18:29 --> Loader Class Initialized
INFO - 2024-10-08 14:18:29 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:29 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:29 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:29 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 14:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:29 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:29 --> Total execution time: 0.0377
INFO - 2024-10-08 14:18:35 --> Config Class Initialized
INFO - 2024-10-08 14:18:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:35 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:35 --> URI Class Initialized
INFO - 2024-10-08 14:18:35 --> Router Class Initialized
INFO - 2024-10-08 14:18:35 --> Output Class Initialized
INFO - 2024-10-08 14:18:35 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:35 --> Input Class Initialized
INFO - 2024-10-08 14:18:35 --> Language Class Initialized
INFO - 2024-10-08 14:18:35 --> Language Class Initialized
INFO - 2024-10-08 14:18:35 --> Config Class Initialized
INFO - 2024-10-08 14:18:35 --> Loader Class Initialized
INFO - 2024-10-08 14:18:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:36 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 14:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:18:36 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:36 --> Total execution time: 0.0358
INFO - 2024-10-08 14:18:37 --> Config Class Initialized
INFO - 2024-10-08 14:18:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:18:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:18:37 --> Utf8 Class Initialized
INFO - 2024-10-08 14:18:37 --> URI Class Initialized
INFO - 2024-10-08 14:18:37 --> Router Class Initialized
INFO - 2024-10-08 14:18:37 --> Output Class Initialized
INFO - 2024-10-08 14:18:37 --> Security Class Initialized
DEBUG - 2024-10-08 14:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:18:37 --> Input Class Initialized
INFO - 2024-10-08 14:18:37 --> Language Class Initialized
INFO - 2024-10-08 14:18:37 --> Language Class Initialized
INFO - 2024-10-08 14:18:37 --> Config Class Initialized
INFO - 2024-10-08 14:18:37 --> Loader Class Initialized
INFO - 2024-10-08 14:18:37 --> Helper loaded: url_helper
INFO - 2024-10-08 14:18:37 --> Helper loaded: file_helper
INFO - 2024-10-08 14:18:37 --> Helper loaded: form_helper
INFO - 2024-10-08 14:18:37 --> Helper loaded: my_helper
INFO - 2024-10-08 14:18:37 --> Database Driver Class Initialized
INFO - 2024-10-08 14:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:18:37 --> Controller Class Initialized
DEBUG - 2024-10-08 14:18:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 14:18:40 --> Final output sent to browser
DEBUG - 2024-10-08 14:18:40 --> Total execution time: 3.4555
INFO - 2024-10-08 14:23:40 --> Config Class Initialized
INFO - 2024-10-08 14:23:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:23:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:23:40 --> Utf8 Class Initialized
INFO - 2024-10-08 14:23:40 --> URI Class Initialized
INFO - 2024-10-08 14:23:40 --> Router Class Initialized
INFO - 2024-10-08 14:23:40 --> Output Class Initialized
INFO - 2024-10-08 14:23:40 --> Security Class Initialized
DEBUG - 2024-10-08 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:23:40 --> Input Class Initialized
INFO - 2024-10-08 14:23:40 --> Language Class Initialized
INFO - 2024-10-08 14:23:40 --> Language Class Initialized
INFO - 2024-10-08 14:23:40 --> Config Class Initialized
INFO - 2024-10-08 14:23:40 --> Loader Class Initialized
INFO - 2024-10-08 14:23:40 --> Helper loaded: url_helper
INFO - 2024-10-08 14:23:40 --> Helper loaded: file_helper
INFO - 2024-10-08 14:23:40 --> Helper loaded: form_helper
INFO - 2024-10-08 14:23:40 --> Helper loaded: my_helper
INFO - 2024-10-08 14:23:40 --> Database Driver Class Initialized
INFO - 2024-10-08 14:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:23:40 --> Controller Class Initialized
DEBUG - 2024-10-08 14:23:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 14:23:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:23:40 --> Final output sent to browser
DEBUG - 2024-10-08 14:23:40 --> Total execution time: 0.0459
INFO - 2024-10-08 14:23:42 --> Config Class Initialized
INFO - 2024-10-08 14:23:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:23:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:23:42 --> Utf8 Class Initialized
INFO - 2024-10-08 14:23:42 --> URI Class Initialized
INFO - 2024-10-08 14:23:42 --> Router Class Initialized
INFO - 2024-10-08 14:23:42 --> Output Class Initialized
INFO - 2024-10-08 14:23:42 --> Security Class Initialized
DEBUG - 2024-10-08 14:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:23:42 --> Input Class Initialized
INFO - 2024-10-08 14:23:42 --> Language Class Initialized
INFO - 2024-10-08 14:23:42 --> Language Class Initialized
INFO - 2024-10-08 14:23:42 --> Config Class Initialized
INFO - 2024-10-08 14:23:42 --> Loader Class Initialized
INFO - 2024-10-08 14:23:42 --> Helper loaded: url_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: file_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: form_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: my_helper
INFO - 2024-10-08 14:23:42 --> Database Driver Class Initialized
INFO - 2024-10-08 14:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:23:42 --> Controller Class Initialized
INFO - 2024-10-08 14:23:42 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:23:42 --> Config Class Initialized
INFO - 2024-10-08 14:23:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:23:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:23:42 --> Utf8 Class Initialized
INFO - 2024-10-08 14:23:42 --> URI Class Initialized
INFO - 2024-10-08 14:23:42 --> Router Class Initialized
INFO - 2024-10-08 14:23:42 --> Output Class Initialized
INFO - 2024-10-08 14:23:42 --> Security Class Initialized
DEBUG - 2024-10-08 14:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:23:42 --> Input Class Initialized
INFO - 2024-10-08 14:23:42 --> Language Class Initialized
INFO - 2024-10-08 14:23:42 --> Language Class Initialized
INFO - 2024-10-08 14:23:42 --> Config Class Initialized
INFO - 2024-10-08 14:23:42 --> Loader Class Initialized
INFO - 2024-10-08 14:23:42 --> Helper loaded: url_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: file_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: form_helper
INFO - 2024-10-08 14:23:42 --> Helper loaded: my_helper
INFO - 2024-10-08 14:23:42 --> Database Driver Class Initialized
INFO - 2024-10-08 14:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:23:42 --> Controller Class Initialized
INFO - 2024-10-08 14:23:43 --> Config Class Initialized
INFO - 2024-10-08 14:23:43 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:23:43 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:23:43 --> Utf8 Class Initialized
INFO - 2024-10-08 14:23:43 --> URI Class Initialized
INFO - 2024-10-08 14:23:43 --> Router Class Initialized
INFO - 2024-10-08 14:23:43 --> Output Class Initialized
INFO - 2024-10-08 14:23:43 --> Security Class Initialized
DEBUG - 2024-10-08 14:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:23:43 --> Input Class Initialized
INFO - 2024-10-08 14:23:43 --> Language Class Initialized
INFO - 2024-10-08 14:23:43 --> Language Class Initialized
INFO - 2024-10-08 14:23:43 --> Config Class Initialized
INFO - 2024-10-08 14:23:43 --> Loader Class Initialized
INFO - 2024-10-08 14:23:43 --> Helper loaded: url_helper
INFO - 2024-10-08 14:23:43 --> Helper loaded: file_helper
INFO - 2024-10-08 14:23:43 --> Helper loaded: form_helper
INFO - 2024-10-08 14:23:43 --> Helper loaded: my_helper
INFO - 2024-10-08 14:23:43 --> Database Driver Class Initialized
INFO - 2024-10-08 14:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:23:43 --> Controller Class Initialized
DEBUG - 2024-10-08 14:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:23:43 --> Final output sent to browser
DEBUG - 2024-10-08 14:23:43 --> Total execution time: 0.0307
INFO - 2024-10-08 14:24:06 --> Config Class Initialized
INFO - 2024-10-08 14:24:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:06 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:06 --> URI Class Initialized
INFO - 2024-10-08 14:24:06 --> Router Class Initialized
INFO - 2024-10-08 14:24:06 --> Output Class Initialized
INFO - 2024-10-08 14:24:06 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:06 --> Input Class Initialized
INFO - 2024-10-08 14:24:06 --> Language Class Initialized
INFO - 2024-10-08 14:24:06 --> Language Class Initialized
INFO - 2024-10-08 14:24:06 --> Config Class Initialized
INFO - 2024-10-08 14:24:06 --> Loader Class Initialized
INFO - 2024-10-08 14:24:06 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:06 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:06 --> Controller Class Initialized
INFO - 2024-10-08 14:24:06 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:24:06 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:06 --> Total execution time: 0.0838
INFO - 2024-10-08 14:24:06 --> Config Class Initialized
INFO - 2024-10-08 14:24:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:06 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:06 --> URI Class Initialized
INFO - 2024-10-08 14:24:06 --> Router Class Initialized
INFO - 2024-10-08 14:24:06 --> Output Class Initialized
INFO - 2024-10-08 14:24:06 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:06 --> Input Class Initialized
INFO - 2024-10-08 14:24:06 --> Language Class Initialized
INFO - 2024-10-08 14:24:06 --> Language Class Initialized
INFO - 2024-10-08 14:24:06 --> Config Class Initialized
INFO - 2024-10-08 14:24:06 --> Loader Class Initialized
INFO - 2024-10-08 14:24:06 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:06 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:06 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:06 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 14:24:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:06 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:06 --> Total execution time: 0.0784
INFO - 2024-10-08 14:24:09 --> Config Class Initialized
INFO - 2024-10-08 14:24:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:09 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:09 --> URI Class Initialized
INFO - 2024-10-08 14:24:09 --> Router Class Initialized
INFO - 2024-10-08 14:24:09 --> Output Class Initialized
INFO - 2024-10-08 14:24:09 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:09 --> Input Class Initialized
INFO - 2024-10-08 14:24:09 --> Language Class Initialized
INFO - 2024-10-08 14:24:09 --> Language Class Initialized
INFO - 2024-10-08 14:24:09 --> Config Class Initialized
INFO - 2024-10-08 14:24:09 --> Loader Class Initialized
INFO - 2024-10-08 14:24:09 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:09 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:09 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 14:24:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:09 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:09 --> Total execution time: 0.0392
INFO - 2024-10-08 14:24:09 --> Config Class Initialized
INFO - 2024-10-08 14:24:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:09 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:09 --> URI Class Initialized
INFO - 2024-10-08 14:24:09 --> Router Class Initialized
INFO - 2024-10-08 14:24:09 --> Output Class Initialized
INFO - 2024-10-08 14:24:09 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:09 --> Input Class Initialized
INFO - 2024-10-08 14:24:09 --> Language Class Initialized
ERROR - 2024-10-08 14:24:09 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:24:09 --> Config Class Initialized
INFO - 2024-10-08 14:24:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:09 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:09 --> URI Class Initialized
INFO - 2024-10-08 14:24:09 --> Router Class Initialized
INFO - 2024-10-08 14:24:09 --> Output Class Initialized
INFO - 2024-10-08 14:24:09 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:09 --> Input Class Initialized
INFO - 2024-10-08 14:24:09 --> Language Class Initialized
INFO - 2024-10-08 14:24:09 --> Language Class Initialized
INFO - 2024-10-08 14:24:09 --> Config Class Initialized
INFO - 2024-10-08 14:24:09 --> Loader Class Initialized
INFO - 2024-10-08 14:24:09 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:09 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:09 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:09 --> Controller Class Initialized
INFO - 2024-10-08 14:24:16 --> Config Class Initialized
INFO - 2024-10-08 14:24:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:16 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:16 --> URI Class Initialized
INFO - 2024-10-08 14:24:16 --> Router Class Initialized
INFO - 2024-10-08 14:24:16 --> Output Class Initialized
INFO - 2024-10-08 14:24:16 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:16 --> Input Class Initialized
INFO - 2024-10-08 14:24:17 --> Language Class Initialized
INFO - 2024-10-08 14:24:17 --> Language Class Initialized
INFO - 2024-10-08 14:24:17 --> Config Class Initialized
INFO - 2024-10-08 14:24:17 --> Loader Class Initialized
INFO - 2024-10-08 14:24:17 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:17 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:17 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-08 14:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:17 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:17 --> Total execution time: 0.0379
INFO - 2024-10-08 14:24:17 --> Config Class Initialized
INFO - 2024-10-08 14:24:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:17 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:17 --> URI Class Initialized
INFO - 2024-10-08 14:24:17 --> Router Class Initialized
INFO - 2024-10-08 14:24:17 --> Output Class Initialized
INFO - 2024-10-08 14:24:17 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:17 --> Input Class Initialized
INFO - 2024-10-08 14:24:17 --> Language Class Initialized
ERROR - 2024-10-08 14:24:17 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:24:17 --> Config Class Initialized
INFO - 2024-10-08 14:24:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:17 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:17 --> URI Class Initialized
INFO - 2024-10-08 14:24:17 --> Router Class Initialized
INFO - 2024-10-08 14:24:17 --> Output Class Initialized
INFO - 2024-10-08 14:24:17 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:17 --> Input Class Initialized
INFO - 2024-10-08 14:24:17 --> Language Class Initialized
INFO - 2024-10-08 14:24:17 --> Language Class Initialized
INFO - 2024-10-08 14:24:17 --> Config Class Initialized
INFO - 2024-10-08 14:24:17 --> Loader Class Initialized
INFO - 2024-10-08 14:24:17 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:17 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:17 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:17 --> Controller Class Initialized
INFO - 2024-10-08 14:24:22 --> Config Class Initialized
INFO - 2024-10-08 14:24:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:22 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:22 --> URI Class Initialized
INFO - 2024-10-08 14:24:22 --> Router Class Initialized
INFO - 2024-10-08 14:24:22 --> Output Class Initialized
INFO - 2024-10-08 14:24:22 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:22 --> Input Class Initialized
INFO - 2024-10-08 14:24:22 --> Language Class Initialized
INFO - 2024-10-08 14:24:22 --> Language Class Initialized
INFO - 2024-10-08 14:24:22 --> Config Class Initialized
INFO - 2024-10-08 14:24:22 --> Loader Class Initialized
INFO - 2024-10-08 14:24:22 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:22 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:22 --> Controller Class Initialized
INFO - 2024-10-08 14:24:22 --> Config Class Initialized
INFO - 2024-10-08 14:24:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:22 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:22 --> URI Class Initialized
INFO - 2024-10-08 14:24:22 --> Router Class Initialized
INFO - 2024-10-08 14:24:22 --> Output Class Initialized
INFO - 2024-10-08 14:24:22 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:22 --> Input Class Initialized
INFO - 2024-10-08 14:24:22 --> Language Class Initialized
INFO - 2024-10-08 14:24:22 --> Language Class Initialized
INFO - 2024-10-08 14:24:22 --> Config Class Initialized
INFO - 2024-10-08 14:24:22 --> Loader Class Initialized
INFO - 2024-10-08 14:24:22 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:22 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:22 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:22 --> Controller Class Initialized
INFO - 2024-10-08 14:24:23 --> Config Class Initialized
INFO - 2024-10-08 14:24:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:23 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:23 --> URI Class Initialized
INFO - 2024-10-08 14:24:23 --> Router Class Initialized
INFO - 2024-10-08 14:24:23 --> Output Class Initialized
INFO - 2024-10-08 14:24:23 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:23 --> Input Class Initialized
INFO - 2024-10-08 14:24:23 --> Language Class Initialized
INFO - 2024-10-08 14:24:23 --> Language Class Initialized
INFO - 2024-10-08 14:24:23 --> Config Class Initialized
INFO - 2024-10-08 14:24:23 --> Loader Class Initialized
INFO - 2024-10-08 14:24:23 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:23 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:23 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:23 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:23 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:23 --> Controller Class Initialized
INFO - 2024-10-08 14:24:28 --> Config Class Initialized
INFO - 2024-10-08 14:24:28 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:28 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:28 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:28 --> URI Class Initialized
INFO - 2024-10-08 14:24:28 --> Router Class Initialized
INFO - 2024-10-08 14:24:28 --> Output Class Initialized
INFO - 2024-10-08 14:24:28 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:28 --> Input Class Initialized
INFO - 2024-10-08 14:24:28 --> Language Class Initialized
INFO - 2024-10-08 14:24:28 --> Language Class Initialized
INFO - 2024-10-08 14:24:28 --> Config Class Initialized
INFO - 2024-10-08 14:24:28 --> Loader Class Initialized
INFO - 2024-10-08 14:24:28 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:28 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:28 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 14:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:28 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:28 --> Total execution time: 0.0299
INFO - 2024-10-08 14:24:28 --> Config Class Initialized
INFO - 2024-10-08 14:24:28 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:28 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:28 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:28 --> URI Class Initialized
INFO - 2024-10-08 14:24:28 --> Router Class Initialized
INFO - 2024-10-08 14:24:28 --> Output Class Initialized
INFO - 2024-10-08 14:24:28 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:28 --> Input Class Initialized
INFO - 2024-10-08 14:24:28 --> Language Class Initialized
ERROR - 2024-10-08 14:24:28 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:24:28 --> Config Class Initialized
INFO - 2024-10-08 14:24:28 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:28 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:28 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:28 --> URI Class Initialized
INFO - 2024-10-08 14:24:28 --> Router Class Initialized
INFO - 2024-10-08 14:24:28 --> Output Class Initialized
INFO - 2024-10-08 14:24:28 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:28 --> Input Class Initialized
INFO - 2024-10-08 14:24:28 --> Language Class Initialized
INFO - 2024-10-08 14:24:28 --> Language Class Initialized
INFO - 2024-10-08 14:24:28 --> Config Class Initialized
INFO - 2024-10-08 14:24:28 --> Loader Class Initialized
INFO - 2024-10-08 14:24:28 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:28 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:28 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:28 --> Controller Class Initialized
INFO - 2024-10-08 14:24:30 --> Config Class Initialized
INFO - 2024-10-08 14:24:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:30 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:30 --> URI Class Initialized
INFO - 2024-10-08 14:24:30 --> Router Class Initialized
INFO - 2024-10-08 14:24:30 --> Output Class Initialized
INFO - 2024-10-08 14:24:30 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:30 --> Input Class Initialized
INFO - 2024-10-08 14:24:30 --> Language Class Initialized
INFO - 2024-10-08 14:24:30 --> Language Class Initialized
INFO - 2024-10-08 14:24:30 --> Config Class Initialized
INFO - 2024-10-08 14:24:30 --> Loader Class Initialized
INFO - 2024-10-08 14:24:30 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:30 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:30 --> Controller Class Initialized
INFO - 2024-10-08 14:24:30 --> Config Class Initialized
INFO - 2024-10-08 14:24:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:30 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:30 --> URI Class Initialized
INFO - 2024-10-08 14:24:30 --> Router Class Initialized
INFO - 2024-10-08 14:24:30 --> Output Class Initialized
INFO - 2024-10-08 14:24:30 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:30 --> Input Class Initialized
INFO - 2024-10-08 14:24:30 --> Language Class Initialized
INFO - 2024-10-08 14:24:30 --> Language Class Initialized
INFO - 2024-10-08 14:24:30 --> Config Class Initialized
INFO - 2024-10-08 14:24:30 --> Loader Class Initialized
INFO - 2024-10-08 14:24:30 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:30 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:30 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:31 --> Controller Class Initialized
INFO - 2024-10-08 14:24:31 --> Config Class Initialized
INFO - 2024-10-08 14:24:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:31 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:31 --> URI Class Initialized
INFO - 2024-10-08 14:24:31 --> Router Class Initialized
INFO - 2024-10-08 14:24:31 --> Output Class Initialized
INFO - 2024-10-08 14:24:31 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:31 --> Input Class Initialized
INFO - 2024-10-08 14:24:31 --> Language Class Initialized
INFO - 2024-10-08 14:24:31 --> Language Class Initialized
INFO - 2024-10-08 14:24:31 --> Config Class Initialized
INFO - 2024-10-08 14:24:31 --> Loader Class Initialized
INFO - 2024-10-08 14:24:31 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:31 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:31 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:31 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:31 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:31 --> Controller Class Initialized
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:33 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:33 --> URI Class Initialized
INFO - 2024-10-08 14:24:33 --> Router Class Initialized
INFO - 2024-10-08 14:24:33 --> Output Class Initialized
INFO - 2024-10-08 14:24:33 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:33 --> Input Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Loader Class Initialized
INFO - 2024-10-08 14:24:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:33 --> Controller Class Initialized
INFO - 2024-10-08 14:24:33 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:33 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:33 --> URI Class Initialized
INFO - 2024-10-08 14:24:33 --> Router Class Initialized
INFO - 2024-10-08 14:24:33 --> Output Class Initialized
INFO - 2024-10-08 14:24:33 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:33 --> Input Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Loader Class Initialized
INFO - 2024-10-08 14:24:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:33 --> Controller Class Initialized
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:33 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:33 --> URI Class Initialized
INFO - 2024-10-08 14:24:33 --> Router Class Initialized
INFO - 2024-10-08 14:24:33 --> Output Class Initialized
INFO - 2024-10-08 14:24:33 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:33 --> Input Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Language Class Initialized
INFO - 2024-10-08 14:24:33 --> Config Class Initialized
INFO - 2024-10-08 14:24:33 --> Loader Class Initialized
INFO - 2024-10-08 14:24:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:33 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:24:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:33 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:33 --> Total execution time: 0.0453
INFO - 2024-10-08 14:24:41 --> Config Class Initialized
INFO - 2024-10-08 14:24:41 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:41 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:41 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:41 --> URI Class Initialized
INFO - 2024-10-08 14:24:41 --> Router Class Initialized
INFO - 2024-10-08 14:24:41 --> Output Class Initialized
INFO - 2024-10-08 14:24:41 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:41 --> Input Class Initialized
INFO - 2024-10-08 14:24:41 --> Language Class Initialized
INFO - 2024-10-08 14:24:41 --> Language Class Initialized
INFO - 2024-10-08 14:24:41 --> Config Class Initialized
INFO - 2024-10-08 14:24:41 --> Loader Class Initialized
INFO - 2024-10-08 14:24:41 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:41 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:41 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:41 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:41 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:41 --> Controller Class Initialized
INFO - 2024-10-08 14:24:41 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:41 --> Total execution time: 0.0303
INFO - 2024-10-08 14:24:46 --> Config Class Initialized
INFO - 2024-10-08 14:24:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:46 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:46 --> URI Class Initialized
INFO - 2024-10-08 14:24:46 --> Router Class Initialized
INFO - 2024-10-08 14:24:46 --> Output Class Initialized
INFO - 2024-10-08 14:24:46 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:46 --> Input Class Initialized
INFO - 2024-10-08 14:24:46 --> Language Class Initialized
INFO - 2024-10-08 14:24:46 --> Language Class Initialized
INFO - 2024-10-08 14:24:46 --> Config Class Initialized
INFO - 2024-10-08 14:24:46 --> Loader Class Initialized
INFO - 2024-10-08 14:24:46 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:46 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:46 --> Controller Class Initialized
INFO - 2024-10-08 14:24:46 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:24:46 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:46 --> Total execution time: 0.0335
INFO - 2024-10-08 14:24:46 --> Config Class Initialized
INFO - 2024-10-08 14:24:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:46 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:46 --> URI Class Initialized
INFO - 2024-10-08 14:24:46 --> Router Class Initialized
INFO - 2024-10-08 14:24:46 --> Output Class Initialized
INFO - 2024-10-08 14:24:46 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:46 --> Input Class Initialized
INFO - 2024-10-08 14:24:46 --> Language Class Initialized
INFO - 2024-10-08 14:24:46 --> Language Class Initialized
INFO - 2024-10-08 14:24:46 --> Config Class Initialized
INFO - 2024-10-08 14:24:46 --> Loader Class Initialized
INFO - 2024-10-08 14:24:46 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:46 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:46 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:46 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 14:24:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:46 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:46 --> Total execution time: 0.0371
INFO - 2024-10-08 14:24:49 --> Config Class Initialized
INFO - 2024-10-08 14:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:24:49 --> Utf8 Class Initialized
INFO - 2024-10-08 14:24:49 --> URI Class Initialized
INFO - 2024-10-08 14:24:49 --> Router Class Initialized
INFO - 2024-10-08 14:24:49 --> Output Class Initialized
INFO - 2024-10-08 14:24:49 --> Security Class Initialized
DEBUG - 2024-10-08 14:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:24:49 --> Input Class Initialized
INFO - 2024-10-08 14:24:49 --> Language Class Initialized
INFO - 2024-10-08 14:24:49 --> Language Class Initialized
INFO - 2024-10-08 14:24:49 --> Config Class Initialized
INFO - 2024-10-08 14:24:49 --> Loader Class Initialized
INFO - 2024-10-08 14:24:49 --> Helper loaded: url_helper
INFO - 2024-10-08 14:24:49 --> Helper loaded: file_helper
INFO - 2024-10-08 14:24:49 --> Helper loaded: form_helper
INFO - 2024-10-08 14:24:49 --> Helper loaded: my_helper
INFO - 2024-10-08 14:24:49 --> Database Driver Class Initialized
INFO - 2024-10-08 14:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:24:49 --> Controller Class Initialized
DEBUG - 2024-10-08 14:24:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 14:24:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:24:49 --> Final output sent to browser
DEBUG - 2024-10-08 14:24:49 --> Total execution time: 0.0354
INFO - 2024-10-08 14:25:05 --> Config Class Initialized
INFO - 2024-10-08 14:25:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:05 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:05 --> URI Class Initialized
INFO - 2024-10-08 14:25:05 --> Router Class Initialized
INFO - 2024-10-08 14:25:05 --> Output Class Initialized
INFO - 2024-10-08 14:25:05 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:05 --> Input Class Initialized
INFO - 2024-10-08 14:25:05 --> Language Class Initialized
INFO - 2024-10-08 14:25:05 --> Language Class Initialized
INFO - 2024-10-08 14:25:05 --> Config Class Initialized
INFO - 2024-10-08 14:25:05 --> Loader Class Initialized
INFO - 2024-10-08 14:25:05 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:05 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:05 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:05 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:05 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:05 --> Controller Class Initialized
DEBUG - 2024-10-08 14:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 14:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:25:05 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:05 --> Total execution time: 0.0434
INFO - 2024-10-08 14:25:06 --> Config Class Initialized
INFO - 2024-10-08 14:25:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:06 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:06 --> URI Class Initialized
INFO - 2024-10-08 14:25:06 --> Router Class Initialized
INFO - 2024-10-08 14:25:06 --> Output Class Initialized
INFO - 2024-10-08 14:25:06 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:06 --> Input Class Initialized
INFO - 2024-10-08 14:25:06 --> Language Class Initialized
INFO - 2024-10-08 14:25:06 --> Language Class Initialized
INFO - 2024-10-08 14:25:06 --> Config Class Initialized
INFO - 2024-10-08 14:25:06 --> Loader Class Initialized
INFO - 2024-10-08 14:25:06 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:06 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:06 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:06 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:06 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:06 --> Controller Class Initialized
INFO - 2024-10-08 14:25:09 --> Config Class Initialized
INFO - 2024-10-08 14:25:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:09 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:09 --> URI Class Initialized
INFO - 2024-10-08 14:25:09 --> Router Class Initialized
INFO - 2024-10-08 14:25:09 --> Output Class Initialized
INFO - 2024-10-08 14:25:09 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:09 --> Input Class Initialized
INFO - 2024-10-08 14:25:09 --> Language Class Initialized
INFO - 2024-10-08 14:25:09 --> Language Class Initialized
INFO - 2024-10-08 14:25:09 --> Config Class Initialized
INFO - 2024-10-08 14:25:09 --> Loader Class Initialized
INFO - 2024-10-08 14:25:09 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:09 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:09 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:09 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:09 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:09 --> Controller Class Initialized
INFO - 2024-10-08 14:25:09 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:09 --> Total execution time: 0.0409
INFO - 2024-10-08 14:25:13 --> Config Class Initialized
INFO - 2024-10-08 14:25:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:13 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:13 --> URI Class Initialized
INFO - 2024-10-08 14:25:13 --> Router Class Initialized
INFO - 2024-10-08 14:25:13 --> Output Class Initialized
INFO - 2024-10-08 14:25:13 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:13 --> Input Class Initialized
INFO - 2024-10-08 14:25:13 --> Language Class Initialized
INFO - 2024-10-08 14:25:13 --> Language Class Initialized
INFO - 2024-10-08 14:25:13 --> Config Class Initialized
INFO - 2024-10-08 14:25:13 --> Loader Class Initialized
INFO - 2024-10-08 14:25:13 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:13 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:13 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:13 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:13 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:13 --> Controller Class Initialized
INFO - 2024-10-08 14:25:13 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:13 --> Total execution time: 0.0355
INFO - 2024-10-08 14:25:16 --> Config Class Initialized
INFO - 2024-10-08 14:25:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:16 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:16 --> URI Class Initialized
INFO - 2024-10-08 14:25:16 --> Router Class Initialized
INFO - 2024-10-08 14:25:16 --> Output Class Initialized
INFO - 2024-10-08 14:25:16 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:16 --> Input Class Initialized
INFO - 2024-10-08 14:25:16 --> Language Class Initialized
INFO - 2024-10-08 14:25:16 --> Language Class Initialized
INFO - 2024-10-08 14:25:16 --> Config Class Initialized
INFO - 2024-10-08 14:25:16 --> Loader Class Initialized
INFO - 2024-10-08 14:25:16 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:16 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:16 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:16 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:16 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:16 --> Controller Class Initialized
INFO - 2024-10-08 14:25:16 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:16 --> Total execution time: 0.0418
INFO - 2024-10-08 14:25:18 --> Config Class Initialized
INFO - 2024-10-08 14:25:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:18 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:18 --> URI Class Initialized
INFO - 2024-10-08 14:25:18 --> Router Class Initialized
INFO - 2024-10-08 14:25:18 --> Output Class Initialized
INFO - 2024-10-08 14:25:18 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:18 --> Input Class Initialized
INFO - 2024-10-08 14:25:18 --> Language Class Initialized
INFO - 2024-10-08 14:25:18 --> Language Class Initialized
INFO - 2024-10-08 14:25:18 --> Config Class Initialized
INFO - 2024-10-08 14:25:18 --> Loader Class Initialized
INFO - 2024-10-08 14:25:18 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:18 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:18 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:18 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:18 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:18 --> Controller Class Initialized
INFO - 2024-10-08 14:25:18 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:18 --> Total execution time: 0.0417
INFO - 2024-10-08 14:25:22 --> Config Class Initialized
INFO - 2024-10-08 14:25:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:22 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:22 --> URI Class Initialized
INFO - 2024-10-08 14:25:22 --> Router Class Initialized
INFO - 2024-10-08 14:25:22 --> Output Class Initialized
INFO - 2024-10-08 14:25:22 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:22 --> Input Class Initialized
INFO - 2024-10-08 14:25:22 --> Language Class Initialized
INFO - 2024-10-08 14:25:22 --> Language Class Initialized
INFO - 2024-10-08 14:25:22 --> Config Class Initialized
INFO - 2024-10-08 14:25:22 --> Loader Class Initialized
INFO - 2024-10-08 14:25:22 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:22 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:22 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:22 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:22 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:22 --> Controller Class Initialized
INFO - 2024-10-08 14:25:22 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:22 --> Total execution time: 0.0763
INFO - 2024-10-08 14:25:32 --> Config Class Initialized
INFO - 2024-10-08 14:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:32 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:32 --> URI Class Initialized
INFO - 2024-10-08 14:25:32 --> Router Class Initialized
INFO - 2024-10-08 14:25:32 --> Output Class Initialized
INFO - 2024-10-08 14:25:32 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:32 --> Input Class Initialized
INFO - 2024-10-08 14:25:32 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Config Class Initialized
INFO - 2024-10-08 14:25:33 --> Loader Class Initialized
INFO - 2024-10-08 14:25:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:33 --> Controller Class Initialized
INFO - 2024-10-08 14:25:33 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:25:33 --> Config Class Initialized
INFO - 2024-10-08 14:25:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:33 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:33 --> URI Class Initialized
INFO - 2024-10-08 14:25:33 --> Router Class Initialized
INFO - 2024-10-08 14:25:33 --> Output Class Initialized
INFO - 2024-10-08 14:25:33 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:33 --> Input Class Initialized
INFO - 2024-10-08 14:25:33 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Config Class Initialized
INFO - 2024-10-08 14:25:33 --> Loader Class Initialized
INFO - 2024-10-08 14:25:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:33 --> Controller Class Initialized
INFO - 2024-10-08 14:25:33 --> Config Class Initialized
INFO - 2024-10-08 14:25:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:33 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:33 --> URI Class Initialized
INFO - 2024-10-08 14:25:33 --> Router Class Initialized
INFO - 2024-10-08 14:25:33 --> Output Class Initialized
INFO - 2024-10-08 14:25:33 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:33 --> Input Class Initialized
INFO - 2024-10-08 14:25:33 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Language Class Initialized
INFO - 2024-10-08 14:25:33 --> Config Class Initialized
INFO - 2024-10-08 14:25:33 --> Loader Class Initialized
INFO - 2024-10-08 14:25:33 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:33 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:33 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:33 --> Controller Class Initialized
DEBUG - 2024-10-08 14:25:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:25:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:25:33 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:33 --> Total execution time: 0.0694
INFO - 2024-10-08 14:25:39 --> Config Class Initialized
INFO - 2024-10-08 14:25:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:39 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:39 --> URI Class Initialized
INFO - 2024-10-08 14:25:39 --> Router Class Initialized
INFO - 2024-10-08 14:25:39 --> Output Class Initialized
INFO - 2024-10-08 14:25:39 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:39 --> Input Class Initialized
INFO - 2024-10-08 14:25:39 --> Language Class Initialized
INFO - 2024-10-08 14:25:39 --> Language Class Initialized
INFO - 2024-10-08 14:25:39 --> Config Class Initialized
INFO - 2024-10-08 14:25:39 --> Loader Class Initialized
INFO - 2024-10-08 14:25:39 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:39 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:39 --> Controller Class Initialized
INFO - 2024-10-08 14:25:39 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:25:39 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:39 --> Total execution time: 0.0380
INFO - 2024-10-08 14:25:39 --> Config Class Initialized
INFO - 2024-10-08 14:25:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:39 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:39 --> URI Class Initialized
INFO - 2024-10-08 14:25:39 --> Router Class Initialized
INFO - 2024-10-08 14:25:39 --> Output Class Initialized
INFO - 2024-10-08 14:25:39 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:39 --> Input Class Initialized
INFO - 2024-10-08 14:25:39 --> Language Class Initialized
INFO - 2024-10-08 14:25:39 --> Language Class Initialized
INFO - 2024-10-08 14:25:39 --> Config Class Initialized
INFO - 2024-10-08 14:25:39 --> Loader Class Initialized
INFO - 2024-10-08 14:25:39 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:39 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:39 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:39 --> Controller Class Initialized
DEBUG - 2024-10-08 14:25:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 14:25:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:25:39 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:39 --> Total execution time: 0.0268
INFO - 2024-10-08 14:25:47 --> Config Class Initialized
INFO - 2024-10-08 14:25:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:47 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:47 --> URI Class Initialized
INFO - 2024-10-08 14:25:47 --> Router Class Initialized
INFO - 2024-10-08 14:25:47 --> Output Class Initialized
INFO - 2024-10-08 14:25:47 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:47 --> Input Class Initialized
INFO - 2024-10-08 14:25:47 --> Language Class Initialized
INFO - 2024-10-08 14:25:47 --> Language Class Initialized
INFO - 2024-10-08 14:25:47 --> Config Class Initialized
INFO - 2024-10-08 14:25:47 --> Loader Class Initialized
INFO - 2024-10-08 14:25:47 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:47 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:47 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:47 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:47 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:47 --> Controller Class Initialized
DEBUG - 2024-10-08 14:25:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 14:25:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:25:47 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:47 --> Total execution time: 0.0358
INFO - 2024-10-08 14:25:52 --> Config Class Initialized
INFO - 2024-10-08 14:25:52 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:52 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:52 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:52 --> URI Class Initialized
INFO - 2024-10-08 14:25:52 --> Router Class Initialized
INFO - 2024-10-08 14:25:52 --> Output Class Initialized
INFO - 2024-10-08 14:25:52 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:52 --> Input Class Initialized
INFO - 2024-10-08 14:25:52 --> Language Class Initialized
INFO - 2024-10-08 14:25:52 --> Language Class Initialized
INFO - 2024-10-08 14:25:52 --> Config Class Initialized
INFO - 2024-10-08 14:25:52 --> Loader Class Initialized
INFO - 2024-10-08 14:25:52 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:52 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:52 --> Controller Class Initialized
DEBUG - 2024-10-08 14:25:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 14:25:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:25:52 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:52 --> Total execution time: 0.0331
INFO - 2024-10-08 14:25:52 --> Config Class Initialized
INFO - 2024-10-08 14:25:52 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:52 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:52 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:52 --> URI Class Initialized
INFO - 2024-10-08 14:25:52 --> Router Class Initialized
INFO - 2024-10-08 14:25:52 --> Output Class Initialized
INFO - 2024-10-08 14:25:52 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:52 --> Input Class Initialized
INFO - 2024-10-08 14:25:52 --> Language Class Initialized
INFO - 2024-10-08 14:25:52 --> Language Class Initialized
INFO - 2024-10-08 14:25:52 --> Config Class Initialized
INFO - 2024-10-08 14:25:52 --> Loader Class Initialized
INFO - 2024-10-08 14:25:52 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:52 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:52 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:52 --> Controller Class Initialized
INFO - 2024-10-08 14:25:54 --> Config Class Initialized
INFO - 2024-10-08 14:25:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:54 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:54 --> URI Class Initialized
INFO - 2024-10-08 14:25:54 --> Router Class Initialized
INFO - 2024-10-08 14:25:54 --> Output Class Initialized
INFO - 2024-10-08 14:25:54 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:54 --> Input Class Initialized
INFO - 2024-10-08 14:25:54 --> Language Class Initialized
INFO - 2024-10-08 14:25:54 --> Language Class Initialized
INFO - 2024-10-08 14:25:54 --> Config Class Initialized
INFO - 2024-10-08 14:25:54 --> Loader Class Initialized
INFO - 2024-10-08 14:25:54 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:54 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:54 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:54 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:54 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:54 --> Controller Class Initialized
INFO - 2024-10-08 14:25:54 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:54 --> Total execution time: 0.0373
INFO - 2024-10-08 14:25:58 --> Config Class Initialized
INFO - 2024-10-08 14:25:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:25:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:25:58 --> Utf8 Class Initialized
INFO - 2024-10-08 14:25:58 --> URI Class Initialized
INFO - 2024-10-08 14:25:58 --> Router Class Initialized
INFO - 2024-10-08 14:25:58 --> Output Class Initialized
INFO - 2024-10-08 14:25:58 --> Security Class Initialized
DEBUG - 2024-10-08 14:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:25:58 --> Input Class Initialized
INFO - 2024-10-08 14:25:58 --> Language Class Initialized
INFO - 2024-10-08 14:25:58 --> Language Class Initialized
INFO - 2024-10-08 14:25:58 --> Config Class Initialized
INFO - 2024-10-08 14:25:58 --> Loader Class Initialized
INFO - 2024-10-08 14:25:58 --> Helper loaded: url_helper
INFO - 2024-10-08 14:25:58 --> Helper loaded: file_helper
INFO - 2024-10-08 14:25:58 --> Helper loaded: form_helper
INFO - 2024-10-08 14:25:58 --> Helper loaded: my_helper
INFO - 2024-10-08 14:25:58 --> Database Driver Class Initialized
INFO - 2024-10-08 14:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:25:58 --> Controller Class Initialized
INFO - 2024-10-08 14:25:58 --> Final output sent to browser
DEBUG - 2024-10-08 14:25:58 --> Total execution time: 0.0325
INFO - 2024-10-08 14:26:08 --> Config Class Initialized
INFO - 2024-10-08 14:26:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:08 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:08 --> URI Class Initialized
INFO - 2024-10-08 14:26:08 --> Router Class Initialized
INFO - 2024-10-08 14:26:08 --> Output Class Initialized
INFO - 2024-10-08 14:26:08 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:08 --> Input Class Initialized
INFO - 2024-10-08 14:26:08 --> Language Class Initialized
INFO - 2024-10-08 14:26:08 --> Language Class Initialized
INFO - 2024-10-08 14:26:08 --> Config Class Initialized
INFO - 2024-10-08 14:26:08 --> Loader Class Initialized
INFO - 2024-10-08 14:26:08 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:08 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:08 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:08 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:08 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:08 --> Controller Class Initialized
INFO - 2024-10-08 14:26:08 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:08 --> Total execution time: 0.0321
INFO - 2024-10-08 14:26:14 --> Config Class Initialized
INFO - 2024-10-08 14:26:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:14 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:14 --> URI Class Initialized
INFO - 2024-10-08 14:26:14 --> Router Class Initialized
INFO - 2024-10-08 14:26:15 --> Output Class Initialized
INFO - 2024-10-08 14:26:15 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:15 --> Input Class Initialized
INFO - 2024-10-08 14:26:15 --> Language Class Initialized
INFO - 2024-10-08 14:26:15 --> Language Class Initialized
INFO - 2024-10-08 14:26:15 --> Config Class Initialized
INFO - 2024-10-08 14:26:15 --> Loader Class Initialized
INFO - 2024-10-08 14:26:15 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:15 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:15 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:15 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:15 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:15 --> Controller Class Initialized
INFO - 2024-10-08 14:26:15 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:15 --> Total execution time: 0.7281
INFO - 2024-10-08 14:26:18 --> Config Class Initialized
INFO - 2024-10-08 14:26:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:18 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:18 --> URI Class Initialized
INFO - 2024-10-08 14:26:18 --> Router Class Initialized
INFO - 2024-10-08 14:26:18 --> Output Class Initialized
INFO - 2024-10-08 14:26:18 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:18 --> Input Class Initialized
INFO - 2024-10-08 14:26:18 --> Language Class Initialized
INFO - 2024-10-08 14:26:18 --> Language Class Initialized
INFO - 2024-10-08 14:26:18 --> Config Class Initialized
INFO - 2024-10-08 14:26:18 --> Loader Class Initialized
INFO - 2024-10-08 14:26:18 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:18 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:18 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:18 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:18 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:18 --> Controller Class Initialized
DEBUG - 2024-10-08 14:26:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 14:26:21 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:21 --> Total execution time: 2.9561
INFO - 2024-10-08 14:26:26 --> Config Class Initialized
INFO - 2024-10-08 14:26:26 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:26 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:26 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:26 --> URI Class Initialized
INFO - 2024-10-08 14:26:26 --> Router Class Initialized
INFO - 2024-10-08 14:26:26 --> Output Class Initialized
INFO - 2024-10-08 14:26:26 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:26 --> Input Class Initialized
INFO - 2024-10-08 14:26:26 --> Language Class Initialized
INFO - 2024-10-08 14:26:26 --> Language Class Initialized
INFO - 2024-10-08 14:26:26 --> Config Class Initialized
INFO - 2024-10-08 14:26:26 --> Loader Class Initialized
INFO - 2024-10-08 14:26:26 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:26 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:26 --> Controller Class Initialized
DEBUG - 2024-10-08 14:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 14:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:26:26 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:26 --> Total execution time: 0.0798
INFO - 2024-10-08 14:26:26 --> Config Class Initialized
INFO - 2024-10-08 14:26:26 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:26 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:26 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:26 --> URI Class Initialized
INFO - 2024-10-08 14:26:26 --> Router Class Initialized
INFO - 2024-10-08 14:26:26 --> Output Class Initialized
INFO - 2024-10-08 14:26:26 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:26 --> Input Class Initialized
INFO - 2024-10-08 14:26:26 --> Language Class Initialized
INFO - 2024-10-08 14:26:26 --> Language Class Initialized
INFO - 2024-10-08 14:26:26 --> Config Class Initialized
INFO - 2024-10-08 14:26:26 --> Loader Class Initialized
INFO - 2024-10-08 14:26:26 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:26 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:26 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:26 --> Controller Class Initialized
INFO - 2024-10-08 14:26:42 --> Config Class Initialized
INFO - 2024-10-08 14:26:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:42 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:42 --> URI Class Initialized
INFO - 2024-10-08 14:26:42 --> Router Class Initialized
INFO - 2024-10-08 14:26:42 --> Output Class Initialized
INFO - 2024-10-08 14:26:42 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:42 --> Input Class Initialized
INFO - 2024-10-08 14:26:42 --> Language Class Initialized
INFO - 2024-10-08 14:26:42 --> Language Class Initialized
INFO - 2024-10-08 14:26:42 --> Config Class Initialized
INFO - 2024-10-08 14:26:42 --> Loader Class Initialized
INFO - 2024-10-08 14:26:42 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:42 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:42 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:42 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:42 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:42 --> Controller Class Initialized
INFO - 2024-10-08 14:26:42 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:42 --> Total execution time: 0.0362
INFO - 2024-10-08 14:26:47 --> Config Class Initialized
INFO - 2024-10-08 14:26:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:47 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:47 --> URI Class Initialized
INFO - 2024-10-08 14:26:47 --> Router Class Initialized
INFO - 2024-10-08 14:26:47 --> Output Class Initialized
INFO - 2024-10-08 14:26:47 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:47 --> Input Class Initialized
INFO - 2024-10-08 14:26:47 --> Language Class Initialized
INFO - 2024-10-08 14:26:47 --> Language Class Initialized
INFO - 2024-10-08 14:26:47 --> Config Class Initialized
INFO - 2024-10-08 14:26:47 --> Loader Class Initialized
INFO - 2024-10-08 14:26:47 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:47 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:47 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:47 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:47 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:47 --> Controller Class Initialized
INFO - 2024-10-08 14:26:48 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:48 --> Total execution time: 0.1991
INFO - 2024-10-08 14:26:49 --> Config Class Initialized
INFO - 2024-10-08 14:26:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:49 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:49 --> URI Class Initialized
INFO - 2024-10-08 14:26:49 --> Router Class Initialized
INFO - 2024-10-08 14:26:49 --> Output Class Initialized
INFO - 2024-10-08 14:26:49 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:49 --> Input Class Initialized
INFO - 2024-10-08 14:26:49 --> Language Class Initialized
INFO - 2024-10-08 14:26:49 --> Language Class Initialized
INFO - 2024-10-08 14:26:49 --> Config Class Initialized
INFO - 2024-10-08 14:26:49 --> Loader Class Initialized
INFO - 2024-10-08 14:26:49 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:49 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:49 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:49 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:49 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:49 --> Controller Class Initialized
INFO - 2024-10-08 14:26:49 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:49 --> Total execution time: 0.0443
INFO - 2024-10-08 14:26:53 --> Config Class Initialized
INFO - 2024-10-08 14:26:53 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:53 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:53 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:53 --> URI Class Initialized
INFO - 2024-10-08 14:26:53 --> Router Class Initialized
INFO - 2024-10-08 14:26:53 --> Output Class Initialized
INFO - 2024-10-08 14:26:53 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:53 --> Input Class Initialized
INFO - 2024-10-08 14:26:53 --> Language Class Initialized
INFO - 2024-10-08 14:26:53 --> Language Class Initialized
INFO - 2024-10-08 14:26:53 --> Config Class Initialized
INFO - 2024-10-08 14:26:53 --> Loader Class Initialized
INFO - 2024-10-08 14:26:53 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:53 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:53 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:53 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:53 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:53 --> Controller Class Initialized
INFO - 2024-10-08 14:26:53 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:53 --> Total execution time: 0.0427
INFO - 2024-10-08 14:26:56 --> Config Class Initialized
INFO - 2024-10-08 14:26:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:56 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:56 --> URI Class Initialized
INFO - 2024-10-08 14:26:56 --> Router Class Initialized
INFO - 2024-10-08 14:26:56 --> Output Class Initialized
INFO - 2024-10-08 14:26:56 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:56 --> Input Class Initialized
INFO - 2024-10-08 14:26:56 --> Language Class Initialized
INFO - 2024-10-08 14:26:56 --> Language Class Initialized
INFO - 2024-10-08 14:26:56 --> Config Class Initialized
INFO - 2024-10-08 14:26:56 --> Loader Class Initialized
INFO - 2024-10-08 14:26:56 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:56 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:56 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:56 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:56 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:56 --> Controller Class Initialized
INFO - 2024-10-08 14:26:56 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:56 --> Total execution time: 0.0337
INFO - 2024-10-08 14:26:58 --> Config Class Initialized
INFO - 2024-10-08 14:26:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:26:58 --> Utf8 Class Initialized
INFO - 2024-10-08 14:26:58 --> URI Class Initialized
INFO - 2024-10-08 14:26:58 --> Router Class Initialized
INFO - 2024-10-08 14:26:58 --> Output Class Initialized
INFO - 2024-10-08 14:26:58 --> Security Class Initialized
DEBUG - 2024-10-08 14:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:26:58 --> Input Class Initialized
INFO - 2024-10-08 14:26:58 --> Language Class Initialized
INFO - 2024-10-08 14:26:58 --> Language Class Initialized
INFO - 2024-10-08 14:26:58 --> Config Class Initialized
INFO - 2024-10-08 14:26:58 --> Loader Class Initialized
INFO - 2024-10-08 14:26:58 --> Helper loaded: url_helper
INFO - 2024-10-08 14:26:58 --> Helper loaded: file_helper
INFO - 2024-10-08 14:26:58 --> Helper loaded: form_helper
INFO - 2024-10-08 14:26:58 --> Helper loaded: my_helper
INFO - 2024-10-08 14:26:58 --> Database Driver Class Initialized
INFO - 2024-10-08 14:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:26:58 --> Controller Class Initialized
INFO - 2024-10-08 14:26:58 --> Final output sent to browser
DEBUG - 2024-10-08 14:26:58 --> Total execution time: 0.0747
INFO - 2024-10-08 14:27:01 --> Config Class Initialized
INFO - 2024-10-08 14:27:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:27:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:27:01 --> Utf8 Class Initialized
INFO - 2024-10-08 14:27:01 --> URI Class Initialized
INFO - 2024-10-08 14:27:01 --> Router Class Initialized
INFO - 2024-10-08 14:27:01 --> Output Class Initialized
INFO - 2024-10-08 14:27:01 --> Security Class Initialized
DEBUG - 2024-10-08 14:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:27:01 --> Input Class Initialized
INFO - 2024-10-08 14:27:01 --> Language Class Initialized
INFO - 2024-10-08 14:27:01 --> Language Class Initialized
INFO - 2024-10-08 14:27:01 --> Config Class Initialized
INFO - 2024-10-08 14:27:01 --> Loader Class Initialized
INFO - 2024-10-08 14:27:01 --> Helper loaded: url_helper
INFO - 2024-10-08 14:27:01 --> Helper loaded: file_helper
INFO - 2024-10-08 14:27:01 --> Helper loaded: form_helper
INFO - 2024-10-08 14:27:01 --> Helper loaded: my_helper
INFO - 2024-10-08 14:27:01 --> Database Driver Class Initialized
INFO - 2024-10-08 14:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:27:01 --> Controller Class Initialized
INFO - 2024-10-08 14:27:01 --> Final output sent to browser
DEBUG - 2024-10-08 14:27:01 --> Total execution time: 0.1057
INFO - 2024-10-08 14:27:05 --> Config Class Initialized
INFO - 2024-10-08 14:27:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:27:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:27:05 --> Utf8 Class Initialized
INFO - 2024-10-08 14:27:05 --> URI Class Initialized
INFO - 2024-10-08 14:27:05 --> Router Class Initialized
INFO - 2024-10-08 14:27:05 --> Output Class Initialized
INFO - 2024-10-08 14:27:05 --> Security Class Initialized
DEBUG - 2024-10-08 14:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:27:05 --> Input Class Initialized
INFO - 2024-10-08 14:27:05 --> Language Class Initialized
INFO - 2024-10-08 14:27:05 --> Language Class Initialized
INFO - 2024-10-08 14:27:05 --> Config Class Initialized
INFO - 2024-10-08 14:27:05 --> Loader Class Initialized
INFO - 2024-10-08 14:27:05 --> Helper loaded: url_helper
INFO - 2024-10-08 14:27:05 --> Helper loaded: file_helper
INFO - 2024-10-08 14:27:05 --> Helper loaded: form_helper
INFO - 2024-10-08 14:27:05 --> Helper loaded: my_helper
INFO - 2024-10-08 14:27:05 --> Database Driver Class Initialized
INFO - 2024-10-08 14:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:27:05 --> Controller Class Initialized
DEBUG - 2024-10-08 14:27:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 14:27:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:27:05 --> Final output sent to browser
DEBUG - 2024-10-08 14:27:05 --> Total execution time: 0.0396
INFO - 2024-10-08 14:27:08 --> Config Class Initialized
INFO - 2024-10-08 14:27:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:27:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:27:08 --> Utf8 Class Initialized
INFO - 2024-10-08 14:27:08 --> URI Class Initialized
INFO - 2024-10-08 14:27:08 --> Router Class Initialized
INFO - 2024-10-08 14:27:08 --> Output Class Initialized
INFO - 2024-10-08 14:27:08 --> Security Class Initialized
DEBUG - 2024-10-08 14:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:27:08 --> Input Class Initialized
INFO - 2024-10-08 14:27:08 --> Language Class Initialized
INFO - 2024-10-08 14:27:08 --> Language Class Initialized
INFO - 2024-10-08 14:27:08 --> Config Class Initialized
INFO - 2024-10-08 14:27:08 --> Loader Class Initialized
INFO - 2024-10-08 14:27:08 --> Helper loaded: url_helper
INFO - 2024-10-08 14:27:08 --> Helper loaded: file_helper
INFO - 2024-10-08 14:27:08 --> Helper loaded: form_helper
INFO - 2024-10-08 14:27:08 --> Helper loaded: my_helper
INFO - 2024-10-08 14:27:08 --> Database Driver Class Initialized
INFO - 2024-10-08 14:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:27:08 --> Controller Class Initialized
DEBUG - 2024-10-08 14:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 14:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:27:08 --> Final output sent to browser
DEBUG - 2024-10-08 14:27:08 --> Total execution time: 0.0782
INFO - 2024-10-08 14:27:10 --> Config Class Initialized
INFO - 2024-10-08 14:27:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:27:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:27:10 --> Utf8 Class Initialized
INFO - 2024-10-08 14:27:10 --> URI Class Initialized
INFO - 2024-10-08 14:27:10 --> Router Class Initialized
INFO - 2024-10-08 14:27:10 --> Output Class Initialized
INFO - 2024-10-08 14:27:10 --> Security Class Initialized
DEBUG - 2024-10-08 14:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:27:10 --> Input Class Initialized
INFO - 2024-10-08 14:27:10 --> Language Class Initialized
INFO - 2024-10-08 14:27:10 --> Language Class Initialized
INFO - 2024-10-08 14:27:10 --> Config Class Initialized
INFO - 2024-10-08 14:27:10 --> Loader Class Initialized
INFO - 2024-10-08 14:27:10 --> Helper loaded: url_helper
INFO - 2024-10-08 14:27:10 --> Helper loaded: file_helper
INFO - 2024-10-08 14:27:10 --> Helper loaded: form_helper
INFO - 2024-10-08 14:27:10 --> Helper loaded: my_helper
INFO - 2024-10-08 14:27:10 --> Database Driver Class Initialized
INFO - 2024-10-08 14:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:27:10 --> Controller Class Initialized
INFO - 2024-10-08 14:27:10 --> Final output sent to browser
DEBUG - 2024-10-08 14:27:10 --> Total execution time: 0.0388
INFO - 2024-10-08 14:30:35 --> Config Class Initialized
INFO - 2024-10-08 14:30:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:35 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:35 --> URI Class Initialized
INFO - 2024-10-08 14:30:35 --> Router Class Initialized
INFO - 2024-10-08 14:30:35 --> Output Class Initialized
INFO - 2024-10-08 14:30:35 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:35 --> Input Class Initialized
INFO - 2024-10-08 14:30:35 --> Language Class Initialized
INFO - 2024-10-08 14:30:35 --> Language Class Initialized
INFO - 2024-10-08 14:30:35 --> Config Class Initialized
INFO - 2024-10-08 14:30:35 --> Loader Class Initialized
INFO - 2024-10-08 14:30:35 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:35 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:35 --> Controller Class Initialized
INFO - 2024-10-08 14:30:35 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:35 --> Total execution time: 0.0337
INFO - 2024-10-08 14:30:35 --> Config Class Initialized
INFO - 2024-10-08 14:30:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:35 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:35 --> URI Class Initialized
INFO - 2024-10-08 14:30:35 --> Router Class Initialized
INFO - 2024-10-08 14:30:35 --> Output Class Initialized
INFO - 2024-10-08 14:30:35 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:35 --> Input Class Initialized
INFO - 2024-10-08 14:30:35 --> Language Class Initialized
INFO - 2024-10-08 14:30:35 --> Language Class Initialized
INFO - 2024-10-08 14:30:35 --> Config Class Initialized
INFO - 2024-10-08 14:30:35 --> Loader Class Initialized
INFO - 2024-10-08 14:30:35 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:35 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:35 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:35 --> Controller Class Initialized
INFO - 2024-10-08 14:30:35 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:35 --> Total execution time: 0.0302
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:36 --> URI Class Initialized
INFO - 2024-10-08 14:30:36 --> Router Class Initialized
INFO - 2024-10-08 14:30:36 --> Output Class Initialized
INFO - 2024-10-08 14:30:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:36 --> Input Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Loader Class Initialized
INFO - 2024-10-08 14:30:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:36 --> Controller Class Initialized
INFO - 2024-10-08 14:30:36 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:36 --> Total execution time: 0.0730
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:36 --> URI Class Initialized
INFO - 2024-10-08 14:30:36 --> Router Class Initialized
INFO - 2024-10-08 14:30:36 --> Output Class Initialized
INFO - 2024-10-08 14:30:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:36 --> Input Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Loader Class Initialized
INFO - 2024-10-08 14:30:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:36 --> Controller Class Initialized
INFO - 2024-10-08 14:30:36 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:36 --> Total execution time: 0.0355
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:36 --> URI Class Initialized
INFO - 2024-10-08 14:30:36 --> Router Class Initialized
INFO - 2024-10-08 14:30:36 --> Output Class Initialized
INFO - 2024-10-08 14:30:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:36 --> Input Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Language Class Initialized
INFO - 2024-10-08 14:30:36 --> Config Class Initialized
INFO - 2024-10-08 14:30:36 --> Loader Class Initialized
INFO - 2024-10-08 14:30:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:36 --> Controller Class Initialized
INFO - 2024-10-08 14:30:36 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:36 --> Total execution time: 0.0679
INFO - 2024-10-08 14:30:37 --> Config Class Initialized
INFO - 2024-10-08 14:30:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:37 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:37 --> URI Class Initialized
INFO - 2024-10-08 14:30:37 --> Router Class Initialized
INFO - 2024-10-08 14:30:37 --> Output Class Initialized
INFO - 2024-10-08 14:30:37 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:37 --> Input Class Initialized
INFO - 2024-10-08 14:30:37 --> Language Class Initialized
INFO - 2024-10-08 14:30:37 --> Language Class Initialized
INFO - 2024-10-08 14:30:37 --> Config Class Initialized
INFO - 2024-10-08 14:30:37 --> Loader Class Initialized
INFO - 2024-10-08 14:30:37 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:37 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:37 --> Controller Class Initialized
INFO - 2024-10-08 14:30:37 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:37 --> Total execution time: 0.0521
INFO - 2024-10-08 14:30:37 --> Config Class Initialized
INFO - 2024-10-08 14:30:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:30:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:30:37 --> Utf8 Class Initialized
INFO - 2024-10-08 14:30:37 --> URI Class Initialized
INFO - 2024-10-08 14:30:37 --> Router Class Initialized
INFO - 2024-10-08 14:30:37 --> Output Class Initialized
INFO - 2024-10-08 14:30:37 --> Security Class Initialized
DEBUG - 2024-10-08 14:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:30:37 --> Input Class Initialized
INFO - 2024-10-08 14:30:37 --> Language Class Initialized
INFO - 2024-10-08 14:30:37 --> Language Class Initialized
INFO - 2024-10-08 14:30:37 --> Config Class Initialized
INFO - 2024-10-08 14:30:37 --> Loader Class Initialized
INFO - 2024-10-08 14:30:37 --> Helper loaded: url_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: file_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: form_helper
INFO - 2024-10-08 14:30:37 --> Helper loaded: my_helper
INFO - 2024-10-08 14:30:37 --> Database Driver Class Initialized
INFO - 2024-10-08 14:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:30:37 --> Controller Class Initialized
INFO - 2024-10-08 14:30:37 --> Final output sent to browser
DEBUG - 2024-10-08 14:30:37 --> Total execution time: 0.0608
INFO - 2024-10-08 14:31:01 --> Config Class Initialized
INFO - 2024-10-08 14:31:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:31:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:31:01 --> Utf8 Class Initialized
INFO - 2024-10-08 14:31:01 --> URI Class Initialized
INFO - 2024-10-08 14:31:01 --> Router Class Initialized
INFO - 2024-10-08 14:31:01 --> Output Class Initialized
INFO - 2024-10-08 14:31:01 --> Security Class Initialized
DEBUG - 2024-10-08 14:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:31:01 --> Input Class Initialized
INFO - 2024-10-08 14:31:01 --> Language Class Initialized
INFO - 2024-10-08 14:31:01 --> Language Class Initialized
INFO - 2024-10-08 14:31:01 --> Config Class Initialized
INFO - 2024-10-08 14:31:01 --> Loader Class Initialized
INFO - 2024-10-08 14:31:01 --> Helper loaded: url_helper
INFO - 2024-10-08 14:31:01 --> Helper loaded: file_helper
INFO - 2024-10-08 14:31:01 --> Helper loaded: form_helper
INFO - 2024-10-08 14:31:01 --> Helper loaded: my_helper
INFO - 2024-10-08 14:31:01 --> Database Driver Class Initialized
INFO - 2024-10-08 14:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:31:01 --> Controller Class Initialized
INFO - 2024-10-08 14:32:12 --> Config Class Initialized
INFO - 2024-10-08 14:32:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:32:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:32:12 --> Utf8 Class Initialized
INFO - 2024-10-08 14:32:12 --> URI Class Initialized
INFO - 2024-10-08 14:32:12 --> Router Class Initialized
INFO - 2024-10-08 14:32:12 --> Output Class Initialized
INFO - 2024-10-08 14:32:12 --> Security Class Initialized
DEBUG - 2024-10-08 14:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:32:12 --> Input Class Initialized
INFO - 2024-10-08 14:32:12 --> Language Class Initialized
ERROR - 2024-10-08 14:32:12 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:35:11 --> Config Class Initialized
INFO - 2024-10-08 14:35:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:35:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:35:11 --> Utf8 Class Initialized
INFO - 2024-10-08 14:35:11 --> URI Class Initialized
INFO - 2024-10-08 14:35:11 --> Router Class Initialized
INFO - 2024-10-08 14:35:11 --> Output Class Initialized
INFO - 2024-10-08 14:35:11 --> Security Class Initialized
DEBUG - 2024-10-08 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:35:11 --> Input Class Initialized
INFO - 2024-10-08 14:35:11 --> Language Class Initialized
INFO - 2024-10-08 14:35:11 --> Language Class Initialized
INFO - 2024-10-08 14:35:11 --> Config Class Initialized
INFO - 2024-10-08 14:35:11 --> Loader Class Initialized
INFO - 2024-10-08 14:35:11 --> Helper loaded: url_helper
INFO - 2024-10-08 14:35:11 --> Helper loaded: file_helper
INFO - 2024-10-08 14:35:11 --> Helper loaded: form_helper
INFO - 2024-10-08 14:35:11 --> Helper loaded: my_helper
INFO - 2024-10-08 14:35:11 --> Database Driver Class Initialized
INFO - 2024-10-08 14:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:35:11 --> Controller Class Initialized
INFO - 2024-10-08 14:35:11 --> Final output sent to browser
DEBUG - 2024-10-08 14:35:11 --> Total execution time: 0.0333
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:43:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:43:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:43:36 --> URI Class Initialized
INFO - 2024-10-08 14:43:36 --> Router Class Initialized
INFO - 2024-10-08 14:43:36 --> Output Class Initialized
INFO - 2024-10-08 14:43:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:43:36 --> Input Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Loader Class Initialized
INFO - 2024-10-08 14:43:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:43:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:43:36 --> Controller Class Initialized
INFO - 2024-10-08 14:43:36 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:43:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:43:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:43:36 --> URI Class Initialized
INFO - 2024-10-08 14:43:36 --> Router Class Initialized
INFO - 2024-10-08 14:43:36 --> Output Class Initialized
INFO - 2024-10-08 14:43:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:43:36 --> Input Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Loader Class Initialized
INFO - 2024-10-08 14:43:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:43:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:43:36 --> Controller Class Initialized
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:43:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:43:36 --> Utf8 Class Initialized
INFO - 2024-10-08 14:43:36 --> URI Class Initialized
INFO - 2024-10-08 14:43:36 --> Router Class Initialized
INFO - 2024-10-08 14:43:36 --> Output Class Initialized
INFO - 2024-10-08 14:43:36 --> Security Class Initialized
DEBUG - 2024-10-08 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:43:36 --> Input Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Language Class Initialized
INFO - 2024-10-08 14:43:36 --> Config Class Initialized
INFO - 2024-10-08 14:43:36 --> Loader Class Initialized
INFO - 2024-10-08 14:43:36 --> Helper loaded: url_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: file_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: form_helper
INFO - 2024-10-08 14:43:36 --> Helper loaded: my_helper
INFO - 2024-10-08 14:43:36 --> Database Driver Class Initialized
INFO - 2024-10-08 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:43:36 --> Controller Class Initialized
DEBUG - 2024-10-08 14:43:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:43:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:43:36 --> Final output sent to browser
DEBUG - 2024-10-08 14:43:36 --> Total execution time: 0.0277
INFO - 2024-10-08 14:59:34 --> Config Class Initialized
INFO - 2024-10-08 14:59:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:34 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:34 --> URI Class Initialized
DEBUG - 2024-10-08 14:59:34 --> No URI present. Default controller set.
INFO - 2024-10-08 14:59:34 --> Router Class Initialized
INFO - 2024-10-08 14:59:34 --> Output Class Initialized
INFO - 2024-10-08 14:59:34 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:34 --> Input Class Initialized
INFO - 2024-10-08 14:59:34 --> Language Class Initialized
INFO - 2024-10-08 14:59:34 --> Language Class Initialized
INFO - 2024-10-08 14:59:34 --> Config Class Initialized
INFO - 2024-10-08 14:59:34 --> Loader Class Initialized
INFO - 2024-10-08 14:59:34 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:34 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:34 --> Controller Class Initialized
INFO - 2024-10-08 14:59:34 --> Config Class Initialized
INFO - 2024-10-08 14:59:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:34 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:34 --> URI Class Initialized
INFO - 2024-10-08 14:59:34 --> Router Class Initialized
INFO - 2024-10-08 14:59:34 --> Output Class Initialized
INFO - 2024-10-08 14:59:34 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:34 --> Input Class Initialized
INFO - 2024-10-08 14:59:34 --> Language Class Initialized
INFO - 2024-10-08 14:59:34 --> Language Class Initialized
INFO - 2024-10-08 14:59:34 --> Config Class Initialized
INFO - 2024-10-08 14:59:34 --> Loader Class Initialized
INFO - 2024-10-08 14:59:34 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:34 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:34 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:34 --> Controller Class Initialized
DEBUG - 2024-10-08 14:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:59:34 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:34 --> Total execution time: 0.0686
INFO - 2024-10-08 14:59:39 --> Config Class Initialized
INFO - 2024-10-08 14:59:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:39 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:39 --> URI Class Initialized
INFO - 2024-10-08 14:59:39 --> Router Class Initialized
INFO - 2024-10-08 14:59:39 --> Output Class Initialized
INFO - 2024-10-08 14:59:39 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:39 --> Input Class Initialized
INFO - 2024-10-08 14:59:39 --> Language Class Initialized
INFO - 2024-10-08 14:59:39 --> Language Class Initialized
INFO - 2024-10-08 14:59:39 --> Config Class Initialized
INFO - 2024-10-08 14:59:39 --> Loader Class Initialized
INFO - 2024-10-08 14:59:39 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:39 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:39 --> Controller Class Initialized
INFO - 2024-10-08 14:59:39 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:59:39 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:39 --> Total execution time: 0.0754
INFO - 2024-10-08 14:59:39 --> Config Class Initialized
INFO - 2024-10-08 14:59:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:39 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:39 --> URI Class Initialized
INFO - 2024-10-08 14:59:39 --> Router Class Initialized
INFO - 2024-10-08 14:59:39 --> Output Class Initialized
INFO - 2024-10-08 14:59:39 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:39 --> Input Class Initialized
INFO - 2024-10-08 14:59:39 --> Language Class Initialized
INFO - 2024-10-08 14:59:39 --> Language Class Initialized
INFO - 2024-10-08 14:59:39 --> Config Class Initialized
INFO - 2024-10-08 14:59:39 --> Loader Class Initialized
INFO - 2024-10-08 14:59:39 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:39 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:39 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:39 --> Controller Class Initialized
DEBUG - 2024-10-08 14:59:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 14:59:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:59:39 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:39 --> Total execution time: 0.0618
INFO - 2024-10-08 14:59:47 --> Config Class Initialized
INFO - 2024-10-08 14:59:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:47 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:47 --> URI Class Initialized
INFO - 2024-10-08 14:59:47 --> Router Class Initialized
INFO - 2024-10-08 14:59:47 --> Output Class Initialized
INFO - 2024-10-08 14:59:47 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:47 --> Input Class Initialized
INFO - 2024-10-08 14:59:47 --> Language Class Initialized
INFO - 2024-10-08 14:59:47 --> Language Class Initialized
INFO - 2024-10-08 14:59:47 --> Config Class Initialized
INFO - 2024-10-08 14:59:47 --> Loader Class Initialized
INFO - 2024-10-08 14:59:47 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:47 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:47 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:47 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:47 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:47 --> Controller Class Initialized
DEBUG - 2024-10-08 14:59:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 14:59:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:59:47 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:47 --> Total execution time: 0.0384
INFO - 2024-10-08 14:59:51 --> Config Class Initialized
INFO - 2024-10-08 14:59:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:51 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:51 --> URI Class Initialized
INFO - 2024-10-08 14:59:51 --> Router Class Initialized
INFO - 2024-10-08 14:59:51 --> Output Class Initialized
INFO - 2024-10-08 14:59:51 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:51 --> Input Class Initialized
INFO - 2024-10-08 14:59:51 --> Language Class Initialized
INFO - 2024-10-08 14:59:51 --> Language Class Initialized
INFO - 2024-10-08 14:59:51 --> Config Class Initialized
INFO - 2024-10-08 14:59:51 --> Loader Class Initialized
INFO - 2024-10-08 14:59:51 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:51 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:51 --> Controller Class Initialized
INFO - 2024-10-08 14:59:51 --> Helper loaded: cookie_helper
INFO - 2024-10-08 14:59:51 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:51 --> Total execution time: 0.0359
INFO - 2024-10-08 14:59:51 --> Config Class Initialized
INFO - 2024-10-08 14:59:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:51 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:51 --> URI Class Initialized
INFO - 2024-10-08 14:59:51 --> Router Class Initialized
INFO - 2024-10-08 14:59:51 --> Output Class Initialized
INFO - 2024-10-08 14:59:51 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:51 --> Input Class Initialized
INFO - 2024-10-08 14:59:51 --> Language Class Initialized
INFO - 2024-10-08 14:59:51 --> Language Class Initialized
INFO - 2024-10-08 14:59:51 --> Config Class Initialized
INFO - 2024-10-08 14:59:51 --> Loader Class Initialized
INFO - 2024-10-08 14:59:51 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:51 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:51 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:51 --> Controller Class Initialized
DEBUG - 2024-10-08 14:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 14:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:59:51 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:51 --> Total execution time: 0.0332
INFO - 2024-10-08 14:59:54 --> Config Class Initialized
INFO - 2024-10-08 14:59:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:54 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:54 --> URI Class Initialized
INFO - 2024-10-08 14:59:54 --> Router Class Initialized
INFO - 2024-10-08 14:59:54 --> Output Class Initialized
INFO - 2024-10-08 14:59:54 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:54 --> Input Class Initialized
INFO - 2024-10-08 14:59:54 --> Language Class Initialized
INFO - 2024-10-08 14:59:54 --> Language Class Initialized
INFO - 2024-10-08 14:59:54 --> Config Class Initialized
INFO - 2024-10-08 14:59:54 --> Loader Class Initialized
INFO - 2024-10-08 14:59:54 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:54 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:54 --> Controller Class Initialized
DEBUG - 2024-10-08 14:59:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-10-08 14:59:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 14:59:54 --> Final output sent to browser
DEBUG - 2024-10-08 14:59:54 --> Total execution time: 0.0425
INFO - 2024-10-08 14:59:54 --> Config Class Initialized
INFO - 2024-10-08 14:59:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:54 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:54 --> URI Class Initialized
INFO - 2024-10-08 14:59:54 --> Router Class Initialized
INFO - 2024-10-08 14:59:54 --> Output Class Initialized
INFO - 2024-10-08 14:59:54 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:54 --> Input Class Initialized
INFO - 2024-10-08 14:59:54 --> Language Class Initialized
ERROR - 2024-10-08 14:59:54 --> 404 Page Not Found: /index
INFO - 2024-10-08 14:59:54 --> Config Class Initialized
INFO - 2024-10-08 14:59:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 14:59:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 14:59:54 --> Utf8 Class Initialized
INFO - 2024-10-08 14:59:54 --> URI Class Initialized
INFO - 2024-10-08 14:59:54 --> Router Class Initialized
INFO - 2024-10-08 14:59:54 --> Output Class Initialized
INFO - 2024-10-08 14:59:54 --> Security Class Initialized
DEBUG - 2024-10-08 14:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 14:59:54 --> Input Class Initialized
INFO - 2024-10-08 14:59:54 --> Language Class Initialized
INFO - 2024-10-08 14:59:54 --> Language Class Initialized
INFO - 2024-10-08 14:59:54 --> Config Class Initialized
INFO - 2024-10-08 14:59:54 --> Loader Class Initialized
INFO - 2024-10-08 14:59:54 --> Helper loaded: url_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: file_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: form_helper
INFO - 2024-10-08 14:59:54 --> Helper loaded: my_helper
INFO - 2024-10-08 14:59:54 --> Database Driver Class Initialized
INFO - 2024-10-08 14:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 14:59:54 --> Controller Class Initialized
INFO - 2024-10-08 15:00:15 --> Config Class Initialized
INFO - 2024-10-08 15:00:15 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:15 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:15 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:15 --> URI Class Initialized
INFO - 2024-10-08 15:00:15 --> Router Class Initialized
INFO - 2024-10-08 15:00:15 --> Output Class Initialized
INFO - 2024-10-08 15:00:15 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:15 --> Input Class Initialized
INFO - 2024-10-08 15:00:15 --> Language Class Initialized
INFO - 2024-10-08 15:00:15 --> Language Class Initialized
INFO - 2024-10-08 15:00:15 --> Config Class Initialized
INFO - 2024-10-08 15:00:15 --> Loader Class Initialized
INFO - 2024-10-08 15:00:15 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:15 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:15 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:15 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:15 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:15 --> Controller Class Initialized
DEBUG - 2024-10-08 15:00:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:00:21 --> Final output sent to browser
DEBUG - 2024-10-08 15:00:21 --> Total execution time: 6.2294
INFO - 2024-10-08 15:00:33 --> Config Class Initialized
INFO - 2024-10-08 15:00:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:33 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:33 --> URI Class Initialized
INFO - 2024-10-08 15:00:33 --> Router Class Initialized
INFO - 2024-10-08 15:00:33 --> Output Class Initialized
INFO - 2024-10-08 15:00:33 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:33 --> Input Class Initialized
INFO - 2024-10-08 15:00:33 --> Language Class Initialized
INFO - 2024-10-08 15:00:33 --> Language Class Initialized
INFO - 2024-10-08 15:00:33 --> Config Class Initialized
INFO - 2024-10-08 15:00:33 --> Loader Class Initialized
INFO - 2024-10-08 15:00:33 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:33 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:33 --> Controller Class Initialized
DEBUG - 2024-10-08 15:00:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-08 15:00:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:00:33 --> Final output sent to browser
DEBUG - 2024-10-08 15:00:33 --> Total execution time: 0.0354
INFO - 2024-10-08 15:00:33 --> Config Class Initialized
INFO - 2024-10-08 15:00:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:33 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:33 --> URI Class Initialized
INFO - 2024-10-08 15:00:33 --> Router Class Initialized
INFO - 2024-10-08 15:00:33 --> Output Class Initialized
INFO - 2024-10-08 15:00:33 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:33 --> Input Class Initialized
INFO - 2024-10-08 15:00:33 --> Language Class Initialized
ERROR - 2024-10-08 15:00:33 --> 404 Page Not Found: /index
INFO - 2024-10-08 15:00:33 --> Config Class Initialized
INFO - 2024-10-08 15:00:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:33 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:33 --> URI Class Initialized
INFO - 2024-10-08 15:00:33 --> Router Class Initialized
INFO - 2024-10-08 15:00:33 --> Output Class Initialized
INFO - 2024-10-08 15:00:33 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:33 --> Input Class Initialized
INFO - 2024-10-08 15:00:33 --> Language Class Initialized
INFO - 2024-10-08 15:00:33 --> Language Class Initialized
INFO - 2024-10-08 15:00:33 --> Config Class Initialized
INFO - 2024-10-08 15:00:33 --> Loader Class Initialized
INFO - 2024-10-08 15:00:33 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:33 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:33 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:33 --> Controller Class Initialized
INFO - 2024-10-08 15:00:34 --> Config Class Initialized
INFO - 2024-10-08 15:00:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:34 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:34 --> URI Class Initialized
INFO - 2024-10-08 15:00:34 --> Router Class Initialized
INFO - 2024-10-08 15:00:34 --> Output Class Initialized
INFO - 2024-10-08 15:00:34 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:34 --> Input Class Initialized
INFO - 2024-10-08 15:00:34 --> Language Class Initialized
INFO - 2024-10-08 15:00:34 --> Language Class Initialized
INFO - 2024-10-08 15:00:34 --> Config Class Initialized
INFO - 2024-10-08 15:00:34 --> Loader Class Initialized
INFO - 2024-10-08 15:00:34 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:34 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:34 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:34 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:35 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:35 --> Controller Class Initialized
INFO - 2024-10-08 15:00:35 --> Config Class Initialized
INFO - 2024-10-08 15:00:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:35 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:35 --> URI Class Initialized
INFO - 2024-10-08 15:00:35 --> Router Class Initialized
INFO - 2024-10-08 15:00:35 --> Output Class Initialized
INFO - 2024-10-08 15:00:35 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:35 --> Input Class Initialized
INFO - 2024-10-08 15:00:35 --> Language Class Initialized
INFO - 2024-10-08 15:00:35 --> Language Class Initialized
INFO - 2024-10-08 15:00:35 --> Config Class Initialized
INFO - 2024-10-08 15:00:35 --> Loader Class Initialized
INFO - 2024-10-08 15:00:35 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:35 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:35 --> Controller Class Initialized
INFO - 2024-10-08 15:00:35 --> Config Class Initialized
INFO - 2024-10-08 15:00:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:35 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:35 --> URI Class Initialized
INFO - 2024-10-08 15:00:35 --> Router Class Initialized
INFO - 2024-10-08 15:00:35 --> Output Class Initialized
INFO - 2024-10-08 15:00:35 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:35 --> Input Class Initialized
INFO - 2024-10-08 15:00:35 --> Language Class Initialized
INFO - 2024-10-08 15:00:35 --> Language Class Initialized
INFO - 2024-10-08 15:00:35 --> Config Class Initialized
INFO - 2024-10-08 15:00:35 --> Loader Class Initialized
INFO - 2024-10-08 15:00:35 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:35 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:36 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:36 --> Controller Class Initialized
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:45 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:45 --> URI Class Initialized
INFO - 2024-10-08 15:00:45 --> Router Class Initialized
INFO - 2024-10-08 15:00:45 --> Output Class Initialized
INFO - 2024-10-08 15:00:45 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:45 --> Input Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Loader Class Initialized
INFO - 2024-10-08 15:00:45 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:45 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:45 --> Controller Class Initialized
INFO - 2024-10-08 15:00:45 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:45 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:45 --> URI Class Initialized
INFO - 2024-10-08 15:00:45 --> Router Class Initialized
INFO - 2024-10-08 15:00:45 --> Output Class Initialized
INFO - 2024-10-08 15:00:45 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:45 --> Input Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Loader Class Initialized
INFO - 2024-10-08 15:00:45 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:45 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:45 --> Controller Class Initialized
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:45 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:45 --> URI Class Initialized
INFO - 2024-10-08 15:00:45 --> Router Class Initialized
INFO - 2024-10-08 15:00:45 --> Output Class Initialized
INFO - 2024-10-08 15:00:45 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:45 --> Input Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Language Class Initialized
INFO - 2024-10-08 15:00:45 --> Config Class Initialized
INFO - 2024-10-08 15:00:45 --> Loader Class Initialized
INFO - 2024-10-08 15:00:45 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:45 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:45 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:45 --> Controller Class Initialized
DEBUG - 2024-10-08 15:00:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 15:00:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:00:45 --> Final output sent to browser
DEBUG - 2024-10-08 15:00:45 --> Total execution time: 0.0759
INFO - 2024-10-08 15:00:48 --> Config Class Initialized
INFO - 2024-10-08 15:00:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:48 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:48 --> URI Class Initialized
INFO - 2024-10-08 15:00:48 --> Router Class Initialized
INFO - 2024-10-08 15:00:48 --> Output Class Initialized
INFO - 2024-10-08 15:00:48 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:48 --> Input Class Initialized
INFO - 2024-10-08 15:00:48 --> Language Class Initialized
INFO - 2024-10-08 15:00:48 --> Language Class Initialized
INFO - 2024-10-08 15:00:48 --> Config Class Initialized
INFO - 2024-10-08 15:00:48 --> Loader Class Initialized
INFO - 2024-10-08 15:00:48 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:48 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:48 --> Controller Class Initialized
INFO - 2024-10-08 15:00:48 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:00:48 --> Final output sent to browser
DEBUG - 2024-10-08 15:00:48 --> Total execution time: 0.0663
INFO - 2024-10-08 15:00:48 --> Config Class Initialized
INFO - 2024-10-08 15:00:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:00:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:00:48 --> Utf8 Class Initialized
INFO - 2024-10-08 15:00:48 --> URI Class Initialized
INFO - 2024-10-08 15:00:48 --> Router Class Initialized
INFO - 2024-10-08 15:00:48 --> Output Class Initialized
INFO - 2024-10-08 15:00:48 --> Security Class Initialized
DEBUG - 2024-10-08 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:00:48 --> Input Class Initialized
INFO - 2024-10-08 15:00:48 --> Language Class Initialized
INFO - 2024-10-08 15:00:48 --> Language Class Initialized
INFO - 2024-10-08 15:00:48 --> Config Class Initialized
INFO - 2024-10-08 15:00:48 --> Loader Class Initialized
INFO - 2024-10-08 15:00:48 --> Helper loaded: url_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: file_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: form_helper
INFO - 2024-10-08 15:00:48 --> Helper loaded: my_helper
INFO - 2024-10-08 15:00:48 --> Database Driver Class Initialized
INFO - 2024-10-08 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:00:48 --> Controller Class Initialized
DEBUG - 2024-10-08 15:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 15:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:00:48 --> Final output sent to browser
DEBUG - 2024-10-08 15:00:48 --> Total execution time: 0.0777
INFO - 2024-10-08 15:01:12 --> Config Class Initialized
INFO - 2024-10-08 15:01:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:01:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:01:12 --> Utf8 Class Initialized
INFO - 2024-10-08 15:01:12 --> URI Class Initialized
INFO - 2024-10-08 15:01:12 --> Router Class Initialized
INFO - 2024-10-08 15:01:12 --> Output Class Initialized
INFO - 2024-10-08 15:01:12 --> Security Class Initialized
DEBUG - 2024-10-08 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:01:12 --> Input Class Initialized
INFO - 2024-10-08 15:01:12 --> Language Class Initialized
INFO - 2024-10-08 15:01:12 --> Language Class Initialized
INFO - 2024-10-08 15:01:12 --> Config Class Initialized
INFO - 2024-10-08 15:01:12 --> Loader Class Initialized
INFO - 2024-10-08 15:01:12 --> Helper loaded: url_helper
INFO - 2024-10-08 15:01:12 --> Helper loaded: file_helper
INFO - 2024-10-08 15:01:12 --> Helper loaded: form_helper
INFO - 2024-10-08 15:01:12 --> Helper loaded: my_helper
INFO - 2024-10-08 15:01:12 --> Database Driver Class Initialized
INFO - 2024-10-08 15:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:01:12 --> Controller Class Initialized
DEBUG - 2024-10-08 15:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 15:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:01:12 --> Final output sent to browser
DEBUG - 2024-10-08 15:01:12 --> Total execution time: 0.0327
INFO - 2024-10-08 15:01:19 --> Config Class Initialized
INFO - 2024-10-08 15:01:19 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:01:19 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:01:19 --> Utf8 Class Initialized
INFO - 2024-10-08 15:01:19 --> URI Class Initialized
INFO - 2024-10-08 15:01:19 --> Router Class Initialized
INFO - 2024-10-08 15:01:19 --> Output Class Initialized
INFO - 2024-10-08 15:01:19 --> Security Class Initialized
DEBUG - 2024-10-08 15:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:01:19 --> Input Class Initialized
INFO - 2024-10-08 15:01:19 --> Language Class Initialized
INFO - 2024-10-08 15:01:19 --> Language Class Initialized
INFO - 2024-10-08 15:01:19 --> Config Class Initialized
INFO - 2024-10-08 15:01:19 --> Loader Class Initialized
INFO - 2024-10-08 15:01:19 --> Helper loaded: url_helper
INFO - 2024-10-08 15:01:19 --> Helper loaded: file_helper
INFO - 2024-10-08 15:01:19 --> Helper loaded: form_helper
INFO - 2024-10-08 15:01:19 --> Helper loaded: my_helper
INFO - 2024-10-08 15:01:19 --> Database Driver Class Initialized
INFO - 2024-10-08 15:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:01:19 --> Controller Class Initialized
DEBUG - 2024-10-08 15:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 15:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:01:20 --> Final output sent to browser
DEBUG - 2024-10-08 15:01:20 --> Total execution time: 0.0332
INFO - 2024-10-08 15:01:21 --> Config Class Initialized
INFO - 2024-10-08 15:01:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:01:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:01:21 --> Utf8 Class Initialized
INFO - 2024-10-08 15:01:21 --> URI Class Initialized
INFO - 2024-10-08 15:01:21 --> Router Class Initialized
INFO - 2024-10-08 15:01:21 --> Output Class Initialized
INFO - 2024-10-08 15:01:21 --> Security Class Initialized
DEBUG - 2024-10-08 15:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:01:21 --> Input Class Initialized
INFO - 2024-10-08 15:01:21 --> Language Class Initialized
INFO - 2024-10-08 15:01:21 --> Language Class Initialized
INFO - 2024-10-08 15:01:21 --> Config Class Initialized
INFO - 2024-10-08 15:01:21 --> Loader Class Initialized
INFO - 2024-10-08 15:01:21 --> Helper loaded: url_helper
INFO - 2024-10-08 15:01:21 --> Helper loaded: file_helper
INFO - 2024-10-08 15:01:21 --> Helper loaded: form_helper
INFO - 2024-10-08 15:01:21 --> Helper loaded: my_helper
INFO - 2024-10-08 15:01:21 --> Database Driver Class Initialized
INFO - 2024-10-08 15:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:01:21 --> Controller Class Initialized
INFO - 2024-10-08 15:01:21 --> Final output sent to browser
DEBUG - 2024-10-08 15:01:21 --> Total execution time: 0.0371
INFO - 2024-10-08 15:01:33 --> Config Class Initialized
INFO - 2024-10-08 15:01:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:01:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:01:33 --> Utf8 Class Initialized
INFO - 2024-10-08 15:01:33 --> URI Class Initialized
INFO - 2024-10-08 15:01:33 --> Router Class Initialized
INFO - 2024-10-08 15:01:33 --> Output Class Initialized
INFO - 2024-10-08 15:01:33 --> Security Class Initialized
DEBUG - 2024-10-08 15:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:01:33 --> Input Class Initialized
INFO - 2024-10-08 15:01:33 --> Language Class Initialized
INFO - 2024-10-08 15:01:33 --> Language Class Initialized
INFO - 2024-10-08 15:01:33 --> Config Class Initialized
INFO - 2024-10-08 15:01:33 --> Loader Class Initialized
INFO - 2024-10-08 15:01:33 --> Helper loaded: url_helper
INFO - 2024-10-08 15:01:33 --> Helper loaded: file_helper
INFO - 2024-10-08 15:01:33 --> Helper loaded: form_helper
INFO - 2024-10-08 15:01:33 --> Helper loaded: my_helper
INFO - 2024-10-08 15:01:33 --> Database Driver Class Initialized
INFO - 2024-10-08 15:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:01:33 --> Controller Class Initialized
DEBUG - 2024-10-08 15:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 15:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:01:33 --> Final output sent to browser
DEBUG - 2024-10-08 15:01:33 --> Total execution time: 0.0340
INFO - 2024-10-08 15:01:35 --> Config Class Initialized
INFO - 2024-10-08 15:01:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:01:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:01:35 --> Utf8 Class Initialized
INFO - 2024-10-08 15:01:35 --> URI Class Initialized
INFO - 2024-10-08 15:01:35 --> Router Class Initialized
INFO - 2024-10-08 15:01:35 --> Output Class Initialized
INFO - 2024-10-08 15:01:35 --> Security Class Initialized
DEBUG - 2024-10-08 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:01:35 --> Input Class Initialized
INFO - 2024-10-08 15:01:35 --> Language Class Initialized
INFO - 2024-10-08 15:01:35 --> Language Class Initialized
INFO - 2024-10-08 15:01:35 --> Config Class Initialized
INFO - 2024-10-08 15:01:35 --> Loader Class Initialized
INFO - 2024-10-08 15:01:35 --> Helper loaded: url_helper
INFO - 2024-10-08 15:01:35 --> Helper loaded: file_helper
INFO - 2024-10-08 15:01:35 --> Helper loaded: form_helper
INFO - 2024-10-08 15:01:35 --> Helper loaded: my_helper
INFO - 2024-10-08 15:01:35 --> Database Driver Class Initialized
INFO - 2024-10-08 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:01:35 --> Controller Class Initialized
DEBUG - 2024-10-08 15:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:01:38 --> Final output sent to browser
DEBUG - 2024-10-08 15:01:38 --> Total execution time: 3.0953
INFO - 2024-10-08 15:02:22 --> Config Class Initialized
INFO - 2024-10-08 15:02:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:02:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:02:23 --> Utf8 Class Initialized
INFO - 2024-10-08 15:02:23 --> URI Class Initialized
INFO - 2024-10-08 15:02:23 --> Router Class Initialized
INFO - 2024-10-08 15:02:23 --> Output Class Initialized
INFO - 2024-10-08 15:02:23 --> Security Class Initialized
DEBUG - 2024-10-08 15:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:02:23 --> Input Class Initialized
INFO - 2024-10-08 15:02:23 --> Language Class Initialized
INFO - 2024-10-08 15:02:23 --> Language Class Initialized
INFO - 2024-10-08 15:02:23 --> Config Class Initialized
INFO - 2024-10-08 15:02:23 --> Loader Class Initialized
INFO - 2024-10-08 15:02:23 --> Helper loaded: url_helper
INFO - 2024-10-08 15:02:23 --> Helper loaded: file_helper
INFO - 2024-10-08 15:02:23 --> Helper loaded: form_helper
INFO - 2024-10-08 15:02:23 --> Helper loaded: my_helper
INFO - 2024-10-08 15:02:23 --> Database Driver Class Initialized
INFO - 2024-10-08 15:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:02:23 --> Controller Class Initialized
DEBUG - 2024-10-08 15:02:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:02:26 --> Final output sent to browser
DEBUG - 2024-10-08 15:02:26 --> Total execution time: 3.6584
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:02:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:02:54 --> Utf8 Class Initialized
INFO - 2024-10-08 15:02:54 --> URI Class Initialized
INFO - 2024-10-08 15:02:54 --> Router Class Initialized
INFO - 2024-10-08 15:02:54 --> Output Class Initialized
INFO - 2024-10-08 15:02:54 --> Security Class Initialized
DEBUG - 2024-10-08 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:02:54 --> Input Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Loader Class Initialized
INFO - 2024-10-08 15:02:54 --> Helper loaded: url_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: file_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: form_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: my_helper
INFO - 2024-10-08 15:02:54 --> Database Driver Class Initialized
INFO - 2024-10-08 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:02:54 --> Controller Class Initialized
INFO - 2024-10-08 15:02:54 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:02:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:02:54 --> Utf8 Class Initialized
INFO - 2024-10-08 15:02:54 --> URI Class Initialized
INFO - 2024-10-08 15:02:54 --> Router Class Initialized
INFO - 2024-10-08 15:02:54 --> Output Class Initialized
INFO - 2024-10-08 15:02:54 --> Security Class Initialized
DEBUG - 2024-10-08 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:02:54 --> Input Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Loader Class Initialized
INFO - 2024-10-08 15:02:54 --> Helper loaded: url_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: file_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: form_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: my_helper
INFO - 2024-10-08 15:02:54 --> Database Driver Class Initialized
INFO - 2024-10-08 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:02:54 --> Controller Class Initialized
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:02:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:02:54 --> Utf8 Class Initialized
INFO - 2024-10-08 15:02:54 --> URI Class Initialized
INFO - 2024-10-08 15:02:54 --> Router Class Initialized
INFO - 2024-10-08 15:02:54 --> Output Class Initialized
INFO - 2024-10-08 15:02:54 --> Security Class Initialized
DEBUG - 2024-10-08 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:02:54 --> Input Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Language Class Initialized
INFO - 2024-10-08 15:02:54 --> Config Class Initialized
INFO - 2024-10-08 15:02:54 --> Loader Class Initialized
INFO - 2024-10-08 15:02:54 --> Helper loaded: url_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: file_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: form_helper
INFO - 2024-10-08 15:02:54 --> Helper loaded: my_helper
INFO - 2024-10-08 15:02:54 --> Database Driver Class Initialized
INFO - 2024-10-08 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:02:54 --> Controller Class Initialized
DEBUG - 2024-10-08 15:02:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 15:02:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:02:54 --> Final output sent to browser
DEBUG - 2024-10-08 15:02:54 --> Total execution time: 0.0367
INFO - 2024-10-08 15:03:00 --> Config Class Initialized
INFO - 2024-10-08 15:03:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:00 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:00 --> URI Class Initialized
INFO - 2024-10-08 15:03:00 --> Router Class Initialized
INFO - 2024-10-08 15:03:00 --> Output Class Initialized
INFO - 2024-10-08 15:03:00 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:00 --> Input Class Initialized
INFO - 2024-10-08 15:03:00 --> Language Class Initialized
INFO - 2024-10-08 15:03:00 --> Language Class Initialized
INFO - 2024-10-08 15:03:00 --> Config Class Initialized
INFO - 2024-10-08 15:03:00 --> Loader Class Initialized
INFO - 2024-10-08 15:03:00 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:00 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:00 --> Controller Class Initialized
INFO - 2024-10-08 15:03:00 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:03:00 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:00 --> Total execution time: 0.0332
INFO - 2024-10-08 15:03:00 --> Config Class Initialized
INFO - 2024-10-08 15:03:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:00 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:00 --> URI Class Initialized
INFO - 2024-10-08 15:03:00 --> Router Class Initialized
INFO - 2024-10-08 15:03:00 --> Output Class Initialized
INFO - 2024-10-08 15:03:00 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:00 --> Input Class Initialized
INFO - 2024-10-08 15:03:00 --> Language Class Initialized
INFO - 2024-10-08 15:03:00 --> Language Class Initialized
INFO - 2024-10-08 15:03:00 --> Config Class Initialized
INFO - 2024-10-08 15:03:00 --> Loader Class Initialized
INFO - 2024-10-08 15:03:00 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:00 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:00 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:00 --> Controller Class Initialized
DEBUG - 2024-10-08 15:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 15:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:03:00 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:00 --> Total execution time: 0.0330
INFO - 2024-10-08 15:03:04 --> Config Class Initialized
INFO - 2024-10-08 15:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:04 --> URI Class Initialized
INFO - 2024-10-08 15:03:04 --> Router Class Initialized
INFO - 2024-10-08 15:03:04 --> Output Class Initialized
INFO - 2024-10-08 15:03:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:04 --> Input Class Initialized
INFO - 2024-10-08 15:03:04 --> Language Class Initialized
INFO - 2024-10-08 15:03:04 --> Language Class Initialized
INFO - 2024-10-08 15:03:04 --> Config Class Initialized
INFO - 2024-10-08 15:03:04 --> Loader Class Initialized
INFO - 2024-10-08 15:03:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:04 --> Controller Class Initialized
DEBUG - 2024-10-08 15:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 15:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:03:04 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:04 --> Total execution time: 0.0628
INFO - 2024-10-08 15:03:05 --> Config Class Initialized
INFO - 2024-10-08 15:03:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:05 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:05 --> URI Class Initialized
INFO - 2024-10-08 15:03:05 --> Router Class Initialized
INFO - 2024-10-08 15:03:05 --> Output Class Initialized
INFO - 2024-10-08 15:03:05 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:05 --> Input Class Initialized
INFO - 2024-10-08 15:03:05 --> Language Class Initialized
INFO - 2024-10-08 15:03:06 --> Language Class Initialized
INFO - 2024-10-08 15:03:06 --> Config Class Initialized
INFO - 2024-10-08 15:03:06 --> Loader Class Initialized
INFO - 2024-10-08 15:03:06 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:06 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:06 --> Controller Class Initialized
DEBUG - 2024-10-08 15:03:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 15:03:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:03:06 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:06 --> Total execution time: 0.1010
INFO - 2024-10-08 15:03:06 --> Config Class Initialized
INFO - 2024-10-08 15:03:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:06 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:06 --> URI Class Initialized
INFO - 2024-10-08 15:03:06 --> Router Class Initialized
INFO - 2024-10-08 15:03:06 --> Output Class Initialized
INFO - 2024-10-08 15:03:06 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:06 --> Input Class Initialized
INFO - 2024-10-08 15:03:06 --> Language Class Initialized
INFO - 2024-10-08 15:03:06 --> Language Class Initialized
INFO - 2024-10-08 15:03:06 --> Config Class Initialized
INFO - 2024-10-08 15:03:06 --> Loader Class Initialized
INFO - 2024-10-08 15:03:06 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:06 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:06 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:06 --> Controller Class Initialized
INFO - 2024-10-08 15:03:07 --> Config Class Initialized
INFO - 2024-10-08 15:03:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:07 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:07 --> URI Class Initialized
INFO - 2024-10-08 15:03:07 --> Router Class Initialized
INFO - 2024-10-08 15:03:07 --> Output Class Initialized
INFO - 2024-10-08 15:03:07 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:07 --> Input Class Initialized
INFO - 2024-10-08 15:03:07 --> Language Class Initialized
INFO - 2024-10-08 15:03:07 --> Language Class Initialized
INFO - 2024-10-08 15:03:07 --> Config Class Initialized
INFO - 2024-10-08 15:03:07 --> Loader Class Initialized
INFO - 2024-10-08 15:03:07 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:07 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:07 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:07 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:07 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:07 --> Controller Class Initialized
INFO - 2024-10-08 15:03:07 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:07 --> Total execution time: 0.0428
INFO - 2024-10-08 15:03:18 --> Config Class Initialized
INFO - 2024-10-08 15:03:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:18 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:18 --> URI Class Initialized
INFO - 2024-10-08 15:03:18 --> Router Class Initialized
INFO - 2024-10-08 15:03:18 --> Output Class Initialized
INFO - 2024-10-08 15:03:18 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:18 --> Input Class Initialized
INFO - 2024-10-08 15:03:18 --> Language Class Initialized
INFO - 2024-10-08 15:03:18 --> Language Class Initialized
INFO - 2024-10-08 15:03:18 --> Config Class Initialized
INFO - 2024-10-08 15:03:18 --> Loader Class Initialized
INFO - 2024-10-08 15:03:18 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:18 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:18 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:18 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:18 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:18 --> Controller Class Initialized
DEBUG - 2024-10-08 15:03:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 15:03:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:03:18 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:18 --> Total execution time: 0.0369
INFO - 2024-10-08 15:03:21 --> Config Class Initialized
INFO - 2024-10-08 15:03:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:21 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:21 --> URI Class Initialized
INFO - 2024-10-08 15:03:21 --> Router Class Initialized
INFO - 2024-10-08 15:03:21 --> Output Class Initialized
INFO - 2024-10-08 15:03:21 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:21 --> Input Class Initialized
INFO - 2024-10-08 15:03:21 --> Language Class Initialized
INFO - 2024-10-08 15:03:21 --> Language Class Initialized
INFO - 2024-10-08 15:03:21 --> Config Class Initialized
INFO - 2024-10-08 15:03:21 --> Loader Class Initialized
INFO - 2024-10-08 15:03:21 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:21 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:21 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:21 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:21 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:21 --> Controller Class Initialized
DEBUG - 2024-10-08 15:03:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 15:03:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:03:21 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:21 --> Total execution time: 0.0389
INFO - 2024-10-08 15:03:23 --> Config Class Initialized
INFO - 2024-10-08 15:03:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:03:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:03:23 --> Utf8 Class Initialized
INFO - 2024-10-08 15:03:23 --> URI Class Initialized
INFO - 2024-10-08 15:03:23 --> Router Class Initialized
INFO - 2024-10-08 15:03:23 --> Output Class Initialized
INFO - 2024-10-08 15:03:23 --> Security Class Initialized
DEBUG - 2024-10-08 15:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:03:23 --> Input Class Initialized
INFO - 2024-10-08 15:03:23 --> Language Class Initialized
INFO - 2024-10-08 15:03:23 --> Language Class Initialized
INFO - 2024-10-08 15:03:23 --> Config Class Initialized
INFO - 2024-10-08 15:03:23 --> Loader Class Initialized
INFO - 2024-10-08 15:03:23 --> Helper loaded: url_helper
INFO - 2024-10-08 15:03:23 --> Helper loaded: file_helper
INFO - 2024-10-08 15:03:23 --> Helper loaded: form_helper
INFO - 2024-10-08 15:03:23 --> Helper loaded: my_helper
INFO - 2024-10-08 15:03:23 --> Database Driver Class Initialized
INFO - 2024-10-08 15:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:03:23 --> Controller Class Initialized
INFO - 2024-10-08 15:03:23 --> Final output sent to browser
DEBUG - 2024-10-08 15:03:23 --> Total execution time: 0.0372
INFO - 2024-10-08 15:07:40 --> Config Class Initialized
INFO - 2024-10-08 15:07:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:07:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:07:40 --> Utf8 Class Initialized
INFO - 2024-10-08 15:07:40 --> URI Class Initialized
INFO - 2024-10-08 15:07:40 --> Router Class Initialized
INFO - 2024-10-08 15:07:40 --> Output Class Initialized
INFO - 2024-10-08 15:07:40 --> Security Class Initialized
DEBUG - 2024-10-08 15:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:07:40 --> Input Class Initialized
INFO - 2024-10-08 15:07:40 --> Language Class Initialized
INFO - 2024-10-08 15:07:40 --> Language Class Initialized
INFO - 2024-10-08 15:07:40 --> Config Class Initialized
INFO - 2024-10-08 15:07:40 --> Loader Class Initialized
INFO - 2024-10-08 15:07:40 --> Helper loaded: url_helper
INFO - 2024-10-08 15:07:40 --> Helper loaded: file_helper
INFO - 2024-10-08 15:07:40 --> Helper loaded: form_helper
INFO - 2024-10-08 15:07:40 --> Helper loaded: my_helper
INFO - 2024-10-08 15:07:40 --> Database Driver Class Initialized
INFO - 2024-10-08 15:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:07:40 --> Controller Class Initialized
DEBUG - 2024-10-08 15:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:07:43 --> Final output sent to browser
DEBUG - 2024-10-08 15:07:43 --> Total execution time: 3.3081
INFO - 2024-10-08 15:08:04 --> Config Class Initialized
INFO - 2024-10-08 15:08:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:08:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:08:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:08:04 --> URI Class Initialized
INFO - 2024-10-08 15:08:04 --> Router Class Initialized
INFO - 2024-10-08 15:08:04 --> Output Class Initialized
INFO - 2024-10-08 15:08:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:08:04 --> Input Class Initialized
INFO - 2024-10-08 15:08:04 --> Language Class Initialized
INFO - 2024-10-08 15:08:04 --> Language Class Initialized
INFO - 2024-10-08 15:08:04 --> Config Class Initialized
INFO - 2024-10-08 15:08:04 --> Loader Class Initialized
INFO - 2024-10-08 15:08:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:08:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:08:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:08:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:08:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:08:04 --> Controller Class Initialized
DEBUG - 2024-10-08 15:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:08:08 --> Final output sent to browser
DEBUG - 2024-10-08 15:08:08 --> Total execution time: 3.4028
INFO - 2024-10-08 15:09:04 --> Config Class Initialized
INFO - 2024-10-08 15:09:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:09:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:09:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:09:04 --> URI Class Initialized
INFO - 2024-10-08 15:09:04 --> Router Class Initialized
INFO - 2024-10-08 15:09:04 --> Output Class Initialized
INFO - 2024-10-08 15:09:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:09:04 --> Input Class Initialized
INFO - 2024-10-08 15:09:04 --> Language Class Initialized
INFO - 2024-10-08 15:09:04 --> Language Class Initialized
INFO - 2024-10-08 15:09:04 --> Config Class Initialized
INFO - 2024-10-08 15:09:04 --> Loader Class Initialized
INFO - 2024-10-08 15:09:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:09:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:09:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:09:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:09:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:09:04 --> Controller Class Initialized
DEBUG - 2024-10-08 15:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 15:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:09:04 --> Final output sent to browser
DEBUG - 2024-10-08 15:09:04 --> Total execution time: 0.3061
INFO - 2024-10-08 15:09:09 --> Config Class Initialized
INFO - 2024-10-08 15:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:09:09 --> Utf8 Class Initialized
INFO - 2024-10-08 15:09:09 --> URI Class Initialized
INFO - 2024-10-08 15:09:09 --> Router Class Initialized
INFO - 2024-10-08 15:09:09 --> Output Class Initialized
INFO - 2024-10-08 15:09:09 --> Security Class Initialized
DEBUG - 2024-10-08 15:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:09:09 --> Input Class Initialized
INFO - 2024-10-08 15:09:09 --> Language Class Initialized
INFO - 2024-10-08 15:09:09 --> Language Class Initialized
INFO - 2024-10-08 15:09:09 --> Config Class Initialized
INFO - 2024-10-08 15:09:09 --> Loader Class Initialized
INFO - 2024-10-08 15:09:09 --> Helper loaded: url_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: file_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: form_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: my_helper
INFO - 2024-10-08 15:09:09 --> Database Driver Class Initialized
INFO - 2024-10-08 15:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:09:09 --> Controller Class Initialized
DEBUG - 2024-10-08 15:09:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 15:09:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:09:09 --> Final output sent to browser
DEBUG - 2024-10-08 15:09:09 --> Total execution time: 0.0660
INFO - 2024-10-08 15:09:09 --> Config Class Initialized
INFO - 2024-10-08 15:09:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:09:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:09:09 --> Utf8 Class Initialized
INFO - 2024-10-08 15:09:09 --> URI Class Initialized
INFO - 2024-10-08 15:09:09 --> Router Class Initialized
INFO - 2024-10-08 15:09:09 --> Output Class Initialized
INFO - 2024-10-08 15:09:09 --> Security Class Initialized
DEBUG - 2024-10-08 15:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:09:09 --> Input Class Initialized
INFO - 2024-10-08 15:09:09 --> Language Class Initialized
INFO - 2024-10-08 15:09:09 --> Language Class Initialized
INFO - 2024-10-08 15:09:09 --> Config Class Initialized
INFO - 2024-10-08 15:09:09 --> Loader Class Initialized
INFO - 2024-10-08 15:09:09 --> Helper loaded: url_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: file_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: form_helper
INFO - 2024-10-08 15:09:09 --> Helper loaded: my_helper
INFO - 2024-10-08 15:09:09 --> Database Driver Class Initialized
INFO - 2024-10-08 15:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:09:09 --> Controller Class Initialized
INFO - 2024-10-08 15:09:34 --> Config Class Initialized
INFO - 2024-10-08 15:09:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:09:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:09:34 --> Utf8 Class Initialized
INFO - 2024-10-08 15:09:34 --> URI Class Initialized
INFO - 2024-10-08 15:09:34 --> Router Class Initialized
INFO - 2024-10-08 15:09:34 --> Output Class Initialized
INFO - 2024-10-08 15:09:34 --> Security Class Initialized
DEBUG - 2024-10-08 15:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:09:34 --> Input Class Initialized
INFO - 2024-10-08 15:09:34 --> Language Class Initialized
INFO - 2024-10-08 15:09:34 --> Language Class Initialized
INFO - 2024-10-08 15:09:34 --> Config Class Initialized
INFO - 2024-10-08 15:09:34 --> Loader Class Initialized
INFO - 2024-10-08 15:09:34 --> Helper loaded: url_helper
INFO - 2024-10-08 15:09:34 --> Helper loaded: file_helper
INFO - 2024-10-08 15:09:34 --> Helper loaded: form_helper
INFO - 2024-10-08 15:09:34 --> Helper loaded: my_helper
INFO - 2024-10-08 15:09:34 --> Database Driver Class Initialized
INFO - 2024-10-08 15:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:09:34 --> Controller Class Initialized
INFO - 2024-10-08 15:09:34 --> Final output sent to browser
DEBUG - 2024-10-08 15:09:34 --> Total execution time: 0.0349
INFO - 2024-10-08 15:09:35 --> Config Class Initialized
INFO - 2024-10-08 15:09:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:09:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:09:35 --> Utf8 Class Initialized
INFO - 2024-10-08 15:09:35 --> URI Class Initialized
INFO - 2024-10-08 15:09:35 --> Router Class Initialized
INFO - 2024-10-08 15:09:35 --> Output Class Initialized
INFO - 2024-10-08 15:09:35 --> Security Class Initialized
DEBUG - 2024-10-08 15:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:09:35 --> Input Class Initialized
INFO - 2024-10-08 15:09:35 --> Language Class Initialized
INFO - 2024-10-08 15:09:35 --> Language Class Initialized
INFO - 2024-10-08 15:09:35 --> Config Class Initialized
INFO - 2024-10-08 15:09:35 --> Loader Class Initialized
INFO - 2024-10-08 15:09:35 --> Helper loaded: url_helper
INFO - 2024-10-08 15:09:35 --> Helper loaded: file_helper
INFO - 2024-10-08 15:09:35 --> Helper loaded: form_helper
INFO - 2024-10-08 15:09:35 --> Helper loaded: my_helper
INFO - 2024-10-08 15:09:35 --> Database Driver Class Initialized
INFO - 2024-10-08 15:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:09:35 --> Controller Class Initialized
INFO - 2024-10-08 15:09:35 --> Final output sent to browser
DEBUG - 2024-10-08 15:09:35 --> Total execution time: 0.0561
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:13:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:13:25 --> Utf8 Class Initialized
INFO - 2024-10-08 15:13:25 --> URI Class Initialized
INFO - 2024-10-08 15:13:25 --> Router Class Initialized
INFO - 2024-10-08 15:13:25 --> Output Class Initialized
INFO - 2024-10-08 15:13:25 --> Security Class Initialized
DEBUG - 2024-10-08 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:13:25 --> Input Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Loader Class Initialized
INFO - 2024-10-08 15:13:25 --> Helper loaded: url_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: file_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: form_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: my_helper
INFO - 2024-10-08 15:13:25 --> Database Driver Class Initialized
INFO - 2024-10-08 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:13:25 --> Controller Class Initialized
INFO - 2024-10-08 15:13:25 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:13:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:13:25 --> Utf8 Class Initialized
INFO - 2024-10-08 15:13:25 --> URI Class Initialized
INFO - 2024-10-08 15:13:25 --> Router Class Initialized
INFO - 2024-10-08 15:13:25 --> Output Class Initialized
INFO - 2024-10-08 15:13:25 --> Security Class Initialized
DEBUG - 2024-10-08 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:13:25 --> Input Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Loader Class Initialized
INFO - 2024-10-08 15:13:25 --> Helper loaded: url_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: file_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: form_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: my_helper
INFO - 2024-10-08 15:13:25 --> Database Driver Class Initialized
INFO - 2024-10-08 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:13:25 --> Controller Class Initialized
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:13:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:13:25 --> Utf8 Class Initialized
INFO - 2024-10-08 15:13:25 --> URI Class Initialized
INFO - 2024-10-08 15:13:25 --> Router Class Initialized
INFO - 2024-10-08 15:13:25 --> Output Class Initialized
INFO - 2024-10-08 15:13:25 --> Security Class Initialized
DEBUG - 2024-10-08 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:13:25 --> Input Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Language Class Initialized
INFO - 2024-10-08 15:13:25 --> Config Class Initialized
INFO - 2024-10-08 15:13:25 --> Loader Class Initialized
INFO - 2024-10-08 15:13:25 --> Helper loaded: url_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: file_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: form_helper
INFO - 2024-10-08 15:13:25 --> Helper loaded: my_helper
INFO - 2024-10-08 15:13:25 --> Database Driver Class Initialized
INFO - 2024-10-08 15:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:13:25 --> Controller Class Initialized
DEBUG - 2024-10-08 15:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 15:13:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:13:25 --> Final output sent to browser
DEBUG - 2024-10-08 15:13:25 --> Total execution time: 0.0339
INFO - 2024-10-08 15:14:08 --> Config Class Initialized
INFO - 2024-10-08 15:14:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:08 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:08 --> URI Class Initialized
INFO - 2024-10-08 15:14:08 --> Router Class Initialized
INFO - 2024-10-08 15:14:08 --> Output Class Initialized
INFO - 2024-10-08 15:14:08 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:08 --> Input Class Initialized
INFO - 2024-10-08 15:14:08 --> Language Class Initialized
INFO - 2024-10-08 15:14:08 --> Language Class Initialized
INFO - 2024-10-08 15:14:08 --> Config Class Initialized
INFO - 2024-10-08 15:14:08 --> Loader Class Initialized
INFO - 2024-10-08 15:14:08 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:08 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:08 --> Controller Class Initialized
INFO - 2024-10-08 15:14:08 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:14:08 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:08 --> Total execution time: 0.0410
INFO - 2024-10-08 15:14:08 --> Config Class Initialized
INFO - 2024-10-08 15:14:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:08 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:08 --> URI Class Initialized
INFO - 2024-10-08 15:14:08 --> Router Class Initialized
INFO - 2024-10-08 15:14:08 --> Output Class Initialized
INFO - 2024-10-08 15:14:08 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:08 --> Input Class Initialized
INFO - 2024-10-08 15:14:08 --> Language Class Initialized
INFO - 2024-10-08 15:14:08 --> Language Class Initialized
INFO - 2024-10-08 15:14:08 --> Config Class Initialized
INFO - 2024-10-08 15:14:08 --> Loader Class Initialized
INFO - 2024-10-08 15:14:08 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:08 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:08 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:08 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-08 15:14:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:08 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:08 --> Total execution time: 0.0320
INFO - 2024-10-08 15:14:09 --> Config Class Initialized
INFO - 2024-10-08 15:14:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:09 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:09 --> URI Class Initialized
INFO - 2024-10-08 15:14:09 --> Router Class Initialized
INFO - 2024-10-08 15:14:09 --> Output Class Initialized
INFO - 2024-10-08 15:14:09 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:09 --> Input Class Initialized
INFO - 2024-10-08 15:14:09 --> Language Class Initialized
INFO - 2024-10-08 15:14:09 --> Language Class Initialized
INFO - 2024-10-08 15:14:09 --> Config Class Initialized
INFO - 2024-10-08 15:14:09 --> Loader Class Initialized
INFO - 2024-10-08 15:14:09 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:09 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:09 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:09 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:09 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:09 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-10-08 15:14:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:09 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:09 --> Total execution time: 0.0410
INFO - 2024-10-08 15:14:09 --> Config Class Initialized
INFO - 2024-10-08 15:14:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:09 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:09 --> URI Class Initialized
INFO - 2024-10-08 15:14:09 --> Router Class Initialized
INFO - 2024-10-08 15:14:09 --> Output Class Initialized
INFO - 2024-10-08 15:14:09 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:09 --> Input Class Initialized
INFO - 2024-10-08 15:14:09 --> Language Class Initialized
ERROR - 2024-10-08 15:14:09 --> 404 Page Not Found: /index
INFO - 2024-10-08 15:14:09 --> Config Class Initialized
INFO - 2024-10-08 15:14:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:09 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:09 --> URI Class Initialized
INFO - 2024-10-08 15:14:09 --> Router Class Initialized
INFO - 2024-10-08 15:14:10 --> Output Class Initialized
INFO - 2024-10-08 15:14:10 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:10 --> Input Class Initialized
INFO - 2024-10-08 15:14:10 --> Language Class Initialized
INFO - 2024-10-08 15:14:10 --> Language Class Initialized
INFO - 2024-10-08 15:14:10 --> Config Class Initialized
INFO - 2024-10-08 15:14:10 --> Loader Class Initialized
INFO - 2024-10-08 15:14:10 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:10 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:10 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:10 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:10 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:10 --> Controller Class Initialized
INFO - 2024-10-08 15:14:11 --> Config Class Initialized
INFO - 2024-10-08 15:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:11 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:11 --> URI Class Initialized
INFO - 2024-10-08 15:14:11 --> Router Class Initialized
INFO - 2024-10-08 15:14:11 --> Output Class Initialized
INFO - 2024-10-08 15:14:11 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:11 --> Input Class Initialized
INFO - 2024-10-08 15:14:11 --> Language Class Initialized
INFO - 2024-10-08 15:14:11 --> Language Class Initialized
INFO - 2024-10-08 15:14:11 --> Config Class Initialized
INFO - 2024-10-08 15:14:11 --> Loader Class Initialized
INFO - 2024-10-08 15:14:11 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:11 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:11 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-08 15:14:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:11 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:11 --> Total execution time: 0.0395
INFO - 2024-10-08 15:14:11 --> Config Class Initialized
INFO - 2024-10-08 15:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:11 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:11 --> URI Class Initialized
INFO - 2024-10-08 15:14:11 --> Router Class Initialized
INFO - 2024-10-08 15:14:11 --> Output Class Initialized
INFO - 2024-10-08 15:14:11 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:11 --> Input Class Initialized
INFO - 2024-10-08 15:14:11 --> Language Class Initialized
ERROR - 2024-10-08 15:14:11 --> 404 Page Not Found: /index
INFO - 2024-10-08 15:14:11 --> Config Class Initialized
INFO - 2024-10-08 15:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:11 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:11 --> URI Class Initialized
INFO - 2024-10-08 15:14:11 --> Router Class Initialized
INFO - 2024-10-08 15:14:11 --> Output Class Initialized
INFO - 2024-10-08 15:14:11 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:11 --> Input Class Initialized
INFO - 2024-10-08 15:14:11 --> Language Class Initialized
INFO - 2024-10-08 15:14:11 --> Language Class Initialized
INFO - 2024-10-08 15:14:11 --> Config Class Initialized
INFO - 2024-10-08 15:14:11 --> Loader Class Initialized
INFO - 2024-10-08 15:14:11 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:11 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:11 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:11 --> Controller Class Initialized
INFO - 2024-10-08 15:14:13 --> Config Class Initialized
INFO - 2024-10-08 15:14:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:13 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:13 --> URI Class Initialized
INFO - 2024-10-08 15:14:13 --> Router Class Initialized
INFO - 2024-10-08 15:14:13 --> Output Class Initialized
INFO - 2024-10-08 15:14:13 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:13 --> Input Class Initialized
INFO - 2024-10-08 15:14:13 --> Language Class Initialized
INFO - 2024-10-08 15:14:13 --> Language Class Initialized
INFO - 2024-10-08 15:14:13 --> Config Class Initialized
INFO - 2024-10-08 15:14:13 --> Loader Class Initialized
INFO - 2024-10-08 15:14:13 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:13 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:13 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:13 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:13 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:13 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-10-08 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:13 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:13 --> Total execution time: 0.0480
INFO - 2024-10-08 15:14:14 --> Config Class Initialized
INFO - 2024-10-08 15:14:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:14 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:14 --> URI Class Initialized
INFO - 2024-10-08 15:14:14 --> Router Class Initialized
INFO - 2024-10-08 15:14:14 --> Output Class Initialized
INFO - 2024-10-08 15:14:14 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:14 --> Input Class Initialized
INFO - 2024-10-08 15:14:14 --> Language Class Initialized
INFO - 2024-10-08 15:14:14 --> Language Class Initialized
INFO - 2024-10-08 15:14:14 --> Config Class Initialized
INFO - 2024-10-08 15:14:14 --> Loader Class Initialized
INFO - 2024-10-08 15:14:14 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:14 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:14 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-10-08 15:14:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:14 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:14 --> Total execution time: 0.0435
INFO - 2024-10-08 15:14:14 --> Config Class Initialized
INFO - 2024-10-08 15:14:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:14 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:14 --> URI Class Initialized
INFO - 2024-10-08 15:14:14 --> Router Class Initialized
INFO - 2024-10-08 15:14:14 --> Output Class Initialized
INFO - 2024-10-08 15:14:14 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:14 --> Input Class Initialized
INFO - 2024-10-08 15:14:14 --> Language Class Initialized
ERROR - 2024-10-08 15:14:14 --> 404 Page Not Found: /index
INFO - 2024-10-08 15:14:14 --> Config Class Initialized
INFO - 2024-10-08 15:14:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:14 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:14 --> URI Class Initialized
INFO - 2024-10-08 15:14:14 --> Router Class Initialized
INFO - 2024-10-08 15:14:14 --> Output Class Initialized
INFO - 2024-10-08 15:14:14 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:14 --> Input Class Initialized
INFO - 2024-10-08 15:14:14 --> Language Class Initialized
INFO - 2024-10-08 15:14:14 --> Language Class Initialized
INFO - 2024-10-08 15:14:14 --> Config Class Initialized
INFO - 2024-10-08 15:14:14 --> Loader Class Initialized
INFO - 2024-10-08 15:14:14 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:14 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:14 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:14 --> Controller Class Initialized
INFO - 2024-10-08 15:14:16 --> Config Class Initialized
INFO - 2024-10-08 15:14:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:16 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:16 --> URI Class Initialized
INFO - 2024-10-08 15:14:16 --> Router Class Initialized
INFO - 2024-10-08 15:14:16 --> Output Class Initialized
INFO - 2024-10-08 15:14:16 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:16 --> Input Class Initialized
INFO - 2024-10-08 15:14:16 --> Language Class Initialized
INFO - 2024-10-08 15:14:16 --> Language Class Initialized
INFO - 2024-10-08 15:14:16 --> Config Class Initialized
INFO - 2024-10-08 15:14:16 --> Loader Class Initialized
INFO - 2024-10-08 15:14:16 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:16 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:16 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-10-08 15:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:16 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:16 --> Total execution time: 0.0330
INFO - 2024-10-08 15:14:16 --> Config Class Initialized
INFO - 2024-10-08 15:14:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:16 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:16 --> URI Class Initialized
INFO - 2024-10-08 15:14:16 --> Router Class Initialized
INFO - 2024-10-08 15:14:16 --> Output Class Initialized
INFO - 2024-10-08 15:14:16 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:16 --> Input Class Initialized
INFO - 2024-10-08 15:14:16 --> Language Class Initialized
ERROR - 2024-10-08 15:14:16 --> 404 Page Not Found: /index
INFO - 2024-10-08 15:14:16 --> Config Class Initialized
INFO - 2024-10-08 15:14:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:16 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:16 --> URI Class Initialized
INFO - 2024-10-08 15:14:16 --> Router Class Initialized
INFO - 2024-10-08 15:14:16 --> Output Class Initialized
INFO - 2024-10-08 15:14:16 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:16 --> Input Class Initialized
INFO - 2024-10-08 15:14:16 --> Language Class Initialized
INFO - 2024-10-08 15:14:16 --> Language Class Initialized
INFO - 2024-10-08 15:14:16 --> Config Class Initialized
INFO - 2024-10-08 15:14:16 --> Loader Class Initialized
INFO - 2024-10-08 15:14:16 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:16 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:16 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:16 --> Controller Class Initialized
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:19 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:19 --> URI Class Initialized
INFO - 2024-10-08 15:14:19 --> Router Class Initialized
INFO - 2024-10-08 15:14:19 --> Output Class Initialized
INFO - 2024-10-08 15:14:19 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:19 --> Input Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Loader Class Initialized
INFO - 2024-10-08 15:14:19 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:19 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:19 --> Controller Class Initialized
INFO - 2024-10-08 15:14:19 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:19 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:19 --> URI Class Initialized
INFO - 2024-10-08 15:14:19 --> Router Class Initialized
INFO - 2024-10-08 15:14:19 --> Output Class Initialized
INFO - 2024-10-08 15:14:19 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:19 --> Input Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Loader Class Initialized
INFO - 2024-10-08 15:14:19 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:19 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:19 --> Controller Class Initialized
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:19 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:19 --> URI Class Initialized
INFO - 2024-10-08 15:14:19 --> Router Class Initialized
INFO - 2024-10-08 15:14:19 --> Output Class Initialized
INFO - 2024-10-08 15:14:19 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:19 --> Input Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Language Class Initialized
INFO - 2024-10-08 15:14:19 --> Config Class Initialized
INFO - 2024-10-08 15:14:19 --> Loader Class Initialized
INFO - 2024-10-08 15:14:19 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:19 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:19 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:19 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 15:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:19 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:19 --> Total execution time: 0.0555
INFO - 2024-10-08 15:14:25 --> Config Class Initialized
INFO - 2024-10-08 15:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:25 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:25 --> URI Class Initialized
INFO - 2024-10-08 15:14:25 --> Router Class Initialized
INFO - 2024-10-08 15:14:25 --> Output Class Initialized
INFO - 2024-10-08 15:14:25 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:25 --> Input Class Initialized
INFO - 2024-10-08 15:14:25 --> Language Class Initialized
INFO - 2024-10-08 15:14:25 --> Language Class Initialized
INFO - 2024-10-08 15:14:25 --> Config Class Initialized
INFO - 2024-10-08 15:14:25 --> Loader Class Initialized
INFO - 2024-10-08 15:14:25 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:25 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:25 --> Controller Class Initialized
INFO - 2024-10-08 15:14:25 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:14:25 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:25 --> Total execution time: 0.0376
INFO - 2024-10-08 15:14:25 --> Config Class Initialized
INFO - 2024-10-08 15:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:25 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:25 --> URI Class Initialized
INFO - 2024-10-08 15:14:25 --> Router Class Initialized
INFO - 2024-10-08 15:14:25 --> Output Class Initialized
INFO - 2024-10-08 15:14:25 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:25 --> Input Class Initialized
INFO - 2024-10-08 15:14:25 --> Language Class Initialized
INFO - 2024-10-08 15:14:25 --> Language Class Initialized
INFO - 2024-10-08 15:14:25 --> Config Class Initialized
INFO - 2024-10-08 15:14:25 --> Loader Class Initialized
INFO - 2024-10-08 15:14:25 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:25 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:25 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:25 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 15:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:25 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:25 --> Total execution time: 0.0440
INFO - 2024-10-08 15:14:28 --> Config Class Initialized
INFO - 2024-10-08 15:14:28 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:28 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:28 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:28 --> URI Class Initialized
INFO - 2024-10-08 15:14:28 --> Router Class Initialized
INFO - 2024-10-08 15:14:28 --> Output Class Initialized
INFO - 2024-10-08 15:14:28 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:28 --> Input Class Initialized
INFO - 2024-10-08 15:14:28 --> Language Class Initialized
INFO - 2024-10-08 15:14:28 --> Language Class Initialized
INFO - 2024-10-08 15:14:28 --> Config Class Initialized
INFO - 2024-10-08 15:14:28 --> Loader Class Initialized
INFO - 2024-10-08 15:14:28 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:28 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:28 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:28 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:28 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:28 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 15:14:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:14:28 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:28 --> Total execution time: 0.0637
INFO - 2024-10-08 15:14:29 --> Config Class Initialized
INFO - 2024-10-08 15:14:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:14:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:14:29 --> Utf8 Class Initialized
INFO - 2024-10-08 15:14:29 --> URI Class Initialized
INFO - 2024-10-08 15:14:29 --> Router Class Initialized
INFO - 2024-10-08 15:14:29 --> Output Class Initialized
INFO - 2024-10-08 15:14:29 --> Security Class Initialized
DEBUG - 2024-10-08 15:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:14:29 --> Input Class Initialized
INFO - 2024-10-08 15:14:29 --> Language Class Initialized
INFO - 2024-10-08 15:14:29 --> Language Class Initialized
INFO - 2024-10-08 15:14:29 --> Config Class Initialized
INFO - 2024-10-08 15:14:29 --> Loader Class Initialized
INFO - 2024-10-08 15:14:29 --> Helper loaded: url_helper
INFO - 2024-10-08 15:14:29 --> Helper loaded: file_helper
INFO - 2024-10-08 15:14:29 --> Helper loaded: form_helper
INFO - 2024-10-08 15:14:29 --> Helper loaded: my_helper
INFO - 2024-10-08 15:14:29 --> Database Driver Class Initialized
INFO - 2024-10-08 15:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:14:29 --> Controller Class Initialized
DEBUG - 2024-10-08 15:14:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 15:14:32 --> Final output sent to browser
DEBUG - 2024-10-08 15:14:32 --> Total execution time: 3.1086
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:38:04 --> URI Class Initialized
INFO - 2024-10-08 15:38:04 --> Router Class Initialized
INFO - 2024-10-08 15:38:04 --> Output Class Initialized
INFO - 2024-10-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:38:04 --> Input Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Loader Class Initialized
INFO - 2024-10-08 15:38:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:38:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:38:04 --> Controller Class Initialized
INFO - 2024-10-08 15:38:04 --> Helper loaded: cookie_helper
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:38:04 --> URI Class Initialized
INFO - 2024-10-08 15:38:04 --> Router Class Initialized
INFO - 2024-10-08 15:38:04 --> Output Class Initialized
INFO - 2024-10-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:38:04 --> Input Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Loader Class Initialized
INFO - 2024-10-08 15:38:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:38:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:38:04 --> Controller Class Initialized
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-10-08 15:38:04 --> URI Class Initialized
INFO - 2024-10-08 15:38:04 --> Router Class Initialized
INFO - 2024-10-08 15:38:04 --> Output Class Initialized
INFO - 2024-10-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-10-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 15:38:04 --> Input Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Language Class Initialized
INFO - 2024-10-08 15:38:04 --> Config Class Initialized
INFO - 2024-10-08 15:38:04 --> Loader Class Initialized
INFO - 2024-10-08 15:38:04 --> Helper loaded: url_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: file_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: form_helper
INFO - 2024-10-08 15:38:04 --> Helper loaded: my_helper
INFO - 2024-10-08 15:38:04 --> Database Driver Class Initialized
INFO - 2024-10-08 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 15:38:04 --> Controller Class Initialized
DEBUG - 2024-10-08 15:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 15:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 15:38:04 --> Final output sent to browser
DEBUG - 2024-10-08 15:38:04 --> Total execution time: 0.0643
INFO - 2024-10-08 16:05:11 --> Config Class Initialized
INFO - 2024-10-08 16:05:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:11 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:11 --> URI Class Initialized
INFO - 2024-10-08 16:05:11 --> Router Class Initialized
INFO - 2024-10-08 16:05:11 --> Output Class Initialized
INFO - 2024-10-08 16:05:11 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:11 --> Input Class Initialized
INFO - 2024-10-08 16:05:11 --> Language Class Initialized
INFO - 2024-10-08 16:05:11 --> Language Class Initialized
INFO - 2024-10-08 16:05:11 --> Config Class Initialized
INFO - 2024-10-08 16:05:11 --> Loader Class Initialized
INFO - 2024-10-08 16:05:11 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:11 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:11 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:11 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:11 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:12 --> Controller Class Initialized
ERROR - 2024-10-08 16:05:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2393
DEBUG - 2024-10-08 16:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 16:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:05:12 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:12 --> Total execution time: 0.6080
INFO - 2024-10-08 16:05:14 --> Config Class Initialized
INFO - 2024-10-08 16:05:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:14 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:14 --> URI Class Initialized
INFO - 2024-10-08 16:05:14 --> Router Class Initialized
INFO - 2024-10-08 16:05:14 --> Output Class Initialized
INFO - 2024-10-08 16:05:14 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:14 --> Input Class Initialized
INFO - 2024-10-08 16:05:14 --> Language Class Initialized
INFO - 2024-10-08 16:05:14 --> Language Class Initialized
INFO - 2024-10-08 16:05:14 --> Config Class Initialized
INFO - 2024-10-08 16:05:14 --> Loader Class Initialized
INFO - 2024-10-08 16:05:14 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:14 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:14 --> Controller Class Initialized
INFO - 2024-10-08 16:05:14 --> Config Class Initialized
INFO - 2024-10-08 16:05:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:14 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:14 --> URI Class Initialized
INFO - 2024-10-08 16:05:14 --> Router Class Initialized
INFO - 2024-10-08 16:05:14 --> Output Class Initialized
INFO - 2024-10-08 16:05:14 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:14 --> Input Class Initialized
INFO - 2024-10-08 16:05:14 --> Language Class Initialized
INFO - 2024-10-08 16:05:14 --> Language Class Initialized
INFO - 2024-10-08 16:05:14 --> Config Class Initialized
INFO - 2024-10-08 16:05:14 --> Loader Class Initialized
INFO - 2024-10-08 16:05:14 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:14 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:14 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:14 --> Controller Class Initialized
DEBUG - 2024-10-08 16:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:05:14 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:14 --> Total execution time: 0.0408
INFO - 2024-10-08 16:05:22 --> Config Class Initialized
INFO - 2024-10-08 16:05:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:22 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:22 --> URI Class Initialized
INFO - 2024-10-08 16:05:22 --> Router Class Initialized
INFO - 2024-10-08 16:05:22 --> Output Class Initialized
INFO - 2024-10-08 16:05:22 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:22 --> Input Class Initialized
INFO - 2024-10-08 16:05:22 --> Language Class Initialized
INFO - 2024-10-08 16:05:22 --> Language Class Initialized
INFO - 2024-10-08 16:05:22 --> Config Class Initialized
INFO - 2024-10-08 16:05:22 --> Loader Class Initialized
INFO - 2024-10-08 16:05:22 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:22 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:22 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:22 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:22 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:22 --> Controller Class Initialized
INFO - 2024-10-08 16:05:22 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:05:22 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:22 --> Total execution time: 0.0853
INFO - 2024-10-08 16:05:23 --> Config Class Initialized
INFO - 2024-10-08 16:05:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:23 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:23 --> URI Class Initialized
INFO - 2024-10-08 16:05:23 --> Router Class Initialized
INFO - 2024-10-08 16:05:23 --> Output Class Initialized
INFO - 2024-10-08 16:05:23 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:23 --> Input Class Initialized
INFO - 2024-10-08 16:05:23 --> Language Class Initialized
INFO - 2024-10-08 16:05:23 --> Language Class Initialized
INFO - 2024-10-08 16:05:23 --> Config Class Initialized
INFO - 2024-10-08 16:05:23 --> Loader Class Initialized
INFO - 2024-10-08 16:05:23 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:23 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:23 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:23 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:23 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:23 --> Controller Class Initialized
DEBUG - 2024-10-08 16:05:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 16:05:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:05:23 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:23 --> Total execution time: 0.0416
INFO - 2024-10-08 16:05:27 --> Config Class Initialized
INFO - 2024-10-08 16:05:27 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:27 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:27 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:27 --> URI Class Initialized
INFO - 2024-10-08 16:05:27 --> Router Class Initialized
INFO - 2024-10-08 16:05:27 --> Output Class Initialized
INFO - 2024-10-08 16:05:27 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:27 --> Input Class Initialized
INFO - 2024-10-08 16:05:27 --> Language Class Initialized
INFO - 2024-10-08 16:05:27 --> Language Class Initialized
INFO - 2024-10-08 16:05:27 --> Config Class Initialized
INFO - 2024-10-08 16:05:27 --> Loader Class Initialized
INFO - 2024-10-08 16:05:27 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:27 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:27 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:27 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:27 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:27 --> Controller Class Initialized
DEBUG - 2024-10-08 16:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 16:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:05:27 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:27 --> Total execution time: 0.0741
INFO - 2024-10-08 16:05:30 --> Config Class Initialized
INFO - 2024-10-08 16:05:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:05:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:05:30 --> Utf8 Class Initialized
INFO - 2024-10-08 16:05:30 --> URI Class Initialized
INFO - 2024-10-08 16:05:30 --> Router Class Initialized
INFO - 2024-10-08 16:05:30 --> Output Class Initialized
INFO - 2024-10-08 16:05:30 --> Security Class Initialized
DEBUG - 2024-10-08 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:05:30 --> Input Class Initialized
INFO - 2024-10-08 16:05:30 --> Language Class Initialized
INFO - 2024-10-08 16:05:30 --> Language Class Initialized
INFO - 2024-10-08 16:05:30 --> Config Class Initialized
INFO - 2024-10-08 16:05:30 --> Loader Class Initialized
INFO - 2024-10-08 16:05:30 --> Helper loaded: url_helper
INFO - 2024-10-08 16:05:30 --> Helper loaded: file_helper
INFO - 2024-10-08 16:05:30 --> Helper loaded: form_helper
INFO - 2024-10-08 16:05:30 --> Helper loaded: my_helper
INFO - 2024-10-08 16:05:30 --> Database Driver Class Initialized
INFO - 2024-10-08 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:05:30 --> Controller Class Initialized
DEBUG - 2024-10-08 16:05:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:05:33 --> Final output sent to browser
DEBUG - 2024-10-08 16:05:33 --> Total execution time: 3.1184
INFO - 2024-10-08 16:23:01 --> Config Class Initialized
INFO - 2024-10-08 16:23:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:01 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:01 --> URI Class Initialized
INFO - 2024-10-08 16:23:01 --> Router Class Initialized
INFO - 2024-10-08 16:23:01 --> Output Class Initialized
INFO - 2024-10-08 16:23:01 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:01 --> Input Class Initialized
INFO - 2024-10-08 16:23:01 --> Language Class Initialized
INFO - 2024-10-08 16:23:01 --> Language Class Initialized
INFO - 2024-10-08 16:23:01 --> Config Class Initialized
INFO - 2024-10-08 16:23:01 --> Loader Class Initialized
INFO - 2024-10-08 16:23:01 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:01 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:01 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:02 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:02 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:02 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:23:05 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:05 --> Total execution time: 3.4275
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:17 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:17 --> URI Class Initialized
INFO - 2024-10-08 16:23:17 --> Router Class Initialized
INFO - 2024-10-08 16:23:17 --> Output Class Initialized
INFO - 2024-10-08 16:23:17 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:17 --> Input Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Loader Class Initialized
INFO - 2024-10-08 16:23:17 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:17 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:17 --> Controller Class Initialized
INFO - 2024-10-08 16:23:17 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:17 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:17 --> URI Class Initialized
INFO - 2024-10-08 16:23:17 --> Router Class Initialized
INFO - 2024-10-08 16:23:17 --> Output Class Initialized
INFO - 2024-10-08 16:23:17 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:17 --> Input Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Loader Class Initialized
INFO - 2024-10-08 16:23:17 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:17 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:17 --> Controller Class Initialized
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:17 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:17 --> URI Class Initialized
INFO - 2024-10-08 16:23:17 --> Router Class Initialized
INFO - 2024-10-08 16:23:17 --> Output Class Initialized
INFO - 2024-10-08 16:23:17 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:17 --> Input Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Language Class Initialized
INFO - 2024-10-08 16:23:17 --> Config Class Initialized
INFO - 2024-10-08 16:23:17 --> Loader Class Initialized
INFO - 2024-10-08 16:23:17 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:17 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:17 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:17 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:23:17 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:17 --> Total execution time: 0.0369
INFO - 2024-10-08 16:23:20 --> Config Class Initialized
INFO - 2024-10-08 16:23:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:20 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:20 --> URI Class Initialized
INFO - 2024-10-08 16:23:20 --> Router Class Initialized
INFO - 2024-10-08 16:23:20 --> Output Class Initialized
INFO - 2024-10-08 16:23:20 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:20 --> Input Class Initialized
INFO - 2024-10-08 16:23:20 --> Language Class Initialized
INFO - 2024-10-08 16:23:20 --> Language Class Initialized
INFO - 2024-10-08 16:23:20 --> Config Class Initialized
INFO - 2024-10-08 16:23:20 --> Loader Class Initialized
INFO - 2024-10-08 16:23:20 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:20 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:20 --> Controller Class Initialized
INFO - 2024-10-08 16:23:20 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:23:20 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:20 --> Total execution time: 0.0333
INFO - 2024-10-08 16:23:20 --> Config Class Initialized
INFO - 2024-10-08 16:23:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:20 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:20 --> URI Class Initialized
INFO - 2024-10-08 16:23:20 --> Router Class Initialized
INFO - 2024-10-08 16:23:20 --> Output Class Initialized
INFO - 2024-10-08 16:23:20 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:20 --> Input Class Initialized
INFO - 2024-10-08 16:23:20 --> Language Class Initialized
INFO - 2024-10-08 16:23:20 --> Language Class Initialized
INFO - 2024-10-08 16:23:20 --> Config Class Initialized
INFO - 2024-10-08 16:23:20 --> Loader Class Initialized
INFO - 2024-10-08 16:23:20 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:20 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:20 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:20 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-10-08 16:23:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:23:20 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:20 --> Total execution time: 0.0362
INFO - 2024-10-08 16:23:23 --> Config Class Initialized
INFO - 2024-10-08 16:23:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:23 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:23 --> URI Class Initialized
INFO - 2024-10-08 16:23:23 --> Router Class Initialized
INFO - 2024-10-08 16:23:23 --> Output Class Initialized
INFO - 2024-10-08 16:23:23 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:23 --> Input Class Initialized
INFO - 2024-10-08 16:23:23 --> Language Class Initialized
INFO - 2024-10-08 16:23:23 --> Language Class Initialized
INFO - 2024-10-08 16:23:23 --> Config Class Initialized
INFO - 2024-10-08 16:23:23 --> Loader Class Initialized
INFO - 2024-10-08 16:23:23 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:23 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:23 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:23 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:23 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:23 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-08 16:23:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:23:23 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:23 --> Total execution time: 0.0358
INFO - 2024-10-08 16:23:26 --> Config Class Initialized
INFO - 2024-10-08 16:23:26 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:26 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:26 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:26 --> URI Class Initialized
INFO - 2024-10-08 16:23:26 --> Router Class Initialized
INFO - 2024-10-08 16:23:26 --> Output Class Initialized
INFO - 2024-10-08 16:23:26 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:26 --> Input Class Initialized
INFO - 2024-10-08 16:23:26 --> Language Class Initialized
INFO - 2024-10-08 16:23:26 --> Language Class Initialized
INFO - 2024-10-08 16:23:26 --> Config Class Initialized
INFO - 2024-10-08 16:23:26 --> Loader Class Initialized
INFO - 2024-10-08 16:23:26 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:26 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:26 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:26 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:26 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:26 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:23:33 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:33 --> Total execution time: 6.6921
INFO - 2024-10-08 16:23:45 --> Config Class Initialized
INFO - 2024-10-08 16:23:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:45 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:45 --> URI Class Initialized
INFO - 2024-10-08 16:23:45 --> Router Class Initialized
INFO - 2024-10-08 16:23:45 --> Output Class Initialized
INFO - 2024-10-08 16:23:45 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:45 --> Input Class Initialized
INFO - 2024-10-08 16:23:45 --> Language Class Initialized
INFO - 2024-10-08 16:23:45 --> Language Class Initialized
INFO - 2024-10-08 16:23:45 --> Config Class Initialized
INFO - 2024-10-08 16:23:45 --> Loader Class Initialized
INFO - 2024-10-08 16:23:45 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:45 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:45 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:45 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:45 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:45 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-10-08 16:23:47 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:47 --> Total execution time: 2.0489
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:54 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:54 --> URI Class Initialized
INFO - 2024-10-08 16:23:54 --> Router Class Initialized
INFO - 2024-10-08 16:23:54 --> Output Class Initialized
INFO - 2024-10-08 16:23:54 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:54 --> Input Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Loader Class Initialized
INFO - 2024-10-08 16:23:54 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:54 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:54 --> Controller Class Initialized
INFO - 2024-10-08 16:23:54 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:54 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:54 --> URI Class Initialized
INFO - 2024-10-08 16:23:54 --> Router Class Initialized
INFO - 2024-10-08 16:23:54 --> Output Class Initialized
INFO - 2024-10-08 16:23:54 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:54 --> Input Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Loader Class Initialized
INFO - 2024-10-08 16:23:54 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:54 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:54 --> Controller Class Initialized
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:23:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:23:54 --> Utf8 Class Initialized
INFO - 2024-10-08 16:23:54 --> URI Class Initialized
INFO - 2024-10-08 16:23:54 --> Router Class Initialized
INFO - 2024-10-08 16:23:54 --> Output Class Initialized
INFO - 2024-10-08 16:23:54 --> Security Class Initialized
DEBUG - 2024-10-08 16:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:23:54 --> Input Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Language Class Initialized
INFO - 2024-10-08 16:23:54 --> Config Class Initialized
INFO - 2024-10-08 16:23:54 --> Loader Class Initialized
INFO - 2024-10-08 16:23:54 --> Helper loaded: url_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: file_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: form_helper
INFO - 2024-10-08 16:23:54 --> Helper loaded: my_helper
INFO - 2024-10-08 16:23:54 --> Database Driver Class Initialized
INFO - 2024-10-08 16:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:23:54 --> Controller Class Initialized
DEBUG - 2024-10-08 16:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:23:54 --> Final output sent to browser
DEBUG - 2024-10-08 16:23:54 --> Total execution time: 0.0378
INFO - 2024-10-08 16:53:32 --> Config Class Initialized
INFO - 2024-10-08 16:53:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:32 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:32 --> URI Class Initialized
INFO - 2024-10-08 16:53:32 --> Router Class Initialized
INFO - 2024-10-08 16:53:32 --> Output Class Initialized
INFO - 2024-10-08 16:53:32 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:32 --> Input Class Initialized
INFO - 2024-10-08 16:53:32 --> Language Class Initialized
INFO - 2024-10-08 16:53:32 --> Language Class Initialized
INFO - 2024-10-08 16:53:32 --> Config Class Initialized
INFO - 2024-10-08 16:53:32 --> Loader Class Initialized
INFO - 2024-10-08 16:53:32 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:32 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:32 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:32 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:32 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:32 --> Controller Class Initialized
INFO - 2024-10-08 16:53:33 --> Config Class Initialized
INFO - 2024-10-08 16:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:33 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:33 --> URI Class Initialized
INFO - 2024-10-08 16:53:33 --> Router Class Initialized
INFO - 2024-10-08 16:53:33 --> Output Class Initialized
INFO - 2024-10-08 16:53:33 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:33 --> Input Class Initialized
INFO - 2024-10-08 16:53:33 --> Language Class Initialized
INFO - 2024-10-08 16:53:33 --> Language Class Initialized
INFO - 2024-10-08 16:53:33 --> Config Class Initialized
INFO - 2024-10-08 16:53:33 --> Loader Class Initialized
INFO - 2024-10-08 16:53:33 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:33 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:33 --> Controller Class Initialized
INFO - 2024-10-08 16:53:33 --> Config Class Initialized
INFO - 2024-10-08 16:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:33 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:33 --> URI Class Initialized
INFO - 2024-10-08 16:53:33 --> Router Class Initialized
INFO - 2024-10-08 16:53:33 --> Output Class Initialized
INFO - 2024-10-08 16:53:33 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:33 --> Input Class Initialized
INFO - 2024-10-08 16:53:33 --> Language Class Initialized
INFO - 2024-10-08 16:53:33 --> Language Class Initialized
INFO - 2024-10-08 16:53:33 --> Config Class Initialized
INFO - 2024-10-08 16:53:33 --> Loader Class Initialized
INFO - 2024-10-08 16:53:33 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:33 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:33 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:33 --> Controller Class Initialized
DEBUG - 2024-10-08 16:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:53:33 --> Final output sent to browser
DEBUG - 2024-10-08 16:53:33 --> Total execution time: 0.0344
INFO - 2024-10-08 16:53:36 --> Config Class Initialized
INFO - 2024-10-08 16:53:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:36 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:36 --> URI Class Initialized
INFO - 2024-10-08 16:53:36 --> Router Class Initialized
INFO - 2024-10-08 16:53:36 --> Output Class Initialized
INFO - 2024-10-08 16:53:36 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:36 --> Input Class Initialized
INFO - 2024-10-08 16:53:36 --> Language Class Initialized
INFO - 2024-10-08 16:53:36 --> Language Class Initialized
INFO - 2024-10-08 16:53:36 --> Config Class Initialized
INFO - 2024-10-08 16:53:36 --> Loader Class Initialized
INFO - 2024-10-08 16:53:36 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:36 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:36 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:36 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:36 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:36 --> Controller Class Initialized
INFO - 2024-10-08 16:53:36 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:53:36 --> Final output sent to browser
DEBUG - 2024-10-08 16:53:36 --> Total execution time: 0.0320
INFO - 2024-10-08 16:53:37 --> Config Class Initialized
INFO - 2024-10-08 16:53:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:37 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:37 --> URI Class Initialized
INFO - 2024-10-08 16:53:37 --> Router Class Initialized
INFO - 2024-10-08 16:53:37 --> Output Class Initialized
INFO - 2024-10-08 16:53:37 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:37 --> Input Class Initialized
INFO - 2024-10-08 16:53:37 --> Language Class Initialized
INFO - 2024-10-08 16:53:37 --> Language Class Initialized
INFO - 2024-10-08 16:53:37 --> Config Class Initialized
INFO - 2024-10-08 16:53:37 --> Loader Class Initialized
INFO - 2024-10-08 16:53:37 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:37 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:37 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:37 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:37 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:37 --> Controller Class Initialized
DEBUG - 2024-10-08 16:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 16:53:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:53:37 --> Final output sent to browser
DEBUG - 2024-10-08 16:53:37 --> Total execution time: 0.0685
INFO - 2024-10-08 16:53:45 --> Config Class Initialized
INFO - 2024-10-08 16:53:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:45 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:45 --> URI Class Initialized
INFO - 2024-10-08 16:53:45 --> Router Class Initialized
INFO - 2024-10-08 16:53:45 --> Output Class Initialized
INFO - 2024-10-08 16:53:45 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:45 --> Input Class Initialized
INFO - 2024-10-08 16:53:45 --> Language Class Initialized
INFO - 2024-10-08 16:53:45 --> Language Class Initialized
INFO - 2024-10-08 16:53:45 --> Config Class Initialized
INFO - 2024-10-08 16:53:45 --> Loader Class Initialized
INFO - 2024-10-08 16:53:45 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:45 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:45 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:45 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:45 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:45 --> Controller Class Initialized
DEBUG - 2024-10-08 16:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 16:53:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:53:45 --> Final output sent to browser
DEBUG - 2024-10-08 16:53:45 --> Total execution time: 0.0673
INFO - 2024-10-08 16:53:47 --> Config Class Initialized
INFO - 2024-10-08 16:53:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:53:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:53:47 --> Utf8 Class Initialized
INFO - 2024-10-08 16:53:47 --> URI Class Initialized
INFO - 2024-10-08 16:53:47 --> Router Class Initialized
INFO - 2024-10-08 16:53:47 --> Output Class Initialized
INFO - 2024-10-08 16:53:47 --> Security Class Initialized
DEBUG - 2024-10-08 16:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:53:47 --> Input Class Initialized
INFO - 2024-10-08 16:53:47 --> Language Class Initialized
INFO - 2024-10-08 16:53:47 --> Language Class Initialized
INFO - 2024-10-08 16:53:47 --> Config Class Initialized
INFO - 2024-10-08 16:53:47 --> Loader Class Initialized
INFO - 2024-10-08 16:53:47 --> Helper loaded: url_helper
INFO - 2024-10-08 16:53:47 --> Helper loaded: file_helper
INFO - 2024-10-08 16:53:47 --> Helper loaded: form_helper
INFO - 2024-10-08 16:53:47 --> Helper loaded: my_helper
INFO - 2024-10-08 16:53:47 --> Database Driver Class Initialized
INFO - 2024-10-08 16:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:53:47 --> Controller Class Initialized
DEBUG - 2024-10-08 16:53:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:53:51 --> Final output sent to browser
DEBUG - 2024-10-08 16:53:51 --> Total execution time: 3.2969
INFO - 2024-10-08 16:54:06 --> Config Class Initialized
INFO - 2024-10-08 16:54:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:06 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:06 --> URI Class Initialized
INFO - 2024-10-08 16:54:06 --> Router Class Initialized
INFO - 2024-10-08 16:54:06 --> Output Class Initialized
INFO - 2024-10-08 16:54:06 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:06 --> Input Class Initialized
INFO - 2024-10-08 16:54:06 --> Language Class Initialized
INFO - 2024-10-08 16:54:06 --> Language Class Initialized
INFO - 2024-10-08 16:54:06 --> Config Class Initialized
INFO - 2024-10-08 16:54:06 --> Loader Class Initialized
INFO - 2024-10-08 16:54:06 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:06 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:06 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:06 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:06 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:06 --> Controller Class Initialized
INFO - 2024-10-08 16:54:07 --> Config Class Initialized
INFO - 2024-10-08 16:54:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:07 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:07 --> URI Class Initialized
INFO - 2024-10-08 16:54:07 --> Router Class Initialized
INFO - 2024-10-08 16:54:07 --> Output Class Initialized
INFO - 2024-10-08 16:54:07 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:07 --> Input Class Initialized
INFO - 2024-10-08 16:54:07 --> Language Class Initialized
INFO - 2024-10-08 16:54:07 --> Language Class Initialized
INFO - 2024-10-08 16:54:07 --> Config Class Initialized
INFO - 2024-10-08 16:54:07 --> Loader Class Initialized
INFO - 2024-10-08 16:54:07 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:07 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:07 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:07 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:07 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:07 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:07 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:07 --> Total execution time: 0.0384
INFO - 2024-10-08 16:54:09 --> Config Class Initialized
INFO - 2024-10-08 16:54:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:09 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:09 --> URI Class Initialized
INFO - 2024-10-08 16:54:09 --> Router Class Initialized
INFO - 2024-10-08 16:54:09 --> Output Class Initialized
INFO - 2024-10-08 16:54:09 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:09 --> Input Class Initialized
INFO - 2024-10-08 16:54:09 --> Language Class Initialized
INFO - 2024-10-08 16:54:09 --> Language Class Initialized
INFO - 2024-10-08 16:54:09 --> Config Class Initialized
INFO - 2024-10-08 16:54:09 --> Loader Class Initialized
INFO - 2024-10-08 16:54:09 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:09 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:09 --> Controller Class Initialized
INFO - 2024-10-08 16:54:09 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:54:09 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:09 --> Total execution time: 0.0503
INFO - 2024-10-08 16:54:09 --> Config Class Initialized
INFO - 2024-10-08 16:54:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:09 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:09 --> URI Class Initialized
INFO - 2024-10-08 16:54:09 --> Router Class Initialized
INFO - 2024-10-08 16:54:09 --> Output Class Initialized
INFO - 2024-10-08 16:54:09 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:09 --> Input Class Initialized
INFO - 2024-10-08 16:54:09 --> Language Class Initialized
INFO - 2024-10-08 16:54:09 --> Language Class Initialized
INFO - 2024-10-08 16:54:09 --> Config Class Initialized
INFO - 2024-10-08 16:54:09 --> Loader Class Initialized
INFO - 2024-10-08 16:54:09 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:09 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:09 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:09 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 16:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:09 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:09 --> Total execution time: 0.0315
INFO - 2024-10-08 16:54:12 --> Config Class Initialized
INFO - 2024-10-08 16:54:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:12 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:12 --> URI Class Initialized
DEBUG - 2024-10-08 16:54:12 --> No URI present. Default controller set.
INFO - 2024-10-08 16:54:12 --> Router Class Initialized
INFO - 2024-10-08 16:54:12 --> Output Class Initialized
INFO - 2024-10-08 16:54:12 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:12 --> Input Class Initialized
INFO - 2024-10-08 16:54:12 --> Language Class Initialized
INFO - 2024-10-08 16:54:12 --> Language Class Initialized
INFO - 2024-10-08 16:54:12 --> Config Class Initialized
INFO - 2024-10-08 16:54:12 --> Loader Class Initialized
INFO - 2024-10-08 16:54:12 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:12 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:12 --> Controller Class Initialized
INFO - 2024-10-08 16:54:12 --> Config Class Initialized
INFO - 2024-10-08 16:54:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:12 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:12 --> URI Class Initialized
INFO - 2024-10-08 16:54:12 --> Router Class Initialized
INFO - 2024-10-08 16:54:12 --> Output Class Initialized
INFO - 2024-10-08 16:54:12 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:12 --> Input Class Initialized
INFO - 2024-10-08 16:54:12 --> Language Class Initialized
INFO - 2024-10-08 16:54:12 --> Language Class Initialized
INFO - 2024-10-08 16:54:12 --> Config Class Initialized
INFO - 2024-10-08 16:54:12 --> Loader Class Initialized
INFO - 2024-10-08 16:54:12 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:12 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:12 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:12 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 16:54:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:12 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:12 --> Total execution time: 0.0743
INFO - 2024-10-08 16:54:14 --> Config Class Initialized
INFO - 2024-10-08 16:54:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:14 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:14 --> URI Class Initialized
INFO - 2024-10-08 16:54:14 --> Router Class Initialized
INFO - 2024-10-08 16:54:14 --> Output Class Initialized
INFO - 2024-10-08 16:54:14 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:14 --> Input Class Initialized
INFO - 2024-10-08 16:54:14 --> Language Class Initialized
INFO - 2024-10-08 16:54:14 --> Language Class Initialized
INFO - 2024-10-08 16:54:14 --> Config Class Initialized
INFO - 2024-10-08 16:54:14 --> Loader Class Initialized
INFO - 2024-10-08 16:54:14 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:14 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:14 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:14 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:14 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:14 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 16:54:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:14 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:14 --> Total execution time: 0.0421
INFO - 2024-10-08 16:54:15 --> Config Class Initialized
INFO - 2024-10-08 16:54:15 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:15 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:15 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:15 --> URI Class Initialized
INFO - 2024-10-08 16:54:15 --> Router Class Initialized
INFO - 2024-10-08 16:54:15 --> Output Class Initialized
INFO - 2024-10-08 16:54:15 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:15 --> Input Class Initialized
INFO - 2024-10-08 16:54:15 --> Language Class Initialized
INFO - 2024-10-08 16:54:15 --> Language Class Initialized
INFO - 2024-10-08 16:54:15 --> Config Class Initialized
INFO - 2024-10-08 16:54:15 --> Loader Class Initialized
INFO - 2024-10-08 16:54:15 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:15 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:15 --> Controller Class Initialized
INFO - 2024-10-08 16:54:15 --> Helper loaded: cookie_helper
INFO - 2024-10-08 16:54:15 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:15 --> Total execution time: 0.0376
INFO - 2024-10-08 16:54:15 --> Config Class Initialized
INFO - 2024-10-08 16:54:15 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:15 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:15 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:15 --> URI Class Initialized
INFO - 2024-10-08 16:54:15 --> Router Class Initialized
INFO - 2024-10-08 16:54:15 --> Output Class Initialized
INFO - 2024-10-08 16:54:15 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:15 --> Input Class Initialized
INFO - 2024-10-08 16:54:15 --> Language Class Initialized
INFO - 2024-10-08 16:54:15 --> Language Class Initialized
INFO - 2024-10-08 16:54:15 --> Config Class Initialized
INFO - 2024-10-08 16:54:15 --> Loader Class Initialized
INFO - 2024-10-08 16:54:15 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:15 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:15 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:15 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 16:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:15 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:15 --> Total execution time: 0.0370
INFO - 2024-10-08 16:54:16 --> Config Class Initialized
INFO - 2024-10-08 16:54:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:16 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:16 --> URI Class Initialized
INFO - 2024-10-08 16:54:16 --> Router Class Initialized
INFO - 2024-10-08 16:54:16 --> Output Class Initialized
INFO - 2024-10-08 16:54:16 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:16 --> Input Class Initialized
INFO - 2024-10-08 16:54:16 --> Language Class Initialized
INFO - 2024-10-08 16:54:16 --> Language Class Initialized
INFO - 2024-10-08 16:54:16 --> Config Class Initialized
INFO - 2024-10-08 16:54:16 --> Loader Class Initialized
INFO - 2024-10-08 16:54:16 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:16 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:16 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:54:16 --> Config Class Initialized
INFO - 2024-10-08 16:54:16 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:16 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:16 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:16 --> URI Class Initialized
INFO - 2024-10-08 16:54:16 --> Router Class Initialized
INFO - 2024-10-08 16:54:16 --> Output Class Initialized
INFO - 2024-10-08 16:54:16 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:16 --> Input Class Initialized
INFO - 2024-10-08 16:54:16 --> Language Class Initialized
INFO - 2024-10-08 16:54:16 --> Language Class Initialized
INFO - 2024-10-08 16:54:16 --> Config Class Initialized
INFO - 2024-10-08 16:54:16 --> Loader Class Initialized
INFO - 2024-10-08 16:54:16 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:16 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:16 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:16 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:16 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:16 --> Total execution time: 0.0758
INFO - 2024-10-08 16:54:19 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:19 --> Total execution time: 3.0928
INFO - 2024-10-08 16:54:23 --> Config Class Initialized
INFO - 2024-10-08 16:54:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:23 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:23 --> URI Class Initialized
INFO - 2024-10-08 16:54:23 --> Router Class Initialized
INFO - 2024-10-08 16:54:23 --> Output Class Initialized
INFO - 2024-10-08 16:54:23 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:23 --> Input Class Initialized
INFO - 2024-10-08 16:54:23 --> Language Class Initialized
INFO - 2024-10-08 16:54:23 --> Language Class Initialized
INFO - 2024-10-08 16:54:23 --> Config Class Initialized
INFO - 2024-10-08 16:54:23 --> Loader Class Initialized
INFO - 2024-10-08 16:54:23 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:23 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:23 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 16:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:23 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:23 --> Total execution time: 0.0445
INFO - 2024-10-08 16:54:23 --> Config Class Initialized
INFO - 2024-10-08 16:54:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:23 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:23 --> URI Class Initialized
INFO - 2024-10-08 16:54:23 --> Router Class Initialized
INFO - 2024-10-08 16:54:23 --> Output Class Initialized
INFO - 2024-10-08 16:54:23 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:23 --> Input Class Initialized
INFO - 2024-10-08 16:54:23 --> Language Class Initialized
INFO - 2024-10-08 16:54:23 --> Language Class Initialized
INFO - 2024-10-08 16:54:23 --> Config Class Initialized
INFO - 2024-10-08 16:54:23 --> Loader Class Initialized
INFO - 2024-10-08 16:54:23 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:23 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:23 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:23 --> Controller Class Initialized
INFO - 2024-10-08 16:54:28 --> Config Class Initialized
INFO - 2024-10-08 16:54:28 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:28 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:28 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:28 --> URI Class Initialized
INFO - 2024-10-08 16:54:28 --> Router Class Initialized
INFO - 2024-10-08 16:54:28 --> Output Class Initialized
INFO - 2024-10-08 16:54:28 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:28 --> Input Class Initialized
INFO - 2024-10-08 16:54:28 --> Language Class Initialized
INFO - 2024-10-08 16:54:28 --> Language Class Initialized
INFO - 2024-10-08 16:54:28 --> Config Class Initialized
INFO - 2024-10-08 16:54:28 --> Loader Class Initialized
INFO - 2024-10-08 16:54:28 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:28 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:28 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:28 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:28 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:28 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:54:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:28 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:28 --> Total execution time: 0.0340
INFO - 2024-10-08 16:54:30 --> Config Class Initialized
INFO - 2024-10-08 16:54:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:30 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:30 --> URI Class Initialized
INFO - 2024-10-08 16:54:30 --> Router Class Initialized
INFO - 2024-10-08 16:54:30 --> Output Class Initialized
INFO - 2024-10-08 16:54:30 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:30 --> Input Class Initialized
INFO - 2024-10-08 16:54:30 --> Language Class Initialized
INFO - 2024-10-08 16:54:30 --> Language Class Initialized
INFO - 2024-10-08 16:54:30 --> Config Class Initialized
INFO - 2024-10-08 16:54:30 --> Loader Class Initialized
INFO - 2024-10-08 16:54:30 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:30 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:30 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:30 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:30 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:30 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:54:33 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:33 --> Total execution time: 3.7276
INFO - 2024-10-08 16:54:34 --> Config Class Initialized
INFO - 2024-10-08 16:54:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:34 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:34 --> URI Class Initialized
INFO - 2024-10-08 16:54:34 --> Router Class Initialized
INFO - 2024-10-08 16:54:34 --> Output Class Initialized
INFO - 2024-10-08 16:54:34 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:34 --> Input Class Initialized
INFO - 2024-10-08 16:54:34 --> Language Class Initialized
INFO - 2024-10-08 16:54:34 --> Language Class Initialized
INFO - 2024-10-08 16:54:34 --> Config Class Initialized
INFO - 2024-10-08 16:54:34 --> Loader Class Initialized
INFO - 2024-10-08 16:54:34 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:34 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:34 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:34 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:34 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:34 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 16:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:54:34 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:34 --> Total execution time: 0.0913
INFO - 2024-10-08 16:54:37 --> Config Class Initialized
INFO - 2024-10-08 16:54:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:37 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:37 --> URI Class Initialized
INFO - 2024-10-08 16:54:37 --> Router Class Initialized
INFO - 2024-10-08 16:54:37 --> Output Class Initialized
INFO - 2024-10-08 16:54:37 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:37 --> Input Class Initialized
INFO - 2024-10-08 16:54:37 --> Language Class Initialized
INFO - 2024-10-08 16:54:37 --> Language Class Initialized
INFO - 2024-10-08 16:54:37 --> Config Class Initialized
INFO - 2024-10-08 16:54:37 --> Loader Class Initialized
INFO - 2024-10-08 16:54:37 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:37 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:37 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:37 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:37 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:37 --> Controller Class Initialized
INFO - 2024-10-08 16:54:37 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:37 --> Total execution time: 0.1071
INFO - 2024-10-08 16:54:44 --> Config Class Initialized
INFO - 2024-10-08 16:54:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:54:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:54:44 --> Utf8 Class Initialized
INFO - 2024-10-08 16:54:44 --> URI Class Initialized
INFO - 2024-10-08 16:54:44 --> Router Class Initialized
INFO - 2024-10-08 16:54:44 --> Output Class Initialized
INFO - 2024-10-08 16:54:44 --> Security Class Initialized
DEBUG - 2024-10-08 16:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:54:44 --> Input Class Initialized
INFO - 2024-10-08 16:54:44 --> Language Class Initialized
INFO - 2024-10-08 16:54:44 --> Language Class Initialized
INFO - 2024-10-08 16:54:44 --> Config Class Initialized
INFO - 2024-10-08 16:54:44 --> Loader Class Initialized
INFO - 2024-10-08 16:54:44 --> Helper loaded: url_helper
INFO - 2024-10-08 16:54:44 --> Helper loaded: file_helper
INFO - 2024-10-08 16:54:44 --> Helper loaded: form_helper
INFO - 2024-10-08 16:54:44 --> Helper loaded: my_helper
INFO - 2024-10-08 16:54:44 --> Database Driver Class Initialized
INFO - 2024-10-08 16:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:54:44 --> Controller Class Initialized
DEBUG - 2024-10-08 16:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:54:48 --> Final output sent to browser
DEBUG - 2024-10-08 16:54:48 --> Total execution time: 3.3274
INFO - 2024-10-08 16:55:08 --> Config Class Initialized
INFO - 2024-10-08 16:55:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:08 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:08 --> URI Class Initialized
INFO - 2024-10-08 16:55:08 --> Router Class Initialized
INFO - 2024-10-08 16:55:08 --> Output Class Initialized
INFO - 2024-10-08 16:55:08 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:08 --> Input Class Initialized
INFO - 2024-10-08 16:55:08 --> Language Class Initialized
INFO - 2024-10-08 16:55:08 --> Language Class Initialized
INFO - 2024-10-08 16:55:08 --> Config Class Initialized
INFO - 2024-10-08 16:55:08 --> Loader Class Initialized
INFO - 2024-10-08 16:55:08 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:08 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:08 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:08 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:08 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:08 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:11 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:11 --> Total execution time: 3.7536
INFO - 2024-10-08 16:55:25 --> Config Class Initialized
INFO - 2024-10-08 16:55:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:25 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:25 --> URI Class Initialized
INFO - 2024-10-08 16:55:25 --> Router Class Initialized
INFO - 2024-10-08 16:55:25 --> Output Class Initialized
INFO - 2024-10-08 16:55:25 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:25 --> Input Class Initialized
INFO - 2024-10-08 16:55:25 --> Language Class Initialized
INFO - 2024-10-08 16:55:25 --> Language Class Initialized
INFO - 2024-10-08 16:55:25 --> Config Class Initialized
INFO - 2024-10-08 16:55:25 --> Loader Class Initialized
INFO - 2024-10-08 16:55:25 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:25 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:25 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:25 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:25 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:25 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:31 --> Config Class Initialized
INFO - 2024-10-08 16:55:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:31 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:31 --> URI Class Initialized
INFO - 2024-10-08 16:55:31 --> Router Class Initialized
INFO - 2024-10-08 16:55:31 --> Output Class Initialized
INFO - 2024-10-08 16:55:31 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:31 --> Input Class Initialized
INFO - 2024-10-08 16:55:31 --> Language Class Initialized
INFO - 2024-10-08 16:55:31 --> Language Class Initialized
INFO - 2024-10-08 16:55:31 --> Config Class Initialized
INFO - 2024-10-08 16:55:31 --> Loader Class Initialized
INFO - 2024-10-08 16:55:31 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:31 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:31 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:31 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:31 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:31 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:32 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:32 --> Total execution time: 6.8771
INFO - 2024-10-08 16:55:35 --> Config Class Initialized
INFO - 2024-10-08 16:55:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:35 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:35 --> URI Class Initialized
INFO - 2024-10-08 16:55:35 --> Router Class Initialized
INFO - 2024-10-08 16:55:35 --> Output Class Initialized
INFO - 2024-10-08 16:55:35 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:35 --> Input Class Initialized
INFO - 2024-10-08 16:55:35 --> Language Class Initialized
INFO - 2024-10-08 16:55:35 --> Language Class Initialized
INFO - 2024-10-08 16:55:35 --> Config Class Initialized
INFO - 2024-10-08 16:55:35 --> Loader Class Initialized
INFO - 2024-10-08 16:55:35 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:35 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:35 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:35 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:35 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:35 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:40 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:40 --> Total execution time: 8.7332
INFO - 2024-10-08 16:55:42 --> Config Class Initialized
INFO - 2024-10-08 16:55:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:42 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:42 --> URI Class Initialized
INFO - 2024-10-08 16:55:42 --> Router Class Initialized
INFO - 2024-10-08 16:55:42 --> Output Class Initialized
INFO - 2024-10-08 16:55:42 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:42 --> Input Class Initialized
INFO - 2024-10-08 16:55:42 --> Language Class Initialized
INFO - 2024-10-08 16:55:42 --> Language Class Initialized
INFO - 2024-10-08 16:55:42 --> Config Class Initialized
INFO - 2024-10-08 16:55:42 --> Loader Class Initialized
INFO - 2024-10-08 16:55:42 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:42 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:42 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:42 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:42 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:42 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:42 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:42 --> Total execution time: 7.5054
INFO - 2024-10-08 16:55:44 --> Config Class Initialized
INFO - 2024-10-08 16:55:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:44 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:44 --> URI Class Initialized
INFO - 2024-10-08 16:55:44 --> Router Class Initialized
INFO - 2024-10-08 16:55:44 --> Output Class Initialized
INFO - 2024-10-08 16:55:44 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:44 --> Input Class Initialized
INFO - 2024-10-08 16:55:44 --> Language Class Initialized
INFO - 2024-10-08 16:55:44 --> Language Class Initialized
INFO - 2024-10-08 16:55:44 --> Config Class Initialized
INFO - 2024-10-08 16:55:44 --> Loader Class Initialized
INFO - 2024-10-08 16:55:44 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:44 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:44 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:44 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:44 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:44 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:55:50 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:50 --> Total execution time: 8.1021
INFO - 2024-10-08 16:55:52 --> Final output sent to browser
DEBUG - 2024-10-08 16:55:52 --> Total execution time: 7.8228
INFO - 2024-10-08 16:55:57 --> Config Class Initialized
INFO - 2024-10-08 16:55:57 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:55:57 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:55:57 --> Utf8 Class Initialized
INFO - 2024-10-08 16:55:57 --> URI Class Initialized
INFO - 2024-10-08 16:55:57 --> Router Class Initialized
INFO - 2024-10-08 16:55:57 --> Output Class Initialized
INFO - 2024-10-08 16:55:57 --> Security Class Initialized
DEBUG - 2024-10-08 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:55:57 --> Input Class Initialized
INFO - 2024-10-08 16:55:57 --> Language Class Initialized
INFO - 2024-10-08 16:55:57 --> Language Class Initialized
INFO - 2024-10-08 16:55:57 --> Config Class Initialized
INFO - 2024-10-08 16:55:57 --> Loader Class Initialized
INFO - 2024-10-08 16:55:57 --> Helper loaded: url_helper
INFO - 2024-10-08 16:55:57 --> Helper loaded: file_helper
INFO - 2024-10-08 16:55:57 --> Helper loaded: form_helper
INFO - 2024-10-08 16:55:57 --> Helper loaded: my_helper
INFO - 2024-10-08 16:55:57 --> Database Driver Class Initialized
INFO - 2024-10-08 16:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:55:57 --> Controller Class Initialized
DEBUG - 2024-10-08 16:55:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:56:04 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:04 --> Total execution time: 7.3097
INFO - 2024-10-08 16:56:25 --> Config Class Initialized
INFO - 2024-10-08 16:56:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:25 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:25 --> URI Class Initialized
INFO - 2024-10-08 16:56:25 --> Router Class Initialized
INFO - 2024-10-08 16:56:25 --> Output Class Initialized
INFO - 2024-10-08 16:56:25 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:25 --> Input Class Initialized
INFO - 2024-10-08 16:56:25 --> Language Class Initialized
INFO - 2024-10-08 16:56:25 --> Language Class Initialized
INFO - 2024-10-08 16:56:25 --> Config Class Initialized
INFO - 2024-10-08 16:56:25 --> Loader Class Initialized
INFO - 2024-10-08 16:56:25 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:25 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:25 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:25 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:25 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:25 --> Controller Class Initialized
DEBUG - 2024-10-08 16:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:56:25 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:26 --> Total execution time: 0.4125
INFO - 2024-10-08 16:56:31 --> Config Class Initialized
INFO - 2024-10-08 16:56:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:31 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:31 --> URI Class Initialized
INFO - 2024-10-08 16:56:31 --> Router Class Initialized
INFO - 2024-10-08 16:56:31 --> Output Class Initialized
INFO - 2024-10-08 16:56:31 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:31 --> Input Class Initialized
INFO - 2024-10-08 16:56:31 --> Language Class Initialized
INFO - 2024-10-08 16:56:31 --> Language Class Initialized
INFO - 2024-10-08 16:56:31 --> Config Class Initialized
INFO - 2024-10-08 16:56:31 --> Loader Class Initialized
INFO - 2024-10-08 16:56:31 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:31 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:31 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:31 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:31 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:31 --> Controller Class Initialized
DEBUG - 2024-10-08 16:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 16:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:56:32 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:32 --> Total execution time: 0.1989
INFO - 2024-10-08 16:56:34 --> Config Class Initialized
INFO - 2024-10-08 16:56:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:34 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:34 --> URI Class Initialized
INFO - 2024-10-08 16:56:34 --> Router Class Initialized
INFO - 2024-10-08 16:56:34 --> Output Class Initialized
INFO - 2024-10-08 16:56:34 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:34 --> Input Class Initialized
INFO - 2024-10-08 16:56:34 --> Language Class Initialized
INFO - 2024-10-08 16:56:34 --> Language Class Initialized
INFO - 2024-10-08 16:56:34 --> Config Class Initialized
INFO - 2024-10-08 16:56:34 --> Loader Class Initialized
INFO - 2024-10-08 16:56:34 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:34 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:34 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:34 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:34 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:34 --> Controller Class Initialized
INFO - 2024-10-08 16:56:34 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:34 --> Total execution time: 0.0448
INFO - 2024-10-08 16:56:40 --> Config Class Initialized
INFO - 2024-10-08 16:56:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:40 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:40 --> URI Class Initialized
INFO - 2024-10-08 16:56:40 --> Router Class Initialized
INFO - 2024-10-08 16:56:40 --> Output Class Initialized
INFO - 2024-10-08 16:56:40 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:40 --> Input Class Initialized
INFO - 2024-10-08 16:56:40 --> Language Class Initialized
INFO - 2024-10-08 16:56:40 --> Language Class Initialized
INFO - 2024-10-08 16:56:40 --> Config Class Initialized
INFO - 2024-10-08 16:56:40 --> Loader Class Initialized
INFO - 2024-10-08 16:56:40 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:40 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:40 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:40 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:40 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:40 --> Controller Class Initialized
INFO - 2024-10-08 16:56:40 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:40 --> Total execution time: 0.1204
INFO - 2024-10-08 16:56:48 --> Config Class Initialized
INFO - 2024-10-08 16:56:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:48 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:48 --> URI Class Initialized
INFO - 2024-10-08 16:56:48 --> Router Class Initialized
INFO - 2024-10-08 16:56:48 --> Output Class Initialized
INFO - 2024-10-08 16:56:48 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:48 --> Input Class Initialized
INFO - 2024-10-08 16:56:48 --> Language Class Initialized
INFO - 2024-10-08 16:56:48 --> Language Class Initialized
INFO - 2024-10-08 16:56:48 --> Config Class Initialized
INFO - 2024-10-08 16:56:48 --> Loader Class Initialized
INFO - 2024-10-08 16:56:48 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:48 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:48 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:48 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:48 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:48 --> Controller Class Initialized
DEBUG - 2024-10-08 16:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:56:48 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:48 --> Total execution time: 0.1047
INFO - 2024-10-08 16:56:50 --> Config Class Initialized
INFO - 2024-10-08 16:56:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:50 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:50 --> URI Class Initialized
INFO - 2024-10-08 16:56:50 --> Router Class Initialized
INFO - 2024-10-08 16:56:50 --> Output Class Initialized
INFO - 2024-10-08 16:56:50 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:50 --> Input Class Initialized
INFO - 2024-10-08 16:56:50 --> Language Class Initialized
INFO - 2024-10-08 16:56:50 --> Language Class Initialized
INFO - 2024-10-08 16:56:50 --> Config Class Initialized
INFO - 2024-10-08 16:56:50 --> Loader Class Initialized
INFO - 2024-10-08 16:56:50 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:50 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:50 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:50 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:50 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:50 --> Controller Class Initialized
DEBUG - 2024-10-08 16:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 16:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:56:50 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:50 --> Total execution time: 0.0354
INFO - 2024-10-08 16:56:51 --> Config Class Initialized
INFO - 2024-10-08 16:56:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:51 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:51 --> URI Class Initialized
INFO - 2024-10-08 16:56:51 --> Router Class Initialized
INFO - 2024-10-08 16:56:51 --> Output Class Initialized
INFO - 2024-10-08 16:56:51 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:51 --> Input Class Initialized
INFO - 2024-10-08 16:56:51 --> Language Class Initialized
INFO - 2024-10-08 16:56:51 --> Language Class Initialized
INFO - 2024-10-08 16:56:51 --> Config Class Initialized
INFO - 2024-10-08 16:56:51 --> Loader Class Initialized
INFO - 2024-10-08 16:56:51 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:51 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:51 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:51 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:51 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:51 --> Controller Class Initialized
INFO - 2024-10-08 16:56:52 --> Config Class Initialized
INFO - 2024-10-08 16:56:52 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:52 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:52 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:52 --> URI Class Initialized
INFO - 2024-10-08 16:56:52 --> Router Class Initialized
INFO - 2024-10-08 16:56:52 --> Output Class Initialized
INFO - 2024-10-08 16:56:52 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:52 --> Input Class Initialized
INFO - 2024-10-08 16:56:52 --> Language Class Initialized
INFO - 2024-10-08 16:56:52 --> Language Class Initialized
INFO - 2024-10-08 16:56:52 --> Config Class Initialized
INFO - 2024-10-08 16:56:52 --> Loader Class Initialized
INFO - 2024-10-08 16:56:52 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:52 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:52 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:52 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:52 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:52 --> Controller Class Initialized
INFO - 2024-10-08 16:56:52 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:52 --> Total execution time: 0.0805
INFO - 2024-10-08 16:56:56 --> Config Class Initialized
INFO - 2024-10-08 16:56:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:56:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:56:56 --> Utf8 Class Initialized
INFO - 2024-10-08 16:56:56 --> URI Class Initialized
INFO - 2024-10-08 16:56:56 --> Router Class Initialized
INFO - 2024-10-08 16:56:56 --> Output Class Initialized
INFO - 2024-10-08 16:56:56 --> Security Class Initialized
DEBUG - 2024-10-08 16:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:56:56 --> Input Class Initialized
INFO - 2024-10-08 16:56:56 --> Language Class Initialized
INFO - 2024-10-08 16:56:56 --> Language Class Initialized
INFO - 2024-10-08 16:56:56 --> Config Class Initialized
INFO - 2024-10-08 16:56:56 --> Loader Class Initialized
INFO - 2024-10-08 16:56:56 --> Helper loaded: url_helper
INFO - 2024-10-08 16:56:56 --> Helper loaded: file_helper
INFO - 2024-10-08 16:56:56 --> Helper loaded: form_helper
INFO - 2024-10-08 16:56:56 --> Helper loaded: my_helper
INFO - 2024-10-08 16:56:56 --> Database Driver Class Initialized
INFO - 2024-10-08 16:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:56:56 --> Controller Class Initialized
INFO - 2024-10-08 16:56:56 --> Final output sent to browser
DEBUG - 2024-10-08 16:56:56 --> Total execution time: 0.0934
INFO - 2024-10-08 16:57:00 --> Config Class Initialized
INFO - 2024-10-08 16:57:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:00 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:00 --> URI Class Initialized
INFO - 2024-10-08 16:57:00 --> Router Class Initialized
INFO - 2024-10-08 16:57:00 --> Output Class Initialized
INFO - 2024-10-08 16:57:00 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:00 --> Input Class Initialized
INFO - 2024-10-08 16:57:00 --> Language Class Initialized
INFO - 2024-10-08 16:57:00 --> Language Class Initialized
INFO - 2024-10-08 16:57:00 --> Config Class Initialized
INFO - 2024-10-08 16:57:00 --> Loader Class Initialized
INFO - 2024-10-08 16:57:00 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:00 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:00 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:00 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:00 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:00 --> Controller Class Initialized
INFO - 2024-10-08 16:57:00 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:00 --> Total execution time: 0.0907
INFO - 2024-10-08 16:57:05 --> Config Class Initialized
INFO - 2024-10-08 16:57:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:05 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:05 --> URI Class Initialized
INFO - 2024-10-08 16:57:05 --> Router Class Initialized
INFO - 2024-10-08 16:57:05 --> Output Class Initialized
INFO - 2024-10-08 16:57:05 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:05 --> Input Class Initialized
INFO - 2024-10-08 16:57:05 --> Language Class Initialized
INFO - 2024-10-08 16:57:05 --> Language Class Initialized
INFO - 2024-10-08 16:57:05 --> Config Class Initialized
INFO - 2024-10-08 16:57:05 --> Loader Class Initialized
INFO - 2024-10-08 16:57:05 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:05 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:05 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:05 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:05 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:05 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:57:08 --> Config Class Initialized
INFO - 2024-10-08 16:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:08 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:08 --> URI Class Initialized
INFO - 2024-10-08 16:57:08 --> Router Class Initialized
INFO - 2024-10-08 16:57:08 --> Output Class Initialized
INFO - 2024-10-08 16:57:08 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:08 --> Input Class Initialized
INFO - 2024-10-08 16:57:08 --> Language Class Initialized
INFO - 2024-10-08 16:57:08 --> Language Class Initialized
INFO - 2024-10-08 16:57:08 --> Config Class Initialized
INFO - 2024-10-08 16:57:08 --> Loader Class Initialized
INFO - 2024-10-08 16:57:08 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:08 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:08 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:08 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:08 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:09 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:09 --> Total execution time: 3.4778
INFO - 2024-10-08 16:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:09 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:57:11 --> Config Class Initialized
INFO - 2024-10-08 16:57:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:11 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:11 --> URI Class Initialized
INFO - 2024-10-08 16:57:11 --> Router Class Initialized
INFO - 2024-10-08 16:57:11 --> Output Class Initialized
INFO - 2024-10-08 16:57:11 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:11 --> Input Class Initialized
INFO - 2024-10-08 16:57:11 --> Language Class Initialized
INFO - 2024-10-08 16:57:11 --> Language Class Initialized
INFO - 2024-10-08 16:57:11 --> Config Class Initialized
INFO - 2024-10-08 16:57:11 --> Loader Class Initialized
INFO - 2024-10-08 16:57:11 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:11 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:11 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:11 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:11 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:12 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:12 --> Total execution time: 3.9975
INFO - 2024-10-08 16:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:12 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:57:14 --> Config Class Initialized
INFO - 2024-10-08 16:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:14 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:14 --> URI Class Initialized
INFO - 2024-10-08 16:57:14 --> Router Class Initialized
INFO - 2024-10-08 16:57:14 --> Output Class Initialized
INFO - 2024-10-08 16:57:14 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:14 --> Input Class Initialized
INFO - 2024-10-08 16:57:14 --> Language Class Initialized
INFO - 2024-10-08 16:57:14 --> Language Class Initialized
INFO - 2024-10-08 16:57:14 --> Config Class Initialized
INFO - 2024-10-08 16:57:14 --> Loader Class Initialized
INFO - 2024-10-08 16:57:14 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:14 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:14 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:14 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:14 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:14 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:57:14 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:14 --> Total execution time: 0.1001
INFO - 2024-10-08 16:57:15 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:15 --> Total execution time: 4.0919
INFO - 2024-10-08 16:57:36 --> Config Class Initialized
INFO - 2024-10-08 16:57:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:36 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:36 --> URI Class Initialized
INFO - 2024-10-08 16:57:36 --> Router Class Initialized
INFO - 2024-10-08 16:57:36 --> Output Class Initialized
INFO - 2024-10-08 16:57:36 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:36 --> Input Class Initialized
INFO - 2024-10-08 16:57:36 --> Language Class Initialized
INFO - 2024-10-08 16:57:36 --> Language Class Initialized
INFO - 2024-10-08 16:57:36 --> Config Class Initialized
INFO - 2024-10-08 16:57:36 --> Loader Class Initialized
INFO - 2024-10-08 16:57:36 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:36 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:36 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:36 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:36 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:36 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 16:57:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:57:36 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:36 --> Total execution time: 0.0379
INFO - 2024-10-08 16:57:38 --> Config Class Initialized
INFO - 2024-10-08 16:57:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:57:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:57:38 --> Utf8 Class Initialized
INFO - 2024-10-08 16:57:38 --> URI Class Initialized
INFO - 2024-10-08 16:57:38 --> Router Class Initialized
INFO - 2024-10-08 16:57:38 --> Output Class Initialized
INFO - 2024-10-08 16:57:38 --> Security Class Initialized
DEBUG - 2024-10-08 16:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:57:38 --> Input Class Initialized
INFO - 2024-10-08 16:57:38 --> Language Class Initialized
INFO - 2024-10-08 16:57:38 --> Language Class Initialized
INFO - 2024-10-08 16:57:38 --> Config Class Initialized
INFO - 2024-10-08 16:57:38 --> Loader Class Initialized
INFO - 2024-10-08 16:57:38 --> Helper loaded: url_helper
INFO - 2024-10-08 16:57:38 --> Helper loaded: file_helper
INFO - 2024-10-08 16:57:38 --> Helper loaded: form_helper
INFO - 2024-10-08 16:57:38 --> Helper loaded: my_helper
INFO - 2024-10-08 16:57:38 --> Database Driver Class Initialized
INFO - 2024-10-08 16:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:57:38 --> Controller Class Initialized
DEBUG - 2024-10-08 16:57:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:57:41 --> Final output sent to browser
DEBUG - 2024-10-08 16:57:41 --> Total execution time: 2.9102
INFO - 2024-10-08 16:58:01 --> Config Class Initialized
INFO - 2024-10-08 16:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:01 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:01 --> URI Class Initialized
INFO - 2024-10-08 16:58:01 --> Router Class Initialized
INFO - 2024-10-08 16:58:01 --> Output Class Initialized
INFO - 2024-10-08 16:58:01 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:01 --> Input Class Initialized
INFO - 2024-10-08 16:58:01 --> Language Class Initialized
INFO - 2024-10-08 16:58:01 --> Language Class Initialized
INFO - 2024-10-08 16:58:01 --> Config Class Initialized
INFO - 2024-10-08 16:58:01 --> Loader Class Initialized
INFO - 2024-10-08 16:58:01 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:01 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:01 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:01 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:01 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:01 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:58:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:58:01 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:01 --> Total execution time: 0.1592
INFO - 2024-10-08 16:58:03 --> Config Class Initialized
INFO - 2024-10-08 16:58:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:03 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:03 --> URI Class Initialized
INFO - 2024-10-08 16:58:03 --> Router Class Initialized
INFO - 2024-10-08 16:58:03 --> Output Class Initialized
INFO - 2024-10-08 16:58:03 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:03 --> Input Class Initialized
INFO - 2024-10-08 16:58:03 --> Language Class Initialized
INFO - 2024-10-08 16:58:03 --> Language Class Initialized
INFO - 2024-10-08 16:58:03 --> Config Class Initialized
INFO - 2024-10-08 16:58:03 --> Loader Class Initialized
INFO - 2024-10-08 16:58:03 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:03 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:03 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 16:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:58:03 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:03 --> Total execution time: 0.0431
INFO - 2024-10-08 16:58:03 --> Config Class Initialized
INFO - 2024-10-08 16:58:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:03 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:03 --> URI Class Initialized
INFO - 2024-10-08 16:58:03 --> Router Class Initialized
INFO - 2024-10-08 16:58:03 --> Output Class Initialized
INFO - 2024-10-08 16:58:03 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:03 --> Input Class Initialized
INFO - 2024-10-08 16:58:03 --> Language Class Initialized
INFO - 2024-10-08 16:58:03 --> Language Class Initialized
INFO - 2024-10-08 16:58:03 --> Config Class Initialized
INFO - 2024-10-08 16:58:03 --> Loader Class Initialized
INFO - 2024-10-08 16:58:03 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:03 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:03 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:03 --> Controller Class Initialized
INFO - 2024-10-08 16:58:05 --> Config Class Initialized
INFO - 2024-10-08 16:58:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:05 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:05 --> URI Class Initialized
INFO - 2024-10-08 16:58:05 --> Router Class Initialized
INFO - 2024-10-08 16:58:05 --> Output Class Initialized
INFO - 2024-10-08 16:58:05 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:05 --> Input Class Initialized
INFO - 2024-10-08 16:58:05 --> Language Class Initialized
INFO - 2024-10-08 16:58:05 --> Language Class Initialized
INFO - 2024-10-08 16:58:05 --> Config Class Initialized
INFO - 2024-10-08 16:58:05 --> Loader Class Initialized
INFO - 2024-10-08 16:58:05 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:05 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:05 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:05 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:05 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:05 --> Controller Class Initialized
INFO - 2024-10-08 16:58:05 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:05 --> Total execution time: 0.0554
INFO - 2024-10-08 16:58:24 --> Config Class Initialized
INFO - 2024-10-08 16:58:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:24 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:24 --> URI Class Initialized
INFO - 2024-10-08 16:58:24 --> Router Class Initialized
INFO - 2024-10-08 16:58:24 --> Output Class Initialized
INFO - 2024-10-08 16:58:24 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:24 --> Input Class Initialized
INFO - 2024-10-08 16:58:24 --> Language Class Initialized
INFO - 2024-10-08 16:58:24 --> Language Class Initialized
INFO - 2024-10-08 16:58:24 --> Config Class Initialized
INFO - 2024-10-08 16:58:24 --> Loader Class Initialized
INFO - 2024-10-08 16:58:24 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:24 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:24 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:24 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:24 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:24 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:58:26 --> Config Class Initialized
INFO - 2024-10-08 16:58:26 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:26 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:26 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:26 --> URI Class Initialized
INFO - 2024-10-08 16:58:26 --> Router Class Initialized
INFO - 2024-10-08 16:58:26 --> Output Class Initialized
INFO - 2024-10-08 16:58:26 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:26 --> Input Class Initialized
INFO - 2024-10-08 16:58:26 --> Language Class Initialized
INFO - 2024-10-08 16:58:26 --> Language Class Initialized
INFO - 2024-10-08 16:58:26 --> Config Class Initialized
INFO - 2024-10-08 16:58:26 --> Loader Class Initialized
INFO - 2024-10-08 16:58:27 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:27 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:27 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:27 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:27 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:27 --> Controller Class Initialized
INFO - 2024-10-08 16:58:27 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:27 --> Total execution time: 0.4916
INFO - 2024-10-08 16:58:27 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:27 --> Total execution time: 3.1485
INFO - 2024-10-08 16:58:31 --> Config Class Initialized
INFO - 2024-10-08 16:58:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:31 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:31 --> URI Class Initialized
INFO - 2024-10-08 16:58:31 --> Router Class Initialized
INFO - 2024-10-08 16:58:31 --> Output Class Initialized
INFO - 2024-10-08 16:58:31 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:31 --> Input Class Initialized
INFO - 2024-10-08 16:58:31 --> Language Class Initialized
INFO - 2024-10-08 16:58:31 --> Language Class Initialized
INFO - 2024-10-08 16:58:31 --> Config Class Initialized
INFO - 2024-10-08 16:58:31 --> Loader Class Initialized
INFO - 2024-10-08 16:58:31 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:31 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:31 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:31 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:31 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:31 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 16:58:34 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:34 --> Total execution time: 2.9804
INFO - 2024-10-08 16:58:35 --> Config Class Initialized
INFO - 2024-10-08 16:58:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:35 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:35 --> URI Class Initialized
INFO - 2024-10-08 16:58:35 --> Router Class Initialized
INFO - 2024-10-08 16:58:35 --> Output Class Initialized
INFO - 2024-10-08 16:58:35 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:35 --> Input Class Initialized
INFO - 2024-10-08 16:58:35 --> Language Class Initialized
INFO - 2024-10-08 16:58:35 --> Language Class Initialized
INFO - 2024-10-08 16:58:35 --> Config Class Initialized
INFO - 2024-10-08 16:58:35 --> Loader Class Initialized
INFO - 2024-10-08 16:58:35 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:35 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:35 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:35 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:35 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:35 --> Controller Class Initialized
INFO - 2024-10-08 16:58:36 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:36 --> Total execution time: 0.5325
INFO - 2024-10-08 16:58:46 --> Config Class Initialized
INFO - 2024-10-08 16:58:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:46 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:46 --> URI Class Initialized
INFO - 2024-10-08 16:58:46 --> Router Class Initialized
INFO - 2024-10-08 16:58:46 --> Output Class Initialized
INFO - 2024-10-08 16:58:46 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:46 --> Input Class Initialized
INFO - 2024-10-08 16:58:46 --> Language Class Initialized
INFO - 2024-10-08 16:58:46 --> Language Class Initialized
INFO - 2024-10-08 16:58:46 --> Config Class Initialized
INFO - 2024-10-08 16:58:46 --> Loader Class Initialized
INFO - 2024-10-08 16:58:46 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:46 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:46 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:46 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:46 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:46 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 16:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:58:46 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:46 --> Total execution time: 0.0411
INFO - 2024-10-08 16:58:51 --> Config Class Initialized
INFO - 2024-10-08 16:58:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:51 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:51 --> URI Class Initialized
INFO - 2024-10-08 16:58:51 --> Router Class Initialized
INFO - 2024-10-08 16:58:51 --> Output Class Initialized
INFO - 2024-10-08 16:58:51 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:51 --> Input Class Initialized
INFO - 2024-10-08 16:58:51 --> Language Class Initialized
INFO - 2024-10-08 16:58:51 --> Language Class Initialized
INFO - 2024-10-08 16:58:51 --> Config Class Initialized
INFO - 2024-10-08 16:58:51 --> Loader Class Initialized
INFO - 2024-10-08 16:58:51 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:51 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:51 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:51 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:51 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:51 --> Controller Class Initialized
DEBUG - 2024-10-08 16:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 16:58:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 16:58:51 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:51 --> Total execution time: 0.0340
INFO - 2024-10-08 16:58:53 --> Config Class Initialized
INFO - 2024-10-08 16:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-08 16:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-08 16:58:53 --> Utf8 Class Initialized
INFO - 2024-10-08 16:58:53 --> URI Class Initialized
INFO - 2024-10-08 16:58:53 --> Router Class Initialized
INFO - 2024-10-08 16:58:53 --> Output Class Initialized
INFO - 2024-10-08 16:58:53 --> Security Class Initialized
DEBUG - 2024-10-08 16:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 16:58:53 --> Input Class Initialized
INFO - 2024-10-08 16:58:53 --> Language Class Initialized
INFO - 2024-10-08 16:58:53 --> Language Class Initialized
INFO - 2024-10-08 16:58:53 --> Config Class Initialized
INFO - 2024-10-08 16:58:53 --> Loader Class Initialized
INFO - 2024-10-08 16:58:53 --> Helper loaded: url_helper
INFO - 2024-10-08 16:58:53 --> Helper loaded: file_helper
INFO - 2024-10-08 16:58:53 --> Helper loaded: form_helper
INFO - 2024-10-08 16:58:53 --> Helper loaded: my_helper
INFO - 2024-10-08 16:58:53 --> Database Driver Class Initialized
INFO - 2024-10-08 16:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 16:58:53 --> Controller Class Initialized
INFO - 2024-10-08 16:58:53 --> Final output sent to browser
DEBUG - 2024-10-08 16:58:53 --> Total execution time: 0.0334
INFO - 2024-10-08 17:01:56 --> Config Class Initialized
INFO - 2024-10-08 17:01:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:01:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:01:56 --> Utf8 Class Initialized
INFO - 2024-10-08 17:01:56 --> URI Class Initialized
INFO - 2024-10-08 17:01:56 --> Router Class Initialized
INFO - 2024-10-08 17:01:56 --> Output Class Initialized
INFO - 2024-10-08 17:01:56 --> Security Class Initialized
DEBUG - 2024-10-08 17:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:01:56 --> Input Class Initialized
INFO - 2024-10-08 17:01:56 --> Language Class Initialized
INFO - 2024-10-08 17:01:56 --> Language Class Initialized
INFO - 2024-10-08 17:01:56 --> Config Class Initialized
INFO - 2024-10-08 17:01:56 --> Loader Class Initialized
INFO - 2024-10-08 17:01:56 --> Helper loaded: url_helper
INFO - 2024-10-08 17:01:56 --> Helper loaded: file_helper
INFO - 2024-10-08 17:01:56 --> Helper loaded: form_helper
INFO - 2024-10-08 17:01:56 --> Helper loaded: my_helper
INFO - 2024-10-08 17:01:56 --> Database Driver Class Initialized
INFO - 2024-10-08 17:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:01:56 --> Controller Class Initialized
INFO - 2024-10-08 17:01:56 --> Final output sent to browser
DEBUG - 2024-10-08 17:01:56 --> Total execution time: 0.0757
INFO - 2024-10-08 17:01:59 --> Config Class Initialized
INFO - 2024-10-08 17:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:01:59 --> Utf8 Class Initialized
INFO - 2024-10-08 17:01:59 --> URI Class Initialized
INFO - 2024-10-08 17:01:59 --> Router Class Initialized
INFO - 2024-10-08 17:01:59 --> Output Class Initialized
INFO - 2024-10-08 17:01:59 --> Security Class Initialized
DEBUG - 2024-10-08 17:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:01:59 --> Input Class Initialized
INFO - 2024-10-08 17:01:59 --> Language Class Initialized
INFO - 2024-10-08 17:01:59 --> Language Class Initialized
INFO - 2024-10-08 17:01:59 --> Config Class Initialized
INFO - 2024-10-08 17:01:59 --> Loader Class Initialized
INFO - 2024-10-08 17:01:59 --> Helper loaded: url_helper
INFO - 2024-10-08 17:01:59 --> Helper loaded: file_helper
INFO - 2024-10-08 17:01:59 --> Helper loaded: form_helper
INFO - 2024-10-08 17:01:59 --> Helper loaded: my_helper
INFO - 2024-10-08 17:01:59 --> Database Driver Class Initialized
INFO - 2024-10-08 17:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:01:59 --> Controller Class Initialized
INFO - 2024-10-08 17:01:59 --> Final output sent to browser
DEBUG - 2024-10-08 17:01:59 --> Total execution time: 0.0855
INFO - 2024-10-08 17:02:00 --> Config Class Initialized
INFO - 2024-10-08 17:02:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:00 --> URI Class Initialized
INFO - 2024-10-08 17:02:00 --> Router Class Initialized
INFO - 2024-10-08 17:02:00 --> Output Class Initialized
INFO - 2024-10-08 17:02:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:00 --> Input Class Initialized
INFO - 2024-10-08 17:02:00 --> Language Class Initialized
INFO - 2024-10-08 17:02:00 --> Language Class Initialized
INFO - 2024-10-08 17:02:00 --> Config Class Initialized
INFO - 2024-10-08 17:02:00 --> Loader Class Initialized
INFO - 2024-10-08 17:02:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:00 --> Controller Class Initialized
INFO - 2024-10-08 17:02:00 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:00 --> Total execution time: 0.1055
INFO - 2024-10-08 17:02:03 --> Config Class Initialized
INFO - 2024-10-08 17:02:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:03 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:03 --> URI Class Initialized
INFO - 2024-10-08 17:02:03 --> Router Class Initialized
INFO - 2024-10-08 17:02:03 --> Output Class Initialized
INFO - 2024-10-08 17:02:03 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:03 --> Input Class Initialized
INFO - 2024-10-08 17:02:03 --> Language Class Initialized
INFO - 2024-10-08 17:02:03 --> Language Class Initialized
INFO - 2024-10-08 17:02:03 --> Config Class Initialized
INFO - 2024-10-08 17:02:03 --> Loader Class Initialized
INFO - 2024-10-08 17:02:03 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:03 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:03 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:03 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:03 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:03 --> Controller Class Initialized
DEBUG - 2024-10-08 17:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:02:03 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:03 --> Total execution time: 0.0443
INFO - 2024-10-08 17:02:09 --> Config Class Initialized
INFO - 2024-10-08 17:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:09 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:09 --> URI Class Initialized
INFO - 2024-10-08 17:02:09 --> Router Class Initialized
INFO - 2024-10-08 17:02:09 --> Output Class Initialized
INFO - 2024-10-08 17:02:09 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:09 --> Input Class Initialized
INFO - 2024-10-08 17:02:09 --> Language Class Initialized
INFO - 2024-10-08 17:02:09 --> Language Class Initialized
INFO - 2024-10-08 17:02:09 --> Config Class Initialized
INFO - 2024-10-08 17:02:09 --> Loader Class Initialized
INFO - 2024-10-08 17:02:09 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:09 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:09 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:09 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:09 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:09 --> Controller Class Initialized
DEBUG - 2024-10-08 17:02:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:02:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:02:09 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:09 --> Total execution time: 0.0428
INFO - 2024-10-08 17:02:23 --> Config Class Initialized
INFO - 2024-10-08 17:02:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:23 --> URI Class Initialized
INFO - 2024-10-08 17:02:23 --> Router Class Initialized
INFO - 2024-10-08 17:02:23 --> Output Class Initialized
INFO - 2024-10-08 17:02:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:23 --> Input Class Initialized
INFO - 2024-10-08 17:02:23 --> Language Class Initialized
INFO - 2024-10-08 17:02:23 --> Language Class Initialized
INFO - 2024-10-08 17:02:23 --> Config Class Initialized
INFO - 2024-10-08 17:02:23 --> Loader Class Initialized
INFO - 2024-10-08 17:02:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:23 --> Controller Class Initialized
DEBUG - 2024-10-08 17:02:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:02:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:02:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:23 --> Total execution time: 0.0750
INFO - 2024-10-08 17:02:25 --> Config Class Initialized
INFO - 2024-10-08 17:02:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:25 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:25 --> URI Class Initialized
INFO - 2024-10-08 17:02:25 --> Router Class Initialized
INFO - 2024-10-08 17:02:25 --> Output Class Initialized
INFO - 2024-10-08 17:02:25 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:25 --> Input Class Initialized
INFO - 2024-10-08 17:02:25 --> Language Class Initialized
INFO - 2024-10-08 17:02:25 --> Language Class Initialized
INFO - 2024-10-08 17:02:25 --> Config Class Initialized
INFO - 2024-10-08 17:02:25 --> Loader Class Initialized
INFO - 2024-10-08 17:02:25 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:25 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:25 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:25 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:25 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:25 --> Controller Class Initialized
DEBUG - 2024-10-08 17:02:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:02:30 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:30 --> Total execution time: 4.9943
INFO - 2024-10-08 17:02:58 --> Config Class Initialized
INFO - 2024-10-08 17:02:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:02:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:02:58 --> Utf8 Class Initialized
INFO - 2024-10-08 17:02:58 --> URI Class Initialized
INFO - 2024-10-08 17:02:58 --> Router Class Initialized
INFO - 2024-10-08 17:02:58 --> Output Class Initialized
INFO - 2024-10-08 17:02:58 --> Security Class Initialized
DEBUG - 2024-10-08 17:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:02:58 --> Input Class Initialized
INFO - 2024-10-08 17:02:58 --> Language Class Initialized
INFO - 2024-10-08 17:02:58 --> Language Class Initialized
INFO - 2024-10-08 17:02:58 --> Config Class Initialized
INFO - 2024-10-08 17:02:58 --> Loader Class Initialized
INFO - 2024-10-08 17:02:58 --> Helper loaded: url_helper
INFO - 2024-10-08 17:02:58 --> Helper loaded: file_helper
INFO - 2024-10-08 17:02:58 --> Helper loaded: form_helper
INFO - 2024-10-08 17:02:58 --> Helper loaded: my_helper
INFO - 2024-10-08 17:02:58 --> Database Driver Class Initialized
INFO - 2024-10-08 17:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:02:58 --> Controller Class Initialized
DEBUG - 2024-10-08 17:02:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-10-08 17:02:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:02:58 --> Final output sent to browser
DEBUG - 2024-10-08 17:02:58 --> Total execution time: 0.0360
INFO - 2024-10-08 17:04:30 --> Config Class Initialized
INFO - 2024-10-08 17:04:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:30 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:30 --> URI Class Initialized
INFO - 2024-10-08 17:04:30 --> Router Class Initialized
INFO - 2024-10-08 17:04:30 --> Output Class Initialized
INFO - 2024-10-08 17:04:30 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:30 --> Input Class Initialized
INFO - 2024-10-08 17:04:30 --> Language Class Initialized
INFO - 2024-10-08 17:04:30 --> Language Class Initialized
INFO - 2024-10-08 17:04:30 --> Config Class Initialized
INFO - 2024-10-08 17:04:30 --> Loader Class Initialized
INFO - 2024-10-08 17:04:30 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:30 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:30 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:30 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:30 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:30 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:30 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:30 --> Total execution time: 0.0430
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:36 --> URI Class Initialized
INFO - 2024-10-08 17:04:36 --> Router Class Initialized
INFO - 2024-10-08 17:04:36 --> Output Class Initialized
INFO - 2024-10-08 17:04:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:36 --> Input Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Loader Class Initialized
INFO - 2024-10-08 17:04:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:36 --> Controller Class Initialized
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:36 --> URI Class Initialized
INFO - 2024-10-08 17:04:36 --> Router Class Initialized
INFO - 2024-10-08 17:04:36 --> Output Class Initialized
INFO - 2024-10-08 17:04:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:36 --> Input Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Loader Class Initialized
INFO - 2024-10-08 17:04:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:36 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:36 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:36 --> Total execution time: 0.0409
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:36 --> URI Class Initialized
INFO - 2024-10-08 17:04:36 --> Router Class Initialized
INFO - 2024-10-08 17:04:36 --> Output Class Initialized
INFO - 2024-10-08 17:04:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:36 --> Input Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Language Class Initialized
INFO - 2024-10-08 17:04:36 --> Config Class Initialized
INFO - 2024-10-08 17:04:36 --> Loader Class Initialized
INFO - 2024-10-08 17:04:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:36 --> Controller Class Initialized
INFO - 2024-10-08 17:04:37 --> Config Class Initialized
INFO - 2024-10-08 17:04:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:37 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:37 --> URI Class Initialized
INFO - 2024-10-08 17:04:37 --> Router Class Initialized
INFO - 2024-10-08 17:04:37 --> Output Class Initialized
INFO - 2024-10-08 17:04:37 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:37 --> Input Class Initialized
INFO - 2024-10-08 17:04:37 --> Language Class Initialized
INFO - 2024-10-08 17:04:37 --> Language Class Initialized
INFO - 2024-10-08 17:04:37 --> Config Class Initialized
INFO - 2024-10-08 17:04:37 --> Loader Class Initialized
INFO - 2024-10-08 17:04:37 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:37 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:37 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:37 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:37 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:37 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:04:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:37 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:37 --> Total execution time: 0.0700
INFO - 2024-10-08 17:04:39 --> Config Class Initialized
INFO - 2024-10-08 17:04:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:39 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:39 --> URI Class Initialized
INFO - 2024-10-08 17:04:39 --> Router Class Initialized
INFO - 2024-10-08 17:04:39 --> Output Class Initialized
INFO - 2024-10-08 17:04:39 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:39 --> Input Class Initialized
INFO - 2024-10-08 17:04:39 --> Language Class Initialized
INFO - 2024-10-08 17:04:39 --> Language Class Initialized
INFO - 2024-10-08 17:04:39 --> Config Class Initialized
INFO - 2024-10-08 17:04:39 --> Loader Class Initialized
INFO - 2024-10-08 17:04:39 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:39 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:39 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:39 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:39 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:39 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:39 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:39 --> Total execution time: 0.0529
INFO - 2024-10-08 17:04:40 --> Config Class Initialized
INFO - 2024-10-08 17:04:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:40 --> URI Class Initialized
INFO - 2024-10-08 17:04:40 --> Router Class Initialized
INFO - 2024-10-08 17:04:40 --> Output Class Initialized
INFO - 2024-10-08 17:04:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:40 --> Input Class Initialized
INFO - 2024-10-08 17:04:40 --> Language Class Initialized
INFO - 2024-10-08 17:04:40 --> Language Class Initialized
INFO - 2024-10-08 17:04:40 --> Config Class Initialized
INFO - 2024-10-08 17:04:40 --> Loader Class Initialized
INFO - 2024-10-08 17:04:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:40 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:40 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:40 --> Total execution time: 0.0340
INFO - 2024-10-08 17:04:40 --> Config Class Initialized
INFO - 2024-10-08 17:04:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:40 --> URI Class Initialized
INFO - 2024-10-08 17:04:40 --> Router Class Initialized
INFO - 2024-10-08 17:04:40 --> Output Class Initialized
INFO - 2024-10-08 17:04:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:40 --> Input Class Initialized
INFO - 2024-10-08 17:04:40 --> Language Class Initialized
INFO - 2024-10-08 17:04:40 --> Language Class Initialized
INFO - 2024-10-08 17:04:40 --> Config Class Initialized
INFO - 2024-10-08 17:04:40 --> Loader Class Initialized
INFO - 2024-10-08 17:04:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:40 --> Controller Class Initialized
INFO - 2024-10-08 17:04:41 --> Config Class Initialized
INFO - 2024-10-08 17:04:41 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:41 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:41 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:41 --> URI Class Initialized
INFO - 2024-10-08 17:04:41 --> Router Class Initialized
INFO - 2024-10-08 17:04:41 --> Output Class Initialized
INFO - 2024-10-08 17:04:41 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:41 --> Input Class Initialized
INFO - 2024-10-08 17:04:41 --> Language Class Initialized
INFO - 2024-10-08 17:04:41 --> Language Class Initialized
INFO - 2024-10-08 17:04:41 --> Config Class Initialized
INFO - 2024-10-08 17:04:41 --> Loader Class Initialized
INFO - 2024-10-08 17:04:41 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:41 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:41 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:41 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:41 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:41 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:41 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:41 --> Total execution time: 0.0419
INFO - 2024-10-08 17:04:42 --> Config Class Initialized
INFO - 2024-10-08 17:04:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:42 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:42 --> URI Class Initialized
INFO - 2024-10-08 17:04:42 --> Router Class Initialized
INFO - 2024-10-08 17:04:42 --> Output Class Initialized
INFO - 2024-10-08 17:04:42 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:42 --> Input Class Initialized
INFO - 2024-10-08 17:04:42 --> Language Class Initialized
INFO - 2024-10-08 17:04:42 --> Language Class Initialized
INFO - 2024-10-08 17:04:42 --> Config Class Initialized
INFO - 2024-10-08 17:04:42 --> Loader Class Initialized
INFO - 2024-10-08 17:04:42 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:42 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:42 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:42 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:42 --> Total execution time: 0.0381
INFO - 2024-10-08 17:04:42 --> Config Class Initialized
INFO - 2024-10-08 17:04:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:42 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:42 --> URI Class Initialized
INFO - 2024-10-08 17:04:42 --> Router Class Initialized
INFO - 2024-10-08 17:04:42 --> Output Class Initialized
INFO - 2024-10-08 17:04:42 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:42 --> Input Class Initialized
INFO - 2024-10-08 17:04:42 --> Language Class Initialized
INFO - 2024-10-08 17:04:42 --> Language Class Initialized
INFO - 2024-10-08 17:04:42 --> Config Class Initialized
INFO - 2024-10-08 17:04:42 --> Loader Class Initialized
INFO - 2024-10-08 17:04:42 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:42 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:42 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:42 --> Controller Class Initialized
INFO - 2024-10-08 17:04:44 --> Config Class Initialized
INFO - 2024-10-08 17:04:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:44 --> URI Class Initialized
INFO - 2024-10-08 17:04:44 --> Router Class Initialized
INFO - 2024-10-08 17:04:44 --> Output Class Initialized
INFO - 2024-10-08 17:04:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:44 --> Input Class Initialized
INFO - 2024-10-08 17:04:44 --> Language Class Initialized
INFO - 2024-10-08 17:04:44 --> Language Class Initialized
INFO - 2024-10-08 17:04:44 --> Config Class Initialized
INFO - 2024-10-08 17:04:44 --> Loader Class Initialized
INFO - 2024-10-08 17:04:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:44 --> Controller Class Initialized
INFO - 2024-10-08 17:04:44 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:44 --> Total execution time: 0.0959
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:45 --> URI Class Initialized
INFO - 2024-10-08 17:04:45 --> Router Class Initialized
INFO - 2024-10-08 17:04:45 --> Output Class Initialized
INFO - 2024-10-08 17:04:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:45 --> Input Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Loader Class Initialized
INFO - 2024-10-08 17:04:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:45 --> Controller Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:45 --> URI Class Initialized
INFO - 2024-10-08 17:04:45 --> Router Class Initialized
INFO - 2024-10-08 17:04:45 --> Output Class Initialized
INFO - 2024-10-08 17:04:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:45 --> Input Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Loader Class Initialized
INFO - 2024-10-08 17:04:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:45 --> Controller Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:45 --> URI Class Initialized
INFO - 2024-10-08 17:04:45 --> Router Class Initialized
INFO - 2024-10-08 17:04:45 --> Output Class Initialized
INFO - 2024-10-08 17:04:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:45 --> Input Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Loader Class Initialized
INFO - 2024-10-08 17:04:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:45 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:45 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:45 --> Total execution time: 0.0534
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:45 --> URI Class Initialized
INFO - 2024-10-08 17:04:45 --> Router Class Initialized
INFO - 2024-10-08 17:04:45 --> Output Class Initialized
INFO - 2024-10-08 17:04:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:45 --> Input Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Language Class Initialized
INFO - 2024-10-08 17:04:45 --> Config Class Initialized
INFO - 2024-10-08 17:04:45 --> Loader Class Initialized
INFO - 2024-10-08 17:04:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:46 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:46 --> Controller Class Initialized
INFO - 2024-10-08 17:04:47 --> Config Class Initialized
INFO - 2024-10-08 17:04:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:47 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:47 --> URI Class Initialized
INFO - 2024-10-08 17:04:47 --> Router Class Initialized
INFO - 2024-10-08 17:04:47 --> Output Class Initialized
INFO - 2024-10-08 17:04:47 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:47 --> Input Class Initialized
INFO - 2024-10-08 17:04:47 --> Language Class Initialized
INFO - 2024-10-08 17:04:47 --> Language Class Initialized
INFO - 2024-10-08 17:04:47 --> Config Class Initialized
INFO - 2024-10-08 17:04:47 --> Loader Class Initialized
INFO - 2024-10-08 17:04:47 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:47 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:47 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:47 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:47 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:47 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:47 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:47 --> Total execution time: 0.0295
INFO - 2024-10-08 17:04:49 --> Config Class Initialized
INFO - 2024-10-08 17:04:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:49 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:49 --> URI Class Initialized
INFO - 2024-10-08 17:04:49 --> Router Class Initialized
INFO - 2024-10-08 17:04:49 --> Output Class Initialized
INFO - 2024-10-08 17:04:49 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:49 --> Input Class Initialized
INFO - 2024-10-08 17:04:49 --> Language Class Initialized
INFO - 2024-10-08 17:04:49 --> Language Class Initialized
INFO - 2024-10-08 17:04:49 --> Config Class Initialized
INFO - 2024-10-08 17:04:49 --> Loader Class Initialized
INFO - 2024-10-08 17:04:49 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:49 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:49 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:49 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:49 --> Total execution time: 0.0683
INFO - 2024-10-08 17:04:49 --> Config Class Initialized
INFO - 2024-10-08 17:04:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:49 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:49 --> URI Class Initialized
INFO - 2024-10-08 17:04:49 --> Router Class Initialized
INFO - 2024-10-08 17:04:49 --> Output Class Initialized
INFO - 2024-10-08 17:04:49 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:49 --> Input Class Initialized
INFO - 2024-10-08 17:04:49 --> Language Class Initialized
INFO - 2024-10-08 17:04:49 --> Language Class Initialized
INFO - 2024-10-08 17:04:49 --> Config Class Initialized
INFO - 2024-10-08 17:04:49 --> Loader Class Initialized
INFO - 2024-10-08 17:04:49 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:49 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:49 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:49 --> Controller Class Initialized
INFO - 2024-10-08 17:04:50 --> Config Class Initialized
INFO - 2024-10-08 17:04:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:50 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:50 --> URI Class Initialized
INFO - 2024-10-08 17:04:50 --> Router Class Initialized
INFO - 2024-10-08 17:04:50 --> Output Class Initialized
INFO - 2024-10-08 17:04:50 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:50 --> Input Class Initialized
INFO - 2024-10-08 17:04:50 --> Language Class Initialized
INFO - 2024-10-08 17:04:50 --> Language Class Initialized
INFO - 2024-10-08 17:04:50 --> Config Class Initialized
INFO - 2024-10-08 17:04:50 --> Loader Class Initialized
INFO - 2024-10-08 17:04:50 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:50 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:50 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:50 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:50 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:50 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:04:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:50 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:50 --> Total execution time: 0.0353
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:54 --> URI Class Initialized
INFO - 2024-10-08 17:04:54 --> Router Class Initialized
INFO - 2024-10-08 17:04:54 --> Output Class Initialized
INFO - 2024-10-08 17:04:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:54 --> Input Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Loader Class Initialized
INFO - 2024-10-08 17:04:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:54 --> Controller Class Initialized
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:54 --> URI Class Initialized
INFO - 2024-10-08 17:04:54 --> Router Class Initialized
INFO - 2024-10-08 17:04:54 --> Output Class Initialized
INFO - 2024-10-08 17:04:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:54 --> Input Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Loader Class Initialized
INFO - 2024-10-08 17:04:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:54 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:54 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:54 --> Total execution time: 0.0319
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:54 --> URI Class Initialized
INFO - 2024-10-08 17:04:54 --> Router Class Initialized
INFO - 2024-10-08 17:04:54 --> Output Class Initialized
INFO - 2024-10-08 17:04:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:54 --> Input Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Language Class Initialized
INFO - 2024-10-08 17:04:54 --> Config Class Initialized
INFO - 2024-10-08 17:04:54 --> Loader Class Initialized
INFO - 2024-10-08 17:04:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:54 --> Controller Class Initialized
INFO - 2024-10-08 17:04:56 --> Config Class Initialized
INFO - 2024-10-08 17:04:56 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:56 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:56 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:56 --> URI Class Initialized
INFO - 2024-10-08 17:04:56 --> Router Class Initialized
INFO - 2024-10-08 17:04:56 --> Output Class Initialized
INFO - 2024-10-08 17:04:56 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:56 --> Input Class Initialized
INFO - 2024-10-08 17:04:56 --> Language Class Initialized
INFO - 2024-10-08 17:04:56 --> Language Class Initialized
INFO - 2024-10-08 17:04:56 --> Config Class Initialized
INFO - 2024-10-08 17:04:56 --> Loader Class Initialized
INFO - 2024-10-08 17:04:56 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:56 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:56 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:56 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:56 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:56 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:04:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:56 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:56 --> Total execution time: 0.0618
INFO - 2024-10-08 17:04:58 --> Config Class Initialized
INFO - 2024-10-08 17:04:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:58 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:58 --> URI Class Initialized
INFO - 2024-10-08 17:04:58 --> Router Class Initialized
INFO - 2024-10-08 17:04:58 --> Output Class Initialized
INFO - 2024-10-08 17:04:58 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:58 --> Input Class Initialized
INFO - 2024-10-08 17:04:58 --> Language Class Initialized
INFO - 2024-10-08 17:04:58 --> Language Class Initialized
INFO - 2024-10-08 17:04:58 --> Config Class Initialized
INFO - 2024-10-08 17:04:58 --> Loader Class Initialized
INFO - 2024-10-08 17:04:58 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:58 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:58 --> Controller Class Initialized
DEBUG - 2024-10-08 17:04:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:04:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:04:58 --> Final output sent to browser
DEBUG - 2024-10-08 17:04:58 --> Total execution time: 0.0405
INFO - 2024-10-08 17:04:58 --> Config Class Initialized
INFO - 2024-10-08 17:04:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:04:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:04:58 --> Utf8 Class Initialized
INFO - 2024-10-08 17:04:58 --> URI Class Initialized
INFO - 2024-10-08 17:04:58 --> Router Class Initialized
INFO - 2024-10-08 17:04:58 --> Output Class Initialized
INFO - 2024-10-08 17:04:58 --> Security Class Initialized
DEBUG - 2024-10-08 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:04:58 --> Input Class Initialized
INFO - 2024-10-08 17:04:58 --> Language Class Initialized
INFO - 2024-10-08 17:04:58 --> Language Class Initialized
INFO - 2024-10-08 17:04:58 --> Config Class Initialized
INFO - 2024-10-08 17:04:58 --> Loader Class Initialized
INFO - 2024-10-08 17:04:58 --> Helper loaded: url_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: file_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: form_helper
INFO - 2024-10-08 17:04:58 --> Helper loaded: my_helper
INFO - 2024-10-08 17:04:58 --> Database Driver Class Initialized
INFO - 2024-10-08 17:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:04:58 --> Controller Class Initialized
INFO - 2024-10-08 17:05:00 --> Config Class Initialized
INFO - 2024-10-08 17:05:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:00 --> URI Class Initialized
INFO - 2024-10-08 17:05:00 --> Router Class Initialized
INFO - 2024-10-08 17:05:00 --> Output Class Initialized
INFO - 2024-10-08 17:05:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:00 --> Input Class Initialized
INFO - 2024-10-08 17:05:00 --> Language Class Initialized
INFO - 2024-10-08 17:05:00 --> Language Class Initialized
INFO - 2024-10-08 17:05:00 --> Config Class Initialized
INFO - 2024-10-08 17:05:00 --> Loader Class Initialized
INFO - 2024-10-08 17:05:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:00 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:05:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:00 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:00 --> Total execution time: 0.0348
INFO - 2024-10-08 17:05:04 --> Config Class Initialized
INFO - 2024-10-08 17:05:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:04 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:04 --> URI Class Initialized
INFO - 2024-10-08 17:05:04 --> Router Class Initialized
INFO - 2024-10-08 17:05:04 --> Output Class Initialized
INFO - 2024-10-08 17:05:04 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:04 --> Input Class Initialized
INFO - 2024-10-08 17:05:04 --> Language Class Initialized
INFO - 2024-10-08 17:05:04 --> Language Class Initialized
INFO - 2024-10-08 17:05:04 --> Config Class Initialized
INFO - 2024-10-08 17:05:04 --> Loader Class Initialized
INFO - 2024-10-08 17:05:04 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:04 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:04 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:04 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:04 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:04 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:05:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:04 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:04 --> Total execution time: 0.0356
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:06 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:06 --> URI Class Initialized
INFO - 2024-10-08 17:05:06 --> Router Class Initialized
INFO - 2024-10-08 17:05:06 --> Output Class Initialized
INFO - 2024-10-08 17:05:06 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:06 --> Input Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Loader Class Initialized
INFO - 2024-10-08 17:05:06 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:06 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:06 --> Controller Class Initialized
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:06 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:06 --> URI Class Initialized
INFO - 2024-10-08 17:05:06 --> Router Class Initialized
INFO - 2024-10-08 17:05:06 --> Output Class Initialized
INFO - 2024-10-08 17:05:06 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:06 --> Input Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Loader Class Initialized
INFO - 2024-10-08 17:05:06 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:06 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:06 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:06 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:06 --> Total execution time: 0.0358
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:06 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:06 --> URI Class Initialized
INFO - 2024-10-08 17:05:06 --> Router Class Initialized
INFO - 2024-10-08 17:05:06 --> Output Class Initialized
INFO - 2024-10-08 17:05:06 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:06 --> Input Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Language Class Initialized
INFO - 2024-10-08 17:05:06 --> Config Class Initialized
INFO - 2024-10-08 17:05:06 --> Loader Class Initialized
INFO - 2024-10-08 17:05:06 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:06 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:06 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:06 --> Controller Class Initialized
INFO - 2024-10-08 17:05:08 --> Config Class Initialized
INFO - 2024-10-08 17:05:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:08 --> URI Class Initialized
INFO - 2024-10-08 17:05:08 --> Router Class Initialized
INFO - 2024-10-08 17:05:08 --> Output Class Initialized
INFO - 2024-10-08 17:05:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:08 --> Input Class Initialized
INFO - 2024-10-08 17:05:08 --> Language Class Initialized
INFO - 2024-10-08 17:05:08 --> Language Class Initialized
INFO - 2024-10-08 17:05:08 --> Config Class Initialized
INFO - 2024-10-08 17:05:08 --> Loader Class Initialized
INFO - 2024-10-08 17:05:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:08 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:08 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:08 --> Total execution time: 0.0717
INFO - 2024-10-08 17:05:08 --> Config Class Initialized
INFO - 2024-10-08 17:05:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:08 --> URI Class Initialized
INFO - 2024-10-08 17:05:08 --> Router Class Initialized
INFO - 2024-10-08 17:05:08 --> Output Class Initialized
INFO - 2024-10-08 17:05:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:08 --> Input Class Initialized
INFO - 2024-10-08 17:05:08 --> Language Class Initialized
INFO - 2024-10-08 17:05:08 --> Language Class Initialized
INFO - 2024-10-08 17:05:08 --> Config Class Initialized
INFO - 2024-10-08 17:05:08 --> Loader Class Initialized
INFO - 2024-10-08 17:05:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:08 --> Controller Class Initialized
INFO - 2024-10-08 17:05:10 --> Config Class Initialized
INFO - 2024-10-08 17:05:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:10 --> URI Class Initialized
INFO - 2024-10-08 17:05:10 --> Router Class Initialized
INFO - 2024-10-08 17:05:10 --> Output Class Initialized
INFO - 2024-10-08 17:05:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:10 --> Input Class Initialized
INFO - 2024-10-08 17:05:10 --> Language Class Initialized
INFO - 2024-10-08 17:05:10 --> Language Class Initialized
INFO - 2024-10-08 17:05:10 --> Config Class Initialized
INFO - 2024-10-08 17:05:10 --> Loader Class Initialized
INFO - 2024-10-08 17:05:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:10 --> Controller Class Initialized
INFO - 2024-10-08 17:05:10 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:10 --> Total execution time: 0.0785
INFO - 2024-10-08 17:05:12 --> Config Class Initialized
INFO - 2024-10-08 17:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:12 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:12 --> URI Class Initialized
INFO - 2024-10-08 17:05:12 --> Router Class Initialized
INFO - 2024-10-08 17:05:12 --> Output Class Initialized
INFO - 2024-10-08 17:05:12 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:12 --> Input Class Initialized
INFO - 2024-10-08 17:05:12 --> Language Class Initialized
INFO - 2024-10-08 17:05:12 --> Language Class Initialized
INFO - 2024-10-08 17:05:12 --> Config Class Initialized
INFO - 2024-10-08 17:05:12 --> Loader Class Initialized
INFO - 2024-10-08 17:05:12 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:12 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:12 --> Controller Class Initialized
INFO - 2024-10-08 17:05:12 --> Config Class Initialized
INFO - 2024-10-08 17:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:12 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:12 --> URI Class Initialized
INFO - 2024-10-08 17:05:12 --> Router Class Initialized
INFO - 2024-10-08 17:05:12 --> Output Class Initialized
INFO - 2024-10-08 17:05:12 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:12 --> Input Class Initialized
INFO - 2024-10-08 17:05:12 --> Language Class Initialized
INFO - 2024-10-08 17:05:12 --> Language Class Initialized
INFO - 2024-10-08 17:05:12 --> Config Class Initialized
INFO - 2024-10-08 17:05:12 --> Loader Class Initialized
INFO - 2024-10-08 17:05:12 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:12 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:12 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:12 --> Controller Class Initialized
INFO - 2024-10-08 17:05:12 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:12 --> Total execution time: 0.0455
INFO - 2024-10-08 17:05:18 --> Config Class Initialized
INFO - 2024-10-08 17:05:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:18 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:18 --> URI Class Initialized
INFO - 2024-10-08 17:05:18 --> Router Class Initialized
INFO - 2024-10-08 17:05:18 --> Output Class Initialized
INFO - 2024-10-08 17:05:18 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:18 --> Input Class Initialized
INFO - 2024-10-08 17:05:18 --> Language Class Initialized
INFO - 2024-10-08 17:05:18 --> Language Class Initialized
INFO - 2024-10-08 17:05:18 --> Config Class Initialized
INFO - 2024-10-08 17:05:18 --> Loader Class Initialized
INFO - 2024-10-08 17:05:18 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:18 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:18 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:18 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:18 --> Total execution time: 0.1131
INFO - 2024-10-08 17:05:18 --> Config Class Initialized
INFO - 2024-10-08 17:05:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:18 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:18 --> URI Class Initialized
INFO - 2024-10-08 17:05:18 --> Router Class Initialized
INFO - 2024-10-08 17:05:18 --> Output Class Initialized
INFO - 2024-10-08 17:05:18 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:18 --> Input Class Initialized
INFO - 2024-10-08 17:05:18 --> Language Class Initialized
INFO - 2024-10-08 17:05:18 --> Language Class Initialized
INFO - 2024-10-08 17:05:18 --> Config Class Initialized
INFO - 2024-10-08 17:05:18 --> Loader Class Initialized
INFO - 2024-10-08 17:05:18 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:18 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:18 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:18 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:05:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:18 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:18 --> Total execution time: 0.0603
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:20 --> URI Class Initialized
INFO - 2024-10-08 17:05:20 --> Router Class Initialized
INFO - 2024-10-08 17:05:20 --> Output Class Initialized
INFO - 2024-10-08 17:05:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:20 --> Input Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Loader Class Initialized
INFO - 2024-10-08 17:05:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:20 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:20 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:20 --> Total execution time: 0.0917
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:20 --> URI Class Initialized
INFO - 2024-10-08 17:05:20 --> Router Class Initialized
INFO - 2024-10-08 17:05:20 --> Output Class Initialized
INFO - 2024-10-08 17:05:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:20 --> Input Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Loader Class Initialized
INFO - 2024-10-08 17:05:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:20 --> Controller Class Initialized
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:20 --> URI Class Initialized
INFO - 2024-10-08 17:05:20 --> Router Class Initialized
INFO - 2024-10-08 17:05:20 --> Output Class Initialized
INFO - 2024-10-08 17:05:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:20 --> Input Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Loader Class Initialized
INFO - 2024-10-08 17:05:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:20 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:20 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:20 --> Total execution time: 0.0933
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:20 --> URI Class Initialized
INFO - 2024-10-08 17:05:20 --> Router Class Initialized
INFO - 2024-10-08 17:05:20 --> Output Class Initialized
INFO - 2024-10-08 17:05:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:20 --> Input Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Language Class Initialized
INFO - 2024-10-08 17:05:20 --> Config Class Initialized
INFO - 2024-10-08 17:05:20 --> Loader Class Initialized
INFO - 2024-10-08 17:05:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:20 --> Controller Class Initialized
INFO - 2024-10-08 17:05:21 --> Config Class Initialized
INFO - 2024-10-08 17:05:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:21 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:21 --> URI Class Initialized
INFO - 2024-10-08 17:05:21 --> Router Class Initialized
INFO - 2024-10-08 17:05:21 --> Output Class Initialized
INFO - 2024-10-08 17:05:21 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:21 --> Input Class Initialized
INFO - 2024-10-08 17:05:21 --> Language Class Initialized
INFO - 2024-10-08 17:05:21 --> Language Class Initialized
INFO - 2024-10-08 17:05:21 --> Config Class Initialized
INFO - 2024-10-08 17:05:21 --> Loader Class Initialized
INFO - 2024-10-08 17:05:21 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:21 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:21 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:21 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:21 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:21 --> Controller Class Initialized
INFO - 2024-10-08 17:05:21 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:21 --> Total execution time: 0.0341
INFO - 2024-10-08 17:05:23 --> Config Class Initialized
INFO - 2024-10-08 17:05:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:23 --> URI Class Initialized
INFO - 2024-10-08 17:05:23 --> Router Class Initialized
INFO - 2024-10-08 17:05:23 --> Output Class Initialized
INFO - 2024-10-08 17:05:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:23 --> Input Class Initialized
INFO - 2024-10-08 17:05:23 --> Language Class Initialized
INFO - 2024-10-08 17:05:23 --> Language Class Initialized
INFO - 2024-10-08 17:05:23 --> Config Class Initialized
INFO - 2024-10-08 17:05:23 --> Loader Class Initialized
INFO - 2024-10-08 17:05:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:23 --> Controller Class Initialized
INFO - 2024-10-08 17:05:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:23 --> Total execution time: 0.0404
INFO - 2024-10-08 17:05:24 --> Config Class Initialized
INFO - 2024-10-08 17:05:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:24 --> URI Class Initialized
INFO - 2024-10-08 17:05:24 --> Router Class Initialized
INFO - 2024-10-08 17:05:24 --> Output Class Initialized
INFO - 2024-10-08 17:05:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:24 --> Input Class Initialized
INFO - 2024-10-08 17:05:24 --> Language Class Initialized
INFO - 2024-10-08 17:05:24 --> Language Class Initialized
INFO - 2024-10-08 17:05:24 --> Config Class Initialized
INFO - 2024-10-08 17:05:24 --> Loader Class Initialized
INFO - 2024-10-08 17:05:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:24 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:24 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:24 --> Total execution time: 0.0450
INFO - 2024-10-08 17:05:25 --> Config Class Initialized
INFO - 2024-10-08 17:05:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:25 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:25 --> URI Class Initialized
INFO - 2024-10-08 17:05:25 --> Router Class Initialized
INFO - 2024-10-08 17:05:25 --> Output Class Initialized
INFO - 2024-10-08 17:05:25 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:25 --> Input Class Initialized
INFO - 2024-10-08 17:05:25 --> Language Class Initialized
INFO - 2024-10-08 17:05:25 --> Language Class Initialized
INFO - 2024-10-08 17:05:25 --> Config Class Initialized
INFO - 2024-10-08 17:05:25 --> Loader Class Initialized
INFO - 2024-10-08 17:05:25 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:25 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:25 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:25 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:25 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:25 --> Controller Class Initialized
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:29 --> URI Class Initialized
INFO - 2024-10-08 17:05:29 --> Router Class Initialized
INFO - 2024-10-08 17:05:29 --> Output Class Initialized
INFO - 2024-10-08 17:05:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:29 --> Input Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Loader Class Initialized
INFO - 2024-10-08 17:05:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:29 --> Controller Class Initialized
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:29 --> URI Class Initialized
INFO - 2024-10-08 17:05:29 --> Router Class Initialized
INFO - 2024-10-08 17:05:29 --> Output Class Initialized
INFO - 2024-10-08 17:05:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:29 --> Input Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Loader Class Initialized
INFO - 2024-10-08 17:05:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:29 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:29 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:29 --> Total execution time: 0.0344
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:29 --> URI Class Initialized
INFO - 2024-10-08 17:05:29 --> Router Class Initialized
INFO - 2024-10-08 17:05:29 --> Output Class Initialized
INFO - 2024-10-08 17:05:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:29 --> Input Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Language Class Initialized
INFO - 2024-10-08 17:05:29 --> Config Class Initialized
INFO - 2024-10-08 17:05:29 --> Loader Class Initialized
INFO - 2024-10-08 17:05:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:29 --> Controller Class Initialized
INFO - 2024-10-08 17:05:31 --> Config Class Initialized
INFO - 2024-10-08 17:05:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:31 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:31 --> URI Class Initialized
INFO - 2024-10-08 17:05:31 --> Router Class Initialized
INFO - 2024-10-08 17:05:31 --> Output Class Initialized
INFO - 2024-10-08 17:05:31 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:31 --> Input Class Initialized
INFO - 2024-10-08 17:05:31 --> Language Class Initialized
INFO - 2024-10-08 17:05:31 --> Language Class Initialized
INFO - 2024-10-08 17:05:31 --> Config Class Initialized
INFO - 2024-10-08 17:05:31 --> Loader Class Initialized
INFO - 2024-10-08 17:05:31 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:31 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:31 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:05:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:31 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:31 --> Total execution time: 0.0317
INFO - 2024-10-08 17:05:31 --> Config Class Initialized
INFO - 2024-10-08 17:05:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:31 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:31 --> URI Class Initialized
INFO - 2024-10-08 17:05:31 --> Router Class Initialized
INFO - 2024-10-08 17:05:31 --> Output Class Initialized
INFO - 2024-10-08 17:05:31 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:31 --> Input Class Initialized
INFO - 2024-10-08 17:05:31 --> Language Class Initialized
INFO - 2024-10-08 17:05:31 --> Language Class Initialized
INFO - 2024-10-08 17:05:31 --> Config Class Initialized
INFO - 2024-10-08 17:05:31 --> Loader Class Initialized
INFO - 2024-10-08 17:05:31 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:31 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:31 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:31 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:05:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:31 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:31 --> Total execution time: 0.0309
INFO - 2024-10-08 17:05:32 --> Config Class Initialized
INFO - 2024-10-08 17:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:32 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:32 --> URI Class Initialized
INFO - 2024-10-08 17:05:32 --> Router Class Initialized
INFO - 2024-10-08 17:05:32 --> Output Class Initialized
INFO - 2024-10-08 17:05:32 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:32 --> Input Class Initialized
INFO - 2024-10-08 17:05:32 --> Language Class Initialized
INFO - 2024-10-08 17:05:32 --> Language Class Initialized
INFO - 2024-10-08 17:05:32 --> Config Class Initialized
INFO - 2024-10-08 17:05:32 --> Loader Class Initialized
INFO - 2024-10-08 17:05:32 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:32 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:32 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:32 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:32 --> Total execution time: 0.0443
INFO - 2024-10-08 17:05:32 --> Config Class Initialized
INFO - 2024-10-08 17:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:32 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:32 --> URI Class Initialized
INFO - 2024-10-08 17:05:32 --> Router Class Initialized
INFO - 2024-10-08 17:05:32 --> Output Class Initialized
INFO - 2024-10-08 17:05:32 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:32 --> Input Class Initialized
INFO - 2024-10-08 17:05:32 --> Language Class Initialized
INFO - 2024-10-08 17:05:32 --> Language Class Initialized
INFO - 2024-10-08 17:05:32 --> Config Class Initialized
INFO - 2024-10-08 17:05:32 --> Loader Class Initialized
INFO - 2024-10-08 17:05:32 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:32 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:32 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:32 --> Controller Class Initialized
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:33 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:33 --> URI Class Initialized
INFO - 2024-10-08 17:05:33 --> Router Class Initialized
INFO - 2024-10-08 17:05:33 --> Output Class Initialized
INFO - 2024-10-08 17:05:33 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:33 --> Input Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Loader Class Initialized
INFO - 2024-10-08 17:05:33 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:33 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:33 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:33 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:33 --> Total execution time: 0.0612
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:33 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:33 --> URI Class Initialized
INFO - 2024-10-08 17:05:33 --> Router Class Initialized
INFO - 2024-10-08 17:05:33 --> Output Class Initialized
INFO - 2024-10-08 17:05:33 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:33 --> Input Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Loader Class Initialized
INFO - 2024-10-08 17:05:33 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:33 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:33 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:33 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:33 --> Total execution time: 0.0414
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:33 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:33 --> URI Class Initialized
INFO - 2024-10-08 17:05:33 --> Router Class Initialized
INFO - 2024-10-08 17:05:33 --> Output Class Initialized
INFO - 2024-10-08 17:05:33 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:33 --> Input Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Language Class Initialized
INFO - 2024-10-08 17:05:33 --> Config Class Initialized
INFO - 2024-10-08 17:05:33 --> Loader Class Initialized
INFO - 2024-10-08 17:05:33 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:33 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:33 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:33 --> Controller Class Initialized
INFO - 2024-10-08 17:05:36 --> Config Class Initialized
INFO - 2024-10-08 17:05:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:36 --> URI Class Initialized
INFO - 2024-10-08 17:05:36 --> Router Class Initialized
INFO - 2024-10-08 17:05:36 --> Output Class Initialized
INFO - 2024-10-08 17:05:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:36 --> Input Class Initialized
INFO - 2024-10-08 17:05:36 --> Language Class Initialized
INFO - 2024-10-08 17:05:36 --> Language Class Initialized
INFO - 2024-10-08 17:05:36 --> Config Class Initialized
INFO - 2024-10-08 17:05:36 --> Loader Class Initialized
INFO - 2024-10-08 17:05:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:36 --> Controller Class Initialized
INFO - 2024-10-08 17:05:36 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:36 --> Total execution time: 0.0372
INFO - 2024-10-08 17:05:37 --> Config Class Initialized
INFO - 2024-10-08 17:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:37 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:37 --> URI Class Initialized
INFO - 2024-10-08 17:05:37 --> Router Class Initialized
INFO - 2024-10-08 17:05:37 --> Output Class Initialized
INFO - 2024-10-08 17:05:37 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:37 --> Input Class Initialized
INFO - 2024-10-08 17:05:37 --> Language Class Initialized
INFO - 2024-10-08 17:05:37 --> Language Class Initialized
INFO - 2024-10-08 17:05:37 --> Config Class Initialized
INFO - 2024-10-08 17:05:37 --> Loader Class Initialized
INFO - 2024-10-08 17:05:37 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:37 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:37 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:37 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:37 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:37 --> Controller Class Initialized
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:38 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:38 --> URI Class Initialized
INFO - 2024-10-08 17:05:38 --> Router Class Initialized
INFO - 2024-10-08 17:05:38 --> Output Class Initialized
INFO - 2024-10-08 17:05:38 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:38 --> Input Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Loader Class Initialized
INFO - 2024-10-08 17:05:38 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:38 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:38 --> Controller Class Initialized
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:38 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:38 --> URI Class Initialized
INFO - 2024-10-08 17:05:38 --> Router Class Initialized
INFO - 2024-10-08 17:05:38 --> Output Class Initialized
INFO - 2024-10-08 17:05:38 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:38 --> Input Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Loader Class Initialized
INFO - 2024-10-08 17:05:38 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:38 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:38 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:38 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:38 --> Total execution time: 0.0402
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:38 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:38 --> URI Class Initialized
INFO - 2024-10-08 17:05:38 --> Router Class Initialized
INFO - 2024-10-08 17:05:38 --> Output Class Initialized
INFO - 2024-10-08 17:05:38 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:38 --> Input Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Language Class Initialized
INFO - 2024-10-08 17:05:38 --> Config Class Initialized
INFO - 2024-10-08 17:05:38 --> Loader Class Initialized
INFO - 2024-10-08 17:05:38 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:38 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:38 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:38 --> Controller Class Initialized
INFO - 2024-10-08 17:05:39 --> Config Class Initialized
INFO - 2024-10-08 17:05:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:39 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:39 --> URI Class Initialized
INFO - 2024-10-08 17:05:39 --> Router Class Initialized
INFO - 2024-10-08 17:05:39 --> Output Class Initialized
INFO - 2024-10-08 17:05:39 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:39 --> Input Class Initialized
INFO - 2024-10-08 17:05:39 --> Language Class Initialized
INFO - 2024-10-08 17:05:39 --> Language Class Initialized
INFO - 2024-10-08 17:05:39 --> Config Class Initialized
INFO - 2024-10-08 17:05:39 --> Loader Class Initialized
INFO - 2024-10-08 17:05:39 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:39 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:39 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:39 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:39 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:39 --> Controller Class Initialized
INFO - 2024-10-08 17:05:39 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:39 --> Total execution time: 0.0383
INFO - 2024-10-08 17:05:49 --> Config Class Initialized
INFO - 2024-10-08 17:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:49 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:49 --> URI Class Initialized
INFO - 2024-10-08 17:05:49 --> Router Class Initialized
INFO - 2024-10-08 17:05:49 --> Output Class Initialized
INFO - 2024-10-08 17:05:49 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:49 --> Input Class Initialized
INFO - 2024-10-08 17:05:49 --> Language Class Initialized
INFO - 2024-10-08 17:05:49 --> Language Class Initialized
INFO - 2024-10-08 17:05:49 --> Config Class Initialized
INFO - 2024-10-08 17:05:49 --> Loader Class Initialized
INFO - 2024-10-08 17:05:49 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:49 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:49 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:49 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:49 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:49 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:05:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:05:49 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:49 --> Total execution time: 0.0364
INFO - 2024-10-08 17:05:50 --> Config Class Initialized
INFO - 2024-10-08 17:05:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:05:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:05:50 --> Utf8 Class Initialized
INFO - 2024-10-08 17:05:50 --> URI Class Initialized
INFO - 2024-10-08 17:05:50 --> Router Class Initialized
INFO - 2024-10-08 17:05:50 --> Output Class Initialized
INFO - 2024-10-08 17:05:50 --> Security Class Initialized
DEBUG - 2024-10-08 17:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:05:50 --> Input Class Initialized
INFO - 2024-10-08 17:05:50 --> Language Class Initialized
INFO - 2024-10-08 17:05:50 --> Language Class Initialized
INFO - 2024-10-08 17:05:50 --> Config Class Initialized
INFO - 2024-10-08 17:05:50 --> Loader Class Initialized
INFO - 2024-10-08 17:05:50 --> Helper loaded: url_helper
INFO - 2024-10-08 17:05:50 --> Helper loaded: file_helper
INFO - 2024-10-08 17:05:50 --> Helper loaded: form_helper
INFO - 2024-10-08 17:05:50 --> Helper loaded: my_helper
INFO - 2024-10-08 17:05:50 --> Database Driver Class Initialized
INFO - 2024-10-08 17:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:05:50 --> Controller Class Initialized
DEBUG - 2024-10-08 17:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:05:53 --> Final output sent to browser
DEBUG - 2024-10-08 17:05:53 --> Total execution time: 3.0841
INFO - 2024-10-08 17:06:05 --> Config Class Initialized
INFO - 2024-10-08 17:06:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:06:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:06:05 --> Utf8 Class Initialized
INFO - 2024-10-08 17:06:05 --> URI Class Initialized
INFO - 2024-10-08 17:06:05 --> Router Class Initialized
INFO - 2024-10-08 17:06:05 --> Output Class Initialized
INFO - 2024-10-08 17:06:05 --> Security Class Initialized
DEBUG - 2024-10-08 17:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:06:05 --> Input Class Initialized
INFO - 2024-10-08 17:06:05 --> Language Class Initialized
INFO - 2024-10-08 17:06:05 --> Language Class Initialized
INFO - 2024-10-08 17:06:05 --> Config Class Initialized
INFO - 2024-10-08 17:06:05 --> Loader Class Initialized
INFO - 2024-10-08 17:06:05 --> Helper loaded: url_helper
INFO - 2024-10-08 17:06:05 --> Helper loaded: file_helper
INFO - 2024-10-08 17:06:05 --> Helper loaded: form_helper
INFO - 2024-10-08 17:06:05 --> Helper loaded: my_helper
INFO - 2024-10-08 17:06:05 --> Database Driver Class Initialized
INFO - 2024-10-08 17:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:06:05 --> Controller Class Initialized
DEBUG - 2024-10-08 17:06:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:06:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:06:05 --> Final output sent to browser
DEBUG - 2024-10-08 17:06:05 --> Total execution time: 0.0411
INFO - 2024-10-08 17:06:08 --> Config Class Initialized
INFO - 2024-10-08 17:06:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:06:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:06:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:06:08 --> URI Class Initialized
INFO - 2024-10-08 17:06:08 --> Router Class Initialized
INFO - 2024-10-08 17:06:08 --> Output Class Initialized
INFO - 2024-10-08 17:06:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:06:08 --> Input Class Initialized
INFO - 2024-10-08 17:06:08 --> Language Class Initialized
INFO - 2024-10-08 17:06:08 --> Language Class Initialized
INFO - 2024-10-08 17:06:08 --> Config Class Initialized
INFO - 2024-10-08 17:06:08 --> Loader Class Initialized
INFO - 2024-10-08 17:06:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:06:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:06:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:06:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:06:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:06:08 --> Controller Class Initialized
DEBUG - 2024-10-08 17:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:06:11 --> Final output sent to browser
DEBUG - 2024-10-08 17:06:11 --> Total execution time: 3.1233
INFO - 2024-10-08 17:06:20 --> Config Class Initialized
INFO - 2024-10-08 17:06:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:06:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:06:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:06:20 --> URI Class Initialized
INFO - 2024-10-08 17:06:20 --> Router Class Initialized
INFO - 2024-10-08 17:06:20 --> Output Class Initialized
INFO - 2024-10-08 17:06:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:06:20 --> Input Class Initialized
INFO - 2024-10-08 17:06:20 --> Language Class Initialized
INFO - 2024-10-08 17:06:20 --> Language Class Initialized
INFO - 2024-10-08 17:06:20 --> Config Class Initialized
INFO - 2024-10-08 17:06:20 --> Loader Class Initialized
INFO - 2024-10-08 17:06:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:06:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:06:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:06:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:06:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:06:20 --> Controller Class Initialized
DEBUG - 2024-10-08 17:06:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:06:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:06:23 --> Total execution time: 3.1039
INFO - 2024-10-08 17:07:46 --> Config Class Initialized
INFO - 2024-10-08 17:07:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:07:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:07:46 --> Utf8 Class Initialized
INFO - 2024-10-08 17:07:46 --> URI Class Initialized
INFO - 2024-10-08 17:07:46 --> Router Class Initialized
INFO - 2024-10-08 17:07:46 --> Output Class Initialized
INFO - 2024-10-08 17:07:46 --> Security Class Initialized
DEBUG - 2024-10-08 17:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:07:46 --> Input Class Initialized
INFO - 2024-10-08 17:07:46 --> Language Class Initialized
INFO - 2024-10-08 17:07:46 --> Language Class Initialized
INFO - 2024-10-08 17:07:46 --> Config Class Initialized
INFO - 2024-10-08 17:07:46 --> Loader Class Initialized
INFO - 2024-10-08 17:07:46 --> Helper loaded: url_helper
INFO - 2024-10-08 17:07:46 --> Helper loaded: file_helper
INFO - 2024-10-08 17:07:46 --> Helper loaded: form_helper
INFO - 2024-10-08 17:07:46 --> Helper loaded: my_helper
INFO - 2024-10-08 17:07:46 --> Database Driver Class Initialized
INFO - 2024-10-08 17:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:07:46 --> Controller Class Initialized
DEBUG - 2024-10-08 17:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:07:46 --> Final output sent to browser
DEBUG - 2024-10-08 17:07:46 --> Total execution time: 0.0928
INFO - 2024-10-08 17:07:51 --> Config Class Initialized
INFO - 2024-10-08 17:07:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:07:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:07:51 --> Utf8 Class Initialized
INFO - 2024-10-08 17:07:51 --> URI Class Initialized
INFO - 2024-10-08 17:07:51 --> Router Class Initialized
INFO - 2024-10-08 17:07:51 --> Output Class Initialized
INFO - 2024-10-08 17:07:51 --> Security Class Initialized
DEBUG - 2024-10-08 17:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:07:51 --> Input Class Initialized
INFO - 2024-10-08 17:07:51 --> Language Class Initialized
INFO - 2024-10-08 17:07:51 --> Language Class Initialized
INFO - 2024-10-08 17:07:51 --> Config Class Initialized
INFO - 2024-10-08 17:07:51 --> Loader Class Initialized
INFO - 2024-10-08 17:07:51 --> Helper loaded: url_helper
INFO - 2024-10-08 17:07:51 --> Helper loaded: file_helper
INFO - 2024-10-08 17:07:51 --> Helper loaded: form_helper
INFO - 2024-10-08 17:07:51 --> Helper loaded: my_helper
INFO - 2024-10-08 17:07:51 --> Database Driver Class Initialized
INFO - 2024-10-08 17:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:07:51 --> Controller Class Initialized
DEBUG - 2024-10-08 17:07:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:07:55 --> Final output sent to browser
DEBUG - 2024-10-08 17:07:55 --> Total execution time: 3.4519
INFO - 2024-10-08 17:11:13 --> Config Class Initialized
INFO - 2024-10-08 17:11:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:13 --> URI Class Initialized
INFO - 2024-10-08 17:11:13 --> Router Class Initialized
INFO - 2024-10-08 17:11:13 --> Output Class Initialized
INFO - 2024-10-08 17:11:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:13 --> Input Class Initialized
INFO - 2024-10-08 17:11:13 --> Language Class Initialized
INFO - 2024-10-08 17:11:13 --> Language Class Initialized
INFO - 2024-10-08 17:11:13 --> Config Class Initialized
INFO - 2024-10-08 17:11:13 --> Loader Class Initialized
INFO - 2024-10-08 17:11:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:13 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 17:11:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:11:13 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:13 --> Total execution time: 0.1117
INFO - 2024-10-08 17:11:13 --> Config Class Initialized
INFO - 2024-10-08 17:11:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:13 --> URI Class Initialized
INFO - 2024-10-08 17:11:13 --> Router Class Initialized
INFO - 2024-10-08 17:11:13 --> Output Class Initialized
INFO - 2024-10-08 17:11:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:13 --> Input Class Initialized
INFO - 2024-10-08 17:11:13 --> Language Class Initialized
INFO - 2024-10-08 17:11:13 --> Language Class Initialized
INFO - 2024-10-08 17:11:13 --> Config Class Initialized
INFO - 2024-10-08 17:11:13 --> Loader Class Initialized
INFO - 2024-10-08 17:11:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:13 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 17:11:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:11:13 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:13 --> Total execution time: 0.0440
INFO - 2024-10-08 17:11:18 --> Config Class Initialized
INFO - 2024-10-08 17:11:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:18 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:18 --> URI Class Initialized
INFO - 2024-10-08 17:11:18 --> Router Class Initialized
INFO - 2024-10-08 17:11:18 --> Output Class Initialized
INFO - 2024-10-08 17:11:18 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:18 --> Input Class Initialized
INFO - 2024-10-08 17:11:18 --> Language Class Initialized
INFO - 2024-10-08 17:11:18 --> Language Class Initialized
INFO - 2024-10-08 17:11:18 --> Config Class Initialized
INFO - 2024-10-08 17:11:18 --> Loader Class Initialized
INFO - 2024-10-08 17:11:18 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:18 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:18 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:18 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:18 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:18 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:11:18 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:18 --> Total execution time: 0.0323
INFO - 2024-10-08 17:11:21 --> Config Class Initialized
INFO - 2024-10-08 17:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:21 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:21 --> URI Class Initialized
INFO - 2024-10-08 17:11:21 --> Router Class Initialized
INFO - 2024-10-08 17:11:21 --> Output Class Initialized
INFO - 2024-10-08 17:11:21 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:21 --> Input Class Initialized
INFO - 2024-10-08 17:11:21 --> Language Class Initialized
INFO - 2024-10-08 17:11:21 --> Language Class Initialized
INFO - 2024-10-08 17:11:21 --> Config Class Initialized
INFO - 2024-10-08 17:11:21 --> Loader Class Initialized
INFO - 2024-10-08 17:11:21 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:21 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:21 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:11:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:11:21 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:21 --> Total execution time: 0.0402
INFO - 2024-10-08 17:11:21 --> Config Class Initialized
INFO - 2024-10-08 17:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:21 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:21 --> URI Class Initialized
INFO - 2024-10-08 17:11:21 --> Router Class Initialized
INFO - 2024-10-08 17:11:21 --> Output Class Initialized
INFO - 2024-10-08 17:11:21 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:21 --> Input Class Initialized
INFO - 2024-10-08 17:11:21 --> Language Class Initialized
INFO - 2024-10-08 17:11:21 --> Language Class Initialized
INFO - 2024-10-08 17:11:21 --> Config Class Initialized
INFO - 2024-10-08 17:11:21 --> Loader Class Initialized
INFO - 2024-10-08 17:11:21 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:21 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:21 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:21 --> Controller Class Initialized
INFO - 2024-10-08 17:11:23 --> Config Class Initialized
INFO - 2024-10-08 17:11:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:23 --> URI Class Initialized
INFO - 2024-10-08 17:11:23 --> Router Class Initialized
INFO - 2024-10-08 17:11:23 --> Output Class Initialized
INFO - 2024-10-08 17:11:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:23 --> Input Class Initialized
INFO - 2024-10-08 17:11:23 --> Language Class Initialized
INFO - 2024-10-08 17:11:23 --> Language Class Initialized
INFO - 2024-10-08 17:11:23 --> Config Class Initialized
INFO - 2024-10-08 17:11:23 --> Loader Class Initialized
INFO - 2024-10-08 17:11:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:23 --> Controller Class Initialized
INFO - 2024-10-08 17:11:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:23 --> Total execution time: 0.0437
INFO - 2024-10-08 17:11:24 --> Config Class Initialized
INFO - 2024-10-08 17:11:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:24 --> URI Class Initialized
INFO - 2024-10-08 17:11:24 --> Router Class Initialized
INFO - 2024-10-08 17:11:24 --> Output Class Initialized
INFO - 2024-10-08 17:11:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:24 --> Input Class Initialized
INFO - 2024-10-08 17:11:24 --> Language Class Initialized
INFO - 2024-10-08 17:11:24 --> Language Class Initialized
INFO - 2024-10-08 17:11:24 --> Config Class Initialized
INFO - 2024-10-08 17:11:24 --> Loader Class Initialized
INFO - 2024-10-08 17:11:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:24 --> Config Class Initialized
INFO - 2024-10-08 17:11:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:24 --> URI Class Initialized
INFO - 2024-10-08 17:11:24 --> Router Class Initialized
INFO - 2024-10-08 17:11:24 --> Output Class Initialized
INFO - 2024-10-08 17:11:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:24 --> Input Class Initialized
INFO - 2024-10-08 17:11:24 --> Language Class Initialized
INFO - 2024-10-08 17:11:24 --> Language Class Initialized
INFO - 2024-10-08 17:11:24 --> Config Class Initialized
INFO - 2024-10-08 17:11:24 --> Loader Class Initialized
INFO - 2024-10-08 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:24 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:11:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:11:24 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:24 --> Total execution time: 0.0629
INFO - 2024-10-08 17:11:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:24 --> Controller Class Initialized
INFO - 2024-10-08 17:11:27 --> Config Class Initialized
INFO - 2024-10-08 17:11:27 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:11:27 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:11:27 --> Utf8 Class Initialized
INFO - 2024-10-08 17:11:27 --> URI Class Initialized
INFO - 2024-10-08 17:11:27 --> Router Class Initialized
INFO - 2024-10-08 17:11:27 --> Output Class Initialized
INFO - 2024-10-08 17:11:27 --> Security Class Initialized
DEBUG - 2024-10-08 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:11:27 --> Input Class Initialized
INFO - 2024-10-08 17:11:27 --> Language Class Initialized
INFO - 2024-10-08 17:11:27 --> Language Class Initialized
INFO - 2024-10-08 17:11:27 --> Config Class Initialized
INFO - 2024-10-08 17:11:27 --> Loader Class Initialized
INFO - 2024-10-08 17:11:27 --> Helper loaded: url_helper
INFO - 2024-10-08 17:11:27 --> Helper loaded: file_helper
INFO - 2024-10-08 17:11:27 --> Helper loaded: form_helper
INFO - 2024-10-08 17:11:27 --> Helper loaded: my_helper
INFO - 2024-10-08 17:11:27 --> Database Driver Class Initialized
INFO - 2024-10-08 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:11:27 --> Controller Class Initialized
DEBUG - 2024-10-08 17:11:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:11:30 --> Final output sent to browser
DEBUG - 2024-10-08 17:11:30 --> Total execution time: 3.3229
INFO - 2024-10-08 17:12:54 --> Config Class Initialized
INFO - 2024-10-08 17:12:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:12:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:12:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:12:55 --> URI Class Initialized
INFO - 2024-10-08 17:12:55 --> Router Class Initialized
INFO - 2024-10-08 17:12:55 --> Output Class Initialized
INFO - 2024-10-08 17:12:55 --> Security Class Initialized
DEBUG - 2024-10-08 17:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:12:55 --> Input Class Initialized
INFO - 2024-10-08 17:12:55 --> Language Class Initialized
INFO - 2024-10-08 17:12:55 --> Language Class Initialized
INFO - 2024-10-08 17:12:55 --> Config Class Initialized
INFO - 2024-10-08 17:12:55 --> Loader Class Initialized
INFO - 2024-10-08 17:12:55 --> Helper loaded: url_helper
INFO - 2024-10-08 17:12:55 --> Helper loaded: file_helper
INFO - 2024-10-08 17:12:55 --> Helper loaded: form_helper
INFO - 2024-10-08 17:12:55 --> Helper loaded: my_helper
INFO - 2024-10-08 17:12:55 --> Database Driver Class Initialized
INFO - 2024-10-08 17:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:12:55 --> Controller Class Initialized
DEBUG - 2024-10-08 17:12:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:12:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:12:55 --> Final output sent to browser
DEBUG - 2024-10-08 17:12:55 --> Total execution time: 0.0587
INFO - 2024-10-08 17:13:01 --> Config Class Initialized
INFO - 2024-10-08 17:13:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:01 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:01 --> URI Class Initialized
INFO - 2024-10-08 17:13:01 --> Router Class Initialized
INFO - 2024-10-08 17:13:01 --> Output Class Initialized
INFO - 2024-10-08 17:13:01 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:01 --> Input Class Initialized
INFO - 2024-10-08 17:13:01 --> Language Class Initialized
INFO - 2024-10-08 17:13:01 --> Language Class Initialized
INFO - 2024-10-08 17:13:01 --> Config Class Initialized
INFO - 2024-10-08 17:13:01 --> Loader Class Initialized
INFO - 2024-10-08 17:13:01 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:01 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:01 --> Controller Class Initialized
INFO - 2024-10-08 17:13:01 --> Config Class Initialized
INFO - 2024-10-08 17:13:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:01 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:01 --> URI Class Initialized
INFO - 2024-10-08 17:13:01 --> Router Class Initialized
INFO - 2024-10-08 17:13:01 --> Output Class Initialized
INFO - 2024-10-08 17:13:01 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:01 --> Input Class Initialized
INFO - 2024-10-08 17:13:01 --> Language Class Initialized
INFO - 2024-10-08 17:13:01 --> Language Class Initialized
INFO - 2024-10-08 17:13:01 --> Config Class Initialized
INFO - 2024-10-08 17:13:01 --> Loader Class Initialized
INFO - 2024-10-08 17:13:01 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:01 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:01 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:02 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:02 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:02 --> Total execution time: 0.0649
INFO - 2024-10-08 17:13:02 --> Config Class Initialized
INFO - 2024-10-08 17:13:02 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:02 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:02 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:02 --> URI Class Initialized
INFO - 2024-10-08 17:13:02 --> Router Class Initialized
INFO - 2024-10-08 17:13:02 --> Output Class Initialized
INFO - 2024-10-08 17:13:02 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:02 --> Input Class Initialized
INFO - 2024-10-08 17:13:02 --> Language Class Initialized
INFO - 2024-10-08 17:13:02 --> Language Class Initialized
INFO - 2024-10-08 17:13:02 --> Config Class Initialized
INFO - 2024-10-08 17:13:02 --> Loader Class Initialized
INFO - 2024-10-08 17:13:02 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:02 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:02 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:02 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:02 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:02 --> Controller Class Initialized
INFO - 2024-10-08 17:13:04 --> Config Class Initialized
INFO - 2024-10-08 17:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:04 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:04 --> URI Class Initialized
INFO - 2024-10-08 17:13:04 --> Router Class Initialized
INFO - 2024-10-08 17:13:04 --> Output Class Initialized
INFO - 2024-10-08 17:13:04 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:04 --> Input Class Initialized
INFO - 2024-10-08 17:13:04 --> Language Class Initialized
INFO - 2024-10-08 17:13:04 --> Language Class Initialized
INFO - 2024-10-08 17:13:04 --> Config Class Initialized
INFO - 2024-10-08 17:13:04 --> Loader Class Initialized
INFO - 2024-10-08 17:13:04 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:04 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:04 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:04 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:04 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:04 --> Controller Class Initialized
INFO - 2024-10-08 17:13:04 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:04 --> Total execution time: 0.0340
INFO - 2024-10-08 17:13:07 --> Config Class Initialized
INFO - 2024-10-08 17:13:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:07 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:07 --> URI Class Initialized
INFO - 2024-10-08 17:13:07 --> Router Class Initialized
INFO - 2024-10-08 17:13:07 --> Output Class Initialized
INFO - 2024-10-08 17:13:07 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:07 --> Input Class Initialized
INFO - 2024-10-08 17:13:07 --> Language Class Initialized
INFO - 2024-10-08 17:13:07 --> Language Class Initialized
INFO - 2024-10-08 17:13:07 --> Config Class Initialized
INFO - 2024-10-08 17:13:07 --> Loader Class Initialized
INFO - 2024-10-08 17:13:07 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:07 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:07 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:07 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:07 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:07 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:07 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:07 --> Total execution time: 0.0625
INFO - 2024-10-08 17:13:10 --> Config Class Initialized
INFO - 2024-10-08 17:13:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:10 --> URI Class Initialized
INFO - 2024-10-08 17:13:10 --> Router Class Initialized
INFO - 2024-10-08 17:13:10 --> Output Class Initialized
INFO - 2024-10-08 17:13:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:10 --> Input Class Initialized
INFO - 2024-10-08 17:13:10 --> Language Class Initialized
INFO - 2024-10-08 17:13:10 --> Language Class Initialized
INFO - 2024-10-08 17:13:10 --> Config Class Initialized
INFO - 2024-10-08 17:13:10 --> Loader Class Initialized
INFO - 2024-10-08 17:13:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:10 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:13:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:10 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:10 --> Total execution time: 0.0368
INFO - 2024-10-08 17:13:10 --> Config Class Initialized
INFO - 2024-10-08 17:13:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:10 --> URI Class Initialized
INFO - 2024-10-08 17:13:10 --> Router Class Initialized
INFO - 2024-10-08 17:13:10 --> Output Class Initialized
INFO - 2024-10-08 17:13:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:10 --> Input Class Initialized
INFO - 2024-10-08 17:13:10 --> Language Class Initialized
INFO - 2024-10-08 17:13:10 --> Language Class Initialized
INFO - 2024-10-08 17:13:10 --> Config Class Initialized
INFO - 2024-10-08 17:13:10 --> Loader Class Initialized
INFO - 2024-10-08 17:13:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:10 --> Controller Class Initialized
INFO - 2024-10-08 17:13:11 --> Config Class Initialized
INFO - 2024-10-08 17:13:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:11 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:11 --> URI Class Initialized
INFO - 2024-10-08 17:13:11 --> Router Class Initialized
INFO - 2024-10-08 17:13:11 --> Output Class Initialized
INFO - 2024-10-08 17:13:11 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:11 --> Input Class Initialized
INFO - 2024-10-08 17:13:11 --> Language Class Initialized
INFO - 2024-10-08 17:13:11 --> Language Class Initialized
INFO - 2024-10-08 17:13:11 --> Config Class Initialized
INFO - 2024-10-08 17:13:11 --> Loader Class Initialized
INFO - 2024-10-08 17:13:11 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:11 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:11 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:11 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:11 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:11 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:13:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:11 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:11 --> Total execution time: 0.0424
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:22 --> URI Class Initialized
INFO - 2024-10-08 17:13:22 --> Router Class Initialized
INFO - 2024-10-08 17:13:22 --> Output Class Initialized
INFO - 2024-10-08 17:13:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:22 --> Input Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Loader Class Initialized
INFO - 2024-10-08 17:13:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:22 --> Controller Class Initialized
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:22 --> URI Class Initialized
INFO - 2024-10-08 17:13:22 --> Router Class Initialized
INFO - 2024-10-08 17:13:22 --> Output Class Initialized
INFO - 2024-10-08 17:13:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:22 --> Input Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Loader Class Initialized
INFO - 2024-10-08 17:13:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:22 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:13:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:22 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:22 --> Total execution time: 0.0374
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:22 --> URI Class Initialized
INFO - 2024-10-08 17:13:22 --> Router Class Initialized
INFO - 2024-10-08 17:13:22 --> Output Class Initialized
INFO - 2024-10-08 17:13:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:22 --> Input Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Language Class Initialized
INFO - 2024-10-08 17:13:22 --> Config Class Initialized
INFO - 2024-10-08 17:13:22 --> Loader Class Initialized
INFO - 2024-10-08 17:13:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:22 --> Controller Class Initialized
INFO - 2024-10-08 17:13:24 --> Config Class Initialized
INFO - 2024-10-08 17:13:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:24 --> URI Class Initialized
INFO - 2024-10-08 17:13:24 --> Router Class Initialized
INFO - 2024-10-08 17:13:24 --> Output Class Initialized
INFO - 2024-10-08 17:13:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:24 --> Input Class Initialized
INFO - 2024-10-08 17:13:24 --> Language Class Initialized
INFO - 2024-10-08 17:13:24 --> Language Class Initialized
INFO - 2024-10-08 17:13:24 --> Config Class Initialized
INFO - 2024-10-08 17:13:24 --> Loader Class Initialized
INFO - 2024-10-08 17:13:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:24 --> Controller Class Initialized
INFO - 2024-10-08 17:13:24 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:24 --> Total execution time: 0.0400
INFO - 2024-10-08 17:13:27 --> Config Class Initialized
INFO - 2024-10-08 17:13:27 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:27 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:27 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:27 --> URI Class Initialized
INFO - 2024-10-08 17:13:27 --> Router Class Initialized
INFO - 2024-10-08 17:13:27 --> Output Class Initialized
INFO - 2024-10-08 17:13:27 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:27 --> Input Class Initialized
INFO - 2024-10-08 17:13:27 --> Language Class Initialized
INFO - 2024-10-08 17:13:27 --> Language Class Initialized
INFO - 2024-10-08 17:13:27 --> Config Class Initialized
INFO - 2024-10-08 17:13:27 --> Loader Class Initialized
INFO - 2024-10-08 17:13:27 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:27 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:27 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:27 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:27 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:27 --> Controller Class Initialized
INFO - 2024-10-08 17:13:27 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:27 --> Total execution time: 0.1752
INFO - 2024-10-08 17:13:30 --> Config Class Initialized
INFO - 2024-10-08 17:13:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:30 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:30 --> URI Class Initialized
INFO - 2024-10-08 17:13:30 --> Router Class Initialized
INFO - 2024-10-08 17:13:30 --> Output Class Initialized
INFO - 2024-10-08 17:13:30 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:30 --> Input Class Initialized
INFO - 2024-10-08 17:13:30 --> Language Class Initialized
INFO - 2024-10-08 17:13:30 --> Language Class Initialized
INFO - 2024-10-08 17:13:30 --> Config Class Initialized
INFO - 2024-10-08 17:13:30 --> Loader Class Initialized
INFO - 2024-10-08 17:13:30 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:30 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:30 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:30 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:30 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:30 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:30 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:30 --> Total execution time: 0.0385
INFO - 2024-10-08 17:13:35 --> Config Class Initialized
INFO - 2024-10-08 17:13:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:35 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:35 --> URI Class Initialized
INFO - 2024-10-08 17:13:35 --> Router Class Initialized
INFO - 2024-10-08 17:13:35 --> Output Class Initialized
INFO - 2024-10-08 17:13:35 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:35 --> Input Class Initialized
INFO - 2024-10-08 17:13:35 --> Language Class Initialized
INFO - 2024-10-08 17:13:35 --> Language Class Initialized
INFO - 2024-10-08 17:13:35 --> Config Class Initialized
INFO - 2024-10-08 17:13:35 --> Loader Class Initialized
INFO - 2024-10-08 17:13:35 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:35 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:35 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:35 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:35 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:35 --> Controller Class Initialized
DEBUG - 2024-10-08 17:13:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:13:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:13:35 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:35 --> Total execution time: 0.0816
INFO - 2024-10-08 17:13:36 --> Config Class Initialized
INFO - 2024-10-08 17:13:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:36 --> URI Class Initialized
INFO - 2024-10-08 17:13:36 --> Router Class Initialized
INFO - 2024-10-08 17:13:36 --> Output Class Initialized
INFO - 2024-10-08 17:13:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:36 --> Input Class Initialized
INFO - 2024-10-08 17:13:36 --> Language Class Initialized
INFO - 2024-10-08 17:13:37 --> Language Class Initialized
INFO - 2024-10-08 17:13:37 --> Config Class Initialized
INFO - 2024-10-08 17:13:37 --> Loader Class Initialized
INFO - 2024-10-08 17:13:37 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:37 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:37 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:37 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:37 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:37 --> Controller Class Initialized
INFO - 2024-10-08 17:13:41 --> Config Class Initialized
INFO - 2024-10-08 17:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:41 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:41 --> URI Class Initialized
INFO - 2024-10-08 17:13:41 --> Router Class Initialized
INFO - 2024-10-08 17:13:41 --> Output Class Initialized
INFO - 2024-10-08 17:13:41 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:41 --> Input Class Initialized
INFO - 2024-10-08 17:13:41 --> Language Class Initialized
INFO - 2024-10-08 17:13:41 --> Language Class Initialized
INFO - 2024-10-08 17:13:41 --> Config Class Initialized
INFO - 2024-10-08 17:13:41 --> Loader Class Initialized
INFO - 2024-10-08 17:13:41 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:41 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:41 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:41 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:41 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:41 --> Controller Class Initialized
INFO - 2024-10-08 17:13:44 --> Config Class Initialized
INFO - 2024-10-08 17:13:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:13:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:13:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:13:44 --> URI Class Initialized
INFO - 2024-10-08 17:13:44 --> Router Class Initialized
INFO - 2024-10-08 17:13:44 --> Output Class Initialized
INFO - 2024-10-08 17:13:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:13:44 --> Input Class Initialized
INFO - 2024-10-08 17:13:44 --> Language Class Initialized
INFO - 2024-10-08 17:13:44 --> Language Class Initialized
INFO - 2024-10-08 17:13:44 --> Config Class Initialized
INFO - 2024-10-08 17:13:44 --> Loader Class Initialized
INFO - 2024-10-08 17:13:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:13:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:13:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:13:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:13:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:13:44 --> Controller Class Initialized
INFO - 2024-10-08 17:13:44 --> Final output sent to browser
DEBUG - 2024-10-08 17:13:44 --> Total execution time: 0.0438
INFO - 2024-10-08 17:15:29 --> Config Class Initialized
INFO - 2024-10-08 17:15:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:29 --> URI Class Initialized
INFO - 2024-10-08 17:15:29 --> Router Class Initialized
INFO - 2024-10-08 17:15:29 --> Output Class Initialized
INFO - 2024-10-08 17:15:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:29 --> Input Class Initialized
INFO - 2024-10-08 17:15:29 --> Language Class Initialized
INFO - 2024-10-08 17:15:29 --> Language Class Initialized
INFO - 2024-10-08 17:15:29 --> Config Class Initialized
INFO - 2024-10-08 17:15:29 --> Loader Class Initialized
INFO - 2024-10-08 17:15:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:29 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:15:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:29 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:29 --> Total execution time: 0.0515
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:40 --> URI Class Initialized
INFO - 2024-10-08 17:15:40 --> Router Class Initialized
INFO - 2024-10-08 17:15:40 --> Output Class Initialized
INFO - 2024-10-08 17:15:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:40 --> Input Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Loader Class Initialized
INFO - 2024-10-08 17:15:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:40 --> Controller Class Initialized
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:40 --> URI Class Initialized
INFO - 2024-10-08 17:15:40 --> Router Class Initialized
INFO - 2024-10-08 17:15:40 --> Output Class Initialized
INFO - 2024-10-08 17:15:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:40 --> Input Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Loader Class Initialized
INFO - 2024-10-08 17:15:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:40 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:40 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:40 --> Total execution time: 0.0328
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:40 --> URI Class Initialized
INFO - 2024-10-08 17:15:40 --> Router Class Initialized
INFO - 2024-10-08 17:15:40 --> Output Class Initialized
INFO - 2024-10-08 17:15:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:40 --> Input Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Language Class Initialized
INFO - 2024-10-08 17:15:40 --> Config Class Initialized
INFO - 2024-10-08 17:15:40 --> Loader Class Initialized
INFO - 2024-10-08 17:15:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:40 --> Controller Class Initialized
INFO - 2024-10-08 17:15:42 --> Config Class Initialized
INFO - 2024-10-08 17:15:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:42 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:42 --> URI Class Initialized
INFO - 2024-10-08 17:15:42 --> Router Class Initialized
INFO - 2024-10-08 17:15:42 --> Output Class Initialized
INFO - 2024-10-08 17:15:42 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:42 --> Input Class Initialized
INFO - 2024-10-08 17:15:42 --> Language Class Initialized
INFO - 2024-10-08 17:15:42 --> Language Class Initialized
INFO - 2024-10-08 17:15:42 --> Config Class Initialized
INFO - 2024-10-08 17:15:42 --> Loader Class Initialized
INFO - 2024-10-08 17:15:42 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:42 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:42 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:42 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:43 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:43 --> Controller Class Initialized
INFO - 2024-10-08 17:15:43 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:43 --> Total execution time: 0.0344
INFO - 2024-10-08 17:15:45 --> Config Class Initialized
INFO - 2024-10-08 17:15:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:45 --> URI Class Initialized
INFO - 2024-10-08 17:15:45 --> Router Class Initialized
INFO - 2024-10-08 17:15:45 --> Output Class Initialized
INFO - 2024-10-08 17:15:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:45 --> Input Class Initialized
INFO - 2024-10-08 17:15:45 --> Language Class Initialized
INFO - 2024-10-08 17:15:45 --> Language Class Initialized
INFO - 2024-10-08 17:15:45 --> Config Class Initialized
INFO - 2024-10-08 17:15:45 --> Loader Class Initialized
INFO - 2024-10-08 17:15:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:45 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:15:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:45 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:45 --> Total execution time: 0.0974
INFO - 2024-10-08 17:15:47 --> Config Class Initialized
INFO - 2024-10-08 17:15:47 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:47 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:47 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:47 --> URI Class Initialized
INFO - 2024-10-08 17:15:47 --> Router Class Initialized
INFO - 2024-10-08 17:15:47 --> Output Class Initialized
INFO - 2024-10-08 17:15:47 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:47 --> Input Class Initialized
INFO - 2024-10-08 17:15:47 --> Language Class Initialized
INFO - 2024-10-08 17:15:47 --> Language Class Initialized
INFO - 2024-10-08 17:15:47 --> Config Class Initialized
INFO - 2024-10-08 17:15:47 --> Loader Class Initialized
INFO - 2024-10-08 17:15:47 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:47 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:47 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:47 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:47 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:47 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:47 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:47 --> Total execution time: 0.0876
INFO - 2024-10-08 17:15:48 --> Config Class Initialized
INFO - 2024-10-08 17:15:48 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:48 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:48 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:48 --> URI Class Initialized
INFO - 2024-10-08 17:15:48 --> Router Class Initialized
INFO - 2024-10-08 17:15:48 --> Output Class Initialized
INFO - 2024-10-08 17:15:48 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:48 --> Input Class Initialized
INFO - 2024-10-08 17:15:48 --> Language Class Initialized
INFO - 2024-10-08 17:15:48 --> Language Class Initialized
INFO - 2024-10-08 17:15:48 --> Config Class Initialized
INFO - 2024-10-08 17:15:48 --> Loader Class Initialized
INFO - 2024-10-08 17:15:48 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:48 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:48 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:48 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:48 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:48 --> Controller Class Initialized
INFO - 2024-10-08 17:15:50 --> Config Class Initialized
INFO - 2024-10-08 17:15:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:50 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:50 --> URI Class Initialized
INFO - 2024-10-08 17:15:50 --> Router Class Initialized
INFO - 2024-10-08 17:15:50 --> Output Class Initialized
INFO - 2024-10-08 17:15:50 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:50 --> Input Class Initialized
INFO - 2024-10-08 17:15:50 --> Language Class Initialized
INFO - 2024-10-08 17:15:50 --> Language Class Initialized
INFO - 2024-10-08 17:15:50 --> Config Class Initialized
INFO - 2024-10-08 17:15:50 --> Loader Class Initialized
INFO - 2024-10-08 17:15:50 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:50 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:50 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:50 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:50 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:50 --> Controller Class Initialized
INFO - 2024-10-08 17:15:54 --> Config Class Initialized
INFO - 2024-10-08 17:15:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:54 --> URI Class Initialized
INFO - 2024-10-08 17:15:54 --> Router Class Initialized
INFO - 2024-10-08 17:15:54 --> Output Class Initialized
INFO - 2024-10-08 17:15:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:54 --> Input Class Initialized
INFO - 2024-10-08 17:15:54 --> Language Class Initialized
INFO - 2024-10-08 17:15:54 --> Language Class Initialized
INFO - 2024-10-08 17:15:54 --> Config Class Initialized
INFO - 2024-10-08 17:15:54 --> Loader Class Initialized
INFO - 2024-10-08 17:15:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:54 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:15:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:54 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:54 --> Total execution time: 0.0703
INFO - 2024-10-08 17:15:59 --> Config Class Initialized
INFO - 2024-10-08 17:15:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:59 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:59 --> URI Class Initialized
INFO - 2024-10-08 17:15:59 --> Router Class Initialized
INFO - 2024-10-08 17:15:59 --> Output Class Initialized
INFO - 2024-10-08 17:15:59 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:59 --> Input Class Initialized
INFO - 2024-10-08 17:15:59 --> Language Class Initialized
INFO - 2024-10-08 17:15:59 --> Language Class Initialized
INFO - 2024-10-08 17:15:59 --> Config Class Initialized
INFO - 2024-10-08 17:15:59 --> Loader Class Initialized
INFO - 2024-10-08 17:15:59 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:59 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:59 --> Controller Class Initialized
DEBUG - 2024-10-08 17:15:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:15:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:15:59 --> Final output sent to browser
DEBUG - 2024-10-08 17:15:59 --> Total execution time: 0.0323
INFO - 2024-10-08 17:15:59 --> Config Class Initialized
INFO - 2024-10-08 17:15:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:15:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:15:59 --> Utf8 Class Initialized
INFO - 2024-10-08 17:15:59 --> URI Class Initialized
INFO - 2024-10-08 17:15:59 --> Router Class Initialized
INFO - 2024-10-08 17:15:59 --> Output Class Initialized
INFO - 2024-10-08 17:15:59 --> Security Class Initialized
DEBUG - 2024-10-08 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:15:59 --> Input Class Initialized
INFO - 2024-10-08 17:15:59 --> Language Class Initialized
INFO - 2024-10-08 17:15:59 --> Language Class Initialized
INFO - 2024-10-08 17:15:59 --> Config Class Initialized
INFO - 2024-10-08 17:15:59 --> Loader Class Initialized
INFO - 2024-10-08 17:15:59 --> Helper loaded: url_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: file_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: form_helper
INFO - 2024-10-08 17:15:59 --> Helper loaded: my_helper
INFO - 2024-10-08 17:15:59 --> Database Driver Class Initialized
INFO - 2024-10-08 17:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:15:59 --> Controller Class Initialized
INFO - 2024-10-08 17:16:00 --> Config Class Initialized
INFO - 2024-10-08 17:16:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:16:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:16:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:16:00 --> URI Class Initialized
INFO - 2024-10-08 17:16:00 --> Router Class Initialized
INFO - 2024-10-08 17:16:00 --> Output Class Initialized
INFO - 2024-10-08 17:16:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:16:00 --> Input Class Initialized
INFO - 2024-10-08 17:16:00 --> Language Class Initialized
INFO - 2024-10-08 17:16:00 --> Language Class Initialized
INFO - 2024-10-08 17:16:00 --> Config Class Initialized
INFO - 2024-10-08 17:16:00 --> Loader Class Initialized
INFO - 2024-10-08 17:16:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:16:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:16:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:16:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:16:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:16:00 --> Controller Class Initialized
INFO - 2024-10-08 17:16:02 --> Config Class Initialized
INFO - 2024-10-08 17:16:02 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:16:02 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:16:02 --> Utf8 Class Initialized
INFO - 2024-10-08 17:16:02 --> URI Class Initialized
INFO - 2024-10-08 17:16:02 --> Router Class Initialized
INFO - 2024-10-08 17:16:02 --> Output Class Initialized
INFO - 2024-10-08 17:16:02 --> Security Class Initialized
DEBUG - 2024-10-08 17:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:16:02 --> Input Class Initialized
INFO - 2024-10-08 17:16:02 --> Language Class Initialized
INFO - 2024-10-08 17:16:02 --> Language Class Initialized
INFO - 2024-10-08 17:16:02 --> Config Class Initialized
INFO - 2024-10-08 17:16:02 --> Loader Class Initialized
INFO - 2024-10-08 17:16:02 --> Helper loaded: url_helper
INFO - 2024-10-08 17:16:02 --> Helper loaded: file_helper
INFO - 2024-10-08 17:16:02 --> Helper loaded: form_helper
INFO - 2024-10-08 17:16:02 --> Helper loaded: my_helper
INFO - 2024-10-08 17:16:02 --> Database Driver Class Initialized
INFO - 2024-10-08 17:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:16:02 --> Controller Class Initialized
DEBUG - 2024-10-08 17:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:16:02 --> Final output sent to browser
DEBUG - 2024-10-08 17:16:02 --> Total execution time: 0.1327
INFO - 2024-10-08 17:16:04 --> Config Class Initialized
INFO - 2024-10-08 17:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:16:04 --> Utf8 Class Initialized
INFO - 2024-10-08 17:16:04 --> URI Class Initialized
INFO - 2024-10-08 17:16:04 --> Router Class Initialized
INFO - 2024-10-08 17:16:04 --> Output Class Initialized
INFO - 2024-10-08 17:16:04 --> Security Class Initialized
DEBUG - 2024-10-08 17:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:16:04 --> Input Class Initialized
INFO - 2024-10-08 17:16:04 --> Language Class Initialized
INFO - 2024-10-08 17:16:04 --> Language Class Initialized
INFO - 2024-10-08 17:16:04 --> Config Class Initialized
INFO - 2024-10-08 17:16:04 --> Loader Class Initialized
INFO - 2024-10-08 17:16:04 --> Helper loaded: url_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: file_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: form_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: my_helper
INFO - 2024-10-08 17:16:04 --> Database Driver Class Initialized
INFO - 2024-10-08 17:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:16:04 --> Controller Class Initialized
DEBUG - 2024-10-08 17:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:16:04 --> Final output sent to browser
DEBUG - 2024-10-08 17:16:04 --> Total execution time: 0.0330
INFO - 2024-10-08 17:16:04 --> Config Class Initialized
INFO - 2024-10-08 17:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:16:04 --> Utf8 Class Initialized
INFO - 2024-10-08 17:16:04 --> URI Class Initialized
INFO - 2024-10-08 17:16:04 --> Router Class Initialized
INFO - 2024-10-08 17:16:04 --> Output Class Initialized
INFO - 2024-10-08 17:16:04 --> Security Class Initialized
DEBUG - 2024-10-08 17:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:16:04 --> Input Class Initialized
INFO - 2024-10-08 17:16:04 --> Language Class Initialized
INFO - 2024-10-08 17:16:04 --> Language Class Initialized
INFO - 2024-10-08 17:16:04 --> Config Class Initialized
INFO - 2024-10-08 17:16:04 --> Loader Class Initialized
INFO - 2024-10-08 17:16:04 --> Helper loaded: url_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: file_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: form_helper
INFO - 2024-10-08 17:16:04 --> Helper loaded: my_helper
INFO - 2024-10-08 17:16:04 --> Database Driver Class Initialized
INFO - 2024-10-08 17:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:16:04 --> Controller Class Initialized
INFO - 2024-10-08 17:16:05 --> Config Class Initialized
INFO - 2024-10-08 17:16:05 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:16:05 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:16:05 --> Utf8 Class Initialized
INFO - 2024-10-08 17:16:05 --> URI Class Initialized
INFO - 2024-10-08 17:16:05 --> Router Class Initialized
INFO - 2024-10-08 17:16:05 --> Output Class Initialized
INFO - 2024-10-08 17:16:05 --> Security Class Initialized
DEBUG - 2024-10-08 17:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:16:05 --> Input Class Initialized
INFO - 2024-10-08 17:16:05 --> Language Class Initialized
INFO - 2024-10-08 17:16:05 --> Language Class Initialized
INFO - 2024-10-08 17:16:05 --> Config Class Initialized
INFO - 2024-10-08 17:16:05 --> Loader Class Initialized
INFO - 2024-10-08 17:16:05 --> Helper loaded: url_helper
INFO - 2024-10-08 17:16:05 --> Helper loaded: file_helper
INFO - 2024-10-08 17:16:05 --> Helper loaded: form_helper
INFO - 2024-10-08 17:16:05 --> Helper loaded: my_helper
INFO - 2024-10-08 17:16:05 --> Database Driver Class Initialized
INFO - 2024-10-08 17:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:16:05 --> Controller Class Initialized
INFO - 2024-10-08 17:17:42 --> Config Class Initialized
INFO - 2024-10-08 17:17:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:42 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:42 --> URI Class Initialized
INFO - 2024-10-08 17:17:42 --> Router Class Initialized
INFO - 2024-10-08 17:17:42 --> Output Class Initialized
INFO - 2024-10-08 17:17:42 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:42 --> Input Class Initialized
INFO - 2024-10-08 17:17:42 --> Language Class Initialized
INFO - 2024-10-08 17:17:42 --> Language Class Initialized
INFO - 2024-10-08 17:17:42 --> Config Class Initialized
INFO - 2024-10-08 17:17:42 --> Loader Class Initialized
INFO - 2024-10-08 17:17:42 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:42 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:42 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:42 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:42 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:42 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:17:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:42 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:42 --> Total execution time: 0.0327
INFO - 2024-10-08 17:17:44 --> Config Class Initialized
INFO - 2024-10-08 17:17:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:44 --> URI Class Initialized
INFO - 2024-10-08 17:17:44 --> Router Class Initialized
INFO - 2024-10-08 17:17:44 --> Output Class Initialized
INFO - 2024-10-08 17:17:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:44 --> Input Class Initialized
INFO - 2024-10-08 17:17:44 --> Language Class Initialized
INFO - 2024-10-08 17:17:44 --> Language Class Initialized
INFO - 2024-10-08 17:17:44 --> Config Class Initialized
INFO - 2024-10-08 17:17:44 --> Loader Class Initialized
INFO - 2024-10-08 17:17:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:44 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:17:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:44 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:44 --> Total execution time: 0.0666
INFO - 2024-10-08 17:17:44 --> Config Class Initialized
INFO - 2024-10-08 17:17:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:44 --> URI Class Initialized
INFO - 2024-10-08 17:17:44 --> Router Class Initialized
INFO - 2024-10-08 17:17:44 --> Output Class Initialized
INFO - 2024-10-08 17:17:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:44 --> Input Class Initialized
INFO - 2024-10-08 17:17:44 --> Language Class Initialized
INFO - 2024-10-08 17:17:44 --> Language Class Initialized
INFO - 2024-10-08 17:17:44 --> Config Class Initialized
INFO - 2024-10-08 17:17:44 --> Loader Class Initialized
INFO - 2024-10-08 17:17:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:44 --> Controller Class Initialized
INFO - 2024-10-08 17:17:45 --> Config Class Initialized
INFO - 2024-10-08 17:17:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:45 --> URI Class Initialized
INFO - 2024-10-08 17:17:45 --> Router Class Initialized
INFO - 2024-10-08 17:17:45 --> Output Class Initialized
INFO - 2024-10-08 17:17:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:45 --> Input Class Initialized
INFO - 2024-10-08 17:17:45 --> Language Class Initialized
INFO - 2024-10-08 17:17:45 --> Language Class Initialized
INFO - 2024-10-08 17:17:45 --> Config Class Initialized
INFO - 2024-10-08 17:17:45 --> Loader Class Initialized
INFO - 2024-10-08 17:17:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:45 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:17:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:45 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:45 --> Total execution time: 0.0331
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:51 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:51 --> URI Class Initialized
INFO - 2024-10-08 17:17:51 --> Router Class Initialized
INFO - 2024-10-08 17:17:51 --> Output Class Initialized
INFO - 2024-10-08 17:17:51 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:51 --> Input Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Loader Class Initialized
INFO - 2024-10-08 17:17:51 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:51 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:51 --> Controller Class Initialized
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:51 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:51 --> URI Class Initialized
INFO - 2024-10-08 17:17:51 --> Router Class Initialized
INFO - 2024-10-08 17:17:51 --> Output Class Initialized
INFO - 2024-10-08 17:17:51 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:51 --> Input Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Loader Class Initialized
INFO - 2024-10-08 17:17:51 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:51 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:51 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:51 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:51 --> Total execution time: 0.0532
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:51 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:51 --> URI Class Initialized
INFO - 2024-10-08 17:17:51 --> Router Class Initialized
INFO - 2024-10-08 17:17:51 --> Output Class Initialized
INFO - 2024-10-08 17:17:51 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:51 --> Input Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Language Class Initialized
INFO - 2024-10-08 17:17:51 --> Config Class Initialized
INFO - 2024-10-08 17:17:51 --> Loader Class Initialized
INFO - 2024-10-08 17:17:51 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:51 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:51 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:51 --> Controller Class Initialized
INFO - 2024-10-08 17:17:53 --> Config Class Initialized
INFO - 2024-10-08 17:17:53 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:53 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:53 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:53 --> URI Class Initialized
INFO - 2024-10-08 17:17:53 --> Router Class Initialized
INFO - 2024-10-08 17:17:53 --> Output Class Initialized
INFO - 2024-10-08 17:17:53 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:53 --> Input Class Initialized
INFO - 2024-10-08 17:17:53 --> Language Class Initialized
INFO - 2024-10-08 17:17:53 --> Language Class Initialized
INFO - 2024-10-08 17:17:53 --> Config Class Initialized
INFO - 2024-10-08 17:17:53 --> Loader Class Initialized
INFO - 2024-10-08 17:17:53 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:53 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:53 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:53 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:53 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:53 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:53 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:53 --> Total execution time: 0.0386
INFO - 2024-10-08 17:17:54 --> Config Class Initialized
INFO - 2024-10-08 17:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:54 --> URI Class Initialized
INFO - 2024-10-08 17:17:54 --> Router Class Initialized
INFO - 2024-10-08 17:17:54 --> Output Class Initialized
INFO - 2024-10-08 17:17:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:54 --> Input Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:54 --> Config Class Initialized
INFO - 2024-10-08 17:17:54 --> Loader Class Initialized
INFO - 2024-10-08 17:17:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:54 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:17:54 --> Config Class Initialized
INFO - 2024-10-08 17:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:54 --> URI Class Initialized
INFO - 2024-10-08 17:17:54 --> Router Class Initialized
INFO - 2024-10-08 17:17:54 --> Output Class Initialized
INFO - 2024-10-08 17:17:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:54 --> Input Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:54 --> Config Class Initialized
INFO - 2024-10-08 17:17:54 --> Loader Class Initialized
INFO - 2024-10-08 17:17:54 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:54 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:54 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:54 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:54 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:54 --> Total execution time: 0.0798
INFO - 2024-10-08 17:17:54 --> Config Class Initialized
INFO - 2024-10-08 17:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:54 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:54 --> URI Class Initialized
INFO - 2024-10-08 17:17:54 --> Router Class Initialized
INFO - 2024-10-08 17:17:54 --> Output Class Initialized
INFO - 2024-10-08 17:17:54 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:54 --> Input Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:54 --> Language Class Initialized
INFO - 2024-10-08 17:17:55 --> Config Class Initialized
INFO - 2024-10-08 17:17:55 --> Loader Class Initialized
INFO - 2024-10-08 17:17:55 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:55 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:55 --> Controller Class Initialized
INFO - 2024-10-08 17:17:55 --> Config Class Initialized
INFO - 2024-10-08 17:17:55 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:17:55 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:17:55 --> Utf8 Class Initialized
INFO - 2024-10-08 17:17:55 --> URI Class Initialized
INFO - 2024-10-08 17:17:55 --> Router Class Initialized
INFO - 2024-10-08 17:17:55 --> Output Class Initialized
INFO - 2024-10-08 17:17:55 --> Security Class Initialized
DEBUG - 2024-10-08 17:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:17:55 --> Input Class Initialized
INFO - 2024-10-08 17:17:55 --> Language Class Initialized
INFO - 2024-10-08 17:17:55 --> Language Class Initialized
INFO - 2024-10-08 17:17:55 --> Config Class Initialized
INFO - 2024-10-08 17:17:55 --> Loader Class Initialized
INFO - 2024-10-08 17:17:55 --> Helper loaded: url_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: file_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: form_helper
INFO - 2024-10-08 17:17:55 --> Helper loaded: my_helper
INFO - 2024-10-08 17:17:55 --> Database Driver Class Initialized
INFO - 2024-10-08 17:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:17:55 --> Controller Class Initialized
DEBUG - 2024-10-08 17:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:17:55 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:55 --> Total execution time: 0.0686
INFO - 2024-10-08 17:17:57 --> Final output sent to browser
DEBUG - 2024-10-08 17:17:57 --> Total execution time: 3.2031
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:00 --> URI Class Initialized
INFO - 2024-10-08 17:18:00 --> Router Class Initialized
INFO - 2024-10-08 17:18:00 --> Output Class Initialized
INFO - 2024-10-08 17:18:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:00 --> Input Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Loader Class Initialized
INFO - 2024-10-08 17:18:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:00 --> Controller Class Initialized
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:00 --> URI Class Initialized
INFO - 2024-10-08 17:18:00 --> Router Class Initialized
INFO - 2024-10-08 17:18:00 --> Output Class Initialized
INFO - 2024-10-08 17:18:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:00 --> Input Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Loader Class Initialized
INFO - 2024-10-08 17:18:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:00 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:00 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:00 --> Total execution time: 0.0354
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:00 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:00 --> URI Class Initialized
INFO - 2024-10-08 17:18:00 --> Router Class Initialized
INFO - 2024-10-08 17:18:00 --> Output Class Initialized
INFO - 2024-10-08 17:18:00 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:00 --> Input Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Language Class Initialized
INFO - 2024-10-08 17:18:00 --> Config Class Initialized
INFO - 2024-10-08 17:18:00 --> Loader Class Initialized
INFO - 2024-10-08 17:18:00 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:00 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:00 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:00 --> Controller Class Initialized
INFO - 2024-10-08 17:18:01 --> Config Class Initialized
INFO - 2024-10-08 17:18:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:01 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:01 --> URI Class Initialized
INFO - 2024-10-08 17:18:01 --> Router Class Initialized
INFO - 2024-10-08 17:18:01 --> Output Class Initialized
INFO - 2024-10-08 17:18:01 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:01 --> Input Class Initialized
INFO - 2024-10-08 17:18:01 --> Language Class Initialized
INFO - 2024-10-08 17:18:01 --> Language Class Initialized
INFO - 2024-10-08 17:18:01 --> Config Class Initialized
INFO - 2024-10-08 17:18:01 --> Loader Class Initialized
INFO - 2024-10-08 17:18:01 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:01 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:01 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:01 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:01 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:01 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:18:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:01 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:01 --> Total execution time: 0.1592
INFO - 2024-10-08 17:18:03 --> Config Class Initialized
INFO - 2024-10-08 17:18:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:03 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:03 --> URI Class Initialized
INFO - 2024-10-08 17:18:03 --> Router Class Initialized
INFO - 2024-10-08 17:18:03 --> Output Class Initialized
INFO - 2024-10-08 17:18:03 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:03 --> Input Class Initialized
INFO - 2024-10-08 17:18:03 --> Language Class Initialized
INFO - 2024-10-08 17:18:03 --> Language Class Initialized
INFO - 2024-10-08 17:18:03 --> Config Class Initialized
INFO - 2024-10-08 17:18:03 --> Loader Class Initialized
INFO - 2024-10-08 17:18:03 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:03 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:03 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:03 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:03 --> Total execution time: 0.0384
INFO - 2024-10-08 17:18:03 --> Config Class Initialized
INFO - 2024-10-08 17:18:03 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:03 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:03 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:03 --> URI Class Initialized
INFO - 2024-10-08 17:18:03 --> Router Class Initialized
INFO - 2024-10-08 17:18:03 --> Output Class Initialized
INFO - 2024-10-08 17:18:03 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:03 --> Input Class Initialized
INFO - 2024-10-08 17:18:03 --> Language Class Initialized
INFO - 2024-10-08 17:18:03 --> Language Class Initialized
INFO - 2024-10-08 17:18:03 --> Config Class Initialized
INFO - 2024-10-08 17:18:03 --> Loader Class Initialized
INFO - 2024-10-08 17:18:03 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:03 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:03 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:03 --> Controller Class Initialized
INFO - 2024-10-08 17:18:04 --> Config Class Initialized
INFO - 2024-10-08 17:18:04 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:04 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:04 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:04 --> URI Class Initialized
INFO - 2024-10-08 17:18:04 --> Router Class Initialized
INFO - 2024-10-08 17:18:04 --> Output Class Initialized
INFO - 2024-10-08 17:18:04 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:04 --> Input Class Initialized
INFO - 2024-10-08 17:18:04 --> Language Class Initialized
INFO - 2024-10-08 17:18:04 --> Language Class Initialized
INFO - 2024-10-08 17:18:04 --> Config Class Initialized
INFO - 2024-10-08 17:18:04 --> Loader Class Initialized
INFO - 2024-10-08 17:18:04 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:04 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:04 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:04 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:04 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:04 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:04 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:04 --> Total execution time: 0.0342
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:10 --> URI Class Initialized
INFO - 2024-10-08 17:18:10 --> Router Class Initialized
INFO - 2024-10-08 17:18:10 --> Output Class Initialized
INFO - 2024-10-08 17:18:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:10 --> Input Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Loader Class Initialized
INFO - 2024-10-08 17:18:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:10 --> Controller Class Initialized
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:10 --> URI Class Initialized
INFO - 2024-10-08 17:18:10 --> Router Class Initialized
INFO - 2024-10-08 17:18:10 --> Output Class Initialized
INFO - 2024-10-08 17:18:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:10 --> Input Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Loader Class Initialized
INFO - 2024-10-08 17:18:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:10 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:10 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:10 --> Total execution time: 0.0357
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:10 --> URI Class Initialized
INFO - 2024-10-08 17:18:10 --> Router Class Initialized
INFO - 2024-10-08 17:18:10 --> Output Class Initialized
INFO - 2024-10-08 17:18:10 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:10 --> Input Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Language Class Initialized
INFO - 2024-10-08 17:18:10 --> Config Class Initialized
INFO - 2024-10-08 17:18:10 --> Loader Class Initialized
INFO - 2024-10-08 17:18:10 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:10 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:10 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:10 --> Controller Class Initialized
INFO - 2024-10-08 17:18:11 --> Config Class Initialized
INFO - 2024-10-08 17:18:11 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:11 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:11 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:11 --> URI Class Initialized
INFO - 2024-10-08 17:18:11 --> Router Class Initialized
INFO - 2024-10-08 17:18:11 --> Output Class Initialized
INFO - 2024-10-08 17:18:11 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:11 --> Input Class Initialized
INFO - 2024-10-08 17:18:11 --> Language Class Initialized
INFO - 2024-10-08 17:18:11 --> Language Class Initialized
INFO - 2024-10-08 17:18:11 --> Config Class Initialized
INFO - 2024-10-08 17:18:11 --> Loader Class Initialized
INFO - 2024-10-08 17:18:11 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:11 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:11 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:11 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:11 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:11 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:11 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:11 --> Total execution time: 0.0373
INFO - 2024-10-08 17:18:13 --> Config Class Initialized
INFO - 2024-10-08 17:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:13 --> URI Class Initialized
INFO - 2024-10-08 17:18:13 --> Router Class Initialized
INFO - 2024-10-08 17:18:13 --> Output Class Initialized
INFO - 2024-10-08 17:18:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:13 --> Input Class Initialized
INFO - 2024-10-08 17:18:13 --> Language Class Initialized
INFO - 2024-10-08 17:18:13 --> Language Class Initialized
INFO - 2024-10-08 17:18:13 --> Config Class Initialized
INFO - 2024-10-08 17:18:13 --> Loader Class Initialized
INFO - 2024-10-08 17:18:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:13 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:13 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:13 --> Total execution time: 0.0662
INFO - 2024-10-08 17:18:13 --> Config Class Initialized
INFO - 2024-10-08 17:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:13 --> URI Class Initialized
INFO - 2024-10-08 17:18:13 --> Router Class Initialized
INFO - 2024-10-08 17:18:13 --> Output Class Initialized
INFO - 2024-10-08 17:18:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:13 --> Input Class Initialized
INFO - 2024-10-08 17:18:13 --> Language Class Initialized
INFO - 2024-10-08 17:18:13 --> Language Class Initialized
INFO - 2024-10-08 17:18:13 --> Config Class Initialized
INFO - 2024-10-08 17:18:13 --> Loader Class Initialized
INFO - 2024-10-08 17:18:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:13 --> Controller Class Initialized
INFO - 2024-10-08 17:18:14 --> Config Class Initialized
INFO - 2024-10-08 17:18:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:14 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:14 --> URI Class Initialized
INFO - 2024-10-08 17:18:14 --> Router Class Initialized
INFO - 2024-10-08 17:18:14 --> Output Class Initialized
INFO - 2024-10-08 17:18:14 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:14 --> Input Class Initialized
INFO - 2024-10-08 17:18:14 --> Language Class Initialized
INFO - 2024-10-08 17:18:14 --> Language Class Initialized
INFO - 2024-10-08 17:18:14 --> Config Class Initialized
INFO - 2024-10-08 17:18:14 --> Loader Class Initialized
INFO - 2024-10-08 17:18:14 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:14 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:14 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:18:14 --> Config Class Initialized
INFO - 2024-10-08 17:18:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:14 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:14 --> URI Class Initialized
INFO - 2024-10-08 17:18:14 --> Router Class Initialized
INFO - 2024-10-08 17:18:14 --> Output Class Initialized
INFO - 2024-10-08 17:18:14 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:14 --> Input Class Initialized
INFO - 2024-10-08 17:18:14 --> Language Class Initialized
INFO - 2024-10-08 17:18:14 --> Language Class Initialized
INFO - 2024-10-08 17:18:14 --> Config Class Initialized
INFO - 2024-10-08 17:18:14 --> Loader Class Initialized
INFO - 2024-10-08 17:18:14 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:14 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:14 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:14 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:14 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:14 --> Total execution time: 0.0673
INFO - 2024-10-08 17:18:17 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:17 --> Total execution time: 3.3434
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:20 --> URI Class Initialized
INFO - 2024-10-08 17:18:20 --> Router Class Initialized
INFO - 2024-10-08 17:18:20 --> Output Class Initialized
INFO - 2024-10-08 17:18:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:20 --> Input Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Loader Class Initialized
INFO - 2024-10-08 17:18:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:20 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:20 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:20 --> Total execution time: 0.0393
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:20 --> URI Class Initialized
INFO - 2024-10-08 17:18:20 --> Router Class Initialized
INFO - 2024-10-08 17:18:20 --> Output Class Initialized
INFO - 2024-10-08 17:18:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:20 --> Input Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Loader Class Initialized
INFO - 2024-10-08 17:18:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:20 --> Controller Class Initialized
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:20 --> URI Class Initialized
INFO - 2024-10-08 17:18:20 --> Router Class Initialized
INFO - 2024-10-08 17:18:20 --> Output Class Initialized
INFO - 2024-10-08 17:18:20 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:20 --> Input Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Language Class Initialized
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Loader Class Initialized
INFO - 2024-10-08 17:18:20 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:20 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:20 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:20 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:20 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:20 --> Total execution time: 0.0684
INFO - 2024-10-08 17:18:20 --> Config Class Initialized
INFO - 2024-10-08 17:18:20 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:20 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:20 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:20 --> URI Class Initialized
INFO - 2024-10-08 17:18:20 --> Router Class Initialized
INFO - 2024-10-08 17:18:21 --> Output Class Initialized
INFO - 2024-10-08 17:18:21 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:21 --> Input Class Initialized
INFO - 2024-10-08 17:18:21 --> Language Class Initialized
INFO - 2024-10-08 17:18:21 --> Language Class Initialized
INFO - 2024-10-08 17:18:21 --> Config Class Initialized
INFO - 2024-10-08 17:18:21 --> Loader Class Initialized
INFO - 2024-10-08 17:18:21 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:21 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:21 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:21 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:21 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:21 --> Controller Class Initialized
INFO - 2024-10-08 17:18:22 --> Config Class Initialized
INFO - 2024-10-08 17:18:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:22 --> URI Class Initialized
INFO - 2024-10-08 17:18:22 --> Router Class Initialized
INFO - 2024-10-08 17:18:22 --> Output Class Initialized
INFO - 2024-10-08 17:18:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:22 --> Input Class Initialized
INFO - 2024-10-08 17:18:22 --> Language Class Initialized
INFO - 2024-10-08 17:18:22 --> Language Class Initialized
INFO - 2024-10-08 17:18:22 --> Config Class Initialized
INFO - 2024-10-08 17:18:22 --> Loader Class Initialized
INFO - 2024-10-08 17:18:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:22 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:22 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:22 --> Total execution time: 0.0366
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:23 --> Total execution time: 0.0626
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:23 --> Total execution time: 0.0417
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:23 --> URI Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Router Class Initialized
INFO - 2024-10-08 17:18:23 --> Output Class Initialized
INFO - 2024-10-08 17:18:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:23 --> Input Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Language Class Initialized
INFO - 2024-10-08 17:18:23 --> Config Class Initialized
INFO - 2024-10-08 17:18:23 --> Loader Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
INFO - 2024-10-08 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:23 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 17:18:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:23 --> Total execution time: 0.1443
INFO - 2024-10-08 17:18:24 --> Config Class Initialized
INFO - 2024-10-08 17:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:24 --> URI Class Initialized
INFO - 2024-10-08 17:18:24 --> Router Class Initialized
INFO - 2024-10-08 17:18:24 --> Output Class Initialized
INFO - 2024-10-08 17:18:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:24 --> Input Class Initialized
INFO - 2024-10-08 17:18:24 --> Language Class Initialized
INFO - 2024-10-08 17:18:24 --> Language Class Initialized
INFO - 2024-10-08 17:18:24 --> Config Class Initialized
INFO - 2024-10-08 17:18:24 --> Loader Class Initialized
INFO - 2024-10-08 17:18:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:24 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:24 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:24 --> Total execution time: 0.0478
INFO - 2024-10-08 17:18:25 --> Config Class Initialized
INFO - 2024-10-08 17:18:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:25 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:25 --> URI Class Initialized
INFO - 2024-10-08 17:18:25 --> Router Class Initialized
INFO - 2024-10-08 17:18:25 --> Output Class Initialized
INFO - 2024-10-08 17:18:25 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:25 --> Input Class Initialized
INFO - 2024-10-08 17:18:25 --> Language Class Initialized
INFO - 2024-10-08 17:18:25 --> Language Class Initialized
INFO - 2024-10-08 17:18:25 --> Config Class Initialized
INFO - 2024-10-08 17:18:25 --> Loader Class Initialized
INFO - 2024-10-08 17:18:25 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:25 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:25 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:25 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:25 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:25 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:25 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:25 --> Total execution time: 0.1035
INFO - 2024-10-08 17:18:29 --> Config Class Initialized
INFO - 2024-10-08 17:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:29 --> URI Class Initialized
INFO - 2024-10-08 17:18:29 --> Router Class Initialized
INFO - 2024-10-08 17:18:29 --> Output Class Initialized
INFO - 2024-10-08 17:18:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:29 --> Input Class Initialized
INFO - 2024-10-08 17:18:29 --> Language Class Initialized
INFO - 2024-10-08 17:18:29 --> Language Class Initialized
INFO - 2024-10-08 17:18:29 --> Config Class Initialized
INFO - 2024-10-08 17:18:29 --> Loader Class Initialized
INFO - 2024-10-08 17:18:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:29 --> Controller Class Initialized
INFO - 2024-10-08 17:18:29 --> Config Class Initialized
INFO - 2024-10-08 17:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:29 --> URI Class Initialized
INFO - 2024-10-08 17:18:29 --> Router Class Initialized
INFO - 2024-10-08 17:18:29 --> Output Class Initialized
INFO - 2024-10-08 17:18:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:29 --> Input Class Initialized
INFO - 2024-10-08 17:18:29 --> Language Class Initialized
INFO - 2024-10-08 17:18:29 --> Language Class Initialized
INFO - 2024-10-08 17:18:29 --> Config Class Initialized
INFO - 2024-10-08 17:18:29 --> Loader Class Initialized
INFO - 2024-10-08 17:18:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:29 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:29 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:29 --> Total execution time: 0.0731
INFO - 2024-10-08 17:18:30 --> Config Class Initialized
INFO - 2024-10-08 17:18:30 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:30 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:30 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:30 --> URI Class Initialized
INFO - 2024-10-08 17:18:30 --> Router Class Initialized
INFO - 2024-10-08 17:18:30 --> Output Class Initialized
INFO - 2024-10-08 17:18:30 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:30 --> Input Class Initialized
INFO - 2024-10-08 17:18:30 --> Language Class Initialized
INFO - 2024-10-08 17:18:30 --> Language Class Initialized
INFO - 2024-10-08 17:18:30 --> Config Class Initialized
INFO - 2024-10-08 17:18:30 --> Loader Class Initialized
INFO - 2024-10-08 17:18:30 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:30 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:30 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:30 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:30 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:30 --> Controller Class Initialized
INFO - 2024-10-08 17:18:31 --> Config Class Initialized
INFO - 2024-10-08 17:18:31 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:31 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:31 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:31 --> URI Class Initialized
INFO - 2024-10-08 17:18:31 --> Router Class Initialized
INFO - 2024-10-08 17:18:31 --> Output Class Initialized
INFO - 2024-10-08 17:18:31 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:31 --> Input Class Initialized
INFO - 2024-10-08 17:18:31 --> Language Class Initialized
INFO - 2024-10-08 17:18:31 --> Language Class Initialized
INFO - 2024-10-08 17:18:31 --> Config Class Initialized
INFO - 2024-10-08 17:18:31 --> Loader Class Initialized
INFO - 2024-10-08 17:18:31 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:31 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:31 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:31 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:31 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:31 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:31 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:31 --> Total execution time: 0.0266
INFO - 2024-10-08 17:18:33 --> Config Class Initialized
INFO - 2024-10-08 17:18:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:33 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:33 --> URI Class Initialized
INFO - 2024-10-08 17:18:33 --> Router Class Initialized
INFO - 2024-10-08 17:18:33 --> Output Class Initialized
INFO - 2024-10-08 17:18:33 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:33 --> Input Class Initialized
INFO - 2024-10-08 17:18:33 --> Language Class Initialized
INFO - 2024-10-08 17:18:33 --> Language Class Initialized
INFO - 2024-10-08 17:18:33 --> Config Class Initialized
INFO - 2024-10-08 17:18:33 --> Loader Class Initialized
INFO - 2024-10-08 17:18:33 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:33 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:33 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:33 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:33 --> Total execution time: 0.0361
INFO - 2024-10-08 17:18:33 --> Config Class Initialized
INFO - 2024-10-08 17:18:33 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:33 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:33 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:33 --> URI Class Initialized
INFO - 2024-10-08 17:18:33 --> Router Class Initialized
INFO - 2024-10-08 17:18:33 --> Output Class Initialized
INFO - 2024-10-08 17:18:33 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:33 --> Input Class Initialized
INFO - 2024-10-08 17:18:33 --> Language Class Initialized
INFO - 2024-10-08 17:18:33 --> Language Class Initialized
INFO - 2024-10-08 17:18:33 --> Config Class Initialized
INFO - 2024-10-08 17:18:33 --> Loader Class Initialized
INFO - 2024-10-08 17:18:33 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:33 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:33 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:33 --> Controller Class Initialized
INFO - 2024-10-08 17:18:34 --> Config Class Initialized
INFO - 2024-10-08 17:18:34 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:34 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:34 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:34 --> URI Class Initialized
INFO - 2024-10-08 17:18:34 --> Router Class Initialized
INFO - 2024-10-08 17:18:34 --> Output Class Initialized
INFO - 2024-10-08 17:18:34 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:34 --> Input Class Initialized
INFO - 2024-10-08 17:18:34 --> Language Class Initialized
INFO - 2024-10-08 17:18:34 --> Language Class Initialized
INFO - 2024-10-08 17:18:34 --> Config Class Initialized
INFO - 2024-10-08 17:18:34 --> Loader Class Initialized
INFO - 2024-10-08 17:18:34 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:34 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:34 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:34 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:34 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:34 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-08 17:18:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:34 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:34 --> Total execution time: 0.0374
INFO - 2024-10-08 17:18:35 --> Config Class Initialized
INFO - 2024-10-08 17:18:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:35 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:35 --> URI Class Initialized
INFO - 2024-10-08 17:18:35 --> Router Class Initialized
INFO - 2024-10-08 17:18:35 --> Output Class Initialized
INFO - 2024-10-08 17:18:35 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:35 --> Input Class Initialized
INFO - 2024-10-08 17:18:35 --> Language Class Initialized
INFO - 2024-10-08 17:18:35 --> Language Class Initialized
INFO - 2024-10-08 17:18:35 --> Config Class Initialized
INFO - 2024-10-08 17:18:35 --> Loader Class Initialized
INFO - 2024-10-08 17:18:35 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:35 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:35 --> Controller Class Initialized
INFO - 2024-10-08 17:18:35 --> Config Class Initialized
INFO - 2024-10-08 17:18:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:35 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:35 --> URI Class Initialized
INFO - 2024-10-08 17:18:35 --> Router Class Initialized
INFO - 2024-10-08 17:18:35 --> Output Class Initialized
INFO - 2024-10-08 17:18:35 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:35 --> Input Class Initialized
INFO - 2024-10-08 17:18:35 --> Language Class Initialized
INFO - 2024-10-08 17:18:35 --> Language Class Initialized
INFO - 2024-10-08 17:18:35 --> Config Class Initialized
INFO - 2024-10-08 17:18:35 --> Loader Class Initialized
INFO - 2024-10-08 17:18:35 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:35 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:35 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:35 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:35 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:35 --> Total execution time: 0.0363
INFO - 2024-10-08 17:18:36 --> Config Class Initialized
INFO - 2024-10-08 17:18:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:36 --> URI Class Initialized
INFO - 2024-10-08 17:18:36 --> Router Class Initialized
INFO - 2024-10-08 17:18:36 --> Output Class Initialized
INFO - 2024-10-08 17:18:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:36 --> Input Class Initialized
INFO - 2024-10-08 17:18:36 --> Language Class Initialized
INFO - 2024-10-08 17:18:36 --> Language Class Initialized
INFO - 2024-10-08 17:18:36 --> Config Class Initialized
INFO - 2024-10-08 17:18:36 --> Loader Class Initialized
INFO - 2024-10-08 17:18:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:36 --> Controller Class Initialized
INFO - 2024-10-08 17:18:39 --> Config Class Initialized
INFO - 2024-10-08 17:18:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:39 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:39 --> URI Class Initialized
INFO - 2024-10-08 17:18:39 --> Router Class Initialized
INFO - 2024-10-08 17:18:39 --> Output Class Initialized
INFO - 2024-10-08 17:18:39 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:39 --> Input Class Initialized
INFO - 2024-10-08 17:18:39 --> Language Class Initialized
INFO - 2024-10-08 17:18:39 --> Language Class Initialized
INFO - 2024-10-08 17:18:39 --> Config Class Initialized
INFO - 2024-10-08 17:18:39 --> Loader Class Initialized
INFO - 2024-10-08 17:18:39 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:39 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:39 --> Controller Class Initialized
INFO - 2024-10-08 17:18:39 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:39 --> Total execution time: 0.1026
INFO - 2024-10-08 17:18:39 --> Config Class Initialized
INFO - 2024-10-08 17:18:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:39 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:39 --> URI Class Initialized
INFO - 2024-10-08 17:18:39 --> Router Class Initialized
INFO - 2024-10-08 17:18:39 --> Output Class Initialized
INFO - 2024-10-08 17:18:39 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:39 --> Input Class Initialized
INFO - 2024-10-08 17:18:39 --> Language Class Initialized
INFO - 2024-10-08 17:18:39 --> Language Class Initialized
INFO - 2024-10-08 17:18:39 --> Config Class Initialized
INFO - 2024-10-08 17:18:39 --> Loader Class Initialized
INFO - 2024-10-08 17:18:39 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:39 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:39 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:39 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:40 --> URI Class Initialized
INFO - 2024-10-08 17:18:40 --> Router Class Initialized
INFO - 2024-10-08 17:18:40 --> Output Class Initialized
INFO - 2024-10-08 17:18:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:40 --> Input Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Loader Class Initialized
INFO - 2024-10-08 17:18:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:40 --> Controller Class Initialized
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:40 --> URI Class Initialized
INFO - 2024-10-08 17:18:40 --> Router Class Initialized
INFO - 2024-10-08 17:18:40 --> Output Class Initialized
INFO - 2024-10-08 17:18:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:40 --> Input Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Loader Class Initialized
INFO - 2024-10-08 17:18:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:40 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:18:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:40 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:40 --> Total execution time: 0.0866
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:40 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:40 --> URI Class Initialized
INFO - 2024-10-08 17:18:40 --> Router Class Initialized
INFO - 2024-10-08 17:18:40 --> Output Class Initialized
INFO - 2024-10-08 17:18:40 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:40 --> Input Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Language Class Initialized
INFO - 2024-10-08 17:18:40 --> Config Class Initialized
INFO - 2024-10-08 17:18:40 --> Loader Class Initialized
INFO - 2024-10-08 17:18:40 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:40 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:40 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:40 --> Controller Class Initialized
INFO - 2024-10-08 17:18:42 --> Config Class Initialized
INFO - 2024-10-08 17:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:42 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:42 --> URI Class Initialized
INFO - 2024-10-08 17:18:42 --> Router Class Initialized
INFO - 2024-10-08 17:18:42 --> Output Class Initialized
INFO - 2024-10-08 17:18:42 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:42 --> Input Class Initialized
INFO - 2024-10-08 17:18:42 --> Language Class Initialized
INFO - 2024-10-08 17:18:42 --> Language Class Initialized
INFO - 2024-10-08 17:18:42 --> Config Class Initialized
INFO - 2024-10-08 17:18:42 --> Loader Class Initialized
INFO - 2024-10-08 17:18:42 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:42 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:42 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:42 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:42 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:42 --> Controller Class Initialized
INFO - 2024-10-08 17:18:42 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:42 --> Total execution time: 0.0972
INFO - 2024-10-08 17:18:43 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:43 --> Total execution time: 4.1853
INFO - 2024-10-08 17:18:44 --> Config Class Initialized
INFO - 2024-10-08 17:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:44 --> URI Class Initialized
INFO - 2024-10-08 17:18:44 --> Router Class Initialized
INFO - 2024-10-08 17:18:44 --> Output Class Initialized
INFO - 2024-10-08 17:18:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:44 --> Input Class Initialized
INFO - 2024-10-08 17:18:44 --> Language Class Initialized
INFO - 2024-10-08 17:18:44 --> Language Class Initialized
INFO - 2024-10-08 17:18:44 --> Config Class Initialized
INFO - 2024-10-08 17:18:44 --> Loader Class Initialized
INFO - 2024-10-08 17:18:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:44 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:44 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:44 --> Total execution time: 0.0360
INFO - 2024-10-08 17:18:45 --> Config Class Initialized
INFO - 2024-10-08 17:18:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:45 --> URI Class Initialized
INFO - 2024-10-08 17:18:45 --> Router Class Initialized
INFO - 2024-10-08 17:18:45 --> Output Class Initialized
INFO - 2024-10-08 17:18:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:45 --> Input Class Initialized
INFO - 2024-10-08 17:18:45 --> Language Class Initialized
INFO - 2024-10-08 17:18:45 --> Language Class Initialized
INFO - 2024-10-08 17:18:45 --> Config Class Initialized
INFO - 2024-10-08 17:18:45 --> Loader Class Initialized
INFO - 2024-10-08 17:18:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:45 --> Controller Class Initialized
INFO - 2024-10-08 17:18:45 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:45 --> Total execution time: 0.0328
INFO - 2024-10-08 17:18:46 --> Config Class Initialized
INFO - 2024-10-08 17:18:46 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:46 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:46 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:46 --> URI Class Initialized
INFO - 2024-10-08 17:18:46 --> Router Class Initialized
INFO - 2024-10-08 17:18:46 --> Output Class Initialized
INFO - 2024-10-08 17:18:46 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:46 --> Input Class Initialized
INFO - 2024-10-08 17:18:46 --> Language Class Initialized
INFO - 2024-10-08 17:18:46 --> Language Class Initialized
INFO - 2024-10-08 17:18:46 --> Config Class Initialized
INFO - 2024-10-08 17:18:46 --> Loader Class Initialized
INFO - 2024-10-08 17:18:46 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:46 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:46 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:46 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:46 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:46 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:18:50 --> Config Class Initialized
INFO - 2024-10-08 17:18:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:50 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:50 --> URI Class Initialized
INFO - 2024-10-08 17:18:50 --> Router Class Initialized
INFO - 2024-10-08 17:18:50 --> Output Class Initialized
INFO - 2024-10-08 17:18:50 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:50 --> Input Class Initialized
INFO - 2024-10-08 17:18:50 --> Language Class Initialized
INFO - 2024-10-08 17:18:50 --> Language Class Initialized
INFO - 2024-10-08 17:18:50 --> Config Class Initialized
INFO - 2024-10-08 17:18:50 --> Loader Class Initialized
INFO - 2024-10-08 17:18:50 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:50 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:50 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:50 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:50 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:50 --> Controller Class Initialized
INFO - 2024-10-08 17:18:50 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:50 --> Total execution time: 0.1734
INFO - 2024-10-08 17:18:52 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:52 --> Total execution time: 5.4423
INFO - 2024-10-08 17:18:55 --> Config Class Initialized
INFO - 2024-10-08 17:18:55 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:55 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:55 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:55 --> URI Class Initialized
INFO - 2024-10-08 17:18:55 --> Router Class Initialized
INFO - 2024-10-08 17:18:55 --> Output Class Initialized
INFO - 2024-10-08 17:18:55 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:55 --> Input Class Initialized
INFO - 2024-10-08 17:18:55 --> Language Class Initialized
INFO - 2024-10-08 17:18:55 --> Language Class Initialized
INFO - 2024-10-08 17:18:55 --> Config Class Initialized
INFO - 2024-10-08 17:18:55 --> Loader Class Initialized
INFO - 2024-10-08 17:18:55 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:55 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:55 --> Controller Class Initialized
INFO - 2024-10-08 17:18:55 --> Config Class Initialized
INFO - 2024-10-08 17:18:55 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:55 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:55 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:55 --> URI Class Initialized
INFO - 2024-10-08 17:18:55 --> Router Class Initialized
INFO - 2024-10-08 17:18:55 --> Output Class Initialized
INFO - 2024-10-08 17:18:55 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:55 --> Input Class Initialized
INFO - 2024-10-08 17:18:55 --> Language Class Initialized
INFO - 2024-10-08 17:18:55 --> Language Class Initialized
INFO - 2024-10-08 17:18:55 --> Config Class Initialized
INFO - 2024-10-08 17:18:55 --> Loader Class Initialized
INFO - 2024-10-08 17:18:55 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:55 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:55 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:55 --> Controller Class Initialized
DEBUG - 2024-10-08 17:18:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 17:18:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:18:55 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:55 --> Total execution time: 0.0530
INFO - 2024-10-08 17:18:58 --> Config Class Initialized
INFO - 2024-10-08 17:18:58 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:18:58 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:18:58 --> Utf8 Class Initialized
INFO - 2024-10-08 17:18:58 --> URI Class Initialized
INFO - 2024-10-08 17:18:58 --> Router Class Initialized
INFO - 2024-10-08 17:18:58 --> Output Class Initialized
INFO - 2024-10-08 17:18:58 --> Security Class Initialized
DEBUG - 2024-10-08 17:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:18:58 --> Input Class Initialized
INFO - 2024-10-08 17:18:58 --> Language Class Initialized
INFO - 2024-10-08 17:18:58 --> Language Class Initialized
INFO - 2024-10-08 17:18:58 --> Config Class Initialized
INFO - 2024-10-08 17:18:58 --> Loader Class Initialized
INFO - 2024-10-08 17:18:58 --> Helper loaded: url_helper
INFO - 2024-10-08 17:18:58 --> Helper loaded: file_helper
INFO - 2024-10-08 17:18:58 --> Helper loaded: form_helper
INFO - 2024-10-08 17:18:58 --> Helper loaded: my_helper
INFO - 2024-10-08 17:18:58 --> Database Driver Class Initialized
INFO - 2024-10-08 17:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:18:58 --> Controller Class Initialized
INFO - 2024-10-08 17:18:58 --> Final output sent to browser
DEBUG - 2024-10-08 17:18:58 --> Total execution time: 0.5859
INFO - 2024-10-08 17:19:01 --> Config Class Initialized
INFO - 2024-10-08 17:19:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:01 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:01 --> URI Class Initialized
INFO - 2024-10-08 17:19:01 --> Router Class Initialized
INFO - 2024-10-08 17:19:01 --> Output Class Initialized
INFO - 2024-10-08 17:19:01 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:01 --> Input Class Initialized
INFO - 2024-10-08 17:19:01 --> Language Class Initialized
INFO - 2024-10-08 17:19:01 --> Language Class Initialized
INFO - 2024-10-08 17:19:01 --> Config Class Initialized
INFO - 2024-10-08 17:19:01 --> Loader Class Initialized
INFO - 2024-10-08 17:19:01 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:01 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:01 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:01 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:01 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:01 --> Controller Class Initialized
INFO - 2024-10-08 17:19:01 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:01 --> Total execution time: 0.1486
INFO - 2024-10-08 17:19:02 --> Config Class Initialized
INFO - 2024-10-08 17:19:02 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:02 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:02 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:02 --> URI Class Initialized
INFO - 2024-10-08 17:19:02 --> Router Class Initialized
INFO - 2024-10-08 17:19:02 --> Output Class Initialized
INFO - 2024-10-08 17:19:02 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:02 --> Input Class Initialized
INFO - 2024-10-08 17:19:02 --> Language Class Initialized
INFO - 2024-10-08 17:19:02 --> Language Class Initialized
INFO - 2024-10-08 17:19:02 --> Config Class Initialized
INFO - 2024-10-08 17:19:02 --> Loader Class Initialized
INFO - 2024-10-08 17:19:02 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:02 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:02 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:02 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:02 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:02 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 17:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:02 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:02 --> Total execution time: 0.0781
INFO - 2024-10-08 17:19:08 --> Config Class Initialized
INFO - 2024-10-08 17:19:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:08 --> URI Class Initialized
INFO - 2024-10-08 17:19:08 --> Router Class Initialized
INFO - 2024-10-08 17:19:08 --> Output Class Initialized
INFO - 2024-10-08 17:19:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:08 --> Input Class Initialized
INFO - 2024-10-08 17:19:08 --> Language Class Initialized
INFO - 2024-10-08 17:19:08 --> Language Class Initialized
INFO - 2024-10-08 17:19:08 --> Config Class Initialized
INFO - 2024-10-08 17:19:08 --> Loader Class Initialized
INFO - 2024-10-08 17:19:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:08 --> Controller Class Initialized
INFO - 2024-10-08 17:19:09 --> Config Class Initialized
INFO - 2024-10-08 17:19:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:09 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:09 --> URI Class Initialized
INFO - 2024-10-08 17:19:09 --> Router Class Initialized
INFO - 2024-10-08 17:19:09 --> Output Class Initialized
INFO - 2024-10-08 17:19:09 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:09 --> Input Class Initialized
INFO - 2024-10-08 17:19:09 --> Language Class Initialized
INFO - 2024-10-08 17:19:09 --> Language Class Initialized
INFO - 2024-10-08 17:19:09 --> Config Class Initialized
INFO - 2024-10-08 17:19:09 --> Loader Class Initialized
INFO - 2024-10-08 17:19:09 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:09 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:09 --> Controller Class Initialized
INFO - 2024-10-08 17:19:09 --> Helper loaded: cookie_helper
INFO - 2024-10-08 17:19:09 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:09 --> Total execution time: 0.0565
INFO - 2024-10-08 17:19:09 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:09 --> Total execution time: 0.2068
INFO - 2024-10-08 17:19:09 --> Config Class Initialized
INFO - 2024-10-08 17:19:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:09 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:09 --> URI Class Initialized
INFO - 2024-10-08 17:19:09 --> Router Class Initialized
INFO - 2024-10-08 17:19:09 --> Output Class Initialized
INFO - 2024-10-08 17:19:09 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:09 --> Input Class Initialized
INFO - 2024-10-08 17:19:09 --> Language Class Initialized
INFO - 2024-10-08 17:19:09 --> Language Class Initialized
INFO - 2024-10-08 17:19:09 --> Config Class Initialized
INFO - 2024-10-08 17:19:09 --> Loader Class Initialized
INFO - 2024-10-08 17:19:09 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:09 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:09 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:09 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 17:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:09 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:09 --> Total execution time: 0.0325
INFO - 2024-10-08 17:19:10 --> Config Class Initialized
INFO - 2024-10-08 17:19:10 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:10 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:10 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:10 --> URI Class Initialized
INFO - 2024-10-08 17:19:11 --> Router Class Initialized
INFO - 2024-10-08 17:19:11 --> Output Class Initialized
INFO - 2024-10-08 17:19:11 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:11 --> Input Class Initialized
INFO - 2024-10-08 17:19:11 --> Language Class Initialized
INFO - 2024-10-08 17:19:11 --> Language Class Initialized
INFO - 2024-10-08 17:19:11 --> Config Class Initialized
INFO - 2024-10-08 17:19:11 --> Loader Class Initialized
INFO - 2024-10-08 17:19:11 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:11 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:11 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:11 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:11 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:11 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:19:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:11 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:11 --> Total execution time: 0.0311
INFO - 2024-10-08 17:19:12 --> Config Class Initialized
INFO - 2024-10-08 17:19:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:12 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:12 --> URI Class Initialized
INFO - 2024-10-08 17:19:12 --> Router Class Initialized
INFO - 2024-10-08 17:19:12 --> Output Class Initialized
INFO - 2024-10-08 17:19:12 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:12 --> Input Class Initialized
INFO - 2024-10-08 17:19:12 --> Language Class Initialized
INFO - 2024-10-08 17:19:12 --> Language Class Initialized
INFO - 2024-10-08 17:19:12 --> Config Class Initialized
INFO - 2024-10-08 17:19:12 --> Loader Class Initialized
INFO - 2024-10-08 17:19:12 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:12 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:12 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:19:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:12 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:12 --> Total execution time: 0.0814
INFO - 2024-10-08 17:19:12 --> Config Class Initialized
INFO - 2024-10-08 17:19:12 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:12 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:12 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:12 --> URI Class Initialized
INFO - 2024-10-08 17:19:12 --> Router Class Initialized
INFO - 2024-10-08 17:19:12 --> Output Class Initialized
INFO - 2024-10-08 17:19:12 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:12 --> Input Class Initialized
INFO - 2024-10-08 17:19:12 --> Language Class Initialized
INFO - 2024-10-08 17:19:12 --> Language Class Initialized
INFO - 2024-10-08 17:19:12 --> Config Class Initialized
INFO - 2024-10-08 17:19:12 --> Loader Class Initialized
INFO - 2024-10-08 17:19:12 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:12 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:13 --> Controller Class Initialized
INFO - 2024-10-08 17:19:14 --> Config Class Initialized
INFO - 2024-10-08 17:19:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:14 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:14 --> URI Class Initialized
INFO - 2024-10-08 17:19:14 --> Router Class Initialized
INFO - 2024-10-08 17:19:14 --> Output Class Initialized
INFO - 2024-10-08 17:19:14 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:14 --> Input Class Initialized
INFO - 2024-10-08 17:19:14 --> Language Class Initialized
INFO - 2024-10-08 17:19:14 --> Language Class Initialized
INFO - 2024-10-08 17:19:14 --> Config Class Initialized
INFO - 2024-10-08 17:19:14 --> Loader Class Initialized
INFO - 2024-10-08 17:19:14 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:14 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:14 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:14 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:14 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:14 --> Controller Class Initialized
INFO - 2024-10-08 17:19:14 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:14 --> Total execution time: 0.0383
INFO - 2024-10-08 17:19:17 --> Config Class Initialized
INFO - 2024-10-08 17:19:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:17 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:17 --> URI Class Initialized
INFO - 2024-10-08 17:19:17 --> Router Class Initialized
INFO - 2024-10-08 17:19:17 --> Output Class Initialized
INFO - 2024-10-08 17:19:17 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:17 --> Input Class Initialized
INFO - 2024-10-08 17:19:17 --> Language Class Initialized
INFO - 2024-10-08 17:19:17 --> Language Class Initialized
INFO - 2024-10-08 17:19:17 --> Config Class Initialized
INFO - 2024-10-08 17:19:17 --> Loader Class Initialized
INFO - 2024-10-08 17:19:17 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:17 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:17 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:17 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:17 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:17 --> Controller Class Initialized
INFO - 2024-10-08 17:19:17 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:17 --> Total execution time: 0.0328
INFO - 2024-10-08 17:19:25 --> Config Class Initialized
INFO - 2024-10-08 17:19:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:25 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:25 --> URI Class Initialized
INFO - 2024-10-08 17:19:25 --> Router Class Initialized
INFO - 2024-10-08 17:19:25 --> Output Class Initialized
INFO - 2024-10-08 17:19:25 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:25 --> Input Class Initialized
INFO - 2024-10-08 17:19:25 --> Language Class Initialized
INFO - 2024-10-08 17:19:25 --> Language Class Initialized
INFO - 2024-10-08 17:19:25 --> Config Class Initialized
INFO - 2024-10-08 17:19:25 --> Loader Class Initialized
INFO - 2024-10-08 17:19:25 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:25 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:25 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:25 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:25 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:25 --> Controller Class Initialized
INFO - 2024-10-08 17:19:25 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:25 --> Total execution time: 0.2718
INFO - 2024-10-08 17:19:29 --> Config Class Initialized
INFO - 2024-10-08 17:19:29 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:29 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:29 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:29 --> URI Class Initialized
INFO - 2024-10-08 17:19:29 --> Router Class Initialized
INFO - 2024-10-08 17:19:29 --> Output Class Initialized
INFO - 2024-10-08 17:19:29 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:29 --> Input Class Initialized
INFO - 2024-10-08 17:19:29 --> Language Class Initialized
INFO - 2024-10-08 17:19:29 --> Language Class Initialized
INFO - 2024-10-08 17:19:29 --> Config Class Initialized
INFO - 2024-10-08 17:19:29 --> Loader Class Initialized
INFO - 2024-10-08 17:19:29 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:29 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:29 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:29 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:29 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:29 --> Controller Class Initialized
INFO - 2024-10-08 17:19:29 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:29 --> Total execution time: 0.0441
INFO - 2024-10-08 17:19:35 --> Config Class Initialized
INFO - 2024-10-08 17:19:35 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:35 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:35 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:35 --> URI Class Initialized
INFO - 2024-10-08 17:19:35 --> Router Class Initialized
INFO - 2024-10-08 17:19:35 --> Output Class Initialized
INFO - 2024-10-08 17:19:35 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:35 --> Input Class Initialized
INFO - 2024-10-08 17:19:35 --> Language Class Initialized
INFO - 2024-10-08 17:19:35 --> Language Class Initialized
INFO - 2024-10-08 17:19:35 --> Config Class Initialized
INFO - 2024-10-08 17:19:35 --> Loader Class Initialized
INFO - 2024-10-08 17:19:35 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:35 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:35 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:35 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:35 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:35 --> Controller Class Initialized
INFO - 2024-10-08 17:19:35 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:35 --> Total execution time: 0.1892
INFO - 2024-10-08 17:19:36 --> Config Class Initialized
INFO - 2024-10-08 17:19:36 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:36 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:36 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:36 --> URI Class Initialized
INFO - 2024-10-08 17:19:36 --> Router Class Initialized
INFO - 2024-10-08 17:19:36 --> Output Class Initialized
INFO - 2024-10-08 17:19:36 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:36 --> Input Class Initialized
INFO - 2024-10-08 17:19:36 --> Language Class Initialized
INFO - 2024-10-08 17:19:36 --> Language Class Initialized
INFO - 2024-10-08 17:19:36 --> Config Class Initialized
INFO - 2024-10-08 17:19:36 --> Loader Class Initialized
INFO - 2024-10-08 17:19:36 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:36 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:36 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:36 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:36 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:36 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:36 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:36 --> Total execution time: 0.0316
INFO - 2024-10-08 17:19:38 --> Config Class Initialized
INFO - 2024-10-08 17:19:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:38 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:38 --> URI Class Initialized
INFO - 2024-10-08 17:19:38 --> Router Class Initialized
INFO - 2024-10-08 17:19:38 --> Output Class Initialized
INFO - 2024-10-08 17:19:38 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:38 --> Input Class Initialized
INFO - 2024-10-08 17:19:38 --> Language Class Initialized
INFO - 2024-10-08 17:19:38 --> Language Class Initialized
INFO - 2024-10-08 17:19:38 --> Config Class Initialized
INFO - 2024-10-08 17:19:38 --> Loader Class Initialized
INFO - 2024-10-08 17:19:38 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:38 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:38 --> Controller Class Initialized
DEBUG - 2024-10-08 17:19:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:19:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:19:38 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:38 --> Total execution time: 0.0472
INFO - 2024-10-08 17:19:38 --> Config Class Initialized
INFO - 2024-10-08 17:19:38 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:38 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:38 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:38 --> URI Class Initialized
INFO - 2024-10-08 17:19:38 --> Router Class Initialized
INFO - 2024-10-08 17:19:38 --> Output Class Initialized
INFO - 2024-10-08 17:19:38 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:38 --> Input Class Initialized
INFO - 2024-10-08 17:19:38 --> Language Class Initialized
INFO - 2024-10-08 17:19:38 --> Language Class Initialized
INFO - 2024-10-08 17:19:38 --> Config Class Initialized
INFO - 2024-10-08 17:19:38 --> Loader Class Initialized
INFO - 2024-10-08 17:19:38 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:38 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:38 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:38 --> Controller Class Initialized
INFO - 2024-10-08 17:19:39 --> Config Class Initialized
INFO - 2024-10-08 17:19:39 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:39 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:39 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:39 --> URI Class Initialized
INFO - 2024-10-08 17:19:39 --> Router Class Initialized
INFO - 2024-10-08 17:19:39 --> Output Class Initialized
INFO - 2024-10-08 17:19:39 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:39 --> Input Class Initialized
INFO - 2024-10-08 17:19:39 --> Language Class Initialized
INFO - 2024-10-08 17:19:39 --> Language Class Initialized
INFO - 2024-10-08 17:19:39 --> Config Class Initialized
INFO - 2024-10-08 17:19:39 --> Loader Class Initialized
INFO - 2024-10-08 17:19:39 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:39 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:39 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:39 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:39 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:39 --> Controller Class Initialized
INFO - 2024-10-08 17:19:39 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:39 --> Total execution time: 0.0338
INFO - 2024-10-08 17:19:43 --> Config Class Initialized
INFO - 2024-10-08 17:19:43 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:43 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:43 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:43 --> URI Class Initialized
INFO - 2024-10-08 17:19:43 --> Router Class Initialized
INFO - 2024-10-08 17:19:43 --> Output Class Initialized
INFO - 2024-10-08 17:19:43 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:43 --> Input Class Initialized
INFO - 2024-10-08 17:19:43 --> Language Class Initialized
INFO - 2024-10-08 17:19:43 --> Language Class Initialized
INFO - 2024-10-08 17:19:43 --> Config Class Initialized
INFO - 2024-10-08 17:19:43 --> Loader Class Initialized
INFO - 2024-10-08 17:19:43 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:43 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:43 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:43 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:43 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:43 --> Controller Class Initialized
INFO - 2024-10-08 17:19:43 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:43 --> Total execution time: 0.0343
INFO - 2024-10-08 17:19:44 --> Config Class Initialized
INFO - 2024-10-08 17:19:44 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:44 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:44 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:44 --> URI Class Initialized
INFO - 2024-10-08 17:19:44 --> Router Class Initialized
INFO - 2024-10-08 17:19:44 --> Output Class Initialized
INFO - 2024-10-08 17:19:44 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:44 --> Input Class Initialized
INFO - 2024-10-08 17:19:44 --> Language Class Initialized
INFO - 2024-10-08 17:19:44 --> Language Class Initialized
INFO - 2024-10-08 17:19:44 --> Config Class Initialized
INFO - 2024-10-08 17:19:44 --> Loader Class Initialized
INFO - 2024-10-08 17:19:44 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:44 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:44 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:44 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:44 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:44 --> Controller Class Initialized
INFO - 2024-10-08 17:19:44 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:44 --> Total execution time: 0.0353
INFO - 2024-10-08 17:19:45 --> Config Class Initialized
INFO - 2024-10-08 17:19:45 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:45 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:45 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:45 --> URI Class Initialized
INFO - 2024-10-08 17:19:45 --> Router Class Initialized
INFO - 2024-10-08 17:19:45 --> Output Class Initialized
INFO - 2024-10-08 17:19:45 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:45 --> Input Class Initialized
INFO - 2024-10-08 17:19:45 --> Language Class Initialized
INFO - 2024-10-08 17:19:45 --> Language Class Initialized
INFO - 2024-10-08 17:19:45 --> Config Class Initialized
INFO - 2024-10-08 17:19:45 --> Loader Class Initialized
INFO - 2024-10-08 17:19:45 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:45 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:45 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:45 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:45 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:45 --> Controller Class Initialized
INFO - 2024-10-08 17:19:45 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:45 --> Total execution time: 0.0383
INFO - 2024-10-08 17:19:49 --> Config Class Initialized
INFO - 2024-10-08 17:19:49 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:49 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:49 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:49 --> URI Class Initialized
INFO - 2024-10-08 17:19:49 --> Router Class Initialized
INFO - 2024-10-08 17:19:49 --> Output Class Initialized
INFO - 2024-10-08 17:19:49 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:49 --> Input Class Initialized
INFO - 2024-10-08 17:19:49 --> Language Class Initialized
INFO - 2024-10-08 17:19:49 --> Language Class Initialized
INFO - 2024-10-08 17:19:49 --> Config Class Initialized
INFO - 2024-10-08 17:19:49 --> Loader Class Initialized
INFO - 2024-10-08 17:19:49 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:49 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:49 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:49 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:49 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:49 --> Controller Class Initialized
INFO - 2024-10-08 17:19:50 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:50 --> Total execution time: 0.1585
INFO - 2024-10-08 17:19:50 --> Config Class Initialized
INFO - 2024-10-08 17:19:50 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:50 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:50 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:50 --> URI Class Initialized
INFO - 2024-10-08 17:19:50 --> Router Class Initialized
INFO - 2024-10-08 17:19:50 --> Output Class Initialized
INFO - 2024-10-08 17:19:50 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:50 --> Input Class Initialized
INFO - 2024-10-08 17:19:50 --> Language Class Initialized
INFO - 2024-10-08 17:19:50 --> Language Class Initialized
INFO - 2024-10-08 17:19:50 --> Config Class Initialized
INFO - 2024-10-08 17:19:50 --> Loader Class Initialized
INFO - 2024-10-08 17:19:50 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:50 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:50 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:50 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:50 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:50 --> Controller Class Initialized
INFO - 2024-10-08 17:19:50 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:50 --> Total execution time: 0.0407
INFO - 2024-10-08 17:19:53 --> Config Class Initialized
INFO - 2024-10-08 17:19:53 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:53 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:53 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:53 --> URI Class Initialized
INFO - 2024-10-08 17:19:53 --> Router Class Initialized
INFO - 2024-10-08 17:19:53 --> Output Class Initialized
INFO - 2024-10-08 17:19:53 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:53 --> Input Class Initialized
INFO - 2024-10-08 17:19:53 --> Language Class Initialized
INFO - 2024-10-08 17:19:53 --> Language Class Initialized
INFO - 2024-10-08 17:19:53 --> Config Class Initialized
INFO - 2024-10-08 17:19:53 --> Loader Class Initialized
INFO - 2024-10-08 17:19:53 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:53 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:53 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:53 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:53 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:53 --> Controller Class Initialized
INFO - 2024-10-08 17:19:53 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:53 --> Total execution time: 0.0359
INFO - 2024-10-08 17:19:59 --> Config Class Initialized
INFO - 2024-10-08 17:19:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:19:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:19:59 --> Utf8 Class Initialized
INFO - 2024-10-08 17:19:59 --> URI Class Initialized
INFO - 2024-10-08 17:19:59 --> Router Class Initialized
INFO - 2024-10-08 17:19:59 --> Output Class Initialized
INFO - 2024-10-08 17:19:59 --> Security Class Initialized
DEBUG - 2024-10-08 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:19:59 --> Input Class Initialized
INFO - 2024-10-08 17:19:59 --> Language Class Initialized
INFO - 2024-10-08 17:19:59 --> Language Class Initialized
INFO - 2024-10-08 17:19:59 --> Config Class Initialized
INFO - 2024-10-08 17:19:59 --> Loader Class Initialized
INFO - 2024-10-08 17:19:59 --> Helper loaded: url_helper
INFO - 2024-10-08 17:19:59 --> Helper loaded: file_helper
INFO - 2024-10-08 17:19:59 --> Helper loaded: form_helper
INFO - 2024-10-08 17:19:59 --> Helper loaded: my_helper
INFO - 2024-10-08 17:19:59 --> Database Driver Class Initialized
INFO - 2024-10-08 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:19:59 --> Controller Class Initialized
INFO - 2024-10-08 17:19:59 --> Final output sent to browser
DEBUG - 2024-10-08 17:19:59 --> Total execution time: 0.1664
INFO - 2024-10-08 17:20:01 --> Config Class Initialized
INFO - 2024-10-08 17:20:01 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:01 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:01 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:01 --> URI Class Initialized
INFO - 2024-10-08 17:20:01 --> Router Class Initialized
INFO - 2024-10-08 17:20:01 --> Output Class Initialized
INFO - 2024-10-08 17:20:01 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:01 --> Input Class Initialized
INFO - 2024-10-08 17:20:01 --> Language Class Initialized
INFO - 2024-10-08 17:20:01 --> Language Class Initialized
INFO - 2024-10-08 17:20:01 --> Config Class Initialized
INFO - 2024-10-08 17:20:01 --> Loader Class Initialized
INFO - 2024-10-08 17:20:01 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:01 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:01 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:01 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:01 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:01 --> Controller Class Initialized
INFO - 2024-10-08 17:20:01 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:01 --> Total execution time: 0.1594
INFO - 2024-10-08 17:20:06 --> Config Class Initialized
INFO - 2024-10-08 17:20:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:06 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:06 --> URI Class Initialized
INFO - 2024-10-08 17:20:06 --> Router Class Initialized
INFO - 2024-10-08 17:20:06 --> Output Class Initialized
INFO - 2024-10-08 17:20:06 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:06 --> Input Class Initialized
INFO - 2024-10-08 17:20:06 --> Language Class Initialized
INFO - 2024-10-08 17:20:06 --> Language Class Initialized
INFO - 2024-10-08 17:20:06 --> Config Class Initialized
INFO - 2024-10-08 17:20:06 --> Loader Class Initialized
INFO - 2024-10-08 17:20:06 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:06 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:06 --> Controller Class Initialized
INFO - 2024-10-08 17:20:06 --> Config Class Initialized
INFO - 2024-10-08 17:20:06 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:06 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:06 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:06 --> URI Class Initialized
INFO - 2024-10-08 17:20:06 --> Router Class Initialized
INFO - 2024-10-08 17:20:06 --> Output Class Initialized
INFO - 2024-10-08 17:20:06 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:06 --> Input Class Initialized
INFO - 2024-10-08 17:20:06 --> Language Class Initialized
INFO - 2024-10-08 17:20:06 --> Language Class Initialized
INFO - 2024-10-08 17:20:06 --> Config Class Initialized
INFO - 2024-10-08 17:20:06 --> Loader Class Initialized
INFO - 2024-10-08 17:20:06 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:06 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:06 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:06 --> Controller Class Initialized
DEBUG - 2024-10-08 17:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:20:06 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:06 --> Total execution time: 0.1010
INFO - 2024-10-08 17:20:06 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:06 --> Total execution time: 0.3691
INFO - 2024-10-08 17:20:08 --> Config Class Initialized
INFO - 2024-10-08 17:20:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:08 --> URI Class Initialized
INFO - 2024-10-08 17:20:08 --> Config Class Initialized
INFO - 2024-10-08 17:20:08 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:08 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:08 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:08 --> URI Class Initialized
INFO - 2024-10-08 17:20:08 --> Router Class Initialized
INFO - 2024-10-08 17:20:08 --> Router Class Initialized
INFO - 2024-10-08 17:20:08 --> Output Class Initialized
INFO - 2024-10-08 17:20:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:08 --> Input Class Initialized
INFO - 2024-10-08 17:20:08 --> Language Class Initialized
INFO - 2024-10-08 17:20:08 --> Output Class Initialized
INFO - 2024-10-08 17:20:08 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:08 --> Input Class Initialized
INFO - 2024-10-08 17:20:08 --> Language Class Initialized
INFO - 2024-10-08 17:20:08 --> Language Class Initialized
INFO - 2024-10-08 17:20:08 --> Config Class Initialized
INFO - 2024-10-08 17:20:08 --> Loader Class Initialized
INFO - 2024-10-08 17:20:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:08 --> Language Class Initialized
INFO - 2024-10-08 17:20:08 --> Config Class Initialized
INFO - 2024-10-08 17:20:08 --> Loader Class Initialized
INFO - 2024-10-08 17:20:08 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:08 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:08 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:08 --> Controller Class Initialized
INFO - 2024-10-08 17:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:08 --> Controller Class Initialized
INFO - 2024-10-08 17:20:08 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:08 --> Total execution time: 0.0770
DEBUG - 2024-10-08 17:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-08 17:20:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:20:08 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:08 --> Total execution time: 0.0884
INFO - 2024-10-08 17:20:13 --> Config Class Initialized
INFO - 2024-10-08 17:20:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:13 --> URI Class Initialized
INFO - 2024-10-08 17:20:13 --> Router Class Initialized
INFO - 2024-10-08 17:20:13 --> Output Class Initialized
INFO - 2024-10-08 17:20:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:13 --> Input Class Initialized
INFO - 2024-10-08 17:20:13 --> Language Class Initialized
INFO - 2024-10-08 17:20:13 --> Language Class Initialized
INFO - 2024-10-08 17:20:13 --> Config Class Initialized
INFO - 2024-10-08 17:20:13 --> Loader Class Initialized
INFO - 2024-10-08 17:20:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:13 --> Controller Class Initialized
INFO - 2024-10-08 17:20:14 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:14 --> Total execution time: 0.2251
INFO - 2024-10-08 17:20:14 --> Config Class Initialized
INFO - 2024-10-08 17:20:14 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:14 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:14 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:14 --> URI Class Initialized
INFO - 2024-10-08 17:20:14 --> Router Class Initialized
INFO - 2024-10-08 17:20:14 --> Output Class Initialized
INFO - 2024-10-08 17:20:14 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:14 --> Input Class Initialized
INFO - 2024-10-08 17:20:14 --> Language Class Initialized
INFO - 2024-10-08 17:20:14 --> Language Class Initialized
INFO - 2024-10-08 17:20:14 --> Config Class Initialized
INFO - 2024-10-08 17:20:14 --> Loader Class Initialized
INFO - 2024-10-08 17:20:14 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:14 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:14 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:14 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:14 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:14 --> Controller Class Initialized
INFO - 2024-10-08 17:20:18 --> Config Class Initialized
INFO - 2024-10-08 17:20:18 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:18 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:18 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:18 --> URI Class Initialized
INFO - 2024-10-08 17:20:18 --> Router Class Initialized
INFO - 2024-10-08 17:20:18 --> Output Class Initialized
INFO - 2024-10-08 17:20:18 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:18 --> Input Class Initialized
INFO - 2024-10-08 17:20:18 --> Language Class Initialized
INFO - 2024-10-08 17:20:18 --> Language Class Initialized
INFO - 2024-10-08 17:20:18 --> Config Class Initialized
INFO - 2024-10-08 17:20:18 --> Loader Class Initialized
INFO - 2024-10-08 17:20:18 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:18 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:18 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:18 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:18 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:18 --> Controller Class Initialized
DEBUG - 2024-10-08 17:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:20:18 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:18 --> Total execution time: 0.0482
INFO - 2024-10-08 17:20:23 --> Config Class Initialized
INFO - 2024-10-08 17:20:23 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:23 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:23 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:23 --> URI Class Initialized
INFO - 2024-10-08 17:20:23 --> Router Class Initialized
INFO - 2024-10-08 17:20:23 --> Output Class Initialized
INFO - 2024-10-08 17:20:23 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:23 --> Input Class Initialized
INFO - 2024-10-08 17:20:23 --> Language Class Initialized
INFO - 2024-10-08 17:20:23 --> Language Class Initialized
INFO - 2024-10-08 17:20:23 --> Config Class Initialized
INFO - 2024-10-08 17:20:23 --> Loader Class Initialized
INFO - 2024-10-08 17:20:23 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:23 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:23 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:23 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:23 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:23 --> Controller Class Initialized
DEBUG - 2024-10-08 17:20:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-08 17:20:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:20:23 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:23 --> Total execution time: 0.0468
INFO - 2024-10-08 17:20:25 --> Config Class Initialized
INFO - 2024-10-08 17:20:25 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:20:25 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:20:25 --> Utf8 Class Initialized
INFO - 2024-10-08 17:20:25 --> URI Class Initialized
INFO - 2024-10-08 17:20:25 --> Router Class Initialized
INFO - 2024-10-08 17:20:25 --> Output Class Initialized
INFO - 2024-10-08 17:20:25 --> Security Class Initialized
DEBUG - 2024-10-08 17:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:20:25 --> Input Class Initialized
INFO - 2024-10-08 17:20:25 --> Language Class Initialized
INFO - 2024-10-08 17:20:25 --> Language Class Initialized
INFO - 2024-10-08 17:20:25 --> Config Class Initialized
INFO - 2024-10-08 17:20:25 --> Loader Class Initialized
INFO - 2024-10-08 17:20:25 --> Helper loaded: url_helper
INFO - 2024-10-08 17:20:25 --> Helper loaded: file_helper
INFO - 2024-10-08 17:20:25 --> Helper loaded: form_helper
INFO - 2024-10-08 17:20:25 --> Helper loaded: my_helper
INFO - 2024-10-08 17:20:25 --> Database Driver Class Initialized
INFO - 2024-10-08 17:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:20:25 --> Controller Class Initialized
DEBUG - 2024-10-08 17:20:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-08 17:20:28 --> Final output sent to browser
DEBUG - 2024-10-08 17:20:28 --> Total execution time: 3.4647
INFO - 2024-10-08 17:52:07 --> Config Class Initialized
INFO - 2024-10-08 17:52:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:07 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:07 --> URI Class Initialized
INFO - 2024-10-08 17:52:07 --> Router Class Initialized
INFO - 2024-10-08 17:52:07 --> Output Class Initialized
INFO - 2024-10-08 17:52:07 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:07 --> Input Class Initialized
INFO - 2024-10-08 17:52:07 --> Language Class Initialized
INFO - 2024-10-08 17:52:07 --> Language Class Initialized
INFO - 2024-10-08 17:52:07 --> Config Class Initialized
INFO - 2024-10-08 17:52:07 --> Loader Class Initialized
INFO - 2024-10-08 17:52:07 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:07 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:07 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:07 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:07 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:07 --> Controller Class Initialized
DEBUG - 2024-10-08 17:52:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-08 17:52:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:52:07 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:07 --> Total execution time: 0.2197
INFO - 2024-10-08 17:52:13 --> Config Class Initialized
INFO - 2024-10-08 17:52:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:13 --> URI Class Initialized
INFO - 2024-10-08 17:52:13 --> Router Class Initialized
INFO - 2024-10-08 17:52:13 --> Output Class Initialized
INFO - 2024-10-08 17:52:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:13 --> Input Class Initialized
INFO - 2024-10-08 17:52:13 --> Language Class Initialized
INFO - 2024-10-08 17:52:13 --> Language Class Initialized
INFO - 2024-10-08 17:52:13 --> Config Class Initialized
INFO - 2024-10-08 17:52:13 --> Loader Class Initialized
INFO - 2024-10-08 17:52:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:13 --> Controller Class Initialized
INFO - 2024-10-08 17:52:13 --> Helper loaded: cookie_helper
INFO - 2024-10-08 17:52:13 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:13 --> Total execution time: 0.0773
INFO - 2024-10-08 17:52:13 --> Config Class Initialized
INFO - 2024-10-08 17:52:13 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:13 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:13 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:13 --> URI Class Initialized
INFO - 2024-10-08 17:52:13 --> Router Class Initialized
INFO - 2024-10-08 17:52:13 --> Output Class Initialized
INFO - 2024-10-08 17:52:13 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:13 --> Input Class Initialized
INFO - 2024-10-08 17:52:13 --> Language Class Initialized
INFO - 2024-10-08 17:52:13 --> Language Class Initialized
INFO - 2024-10-08 17:52:13 --> Config Class Initialized
INFO - 2024-10-08 17:52:13 --> Loader Class Initialized
INFO - 2024-10-08 17:52:13 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:13 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:13 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:13 --> Controller Class Initialized
DEBUG - 2024-10-08 17:52:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-08 17:52:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:52:13 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:13 --> Total execution time: 0.0784
INFO - 2024-10-08 17:52:17 --> Config Class Initialized
INFO - 2024-10-08 17:52:17 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:17 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:17 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:17 --> URI Class Initialized
INFO - 2024-10-08 17:52:17 --> Router Class Initialized
INFO - 2024-10-08 17:52:17 --> Output Class Initialized
INFO - 2024-10-08 17:52:17 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:17 --> Input Class Initialized
INFO - 2024-10-08 17:52:17 --> Language Class Initialized
INFO - 2024-10-08 17:52:17 --> Language Class Initialized
INFO - 2024-10-08 17:52:17 --> Config Class Initialized
INFO - 2024-10-08 17:52:17 --> Loader Class Initialized
INFO - 2024-10-08 17:52:17 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:17 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:17 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:17 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:17 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:17 --> Controller Class Initialized
DEBUG - 2024-10-08 17:52:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-08 17:52:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:52:17 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:17 --> Total execution time: 0.0392
INFO - 2024-10-08 17:52:22 --> Config Class Initialized
INFO - 2024-10-08 17:52:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:22 --> URI Class Initialized
INFO - 2024-10-08 17:52:22 --> Router Class Initialized
INFO - 2024-10-08 17:52:22 --> Output Class Initialized
INFO - 2024-10-08 17:52:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:22 --> Input Class Initialized
INFO - 2024-10-08 17:52:22 --> Language Class Initialized
INFO - 2024-10-08 17:52:22 --> Language Class Initialized
INFO - 2024-10-08 17:52:22 --> Config Class Initialized
INFO - 2024-10-08 17:52:22 --> Loader Class Initialized
INFO - 2024-10-08 17:52:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:22 --> Controller Class Initialized
DEBUG - 2024-10-08 17:52:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 17:52:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 17:52:22 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:22 --> Total execution time: 0.0404
INFO - 2024-10-08 17:52:22 --> Config Class Initialized
INFO - 2024-10-08 17:52:22 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:22 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:22 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:22 --> URI Class Initialized
INFO - 2024-10-08 17:52:22 --> Router Class Initialized
INFO - 2024-10-08 17:52:22 --> Output Class Initialized
INFO - 2024-10-08 17:52:22 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:22 --> Input Class Initialized
INFO - 2024-10-08 17:52:22 --> Language Class Initialized
INFO - 2024-10-08 17:52:22 --> Language Class Initialized
INFO - 2024-10-08 17:52:22 --> Config Class Initialized
INFO - 2024-10-08 17:52:22 --> Loader Class Initialized
INFO - 2024-10-08 17:52:22 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:22 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:22 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:22 --> Controller Class Initialized
INFO - 2024-10-08 17:52:24 --> Config Class Initialized
INFO - 2024-10-08 17:52:24 --> Hooks Class Initialized
DEBUG - 2024-10-08 17:52:24 --> UTF-8 Support Enabled
INFO - 2024-10-08 17:52:24 --> Utf8 Class Initialized
INFO - 2024-10-08 17:52:24 --> URI Class Initialized
INFO - 2024-10-08 17:52:24 --> Router Class Initialized
INFO - 2024-10-08 17:52:24 --> Output Class Initialized
INFO - 2024-10-08 17:52:24 --> Security Class Initialized
DEBUG - 2024-10-08 17:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 17:52:24 --> Input Class Initialized
INFO - 2024-10-08 17:52:24 --> Language Class Initialized
INFO - 2024-10-08 17:52:24 --> Language Class Initialized
INFO - 2024-10-08 17:52:24 --> Config Class Initialized
INFO - 2024-10-08 17:52:24 --> Loader Class Initialized
INFO - 2024-10-08 17:52:24 --> Helper loaded: url_helper
INFO - 2024-10-08 17:52:24 --> Helper loaded: file_helper
INFO - 2024-10-08 17:52:24 --> Helper loaded: form_helper
INFO - 2024-10-08 17:52:24 --> Helper loaded: my_helper
INFO - 2024-10-08 17:52:24 --> Database Driver Class Initialized
INFO - 2024-10-08 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 17:52:24 --> Controller Class Initialized
INFO - 2024-10-08 17:52:24 --> Final output sent to browser
DEBUG - 2024-10-08 17:52:24 --> Total execution time: 0.0572
INFO - 2024-10-08 18:04:51 --> Config Class Initialized
INFO - 2024-10-08 18:04:51 --> Hooks Class Initialized
DEBUG - 2024-10-08 18:04:51 --> UTF-8 Support Enabled
INFO - 2024-10-08 18:04:51 --> Utf8 Class Initialized
INFO - 2024-10-08 18:04:51 --> URI Class Initialized
INFO - 2024-10-08 18:04:51 --> Router Class Initialized
INFO - 2024-10-08 18:04:51 --> Output Class Initialized
INFO - 2024-10-08 18:04:51 --> Security Class Initialized
DEBUG - 2024-10-08 18:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 18:04:51 --> Input Class Initialized
INFO - 2024-10-08 18:04:51 --> Language Class Initialized
INFO - 2024-10-08 18:04:51 --> Language Class Initialized
INFO - 2024-10-08 18:04:51 --> Config Class Initialized
INFO - 2024-10-08 18:04:51 --> Loader Class Initialized
INFO - 2024-10-08 18:04:51 --> Helper loaded: url_helper
INFO - 2024-10-08 18:04:51 --> Helper loaded: file_helper
INFO - 2024-10-08 18:04:51 --> Helper loaded: form_helper
INFO - 2024-10-08 18:04:51 --> Helper loaded: my_helper
INFO - 2024-10-08 18:04:51 --> Database Driver Class Initialized
INFO - 2024-10-08 18:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 18:04:51 --> Controller Class Initialized
INFO - 2024-10-08 18:04:51 --> Final output sent to browser
DEBUG - 2024-10-08 18:04:51 --> Total execution time: 0.0586
INFO - 2024-10-08 18:04:59 --> Config Class Initialized
INFO - 2024-10-08 18:04:59 --> Hooks Class Initialized
DEBUG - 2024-10-08 18:04:59 --> UTF-8 Support Enabled
INFO - 2024-10-08 18:04:59 --> Utf8 Class Initialized
INFO - 2024-10-08 18:04:59 --> URI Class Initialized
INFO - 2024-10-08 18:04:59 --> Router Class Initialized
INFO - 2024-10-08 18:04:59 --> Output Class Initialized
INFO - 2024-10-08 18:04:59 --> Security Class Initialized
DEBUG - 2024-10-08 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 18:04:59 --> Input Class Initialized
INFO - 2024-10-08 18:04:59 --> Language Class Initialized
INFO - 2024-10-08 18:04:59 --> Language Class Initialized
INFO - 2024-10-08 18:04:59 --> Config Class Initialized
INFO - 2024-10-08 18:04:59 --> Loader Class Initialized
INFO - 2024-10-08 18:04:59 --> Helper loaded: url_helper
INFO - 2024-10-08 18:04:59 --> Helper loaded: file_helper
INFO - 2024-10-08 18:04:59 --> Helper loaded: form_helper
INFO - 2024-10-08 18:04:59 --> Helper loaded: my_helper
INFO - 2024-10-08 18:04:59 --> Database Driver Class Initialized
INFO - 2024-10-08 18:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 18:04:59 --> Controller Class Initialized
INFO - 2024-10-08 18:04:59 --> Final output sent to browser
DEBUG - 2024-10-08 18:04:59 --> Total execution time: 0.0351
INFO - 2024-10-08 18:05:09 --> Config Class Initialized
INFO - 2024-10-08 18:05:09 --> Hooks Class Initialized
DEBUG - 2024-10-08 18:05:09 --> UTF-8 Support Enabled
INFO - 2024-10-08 18:05:09 --> Utf8 Class Initialized
INFO - 2024-10-08 18:05:09 --> URI Class Initialized
INFO - 2024-10-08 18:05:09 --> Router Class Initialized
INFO - 2024-10-08 18:05:09 --> Output Class Initialized
INFO - 2024-10-08 18:05:09 --> Security Class Initialized
DEBUG - 2024-10-08 18:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 18:05:09 --> Input Class Initialized
INFO - 2024-10-08 18:05:09 --> Language Class Initialized
INFO - 2024-10-08 18:05:09 --> Language Class Initialized
INFO - 2024-10-08 18:05:09 --> Config Class Initialized
INFO - 2024-10-08 18:05:09 --> Loader Class Initialized
INFO - 2024-10-08 18:05:09 --> Helper loaded: url_helper
INFO - 2024-10-08 18:05:09 --> Helper loaded: file_helper
INFO - 2024-10-08 18:05:09 --> Helper loaded: form_helper
INFO - 2024-10-08 18:05:09 --> Helper loaded: my_helper
INFO - 2024-10-08 18:05:09 --> Database Driver Class Initialized
INFO - 2024-10-08 18:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 18:05:09 --> Controller Class Initialized
INFO - 2024-10-08 18:05:10 --> Final output sent to browser
DEBUG - 2024-10-08 18:05:10 --> Total execution time: 0.1811
INFO - 2024-10-08 18:05:15 --> Config Class Initialized
INFO - 2024-10-08 18:05:15 --> Hooks Class Initialized
DEBUG - 2024-10-08 18:05:15 --> UTF-8 Support Enabled
INFO - 2024-10-08 18:05:15 --> Utf8 Class Initialized
INFO - 2024-10-08 18:05:15 --> URI Class Initialized
INFO - 2024-10-08 18:05:15 --> Router Class Initialized
INFO - 2024-10-08 18:05:15 --> Output Class Initialized
INFO - 2024-10-08 18:05:15 --> Security Class Initialized
DEBUG - 2024-10-08 18:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 18:05:15 --> Input Class Initialized
INFO - 2024-10-08 18:05:15 --> Language Class Initialized
INFO - 2024-10-08 18:05:15 --> Language Class Initialized
INFO - 2024-10-08 18:05:15 --> Config Class Initialized
INFO - 2024-10-08 18:05:15 --> Loader Class Initialized
INFO - 2024-10-08 18:05:15 --> Helper loaded: url_helper
INFO - 2024-10-08 18:05:15 --> Helper loaded: file_helper
INFO - 2024-10-08 18:05:15 --> Helper loaded: form_helper
INFO - 2024-10-08 18:05:15 --> Helper loaded: my_helper
INFO - 2024-10-08 18:05:15 --> Database Driver Class Initialized
INFO - 2024-10-08 18:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 18:05:15 --> Controller Class Initialized
INFO - 2024-10-08 18:05:15 --> Final output sent to browser
DEBUG - 2024-10-08 18:05:15 --> Total execution time: 0.1708
INFO - 2024-10-08 20:09:07 --> Config Class Initialized
INFO - 2024-10-08 20:09:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 20:09:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 20:09:07 --> Utf8 Class Initialized
INFO - 2024-10-08 20:09:07 --> URI Class Initialized
INFO - 2024-10-08 20:09:07 --> Router Class Initialized
INFO - 2024-10-08 20:09:07 --> Output Class Initialized
INFO - 2024-10-08 20:09:07 --> Security Class Initialized
DEBUG - 2024-10-08 20:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 20:09:07 --> Input Class Initialized
INFO - 2024-10-08 20:09:07 --> Language Class Initialized
INFO - 2024-10-08 20:09:07 --> Language Class Initialized
INFO - 2024-10-08 20:09:07 --> Config Class Initialized
INFO - 2024-10-08 20:09:07 --> Loader Class Initialized
INFO - 2024-10-08 20:09:07 --> Helper loaded: url_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: file_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: form_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: my_helper
INFO - 2024-10-08 20:09:07 --> Database Driver Class Initialized
INFO - 2024-10-08 20:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 20:09:07 --> Controller Class Initialized
DEBUG - 2024-10-08 20:09:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 20:09:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 20:09:07 --> Final output sent to browser
DEBUG - 2024-10-08 20:09:07 --> Total execution time: 0.2036
INFO - 2024-10-08 20:09:07 --> Config Class Initialized
INFO - 2024-10-08 20:09:07 --> Hooks Class Initialized
DEBUG - 2024-10-08 20:09:07 --> UTF-8 Support Enabled
INFO - 2024-10-08 20:09:07 --> Utf8 Class Initialized
INFO - 2024-10-08 20:09:07 --> URI Class Initialized
INFO - 2024-10-08 20:09:07 --> Router Class Initialized
INFO - 2024-10-08 20:09:07 --> Output Class Initialized
INFO - 2024-10-08 20:09:07 --> Security Class Initialized
DEBUG - 2024-10-08 20:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 20:09:07 --> Input Class Initialized
INFO - 2024-10-08 20:09:07 --> Language Class Initialized
INFO - 2024-10-08 20:09:07 --> Language Class Initialized
INFO - 2024-10-08 20:09:07 --> Config Class Initialized
INFO - 2024-10-08 20:09:07 --> Loader Class Initialized
INFO - 2024-10-08 20:09:07 --> Helper loaded: url_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: file_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: form_helper
INFO - 2024-10-08 20:09:07 --> Helper loaded: my_helper
INFO - 2024-10-08 20:09:07 --> Database Driver Class Initialized
INFO - 2024-10-08 20:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 20:09:07 --> Controller Class Initialized
INFO - 2024-10-08 21:06:52 --> Config Class Initialized
INFO - 2024-10-08 21:06:52 --> Hooks Class Initialized
DEBUG - 2024-10-08 21:06:52 --> UTF-8 Support Enabled
INFO - 2024-10-08 21:06:52 --> Utf8 Class Initialized
INFO - 2024-10-08 21:06:52 --> URI Class Initialized
INFO - 2024-10-08 21:06:52 --> Router Class Initialized
INFO - 2024-10-08 21:06:52 --> Output Class Initialized
INFO - 2024-10-08 21:06:52 --> Security Class Initialized
DEBUG - 2024-10-08 21:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 21:06:52 --> Input Class Initialized
INFO - 2024-10-08 21:06:52 --> Language Class Initialized
INFO - 2024-10-08 21:06:52 --> Language Class Initialized
INFO - 2024-10-08 21:06:52 --> Config Class Initialized
INFO - 2024-10-08 21:06:52 --> Loader Class Initialized
INFO - 2024-10-08 21:06:52 --> Helper loaded: url_helper
INFO - 2024-10-08 21:06:52 --> Helper loaded: file_helper
INFO - 2024-10-08 21:06:52 --> Helper loaded: form_helper
INFO - 2024-10-08 21:06:52 --> Helper loaded: my_helper
INFO - 2024-10-08 21:06:52 --> Database Driver Class Initialized
INFO - 2024-10-08 21:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 21:06:52 --> Controller Class Initialized
DEBUG - 2024-10-08 21:06:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-08 21:06:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-08 21:06:52 --> Final output sent to browser
DEBUG - 2024-10-08 21:06:52 --> Total execution time: 0.0474
INFO - 2024-10-08 21:06:53 --> Config Class Initialized
INFO - 2024-10-08 21:06:53 --> Hooks Class Initialized
DEBUG - 2024-10-08 21:06:53 --> UTF-8 Support Enabled
INFO - 2024-10-08 21:06:53 --> Utf8 Class Initialized
INFO - 2024-10-08 21:06:53 --> URI Class Initialized
INFO - 2024-10-08 21:06:53 --> Router Class Initialized
INFO - 2024-10-08 21:06:53 --> Output Class Initialized
INFO - 2024-10-08 21:06:53 --> Security Class Initialized
DEBUG - 2024-10-08 21:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-08 21:06:53 --> Input Class Initialized
INFO - 2024-10-08 21:06:53 --> Language Class Initialized
INFO - 2024-10-08 21:06:53 --> Language Class Initialized
INFO - 2024-10-08 21:06:53 --> Config Class Initialized
INFO - 2024-10-08 21:06:53 --> Loader Class Initialized
INFO - 2024-10-08 21:06:53 --> Helper loaded: url_helper
INFO - 2024-10-08 21:06:53 --> Helper loaded: file_helper
INFO - 2024-10-08 21:06:53 --> Helper loaded: form_helper
INFO - 2024-10-08 21:06:53 --> Helper loaded: my_helper
INFO - 2024-10-08 21:06:53 --> Database Driver Class Initialized
INFO - 2024-10-08 21:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-08 21:06:53 --> Controller Class Initialized
