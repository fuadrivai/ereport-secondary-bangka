<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-04 04:32:17 --> Config Class Initialized
INFO - 2020-02-04 04:32:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:32:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:32:17 --> Utf8 Class Initialized
INFO - 2020-02-04 04:32:17 --> URI Class Initialized
DEBUG - 2020-02-04 04:32:18 --> No URI present. Default controller set.
INFO - 2020-02-04 04:32:18 --> Router Class Initialized
INFO - 2020-02-04 04:32:18 --> Output Class Initialized
INFO - 2020-02-04 04:32:18 --> Security Class Initialized
DEBUG - 2020-02-04 04:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:32:18 --> Input Class Initialized
INFO - 2020-02-04 04:32:18 --> Language Class Initialized
INFO - 2020-02-04 04:32:18 --> Language Class Initialized
INFO - 2020-02-04 04:32:18 --> Config Class Initialized
INFO - 2020-02-04 04:32:18 --> Loader Class Initialized
INFO - 2020-02-04 04:32:18 --> Helper loaded: url_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: file_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: form_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: my_helper
INFO - 2020-02-04 04:32:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:32:18 --> Controller Class Initialized
INFO - 2020-02-04 04:32:18 --> Config Class Initialized
INFO - 2020-02-04 04:32:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:32:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:32:18 --> Utf8 Class Initialized
INFO - 2020-02-04 04:32:18 --> URI Class Initialized
INFO - 2020-02-04 04:32:18 --> Router Class Initialized
INFO - 2020-02-04 04:32:18 --> Output Class Initialized
INFO - 2020-02-04 04:32:18 --> Security Class Initialized
DEBUG - 2020-02-04 04:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:32:18 --> Input Class Initialized
INFO - 2020-02-04 04:32:18 --> Language Class Initialized
INFO - 2020-02-04 04:32:18 --> Language Class Initialized
INFO - 2020-02-04 04:32:18 --> Config Class Initialized
INFO - 2020-02-04 04:32:18 --> Loader Class Initialized
INFO - 2020-02-04 04:32:18 --> Helper loaded: url_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: file_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: form_helper
INFO - 2020-02-04 04:32:18 --> Helper loaded: my_helper
INFO - 2020-02-04 04:32:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:32:18 --> Controller Class Initialized
DEBUG - 2020-02-04 04:32:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-04 04:32:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:32:18 --> Final output sent to browser
DEBUG - 2020-02-04 04:32:19 --> Total execution time: 0.2908
INFO - 2020-02-04 04:35:13 --> Config Class Initialized
INFO - 2020-02-04 04:35:13 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:35:13 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:35:13 --> Utf8 Class Initialized
INFO - 2020-02-04 04:35:13 --> URI Class Initialized
INFO - 2020-02-04 04:35:13 --> Router Class Initialized
INFO - 2020-02-04 04:35:13 --> Output Class Initialized
INFO - 2020-02-04 04:35:13 --> Security Class Initialized
DEBUG - 2020-02-04 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:35:13 --> Input Class Initialized
INFO - 2020-02-04 04:35:13 --> Language Class Initialized
INFO - 2020-02-04 04:35:13 --> Language Class Initialized
INFO - 2020-02-04 04:35:13 --> Config Class Initialized
INFO - 2020-02-04 04:35:13 --> Loader Class Initialized
INFO - 2020-02-04 04:35:13 --> Helper loaded: url_helper
INFO - 2020-02-04 04:35:13 --> Helper loaded: file_helper
INFO - 2020-02-04 04:35:13 --> Helper loaded: form_helper
INFO - 2020-02-04 04:35:13 --> Helper loaded: my_helper
INFO - 2020-02-04 04:35:13 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:35:13 --> Controller Class Initialized
INFO - 2020-02-04 04:35:13 --> Helper loaded: cookie_helper
INFO - 2020-02-04 04:35:13 --> Final output sent to browser
DEBUG - 2020-02-04 04:35:13 --> Total execution time: 0.3336
INFO - 2020-02-04 04:35:13 --> Config Class Initialized
INFO - 2020-02-04 04:35:13 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:35:13 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:35:13 --> Utf8 Class Initialized
INFO - 2020-02-04 04:35:13 --> URI Class Initialized
INFO - 2020-02-04 04:35:13 --> Router Class Initialized
INFO - 2020-02-04 04:35:13 --> Output Class Initialized
INFO - 2020-02-04 04:35:13 --> Security Class Initialized
DEBUG - 2020-02-04 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:35:13 --> Input Class Initialized
INFO - 2020-02-04 04:35:13 --> Language Class Initialized
INFO - 2020-02-04 04:35:13 --> Language Class Initialized
INFO - 2020-02-04 04:35:13 --> Config Class Initialized
INFO - 2020-02-04 04:35:13 --> Loader Class Initialized
INFO - 2020-02-04 04:35:13 --> Helper loaded: url_helper
INFO - 2020-02-04 04:35:13 --> Helper loaded: file_helper
INFO - 2020-02-04 04:35:13 --> Helper loaded: form_helper
INFO - 2020-02-04 04:35:14 --> Helper loaded: my_helper
INFO - 2020-02-04 04:35:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:35:14 --> Controller Class Initialized
DEBUG - 2020-02-04 04:35:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-04 04:35:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:35:14 --> Final output sent to browser
DEBUG - 2020-02-04 04:35:14 --> Total execution time: 0.3584
INFO - 2020-02-04 04:35:24 --> Config Class Initialized
INFO - 2020-02-04 04:35:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:35:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:35:24 --> Utf8 Class Initialized
INFO - 2020-02-04 04:35:24 --> URI Class Initialized
INFO - 2020-02-04 04:35:24 --> Router Class Initialized
INFO - 2020-02-04 04:35:24 --> Output Class Initialized
INFO - 2020-02-04 04:35:24 --> Security Class Initialized
DEBUG - 2020-02-04 04:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:35:24 --> Input Class Initialized
INFO - 2020-02-04 04:35:24 --> Language Class Initialized
INFO - 2020-02-04 04:35:24 --> Language Class Initialized
INFO - 2020-02-04 04:35:24 --> Config Class Initialized
INFO - 2020-02-04 04:35:24 --> Loader Class Initialized
INFO - 2020-02-04 04:35:24 --> Helper loaded: url_helper
INFO - 2020-02-04 04:35:24 --> Helper loaded: file_helper
INFO - 2020-02-04 04:35:24 --> Helper loaded: form_helper
INFO - 2020-02-04 04:35:24 --> Helper loaded: my_helper
INFO - 2020-02-04 04:35:24 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:35:24 --> Controller Class Initialized
DEBUG - 2020-02-04 04:35:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:35:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:35:24 --> Final output sent to browser
DEBUG - 2020-02-04 04:35:24 --> Total execution time: 0.3313
INFO - 2020-02-04 04:35:26 --> Config Class Initialized
INFO - 2020-02-04 04:35:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:35:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:35:26 --> Utf8 Class Initialized
INFO - 2020-02-04 04:35:26 --> URI Class Initialized
INFO - 2020-02-04 04:35:26 --> Router Class Initialized
INFO - 2020-02-04 04:35:26 --> Output Class Initialized
INFO - 2020-02-04 04:35:26 --> Security Class Initialized
DEBUG - 2020-02-04 04:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:35:26 --> Input Class Initialized
INFO - 2020-02-04 04:35:26 --> Language Class Initialized
INFO - 2020-02-04 04:35:26 --> Language Class Initialized
INFO - 2020-02-04 04:35:26 --> Config Class Initialized
INFO - 2020-02-04 04:35:26 --> Loader Class Initialized
INFO - 2020-02-04 04:35:26 --> Helper loaded: url_helper
INFO - 2020-02-04 04:35:26 --> Helper loaded: file_helper
INFO - 2020-02-04 04:35:26 --> Helper loaded: form_helper
INFO - 2020-02-04 04:35:26 --> Helper loaded: my_helper
INFO - 2020-02-04 04:35:26 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:35:26 --> Controller Class Initialized
DEBUG - 2020-02-04 04:35:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:35:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:35:26 --> Final output sent to browser
DEBUG - 2020-02-04 04:35:26 --> Total execution time: 0.2919
INFO - 2020-02-04 04:37:18 --> Config Class Initialized
INFO - 2020-02-04 04:37:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:37:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:37:18 --> Utf8 Class Initialized
INFO - 2020-02-04 04:37:18 --> URI Class Initialized
INFO - 2020-02-04 04:37:18 --> Router Class Initialized
INFO - 2020-02-04 04:37:18 --> Output Class Initialized
INFO - 2020-02-04 04:37:18 --> Security Class Initialized
DEBUG - 2020-02-04 04:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:37:19 --> Input Class Initialized
INFO - 2020-02-04 04:37:19 --> Language Class Initialized
INFO - 2020-02-04 04:37:19 --> Language Class Initialized
INFO - 2020-02-04 04:37:19 --> Config Class Initialized
INFO - 2020-02-04 04:37:19 --> Loader Class Initialized
INFO - 2020-02-04 04:37:19 --> Helper loaded: url_helper
INFO - 2020-02-04 04:37:19 --> Helper loaded: file_helper
INFO - 2020-02-04 04:37:19 --> Helper loaded: form_helper
INFO - 2020-02-04 04:37:19 --> Helper loaded: my_helper
INFO - 2020-02-04 04:37:19 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:37:19 --> Controller Class Initialized
DEBUG - 2020-02-04 04:37:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:37:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:37:19 --> Final output sent to browser
DEBUG - 2020-02-04 04:37:19 --> Total execution time: 0.3015
INFO - 2020-02-04 04:38:35 --> Config Class Initialized
INFO - 2020-02-04 04:38:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:38:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:38:35 --> Utf8 Class Initialized
INFO - 2020-02-04 04:38:35 --> URI Class Initialized
INFO - 2020-02-04 04:38:35 --> Router Class Initialized
INFO - 2020-02-04 04:38:35 --> Output Class Initialized
INFO - 2020-02-04 04:38:35 --> Security Class Initialized
DEBUG - 2020-02-04 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:38:35 --> Input Class Initialized
INFO - 2020-02-04 04:38:35 --> Language Class Initialized
INFO - 2020-02-04 04:38:35 --> Language Class Initialized
INFO - 2020-02-04 04:38:35 --> Config Class Initialized
INFO - 2020-02-04 04:38:35 --> Loader Class Initialized
INFO - 2020-02-04 04:38:35 --> Helper loaded: url_helper
INFO - 2020-02-04 04:38:35 --> Helper loaded: file_helper
INFO - 2020-02-04 04:38:35 --> Helper loaded: form_helper
INFO - 2020-02-04 04:38:35 --> Helper loaded: my_helper
INFO - 2020-02-04 04:38:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:38:35 --> Controller Class Initialized
DEBUG - 2020-02-04 04:38:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:38:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:38:35 --> Final output sent to browser
DEBUG - 2020-02-04 04:38:35 --> Total execution time: 0.2981
INFO - 2020-02-04 04:38:37 --> Config Class Initialized
INFO - 2020-02-04 04:38:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:38:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:38:37 --> Utf8 Class Initialized
INFO - 2020-02-04 04:38:37 --> URI Class Initialized
INFO - 2020-02-04 04:38:37 --> Router Class Initialized
INFO - 2020-02-04 04:38:37 --> Output Class Initialized
INFO - 2020-02-04 04:38:37 --> Security Class Initialized
DEBUG - 2020-02-04 04:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:38:37 --> Input Class Initialized
INFO - 2020-02-04 04:38:37 --> Language Class Initialized
INFO - 2020-02-04 04:38:37 --> Language Class Initialized
INFO - 2020-02-04 04:38:37 --> Config Class Initialized
INFO - 2020-02-04 04:38:37 --> Loader Class Initialized
INFO - 2020-02-04 04:38:37 --> Helper loaded: url_helper
INFO - 2020-02-04 04:38:37 --> Helper loaded: file_helper
INFO - 2020-02-04 04:38:38 --> Helper loaded: form_helper
INFO - 2020-02-04 04:38:38 --> Helper loaded: my_helper
INFO - 2020-02-04 04:38:38 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:38:38 --> Controller Class Initialized
DEBUG - 2020-02-04 04:38:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:38:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:38:38 --> Final output sent to browser
DEBUG - 2020-02-04 04:38:38 --> Total execution time: 0.3009
INFO - 2020-02-04 04:38:56 --> Config Class Initialized
INFO - 2020-02-04 04:38:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:38:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:38:56 --> Utf8 Class Initialized
INFO - 2020-02-04 04:38:56 --> URI Class Initialized
INFO - 2020-02-04 04:38:56 --> Router Class Initialized
INFO - 2020-02-04 04:38:56 --> Output Class Initialized
INFO - 2020-02-04 04:38:56 --> Security Class Initialized
DEBUG - 2020-02-04 04:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:38:56 --> Input Class Initialized
INFO - 2020-02-04 04:38:56 --> Language Class Initialized
INFO - 2020-02-04 04:38:56 --> Language Class Initialized
INFO - 2020-02-04 04:38:56 --> Config Class Initialized
INFO - 2020-02-04 04:38:56 --> Loader Class Initialized
INFO - 2020-02-04 04:38:56 --> Helper loaded: url_helper
INFO - 2020-02-04 04:38:56 --> Helper loaded: file_helper
INFO - 2020-02-04 04:38:56 --> Helper loaded: form_helper
INFO - 2020-02-04 04:38:56 --> Helper loaded: my_helper
INFO - 2020-02-04 04:38:56 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:38:56 --> Controller Class Initialized
DEBUG - 2020-02-04 04:38:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:38:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:38:57 --> Final output sent to browser
DEBUG - 2020-02-04 04:38:57 --> Total execution time: 0.3071
INFO - 2020-02-04 04:38:58 --> Config Class Initialized
INFO - 2020-02-04 04:38:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:38:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:38:58 --> Utf8 Class Initialized
INFO - 2020-02-04 04:38:58 --> URI Class Initialized
INFO - 2020-02-04 04:38:58 --> Router Class Initialized
INFO - 2020-02-04 04:38:58 --> Output Class Initialized
INFO - 2020-02-04 04:38:58 --> Security Class Initialized
DEBUG - 2020-02-04 04:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:38:58 --> Input Class Initialized
INFO - 2020-02-04 04:38:58 --> Language Class Initialized
INFO - 2020-02-04 04:38:58 --> Language Class Initialized
INFO - 2020-02-04 04:38:58 --> Config Class Initialized
INFO - 2020-02-04 04:38:58 --> Loader Class Initialized
INFO - 2020-02-04 04:38:58 --> Helper loaded: url_helper
INFO - 2020-02-04 04:38:58 --> Helper loaded: file_helper
INFO - 2020-02-04 04:38:58 --> Helper loaded: form_helper
INFO - 2020-02-04 04:38:58 --> Helper loaded: my_helper
INFO - 2020-02-04 04:38:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:38:58 --> Controller Class Initialized
DEBUG - 2020-02-04 04:38:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:38:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:38:58 --> Final output sent to browser
DEBUG - 2020-02-04 04:38:58 --> Total execution time: 0.2936
INFO - 2020-02-04 04:39:32 --> Config Class Initialized
INFO - 2020-02-04 04:39:32 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:39:32 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:39:32 --> Utf8 Class Initialized
INFO - 2020-02-04 04:39:32 --> URI Class Initialized
INFO - 2020-02-04 04:39:32 --> Router Class Initialized
INFO - 2020-02-04 04:39:32 --> Output Class Initialized
INFO - 2020-02-04 04:39:32 --> Security Class Initialized
DEBUG - 2020-02-04 04:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:39:32 --> Input Class Initialized
INFO - 2020-02-04 04:39:32 --> Language Class Initialized
INFO - 2020-02-04 04:39:32 --> Language Class Initialized
INFO - 2020-02-04 04:39:32 --> Config Class Initialized
INFO - 2020-02-04 04:39:32 --> Loader Class Initialized
INFO - 2020-02-04 04:39:32 --> Helper loaded: url_helper
INFO - 2020-02-04 04:39:32 --> Helper loaded: file_helper
INFO - 2020-02-04 04:39:32 --> Helper loaded: form_helper
INFO - 2020-02-04 04:39:32 --> Helper loaded: my_helper
INFO - 2020-02-04 04:39:32 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:39:32 --> Controller Class Initialized
DEBUG - 2020-02-04 04:39:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:39:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:39:32 --> Final output sent to browser
DEBUG - 2020-02-04 04:39:32 --> Total execution time: 0.3183
INFO - 2020-02-04 04:40:05 --> Config Class Initialized
INFO - 2020-02-04 04:40:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:40:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:40:05 --> Utf8 Class Initialized
INFO - 2020-02-04 04:40:05 --> URI Class Initialized
INFO - 2020-02-04 04:40:05 --> Router Class Initialized
INFO - 2020-02-04 04:40:05 --> Output Class Initialized
INFO - 2020-02-04 04:40:05 --> Security Class Initialized
DEBUG - 2020-02-04 04:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:40:05 --> Input Class Initialized
INFO - 2020-02-04 04:40:05 --> Language Class Initialized
INFO - 2020-02-04 04:40:05 --> Language Class Initialized
INFO - 2020-02-04 04:40:05 --> Config Class Initialized
INFO - 2020-02-04 04:40:05 --> Loader Class Initialized
INFO - 2020-02-04 04:40:05 --> Helper loaded: url_helper
INFO - 2020-02-04 04:40:05 --> Helper loaded: file_helper
INFO - 2020-02-04 04:40:05 --> Helper loaded: form_helper
INFO - 2020-02-04 04:40:05 --> Helper loaded: my_helper
INFO - 2020-02-04 04:40:05 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:40:05 --> Controller Class Initialized
DEBUG - 2020-02-04 04:40:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:40:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:40:05 --> Final output sent to browser
DEBUG - 2020-02-04 04:40:05 --> Total execution time: 0.3062
INFO - 2020-02-04 04:40:35 --> Config Class Initialized
INFO - 2020-02-04 04:40:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:40:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:40:35 --> Utf8 Class Initialized
INFO - 2020-02-04 04:40:35 --> URI Class Initialized
INFO - 2020-02-04 04:40:35 --> Router Class Initialized
INFO - 2020-02-04 04:40:35 --> Output Class Initialized
INFO - 2020-02-04 04:40:35 --> Security Class Initialized
DEBUG - 2020-02-04 04:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:40:35 --> Input Class Initialized
INFO - 2020-02-04 04:40:35 --> Language Class Initialized
INFO - 2020-02-04 04:40:35 --> Language Class Initialized
INFO - 2020-02-04 04:40:35 --> Config Class Initialized
INFO - 2020-02-04 04:40:35 --> Loader Class Initialized
INFO - 2020-02-04 04:40:35 --> Helper loaded: url_helper
INFO - 2020-02-04 04:40:35 --> Helper loaded: file_helper
INFO - 2020-02-04 04:40:35 --> Helper loaded: form_helper
INFO - 2020-02-04 04:40:35 --> Helper loaded: my_helper
INFO - 2020-02-04 04:40:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:40:35 --> Controller Class Initialized
DEBUG - 2020-02-04 04:40:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:40:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:40:35 --> Final output sent to browser
DEBUG - 2020-02-04 04:40:35 --> Total execution time: 0.3179
INFO - 2020-02-04 04:41:05 --> Config Class Initialized
INFO - 2020-02-04 04:41:05 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:41:05 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:41:05 --> Utf8 Class Initialized
INFO - 2020-02-04 04:41:05 --> URI Class Initialized
INFO - 2020-02-04 04:41:05 --> Router Class Initialized
INFO - 2020-02-04 04:41:05 --> Output Class Initialized
INFO - 2020-02-04 04:41:05 --> Security Class Initialized
DEBUG - 2020-02-04 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:41:05 --> Input Class Initialized
INFO - 2020-02-04 04:41:05 --> Language Class Initialized
INFO - 2020-02-04 04:41:05 --> Language Class Initialized
INFO - 2020-02-04 04:41:05 --> Config Class Initialized
INFO - 2020-02-04 04:41:05 --> Loader Class Initialized
INFO - 2020-02-04 04:41:05 --> Helper loaded: url_helper
INFO - 2020-02-04 04:41:05 --> Helper loaded: file_helper
INFO - 2020-02-04 04:41:05 --> Helper loaded: form_helper
INFO - 2020-02-04 04:41:05 --> Helper loaded: my_helper
INFO - 2020-02-04 04:41:05 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:41:05 --> Controller Class Initialized
DEBUG - 2020-02-04 04:41:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:41:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:41:05 --> Final output sent to browser
DEBUG - 2020-02-04 04:41:05 --> Total execution time: 0.3054
INFO - 2020-02-04 04:41:59 --> Config Class Initialized
INFO - 2020-02-04 04:41:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:41:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:41:59 --> Utf8 Class Initialized
INFO - 2020-02-04 04:41:59 --> URI Class Initialized
INFO - 2020-02-04 04:41:59 --> Router Class Initialized
INFO - 2020-02-04 04:41:59 --> Output Class Initialized
INFO - 2020-02-04 04:41:59 --> Security Class Initialized
DEBUG - 2020-02-04 04:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:41:59 --> Input Class Initialized
INFO - 2020-02-04 04:41:59 --> Language Class Initialized
INFO - 2020-02-04 04:41:59 --> Language Class Initialized
INFO - 2020-02-04 04:41:59 --> Config Class Initialized
INFO - 2020-02-04 04:41:59 --> Loader Class Initialized
INFO - 2020-02-04 04:41:59 --> Helper loaded: url_helper
INFO - 2020-02-04 04:42:00 --> Helper loaded: file_helper
INFO - 2020-02-04 04:42:00 --> Helper loaded: form_helper
INFO - 2020-02-04 04:42:00 --> Helper loaded: my_helper
INFO - 2020-02-04 04:42:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:42:00 --> Controller Class Initialized
DEBUG - 2020-02-04 04:42:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:42:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:42:00 --> Final output sent to browser
DEBUG - 2020-02-04 04:42:00 --> Total execution time: 0.3188
INFO - 2020-02-04 04:42:18 --> Config Class Initialized
INFO - 2020-02-04 04:42:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:42:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:42:18 --> Utf8 Class Initialized
INFO - 2020-02-04 04:42:18 --> URI Class Initialized
INFO - 2020-02-04 04:42:18 --> Router Class Initialized
INFO - 2020-02-04 04:42:18 --> Output Class Initialized
INFO - 2020-02-04 04:42:18 --> Security Class Initialized
DEBUG - 2020-02-04 04:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:42:18 --> Input Class Initialized
INFO - 2020-02-04 04:42:18 --> Language Class Initialized
INFO - 2020-02-04 04:42:18 --> Language Class Initialized
INFO - 2020-02-04 04:42:18 --> Config Class Initialized
INFO - 2020-02-04 04:42:18 --> Loader Class Initialized
INFO - 2020-02-04 04:42:18 --> Helper loaded: url_helper
INFO - 2020-02-04 04:42:18 --> Helper loaded: file_helper
INFO - 2020-02-04 04:42:18 --> Helper loaded: form_helper
INFO - 2020-02-04 04:42:18 --> Helper loaded: my_helper
INFO - 2020-02-04 04:42:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:42:18 --> Controller Class Initialized
DEBUG - 2020-02-04 04:42:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:42:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:42:18 --> Final output sent to browser
DEBUG - 2020-02-04 04:42:18 --> Total execution time: 0.3154
INFO - 2020-02-04 04:42:43 --> Config Class Initialized
INFO - 2020-02-04 04:42:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:42:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:42:43 --> Utf8 Class Initialized
INFO - 2020-02-04 04:42:43 --> URI Class Initialized
INFO - 2020-02-04 04:42:43 --> Router Class Initialized
INFO - 2020-02-04 04:42:43 --> Output Class Initialized
INFO - 2020-02-04 04:42:43 --> Security Class Initialized
DEBUG - 2020-02-04 04:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:42:43 --> Input Class Initialized
INFO - 2020-02-04 04:42:43 --> Language Class Initialized
INFO - 2020-02-04 04:42:43 --> Language Class Initialized
INFO - 2020-02-04 04:42:43 --> Config Class Initialized
INFO - 2020-02-04 04:42:43 --> Loader Class Initialized
INFO - 2020-02-04 04:42:43 --> Helper loaded: url_helper
INFO - 2020-02-04 04:42:43 --> Helper loaded: file_helper
INFO - 2020-02-04 04:42:43 --> Helper loaded: form_helper
INFO - 2020-02-04 04:42:43 --> Helper loaded: my_helper
INFO - 2020-02-04 04:42:43 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:42:43 --> Controller Class Initialized
DEBUG - 2020-02-04 04:42:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:42:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:42:43 --> Final output sent to browser
DEBUG - 2020-02-04 04:42:43 --> Total execution time: 0.3030
INFO - 2020-02-04 04:45:08 --> Config Class Initialized
INFO - 2020-02-04 04:45:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:08 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:08 --> URI Class Initialized
INFO - 2020-02-04 04:45:09 --> Router Class Initialized
INFO - 2020-02-04 04:45:09 --> Output Class Initialized
INFO - 2020-02-04 04:45:09 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:09 --> Input Class Initialized
INFO - 2020-02-04 04:45:09 --> Language Class Initialized
INFO - 2020-02-04 04:45:09 --> Language Class Initialized
INFO - 2020-02-04 04:45:09 --> Config Class Initialized
INFO - 2020-02-04 04:45:09 --> Loader Class Initialized
INFO - 2020-02-04 04:45:09 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:09 --> Controller Class Initialized
INFO - 2020-02-04 04:45:09 --> Config Class Initialized
INFO - 2020-02-04 04:45:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:09 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:09 --> URI Class Initialized
INFO - 2020-02-04 04:45:09 --> Router Class Initialized
INFO - 2020-02-04 04:45:09 --> Output Class Initialized
INFO - 2020-02-04 04:45:09 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:09 --> Input Class Initialized
INFO - 2020-02-04 04:45:09 --> Language Class Initialized
INFO - 2020-02-04 04:45:09 --> Language Class Initialized
INFO - 2020-02-04 04:45:09 --> Config Class Initialized
INFO - 2020-02-04 04:45:09 --> Loader Class Initialized
INFO - 2020-02-04 04:45:09 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:09 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:09 --> Controller Class Initialized
DEBUG - 2020-02-04 04:45:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:45:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:45:09 --> Final output sent to browser
DEBUG - 2020-02-04 04:45:09 --> Total execution time: 0.2857
INFO - 2020-02-04 04:45:15 --> Config Class Initialized
INFO - 2020-02-04 04:45:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:15 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:15 --> URI Class Initialized
INFO - 2020-02-04 04:45:15 --> Router Class Initialized
INFO - 2020-02-04 04:45:15 --> Output Class Initialized
INFO - 2020-02-04 04:45:15 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:16 --> Input Class Initialized
INFO - 2020-02-04 04:45:16 --> Language Class Initialized
INFO - 2020-02-04 04:45:16 --> Language Class Initialized
INFO - 2020-02-04 04:45:16 --> Config Class Initialized
INFO - 2020-02-04 04:45:16 --> Loader Class Initialized
INFO - 2020-02-04 04:45:16 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:16 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:16 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:16 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:16 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:16 --> Controller Class Initialized
DEBUG - 2020-02-04 04:45:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:45:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:45:16 --> Final output sent to browser
DEBUG - 2020-02-04 04:45:16 --> Total execution time: 0.2891
INFO - 2020-02-04 04:45:28 --> Config Class Initialized
INFO - 2020-02-04 04:45:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:28 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:28 --> URI Class Initialized
INFO - 2020-02-04 04:45:28 --> Router Class Initialized
INFO - 2020-02-04 04:45:28 --> Output Class Initialized
INFO - 2020-02-04 04:45:28 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:28 --> Input Class Initialized
INFO - 2020-02-04 04:45:28 --> Language Class Initialized
INFO - 2020-02-04 04:45:28 --> Language Class Initialized
INFO - 2020-02-04 04:45:28 --> Config Class Initialized
INFO - 2020-02-04 04:45:28 --> Loader Class Initialized
INFO - 2020-02-04 04:45:28 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:28 --> Controller Class Initialized
INFO - 2020-02-04 04:45:28 --> Config Class Initialized
INFO - 2020-02-04 04:45:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:28 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:28 --> URI Class Initialized
INFO - 2020-02-04 04:45:28 --> Router Class Initialized
INFO - 2020-02-04 04:45:28 --> Output Class Initialized
INFO - 2020-02-04 04:45:28 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:28 --> Input Class Initialized
INFO - 2020-02-04 04:45:28 --> Language Class Initialized
INFO - 2020-02-04 04:45:28 --> Language Class Initialized
INFO - 2020-02-04 04:45:28 --> Config Class Initialized
INFO - 2020-02-04 04:45:28 --> Loader Class Initialized
INFO - 2020-02-04 04:45:28 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:28 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:28 --> Controller Class Initialized
DEBUG - 2020-02-04 04:45:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:45:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:45:28 --> Final output sent to browser
DEBUG - 2020-02-04 04:45:28 --> Total execution time: 0.2790
INFO - 2020-02-04 04:45:37 --> Config Class Initialized
INFO - 2020-02-04 04:45:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:37 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:37 --> URI Class Initialized
INFO - 2020-02-04 04:45:37 --> Router Class Initialized
INFO - 2020-02-04 04:45:37 --> Output Class Initialized
INFO - 2020-02-04 04:45:37 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:37 --> Input Class Initialized
INFO - 2020-02-04 04:45:37 --> Language Class Initialized
INFO - 2020-02-04 04:45:37 --> Language Class Initialized
INFO - 2020-02-04 04:45:37 --> Config Class Initialized
INFO - 2020-02-04 04:45:37 --> Loader Class Initialized
INFO - 2020-02-04 04:45:37 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:37 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:37 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:37 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:37 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:37 --> Controller Class Initialized
DEBUG - 2020-02-04 04:45:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:45:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:45:37 --> Final output sent to browser
DEBUG - 2020-02-04 04:45:37 --> Total execution time: 0.2974
INFO - 2020-02-04 04:45:48 --> Config Class Initialized
INFO - 2020-02-04 04:45:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:48 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:48 --> URI Class Initialized
INFO - 2020-02-04 04:45:48 --> Router Class Initialized
INFO - 2020-02-04 04:45:48 --> Output Class Initialized
INFO - 2020-02-04 04:45:48 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:48 --> Input Class Initialized
INFO - 2020-02-04 04:45:48 --> Language Class Initialized
INFO - 2020-02-04 04:45:49 --> Language Class Initialized
INFO - 2020-02-04 04:45:49 --> Config Class Initialized
INFO - 2020-02-04 04:45:49 --> Loader Class Initialized
INFO - 2020-02-04 04:45:49 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:49 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:49 --> Controller Class Initialized
INFO - 2020-02-04 04:45:49 --> Config Class Initialized
INFO - 2020-02-04 04:45:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:45:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:45:49 --> Utf8 Class Initialized
INFO - 2020-02-04 04:45:49 --> URI Class Initialized
INFO - 2020-02-04 04:45:49 --> Router Class Initialized
INFO - 2020-02-04 04:45:49 --> Output Class Initialized
INFO - 2020-02-04 04:45:49 --> Security Class Initialized
DEBUG - 2020-02-04 04:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:45:49 --> Input Class Initialized
INFO - 2020-02-04 04:45:49 --> Language Class Initialized
INFO - 2020-02-04 04:45:49 --> Language Class Initialized
INFO - 2020-02-04 04:45:49 --> Config Class Initialized
INFO - 2020-02-04 04:45:49 --> Loader Class Initialized
INFO - 2020-02-04 04:45:49 --> Helper loaded: url_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: file_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: form_helper
INFO - 2020-02-04 04:45:49 --> Helper loaded: my_helper
INFO - 2020-02-04 04:45:49 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:45:49 --> Controller Class Initialized
DEBUG - 2020-02-04 04:45:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:45:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:45:49 --> Final output sent to browser
DEBUG - 2020-02-04 04:45:49 --> Total execution time: 0.2898
INFO - 2020-02-04 04:46:31 --> Config Class Initialized
INFO - 2020-02-04 04:46:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:46:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:46:31 --> Utf8 Class Initialized
INFO - 2020-02-04 04:46:31 --> URI Class Initialized
INFO - 2020-02-04 04:46:31 --> Router Class Initialized
INFO - 2020-02-04 04:46:31 --> Output Class Initialized
INFO - 2020-02-04 04:46:31 --> Security Class Initialized
DEBUG - 2020-02-04 04:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:46:31 --> Input Class Initialized
INFO - 2020-02-04 04:46:31 --> Language Class Initialized
INFO - 2020-02-04 04:46:31 --> Language Class Initialized
INFO - 2020-02-04 04:46:31 --> Config Class Initialized
INFO - 2020-02-04 04:46:31 --> Loader Class Initialized
INFO - 2020-02-04 04:46:31 --> Helper loaded: url_helper
INFO - 2020-02-04 04:46:31 --> Helper loaded: file_helper
INFO - 2020-02-04 04:46:31 --> Helper loaded: form_helper
INFO - 2020-02-04 04:46:32 --> Helper loaded: my_helper
INFO - 2020-02-04 04:46:32 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:46:32 --> Controller Class Initialized
DEBUG - 2020-02-04 04:46:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:46:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:46:32 --> Final output sent to browser
DEBUG - 2020-02-04 04:46:32 --> Total execution time: 0.2963
INFO - 2020-02-04 04:46:33 --> Config Class Initialized
INFO - 2020-02-04 04:46:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:46:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:46:33 --> Utf8 Class Initialized
INFO - 2020-02-04 04:46:33 --> URI Class Initialized
INFO - 2020-02-04 04:46:33 --> Router Class Initialized
INFO - 2020-02-04 04:46:33 --> Output Class Initialized
INFO - 2020-02-04 04:46:33 --> Security Class Initialized
DEBUG - 2020-02-04 04:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:46:33 --> Input Class Initialized
INFO - 2020-02-04 04:46:33 --> Language Class Initialized
INFO - 2020-02-04 04:46:33 --> Language Class Initialized
INFO - 2020-02-04 04:46:33 --> Config Class Initialized
INFO - 2020-02-04 04:46:33 --> Loader Class Initialized
INFO - 2020-02-04 04:46:33 --> Helper loaded: url_helper
INFO - 2020-02-04 04:46:33 --> Helper loaded: file_helper
INFO - 2020-02-04 04:46:33 --> Helper loaded: form_helper
INFO - 2020-02-04 04:46:33 --> Helper loaded: my_helper
INFO - 2020-02-04 04:46:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:46:33 --> Controller Class Initialized
DEBUG - 2020-02-04 04:46:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:46:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:46:33 --> Final output sent to browser
DEBUG - 2020-02-04 04:46:33 --> Total execution time: 0.4081
INFO - 2020-02-04 04:48:26 --> Config Class Initialized
INFO - 2020-02-04 04:48:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:26 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:26 --> URI Class Initialized
INFO - 2020-02-04 04:48:26 --> Router Class Initialized
INFO - 2020-02-04 04:48:26 --> Output Class Initialized
INFO - 2020-02-04 04:48:26 --> Security Class Initialized
DEBUG - 2020-02-04 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:48:26 --> Input Class Initialized
INFO - 2020-02-04 04:48:26 --> Language Class Initialized
INFO - 2020-02-04 04:48:26 --> Language Class Initialized
INFO - 2020-02-04 04:48:26 --> Config Class Initialized
INFO - 2020-02-04 04:48:26 --> Loader Class Initialized
INFO - 2020-02-04 04:48:26 --> Helper loaded: url_helper
INFO - 2020-02-04 04:48:26 --> Helper loaded: file_helper
INFO - 2020-02-04 04:48:26 --> Helper loaded: form_helper
INFO - 2020-02-04 04:48:26 --> Helper loaded: my_helper
INFO - 2020-02-04 04:48:26 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:48:26 --> Controller Class Initialized
DEBUG - 2020-02-04 04:48:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:48:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:48:26 --> Final output sent to browser
DEBUG - 2020-02-04 04:48:26 --> Total execution time: 0.2982
INFO - 2020-02-04 04:48:33 --> Config Class Initialized
INFO - 2020-02-04 04:48:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:33 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:33 --> URI Class Initialized
INFO - 2020-02-04 04:48:33 --> Router Class Initialized
INFO - 2020-02-04 04:48:33 --> Output Class Initialized
INFO - 2020-02-04 04:48:33 --> Security Class Initialized
DEBUG - 2020-02-04 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:48:33 --> Input Class Initialized
INFO - 2020-02-04 04:48:33 --> Language Class Initialized
INFO - 2020-02-04 04:48:33 --> Language Class Initialized
INFO - 2020-02-04 04:48:33 --> Config Class Initialized
INFO - 2020-02-04 04:48:33 --> Loader Class Initialized
INFO - 2020-02-04 04:48:33 --> Helper loaded: url_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: file_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: form_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: my_helper
INFO - 2020-02-04 04:48:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:48:33 --> Controller Class Initialized
INFO - 2020-02-04 04:48:33 --> Config Class Initialized
INFO - 2020-02-04 04:48:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:33 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:33 --> URI Class Initialized
INFO - 2020-02-04 04:48:33 --> Router Class Initialized
INFO - 2020-02-04 04:48:33 --> Output Class Initialized
INFO - 2020-02-04 04:48:33 --> Security Class Initialized
DEBUG - 2020-02-04 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:48:33 --> Input Class Initialized
INFO - 2020-02-04 04:48:33 --> Language Class Initialized
INFO - 2020-02-04 04:48:33 --> Language Class Initialized
INFO - 2020-02-04 04:48:33 --> Config Class Initialized
INFO - 2020-02-04 04:48:33 --> Loader Class Initialized
INFO - 2020-02-04 04:48:33 --> Helper loaded: url_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: file_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: form_helper
INFO - 2020-02-04 04:48:33 --> Helper loaded: my_helper
INFO - 2020-02-04 04:48:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:48:34 --> Controller Class Initialized
DEBUG - 2020-02-04 04:48:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:48:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:48:34 --> Final output sent to browser
DEBUG - 2020-02-04 04:48:34 --> Total execution time: 0.2765
INFO - 2020-02-04 04:48:43 --> Config Class Initialized
INFO - 2020-02-04 04:48:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:43 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:43 --> URI Class Initialized
INFO - 2020-02-04 04:48:43 --> Router Class Initialized
INFO - 2020-02-04 04:48:43 --> Output Class Initialized
INFO - 2020-02-04 04:48:43 --> Security Class Initialized
DEBUG - 2020-02-04 04:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:48:43 --> Input Class Initialized
INFO - 2020-02-04 04:48:43 --> Language Class Initialized
INFO - 2020-02-04 04:48:43 --> Language Class Initialized
INFO - 2020-02-04 04:48:43 --> Config Class Initialized
INFO - 2020-02-04 04:48:43 --> Loader Class Initialized
INFO - 2020-02-04 04:48:43 --> Helper loaded: url_helper
INFO - 2020-02-04 04:48:43 --> Helper loaded: file_helper
INFO - 2020-02-04 04:48:43 --> Helper loaded: form_helper
INFO - 2020-02-04 04:48:43 --> Helper loaded: my_helper
INFO - 2020-02-04 04:48:43 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:48:43 --> Controller Class Initialized
DEBUG - 2020-02-04 04:48:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:48:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:48:43 --> Final output sent to browser
DEBUG - 2020-02-04 04:48:43 --> Total execution time: 0.3048
INFO - 2020-02-04 04:48:56 --> Config Class Initialized
INFO - 2020-02-04 04:48:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:56 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:56 --> URI Class Initialized
INFO - 2020-02-04 04:48:56 --> Router Class Initialized
INFO - 2020-02-04 04:48:56 --> Output Class Initialized
INFO - 2020-02-04 04:48:56 --> Security Class Initialized
DEBUG - 2020-02-04 04:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:48:56 --> Input Class Initialized
INFO - 2020-02-04 04:48:56 --> Language Class Initialized
INFO - 2020-02-04 04:48:56 --> Language Class Initialized
INFO - 2020-02-04 04:48:56 --> Config Class Initialized
INFO - 2020-02-04 04:48:56 --> Loader Class Initialized
INFO - 2020-02-04 04:48:56 --> Helper loaded: url_helper
INFO - 2020-02-04 04:48:56 --> Helper loaded: file_helper
INFO - 2020-02-04 04:48:56 --> Helper loaded: form_helper
INFO - 2020-02-04 04:48:56 --> Helper loaded: my_helper
INFO - 2020-02-04 04:48:56 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:48:56 --> Controller Class Initialized
DEBUG - 2020-02-04 04:48:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:48:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:48:56 --> Final output sent to browser
DEBUG - 2020-02-04 04:48:56 --> Total execution time: 0.3524
INFO - 2020-02-04 04:48:59 --> Config Class Initialized
INFO - 2020-02-04 04:48:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:48:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:48:59 --> Utf8 Class Initialized
INFO - 2020-02-04 04:48:59 --> URI Class Initialized
INFO - 2020-02-04 04:49:00 --> Router Class Initialized
INFO - 2020-02-04 04:49:00 --> Output Class Initialized
INFO - 2020-02-04 04:49:00 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:00 --> Input Class Initialized
INFO - 2020-02-04 04:49:00 --> Language Class Initialized
INFO - 2020-02-04 04:49:00 --> Language Class Initialized
INFO - 2020-02-04 04:49:00 --> Config Class Initialized
INFO - 2020-02-04 04:49:00 --> Loader Class Initialized
INFO - 2020-02-04 04:49:00 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:00 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:00 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:00 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:00 --> Controller Class Initialized
INFO - 2020-02-04 04:49:00 --> Final output sent to browser
DEBUG - 2020-02-04 04:49:00 --> Total execution time: 0.3783
INFO - 2020-02-04 04:49:03 --> Config Class Initialized
INFO - 2020-02-04 04:49:03 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:49:03 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:49:03 --> Utf8 Class Initialized
INFO - 2020-02-04 04:49:03 --> URI Class Initialized
INFO - 2020-02-04 04:49:03 --> Router Class Initialized
INFO - 2020-02-04 04:49:03 --> Output Class Initialized
INFO - 2020-02-04 04:49:03 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:03 --> Input Class Initialized
INFO - 2020-02-04 04:49:03 --> Language Class Initialized
INFO - 2020-02-04 04:49:03 --> Language Class Initialized
INFO - 2020-02-04 04:49:03 --> Config Class Initialized
INFO - 2020-02-04 04:49:03 --> Loader Class Initialized
INFO - 2020-02-04 04:49:03 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:03 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:03 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:03 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:03 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:03 --> Controller Class Initialized
DEBUG - 2020-02-04 04:49:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:49:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:49:03 --> Final output sent to browser
DEBUG - 2020-02-04 04:49:03 --> Total execution time: 0.3258
INFO - 2020-02-04 04:49:07 --> Config Class Initialized
INFO - 2020-02-04 04:49:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:49:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:49:07 --> Utf8 Class Initialized
INFO - 2020-02-04 04:49:07 --> URI Class Initialized
INFO - 2020-02-04 04:49:07 --> Router Class Initialized
INFO - 2020-02-04 04:49:07 --> Output Class Initialized
INFO - 2020-02-04 04:49:07 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:07 --> Input Class Initialized
INFO - 2020-02-04 04:49:07 --> Language Class Initialized
INFO - 2020-02-04 04:49:07 --> Language Class Initialized
INFO - 2020-02-04 04:49:07 --> Config Class Initialized
INFO - 2020-02-04 04:49:07 --> Loader Class Initialized
INFO - 2020-02-04 04:49:07 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:07 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:07 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:07 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:07 --> Controller Class Initialized
DEBUG - 2020-02-04 04:49:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:49:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:49:07 --> Final output sent to browser
DEBUG - 2020-02-04 04:49:07 --> Total execution time: 0.3702
INFO - 2020-02-04 04:49:16 --> Config Class Initialized
INFO - 2020-02-04 04:49:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:49:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:49:16 --> Utf8 Class Initialized
INFO - 2020-02-04 04:49:16 --> URI Class Initialized
INFO - 2020-02-04 04:49:16 --> Router Class Initialized
INFO - 2020-02-04 04:49:16 --> Output Class Initialized
INFO - 2020-02-04 04:49:16 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:16 --> Input Class Initialized
INFO - 2020-02-04 04:49:16 --> Language Class Initialized
INFO - 2020-02-04 04:49:16 --> Language Class Initialized
INFO - 2020-02-04 04:49:16 --> Config Class Initialized
INFO - 2020-02-04 04:49:16 --> Loader Class Initialized
INFO - 2020-02-04 04:49:16 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:16 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:16 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:16 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:16 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:16 --> Controller Class Initialized
INFO - 2020-02-04 04:49:16 --> Config Class Initialized
INFO - 2020-02-04 04:49:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:49:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:49:16 --> Utf8 Class Initialized
INFO - 2020-02-04 04:49:16 --> URI Class Initialized
INFO - 2020-02-04 04:49:16 --> Router Class Initialized
INFO - 2020-02-04 04:49:16 --> Output Class Initialized
INFO - 2020-02-04 04:49:16 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:16 --> Input Class Initialized
INFO - 2020-02-04 04:49:16 --> Language Class Initialized
INFO - 2020-02-04 04:49:16 --> Language Class Initialized
INFO - 2020-02-04 04:49:16 --> Config Class Initialized
INFO - 2020-02-04 04:49:16 --> Loader Class Initialized
INFO - 2020-02-04 04:49:17 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:17 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:17 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:17 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:17 --> Controller Class Initialized
DEBUG - 2020-02-04 04:49:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:49:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:49:17 --> Final output sent to browser
DEBUG - 2020-02-04 04:49:17 --> Total execution time: 0.2984
INFO - 2020-02-04 04:49:29 --> Config Class Initialized
INFO - 2020-02-04 04:49:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:49:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:49:29 --> Utf8 Class Initialized
INFO - 2020-02-04 04:49:29 --> URI Class Initialized
INFO - 2020-02-04 04:49:29 --> Router Class Initialized
INFO - 2020-02-04 04:49:29 --> Output Class Initialized
INFO - 2020-02-04 04:49:29 --> Security Class Initialized
DEBUG - 2020-02-04 04:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:49:29 --> Input Class Initialized
INFO - 2020-02-04 04:49:29 --> Language Class Initialized
INFO - 2020-02-04 04:49:29 --> Language Class Initialized
INFO - 2020-02-04 04:49:29 --> Config Class Initialized
INFO - 2020-02-04 04:49:29 --> Loader Class Initialized
INFO - 2020-02-04 04:49:29 --> Helper loaded: url_helper
INFO - 2020-02-04 04:49:29 --> Helper loaded: file_helper
INFO - 2020-02-04 04:49:29 --> Helper loaded: form_helper
INFO - 2020-02-04 04:49:29 --> Helper loaded: my_helper
INFO - 2020-02-04 04:49:29 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:49:29 --> Controller Class Initialized
DEBUG - 2020-02-04 04:49:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:49:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:49:29 --> Final output sent to browser
DEBUG - 2020-02-04 04:49:29 --> Total execution time: 0.3464
INFO - 2020-02-04 04:55:31 --> Config Class Initialized
INFO - 2020-02-04 04:55:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:31 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:31 --> URI Class Initialized
INFO - 2020-02-04 04:55:31 --> Router Class Initialized
INFO - 2020-02-04 04:55:31 --> Output Class Initialized
INFO - 2020-02-04 04:55:31 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:31 --> Input Class Initialized
INFO - 2020-02-04 04:55:31 --> Language Class Initialized
INFO - 2020-02-04 04:55:31 --> Language Class Initialized
INFO - 2020-02-04 04:55:31 --> Config Class Initialized
INFO - 2020-02-04 04:55:31 --> Loader Class Initialized
INFO - 2020-02-04 04:55:31 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:31 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:31 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:31 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:31 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:31 --> Controller Class Initialized
DEBUG - 2020-02-04 04:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:55:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:55:31 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:31 --> Total execution time: 0.3659
INFO - 2020-02-04 04:55:34 --> Config Class Initialized
INFO - 2020-02-04 04:55:34 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:34 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:34 --> URI Class Initialized
INFO - 2020-02-04 04:55:34 --> Router Class Initialized
INFO - 2020-02-04 04:55:34 --> Output Class Initialized
INFO - 2020-02-04 04:55:34 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:34 --> Input Class Initialized
INFO - 2020-02-04 04:55:34 --> Language Class Initialized
INFO - 2020-02-04 04:55:34 --> Language Class Initialized
INFO - 2020-02-04 04:55:35 --> Config Class Initialized
INFO - 2020-02-04 04:55:35 --> Loader Class Initialized
INFO - 2020-02-04 04:55:35 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:35 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:35 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:35 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:35 --> Controller Class Initialized
INFO - 2020-02-04 04:55:35 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:35 --> Total execution time: 0.3384
INFO - 2020-02-04 04:55:36 --> Config Class Initialized
INFO - 2020-02-04 04:55:36 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:37 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:37 --> URI Class Initialized
INFO - 2020-02-04 04:55:37 --> Router Class Initialized
INFO - 2020-02-04 04:55:37 --> Output Class Initialized
INFO - 2020-02-04 04:55:37 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:37 --> Input Class Initialized
INFO - 2020-02-04 04:55:37 --> Language Class Initialized
INFO - 2020-02-04 04:55:37 --> Language Class Initialized
INFO - 2020-02-04 04:55:37 --> Config Class Initialized
INFO - 2020-02-04 04:55:37 --> Loader Class Initialized
INFO - 2020-02-04 04:55:37 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:37 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:37 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:37 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:37 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:37 --> Controller Class Initialized
INFO - 2020-02-04 04:55:37 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:37 --> Total execution time: 0.3269
INFO - 2020-02-04 04:55:38 --> Config Class Initialized
INFO - 2020-02-04 04:55:38 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:38 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:38 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:38 --> URI Class Initialized
INFO - 2020-02-04 04:55:38 --> Router Class Initialized
INFO - 2020-02-04 04:55:38 --> Output Class Initialized
INFO - 2020-02-04 04:55:38 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:38 --> Input Class Initialized
INFO - 2020-02-04 04:55:38 --> Language Class Initialized
INFO - 2020-02-04 04:55:38 --> Language Class Initialized
INFO - 2020-02-04 04:55:38 --> Config Class Initialized
INFO - 2020-02-04 04:55:38 --> Loader Class Initialized
INFO - 2020-02-04 04:55:38 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:39 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:39 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:39 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:39 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:39 --> Controller Class Initialized
INFO - 2020-02-04 04:55:39 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:39 --> Total execution time: 0.3412
INFO - 2020-02-04 04:55:40 --> Config Class Initialized
INFO - 2020-02-04 04:55:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:40 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:40 --> URI Class Initialized
INFO - 2020-02-04 04:55:40 --> Router Class Initialized
INFO - 2020-02-04 04:55:40 --> Output Class Initialized
INFO - 2020-02-04 04:55:40 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:40 --> Input Class Initialized
INFO - 2020-02-04 04:55:40 --> Language Class Initialized
INFO - 2020-02-04 04:55:40 --> Language Class Initialized
INFO - 2020-02-04 04:55:40 --> Config Class Initialized
INFO - 2020-02-04 04:55:40 --> Loader Class Initialized
INFO - 2020-02-04 04:55:40 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:40 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:40 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:40 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:40 --> Controller Class Initialized
DEBUG - 2020-02-04 04:55:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:55:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:55:40 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:40 --> Total execution time: 0.3555
INFO - 2020-02-04 04:55:43 --> Config Class Initialized
INFO - 2020-02-04 04:55:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:43 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:43 --> URI Class Initialized
INFO - 2020-02-04 04:55:43 --> Router Class Initialized
INFO - 2020-02-04 04:55:43 --> Output Class Initialized
INFO - 2020-02-04 04:55:43 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:43 --> Input Class Initialized
INFO - 2020-02-04 04:55:43 --> Language Class Initialized
INFO - 2020-02-04 04:55:43 --> Language Class Initialized
INFO - 2020-02-04 04:55:43 --> Config Class Initialized
INFO - 2020-02-04 04:55:43 --> Loader Class Initialized
INFO - 2020-02-04 04:55:43 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:43 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:43 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:43 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:43 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:43 --> Controller Class Initialized
INFO - 2020-02-04 04:55:43 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:43 --> Total execution time: 0.3434
INFO - 2020-02-04 04:55:45 --> Config Class Initialized
INFO - 2020-02-04 04:55:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:45 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:45 --> URI Class Initialized
INFO - 2020-02-04 04:55:45 --> Router Class Initialized
INFO - 2020-02-04 04:55:45 --> Output Class Initialized
INFO - 2020-02-04 04:55:45 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:45 --> Input Class Initialized
INFO - 2020-02-04 04:55:45 --> Language Class Initialized
INFO - 2020-02-04 04:55:45 --> Language Class Initialized
INFO - 2020-02-04 04:55:45 --> Config Class Initialized
INFO - 2020-02-04 04:55:45 --> Loader Class Initialized
INFO - 2020-02-04 04:55:45 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:45 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:45 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:45 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:45 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:45 --> Controller Class Initialized
INFO - 2020-02-04 04:55:45 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:45 --> Total execution time: 0.3638
INFO - 2020-02-04 04:55:46 --> Config Class Initialized
INFO - 2020-02-04 04:55:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:46 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:46 --> URI Class Initialized
INFO - 2020-02-04 04:55:46 --> Router Class Initialized
INFO - 2020-02-04 04:55:46 --> Output Class Initialized
INFO - 2020-02-04 04:55:46 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:47 --> Input Class Initialized
INFO - 2020-02-04 04:55:47 --> Language Class Initialized
INFO - 2020-02-04 04:55:47 --> Language Class Initialized
INFO - 2020-02-04 04:55:47 --> Config Class Initialized
INFO - 2020-02-04 04:55:47 --> Loader Class Initialized
INFO - 2020-02-04 04:55:47 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:47 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:47 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:47 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:47 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:47 --> Controller Class Initialized
INFO - 2020-02-04 04:55:47 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:47 --> Total execution time: 0.3918
INFO - 2020-02-04 04:55:47 --> Config Class Initialized
INFO - 2020-02-04 04:55:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:47 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:47 --> URI Class Initialized
INFO - 2020-02-04 04:55:47 --> Router Class Initialized
INFO - 2020-02-04 04:55:47 --> Output Class Initialized
INFO - 2020-02-04 04:55:47 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:48 --> Input Class Initialized
INFO - 2020-02-04 04:55:48 --> Language Class Initialized
INFO - 2020-02-04 04:55:48 --> Language Class Initialized
INFO - 2020-02-04 04:55:48 --> Config Class Initialized
INFO - 2020-02-04 04:55:48 --> Loader Class Initialized
INFO - 2020-02-04 04:55:48 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:48 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:48 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:48 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:48 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:48 --> Controller Class Initialized
DEBUG - 2020-02-04 04:55:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:55:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:55:48 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:48 --> Total execution time: 0.4441
INFO - 2020-02-04 04:55:51 --> Config Class Initialized
INFO - 2020-02-04 04:55:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:51 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:51 --> URI Class Initialized
INFO - 2020-02-04 04:55:51 --> Router Class Initialized
INFO - 2020-02-04 04:55:51 --> Output Class Initialized
INFO - 2020-02-04 04:55:51 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:51 --> Input Class Initialized
INFO - 2020-02-04 04:55:51 --> Language Class Initialized
INFO - 2020-02-04 04:55:51 --> Language Class Initialized
INFO - 2020-02-04 04:55:51 --> Config Class Initialized
INFO - 2020-02-04 04:55:52 --> Loader Class Initialized
INFO - 2020-02-04 04:55:52 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:52 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:52 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:52 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:52 --> Controller Class Initialized
INFO - 2020-02-04 04:55:52 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:52 --> Total execution time: 0.3514
INFO - 2020-02-04 04:55:54 --> Config Class Initialized
INFO - 2020-02-04 04:55:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:54 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:54 --> URI Class Initialized
INFO - 2020-02-04 04:55:54 --> Router Class Initialized
INFO - 2020-02-04 04:55:54 --> Output Class Initialized
INFO - 2020-02-04 04:55:54 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:54 --> Input Class Initialized
INFO - 2020-02-04 04:55:54 --> Language Class Initialized
INFO - 2020-02-04 04:55:54 --> Language Class Initialized
INFO - 2020-02-04 04:55:54 --> Config Class Initialized
INFO - 2020-02-04 04:55:54 --> Loader Class Initialized
INFO - 2020-02-04 04:55:54 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:54 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:54 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:54 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:54 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:54 --> Controller Class Initialized
INFO - 2020-02-04 04:55:54 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:54 --> Total execution time: 0.3720
INFO - 2020-02-04 04:55:55 --> Config Class Initialized
INFO - 2020-02-04 04:55:55 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:55 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:55 --> URI Class Initialized
INFO - 2020-02-04 04:55:55 --> Router Class Initialized
INFO - 2020-02-04 04:55:55 --> Output Class Initialized
INFO - 2020-02-04 04:55:55 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:55 --> Input Class Initialized
INFO - 2020-02-04 04:55:55 --> Language Class Initialized
INFO - 2020-02-04 04:55:55 --> Language Class Initialized
INFO - 2020-02-04 04:55:55 --> Config Class Initialized
INFO - 2020-02-04 04:55:55 --> Loader Class Initialized
INFO - 2020-02-04 04:55:55 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:55 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:55 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:55 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:55 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:55 --> Controller Class Initialized
DEBUG - 2020-02-04 04:55:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:55:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:55:55 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:55 --> Total execution time: 0.3906
INFO - 2020-02-04 04:55:57 --> Config Class Initialized
INFO - 2020-02-04 04:55:57 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:55:57 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:55:57 --> Utf8 Class Initialized
INFO - 2020-02-04 04:55:57 --> URI Class Initialized
INFO - 2020-02-04 04:55:57 --> Router Class Initialized
INFO - 2020-02-04 04:55:57 --> Output Class Initialized
INFO - 2020-02-04 04:55:57 --> Security Class Initialized
DEBUG - 2020-02-04 04:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:55:57 --> Input Class Initialized
INFO - 2020-02-04 04:55:57 --> Language Class Initialized
INFO - 2020-02-04 04:55:57 --> Language Class Initialized
INFO - 2020-02-04 04:55:57 --> Config Class Initialized
INFO - 2020-02-04 04:55:58 --> Loader Class Initialized
INFO - 2020-02-04 04:55:58 --> Helper loaded: url_helper
INFO - 2020-02-04 04:55:58 --> Helper loaded: file_helper
INFO - 2020-02-04 04:55:58 --> Helper loaded: form_helper
INFO - 2020-02-04 04:55:58 --> Helper loaded: my_helper
INFO - 2020-02-04 04:55:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:55:58 --> Controller Class Initialized
INFO - 2020-02-04 04:55:58 --> Final output sent to browser
DEBUG - 2020-02-04 04:55:58 --> Total execution time: 0.3555
INFO - 2020-02-04 04:56:42 --> Config Class Initialized
INFO - 2020-02-04 04:56:42 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:56:42 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:56:42 --> Utf8 Class Initialized
INFO - 2020-02-04 04:56:42 --> URI Class Initialized
INFO - 2020-02-04 04:56:42 --> Router Class Initialized
INFO - 2020-02-04 04:56:42 --> Output Class Initialized
INFO - 2020-02-04 04:56:42 --> Security Class Initialized
DEBUG - 2020-02-04 04:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:56:42 --> Input Class Initialized
INFO - 2020-02-04 04:56:42 --> Language Class Initialized
INFO - 2020-02-04 04:56:42 --> Language Class Initialized
INFO - 2020-02-04 04:56:42 --> Config Class Initialized
INFO - 2020-02-04 04:56:42 --> Loader Class Initialized
INFO - 2020-02-04 04:56:42 --> Helper loaded: url_helper
INFO - 2020-02-04 04:56:42 --> Helper loaded: file_helper
INFO - 2020-02-04 04:56:42 --> Helper loaded: form_helper
INFO - 2020-02-04 04:56:42 --> Helper loaded: my_helper
INFO - 2020-02-04 04:56:42 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:56:42 --> Controller Class Initialized
DEBUG - 2020-02-04 04:56:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 04:56:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:56:42 --> Final output sent to browser
DEBUG - 2020-02-04 04:56:42 --> Total execution time: 0.3315
INFO - 2020-02-04 04:56:44 --> Config Class Initialized
INFO - 2020-02-04 04:56:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 04:56:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 04:56:44 --> Utf8 Class Initialized
INFO - 2020-02-04 04:56:44 --> URI Class Initialized
INFO - 2020-02-04 04:56:44 --> Router Class Initialized
INFO - 2020-02-04 04:56:44 --> Output Class Initialized
INFO - 2020-02-04 04:56:44 --> Security Class Initialized
DEBUG - 2020-02-04 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 04:56:44 --> Input Class Initialized
INFO - 2020-02-04 04:56:44 --> Language Class Initialized
INFO - 2020-02-04 04:56:44 --> Language Class Initialized
INFO - 2020-02-04 04:56:44 --> Config Class Initialized
INFO - 2020-02-04 04:56:44 --> Loader Class Initialized
INFO - 2020-02-04 04:56:44 --> Helper loaded: url_helper
INFO - 2020-02-04 04:56:44 --> Helper loaded: file_helper
INFO - 2020-02-04 04:56:44 --> Helper loaded: form_helper
INFO - 2020-02-04 04:56:44 --> Helper loaded: my_helper
INFO - 2020-02-04 04:56:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 04:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 04:56:44 --> Controller Class Initialized
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:44 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:45 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:46 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmsiswa E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
ERROR - 2020-02-04 04:56:47 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 43
DEBUG - 2020-02-04 04:56:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 04:56:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 04:56:47 --> Final output sent to browser
DEBUG - 2020-02-04 04:56:47 --> Total execution time: 3.0907
INFO - 2020-02-04 05:00:38 --> Config Class Initialized
INFO - 2020-02-04 05:00:38 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:00:38 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:00:38 --> Utf8 Class Initialized
INFO - 2020-02-04 05:00:38 --> URI Class Initialized
INFO - 2020-02-04 05:00:38 --> Router Class Initialized
INFO - 2020-02-04 05:00:38 --> Output Class Initialized
INFO - 2020-02-04 05:00:38 --> Security Class Initialized
DEBUG - 2020-02-04 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:00:38 --> Input Class Initialized
INFO - 2020-02-04 05:00:38 --> Language Class Initialized
INFO - 2020-02-04 05:00:38 --> Language Class Initialized
INFO - 2020-02-04 05:00:38 --> Config Class Initialized
INFO - 2020-02-04 05:00:38 --> Loader Class Initialized
INFO - 2020-02-04 05:00:38 --> Helper loaded: url_helper
INFO - 2020-02-04 05:00:38 --> Helper loaded: file_helper
INFO - 2020-02-04 05:00:38 --> Helper loaded: form_helper
INFO - 2020-02-04 05:00:38 --> Helper loaded: my_helper
INFO - 2020-02-04 05:00:38 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:00:38 --> Controller Class Initialized
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:38 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:39 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
ERROR - 2020-02-04 05:00:40 --> Severity: Notice --> Undefined index: nmkelas E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 50
DEBUG - 2020-02-04 05:00:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:00:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:00:40 --> Final output sent to browser
DEBUG - 2020-02-04 05:00:40 --> Total execution time: 2.0327
INFO - 2020-02-04 05:00:58 --> Config Class Initialized
INFO - 2020-02-04 05:00:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:00:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:00:58 --> Utf8 Class Initialized
INFO - 2020-02-04 05:00:58 --> URI Class Initialized
INFO - 2020-02-04 05:00:58 --> Router Class Initialized
INFO - 2020-02-04 05:00:58 --> Output Class Initialized
INFO - 2020-02-04 05:00:58 --> Security Class Initialized
DEBUG - 2020-02-04 05:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:00:58 --> Input Class Initialized
INFO - 2020-02-04 05:00:58 --> Language Class Initialized
INFO - 2020-02-04 05:00:58 --> Language Class Initialized
INFO - 2020-02-04 05:00:58 --> Config Class Initialized
INFO - 2020-02-04 05:00:58 --> Loader Class Initialized
INFO - 2020-02-04 05:00:58 --> Helper loaded: url_helper
INFO - 2020-02-04 05:00:58 --> Helper loaded: file_helper
INFO - 2020-02-04 05:00:58 --> Helper loaded: form_helper
INFO - 2020-02-04 05:00:58 --> Helper loaded: my_helper
INFO - 2020-02-04 05:00:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:00:58 --> Controller Class Initialized
DEBUG - 2020-02-04 05:00:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:00:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:00:58 --> Final output sent to browser
DEBUG - 2020-02-04 05:00:58 --> Total execution time: 0.4189
INFO - 2020-02-04 05:01:11 --> Config Class Initialized
INFO - 2020-02-04 05:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:12 --> URI Class Initialized
INFO - 2020-02-04 05:01:12 --> Router Class Initialized
INFO - 2020-02-04 05:01:12 --> Output Class Initialized
INFO - 2020-02-04 05:01:12 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:12 --> Input Class Initialized
INFO - 2020-02-04 05:01:12 --> Language Class Initialized
INFO - 2020-02-04 05:01:12 --> Language Class Initialized
INFO - 2020-02-04 05:01:12 --> Config Class Initialized
INFO - 2020-02-04 05:01:12 --> Loader Class Initialized
INFO - 2020-02-04 05:01:12 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:12 --> Controller Class Initialized
INFO - 2020-02-04 05:01:12 --> Config Class Initialized
INFO - 2020-02-04 05:01:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:12 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:12 --> URI Class Initialized
INFO - 2020-02-04 05:01:12 --> Router Class Initialized
INFO - 2020-02-04 05:01:12 --> Output Class Initialized
INFO - 2020-02-04 05:01:12 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:12 --> Input Class Initialized
INFO - 2020-02-04 05:01:12 --> Language Class Initialized
INFO - 2020-02-04 05:01:12 --> Language Class Initialized
INFO - 2020-02-04 05:01:12 --> Config Class Initialized
INFO - 2020-02-04 05:01:12 --> Loader Class Initialized
INFO - 2020-02-04 05:01:12 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:12 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:12 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 05:01:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:12 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:12 --> Total execution time: 0.3513
INFO - 2020-02-04 05:01:15 --> Config Class Initialized
INFO - 2020-02-04 05:01:15 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:15 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:15 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:15 --> URI Class Initialized
INFO - 2020-02-04 05:01:15 --> Router Class Initialized
INFO - 2020-02-04 05:01:15 --> Output Class Initialized
INFO - 2020-02-04 05:01:15 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:15 --> Input Class Initialized
INFO - 2020-02-04 05:01:15 --> Language Class Initialized
INFO - 2020-02-04 05:01:15 --> Language Class Initialized
INFO - 2020-02-04 05:01:15 --> Config Class Initialized
INFO - 2020-02-04 05:01:15 --> Loader Class Initialized
INFO - 2020-02-04 05:01:15 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:15 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:15 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:15 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:15 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:15 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:01:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:15 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:15 --> Total execution time: 0.4112
INFO - 2020-02-04 05:01:24 --> Config Class Initialized
INFO - 2020-02-04 05:01:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:24 --> URI Class Initialized
INFO - 2020-02-04 05:01:24 --> Router Class Initialized
INFO - 2020-02-04 05:01:24 --> Output Class Initialized
INFO - 2020-02-04 05:01:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:24 --> Input Class Initialized
INFO - 2020-02-04 05:01:24 --> Language Class Initialized
INFO - 2020-02-04 05:01:24 --> Language Class Initialized
INFO - 2020-02-04 05:01:24 --> Config Class Initialized
INFO - 2020-02-04 05:01:24 --> Loader Class Initialized
INFO - 2020-02-04 05:01:24 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:24 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:24 --> Controller Class Initialized
INFO - 2020-02-04 05:01:24 --> Config Class Initialized
INFO - 2020-02-04 05:01:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:24 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:24 --> URI Class Initialized
INFO - 2020-02-04 05:01:24 --> Router Class Initialized
INFO - 2020-02-04 05:01:24 --> Output Class Initialized
INFO - 2020-02-04 05:01:24 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:24 --> Input Class Initialized
INFO - 2020-02-04 05:01:24 --> Language Class Initialized
INFO - 2020-02-04 05:01:24 --> Language Class Initialized
INFO - 2020-02-04 05:01:24 --> Config Class Initialized
INFO - 2020-02-04 05:01:24 --> Loader Class Initialized
INFO - 2020-02-04 05:01:24 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:24 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:24 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:25 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 05:01:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:25 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:25 --> Total execution time: 0.3524
INFO - 2020-02-04 05:01:33 --> Config Class Initialized
INFO - 2020-02-04 05:01:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:33 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:33 --> URI Class Initialized
INFO - 2020-02-04 05:01:33 --> Router Class Initialized
INFO - 2020-02-04 05:01:33 --> Output Class Initialized
INFO - 2020-02-04 05:01:33 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:33 --> Input Class Initialized
INFO - 2020-02-04 05:01:33 --> Language Class Initialized
INFO - 2020-02-04 05:01:33 --> Language Class Initialized
INFO - 2020-02-04 05:01:33 --> Config Class Initialized
INFO - 2020-02-04 05:01:33 --> Loader Class Initialized
INFO - 2020-02-04 05:01:33 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:33 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:33 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:33 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:33 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:01:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:33 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:33 --> Total execution time: 0.3668
INFO - 2020-02-04 05:01:45 --> Config Class Initialized
INFO - 2020-02-04 05:01:45 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:45 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:45 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:45 --> URI Class Initialized
INFO - 2020-02-04 05:01:45 --> Router Class Initialized
INFO - 2020-02-04 05:01:46 --> Output Class Initialized
INFO - 2020-02-04 05:01:46 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:46 --> Input Class Initialized
INFO - 2020-02-04 05:01:46 --> Language Class Initialized
INFO - 2020-02-04 05:01:46 --> Language Class Initialized
INFO - 2020-02-04 05:01:46 --> Config Class Initialized
INFO - 2020-02-04 05:01:46 --> Loader Class Initialized
INFO - 2020-02-04 05:01:46 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:46 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:46 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-04 05:01:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:46 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:46 --> Total execution time: 0.3952
INFO - 2020-02-04 05:01:46 --> Config Class Initialized
INFO - 2020-02-04 05:01:46 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:46 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:46 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:46 --> URI Class Initialized
INFO - 2020-02-04 05:01:46 --> Router Class Initialized
INFO - 2020-02-04 05:01:46 --> Output Class Initialized
INFO - 2020-02-04 05:01:46 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:46 --> Input Class Initialized
INFO - 2020-02-04 05:01:46 --> Language Class Initialized
INFO - 2020-02-04 05:01:46 --> Language Class Initialized
INFO - 2020-02-04 05:01:46 --> Config Class Initialized
INFO - 2020-02-04 05:01:46 --> Loader Class Initialized
INFO - 2020-02-04 05:01:46 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:46 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:46 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:46 --> Controller Class Initialized
INFO - 2020-02-04 05:01:51 --> Config Class Initialized
INFO - 2020-02-04 05:01:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:51 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:51 --> URI Class Initialized
INFO - 2020-02-04 05:01:51 --> Router Class Initialized
INFO - 2020-02-04 05:01:51 --> Output Class Initialized
INFO - 2020-02-04 05:01:51 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:51 --> Input Class Initialized
INFO - 2020-02-04 05:01:51 --> Language Class Initialized
INFO - 2020-02-04 05:01:51 --> Language Class Initialized
INFO - 2020-02-04 05:01:51 --> Config Class Initialized
INFO - 2020-02-04 05:01:51 --> Loader Class Initialized
INFO - 2020-02-04 05:01:51 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:51 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:51 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:51 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:51 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:51 --> Controller Class Initialized
DEBUG - 2020-02-04 05:01:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-04 05:01:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:01:51 --> Final output sent to browser
DEBUG - 2020-02-04 05:01:51 --> Total execution time: 0.3463
INFO - 2020-02-04 05:01:51 --> Config Class Initialized
INFO - 2020-02-04 05:01:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:01:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:01:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:01:52 --> URI Class Initialized
INFO - 2020-02-04 05:01:52 --> Router Class Initialized
INFO - 2020-02-04 05:01:52 --> Output Class Initialized
INFO - 2020-02-04 05:01:52 --> Security Class Initialized
DEBUG - 2020-02-04 05:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:01:52 --> Input Class Initialized
INFO - 2020-02-04 05:01:52 --> Language Class Initialized
INFO - 2020-02-04 05:01:52 --> Language Class Initialized
INFO - 2020-02-04 05:01:52 --> Config Class Initialized
INFO - 2020-02-04 05:01:52 --> Loader Class Initialized
INFO - 2020-02-04 05:01:52 --> Helper loaded: url_helper
INFO - 2020-02-04 05:01:52 --> Helper loaded: file_helper
INFO - 2020-02-04 05:01:52 --> Helper loaded: form_helper
INFO - 2020-02-04 05:01:52 --> Helper loaded: my_helper
INFO - 2020-02-04 05:01:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:01:52 --> Controller Class Initialized
INFO - 2020-02-04 05:02:07 --> Config Class Initialized
INFO - 2020-02-04 05:02:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:02:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:02:07 --> Utf8 Class Initialized
INFO - 2020-02-04 05:02:07 --> URI Class Initialized
INFO - 2020-02-04 05:02:07 --> Router Class Initialized
INFO - 2020-02-04 05:02:07 --> Output Class Initialized
INFO - 2020-02-04 05:02:07 --> Security Class Initialized
DEBUG - 2020-02-04 05:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:02:07 --> Input Class Initialized
INFO - 2020-02-04 05:02:07 --> Language Class Initialized
INFO - 2020-02-04 05:02:07 --> Language Class Initialized
INFO - 2020-02-04 05:02:07 --> Config Class Initialized
INFO - 2020-02-04 05:02:07 --> Loader Class Initialized
INFO - 2020-02-04 05:02:07 --> Helper loaded: url_helper
INFO - 2020-02-04 05:02:07 --> Helper loaded: file_helper
INFO - 2020-02-04 05:02:07 --> Helper loaded: form_helper
INFO - 2020-02-04 05:02:07 --> Helper loaded: my_helper
INFO - 2020-02-04 05:02:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:02:08 --> Controller Class Initialized
DEBUG - 2020-02-04 05:02:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 05:02:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:02:08 --> Final output sent to browser
DEBUG - 2020-02-04 05:02:08 --> Total execution time: 0.3962
INFO - 2020-02-04 05:02:09 --> Config Class Initialized
INFO - 2020-02-04 05:02:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:02:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:02:09 --> Utf8 Class Initialized
INFO - 2020-02-04 05:02:09 --> URI Class Initialized
INFO - 2020-02-04 05:02:09 --> Router Class Initialized
INFO - 2020-02-04 05:02:09 --> Output Class Initialized
INFO - 2020-02-04 05:02:09 --> Security Class Initialized
DEBUG - 2020-02-04 05:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:02:09 --> Input Class Initialized
INFO - 2020-02-04 05:02:09 --> Language Class Initialized
INFO - 2020-02-04 05:02:09 --> Language Class Initialized
INFO - 2020-02-04 05:02:09 --> Config Class Initialized
INFO - 2020-02-04 05:02:09 --> Loader Class Initialized
INFO - 2020-02-04 05:02:09 --> Helper loaded: url_helper
INFO - 2020-02-04 05:02:09 --> Helper loaded: file_helper
INFO - 2020-02-04 05:02:09 --> Helper loaded: form_helper
INFO - 2020-02-04 05:02:09 --> Helper loaded: my_helper
INFO - 2020-02-04 05:02:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:02:09 --> Controller Class Initialized
DEBUG - 2020-02-04 05:02:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:02:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:02:09 --> Final output sent to browser
DEBUG - 2020-02-04 05:02:09 --> Total execution time: 0.3951
INFO - 2020-02-04 05:02:26 --> Config Class Initialized
INFO - 2020-02-04 05:02:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:02:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:02:26 --> Utf8 Class Initialized
INFO - 2020-02-04 05:02:26 --> URI Class Initialized
INFO - 2020-02-04 05:02:26 --> Router Class Initialized
INFO - 2020-02-04 05:02:26 --> Output Class Initialized
INFO - 2020-02-04 05:02:26 --> Security Class Initialized
DEBUG - 2020-02-04 05:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:02:26 --> Input Class Initialized
INFO - 2020-02-04 05:02:26 --> Language Class Initialized
INFO - 2020-02-04 05:02:26 --> Language Class Initialized
INFO - 2020-02-04 05:02:27 --> Config Class Initialized
INFO - 2020-02-04 05:02:27 --> Loader Class Initialized
INFO - 2020-02-04 05:02:27 --> Helper loaded: url_helper
INFO - 2020-02-04 05:02:27 --> Helper loaded: file_helper
INFO - 2020-02-04 05:02:27 --> Helper loaded: form_helper
INFO - 2020-02-04 05:02:27 --> Helper loaded: my_helper
INFO - 2020-02-04 05:02:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:02:27 --> Controller Class Initialized
DEBUG - 2020-02-04 05:02:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:02:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:02:27 --> Final output sent to browser
DEBUG - 2020-02-04 05:02:27 --> Total execution time: 0.3715
INFO - 2020-02-04 05:02:37 --> Config Class Initialized
INFO - 2020-02-04 05:02:37 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:02:37 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:02:37 --> Utf8 Class Initialized
INFO - 2020-02-04 05:02:37 --> URI Class Initialized
INFO - 2020-02-04 05:02:37 --> Router Class Initialized
INFO - 2020-02-04 05:02:37 --> Output Class Initialized
INFO - 2020-02-04 05:02:37 --> Security Class Initialized
DEBUG - 2020-02-04 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:02:37 --> Input Class Initialized
INFO - 2020-02-04 05:02:37 --> Language Class Initialized
INFO - 2020-02-04 05:02:37 --> Language Class Initialized
INFO - 2020-02-04 05:02:37 --> Config Class Initialized
INFO - 2020-02-04 05:02:37 --> Loader Class Initialized
INFO - 2020-02-04 05:02:37 --> Helper loaded: url_helper
INFO - 2020-02-04 05:02:37 --> Helper loaded: file_helper
INFO - 2020-02-04 05:02:37 --> Helper loaded: form_helper
INFO - 2020-02-04 05:02:37 --> Helper loaded: my_helper
INFO - 2020-02-04 05:02:37 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:02:37 --> Controller Class Initialized
DEBUG - 2020-02-04 05:02:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:02:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:02:37 --> Final output sent to browser
DEBUG - 2020-02-04 05:02:38 --> Total execution time: 0.3747
INFO - 2020-02-04 05:02:54 --> Config Class Initialized
INFO - 2020-02-04 05:02:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:02:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:02:54 --> Utf8 Class Initialized
INFO - 2020-02-04 05:02:54 --> URI Class Initialized
INFO - 2020-02-04 05:02:54 --> Router Class Initialized
INFO - 2020-02-04 05:02:54 --> Output Class Initialized
INFO - 2020-02-04 05:02:54 --> Security Class Initialized
DEBUG - 2020-02-04 05:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:02:55 --> Input Class Initialized
INFO - 2020-02-04 05:02:55 --> Language Class Initialized
INFO - 2020-02-04 05:02:55 --> Language Class Initialized
INFO - 2020-02-04 05:02:55 --> Config Class Initialized
INFO - 2020-02-04 05:02:55 --> Loader Class Initialized
INFO - 2020-02-04 05:02:55 --> Helper loaded: url_helper
INFO - 2020-02-04 05:02:55 --> Helper loaded: file_helper
INFO - 2020-02-04 05:02:55 --> Helper loaded: form_helper
INFO - 2020-02-04 05:02:55 --> Helper loaded: my_helper
INFO - 2020-02-04 05:02:55 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:02:55 --> Controller Class Initialized
DEBUG - 2020-02-04 05:02:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:02:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:02:55 --> Final output sent to browser
DEBUG - 2020-02-04 05:02:55 --> Total execution time: 0.3631
INFO - 2020-02-04 05:03:10 --> Config Class Initialized
INFO - 2020-02-04 05:03:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:03:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:03:10 --> Utf8 Class Initialized
INFO - 2020-02-04 05:03:11 --> URI Class Initialized
INFO - 2020-02-04 05:03:11 --> Router Class Initialized
INFO - 2020-02-04 05:03:11 --> Output Class Initialized
INFO - 2020-02-04 05:03:11 --> Security Class Initialized
DEBUG - 2020-02-04 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:03:11 --> Input Class Initialized
INFO - 2020-02-04 05:03:11 --> Language Class Initialized
INFO - 2020-02-04 05:03:11 --> Language Class Initialized
INFO - 2020-02-04 05:03:11 --> Config Class Initialized
INFO - 2020-02-04 05:03:11 --> Loader Class Initialized
INFO - 2020-02-04 05:03:11 --> Helper loaded: url_helper
INFO - 2020-02-04 05:03:11 --> Helper loaded: file_helper
INFO - 2020-02-04 05:03:11 --> Helper loaded: form_helper
INFO - 2020-02-04 05:03:11 --> Helper loaded: my_helper
INFO - 2020-02-04 05:03:11 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:03:11 --> Controller Class Initialized
DEBUG - 2020-02-04 05:03:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:03:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:03:11 --> Final output sent to browser
DEBUG - 2020-02-04 05:03:11 --> Total execution time: 0.3711
INFO - 2020-02-04 05:03:18 --> Config Class Initialized
INFO - 2020-02-04 05:03:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:03:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:03:18 --> Utf8 Class Initialized
INFO - 2020-02-04 05:03:18 --> URI Class Initialized
INFO - 2020-02-04 05:03:18 --> Router Class Initialized
INFO - 2020-02-04 05:03:18 --> Output Class Initialized
INFO - 2020-02-04 05:03:18 --> Security Class Initialized
DEBUG - 2020-02-04 05:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:03:18 --> Input Class Initialized
INFO - 2020-02-04 05:03:18 --> Language Class Initialized
INFO - 2020-02-04 05:03:18 --> Language Class Initialized
INFO - 2020-02-04 05:03:18 --> Config Class Initialized
INFO - 2020-02-04 05:03:18 --> Loader Class Initialized
INFO - 2020-02-04 05:03:18 --> Helper loaded: url_helper
INFO - 2020-02-04 05:03:18 --> Helper loaded: file_helper
INFO - 2020-02-04 05:03:18 --> Helper loaded: form_helper
INFO - 2020-02-04 05:03:18 --> Helper loaded: my_helper
INFO - 2020-02-04 05:03:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:03:18 --> Controller Class Initialized
DEBUG - 2020-02-04 05:03:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:03:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:03:18 --> Final output sent to browser
DEBUG - 2020-02-04 05:03:18 --> Total execution time: 0.3617
INFO - 2020-02-04 05:03:30 --> Config Class Initialized
INFO - 2020-02-04 05:03:30 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:03:30 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:03:30 --> Utf8 Class Initialized
INFO - 2020-02-04 05:03:30 --> URI Class Initialized
INFO - 2020-02-04 05:03:30 --> Router Class Initialized
INFO - 2020-02-04 05:03:31 --> Output Class Initialized
INFO - 2020-02-04 05:03:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:03:31 --> Input Class Initialized
INFO - 2020-02-04 05:03:31 --> Language Class Initialized
INFO - 2020-02-04 05:03:31 --> Language Class Initialized
INFO - 2020-02-04 05:03:31 --> Config Class Initialized
INFO - 2020-02-04 05:03:31 --> Loader Class Initialized
INFO - 2020-02-04 05:03:31 --> Helper loaded: url_helper
INFO - 2020-02-04 05:03:31 --> Helper loaded: file_helper
INFO - 2020-02-04 05:03:31 --> Helper loaded: form_helper
INFO - 2020-02-04 05:03:31 --> Helper loaded: my_helper
INFO - 2020-02-04 05:03:31 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:03:31 --> Controller Class Initialized
DEBUG - 2020-02-04 05:03:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:03:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:03:31 --> Final output sent to browser
DEBUG - 2020-02-04 05:03:31 --> Total execution time: 0.3754
INFO - 2020-02-04 05:03:43 --> Config Class Initialized
INFO - 2020-02-04 05:03:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:03:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:03:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:03:43 --> URI Class Initialized
INFO - 2020-02-04 05:03:43 --> Router Class Initialized
INFO - 2020-02-04 05:03:43 --> Output Class Initialized
INFO - 2020-02-04 05:03:43 --> Security Class Initialized
DEBUG - 2020-02-04 05:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:03:43 --> Input Class Initialized
INFO - 2020-02-04 05:03:43 --> Language Class Initialized
INFO - 2020-02-04 05:03:43 --> Language Class Initialized
INFO - 2020-02-04 05:03:43 --> Config Class Initialized
INFO - 2020-02-04 05:03:43 --> Loader Class Initialized
INFO - 2020-02-04 05:03:43 --> Helper loaded: url_helper
INFO - 2020-02-04 05:03:44 --> Helper loaded: file_helper
INFO - 2020-02-04 05:03:44 --> Helper loaded: form_helper
INFO - 2020-02-04 05:03:44 --> Helper loaded: my_helper
INFO - 2020-02-04 05:03:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:03:44 --> Controller Class Initialized
DEBUG - 2020-02-04 05:03:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:03:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:03:44 --> Final output sent to browser
DEBUG - 2020-02-04 05:03:44 --> Total execution time: 0.3690
INFO - 2020-02-04 05:03:56 --> Config Class Initialized
INFO - 2020-02-04 05:03:56 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:03:56 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:03:56 --> Utf8 Class Initialized
INFO - 2020-02-04 05:03:56 --> URI Class Initialized
INFO - 2020-02-04 05:03:56 --> Router Class Initialized
INFO - 2020-02-04 05:03:56 --> Output Class Initialized
INFO - 2020-02-04 05:03:56 --> Security Class Initialized
DEBUG - 2020-02-04 05:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:03:56 --> Input Class Initialized
INFO - 2020-02-04 05:03:56 --> Language Class Initialized
INFO - 2020-02-04 05:03:56 --> Language Class Initialized
INFO - 2020-02-04 05:03:56 --> Config Class Initialized
INFO - 2020-02-04 05:03:56 --> Loader Class Initialized
INFO - 2020-02-04 05:03:56 --> Helper loaded: url_helper
INFO - 2020-02-04 05:03:56 --> Helper loaded: file_helper
INFO - 2020-02-04 05:03:56 --> Helper loaded: form_helper
INFO - 2020-02-04 05:03:56 --> Helper loaded: my_helper
INFO - 2020-02-04 05:03:56 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:03:56 --> Controller Class Initialized
DEBUG - 2020-02-04 05:03:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:03:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:03:56 --> Final output sent to browser
DEBUG - 2020-02-04 05:03:56 --> Total execution time: 0.3754
INFO - 2020-02-04 05:04:06 --> Config Class Initialized
INFO - 2020-02-04 05:04:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:04:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:04:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:04:06 --> URI Class Initialized
INFO - 2020-02-04 05:04:06 --> Router Class Initialized
INFO - 2020-02-04 05:04:06 --> Output Class Initialized
INFO - 2020-02-04 05:04:06 --> Security Class Initialized
DEBUG - 2020-02-04 05:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:04:06 --> Input Class Initialized
INFO - 2020-02-04 05:04:06 --> Language Class Initialized
INFO - 2020-02-04 05:04:06 --> Language Class Initialized
INFO - 2020-02-04 05:04:06 --> Config Class Initialized
INFO - 2020-02-04 05:04:06 --> Loader Class Initialized
INFO - 2020-02-04 05:04:06 --> Helper loaded: url_helper
INFO - 2020-02-04 05:04:06 --> Helper loaded: file_helper
INFO - 2020-02-04 05:04:06 --> Helper loaded: form_helper
INFO - 2020-02-04 05:04:06 --> Helper loaded: my_helper
INFO - 2020-02-04 05:04:06 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:04:06 --> Controller Class Initialized
DEBUG - 2020-02-04 05:04:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:04:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:04:06 --> Final output sent to browser
DEBUG - 2020-02-04 05:04:06 --> Total execution time: 0.3776
INFO - 2020-02-04 05:04:27 --> Config Class Initialized
INFO - 2020-02-04 05:04:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:04:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:04:27 --> Utf8 Class Initialized
INFO - 2020-02-04 05:04:27 --> URI Class Initialized
INFO - 2020-02-04 05:04:27 --> Router Class Initialized
INFO - 2020-02-04 05:04:27 --> Output Class Initialized
INFO - 2020-02-04 05:04:27 --> Security Class Initialized
DEBUG - 2020-02-04 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:04:27 --> Input Class Initialized
INFO - 2020-02-04 05:04:27 --> Language Class Initialized
INFO - 2020-02-04 05:04:27 --> Language Class Initialized
INFO - 2020-02-04 05:04:27 --> Config Class Initialized
INFO - 2020-02-04 05:04:27 --> Loader Class Initialized
INFO - 2020-02-04 05:04:27 --> Helper loaded: url_helper
INFO - 2020-02-04 05:04:27 --> Helper loaded: file_helper
INFO - 2020-02-04 05:04:27 --> Helper loaded: form_helper
INFO - 2020-02-04 05:04:27 --> Helper loaded: my_helper
INFO - 2020-02-04 05:04:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:04:27 --> Controller Class Initialized
DEBUG - 2020-02-04 05:04:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:04:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:04:27 --> Final output sent to browser
DEBUG - 2020-02-04 05:04:27 --> Total execution time: 0.3723
INFO - 2020-02-04 05:04:38 --> Config Class Initialized
INFO - 2020-02-04 05:04:38 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:04:38 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:04:38 --> Utf8 Class Initialized
INFO - 2020-02-04 05:04:38 --> URI Class Initialized
INFO - 2020-02-04 05:04:38 --> Router Class Initialized
INFO - 2020-02-04 05:04:38 --> Output Class Initialized
INFO - 2020-02-04 05:04:38 --> Security Class Initialized
DEBUG - 2020-02-04 05:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:04:38 --> Input Class Initialized
INFO - 2020-02-04 05:04:38 --> Language Class Initialized
INFO - 2020-02-04 05:04:38 --> Language Class Initialized
INFO - 2020-02-04 05:04:38 --> Config Class Initialized
INFO - 2020-02-04 05:04:38 --> Loader Class Initialized
INFO - 2020-02-04 05:04:38 --> Helper loaded: url_helper
INFO - 2020-02-04 05:04:38 --> Helper loaded: file_helper
INFO - 2020-02-04 05:04:38 --> Helper loaded: form_helper
INFO - 2020-02-04 05:04:38 --> Helper loaded: my_helper
INFO - 2020-02-04 05:04:38 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:04:38 --> Controller Class Initialized
DEBUG - 2020-02-04 05:04:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 05:04:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:04:39 --> Final output sent to browser
DEBUG - 2020-02-04 05:04:39 --> Total execution time: 0.3863
INFO - 2020-02-04 05:04:41 --> Config Class Initialized
INFO - 2020-02-04 05:04:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:04:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:04:41 --> Utf8 Class Initialized
INFO - 2020-02-04 05:04:41 --> URI Class Initialized
INFO - 2020-02-04 05:04:41 --> Router Class Initialized
INFO - 2020-02-04 05:04:41 --> Output Class Initialized
INFO - 2020-02-04 05:04:41 --> Security Class Initialized
DEBUG - 2020-02-04 05:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:04:41 --> Input Class Initialized
INFO - 2020-02-04 05:04:41 --> Language Class Initialized
INFO - 2020-02-04 05:04:41 --> Language Class Initialized
INFO - 2020-02-04 05:04:41 --> Config Class Initialized
INFO - 2020-02-04 05:04:41 --> Loader Class Initialized
INFO - 2020-02-04 05:04:41 --> Helper loaded: url_helper
INFO - 2020-02-04 05:04:41 --> Helper loaded: file_helper
INFO - 2020-02-04 05:04:41 --> Helper loaded: form_helper
INFO - 2020-02-04 05:04:41 --> Helper loaded: my_helper
INFO - 2020-02-04 05:04:41 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:04:41 --> Controller Class Initialized
INFO - 2020-02-04 05:04:41 --> Final output sent to browser
DEBUG - 2020-02-04 05:04:41 --> Total execution time: 0.3698
INFO - 2020-02-04 05:04:43 --> Config Class Initialized
INFO - 2020-02-04 05:04:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:04:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:04:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:04:43 --> URI Class Initialized
INFO - 2020-02-04 05:04:43 --> Router Class Initialized
INFO - 2020-02-04 05:04:43 --> Output Class Initialized
INFO - 2020-02-04 05:04:43 --> Security Class Initialized
DEBUG - 2020-02-04 05:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:04:43 --> Input Class Initialized
INFO - 2020-02-04 05:04:43 --> Language Class Initialized
INFO - 2020-02-04 05:04:43 --> Language Class Initialized
INFO - 2020-02-04 05:04:43 --> Config Class Initialized
INFO - 2020-02-04 05:04:43 --> Loader Class Initialized
INFO - 2020-02-04 05:04:43 --> Helper loaded: url_helper
INFO - 2020-02-04 05:04:43 --> Helper loaded: file_helper
INFO - 2020-02-04 05:04:43 --> Helper loaded: form_helper
INFO - 2020-02-04 05:04:43 --> Helper loaded: my_helper
INFO - 2020-02-04 05:04:43 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:04:43 --> Controller Class Initialized
DEBUG - 2020-02-04 05:04:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:04:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:04:43 --> Final output sent to browser
DEBUG - 2020-02-04 05:04:43 --> Total execution time: 0.3796
INFO - 2020-02-04 05:05:04 --> Config Class Initialized
INFO - 2020-02-04 05:05:04 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:05:04 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:05:04 --> Utf8 Class Initialized
INFO - 2020-02-04 05:05:04 --> URI Class Initialized
INFO - 2020-02-04 05:05:04 --> Router Class Initialized
INFO - 2020-02-04 05:05:04 --> Output Class Initialized
INFO - 2020-02-04 05:05:04 --> Security Class Initialized
DEBUG - 2020-02-04 05:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:05:04 --> Input Class Initialized
INFO - 2020-02-04 05:05:04 --> Language Class Initialized
INFO - 2020-02-04 05:05:04 --> Language Class Initialized
INFO - 2020-02-04 05:05:04 --> Config Class Initialized
INFO - 2020-02-04 05:05:04 --> Loader Class Initialized
INFO - 2020-02-04 05:05:04 --> Helper loaded: url_helper
INFO - 2020-02-04 05:05:04 --> Helper loaded: file_helper
INFO - 2020-02-04 05:05:04 --> Helper loaded: form_helper
INFO - 2020-02-04 05:05:04 --> Helper loaded: my_helper
INFO - 2020-02-04 05:05:04 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:05:04 --> Controller Class Initialized
DEBUG - 2020-02-04 05:05:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:05:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:05:04 --> Final output sent to browser
DEBUG - 2020-02-04 05:05:04 --> Total execution time: 0.3757
INFO - 2020-02-04 05:05:28 --> Config Class Initialized
INFO - 2020-02-04 05:05:28 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:05:28 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:05:28 --> Utf8 Class Initialized
INFO - 2020-02-04 05:05:28 --> URI Class Initialized
INFO - 2020-02-04 05:05:28 --> Router Class Initialized
INFO - 2020-02-04 05:05:28 --> Output Class Initialized
INFO - 2020-02-04 05:05:28 --> Security Class Initialized
DEBUG - 2020-02-04 05:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:05:28 --> Input Class Initialized
INFO - 2020-02-04 05:05:28 --> Language Class Initialized
INFO - 2020-02-04 05:05:28 --> Language Class Initialized
INFO - 2020-02-04 05:05:28 --> Config Class Initialized
INFO - 2020-02-04 05:05:28 --> Loader Class Initialized
INFO - 2020-02-04 05:05:28 --> Helper loaded: url_helper
INFO - 2020-02-04 05:05:28 --> Helper loaded: file_helper
INFO - 2020-02-04 05:05:28 --> Helper loaded: form_helper
INFO - 2020-02-04 05:05:28 --> Helper loaded: my_helper
INFO - 2020-02-04 05:05:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:05:28 --> Controller Class Initialized
DEBUG - 2020-02-04 05:05:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:05:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:05:28 --> Final output sent to browser
DEBUG - 2020-02-04 05:05:28 --> Total execution time: 0.3558
INFO - 2020-02-04 05:05:50 --> Config Class Initialized
INFO - 2020-02-04 05:05:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:05:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:05:50 --> Utf8 Class Initialized
INFO - 2020-02-04 05:05:50 --> URI Class Initialized
INFO - 2020-02-04 05:05:50 --> Router Class Initialized
INFO - 2020-02-04 05:05:50 --> Output Class Initialized
INFO - 2020-02-04 05:05:50 --> Security Class Initialized
DEBUG - 2020-02-04 05:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:05:50 --> Input Class Initialized
INFO - 2020-02-04 05:05:50 --> Language Class Initialized
INFO - 2020-02-04 05:05:50 --> Language Class Initialized
INFO - 2020-02-04 05:05:50 --> Config Class Initialized
INFO - 2020-02-04 05:05:50 --> Loader Class Initialized
INFO - 2020-02-04 05:05:50 --> Helper loaded: url_helper
INFO - 2020-02-04 05:05:50 --> Helper loaded: file_helper
INFO - 2020-02-04 05:05:50 --> Helper loaded: form_helper
INFO - 2020-02-04 05:05:50 --> Helper loaded: my_helper
INFO - 2020-02-04 05:05:50 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:05:50 --> Controller Class Initialized
DEBUG - 2020-02-04 05:05:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:05:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:05:50 --> Final output sent to browser
DEBUG - 2020-02-04 05:05:50 --> Total execution time: 0.3802
INFO - 2020-02-04 05:06:06 --> Config Class Initialized
INFO - 2020-02-04 05:06:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:06:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:06:06 --> Utf8 Class Initialized
INFO - 2020-02-04 05:06:06 --> URI Class Initialized
INFO - 2020-02-04 05:06:06 --> Router Class Initialized
INFO - 2020-02-04 05:06:06 --> Output Class Initialized
INFO - 2020-02-04 05:06:06 --> Security Class Initialized
DEBUG - 2020-02-04 05:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:06:06 --> Input Class Initialized
INFO - 2020-02-04 05:06:06 --> Language Class Initialized
INFO - 2020-02-04 05:06:06 --> Language Class Initialized
INFO - 2020-02-04 05:06:06 --> Config Class Initialized
INFO - 2020-02-04 05:06:06 --> Loader Class Initialized
INFO - 2020-02-04 05:06:06 --> Helper loaded: url_helper
INFO - 2020-02-04 05:06:06 --> Helper loaded: file_helper
INFO - 2020-02-04 05:06:06 --> Helper loaded: form_helper
INFO - 2020-02-04 05:06:06 --> Helper loaded: my_helper
INFO - 2020-02-04 05:06:06 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:06:06 --> Controller Class Initialized
DEBUG - 2020-02-04 05:06:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:06:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:06:07 --> Final output sent to browser
DEBUG - 2020-02-04 05:06:07 --> Total execution time: 0.3890
INFO - 2020-02-04 05:06:16 --> Config Class Initialized
INFO - 2020-02-04 05:06:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:06:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:06:16 --> Utf8 Class Initialized
INFO - 2020-02-04 05:06:16 --> URI Class Initialized
INFO - 2020-02-04 05:06:16 --> Router Class Initialized
INFO - 2020-02-04 05:06:16 --> Output Class Initialized
INFO - 2020-02-04 05:06:16 --> Security Class Initialized
DEBUG - 2020-02-04 05:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:06:16 --> Input Class Initialized
INFO - 2020-02-04 05:06:16 --> Language Class Initialized
INFO - 2020-02-04 05:06:16 --> Language Class Initialized
INFO - 2020-02-04 05:06:16 --> Config Class Initialized
INFO - 2020-02-04 05:06:16 --> Loader Class Initialized
INFO - 2020-02-04 05:06:16 --> Helper loaded: url_helper
INFO - 2020-02-04 05:06:16 --> Helper loaded: file_helper
INFO - 2020-02-04 05:06:16 --> Helper loaded: form_helper
INFO - 2020-02-04 05:06:16 --> Helper loaded: my_helper
INFO - 2020-02-04 05:06:16 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:06:17 --> Controller Class Initialized
DEBUG - 2020-02-04 05:06:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-04 05:06:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:06:17 --> Final output sent to browser
DEBUG - 2020-02-04 05:06:17 --> Total execution time: 0.3786
INFO - 2020-02-04 05:21:30 --> Config Class Initialized
INFO - 2020-02-04 05:21:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:31 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:31 --> URI Class Initialized
DEBUG - 2020-02-04 05:21:31 --> No URI present. Default controller set.
INFO - 2020-02-04 05:21:31 --> Router Class Initialized
INFO - 2020-02-04 05:21:31 --> Output Class Initialized
INFO - 2020-02-04 05:21:31 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:31 --> Input Class Initialized
INFO - 2020-02-04 05:21:31 --> Language Class Initialized
INFO - 2020-02-04 05:21:31 --> Language Class Initialized
INFO - 2020-02-04 05:21:31 --> Config Class Initialized
INFO - 2020-02-04 05:21:31 --> Loader Class Initialized
INFO - 2020-02-04 05:21:31 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:31 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:31 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:31 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:31 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:31 --> Controller Class Initialized
DEBUG - 2020-02-04 05:21:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-04 05:21:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:21:31 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:31 --> Total execution time: 0.6915
INFO - 2020-02-04 05:21:43 --> Config Class Initialized
INFO - 2020-02-04 05:21:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:43 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:43 --> URI Class Initialized
INFO - 2020-02-04 05:21:43 --> Router Class Initialized
INFO - 2020-02-04 05:21:43 --> Output Class Initialized
INFO - 2020-02-04 05:21:44 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:44 --> Input Class Initialized
INFO - 2020-02-04 05:21:44 --> Language Class Initialized
INFO - 2020-02-04 05:21:44 --> Language Class Initialized
INFO - 2020-02-04 05:21:44 --> Config Class Initialized
INFO - 2020-02-04 05:21:44 --> Loader Class Initialized
INFO - 2020-02-04 05:21:44 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:44 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:44 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:44 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:44 --> Controller Class Initialized
DEBUG - 2020-02-04 05:21:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-04 05:21:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:21:44 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:44 --> Total execution time: 0.4727
INFO - 2020-02-04 05:21:44 --> Config Class Initialized
INFO - 2020-02-04 05:21:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:44 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:44 --> URI Class Initialized
INFO - 2020-02-04 05:21:44 --> Router Class Initialized
INFO - 2020-02-04 05:21:44 --> Output Class Initialized
INFO - 2020-02-04 05:21:44 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:44 --> Input Class Initialized
INFO - 2020-02-04 05:21:44 --> Language Class Initialized
INFO - 2020-02-04 05:21:44 --> Language Class Initialized
INFO - 2020-02-04 05:21:44 --> Config Class Initialized
INFO - 2020-02-04 05:21:44 --> Loader Class Initialized
INFO - 2020-02-04 05:21:44 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:44 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:44 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:45 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:45 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:45 --> Controller Class Initialized
INFO - 2020-02-04 05:21:47 --> Config Class Initialized
INFO - 2020-02-04 05:21:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:47 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:47 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:47 --> URI Class Initialized
INFO - 2020-02-04 05:21:47 --> Router Class Initialized
INFO - 2020-02-04 05:21:47 --> Output Class Initialized
INFO - 2020-02-04 05:21:47 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:47 --> Input Class Initialized
INFO - 2020-02-04 05:21:47 --> Language Class Initialized
INFO - 2020-02-04 05:21:47 --> Language Class Initialized
INFO - 2020-02-04 05:21:47 --> Config Class Initialized
INFO - 2020-02-04 05:21:47 --> Loader Class Initialized
INFO - 2020-02-04 05:21:47 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:47 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:47 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:47 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:47 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:47 --> Controller Class Initialized
INFO - 2020-02-04 05:21:47 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:47 --> Total execution time: 0.5913
INFO - 2020-02-04 05:21:47 --> Config Class Initialized
INFO - 2020-02-04 05:21:47 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:48 --> URI Class Initialized
INFO - 2020-02-04 05:21:48 --> Router Class Initialized
INFO - 2020-02-04 05:21:48 --> Output Class Initialized
INFO - 2020-02-04 05:21:48 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:48 --> Input Class Initialized
INFO - 2020-02-04 05:21:48 --> Language Class Initialized
INFO - 2020-02-04 05:21:48 --> Language Class Initialized
INFO - 2020-02-04 05:21:48 --> Config Class Initialized
INFO - 2020-02-04 05:21:48 --> Loader Class Initialized
INFO - 2020-02-04 05:21:48 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:48 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:48 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:48 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:48 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:48 --> Controller Class Initialized
INFO - 2020-02-04 05:21:48 --> Config Class Initialized
INFO - 2020-02-04 05:21:48 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:48 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:48 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:48 --> URI Class Initialized
DEBUG - 2020-02-04 05:21:49 --> No URI present. Default controller set.
INFO - 2020-02-04 05:21:49 --> Router Class Initialized
INFO - 2020-02-04 05:21:49 --> Output Class Initialized
INFO - 2020-02-04 05:21:49 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:49 --> Input Class Initialized
INFO - 2020-02-04 05:21:49 --> Language Class Initialized
INFO - 2020-02-04 05:21:49 --> Language Class Initialized
INFO - 2020-02-04 05:21:49 --> Config Class Initialized
INFO - 2020-02-04 05:21:49 --> Loader Class Initialized
INFO - 2020-02-04 05:21:49 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:49 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:49 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:49 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:49 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:49 --> Controller Class Initialized
DEBUG - 2020-02-04 05:21:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-04 05:21:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:21:49 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:49 --> Total execution time: 0.6064
INFO - 2020-02-04 05:21:51 --> Config Class Initialized
INFO - 2020-02-04 05:21:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:52 --> URI Class Initialized
INFO - 2020-02-04 05:21:52 --> Router Class Initialized
INFO - 2020-02-04 05:21:52 --> Output Class Initialized
INFO - 2020-02-04 05:21:52 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:52 --> Input Class Initialized
INFO - 2020-02-04 05:21:52 --> Language Class Initialized
INFO - 2020-02-04 05:21:52 --> Language Class Initialized
INFO - 2020-02-04 05:21:52 --> Config Class Initialized
INFO - 2020-02-04 05:21:52 --> Loader Class Initialized
INFO - 2020-02-04 05:21:52 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:52 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:52 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:52 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:52 --> Controller Class Initialized
DEBUG - 2020-02-04 05:21:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-04 05:21:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:21:52 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:52 --> Total execution time: 0.5085
INFO - 2020-02-04 05:21:52 --> Config Class Initialized
INFO - 2020-02-04 05:21:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:52 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:52 --> URI Class Initialized
INFO - 2020-02-04 05:21:52 --> Router Class Initialized
INFO - 2020-02-04 05:21:52 --> Output Class Initialized
INFO - 2020-02-04 05:21:52 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:52 --> Input Class Initialized
INFO - 2020-02-04 05:21:53 --> Language Class Initialized
INFO - 2020-02-04 05:21:53 --> Language Class Initialized
INFO - 2020-02-04 05:21:53 --> Config Class Initialized
INFO - 2020-02-04 05:21:53 --> Loader Class Initialized
INFO - 2020-02-04 05:21:53 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:53 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:53 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:53 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:53 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:53 --> Controller Class Initialized
INFO - 2020-02-04 05:21:54 --> Config Class Initialized
INFO - 2020-02-04 05:21:54 --> Hooks Class Initialized
DEBUG - 2020-02-04 05:21:54 --> UTF-8 Support Enabled
INFO - 2020-02-04 05:21:54 --> Utf8 Class Initialized
INFO - 2020-02-04 05:21:54 --> URI Class Initialized
INFO - 2020-02-04 05:21:54 --> Router Class Initialized
INFO - 2020-02-04 05:21:54 --> Output Class Initialized
INFO - 2020-02-04 05:21:54 --> Security Class Initialized
DEBUG - 2020-02-04 05:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 05:21:54 --> Input Class Initialized
INFO - 2020-02-04 05:21:54 --> Language Class Initialized
INFO - 2020-02-04 05:21:54 --> Language Class Initialized
INFO - 2020-02-04 05:21:54 --> Config Class Initialized
INFO - 2020-02-04 05:21:54 --> Loader Class Initialized
INFO - 2020-02-04 05:21:54 --> Helper loaded: url_helper
INFO - 2020-02-04 05:21:54 --> Helper loaded: file_helper
INFO - 2020-02-04 05:21:54 --> Helper loaded: form_helper
INFO - 2020-02-04 05:21:55 --> Helper loaded: my_helper
INFO - 2020-02-04 05:21:55 --> Database Driver Class Initialized
DEBUG - 2020-02-04 05:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 05:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 05:21:55 --> Controller Class Initialized
DEBUG - 2020-02-04 05:21:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 05:21:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 05:21:55 --> Final output sent to browser
DEBUG - 2020-02-04 05:21:55 --> Total execution time: 0.5484
INFO - 2020-02-04 08:22:10 --> Config Class Initialized
INFO - 2020-02-04 08:22:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:10 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:10 --> URI Class Initialized
INFO - 2020-02-04 08:22:10 --> Router Class Initialized
INFO - 2020-02-04 08:22:10 --> Output Class Initialized
INFO - 2020-02-04 08:22:10 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:10 --> Input Class Initialized
INFO - 2020-02-04 08:22:10 --> Language Class Initialized
INFO - 2020-02-04 08:22:10 --> Language Class Initialized
INFO - 2020-02-04 08:22:10 --> Config Class Initialized
INFO - 2020-02-04 08:22:10 --> Loader Class Initialized
INFO - 2020-02-04 08:22:10 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:10 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:10 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:10 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:10 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:10 --> Controller Class Initialized
DEBUG - 2020-02-04 08:22:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 08:22:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:22:10 --> Final output sent to browser
DEBUG - 2020-02-04 08:22:10 --> Total execution time: 0.4071
INFO - 2020-02-04 08:22:12 --> Config Class Initialized
INFO - 2020-02-04 08:22:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:12 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:12 --> URI Class Initialized
INFO - 2020-02-04 08:22:12 --> Router Class Initialized
INFO - 2020-02-04 08:22:12 --> Output Class Initialized
INFO - 2020-02-04 08:22:12 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:12 --> Input Class Initialized
INFO - 2020-02-04 08:22:12 --> Language Class Initialized
INFO - 2020-02-04 08:22:12 --> Language Class Initialized
INFO - 2020-02-04 08:22:12 --> Config Class Initialized
INFO - 2020-02-04 08:22:12 --> Loader Class Initialized
INFO - 2020-02-04 08:22:12 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:12 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:12 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:12 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:12 --> Controller Class Initialized
DEBUG - 2020-02-04 08:22:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-04 08:22:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:22:12 --> Final output sent to browser
DEBUG - 2020-02-04 08:22:12 --> Total execution time: 0.3788
INFO - 2020-02-04 08:22:18 --> Config Class Initialized
INFO - 2020-02-04 08:22:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:18 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:18 --> URI Class Initialized
INFO - 2020-02-04 08:22:18 --> Router Class Initialized
INFO - 2020-02-04 08:22:18 --> Output Class Initialized
INFO - 2020-02-04 08:22:18 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:18 --> Input Class Initialized
INFO - 2020-02-04 08:22:18 --> Language Class Initialized
INFO - 2020-02-04 08:22:18 --> Language Class Initialized
INFO - 2020-02-04 08:22:18 --> Config Class Initialized
INFO - 2020-02-04 08:22:18 --> Loader Class Initialized
INFO - 2020-02-04 08:22:18 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:18 --> Controller Class Initialized
INFO - 2020-02-04 08:22:18 --> Helper loaded: cookie_helper
INFO - 2020-02-04 08:22:18 --> Final output sent to browser
DEBUG - 2020-02-04 08:22:18 --> Total execution time: 0.3909
INFO - 2020-02-04 08:22:18 --> Config Class Initialized
INFO - 2020-02-04 08:22:18 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:18 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:18 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:18 --> URI Class Initialized
INFO - 2020-02-04 08:22:18 --> Router Class Initialized
INFO - 2020-02-04 08:22:18 --> Output Class Initialized
INFO - 2020-02-04 08:22:18 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:18 --> Input Class Initialized
INFO - 2020-02-04 08:22:18 --> Language Class Initialized
INFO - 2020-02-04 08:22:18 --> Language Class Initialized
INFO - 2020-02-04 08:22:18 --> Config Class Initialized
INFO - 2020-02-04 08:22:18 --> Loader Class Initialized
INFO - 2020-02-04 08:22:18 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:18 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:19 --> Controller Class Initialized
DEBUG - 2020-02-04 08:22:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-04 08:22:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:22:19 --> Final output sent to browser
DEBUG - 2020-02-04 08:22:19 --> Total execution time: 0.4225
INFO - 2020-02-04 08:22:51 --> Config Class Initialized
INFO - 2020-02-04 08:22:51 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:51 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:51 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:51 --> URI Class Initialized
INFO - 2020-02-04 08:22:51 --> Router Class Initialized
INFO - 2020-02-04 08:22:51 --> Output Class Initialized
INFO - 2020-02-04 08:22:51 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:51 --> Input Class Initialized
INFO - 2020-02-04 08:22:51 --> Language Class Initialized
INFO - 2020-02-04 08:22:51 --> Language Class Initialized
INFO - 2020-02-04 08:22:51 --> Config Class Initialized
INFO - 2020-02-04 08:22:51 --> Loader Class Initialized
INFO - 2020-02-04 08:22:51 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:51 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:51 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:51 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:51 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:51 --> Controller Class Initialized
DEBUG - 2020-02-04 08:22:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-04 08:22:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:22:51 --> Final output sent to browser
DEBUG - 2020-02-04 08:22:51 --> Total execution time: 0.3745
INFO - 2020-02-04 08:22:52 --> Config Class Initialized
INFO - 2020-02-04 08:22:52 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:22:52 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:22:52 --> Utf8 Class Initialized
INFO - 2020-02-04 08:22:52 --> URI Class Initialized
INFO - 2020-02-04 08:22:52 --> Router Class Initialized
INFO - 2020-02-04 08:22:52 --> Output Class Initialized
INFO - 2020-02-04 08:22:52 --> Security Class Initialized
DEBUG - 2020-02-04 08:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:22:52 --> Input Class Initialized
INFO - 2020-02-04 08:22:52 --> Language Class Initialized
INFO - 2020-02-04 08:22:52 --> Language Class Initialized
INFO - 2020-02-04 08:22:52 --> Config Class Initialized
INFO - 2020-02-04 08:22:52 --> Loader Class Initialized
INFO - 2020-02-04 08:22:52 --> Helper loaded: url_helper
INFO - 2020-02-04 08:22:52 --> Helper loaded: file_helper
INFO - 2020-02-04 08:22:52 --> Helper loaded: form_helper
INFO - 2020-02-04 08:22:52 --> Helper loaded: my_helper
INFO - 2020-02-04 08:22:52 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:22:52 --> Controller Class Initialized
INFO - 2020-02-04 08:23:07 --> Config Class Initialized
INFO - 2020-02-04 08:23:07 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:07 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:07 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:07 --> URI Class Initialized
INFO - 2020-02-04 08:23:07 --> Router Class Initialized
INFO - 2020-02-04 08:23:07 --> Output Class Initialized
INFO - 2020-02-04 08:23:07 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:07 --> Input Class Initialized
INFO - 2020-02-04 08:23:07 --> Language Class Initialized
INFO - 2020-02-04 08:23:07 --> Language Class Initialized
INFO - 2020-02-04 08:23:07 --> Config Class Initialized
INFO - 2020-02-04 08:23:07 --> Loader Class Initialized
INFO - 2020-02-04 08:23:07 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:07 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:07 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:07 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:07 --> Controller Class Initialized
DEBUG - 2020-02-04 08:23:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-04 08:23:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:23:07 --> Final output sent to browser
DEBUG - 2020-02-04 08:23:07 --> Total execution time: 0.3762
INFO - 2020-02-04 08:23:14 --> Config Class Initialized
INFO - 2020-02-04 08:23:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:14 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:14 --> URI Class Initialized
INFO - 2020-02-04 08:23:14 --> Router Class Initialized
INFO - 2020-02-04 08:23:14 --> Output Class Initialized
INFO - 2020-02-04 08:23:14 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:14 --> Input Class Initialized
INFO - 2020-02-04 08:23:14 --> Language Class Initialized
INFO - 2020-02-04 08:23:14 --> Language Class Initialized
INFO - 2020-02-04 08:23:14 --> Config Class Initialized
INFO - 2020-02-04 08:23:14 --> Loader Class Initialized
INFO - 2020-02-04 08:23:14 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:14 --> Controller Class Initialized
DEBUG - 2020-02-04 08:23:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-04 08:23:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:23:14 --> Final output sent to browser
DEBUG - 2020-02-04 08:23:14 --> Total execution time: 0.3908
INFO - 2020-02-04 08:23:14 --> Config Class Initialized
INFO - 2020-02-04 08:23:14 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:14 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:14 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:14 --> URI Class Initialized
INFO - 2020-02-04 08:23:14 --> Router Class Initialized
INFO - 2020-02-04 08:23:14 --> Output Class Initialized
INFO - 2020-02-04 08:23:14 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:14 --> Input Class Initialized
INFO - 2020-02-04 08:23:14 --> Language Class Initialized
INFO - 2020-02-04 08:23:14 --> Language Class Initialized
INFO - 2020-02-04 08:23:14 --> Config Class Initialized
INFO - 2020-02-04 08:23:14 --> Loader Class Initialized
INFO - 2020-02-04 08:23:14 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:14 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:14 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:15 --> Controller Class Initialized
INFO - 2020-02-04 08:23:17 --> Config Class Initialized
INFO - 2020-02-04 08:23:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:17 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:17 --> URI Class Initialized
INFO - 2020-02-04 08:23:17 --> Router Class Initialized
INFO - 2020-02-04 08:23:17 --> Output Class Initialized
INFO - 2020-02-04 08:23:17 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:17 --> Input Class Initialized
INFO - 2020-02-04 08:23:17 --> Language Class Initialized
INFO - 2020-02-04 08:23:17 --> Language Class Initialized
INFO - 2020-02-04 08:23:17 --> Config Class Initialized
INFO - 2020-02-04 08:23:17 --> Loader Class Initialized
INFO - 2020-02-04 08:23:17 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:17 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:17 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:17 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:17 --> Controller Class Initialized
DEBUG - 2020-02-04 08:23:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-04 08:23:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:23:17 --> Final output sent to browser
DEBUG - 2020-02-04 08:23:17 --> Total execution time: 0.4429
INFO - 2020-02-04 08:23:17 --> Config Class Initialized
INFO - 2020-02-04 08:23:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:17 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:17 --> URI Class Initialized
INFO - 2020-02-04 08:23:17 --> Router Class Initialized
INFO - 2020-02-04 08:23:17 --> Output Class Initialized
INFO - 2020-02-04 08:23:17 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:17 --> Input Class Initialized
INFO - 2020-02-04 08:23:17 --> Language Class Initialized
INFO - 2020-02-04 08:23:17 --> Language Class Initialized
INFO - 2020-02-04 08:23:17 --> Config Class Initialized
INFO - 2020-02-04 08:23:17 --> Loader Class Initialized
INFO - 2020-02-04 08:23:17 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:18 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:18 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:18 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:18 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:18 --> Controller Class Initialized
INFO - 2020-02-04 08:23:27 --> Config Class Initialized
INFO - 2020-02-04 08:23:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:27 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:27 --> URI Class Initialized
INFO - 2020-02-04 08:23:27 --> Router Class Initialized
INFO - 2020-02-04 08:23:27 --> Output Class Initialized
INFO - 2020-02-04 08:23:27 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:27 --> Input Class Initialized
INFO - 2020-02-04 08:23:27 --> Language Class Initialized
INFO - 2020-02-04 08:23:27 --> Language Class Initialized
INFO - 2020-02-04 08:23:27 --> Config Class Initialized
INFO - 2020-02-04 08:23:27 --> Loader Class Initialized
INFO - 2020-02-04 08:23:27 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:27 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:27 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:27 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:27 --> Controller Class Initialized
DEBUG - 2020-02-04 08:23:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-04 08:23:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:23:27 --> Final output sent to browser
DEBUG - 2020-02-04 08:23:27 --> Total execution time: 0.4997
INFO - 2020-02-04 08:23:27 --> Config Class Initialized
INFO - 2020-02-04 08:23:27 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:27 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:28 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:28 --> URI Class Initialized
INFO - 2020-02-04 08:23:28 --> Router Class Initialized
INFO - 2020-02-04 08:23:28 --> Output Class Initialized
INFO - 2020-02-04 08:23:28 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:28 --> Input Class Initialized
INFO - 2020-02-04 08:23:28 --> Language Class Initialized
INFO - 2020-02-04 08:23:28 --> Language Class Initialized
INFO - 2020-02-04 08:23:28 --> Config Class Initialized
INFO - 2020-02-04 08:23:28 --> Loader Class Initialized
INFO - 2020-02-04 08:23:28 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:28 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:28 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:28 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:28 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:28 --> Controller Class Initialized
INFO - 2020-02-04 08:23:33 --> Config Class Initialized
INFO - 2020-02-04 08:23:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:33 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:33 --> URI Class Initialized
INFO - 2020-02-04 08:23:33 --> Router Class Initialized
INFO - 2020-02-04 08:23:33 --> Output Class Initialized
INFO - 2020-02-04 08:23:33 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:33 --> Input Class Initialized
INFO - 2020-02-04 08:23:33 --> Language Class Initialized
INFO - 2020-02-04 08:23:33 --> Language Class Initialized
INFO - 2020-02-04 08:23:33 --> Config Class Initialized
INFO - 2020-02-04 08:23:33 --> Loader Class Initialized
INFO - 2020-02-04 08:23:33 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:33 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:33 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:33 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:33 --> Controller Class Initialized
INFO - 2020-02-04 08:23:33 --> Helper loaded: cookie_helper
INFO - 2020-02-04 08:23:33 --> Config Class Initialized
INFO - 2020-02-04 08:23:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:33 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:33 --> URI Class Initialized
INFO - 2020-02-04 08:23:33 --> Router Class Initialized
INFO - 2020-02-04 08:23:33 --> Output Class Initialized
INFO - 2020-02-04 08:23:33 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:33 --> Input Class Initialized
INFO - 2020-02-04 08:23:33 --> Language Class Initialized
INFO - 2020-02-04 08:23:33 --> Language Class Initialized
INFO - 2020-02-04 08:23:33 --> Config Class Initialized
INFO - 2020-02-04 08:23:33 --> Loader Class Initialized
INFO - 2020-02-04 08:23:33 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:33 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:34 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:34 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:34 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:34 --> Controller Class Initialized
INFO - 2020-02-04 08:23:34 --> Config Class Initialized
INFO - 2020-02-04 08:23:34 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:23:34 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:23:34 --> Utf8 Class Initialized
INFO - 2020-02-04 08:23:34 --> URI Class Initialized
INFO - 2020-02-04 08:23:34 --> Router Class Initialized
INFO - 2020-02-04 08:23:34 --> Output Class Initialized
INFO - 2020-02-04 08:23:34 --> Security Class Initialized
DEBUG - 2020-02-04 08:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:23:34 --> Input Class Initialized
INFO - 2020-02-04 08:23:34 --> Language Class Initialized
INFO - 2020-02-04 08:23:34 --> Language Class Initialized
INFO - 2020-02-04 08:23:34 --> Config Class Initialized
INFO - 2020-02-04 08:23:34 --> Loader Class Initialized
INFO - 2020-02-04 08:23:34 --> Helper loaded: url_helper
INFO - 2020-02-04 08:23:34 --> Helper loaded: file_helper
INFO - 2020-02-04 08:23:34 --> Helper loaded: form_helper
INFO - 2020-02-04 08:23:34 --> Helper loaded: my_helper
INFO - 2020-02-04 08:23:34 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:23:34 --> Controller Class Initialized
DEBUG - 2020-02-04 08:23:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-04 08:23:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:23:34 --> Final output sent to browser
DEBUG - 2020-02-04 08:23:34 --> Total execution time: 0.3768
INFO - 2020-02-04 08:24:01 --> Config Class Initialized
INFO - 2020-02-04 08:24:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:01 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:01 --> URI Class Initialized
INFO - 2020-02-04 08:24:01 --> Router Class Initialized
INFO - 2020-02-04 08:24:01 --> Output Class Initialized
INFO - 2020-02-04 08:24:01 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:01 --> Input Class Initialized
INFO - 2020-02-04 08:24:01 --> Language Class Initialized
INFO - 2020-02-04 08:24:01 --> Language Class Initialized
INFO - 2020-02-04 08:24:01 --> Config Class Initialized
INFO - 2020-02-04 08:24:01 --> Loader Class Initialized
INFO - 2020-02-04 08:24:01 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:01 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:01 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:01 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:01 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:01 --> Controller Class Initialized
INFO - 2020-02-04 08:24:01 --> Helper loaded: cookie_helper
INFO - 2020-02-04 08:24:01 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:01 --> Total execution time: 0.3862
INFO - 2020-02-04 08:24:01 --> Config Class Initialized
INFO - 2020-02-04 08:24:01 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:01 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:01 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:01 --> URI Class Initialized
INFO - 2020-02-04 08:24:01 --> Router Class Initialized
INFO - 2020-02-04 08:24:01 --> Output Class Initialized
INFO - 2020-02-04 08:24:01 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:01 --> Input Class Initialized
INFO - 2020-02-04 08:24:01 --> Language Class Initialized
INFO - 2020-02-04 08:24:01 --> Language Class Initialized
INFO - 2020-02-04 08:24:01 --> Config Class Initialized
INFO - 2020-02-04 08:24:01 --> Loader Class Initialized
INFO - 2020-02-04 08:24:01 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:01 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:02 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:02 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:02 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:02 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-04 08:24:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:02 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:02 --> Total execution time: 0.4454
INFO - 2020-02-04 08:24:06 --> Config Class Initialized
INFO - 2020-02-04 08:24:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:06 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:06 --> URI Class Initialized
INFO - 2020-02-04 08:24:06 --> Router Class Initialized
INFO - 2020-02-04 08:24:06 --> Output Class Initialized
INFO - 2020-02-04 08:24:06 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:07 --> Input Class Initialized
INFO - 2020-02-04 08:24:07 --> Language Class Initialized
INFO - 2020-02-04 08:24:07 --> Language Class Initialized
INFO - 2020-02-04 08:24:07 --> Config Class Initialized
INFO - 2020-02-04 08:24:07 --> Loader Class Initialized
INFO - 2020-02-04 08:24:07 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:07 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:07 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:07 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:07 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-04 08:24:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:07 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:07 --> Total execution time: 0.4485
INFO - 2020-02-04 08:24:10 --> Config Class Initialized
INFO - 2020-02-04 08:24:10 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:10 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:10 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:10 --> URI Class Initialized
INFO - 2020-02-04 08:24:10 --> Router Class Initialized
INFO - 2020-02-04 08:24:10 --> Output Class Initialized
INFO - 2020-02-04 08:24:10 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:10 --> Input Class Initialized
INFO - 2020-02-04 08:24:10 --> Language Class Initialized
INFO - 2020-02-04 08:24:10 --> Language Class Initialized
INFO - 2020-02-04 08:24:10 --> Config Class Initialized
INFO - 2020-02-04 08:24:10 --> Loader Class Initialized
INFO - 2020-02-04 08:24:10 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:10 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:10 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:10 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:10 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:10 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-04 08:24:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:10 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:10 --> Total execution time: 0.3958
INFO - 2020-02-04 08:24:10 --> Config Class Initialized
INFO - 2020-02-04 08:24:11 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:11 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:11 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:11 --> URI Class Initialized
INFO - 2020-02-04 08:24:11 --> Router Class Initialized
INFO - 2020-02-04 08:24:11 --> Output Class Initialized
INFO - 2020-02-04 08:24:11 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:11 --> Input Class Initialized
INFO - 2020-02-04 08:24:11 --> Language Class Initialized
INFO - 2020-02-04 08:24:11 --> Language Class Initialized
INFO - 2020-02-04 08:24:11 --> Config Class Initialized
INFO - 2020-02-04 08:24:11 --> Loader Class Initialized
INFO - 2020-02-04 08:24:11 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:11 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:11 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:11 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:11 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:11 --> Controller Class Initialized
INFO - 2020-02-04 08:24:16 --> Config Class Initialized
INFO - 2020-02-04 08:24:16 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:16 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:16 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:16 --> URI Class Initialized
INFO - 2020-02-04 08:24:16 --> Router Class Initialized
INFO - 2020-02-04 08:24:16 --> Output Class Initialized
INFO - 2020-02-04 08:24:16 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:16 --> Input Class Initialized
INFO - 2020-02-04 08:24:16 --> Language Class Initialized
INFO - 2020-02-04 08:24:17 --> Language Class Initialized
INFO - 2020-02-04 08:24:17 --> Config Class Initialized
INFO - 2020-02-04 08:24:17 --> Loader Class Initialized
INFO - 2020-02-04 08:24:17 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:17 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:17 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:17 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:17 --> Controller Class Initialized
INFO - 2020-02-04 08:24:17 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:17 --> Total execution time: 0.3231
INFO - 2020-02-04 08:24:21 --> Config Class Initialized
INFO - 2020-02-04 08:24:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:21 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:21 --> URI Class Initialized
INFO - 2020-02-04 08:24:21 --> Router Class Initialized
INFO - 2020-02-04 08:24:21 --> Output Class Initialized
INFO - 2020-02-04 08:24:21 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:21 --> Input Class Initialized
INFO - 2020-02-04 08:24:21 --> Language Class Initialized
INFO - 2020-02-04 08:24:21 --> Language Class Initialized
INFO - 2020-02-04 08:24:21 --> Config Class Initialized
INFO - 2020-02-04 08:24:21 --> Loader Class Initialized
INFO - 2020-02-04 08:24:21 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:21 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:21 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:21 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:21 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:21 --> Controller Class Initialized
INFO - 2020-02-04 08:24:21 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:21 --> Total execution time: 0.3478
INFO - 2020-02-04 08:24:23 --> Config Class Initialized
INFO - 2020-02-04 08:24:23 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:23 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:23 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:23 --> URI Class Initialized
INFO - 2020-02-04 08:24:23 --> Router Class Initialized
INFO - 2020-02-04 08:24:23 --> Output Class Initialized
INFO - 2020-02-04 08:24:23 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:23 --> Input Class Initialized
INFO - 2020-02-04 08:24:23 --> Language Class Initialized
INFO - 2020-02-04 08:24:23 --> Language Class Initialized
INFO - 2020-02-04 08:24:23 --> Config Class Initialized
INFO - 2020-02-04 08:24:23 --> Loader Class Initialized
INFO - 2020-02-04 08:24:23 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:23 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:23 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:23 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:23 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:23 --> Controller Class Initialized
INFO - 2020-02-04 08:24:23 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:23 --> Total execution time: 0.3669
INFO - 2020-02-04 08:24:26 --> Config Class Initialized
INFO - 2020-02-04 08:24:26 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:26 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:26 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:26 --> URI Class Initialized
INFO - 2020-02-04 08:24:26 --> Router Class Initialized
INFO - 2020-02-04 08:24:26 --> Output Class Initialized
INFO - 2020-02-04 08:24:26 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:26 --> Input Class Initialized
INFO - 2020-02-04 08:24:26 --> Language Class Initialized
INFO - 2020-02-04 08:24:26 --> Language Class Initialized
INFO - 2020-02-04 08:24:26 --> Config Class Initialized
INFO - 2020-02-04 08:24:26 --> Loader Class Initialized
INFO - 2020-02-04 08:24:26 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:26 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:26 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:26 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:27 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:27 --> Controller Class Initialized
INFO - 2020-02-04 08:24:27 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:27 --> Total execution time: 0.3603
INFO - 2020-02-04 08:24:29 --> Config Class Initialized
INFO - 2020-02-04 08:24:29 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:29 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:29 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:29 --> URI Class Initialized
INFO - 2020-02-04 08:24:30 --> Router Class Initialized
INFO - 2020-02-04 08:24:30 --> Output Class Initialized
INFO - 2020-02-04 08:24:30 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:30 --> Input Class Initialized
INFO - 2020-02-04 08:24:30 --> Language Class Initialized
INFO - 2020-02-04 08:24:30 --> Language Class Initialized
INFO - 2020-02-04 08:24:30 --> Config Class Initialized
INFO - 2020-02-04 08:24:30 --> Loader Class Initialized
INFO - 2020-02-04 08:24:30 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:30 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:30 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:30 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:30 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:30 --> Controller Class Initialized
INFO - 2020-02-04 08:24:50 --> Config Class Initialized
INFO - 2020-02-04 08:24:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:50 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:50 --> URI Class Initialized
INFO - 2020-02-04 08:24:50 --> Router Class Initialized
INFO - 2020-02-04 08:24:50 --> Output Class Initialized
INFO - 2020-02-04 08:24:50 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:50 --> Input Class Initialized
INFO - 2020-02-04 08:24:50 --> Language Class Initialized
INFO - 2020-02-04 08:24:50 --> Language Class Initialized
INFO - 2020-02-04 08:24:50 --> Config Class Initialized
INFO - 2020-02-04 08:24:50 --> Loader Class Initialized
INFO - 2020-02-04 08:24:50 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:50 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:50 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:50 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:50 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:50 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-02-04 08:24:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:50 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:50 --> Total execution time: 0.4195
INFO - 2020-02-04 08:24:55 --> Config Class Initialized
INFO - 2020-02-04 08:24:55 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:55 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:55 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:55 --> URI Class Initialized
INFO - 2020-02-04 08:24:55 --> Router Class Initialized
INFO - 2020-02-04 08:24:56 --> Output Class Initialized
INFO - 2020-02-04 08:24:56 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:56 --> Input Class Initialized
INFO - 2020-02-04 08:24:56 --> Language Class Initialized
INFO - 2020-02-04 08:24:56 --> Language Class Initialized
INFO - 2020-02-04 08:24:56 --> Config Class Initialized
INFO - 2020-02-04 08:24:56 --> Loader Class Initialized
INFO - 2020-02-04 08:24:56 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:56 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:56 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:56 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:56 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:56 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-04 08:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:56 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:56 --> Total execution time: 0.4670
INFO - 2020-02-04 08:24:58 --> Config Class Initialized
INFO - 2020-02-04 08:24:58 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:24:58 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:24:58 --> Utf8 Class Initialized
INFO - 2020-02-04 08:24:58 --> URI Class Initialized
INFO - 2020-02-04 08:24:58 --> Router Class Initialized
INFO - 2020-02-04 08:24:58 --> Output Class Initialized
INFO - 2020-02-04 08:24:58 --> Security Class Initialized
DEBUG - 2020-02-04 08:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:24:58 --> Input Class Initialized
INFO - 2020-02-04 08:24:58 --> Language Class Initialized
INFO - 2020-02-04 08:24:58 --> Language Class Initialized
INFO - 2020-02-04 08:24:58 --> Config Class Initialized
INFO - 2020-02-04 08:24:58 --> Loader Class Initialized
INFO - 2020-02-04 08:24:58 --> Helper loaded: url_helper
INFO - 2020-02-04 08:24:58 --> Helper loaded: file_helper
INFO - 2020-02-04 08:24:58 --> Helper loaded: form_helper
INFO - 2020-02-04 08:24:58 --> Helper loaded: my_helper
INFO - 2020-02-04 08:24:58 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:24:58 --> Controller Class Initialized
DEBUG - 2020-02-04 08:24:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-02-04 08:24:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:24:58 --> Final output sent to browser
DEBUG - 2020-02-04 08:24:58 --> Total execution time: 0.3871
INFO - 2020-02-04 08:25:00 --> Config Class Initialized
INFO - 2020-02-04 08:25:00 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:00 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:00 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:00 --> URI Class Initialized
INFO - 2020-02-04 08:25:00 --> Router Class Initialized
INFO - 2020-02-04 08:25:00 --> Output Class Initialized
INFO - 2020-02-04 08:25:00 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:00 --> Input Class Initialized
INFO - 2020-02-04 08:25:00 --> Language Class Initialized
INFO - 2020-02-04 08:25:00 --> Language Class Initialized
INFO - 2020-02-04 08:25:00 --> Config Class Initialized
INFO - 2020-02-04 08:25:00 --> Loader Class Initialized
INFO - 2020-02-04 08:25:00 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:00 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:00 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:00 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:00 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-02-04 08:25:00 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:01 --> Total execution time: 0.6683
INFO - 2020-02-04 08:25:08 --> Config Class Initialized
INFO - 2020-02-04 08:25:08 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:08 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:08 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:08 --> URI Class Initialized
INFO - 2020-02-04 08:25:09 --> Router Class Initialized
INFO - 2020-02-04 08:25:09 --> Output Class Initialized
INFO - 2020-02-04 08:25:09 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:09 --> Input Class Initialized
INFO - 2020-02-04 08:25:09 --> Language Class Initialized
INFO - 2020-02-04 08:25:09 --> Language Class Initialized
INFO - 2020-02-04 08:25:09 --> Config Class Initialized
INFO - 2020-02-04 08:25:09 --> Loader Class Initialized
INFO - 2020-02-04 08:25:09 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:09 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:09 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:09 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:09 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-04 08:25:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:09 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:09 --> Total execution time: 0.4473
INFO - 2020-02-04 08:25:11 --> Config Class Initialized
INFO - 2020-02-04 08:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:11 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:11 --> URI Class Initialized
INFO - 2020-02-04 08:25:11 --> Router Class Initialized
INFO - 2020-02-04 08:25:11 --> Output Class Initialized
INFO - 2020-02-04 08:25:11 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:11 --> Input Class Initialized
INFO - 2020-02-04 08:25:11 --> Language Class Initialized
INFO - 2020-02-04 08:25:11 --> Language Class Initialized
INFO - 2020-02-04 08:25:11 --> Config Class Initialized
INFO - 2020-02-04 08:25:11 --> Loader Class Initialized
INFO - 2020-02-04 08:25:11 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:11 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:11 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:11 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:11 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:11 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-04 08:25:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:11 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:11 --> Total execution time: 0.4062
INFO - 2020-02-04 08:25:11 --> Config Class Initialized
INFO - 2020-02-04 08:25:11 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:11 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:11 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:11 --> URI Class Initialized
INFO - 2020-02-04 08:25:11 --> Router Class Initialized
INFO - 2020-02-04 08:25:11 --> Output Class Initialized
INFO - 2020-02-04 08:25:11 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:11 --> Input Class Initialized
INFO - 2020-02-04 08:25:11 --> Language Class Initialized
INFO - 2020-02-04 08:25:12 --> Language Class Initialized
INFO - 2020-02-04 08:25:12 --> Config Class Initialized
INFO - 2020-02-04 08:25:12 --> Loader Class Initialized
INFO - 2020-02-04 08:25:12 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:12 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:12 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:12 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:12 --> Controller Class Initialized
INFO - 2020-02-04 08:25:12 --> Config Class Initialized
INFO - 2020-02-04 08:25:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:12 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:12 --> URI Class Initialized
INFO - 2020-02-04 08:25:12 --> Router Class Initialized
INFO - 2020-02-04 08:25:12 --> Output Class Initialized
INFO - 2020-02-04 08:25:12 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:12 --> Input Class Initialized
INFO - 2020-02-04 08:25:13 --> Language Class Initialized
INFO - 2020-02-04 08:25:13 --> Language Class Initialized
INFO - 2020-02-04 08:25:13 --> Config Class Initialized
INFO - 2020-02-04 08:25:13 --> Loader Class Initialized
INFO - 2020-02-04 08:25:13 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:13 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:13 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:13 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:13 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:13 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-04 08:25:13 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:13 --> Total execution time: 0.6367
INFO - 2020-02-04 08:25:25 --> Config Class Initialized
INFO - 2020-02-04 08:25:25 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:25 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:25 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:25 --> URI Class Initialized
INFO - 2020-02-04 08:25:25 --> Router Class Initialized
INFO - 2020-02-04 08:25:25 --> Output Class Initialized
INFO - 2020-02-04 08:25:25 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:25 --> Input Class Initialized
INFO - 2020-02-04 08:25:25 --> Language Class Initialized
INFO - 2020-02-04 08:25:25 --> Language Class Initialized
INFO - 2020-02-04 08:25:25 --> Config Class Initialized
INFO - 2020-02-04 08:25:25 --> Loader Class Initialized
INFO - 2020-02-04 08:25:25 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:25 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:25 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:25 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:25 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:25 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-02-04 08:25:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:26 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:26 --> Total execution time: 0.3910
INFO - 2020-02-04 08:25:31 --> Config Class Initialized
INFO - 2020-02-04 08:25:31 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:31 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:31 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:31 --> URI Class Initialized
INFO - 2020-02-04 08:25:31 --> Router Class Initialized
INFO - 2020-02-04 08:25:31 --> Output Class Initialized
INFO - 2020-02-04 08:25:31 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:31 --> Input Class Initialized
INFO - 2020-02-04 08:25:31 --> Language Class Initialized
INFO - 2020-02-04 08:25:31 --> Language Class Initialized
INFO - 2020-02-04 08:25:31 --> Config Class Initialized
INFO - 2020-02-04 08:25:31 --> Loader Class Initialized
INFO - 2020-02-04 08:25:31 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:31 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:31 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:31 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:31 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:31 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-02-04 08:25:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:31 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:31 --> Total execution time: 0.4311
INFO - 2020-02-04 08:25:35 --> Config Class Initialized
INFO - 2020-02-04 08:25:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:35 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:35 --> URI Class Initialized
INFO - 2020-02-04 08:25:35 --> Router Class Initialized
INFO - 2020-02-04 08:25:35 --> Output Class Initialized
INFO - 2020-02-04 08:25:35 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:35 --> Input Class Initialized
INFO - 2020-02-04 08:25:35 --> Language Class Initialized
INFO - 2020-02-04 08:25:35 --> Language Class Initialized
INFO - 2020-02-04 08:25:35 --> Config Class Initialized
INFO - 2020-02-04 08:25:35 --> Loader Class Initialized
INFO - 2020-02-04 08:25:35 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:35 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:35 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:35 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:35 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_ekstra/views/list.php
DEBUG - 2020-02-04 08:25:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:36 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:36 --> Total execution time: 0.4330
INFO - 2020-02-04 08:25:40 --> Config Class Initialized
INFO - 2020-02-04 08:25:40 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:40 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:40 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:40 --> URI Class Initialized
INFO - 2020-02-04 08:25:40 --> Router Class Initialized
INFO - 2020-02-04 08:25:40 --> Output Class Initialized
INFO - 2020-02-04 08:25:40 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:40 --> Input Class Initialized
INFO - 2020-02-04 08:25:40 --> Language Class Initialized
INFO - 2020-02-04 08:25:40 --> Language Class Initialized
INFO - 2020-02-04 08:25:40 --> Config Class Initialized
INFO - 2020-02-04 08:25:40 --> Loader Class Initialized
INFO - 2020-02-04 08:25:40 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:40 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:40 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:40 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:40 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:40 --> Controller Class Initialized
INFO - 2020-02-04 08:25:40 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:40 --> Total execution time: 0.3605
INFO - 2020-02-04 08:25:41 --> Config Class Initialized
INFO - 2020-02-04 08:25:41 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:41 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:41 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:41 --> URI Class Initialized
INFO - 2020-02-04 08:25:41 --> Router Class Initialized
INFO - 2020-02-04 08:25:41 --> Output Class Initialized
INFO - 2020-02-04 08:25:41 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:41 --> Input Class Initialized
INFO - 2020-02-04 08:25:41 --> Language Class Initialized
INFO - 2020-02-04 08:25:41 --> Language Class Initialized
INFO - 2020-02-04 08:25:41 --> Config Class Initialized
INFO - 2020-02-04 08:25:41 --> Loader Class Initialized
INFO - 2020-02-04 08:25:41 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:41 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:41 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:41 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:42 --> Controller Class Initialized
INFO - 2020-02-04 08:25:42 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:42 --> Total execution time: 0.3333
INFO - 2020-02-04 08:25:43 --> Config Class Initialized
INFO - 2020-02-04 08:25:43 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:43 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:43 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:43 --> URI Class Initialized
INFO - 2020-02-04 08:25:43 --> Router Class Initialized
INFO - 2020-02-04 08:25:43 --> Output Class Initialized
INFO - 2020-02-04 08:25:43 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:43 --> Input Class Initialized
INFO - 2020-02-04 08:25:43 --> Language Class Initialized
INFO - 2020-02-04 08:25:43 --> Language Class Initialized
INFO - 2020-02-04 08:25:43 --> Config Class Initialized
INFO - 2020-02-04 08:25:43 --> Loader Class Initialized
INFO - 2020-02-04 08:25:43 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:43 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:43 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:43 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:43 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:44 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_prestasi/views/list.php
DEBUG - 2020-02-04 08:25:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:44 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:44 --> Total execution time: 0.4262
INFO - 2020-02-04 08:25:44 --> Config Class Initialized
INFO - 2020-02-04 08:25:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:44 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:44 --> URI Class Initialized
INFO - 2020-02-04 08:25:44 --> Router Class Initialized
INFO - 2020-02-04 08:25:44 --> Output Class Initialized
INFO - 2020-02-04 08:25:44 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:44 --> Input Class Initialized
INFO - 2020-02-04 08:25:44 --> Language Class Initialized
INFO - 2020-02-04 08:25:44 --> Language Class Initialized
INFO - 2020-02-04 08:25:44 --> Config Class Initialized
INFO - 2020-02-04 08:25:44 --> Loader Class Initialized
INFO - 2020-02-04 08:25:44 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:44 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:44 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:44 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:44 --> Controller Class Initialized
INFO - 2020-02-04 08:25:49 --> Config Class Initialized
INFO - 2020-02-04 08:25:49 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:49 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:49 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:49 --> URI Class Initialized
INFO - 2020-02-04 08:25:49 --> Router Class Initialized
INFO - 2020-02-04 08:25:49 --> Output Class Initialized
INFO - 2020-02-04 08:25:49 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:49 --> Input Class Initialized
INFO - 2020-02-04 08:25:49 --> Language Class Initialized
INFO - 2020-02-04 08:25:49 --> Language Class Initialized
INFO - 2020-02-04 08:25:49 --> Config Class Initialized
INFO - 2020-02-04 08:25:49 --> Loader Class Initialized
INFO - 2020-02-04 08:25:50 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:50 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:50 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:50 --> Helper loaded: my_helper
INFO - 2020-02-04 08:25:50 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:25:50 --> Controller Class Initialized
DEBUG - 2020-02-04 08:25:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-02-04 08:25:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:25:50 --> Final output sent to browser
DEBUG - 2020-02-04 08:25:50 --> Total execution time: 0.4005
INFO - 2020-02-04 08:25:59 --> Config Class Initialized
INFO - 2020-02-04 08:25:59 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:25:59 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:25:59 --> Utf8 Class Initialized
INFO - 2020-02-04 08:25:59 --> URI Class Initialized
INFO - 2020-02-04 08:25:59 --> Router Class Initialized
INFO - 2020-02-04 08:25:59 --> Output Class Initialized
INFO - 2020-02-04 08:25:59 --> Security Class Initialized
DEBUG - 2020-02-04 08:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:25:59 --> Input Class Initialized
INFO - 2020-02-04 08:25:59 --> Language Class Initialized
INFO - 2020-02-04 08:25:59 --> Language Class Initialized
INFO - 2020-02-04 08:25:59 --> Config Class Initialized
INFO - 2020-02-04 08:25:59 --> Loader Class Initialized
INFO - 2020-02-04 08:25:59 --> Helper loaded: url_helper
INFO - 2020-02-04 08:25:59 --> Helper loaded: file_helper
INFO - 2020-02-04 08:25:59 --> Helper loaded: form_helper
INFO - 2020-02-04 08:25:59 --> Helper loaded: my_helper
INFO - 2020-02-04 08:26:00 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:26:00 --> Controller Class Initialized
DEBUG - 2020-02-04 08:26:00 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-02-04 08:26:00 --> Final output sent to browser
DEBUG - 2020-02-04 08:26:00 --> Total execution time: 0.5218
INFO - 2020-02-04 08:26:12 --> Config Class Initialized
INFO - 2020-02-04 08:26:12 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:26:12 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:26:12 --> Utf8 Class Initialized
INFO - 2020-02-04 08:26:12 --> URI Class Initialized
INFO - 2020-02-04 08:26:12 --> Router Class Initialized
INFO - 2020-02-04 08:26:12 --> Output Class Initialized
INFO - 2020-02-04 08:26:12 --> Security Class Initialized
DEBUG - 2020-02-04 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:26:12 --> Input Class Initialized
INFO - 2020-02-04 08:26:12 --> Language Class Initialized
INFO - 2020-02-04 08:26:12 --> Language Class Initialized
INFO - 2020-02-04 08:26:12 --> Config Class Initialized
INFO - 2020-02-04 08:26:12 --> Loader Class Initialized
INFO - 2020-02-04 08:26:12 --> Helper loaded: url_helper
INFO - 2020-02-04 08:26:12 --> Helper loaded: file_helper
INFO - 2020-02-04 08:26:12 --> Helper loaded: form_helper
INFO - 2020-02-04 08:26:12 --> Helper loaded: my_helper
INFO - 2020-02-04 08:26:12 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:26:12 --> Controller Class Initialized
DEBUG - 2020-02-04 08:26:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-04 08:26:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:26:12 --> Final output sent to browser
DEBUG - 2020-02-04 08:26:12 --> Total execution time: 0.4145
INFO - 2020-02-04 08:26:17 --> Config Class Initialized
INFO - 2020-02-04 08:26:17 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:26:17 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:26:17 --> Utf8 Class Initialized
INFO - 2020-02-04 08:26:17 --> URI Class Initialized
INFO - 2020-02-04 08:26:17 --> Router Class Initialized
INFO - 2020-02-04 08:26:17 --> Output Class Initialized
INFO - 2020-02-04 08:26:17 --> Security Class Initialized
DEBUG - 2020-02-04 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:26:17 --> Input Class Initialized
INFO - 2020-02-04 08:26:17 --> Language Class Initialized
INFO - 2020-02-04 08:26:17 --> Language Class Initialized
INFO - 2020-02-04 08:26:17 --> Config Class Initialized
INFO - 2020-02-04 08:26:17 --> Loader Class Initialized
INFO - 2020-02-04 08:26:17 --> Helper loaded: url_helper
INFO - 2020-02-04 08:26:17 --> Helper loaded: file_helper
INFO - 2020-02-04 08:26:17 --> Helper loaded: form_helper
INFO - 2020-02-04 08:26:17 --> Helper loaded: my_helper
INFO - 2020-02-04 08:26:17 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:26:17 --> Controller Class Initialized
DEBUG - 2020-02-04 08:26:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-02-04 08:26:17 --> Final output sent to browser
DEBUG - 2020-02-04 08:26:17 --> Total execution time: 0.4509
INFO - 2020-02-04 08:26:53 --> Config Class Initialized
INFO - 2020-02-04 08:26:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:26:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:26:53 --> Utf8 Class Initialized
INFO - 2020-02-04 08:26:53 --> URI Class Initialized
INFO - 2020-02-04 08:26:53 --> Router Class Initialized
INFO - 2020-02-04 08:26:53 --> Output Class Initialized
INFO - 2020-02-04 08:26:53 --> Security Class Initialized
DEBUG - 2020-02-04 08:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:26:53 --> Input Class Initialized
INFO - 2020-02-04 08:26:53 --> Language Class Initialized
INFO - 2020-02-04 08:26:53 --> Language Class Initialized
INFO - 2020-02-04 08:26:53 --> Config Class Initialized
INFO - 2020-02-04 08:26:53 --> Loader Class Initialized
INFO - 2020-02-04 08:26:53 --> Helper loaded: url_helper
INFO - 2020-02-04 08:26:53 --> Helper loaded: file_helper
INFO - 2020-02-04 08:26:53 --> Helper loaded: form_helper
INFO - 2020-02-04 08:26:53 --> Helper loaded: my_helper
INFO - 2020-02-04 08:26:53 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:26:53 --> Controller Class Initialized
DEBUG - 2020-02-04 08:26:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-02-04 08:26:53 --> Final output sent to browser
DEBUG - 2020-02-04 08:26:53 --> Total execution time: 0.4584
INFO - 2020-02-04 08:27:21 --> Config Class Initialized
INFO - 2020-02-04 08:27:21 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:27:21 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:27:21 --> Utf8 Class Initialized
INFO - 2020-02-04 08:27:21 --> URI Class Initialized
INFO - 2020-02-04 08:27:22 --> Router Class Initialized
INFO - 2020-02-04 08:27:22 --> Output Class Initialized
INFO - 2020-02-04 08:27:22 --> Security Class Initialized
DEBUG - 2020-02-04 08:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:27:22 --> Input Class Initialized
INFO - 2020-02-04 08:27:22 --> Language Class Initialized
INFO - 2020-02-04 08:27:22 --> Language Class Initialized
INFO - 2020-02-04 08:27:22 --> Config Class Initialized
INFO - 2020-02-04 08:27:22 --> Loader Class Initialized
INFO - 2020-02-04 08:27:22 --> Helper loaded: url_helper
INFO - 2020-02-04 08:27:22 --> Helper loaded: file_helper
INFO - 2020-02-04 08:27:22 --> Helper loaded: form_helper
INFO - 2020-02-04 08:27:22 --> Helper loaded: my_helper
INFO - 2020-02-04 08:27:22 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:27:22 --> Controller Class Initialized
DEBUG - 2020-02-04 08:27:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_catatan/views/list.php
DEBUG - 2020-02-04 08:27:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:27:22 --> Final output sent to browser
DEBUG - 2020-02-04 08:27:22 --> Total execution time: 0.3979
INFO - 2020-02-04 08:27:33 --> Config Class Initialized
INFO - 2020-02-04 08:27:33 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:27:33 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:27:33 --> Utf8 Class Initialized
INFO - 2020-02-04 08:27:33 --> URI Class Initialized
INFO - 2020-02-04 08:27:33 --> Router Class Initialized
INFO - 2020-02-04 08:27:33 --> Output Class Initialized
INFO - 2020-02-04 08:27:33 --> Security Class Initialized
DEBUG - 2020-02-04 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:27:33 --> Input Class Initialized
INFO - 2020-02-04 08:27:33 --> Language Class Initialized
INFO - 2020-02-04 08:27:33 --> Language Class Initialized
INFO - 2020-02-04 08:27:33 --> Config Class Initialized
INFO - 2020-02-04 08:27:33 --> Loader Class Initialized
INFO - 2020-02-04 08:27:33 --> Helper loaded: url_helper
INFO - 2020-02-04 08:27:33 --> Helper loaded: file_helper
INFO - 2020-02-04 08:27:33 --> Helper loaded: form_helper
INFO - 2020-02-04 08:27:33 --> Helper loaded: my_helper
INFO - 2020-02-04 08:27:33 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:27:33 --> Controller Class Initialized
INFO - 2020-02-04 08:27:33 --> Final output sent to browser
DEBUG - 2020-02-04 08:27:33 --> Total execution time: 0.3808
INFO - 2020-02-04 08:27:36 --> Config Class Initialized
INFO - 2020-02-04 08:27:36 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:27:36 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:27:36 --> Utf8 Class Initialized
INFO - 2020-02-04 08:27:36 --> URI Class Initialized
INFO - 2020-02-04 08:27:36 --> Router Class Initialized
INFO - 2020-02-04 08:27:36 --> Output Class Initialized
INFO - 2020-02-04 08:27:36 --> Security Class Initialized
DEBUG - 2020-02-04 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:27:36 --> Input Class Initialized
INFO - 2020-02-04 08:27:36 --> Language Class Initialized
INFO - 2020-02-04 08:27:36 --> Language Class Initialized
INFO - 2020-02-04 08:27:36 --> Config Class Initialized
INFO - 2020-02-04 08:27:36 --> Loader Class Initialized
INFO - 2020-02-04 08:27:36 --> Helper loaded: url_helper
INFO - 2020-02-04 08:27:36 --> Helper loaded: file_helper
INFO - 2020-02-04 08:27:36 --> Helper loaded: form_helper
INFO - 2020-02-04 08:27:36 --> Helper loaded: my_helper
INFO - 2020-02-04 08:27:36 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:27:36 --> Controller Class Initialized
DEBUG - 2020-02-04 08:27:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-02-04 08:27:36 --> Final output sent to browser
DEBUG - 2020-02-04 08:27:36 --> Total execution time: 0.4354
INFO - 2020-02-04 08:27:50 --> Config Class Initialized
INFO - 2020-02-04 08:27:50 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:27:50 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:27:50 --> Utf8 Class Initialized
INFO - 2020-02-04 08:27:50 --> URI Class Initialized
INFO - 2020-02-04 08:27:50 --> Router Class Initialized
INFO - 2020-02-04 08:27:50 --> Output Class Initialized
INFO - 2020-02-04 08:27:50 --> Security Class Initialized
DEBUG - 2020-02-04 08:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:27:50 --> Input Class Initialized
INFO - 2020-02-04 08:27:50 --> Language Class Initialized
INFO - 2020-02-04 08:27:50 --> Language Class Initialized
INFO - 2020-02-04 08:27:50 --> Config Class Initialized
INFO - 2020-02-04 08:27:50 --> Loader Class Initialized
INFO - 2020-02-04 08:27:50 --> Helper loaded: url_helper
INFO - 2020-02-04 08:27:51 --> Helper loaded: file_helper
INFO - 2020-02-04 08:27:51 --> Helper loaded: form_helper
INFO - 2020-02-04 08:27:51 --> Helper loaded: my_helper
INFO - 2020-02-04 08:27:51 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:27:51 --> Controller Class Initialized
DEBUG - 2020-02-04 08:27:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/list.php
DEBUG - 2020-02-04 08:27:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:27:51 --> Final output sent to browser
DEBUG - 2020-02-04 08:27:51 --> Total execution time: 0.4158
INFO - 2020-02-04 08:27:53 --> Config Class Initialized
INFO - 2020-02-04 08:27:53 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:27:53 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:27:53 --> Utf8 Class Initialized
INFO - 2020-02-04 08:27:53 --> URI Class Initialized
INFO - 2020-02-04 08:27:53 --> Router Class Initialized
INFO - 2020-02-04 08:27:53 --> Output Class Initialized
INFO - 2020-02-04 08:27:53 --> Security Class Initialized
DEBUG - 2020-02-04 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:27:53 --> Input Class Initialized
INFO - 2020-02-04 08:27:53 --> Language Class Initialized
INFO - 2020-02-04 08:27:53 --> Language Class Initialized
INFO - 2020-02-04 08:27:53 --> Config Class Initialized
INFO - 2020-02-04 08:27:53 --> Loader Class Initialized
INFO - 2020-02-04 08:27:53 --> Helper loaded: url_helper
INFO - 2020-02-04 08:27:53 --> Helper loaded: file_helper
INFO - 2020-02-04 08:27:53 --> Helper loaded: form_helper
INFO - 2020-02-04 08:27:53 --> Helper loaded: my_helper
INFO - 2020-02-04 08:27:53 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:27:53 --> Controller Class Initialized
DEBUG - 2020-02-04 08:27:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-02-04 08:27:53 --> Final output sent to browser
DEBUG - 2020-02-04 08:27:53 --> Total execution time: 0.5215
INFO - 2020-02-04 08:28:06 --> Config Class Initialized
INFO - 2020-02-04 08:28:06 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:28:06 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:28:06 --> Utf8 Class Initialized
INFO - 2020-02-04 08:28:06 --> URI Class Initialized
INFO - 2020-02-04 08:28:06 --> Router Class Initialized
INFO - 2020-02-04 08:28:06 --> Output Class Initialized
INFO - 2020-02-04 08:28:06 --> Security Class Initialized
DEBUG - 2020-02-04 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:28:07 --> Input Class Initialized
INFO - 2020-02-04 08:28:07 --> Language Class Initialized
INFO - 2020-02-04 08:28:07 --> Language Class Initialized
INFO - 2020-02-04 08:28:07 --> Config Class Initialized
INFO - 2020-02-04 08:28:07 --> Loader Class Initialized
INFO - 2020-02-04 08:28:07 --> Helper loaded: url_helper
INFO - 2020-02-04 08:28:07 --> Helper loaded: file_helper
INFO - 2020-02-04 08:28:07 --> Helper loaded: form_helper
INFO - 2020-02-04 08:28:07 --> Helper loaded: my_helper
INFO - 2020-02-04 08:28:07 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:28:07 --> Controller Class Initialized
DEBUG - 2020-02-04 08:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-02-04 08:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:28:07 --> Final output sent to browser
DEBUG - 2020-02-04 08:28:07 --> Total execution time: 0.4641
INFO - 2020-02-04 08:28:09 --> Config Class Initialized
INFO - 2020-02-04 08:28:09 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:28:09 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:28:09 --> Utf8 Class Initialized
INFO - 2020-02-04 08:28:09 --> URI Class Initialized
INFO - 2020-02-04 08:28:09 --> Router Class Initialized
INFO - 2020-02-04 08:28:09 --> Output Class Initialized
INFO - 2020-02-04 08:28:09 --> Security Class Initialized
DEBUG - 2020-02-04 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:28:09 --> Input Class Initialized
INFO - 2020-02-04 08:28:09 --> Language Class Initialized
INFO - 2020-02-04 08:28:09 --> Language Class Initialized
INFO - 2020-02-04 08:28:09 --> Config Class Initialized
INFO - 2020-02-04 08:28:09 --> Loader Class Initialized
INFO - 2020-02-04 08:28:09 --> Helper loaded: url_helper
INFO - 2020-02-04 08:28:09 --> Helper loaded: file_helper
INFO - 2020-02-04 08:28:09 --> Helper loaded: form_helper
INFO - 2020-02-04 08:28:09 --> Helper loaded: my_helper
INFO - 2020-02-04 08:28:09 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:28:09 --> Controller Class Initialized
DEBUG - 2020-02-04 08:28:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/cetak.php
INFO - 2020-02-04 08:28:10 --> Final output sent to browser
DEBUG - 2020-02-04 08:28:10 --> Total execution time: 1.0140
INFO - 2020-02-04 08:28:34 --> Config Class Initialized
INFO - 2020-02-04 08:28:35 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:28:35 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:28:35 --> Utf8 Class Initialized
INFO - 2020-02-04 08:28:35 --> URI Class Initialized
INFO - 2020-02-04 08:28:35 --> Router Class Initialized
INFO - 2020-02-04 08:28:35 --> Output Class Initialized
INFO - 2020-02-04 08:28:35 --> Security Class Initialized
DEBUG - 2020-02-04 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:28:35 --> Input Class Initialized
INFO - 2020-02-04 08:28:35 --> Language Class Initialized
INFO - 2020-02-04 08:28:35 --> Language Class Initialized
INFO - 2020-02-04 08:28:35 --> Config Class Initialized
INFO - 2020-02-04 08:28:35 --> Loader Class Initialized
INFO - 2020-02-04 08:28:35 --> Helper loaded: url_helper
INFO - 2020-02-04 08:28:35 --> Helper loaded: file_helper
INFO - 2020-02-04 08:28:35 --> Helper loaded: form_helper
INFO - 2020-02-04 08:28:35 --> Helper loaded: my_helper
INFO - 2020-02-04 08:28:35 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:28:35 --> Controller Class Initialized
DEBUG - 2020-02-04 08:28:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-02-04 08:28:35 --> Final output sent to browser
DEBUG - 2020-02-04 08:28:35 --> Total execution time: 0.4619
INFO - 2020-02-04 08:28:44 --> Config Class Initialized
INFO - 2020-02-04 08:28:44 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:28:44 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:28:44 --> Utf8 Class Initialized
INFO - 2020-02-04 08:28:44 --> URI Class Initialized
INFO - 2020-02-04 08:28:44 --> Router Class Initialized
INFO - 2020-02-04 08:28:44 --> Output Class Initialized
INFO - 2020-02-04 08:28:44 --> Security Class Initialized
DEBUG - 2020-02-04 08:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:28:44 --> Input Class Initialized
INFO - 2020-02-04 08:28:44 --> Language Class Initialized
INFO - 2020-02-04 08:28:44 --> Language Class Initialized
INFO - 2020-02-04 08:28:44 --> Config Class Initialized
INFO - 2020-02-04 08:28:44 --> Loader Class Initialized
INFO - 2020-02-04 08:28:44 --> Helper loaded: url_helper
INFO - 2020-02-04 08:28:44 --> Helper loaded: file_helper
INFO - 2020-02-04 08:28:44 --> Helper loaded: form_helper
INFO - 2020-02-04 08:28:44 --> Helper loaded: my_helper
INFO - 2020-02-04 08:28:44 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:28:44 --> Controller Class Initialized
DEBUG - 2020-02-04 08:28:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-04 08:28:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:28:44 --> Final output sent to browser
DEBUG - 2020-02-04 08:28:44 --> Total execution time: 0.4100
INFO - 2020-02-04 08:29:24 --> Config Class Initialized
INFO - 2020-02-04 08:29:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:29:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:29:24 --> Utf8 Class Initialized
INFO - 2020-02-04 08:29:24 --> URI Class Initialized
INFO - 2020-02-04 08:29:24 --> Router Class Initialized
INFO - 2020-02-04 08:29:24 --> Output Class Initialized
INFO - 2020-02-04 08:29:24 --> Security Class Initialized
DEBUG - 2020-02-04 08:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:29:24 --> Input Class Initialized
INFO - 2020-02-04 08:29:24 --> Language Class Initialized
INFO - 2020-02-04 08:29:24 --> Language Class Initialized
INFO - 2020-02-04 08:29:24 --> Config Class Initialized
INFO - 2020-02-04 08:29:24 --> Loader Class Initialized
INFO - 2020-02-04 08:29:24 --> Helper loaded: url_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: file_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: form_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: my_helper
INFO - 2020-02-04 08:29:24 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:29:24 --> Controller Class Initialized
INFO - 2020-02-04 08:29:24 --> Helper loaded: cookie_helper
INFO - 2020-02-04 08:29:24 --> Config Class Initialized
INFO - 2020-02-04 08:29:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:29:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:29:24 --> Utf8 Class Initialized
INFO - 2020-02-04 08:29:24 --> URI Class Initialized
INFO - 2020-02-04 08:29:24 --> Router Class Initialized
INFO - 2020-02-04 08:29:24 --> Output Class Initialized
INFO - 2020-02-04 08:29:24 --> Security Class Initialized
DEBUG - 2020-02-04 08:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:29:24 --> Input Class Initialized
INFO - 2020-02-04 08:29:24 --> Language Class Initialized
INFO - 2020-02-04 08:29:24 --> Language Class Initialized
INFO - 2020-02-04 08:29:24 --> Config Class Initialized
INFO - 2020-02-04 08:29:24 --> Loader Class Initialized
INFO - 2020-02-04 08:29:24 --> Helper loaded: url_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: file_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: form_helper
INFO - 2020-02-04 08:29:24 --> Helper loaded: my_helper
INFO - 2020-02-04 08:29:24 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:29:24 --> Controller Class Initialized
INFO - 2020-02-04 08:29:24 --> Config Class Initialized
INFO - 2020-02-04 08:29:24 --> Hooks Class Initialized
DEBUG - 2020-02-04 08:29:24 --> UTF-8 Support Enabled
INFO - 2020-02-04 08:29:24 --> Utf8 Class Initialized
INFO - 2020-02-04 08:29:24 --> URI Class Initialized
INFO - 2020-02-04 08:29:24 --> Router Class Initialized
INFO - 2020-02-04 08:29:25 --> Output Class Initialized
INFO - 2020-02-04 08:29:25 --> Security Class Initialized
DEBUG - 2020-02-04 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-04 08:29:25 --> Input Class Initialized
INFO - 2020-02-04 08:29:25 --> Language Class Initialized
INFO - 2020-02-04 08:29:25 --> Language Class Initialized
INFO - 2020-02-04 08:29:25 --> Config Class Initialized
INFO - 2020-02-04 08:29:25 --> Loader Class Initialized
INFO - 2020-02-04 08:29:25 --> Helper loaded: url_helper
INFO - 2020-02-04 08:29:25 --> Helper loaded: file_helper
INFO - 2020-02-04 08:29:25 --> Helper loaded: form_helper
INFO - 2020-02-04 08:29:25 --> Helper loaded: my_helper
INFO - 2020-02-04 08:29:25 --> Database Driver Class Initialized
DEBUG - 2020-02-04 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-04 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-04 08:29:25 --> Controller Class Initialized
DEBUG - 2020-02-04 08:29:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-04 08:29:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-04 08:29:25 --> Final output sent to browser
DEBUG - 2020-02-04 08:29:25 --> Total execution time: 0.4164
