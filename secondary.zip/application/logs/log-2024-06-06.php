<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-06 08:20:07 --> Config Class Initialized
INFO - 2024-06-06 08:20:07 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:07 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:07 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:07 --> URI Class Initialized
INFO - 2024-06-06 08:20:07 --> Router Class Initialized
INFO - 2024-06-06 08:20:07 --> Output Class Initialized
INFO - 2024-06-06 08:20:07 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:07 --> Input Class Initialized
INFO - 2024-06-06 08:20:07 --> Language Class Initialized
INFO - 2024-06-06 08:20:07 --> Language Class Initialized
INFO - 2024-06-06 08:20:07 --> Config Class Initialized
INFO - 2024-06-06 08:20:07 --> Loader Class Initialized
INFO - 2024-06-06 08:20:07 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:07 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:07 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:07 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:07 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:07 --> Controller Class Initialized
DEBUG - 2024-06-06 08:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-06 08:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 08:20:07 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:07 --> Total execution time: 0.0513
INFO - 2024-06-06 08:20:15 --> Config Class Initialized
INFO - 2024-06-06 08:20:15 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:15 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:15 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:15 --> URI Class Initialized
INFO - 2024-06-06 08:20:15 --> Router Class Initialized
INFO - 2024-06-06 08:20:15 --> Output Class Initialized
INFO - 2024-06-06 08:20:15 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:15 --> Input Class Initialized
INFO - 2024-06-06 08:20:15 --> Language Class Initialized
INFO - 2024-06-06 08:20:15 --> Language Class Initialized
INFO - 2024-06-06 08:20:15 --> Config Class Initialized
INFO - 2024-06-06 08:20:15 --> Loader Class Initialized
INFO - 2024-06-06 08:20:15 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:15 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:15 --> Controller Class Initialized
INFO - 2024-06-06 08:20:15 --> Helper loaded: cookie_helper
INFO - 2024-06-06 08:20:15 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:15 --> Total execution time: 0.0510
INFO - 2024-06-06 08:20:15 --> Config Class Initialized
INFO - 2024-06-06 08:20:15 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:15 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:15 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:15 --> URI Class Initialized
INFO - 2024-06-06 08:20:15 --> Router Class Initialized
INFO - 2024-06-06 08:20:15 --> Output Class Initialized
INFO - 2024-06-06 08:20:15 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:15 --> Input Class Initialized
INFO - 2024-06-06 08:20:15 --> Language Class Initialized
INFO - 2024-06-06 08:20:15 --> Language Class Initialized
INFO - 2024-06-06 08:20:15 --> Config Class Initialized
INFO - 2024-06-06 08:20:15 --> Loader Class Initialized
INFO - 2024-06-06 08:20:15 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:15 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:15 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:15 --> Controller Class Initialized
DEBUG - 2024-06-06 08:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-06 08:20:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 08:20:15 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:15 --> Total execution time: 0.0567
INFO - 2024-06-06 08:20:33 --> Config Class Initialized
INFO - 2024-06-06 08:20:33 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:33 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:33 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:33 --> URI Class Initialized
INFO - 2024-06-06 08:20:33 --> Router Class Initialized
INFO - 2024-06-06 08:20:33 --> Output Class Initialized
INFO - 2024-06-06 08:20:33 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:33 --> Input Class Initialized
INFO - 2024-06-06 08:20:33 --> Language Class Initialized
INFO - 2024-06-06 08:20:33 --> Language Class Initialized
INFO - 2024-06-06 08:20:33 --> Config Class Initialized
INFO - 2024-06-06 08:20:33 --> Loader Class Initialized
INFO - 2024-06-06 08:20:33 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:33 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:33 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:33 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:33 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:33 --> Controller Class Initialized
DEBUG - 2024-06-06 08:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 08:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 08:20:33 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:33 --> Total execution time: 0.0311
INFO - 2024-06-06 08:20:35 --> Config Class Initialized
INFO - 2024-06-06 08:20:35 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:35 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:35 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:35 --> URI Class Initialized
INFO - 2024-06-06 08:20:35 --> Router Class Initialized
INFO - 2024-06-06 08:20:35 --> Output Class Initialized
INFO - 2024-06-06 08:20:35 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:35 --> Input Class Initialized
INFO - 2024-06-06 08:20:35 --> Language Class Initialized
INFO - 2024-06-06 08:20:35 --> Language Class Initialized
INFO - 2024-06-06 08:20:35 --> Config Class Initialized
INFO - 2024-06-06 08:20:35 --> Loader Class Initialized
INFO - 2024-06-06 08:20:35 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:35 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:35 --> Controller Class Initialized
DEBUG - 2024-06-06 08:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-06 08:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 08:20:35 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:35 --> Total execution time: 0.1174
INFO - 2024-06-06 08:20:35 --> Config Class Initialized
INFO - 2024-06-06 08:20:35 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:35 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:35 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:35 --> URI Class Initialized
INFO - 2024-06-06 08:20:35 --> Router Class Initialized
INFO - 2024-06-06 08:20:35 --> Output Class Initialized
INFO - 2024-06-06 08:20:35 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:35 --> Input Class Initialized
INFO - 2024-06-06 08:20:35 --> Language Class Initialized
INFO - 2024-06-06 08:20:35 --> Language Class Initialized
INFO - 2024-06-06 08:20:35 --> Config Class Initialized
INFO - 2024-06-06 08:20:35 --> Loader Class Initialized
INFO - 2024-06-06 08:20:35 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:35 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:35 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:35 --> Controller Class Initialized
INFO - 2024-06-06 08:20:36 --> Config Class Initialized
INFO - 2024-06-06 08:20:36 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:36 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:36 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:36 --> URI Class Initialized
INFO - 2024-06-06 08:20:37 --> Router Class Initialized
INFO - 2024-06-06 08:20:37 --> Output Class Initialized
INFO - 2024-06-06 08:20:37 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:37 --> Input Class Initialized
INFO - 2024-06-06 08:20:37 --> Language Class Initialized
INFO - 2024-06-06 08:20:37 --> Language Class Initialized
INFO - 2024-06-06 08:20:37 --> Config Class Initialized
INFO - 2024-06-06 08:20:37 --> Loader Class Initialized
INFO - 2024-06-06 08:20:37 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:37 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:37 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:37 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:37 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:37 --> Controller Class Initialized
INFO - 2024-06-06 08:20:37 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:37 --> Total execution time: 0.0509
INFO - 2024-06-06 08:20:39 --> Config Class Initialized
INFO - 2024-06-06 08:20:39 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:39 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:39 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:39 --> URI Class Initialized
INFO - 2024-06-06 08:20:39 --> Router Class Initialized
INFO - 2024-06-06 08:20:39 --> Output Class Initialized
INFO - 2024-06-06 08:20:39 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:39 --> Input Class Initialized
INFO - 2024-06-06 08:20:39 --> Language Class Initialized
INFO - 2024-06-06 08:20:39 --> Language Class Initialized
INFO - 2024-06-06 08:20:39 --> Config Class Initialized
INFO - 2024-06-06 08:20:39 --> Loader Class Initialized
INFO - 2024-06-06 08:20:39 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:39 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:39 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:39 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:39 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:39 --> Controller Class Initialized
INFO - 2024-06-06 08:20:39 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:39 --> Total execution time: 0.0350
INFO - 2024-06-06 08:20:44 --> Config Class Initialized
INFO - 2024-06-06 08:20:44 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:44 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:44 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:44 --> URI Class Initialized
INFO - 2024-06-06 08:20:44 --> Router Class Initialized
INFO - 2024-06-06 08:20:44 --> Output Class Initialized
INFO - 2024-06-06 08:20:44 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:44 --> Input Class Initialized
INFO - 2024-06-06 08:20:44 --> Language Class Initialized
INFO - 2024-06-06 08:20:44 --> Language Class Initialized
INFO - 2024-06-06 08:20:44 --> Config Class Initialized
INFO - 2024-06-06 08:20:44 --> Loader Class Initialized
INFO - 2024-06-06 08:20:44 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:44 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:44 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:44 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:44 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:44 --> Controller Class Initialized
INFO - 2024-06-06 08:20:44 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:44 --> Total execution time: 0.0638
INFO - 2024-06-06 08:20:48 --> Config Class Initialized
INFO - 2024-06-06 08:20:48 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:48 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:48 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:48 --> URI Class Initialized
INFO - 2024-06-06 08:20:48 --> Router Class Initialized
INFO - 2024-06-06 08:20:48 --> Output Class Initialized
INFO - 2024-06-06 08:20:48 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:48 --> Input Class Initialized
INFO - 2024-06-06 08:20:48 --> Language Class Initialized
INFO - 2024-06-06 08:20:48 --> Language Class Initialized
INFO - 2024-06-06 08:20:48 --> Config Class Initialized
INFO - 2024-06-06 08:20:48 --> Loader Class Initialized
INFO - 2024-06-06 08:20:48 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:48 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:48 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:48 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:48 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:48 --> Controller Class Initialized
INFO - 2024-06-06 08:20:48 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:48 --> Total execution time: 0.0275
INFO - 2024-06-06 08:20:50 --> Config Class Initialized
INFO - 2024-06-06 08:20:50 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:50 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:50 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:50 --> URI Class Initialized
INFO - 2024-06-06 08:20:50 --> Router Class Initialized
INFO - 2024-06-06 08:20:50 --> Output Class Initialized
INFO - 2024-06-06 08:20:50 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:50 --> Input Class Initialized
INFO - 2024-06-06 08:20:50 --> Language Class Initialized
INFO - 2024-06-06 08:20:50 --> Language Class Initialized
INFO - 2024-06-06 08:20:50 --> Config Class Initialized
INFO - 2024-06-06 08:20:50 --> Loader Class Initialized
INFO - 2024-06-06 08:20:50 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:50 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:50 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:50 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:50 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:50 --> Controller Class Initialized
INFO - 2024-06-06 08:20:50 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:50 --> Total execution time: 0.0563
INFO - 2024-06-06 08:20:53 --> Config Class Initialized
INFO - 2024-06-06 08:20:53 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:53 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:53 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:53 --> URI Class Initialized
INFO - 2024-06-06 08:20:53 --> Router Class Initialized
INFO - 2024-06-06 08:20:53 --> Output Class Initialized
INFO - 2024-06-06 08:20:53 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:53 --> Input Class Initialized
INFO - 2024-06-06 08:20:53 --> Language Class Initialized
INFO - 2024-06-06 08:20:53 --> Language Class Initialized
INFO - 2024-06-06 08:20:53 --> Config Class Initialized
INFO - 2024-06-06 08:20:53 --> Loader Class Initialized
INFO - 2024-06-06 08:20:53 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:53 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:53 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:53 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:53 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:53 --> Controller Class Initialized
INFO - 2024-06-06 08:20:53 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:53 --> Total execution time: 0.0348
INFO - 2024-06-06 08:20:56 --> Config Class Initialized
INFO - 2024-06-06 08:20:56 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:56 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:56 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:56 --> URI Class Initialized
INFO - 2024-06-06 08:20:56 --> Router Class Initialized
INFO - 2024-06-06 08:20:56 --> Output Class Initialized
INFO - 2024-06-06 08:20:56 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:56 --> Input Class Initialized
INFO - 2024-06-06 08:20:56 --> Language Class Initialized
INFO - 2024-06-06 08:20:56 --> Language Class Initialized
INFO - 2024-06-06 08:20:56 --> Config Class Initialized
INFO - 2024-06-06 08:20:56 --> Loader Class Initialized
INFO - 2024-06-06 08:20:56 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:56 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:56 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:56 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:56 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:56 --> Controller Class Initialized
INFO - 2024-06-06 08:20:56 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:56 --> Total execution time: 0.0355
INFO - 2024-06-06 08:20:59 --> Config Class Initialized
INFO - 2024-06-06 08:20:59 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:20:59 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:20:59 --> Utf8 Class Initialized
INFO - 2024-06-06 08:20:59 --> URI Class Initialized
INFO - 2024-06-06 08:20:59 --> Router Class Initialized
INFO - 2024-06-06 08:20:59 --> Output Class Initialized
INFO - 2024-06-06 08:20:59 --> Security Class Initialized
DEBUG - 2024-06-06 08:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:20:59 --> Input Class Initialized
INFO - 2024-06-06 08:20:59 --> Language Class Initialized
INFO - 2024-06-06 08:20:59 --> Language Class Initialized
INFO - 2024-06-06 08:20:59 --> Config Class Initialized
INFO - 2024-06-06 08:20:59 --> Loader Class Initialized
INFO - 2024-06-06 08:20:59 --> Helper loaded: url_helper
INFO - 2024-06-06 08:20:59 --> Helper loaded: file_helper
INFO - 2024-06-06 08:20:59 --> Helper loaded: form_helper
INFO - 2024-06-06 08:20:59 --> Helper loaded: my_helper
INFO - 2024-06-06 08:20:59 --> Database Driver Class Initialized
INFO - 2024-06-06 08:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:20:59 --> Controller Class Initialized
INFO - 2024-06-06 08:20:59 --> Final output sent to browser
DEBUG - 2024-06-06 08:20:59 --> Total execution time: 0.0268
INFO - 2024-06-06 08:21:04 --> Config Class Initialized
INFO - 2024-06-06 08:21:04 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:21:04 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:21:04 --> Utf8 Class Initialized
INFO - 2024-06-06 08:21:04 --> URI Class Initialized
INFO - 2024-06-06 08:21:04 --> Router Class Initialized
INFO - 2024-06-06 08:21:04 --> Output Class Initialized
INFO - 2024-06-06 08:21:04 --> Security Class Initialized
DEBUG - 2024-06-06 08:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:21:04 --> Input Class Initialized
INFO - 2024-06-06 08:21:04 --> Language Class Initialized
INFO - 2024-06-06 08:21:04 --> Language Class Initialized
INFO - 2024-06-06 08:21:04 --> Config Class Initialized
INFO - 2024-06-06 08:21:04 --> Loader Class Initialized
INFO - 2024-06-06 08:21:04 --> Helper loaded: url_helper
INFO - 2024-06-06 08:21:04 --> Helper loaded: file_helper
INFO - 2024-06-06 08:21:04 --> Helper loaded: form_helper
INFO - 2024-06-06 08:21:04 --> Helper loaded: my_helper
INFO - 2024-06-06 08:21:04 --> Database Driver Class Initialized
INFO - 2024-06-06 08:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:21:04 --> Controller Class Initialized
INFO - 2024-06-06 08:21:04 --> Final output sent to browser
DEBUG - 2024-06-06 08:21:04 --> Total execution time: 0.0277
INFO - 2024-06-06 08:21:35 --> Config Class Initialized
INFO - 2024-06-06 08:21:35 --> Hooks Class Initialized
DEBUG - 2024-06-06 08:21:35 --> UTF-8 Support Enabled
INFO - 2024-06-06 08:21:35 --> Utf8 Class Initialized
INFO - 2024-06-06 08:21:35 --> URI Class Initialized
INFO - 2024-06-06 08:21:35 --> Router Class Initialized
INFO - 2024-06-06 08:21:35 --> Output Class Initialized
INFO - 2024-06-06 08:21:35 --> Security Class Initialized
DEBUG - 2024-06-06 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 08:21:35 --> Input Class Initialized
INFO - 2024-06-06 08:21:35 --> Language Class Initialized
INFO - 2024-06-06 08:21:35 --> Language Class Initialized
INFO - 2024-06-06 08:21:35 --> Config Class Initialized
INFO - 2024-06-06 08:21:35 --> Loader Class Initialized
INFO - 2024-06-06 08:21:35 --> Helper loaded: url_helper
INFO - 2024-06-06 08:21:35 --> Helper loaded: file_helper
INFO - 2024-06-06 08:21:35 --> Helper loaded: form_helper
INFO - 2024-06-06 08:21:35 --> Helper loaded: my_helper
INFO - 2024-06-06 08:21:35 --> Database Driver Class Initialized
INFO - 2024-06-06 08:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 08:21:35 --> Controller Class Initialized
DEBUG - 2024-06-06 08:21:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-06-06 08:21:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 08:21:35 --> Final output sent to browser
DEBUG - 2024-06-06 08:21:35 --> Total execution time: 0.0329
INFO - 2024-06-06 09:40:09 --> Config Class Initialized
INFO - 2024-06-06 09:40:09 --> Hooks Class Initialized
DEBUG - 2024-06-06 09:40:09 --> UTF-8 Support Enabled
INFO - 2024-06-06 09:40:09 --> Utf8 Class Initialized
INFO - 2024-06-06 09:40:09 --> URI Class Initialized
INFO - 2024-06-06 09:40:09 --> Router Class Initialized
INFO - 2024-06-06 09:40:09 --> Output Class Initialized
INFO - 2024-06-06 09:40:09 --> Security Class Initialized
DEBUG - 2024-06-06 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 09:40:09 --> Input Class Initialized
INFO - 2024-06-06 09:40:09 --> Language Class Initialized
INFO - 2024-06-06 09:40:09 --> Language Class Initialized
INFO - 2024-06-06 09:40:09 --> Config Class Initialized
INFO - 2024-06-06 09:40:09 --> Loader Class Initialized
INFO - 2024-06-06 09:40:09 --> Helper loaded: url_helper
INFO - 2024-06-06 09:40:09 --> Helper loaded: file_helper
INFO - 2024-06-06 09:40:09 --> Helper loaded: form_helper
INFO - 2024-06-06 09:40:09 --> Helper loaded: my_helper
INFO - 2024-06-06 09:40:09 --> Database Driver Class Initialized
INFO - 2024-06-06 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 09:40:09 --> Controller Class Initialized
DEBUG - 2024-06-06 09:40:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-06 09:40:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 09:40:09 --> Final output sent to browser
DEBUG - 2024-06-06 09:40:09 --> Total execution time: 0.0491
INFO - 2024-06-06 12:02:21 --> Config Class Initialized
INFO - 2024-06-06 12:02:21 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:02:21 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:02:21 --> Utf8 Class Initialized
INFO - 2024-06-06 12:02:21 --> URI Class Initialized
INFO - 2024-06-06 12:02:21 --> Router Class Initialized
INFO - 2024-06-06 12:02:21 --> Output Class Initialized
INFO - 2024-06-06 12:02:21 --> Security Class Initialized
DEBUG - 2024-06-06 12:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:02:21 --> Input Class Initialized
INFO - 2024-06-06 12:02:21 --> Language Class Initialized
INFO - 2024-06-06 12:02:21 --> Language Class Initialized
INFO - 2024-06-06 12:02:21 --> Config Class Initialized
INFO - 2024-06-06 12:02:21 --> Loader Class Initialized
INFO - 2024-06-06 12:02:21 --> Helper loaded: url_helper
INFO - 2024-06-06 12:02:21 --> Helper loaded: file_helper
INFO - 2024-06-06 12:02:21 --> Helper loaded: form_helper
INFO - 2024-06-06 12:02:21 --> Helper loaded: my_helper
INFO - 2024-06-06 12:02:21 --> Database Driver Class Initialized
INFO - 2024-06-06 12:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:02:21 --> Controller Class Initialized
ERROR - 2024-06-06 12:02:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/controllers/N_absensi.php 14
ERROR - 2024-06-06 12:02:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/controllers/N_absensi.php 15
INFO - 2024-06-06 12:02:21 --> Final output sent to browser
DEBUG - 2024-06-06 12:02:21 --> Total execution time: 0.0851
INFO - 2024-06-06 12:02:39 --> Config Class Initialized
INFO - 2024-06-06 12:02:39 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:02:39 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:02:39 --> Utf8 Class Initialized
INFO - 2024-06-06 12:02:39 --> URI Class Initialized
INFO - 2024-06-06 12:02:39 --> Router Class Initialized
INFO - 2024-06-06 12:02:39 --> Output Class Initialized
INFO - 2024-06-06 12:02:39 --> Security Class Initialized
DEBUG - 2024-06-06 12:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:02:39 --> Input Class Initialized
INFO - 2024-06-06 12:02:39 --> Language Class Initialized
INFO - 2024-06-06 12:02:39 --> Language Class Initialized
INFO - 2024-06-06 12:02:39 --> Config Class Initialized
INFO - 2024-06-06 12:02:39 --> Loader Class Initialized
INFO - 2024-06-06 12:02:39 --> Helper loaded: url_helper
INFO - 2024-06-06 12:02:39 --> Helper loaded: file_helper
INFO - 2024-06-06 12:02:39 --> Helper loaded: form_helper
INFO - 2024-06-06 12:02:39 --> Helper loaded: my_helper
INFO - 2024-06-06 12:02:39 --> Database Driver Class Initialized
INFO - 2024-06-06 12:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:02:39 --> Controller Class Initialized
ERROR - 2024-06-06 12:02:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/controllers/N_absensi.php 14
ERROR - 2024-06-06 12:02:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/controllers/N_absensi.php 15
DEBUG - 2024-06-06 12:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-06-06 12:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:02:39 --> Final output sent to browser
DEBUG - 2024-06-06 12:02:39 --> Total execution time: 0.0366
INFO - 2024-06-06 12:02:46 --> Config Class Initialized
INFO - 2024-06-06 12:02:46 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:02:46 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:02:46 --> Utf8 Class Initialized
INFO - 2024-06-06 12:02:46 --> URI Class Initialized
INFO - 2024-06-06 12:02:46 --> Router Class Initialized
INFO - 2024-06-06 12:02:46 --> Output Class Initialized
INFO - 2024-06-06 12:02:46 --> Security Class Initialized
DEBUG - 2024-06-06 12:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:02:46 --> Input Class Initialized
INFO - 2024-06-06 12:02:46 --> Language Class Initialized
INFO - 2024-06-06 12:02:46 --> Language Class Initialized
INFO - 2024-06-06 12:02:46 --> Config Class Initialized
INFO - 2024-06-06 12:02:46 --> Loader Class Initialized
INFO - 2024-06-06 12:02:46 --> Helper loaded: url_helper
INFO - 2024-06-06 12:02:46 --> Helper loaded: file_helper
INFO - 2024-06-06 12:02:46 --> Helper loaded: form_helper
INFO - 2024-06-06 12:02:46 --> Helper loaded: my_helper
INFO - 2024-06-06 12:02:46 --> Database Driver Class Initialized
INFO - 2024-06-06 12:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:02:46 --> Controller Class Initialized
DEBUG - 2024-06-06 12:02:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-06 12:02:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:02:46 --> Final output sent to browser
DEBUG - 2024-06-06 12:02:46 --> Total execution time: 0.0280
INFO - 2024-06-06 12:13:06 --> Config Class Initialized
INFO - 2024-06-06 12:13:06 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:13:06 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:13:06 --> Utf8 Class Initialized
INFO - 2024-06-06 12:13:06 --> URI Class Initialized
INFO - 2024-06-06 12:13:06 --> Router Class Initialized
INFO - 2024-06-06 12:13:06 --> Output Class Initialized
INFO - 2024-06-06 12:13:06 --> Security Class Initialized
DEBUG - 2024-06-06 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:13:06 --> Input Class Initialized
INFO - 2024-06-06 12:13:06 --> Language Class Initialized
INFO - 2024-06-06 12:13:06 --> Language Class Initialized
INFO - 2024-06-06 12:13:06 --> Config Class Initialized
INFO - 2024-06-06 12:13:06 --> Loader Class Initialized
INFO - 2024-06-06 12:13:06 --> Helper loaded: url_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: file_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: form_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: my_helper
INFO - 2024-06-06 12:13:06 --> Database Driver Class Initialized
INFO - 2024-06-06 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:13:06 --> Controller Class Initialized
INFO - 2024-06-06 12:13:06 --> Helper loaded: cookie_helper
INFO - 2024-06-06 12:13:06 --> Final output sent to browser
DEBUG - 2024-06-06 12:13:06 --> Total execution time: 0.0457
INFO - 2024-06-06 12:13:06 --> Config Class Initialized
INFO - 2024-06-06 12:13:06 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:13:06 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:13:06 --> Utf8 Class Initialized
INFO - 2024-06-06 12:13:06 --> URI Class Initialized
INFO - 2024-06-06 12:13:06 --> Router Class Initialized
INFO - 2024-06-06 12:13:06 --> Output Class Initialized
INFO - 2024-06-06 12:13:06 --> Security Class Initialized
DEBUG - 2024-06-06 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:13:06 --> Input Class Initialized
INFO - 2024-06-06 12:13:06 --> Language Class Initialized
INFO - 2024-06-06 12:13:06 --> Language Class Initialized
INFO - 2024-06-06 12:13:06 --> Config Class Initialized
INFO - 2024-06-06 12:13:06 --> Loader Class Initialized
INFO - 2024-06-06 12:13:06 --> Helper loaded: url_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: file_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: form_helper
INFO - 2024-06-06 12:13:06 --> Helper loaded: my_helper
INFO - 2024-06-06 12:13:06 --> Database Driver Class Initialized
INFO - 2024-06-06 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:13:06 --> Controller Class Initialized
DEBUG - 2024-06-06 12:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-06 12:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:13:06 --> Final output sent to browser
DEBUG - 2024-06-06 12:13:06 --> Total execution time: 0.0314
INFO - 2024-06-06 12:13:12 --> Config Class Initialized
INFO - 2024-06-06 12:13:12 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:13:12 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:13:12 --> Utf8 Class Initialized
INFO - 2024-06-06 12:13:12 --> URI Class Initialized
INFO - 2024-06-06 12:13:12 --> Router Class Initialized
INFO - 2024-06-06 12:13:12 --> Output Class Initialized
INFO - 2024-06-06 12:13:12 --> Security Class Initialized
DEBUG - 2024-06-06 12:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:13:12 --> Input Class Initialized
INFO - 2024-06-06 12:13:12 --> Language Class Initialized
INFO - 2024-06-06 12:13:12 --> Language Class Initialized
INFO - 2024-06-06 12:13:12 --> Config Class Initialized
INFO - 2024-06-06 12:13:12 --> Loader Class Initialized
INFO - 2024-06-06 12:13:12 --> Helper loaded: url_helper
INFO - 2024-06-06 12:13:12 --> Helper loaded: file_helper
INFO - 2024-06-06 12:13:12 --> Helper loaded: form_helper
INFO - 2024-06-06 12:13:12 --> Helper loaded: my_helper
INFO - 2024-06-06 12:13:12 --> Database Driver Class Initialized
INFO - 2024-06-06 12:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:13:12 --> Controller Class Initialized
DEBUG - 2024-06-06 12:13:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-06-06 12:13:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:13:12 --> Final output sent to browser
DEBUG - 2024-06-06 12:13:12 --> Total execution time: 0.0328
INFO - 2024-06-06 12:14:16 --> Config Class Initialized
INFO - 2024-06-06 12:14:16 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:14:16 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:14:16 --> Utf8 Class Initialized
INFO - 2024-06-06 12:14:16 --> URI Class Initialized
INFO - 2024-06-06 12:14:16 --> Router Class Initialized
INFO - 2024-06-06 12:14:16 --> Output Class Initialized
INFO - 2024-06-06 12:14:16 --> Security Class Initialized
DEBUG - 2024-06-06 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:14:16 --> Input Class Initialized
INFO - 2024-06-06 12:14:16 --> Language Class Initialized
INFO - 2024-06-06 12:14:16 --> Language Class Initialized
INFO - 2024-06-06 12:14:16 --> Config Class Initialized
INFO - 2024-06-06 12:14:16 --> Loader Class Initialized
INFO - 2024-06-06 12:14:16 --> Helper loaded: url_helper
INFO - 2024-06-06 12:14:16 --> Helper loaded: file_helper
INFO - 2024-06-06 12:14:16 --> Helper loaded: form_helper
INFO - 2024-06-06 12:14:16 --> Helper loaded: my_helper
INFO - 2024-06-06 12:14:16 --> Database Driver Class Initialized
INFO - 2024-06-06 12:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:14:16 --> Controller Class Initialized
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-06 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-06 12:14:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:14:16 --> Final output sent to browser
DEBUG - 2024-06-06 12:14:16 --> Total execution time: 0.0410
INFO - 2024-06-06 12:14:19 --> Config Class Initialized
INFO - 2024-06-06 12:14:19 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:14:19 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:14:19 --> Utf8 Class Initialized
INFO - 2024-06-06 12:14:19 --> URI Class Initialized
INFO - 2024-06-06 12:14:19 --> Router Class Initialized
INFO - 2024-06-06 12:14:19 --> Output Class Initialized
INFO - 2024-06-06 12:14:19 --> Security Class Initialized
DEBUG - 2024-06-06 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:14:19 --> Input Class Initialized
INFO - 2024-06-06 12:14:19 --> Language Class Initialized
INFO - 2024-06-06 12:14:19 --> Language Class Initialized
INFO - 2024-06-06 12:14:19 --> Config Class Initialized
INFO - 2024-06-06 12:14:19 --> Loader Class Initialized
INFO - 2024-06-06 12:14:19 --> Helper loaded: url_helper
INFO - 2024-06-06 12:14:19 --> Helper loaded: file_helper
INFO - 2024-06-06 12:14:19 --> Helper loaded: form_helper
INFO - 2024-06-06 12:14:19 --> Helper loaded: my_helper
INFO - 2024-06-06 12:14:19 --> Database Driver Class Initialized
INFO - 2024-06-06 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:14:19 --> Controller Class Initialized
DEBUG - 2024-06-06 12:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-06 12:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:14:19 --> Final output sent to browser
DEBUG - 2024-06-06 12:14:19 --> Total execution time: 0.0760
INFO - 2024-06-06 12:14:20 --> Config Class Initialized
INFO - 2024-06-06 12:14:20 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:14:20 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:14:20 --> Utf8 Class Initialized
INFO - 2024-06-06 12:14:20 --> URI Class Initialized
INFO - 2024-06-06 12:14:20 --> Router Class Initialized
INFO - 2024-06-06 12:14:20 --> Output Class Initialized
INFO - 2024-06-06 12:14:20 --> Security Class Initialized
DEBUG - 2024-06-06 12:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:14:20 --> Input Class Initialized
INFO - 2024-06-06 12:14:20 --> Language Class Initialized
INFO - 2024-06-06 12:14:20 --> Language Class Initialized
INFO - 2024-06-06 12:14:20 --> Config Class Initialized
INFO - 2024-06-06 12:14:20 --> Loader Class Initialized
INFO - 2024-06-06 12:14:20 --> Helper loaded: url_helper
INFO - 2024-06-06 12:14:20 --> Helper loaded: file_helper
INFO - 2024-06-06 12:14:20 --> Helper loaded: form_helper
INFO - 2024-06-06 12:14:20 --> Helper loaded: my_helper
INFO - 2024-06-06 12:14:20 --> Database Driver Class Initialized
INFO - 2024-06-06 12:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:14:20 --> Controller Class Initialized
INFO - 2024-06-06 12:14:22 --> Config Class Initialized
INFO - 2024-06-06 12:14:22 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:14:22 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:14:22 --> Utf8 Class Initialized
INFO - 2024-06-06 12:14:22 --> URI Class Initialized
INFO - 2024-06-06 12:14:22 --> Router Class Initialized
INFO - 2024-06-06 12:14:22 --> Output Class Initialized
INFO - 2024-06-06 12:14:22 --> Security Class Initialized
DEBUG - 2024-06-06 12:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:14:22 --> Input Class Initialized
INFO - 2024-06-06 12:14:22 --> Language Class Initialized
INFO - 2024-06-06 12:14:22 --> Language Class Initialized
INFO - 2024-06-06 12:14:22 --> Config Class Initialized
INFO - 2024-06-06 12:14:22 --> Loader Class Initialized
INFO - 2024-06-06 12:14:22 --> Helper loaded: url_helper
INFO - 2024-06-06 12:14:22 --> Helper loaded: file_helper
INFO - 2024-06-06 12:14:22 --> Helper loaded: form_helper
INFO - 2024-06-06 12:14:22 --> Helper loaded: my_helper
INFO - 2024-06-06 12:14:22 --> Database Driver Class Initialized
INFO - 2024-06-06 12:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:14:22 --> Controller Class Initialized
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-06 12:14:22 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-06 12:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-06 12:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:14:22 --> Final output sent to browser
DEBUG - 2024-06-06 12:14:22 --> Total execution time: 0.0299
INFO - 2024-06-06 12:15:51 --> Config Class Initialized
INFO - 2024-06-06 12:15:51 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:15:51 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:15:51 --> Utf8 Class Initialized
INFO - 2024-06-06 12:15:51 --> URI Class Initialized
INFO - 2024-06-06 12:15:51 --> Router Class Initialized
INFO - 2024-06-06 12:15:51 --> Output Class Initialized
INFO - 2024-06-06 12:15:51 --> Security Class Initialized
DEBUG - 2024-06-06 12:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:15:51 --> Input Class Initialized
INFO - 2024-06-06 12:15:51 --> Language Class Initialized
INFO - 2024-06-06 12:15:51 --> Language Class Initialized
INFO - 2024-06-06 12:15:51 --> Config Class Initialized
INFO - 2024-06-06 12:15:51 --> Loader Class Initialized
INFO - 2024-06-06 12:15:51 --> Helper loaded: url_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: file_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: form_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: my_helper
INFO - 2024-06-06 12:15:51 --> Database Driver Class Initialized
INFO - 2024-06-06 12:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:15:51 --> Controller Class Initialized
DEBUG - 2024-06-06 12:15:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-06 12:15:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:15:51 --> Final output sent to browser
DEBUG - 2024-06-06 12:15:51 --> Total execution time: 0.0390
INFO - 2024-06-06 12:15:51 --> Config Class Initialized
INFO - 2024-06-06 12:15:51 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:15:51 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:15:51 --> Utf8 Class Initialized
INFO - 2024-06-06 12:15:51 --> URI Class Initialized
INFO - 2024-06-06 12:15:51 --> Router Class Initialized
INFO - 2024-06-06 12:15:51 --> Output Class Initialized
INFO - 2024-06-06 12:15:51 --> Security Class Initialized
DEBUG - 2024-06-06 12:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:15:51 --> Input Class Initialized
INFO - 2024-06-06 12:15:51 --> Language Class Initialized
INFO - 2024-06-06 12:15:51 --> Language Class Initialized
INFO - 2024-06-06 12:15:51 --> Config Class Initialized
INFO - 2024-06-06 12:15:51 --> Loader Class Initialized
INFO - 2024-06-06 12:15:51 --> Helper loaded: url_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: file_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: form_helper
INFO - 2024-06-06 12:15:51 --> Helper loaded: my_helper
INFO - 2024-06-06 12:15:51 --> Database Driver Class Initialized
INFO - 2024-06-06 12:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:15:51 --> Controller Class Initialized
INFO - 2024-06-06 12:15:53 --> Config Class Initialized
INFO - 2024-06-06 12:15:53 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:15:53 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:15:53 --> Utf8 Class Initialized
INFO - 2024-06-06 12:15:53 --> URI Class Initialized
INFO - 2024-06-06 12:15:53 --> Router Class Initialized
INFO - 2024-06-06 12:15:53 --> Output Class Initialized
INFO - 2024-06-06 12:15:53 --> Security Class Initialized
DEBUG - 2024-06-06 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:15:53 --> Input Class Initialized
INFO - 2024-06-06 12:15:53 --> Language Class Initialized
INFO - 2024-06-06 12:15:53 --> Language Class Initialized
INFO - 2024-06-06 12:15:53 --> Config Class Initialized
INFO - 2024-06-06 12:15:53 --> Loader Class Initialized
INFO - 2024-06-06 12:15:53 --> Helper loaded: url_helper
INFO - 2024-06-06 12:15:53 --> Helper loaded: file_helper
INFO - 2024-06-06 12:15:53 --> Helper loaded: form_helper
INFO - 2024-06-06 12:15:53 --> Helper loaded: my_helper
INFO - 2024-06-06 12:15:53 --> Database Driver Class Initialized
INFO - 2024-06-06 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:15:53 --> Controller Class Initialized
INFO - 2024-06-06 12:15:53 --> Final output sent to browser
DEBUG - 2024-06-06 12:15:53 --> Total execution time: 0.0265
INFO - 2024-06-06 12:20:07 --> Config Class Initialized
INFO - 2024-06-06 12:20:07 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:07 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:07 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:07 --> URI Class Initialized
INFO - 2024-06-06 12:20:07 --> Router Class Initialized
INFO - 2024-06-06 12:20:07 --> Output Class Initialized
INFO - 2024-06-06 12:20:07 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:07 --> Input Class Initialized
INFO - 2024-06-06 12:20:07 --> Language Class Initialized
INFO - 2024-06-06 12:20:07 --> Language Class Initialized
INFO - 2024-06-06 12:20:07 --> Config Class Initialized
INFO - 2024-06-06 12:20:07 --> Loader Class Initialized
INFO - 2024-06-06 12:20:07 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:07 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:07 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:07 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:07 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:07 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-06-06 12:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:20:07 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:07 --> Total execution time: 0.0416
INFO - 2024-06-06 12:20:10 --> Config Class Initialized
INFO - 2024-06-06 12:20:10 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:10 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:10 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:10 --> URI Class Initialized
INFO - 2024-06-06 12:20:10 --> Router Class Initialized
INFO - 2024-06-06 12:20:10 --> Output Class Initialized
INFO - 2024-06-06 12:20:10 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:10 --> Input Class Initialized
INFO - 2024-06-06 12:20:10 --> Language Class Initialized
INFO - 2024-06-06 12:20:10 --> Language Class Initialized
INFO - 2024-06-06 12:20:10 --> Config Class Initialized
INFO - 2024-06-06 12:20:10 --> Loader Class Initialized
INFO - 2024-06-06 12:20:10 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:10 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:10 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:10 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:10 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:10 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-06-06 12:20:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:20:10 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:10 --> Total execution time: 0.0407
INFO - 2024-06-06 12:20:12 --> Config Class Initialized
INFO - 2024-06-06 12:20:12 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:12 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:12 --> URI Class Initialized
INFO - 2024-06-06 12:20:12 --> Router Class Initialized
INFO - 2024-06-06 12:20:12 --> Output Class Initialized
INFO - 2024-06-06 12:20:12 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:12 --> Input Class Initialized
INFO - 2024-06-06 12:20:12 --> Language Class Initialized
INFO - 2024-06-06 12:20:12 --> Language Class Initialized
INFO - 2024-06-06 12:20:12 --> Config Class Initialized
INFO - 2024-06-06 12:20:12 --> Loader Class Initialized
INFO - 2024-06-06 12:20:12 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:12 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:12 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:12 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:12 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:12 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-06 12:20:15 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:15 --> Total execution time: 2.9006
INFO - 2024-06-06 12:20:24 --> Config Class Initialized
INFO - 2024-06-06 12:20:24 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:24 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:24 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:24 --> URI Class Initialized
INFO - 2024-06-06 12:20:24 --> Router Class Initialized
INFO - 2024-06-06 12:20:24 --> Output Class Initialized
INFO - 2024-06-06 12:20:24 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:24 --> Input Class Initialized
INFO - 2024-06-06 12:20:24 --> Language Class Initialized
INFO - 2024-06-06 12:20:24 --> Language Class Initialized
INFO - 2024-06-06 12:20:24 --> Config Class Initialized
INFO - 2024-06-06 12:20:24 --> Loader Class Initialized
INFO - 2024-06-06 12:20:24 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:24 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:24 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:24 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:24 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:24 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_leger/views/landing.php
DEBUG - 2024-06-06 12:20:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:20:24 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:24 --> Total execution time: 0.0345
INFO - 2024-06-06 12:20:28 --> Config Class Initialized
INFO - 2024-06-06 12:20:28 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:28 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:28 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:28 --> URI Class Initialized
INFO - 2024-06-06 12:20:28 --> Router Class Initialized
INFO - 2024-06-06 12:20:28 --> Output Class Initialized
INFO - 2024-06-06 12:20:28 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:28 --> Input Class Initialized
INFO - 2024-06-06 12:20:28 --> Language Class Initialized
INFO - 2024-06-06 12:20:28 --> Language Class Initialized
INFO - 2024-06-06 12:20:28 --> Config Class Initialized
INFO - 2024-06-06 12:20:28 --> Loader Class Initialized
INFO - 2024-06-06 12:20:28 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:28 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:28 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:28 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:28 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:28 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-06 12:20:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:20:28 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:28 --> Total execution time: 0.1421
INFO - 2024-06-06 12:20:33 --> Config Class Initialized
INFO - 2024-06-06 12:20:33 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:33 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:33 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:33 --> URI Class Initialized
INFO - 2024-06-06 12:20:33 --> Router Class Initialized
INFO - 2024-06-06 12:20:33 --> Output Class Initialized
INFO - 2024-06-06 12:20:33 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:33 --> Input Class Initialized
INFO - 2024-06-06 12:20:33 --> Language Class Initialized
INFO - 2024-06-06 12:20:33 --> Language Class Initialized
INFO - 2024-06-06 12:20:33 --> Config Class Initialized
INFO - 2024-06-06 12:20:33 --> Loader Class Initialized
INFO - 2024-06-06 12:20:33 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:33 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:33 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:33 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:33 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:33 --> Controller Class Initialized
ERROR - 2024-06-06 12:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 459
ERROR - 2024-06-06 12:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 460
ERROR - 2024-06-06 12:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 240
ERROR - 2024-06-06 12:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 258
DEBUG - 2024-06-06 12:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-06 12:20:35 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:35 --> Total execution time: 1.9072
INFO - 2024-06-06 12:20:42 --> Config Class Initialized
INFO - 2024-06-06 12:20:42 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:42 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:42 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:42 --> URI Class Initialized
INFO - 2024-06-06 12:20:42 --> Router Class Initialized
INFO - 2024-06-06 12:20:42 --> Output Class Initialized
INFO - 2024-06-06 12:20:42 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:42 --> Input Class Initialized
INFO - 2024-06-06 12:20:42 --> Language Class Initialized
INFO - 2024-06-06 12:20:42 --> Language Class Initialized
INFO - 2024-06-06 12:20:42 --> Config Class Initialized
INFO - 2024-06-06 12:20:42 --> Loader Class Initialized
INFO - 2024-06-06 12:20:42 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:42 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:42 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:42 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:42 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:42 --> Controller Class Initialized
DEBUG - 2024-06-06 12:20:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-06-06 12:20:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:20:42 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:42 --> Total execution time: 0.1142
INFO - 2024-06-06 12:20:46 --> Config Class Initialized
INFO - 2024-06-06 12:20:46 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:46 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:46 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:46 --> URI Class Initialized
INFO - 2024-06-06 12:20:46 --> Router Class Initialized
INFO - 2024-06-06 12:20:46 --> Output Class Initialized
INFO - 2024-06-06 12:20:46 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:46 --> Input Class Initialized
INFO - 2024-06-06 12:20:46 --> Language Class Initialized
INFO - 2024-06-06 12:20:46 --> Language Class Initialized
INFO - 2024-06-06 12:20:46 --> Config Class Initialized
INFO - 2024-06-06 12:20:46 --> Loader Class Initialized
INFO - 2024-06-06 12:20:46 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:46 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:46 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:46 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:46 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:46 --> Controller Class Initialized
INFO - 2024-06-06 12:20:46 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:46 --> Total execution time: 0.0303
INFO - 2024-06-06 12:20:50 --> Config Class Initialized
INFO - 2024-06-06 12:20:50 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:20:50 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:20:50 --> Utf8 Class Initialized
INFO - 2024-06-06 12:20:50 --> URI Class Initialized
INFO - 2024-06-06 12:20:50 --> Router Class Initialized
INFO - 2024-06-06 12:20:50 --> Output Class Initialized
INFO - 2024-06-06 12:20:50 --> Security Class Initialized
DEBUG - 2024-06-06 12:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:20:50 --> Input Class Initialized
INFO - 2024-06-06 12:20:50 --> Language Class Initialized
INFO - 2024-06-06 12:20:50 --> Language Class Initialized
INFO - 2024-06-06 12:20:50 --> Config Class Initialized
INFO - 2024-06-06 12:20:50 --> Loader Class Initialized
INFO - 2024-06-06 12:20:50 --> Helper loaded: url_helper
INFO - 2024-06-06 12:20:50 --> Helper loaded: file_helper
INFO - 2024-06-06 12:20:50 --> Helper loaded: form_helper
INFO - 2024-06-06 12:20:50 --> Helper loaded: my_helper
INFO - 2024-06-06 12:20:50 --> Database Driver Class Initialized
INFO - 2024-06-06 12:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:20:50 --> Controller Class Initialized
INFO - 2024-06-06 12:20:50 --> Final output sent to browser
DEBUG - 2024-06-06 12:20:50 --> Total execution time: 0.0283
INFO - 2024-06-06 12:21:00 --> Config Class Initialized
INFO - 2024-06-06 12:21:00 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:00 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:00 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:00 --> URI Class Initialized
INFO - 2024-06-06 12:21:00 --> Router Class Initialized
INFO - 2024-06-06 12:21:00 --> Output Class Initialized
INFO - 2024-06-06 12:21:00 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:00 --> Input Class Initialized
INFO - 2024-06-06 12:21:00 --> Language Class Initialized
INFO - 2024-06-06 12:21:00 --> Language Class Initialized
INFO - 2024-06-06 12:21:00 --> Config Class Initialized
INFO - 2024-06-06 12:21:00 --> Loader Class Initialized
INFO - 2024-06-06 12:21:00 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:00 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:00 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:00 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:00 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:00 --> Controller Class Initialized
INFO - 2024-06-06 12:21:00 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:00 --> Total execution time: 0.0316
INFO - 2024-06-06 12:21:02 --> Config Class Initialized
INFO - 2024-06-06 12:21:02 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:02 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:02 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:02 --> URI Class Initialized
INFO - 2024-06-06 12:21:02 --> Router Class Initialized
INFO - 2024-06-06 12:21:02 --> Output Class Initialized
INFO - 2024-06-06 12:21:02 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:02 --> Input Class Initialized
INFO - 2024-06-06 12:21:02 --> Language Class Initialized
INFO - 2024-06-06 12:21:02 --> Language Class Initialized
INFO - 2024-06-06 12:21:02 --> Config Class Initialized
INFO - 2024-06-06 12:21:02 --> Loader Class Initialized
INFO - 2024-06-06 12:21:02 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:02 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:02 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:02 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:02 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:02 --> Controller Class Initialized
INFO - 2024-06-06 12:21:02 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:02 --> Total execution time: 0.0301
INFO - 2024-06-06 12:21:09 --> Config Class Initialized
INFO - 2024-06-06 12:21:09 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:09 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:09 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:09 --> URI Class Initialized
INFO - 2024-06-06 12:21:09 --> Router Class Initialized
INFO - 2024-06-06 12:21:09 --> Output Class Initialized
INFO - 2024-06-06 12:21:09 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:09 --> Input Class Initialized
INFO - 2024-06-06 12:21:09 --> Language Class Initialized
INFO - 2024-06-06 12:21:09 --> Language Class Initialized
INFO - 2024-06-06 12:21:09 --> Config Class Initialized
INFO - 2024-06-06 12:21:09 --> Loader Class Initialized
INFO - 2024-06-06 12:21:09 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:09 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:09 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:09 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:09 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:09 --> Controller Class Initialized
INFO - 2024-06-06 12:21:09 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:09 --> Total execution time: 0.0517
INFO - 2024-06-06 12:21:11 --> Config Class Initialized
INFO - 2024-06-06 12:21:11 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:11 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:11 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:11 --> URI Class Initialized
INFO - 2024-06-06 12:21:11 --> Router Class Initialized
INFO - 2024-06-06 12:21:11 --> Output Class Initialized
INFO - 2024-06-06 12:21:11 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:11 --> Input Class Initialized
INFO - 2024-06-06 12:21:11 --> Language Class Initialized
INFO - 2024-06-06 12:21:11 --> Language Class Initialized
INFO - 2024-06-06 12:21:11 --> Config Class Initialized
INFO - 2024-06-06 12:21:11 --> Loader Class Initialized
INFO - 2024-06-06 12:21:11 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:11 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:11 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:11 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:11 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:11 --> Controller Class Initialized
INFO - 2024-06-06 12:21:11 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:11 --> Total execution time: 0.0255
INFO - 2024-06-06 12:21:12 --> Config Class Initialized
INFO - 2024-06-06 12:21:12 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:12 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:12 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:12 --> URI Class Initialized
INFO - 2024-06-06 12:21:12 --> Router Class Initialized
INFO - 2024-06-06 12:21:12 --> Output Class Initialized
INFO - 2024-06-06 12:21:12 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:12 --> Input Class Initialized
INFO - 2024-06-06 12:21:12 --> Language Class Initialized
INFO - 2024-06-06 12:21:12 --> Language Class Initialized
INFO - 2024-06-06 12:21:12 --> Config Class Initialized
INFO - 2024-06-06 12:21:12 --> Loader Class Initialized
INFO - 2024-06-06 12:21:12 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:12 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:12 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:12 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:12 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:12 --> Controller Class Initialized
INFO - 2024-06-06 12:21:12 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:12 --> Total execution time: 0.0252
INFO - 2024-06-06 12:21:13 --> Config Class Initialized
INFO - 2024-06-06 12:21:13 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:13 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:13 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:13 --> URI Class Initialized
INFO - 2024-06-06 12:21:13 --> Router Class Initialized
INFO - 2024-06-06 12:21:13 --> Output Class Initialized
INFO - 2024-06-06 12:21:13 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:13 --> Input Class Initialized
INFO - 2024-06-06 12:21:13 --> Language Class Initialized
INFO - 2024-06-06 12:21:13 --> Language Class Initialized
INFO - 2024-06-06 12:21:13 --> Config Class Initialized
INFO - 2024-06-06 12:21:13 --> Loader Class Initialized
INFO - 2024-06-06 12:21:13 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:13 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:13 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:13 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:13 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:13 --> Controller Class Initialized
INFO - 2024-06-06 12:21:13 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:13 --> Total execution time: 0.0255
INFO - 2024-06-06 12:21:14 --> Config Class Initialized
INFO - 2024-06-06 12:21:14 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:14 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:14 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:14 --> URI Class Initialized
INFO - 2024-06-06 12:21:14 --> Router Class Initialized
INFO - 2024-06-06 12:21:14 --> Output Class Initialized
INFO - 2024-06-06 12:21:14 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:14 --> Input Class Initialized
INFO - 2024-06-06 12:21:14 --> Language Class Initialized
INFO - 2024-06-06 12:21:14 --> Language Class Initialized
INFO - 2024-06-06 12:21:14 --> Config Class Initialized
INFO - 2024-06-06 12:21:14 --> Loader Class Initialized
INFO - 2024-06-06 12:21:14 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:14 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:14 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:14 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:14 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:14 --> Controller Class Initialized
INFO - 2024-06-06 12:21:14 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:14 --> Total execution time: 0.0320
INFO - 2024-06-06 12:21:19 --> Config Class Initialized
INFO - 2024-06-06 12:21:19 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:19 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:19 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:19 --> URI Class Initialized
INFO - 2024-06-06 12:21:19 --> Router Class Initialized
INFO - 2024-06-06 12:21:19 --> Output Class Initialized
INFO - 2024-06-06 12:21:19 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:19 --> Input Class Initialized
INFO - 2024-06-06 12:21:19 --> Language Class Initialized
INFO - 2024-06-06 12:21:19 --> Language Class Initialized
INFO - 2024-06-06 12:21:19 --> Config Class Initialized
INFO - 2024-06-06 12:21:19 --> Loader Class Initialized
INFO - 2024-06-06 12:21:19 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:19 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:19 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:19 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:19 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:19 --> Controller Class Initialized
DEBUG - 2024-06-06 12:21:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 12:21:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:21:19 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:19 --> Total execution time: 0.0367
INFO - 2024-06-06 12:21:20 --> Config Class Initialized
INFO - 2024-06-06 12:21:20 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:20 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:20 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:20 --> URI Class Initialized
INFO - 2024-06-06 12:21:20 --> Router Class Initialized
INFO - 2024-06-06 12:21:20 --> Output Class Initialized
INFO - 2024-06-06 12:21:20 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:20 --> Input Class Initialized
INFO - 2024-06-06 12:21:20 --> Language Class Initialized
INFO - 2024-06-06 12:21:20 --> Language Class Initialized
INFO - 2024-06-06 12:21:20 --> Config Class Initialized
INFO - 2024-06-06 12:21:20 --> Loader Class Initialized
INFO - 2024-06-06 12:21:20 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:20 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:20 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:20 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:20 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:20 --> Controller Class Initialized
DEBUG - 2024-06-06 12:21:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-06-06 12:21:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:21:20 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:20 --> Total execution time: 0.1244
INFO - 2024-06-06 12:21:21 --> Config Class Initialized
INFO - 2024-06-06 12:21:21 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:21 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:21 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:21 --> URI Class Initialized
INFO - 2024-06-06 12:21:21 --> Router Class Initialized
INFO - 2024-06-06 12:21:21 --> Output Class Initialized
INFO - 2024-06-06 12:21:21 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:21 --> Input Class Initialized
INFO - 2024-06-06 12:21:21 --> Language Class Initialized
INFO - 2024-06-06 12:21:21 --> Language Class Initialized
INFO - 2024-06-06 12:21:21 --> Config Class Initialized
INFO - 2024-06-06 12:21:21 --> Loader Class Initialized
INFO - 2024-06-06 12:21:21 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:21 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:21 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:21 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:21 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:21 --> Controller Class Initialized
INFO - 2024-06-06 12:21:22 --> Config Class Initialized
INFO - 2024-06-06 12:21:22 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:22 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:22 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:22 --> URI Class Initialized
INFO - 2024-06-06 12:21:22 --> Router Class Initialized
INFO - 2024-06-06 12:21:22 --> Output Class Initialized
INFO - 2024-06-06 12:21:22 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:22 --> Input Class Initialized
INFO - 2024-06-06 12:21:22 --> Language Class Initialized
INFO - 2024-06-06 12:21:22 --> Language Class Initialized
INFO - 2024-06-06 12:21:22 --> Config Class Initialized
INFO - 2024-06-06 12:21:22 --> Loader Class Initialized
INFO - 2024-06-06 12:21:22 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:22 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:22 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:22 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:22 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:22 --> Controller Class Initialized
INFO - 2024-06-06 12:21:22 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:22 --> Total execution time: 0.0329
INFO - 2024-06-06 12:21:25 --> Config Class Initialized
INFO - 2024-06-06 12:21:25 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:25 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:25 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:25 --> URI Class Initialized
INFO - 2024-06-06 12:21:25 --> Router Class Initialized
INFO - 2024-06-06 12:21:25 --> Output Class Initialized
INFO - 2024-06-06 12:21:25 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:25 --> Input Class Initialized
INFO - 2024-06-06 12:21:25 --> Language Class Initialized
INFO - 2024-06-06 12:21:25 --> Language Class Initialized
INFO - 2024-06-06 12:21:25 --> Config Class Initialized
INFO - 2024-06-06 12:21:25 --> Loader Class Initialized
INFO - 2024-06-06 12:21:25 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:25 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:25 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:25 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:25 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:25 --> Controller Class Initialized
INFO - 2024-06-06 12:21:25 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:25 --> Total execution time: 0.0310
INFO - 2024-06-06 12:21:27 --> Config Class Initialized
INFO - 2024-06-06 12:21:27 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:27 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:27 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:27 --> URI Class Initialized
INFO - 2024-06-06 12:21:27 --> Router Class Initialized
INFO - 2024-06-06 12:21:27 --> Output Class Initialized
INFO - 2024-06-06 12:21:27 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:27 --> Input Class Initialized
INFO - 2024-06-06 12:21:27 --> Language Class Initialized
INFO - 2024-06-06 12:21:27 --> Language Class Initialized
INFO - 2024-06-06 12:21:27 --> Config Class Initialized
INFO - 2024-06-06 12:21:27 --> Loader Class Initialized
INFO - 2024-06-06 12:21:27 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:27 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:27 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:27 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:27 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:27 --> Controller Class Initialized
INFO - 2024-06-06 12:21:27 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:27 --> Total execution time: 0.0285
INFO - 2024-06-06 12:21:34 --> Config Class Initialized
INFO - 2024-06-06 12:21:34 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:34 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:34 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:34 --> URI Class Initialized
INFO - 2024-06-06 12:21:34 --> Router Class Initialized
INFO - 2024-06-06 12:21:34 --> Output Class Initialized
INFO - 2024-06-06 12:21:34 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:34 --> Input Class Initialized
INFO - 2024-06-06 12:21:34 --> Language Class Initialized
INFO - 2024-06-06 12:21:34 --> Language Class Initialized
INFO - 2024-06-06 12:21:34 --> Config Class Initialized
INFO - 2024-06-06 12:21:34 --> Loader Class Initialized
INFO - 2024-06-06 12:21:34 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:34 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:34 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:34 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:34 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:34 --> Controller Class Initialized
INFO - 2024-06-06 12:21:34 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:34 --> Total execution time: 0.0286
INFO - 2024-06-06 12:21:36 --> Config Class Initialized
INFO - 2024-06-06 12:21:36 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:36 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:36 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:36 --> URI Class Initialized
INFO - 2024-06-06 12:21:36 --> Router Class Initialized
INFO - 2024-06-06 12:21:36 --> Output Class Initialized
INFO - 2024-06-06 12:21:36 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:36 --> Input Class Initialized
INFO - 2024-06-06 12:21:36 --> Language Class Initialized
INFO - 2024-06-06 12:21:36 --> Language Class Initialized
INFO - 2024-06-06 12:21:36 --> Config Class Initialized
INFO - 2024-06-06 12:21:36 --> Loader Class Initialized
INFO - 2024-06-06 12:21:36 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:36 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:36 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:36 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:36 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:36 --> Controller Class Initialized
INFO - 2024-06-06 12:21:36 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:36 --> Total execution time: 0.0297
INFO - 2024-06-06 12:21:37 --> Config Class Initialized
INFO - 2024-06-06 12:21:37 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:37 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:37 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:37 --> URI Class Initialized
INFO - 2024-06-06 12:21:37 --> Router Class Initialized
INFO - 2024-06-06 12:21:37 --> Output Class Initialized
INFO - 2024-06-06 12:21:37 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:37 --> Input Class Initialized
INFO - 2024-06-06 12:21:37 --> Language Class Initialized
INFO - 2024-06-06 12:21:37 --> Language Class Initialized
INFO - 2024-06-06 12:21:37 --> Config Class Initialized
INFO - 2024-06-06 12:21:37 --> Loader Class Initialized
INFO - 2024-06-06 12:21:37 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:37 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:37 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:37 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:37 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:37 --> Controller Class Initialized
INFO - 2024-06-06 12:21:37 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:37 --> Total execution time: 0.0340
INFO - 2024-06-06 12:21:59 --> Config Class Initialized
INFO - 2024-06-06 12:21:59 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:21:59 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:21:59 --> Utf8 Class Initialized
INFO - 2024-06-06 12:21:59 --> URI Class Initialized
INFO - 2024-06-06 12:21:59 --> Router Class Initialized
INFO - 2024-06-06 12:21:59 --> Output Class Initialized
INFO - 2024-06-06 12:21:59 --> Security Class Initialized
DEBUG - 2024-06-06 12:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:21:59 --> Input Class Initialized
INFO - 2024-06-06 12:21:59 --> Language Class Initialized
INFO - 2024-06-06 12:21:59 --> Language Class Initialized
INFO - 2024-06-06 12:21:59 --> Config Class Initialized
INFO - 2024-06-06 12:21:59 --> Loader Class Initialized
INFO - 2024-06-06 12:21:59 --> Helper loaded: url_helper
INFO - 2024-06-06 12:21:59 --> Helper loaded: file_helper
INFO - 2024-06-06 12:21:59 --> Helper loaded: form_helper
INFO - 2024-06-06 12:21:59 --> Helper loaded: my_helper
INFO - 2024-06-06 12:21:59 --> Database Driver Class Initialized
INFO - 2024-06-06 12:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:21:59 --> Controller Class Initialized
INFO - 2024-06-06 12:21:59 --> Final output sent to browser
DEBUG - 2024-06-06 12:21:59 --> Total execution time: 0.0499
INFO - 2024-06-06 12:22:02 --> Config Class Initialized
INFO - 2024-06-06 12:22:02 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:22:02 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:22:02 --> Utf8 Class Initialized
INFO - 2024-06-06 12:22:02 --> URI Class Initialized
INFO - 2024-06-06 12:22:02 --> Router Class Initialized
INFO - 2024-06-06 12:22:02 --> Output Class Initialized
INFO - 2024-06-06 12:22:02 --> Security Class Initialized
DEBUG - 2024-06-06 12:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:22:02 --> Input Class Initialized
INFO - 2024-06-06 12:22:02 --> Language Class Initialized
INFO - 2024-06-06 12:22:02 --> Language Class Initialized
INFO - 2024-06-06 12:22:02 --> Config Class Initialized
INFO - 2024-06-06 12:22:02 --> Loader Class Initialized
INFO - 2024-06-06 12:22:02 --> Helper loaded: url_helper
INFO - 2024-06-06 12:22:02 --> Helper loaded: file_helper
INFO - 2024-06-06 12:22:02 --> Helper loaded: form_helper
INFO - 2024-06-06 12:22:02 --> Helper loaded: my_helper
INFO - 2024-06-06 12:22:02 --> Database Driver Class Initialized
INFO - 2024-06-06 12:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:22:02 --> Controller Class Initialized
INFO - 2024-06-06 12:22:02 --> Final output sent to browser
DEBUG - 2024-06-06 12:22:02 --> Total execution time: 0.0344
INFO - 2024-06-06 12:22:09 --> Config Class Initialized
INFO - 2024-06-06 12:22:09 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:22:09 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:22:09 --> Utf8 Class Initialized
INFO - 2024-06-06 12:22:09 --> URI Class Initialized
INFO - 2024-06-06 12:22:09 --> Router Class Initialized
INFO - 2024-06-06 12:22:09 --> Output Class Initialized
INFO - 2024-06-06 12:22:09 --> Security Class Initialized
DEBUG - 2024-06-06 12:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:22:09 --> Input Class Initialized
INFO - 2024-06-06 12:22:09 --> Language Class Initialized
INFO - 2024-06-06 12:22:09 --> Language Class Initialized
INFO - 2024-06-06 12:22:09 --> Config Class Initialized
INFO - 2024-06-06 12:22:09 --> Loader Class Initialized
INFO - 2024-06-06 12:22:09 --> Helper loaded: url_helper
INFO - 2024-06-06 12:22:09 --> Helper loaded: file_helper
INFO - 2024-06-06 12:22:09 --> Helper loaded: form_helper
INFO - 2024-06-06 12:22:09 --> Helper loaded: my_helper
INFO - 2024-06-06 12:22:09 --> Database Driver Class Initialized
INFO - 2024-06-06 12:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:22:09 --> Controller Class Initialized
INFO - 2024-06-06 12:22:09 --> Final output sent to browser
DEBUG - 2024-06-06 12:22:09 --> Total execution time: 0.0505
INFO - 2024-06-06 12:22:16 --> Config Class Initialized
INFO - 2024-06-06 12:22:16 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:22:16 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:22:16 --> Utf8 Class Initialized
INFO - 2024-06-06 12:22:16 --> URI Class Initialized
INFO - 2024-06-06 12:22:16 --> Router Class Initialized
INFO - 2024-06-06 12:22:16 --> Output Class Initialized
INFO - 2024-06-06 12:22:16 --> Security Class Initialized
DEBUG - 2024-06-06 12:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:22:16 --> Input Class Initialized
INFO - 2024-06-06 12:22:16 --> Language Class Initialized
INFO - 2024-06-06 12:22:16 --> Language Class Initialized
INFO - 2024-06-06 12:22:16 --> Config Class Initialized
INFO - 2024-06-06 12:22:16 --> Loader Class Initialized
INFO - 2024-06-06 12:22:16 --> Helper loaded: url_helper
INFO - 2024-06-06 12:22:16 --> Helper loaded: file_helper
INFO - 2024-06-06 12:22:16 --> Helper loaded: form_helper
INFO - 2024-06-06 12:22:16 --> Helper loaded: my_helper
INFO - 2024-06-06 12:22:16 --> Database Driver Class Initialized
INFO - 2024-06-06 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:22:16 --> Controller Class Initialized
INFO - 2024-06-06 12:22:16 --> Final output sent to browser
DEBUG - 2024-06-06 12:22:16 --> Total execution time: 0.0341
INFO - 2024-06-06 12:22:21 --> Config Class Initialized
INFO - 2024-06-06 12:22:21 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:22:21 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:22:21 --> Utf8 Class Initialized
INFO - 2024-06-06 12:22:21 --> URI Class Initialized
INFO - 2024-06-06 12:22:21 --> Router Class Initialized
INFO - 2024-06-06 12:22:21 --> Output Class Initialized
INFO - 2024-06-06 12:22:21 --> Security Class Initialized
DEBUG - 2024-06-06 12:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:22:21 --> Input Class Initialized
INFO - 2024-06-06 12:22:21 --> Language Class Initialized
INFO - 2024-06-06 12:22:21 --> Language Class Initialized
INFO - 2024-06-06 12:22:21 --> Config Class Initialized
INFO - 2024-06-06 12:22:21 --> Loader Class Initialized
INFO - 2024-06-06 12:22:21 --> Helper loaded: url_helper
INFO - 2024-06-06 12:22:21 --> Helper loaded: file_helper
INFO - 2024-06-06 12:22:21 --> Helper loaded: form_helper
INFO - 2024-06-06 12:22:21 --> Helper loaded: my_helper
INFO - 2024-06-06 12:22:21 --> Database Driver Class Initialized
INFO - 2024-06-06 12:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:22:21 --> Controller Class Initialized
INFO - 2024-06-06 12:22:21 --> Final output sent to browser
DEBUG - 2024-06-06 12:22:21 --> Total execution time: 0.0297
INFO - 2024-06-06 12:23:29 --> Config Class Initialized
INFO - 2024-06-06 12:23:29 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:29 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:29 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:29 --> URI Class Initialized
INFO - 2024-06-06 12:23:29 --> Router Class Initialized
INFO - 2024-06-06 12:23:29 --> Output Class Initialized
INFO - 2024-06-06 12:23:29 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:29 --> Input Class Initialized
INFO - 2024-06-06 12:23:29 --> Language Class Initialized
INFO - 2024-06-06 12:23:29 --> Language Class Initialized
INFO - 2024-06-06 12:23:29 --> Config Class Initialized
INFO - 2024-06-06 12:23:29 --> Loader Class Initialized
INFO - 2024-06-06 12:23:29 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:29 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:29 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:29 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:29 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:29 --> Controller Class Initialized
INFO - 2024-06-06 12:23:29 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:29 --> Total execution time: 0.0511
INFO - 2024-06-06 12:23:31 --> Config Class Initialized
INFO - 2024-06-06 12:23:31 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:31 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:31 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:31 --> URI Class Initialized
INFO - 2024-06-06 12:23:31 --> Router Class Initialized
INFO - 2024-06-06 12:23:31 --> Output Class Initialized
INFO - 2024-06-06 12:23:31 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:31 --> Input Class Initialized
INFO - 2024-06-06 12:23:31 --> Language Class Initialized
INFO - 2024-06-06 12:23:31 --> Language Class Initialized
INFO - 2024-06-06 12:23:31 --> Config Class Initialized
INFO - 2024-06-06 12:23:31 --> Loader Class Initialized
INFO - 2024-06-06 12:23:31 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:31 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:31 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:31 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:31 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:31 --> Controller Class Initialized
INFO - 2024-06-06 12:23:31 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:31 --> Total execution time: 0.0637
INFO - 2024-06-06 12:23:35 --> Config Class Initialized
INFO - 2024-06-06 12:23:35 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:35 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:35 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:35 --> URI Class Initialized
INFO - 2024-06-06 12:23:35 --> Router Class Initialized
INFO - 2024-06-06 12:23:35 --> Output Class Initialized
INFO - 2024-06-06 12:23:35 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:35 --> Input Class Initialized
INFO - 2024-06-06 12:23:35 --> Language Class Initialized
INFO - 2024-06-06 12:23:35 --> Language Class Initialized
INFO - 2024-06-06 12:23:35 --> Config Class Initialized
INFO - 2024-06-06 12:23:35 --> Loader Class Initialized
INFO - 2024-06-06 12:23:35 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:35 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:35 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:35 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:35 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:35 --> Controller Class Initialized
ERROR - 2024-06-06 12:23:35 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 109
INFO - 2024-06-06 12:23:35 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:35 --> Total execution time: 0.0287
INFO - 2024-06-06 12:23:43 --> Config Class Initialized
INFO - 2024-06-06 12:23:43 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:43 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:43 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:43 --> URI Class Initialized
INFO - 2024-06-06 12:23:43 --> Router Class Initialized
INFO - 2024-06-06 12:23:43 --> Output Class Initialized
INFO - 2024-06-06 12:23:43 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:43 --> Input Class Initialized
INFO - 2024-06-06 12:23:43 --> Language Class Initialized
INFO - 2024-06-06 12:23:43 --> Language Class Initialized
INFO - 2024-06-06 12:23:43 --> Config Class Initialized
INFO - 2024-06-06 12:23:43 --> Loader Class Initialized
INFO - 2024-06-06 12:23:43 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:43 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:43 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:43 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:43 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:43 --> Controller Class Initialized
DEBUG - 2024-06-06 12:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-06-06 12:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:23:43 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:43 --> Total execution time: 0.0496
INFO - 2024-06-06 12:23:44 --> Config Class Initialized
INFO - 2024-06-06 12:23:44 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:44 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:44 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:44 --> URI Class Initialized
INFO - 2024-06-06 12:23:44 --> Router Class Initialized
INFO - 2024-06-06 12:23:44 --> Output Class Initialized
INFO - 2024-06-06 12:23:44 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:44 --> Input Class Initialized
INFO - 2024-06-06 12:23:44 --> Language Class Initialized
INFO - 2024-06-06 12:23:44 --> Language Class Initialized
INFO - 2024-06-06 12:23:44 --> Config Class Initialized
INFO - 2024-06-06 12:23:44 --> Loader Class Initialized
INFO - 2024-06-06 12:23:44 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:44 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:44 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:44 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:44 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:44 --> Controller Class Initialized
INFO - 2024-06-06 12:23:46 --> Config Class Initialized
INFO - 2024-06-06 12:23:46 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:46 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:46 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:46 --> URI Class Initialized
INFO - 2024-06-06 12:23:46 --> Router Class Initialized
INFO - 2024-06-06 12:23:46 --> Output Class Initialized
INFO - 2024-06-06 12:23:46 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:46 --> Input Class Initialized
INFO - 2024-06-06 12:23:46 --> Language Class Initialized
INFO - 2024-06-06 12:23:46 --> Language Class Initialized
INFO - 2024-06-06 12:23:46 --> Config Class Initialized
INFO - 2024-06-06 12:23:46 --> Loader Class Initialized
INFO - 2024-06-06 12:23:46 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:46 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:46 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:46 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:46 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:46 --> Controller Class Initialized
INFO - 2024-06-06 12:23:46 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:46 --> Total execution time: 0.0313
INFO - 2024-06-06 12:23:50 --> Config Class Initialized
INFO - 2024-06-06 12:23:50 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:23:50 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:23:50 --> Utf8 Class Initialized
INFO - 2024-06-06 12:23:50 --> URI Class Initialized
INFO - 2024-06-06 12:23:50 --> Router Class Initialized
INFO - 2024-06-06 12:23:50 --> Output Class Initialized
INFO - 2024-06-06 12:23:50 --> Security Class Initialized
DEBUG - 2024-06-06 12:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:23:50 --> Input Class Initialized
INFO - 2024-06-06 12:23:50 --> Language Class Initialized
INFO - 2024-06-06 12:23:50 --> Language Class Initialized
INFO - 2024-06-06 12:23:50 --> Config Class Initialized
INFO - 2024-06-06 12:23:50 --> Loader Class Initialized
INFO - 2024-06-06 12:23:50 --> Helper loaded: url_helper
INFO - 2024-06-06 12:23:50 --> Helper loaded: file_helper
INFO - 2024-06-06 12:23:50 --> Helper loaded: form_helper
INFO - 2024-06-06 12:23:50 --> Helper loaded: my_helper
INFO - 2024-06-06 12:23:50 --> Database Driver Class Initialized
INFO - 2024-06-06 12:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:23:50 --> Controller Class Initialized
INFO - 2024-06-06 12:23:50 --> Final output sent to browser
DEBUG - 2024-06-06 12:23:50 --> Total execution time: 0.0349
INFO - 2024-06-06 12:24:30 --> Config Class Initialized
INFO - 2024-06-06 12:24:30 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:30 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:30 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:30 --> URI Class Initialized
INFO - 2024-06-06 12:24:30 --> Router Class Initialized
INFO - 2024-06-06 12:24:30 --> Output Class Initialized
INFO - 2024-06-06 12:24:30 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:30 --> Input Class Initialized
INFO - 2024-06-06 12:24:30 --> Language Class Initialized
INFO - 2024-06-06 12:24:30 --> Language Class Initialized
INFO - 2024-06-06 12:24:30 --> Config Class Initialized
INFO - 2024-06-06 12:24:30 --> Loader Class Initialized
INFO - 2024-06-06 12:24:30 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:30 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:30 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:30 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:30 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:30 --> Controller Class Initialized
INFO - 2024-06-06 12:24:31 --> Final output sent to browser
DEBUG - 2024-06-06 12:24:31 --> Total execution time: 0.4634
INFO - 2024-06-06 12:24:44 --> Config Class Initialized
INFO - 2024-06-06 12:24:44 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:44 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:44 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:44 --> URI Class Initialized
INFO - 2024-06-06 12:24:44 --> Router Class Initialized
INFO - 2024-06-06 12:24:44 --> Output Class Initialized
INFO - 2024-06-06 12:24:44 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:44 --> Input Class Initialized
INFO - 2024-06-06 12:24:44 --> Language Class Initialized
INFO - 2024-06-06 12:24:44 --> Language Class Initialized
INFO - 2024-06-06 12:24:44 --> Config Class Initialized
INFO - 2024-06-06 12:24:44 --> Loader Class Initialized
INFO - 2024-06-06 12:24:44 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:44 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:44 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:44 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:44 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:44 --> Controller Class Initialized
DEBUG - 2024-06-06 12:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 12:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:24:44 --> Final output sent to browser
DEBUG - 2024-06-06 12:24:44 --> Total execution time: 0.0252
INFO - 2024-06-06 12:24:45 --> Config Class Initialized
INFO - 2024-06-06 12:24:45 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:45 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:45 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:45 --> URI Class Initialized
INFO - 2024-06-06 12:24:45 --> Router Class Initialized
INFO - 2024-06-06 12:24:45 --> Output Class Initialized
INFO - 2024-06-06 12:24:45 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:45 --> Input Class Initialized
INFO - 2024-06-06 12:24:45 --> Language Class Initialized
INFO - 2024-06-06 12:24:45 --> Language Class Initialized
INFO - 2024-06-06 12:24:45 --> Config Class Initialized
INFO - 2024-06-06 12:24:45 --> Loader Class Initialized
INFO - 2024-06-06 12:24:45 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:45 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:45 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:45 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:45 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:45 --> Controller Class Initialized
DEBUG - 2024-06-06 12:24:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-06-06 12:24:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:24:45 --> Final output sent to browser
DEBUG - 2024-06-06 12:24:45 --> Total execution time: 0.0295
INFO - 2024-06-06 12:24:46 --> Config Class Initialized
INFO - 2024-06-06 12:24:46 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:46 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:46 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:46 --> URI Class Initialized
INFO - 2024-06-06 12:24:46 --> Router Class Initialized
INFO - 2024-06-06 12:24:46 --> Output Class Initialized
INFO - 2024-06-06 12:24:46 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:46 --> Input Class Initialized
INFO - 2024-06-06 12:24:46 --> Language Class Initialized
INFO - 2024-06-06 12:24:46 --> Language Class Initialized
INFO - 2024-06-06 12:24:46 --> Config Class Initialized
INFO - 2024-06-06 12:24:46 --> Loader Class Initialized
INFO - 2024-06-06 12:24:46 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:46 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:46 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:46 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:46 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:46 --> Controller Class Initialized
INFO - 2024-06-06 12:24:47 --> Config Class Initialized
INFO - 2024-06-06 12:24:47 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:47 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:47 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:47 --> URI Class Initialized
INFO - 2024-06-06 12:24:47 --> Router Class Initialized
INFO - 2024-06-06 12:24:47 --> Output Class Initialized
INFO - 2024-06-06 12:24:47 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:47 --> Input Class Initialized
INFO - 2024-06-06 12:24:47 --> Language Class Initialized
INFO - 2024-06-06 12:24:47 --> Language Class Initialized
INFO - 2024-06-06 12:24:47 --> Config Class Initialized
INFO - 2024-06-06 12:24:47 --> Loader Class Initialized
INFO - 2024-06-06 12:24:47 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:47 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:47 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:47 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:47 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:47 --> Controller Class Initialized
INFO - 2024-06-06 12:24:47 --> Final output sent to browser
DEBUG - 2024-06-06 12:24:47 --> Total execution time: 0.0587
INFO - 2024-06-06 12:24:56 --> Config Class Initialized
INFO - 2024-06-06 12:24:56 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:24:56 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:24:56 --> Utf8 Class Initialized
INFO - 2024-06-06 12:24:56 --> URI Class Initialized
INFO - 2024-06-06 12:24:56 --> Router Class Initialized
INFO - 2024-06-06 12:24:56 --> Output Class Initialized
INFO - 2024-06-06 12:24:56 --> Security Class Initialized
DEBUG - 2024-06-06 12:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:24:56 --> Input Class Initialized
INFO - 2024-06-06 12:24:56 --> Language Class Initialized
INFO - 2024-06-06 12:24:56 --> Language Class Initialized
INFO - 2024-06-06 12:24:56 --> Config Class Initialized
INFO - 2024-06-06 12:24:56 --> Loader Class Initialized
INFO - 2024-06-06 12:24:56 --> Helper loaded: url_helper
INFO - 2024-06-06 12:24:56 --> Helper loaded: file_helper
INFO - 2024-06-06 12:24:56 --> Helper loaded: form_helper
INFO - 2024-06-06 12:24:56 --> Helper loaded: my_helper
INFO - 2024-06-06 12:24:56 --> Database Driver Class Initialized
INFO - 2024-06-06 12:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:24:56 --> Controller Class Initialized
INFO - 2024-06-06 12:24:56 --> Final output sent to browser
DEBUG - 2024-06-06 12:24:56 --> Total execution time: 0.0414
INFO - 2024-06-06 12:25:03 --> Config Class Initialized
INFO - 2024-06-06 12:25:03 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:25:03 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:25:03 --> Utf8 Class Initialized
INFO - 2024-06-06 12:25:03 --> URI Class Initialized
INFO - 2024-06-06 12:25:03 --> Router Class Initialized
INFO - 2024-06-06 12:25:03 --> Output Class Initialized
INFO - 2024-06-06 12:25:03 --> Security Class Initialized
DEBUG - 2024-06-06 12:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:25:03 --> Input Class Initialized
INFO - 2024-06-06 12:25:03 --> Language Class Initialized
INFO - 2024-06-06 12:25:03 --> Language Class Initialized
INFO - 2024-06-06 12:25:03 --> Config Class Initialized
INFO - 2024-06-06 12:25:03 --> Loader Class Initialized
INFO - 2024-06-06 12:25:03 --> Helper loaded: url_helper
INFO - 2024-06-06 12:25:03 --> Helper loaded: file_helper
INFO - 2024-06-06 12:25:03 --> Helper loaded: form_helper
INFO - 2024-06-06 12:25:03 --> Helper loaded: my_helper
INFO - 2024-06-06 12:25:03 --> Database Driver Class Initialized
INFO - 2024-06-06 12:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:25:03 --> Controller Class Initialized
INFO - 2024-06-06 12:25:03 --> Final output sent to browser
DEBUG - 2024-06-06 12:25:03 --> Total execution time: 0.0396
INFO - 2024-06-06 12:25:44 --> Config Class Initialized
INFO - 2024-06-06 12:25:44 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:25:44 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:25:44 --> Utf8 Class Initialized
INFO - 2024-06-06 12:25:44 --> URI Class Initialized
INFO - 2024-06-06 12:25:44 --> Router Class Initialized
INFO - 2024-06-06 12:25:44 --> Output Class Initialized
INFO - 2024-06-06 12:25:44 --> Security Class Initialized
DEBUG - 2024-06-06 12:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:25:44 --> Input Class Initialized
INFO - 2024-06-06 12:25:44 --> Language Class Initialized
INFO - 2024-06-06 12:25:44 --> Language Class Initialized
INFO - 2024-06-06 12:25:44 --> Config Class Initialized
INFO - 2024-06-06 12:25:44 --> Loader Class Initialized
INFO - 2024-06-06 12:25:44 --> Helper loaded: url_helper
INFO - 2024-06-06 12:25:44 --> Helper loaded: file_helper
INFO - 2024-06-06 12:25:44 --> Helper loaded: form_helper
INFO - 2024-06-06 12:25:44 --> Helper loaded: my_helper
INFO - 2024-06-06 12:25:44 --> Database Driver Class Initialized
INFO - 2024-06-06 12:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:25:44 --> Controller Class Initialized
INFO - 2024-06-06 12:25:44 --> Final output sent to browser
DEBUG - 2024-06-06 12:25:44 --> Total execution time: 0.0649
INFO - 2024-06-06 12:26:17 --> Config Class Initialized
INFO - 2024-06-06 12:26:17 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:17 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:17 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:17 --> URI Class Initialized
INFO - 2024-06-06 12:26:17 --> Router Class Initialized
INFO - 2024-06-06 12:26:17 --> Output Class Initialized
INFO - 2024-06-06 12:26:17 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:17 --> Input Class Initialized
INFO - 2024-06-06 12:26:17 --> Language Class Initialized
INFO - 2024-06-06 12:26:17 --> Language Class Initialized
INFO - 2024-06-06 12:26:17 --> Config Class Initialized
INFO - 2024-06-06 12:26:17 --> Loader Class Initialized
INFO - 2024-06-06 12:26:17 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:17 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:17 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:17 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:17 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:17 --> Controller Class Initialized
INFO - 2024-06-06 12:26:17 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:17 --> Total execution time: 0.0387
INFO - 2024-06-06 12:26:37 --> Config Class Initialized
INFO - 2024-06-06 12:26:37 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:37 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:37 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:37 --> URI Class Initialized
INFO - 2024-06-06 12:26:37 --> Router Class Initialized
INFO - 2024-06-06 12:26:37 --> Output Class Initialized
INFO - 2024-06-06 12:26:37 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:37 --> Input Class Initialized
INFO - 2024-06-06 12:26:37 --> Language Class Initialized
INFO - 2024-06-06 12:26:37 --> Language Class Initialized
INFO - 2024-06-06 12:26:37 --> Config Class Initialized
INFO - 2024-06-06 12:26:37 --> Loader Class Initialized
INFO - 2024-06-06 12:26:37 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:37 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:37 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:37 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:37 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:37 --> Controller Class Initialized
INFO - 2024-06-06 12:26:37 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:37 --> Total execution time: 0.0645
INFO - 2024-06-06 12:26:38 --> Config Class Initialized
INFO - 2024-06-06 12:26:38 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:38 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:38 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:38 --> URI Class Initialized
INFO - 2024-06-06 12:26:38 --> Router Class Initialized
INFO - 2024-06-06 12:26:38 --> Output Class Initialized
INFO - 2024-06-06 12:26:38 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:38 --> Input Class Initialized
INFO - 2024-06-06 12:26:38 --> Language Class Initialized
INFO - 2024-06-06 12:26:38 --> Language Class Initialized
INFO - 2024-06-06 12:26:38 --> Config Class Initialized
INFO - 2024-06-06 12:26:38 --> Loader Class Initialized
INFO - 2024-06-06 12:26:38 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:38 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:38 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:38 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:38 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:38 --> Controller Class Initialized
INFO - 2024-06-06 12:26:38 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:38 --> Total execution time: 0.0301
INFO - 2024-06-06 12:26:45 --> Config Class Initialized
INFO - 2024-06-06 12:26:45 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:45 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:45 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:45 --> URI Class Initialized
INFO - 2024-06-06 12:26:45 --> Router Class Initialized
INFO - 2024-06-06 12:26:45 --> Output Class Initialized
INFO - 2024-06-06 12:26:45 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:46 --> Input Class Initialized
INFO - 2024-06-06 12:26:46 --> Language Class Initialized
INFO - 2024-06-06 12:26:46 --> Language Class Initialized
INFO - 2024-06-06 12:26:46 --> Config Class Initialized
INFO - 2024-06-06 12:26:46 --> Loader Class Initialized
INFO - 2024-06-06 12:26:46 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:46 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:46 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:46 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:46 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:46 --> Controller Class Initialized
DEBUG - 2024-06-06 12:26:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 12:26:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:26:46 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:46 --> Total execution time: 0.0407
INFO - 2024-06-06 12:26:47 --> Config Class Initialized
INFO - 2024-06-06 12:26:47 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:47 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:47 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:47 --> URI Class Initialized
INFO - 2024-06-06 12:26:47 --> Router Class Initialized
INFO - 2024-06-06 12:26:47 --> Output Class Initialized
INFO - 2024-06-06 12:26:47 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:47 --> Input Class Initialized
INFO - 2024-06-06 12:26:47 --> Language Class Initialized
INFO - 2024-06-06 12:26:47 --> Language Class Initialized
INFO - 2024-06-06 12:26:47 --> Config Class Initialized
INFO - 2024-06-06 12:26:47 --> Loader Class Initialized
INFO - 2024-06-06 12:26:47 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:47 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:47 --> Controller Class Initialized
DEBUG - 2024-06-06 12:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-06 12:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 12:26:47 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:47 --> Total execution time: 0.0305
INFO - 2024-06-06 12:26:47 --> Config Class Initialized
INFO - 2024-06-06 12:26:47 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:47 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:47 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:47 --> URI Class Initialized
INFO - 2024-06-06 12:26:47 --> Router Class Initialized
INFO - 2024-06-06 12:26:47 --> Output Class Initialized
INFO - 2024-06-06 12:26:47 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:47 --> Input Class Initialized
INFO - 2024-06-06 12:26:47 --> Language Class Initialized
INFO - 2024-06-06 12:26:47 --> Language Class Initialized
INFO - 2024-06-06 12:26:47 --> Config Class Initialized
INFO - 2024-06-06 12:26:47 --> Loader Class Initialized
INFO - 2024-06-06 12:26:47 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:47 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:47 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:47 --> Controller Class Initialized
INFO - 2024-06-06 12:26:51 --> Config Class Initialized
INFO - 2024-06-06 12:26:51 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:51 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:51 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:51 --> URI Class Initialized
INFO - 2024-06-06 12:26:51 --> Router Class Initialized
INFO - 2024-06-06 12:26:51 --> Output Class Initialized
INFO - 2024-06-06 12:26:51 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:51 --> Input Class Initialized
INFO - 2024-06-06 12:26:51 --> Language Class Initialized
INFO - 2024-06-06 12:26:51 --> Language Class Initialized
INFO - 2024-06-06 12:26:51 --> Config Class Initialized
INFO - 2024-06-06 12:26:51 --> Loader Class Initialized
INFO - 2024-06-06 12:26:51 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:51 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:51 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:51 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:51 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:51 --> Controller Class Initialized
INFO - 2024-06-06 12:26:51 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:51 --> Total execution time: 0.0297
INFO - 2024-06-06 12:26:58 --> Config Class Initialized
INFO - 2024-06-06 12:26:58 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:26:58 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:26:58 --> Utf8 Class Initialized
INFO - 2024-06-06 12:26:58 --> URI Class Initialized
INFO - 2024-06-06 12:26:58 --> Router Class Initialized
INFO - 2024-06-06 12:26:58 --> Output Class Initialized
INFO - 2024-06-06 12:26:58 --> Security Class Initialized
DEBUG - 2024-06-06 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:26:58 --> Input Class Initialized
INFO - 2024-06-06 12:26:58 --> Language Class Initialized
INFO - 2024-06-06 12:26:58 --> Language Class Initialized
INFO - 2024-06-06 12:26:58 --> Config Class Initialized
INFO - 2024-06-06 12:26:58 --> Loader Class Initialized
INFO - 2024-06-06 12:26:58 --> Helper loaded: url_helper
INFO - 2024-06-06 12:26:58 --> Helper loaded: file_helper
INFO - 2024-06-06 12:26:58 --> Helper loaded: form_helper
INFO - 2024-06-06 12:26:58 --> Helper loaded: my_helper
INFO - 2024-06-06 12:26:58 --> Database Driver Class Initialized
INFO - 2024-06-06 12:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:26:58 --> Controller Class Initialized
INFO - 2024-06-06 12:26:58 --> Final output sent to browser
DEBUG - 2024-06-06 12:26:58 --> Total execution time: 0.0411
INFO - 2024-06-06 12:30:08 --> Config Class Initialized
INFO - 2024-06-06 12:30:08 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:30:08 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:30:08 --> Utf8 Class Initialized
INFO - 2024-06-06 12:30:08 --> URI Class Initialized
INFO - 2024-06-06 12:30:08 --> Router Class Initialized
INFO - 2024-06-06 12:30:08 --> Output Class Initialized
INFO - 2024-06-06 12:30:08 --> Security Class Initialized
DEBUG - 2024-06-06 12:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:30:08 --> Input Class Initialized
INFO - 2024-06-06 12:30:08 --> Language Class Initialized
INFO - 2024-06-06 12:30:08 --> Language Class Initialized
INFO - 2024-06-06 12:30:08 --> Config Class Initialized
INFO - 2024-06-06 12:30:08 --> Loader Class Initialized
INFO - 2024-06-06 12:30:08 --> Helper loaded: url_helper
INFO - 2024-06-06 12:30:08 --> Helper loaded: file_helper
INFO - 2024-06-06 12:30:08 --> Helper loaded: form_helper
INFO - 2024-06-06 12:30:08 --> Helper loaded: my_helper
INFO - 2024-06-06 12:30:08 --> Database Driver Class Initialized
INFO - 2024-06-06 12:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:30:08 --> Controller Class Initialized
INFO - 2024-06-06 12:30:08 --> Final output sent to browser
DEBUG - 2024-06-06 12:30:08 --> Total execution time: 0.0319
INFO - 2024-06-06 12:30:33 --> Config Class Initialized
INFO - 2024-06-06 12:30:33 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:30:33 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:30:33 --> Utf8 Class Initialized
INFO - 2024-06-06 12:30:33 --> URI Class Initialized
INFO - 2024-06-06 12:30:33 --> Router Class Initialized
INFO - 2024-06-06 12:30:33 --> Output Class Initialized
INFO - 2024-06-06 12:30:33 --> Security Class Initialized
DEBUG - 2024-06-06 12:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:30:33 --> Input Class Initialized
INFO - 2024-06-06 12:30:33 --> Language Class Initialized
INFO - 2024-06-06 12:30:33 --> Language Class Initialized
INFO - 2024-06-06 12:30:33 --> Config Class Initialized
INFO - 2024-06-06 12:30:33 --> Loader Class Initialized
INFO - 2024-06-06 12:30:33 --> Helper loaded: url_helper
INFO - 2024-06-06 12:30:33 --> Helper loaded: file_helper
INFO - 2024-06-06 12:30:33 --> Helper loaded: form_helper
INFO - 2024-06-06 12:30:33 --> Helper loaded: my_helper
INFO - 2024-06-06 12:30:33 --> Database Driver Class Initialized
INFO - 2024-06-06 12:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:30:33 --> Controller Class Initialized
INFO - 2024-06-06 12:30:33 --> Final output sent to browser
DEBUG - 2024-06-06 12:30:33 --> Total execution time: 0.0565
INFO - 2024-06-06 12:30:36 --> Config Class Initialized
INFO - 2024-06-06 12:30:36 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:30:36 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:30:36 --> Utf8 Class Initialized
INFO - 2024-06-06 12:30:36 --> URI Class Initialized
INFO - 2024-06-06 12:30:36 --> Router Class Initialized
INFO - 2024-06-06 12:30:36 --> Output Class Initialized
INFO - 2024-06-06 12:30:36 --> Security Class Initialized
DEBUG - 2024-06-06 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:30:36 --> Input Class Initialized
INFO - 2024-06-06 12:30:36 --> Language Class Initialized
INFO - 2024-06-06 12:30:36 --> Language Class Initialized
INFO - 2024-06-06 12:30:36 --> Config Class Initialized
INFO - 2024-06-06 12:30:36 --> Loader Class Initialized
INFO - 2024-06-06 12:30:36 --> Helper loaded: url_helper
INFO - 2024-06-06 12:30:36 --> Helper loaded: file_helper
INFO - 2024-06-06 12:30:36 --> Helper loaded: form_helper
INFO - 2024-06-06 12:30:36 --> Helper loaded: my_helper
INFO - 2024-06-06 12:30:36 --> Database Driver Class Initialized
INFO - 2024-06-06 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:30:36 --> Controller Class Initialized
INFO - 2024-06-06 12:30:36 --> Final output sent to browser
DEBUG - 2024-06-06 12:30:36 --> Total execution time: 0.0369
INFO - 2024-06-06 12:31:14 --> Config Class Initialized
INFO - 2024-06-06 12:31:14 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:31:14 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:31:14 --> Utf8 Class Initialized
INFO - 2024-06-06 12:31:14 --> URI Class Initialized
INFO - 2024-06-06 12:31:14 --> Router Class Initialized
INFO - 2024-06-06 12:31:14 --> Output Class Initialized
INFO - 2024-06-06 12:31:14 --> Security Class Initialized
DEBUG - 2024-06-06 12:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:31:14 --> Input Class Initialized
INFO - 2024-06-06 12:31:14 --> Language Class Initialized
INFO - 2024-06-06 12:31:14 --> Language Class Initialized
INFO - 2024-06-06 12:31:14 --> Config Class Initialized
INFO - 2024-06-06 12:31:14 --> Loader Class Initialized
INFO - 2024-06-06 12:31:14 --> Helper loaded: url_helper
INFO - 2024-06-06 12:31:14 --> Helper loaded: file_helper
INFO - 2024-06-06 12:31:14 --> Helper loaded: form_helper
INFO - 2024-06-06 12:31:14 --> Helper loaded: my_helper
INFO - 2024-06-06 12:31:14 --> Database Driver Class Initialized
INFO - 2024-06-06 12:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:31:14 --> Controller Class Initialized
INFO - 2024-06-06 12:31:14 --> Final output sent to browser
DEBUG - 2024-06-06 12:31:14 --> Total execution time: 0.0587
INFO - 2024-06-06 12:31:27 --> Config Class Initialized
INFO - 2024-06-06 12:31:27 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:31:27 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:31:27 --> Utf8 Class Initialized
INFO - 2024-06-06 12:31:27 --> URI Class Initialized
INFO - 2024-06-06 12:31:27 --> Router Class Initialized
INFO - 2024-06-06 12:31:27 --> Output Class Initialized
INFO - 2024-06-06 12:31:27 --> Security Class Initialized
DEBUG - 2024-06-06 12:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:31:27 --> Input Class Initialized
INFO - 2024-06-06 12:31:27 --> Language Class Initialized
INFO - 2024-06-06 12:31:27 --> Language Class Initialized
INFO - 2024-06-06 12:31:27 --> Config Class Initialized
INFO - 2024-06-06 12:31:27 --> Loader Class Initialized
INFO - 2024-06-06 12:31:27 --> Helper loaded: url_helper
INFO - 2024-06-06 12:31:27 --> Helper loaded: file_helper
INFO - 2024-06-06 12:31:27 --> Helper loaded: form_helper
INFO - 2024-06-06 12:31:27 --> Helper loaded: my_helper
INFO - 2024-06-06 12:31:27 --> Database Driver Class Initialized
INFO - 2024-06-06 12:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:31:27 --> Controller Class Initialized
INFO - 2024-06-06 12:31:27 --> Final output sent to browser
DEBUG - 2024-06-06 12:31:27 --> Total execution time: 0.0507
INFO - 2024-06-06 12:31:29 --> Config Class Initialized
INFO - 2024-06-06 12:31:29 --> Hooks Class Initialized
DEBUG - 2024-06-06 12:31:29 --> UTF-8 Support Enabled
INFO - 2024-06-06 12:31:29 --> Utf8 Class Initialized
INFO - 2024-06-06 12:31:29 --> URI Class Initialized
INFO - 2024-06-06 12:31:29 --> Router Class Initialized
INFO - 2024-06-06 12:31:29 --> Output Class Initialized
INFO - 2024-06-06 12:31:29 --> Security Class Initialized
DEBUG - 2024-06-06 12:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 12:31:29 --> Input Class Initialized
INFO - 2024-06-06 12:31:29 --> Language Class Initialized
INFO - 2024-06-06 12:31:29 --> Language Class Initialized
INFO - 2024-06-06 12:31:29 --> Config Class Initialized
INFO - 2024-06-06 12:31:29 --> Loader Class Initialized
INFO - 2024-06-06 12:31:29 --> Helper loaded: url_helper
INFO - 2024-06-06 12:31:29 --> Helper loaded: file_helper
INFO - 2024-06-06 12:31:29 --> Helper loaded: form_helper
INFO - 2024-06-06 12:31:29 --> Helper loaded: my_helper
INFO - 2024-06-06 12:31:29 --> Database Driver Class Initialized
INFO - 2024-06-06 12:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 12:31:29 --> Controller Class Initialized
INFO - 2024-06-06 12:31:29 --> Final output sent to browser
DEBUG - 2024-06-06 12:31:29 --> Total execution time: 0.0381
INFO - 2024-06-06 20:44:40 --> Config Class Initialized
INFO - 2024-06-06 20:44:40 --> Hooks Class Initialized
DEBUG - 2024-06-06 20:44:40 --> UTF-8 Support Enabled
INFO - 2024-06-06 20:44:40 --> Utf8 Class Initialized
INFO - 2024-06-06 20:44:40 --> URI Class Initialized
INFO - 2024-06-06 20:44:40 --> Router Class Initialized
INFO - 2024-06-06 20:44:40 --> Output Class Initialized
INFO - 2024-06-06 20:44:40 --> Security Class Initialized
DEBUG - 2024-06-06 20:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 20:44:40 --> Input Class Initialized
INFO - 2024-06-06 20:44:40 --> Language Class Initialized
INFO - 2024-06-06 20:44:40 --> Language Class Initialized
INFO - 2024-06-06 20:44:40 --> Config Class Initialized
INFO - 2024-06-06 20:44:40 --> Loader Class Initialized
INFO - 2024-06-06 20:44:40 --> Helper loaded: url_helper
INFO - 2024-06-06 20:44:40 --> Helper loaded: file_helper
INFO - 2024-06-06 20:44:40 --> Helper loaded: form_helper
INFO - 2024-06-06 20:44:40 --> Helper loaded: my_helper
INFO - 2024-06-06 20:44:40 --> Database Driver Class Initialized
INFO - 2024-06-06 20:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 20:44:40 --> Controller Class Initialized
DEBUG - 2024-06-06 20:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-06 20:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 20:44:40 --> Final output sent to browser
DEBUG - 2024-06-06 20:44:40 --> Total execution time: 0.0400
INFO - 2024-06-06 20:44:41 --> Config Class Initialized
INFO - 2024-06-06 20:44:41 --> Hooks Class Initialized
DEBUG - 2024-06-06 20:44:41 --> UTF-8 Support Enabled
INFO - 2024-06-06 20:44:41 --> Utf8 Class Initialized
INFO - 2024-06-06 20:44:41 --> URI Class Initialized
INFO - 2024-06-06 20:44:41 --> Router Class Initialized
INFO - 2024-06-06 20:44:41 --> Output Class Initialized
INFO - 2024-06-06 20:44:41 --> Security Class Initialized
DEBUG - 2024-06-06 20:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 20:44:41 --> Input Class Initialized
INFO - 2024-06-06 20:44:41 --> Language Class Initialized
INFO - 2024-06-06 20:44:41 --> Language Class Initialized
INFO - 2024-06-06 20:44:41 --> Config Class Initialized
INFO - 2024-06-06 20:44:41 --> Loader Class Initialized
INFO - 2024-06-06 20:44:41 --> Helper loaded: url_helper
INFO - 2024-06-06 20:44:41 --> Helper loaded: file_helper
INFO - 2024-06-06 20:44:41 --> Helper loaded: form_helper
INFO - 2024-06-06 20:44:41 --> Helper loaded: my_helper
INFO - 2024-06-06 20:44:41 --> Database Driver Class Initialized
INFO - 2024-06-06 20:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 20:44:41 --> Controller Class Initialized
INFO - 2024-06-06 20:45:11 --> Config Class Initialized
INFO - 2024-06-06 20:45:11 --> Hooks Class Initialized
DEBUG - 2024-06-06 20:45:11 --> UTF-8 Support Enabled
INFO - 2024-06-06 20:45:11 --> Utf8 Class Initialized
INFO - 2024-06-06 20:45:11 --> URI Class Initialized
INFO - 2024-06-06 20:45:11 --> Router Class Initialized
INFO - 2024-06-06 20:45:11 --> Output Class Initialized
INFO - 2024-06-06 20:45:11 --> Security Class Initialized
DEBUG - 2024-06-06 20:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 20:45:11 --> Input Class Initialized
INFO - 2024-06-06 20:45:11 --> Language Class Initialized
INFO - 2024-06-06 20:45:11 --> Language Class Initialized
INFO - 2024-06-06 20:45:11 --> Config Class Initialized
INFO - 2024-06-06 20:45:11 --> Loader Class Initialized
INFO - 2024-06-06 20:45:11 --> Helper loaded: url_helper
INFO - 2024-06-06 20:45:11 --> Helper loaded: file_helper
INFO - 2024-06-06 20:45:11 --> Helper loaded: form_helper
INFO - 2024-06-06 20:45:11 --> Helper loaded: my_helper
INFO - 2024-06-06 20:45:11 --> Database Driver Class Initialized
INFO - 2024-06-06 20:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 20:45:11 --> Controller Class Initialized
INFO - 2024-06-06 20:45:11 --> Final output sent to browser
DEBUG - 2024-06-06 20:45:11 --> Total execution time: 0.0903
INFO - 2024-06-06 21:04:16 --> Config Class Initialized
INFO - 2024-06-06 21:04:16 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:16 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:16 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:16 --> URI Class Initialized
INFO - 2024-06-06 21:04:16 --> Router Class Initialized
INFO - 2024-06-06 21:04:16 --> Output Class Initialized
INFO - 2024-06-06 21:04:16 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:16 --> Input Class Initialized
INFO - 2024-06-06 21:04:16 --> Language Class Initialized
INFO - 2024-06-06 21:04:16 --> Language Class Initialized
INFO - 2024-06-06 21:04:16 --> Config Class Initialized
INFO - 2024-06-06 21:04:16 --> Loader Class Initialized
INFO - 2024-06-06 21:04:16 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:16 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:16 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:16 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:16 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:16 --> Controller Class Initialized
INFO - 2024-06-06 21:04:16 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:16 --> Total execution time: 0.0613
INFO - 2024-06-06 21:04:25 --> Config Class Initialized
INFO - 2024-06-06 21:04:25 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:25 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:25 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:25 --> URI Class Initialized
INFO - 2024-06-06 21:04:25 --> Router Class Initialized
INFO - 2024-06-06 21:04:25 --> Output Class Initialized
INFO - 2024-06-06 21:04:25 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:25 --> Input Class Initialized
INFO - 2024-06-06 21:04:25 --> Language Class Initialized
INFO - 2024-06-06 21:04:25 --> Language Class Initialized
INFO - 2024-06-06 21:04:25 --> Config Class Initialized
INFO - 2024-06-06 21:04:25 --> Loader Class Initialized
INFO - 2024-06-06 21:04:25 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:25 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:25 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:25 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:25 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:25 --> Controller Class Initialized
INFO - 2024-06-06 21:04:25 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:25 --> Total execution time: 0.0394
INFO - 2024-06-06 21:04:27 --> Config Class Initialized
INFO - 2024-06-06 21:04:27 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:27 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:27 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:27 --> URI Class Initialized
INFO - 2024-06-06 21:04:27 --> Router Class Initialized
INFO - 2024-06-06 21:04:27 --> Output Class Initialized
INFO - 2024-06-06 21:04:27 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:27 --> Input Class Initialized
INFO - 2024-06-06 21:04:27 --> Language Class Initialized
INFO - 2024-06-06 21:04:27 --> Language Class Initialized
INFO - 2024-06-06 21:04:27 --> Config Class Initialized
INFO - 2024-06-06 21:04:27 --> Loader Class Initialized
INFO - 2024-06-06 21:04:27 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:27 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:27 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:27 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:27 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:27 --> Controller Class Initialized
INFO - 2024-06-06 21:04:27 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:27 --> Total execution time: 0.0315
INFO - 2024-06-06 21:04:35 --> Config Class Initialized
INFO - 2024-06-06 21:04:35 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:35 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:35 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:35 --> URI Class Initialized
INFO - 2024-06-06 21:04:35 --> Router Class Initialized
INFO - 2024-06-06 21:04:35 --> Output Class Initialized
INFO - 2024-06-06 21:04:35 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:35 --> Input Class Initialized
INFO - 2024-06-06 21:04:35 --> Language Class Initialized
INFO - 2024-06-06 21:04:35 --> Language Class Initialized
INFO - 2024-06-06 21:04:35 --> Config Class Initialized
INFO - 2024-06-06 21:04:35 --> Loader Class Initialized
INFO - 2024-06-06 21:04:35 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:35 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:35 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:35 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:35 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:35 --> Controller Class Initialized
INFO - 2024-06-06 21:04:35 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:35 --> Total execution time: 0.0313
INFO - 2024-06-06 21:04:37 --> Config Class Initialized
INFO - 2024-06-06 21:04:37 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:37 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:37 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:37 --> URI Class Initialized
INFO - 2024-06-06 21:04:37 --> Router Class Initialized
INFO - 2024-06-06 21:04:37 --> Output Class Initialized
INFO - 2024-06-06 21:04:38 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:38 --> Input Class Initialized
INFO - 2024-06-06 21:04:38 --> Language Class Initialized
INFO - 2024-06-06 21:04:38 --> Language Class Initialized
INFO - 2024-06-06 21:04:38 --> Config Class Initialized
INFO - 2024-06-06 21:04:38 --> Loader Class Initialized
INFO - 2024-06-06 21:04:38 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:38 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:38 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:38 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:38 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:38 --> Controller Class Initialized
INFO - 2024-06-06 21:04:38 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:38 --> Total execution time: 0.0362
INFO - 2024-06-06 21:04:39 --> Config Class Initialized
INFO - 2024-06-06 21:04:39 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:39 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:39 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:39 --> URI Class Initialized
INFO - 2024-06-06 21:04:39 --> Router Class Initialized
INFO - 2024-06-06 21:04:39 --> Output Class Initialized
INFO - 2024-06-06 21:04:39 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:39 --> Input Class Initialized
INFO - 2024-06-06 21:04:39 --> Language Class Initialized
INFO - 2024-06-06 21:04:39 --> Language Class Initialized
INFO - 2024-06-06 21:04:39 --> Config Class Initialized
INFO - 2024-06-06 21:04:39 --> Loader Class Initialized
INFO - 2024-06-06 21:04:39 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:39 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:39 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:39 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:39 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:39 --> Controller Class Initialized
INFO - 2024-06-06 21:04:39 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:39 --> Total execution time: 0.0351
INFO - 2024-06-06 21:04:40 --> Config Class Initialized
INFO - 2024-06-06 21:04:40 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:04:40 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:04:40 --> Utf8 Class Initialized
INFO - 2024-06-06 21:04:40 --> URI Class Initialized
INFO - 2024-06-06 21:04:40 --> Router Class Initialized
INFO - 2024-06-06 21:04:40 --> Output Class Initialized
INFO - 2024-06-06 21:04:40 --> Security Class Initialized
DEBUG - 2024-06-06 21:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:04:40 --> Input Class Initialized
INFO - 2024-06-06 21:04:40 --> Language Class Initialized
INFO - 2024-06-06 21:04:40 --> Language Class Initialized
INFO - 2024-06-06 21:04:40 --> Config Class Initialized
INFO - 2024-06-06 21:04:40 --> Loader Class Initialized
INFO - 2024-06-06 21:04:40 --> Helper loaded: url_helper
INFO - 2024-06-06 21:04:40 --> Helper loaded: file_helper
INFO - 2024-06-06 21:04:40 --> Helper loaded: form_helper
INFO - 2024-06-06 21:04:40 --> Helper loaded: my_helper
INFO - 2024-06-06 21:04:40 --> Database Driver Class Initialized
INFO - 2024-06-06 21:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:04:40 --> Controller Class Initialized
INFO - 2024-06-06 21:04:40 --> Final output sent to browser
DEBUG - 2024-06-06 21:04:40 --> Total execution time: 0.0265
INFO - 2024-06-06 21:07:50 --> Config Class Initialized
INFO - 2024-06-06 21:07:50 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:07:50 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:07:50 --> Utf8 Class Initialized
INFO - 2024-06-06 21:07:50 --> URI Class Initialized
INFO - 2024-06-06 21:07:50 --> Router Class Initialized
INFO - 2024-06-06 21:07:50 --> Output Class Initialized
INFO - 2024-06-06 21:07:50 --> Security Class Initialized
DEBUG - 2024-06-06 21:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:07:50 --> Input Class Initialized
INFO - 2024-06-06 21:07:50 --> Language Class Initialized
INFO - 2024-06-06 21:07:50 --> Language Class Initialized
INFO - 2024-06-06 21:07:50 --> Config Class Initialized
INFO - 2024-06-06 21:07:50 --> Loader Class Initialized
INFO - 2024-06-06 21:07:50 --> Helper loaded: url_helper
INFO - 2024-06-06 21:07:50 --> Helper loaded: file_helper
INFO - 2024-06-06 21:07:50 --> Helper loaded: form_helper
INFO - 2024-06-06 21:07:50 --> Helper loaded: my_helper
INFO - 2024-06-06 21:07:50 --> Database Driver Class Initialized
INFO - 2024-06-06 21:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:07:50 --> Controller Class Initialized
INFO - 2024-06-06 21:07:50 --> Final output sent to browser
DEBUG - 2024-06-06 21:07:50 --> Total execution time: 0.0516
INFO - 2024-06-06 21:08:00 --> Config Class Initialized
INFO - 2024-06-06 21:08:00 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:00 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:00 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:00 --> URI Class Initialized
DEBUG - 2024-06-06 21:08:00 --> No URI present. Default controller set.
INFO - 2024-06-06 21:08:00 --> Router Class Initialized
INFO - 2024-06-06 21:08:00 --> Output Class Initialized
INFO - 2024-06-06 21:08:00 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:00 --> Input Class Initialized
INFO - 2024-06-06 21:08:00 --> Language Class Initialized
INFO - 2024-06-06 21:08:00 --> Language Class Initialized
INFO - 2024-06-06 21:08:00 --> Config Class Initialized
INFO - 2024-06-06 21:08:00 --> Loader Class Initialized
INFO - 2024-06-06 21:08:00 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:00 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:00 --> Controller Class Initialized
INFO - 2024-06-06 21:08:00 --> Config Class Initialized
INFO - 2024-06-06 21:08:00 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:00 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:00 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:00 --> URI Class Initialized
INFO - 2024-06-06 21:08:00 --> Router Class Initialized
INFO - 2024-06-06 21:08:00 --> Output Class Initialized
INFO - 2024-06-06 21:08:00 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:00 --> Input Class Initialized
INFO - 2024-06-06 21:08:00 --> Language Class Initialized
INFO - 2024-06-06 21:08:00 --> Language Class Initialized
INFO - 2024-06-06 21:08:00 --> Config Class Initialized
INFO - 2024-06-06 21:08:00 --> Loader Class Initialized
INFO - 2024-06-06 21:08:00 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:00 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:00 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:00 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-06 21:08:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:00 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:00 --> Total execution time: 0.0276
INFO - 2024-06-06 21:08:07 --> Config Class Initialized
INFO - 2024-06-06 21:08:07 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:07 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:07 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:07 --> URI Class Initialized
INFO - 2024-06-06 21:08:07 --> Router Class Initialized
INFO - 2024-06-06 21:08:07 --> Output Class Initialized
INFO - 2024-06-06 21:08:07 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:07 --> Input Class Initialized
INFO - 2024-06-06 21:08:07 --> Language Class Initialized
INFO - 2024-06-06 21:08:07 --> Language Class Initialized
INFO - 2024-06-06 21:08:07 --> Config Class Initialized
INFO - 2024-06-06 21:08:07 --> Loader Class Initialized
INFO - 2024-06-06 21:08:07 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:07 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:07 --> Controller Class Initialized
INFO - 2024-06-06 21:08:07 --> Helper loaded: cookie_helper
INFO - 2024-06-06 21:08:07 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:07 --> Total execution time: 0.0351
INFO - 2024-06-06 21:08:07 --> Config Class Initialized
INFO - 2024-06-06 21:08:07 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:07 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:07 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:07 --> URI Class Initialized
INFO - 2024-06-06 21:08:07 --> Router Class Initialized
INFO - 2024-06-06 21:08:07 --> Output Class Initialized
INFO - 2024-06-06 21:08:07 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:07 --> Input Class Initialized
INFO - 2024-06-06 21:08:07 --> Language Class Initialized
INFO - 2024-06-06 21:08:07 --> Language Class Initialized
INFO - 2024-06-06 21:08:07 --> Config Class Initialized
INFO - 2024-06-06 21:08:07 --> Loader Class Initialized
INFO - 2024-06-06 21:08:07 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:07 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:07 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:07 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-06 21:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:07 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:07 --> Total execution time: 0.0835
INFO - 2024-06-06 21:08:14 --> Config Class Initialized
INFO - 2024-06-06 21:08:14 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:14 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:14 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:14 --> URI Class Initialized
INFO - 2024-06-06 21:08:14 --> Router Class Initialized
INFO - 2024-06-06 21:08:14 --> Output Class Initialized
INFO - 2024-06-06 21:08:14 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:14 --> Input Class Initialized
INFO - 2024-06-06 21:08:14 --> Language Class Initialized
INFO - 2024-06-06 21:08:14 --> Language Class Initialized
INFO - 2024-06-06 21:08:14 --> Config Class Initialized
INFO - 2024-06-06 21:08:14 --> Loader Class Initialized
INFO - 2024-06-06 21:08:14 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:14 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:15 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:15 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:15 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:15 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 21:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:15 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:15 --> Total execution time: 0.0326
INFO - 2024-06-06 21:08:17 --> Config Class Initialized
INFO - 2024-06-06 21:08:17 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:17 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:17 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:17 --> URI Class Initialized
INFO - 2024-06-06 21:08:17 --> Router Class Initialized
INFO - 2024-06-06 21:08:17 --> Output Class Initialized
INFO - 2024-06-06 21:08:17 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:17 --> Input Class Initialized
INFO - 2024-06-06 21:08:17 --> Language Class Initialized
INFO - 2024-06-06 21:08:17 --> Language Class Initialized
INFO - 2024-06-06 21:08:17 --> Config Class Initialized
INFO - 2024-06-06 21:08:17 --> Loader Class Initialized
INFO - 2024-06-06 21:08:17 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:17 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:17 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:17 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:17 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:17 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 21:08:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:17 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:17 --> Total execution time: 0.0249
INFO - 2024-06-06 21:08:19 --> Config Class Initialized
INFO - 2024-06-06 21:08:19 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:19 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:19 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:19 --> URI Class Initialized
INFO - 2024-06-06 21:08:19 --> Router Class Initialized
INFO - 2024-06-06 21:08:19 --> Output Class Initialized
INFO - 2024-06-06 21:08:19 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:19 --> Input Class Initialized
INFO - 2024-06-06 21:08:19 --> Language Class Initialized
INFO - 2024-06-06 21:08:19 --> Language Class Initialized
INFO - 2024-06-06 21:08:19 --> Config Class Initialized
INFO - 2024-06-06 21:08:19 --> Loader Class Initialized
INFO - 2024-06-06 21:08:19 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:19 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:19 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-06 21:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:19 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:19 --> Total execution time: 0.0320
INFO - 2024-06-06 21:08:19 --> Config Class Initialized
INFO - 2024-06-06 21:08:19 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:19 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:19 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:19 --> URI Class Initialized
INFO - 2024-06-06 21:08:19 --> Router Class Initialized
INFO - 2024-06-06 21:08:19 --> Output Class Initialized
INFO - 2024-06-06 21:08:19 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:19 --> Input Class Initialized
INFO - 2024-06-06 21:08:19 --> Language Class Initialized
INFO - 2024-06-06 21:08:19 --> Language Class Initialized
INFO - 2024-06-06 21:08:19 --> Config Class Initialized
INFO - 2024-06-06 21:08:19 --> Loader Class Initialized
INFO - 2024-06-06 21:08:19 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:19 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:19 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:19 --> Controller Class Initialized
INFO - 2024-06-06 21:08:21 --> Config Class Initialized
INFO - 2024-06-06 21:08:21 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:21 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:21 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:21 --> URI Class Initialized
INFO - 2024-06-06 21:08:21 --> Router Class Initialized
INFO - 2024-06-06 21:08:21 --> Output Class Initialized
INFO - 2024-06-06 21:08:21 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:21 --> Input Class Initialized
INFO - 2024-06-06 21:08:21 --> Language Class Initialized
INFO - 2024-06-06 21:08:21 --> Language Class Initialized
INFO - 2024-06-06 21:08:21 --> Config Class Initialized
INFO - 2024-06-06 21:08:21 --> Loader Class Initialized
INFO - 2024-06-06 21:08:21 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:21 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:21 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:21 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:21 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:21 --> Controller Class Initialized
INFO - 2024-06-06 21:08:21 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:21 --> Total execution time: 0.0309
INFO - 2024-06-06 21:08:23 --> Config Class Initialized
INFO - 2024-06-06 21:08:23 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:23 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:23 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:23 --> URI Class Initialized
INFO - 2024-06-06 21:08:23 --> Router Class Initialized
INFO - 2024-06-06 21:08:23 --> Output Class Initialized
INFO - 2024-06-06 21:08:23 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:23 --> Input Class Initialized
INFO - 2024-06-06 21:08:23 --> Language Class Initialized
INFO - 2024-06-06 21:08:23 --> Language Class Initialized
INFO - 2024-06-06 21:08:23 --> Config Class Initialized
INFO - 2024-06-06 21:08:23 --> Loader Class Initialized
INFO - 2024-06-06 21:08:23 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:23 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:23 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:23 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:23 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:23 --> Controller Class Initialized
INFO - 2024-06-06 21:08:23 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:23 --> Total execution time: 0.0639
INFO - 2024-06-06 21:08:26 --> Config Class Initialized
INFO - 2024-06-06 21:08:26 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:26 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:26 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:26 --> URI Class Initialized
INFO - 2024-06-06 21:08:26 --> Router Class Initialized
INFO - 2024-06-06 21:08:26 --> Output Class Initialized
INFO - 2024-06-06 21:08:26 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:26 --> Input Class Initialized
INFO - 2024-06-06 21:08:26 --> Language Class Initialized
INFO - 2024-06-06 21:08:26 --> Language Class Initialized
INFO - 2024-06-06 21:08:26 --> Config Class Initialized
INFO - 2024-06-06 21:08:26 --> Loader Class Initialized
INFO - 2024-06-06 21:08:26 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:26 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:26 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:26 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:26 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:26 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-06 21:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:26 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:26 --> Total execution time: 0.0268
INFO - 2024-06-06 21:08:27 --> Config Class Initialized
INFO - 2024-06-06 21:08:27 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:27 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:27 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:27 --> URI Class Initialized
INFO - 2024-06-06 21:08:27 --> Router Class Initialized
INFO - 2024-06-06 21:08:27 --> Output Class Initialized
INFO - 2024-06-06 21:08:27 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:27 --> Input Class Initialized
INFO - 2024-06-06 21:08:27 --> Language Class Initialized
INFO - 2024-06-06 21:08:27 --> Language Class Initialized
INFO - 2024-06-06 21:08:27 --> Config Class Initialized
INFO - 2024-06-06 21:08:27 --> Loader Class Initialized
INFO - 2024-06-06 21:08:27 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:27 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:27 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:27 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:27 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:27 --> Controller Class Initialized
DEBUG - 2024-06-06 21:08:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-06 21:08:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-06 21:08:28 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:28 --> Total execution time: 0.2811
INFO - 2024-06-06 21:08:29 --> Config Class Initialized
INFO - 2024-06-06 21:08:29 --> Hooks Class Initialized
DEBUG - 2024-06-06 21:08:29 --> UTF-8 Support Enabled
INFO - 2024-06-06 21:08:29 --> Utf8 Class Initialized
INFO - 2024-06-06 21:08:29 --> URI Class Initialized
INFO - 2024-06-06 21:08:29 --> Router Class Initialized
INFO - 2024-06-06 21:08:29 --> Output Class Initialized
INFO - 2024-06-06 21:08:29 --> Security Class Initialized
DEBUG - 2024-06-06 21:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-06 21:08:29 --> Input Class Initialized
INFO - 2024-06-06 21:08:29 --> Language Class Initialized
INFO - 2024-06-06 21:08:29 --> Language Class Initialized
INFO - 2024-06-06 21:08:29 --> Config Class Initialized
INFO - 2024-06-06 21:08:29 --> Loader Class Initialized
INFO - 2024-06-06 21:08:29 --> Helper loaded: url_helper
INFO - 2024-06-06 21:08:29 --> Helper loaded: file_helper
INFO - 2024-06-06 21:08:29 --> Helper loaded: form_helper
INFO - 2024-06-06 21:08:29 --> Helper loaded: my_helper
INFO - 2024-06-06 21:08:29 --> Database Driver Class Initialized
INFO - 2024-06-06 21:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-06 21:08:29 --> Controller Class Initialized
INFO - 2024-06-06 21:08:29 --> Final output sent to browser
DEBUG - 2024-06-06 21:08:29 --> Total execution time: 0.0342
