<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-15 16:17:12 --> Config Class Initialized
INFO - 2024-06-15 16:17:12 --> Hooks Class Initialized
DEBUG - 2024-06-15 16:17:12 --> UTF-8 Support Enabled
INFO - 2024-06-15 16:17:12 --> Utf8 Class Initialized
INFO - 2024-06-15 16:17:12 --> URI Class Initialized
INFO - 2024-06-15 16:17:12 --> Router Class Initialized
INFO - 2024-06-15 16:17:12 --> Output Class Initialized
INFO - 2024-06-15 16:17:13 --> Security Class Initialized
DEBUG - 2024-06-15 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 16:17:13 --> Input Class Initialized
INFO - 2024-06-15 16:17:13 --> Language Class Initialized
INFO - 2024-06-15 16:17:13 --> Language Class Initialized
INFO - 2024-06-15 16:17:13 --> Config Class Initialized
INFO - 2024-06-15 16:17:13 --> Loader Class Initialized
INFO - 2024-06-15 16:17:13 --> Helper loaded: url_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: file_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: form_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: my_helper
INFO - 2024-06-15 16:17:13 --> Database Driver Class Initialized
INFO - 2024-06-15 16:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 16:17:13 --> Controller Class Initialized
DEBUG - 2024-06-15 16:17:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-15 16:17:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 16:17:13 --> Final output sent to browser
DEBUG - 2024-06-15 16:17:13 --> Total execution time: 0.3347
INFO - 2024-06-15 16:17:13 --> Config Class Initialized
INFO - 2024-06-15 16:17:13 --> Hooks Class Initialized
DEBUG - 2024-06-15 16:17:13 --> UTF-8 Support Enabled
INFO - 2024-06-15 16:17:13 --> Utf8 Class Initialized
INFO - 2024-06-15 16:17:13 --> URI Class Initialized
INFO - 2024-06-15 16:17:13 --> Router Class Initialized
INFO - 2024-06-15 16:17:13 --> Output Class Initialized
INFO - 2024-06-15 16:17:13 --> Security Class Initialized
DEBUG - 2024-06-15 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 16:17:13 --> Input Class Initialized
INFO - 2024-06-15 16:17:13 --> Language Class Initialized
INFO - 2024-06-15 16:17:13 --> Language Class Initialized
INFO - 2024-06-15 16:17:13 --> Config Class Initialized
INFO - 2024-06-15 16:17:13 --> Loader Class Initialized
INFO - 2024-06-15 16:17:13 --> Helper loaded: url_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: file_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: form_helper
INFO - 2024-06-15 16:17:13 --> Helper loaded: my_helper
INFO - 2024-06-15 16:17:13 --> Database Driver Class Initialized
INFO - 2024-06-15 16:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 16:17:13 --> Controller Class Initialized
INFO - 2024-06-15 17:01:51 --> Config Class Initialized
INFO - 2024-06-15 17:01:51 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:01:51 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:01:51 --> Utf8 Class Initialized
INFO - 2024-06-15 17:01:51 --> URI Class Initialized
INFO - 2024-06-15 17:01:51 --> Router Class Initialized
INFO - 2024-06-15 17:01:51 --> Output Class Initialized
INFO - 2024-06-15 17:01:51 --> Security Class Initialized
DEBUG - 2024-06-15 17:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:01:51 --> Input Class Initialized
INFO - 2024-06-15 17:01:51 --> Language Class Initialized
INFO - 2024-06-15 17:01:51 --> Language Class Initialized
INFO - 2024-06-15 17:01:51 --> Config Class Initialized
INFO - 2024-06-15 17:01:51 --> Loader Class Initialized
INFO - 2024-06-15 17:01:51 --> Helper loaded: url_helper
INFO - 2024-06-15 17:01:51 --> Helper loaded: file_helper
INFO - 2024-06-15 17:01:51 --> Helper loaded: form_helper
INFO - 2024-06-15 17:01:51 --> Helper loaded: my_helper
INFO - 2024-06-15 17:01:51 --> Database Driver Class Initialized
INFO - 2024-06-15 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:01:51 --> Controller Class Initialized
DEBUG - 2024-06-15 17:01:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-15 17:01:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:01:51 --> Final output sent to browser
DEBUG - 2024-06-15 17:01:51 --> Total execution time: 0.1828
INFO - 2024-06-15 17:32:29 --> Config Class Initialized
INFO - 2024-06-15 17:32:29 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:29 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:29 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:29 --> URI Class Initialized
INFO - 2024-06-15 17:32:29 --> Router Class Initialized
INFO - 2024-06-15 17:32:29 --> Output Class Initialized
INFO - 2024-06-15 17:32:29 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:29 --> Input Class Initialized
INFO - 2024-06-15 17:32:29 --> Language Class Initialized
INFO - 2024-06-15 17:32:29 --> Language Class Initialized
INFO - 2024-06-15 17:32:29 --> Config Class Initialized
INFO - 2024-06-15 17:32:29 --> Loader Class Initialized
INFO - 2024-06-15 17:32:29 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:29 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:29 --> Controller Class Initialized
INFO - 2024-06-15 17:32:29 --> Config Class Initialized
INFO - 2024-06-15 17:32:29 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:29 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:29 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:29 --> URI Class Initialized
INFO - 2024-06-15 17:32:29 --> Router Class Initialized
INFO - 2024-06-15 17:32:29 --> Output Class Initialized
INFO - 2024-06-15 17:32:29 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:29 --> Input Class Initialized
INFO - 2024-06-15 17:32:29 --> Language Class Initialized
INFO - 2024-06-15 17:32:29 --> Language Class Initialized
INFO - 2024-06-15 17:32:29 --> Config Class Initialized
INFO - 2024-06-15 17:32:29 --> Loader Class Initialized
INFO - 2024-06-15 17:32:29 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:29 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:29 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:30 --> Controller Class Initialized
DEBUG - 2024-06-15 17:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-15 17:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:32:30 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:30 --> Total execution time: 0.5492
INFO - 2024-06-15 17:32:43 --> Config Class Initialized
INFO - 2024-06-15 17:32:43 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:43 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:43 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:43 --> URI Class Initialized
INFO - 2024-06-15 17:32:43 --> Router Class Initialized
INFO - 2024-06-15 17:32:43 --> Output Class Initialized
INFO - 2024-06-15 17:32:43 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:43 --> Input Class Initialized
INFO - 2024-06-15 17:32:43 --> Language Class Initialized
INFO - 2024-06-15 17:32:43 --> Language Class Initialized
INFO - 2024-06-15 17:32:43 --> Config Class Initialized
INFO - 2024-06-15 17:32:43 --> Loader Class Initialized
INFO - 2024-06-15 17:32:43 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:43 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:43 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:43 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:44 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:44 --> Controller Class Initialized
INFO - 2024-06-15 17:32:44 --> Helper loaded: cookie_helper
INFO - 2024-06-15 17:32:44 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:44 --> Total execution time: 0.7923
INFO - 2024-06-15 17:32:44 --> Config Class Initialized
INFO - 2024-06-15 17:32:44 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:44 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:44 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:44 --> URI Class Initialized
INFO - 2024-06-15 17:32:44 --> Router Class Initialized
INFO - 2024-06-15 17:32:44 --> Output Class Initialized
INFO - 2024-06-15 17:32:44 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:44 --> Input Class Initialized
INFO - 2024-06-15 17:32:44 --> Language Class Initialized
INFO - 2024-06-15 17:32:44 --> Language Class Initialized
INFO - 2024-06-15 17:32:44 --> Config Class Initialized
INFO - 2024-06-15 17:32:44 --> Loader Class Initialized
INFO - 2024-06-15 17:32:44 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:44 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:44 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:44 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:44 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:44 --> Controller Class Initialized
DEBUG - 2024-06-15 17:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-15 17:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:32:45 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:45 --> Total execution time: 0.3619
INFO - 2024-06-15 17:32:46 --> Config Class Initialized
INFO - 2024-06-15 17:32:46 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:46 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:46 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:46 --> URI Class Initialized
INFO - 2024-06-15 17:32:46 --> Router Class Initialized
INFO - 2024-06-15 17:32:46 --> Output Class Initialized
INFO - 2024-06-15 17:32:46 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:46 --> Input Class Initialized
INFO - 2024-06-15 17:32:46 --> Language Class Initialized
INFO - 2024-06-15 17:32:46 --> Language Class Initialized
INFO - 2024-06-15 17:32:46 --> Config Class Initialized
INFO - 2024-06-15 17:32:46 --> Loader Class Initialized
INFO - 2024-06-15 17:32:46 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:46 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:46 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:46 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:46 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:46 --> Controller Class Initialized
INFO - 2024-06-15 17:32:47 --> Config Class Initialized
INFO - 2024-06-15 17:32:47 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:47 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:47 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:47 --> URI Class Initialized
INFO - 2024-06-15 17:32:47 --> Router Class Initialized
INFO - 2024-06-15 17:32:47 --> Output Class Initialized
INFO - 2024-06-15 17:32:47 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:47 --> Input Class Initialized
INFO - 2024-06-15 17:32:47 --> Language Class Initialized
INFO - 2024-06-15 17:32:47 --> Language Class Initialized
INFO - 2024-06-15 17:32:47 --> Config Class Initialized
INFO - 2024-06-15 17:32:47 --> Loader Class Initialized
INFO - 2024-06-15 17:32:47 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:47 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:47 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:47 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:47 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:47 --> Controller Class Initialized
DEBUG - 2024-06-15 17:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-15 17:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:32:47 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:47 --> Total execution time: 0.0357
INFO - 2024-06-15 17:32:52 --> Config Class Initialized
INFO - 2024-06-15 17:32:52 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:52 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:52 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:52 --> URI Class Initialized
INFO - 2024-06-15 17:32:52 --> Router Class Initialized
INFO - 2024-06-15 17:32:52 --> Output Class Initialized
INFO - 2024-06-15 17:32:52 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:52 --> Input Class Initialized
INFO - 2024-06-15 17:32:52 --> Language Class Initialized
INFO - 2024-06-15 17:32:52 --> Language Class Initialized
INFO - 2024-06-15 17:32:52 --> Config Class Initialized
INFO - 2024-06-15 17:32:52 --> Loader Class Initialized
INFO - 2024-06-15 17:32:52 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:52 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:52 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:52 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:52 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:52 --> Controller Class Initialized
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-15 17:32:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-15 17:32:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-15 17:32:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:32:52 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:52 --> Total execution time: 0.3770
INFO - 2024-06-15 17:32:55 --> Config Class Initialized
INFO - 2024-06-15 17:32:55 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:55 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:55 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:55 --> URI Class Initialized
INFO - 2024-06-15 17:32:55 --> Router Class Initialized
INFO - 2024-06-15 17:32:55 --> Output Class Initialized
INFO - 2024-06-15 17:32:55 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:55 --> Input Class Initialized
INFO - 2024-06-15 17:32:55 --> Language Class Initialized
INFO - 2024-06-15 17:32:55 --> Language Class Initialized
INFO - 2024-06-15 17:32:55 --> Config Class Initialized
INFO - 2024-06-15 17:32:55 --> Loader Class Initialized
INFO - 2024-06-15 17:32:55 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:55 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:55 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:55 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:55 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:55 --> Controller Class Initialized
DEBUG - 2024-06-15 17:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-15 17:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:32:55 --> Final output sent to browser
DEBUG - 2024-06-15 17:32:55 --> Total execution time: 0.1289
INFO - 2024-06-15 17:32:56 --> Config Class Initialized
INFO - 2024-06-15 17:32:56 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:32:56 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:32:56 --> Utf8 Class Initialized
INFO - 2024-06-15 17:32:56 --> URI Class Initialized
INFO - 2024-06-15 17:32:56 --> Router Class Initialized
INFO - 2024-06-15 17:32:56 --> Output Class Initialized
INFO - 2024-06-15 17:32:56 --> Security Class Initialized
DEBUG - 2024-06-15 17:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:32:56 --> Input Class Initialized
INFO - 2024-06-15 17:32:56 --> Language Class Initialized
INFO - 2024-06-15 17:32:56 --> Language Class Initialized
INFO - 2024-06-15 17:32:56 --> Config Class Initialized
INFO - 2024-06-15 17:32:56 --> Loader Class Initialized
INFO - 2024-06-15 17:32:56 --> Helper loaded: url_helper
INFO - 2024-06-15 17:32:56 --> Helper loaded: file_helper
INFO - 2024-06-15 17:32:56 --> Helper loaded: form_helper
INFO - 2024-06-15 17:32:56 --> Helper loaded: my_helper
INFO - 2024-06-15 17:32:56 --> Database Driver Class Initialized
INFO - 2024-06-15 17:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:32:56 --> Controller Class Initialized
INFO - 2024-06-15 17:33:04 --> Config Class Initialized
INFO - 2024-06-15 17:33:04 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:04 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:04 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:04 --> URI Class Initialized
INFO - 2024-06-15 17:33:04 --> Router Class Initialized
INFO - 2024-06-15 17:33:04 --> Output Class Initialized
INFO - 2024-06-15 17:33:04 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:04 --> Input Class Initialized
INFO - 2024-06-15 17:33:04 --> Language Class Initialized
INFO - 2024-06-15 17:33:04 --> Language Class Initialized
INFO - 2024-06-15 17:33:04 --> Config Class Initialized
INFO - 2024-06-15 17:33:04 --> Loader Class Initialized
INFO - 2024-06-15 17:33:04 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:04 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:04 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:04 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:04 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:05 --> Controller Class Initialized
DEBUG - 2024-06-15 17:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-06-15 17:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:33:05 --> Final output sent to browser
DEBUG - 2024-06-15 17:33:05 --> Total execution time: 0.4509
INFO - 2024-06-15 17:33:09 --> Config Class Initialized
INFO - 2024-06-15 17:33:09 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:09 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:09 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:09 --> URI Class Initialized
INFO - 2024-06-15 17:33:09 --> Router Class Initialized
INFO - 2024-06-15 17:33:09 --> Output Class Initialized
INFO - 2024-06-15 17:33:09 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:09 --> Input Class Initialized
INFO - 2024-06-15 17:33:09 --> Language Class Initialized
INFO - 2024-06-15 17:33:09 --> Language Class Initialized
INFO - 2024-06-15 17:33:09 --> Config Class Initialized
INFO - 2024-06-15 17:33:09 --> Loader Class Initialized
INFO - 2024-06-15 17:33:09 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:09 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:09 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:09 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:09 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:09 --> Controller Class Initialized
DEBUG - 2024-06-15 17:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-15 17:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:33:09 --> Final output sent to browser
DEBUG - 2024-06-15 17:33:09 --> Total execution time: 0.5689
INFO - 2024-06-15 17:33:11 --> Config Class Initialized
INFO - 2024-06-15 17:33:11 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:11 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:11 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:12 --> URI Class Initialized
INFO - 2024-06-15 17:33:12 --> Router Class Initialized
INFO - 2024-06-15 17:33:12 --> Output Class Initialized
INFO - 2024-06-15 17:33:12 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:12 --> Input Class Initialized
INFO - 2024-06-15 17:33:12 --> Language Class Initialized
INFO - 2024-06-15 17:33:12 --> Language Class Initialized
INFO - 2024-06-15 17:33:12 --> Config Class Initialized
INFO - 2024-06-15 17:33:12 --> Loader Class Initialized
INFO - 2024-06-15 17:33:12 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:12 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:12 --> Controller Class Initialized
DEBUG - 2024-06-15 17:33:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-15 17:33:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:33:12 --> Final output sent to browser
DEBUG - 2024-06-15 17:33:12 --> Total execution time: 0.2432
INFO - 2024-06-15 17:33:12 --> Config Class Initialized
INFO - 2024-06-15 17:33:12 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:12 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:12 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:12 --> URI Class Initialized
INFO - 2024-06-15 17:33:12 --> Router Class Initialized
INFO - 2024-06-15 17:33:12 --> Output Class Initialized
INFO - 2024-06-15 17:33:12 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:12 --> Input Class Initialized
INFO - 2024-06-15 17:33:12 --> Language Class Initialized
INFO - 2024-06-15 17:33:12 --> Language Class Initialized
INFO - 2024-06-15 17:33:12 --> Config Class Initialized
INFO - 2024-06-15 17:33:12 --> Loader Class Initialized
INFO - 2024-06-15 17:33:12 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:12 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:12 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:12 --> Controller Class Initialized
INFO - 2024-06-15 17:33:20 --> Config Class Initialized
INFO - 2024-06-15 17:33:20 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:20 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:20 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:20 --> URI Class Initialized
INFO - 2024-06-15 17:33:20 --> Router Class Initialized
INFO - 2024-06-15 17:33:20 --> Output Class Initialized
INFO - 2024-06-15 17:33:20 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:20 --> Input Class Initialized
INFO - 2024-06-15 17:33:20 --> Language Class Initialized
INFO - 2024-06-15 17:33:20 --> Language Class Initialized
INFO - 2024-06-15 17:33:20 --> Config Class Initialized
INFO - 2024-06-15 17:33:20 --> Loader Class Initialized
INFO - 2024-06-15 17:33:20 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:20 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:20 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:20 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:20 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:20 --> Controller Class Initialized
DEBUG - 2024-06-15 17:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-15 17:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:33:20 --> Final output sent to browser
DEBUG - 2024-06-15 17:33:20 --> Total execution time: 0.1161
INFO - 2024-06-15 17:33:26 --> Config Class Initialized
INFO - 2024-06-15 17:33:26 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:33:26 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:33:26 --> Utf8 Class Initialized
INFO - 2024-06-15 17:33:26 --> URI Class Initialized
INFO - 2024-06-15 17:33:26 --> Router Class Initialized
INFO - 2024-06-15 17:33:26 --> Output Class Initialized
INFO - 2024-06-15 17:33:26 --> Security Class Initialized
DEBUG - 2024-06-15 17:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:33:26 --> Input Class Initialized
INFO - 2024-06-15 17:33:26 --> Language Class Initialized
INFO - 2024-06-15 17:33:26 --> Language Class Initialized
INFO - 2024-06-15 17:33:26 --> Config Class Initialized
INFO - 2024-06-15 17:33:26 --> Loader Class Initialized
INFO - 2024-06-15 17:33:26 --> Helper loaded: url_helper
INFO - 2024-06-15 17:33:26 --> Helper loaded: file_helper
INFO - 2024-06-15 17:33:26 --> Helper loaded: form_helper
INFO - 2024-06-15 17:33:26 --> Helper loaded: my_helper
INFO - 2024-06-15 17:33:26 --> Database Driver Class Initialized
INFO - 2024-06-15 17:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:33:26 --> Controller Class Initialized
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2024-06-15 17:33:27 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3192
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
ERROR - 2024-06-15 17:33:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
ERROR - 2024-06-15 17:33:27 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3230
DEBUG - 2024-06-15 17:33:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-15 17:33:33 --> Final output sent to browser
DEBUG - 2024-06-15 17:33:33 --> Total execution time: 6.9009
INFO - 2024-06-15 17:34:52 --> Config Class Initialized
INFO - 2024-06-15 17:34:52 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:34:52 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:34:52 --> Utf8 Class Initialized
INFO - 2024-06-15 17:34:52 --> URI Class Initialized
INFO - 2024-06-15 17:34:52 --> Router Class Initialized
INFO - 2024-06-15 17:34:52 --> Output Class Initialized
INFO - 2024-06-15 17:34:52 --> Security Class Initialized
DEBUG - 2024-06-15 17:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:34:52 --> Input Class Initialized
INFO - 2024-06-15 17:34:52 --> Language Class Initialized
INFO - 2024-06-15 17:34:52 --> Language Class Initialized
INFO - 2024-06-15 17:34:52 --> Config Class Initialized
INFO - 2024-06-15 17:34:52 --> Loader Class Initialized
INFO - 2024-06-15 17:34:52 --> Helper loaded: url_helper
INFO - 2024-06-15 17:34:52 --> Helper loaded: file_helper
INFO - 2024-06-15 17:34:52 --> Helper loaded: form_helper
INFO - 2024-06-15 17:34:52 --> Helper loaded: my_helper
INFO - 2024-06-15 17:34:52 --> Database Driver Class Initialized
INFO - 2024-06-15 17:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:34:52 --> Controller Class Initialized
DEBUG - 2024-06-15 17:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-15 17:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:34:52 --> Final output sent to browser
DEBUG - 2024-06-15 17:34:52 --> Total execution time: 0.2449
INFO - 2024-06-15 17:34:54 --> Config Class Initialized
INFO - 2024-06-15 17:34:54 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:34:54 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:34:54 --> Utf8 Class Initialized
INFO - 2024-06-15 17:34:54 --> URI Class Initialized
INFO - 2024-06-15 17:34:54 --> Router Class Initialized
INFO - 2024-06-15 17:34:54 --> Output Class Initialized
INFO - 2024-06-15 17:34:54 --> Security Class Initialized
DEBUG - 2024-06-15 17:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:34:54 --> Input Class Initialized
INFO - 2024-06-15 17:34:54 --> Language Class Initialized
INFO - 2024-06-15 17:34:54 --> Language Class Initialized
INFO - 2024-06-15 17:34:54 --> Config Class Initialized
INFO - 2024-06-15 17:34:54 --> Loader Class Initialized
INFO - 2024-06-15 17:34:54 --> Helper loaded: url_helper
INFO - 2024-06-15 17:34:54 --> Helper loaded: file_helper
INFO - 2024-06-15 17:34:54 --> Helper loaded: form_helper
INFO - 2024-06-15 17:34:54 --> Helper loaded: my_helper
INFO - 2024-06-15 17:34:54 --> Database Driver Class Initialized
INFO - 2024-06-15 17:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:34:54 --> Controller Class Initialized
DEBUG - 2024-06-15 17:34:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-15 17:34:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 17:34:54 --> Final output sent to browser
DEBUG - 2024-06-15 17:34:54 --> Total execution time: 0.3280
INFO - 2024-06-15 17:34:55 --> Config Class Initialized
INFO - 2024-06-15 17:34:55 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:34:55 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:34:55 --> Utf8 Class Initialized
INFO - 2024-06-15 17:34:55 --> URI Class Initialized
INFO - 2024-06-15 17:34:55 --> Router Class Initialized
INFO - 2024-06-15 17:34:55 --> Output Class Initialized
INFO - 2024-06-15 17:34:55 --> Security Class Initialized
DEBUG - 2024-06-15 17:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:34:55 --> Input Class Initialized
INFO - 2024-06-15 17:34:55 --> Language Class Initialized
INFO - 2024-06-15 17:34:55 --> Language Class Initialized
INFO - 2024-06-15 17:34:55 --> Config Class Initialized
INFO - 2024-06-15 17:34:55 --> Loader Class Initialized
INFO - 2024-06-15 17:34:55 --> Helper loaded: url_helper
INFO - 2024-06-15 17:34:55 --> Helper loaded: file_helper
INFO - 2024-06-15 17:34:55 --> Helper loaded: form_helper
INFO - 2024-06-15 17:34:55 --> Helper loaded: my_helper
INFO - 2024-06-15 17:34:55 --> Database Driver Class Initialized
INFO - 2024-06-15 17:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:34:55 --> Controller Class Initialized
INFO - 2024-06-15 17:34:56 --> Config Class Initialized
INFO - 2024-06-15 17:34:56 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:34:56 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:34:56 --> Utf8 Class Initialized
INFO - 2024-06-15 17:34:56 --> URI Class Initialized
INFO - 2024-06-15 17:34:56 --> Router Class Initialized
INFO - 2024-06-15 17:34:56 --> Output Class Initialized
INFO - 2024-06-15 17:34:56 --> Security Class Initialized
DEBUG - 2024-06-15 17:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:34:56 --> Input Class Initialized
INFO - 2024-06-15 17:34:56 --> Language Class Initialized
INFO - 2024-06-15 17:34:57 --> Language Class Initialized
INFO - 2024-06-15 17:34:57 --> Config Class Initialized
INFO - 2024-06-15 17:34:57 --> Loader Class Initialized
INFO - 2024-06-15 17:34:57 --> Helper loaded: url_helper
INFO - 2024-06-15 17:34:57 --> Helper loaded: file_helper
INFO - 2024-06-15 17:34:57 --> Helper loaded: form_helper
INFO - 2024-06-15 17:34:57 --> Helper loaded: my_helper
INFO - 2024-06-15 17:34:57 --> Database Driver Class Initialized
INFO - 2024-06-15 17:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:34:57 --> Controller Class Initialized
INFO - 2024-06-15 17:34:57 --> Final output sent to browser
DEBUG - 2024-06-15 17:34:57 --> Total execution time: 0.1751
INFO - 2024-06-15 17:41:15 --> Config Class Initialized
INFO - 2024-06-15 17:41:15 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:41:15 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:41:15 --> Utf8 Class Initialized
INFO - 2024-06-15 17:41:15 --> URI Class Initialized
INFO - 2024-06-15 17:41:15 --> Router Class Initialized
INFO - 2024-06-15 17:41:15 --> Output Class Initialized
INFO - 2024-06-15 17:41:15 --> Security Class Initialized
DEBUG - 2024-06-15 17:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:41:15 --> Input Class Initialized
INFO - 2024-06-15 17:41:15 --> Language Class Initialized
INFO - 2024-06-15 17:41:15 --> Language Class Initialized
INFO - 2024-06-15 17:41:15 --> Config Class Initialized
INFO - 2024-06-15 17:41:15 --> Loader Class Initialized
INFO - 2024-06-15 17:41:15 --> Helper loaded: url_helper
INFO - 2024-06-15 17:41:15 --> Helper loaded: file_helper
INFO - 2024-06-15 17:41:15 --> Helper loaded: form_helper
INFO - 2024-06-15 17:41:15 --> Helper loaded: my_helper
INFO - 2024-06-15 17:41:15 --> Database Driver Class Initialized
INFO - 2024-06-15 17:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:41:15 --> Controller Class Initialized
INFO - 2024-06-15 17:41:15 --> Final output sent to browser
DEBUG - 2024-06-15 17:41:15 --> Total execution time: 0.2052
INFO - 2024-06-15 17:42:57 --> Config Class Initialized
INFO - 2024-06-15 17:42:57 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:42:57 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:42:57 --> Utf8 Class Initialized
INFO - 2024-06-15 17:42:57 --> URI Class Initialized
INFO - 2024-06-15 17:42:57 --> Router Class Initialized
INFO - 2024-06-15 17:42:57 --> Output Class Initialized
INFO - 2024-06-15 17:42:57 --> Security Class Initialized
DEBUG - 2024-06-15 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:42:57 --> Input Class Initialized
INFO - 2024-06-15 17:42:57 --> Language Class Initialized
INFO - 2024-06-15 17:42:57 --> Language Class Initialized
INFO - 2024-06-15 17:42:57 --> Config Class Initialized
INFO - 2024-06-15 17:42:57 --> Loader Class Initialized
INFO - 2024-06-15 17:42:57 --> Helper loaded: url_helper
INFO - 2024-06-15 17:42:57 --> Helper loaded: file_helper
INFO - 2024-06-15 17:42:57 --> Helper loaded: form_helper
INFO - 2024-06-15 17:42:57 --> Helper loaded: my_helper
INFO - 2024-06-15 17:42:57 --> Database Driver Class Initialized
INFO - 2024-06-15 17:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:42:57 --> Controller Class Initialized
INFO - 2024-06-15 17:42:57 --> Final output sent to browser
DEBUG - 2024-06-15 17:42:57 --> Total execution time: 0.2892
INFO - 2024-06-15 17:43:01 --> Config Class Initialized
INFO - 2024-06-15 17:43:01 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:43:01 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:43:01 --> Utf8 Class Initialized
INFO - 2024-06-15 17:43:01 --> URI Class Initialized
INFO - 2024-06-15 17:43:01 --> Router Class Initialized
INFO - 2024-06-15 17:43:01 --> Output Class Initialized
INFO - 2024-06-15 17:43:01 --> Security Class Initialized
DEBUG - 2024-06-15 17:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:43:01 --> Input Class Initialized
INFO - 2024-06-15 17:43:01 --> Language Class Initialized
INFO - 2024-06-15 17:43:01 --> Language Class Initialized
INFO - 2024-06-15 17:43:01 --> Config Class Initialized
INFO - 2024-06-15 17:43:01 --> Loader Class Initialized
INFO - 2024-06-15 17:43:01 --> Helper loaded: url_helper
INFO - 2024-06-15 17:43:01 --> Helper loaded: file_helper
INFO - 2024-06-15 17:43:01 --> Helper loaded: form_helper
INFO - 2024-06-15 17:43:01 --> Helper loaded: my_helper
INFO - 2024-06-15 17:43:01 --> Database Driver Class Initialized
INFO - 2024-06-15 17:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:43:01 --> Controller Class Initialized
INFO - 2024-06-15 17:43:02 --> Final output sent to browser
DEBUG - 2024-06-15 17:43:02 --> Total execution time: 0.9616
INFO - 2024-06-15 17:52:13 --> Config Class Initialized
INFO - 2024-06-15 17:52:13 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:52:13 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:52:13 --> Utf8 Class Initialized
INFO - 2024-06-15 17:52:13 --> URI Class Initialized
INFO - 2024-06-15 17:52:13 --> Router Class Initialized
INFO - 2024-06-15 17:52:13 --> Output Class Initialized
INFO - 2024-06-15 17:52:13 --> Security Class Initialized
DEBUG - 2024-06-15 17:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:52:13 --> Input Class Initialized
INFO - 2024-06-15 17:52:13 --> Language Class Initialized
INFO - 2024-06-15 17:52:13 --> Language Class Initialized
INFO - 2024-06-15 17:52:13 --> Config Class Initialized
INFO - 2024-06-15 17:52:13 --> Loader Class Initialized
INFO - 2024-06-15 17:52:13 --> Helper loaded: url_helper
INFO - 2024-06-15 17:52:13 --> Helper loaded: file_helper
INFO - 2024-06-15 17:52:13 --> Helper loaded: form_helper
INFO - 2024-06-15 17:52:13 --> Helper loaded: my_helper
INFO - 2024-06-15 17:52:13 --> Database Driver Class Initialized
INFO - 2024-06-15 17:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:52:13 --> Controller Class Initialized
INFO - 2024-06-15 17:52:13 --> Final output sent to browser
DEBUG - 2024-06-15 17:52:13 --> Total execution time: 0.2612
INFO - 2024-06-15 17:52:16 --> Config Class Initialized
INFO - 2024-06-15 17:52:16 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:52:16 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:52:16 --> Utf8 Class Initialized
INFO - 2024-06-15 17:52:16 --> URI Class Initialized
INFO - 2024-06-15 17:52:16 --> Router Class Initialized
INFO - 2024-06-15 17:52:17 --> Output Class Initialized
INFO - 2024-06-15 17:52:17 --> Security Class Initialized
DEBUG - 2024-06-15 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:52:17 --> Input Class Initialized
INFO - 2024-06-15 17:52:17 --> Language Class Initialized
INFO - 2024-06-15 17:52:17 --> Language Class Initialized
INFO - 2024-06-15 17:52:17 --> Config Class Initialized
INFO - 2024-06-15 17:52:17 --> Loader Class Initialized
INFO - 2024-06-15 17:52:17 --> Helper loaded: url_helper
INFO - 2024-06-15 17:52:17 --> Helper loaded: file_helper
INFO - 2024-06-15 17:52:17 --> Helper loaded: form_helper
INFO - 2024-06-15 17:52:17 --> Helper loaded: my_helper
INFO - 2024-06-15 17:52:17 --> Database Driver Class Initialized
INFO - 2024-06-15 17:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:52:17 --> Controller Class Initialized
INFO - 2024-06-15 17:52:17 --> Final output sent to browser
DEBUG - 2024-06-15 17:52:17 --> Total execution time: 0.2523
INFO - 2024-06-15 17:52:32 --> Config Class Initialized
INFO - 2024-06-15 17:52:32 --> Hooks Class Initialized
DEBUG - 2024-06-15 17:52:32 --> UTF-8 Support Enabled
INFO - 2024-06-15 17:52:32 --> Utf8 Class Initialized
INFO - 2024-06-15 17:52:32 --> URI Class Initialized
INFO - 2024-06-15 17:52:32 --> Router Class Initialized
INFO - 2024-06-15 17:52:32 --> Output Class Initialized
INFO - 2024-06-15 17:52:32 --> Security Class Initialized
DEBUG - 2024-06-15 17:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 17:52:32 --> Input Class Initialized
INFO - 2024-06-15 17:52:32 --> Language Class Initialized
INFO - 2024-06-15 17:52:32 --> Language Class Initialized
INFO - 2024-06-15 17:52:32 --> Config Class Initialized
INFO - 2024-06-15 17:52:32 --> Loader Class Initialized
INFO - 2024-06-15 17:52:32 --> Helper loaded: url_helper
INFO - 2024-06-15 17:52:32 --> Helper loaded: file_helper
INFO - 2024-06-15 17:52:32 --> Helper loaded: form_helper
INFO - 2024-06-15 17:52:32 --> Helper loaded: my_helper
INFO - 2024-06-15 17:52:32 --> Database Driver Class Initialized
INFO - 2024-06-15 17:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 17:52:33 --> Controller Class Initialized
INFO - 2024-06-15 17:52:33 --> Final output sent to browser
DEBUG - 2024-06-15 17:52:33 --> Total execution time: 0.1110
INFO - 2024-06-15 18:30:39 --> Config Class Initialized
INFO - 2024-06-15 18:30:39 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:30:39 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:30:39 --> Utf8 Class Initialized
INFO - 2024-06-15 18:30:39 --> URI Class Initialized
INFO - 2024-06-15 18:30:39 --> Router Class Initialized
INFO - 2024-06-15 18:30:39 --> Output Class Initialized
INFO - 2024-06-15 18:30:39 --> Security Class Initialized
DEBUG - 2024-06-15 18:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:30:39 --> Input Class Initialized
INFO - 2024-06-15 18:30:39 --> Language Class Initialized
INFO - 2024-06-15 18:30:39 --> Language Class Initialized
INFO - 2024-06-15 18:30:39 --> Config Class Initialized
INFO - 2024-06-15 18:30:39 --> Loader Class Initialized
INFO - 2024-06-15 18:30:39 --> Helper loaded: url_helper
INFO - 2024-06-15 18:30:39 --> Helper loaded: file_helper
INFO - 2024-06-15 18:30:39 --> Helper loaded: form_helper
INFO - 2024-06-15 18:30:39 --> Helper loaded: my_helper
INFO - 2024-06-15 18:30:39 --> Database Driver Class Initialized
INFO - 2024-06-15 18:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:30:39 --> Controller Class Initialized
INFO - 2024-06-15 18:30:39 --> Final output sent to browser
DEBUG - 2024-06-15 18:30:39 --> Total execution time: 0.3389
INFO - 2024-06-15 18:40:12 --> Config Class Initialized
INFO - 2024-06-15 18:40:12 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:40:12 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:40:12 --> Utf8 Class Initialized
INFO - 2024-06-15 18:40:12 --> URI Class Initialized
INFO - 2024-06-15 18:40:12 --> Router Class Initialized
INFO - 2024-06-15 18:40:12 --> Output Class Initialized
INFO - 2024-06-15 18:40:12 --> Security Class Initialized
DEBUG - 2024-06-15 18:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:40:12 --> Input Class Initialized
INFO - 2024-06-15 18:40:12 --> Language Class Initialized
INFO - 2024-06-15 18:40:12 --> Language Class Initialized
INFO - 2024-06-15 18:40:12 --> Config Class Initialized
INFO - 2024-06-15 18:40:12 --> Loader Class Initialized
INFO - 2024-06-15 18:40:12 --> Helper loaded: url_helper
INFO - 2024-06-15 18:40:12 --> Helper loaded: file_helper
INFO - 2024-06-15 18:40:12 --> Helper loaded: form_helper
INFO - 2024-06-15 18:40:12 --> Helper loaded: my_helper
INFO - 2024-06-15 18:40:12 --> Database Driver Class Initialized
INFO - 2024-06-15 18:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:40:12 --> Controller Class Initialized
INFO - 2024-06-15 18:40:13 --> Final output sent to browser
DEBUG - 2024-06-15 18:40:13 --> Total execution time: 0.2620
INFO - 2024-06-15 18:41:25 --> Config Class Initialized
INFO - 2024-06-15 18:41:25 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:41:25 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:41:25 --> Utf8 Class Initialized
INFO - 2024-06-15 18:41:25 --> URI Class Initialized
INFO - 2024-06-15 18:41:25 --> Router Class Initialized
INFO - 2024-06-15 18:41:25 --> Output Class Initialized
INFO - 2024-06-15 18:41:25 --> Security Class Initialized
DEBUG - 2024-06-15 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:41:25 --> Input Class Initialized
INFO - 2024-06-15 18:41:25 --> Language Class Initialized
INFO - 2024-06-15 18:41:25 --> Language Class Initialized
INFO - 2024-06-15 18:41:25 --> Config Class Initialized
INFO - 2024-06-15 18:41:25 --> Loader Class Initialized
INFO - 2024-06-15 18:41:25 --> Helper loaded: url_helper
INFO - 2024-06-15 18:41:25 --> Helper loaded: file_helper
INFO - 2024-06-15 18:41:25 --> Helper loaded: form_helper
INFO - 2024-06-15 18:41:25 --> Helper loaded: my_helper
INFO - 2024-06-15 18:41:25 --> Database Driver Class Initialized
INFO - 2024-06-15 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:41:25 --> Controller Class Initialized
INFO - 2024-06-15 18:41:25 --> Final output sent to browser
DEBUG - 2024-06-15 18:41:25 --> Total execution time: 0.1819
INFO - 2024-06-15 18:41:28 --> Config Class Initialized
INFO - 2024-06-15 18:41:28 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:41:28 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:41:28 --> Utf8 Class Initialized
INFO - 2024-06-15 18:41:28 --> URI Class Initialized
INFO - 2024-06-15 18:41:28 --> Router Class Initialized
INFO - 2024-06-15 18:41:28 --> Output Class Initialized
INFO - 2024-06-15 18:41:28 --> Security Class Initialized
DEBUG - 2024-06-15 18:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:41:28 --> Input Class Initialized
INFO - 2024-06-15 18:41:28 --> Language Class Initialized
INFO - 2024-06-15 18:41:28 --> Language Class Initialized
INFO - 2024-06-15 18:41:28 --> Config Class Initialized
INFO - 2024-06-15 18:41:28 --> Loader Class Initialized
INFO - 2024-06-15 18:41:28 --> Helper loaded: url_helper
INFO - 2024-06-15 18:41:28 --> Helper loaded: file_helper
INFO - 2024-06-15 18:41:28 --> Helper loaded: form_helper
INFO - 2024-06-15 18:41:28 --> Helper loaded: my_helper
INFO - 2024-06-15 18:41:28 --> Database Driver Class Initialized
INFO - 2024-06-15 18:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:41:28 --> Controller Class Initialized
INFO - 2024-06-15 18:41:28 --> Final output sent to browser
DEBUG - 2024-06-15 18:41:28 --> Total execution time: 0.4187
INFO - 2024-06-15 18:41:29 --> Config Class Initialized
INFO - 2024-06-15 18:41:29 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:41:29 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:41:29 --> Utf8 Class Initialized
INFO - 2024-06-15 18:41:29 --> URI Class Initialized
INFO - 2024-06-15 18:41:29 --> Router Class Initialized
INFO - 2024-06-15 18:41:29 --> Output Class Initialized
INFO - 2024-06-15 18:41:29 --> Security Class Initialized
DEBUG - 2024-06-15 18:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:41:29 --> Input Class Initialized
INFO - 2024-06-15 18:41:29 --> Language Class Initialized
INFO - 2024-06-15 18:41:29 --> Language Class Initialized
INFO - 2024-06-15 18:41:29 --> Config Class Initialized
INFO - 2024-06-15 18:41:29 --> Loader Class Initialized
INFO - 2024-06-15 18:41:29 --> Helper loaded: url_helper
INFO - 2024-06-15 18:41:29 --> Helper loaded: file_helper
INFO - 2024-06-15 18:41:29 --> Helper loaded: form_helper
INFO - 2024-06-15 18:41:29 --> Helper loaded: my_helper
INFO - 2024-06-15 18:41:29 --> Database Driver Class Initialized
INFO - 2024-06-15 18:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:41:29 --> Controller Class Initialized
INFO - 2024-06-15 18:41:29 --> Final output sent to browser
DEBUG - 2024-06-15 18:41:29 --> Total execution time: 0.1188
INFO - 2024-06-15 18:45:04 --> Config Class Initialized
INFO - 2024-06-15 18:45:04 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:45:04 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:45:04 --> Utf8 Class Initialized
INFO - 2024-06-15 18:45:04 --> URI Class Initialized
INFO - 2024-06-15 18:45:04 --> Router Class Initialized
INFO - 2024-06-15 18:45:04 --> Output Class Initialized
INFO - 2024-06-15 18:45:04 --> Security Class Initialized
DEBUG - 2024-06-15 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:45:04 --> Input Class Initialized
INFO - 2024-06-15 18:45:04 --> Language Class Initialized
INFO - 2024-06-15 18:45:04 --> Language Class Initialized
INFO - 2024-06-15 18:45:04 --> Config Class Initialized
INFO - 2024-06-15 18:45:04 --> Loader Class Initialized
INFO - 2024-06-15 18:45:04 --> Helper loaded: url_helper
INFO - 2024-06-15 18:45:04 --> Helper loaded: file_helper
INFO - 2024-06-15 18:45:04 --> Helper loaded: form_helper
INFO - 2024-06-15 18:45:04 --> Helper loaded: my_helper
INFO - 2024-06-15 18:45:04 --> Database Driver Class Initialized
INFO - 2024-06-15 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:45:04 --> Controller Class Initialized
INFO - 2024-06-15 18:45:04 --> Final output sent to browser
DEBUG - 2024-06-15 18:45:04 --> Total execution time: 0.2984
INFO - 2024-06-15 18:45:09 --> Config Class Initialized
INFO - 2024-06-15 18:45:09 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:45:09 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:45:09 --> Utf8 Class Initialized
INFO - 2024-06-15 18:45:09 --> URI Class Initialized
INFO - 2024-06-15 18:45:09 --> Router Class Initialized
INFO - 2024-06-15 18:45:09 --> Output Class Initialized
INFO - 2024-06-15 18:45:09 --> Security Class Initialized
DEBUG - 2024-06-15 18:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:45:09 --> Input Class Initialized
INFO - 2024-06-15 18:45:09 --> Language Class Initialized
INFO - 2024-06-15 18:45:09 --> Language Class Initialized
INFO - 2024-06-15 18:45:09 --> Config Class Initialized
INFO - 2024-06-15 18:45:09 --> Loader Class Initialized
INFO - 2024-06-15 18:45:09 --> Helper loaded: url_helper
INFO - 2024-06-15 18:45:09 --> Helper loaded: file_helper
INFO - 2024-06-15 18:45:09 --> Helper loaded: form_helper
INFO - 2024-06-15 18:45:09 --> Helper loaded: my_helper
INFO - 2024-06-15 18:45:09 --> Database Driver Class Initialized
INFO - 2024-06-15 18:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:45:10 --> Controller Class Initialized
INFO - 2024-06-15 18:45:10 --> Final output sent to browser
DEBUG - 2024-06-15 18:45:10 --> Total execution time: 0.8463
INFO - 2024-06-15 18:45:26 --> Config Class Initialized
INFO - 2024-06-15 18:45:26 --> Hooks Class Initialized
DEBUG - 2024-06-15 18:45:26 --> UTF-8 Support Enabled
INFO - 2024-06-15 18:45:26 --> Utf8 Class Initialized
INFO - 2024-06-15 18:45:26 --> URI Class Initialized
INFO - 2024-06-15 18:45:26 --> Router Class Initialized
INFO - 2024-06-15 18:45:26 --> Output Class Initialized
INFO - 2024-06-15 18:45:26 --> Security Class Initialized
DEBUG - 2024-06-15 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 18:45:26 --> Input Class Initialized
INFO - 2024-06-15 18:45:26 --> Language Class Initialized
INFO - 2024-06-15 18:45:26 --> Language Class Initialized
INFO - 2024-06-15 18:45:26 --> Config Class Initialized
INFO - 2024-06-15 18:45:26 --> Loader Class Initialized
INFO - 2024-06-15 18:45:26 --> Helper loaded: url_helper
INFO - 2024-06-15 18:45:26 --> Helper loaded: file_helper
INFO - 2024-06-15 18:45:26 --> Helper loaded: form_helper
INFO - 2024-06-15 18:45:26 --> Helper loaded: my_helper
INFO - 2024-06-15 18:45:26 --> Database Driver Class Initialized
INFO - 2024-06-15 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 18:45:26 --> Controller Class Initialized
INFO - 2024-06-15 18:45:26 --> Final output sent to browser
DEBUG - 2024-06-15 18:45:26 --> Total execution time: 0.1875
INFO - 2024-06-15 20:25:53 --> Config Class Initialized
INFO - 2024-06-15 20:25:53 --> Hooks Class Initialized
DEBUG - 2024-06-15 20:25:53 --> UTF-8 Support Enabled
INFO - 2024-06-15 20:25:53 --> Utf8 Class Initialized
INFO - 2024-06-15 20:25:53 --> URI Class Initialized
INFO - 2024-06-15 20:25:54 --> Router Class Initialized
INFO - 2024-06-15 20:25:54 --> Output Class Initialized
INFO - 2024-06-15 20:25:54 --> Security Class Initialized
DEBUG - 2024-06-15 20:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-15 20:25:54 --> Input Class Initialized
INFO - 2024-06-15 20:25:54 --> Language Class Initialized
INFO - 2024-06-15 20:25:54 --> Language Class Initialized
INFO - 2024-06-15 20:25:54 --> Config Class Initialized
INFO - 2024-06-15 20:25:54 --> Loader Class Initialized
INFO - 2024-06-15 20:25:54 --> Helper loaded: url_helper
INFO - 2024-06-15 20:25:54 --> Helper loaded: file_helper
INFO - 2024-06-15 20:25:54 --> Helper loaded: form_helper
INFO - 2024-06-15 20:25:54 --> Helper loaded: my_helper
INFO - 2024-06-15 20:25:54 --> Database Driver Class Initialized
INFO - 2024-06-15 20:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-15 20:25:54 --> Controller Class Initialized
DEBUG - 2024-06-15 20:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-15 20:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-15 20:25:54 --> Final output sent to browser
DEBUG - 2024-06-15 20:25:54 --> Total execution time: 0.3066
