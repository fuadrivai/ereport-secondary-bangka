<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-06 07:15:31 --> Config Class Initialized
INFO - 2023-06-06 07:15:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:31 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:31 --> URI Class Initialized
DEBUG - 2023-06-06 07:15:31 --> No URI present. Default controller set.
INFO - 2023-06-06 07:15:31 --> Router Class Initialized
INFO - 2023-06-06 07:15:31 --> Output Class Initialized
INFO - 2023-06-06 07:15:31 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:31 --> Input Class Initialized
INFO - 2023-06-06 07:15:31 --> Language Class Initialized
INFO - 2023-06-06 07:15:31 --> Language Class Initialized
INFO - 2023-06-06 07:15:31 --> Config Class Initialized
INFO - 2023-06-06 07:15:31 --> Loader Class Initialized
INFO - 2023-06-06 07:15:31 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:31 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:31 --> Controller Class Initialized
INFO - 2023-06-06 07:15:31 --> Config Class Initialized
INFO - 2023-06-06 07:15:31 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:31 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:31 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:31 --> URI Class Initialized
INFO - 2023-06-06 07:15:31 --> Router Class Initialized
INFO - 2023-06-06 07:15:31 --> Output Class Initialized
INFO - 2023-06-06 07:15:31 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:31 --> Input Class Initialized
INFO - 2023-06-06 07:15:31 --> Language Class Initialized
INFO - 2023-06-06 07:15:31 --> Language Class Initialized
INFO - 2023-06-06 07:15:31 --> Config Class Initialized
INFO - 2023-06-06 07:15:31 --> Loader Class Initialized
INFO - 2023-06-06 07:15:31 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:31 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:31 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:32 --> Controller Class Initialized
DEBUG - 2023-06-06 07:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-06 07:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:15:32 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:32 --> Total execution time: 0.0249
INFO - 2023-06-06 07:15:36 --> Config Class Initialized
INFO - 2023-06-06 07:15:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:36 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:36 --> URI Class Initialized
INFO - 2023-06-06 07:15:36 --> Router Class Initialized
INFO - 2023-06-06 07:15:36 --> Output Class Initialized
INFO - 2023-06-06 07:15:36 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:36 --> Input Class Initialized
INFO - 2023-06-06 07:15:36 --> Language Class Initialized
INFO - 2023-06-06 07:15:36 --> Language Class Initialized
INFO - 2023-06-06 07:15:36 --> Config Class Initialized
INFO - 2023-06-06 07:15:36 --> Loader Class Initialized
INFO - 2023-06-06 07:15:36 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:36 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:36 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:36 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:36 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:36 --> Controller Class Initialized
INFO - 2023-06-06 07:15:36 --> Helper loaded: cookie_helper
INFO - 2023-06-06 07:15:36 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:36 --> Total execution time: 0.0487
INFO - 2023-06-06 07:15:36 --> Config Class Initialized
INFO - 2023-06-06 07:15:36 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:36 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:36 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:36 --> URI Class Initialized
INFO - 2023-06-06 07:15:36 --> Router Class Initialized
INFO - 2023-06-06 07:15:37 --> Output Class Initialized
INFO - 2023-06-06 07:15:37 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:37 --> Input Class Initialized
INFO - 2023-06-06 07:15:37 --> Language Class Initialized
INFO - 2023-06-06 07:15:37 --> Language Class Initialized
INFO - 2023-06-06 07:15:37 --> Config Class Initialized
INFO - 2023-06-06 07:15:37 --> Loader Class Initialized
INFO - 2023-06-06 07:15:37 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:37 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:37 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:37 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:37 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:37 --> Controller Class Initialized
DEBUG - 2023-06-06 07:15:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-06 07:15:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:15:37 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:37 --> Total execution time: 0.0946
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:43 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:43 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:43 --> URI Class Initialized
INFO - 2023-06-06 07:15:43 --> Router Class Initialized
INFO - 2023-06-06 07:15:43 --> Output Class Initialized
INFO - 2023-06-06 07:15:43 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:43 --> Input Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Loader Class Initialized
INFO - 2023-06-06 07:15:43 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:43 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:43 --> Controller Class Initialized
INFO - 2023-06-06 07:15:43 --> Helper loaded: cookie_helper
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:43 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:43 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:43 --> URI Class Initialized
INFO - 2023-06-06 07:15:43 --> Router Class Initialized
INFO - 2023-06-06 07:15:43 --> Output Class Initialized
INFO - 2023-06-06 07:15:43 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:43 --> Input Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Loader Class Initialized
INFO - 2023-06-06 07:15:43 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:43 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:43 --> Controller Class Initialized
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:43 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:43 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:43 --> URI Class Initialized
INFO - 2023-06-06 07:15:43 --> Router Class Initialized
INFO - 2023-06-06 07:15:43 --> Output Class Initialized
INFO - 2023-06-06 07:15:43 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:43 --> Input Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Language Class Initialized
INFO - 2023-06-06 07:15:43 --> Config Class Initialized
INFO - 2023-06-06 07:15:43 --> Loader Class Initialized
INFO - 2023-06-06 07:15:43 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:43 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:43 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:43 --> Controller Class Initialized
DEBUG - 2023-06-06 07:15:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-06 07:15:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:15:43 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:43 --> Total execution time: 0.0423
INFO - 2023-06-06 07:15:47 --> Config Class Initialized
INFO - 2023-06-06 07:15:47 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:47 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:47 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:47 --> URI Class Initialized
INFO - 2023-06-06 07:15:47 --> Router Class Initialized
INFO - 2023-06-06 07:15:47 --> Output Class Initialized
INFO - 2023-06-06 07:15:47 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:47 --> Input Class Initialized
INFO - 2023-06-06 07:15:47 --> Language Class Initialized
INFO - 2023-06-06 07:15:47 --> Language Class Initialized
INFO - 2023-06-06 07:15:47 --> Config Class Initialized
INFO - 2023-06-06 07:15:47 --> Loader Class Initialized
INFO - 2023-06-06 07:15:47 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:47 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:47 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:47 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:47 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:48 --> Controller Class Initialized
INFO - 2023-06-06 07:15:48 --> Helper loaded: cookie_helper
INFO - 2023-06-06 07:15:48 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:48 --> Total execution time: 0.0617
INFO - 2023-06-06 07:15:48 --> Config Class Initialized
INFO - 2023-06-06 07:15:48 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:15:48 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:15:48 --> Utf8 Class Initialized
INFO - 2023-06-06 07:15:48 --> URI Class Initialized
INFO - 2023-06-06 07:15:48 --> Router Class Initialized
INFO - 2023-06-06 07:15:48 --> Output Class Initialized
INFO - 2023-06-06 07:15:48 --> Security Class Initialized
DEBUG - 2023-06-06 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:15:48 --> Input Class Initialized
INFO - 2023-06-06 07:15:48 --> Language Class Initialized
INFO - 2023-06-06 07:15:48 --> Language Class Initialized
INFO - 2023-06-06 07:15:48 --> Config Class Initialized
INFO - 2023-06-06 07:15:48 --> Loader Class Initialized
INFO - 2023-06-06 07:15:48 --> Helper loaded: url_helper
INFO - 2023-06-06 07:15:48 --> Helper loaded: file_helper
INFO - 2023-06-06 07:15:48 --> Helper loaded: form_helper
INFO - 2023-06-06 07:15:48 --> Helper loaded: my_helper
INFO - 2023-06-06 07:15:48 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:15:48 --> Controller Class Initialized
DEBUG - 2023-06-06 07:15:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-06 07:15:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:15:48 --> Final output sent to browser
DEBUG - 2023-06-06 07:15:48 --> Total execution time: 0.0502
INFO - 2023-06-06 07:16:08 --> Config Class Initialized
INFO - 2023-06-06 07:16:08 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:16:08 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:16:08 --> Utf8 Class Initialized
INFO - 2023-06-06 07:16:08 --> URI Class Initialized
INFO - 2023-06-06 07:16:08 --> Router Class Initialized
INFO - 2023-06-06 07:16:08 --> Output Class Initialized
INFO - 2023-06-06 07:16:08 --> Security Class Initialized
DEBUG - 2023-06-06 07:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:16:08 --> Input Class Initialized
INFO - 2023-06-06 07:16:08 --> Language Class Initialized
INFO - 2023-06-06 07:16:08 --> Language Class Initialized
INFO - 2023-06-06 07:16:08 --> Config Class Initialized
INFO - 2023-06-06 07:16:08 --> Loader Class Initialized
INFO - 2023-06-06 07:16:08 --> Helper loaded: url_helper
INFO - 2023-06-06 07:16:08 --> Helper loaded: file_helper
INFO - 2023-06-06 07:16:08 --> Helper loaded: form_helper
INFO - 2023-06-06 07:16:08 --> Helper loaded: my_helper
INFO - 2023-06-06 07:16:08 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:16:08 --> Controller Class Initialized
DEBUG - 2023-06-06 07:16:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-06 07:16:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:16:08 --> Final output sent to browser
DEBUG - 2023-06-06 07:16:08 --> Total execution time: 0.0434
INFO - 2023-06-06 07:16:20 --> Config Class Initialized
INFO - 2023-06-06 07:16:20 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:16:20 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:16:20 --> Utf8 Class Initialized
INFO - 2023-06-06 07:16:20 --> URI Class Initialized
INFO - 2023-06-06 07:16:20 --> Router Class Initialized
INFO - 2023-06-06 07:16:20 --> Output Class Initialized
INFO - 2023-06-06 07:16:20 --> Security Class Initialized
DEBUG - 2023-06-06 07:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:16:20 --> Input Class Initialized
INFO - 2023-06-06 07:16:20 --> Language Class Initialized
INFO - 2023-06-06 07:16:20 --> Language Class Initialized
INFO - 2023-06-06 07:16:20 --> Config Class Initialized
INFO - 2023-06-06 07:16:20 --> Loader Class Initialized
INFO - 2023-06-06 07:16:20 --> Helper loaded: url_helper
INFO - 2023-06-06 07:16:20 --> Helper loaded: file_helper
INFO - 2023-06-06 07:16:20 --> Helper loaded: form_helper
INFO - 2023-06-06 07:16:20 --> Helper loaded: my_helper
INFO - 2023-06-06 07:16:20 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:16:20 --> Controller Class Initialized
DEBUG - 2023-06-06 07:16:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-06 07:16:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:16:20 --> Final output sent to browser
DEBUG - 2023-06-06 07:16:20 --> Total execution time: 0.0535
INFO - 2023-06-06 07:16:48 --> Config Class Initialized
INFO - 2023-06-06 07:16:48 --> Hooks Class Initialized
DEBUG - 2023-06-06 07:16:48 --> UTF-8 Support Enabled
INFO - 2023-06-06 07:16:48 --> Utf8 Class Initialized
INFO - 2023-06-06 07:16:48 --> URI Class Initialized
INFO - 2023-06-06 07:16:48 --> Router Class Initialized
INFO - 2023-06-06 07:16:48 --> Output Class Initialized
INFO - 2023-06-06 07:16:48 --> Security Class Initialized
DEBUG - 2023-06-06 07:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 07:16:48 --> Input Class Initialized
INFO - 2023-06-06 07:16:48 --> Language Class Initialized
INFO - 2023-06-06 07:16:48 --> Language Class Initialized
INFO - 2023-06-06 07:16:48 --> Config Class Initialized
INFO - 2023-06-06 07:16:48 --> Loader Class Initialized
INFO - 2023-06-06 07:16:48 --> Helper loaded: url_helper
INFO - 2023-06-06 07:16:48 --> Helper loaded: file_helper
INFO - 2023-06-06 07:16:48 --> Helper loaded: form_helper
INFO - 2023-06-06 07:16:48 --> Helper loaded: my_helper
INFO - 2023-06-06 07:16:48 --> Database Driver Class Initialized
DEBUG - 2023-06-06 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 07:16:49 --> Controller Class Initialized
DEBUG - 2023-06-06 07:16:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-06 07:16:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 07:16:49 --> Final output sent to browser
DEBUG - 2023-06-06 07:16:49 --> Total execution time: 0.0561
INFO - 2023-06-06 09:16:32 --> Config Class Initialized
INFO - 2023-06-06 09:16:32 --> Hooks Class Initialized
DEBUG - 2023-06-06 09:16:32 --> UTF-8 Support Enabled
INFO - 2023-06-06 09:16:32 --> Utf8 Class Initialized
INFO - 2023-06-06 09:16:32 --> URI Class Initialized
INFO - 2023-06-06 09:16:32 --> Router Class Initialized
INFO - 2023-06-06 09:16:32 --> Output Class Initialized
INFO - 2023-06-06 09:16:32 --> Security Class Initialized
DEBUG - 2023-06-06 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-06 09:16:32 --> Input Class Initialized
INFO - 2023-06-06 09:16:32 --> Language Class Initialized
INFO - 2023-06-06 09:16:32 --> Language Class Initialized
INFO - 2023-06-06 09:16:32 --> Config Class Initialized
INFO - 2023-06-06 09:16:32 --> Loader Class Initialized
INFO - 2023-06-06 09:16:32 --> Helper loaded: url_helper
INFO - 2023-06-06 09:16:32 --> Helper loaded: file_helper
INFO - 2023-06-06 09:16:32 --> Helper loaded: form_helper
INFO - 2023-06-06 09:16:32 --> Helper loaded: my_helper
INFO - 2023-06-06 09:16:32 --> Database Driver Class Initialized
DEBUG - 2023-06-06 09:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-06 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-06 09:16:32 --> Controller Class Initialized
ERROR - 2023-06-06 09:16:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 21
ERROR - 2023-06-06 09:16:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 22
DEBUG - 2023-06-06 09:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-06 09:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-06 09:16:32 --> Final output sent to browser
DEBUG - 2023-06-06 09:16:32 --> Total execution time: 0.0942
