<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:01:40 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:01:40 --> Utf8 Class Initialized
INFO - 2024-07-23 10:01:40 --> URI Class Initialized
INFO - 2024-07-23 10:01:40 --> Router Class Initialized
INFO - 2024-07-23 10:01:40 --> Output Class Initialized
INFO - 2024-07-23 10:01:40 --> Security Class Initialized
DEBUG - 2024-07-23 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:01:40 --> Input Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Loader Class Initialized
INFO - 2024-07-23 10:01:40 --> Helper loaded: url_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: file_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: form_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: my_helper
INFO - 2024-07-23 10:01:40 --> Database Driver Class Initialized
INFO - 2024-07-23 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:01:40 --> Controller Class Initialized
INFO - 2024-07-23 10:01:40 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:01:40 --> Final output sent to browser
DEBUG - 2024-07-23 10:01:40 --> Total execution time: 0.0585
INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:01:40 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:01:40 --> Utf8 Class Initialized
INFO - 2024-07-23 10:01:40 --> URI Class Initialized
INFO - 2024-07-23 10:01:40 --> Router Class Initialized
INFO - 2024-07-23 10:01:40 --> Output Class Initialized
INFO - 2024-07-23 10:01:40 --> Security Class Initialized
DEBUG - 2024-07-23 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:01:40 --> Input Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Loader Class Initialized
INFO - 2024-07-23 10:01:40 --> Helper loaded: url_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: file_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: form_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: my_helper
INFO - 2024-07-23 10:01:40 --> Database Driver Class Initialized
INFO - 2024-07-23 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:01:40 --> Controller Class Initialized
INFO - 2024-07-23 10:01:40 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:01:40 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:01:40 --> Utf8 Class Initialized
INFO - 2024-07-23 10:01:40 --> URI Class Initialized
INFO - 2024-07-23 10:01:40 --> Router Class Initialized
INFO - 2024-07-23 10:01:40 --> Output Class Initialized
INFO - 2024-07-23 10:01:40 --> Security Class Initialized
DEBUG - 2024-07-23 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:01:40 --> Input Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Language Class Initialized
INFO - 2024-07-23 10:01:40 --> Config Class Initialized
INFO - 2024-07-23 10:01:40 --> Loader Class Initialized
INFO - 2024-07-23 10:01:40 --> Helper loaded: url_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: file_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: form_helper
INFO - 2024-07-23 10:01:40 --> Helper loaded: my_helper
INFO - 2024-07-23 10:01:40 --> Database Driver Class Initialized
INFO - 2024-07-23 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:01:40 --> Controller Class Initialized
DEBUG - 2024-07-23 10:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 10:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 10:01:40 --> Final output sent to browser
DEBUG - 2024-07-23 10:01:40 --> Total execution time: 0.0405
INFO - 2024-07-23 10:01:52 --> Config Class Initialized
INFO - 2024-07-23 10:01:52 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:01:52 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:01:52 --> Utf8 Class Initialized
INFO - 2024-07-23 10:01:52 --> URI Class Initialized
INFO - 2024-07-23 10:01:52 --> Router Class Initialized
INFO - 2024-07-23 10:01:52 --> Output Class Initialized
INFO - 2024-07-23 10:01:52 --> Security Class Initialized
DEBUG - 2024-07-23 10:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:01:52 --> Input Class Initialized
INFO - 2024-07-23 10:01:52 --> Language Class Initialized
INFO - 2024-07-23 10:01:52 --> Language Class Initialized
INFO - 2024-07-23 10:01:52 --> Config Class Initialized
INFO - 2024-07-23 10:01:52 --> Loader Class Initialized
INFO - 2024-07-23 10:01:52 --> Helper loaded: url_helper
INFO - 2024-07-23 10:01:52 --> Helper loaded: file_helper
INFO - 2024-07-23 10:01:52 --> Helper loaded: form_helper
INFO - 2024-07-23 10:01:52 --> Helper loaded: my_helper
INFO - 2024-07-23 10:01:52 --> Database Driver Class Initialized
INFO - 2024-07-23 10:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:01:52 --> Controller Class Initialized
DEBUG - 2024-07-23 10:01:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-23 10:01:56 --> Final output sent to browser
DEBUG - 2024-07-23 10:01:56 --> Total execution time: 4.6809
INFO - 2024-07-23 10:02:48 --> Config Class Initialized
INFO - 2024-07-23 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:02:48 --> Utf8 Class Initialized
INFO - 2024-07-23 10:02:48 --> URI Class Initialized
INFO - 2024-07-23 10:02:48 --> Router Class Initialized
INFO - 2024-07-23 10:02:48 --> Output Class Initialized
INFO - 2024-07-23 10:02:48 --> Security Class Initialized
DEBUG - 2024-07-23 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:02:48 --> Input Class Initialized
INFO - 2024-07-23 10:02:48 --> Language Class Initialized
INFO - 2024-07-23 10:02:48 --> Language Class Initialized
INFO - 2024-07-23 10:02:48 --> Config Class Initialized
INFO - 2024-07-23 10:02:48 --> Loader Class Initialized
INFO - 2024-07-23 10:02:48 --> Helper loaded: url_helper
INFO - 2024-07-23 10:02:48 --> Helper loaded: file_helper
INFO - 2024-07-23 10:02:48 --> Helper loaded: form_helper
INFO - 2024-07-23 10:02:48 --> Helper loaded: my_helper
INFO - 2024-07-23 10:02:48 --> Database Driver Class Initialized
INFO - 2024-07-23 10:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:02:48 --> Controller Class Initialized
INFO - 2024-07-23 10:02:48 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:02:48 --> Final output sent to browser
DEBUG - 2024-07-23 10:02:48 --> Total execution time: 0.0282
INFO - 2024-07-23 10:02:49 --> Config Class Initialized
INFO - 2024-07-23 10:02:49 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:02:49 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:02:49 --> Utf8 Class Initialized
INFO - 2024-07-23 10:02:49 --> URI Class Initialized
INFO - 2024-07-23 10:02:49 --> Router Class Initialized
INFO - 2024-07-23 10:02:49 --> Output Class Initialized
INFO - 2024-07-23 10:02:49 --> Security Class Initialized
DEBUG - 2024-07-23 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:02:49 --> Input Class Initialized
INFO - 2024-07-23 10:02:49 --> Language Class Initialized
INFO - 2024-07-23 10:02:49 --> Language Class Initialized
INFO - 2024-07-23 10:02:49 --> Config Class Initialized
INFO - 2024-07-23 10:02:49 --> Loader Class Initialized
INFO - 2024-07-23 10:02:49 --> Helper loaded: url_helper
INFO - 2024-07-23 10:02:49 --> Helper loaded: file_helper
INFO - 2024-07-23 10:02:49 --> Helper loaded: form_helper
INFO - 2024-07-23 10:02:49 --> Helper loaded: my_helper
INFO - 2024-07-23 10:02:49 --> Database Driver Class Initialized
INFO - 2024-07-23 10:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:02:49 --> Controller Class Initialized
INFO - 2024-07-23 10:02:49 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:02:49 --> Final output sent to browser
DEBUG - 2024-07-23 10:02:49 --> Total execution time: 0.0284
INFO - 2024-07-23 10:03:16 --> Config Class Initialized
INFO - 2024-07-23 10:03:16 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:03:16 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:03:16 --> Utf8 Class Initialized
INFO - 2024-07-23 10:03:16 --> URI Class Initialized
INFO - 2024-07-23 10:03:16 --> Router Class Initialized
INFO - 2024-07-23 10:03:16 --> Output Class Initialized
INFO - 2024-07-23 10:03:16 --> Security Class Initialized
DEBUG - 2024-07-23 10:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:03:16 --> Input Class Initialized
INFO - 2024-07-23 10:03:16 --> Language Class Initialized
INFO - 2024-07-23 10:03:16 --> Language Class Initialized
INFO - 2024-07-23 10:03:16 --> Config Class Initialized
INFO - 2024-07-23 10:03:16 --> Loader Class Initialized
INFO - 2024-07-23 10:03:16 --> Helper loaded: url_helper
INFO - 2024-07-23 10:03:16 --> Helper loaded: file_helper
INFO - 2024-07-23 10:03:16 --> Helper loaded: form_helper
INFO - 2024-07-23 10:03:16 --> Helper loaded: my_helper
INFO - 2024-07-23 10:03:16 --> Database Driver Class Initialized
INFO - 2024-07-23 10:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:03:16 --> Controller Class Initialized
INFO - 2024-07-23 10:03:16 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:03:16 --> Final output sent to browser
DEBUG - 2024-07-23 10:03:16 --> Total execution time: 0.0365
INFO - 2024-07-23 10:03:17 --> Config Class Initialized
INFO - 2024-07-23 10:03:17 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:03:17 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:03:17 --> Utf8 Class Initialized
INFO - 2024-07-23 10:03:17 --> URI Class Initialized
INFO - 2024-07-23 10:03:17 --> Router Class Initialized
INFO - 2024-07-23 10:03:17 --> Output Class Initialized
INFO - 2024-07-23 10:03:17 --> Security Class Initialized
DEBUG - 2024-07-23 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:03:17 --> Input Class Initialized
INFO - 2024-07-23 10:03:17 --> Language Class Initialized
INFO - 2024-07-23 10:03:17 --> Language Class Initialized
INFO - 2024-07-23 10:03:17 --> Config Class Initialized
INFO - 2024-07-23 10:03:17 --> Loader Class Initialized
INFO - 2024-07-23 10:03:17 --> Helper loaded: url_helper
INFO - 2024-07-23 10:03:17 --> Helper loaded: file_helper
INFO - 2024-07-23 10:03:17 --> Helper loaded: form_helper
INFO - 2024-07-23 10:03:17 --> Helper loaded: my_helper
INFO - 2024-07-23 10:03:17 --> Database Driver Class Initialized
INFO - 2024-07-23 10:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:03:17 --> Controller Class Initialized
INFO - 2024-07-23 10:03:17 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:03:17 --> Final output sent to browser
DEBUG - 2024-07-23 10:03:17 --> Total execution time: 0.0298
INFO - 2024-07-23 10:05:24 --> Config Class Initialized
INFO - 2024-07-23 10:05:24 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:05:24 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:05:24 --> Utf8 Class Initialized
INFO - 2024-07-23 10:05:24 --> URI Class Initialized
INFO - 2024-07-23 10:05:24 --> Router Class Initialized
INFO - 2024-07-23 10:05:24 --> Output Class Initialized
INFO - 2024-07-23 10:05:24 --> Security Class Initialized
DEBUG - 2024-07-23 10:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:05:24 --> Input Class Initialized
INFO - 2024-07-23 10:05:24 --> Language Class Initialized
INFO - 2024-07-23 10:05:24 --> Language Class Initialized
INFO - 2024-07-23 10:05:24 --> Config Class Initialized
INFO - 2024-07-23 10:05:24 --> Loader Class Initialized
INFO - 2024-07-23 10:05:24 --> Helper loaded: url_helper
INFO - 2024-07-23 10:05:24 --> Helper loaded: file_helper
INFO - 2024-07-23 10:05:24 --> Helper loaded: form_helper
INFO - 2024-07-23 10:05:24 --> Helper loaded: my_helper
INFO - 2024-07-23 10:05:24 --> Database Driver Class Initialized
INFO - 2024-07-23 10:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:05:24 --> Controller Class Initialized
INFO - 2024-07-23 10:05:24 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:05:24 --> Final output sent to browser
DEBUG - 2024-07-23 10:05:24 --> Total execution time: 0.0261
INFO - 2024-07-23 10:05:25 --> Config Class Initialized
INFO - 2024-07-23 10:05:25 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:05:25 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:05:25 --> Utf8 Class Initialized
INFO - 2024-07-23 10:05:25 --> URI Class Initialized
INFO - 2024-07-23 10:05:25 --> Router Class Initialized
INFO - 2024-07-23 10:05:25 --> Output Class Initialized
INFO - 2024-07-23 10:05:25 --> Security Class Initialized
DEBUG - 2024-07-23 10:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:05:25 --> Input Class Initialized
INFO - 2024-07-23 10:05:25 --> Language Class Initialized
INFO - 2024-07-23 10:05:25 --> Language Class Initialized
INFO - 2024-07-23 10:05:25 --> Config Class Initialized
INFO - 2024-07-23 10:05:25 --> Loader Class Initialized
INFO - 2024-07-23 10:05:25 --> Helper loaded: url_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: file_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: form_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: my_helper
INFO - 2024-07-23 10:05:25 --> Database Driver Class Initialized
INFO - 2024-07-23 10:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:05:25 --> Controller Class Initialized
INFO - 2024-07-23 10:05:25 --> Helper loaded: cookie_helper
INFO - 2024-07-23 10:05:25 --> Config Class Initialized
INFO - 2024-07-23 10:05:25 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:05:25 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:05:25 --> Utf8 Class Initialized
INFO - 2024-07-23 10:05:25 --> URI Class Initialized
INFO - 2024-07-23 10:05:25 --> Router Class Initialized
INFO - 2024-07-23 10:05:25 --> Output Class Initialized
INFO - 2024-07-23 10:05:25 --> Security Class Initialized
DEBUG - 2024-07-23 10:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:05:25 --> Input Class Initialized
INFO - 2024-07-23 10:05:25 --> Language Class Initialized
INFO - 2024-07-23 10:05:25 --> Language Class Initialized
INFO - 2024-07-23 10:05:25 --> Config Class Initialized
INFO - 2024-07-23 10:05:25 --> Loader Class Initialized
INFO - 2024-07-23 10:05:25 --> Helper loaded: url_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: file_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: form_helper
INFO - 2024-07-23 10:05:25 --> Helper loaded: my_helper
INFO - 2024-07-23 10:05:25 --> Database Driver Class Initialized
INFO - 2024-07-23 10:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:05:25 --> Controller Class Initialized
DEBUG - 2024-07-23 10:05:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 10:05:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 10:05:25 --> Final output sent to browser
DEBUG - 2024-07-23 10:05:25 --> Total execution time: 0.0275
INFO - 2024-07-23 10:06:12 --> Config Class Initialized
INFO - 2024-07-23 10:06:12 --> Hooks Class Initialized
DEBUG - 2024-07-23 10:06:12 --> UTF-8 Support Enabled
INFO - 2024-07-23 10:06:12 --> Utf8 Class Initialized
INFO - 2024-07-23 10:06:12 --> URI Class Initialized
INFO - 2024-07-23 10:06:12 --> Router Class Initialized
INFO - 2024-07-23 10:06:12 --> Output Class Initialized
INFO - 2024-07-23 10:06:12 --> Security Class Initialized
DEBUG - 2024-07-23 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 10:06:12 --> Input Class Initialized
INFO - 2024-07-23 10:06:12 --> Language Class Initialized
INFO - 2024-07-23 10:06:12 --> Language Class Initialized
INFO - 2024-07-23 10:06:12 --> Config Class Initialized
INFO - 2024-07-23 10:06:12 --> Loader Class Initialized
INFO - 2024-07-23 10:06:12 --> Helper loaded: url_helper
INFO - 2024-07-23 10:06:12 --> Helper loaded: file_helper
INFO - 2024-07-23 10:06:12 --> Helper loaded: form_helper
INFO - 2024-07-23 10:06:12 --> Helper loaded: my_helper
INFO - 2024-07-23 10:06:12 --> Database Driver Class Initialized
INFO - 2024-07-23 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 10:06:12 --> Controller Class Initialized
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-23 10:06:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-23 10:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-23 10:06:14 --> Final output sent to browser
DEBUG - 2024-07-23 10:06:14 --> Total execution time: 2.7592
INFO - 2024-07-23 11:17:22 --> Config Class Initialized
INFO - 2024-07-23 11:17:22 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:22 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:22 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:22 --> URI Class Initialized
INFO - 2024-07-23 11:17:22 --> Router Class Initialized
INFO - 2024-07-23 11:17:22 --> Output Class Initialized
INFO - 2024-07-23 11:17:22 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:22 --> Input Class Initialized
INFO - 2024-07-23 11:17:22 --> Language Class Initialized
INFO - 2024-07-23 11:17:22 --> Language Class Initialized
INFO - 2024-07-23 11:17:22 --> Config Class Initialized
INFO - 2024-07-23 11:17:22 --> Loader Class Initialized
INFO - 2024-07-23 11:17:22 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:22 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:22 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:22 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:22 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:22 --> Controller Class Initialized
INFO - 2024-07-23 11:17:22 --> Helper loaded: cookie_helper
INFO - 2024-07-23 11:17:22 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:22 --> Total execution time: 0.0539
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:23 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:23 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:23 --> URI Class Initialized
INFO - 2024-07-23 11:17:23 --> Router Class Initialized
INFO - 2024-07-23 11:17:23 --> Output Class Initialized
INFO - 2024-07-23 11:17:23 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:23 --> Input Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Loader Class Initialized
INFO - 2024-07-23 11:17:23 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:23 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:23 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:23 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:23 --> URI Class Initialized
INFO - 2024-07-23 11:17:23 --> Router Class Initialized
INFO - 2024-07-23 11:17:23 --> Output Class Initialized
INFO - 2024-07-23 11:17:23 --> Security Class Initialized
INFO - 2024-07-23 11:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:23 --> Controller Class Initialized
INFO - 2024-07-23 11:17:23 --> Helper loaded: cookie_helper
DEBUG - 2024-07-23 11:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:23 --> Input Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Loader Class Initialized
INFO - 2024-07-23 11:17:23 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:23 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:23 --> Controller Class Initialized
INFO - 2024-07-23 11:17:23 --> Helper loaded: cookie_helper
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:23 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:23 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:23 --> URI Class Initialized
INFO - 2024-07-23 11:17:23 --> Router Class Initialized
INFO - 2024-07-23 11:17:23 --> Output Class Initialized
INFO - 2024-07-23 11:17:23 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:23 --> Input Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Language Class Initialized
INFO - 2024-07-23 11:17:23 --> Config Class Initialized
INFO - 2024-07-23 11:17:23 --> Loader Class Initialized
INFO - 2024-07-23 11:17:23 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:23 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:23 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:23 --> Controller Class Initialized
DEBUG - 2024-07-23 11:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 11:17:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 11:17:23 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:23 --> Total execution time: 0.0316
INFO - 2024-07-23 11:17:24 --> Config Class Initialized
INFO - 2024-07-23 11:17:24 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:24 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:24 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:24 --> URI Class Initialized
INFO - 2024-07-23 11:17:24 --> Router Class Initialized
INFO - 2024-07-23 11:17:24 --> Output Class Initialized
INFO - 2024-07-23 11:17:24 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:24 --> Input Class Initialized
INFO - 2024-07-23 11:17:24 --> Language Class Initialized
INFO - 2024-07-23 11:17:24 --> Language Class Initialized
INFO - 2024-07-23 11:17:24 --> Config Class Initialized
INFO - 2024-07-23 11:17:24 --> Loader Class Initialized
INFO - 2024-07-23 11:17:24 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:24 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:24 --> Controller Class Initialized
INFO - 2024-07-23 11:17:24 --> Helper loaded: cookie_helper
INFO - 2024-07-23 11:17:24 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:24 --> Total execution time: 0.0281
INFO - 2024-07-23 11:17:24 --> Config Class Initialized
INFO - 2024-07-23 11:17:24 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:24 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:24 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:24 --> URI Class Initialized
INFO - 2024-07-23 11:17:24 --> Router Class Initialized
INFO - 2024-07-23 11:17:24 --> Output Class Initialized
INFO - 2024-07-23 11:17:24 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:24 --> Input Class Initialized
INFO - 2024-07-23 11:17:24 --> Language Class Initialized
INFO - 2024-07-23 11:17:24 --> Language Class Initialized
INFO - 2024-07-23 11:17:24 --> Config Class Initialized
INFO - 2024-07-23 11:17:24 --> Loader Class Initialized
INFO - 2024-07-23 11:17:24 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:24 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:24 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:24 --> Controller Class Initialized
INFO - 2024-07-23 11:17:24 --> Helper loaded: cookie_helper
INFO - 2024-07-23 11:17:25 --> Config Class Initialized
INFO - 2024-07-23 11:17:25 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:25 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:25 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:25 --> URI Class Initialized
INFO - 2024-07-23 11:17:25 --> Router Class Initialized
INFO - 2024-07-23 11:17:25 --> Output Class Initialized
INFO - 2024-07-23 11:17:25 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:25 --> Input Class Initialized
INFO - 2024-07-23 11:17:25 --> Language Class Initialized
INFO - 2024-07-23 11:17:25 --> Language Class Initialized
INFO - 2024-07-23 11:17:25 --> Config Class Initialized
INFO - 2024-07-23 11:17:25 --> Loader Class Initialized
INFO - 2024-07-23 11:17:25 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:25 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:25 --> Controller Class Initialized
DEBUG - 2024-07-23 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 11:17:25 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:25 --> Total execution time: 0.0260
INFO - 2024-07-23 11:17:25 --> Config Class Initialized
INFO - 2024-07-23 11:17:25 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:25 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:25 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:25 --> URI Class Initialized
INFO - 2024-07-23 11:17:25 --> Router Class Initialized
INFO - 2024-07-23 11:17:25 --> Output Class Initialized
INFO - 2024-07-23 11:17:25 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:25 --> Input Class Initialized
INFO - 2024-07-23 11:17:25 --> Language Class Initialized
INFO - 2024-07-23 11:17:25 --> Language Class Initialized
INFO - 2024-07-23 11:17:25 --> Config Class Initialized
INFO - 2024-07-23 11:17:25 --> Loader Class Initialized
INFO - 2024-07-23 11:17:25 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:25 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:25 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:25 --> Controller Class Initialized
DEBUG - 2024-07-23 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 11:17:25 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:25 --> Total execution time: 0.0267
INFO - 2024-07-23 11:17:38 --> Config Class Initialized
INFO - 2024-07-23 11:17:38 --> Hooks Class Initialized
DEBUG - 2024-07-23 11:17:38 --> UTF-8 Support Enabled
INFO - 2024-07-23 11:17:38 --> Utf8 Class Initialized
INFO - 2024-07-23 11:17:38 --> URI Class Initialized
INFO - 2024-07-23 11:17:38 --> Router Class Initialized
INFO - 2024-07-23 11:17:38 --> Output Class Initialized
INFO - 2024-07-23 11:17:38 --> Security Class Initialized
DEBUG - 2024-07-23 11:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 11:17:38 --> Input Class Initialized
INFO - 2024-07-23 11:17:38 --> Language Class Initialized
INFO - 2024-07-23 11:17:38 --> Language Class Initialized
INFO - 2024-07-23 11:17:38 --> Config Class Initialized
INFO - 2024-07-23 11:17:38 --> Loader Class Initialized
INFO - 2024-07-23 11:17:38 --> Helper loaded: url_helper
INFO - 2024-07-23 11:17:38 --> Helper loaded: file_helper
INFO - 2024-07-23 11:17:38 --> Helper loaded: form_helper
INFO - 2024-07-23 11:17:38 --> Helper loaded: my_helper
INFO - 2024-07-23 11:17:38 --> Database Driver Class Initialized
INFO - 2024-07-23 11:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 11:17:38 --> Controller Class Initialized
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-23 11:17:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-23 11:17:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-23 11:17:41 --> Final output sent to browser
DEBUG - 2024-07-23 11:17:41 --> Total execution time: 3.3249
INFO - 2024-07-23 12:48:06 --> Config Class Initialized
INFO - 2024-07-23 12:48:06 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:48:06 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:48:06 --> Utf8 Class Initialized
INFO - 2024-07-23 12:48:06 --> URI Class Initialized
INFO - 2024-07-23 12:48:06 --> Router Class Initialized
INFO - 2024-07-23 12:48:06 --> Output Class Initialized
INFO - 2024-07-23 12:48:06 --> Security Class Initialized
DEBUG - 2024-07-23 12:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:48:06 --> Input Class Initialized
INFO - 2024-07-23 12:48:06 --> Language Class Initialized
INFO - 2024-07-23 12:48:06 --> Language Class Initialized
INFO - 2024-07-23 12:48:06 --> Config Class Initialized
INFO - 2024-07-23 12:48:06 --> Loader Class Initialized
INFO - 2024-07-23 12:48:06 --> Helper loaded: url_helper
INFO - 2024-07-23 12:48:06 --> Helper loaded: file_helper
INFO - 2024-07-23 12:48:06 --> Helper loaded: form_helper
INFO - 2024-07-23 12:48:06 --> Helper loaded: my_helper
INFO - 2024-07-23 12:48:06 --> Database Driver Class Initialized
INFO - 2024-07-23 12:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:48:06 --> Controller Class Initialized
INFO - 2024-07-23 12:48:06 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:48:06 --> Final output sent to browser
DEBUG - 2024-07-23 12:48:06 --> Total execution time: 0.0439
INFO - 2024-07-23 12:48:07 --> Config Class Initialized
INFO - 2024-07-23 12:48:07 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:48:07 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:48:07 --> Utf8 Class Initialized
INFO - 2024-07-23 12:48:07 --> URI Class Initialized
INFO - 2024-07-23 12:48:07 --> Router Class Initialized
INFO - 2024-07-23 12:48:07 --> Output Class Initialized
INFO - 2024-07-23 12:48:07 --> Security Class Initialized
DEBUG - 2024-07-23 12:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:48:07 --> Input Class Initialized
INFO - 2024-07-23 12:48:07 --> Language Class Initialized
INFO - 2024-07-23 12:48:07 --> Language Class Initialized
INFO - 2024-07-23 12:48:07 --> Config Class Initialized
INFO - 2024-07-23 12:48:07 --> Loader Class Initialized
INFO - 2024-07-23 12:48:07 --> Helper loaded: url_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: file_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: form_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: my_helper
INFO - 2024-07-23 12:48:07 --> Database Driver Class Initialized
INFO - 2024-07-23 12:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:48:07 --> Controller Class Initialized
INFO - 2024-07-23 12:48:07 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:48:07 --> Config Class Initialized
INFO - 2024-07-23 12:48:07 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:48:07 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:48:07 --> Utf8 Class Initialized
INFO - 2024-07-23 12:48:07 --> URI Class Initialized
INFO - 2024-07-23 12:48:07 --> Router Class Initialized
INFO - 2024-07-23 12:48:07 --> Output Class Initialized
INFO - 2024-07-23 12:48:07 --> Security Class Initialized
DEBUG - 2024-07-23 12:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:48:07 --> Input Class Initialized
INFO - 2024-07-23 12:48:07 --> Language Class Initialized
INFO - 2024-07-23 12:48:07 --> Language Class Initialized
INFO - 2024-07-23 12:48:07 --> Config Class Initialized
INFO - 2024-07-23 12:48:07 --> Loader Class Initialized
INFO - 2024-07-23 12:48:07 --> Helper loaded: url_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: file_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: form_helper
INFO - 2024-07-23 12:48:07 --> Helper loaded: my_helper
INFO - 2024-07-23 12:48:07 --> Database Driver Class Initialized
INFO - 2024-07-23 12:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:48:07 --> Controller Class Initialized
DEBUG - 2024-07-23 12:48:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 12:48:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:48:07 --> Final output sent to browser
DEBUG - 2024-07-23 12:48:07 --> Total execution time: 0.0307
INFO - 2024-07-23 12:49:19 --> Config Class Initialized
INFO - 2024-07-23 12:49:19 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:49:19 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:49:19 --> Utf8 Class Initialized
INFO - 2024-07-23 12:49:19 --> URI Class Initialized
DEBUG - 2024-07-23 12:49:19 --> No URI present. Default controller set.
INFO - 2024-07-23 12:49:19 --> Router Class Initialized
INFO - 2024-07-23 12:49:19 --> Output Class Initialized
INFO - 2024-07-23 12:49:19 --> Security Class Initialized
DEBUG - 2024-07-23 12:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:49:19 --> Input Class Initialized
INFO - 2024-07-23 12:49:19 --> Language Class Initialized
INFO - 2024-07-23 12:49:19 --> Language Class Initialized
INFO - 2024-07-23 12:49:19 --> Config Class Initialized
INFO - 2024-07-23 12:49:19 --> Loader Class Initialized
INFO - 2024-07-23 12:49:19 --> Helper loaded: url_helper
INFO - 2024-07-23 12:49:19 --> Helper loaded: file_helper
INFO - 2024-07-23 12:49:19 --> Helper loaded: form_helper
INFO - 2024-07-23 12:49:19 --> Helper loaded: my_helper
INFO - 2024-07-23 12:49:19 --> Database Driver Class Initialized
INFO - 2024-07-23 12:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:49:19 --> Controller Class Initialized
DEBUG - 2024-07-23 12:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-07-23 12:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:49:19 --> Final output sent to browser
DEBUG - 2024-07-23 12:49:19 --> Total execution time: 0.0278
INFO - 2024-07-23 12:49:26 --> Config Class Initialized
INFO - 2024-07-23 12:49:26 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:49:26 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:49:26 --> Utf8 Class Initialized
INFO - 2024-07-23 12:49:26 --> URI Class Initialized
DEBUG - 2024-07-23 12:49:26 --> No URI present. Default controller set.
INFO - 2024-07-23 12:49:26 --> Router Class Initialized
INFO - 2024-07-23 12:49:26 --> Output Class Initialized
INFO - 2024-07-23 12:49:26 --> Security Class Initialized
DEBUG - 2024-07-23 12:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:49:26 --> Input Class Initialized
INFO - 2024-07-23 12:49:26 --> Language Class Initialized
INFO - 2024-07-23 12:49:26 --> Language Class Initialized
INFO - 2024-07-23 12:49:26 --> Config Class Initialized
INFO - 2024-07-23 12:49:26 --> Loader Class Initialized
INFO - 2024-07-23 12:49:26 --> Helper loaded: url_helper
INFO - 2024-07-23 12:49:26 --> Helper loaded: file_helper
INFO - 2024-07-23 12:49:26 --> Helper loaded: form_helper
INFO - 2024-07-23 12:49:26 --> Helper loaded: my_helper
INFO - 2024-07-23 12:49:26 --> Database Driver Class Initialized
INFO - 2024-07-23 12:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:49:26 --> Controller Class Initialized
DEBUG - 2024-07-23 12:49:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-07-23 12:49:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:49:26 --> Final output sent to browser
DEBUG - 2024-07-23 12:49:26 --> Total execution time: 0.0332
INFO - 2024-07-23 12:49:29 --> Config Class Initialized
INFO - 2024-07-23 12:49:29 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:49:29 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:49:29 --> Utf8 Class Initialized
INFO - 2024-07-23 12:49:29 --> URI Class Initialized
INFO - 2024-07-23 12:49:29 --> Router Class Initialized
INFO - 2024-07-23 12:49:29 --> Output Class Initialized
INFO - 2024-07-23 12:49:29 --> Security Class Initialized
DEBUG - 2024-07-23 12:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:49:29 --> Input Class Initialized
INFO - 2024-07-23 12:49:29 --> Language Class Initialized
INFO - 2024-07-23 12:49:29 --> Language Class Initialized
INFO - 2024-07-23 12:49:29 --> Config Class Initialized
INFO - 2024-07-23 12:49:29 --> Loader Class Initialized
INFO - 2024-07-23 12:49:29 --> Helper loaded: url_helper
INFO - 2024-07-23 12:49:29 --> Helper loaded: file_helper
INFO - 2024-07-23 12:49:29 --> Helper loaded: form_helper
INFO - 2024-07-23 12:49:29 --> Helper loaded: my_helper
INFO - 2024-07-23 12:49:29 --> Database Driver Class Initialized
INFO - 2024-07-23 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:49:29 --> Controller Class Initialized
DEBUG - 2024-07-23 12:49:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 12:49:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:49:29 --> Final output sent to browser
DEBUG - 2024-07-23 12:49:29 --> Total execution time: 0.0692
INFO - 2024-07-23 12:59:57 --> Config Class Initialized
INFO - 2024-07-23 12:59:57 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:57 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:57 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:57 --> URI Class Initialized
INFO - 2024-07-23 12:59:57 --> Router Class Initialized
INFO - 2024-07-23 12:59:57 --> Output Class Initialized
INFO - 2024-07-23 12:59:57 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:57 --> Input Class Initialized
INFO - 2024-07-23 12:59:57 --> Language Class Initialized
INFO - 2024-07-23 12:59:57 --> Language Class Initialized
INFO - 2024-07-23 12:59:57 --> Config Class Initialized
INFO - 2024-07-23 12:59:57 --> Loader Class Initialized
INFO - 2024-07-23 12:59:57 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:57 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:57 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:57 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:57 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:57 --> Controller Class Initialized
INFO - 2024-07-23 12:59:57 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:59:57 --> Final output sent to browser
DEBUG - 2024-07-23 12:59:57 --> Total execution time: 0.1600
INFO - 2024-07-23 12:59:58 --> Config Class Initialized
INFO - 2024-07-23 12:59:58 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:58 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:58 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:58 --> URI Class Initialized
INFO - 2024-07-23 12:59:58 --> Router Class Initialized
INFO - 2024-07-23 12:59:58 --> Output Class Initialized
INFO - 2024-07-23 12:59:58 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:58 --> Input Class Initialized
INFO - 2024-07-23 12:59:58 --> Language Class Initialized
INFO - 2024-07-23 12:59:58 --> Language Class Initialized
INFO - 2024-07-23 12:59:58 --> Config Class Initialized
INFO - 2024-07-23 12:59:58 --> Loader Class Initialized
INFO - 2024-07-23 12:59:58 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:58 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:58 --> Controller Class Initialized
INFO - 2024-07-23 12:59:58 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:59:58 --> Config Class Initialized
INFO - 2024-07-23 12:59:58 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:58 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:58 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:58 --> URI Class Initialized
INFO - 2024-07-23 12:59:58 --> Router Class Initialized
INFO - 2024-07-23 12:59:58 --> Output Class Initialized
INFO - 2024-07-23 12:59:58 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:58 --> Input Class Initialized
INFO - 2024-07-23 12:59:58 --> Language Class Initialized
INFO - 2024-07-23 12:59:58 --> Language Class Initialized
INFO - 2024-07-23 12:59:58 --> Config Class Initialized
INFO - 2024-07-23 12:59:58 --> Loader Class Initialized
INFO - 2024-07-23 12:59:58 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:58 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:58 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:58 --> Controller Class Initialized
DEBUG - 2024-07-23 12:59:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 12:59:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:59:58 --> Final output sent to browser
DEBUG - 2024-07-23 12:59:58 --> Total execution time: 0.0264
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:59 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:59 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:59 --> URI Class Initialized
INFO - 2024-07-23 12:59:59 --> Router Class Initialized
INFO - 2024-07-23 12:59:59 --> Output Class Initialized
INFO - 2024-07-23 12:59:59 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:59 --> Input Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Loader Class Initialized
INFO - 2024-07-23 12:59:59 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:59 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:59 --> Controller Class Initialized
INFO - 2024-07-23 12:59:59 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:59:59 --> Final output sent to browser
DEBUG - 2024-07-23 12:59:59 --> Total execution time: 0.0297
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:59 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:59 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:59 --> URI Class Initialized
INFO - 2024-07-23 12:59:59 --> Router Class Initialized
INFO - 2024-07-23 12:59:59 --> Output Class Initialized
INFO - 2024-07-23 12:59:59 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:59 --> Input Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Loader Class Initialized
INFO - 2024-07-23 12:59:59 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:59 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:59 --> Controller Class Initialized
INFO - 2024-07-23 12:59:59 --> Helper loaded: cookie_helper
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Hooks Class Initialized
DEBUG - 2024-07-23 12:59:59 --> UTF-8 Support Enabled
INFO - 2024-07-23 12:59:59 --> Utf8 Class Initialized
INFO - 2024-07-23 12:59:59 --> URI Class Initialized
INFO - 2024-07-23 12:59:59 --> Router Class Initialized
INFO - 2024-07-23 12:59:59 --> Output Class Initialized
INFO - 2024-07-23 12:59:59 --> Security Class Initialized
DEBUG - 2024-07-23 12:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 12:59:59 --> Input Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Language Class Initialized
INFO - 2024-07-23 12:59:59 --> Config Class Initialized
INFO - 2024-07-23 12:59:59 --> Loader Class Initialized
INFO - 2024-07-23 12:59:59 --> Helper loaded: url_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: file_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: form_helper
INFO - 2024-07-23 12:59:59 --> Helper loaded: my_helper
INFO - 2024-07-23 12:59:59 --> Database Driver Class Initialized
INFO - 2024-07-23 12:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 12:59:59 --> Controller Class Initialized
DEBUG - 2024-07-23 12:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 12:59:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 12:59:59 --> Final output sent to browser
DEBUG - 2024-07-23 12:59:59 --> Total execution time: 0.0265
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Hooks Class Initialized
DEBUG - 2024-07-23 15:53:58 --> UTF-8 Support Enabled
INFO - 2024-07-23 15:53:58 --> Utf8 Class Initialized
INFO - 2024-07-23 15:53:58 --> URI Class Initialized
INFO - 2024-07-23 15:53:58 --> Router Class Initialized
INFO - 2024-07-23 15:53:58 --> Output Class Initialized
INFO - 2024-07-23 15:53:58 --> Security Class Initialized
DEBUG - 2024-07-23 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 15:53:58 --> Input Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Loader Class Initialized
INFO - 2024-07-23 15:53:58 --> Helper loaded: url_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: file_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: form_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: my_helper
INFO - 2024-07-23 15:53:58 --> Database Driver Class Initialized
INFO - 2024-07-23 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 15:53:58 --> Controller Class Initialized
INFO - 2024-07-23 15:53:58 --> Helper loaded: cookie_helper
INFO - 2024-07-23 15:53:58 --> Final output sent to browser
DEBUG - 2024-07-23 15:53:58 --> Total execution time: 0.0447
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Hooks Class Initialized
DEBUG - 2024-07-23 15:53:58 --> UTF-8 Support Enabled
INFO - 2024-07-23 15:53:58 --> Utf8 Class Initialized
INFO - 2024-07-23 15:53:58 --> URI Class Initialized
INFO - 2024-07-23 15:53:58 --> Router Class Initialized
INFO - 2024-07-23 15:53:58 --> Output Class Initialized
INFO - 2024-07-23 15:53:58 --> Security Class Initialized
DEBUG - 2024-07-23 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 15:53:58 --> Input Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Loader Class Initialized
INFO - 2024-07-23 15:53:58 --> Helper loaded: url_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: file_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: form_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: my_helper
INFO - 2024-07-23 15:53:58 --> Database Driver Class Initialized
INFO - 2024-07-23 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 15:53:58 --> Controller Class Initialized
INFO - 2024-07-23 15:53:58 --> Helper loaded: cookie_helper
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Hooks Class Initialized
DEBUG - 2024-07-23 15:53:58 --> UTF-8 Support Enabled
INFO - 2024-07-23 15:53:58 --> Utf8 Class Initialized
INFO - 2024-07-23 15:53:58 --> URI Class Initialized
INFO - 2024-07-23 15:53:58 --> Router Class Initialized
INFO - 2024-07-23 15:53:58 --> Output Class Initialized
INFO - 2024-07-23 15:53:58 --> Security Class Initialized
DEBUG - 2024-07-23 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 15:53:58 --> Input Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Language Class Initialized
INFO - 2024-07-23 15:53:58 --> Config Class Initialized
INFO - 2024-07-23 15:53:58 --> Loader Class Initialized
INFO - 2024-07-23 15:53:58 --> Helper loaded: url_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: file_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: form_helper
INFO - 2024-07-23 15:53:58 --> Helper loaded: my_helper
INFO - 2024-07-23 15:53:58 --> Database Driver Class Initialized
INFO - 2024-07-23 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 15:53:58 --> Controller Class Initialized
DEBUG - 2024-07-23 15:53:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 15:53:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 15:53:58 --> Final output sent to browser
DEBUG - 2024-07-23 15:53:58 --> Total execution time: 0.0317
INFO - 2024-07-23 15:54:02 --> Config Class Initialized
INFO - 2024-07-23 15:54:02 --> Hooks Class Initialized
DEBUG - 2024-07-23 15:54:02 --> UTF-8 Support Enabled
INFO - 2024-07-23 15:54:02 --> Utf8 Class Initialized
INFO - 2024-07-23 15:54:02 --> URI Class Initialized
INFO - 2024-07-23 15:54:02 --> Router Class Initialized
INFO - 2024-07-23 15:54:02 --> Output Class Initialized
INFO - 2024-07-23 15:54:02 --> Security Class Initialized
DEBUG - 2024-07-23 15:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 15:54:02 --> Input Class Initialized
INFO - 2024-07-23 15:54:02 --> Language Class Initialized
INFO - 2024-07-23 15:54:02 --> Language Class Initialized
INFO - 2024-07-23 15:54:02 --> Config Class Initialized
INFO - 2024-07-23 15:54:02 --> Loader Class Initialized
INFO - 2024-07-23 15:54:02 --> Helper loaded: url_helper
INFO - 2024-07-23 15:54:02 --> Helper loaded: file_helper
INFO - 2024-07-23 15:54:02 --> Helper loaded: form_helper
INFO - 2024-07-23 15:54:02 --> Helper loaded: my_helper
INFO - 2024-07-23 15:54:02 --> Database Driver Class Initialized
INFO - 2024-07-23 15:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 15:54:02 --> Controller Class Initialized
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-23 15:54:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-23 15:54:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-23 15:54:05 --> Final output sent to browser
DEBUG - 2024-07-23 15:54:05 --> Total execution time: 3.2158
INFO - 2024-07-23 17:44:04 --> Config Class Initialized
INFO - 2024-07-23 17:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:04 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:04 --> URI Class Initialized
INFO - 2024-07-23 17:44:04 --> Router Class Initialized
INFO - 2024-07-23 17:44:04 --> Output Class Initialized
INFO - 2024-07-23 17:44:04 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:04 --> Input Class Initialized
INFO - 2024-07-23 17:44:04 --> Language Class Initialized
INFO - 2024-07-23 17:44:04 --> Language Class Initialized
INFO - 2024-07-23 17:44:04 --> Config Class Initialized
INFO - 2024-07-23 17:44:04 --> Loader Class Initialized
INFO - 2024-07-23 17:44:04 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:04 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:04 --> Controller Class Initialized
INFO - 2024-07-23 17:44:04 --> Helper loaded: cookie_helper
INFO - 2024-07-23 17:44:04 --> Final output sent to browser
DEBUG - 2024-07-23 17:44:04 --> Total execution time: 0.0746
INFO - 2024-07-23 17:44:04 --> Config Class Initialized
INFO - 2024-07-23 17:44:04 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:04 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:04 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:04 --> URI Class Initialized
INFO - 2024-07-23 17:44:04 --> Router Class Initialized
INFO - 2024-07-23 17:44:04 --> Output Class Initialized
INFO - 2024-07-23 17:44:04 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:04 --> Input Class Initialized
INFO - 2024-07-23 17:44:04 --> Language Class Initialized
INFO - 2024-07-23 17:44:04 --> Language Class Initialized
INFO - 2024-07-23 17:44:04 --> Config Class Initialized
INFO - 2024-07-23 17:44:04 --> Loader Class Initialized
INFO - 2024-07-23 17:44:04 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:04 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:05 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:05 --> Controller Class Initialized
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:05 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:05 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:05 --> URI Class Initialized
INFO - 2024-07-23 17:44:05 --> Router Class Initialized
INFO - 2024-07-23 17:44:05 --> Output Class Initialized
INFO - 2024-07-23 17:44:05 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:05 --> Input Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Loader Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:05 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: cookie_helper
INFO - 2024-07-23 17:44:05 --> Final output sent to browser
DEBUG - 2024-07-23 17:44:05 --> Total execution time: 0.0779
INFO - 2024-07-23 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:05 --> Controller Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: cookie_helper
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:05 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:05 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:05 --> URI Class Initialized
INFO - 2024-07-23 17:44:05 --> Router Class Initialized
INFO - 2024-07-23 17:44:05 --> Output Class Initialized
INFO - 2024-07-23 17:44:05 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:05 --> Input Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Loader Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:05 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:05 --> Controller Class Initialized
DEBUG - 2024-07-23 17:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 17:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 17:44:05 --> Final output sent to browser
DEBUG - 2024-07-23 17:44:05 --> Total execution time: 0.0362
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:05 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:05 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:05 --> URI Class Initialized
INFO - 2024-07-23 17:44:05 --> Router Class Initialized
INFO - 2024-07-23 17:44:05 --> Output Class Initialized
INFO - 2024-07-23 17:44:05 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:05 --> Input Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Loader Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:05 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:05 --> Controller Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: cookie_helper
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:05 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:05 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:05 --> URI Class Initialized
INFO - 2024-07-23 17:44:05 --> Router Class Initialized
INFO - 2024-07-23 17:44:05 --> Output Class Initialized
INFO - 2024-07-23 17:44:05 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:05 --> Input Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Language Class Initialized
INFO - 2024-07-23 17:44:05 --> Config Class Initialized
INFO - 2024-07-23 17:44:05 --> Loader Class Initialized
INFO - 2024-07-23 17:44:05 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:05 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:05 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:05 --> Controller Class Initialized
DEBUG - 2024-07-23 17:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 17:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 17:44:05 --> Final output sent to browser
DEBUG - 2024-07-23 17:44:05 --> Total execution time: 0.0780
INFO - 2024-07-23 17:44:38 --> Config Class Initialized
INFO - 2024-07-23 17:44:38 --> Hooks Class Initialized
DEBUG - 2024-07-23 17:44:38 --> UTF-8 Support Enabled
INFO - 2024-07-23 17:44:38 --> Utf8 Class Initialized
INFO - 2024-07-23 17:44:38 --> URI Class Initialized
INFO - 2024-07-23 17:44:38 --> Router Class Initialized
INFO - 2024-07-23 17:44:38 --> Output Class Initialized
INFO - 2024-07-23 17:44:38 --> Security Class Initialized
DEBUG - 2024-07-23 17:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 17:44:38 --> Input Class Initialized
INFO - 2024-07-23 17:44:38 --> Language Class Initialized
INFO - 2024-07-23 17:44:38 --> Language Class Initialized
INFO - 2024-07-23 17:44:38 --> Config Class Initialized
INFO - 2024-07-23 17:44:38 --> Loader Class Initialized
INFO - 2024-07-23 17:44:38 --> Helper loaded: url_helper
INFO - 2024-07-23 17:44:38 --> Helper loaded: file_helper
INFO - 2024-07-23 17:44:38 --> Helper loaded: form_helper
INFO - 2024-07-23 17:44:38 --> Helper loaded: my_helper
INFO - 2024-07-23 17:44:38 --> Database Driver Class Initialized
INFO - 2024-07-23 17:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 17:44:38 --> Controller Class Initialized
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-23 17:44:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-23 17:44:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-23 17:44:41 --> Final output sent to browser
DEBUG - 2024-07-23 17:44:41 --> Total execution time: 2.7900
INFO - 2024-07-23 21:17:52 --> Config Class Initialized
INFO - 2024-07-23 21:17:52 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:17:52 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:17:52 --> Utf8 Class Initialized
INFO - 2024-07-23 21:17:52 --> URI Class Initialized
INFO - 2024-07-23 21:17:52 --> Router Class Initialized
INFO - 2024-07-23 21:17:52 --> Output Class Initialized
INFO - 2024-07-23 21:17:52 --> Security Class Initialized
DEBUG - 2024-07-23 21:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:17:52 --> Input Class Initialized
INFO - 2024-07-23 21:17:52 --> Language Class Initialized
INFO - 2024-07-23 21:17:52 --> Language Class Initialized
INFO - 2024-07-23 21:17:52 --> Config Class Initialized
INFO - 2024-07-23 21:17:52 --> Loader Class Initialized
INFO - 2024-07-23 21:17:52 --> Helper loaded: url_helper
INFO - 2024-07-23 21:17:52 --> Helper loaded: file_helper
INFO - 2024-07-23 21:17:52 --> Helper loaded: form_helper
INFO - 2024-07-23 21:17:52 --> Helper loaded: my_helper
INFO - 2024-07-23 21:17:52 --> Database Driver Class Initialized
INFO - 2024-07-23 21:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:17:52 --> Controller Class Initialized
INFO - 2024-07-23 21:17:52 --> Helper loaded: cookie_helper
INFO - 2024-07-23 21:17:52 --> Final output sent to browser
DEBUG - 2024-07-23 21:17:52 --> Total execution time: 0.0520
INFO - 2024-07-23 21:17:53 --> Config Class Initialized
INFO - 2024-07-23 21:17:53 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:17:53 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:17:53 --> Utf8 Class Initialized
INFO - 2024-07-23 21:17:53 --> URI Class Initialized
INFO - 2024-07-23 21:17:53 --> Router Class Initialized
INFO - 2024-07-23 21:17:53 --> Output Class Initialized
INFO - 2024-07-23 21:17:53 --> Security Class Initialized
DEBUG - 2024-07-23 21:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:17:53 --> Input Class Initialized
INFO - 2024-07-23 21:17:53 --> Language Class Initialized
INFO - 2024-07-23 21:17:53 --> Language Class Initialized
INFO - 2024-07-23 21:17:53 --> Config Class Initialized
INFO - 2024-07-23 21:17:53 --> Loader Class Initialized
INFO - 2024-07-23 21:17:53 --> Helper loaded: url_helper
INFO - 2024-07-23 21:17:53 --> Helper loaded: file_helper
INFO - 2024-07-23 21:17:53 --> Helper loaded: form_helper
INFO - 2024-07-23 21:17:53 --> Helper loaded: my_helper
INFO - 2024-07-23 21:17:53 --> Database Driver Class Initialized
INFO - 2024-07-23 21:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:17:53 --> Controller Class Initialized
INFO - 2024-07-23 21:17:53 --> Helper loaded: cookie_helper
INFO - 2024-07-23 21:17:55 --> Config Class Initialized
INFO - 2024-07-23 21:17:55 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:17:55 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:17:55 --> Utf8 Class Initialized
INFO - 2024-07-23 21:17:55 --> URI Class Initialized
INFO - 2024-07-23 21:17:55 --> Router Class Initialized
INFO - 2024-07-23 21:17:55 --> Output Class Initialized
INFO - 2024-07-23 21:17:55 --> Security Class Initialized
DEBUG - 2024-07-23 21:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:17:55 --> Input Class Initialized
INFO - 2024-07-23 21:17:55 --> Language Class Initialized
INFO - 2024-07-23 21:17:55 --> Language Class Initialized
INFO - 2024-07-23 21:17:55 --> Config Class Initialized
INFO - 2024-07-23 21:17:55 --> Loader Class Initialized
INFO - 2024-07-23 21:17:55 --> Helper loaded: url_helper
INFO - 2024-07-23 21:17:55 --> Helper loaded: file_helper
INFO - 2024-07-23 21:17:55 --> Helper loaded: form_helper
INFO - 2024-07-23 21:17:55 --> Helper loaded: my_helper
INFO - 2024-07-23 21:17:55 --> Database Driver Class Initialized
INFO - 2024-07-23 21:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:17:55 --> Controller Class Initialized
DEBUG - 2024-07-23 21:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 21:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 21:17:55 --> Final output sent to browser
DEBUG - 2024-07-23 21:17:55 --> Total execution time: 0.0343
INFO - 2024-07-23 21:23:03 --> Config Class Initialized
INFO - 2024-07-23 21:23:03 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:03 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:03 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:03 --> URI Class Initialized
INFO - 2024-07-23 21:23:03 --> Router Class Initialized
INFO - 2024-07-23 21:23:03 --> Output Class Initialized
INFO - 2024-07-23 21:23:03 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:03 --> Input Class Initialized
INFO - 2024-07-23 21:23:03 --> Language Class Initialized
INFO - 2024-07-23 21:23:03 --> Language Class Initialized
INFO - 2024-07-23 21:23:03 --> Config Class Initialized
INFO - 2024-07-23 21:23:03 --> Loader Class Initialized
INFO - 2024-07-23 21:23:03 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:03 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:03 --> Controller Class Initialized
INFO - 2024-07-23 21:23:03 --> Helper loaded: cookie_helper
INFO - 2024-07-23 21:23:03 --> Final output sent to browser
DEBUG - 2024-07-23 21:23:03 --> Total execution time: 0.0351
INFO - 2024-07-23 21:23:03 --> Config Class Initialized
INFO - 2024-07-23 21:23:03 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:03 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:03 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:03 --> URI Class Initialized
INFO - 2024-07-23 21:23:03 --> Router Class Initialized
INFO - 2024-07-23 21:23:03 --> Output Class Initialized
INFO - 2024-07-23 21:23:03 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:03 --> Input Class Initialized
INFO - 2024-07-23 21:23:03 --> Language Class Initialized
INFO - 2024-07-23 21:23:03 --> Language Class Initialized
INFO - 2024-07-23 21:23:03 --> Config Class Initialized
INFO - 2024-07-23 21:23:03 --> Loader Class Initialized
INFO - 2024-07-23 21:23:03 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:03 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:03 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:03 --> Controller Class Initialized
INFO - 2024-07-23 21:23:03 --> Helper loaded: cookie_helper
INFO - 2024-07-23 21:23:04 --> Config Class Initialized
INFO - 2024-07-23 21:23:04 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:04 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:04 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:04 --> URI Class Initialized
INFO - 2024-07-23 21:23:04 --> Router Class Initialized
INFO - 2024-07-23 21:23:04 --> Output Class Initialized
INFO - 2024-07-23 21:23:04 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:04 --> Input Class Initialized
INFO - 2024-07-23 21:23:04 --> Language Class Initialized
INFO - 2024-07-23 21:23:04 --> Language Class Initialized
INFO - 2024-07-23 21:23:04 --> Config Class Initialized
INFO - 2024-07-23 21:23:04 --> Loader Class Initialized
INFO - 2024-07-23 21:23:04 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:04 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:04 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:04 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:04 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:04 --> Controller Class Initialized
DEBUG - 2024-07-23 21:23:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 21:23:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 21:23:04 --> Final output sent to browser
DEBUG - 2024-07-23 21:23:04 --> Total execution time: 0.0312
INFO - 2024-07-23 21:23:17 --> Config Class Initialized
INFO - 2024-07-23 21:23:17 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:17 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:17 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:17 --> URI Class Initialized
INFO - 2024-07-23 21:23:17 --> Router Class Initialized
INFO - 2024-07-23 21:23:17 --> Output Class Initialized
INFO - 2024-07-23 21:23:17 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:17 --> Input Class Initialized
INFO - 2024-07-23 21:23:17 --> Language Class Initialized
INFO - 2024-07-23 21:23:17 --> Language Class Initialized
INFO - 2024-07-23 21:23:17 --> Config Class Initialized
INFO - 2024-07-23 21:23:17 --> Loader Class Initialized
INFO - 2024-07-23 21:23:17 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:17 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:17 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:17 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:17 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:17 --> Controller Class Initialized
DEBUG - 2024-07-23 21:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-23 21:23:19 --> Config Class Initialized
INFO - 2024-07-23 21:23:19 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:19 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:19 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:19 --> URI Class Initialized
INFO - 2024-07-23 21:23:19 --> Router Class Initialized
INFO - 2024-07-23 21:23:19 --> Output Class Initialized
INFO - 2024-07-23 21:23:19 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:19 --> Input Class Initialized
INFO - 2024-07-23 21:23:19 --> Language Class Initialized
INFO - 2024-07-23 21:23:19 --> Language Class Initialized
INFO - 2024-07-23 21:23:19 --> Config Class Initialized
INFO - 2024-07-23 21:23:19 --> Loader Class Initialized
INFO - 2024-07-23 21:23:19 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:19 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:19 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:19 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:19 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:21 --> Controller Class Initialized
DEBUG - 2024-07-23 21:23:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-23 21:23:21 --> Config Class Initialized
INFO - 2024-07-23 21:23:21 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:21 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:21 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:21 --> URI Class Initialized
INFO - 2024-07-23 21:23:21 --> Router Class Initialized
INFO - 2024-07-23 21:23:21 --> Output Class Initialized
INFO - 2024-07-23 21:23:21 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:21 --> Input Class Initialized
INFO - 2024-07-23 21:23:21 --> Language Class Initialized
INFO - 2024-07-23 21:23:21 --> Language Class Initialized
INFO - 2024-07-23 21:23:21 --> Config Class Initialized
INFO - 2024-07-23 21:23:21 --> Loader Class Initialized
INFO - 2024-07-23 21:23:21 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:21 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:21 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:21 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:21 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:24 --> Controller Class Initialized
DEBUG - 2024-07-23 21:23:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-23 21:23:31 --> Config Class Initialized
INFO - 2024-07-23 21:23:31 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:23:31 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:23:31 --> Utf8 Class Initialized
INFO - 2024-07-23 21:23:31 --> URI Class Initialized
INFO - 2024-07-23 21:23:31 --> Router Class Initialized
INFO - 2024-07-23 21:23:31 --> Output Class Initialized
INFO - 2024-07-23 21:23:31 --> Security Class Initialized
DEBUG - 2024-07-23 21:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:23:31 --> Input Class Initialized
INFO - 2024-07-23 21:23:31 --> Language Class Initialized
INFO - 2024-07-23 21:23:31 --> Language Class Initialized
INFO - 2024-07-23 21:23:31 --> Config Class Initialized
INFO - 2024-07-23 21:23:31 --> Loader Class Initialized
INFO - 2024-07-23 21:23:31 --> Helper loaded: url_helper
INFO - 2024-07-23 21:23:31 --> Helper loaded: file_helper
INFO - 2024-07-23 21:23:31 --> Helper loaded: form_helper
INFO - 2024-07-23 21:23:31 --> Helper loaded: my_helper
INFO - 2024-07-23 21:23:31 --> Database Driver Class Initialized
INFO - 2024-07-23 21:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:23:31 --> Controller Class Initialized
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-23 21:23:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-23 21:23:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-23 21:23:34 --> Final output sent to browser
DEBUG - 2024-07-23 21:23:34 --> Total execution time: 2.8697
INFO - 2024-07-23 21:24:34 --> Config Class Initialized
INFO - 2024-07-23 21:24:34 --> Hooks Class Initialized
DEBUG - 2024-07-23 21:24:34 --> UTF-8 Support Enabled
INFO - 2024-07-23 21:24:34 --> Utf8 Class Initialized
INFO - 2024-07-23 21:24:34 --> URI Class Initialized
INFO - 2024-07-23 21:24:35 --> Router Class Initialized
INFO - 2024-07-23 21:24:35 --> Output Class Initialized
INFO - 2024-07-23 21:24:35 --> Security Class Initialized
DEBUG - 2024-07-23 21:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-23 21:24:35 --> Input Class Initialized
INFO - 2024-07-23 21:24:35 --> Language Class Initialized
INFO - 2024-07-23 21:24:35 --> Language Class Initialized
INFO - 2024-07-23 21:24:35 --> Config Class Initialized
INFO - 2024-07-23 21:24:35 --> Loader Class Initialized
INFO - 2024-07-23 21:24:35 --> Helper loaded: url_helper
INFO - 2024-07-23 21:24:35 --> Helper loaded: file_helper
INFO - 2024-07-23 21:24:35 --> Helper loaded: form_helper
INFO - 2024-07-23 21:24:35 --> Helper loaded: my_helper
INFO - 2024-07-23 21:24:35 --> Database Driver Class Initialized
INFO - 2024-07-23 21:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-23 21:24:35 --> Controller Class Initialized
DEBUG - 2024-07-23 21:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-23 21:24:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-23 21:24:35 --> Final output sent to browser
DEBUG - 2024-07-23 21:24:35 --> Total execution time: 0.0289
