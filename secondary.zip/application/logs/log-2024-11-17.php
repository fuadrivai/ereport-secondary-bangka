<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-17 00:39:21 --> Config Class Initialized
INFO - 2024-11-17 00:39:21 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:21 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:21 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:21 --> URI Class Initialized
INFO - 2024-11-17 00:39:21 --> Router Class Initialized
INFO - 2024-11-17 00:39:21 --> Output Class Initialized
INFO - 2024-11-17 00:39:21 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:21 --> Input Class Initialized
INFO - 2024-11-17 00:39:21 --> Language Class Initialized
INFO - 2024-11-17 00:39:21 --> Language Class Initialized
INFO - 2024-11-17 00:39:21 --> Config Class Initialized
INFO - 2024-11-17 00:39:21 --> Loader Class Initialized
INFO - 2024-11-17 00:39:21 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:21 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:21 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:21 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:21 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:21 --> Controller Class Initialized
INFO - 2024-11-17 00:39:21 --> Helper loaded: cookie_helper
INFO - 2024-11-17 00:39:21 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:21 --> Total execution time: 0.0641
INFO - 2024-11-17 00:39:22 --> Config Class Initialized
INFO - 2024-11-17 00:39:22 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:22 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:22 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:22 --> URI Class Initialized
INFO - 2024-11-17 00:39:22 --> Router Class Initialized
INFO - 2024-11-17 00:39:22 --> Output Class Initialized
INFO - 2024-11-17 00:39:22 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:22 --> Input Class Initialized
INFO - 2024-11-17 00:39:22 --> Language Class Initialized
INFO - 2024-11-17 00:39:22 --> Language Class Initialized
INFO - 2024-11-17 00:39:22 --> Config Class Initialized
INFO - 2024-11-17 00:39:22 --> Loader Class Initialized
INFO - 2024-11-17 00:39:22 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:22 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:22 --> Controller Class Initialized
INFO - 2024-11-17 00:39:22 --> Helper loaded: cookie_helper
INFO - 2024-11-17 00:39:22 --> Config Class Initialized
INFO - 2024-11-17 00:39:22 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:22 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:22 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:22 --> URI Class Initialized
INFO - 2024-11-17 00:39:22 --> Router Class Initialized
INFO - 2024-11-17 00:39:22 --> Output Class Initialized
INFO - 2024-11-17 00:39:22 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:22 --> Input Class Initialized
INFO - 2024-11-17 00:39:22 --> Language Class Initialized
INFO - 2024-11-17 00:39:22 --> Language Class Initialized
INFO - 2024-11-17 00:39:22 --> Config Class Initialized
INFO - 2024-11-17 00:39:22 --> Loader Class Initialized
INFO - 2024-11-17 00:39:22 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:22 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:22 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:22 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 00:39:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 00:39:22 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:22 --> Total execution time: 0.0435
INFO - 2024-11-17 00:39:26 --> Config Class Initialized
INFO - 2024-11-17 00:39:26 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:26 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:26 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:26 --> URI Class Initialized
INFO - 2024-11-17 00:39:26 --> Router Class Initialized
INFO - 2024-11-17 00:39:26 --> Output Class Initialized
INFO - 2024-11-17 00:39:26 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:26 --> Input Class Initialized
INFO - 2024-11-17 00:39:26 --> Language Class Initialized
INFO - 2024-11-17 00:39:26 --> Language Class Initialized
INFO - 2024-11-17 00:39:26 --> Config Class Initialized
INFO - 2024-11-17 00:39:26 --> Loader Class Initialized
INFO - 2024-11-17 00:39:26 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:26 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:26 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:26 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:26 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:26 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:29 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:29 --> Total execution time: 3.1715
INFO - 2024-11-17 00:39:29 --> Config Class Initialized
INFO - 2024-11-17 00:39:29 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:29 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:29 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:29 --> URI Class Initialized
INFO - 2024-11-17 00:39:29 --> Router Class Initialized
INFO - 2024-11-17 00:39:29 --> Output Class Initialized
INFO - 2024-11-17 00:39:29 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:29 --> Input Class Initialized
INFO - 2024-11-17 00:39:29 --> Language Class Initialized
INFO - 2024-11-17 00:39:29 --> Language Class Initialized
INFO - 2024-11-17 00:39:29 --> Config Class Initialized
INFO - 2024-11-17 00:39:29 --> Loader Class Initialized
INFO - 2024-11-17 00:39:29 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:29 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:29 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:29 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:29 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:29 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:30 --> Config Class Initialized
INFO - 2024-11-17 00:39:30 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:30 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:30 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:30 --> URI Class Initialized
INFO - 2024-11-17 00:39:30 --> Router Class Initialized
INFO - 2024-11-17 00:39:30 --> Output Class Initialized
INFO - 2024-11-17 00:39:30 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:30 --> Input Class Initialized
INFO - 2024-11-17 00:39:30 --> Language Class Initialized
INFO - 2024-11-17 00:39:30 --> Language Class Initialized
INFO - 2024-11-17 00:39:30 --> Config Class Initialized
INFO - 2024-11-17 00:39:30 --> Loader Class Initialized
INFO - 2024-11-17 00:39:30 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:30 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:30 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:30 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:30 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:31 --> Config Class Initialized
INFO - 2024-11-17 00:39:31 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:31 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:31 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:31 --> URI Class Initialized
INFO - 2024-11-17 00:39:31 --> Router Class Initialized
INFO - 2024-11-17 00:39:31 --> Output Class Initialized
INFO - 2024-11-17 00:39:31 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:31 --> Input Class Initialized
INFO - 2024-11-17 00:39:31 --> Language Class Initialized
INFO - 2024-11-17 00:39:31 --> Language Class Initialized
INFO - 2024-11-17 00:39:31 --> Config Class Initialized
INFO - 2024-11-17 00:39:31 --> Loader Class Initialized
INFO - 2024-11-17 00:39:31 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:31 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:31 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:31 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:31 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:32 --> Config Class Initialized
INFO - 2024-11-17 00:39:32 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:32 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:32 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:32 --> URI Class Initialized
INFO - 2024-11-17 00:39:32 --> Router Class Initialized
INFO - 2024-11-17 00:39:32 --> Output Class Initialized
INFO - 2024-11-17 00:39:32 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:32 --> Input Class Initialized
INFO - 2024-11-17 00:39:32 --> Language Class Initialized
INFO - 2024-11-17 00:39:32 --> Language Class Initialized
INFO - 2024-11-17 00:39:32 --> Config Class Initialized
INFO - 2024-11-17 00:39:32 --> Loader Class Initialized
INFO - 2024-11-17 00:39:32 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:32 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:32 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:32 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:32 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:32 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:32 --> Total execution time: 3.0297
INFO - 2024-11-17 00:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:32 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:35 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:35 --> Total execution time: 4.7811
INFO - 2024-11-17 00:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:35 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:38 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:38 --> Total execution time: 6.7816
INFO - 2024-11-17 00:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:38 --> Controller Class Initialized
INFO - 2024-11-17 00:39:38 --> Config Class Initialized
INFO - 2024-11-17 00:39:38 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:38 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:38 --> Utf8 Class Initialized
DEBUG - 2024-11-17 00:39:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:38 --> URI Class Initialized
INFO - 2024-11-17 00:39:38 --> Router Class Initialized
INFO - 2024-11-17 00:39:38 --> Output Class Initialized
INFO - 2024-11-17 00:39:38 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:38 --> Input Class Initialized
INFO - 2024-11-17 00:39:38 --> Language Class Initialized
INFO - 2024-11-17 00:39:38 --> Language Class Initialized
INFO - 2024-11-17 00:39:38 --> Config Class Initialized
INFO - 2024-11-17 00:39:38 --> Loader Class Initialized
INFO - 2024-11-17 00:39:38 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:38 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:38 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:38 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:38 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:41 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:41 --> Total execution time: 9.1238
INFO - 2024-11-17 00:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:41 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:41 --> Config Class Initialized
INFO - 2024-11-17 00:39:41 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:41 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:41 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:41 --> URI Class Initialized
INFO - 2024-11-17 00:39:41 --> Router Class Initialized
INFO - 2024-11-17 00:39:41 --> Output Class Initialized
INFO - 2024-11-17 00:39:41 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:41 --> Input Class Initialized
INFO - 2024-11-17 00:39:41 --> Language Class Initialized
INFO - 2024-11-17 00:39:41 --> Language Class Initialized
INFO - 2024-11-17 00:39:41 --> Config Class Initialized
INFO - 2024-11-17 00:39:41 --> Loader Class Initialized
INFO - 2024-11-17 00:39:41 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:41 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:41 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:41 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:41 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:44 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:44 --> Total execution time: 5.9897
INFO - 2024-11-17 00:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:44 --> Controller Class Initialized
INFO - 2024-11-17 00:39:44 --> Config Class Initialized
INFO - 2024-11-17 00:39:44 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:44 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:44 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:44 --> URI Class Initialized
DEBUG - 2024-11-17 00:39:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:44 --> Router Class Initialized
INFO - 2024-11-17 00:39:44 --> Output Class Initialized
INFO - 2024-11-17 00:39:44 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:44 --> Input Class Initialized
INFO - 2024-11-17 00:39:44 --> Language Class Initialized
INFO - 2024-11-17 00:39:44 --> Language Class Initialized
INFO - 2024-11-17 00:39:44 --> Config Class Initialized
INFO - 2024-11-17 00:39:44 --> Loader Class Initialized
INFO - 2024-11-17 00:39:44 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:44 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:44 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:44 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:44 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:46 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:46 --> Total execution time: 5.3228
INFO - 2024-11-17 00:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:46 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:49 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:49 --> Total execution time: 5.2251
INFO - 2024-11-17 00:39:49 --> Config Class Initialized
INFO - 2024-11-17 00:39:49 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:49 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:49 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:49 --> URI Class Initialized
INFO - 2024-11-17 00:39:49 --> Router Class Initialized
INFO - 2024-11-17 00:39:49 --> Output Class Initialized
INFO - 2024-11-17 00:39:49 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:49 --> Input Class Initialized
INFO - 2024-11-17 00:39:49 --> Language Class Initialized
INFO - 2024-11-17 00:39:49 --> Language Class Initialized
INFO - 2024-11-17 00:39:49 --> Config Class Initialized
INFO - 2024-11-17 00:39:49 --> Loader Class Initialized
INFO - 2024-11-17 00:39:49 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:49 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:49 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:49 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:49 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:49 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:51 --> Config Class Initialized
INFO - 2024-11-17 00:39:51 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:51 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:51 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:51 --> URI Class Initialized
INFO - 2024-11-17 00:39:51 --> Router Class Initialized
INFO - 2024-11-17 00:39:51 --> Output Class Initialized
INFO - 2024-11-17 00:39:51 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:51 --> Input Class Initialized
INFO - 2024-11-17 00:39:51 --> Language Class Initialized
INFO - 2024-11-17 00:39:51 --> Language Class Initialized
INFO - 2024-11-17 00:39:51 --> Config Class Initialized
INFO - 2024-11-17 00:39:51 --> Loader Class Initialized
INFO - 2024-11-17 00:39:51 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:51 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:51 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:51 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:51 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:52 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:52 --> Total execution time: 2.7175
INFO - 2024-11-17 00:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:52 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 00:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 00:39:52 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:52 --> Total execution time: 0.7825
INFO - 2024-11-17 00:39:56 --> Config Class Initialized
INFO - 2024-11-17 00:39:56 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:56 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:56 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:56 --> URI Class Initialized
INFO - 2024-11-17 00:39:56 --> Router Class Initialized
INFO - 2024-11-17 00:39:56 --> Output Class Initialized
INFO - 2024-11-17 00:39:56 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:56 --> Input Class Initialized
INFO - 2024-11-17 00:39:56 --> Language Class Initialized
INFO - 2024-11-17 00:39:56 --> Language Class Initialized
INFO - 2024-11-17 00:39:56 --> Config Class Initialized
INFO - 2024-11-17 00:39:56 --> Loader Class Initialized
INFO - 2024-11-17 00:39:56 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:56 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:56 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:56 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:56 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:56 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:39:58 --> Final output sent to browser
DEBUG - 2024-11-17 00:39:58 --> Total execution time: 2.6346
INFO - 2024-11-17 00:39:58 --> Config Class Initialized
INFO - 2024-11-17 00:39:58 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:39:58 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:39:58 --> Utf8 Class Initialized
INFO - 2024-11-17 00:39:58 --> URI Class Initialized
INFO - 2024-11-17 00:39:58 --> Router Class Initialized
INFO - 2024-11-17 00:39:58 --> Output Class Initialized
INFO - 2024-11-17 00:39:58 --> Security Class Initialized
DEBUG - 2024-11-17 00:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:39:58 --> Input Class Initialized
INFO - 2024-11-17 00:39:58 --> Language Class Initialized
INFO - 2024-11-17 00:39:58 --> Language Class Initialized
INFO - 2024-11-17 00:39:58 --> Config Class Initialized
INFO - 2024-11-17 00:39:58 --> Loader Class Initialized
INFO - 2024-11-17 00:39:58 --> Helper loaded: url_helper
INFO - 2024-11-17 00:39:58 --> Helper loaded: file_helper
INFO - 2024-11-17 00:39:58 --> Helper loaded: form_helper
INFO - 2024-11-17 00:39:58 --> Helper loaded: my_helper
INFO - 2024-11-17 00:39:58 --> Database Driver Class Initialized
INFO - 2024-11-17 00:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:39:58 --> Controller Class Initialized
DEBUG - 2024-11-17 00:39:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:02 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:02 --> Total execution time: 3.5993
INFO - 2024-11-17 00:40:02 --> Config Class Initialized
INFO - 2024-11-17 00:40:02 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:02 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:02 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:02 --> URI Class Initialized
INFO - 2024-11-17 00:40:02 --> Router Class Initialized
INFO - 2024-11-17 00:40:02 --> Output Class Initialized
INFO - 2024-11-17 00:40:02 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:02 --> Input Class Initialized
INFO - 2024-11-17 00:40:02 --> Language Class Initialized
INFO - 2024-11-17 00:40:02 --> Language Class Initialized
INFO - 2024-11-17 00:40:02 --> Config Class Initialized
INFO - 2024-11-17 00:40:02 --> Loader Class Initialized
INFO - 2024-11-17 00:40:02 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:02 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:02 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:02 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:02 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:02 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:06 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:06 --> Total execution time: 3.4348
INFO - 2024-11-17 00:40:06 --> Config Class Initialized
INFO - 2024-11-17 00:40:06 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:06 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:06 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:06 --> URI Class Initialized
INFO - 2024-11-17 00:40:06 --> Router Class Initialized
INFO - 2024-11-17 00:40:06 --> Output Class Initialized
INFO - 2024-11-17 00:40:06 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:06 --> Input Class Initialized
INFO - 2024-11-17 00:40:06 --> Language Class Initialized
INFO - 2024-11-17 00:40:06 --> Language Class Initialized
INFO - 2024-11-17 00:40:06 --> Config Class Initialized
INFO - 2024-11-17 00:40:06 --> Loader Class Initialized
INFO - 2024-11-17 00:40:06 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:06 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:06 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:06 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:06 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:06 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:07 --> Config Class Initialized
INFO - 2024-11-17 00:40:07 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:07 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:07 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:07 --> URI Class Initialized
INFO - 2024-11-17 00:40:07 --> Router Class Initialized
INFO - 2024-11-17 00:40:07 --> Output Class Initialized
INFO - 2024-11-17 00:40:07 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:07 --> Input Class Initialized
INFO - 2024-11-17 00:40:07 --> Language Class Initialized
INFO - 2024-11-17 00:40:07 --> Language Class Initialized
INFO - 2024-11-17 00:40:07 --> Config Class Initialized
INFO - 2024-11-17 00:40:07 --> Loader Class Initialized
INFO - 2024-11-17 00:40:07 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:07 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:07 --> Controller Class Initialized
INFO - 2024-11-17 00:40:07 --> Helper loaded: cookie_helper
INFO - 2024-11-17 00:40:07 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:07 --> Total execution time: 0.1058
INFO - 2024-11-17 00:40:07 --> Config Class Initialized
INFO - 2024-11-17 00:40:07 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:07 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:07 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:07 --> URI Class Initialized
INFO - 2024-11-17 00:40:07 --> Router Class Initialized
INFO - 2024-11-17 00:40:07 --> Output Class Initialized
INFO - 2024-11-17 00:40:07 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:07 --> Input Class Initialized
INFO - 2024-11-17 00:40:07 --> Language Class Initialized
INFO - 2024-11-17 00:40:07 --> Language Class Initialized
INFO - 2024-11-17 00:40:07 --> Config Class Initialized
INFO - 2024-11-17 00:40:07 --> Loader Class Initialized
INFO - 2024-11-17 00:40:07 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:07 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:07 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:09 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:09 --> Total execution time: 2.9540
INFO - 2024-11-17 00:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:09 --> Controller Class Initialized
INFO - 2024-11-17 00:40:09 --> Helper loaded: cookie_helper
INFO - 2024-11-17 00:40:09 --> Config Class Initialized
INFO - 2024-11-17 00:40:09 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:09 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:09 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:09 --> URI Class Initialized
INFO - 2024-11-17 00:40:09 --> Router Class Initialized
INFO - 2024-11-17 00:40:09 --> Output Class Initialized
INFO - 2024-11-17 00:40:09 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:09 --> Input Class Initialized
INFO - 2024-11-17 00:40:09 --> Language Class Initialized
INFO - 2024-11-17 00:40:09 --> Language Class Initialized
INFO - 2024-11-17 00:40:09 --> Config Class Initialized
INFO - 2024-11-17 00:40:09 --> Loader Class Initialized
INFO - 2024-11-17 00:40:09 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:09 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:09 --> Config Class Initialized
INFO - 2024-11-17 00:40:09 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:09 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:09 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:09 --> URI Class Initialized
INFO - 2024-11-17 00:40:09 --> Router Class Initialized
INFO - 2024-11-17 00:40:09 --> Output Class Initialized
INFO - 2024-11-17 00:40:09 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:09 --> Input Class Initialized
INFO - 2024-11-17 00:40:09 --> Language Class Initialized
INFO - 2024-11-17 00:40:09 --> Language Class Initialized
INFO - 2024-11-17 00:40:09 --> Config Class Initialized
INFO - 2024-11-17 00:40:09 --> Loader Class Initialized
INFO - 2024-11-17 00:40:09 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:09 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:09 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:09 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:12 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:12 --> Total execution time: 2.8518
INFO - 2024-11-17 00:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:12 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 00:40:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 00:40:12 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:12 --> Total execution time: 2.8289
INFO - 2024-11-17 00:40:12 --> Config Class Initialized
INFO - 2024-11-17 00:40:12 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:12 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:12 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:12 --> URI Class Initialized
INFO - 2024-11-17 00:40:12 --> Router Class Initialized
INFO - 2024-11-17 00:40:12 --> Output Class Initialized
INFO - 2024-11-17 00:40:12 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:12 --> Input Class Initialized
INFO - 2024-11-17 00:40:12 --> Language Class Initialized
INFO - 2024-11-17 00:40:12 --> Language Class Initialized
INFO - 2024-11-17 00:40:12 --> Config Class Initialized
INFO - 2024-11-17 00:40:12 --> Loader Class Initialized
INFO - 2024-11-17 00:40:12 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:12 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:12 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:12 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:12 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:12 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:15 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:15 --> Total execution time: 2.9425
INFO - 2024-11-17 00:40:15 --> Config Class Initialized
INFO - 2024-11-17 00:40:15 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:15 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:15 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:15 --> URI Class Initialized
INFO - 2024-11-17 00:40:15 --> Config Class Initialized
INFO - 2024-11-17 00:40:15 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:15 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:15 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:15 --> URI Class Initialized
INFO - 2024-11-17 00:40:15 --> Router Class Initialized
INFO - 2024-11-17 00:40:15 --> Output Class Initialized
INFO - 2024-11-17 00:40:15 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:15 --> Input Class Initialized
INFO - 2024-11-17 00:40:15 --> Language Class Initialized
INFO - 2024-11-17 00:40:15 --> Router Class Initialized
INFO - 2024-11-17 00:40:15 --> Output Class Initialized
INFO - 2024-11-17 00:40:15 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:15 --> Input Class Initialized
INFO - 2024-11-17 00:40:15 --> Language Class Initialized
INFO - 2024-11-17 00:40:15 --> Language Class Initialized
INFO - 2024-11-17 00:40:15 --> Config Class Initialized
INFO - 2024-11-17 00:40:15 --> Loader Class Initialized
INFO - 2024-11-17 00:40:15 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:15 --> Language Class Initialized
INFO - 2024-11-17 00:40:15 --> Config Class Initialized
INFO - 2024-11-17 00:40:15 --> Loader Class Initialized
INFO - 2024-11-17 00:40:15 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:15 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:15 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:15 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:15 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:18 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:18 --> Total execution time: 2.8558
INFO - 2024-11-17 00:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:18 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:21 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:21 --> Total execution time: 6.0143
INFO - 2024-11-17 00:40:21 --> Config Class Initialized
INFO - 2024-11-17 00:40:21 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:21 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:21 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:21 --> URI Class Initialized
INFO - 2024-11-17 00:40:21 --> Router Class Initialized
INFO - 2024-11-17 00:40:21 --> Output Class Initialized
INFO - 2024-11-17 00:40:21 --> Config Class Initialized
INFO - 2024-11-17 00:40:21 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:21 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:21 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:21 --> URI Class Initialized
INFO - 2024-11-17 00:40:21 --> Router Class Initialized
INFO - 2024-11-17 00:40:21 --> Output Class Initialized
INFO - 2024-11-17 00:40:21 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:21 --> Input Class Initialized
INFO - 2024-11-17 00:40:21 --> Language Class Initialized
INFO - 2024-11-17 00:40:21 --> Language Class Initialized
INFO - 2024-11-17 00:40:21 --> Config Class Initialized
INFO - 2024-11-17 00:40:21 --> Loader Class Initialized
INFO - 2024-11-17 00:40:21 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:21 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:21 --> Input Class Initialized
INFO - 2024-11-17 00:40:21 --> Language Class Initialized
INFO - 2024-11-17 00:40:21 --> Language Class Initialized
INFO - 2024-11-17 00:40:21 --> Config Class Initialized
INFO - 2024-11-17 00:40:21 --> Loader Class Initialized
INFO - 2024-11-17 00:40:21 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:21 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:21 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:21 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:21 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:21 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:21 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:21 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:21 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:21 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:24 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:24 --> Total execution time: 2.7931
INFO - 2024-11-17 00:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:24 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:24 --> Config Class Initialized
INFO - 2024-11-17 00:40:24 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:24 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:24 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:24 --> URI Class Initialized
INFO - 2024-11-17 00:40:24 --> Router Class Initialized
INFO - 2024-11-17 00:40:24 --> Output Class Initialized
INFO - 2024-11-17 00:40:24 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:24 --> Input Class Initialized
INFO - 2024-11-17 00:40:24 --> Language Class Initialized
INFO - 2024-11-17 00:40:24 --> Language Class Initialized
INFO - 2024-11-17 00:40:24 --> Config Class Initialized
INFO - 2024-11-17 00:40:24 --> Loader Class Initialized
INFO - 2024-11-17 00:40:24 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:24 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:24 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:24 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:24 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:27 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:27 --> Total execution time: 5.6046
INFO - 2024-11-17 00:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:27 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:30 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:30 --> Total execution time: 5.6265
INFO - 2024-11-17 00:40:30 --> Config Class Initialized
INFO - 2024-11-17 00:40:30 --> Hooks Class Initialized
DEBUG - 2024-11-17 00:40:30 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:30 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:30 --> URI Class Initialized
INFO - 2024-11-17 00:40:30 --> Router Class Initialized
INFO - 2024-11-17 00:40:30 --> Output Class Initialized
INFO - 2024-11-17 00:40:30 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:30 --> Input Class Initialized
INFO - 2024-11-17 00:40:30 --> Language Class Initialized
INFO - 2024-11-17 00:40:30 --> Config Class Initialized
INFO - 2024-11-17 00:40:30 --> Hooks Class Initialized
INFO - 2024-11-17 00:40:30 --> Language Class Initialized
INFO - 2024-11-17 00:40:30 --> Config Class Initialized
INFO - 2024-11-17 00:40:30 --> Loader Class Initialized
INFO - 2024-11-17 00:40:30 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: my_helper
DEBUG - 2024-11-17 00:40:30 --> UTF-8 Support Enabled
INFO - 2024-11-17 00:40:30 --> Utf8 Class Initialized
INFO - 2024-11-17 00:40:30 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:30 --> URI Class Initialized
INFO - 2024-11-17 00:40:30 --> Router Class Initialized
INFO - 2024-11-17 00:40:30 --> Output Class Initialized
INFO - 2024-11-17 00:40:30 --> Security Class Initialized
DEBUG - 2024-11-17 00:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 00:40:30 --> Input Class Initialized
INFO - 2024-11-17 00:40:30 --> Language Class Initialized
INFO - 2024-11-17 00:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:30 --> Controller Class Initialized
INFO - 2024-11-17 00:40:30 --> Language Class Initialized
INFO - 2024-11-17 00:40:30 --> Config Class Initialized
INFO - 2024-11-17 00:40:30 --> Loader Class Initialized
DEBUG - 2024-11-17 00:40:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 00:40:30 --> Helper loaded: url_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: file_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: form_helper
INFO - 2024-11-17 00:40:30 --> Helper loaded: my_helper
INFO - 2024-11-17 00:40:30 --> Database Driver Class Initialized
INFO - 2024-11-17 00:40:33 --> Final output sent to browser
DEBUG - 2024-11-17 00:40:33 --> Total execution time: 2.9295
INFO - 2024-11-17 00:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 00:40:33 --> Controller Class Initialized
DEBUG - 2024-11-17 00:40:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 20:07:58 --> Config Class Initialized
INFO - 2024-11-17 20:07:58 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:07:58 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:07:58 --> Utf8 Class Initialized
INFO - 2024-11-17 20:07:58 --> URI Class Initialized
INFO - 2024-11-17 20:07:58 --> Router Class Initialized
INFO - 2024-11-17 20:07:58 --> Output Class Initialized
INFO - 2024-11-17 20:07:58 --> Security Class Initialized
DEBUG - 2024-11-17 20:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:07:58 --> Input Class Initialized
INFO - 2024-11-17 20:07:58 --> Language Class Initialized
INFO - 2024-11-17 20:07:58 --> Language Class Initialized
INFO - 2024-11-17 20:07:58 --> Config Class Initialized
INFO - 2024-11-17 20:07:58 --> Loader Class Initialized
INFO - 2024-11-17 20:07:58 --> Helper loaded: url_helper
INFO - 2024-11-17 20:07:58 --> Helper loaded: file_helper
INFO - 2024-11-17 20:07:58 --> Helper loaded: form_helper
INFO - 2024-11-17 20:07:58 --> Helper loaded: my_helper
INFO - 2024-11-17 20:07:58 --> Database Driver Class Initialized
INFO - 2024-11-17 20:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:07:58 --> Controller Class Initialized
INFO - 2024-11-17 20:07:58 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:07:58 --> Final output sent to browser
DEBUG - 2024-11-17 20:07:58 --> Total execution time: 0.0817
INFO - 2024-11-17 20:07:59 --> Config Class Initialized
INFO - 2024-11-17 20:07:59 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:07:59 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:07:59 --> Utf8 Class Initialized
INFO - 2024-11-17 20:07:59 --> URI Class Initialized
INFO - 2024-11-17 20:07:59 --> Router Class Initialized
INFO - 2024-11-17 20:07:59 --> Output Class Initialized
INFO - 2024-11-17 20:07:59 --> Security Class Initialized
DEBUG - 2024-11-17 20:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:07:59 --> Input Class Initialized
INFO - 2024-11-17 20:07:59 --> Language Class Initialized
INFO - 2024-11-17 20:07:59 --> Language Class Initialized
INFO - 2024-11-17 20:07:59 --> Config Class Initialized
INFO - 2024-11-17 20:07:59 --> Loader Class Initialized
INFO - 2024-11-17 20:07:59 --> Helper loaded: url_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: file_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: form_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: my_helper
INFO - 2024-11-17 20:07:59 --> Database Driver Class Initialized
INFO - 2024-11-17 20:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:07:59 --> Controller Class Initialized
INFO - 2024-11-17 20:07:59 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:07:59 --> Config Class Initialized
INFO - 2024-11-17 20:07:59 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:07:59 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:07:59 --> Utf8 Class Initialized
INFO - 2024-11-17 20:07:59 --> URI Class Initialized
INFO - 2024-11-17 20:07:59 --> Router Class Initialized
INFO - 2024-11-17 20:07:59 --> Output Class Initialized
INFO - 2024-11-17 20:07:59 --> Security Class Initialized
DEBUG - 2024-11-17 20:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:07:59 --> Input Class Initialized
INFO - 2024-11-17 20:07:59 --> Language Class Initialized
INFO - 2024-11-17 20:07:59 --> Language Class Initialized
INFO - 2024-11-17 20:07:59 --> Config Class Initialized
INFO - 2024-11-17 20:07:59 --> Loader Class Initialized
INFO - 2024-11-17 20:07:59 --> Helper loaded: url_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: file_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: form_helper
INFO - 2024-11-17 20:07:59 --> Helper loaded: my_helper
INFO - 2024-11-17 20:07:59 --> Database Driver Class Initialized
INFO - 2024-11-17 20:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:07:59 --> Controller Class Initialized
DEBUG - 2024-11-17 20:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 20:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 20:07:59 --> Final output sent to browser
DEBUG - 2024-11-17 20:07:59 --> Total execution time: 0.0354
INFO - 2024-11-17 20:08:02 --> Config Class Initialized
INFO - 2024-11-17 20:08:02 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:08:02 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:08:02 --> Utf8 Class Initialized
INFO - 2024-11-17 20:08:02 --> URI Class Initialized
INFO - 2024-11-17 20:08:02 --> Router Class Initialized
INFO - 2024-11-17 20:08:02 --> Output Class Initialized
INFO - 2024-11-17 20:08:02 --> Security Class Initialized
DEBUG - 2024-11-17 20:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:08:02 --> Input Class Initialized
INFO - 2024-11-17 20:08:02 --> Language Class Initialized
INFO - 2024-11-17 20:08:02 --> Language Class Initialized
INFO - 2024-11-17 20:08:02 --> Config Class Initialized
INFO - 2024-11-17 20:08:02 --> Loader Class Initialized
INFO - 2024-11-17 20:08:02 --> Helper loaded: url_helper
INFO - 2024-11-17 20:08:02 --> Helper loaded: file_helper
INFO - 2024-11-17 20:08:02 --> Helper loaded: form_helper
INFO - 2024-11-17 20:08:02 --> Helper loaded: my_helper
INFO - 2024-11-17 20:08:02 --> Database Driver Class Initialized
INFO - 2024-11-17 20:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:08:02 --> Controller Class Initialized
DEBUG - 2024-11-17 20:08:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 20:08:05 --> Final output sent to browser
DEBUG - 2024-11-17 20:08:05 --> Total execution time: 3.3086
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:12:32 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:12:32 --> Utf8 Class Initialized
INFO - 2024-11-17 20:12:32 --> URI Class Initialized
INFO - 2024-11-17 20:12:32 --> Router Class Initialized
INFO - 2024-11-17 20:12:32 --> Output Class Initialized
INFO - 2024-11-17 20:12:32 --> Security Class Initialized
DEBUG - 2024-11-17 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:12:32 --> Input Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Loader Class Initialized
INFO - 2024-11-17 20:12:32 --> Helper loaded: url_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: file_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: form_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: my_helper
INFO - 2024-11-17 20:12:32 --> Database Driver Class Initialized
INFO - 2024-11-17 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:12:32 --> Controller Class Initialized
INFO - 2024-11-17 20:12:32 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:12:32 --> Final output sent to browser
DEBUG - 2024-11-17 20:12:32 --> Total execution time: 0.0294
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:12:32 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:12:32 --> Utf8 Class Initialized
INFO - 2024-11-17 20:12:32 --> URI Class Initialized
INFO - 2024-11-17 20:12:32 --> Router Class Initialized
INFO - 2024-11-17 20:12:32 --> Output Class Initialized
INFO - 2024-11-17 20:12:32 --> Security Class Initialized
DEBUG - 2024-11-17 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:12:32 --> Input Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Loader Class Initialized
INFO - 2024-11-17 20:12:32 --> Helper loaded: url_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: file_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: form_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: my_helper
INFO - 2024-11-17 20:12:32 --> Database Driver Class Initialized
INFO - 2024-11-17 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:12:32 --> Controller Class Initialized
INFO - 2024-11-17 20:12:32 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:12:32 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:12:32 --> Utf8 Class Initialized
INFO - 2024-11-17 20:12:32 --> URI Class Initialized
INFO - 2024-11-17 20:12:32 --> Router Class Initialized
INFO - 2024-11-17 20:12:32 --> Output Class Initialized
INFO - 2024-11-17 20:12:32 --> Security Class Initialized
DEBUG - 2024-11-17 20:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:12:32 --> Input Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Language Class Initialized
INFO - 2024-11-17 20:12:32 --> Config Class Initialized
INFO - 2024-11-17 20:12:32 --> Loader Class Initialized
INFO - 2024-11-17 20:12:32 --> Helper loaded: url_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: file_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: form_helper
INFO - 2024-11-17 20:12:32 --> Helper loaded: my_helper
INFO - 2024-11-17 20:12:32 --> Database Driver Class Initialized
INFO - 2024-11-17 20:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:12:32 --> Controller Class Initialized
DEBUG - 2024-11-17 20:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 20:12:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 20:12:32 --> Final output sent to browser
DEBUG - 2024-11-17 20:12:32 --> Total execution time: 0.0298
INFO - 2024-11-17 20:12:33 --> Config Class Initialized
INFO - 2024-11-17 20:12:33 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:12:33 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:12:33 --> Utf8 Class Initialized
INFO - 2024-11-17 20:12:33 --> URI Class Initialized
INFO - 2024-11-17 20:12:33 --> Router Class Initialized
INFO - 2024-11-17 20:12:33 --> Output Class Initialized
INFO - 2024-11-17 20:12:33 --> Security Class Initialized
DEBUG - 2024-11-17 20:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:12:33 --> Input Class Initialized
INFO - 2024-11-17 20:12:33 --> Language Class Initialized
INFO - 2024-11-17 20:12:33 --> Language Class Initialized
INFO - 2024-11-17 20:12:33 --> Config Class Initialized
INFO - 2024-11-17 20:12:33 --> Loader Class Initialized
INFO - 2024-11-17 20:12:33 --> Helper loaded: url_helper
INFO - 2024-11-17 20:12:33 --> Helper loaded: file_helper
INFO - 2024-11-17 20:12:33 --> Helper loaded: form_helper
INFO - 2024-11-17 20:12:33 --> Helper loaded: my_helper
INFO - 2024-11-17 20:12:33 --> Database Driver Class Initialized
INFO - 2024-11-17 20:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:12:33 --> Controller Class Initialized
DEBUG - 2024-11-17 20:12:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 20:12:36 --> Final output sent to browser
DEBUG - 2024-11-17 20:12:36 --> Total execution time: 2.6737
INFO - 2024-11-17 20:13:09 --> Config Class Initialized
INFO - 2024-11-17 20:13:09 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:13:09 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:13:09 --> Utf8 Class Initialized
INFO - 2024-11-17 20:13:09 --> URI Class Initialized
INFO - 2024-11-17 20:13:09 --> Router Class Initialized
INFO - 2024-11-17 20:13:09 --> Output Class Initialized
INFO - 2024-11-17 20:13:09 --> Security Class Initialized
DEBUG - 2024-11-17 20:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:13:09 --> Input Class Initialized
INFO - 2024-11-17 20:13:09 --> Language Class Initialized
INFO - 2024-11-17 20:13:09 --> Language Class Initialized
INFO - 2024-11-17 20:13:09 --> Config Class Initialized
INFO - 2024-11-17 20:13:09 --> Loader Class Initialized
INFO - 2024-11-17 20:13:09 --> Helper loaded: url_helper
INFO - 2024-11-17 20:13:09 --> Helper loaded: file_helper
INFO - 2024-11-17 20:13:09 --> Helper loaded: form_helper
INFO - 2024-11-17 20:13:09 --> Helper loaded: my_helper
INFO - 2024-11-17 20:13:09 --> Database Driver Class Initialized
INFO - 2024-11-17 20:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:13:09 --> Controller Class Initialized
DEBUG - 2024-11-17 20:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 20:13:12 --> Final output sent to browser
DEBUG - 2024-11-17 20:13:12 --> Total execution time: 2.6928
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:14:59 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:14:59 --> Utf8 Class Initialized
INFO - 2024-11-17 20:14:59 --> URI Class Initialized
INFO - 2024-11-17 20:14:59 --> Router Class Initialized
INFO - 2024-11-17 20:14:59 --> Output Class Initialized
INFO - 2024-11-17 20:14:59 --> Security Class Initialized
DEBUG - 2024-11-17 20:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:14:59 --> Input Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Loader Class Initialized
INFO - 2024-11-17 20:14:59 --> Helper loaded: url_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: file_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: form_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: my_helper
INFO - 2024-11-17 20:14:59 --> Database Driver Class Initialized
INFO - 2024-11-17 20:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:14:59 --> Controller Class Initialized
INFO - 2024-11-17 20:14:59 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:14:59 --> Final output sent to browser
DEBUG - 2024-11-17 20:14:59 --> Total execution time: 0.0694
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:14:59 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:14:59 --> Utf8 Class Initialized
INFO - 2024-11-17 20:14:59 --> URI Class Initialized
INFO - 2024-11-17 20:14:59 --> Router Class Initialized
INFO - 2024-11-17 20:14:59 --> Output Class Initialized
INFO - 2024-11-17 20:14:59 --> Security Class Initialized
DEBUG - 2024-11-17 20:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:14:59 --> Input Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Loader Class Initialized
INFO - 2024-11-17 20:14:59 --> Helper loaded: url_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: file_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: form_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: my_helper
INFO - 2024-11-17 20:14:59 --> Database Driver Class Initialized
INFO - 2024-11-17 20:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:14:59 --> Controller Class Initialized
INFO - 2024-11-17 20:14:59 --> Helper loaded: cookie_helper
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:14:59 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:14:59 --> Utf8 Class Initialized
INFO - 2024-11-17 20:14:59 --> URI Class Initialized
INFO - 2024-11-17 20:14:59 --> Router Class Initialized
INFO - 2024-11-17 20:14:59 --> Output Class Initialized
INFO - 2024-11-17 20:14:59 --> Security Class Initialized
DEBUG - 2024-11-17 20:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:14:59 --> Input Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Language Class Initialized
INFO - 2024-11-17 20:14:59 --> Config Class Initialized
INFO - 2024-11-17 20:14:59 --> Loader Class Initialized
INFO - 2024-11-17 20:14:59 --> Helper loaded: url_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: file_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: form_helper
INFO - 2024-11-17 20:14:59 --> Helper loaded: my_helper
INFO - 2024-11-17 20:14:59 --> Database Driver Class Initialized
INFO - 2024-11-17 20:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:14:59 --> Controller Class Initialized
DEBUG - 2024-11-17 20:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-17 20:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-17 20:15:00 --> Final output sent to browser
DEBUG - 2024-11-17 20:15:00 --> Total execution time: 0.0365
INFO - 2024-11-17 20:15:02 --> Config Class Initialized
INFO - 2024-11-17 20:15:02 --> Hooks Class Initialized
DEBUG - 2024-11-17 20:15:02 --> UTF-8 Support Enabled
INFO - 2024-11-17 20:15:02 --> Utf8 Class Initialized
INFO - 2024-11-17 20:15:02 --> URI Class Initialized
INFO - 2024-11-17 20:15:02 --> Router Class Initialized
INFO - 2024-11-17 20:15:02 --> Output Class Initialized
INFO - 2024-11-17 20:15:02 --> Security Class Initialized
DEBUG - 2024-11-17 20:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 20:15:02 --> Input Class Initialized
INFO - 2024-11-17 20:15:02 --> Language Class Initialized
INFO - 2024-11-17 20:15:02 --> Language Class Initialized
INFO - 2024-11-17 20:15:02 --> Config Class Initialized
INFO - 2024-11-17 20:15:02 --> Loader Class Initialized
INFO - 2024-11-17 20:15:02 --> Helper loaded: url_helper
INFO - 2024-11-17 20:15:02 --> Helper loaded: file_helper
INFO - 2024-11-17 20:15:02 --> Helper loaded: form_helper
INFO - 2024-11-17 20:15:02 --> Helper loaded: my_helper
INFO - 2024-11-17 20:15:02 --> Database Driver Class Initialized
INFO - 2024-11-17 20:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 20:15:02 --> Controller Class Initialized
DEBUG - 2024-11-17 20:15:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-17 20:15:05 --> Final output sent to browser
DEBUG - 2024-11-17 20:15:05 --> Total execution time: 3.1844
