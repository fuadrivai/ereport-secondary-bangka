<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-07 03:40:11 --> Config Class Initialized
INFO - 2023-06-07 03:40:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:11 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:11 --> URI Class Initialized
DEBUG - 2023-06-07 03:40:11 --> No URI present. Default controller set.
INFO - 2023-06-07 03:40:11 --> Router Class Initialized
INFO - 2023-06-07 03:40:11 --> Output Class Initialized
INFO - 2023-06-07 03:40:11 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:11 --> Input Class Initialized
INFO - 2023-06-07 03:40:11 --> Language Class Initialized
INFO - 2023-06-07 03:40:11 --> Language Class Initialized
INFO - 2023-06-07 03:40:11 --> Config Class Initialized
INFO - 2023-06-07 03:40:11 --> Loader Class Initialized
INFO - 2023-06-07 03:40:11 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:11 --> Controller Class Initialized
INFO - 2023-06-07 03:40:11 --> Config Class Initialized
INFO - 2023-06-07 03:40:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:11 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:11 --> URI Class Initialized
INFO - 2023-06-07 03:40:11 --> Router Class Initialized
INFO - 2023-06-07 03:40:11 --> Output Class Initialized
INFO - 2023-06-07 03:40:11 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:11 --> Input Class Initialized
INFO - 2023-06-07 03:40:11 --> Language Class Initialized
INFO - 2023-06-07 03:40:11 --> Language Class Initialized
INFO - 2023-06-07 03:40:11 --> Config Class Initialized
INFO - 2023-06-07 03:40:11 --> Loader Class Initialized
INFO - 2023-06-07 03:40:11 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:11 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:11 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 03:40:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:40:11 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:11 --> Total execution time: 0.0402
INFO - 2023-06-07 03:40:18 --> Config Class Initialized
INFO - 2023-06-07 03:40:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:18 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:18 --> URI Class Initialized
INFO - 2023-06-07 03:40:18 --> Router Class Initialized
INFO - 2023-06-07 03:40:18 --> Output Class Initialized
INFO - 2023-06-07 03:40:18 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:18 --> Input Class Initialized
INFO - 2023-06-07 03:40:18 --> Language Class Initialized
INFO - 2023-06-07 03:40:18 --> Language Class Initialized
INFO - 2023-06-07 03:40:18 --> Config Class Initialized
INFO - 2023-06-07 03:40:18 --> Loader Class Initialized
INFO - 2023-06-07 03:40:18 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:18 --> Controller Class Initialized
INFO - 2023-06-07 03:40:18 --> Helper loaded: cookie_helper
INFO - 2023-06-07 03:40:18 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:18 --> Total execution time: 0.0888
INFO - 2023-06-07 03:40:18 --> Config Class Initialized
INFO - 2023-06-07 03:40:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:18 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:18 --> URI Class Initialized
INFO - 2023-06-07 03:40:18 --> Router Class Initialized
INFO - 2023-06-07 03:40:18 --> Output Class Initialized
INFO - 2023-06-07 03:40:18 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:18 --> Input Class Initialized
INFO - 2023-06-07 03:40:18 --> Language Class Initialized
INFO - 2023-06-07 03:40:18 --> Language Class Initialized
INFO - 2023-06-07 03:40:18 --> Config Class Initialized
INFO - 2023-06-07 03:40:18 --> Loader Class Initialized
INFO - 2023-06-07 03:40:18 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:18 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:18 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-07 03:40:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:40:18 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:18 --> Total execution time: 0.0594
INFO - 2023-06-07 03:40:20 --> Config Class Initialized
INFO - 2023-06-07 03:40:20 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:20 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:20 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:20 --> URI Class Initialized
INFO - 2023-06-07 03:40:20 --> Router Class Initialized
INFO - 2023-06-07 03:40:20 --> Output Class Initialized
INFO - 2023-06-07 03:40:20 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:20 --> Input Class Initialized
INFO - 2023-06-07 03:40:20 --> Language Class Initialized
INFO - 2023-06-07 03:40:20 --> Language Class Initialized
INFO - 2023-06-07 03:40:20 --> Config Class Initialized
INFO - 2023-06-07 03:40:20 --> Loader Class Initialized
INFO - 2023-06-07 03:40:20 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:20 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:20 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:20 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:20 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:20 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-06-07 03:40:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:40:20 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:20 --> Total execution time: 0.0269
INFO - 2023-06-07 03:40:37 --> Config Class Initialized
INFO - 2023-06-07 03:40:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:37 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:37 --> URI Class Initialized
INFO - 2023-06-07 03:40:37 --> Router Class Initialized
INFO - 2023-06-07 03:40:37 --> Output Class Initialized
INFO - 2023-06-07 03:40:37 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:37 --> Input Class Initialized
INFO - 2023-06-07 03:40:37 --> Language Class Initialized
INFO - 2023-06-07 03:40:37 --> Language Class Initialized
INFO - 2023-06-07 03:40:37 --> Config Class Initialized
INFO - 2023-06-07 03:40:37 --> Loader Class Initialized
INFO - 2023-06-07 03:40:37 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:37 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:37 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:37 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:37 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-07 03:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:40:37 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:37 --> Total execution time: 0.0323
INFO - 2023-06-07 03:40:39 --> Config Class Initialized
INFO - 2023-06-07 03:40:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:39 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:39 --> URI Class Initialized
INFO - 2023-06-07 03:40:39 --> Router Class Initialized
INFO - 2023-06-07 03:40:39 --> Output Class Initialized
INFO - 2023-06-07 03:40:39 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:39 --> Input Class Initialized
INFO - 2023-06-07 03:40:39 --> Language Class Initialized
INFO - 2023-06-07 03:40:39 --> Language Class Initialized
INFO - 2023-06-07 03:40:39 --> Config Class Initialized
INFO - 2023-06-07 03:40:39 --> Loader Class Initialized
INFO - 2023-06-07 03:40:39 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:39 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:39 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:39 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:40 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 03:40:41 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:41 --> Total execution time: 2.0607
INFO - 2023-06-07 03:40:53 --> Config Class Initialized
INFO - 2023-06-07 03:40:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:40:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:40:53 --> Utf8 Class Initialized
INFO - 2023-06-07 03:40:53 --> URI Class Initialized
INFO - 2023-06-07 03:40:53 --> Router Class Initialized
INFO - 2023-06-07 03:40:53 --> Output Class Initialized
INFO - 2023-06-07 03:40:53 --> Security Class Initialized
DEBUG - 2023-06-07 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:40:53 --> Input Class Initialized
INFO - 2023-06-07 03:40:53 --> Language Class Initialized
INFO - 2023-06-07 03:40:53 --> Language Class Initialized
INFO - 2023-06-07 03:40:53 --> Config Class Initialized
INFO - 2023-06-07 03:40:53 --> Loader Class Initialized
INFO - 2023-06-07 03:40:53 --> Helper loaded: url_helper
INFO - 2023-06-07 03:40:53 --> Helper loaded: file_helper
INFO - 2023-06-07 03:40:53 --> Helper loaded: form_helper
INFO - 2023-06-07 03:40:53 --> Helper loaded: my_helper
INFO - 2023-06-07 03:40:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:40:53 --> Controller Class Initialized
DEBUG - 2023-06-07 03:40:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-06-07 03:40:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:40:53 --> Final output sent to browser
DEBUG - 2023-06-07 03:40:53 --> Total execution time: 0.1119
INFO - 2023-06-07 03:41:08 --> Config Class Initialized
INFO - 2023-06-07 03:41:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:41:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:41:08 --> Utf8 Class Initialized
INFO - 2023-06-07 03:41:08 --> URI Class Initialized
INFO - 2023-06-07 03:41:08 --> Router Class Initialized
INFO - 2023-06-07 03:41:08 --> Output Class Initialized
INFO - 2023-06-07 03:41:08 --> Security Class Initialized
DEBUG - 2023-06-07 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:41:08 --> Input Class Initialized
INFO - 2023-06-07 03:41:08 --> Language Class Initialized
INFO - 2023-06-07 03:41:08 --> Language Class Initialized
INFO - 2023-06-07 03:41:08 --> Config Class Initialized
INFO - 2023-06-07 03:41:08 --> Loader Class Initialized
INFO - 2023-06-07 03:41:08 --> Helper loaded: url_helper
INFO - 2023-06-07 03:41:08 --> Helper loaded: file_helper
INFO - 2023-06-07 03:41:08 --> Helper loaded: form_helper
INFO - 2023-06-07 03:41:08 --> Helper loaded: my_helper
INFO - 2023-06-07 03:41:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:41:08 --> Controller Class Initialized
DEBUG - 2023-06-07 03:41:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-06-07 03:41:10 --> Final output sent to browser
DEBUG - 2023-06-07 03:41:10 --> Total execution time: 1.1691
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:41:34 --> Utf8 Class Initialized
INFO - 2023-06-07 03:41:34 --> URI Class Initialized
INFO - 2023-06-07 03:41:34 --> Router Class Initialized
INFO - 2023-06-07 03:41:34 --> Output Class Initialized
INFO - 2023-06-07 03:41:34 --> Security Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:41:34 --> Input Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Loader Class Initialized
INFO - 2023-06-07 03:41:34 --> Helper loaded: url_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: file_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: form_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: my_helper
INFO - 2023-06-07 03:41:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:41:34 --> Controller Class Initialized
INFO - 2023-06-07 03:41:34 --> Helper loaded: cookie_helper
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:41:34 --> Utf8 Class Initialized
INFO - 2023-06-07 03:41:34 --> URI Class Initialized
INFO - 2023-06-07 03:41:34 --> Router Class Initialized
INFO - 2023-06-07 03:41:34 --> Output Class Initialized
INFO - 2023-06-07 03:41:34 --> Security Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:41:34 --> Input Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Loader Class Initialized
INFO - 2023-06-07 03:41:34 --> Helper loaded: url_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: file_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: form_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: my_helper
INFO - 2023-06-07 03:41:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:41:34 --> Controller Class Initialized
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:41:34 --> Utf8 Class Initialized
INFO - 2023-06-07 03:41:34 --> URI Class Initialized
INFO - 2023-06-07 03:41:34 --> Router Class Initialized
INFO - 2023-06-07 03:41:34 --> Output Class Initialized
INFO - 2023-06-07 03:41:34 --> Security Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:41:34 --> Input Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Language Class Initialized
INFO - 2023-06-07 03:41:34 --> Config Class Initialized
INFO - 2023-06-07 03:41:34 --> Loader Class Initialized
INFO - 2023-06-07 03:41:34 --> Helper loaded: url_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: file_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: form_helper
INFO - 2023-06-07 03:41:34 --> Helper loaded: my_helper
INFO - 2023-06-07 03:41:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:41:34 --> Controller Class Initialized
DEBUG - 2023-06-07 03:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 03:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:41:34 --> Final output sent to browser
DEBUG - 2023-06-07 03:41:34 --> Total execution time: 0.0433
INFO - 2023-06-07 03:42:35 --> Config Class Initialized
INFO - 2023-06-07 03:42:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:35 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:35 --> URI Class Initialized
DEBUG - 2023-06-07 03:42:35 --> No URI present. Default controller set.
INFO - 2023-06-07 03:42:35 --> Router Class Initialized
INFO - 2023-06-07 03:42:35 --> Output Class Initialized
INFO - 2023-06-07 03:42:35 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:35 --> Input Class Initialized
INFO - 2023-06-07 03:42:35 --> Language Class Initialized
INFO - 2023-06-07 03:42:35 --> Language Class Initialized
INFO - 2023-06-07 03:42:35 --> Config Class Initialized
INFO - 2023-06-07 03:42:35 --> Loader Class Initialized
INFO - 2023-06-07 03:42:35 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:35 --> Controller Class Initialized
INFO - 2023-06-07 03:42:35 --> Config Class Initialized
INFO - 2023-06-07 03:42:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:35 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:35 --> URI Class Initialized
INFO - 2023-06-07 03:42:35 --> Router Class Initialized
INFO - 2023-06-07 03:42:35 --> Output Class Initialized
INFO - 2023-06-07 03:42:35 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:35 --> Input Class Initialized
INFO - 2023-06-07 03:42:35 --> Language Class Initialized
INFO - 2023-06-07 03:42:35 --> Language Class Initialized
INFO - 2023-06-07 03:42:35 --> Config Class Initialized
INFO - 2023-06-07 03:42:35 --> Loader Class Initialized
INFO - 2023-06-07 03:42:35 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:35 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:35 --> Controller Class Initialized
DEBUG - 2023-06-07 03:42:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 03:42:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:42:35 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:35 --> Total execution time: 0.0332
INFO - 2023-06-07 03:42:39 --> Config Class Initialized
INFO - 2023-06-07 03:42:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:39 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:39 --> URI Class Initialized
INFO - 2023-06-07 03:42:39 --> Router Class Initialized
INFO - 2023-06-07 03:42:39 --> Output Class Initialized
INFO - 2023-06-07 03:42:39 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:39 --> Input Class Initialized
INFO - 2023-06-07 03:42:39 --> Language Class Initialized
INFO - 2023-06-07 03:42:39 --> Language Class Initialized
INFO - 2023-06-07 03:42:39 --> Config Class Initialized
INFO - 2023-06-07 03:42:39 --> Loader Class Initialized
INFO - 2023-06-07 03:42:39 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:39 --> Controller Class Initialized
INFO - 2023-06-07 03:42:39 --> Helper loaded: cookie_helper
INFO - 2023-06-07 03:42:39 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:39 --> Total execution time: 0.0248
INFO - 2023-06-07 03:42:39 --> Config Class Initialized
INFO - 2023-06-07 03:42:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:39 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:39 --> URI Class Initialized
INFO - 2023-06-07 03:42:39 --> Router Class Initialized
INFO - 2023-06-07 03:42:39 --> Output Class Initialized
INFO - 2023-06-07 03:42:39 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:39 --> Input Class Initialized
INFO - 2023-06-07 03:42:39 --> Language Class Initialized
INFO - 2023-06-07 03:42:39 --> Language Class Initialized
INFO - 2023-06-07 03:42:39 --> Config Class Initialized
INFO - 2023-06-07 03:42:39 --> Loader Class Initialized
INFO - 2023-06-07 03:42:39 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:39 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:39 --> Controller Class Initialized
DEBUG - 2023-06-07 03:42:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-07 03:42:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:42:39 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:39 --> Total execution time: 0.0446
INFO - 2023-06-07 03:42:45 --> Config Class Initialized
INFO - 2023-06-07 03:42:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:45 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:45 --> URI Class Initialized
INFO - 2023-06-07 03:42:45 --> Router Class Initialized
INFO - 2023-06-07 03:42:45 --> Output Class Initialized
INFO - 2023-06-07 03:42:45 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:45 --> Input Class Initialized
INFO - 2023-06-07 03:42:45 --> Language Class Initialized
INFO - 2023-06-07 03:42:45 --> Language Class Initialized
INFO - 2023-06-07 03:42:45 --> Config Class Initialized
INFO - 2023-06-07 03:42:45 --> Loader Class Initialized
INFO - 2023-06-07 03:42:45 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:45 --> Controller Class Initialized
DEBUG - 2023-06-07 03:42:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_walikelas/views/list.php
DEBUG - 2023-06-07 03:42:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:42:45 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:45 --> Total execution time: 0.0546
INFO - 2023-06-07 03:42:45 --> Config Class Initialized
INFO - 2023-06-07 03:42:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:45 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:45 --> URI Class Initialized
INFO - 2023-06-07 03:42:45 --> Router Class Initialized
INFO - 2023-06-07 03:42:45 --> Output Class Initialized
INFO - 2023-06-07 03:42:45 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:45 --> Input Class Initialized
INFO - 2023-06-07 03:42:45 --> Language Class Initialized
INFO - 2023-06-07 03:42:45 --> Language Class Initialized
INFO - 2023-06-07 03:42:45 --> Config Class Initialized
INFO - 2023-06-07 03:42:45 --> Loader Class Initialized
INFO - 2023-06-07 03:42:45 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:45 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:45 --> Controller Class Initialized
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:47 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:47 --> URI Class Initialized
INFO - 2023-06-07 03:42:47 --> Router Class Initialized
INFO - 2023-06-07 03:42:47 --> Output Class Initialized
INFO - 2023-06-07 03:42:47 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:47 --> Input Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Loader Class Initialized
INFO - 2023-06-07 03:42:47 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:47 --> Controller Class Initialized
INFO - 2023-06-07 03:42:47 --> Helper loaded: cookie_helper
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:47 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:47 --> URI Class Initialized
INFO - 2023-06-07 03:42:47 --> Router Class Initialized
INFO - 2023-06-07 03:42:47 --> Output Class Initialized
INFO - 2023-06-07 03:42:47 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:47 --> Input Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Loader Class Initialized
INFO - 2023-06-07 03:42:47 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:47 --> Controller Class Initialized
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:47 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:47 --> URI Class Initialized
INFO - 2023-06-07 03:42:47 --> Router Class Initialized
INFO - 2023-06-07 03:42:47 --> Output Class Initialized
INFO - 2023-06-07 03:42:47 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:47 --> Input Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Language Class Initialized
INFO - 2023-06-07 03:42:47 --> Config Class Initialized
INFO - 2023-06-07 03:42:47 --> Loader Class Initialized
INFO - 2023-06-07 03:42:47 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:47 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:47 --> Controller Class Initialized
DEBUG - 2023-06-07 03:42:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 03:42:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:42:47 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:47 --> Total execution time: 0.0223
INFO - 2023-06-07 03:42:50 --> Config Class Initialized
INFO - 2023-06-07 03:42:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:50 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:50 --> URI Class Initialized
INFO - 2023-06-07 03:42:50 --> Router Class Initialized
INFO - 2023-06-07 03:42:50 --> Output Class Initialized
INFO - 2023-06-07 03:42:50 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:50 --> Input Class Initialized
INFO - 2023-06-07 03:42:50 --> Language Class Initialized
INFO - 2023-06-07 03:42:50 --> Language Class Initialized
INFO - 2023-06-07 03:42:50 --> Config Class Initialized
INFO - 2023-06-07 03:42:50 --> Loader Class Initialized
INFO - 2023-06-07 03:42:50 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:50 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:50 --> Controller Class Initialized
INFO - 2023-06-07 03:42:50 --> Helper loaded: cookie_helper
INFO - 2023-06-07 03:42:50 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:50 --> Total execution time: 0.0370
INFO - 2023-06-07 03:42:50 --> Config Class Initialized
INFO - 2023-06-07 03:42:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:42:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:42:50 --> Utf8 Class Initialized
INFO - 2023-06-07 03:42:50 --> URI Class Initialized
INFO - 2023-06-07 03:42:50 --> Router Class Initialized
INFO - 2023-06-07 03:42:50 --> Output Class Initialized
INFO - 2023-06-07 03:42:50 --> Security Class Initialized
DEBUG - 2023-06-07 03:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:42:50 --> Input Class Initialized
INFO - 2023-06-07 03:42:50 --> Language Class Initialized
INFO - 2023-06-07 03:42:50 --> Language Class Initialized
INFO - 2023-06-07 03:42:50 --> Config Class Initialized
INFO - 2023-06-07 03:42:50 --> Loader Class Initialized
INFO - 2023-06-07 03:42:50 --> Helper loaded: url_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: file_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: form_helper
INFO - 2023-06-07 03:42:50 --> Helper loaded: my_helper
INFO - 2023-06-07 03:42:50 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:42:50 --> Controller Class Initialized
DEBUG - 2023-06-07 03:42:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-07 03:42:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:42:50 --> Final output sent to browser
DEBUG - 2023-06-07 03:42:50 --> Total execution time: 0.0279
INFO - 2023-06-07 03:43:03 --> Config Class Initialized
INFO - 2023-06-07 03:43:03 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:43:03 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:43:03 --> Utf8 Class Initialized
INFO - 2023-06-07 03:43:03 --> URI Class Initialized
INFO - 2023-06-07 03:43:03 --> Router Class Initialized
INFO - 2023-06-07 03:43:03 --> Output Class Initialized
INFO - 2023-06-07 03:43:03 --> Security Class Initialized
DEBUG - 2023-06-07 03:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:43:03 --> Input Class Initialized
INFO - 2023-06-07 03:43:03 --> Language Class Initialized
INFO - 2023-06-07 03:43:03 --> Language Class Initialized
INFO - 2023-06-07 03:43:03 --> Config Class Initialized
INFO - 2023-06-07 03:43:03 --> Loader Class Initialized
INFO - 2023-06-07 03:43:03 --> Helper loaded: url_helper
INFO - 2023-06-07 03:43:03 --> Helper loaded: file_helper
INFO - 2023-06-07 03:43:03 --> Helper loaded: form_helper
INFO - 2023-06-07 03:43:03 --> Helper loaded: my_helper
INFO - 2023-06-07 03:43:03 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:43:04 --> Controller Class Initialized
DEBUG - 2023-06-07 03:43:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-07 03:43:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:43:04 --> Final output sent to browser
DEBUG - 2023-06-07 03:43:04 --> Total execution time: 0.0506
INFO - 2023-06-07 03:43:05 --> Config Class Initialized
INFO - 2023-06-07 03:43:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:43:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:43:05 --> Utf8 Class Initialized
INFO - 2023-06-07 03:43:05 --> URI Class Initialized
INFO - 2023-06-07 03:43:05 --> Router Class Initialized
INFO - 2023-06-07 03:43:05 --> Output Class Initialized
INFO - 2023-06-07 03:43:05 --> Security Class Initialized
DEBUG - 2023-06-07 03:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:43:05 --> Input Class Initialized
INFO - 2023-06-07 03:43:05 --> Language Class Initialized
INFO - 2023-06-07 03:43:05 --> Language Class Initialized
INFO - 2023-06-07 03:43:05 --> Config Class Initialized
INFO - 2023-06-07 03:43:05 --> Loader Class Initialized
INFO - 2023-06-07 03:43:05 --> Helper loaded: url_helper
INFO - 2023-06-07 03:43:05 --> Helper loaded: file_helper
INFO - 2023-06-07 03:43:05 --> Helper loaded: form_helper
INFO - 2023-06-07 03:43:05 --> Helper loaded: my_helper
INFO - 2023-06-07 03:43:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:43:05 --> Controller Class Initialized
DEBUG - 2023-06-07 03:43:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 03:43:06 --> Final output sent to browser
DEBUG - 2023-06-07 03:43:06 --> Total execution time: 0.9148
INFO - 2023-06-07 03:44:34 --> Config Class Initialized
INFO - 2023-06-07 03:44:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:44:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:44:34 --> Utf8 Class Initialized
INFO - 2023-06-07 03:44:34 --> URI Class Initialized
INFO - 2023-06-07 03:44:34 --> Router Class Initialized
INFO - 2023-06-07 03:44:34 --> Output Class Initialized
INFO - 2023-06-07 03:44:34 --> Security Class Initialized
DEBUG - 2023-06-07 03:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:44:34 --> Input Class Initialized
INFO - 2023-06-07 03:44:34 --> Language Class Initialized
INFO - 2023-06-07 03:44:34 --> Language Class Initialized
INFO - 2023-06-07 03:44:34 --> Config Class Initialized
INFO - 2023-06-07 03:44:34 --> Loader Class Initialized
INFO - 2023-06-07 03:44:34 --> Helper loaded: url_helper
INFO - 2023-06-07 03:44:34 --> Helper loaded: file_helper
INFO - 2023-06-07 03:44:34 --> Helper loaded: form_helper
INFO - 2023-06-07 03:44:34 --> Helper loaded: my_helper
INFO - 2023-06-07 03:44:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:44:34 --> Controller Class Initialized
DEBUG - 2023-06-07 03:44:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 03:44:35 --> Final output sent to browser
DEBUG - 2023-06-07 03:44:35 --> Total execution time: 0.9948
INFO - 2023-06-07 03:44:39 --> Config Class Initialized
INFO - 2023-06-07 03:44:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:44:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:44:39 --> Utf8 Class Initialized
INFO - 2023-06-07 03:44:39 --> URI Class Initialized
INFO - 2023-06-07 03:44:39 --> Router Class Initialized
INFO - 2023-06-07 03:44:39 --> Output Class Initialized
INFO - 2023-06-07 03:44:39 --> Security Class Initialized
DEBUG - 2023-06-07 03:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:44:39 --> Input Class Initialized
INFO - 2023-06-07 03:44:39 --> Language Class Initialized
INFO - 2023-06-07 03:44:39 --> Language Class Initialized
INFO - 2023-06-07 03:44:39 --> Config Class Initialized
INFO - 2023-06-07 03:44:39 --> Loader Class Initialized
INFO - 2023-06-07 03:44:39 --> Helper loaded: url_helper
INFO - 2023-06-07 03:44:39 --> Helper loaded: file_helper
INFO - 2023-06-07 03:44:39 --> Helper loaded: form_helper
INFO - 2023-06-07 03:44:39 --> Helper loaded: my_helper
INFO - 2023-06-07 03:44:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:44:39 --> Controller Class Initialized
DEBUG - 2023-06-07 03:44:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-06-07 03:44:40 --> Final output sent to browser
DEBUG - 2023-06-07 03:44:40 --> Total execution time: 0.5223
INFO - 2023-06-07 03:45:08 --> Config Class Initialized
INFO - 2023-06-07 03:45:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:45:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:45:08 --> Utf8 Class Initialized
INFO - 2023-06-07 03:45:08 --> URI Class Initialized
INFO - 2023-06-07 03:45:08 --> Router Class Initialized
INFO - 2023-06-07 03:45:08 --> Output Class Initialized
INFO - 2023-06-07 03:45:08 --> Security Class Initialized
DEBUG - 2023-06-07 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:45:08 --> Input Class Initialized
INFO - 2023-06-07 03:45:08 --> Language Class Initialized
INFO - 2023-06-07 03:45:08 --> Language Class Initialized
INFO - 2023-06-07 03:45:08 --> Config Class Initialized
INFO - 2023-06-07 03:45:08 --> Loader Class Initialized
INFO - 2023-06-07 03:45:08 --> Helper loaded: url_helper
INFO - 2023-06-07 03:45:08 --> Helper loaded: file_helper
INFO - 2023-06-07 03:45:08 --> Helper loaded: form_helper
INFO - 2023-06-07 03:45:08 --> Helper loaded: my_helper
INFO - 2023-06-07 03:45:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:45:08 --> Controller Class Initialized
DEBUG - 2023-06-07 03:45:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 03:45:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:45:08 --> Final output sent to browser
DEBUG - 2023-06-07 03:45:08 --> Total execution time: 0.0851
INFO - 2023-06-07 03:45:52 --> Config Class Initialized
INFO - 2023-06-07 03:45:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:45:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:45:52 --> Utf8 Class Initialized
INFO - 2023-06-07 03:45:52 --> URI Class Initialized
INFO - 2023-06-07 03:45:52 --> Router Class Initialized
INFO - 2023-06-07 03:45:52 --> Output Class Initialized
INFO - 2023-06-07 03:45:52 --> Security Class Initialized
DEBUG - 2023-06-07 03:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:45:52 --> Input Class Initialized
INFO - 2023-06-07 03:45:52 --> Language Class Initialized
INFO - 2023-06-07 03:45:52 --> Language Class Initialized
INFO - 2023-06-07 03:45:52 --> Config Class Initialized
INFO - 2023-06-07 03:45:52 --> Loader Class Initialized
INFO - 2023-06-07 03:45:52 --> Helper loaded: url_helper
INFO - 2023-06-07 03:45:52 --> Helper loaded: file_helper
INFO - 2023-06-07 03:45:52 --> Helper loaded: form_helper
INFO - 2023-06-07 03:45:52 --> Helper loaded: my_helper
INFO - 2023-06-07 03:45:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:45:52 --> Controller Class Initialized
DEBUG - 2023-06-07 03:45:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-06-07 03:45:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:45:52 --> Final output sent to browser
DEBUG - 2023-06-07 03:45:52 --> Total execution time: 0.0595
INFO - 2023-06-07 03:46:29 --> Config Class Initialized
INFO - 2023-06-07 03:46:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:46:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:46:29 --> Utf8 Class Initialized
INFO - 2023-06-07 03:46:29 --> URI Class Initialized
INFO - 2023-06-07 03:46:29 --> Router Class Initialized
INFO - 2023-06-07 03:46:29 --> Output Class Initialized
INFO - 2023-06-07 03:46:29 --> Security Class Initialized
DEBUG - 2023-06-07 03:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:46:29 --> Input Class Initialized
INFO - 2023-06-07 03:46:29 --> Language Class Initialized
INFO - 2023-06-07 03:46:29 --> Language Class Initialized
INFO - 2023-06-07 03:46:29 --> Config Class Initialized
INFO - 2023-06-07 03:46:29 --> Loader Class Initialized
INFO - 2023-06-07 03:46:29 --> Helper loaded: url_helper
INFO - 2023-06-07 03:46:29 --> Helper loaded: file_helper
INFO - 2023-06-07 03:46:29 --> Helper loaded: form_helper
INFO - 2023-06-07 03:46:29 --> Helper loaded: my_helper
INFO - 2023-06-07 03:46:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:46:29 --> Controller Class Initialized
DEBUG - 2023-06-07 03:46:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-07 03:46:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:46:29 --> Final output sent to browser
DEBUG - 2023-06-07 03:46:29 --> Total execution time: 0.0647
INFO - 2023-06-07 03:46:45 --> Config Class Initialized
INFO - 2023-06-07 03:46:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:46:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:46:45 --> Utf8 Class Initialized
INFO - 2023-06-07 03:46:45 --> URI Class Initialized
INFO - 2023-06-07 03:46:45 --> Router Class Initialized
INFO - 2023-06-07 03:46:45 --> Output Class Initialized
INFO - 2023-06-07 03:46:45 --> Security Class Initialized
DEBUG - 2023-06-07 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:46:45 --> Input Class Initialized
INFO - 2023-06-07 03:46:45 --> Language Class Initialized
INFO - 2023-06-07 03:46:45 --> Language Class Initialized
INFO - 2023-06-07 03:46:45 --> Config Class Initialized
INFO - 2023-06-07 03:46:45 --> Loader Class Initialized
INFO - 2023-06-07 03:46:45 --> Helper loaded: url_helper
INFO - 2023-06-07 03:46:45 --> Helper loaded: file_helper
INFO - 2023-06-07 03:46:45 --> Helper loaded: form_helper
INFO - 2023-06-07 03:46:45 --> Helper loaded: my_helper
INFO - 2023-06-07 03:46:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:46:45 --> Controller Class Initialized
DEBUG - 2023-06-07 03:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-07 03:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:46:45 --> Final output sent to browser
DEBUG - 2023-06-07 03:46:45 --> Total execution time: 0.0289
INFO - 2023-06-07 03:47:15 --> Config Class Initialized
INFO - 2023-06-07 03:47:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:47:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:47:15 --> Utf8 Class Initialized
INFO - 2023-06-07 03:47:15 --> URI Class Initialized
INFO - 2023-06-07 03:47:15 --> Router Class Initialized
INFO - 2023-06-07 03:47:15 --> Output Class Initialized
INFO - 2023-06-07 03:47:15 --> Security Class Initialized
DEBUG - 2023-06-07 03:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:47:15 --> Input Class Initialized
INFO - 2023-06-07 03:47:15 --> Language Class Initialized
INFO - 2023-06-07 03:47:15 --> Language Class Initialized
INFO - 2023-06-07 03:47:15 --> Config Class Initialized
INFO - 2023-06-07 03:47:15 --> Loader Class Initialized
INFO - 2023-06-07 03:47:15 --> Helper loaded: url_helper
INFO - 2023-06-07 03:47:15 --> Helper loaded: file_helper
INFO - 2023-06-07 03:47:15 --> Helper loaded: form_helper
INFO - 2023-06-07 03:47:15 --> Helper loaded: my_helper
INFO - 2023-06-07 03:47:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:47:15 --> Controller Class Initialized
DEBUG - 2023-06-07 03:47:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-06-07 03:47:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:47:15 --> Final output sent to browser
DEBUG - 2023-06-07 03:47:15 --> Total execution time: 0.0368
INFO - 2023-06-07 03:47:34 --> Config Class Initialized
INFO - 2023-06-07 03:47:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:47:34 --> Utf8 Class Initialized
INFO - 2023-06-07 03:47:34 --> URI Class Initialized
INFO - 2023-06-07 03:47:34 --> Router Class Initialized
INFO - 2023-06-07 03:47:34 --> Output Class Initialized
INFO - 2023-06-07 03:47:34 --> Security Class Initialized
DEBUG - 2023-06-07 03:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:47:34 --> Input Class Initialized
INFO - 2023-06-07 03:47:34 --> Language Class Initialized
INFO - 2023-06-07 03:47:34 --> Language Class Initialized
INFO - 2023-06-07 03:47:34 --> Config Class Initialized
INFO - 2023-06-07 03:47:34 --> Loader Class Initialized
INFO - 2023-06-07 03:47:34 --> Helper loaded: url_helper
INFO - 2023-06-07 03:47:34 --> Helper loaded: file_helper
INFO - 2023-06-07 03:47:34 --> Helper loaded: form_helper
INFO - 2023-06-07 03:47:34 --> Helper loaded: my_helper
INFO - 2023-06-07 03:47:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:47:34 --> Controller Class Initialized
DEBUG - 2023-06-07 03:47:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 03:47:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:47:34 --> Final output sent to browser
DEBUG - 2023-06-07 03:47:34 --> Total execution time: 0.0497
INFO - 2023-06-07 03:51:28 --> Config Class Initialized
INFO - 2023-06-07 03:51:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:51:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:51:28 --> Utf8 Class Initialized
INFO - 2023-06-07 03:51:28 --> URI Class Initialized
INFO - 2023-06-07 03:51:28 --> Router Class Initialized
INFO - 2023-06-07 03:51:28 --> Output Class Initialized
INFO - 2023-06-07 03:51:28 --> Security Class Initialized
DEBUG - 2023-06-07 03:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:51:28 --> Input Class Initialized
INFO - 2023-06-07 03:51:28 --> Language Class Initialized
INFO - 2023-06-07 03:51:28 --> Language Class Initialized
INFO - 2023-06-07 03:51:28 --> Config Class Initialized
INFO - 2023-06-07 03:51:28 --> Loader Class Initialized
INFO - 2023-06-07 03:51:28 --> Helper loaded: url_helper
INFO - 2023-06-07 03:51:28 --> Helper loaded: file_helper
INFO - 2023-06-07 03:51:28 --> Helper loaded: form_helper
INFO - 2023-06-07 03:51:28 --> Helper loaded: my_helper
INFO - 2023-06-07 03:51:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:51:28 --> Controller Class Initialized
DEBUG - 2023-06-07 03:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 03:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:51:28 --> Final output sent to browser
DEBUG - 2023-06-07 03:51:28 --> Total execution time: 0.0514
INFO - 2023-06-07 03:51:33 --> Config Class Initialized
INFO - 2023-06-07 03:51:33 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:51:33 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:51:33 --> Utf8 Class Initialized
INFO - 2023-06-07 03:51:33 --> URI Class Initialized
INFO - 2023-06-07 03:51:33 --> Router Class Initialized
INFO - 2023-06-07 03:51:33 --> Output Class Initialized
INFO - 2023-06-07 03:51:33 --> Security Class Initialized
DEBUG - 2023-06-07 03:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:51:33 --> Input Class Initialized
INFO - 2023-06-07 03:51:33 --> Language Class Initialized
INFO - 2023-06-07 03:51:33 --> Language Class Initialized
INFO - 2023-06-07 03:51:33 --> Config Class Initialized
INFO - 2023-06-07 03:51:33 --> Loader Class Initialized
INFO - 2023-06-07 03:51:33 --> Helper loaded: url_helper
INFO - 2023-06-07 03:51:33 --> Helper loaded: file_helper
INFO - 2023-06-07 03:51:33 --> Helper loaded: form_helper
INFO - 2023-06-07 03:51:33 --> Helper loaded: my_helper
INFO - 2023-06-07 03:51:33 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:51:33 --> Controller Class Initialized
INFO - 2023-06-07 03:52:13 --> Config Class Initialized
INFO - 2023-06-07 03:52:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:52:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:52:13 --> Utf8 Class Initialized
INFO - 2023-06-07 03:52:13 --> URI Class Initialized
INFO - 2023-06-07 03:52:13 --> Router Class Initialized
INFO - 2023-06-07 03:52:13 --> Output Class Initialized
INFO - 2023-06-07 03:52:13 --> Security Class Initialized
DEBUG - 2023-06-07 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:52:13 --> Input Class Initialized
INFO - 2023-06-07 03:52:13 --> Language Class Initialized
INFO - 2023-06-07 03:52:13 --> Language Class Initialized
INFO - 2023-06-07 03:52:13 --> Config Class Initialized
INFO - 2023-06-07 03:52:13 --> Loader Class Initialized
INFO - 2023-06-07 03:52:13 --> Helper loaded: url_helper
INFO - 2023-06-07 03:52:13 --> Helper loaded: file_helper
INFO - 2023-06-07 03:52:13 --> Helper loaded: form_helper
INFO - 2023-06-07 03:52:13 --> Helper loaded: my_helper
INFO - 2023-06-07 03:52:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:52:13 --> Controller Class Initialized
DEBUG - 2023-06-07 03:52:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 03:52:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:52:13 --> Final output sent to browser
DEBUG - 2023-06-07 03:52:13 --> Total execution time: 0.0685
INFO - 2023-06-07 03:52:15 --> Config Class Initialized
INFO - 2023-06-07 03:52:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:52:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:52:15 --> Utf8 Class Initialized
INFO - 2023-06-07 03:52:15 --> URI Class Initialized
INFO - 2023-06-07 03:52:15 --> Router Class Initialized
INFO - 2023-06-07 03:52:15 --> Output Class Initialized
INFO - 2023-06-07 03:52:15 --> Security Class Initialized
DEBUG - 2023-06-07 03:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:52:15 --> Input Class Initialized
INFO - 2023-06-07 03:52:15 --> Language Class Initialized
INFO - 2023-06-07 03:52:15 --> Language Class Initialized
INFO - 2023-06-07 03:52:15 --> Config Class Initialized
INFO - 2023-06-07 03:52:15 --> Loader Class Initialized
INFO - 2023-06-07 03:52:15 --> Helper loaded: url_helper
INFO - 2023-06-07 03:52:15 --> Helper loaded: file_helper
INFO - 2023-06-07 03:52:15 --> Helper loaded: form_helper
INFO - 2023-06-07 03:52:15 --> Helper loaded: my_helper
INFO - 2023-06-07 03:52:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:52:15 --> Controller Class Initialized
DEBUG - 2023-06-07 03:52:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/form.php
DEBUG - 2023-06-07 03:52:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:52:15 --> Final output sent to browser
DEBUG - 2023-06-07 03:52:15 --> Total execution time: 0.0395
INFO - 2023-06-07 03:52:18 --> Config Class Initialized
INFO - 2023-06-07 03:52:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:52:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:52:18 --> Utf8 Class Initialized
INFO - 2023-06-07 03:52:18 --> URI Class Initialized
INFO - 2023-06-07 03:52:18 --> Router Class Initialized
INFO - 2023-06-07 03:52:18 --> Output Class Initialized
INFO - 2023-06-07 03:52:18 --> Security Class Initialized
DEBUG - 2023-06-07 03:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:52:18 --> Input Class Initialized
INFO - 2023-06-07 03:52:18 --> Language Class Initialized
INFO - 2023-06-07 03:52:18 --> Language Class Initialized
INFO - 2023-06-07 03:52:18 --> Config Class Initialized
INFO - 2023-06-07 03:52:18 --> Loader Class Initialized
INFO - 2023-06-07 03:52:18 --> Helper loaded: url_helper
INFO - 2023-06-07 03:52:18 --> Helper loaded: file_helper
INFO - 2023-06-07 03:52:18 --> Helper loaded: form_helper
INFO - 2023-06-07 03:52:18 --> Helper loaded: my_helper
INFO - 2023-06-07 03:52:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:52:18 --> Controller Class Initialized
DEBUG - 2023-06-07 03:52:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 03:52:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:52:18 --> Final output sent to browser
DEBUG - 2023-06-07 03:52:18 --> Total execution time: 0.0430
INFO - 2023-06-07 03:52:19 --> Config Class Initialized
INFO - 2023-06-07 03:52:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:52:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:52:19 --> Utf8 Class Initialized
INFO - 2023-06-07 03:52:19 --> URI Class Initialized
INFO - 2023-06-07 03:52:19 --> Router Class Initialized
INFO - 2023-06-07 03:52:19 --> Output Class Initialized
INFO - 2023-06-07 03:52:19 --> Security Class Initialized
DEBUG - 2023-06-07 03:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:52:19 --> Input Class Initialized
INFO - 2023-06-07 03:52:19 --> Language Class Initialized
INFO - 2023-06-07 03:52:19 --> Language Class Initialized
INFO - 2023-06-07 03:52:19 --> Config Class Initialized
INFO - 2023-06-07 03:52:19 --> Loader Class Initialized
INFO - 2023-06-07 03:52:19 --> Helper loaded: url_helper
INFO - 2023-06-07 03:52:19 --> Helper loaded: file_helper
INFO - 2023-06-07 03:52:19 --> Helper loaded: form_helper
INFO - 2023-06-07 03:52:19 --> Helper loaded: my_helper
INFO - 2023-06-07 03:52:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:52:19 --> Controller Class Initialized
INFO - 2023-06-07 03:52:21 --> Config Class Initialized
INFO - 2023-06-07 03:52:21 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:52:21 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:52:21 --> Utf8 Class Initialized
INFO - 2023-06-07 03:52:21 --> URI Class Initialized
INFO - 2023-06-07 03:52:21 --> Router Class Initialized
INFO - 2023-06-07 03:52:21 --> Output Class Initialized
INFO - 2023-06-07 03:52:21 --> Security Class Initialized
DEBUG - 2023-06-07 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:52:21 --> Input Class Initialized
INFO - 2023-06-07 03:52:21 --> Language Class Initialized
INFO - 2023-06-07 03:52:21 --> Language Class Initialized
INFO - 2023-06-07 03:52:21 --> Config Class Initialized
INFO - 2023-06-07 03:52:21 --> Loader Class Initialized
INFO - 2023-06-07 03:52:21 --> Helper loaded: url_helper
INFO - 2023-06-07 03:52:21 --> Helper loaded: file_helper
INFO - 2023-06-07 03:52:21 --> Helper loaded: form_helper
INFO - 2023-06-07 03:52:21 --> Helper loaded: my_helper
INFO - 2023-06-07 03:52:21 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:52:21 --> Controller Class Initialized
DEBUG - 2023-06-07 03:52:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 03:52:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:52:21 --> Final output sent to browser
DEBUG - 2023-06-07 03:52:21 --> Total execution time: 0.0417
INFO - 2023-06-07 03:55:19 --> Config Class Initialized
INFO - 2023-06-07 03:55:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:55:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:55:19 --> Utf8 Class Initialized
INFO - 2023-06-07 03:55:19 --> URI Class Initialized
INFO - 2023-06-07 03:55:19 --> Router Class Initialized
INFO - 2023-06-07 03:55:19 --> Output Class Initialized
INFO - 2023-06-07 03:55:19 --> Security Class Initialized
DEBUG - 2023-06-07 03:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:55:19 --> Input Class Initialized
INFO - 2023-06-07 03:55:19 --> Language Class Initialized
INFO - 2023-06-07 03:55:19 --> Language Class Initialized
INFO - 2023-06-07 03:55:19 --> Config Class Initialized
INFO - 2023-06-07 03:55:19 --> Loader Class Initialized
INFO - 2023-06-07 03:55:19 --> Helper loaded: url_helper
INFO - 2023-06-07 03:55:19 --> Helper loaded: file_helper
INFO - 2023-06-07 03:55:19 --> Helper loaded: form_helper
INFO - 2023-06-07 03:55:19 --> Helper loaded: my_helper
INFO - 2023-06-07 03:55:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:55:19 --> Controller Class Initialized
INFO - 2023-06-07 03:55:19 --> Final output sent to browser
DEBUG - 2023-06-07 03:55:19 --> Total execution time: 0.0327
INFO - 2023-06-07 03:55:20 --> Config Class Initialized
INFO - 2023-06-07 03:55:20 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:55:20 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:55:20 --> Utf8 Class Initialized
INFO - 2023-06-07 03:55:20 --> URI Class Initialized
INFO - 2023-06-07 03:55:20 --> Router Class Initialized
INFO - 2023-06-07 03:55:20 --> Output Class Initialized
INFO - 2023-06-07 03:55:20 --> Security Class Initialized
DEBUG - 2023-06-07 03:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:55:20 --> Input Class Initialized
INFO - 2023-06-07 03:55:20 --> Language Class Initialized
INFO - 2023-06-07 03:55:20 --> Language Class Initialized
INFO - 2023-06-07 03:55:20 --> Config Class Initialized
INFO - 2023-06-07 03:55:20 --> Loader Class Initialized
INFO - 2023-06-07 03:55:20 --> Helper loaded: url_helper
INFO - 2023-06-07 03:55:20 --> Helper loaded: file_helper
INFO - 2023-06-07 03:55:20 --> Helper loaded: form_helper
INFO - 2023-06-07 03:55:21 --> Helper loaded: my_helper
INFO - 2023-06-07 03:55:21 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:55:21 --> Controller Class Initialized
INFO - 2023-06-07 03:55:37 --> Config Class Initialized
INFO - 2023-06-07 03:55:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:55:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:55:37 --> Utf8 Class Initialized
INFO - 2023-06-07 03:55:37 --> URI Class Initialized
INFO - 2023-06-07 03:55:37 --> Router Class Initialized
INFO - 2023-06-07 03:55:37 --> Output Class Initialized
INFO - 2023-06-07 03:55:37 --> Security Class Initialized
DEBUG - 2023-06-07 03:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:55:37 --> Input Class Initialized
INFO - 2023-06-07 03:55:37 --> Language Class Initialized
INFO - 2023-06-07 03:55:37 --> Language Class Initialized
INFO - 2023-06-07 03:55:37 --> Config Class Initialized
INFO - 2023-06-07 03:55:37 --> Loader Class Initialized
INFO - 2023-06-07 03:55:37 --> Helper loaded: url_helper
INFO - 2023-06-07 03:55:37 --> Helper loaded: file_helper
INFO - 2023-06-07 03:55:37 --> Helper loaded: form_helper
INFO - 2023-06-07 03:55:37 --> Helper loaded: my_helper
INFO - 2023-06-07 03:55:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:55:37 --> Controller Class Initialized
INFO - 2023-06-07 03:55:37 --> Final output sent to browser
DEBUG - 2023-06-07 03:55:37 --> Total execution time: 0.0265
INFO - 2023-06-07 03:55:39 --> Config Class Initialized
INFO - 2023-06-07 03:55:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:55:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:55:39 --> Utf8 Class Initialized
INFO - 2023-06-07 03:55:39 --> URI Class Initialized
INFO - 2023-06-07 03:55:39 --> Router Class Initialized
INFO - 2023-06-07 03:55:39 --> Output Class Initialized
INFO - 2023-06-07 03:55:39 --> Security Class Initialized
DEBUG - 2023-06-07 03:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:55:39 --> Input Class Initialized
INFO - 2023-06-07 03:55:39 --> Language Class Initialized
INFO - 2023-06-07 03:55:39 --> Language Class Initialized
INFO - 2023-06-07 03:55:39 --> Config Class Initialized
INFO - 2023-06-07 03:55:39 --> Loader Class Initialized
INFO - 2023-06-07 03:55:39 --> Helper loaded: url_helper
INFO - 2023-06-07 03:55:39 --> Helper loaded: file_helper
INFO - 2023-06-07 03:55:39 --> Helper loaded: form_helper
INFO - 2023-06-07 03:55:39 --> Helper loaded: my_helper
INFO - 2023-06-07 03:55:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:55:39 --> Controller Class Initialized
INFO - 2023-06-07 03:56:08 --> Config Class Initialized
INFO - 2023-06-07 03:56:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:56:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:56:08 --> Utf8 Class Initialized
INFO - 2023-06-07 03:56:08 --> URI Class Initialized
INFO - 2023-06-07 03:56:08 --> Router Class Initialized
INFO - 2023-06-07 03:56:08 --> Output Class Initialized
INFO - 2023-06-07 03:56:08 --> Security Class Initialized
DEBUG - 2023-06-07 03:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:56:08 --> Input Class Initialized
INFO - 2023-06-07 03:56:08 --> Language Class Initialized
INFO - 2023-06-07 03:56:08 --> Language Class Initialized
INFO - 2023-06-07 03:56:08 --> Config Class Initialized
INFO - 2023-06-07 03:56:08 --> Loader Class Initialized
INFO - 2023-06-07 03:56:08 --> Helper loaded: url_helper
INFO - 2023-06-07 03:56:08 --> Helper loaded: file_helper
INFO - 2023-06-07 03:56:08 --> Helper loaded: form_helper
INFO - 2023-06-07 03:56:08 --> Helper loaded: my_helper
INFO - 2023-06-07 03:56:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:56:08 --> Controller Class Initialized
DEBUG - 2023-06-07 03:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-07 03:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:56:08 --> Final output sent to browser
DEBUG - 2023-06-07 03:56:08 --> Total execution time: 0.0312
INFO - 2023-06-07 03:56:19 --> Config Class Initialized
INFO - 2023-06-07 03:56:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 03:56:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 03:56:19 --> Utf8 Class Initialized
INFO - 2023-06-07 03:56:19 --> URI Class Initialized
INFO - 2023-06-07 03:56:19 --> Router Class Initialized
INFO - 2023-06-07 03:56:19 --> Output Class Initialized
INFO - 2023-06-07 03:56:19 --> Security Class Initialized
DEBUG - 2023-06-07 03:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 03:56:19 --> Input Class Initialized
INFO - 2023-06-07 03:56:19 --> Language Class Initialized
INFO - 2023-06-07 03:56:19 --> Language Class Initialized
INFO - 2023-06-07 03:56:19 --> Config Class Initialized
INFO - 2023-06-07 03:56:19 --> Loader Class Initialized
INFO - 2023-06-07 03:56:19 --> Helper loaded: url_helper
INFO - 2023-06-07 03:56:19 --> Helper loaded: file_helper
INFO - 2023-06-07 03:56:19 --> Helper loaded: form_helper
INFO - 2023-06-07 03:56:19 --> Helper loaded: my_helper
INFO - 2023-06-07 03:56:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 03:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 03:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 03:56:19 --> Controller Class Initialized
DEBUG - 2023-06-07 03:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-07 03:56:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 03:56:19 --> Final output sent to browser
DEBUG - 2023-06-07 03:56:19 --> Total execution time: 0.0444
INFO - 2023-06-07 04:01:55 --> Config Class Initialized
INFO - 2023-06-07 04:01:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:01:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:01:55 --> Utf8 Class Initialized
INFO - 2023-06-07 04:01:55 --> URI Class Initialized
INFO - 2023-06-07 04:01:55 --> Router Class Initialized
INFO - 2023-06-07 04:01:55 --> Output Class Initialized
INFO - 2023-06-07 04:01:55 --> Security Class Initialized
DEBUG - 2023-06-07 04:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:01:55 --> Input Class Initialized
INFO - 2023-06-07 04:01:55 --> Language Class Initialized
INFO - 2023-06-07 04:01:55 --> Language Class Initialized
INFO - 2023-06-07 04:01:55 --> Config Class Initialized
INFO - 2023-06-07 04:01:55 --> Loader Class Initialized
INFO - 2023-06-07 04:01:55 --> Helper loaded: url_helper
INFO - 2023-06-07 04:01:55 --> Helper loaded: file_helper
INFO - 2023-06-07 04:01:55 --> Helper loaded: form_helper
INFO - 2023-06-07 04:01:55 --> Helper loaded: my_helper
INFO - 2023-06-07 04:01:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:01:55 --> Controller Class Initialized
DEBUG - 2023-06-07 04:01:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-06-07 04:01:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:01:55 --> Final output sent to browser
DEBUG - 2023-06-07 04:01:55 --> Total execution time: 0.0547
INFO - 2023-06-07 04:01:58 --> Config Class Initialized
INFO - 2023-06-07 04:01:58 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:01:58 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:01:58 --> Utf8 Class Initialized
INFO - 2023-06-07 04:01:58 --> URI Class Initialized
INFO - 2023-06-07 04:01:58 --> Router Class Initialized
INFO - 2023-06-07 04:01:58 --> Output Class Initialized
INFO - 2023-06-07 04:01:58 --> Security Class Initialized
DEBUG - 2023-06-07 04:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:01:58 --> Input Class Initialized
INFO - 2023-06-07 04:01:58 --> Language Class Initialized
INFO - 2023-06-07 04:01:58 --> Language Class Initialized
INFO - 2023-06-07 04:01:58 --> Config Class Initialized
INFO - 2023-06-07 04:01:58 --> Loader Class Initialized
INFO - 2023-06-07 04:01:58 --> Helper loaded: url_helper
INFO - 2023-06-07 04:01:58 --> Helper loaded: file_helper
INFO - 2023-06-07 04:01:58 --> Helper loaded: form_helper
INFO - 2023-06-07 04:01:58 --> Helper loaded: my_helper
INFO - 2023-06-07 04:01:58 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:01:58 --> Controller Class Initialized
DEBUG - 2023-06-07 04:01:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-06-07 04:01:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:01:58 --> Final output sent to browser
DEBUG - 2023-06-07 04:01:58 --> Total execution time: 0.0537
INFO - 2023-06-07 04:02:29 --> Config Class Initialized
INFO - 2023-06-07 04:02:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:02:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:02:29 --> Utf8 Class Initialized
INFO - 2023-06-07 04:02:29 --> URI Class Initialized
INFO - 2023-06-07 04:02:29 --> Router Class Initialized
INFO - 2023-06-07 04:02:29 --> Output Class Initialized
INFO - 2023-06-07 04:02:29 --> Security Class Initialized
DEBUG - 2023-06-07 04:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:02:29 --> Input Class Initialized
INFO - 2023-06-07 04:02:29 --> Language Class Initialized
INFO - 2023-06-07 04:02:29 --> Language Class Initialized
INFO - 2023-06-07 04:02:29 --> Config Class Initialized
INFO - 2023-06-07 04:02:29 --> Loader Class Initialized
INFO - 2023-06-07 04:02:29 --> Helper loaded: url_helper
INFO - 2023-06-07 04:02:29 --> Helper loaded: file_helper
INFO - 2023-06-07 04:02:29 --> Helper loaded: form_helper
INFO - 2023-06-07 04:02:29 --> Helper loaded: my_helper
INFO - 2023-06-07 04:02:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:02:29 --> Controller Class Initialized
DEBUG - 2023-06-07 04:02:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-06-07 04:02:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:02:29 --> Final output sent to browser
DEBUG - 2023-06-07 04:02:29 --> Total execution time: 0.0493
INFO - 2023-06-07 04:02:35 --> Config Class Initialized
INFO - 2023-06-07 04:02:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:02:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:02:35 --> Utf8 Class Initialized
INFO - 2023-06-07 04:02:35 --> URI Class Initialized
INFO - 2023-06-07 04:02:35 --> Router Class Initialized
INFO - 2023-06-07 04:02:35 --> Output Class Initialized
INFO - 2023-06-07 04:02:35 --> Security Class Initialized
DEBUG - 2023-06-07 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:02:35 --> Input Class Initialized
INFO - 2023-06-07 04:02:35 --> Language Class Initialized
INFO - 2023-06-07 04:02:35 --> Language Class Initialized
INFO - 2023-06-07 04:02:35 --> Config Class Initialized
INFO - 2023-06-07 04:02:35 --> Loader Class Initialized
INFO - 2023-06-07 04:02:35 --> Helper loaded: url_helper
INFO - 2023-06-07 04:02:35 --> Helper loaded: file_helper
INFO - 2023-06-07 04:02:35 --> Helper loaded: form_helper
INFO - 2023-06-07 04:02:35 --> Helper loaded: my_helper
INFO - 2023-06-07 04:02:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:02:35 --> Controller Class Initialized
DEBUG - 2023-06-07 04:02:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_sek/views/list.php
DEBUG - 2023-06-07 04:02:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:02:35 --> Final output sent to browser
DEBUG - 2023-06-07 04:02:35 --> Total execution time: 0.0704
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:37 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:37 --> URI Class Initialized
INFO - 2023-06-07 04:06:37 --> Router Class Initialized
INFO - 2023-06-07 04:06:37 --> Output Class Initialized
INFO - 2023-06-07 04:06:37 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:37 --> Input Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Loader Class Initialized
INFO - 2023-06-07 04:06:37 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:37 --> Controller Class Initialized
INFO - 2023-06-07 04:06:37 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:37 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:37 --> URI Class Initialized
INFO - 2023-06-07 04:06:37 --> Router Class Initialized
INFO - 2023-06-07 04:06:37 --> Output Class Initialized
INFO - 2023-06-07 04:06:37 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:37 --> Input Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Loader Class Initialized
INFO - 2023-06-07 04:06:37 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:37 --> Controller Class Initialized
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:37 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:37 --> URI Class Initialized
INFO - 2023-06-07 04:06:37 --> Router Class Initialized
INFO - 2023-06-07 04:06:37 --> Output Class Initialized
INFO - 2023-06-07 04:06:37 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:37 --> Input Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Language Class Initialized
INFO - 2023-06-07 04:06:37 --> Config Class Initialized
INFO - 2023-06-07 04:06:37 --> Loader Class Initialized
INFO - 2023-06-07 04:06:37 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:37 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:37 --> Controller Class Initialized
DEBUG - 2023-06-07 04:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 04:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:06:37 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:37 --> Total execution time: 0.0235
INFO - 2023-06-07 04:06:42 --> Config Class Initialized
INFO - 2023-06-07 04:06:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:42 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:42 --> URI Class Initialized
INFO - 2023-06-07 04:06:42 --> Router Class Initialized
INFO - 2023-06-07 04:06:42 --> Output Class Initialized
INFO - 2023-06-07 04:06:42 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:42 --> Input Class Initialized
INFO - 2023-06-07 04:06:42 --> Language Class Initialized
INFO - 2023-06-07 04:06:42 --> Language Class Initialized
INFO - 2023-06-07 04:06:42 --> Config Class Initialized
INFO - 2023-06-07 04:06:42 --> Loader Class Initialized
INFO - 2023-06-07 04:06:42 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:42 --> Controller Class Initialized
INFO - 2023-06-07 04:06:42 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:06:42 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:42 --> Total execution time: 0.0279
INFO - 2023-06-07 04:06:42 --> Config Class Initialized
INFO - 2023-06-07 04:06:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:42 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:42 --> URI Class Initialized
INFO - 2023-06-07 04:06:42 --> Router Class Initialized
INFO - 2023-06-07 04:06:42 --> Output Class Initialized
INFO - 2023-06-07 04:06:42 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:42 --> Input Class Initialized
INFO - 2023-06-07 04:06:42 --> Language Class Initialized
INFO - 2023-06-07 04:06:42 --> Language Class Initialized
INFO - 2023-06-07 04:06:42 --> Config Class Initialized
INFO - 2023-06-07 04:06:42 --> Loader Class Initialized
INFO - 2023-06-07 04:06:42 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:42 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:42 --> Controller Class Initialized
DEBUG - 2023-06-07 04:06:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-07 04:06:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:06:42 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:42 --> Total execution time: 0.0944
INFO - 2023-06-07 04:06:45 --> Config Class Initialized
INFO - 2023-06-07 04:06:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:45 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:45 --> URI Class Initialized
INFO - 2023-06-07 04:06:45 --> Router Class Initialized
INFO - 2023-06-07 04:06:45 --> Output Class Initialized
INFO - 2023-06-07 04:06:45 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:45 --> Input Class Initialized
INFO - 2023-06-07 04:06:45 --> Language Class Initialized
INFO - 2023-06-07 04:06:45 --> Language Class Initialized
INFO - 2023-06-07 04:06:45 --> Config Class Initialized
INFO - 2023-06-07 04:06:45 --> Loader Class Initialized
INFO - 2023-06-07 04:06:45 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:45 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:45 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:45 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:45 --> Controller Class Initialized
DEBUG - 2023-06-07 04:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-06-07 04:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:06:45 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:45 --> Total execution time: 0.0586
INFO - 2023-06-07 04:06:46 --> Config Class Initialized
INFO - 2023-06-07 04:06:46 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:46 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:46 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:46 --> URI Class Initialized
INFO - 2023-06-07 04:06:46 --> Router Class Initialized
INFO - 2023-06-07 04:06:46 --> Output Class Initialized
INFO - 2023-06-07 04:06:46 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:46 --> Input Class Initialized
INFO - 2023-06-07 04:06:46 --> Language Class Initialized
INFO - 2023-06-07 04:06:46 --> Language Class Initialized
INFO - 2023-06-07 04:06:46 --> Config Class Initialized
INFO - 2023-06-07 04:06:46 --> Loader Class Initialized
INFO - 2023-06-07 04:06:46 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:46 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:46 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:46 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:46 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:46 --> Controller Class Initialized
INFO - 2023-06-07 04:06:49 --> Config Class Initialized
INFO - 2023-06-07 04:06:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:49 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:49 --> URI Class Initialized
INFO - 2023-06-07 04:06:49 --> Router Class Initialized
INFO - 2023-06-07 04:06:49 --> Output Class Initialized
INFO - 2023-06-07 04:06:49 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:49 --> Input Class Initialized
INFO - 2023-06-07 04:06:49 --> Language Class Initialized
INFO - 2023-06-07 04:06:49 --> Language Class Initialized
INFO - 2023-06-07 04:06:49 --> Config Class Initialized
INFO - 2023-06-07 04:06:49 --> Loader Class Initialized
INFO - 2023-06-07 04:06:49 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:49 --> Controller Class Initialized
DEBUG - 2023-06-07 04:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-06-07 04:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:06:49 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:49 --> Total execution time: 0.0478
INFO - 2023-06-07 04:06:49 --> Config Class Initialized
INFO - 2023-06-07 04:06:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:49 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:49 --> URI Class Initialized
INFO - 2023-06-07 04:06:49 --> Router Class Initialized
INFO - 2023-06-07 04:06:49 --> Output Class Initialized
INFO - 2023-06-07 04:06:49 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:49 --> Input Class Initialized
INFO - 2023-06-07 04:06:49 --> Language Class Initialized
INFO - 2023-06-07 04:06:49 --> Language Class Initialized
INFO - 2023-06-07 04:06:49 --> Config Class Initialized
INFO - 2023-06-07 04:06:49 --> Loader Class Initialized
INFO - 2023-06-07 04:06:49 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:49 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:49 --> Controller Class Initialized
INFO - 2023-06-07 04:06:53 --> Config Class Initialized
INFO - 2023-06-07 04:06:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:06:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:06:53 --> Utf8 Class Initialized
INFO - 2023-06-07 04:06:53 --> URI Class Initialized
INFO - 2023-06-07 04:06:53 --> Router Class Initialized
INFO - 2023-06-07 04:06:53 --> Output Class Initialized
INFO - 2023-06-07 04:06:53 --> Security Class Initialized
DEBUG - 2023-06-07 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:06:53 --> Input Class Initialized
INFO - 2023-06-07 04:06:53 --> Language Class Initialized
INFO - 2023-06-07 04:06:53 --> Language Class Initialized
INFO - 2023-06-07 04:06:53 --> Config Class Initialized
INFO - 2023-06-07 04:06:53 --> Loader Class Initialized
INFO - 2023-06-07 04:06:53 --> Helper loaded: url_helper
INFO - 2023-06-07 04:06:53 --> Helper loaded: file_helper
INFO - 2023-06-07 04:06:53 --> Helper loaded: form_helper
INFO - 2023-06-07 04:06:53 --> Helper loaded: my_helper
INFO - 2023-06-07 04:06:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:06:53 --> Controller Class Initialized
INFO - 2023-06-07 04:06:53 --> Final output sent to browser
DEBUG - 2023-06-07 04:06:53 --> Total execution time: 0.0298
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:19 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:19 --> URI Class Initialized
INFO - 2023-06-07 04:07:19 --> Router Class Initialized
INFO - 2023-06-07 04:07:19 --> Output Class Initialized
INFO - 2023-06-07 04:07:19 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:19 --> Input Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Loader Class Initialized
INFO - 2023-06-07 04:07:19 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:19 --> Controller Class Initialized
INFO - 2023-06-07 04:07:19 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:19 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:19 --> URI Class Initialized
INFO - 2023-06-07 04:07:19 --> Router Class Initialized
INFO - 2023-06-07 04:07:19 --> Output Class Initialized
INFO - 2023-06-07 04:07:19 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:19 --> Input Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Loader Class Initialized
INFO - 2023-06-07 04:07:19 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:19 --> Controller Class Initialized
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:19 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:19 --> URI Class Initialized
INFO - 2023-06-07 04:07:19 --> Router Class Initialized
INFO - 2023-06-07 04:07:19 --> Output Class Initialized
INFO - 2023-06-07 04:07:19 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:19 --> Input Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Language Class Initialized
INFO - 2023-06-07 04:07:19 --> Config Class Initialized
INFO - 2023-06-07 04:07:19 --> Loader Class Initialized
INFO - 2023-06-07 04:07:19 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:19 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:19 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 04:07:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:19 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:19 --> Total execution time: 0.0239
INFO - 2023-06-07 04:07:24 --> Config Class Initialized
INFO - 2023-06-07 04:07:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:24 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:24 --> URI Class Initialized
INFO - 2023-06-07 04:07:24 --> Router Class Initialized
INFO - 2023-06-07 04:07:24 --> Output Class Initialized
INFO - 2023-06-07 04:07:24 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:24 --> Input Class Initialized
INFO - 2023-06-07 04:07:24 --> Language Class Initialized
INFO - 2023-06-07 04:07:24 --> Language Class Initialized
INFO - 2023-06-07 04:07:24 --> Config Class Initialized
INFO - 2023-06-07 04:07:24 --> Loader Class Initialized
INFO - 2023-06-07 04:07:24 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:24 --> Controller Class Initialized
INFO - 2023-06-07 04:07:24 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:07:24 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:24 --> Total execution time: 0.0282
INFO - 2023-06-07 04:07:24 --> Config Class Initialized
INFO - 2023-06-07 04:07:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:24 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:24 --> URI Class Initialized
INFO - 2023-06-07 04:07:24 --> Router Class Initialized
INFO - 2023-06-07 04:07:24 --> Output Class Initialized
INFO - 2023-06-07 04:07:24 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:24 --> Input Class Initialized
INFO - 2023-06-07 04:07:24 --> Language Class Initialized
INFO - 2023-06-07 04:07:24 --> Language Class Initialized
INFO - 2023-06-07 04:07:24 --> Config Class Initialized
INFO - 2023-06-07 04:07:24 --> Loader Class Initialized
INFO - 2023-06-07 04:07:24 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:24 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:24 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-07 04:07:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:24 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:24 --> Total execution time: 0.0463
INFO - 2023-06-07 04:07:26 --> Config Class Initialized
INFO - 2023-06-07 04:07:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:26 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:26 --> URI Class Initialized
INFO - 2023-06-07 04:07:26 --> Router Class Initialized
INFO - 2023-06-07 04:07:26 --> Output Class Initialized
INFO - 2023-06-07 04:07:26 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:26 --> Input Class Initialized
INFO - 2023-06-07 04:07:26 --> Language Class Initialized
INFO - 2023-06-07 04:07:26 --> Language Class Initialized
INFO - 2023-06-07 04:07:26 --> Config Class Initialized
INFO - 2023-06-07 04:07:26 --> Loader Class Initialized
INFO - 2023-06-07 04:07:26 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:26 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:26 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:26 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:26 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-06-07 04:07:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:26 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:26 --> Total execution time: 0.0876
INFO - 2023-06-07 04:07:33 --> Config Class Initialized
INFO - 2023-06-07 04:07:33 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:33 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:33 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:33 --> URI Class Initialized
INFO - 2023-06-07 04:07:33 --> Router Class Initialized
INFO - 2023-06-07 04:07:33 --> Output Class Initialized
INFO - 2023-06-07 04:07:33 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:33 --> Input Class Initialized
INFO - 2023-06-07 04:07:33 --> Language Class Initialized
INFO - 2023-06-07 04:07:33 --> Language Class Initialized
INFO - 2023-06-07 04:07:33 --> Config Class Initialized
INFO - 2023-06-07 04:07:33 --> Loader Class Initialized
INFO - 2023-06-07 04:07:33 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:33 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:33 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:33 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:33 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:33 --> Controller Class Initialized
INFO - 2023-06-07 04:07:33 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:07:34 --> Config Class Initialized
INFO - 2023-06-07 04:07:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:34 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:34 --> URI Class Initialized
INFO - 2023-06-07 04:07:34 --> Router Class Initialized
INFO - 2023-06-07 04:07:34 --> Output Class Initialized
INFO - 2023-06-07 04:07:34 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:34 --> Input Class Initialized
INFO - 2023-06-07 04:07:34 --> Language Class Initialized
INFO - 2023-06-07 04:07:34 --> Language Class Initialized
INFO - 2023-06-07 04:07:34 --> Config Class Initialized
INFO - 2023-06-07 04:07:34 --> Loader Class Initialized
INFO - 2023-06-07 04:07:34 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:34 --> Controller Class Initialized
INFO - 2023-06-07 04:07:34 --> Config Class Initialized
INFO - 2023-06-07 04:07:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:34 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:34 --> URI Class Initialized
INFO - 2023-06-07 04:07:34 --> Router Class Initialized
INFO - 2023-06-07 04:07:34 --> Output Class Initialized
INFO - 2023-06-07 04:07:34 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:34 --> Input Class Initialized
INFO - 2023-06-07 04:07:34 --> Language Class Initialized
INFO - 2023-06-07 04:07:34 --> Language Class Initialized
INFO - 2023-06-07 04:07:34 --> Config Class Initialized
INFO - 2023-06-07 04:07:34 --> Loader Class Initialized
INFO - 2023-06-07 04:07:34 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:34 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:34 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 04:07:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:34 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:34 --> Total execution time: 0.0422
INFO - 2023-06-07 04:07:48 --> Config Class Initialized
INFO - 2023-06-07 04:07:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:48 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:48 --> URI Class Initialized
INFO - 2023-06-07 04:07:48 --> Router Class Initialized
INFO - 2023-06-07 04:07:48 --> Output Class Initialized
INFO - 2023-06-07 04:07:48 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:48 --> Input Class Initialized
INFO - 2023-06-07 04:07:48 --> Language Class Initialized
INFO - 2023-06-07 04:07:48 --> Language Class Initialized
INFO - 2023-06-07 04:07:48 --> Config Class Initialized
INFO - 2023-06-07 04:07:48 --> Loader Class Initialized
INFO - 2023-06-07 04:07:48 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:48 --> Controller Class Initialized
INFO - 2023-06-07 04:07:48 --> Helper loaded: cookie_helper
INFO - 2023-06-07 04:07:48 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:48 --> Total execution time: 0.0476
INFO - 2023-06-07 04:07:48 --> Config Class Initialized
INFO - 2023-06-07 04:07:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:48 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:48 --> URI Class Initialized
INFO - 2023-06-07 04:07:48 --> Router Class Initialized
INFO - 2023-06-07 04:07:48 --> Output Class Initialized
INFO - 2023-06-07 04:07:48 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:48 --> Input Class Initialized
INFO - 2023-06-07 04:07:48 --> Language Class Initialized
INFO - 2023-06-07 04:07:48 --> Language Class Initialized
INFO - 2023-06-07 04:07:48 --> Config Class Initialized
INFO - 2023-06-07 04:07:48 --> Loader Class Initialized
INFO - 2023-06-07 04:07:48 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:48 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:48 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-07 04:07:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:48 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:48 --> Total execution time: 0.0507
INFO - 2023-06-07 04:07:53 --> Config Class Initialized
INFO - 2023-06-07 04:07:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:07:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:07:53 --> Utf8 Class Initialized
INFO - 2023-06-07 04:07:53 --> URI Class Initialized
INFO - 2023-06-07 04:07:53 --> Router Class Initialized
INFO - 2023-06-07 04:07:53 --> Output Class Initialized
INFO - 2023-06-07 04:07:53 --> Security Class Initialized
DEBUG - 2023-06-07 04:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:07:53 --> Input Class Initialized
INFO - 2023-06-07 04:07:53 --> Language Class Initialized
INFO - 2023-06-07 04:07:53 --> Language Class Initialized
INFO - 2023-06-07 04:07:53 --> Config Class Initialized
INFO - 2023-06-07 04:07:53 --> Loader Class Initialized
INFO - 2023-06-07 04:07:53 --> Helper loaded: url_helper
INFO - 2023-06-07 04:07:53 --> Helper loaded: file_helper
INFO - 2023-06-07 04:07:53 --> Helper loaded: form_helper
INFO - 2023-06-07 04:07:53 --> Helper loaded: my_helper
INFO - 2023-06-07 04:07:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:07:53 --> Controller Class Initialized
DEBUG - 2023-06-07 04:07:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 04:07:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:07:53 --> Final output sent to browser
DEBUG - 2023-06-07 04:07:53 --> Total execution time: 0.0301
INFO - 2023-06-07 04:08:00 --> Config Class Initialized
INFO - 2023-06-07 04:08:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:08:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:08:00 --> Utf8 Class Initialized
INFO - 2023-06-07 04:08:00 --> URI Class Initialized
INFO - 2023-06-07 04:08:00 --> Router Class Initialized
INFO - 2023-06-07 04:08:00 --> Output Class Initialized
INFO - 2023-06-07 04:08:00 --> Security Class Initialized
DEBUG - 2023-06-07 04:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:08:00 --> Input Class Initialized
INFO - 2023-06-07 04:08:00 --> Language Class Initialized
INFO - 2023-06-07 04:08:00 --> Language Class Initialized
INFO - 2023-06-07 04:08:00 --> Config Class Initialized
INFO - 2023-06-07 04:08:00 --> Loader Class Initialized
INFO - 2023-06-07 04:08:00 --> Helper loaded: url_helper
INFO - 2023-06-07 04:08:00 --> Helper loaded: file_helper
INFO - 2023-06-07 04:08:00 --> Helper loaded: form_helper
INFO - 2023-06-07 04:08:00 --> Helper loaded: my_helper
INFO - 2023-06-07 04:08:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:08:00 --> Controller Class Initialized
DEBUG - 2023-06-07 04:08:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 04:08:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:08:00 --> Final output sent to browser
DEBUG - 2023-06-07 04:08:00 --> Total execution time: 0.0496
INFO - 2023-06-07 04:08:40 --> Config Class Initialized
INFO - 2023-06-07 04:08:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:08:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:08:40 --> Utf8 Class Initialized
INFO - 2023-06-07 04:08:40 --> URI Class Initialized
INFO - 2023-06-07 04:08:40 --> Router Class Initialized
INFO - 2023-06-07 04:08:40 --> Output Class Initialized
INFO - 2023-06-07 04:08:40 --> Security Class Initialized
DEBUG - 2023-06-07 04:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:08:40 --> Input Class Initialized
INFO - 2023-06-07 04:08:40 --> Language Class Initialized
INFO - 2023-06-07 04:08:40 --> Language Class Initialized
INFO - 2023-06-07 04:08:40 --> Config Class Initialized
INFO - 2023-06-07 04:08:40 --> Loader Class Initialized
INFO - 2023-06-07 04:08:40 --> Helper loaded: url_helper
INFO - 2023-06-07 04:08:40 --> Helper loaded: file_helper
INFO - 2023-06-07 04:08:40 --> Helper loaded: form_helper
INFO - 2023-06-07 04:08:40 --> Helper loaded: my_helper
INFO - 2023-06-07 04:08:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:08:40 --> Controller Class Initialized
DEBUG - 2023-06-07 04:08:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 04:08:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:08:40 --> Final output sent to browser
DEBUG - 2023-06-07 04:08:40 --> Total execution time: 0.0292
INFO - 2023-06-07 04:08:42 --> Config Class Initialized
INFO - 2023-06-07 04:08:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:08:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:08:42 --> Utf8 Class Initialized
INFO - 2023-06-07 04:08:42 --> URI Class Initialized
INFO - 2023-06-07 04:08:42 --> Router Class Initialized
INFO - 2023-06-07 04:08:42 --> Output Class Initialized
INFO - 2023-06-07 04:08:42 --> Security Class Initialized
DEBUG - 2023-06-07 04:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:08:42 --> Input Class Initialized
INFO - 2023-06-07 04:08:42 --> Language Class Initialized
INFO - 2023-06-07 04:08:42 --> Language Class Initialized
INFO - 2023-06-07 04:08:42 --> Config Class Initialized
INFO - 2023-06-07 04:08:42 --> Loader Class Initialized
INFO - 2023-06-07 04:08:42 --> Helper loaded: url_helper
INFO - 2023-06-07 04:08:42 --> Helper loaded: file_helper
INFO - 2023-06-07 04:08:42 --> Helper loaded: form_helper
INFO - 2023-06-07 04:08:42 --> Helper loaded: my_helper
INFO - 2023-06-07 04:08:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:08:42 --> Controller Class Initialized
INFO - 2023-06-07 04:08:42 --> Final output sent to browser
DEBUG - 2023-06-07 04:08:42 --> Total execution time: 0.0530
INFO - 2023-06-07 04:08:44 --> Config Class Initialized
INFO - 2023-06-07 04:08:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:08:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:08:44 --> Utf8 Class Initialized
INFO - 2023-06-07 04:08:44 --> URI Class Initialized
INFO - 2023-06-07 04:08:44 --> Router Class Initialized
INFO - 2023-06-07 04:08:44 --> Output Class Initialized
INFO - 2023-06-07 04:08:44 --> Security Class Initialized
DEBUG - 2023-06-07 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:08:44 --> Input Class Initialized
INFO - 2023-06-07 04:08:44 --> Language Class Initialized
INFO - 2023-06-07 04:08:44 --> Language Class Initialized
INFO - 2023-06-07 04:08:44 --> Config Class Initialized
INFO - 2023-06-07 04:08:44 --> Loader Class Initialized
INFO - 2023-06-07 04:08:44 --> Helper loaded: url_helper
INFO - 2023-06-07 04:08:44 --> Helper loaded: file_helper
INFO - 2023-06-07 04:08:44 --> Helper loaded: form_helper
INFO - 2023-06-07 04:08:44 --> Helper loaded: my_helper
INFO - 2023-06-07 04:08:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:08:44 --> Controller Class Initialized
DEBUG - 2023-06-07 04:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 04:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:08:44 --> Final output sent to browser
DEBUG - 2023-06-07 04:08:44 --> Total execution time: 0.0258
INFO - 2023-06-07 04:09:11 --> Config Class Initialized
INFO - 2023-06-07 04:09:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:11 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:11 --> URI Class Initialized
INFO - 2023-06-07 04:09:11 --> Router Class Initialized
INFO - 2023-06-07 04:09:11 --> Output Class Initialized
INFO - 2023-06-07 04:09:11 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:11 --> Input Class Initialized
INFO - 2023-06-07 04:09:11 --> Language Class Initialized
INFO - 2023-06-07 04:09:11 --> Language Class Initialized
INFO - 2023-06-07 04:09:11 --> Config Class Initialized
INFO - 2023-06-07 04:09:11 --> Loader Class Initialized
INFO - 2023-06-07 04:09:11 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:11 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:11 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:11 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:11 --> Controller Class Initialized
INFO - 2023-06-07 04:09:11 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:11 --> Total execution time: 0.0473
INFO - 2023-06-07 04:09:13 --> Config Class Initialized
INFO - 2023-06-07 04:09:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:13 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:13 --> URI Class Initialized
INFO - 2023-06-07 04:09:13 --> Router Class Initialized
INFO - 2023-06-07 04:09:13 --> Output Class Initialized
INFO - 2023-06-07 04:09:13 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:13 --> Input Class Initialized
INFO - 2023-06-07 04:09:13 --> Language Class Initialized
INFO - 2023-06-07 04:09:13 --> Language Class Initialized
INFO - 2023-06-07 04:09:13 --> Config Class Initialized
INFO - 2023-06-07 04:09:13 --> Loader Class Initialized
INFO - 2023-06-07 04:09:13 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:13 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:13 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:13 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:13 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 04:09:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:13 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:13 --> Total execution time: 0.0446
INFO - 2023-06-07 04:09:14 --> Config Class Initialized
INFO - 2023-06-07 04:09:14 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:14 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:14 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:14 --> URI Class Initialized
INFO - 2023-06-07 04:09:14 --> Router Class Initialized
INFO - 2023-06-07 04:09:14 --> Output Class Initialized
INFO - 2023-06-07 04:09:14 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:14 --> Input Class Initialized
INFO - 2023-06-07 04:09:14 --> Language Class Initialized
INFO - 2023-06-07 04:09:14 --> Language Class Initialized
INFO - 2023-06-07 04:09:14 --> Config Class Initialized
INFO - 2023-06-07 04:09:14 --> Loader Class Initialized
INFO - 2023-06-07 04:09:14 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:14 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:14 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:14 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:14 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:14 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-07 04:09:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:14 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:14 --> Total execution time: 0.0417
INFO - 2023-06-07 04:09:17 --> Config Class Initialized
INFO - 2023-06-07 04:09:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:17 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:17 --> URI Class Initialized
INFO - 2023-06-07 04:09:17 --> Router Class Initialized
INFO - 2023-06-07 04:09:17 --> Output Class Initialized
INFO - 2023-06-07 04:09:17 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:17 --> Input Class Initialized
INFO - 2023-06-07 04:09:17 --> Language Class Initialized
INFO - 2023-06-07 04:09:17 --> Language Class Initialized
INFO - 2023-06-07 04:09:17 --> Config Class Initialized
INFO - 2023-06-07 04:09:17 --> Loader Class Initialized
INFO - 2023-06-07 04:09:17 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:17 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:17 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:17 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:17 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-06-07 04:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:17 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:17 --> Total execution time: 0.0530
INFO - 2023-06-07 04:09:18 --> Config Class Initialized
INFO - 2023-06-07 04:09:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:18 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:18 --> URI Class Initialized
INFO - 2023-06-07 04:09:18 --> Router Class Initialized
INFO - 2023-06-07 04:09:18 --> Output Class Initialized
INFO - 2023-06-07 04:09:18 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:18 --> Input Class Initialized
INFO - 2023-06-07 04:09:18 --> Language Class Initialized
INFO - 2023-06-07 04:09:18 --> Language Class Initialized
INFO - 2023-06-07 04:09:18 --> Config Class Initialized
INFO - 2023-06-07 04:09:18 --> Loader Class Initialized
INFO - 2023-06-07 04:09:18 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:18 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:18 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:18 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:18 --> Controller Class Initialized
INFO - 2023-06-07 04:09:18 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:18 --> Total execution time: 0.0402
INFO - 2023-06-07 04:09:23 --> Config Class Initialized
INFO - 2023-06-07 04:09:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:23 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:23 --> URI Class Initialized
INFO - 2023-06-07 04:09:23 --> Router Class Initialized
INFO - 2023-06-07 04:09:23 --> Output Class Initialized
INFO - 2023-06-07 04:09:23 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:23 --> Input Class Initialized
INFO - 2023-06-07 04:09:23 --> Language Class Initialized
INFO - 2023-06-07 04:09:23 --> Language Class Initialized
INFO - 2023-06-07 04:09:23 --> Config Class Initialized
INFO - 2023-06-07 04:09:23 --> Loader Class Initialized
INFO - 2023-06-07 04:09:23 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:23 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:23 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:23 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:23 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_fimo/views/list.php
DEBUG - 2023-06-07 04:09:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:23 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:23 --> Total execution time: 0.0506
INFO - 2023-06-07 04:09:23 --> Config Class Initialized
INFO - 2023-06-07 04:09:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:23 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:23 --> URI Class Initialized
INFO - 2023-06-07 04:09:23 --> Router Class Initialized
INFO - 2023-06-07 04:09:23 --> Output Class Initialized
INFO - 2023-06-07 04:09:23 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:23 --> Input Class Initialized
INFO - 2023-06-07 04:09:23 --> Language Class Initialized
INFO - 2023-06-07 04:09:23 --> Language Class Initialized
INFO - 2023-06-07 04:09:23 --> Config Class Initialized
INFO - 2023-06-07 04:09:23 --> Loader Class Initialized
INFO - 2023-06-07 04:09:24 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:24 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:24 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:24 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:24 --> Controller Class Initialized
INFO - 2023-06-07 04:09:24 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:24 --> Total execution time: 0.0358
INFO - 2023-06-07 04:09:28 --> Config Class Initialized
INFO - 2023-06-07 04:09:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:28 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:28 --> URI Class Initialized
INFO - 2023-06-07 04:09:28 --> Router Class Initialized
INFO - 2023-06-07 04:09:28 --> Output Class Initialized
INFO - 2023-06-07 04:09:28 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:28 --> Input Class Initialized
INFO - 2023-06-07 04:09:28 --> Language Class Initialized
INFO - 2023-06-07 04:09:28 --> Language Class Initialized
INFO - 2023-06-07 04:09:28 --> Config Class Initialized
INFO - 2023-06-07 04:09:28 --> Loader Class Initialized
INFO - 2023-06-07 04:09:28 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:28 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:28 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:28 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:28 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_sek/views/list.php
DEBUG - 2023-06-07 04:09:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:28 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:28 --> Total execution time: 0.0503
INFO - 2023-06-07 04:09:30 --> Config Class Initialized
INFO - 2023-06-07 04:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:30 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:30 --> URI Class Initialized
INFO - 2023-06-07 04:09:30 --> Router Class Initialized
INFO - 2023-06-07 04:09:30 --> Output Class Initialized
INFO - 2023-06-07 04:09:30 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:30 --> Input Class Initialized
INFO - 2023-06-07 04:09:30 --> Language Class Initialized
INFO - 2023-06-07 04:09:30 --> Language Class Initialized
INFO - 2023-06-07 04:09:30 --> Config Class Initialized
INFO - 2023-06-07 04:09:30 --> Loader Class Initialized
INFO - 2023-06-07 04:09:30 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:30 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:30 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:30 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:30 --> Controller Class Initialized
INFO - 2023-06-07 04:09:30 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:30 --> Total execution time: 0.0252
INFO - 2023-06-07 04:09:32 --> Config Class Initialized
INFO - 2023-06-07 04:09:32 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:09:32 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:09:32 --> Utf8 Class Initialized
INFO - 2023-06-07 04:09:32 --> URI Class Initialized
INFO - 2023-06-07 04:09:32 --> Router Class Initialized
INFO - 2023-06-07 04:09:32 --> Output Class Initialized
INFO - 2023-06-07 04:09:32 --> Security Class Initialized
DEBUG - 2023-06-07 04:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:09:32 --> Input Class Initialized
INFO - 2023-06-07 04:09:32 --> Language Class Initialized
INFO - 2023-06-07 04:09:32 --> Language Class Initialized
INFO - 2023-06-07 04:09:32 --> Config Class Initialized
INFO - 2023-06-07 04:09:32 --> Loader Class Initialized
INFO - 2023-06-07 04:09:32 --> Helper loaded: url_helper
INFO - 2023-06-07 04:09:32 --> Helper loaded: file_helper
INFO - 2023-06-07 04:09:32 --> Helper loaded: form_helper
INFO - 2023-06-07 04:09:32 --> Helper loaded: my_helper
INFO - 2023-06-07 04:09:32 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:09:32 --> Controller Class Initialized
DEBUG - 2023-06-07 04:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_sek/views/list.php
DEBUG - 2023-06-07 04:09:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:09:32 --> Final output sent to browser
DEBUG - 2023-06-07 04:09:32 --> Total execution time: 0.0503
INFO - 2023-06-07 04:12:48 --> Config Class Initialized
INFO - 2023-06-07 04:12:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:12:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:12:48 --> Utf8 Class Initialized
INFO - 2023-06-07 04:12:48 --> URI Class Initialized
INFO - 2023-06-07 04:12:48 --> Router Class Initialized
INFO - 2023-06-07 04:12:48 --> Output Class Initialized
INFO - 2023-06-07 04:12:48 --> Security Class Initialized
DEBUG - 2023-06-07 04:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:12:48 --> Input Class Initialized
INFO - 2023-06-07 04:12:48 --> Language Class Initialized
INFO - 2023-06-07 04:12:48 --> Language Class Initialized
INFO - 2023-06-07 04:12:48 --> Config Class Initialized
INFO - 2023-06-07 04:12:48 --> Loader Class Initialized
INFO - 2023-06-07 04:12:48 --> Helper loaded: url_helper
INFO - 2023-06-07 04:12:48 --> Helper loaded: file_helper
INFO - 2023-06-07 04:12:48 --> Helper loaded: form_helper
INFO - 2023-06-07 04:12:48 --> Helper loaded: my_helper
INFO - 2023-06-07 04:12:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:12:48 --> Controller Class Initialized
DEBUG - 2023-06-07 04:12:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-07 04:12:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 04:12:48 --> Final output sent to browser
DEBUG - 2023-06-07 04:12:48 --> Total execution time: 0.0325
INFO - 2023-06-07 04:12:50 --> Config Class Initialized
INFO - 2023-06-07 04:12:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:12:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:12:50 --> Utf8 Class Initialized
INFO - 2023-06-07 04:12:50 --> URI Class Initialized
INFO - 2023-06-07 04:12:50 --> Router Class Initialized
INFO - 2023-06-07 04:12:50 --> Output Class Initialized
INFO - 2023-06-07 04:12:50 --> Security Class Initialized
DEBUG - 2023-06-07 04:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:12:50 --> Input Class Initialized
INFO - 2023-06-07 04:12:50 --> Language Class Initialized
INFO - 2023-06-07 04:12:50 --> Language Class Initialized
INFO - 2023-06-07 04:12:50 --> Config Class Initialized
INFO - 2023-06-07 04:12:50 --> Loader Class Initialized
INFO - 2023-06-07 04:12:50 --> Helper loaded: url_helper
INFO - 2023-06-07 04:12:50 --> Helper loaded: file_helper
INFO - 2023-06-07 04:12:50 --> Helper loaded: form_helper
INFO - 2023-06-07 04:12:50 --> Helper loaded: my_helper
INFO - 2023-06-07 04:12:50 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:12:50 --> Controller Class Initialized
DEBUG - 2023-06-07 04:12:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 04:12:51 --> Final output sent to browser
DEBUG - 2023-06-07 04:12:51 --> Total execution time: 0.9886
INFO - 2023-06-07 04:44:24 --> Config Class Initialized
INFO - 2023-06-07 04:44:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:44:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:44:24 --> Utf8 Class Initialized
INFO - 2023-06-07 04:44:24 --> URI Class Initialized
INFO - 2023-06-07 04:44:24 --> Router Class Initialized
INFO - 2023-06-07 04:44:24 --> Output Class Initialized
INFO - 2023-06-07 04:44:25 --> Security Class Initialized
DEBUG - 2023-06-07 04:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:44:25 --> Input Class Initialized
INFO - 2023-06-07 04:44:25 --> Language Class Initialized
INFO - 2023-06-07 04:44:25 --> Language Class Initialized
INFO - 2023-06-07 04:44:25 --> Config Class Initialized
INFO - 2023-06-07 04:44:25 --> Loader Class Initialized
INFO - 2023-06-07 04:44:25 --> Helper loaded: url_helper
INFO - 2023-06-07 04:44:25 --> Helper loaded: file_helper
INFO - 2023-06-07 04:44:25 --> Helper loaded: form_helper
INFO - 2023-06-07 04:44:25 --> Helper loaded: my_helper
INFO - 2023-06-07 04:44:25 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:44:25 --> Controller Class Initialized
DEBUG - 2023-06-07 04:44:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:44:25 --> Final output sent to browser
DEBUG - 2023-06-07 04:44:25 --> Total execution time: 0.9326
INFO - 2023-06-07 04:45:10 --> Config Class Initialized
INFO - 2023-06-07 04:45:10 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:45:10 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:45:10 --> Utf8 Class Initialized
INFO - 2023-06-07 04:45:10 --> URI Class Initialized
INFO - 2023-06-07 04:45:10 --> Router Class Initialized
INFO - 2023-06-07 04:45:10 --> Output Class Initialized
INFO - 2023-06-07 04:45:10 --> Security Class Initialized
DEBUG - 2023-06-07 04:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:45:10 --> Input Class Initialized
INFO - 2023-06-07 04:45:10 --> Language Class Initialized
INFO - 2023-06-07 04:45:10 --> Language Class Initialized
INFO - 2023-06-07 04:45:10 --> Config Class Initialized
INFO - 2023-06-07 04:45:10 --> Loader Class Initialized
INFO - 2023-06-07 04:45:10 --> Helper loaded: url_helper
INFO - 2023-06-07 04:45:10 --> Helper loaded: file_helper
INFO - 2023-06-07 04:45:10 --> Helper loaded: form_helper
INFO - 2023-06-07 04:45:10 --> Helper loaded: my_helper
INFO - 2023-06-07 04:45:10 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:45:10 --> Controller Class Initialized
DEBUG - 2023-06-07 04:45:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:45:11 --> Final output sent to browser
DEBUG - 2023-06-07 04:45:11 --> Total execution time: 0.8878
INFO - 2023-06-07 04:45:29 --> Config Class Initialized
INFO - 2023-06-07 04:45:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:45:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:45:29 --> Utf8 Class Initialized
INFO - 2023-06-07 04:45:29 --> URI Class Initialized
INFO - 2023-06-07 04:45:29 --> Router Class Initialized
INFO - 2023-06-07 04:45:29 --> Output Class Initialized
INFO - 2023-06-07 04:45:29 --> Security Class Initialized
DEBUG - 2023-06-07 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:45:29 --> Input Class Initialized
INFO - 2023-06-07 04:45:29 --> Language Class Initialized
INFO - 2023-06-07 04:45:29 --> Language Class Initialized
INFO - 2023-06-07 04:45:29 --> Config Class Initialized
INFO - 2023-06-07 04:45:29 --> Loader Class Initialized
INFO - 2023-06-07 04:45:29 --> Helper loaded: url_helper
INFO - 2023-06-07 04:45:29 --> Helper loaded: file_helper
INFO - 2023-06-07 04:45:29 --> Helper loaded: form_helper
INFO - 2023-06-07 04:45:29 --> Helper loaded: my_helper
INFO - 2023-06-07 04:45:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:45:29 --> Controller Class Initialized
DEBUG - 2023-06-07 04:45:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:45:30 --> Final output sent to browser
DEBUG - 2023-06-07 04:45:30 --> Total execution time: 0.9042
INFO - 2023-06-07 04:47:06 --> Config Class Initialized
INFO - 2023-06-07 04:47:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:47:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:47:06 --> Utf8 Class Initialized
INFO - 2023-06-07 04:47:06 --> URI Class Initialized
INFO - 2023-06-07 04:47:06 --> Router Class Initialized
INFO - 2023-06-07 04:47:06 --> Output Class Initialized
INFO - 2023-06-07 04:47:06 --> Security Class Initialized
DEBUG - 2023-06-07 04:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:47:06 --> Input Class Initialized
INFO - 2023-06-07 04:47:06 --> Language Class Initialized
INFO - 2023-06-07 04:47:06 --> Language Class Initialized
INFO - 2023-06-07 04:47:06 --> Config Class Initialized
INFO - 2023-06-07 04:47:06 --> Loader Class Initialized
INFO - 2023-06-07 04:47:06 --> Helper loaded: url_helper
INFO - 2023-06-07 04:47:06 --> Helper loaded: file_helper
INFO - 2023-06-07 04:47:06 --> Helper loaded: form_helper
INFO - 2023-06-07 04:47:06 --> Helper loaded: my_helper
INFO - 2023-06-07 04:47:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:47:06 --> Controller Class Initialized
DEBUG - 2023-06-07 04:47:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:47:07 --> Final output sent to browser
DEBUG - 2023-06-07 04:47:07 --> Total execution time: 0.8951
INFO - 2023-06-07 04:47:34 --> Config Class Initialized
INFO - 2023-06-07 04:47:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:47:34 --> Utf8 Class Initialized
INFO - 2023-06-07 04:47:34 --> URI Class Initialized
INFO - 2023-06-07 04:47:34 --> Router Class Initialized
INFO - 2023-06-07 04:47:34 --> Output Class Initialized
INFO - 2023-06-07 04:47:34 --> Security Class Initialized
DEBUG - 2023-06-07 04:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:47:34 --> Input Class Initialized
INFO - 2023-06-07 04:47:34 --> Language Class Initialized
INFO - 2023-06-07 04:47:34 --> Language Class Initialized
INFO - 2023-06-07 04:47:34 --> Config Class Initialized
INFO - 2023-06-07 04:47:34 --> Loader Class Initialized
INFO - 2023-06-07 04:47:34 --> Helper loaded: url_helper
INFO - 2023-06-07 04:47:34 --> Helper loaded: file_helper
INFO - 2023-06-07 04:47:34 --> Helper loaded: form_helper
INFO - 2023-06-07 04:47:34 --> Helper loaded: my_helper
INFO - 2023-06-07 04:47:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:47:34 --> Controller Class Initialized
DEBUG - 2023-06-07 04:47:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:47:35 --> Final output sent to browser
DEBUG - 2023-06-07 04:47:35 --> Total execution time: 0.9013
INFO - 2023-06-07 04:47:44 --> Config Class Initialized
INFO - 2023-06-07 04:47:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:47:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:47:44 --> Utf8 Class Initialized
INFO - 2023-06-07 04:47:44 --> URI Class Initialized
INFO - 2023-06-07 04:47:44 --> Router Class Initialized
INFO - 2023-06-07 04:47:44 --> Output Class Initialized
INFO - 2023-06-07 04:47:44 --> Security Class Initialized
DEBUG - 2023-06-07 04:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:47:44 --> Input Class Initialized
INFO - 2023-06-07 04:47:44 --> Language Class Initialized
INFO - 2023-06-07 04:47:44 --> Language Class Initialized
INFO - 2023-06-07 04:47:44 --> Config Class Initialized
INFO - 2023-06-07 04:47:44 --> Loader Class Initialized
INFO - 2023-06-07 04:47:44 --> Helper loaded: url_helper
INFO - 2023-06-07 04:47:44 --> Helper loaded: file_helper
INFO - 2023-06-07 04:47:44 --> Helper loaded: form_helper
INFO - 2023-06-07 04:47:44 --> Helper loaded: my_helper
INFO - 2023-06-07 04:47:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:47:44 --> Controller Class Initialized
DEBUG - 2023-06-07 04:47:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:47:45 --> Final output sent to browser
DEBUG - 2023-06-07 04:47:45 --> Total execution time: 0.8938
INFO - 2023-06-07 04:48:03 --> Config Class Initialized
INFO - 2023-06-07 04:48:03 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:48:03 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:48:03 --> Utf8 Class Initialized
INFO - 2023-06-07 04:48:03 --> URI Class Initialized
INFO - 2023-06-07 04:48:03 --> Router Class Initialized
INFO - 2023-06-07 04:48:03 --> Output Class Initialized
INFO - 2023-06-07 04:48:03 --> Security Class Initialized
DEBUG - 2023-06-07 04:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:48:03 --> Input Class Initialized
INFO - 2023-06-07 04:48:03 --> Language Class Initialized
INFO - 2023-06-07 04:48:03 --> Language Class Initialized
INFO - 2023-06-07 04:48:03 --> Config Class Initialized
INFO - 2023-06-07 04:48:03 --> Loader Class Initialized
INFO - 2023-06-07 04:48:03 --> Helper loaded: url_helper
INFO - 2023-06-07 04:48:04 --> Helper loaded: file_helper
INFO - 2023-06-07 04:48:04 --> Helper loaded: form_helper
INFO - 2023-06-07 04:48:04 --> Helper loaded: my_helper
INFO - 2023-06-07 04:48:04 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:48:04 --> Controller Class Initialized
DEBUG - 2023-06-07 04:48:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:48:04 --> Final output sent to browser
DEBUG - 2023-06-07 04:48:04 --> Total execution time: 0.9136
INFO - 2023-06-07 04:49:16 --> Config Class Initialized
INFO - 2023-06-07 04:49:16 --> Hooks Class Initialized
DEBUG - 2023-06-07 04:49:16 --> UTF-8 Support Enabled
INFO - 2023-06-07 04:49:16 --> Utf8 Class Initialized
INFO - 2023-06-07 04:49:16 --> URI Class Initialized
INFO - 2023-06-07 04:49:16 --> Router Class Initialized
INFO - 2023-06-07 04:49:16 --> Output Class Initialized
INFO - 2023-06-07 04:49:16 --> Security Class Initialized
DEBUG - 2023-06-07 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 04:49:16 --> Input Class Initialized
INFO - 2023-06-07 04:49:16 --> Language Class Initialized
INFO - 2023-06-07 04:49:16 --> Language Class Initialized
INFO - 2023-06-07 04:49:16 --> Config Class Initialized
INFO - 2023-06-07 04:49:16 --> Loader Class Initialized
INFO - 2023-06-07 04:49:16 --> Helper loaded: url_helper
INFO - 2023-06-07 04:49:16 --> Helper loaded: file_helper
INFO - 2023-06-07 04:49:16 --> Helper loaded: form_helper
INFO - 2023-06-07 04:49:16 --> Helper loaded: my_helper
INFO - 2023-06-07 04:49:16 --> Database Driver Class Initialized
DEBUG - 2023-06-07 04:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 04:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 04:49:16 --> Controller Class Initialized
DEBUG - 2023-06-07 04:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 04:49:16 --> Final output sent to browser
DEBUG - 2023-06-07 04:49:16 --> Total execution time: 0.9030
INFO - 2023-06-07 05:02:18 --> Config Class Initialized
INFO - 2023-06-07 05:02:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:02:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:02:18 --> Utf8 Class Initialized
INFO - 2023-06-07 05:02:18 --> URI Class Initialized
INFO - 2023-06-07 05:02:18 --> Router Class Initialized
INFO - 2023-06-07 05:02:18 --> Output Class Initialized
INFO - 2023-06-07 05:02:18 --> Security Class Initialized
DEBUG - 2023-06-07 05:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:02:18 --> Input Class Initialized
INFO - 2023-06-07 05:02:18 --> Language Class Initialized
INFO - 2023-06-07 05:02:18 --> Language Class Initialized
INFO - 2023-06-07 05:02:18 --> Config Class Initialized
INFO - 2023-06-07 05:02:18 --> Loader Class Initialized
INFO - 2023-06-07 05:02:18 --> Helper loaded: url_helper
INFO - 2023-06-07 05:02:18 --> Helper loaded: file_helper
INFO - 2023-06-07 05:02:18 --> Helper loaded: form_helper
INFO - 2023-06-07 05:02:18 --> Helper loaded: my_helper
INFO - 2023-06-07 05:02:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:02:18 --> Controller Class Initialized
DEBUG - 2023-06-07 05:02:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:02:19 --> Final output sent to browser
DEBUG - 2023-06-07 05:02:19 --> Total execution time: 0.8706
INFO - 2023-06-07 05:02:40 --> Config Class Initialized
INFO - 2023-06-07 05:02:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:02:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:02:40 --> Utf8 Class Initialized
INFO - 2023-06-07 05:02:40 --> URI Class Initialized
INFO - 2023-06-07 05:02:40 --> Router Class Initialized
INFO - 2023-06-07 05:02:40 --> Output Class Initialized
INFO - 2023-06-07 05:02:40 --> Security Class Initialized
DEBUG - 2023-06-07 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:02:40 --> Input Class Initialized
INFO - 2023-06-07 05:02:40 --> Language Class Initialized
INFO - 2023-06-07 05:02:40 --> Language Class Initialized
INFO - 2023-06-07 05:02:40 --> Config Class Initialized
INFO - 2023-06-07 05:02:40 --> Loader Class Initialized
INFO - 2023-06-07 05:02:40 --> Helper loaded: url_helper
INFO - 2023-06-07 05:02:40 --> Helper loaded: file_helper
INFO - 2023-06-07 05:02:40 --> Helper loaded: form_helper
INFO - 2023-06-07 05:02:40 --> Helper loaded: my_helper
INFO - 2023-06-07 05:02:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:02:40 --> Controller Class Initialized
DEBUG - 2023-06-07 05:02:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:02:40 --> Final output sent to browser
DEBUG - 2023-06-07 05:02:40 --> Total execution time: 0.8784
INFO - 2023-06-07 05:03:19 --> Config Class Initialized
INFO - 2023-06-07 05:03:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:03:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:03:19 --> Utf8 Class Initialized
INFO - 2023-06-07 05:03:19 --> URI Class Initialized
INFO - 2023-06-07 05:03:19 --> Router Class Initialized
INFO - 2023-06-07 05:03:19 --> Output Class Initialized
INFO - 2023-06-07 05:03:19 --> Security Class Initialized
DEBUG - 2023-06-07 05:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:03:19 --> Input Class Initialized
INFO - 2023-06-07 05:03:19 --> Language Class Initialized
INFO - 2023-06-07 05:03:19 --> Language Class Initialized
INFO - 2023-06-07 05:03:19 --> Config Class Initialized
INFO - 2023-06-07 05:03:19 --> Loader Class Initialized
INFO - 2023-06-07 05:03:19 --> Helper loaded: url_helper
INFO - 2023-06-07 05:03:19 --> Helper loaded: file_helper
INFO - 2023-06-07 05:03:19 --> Helper loaded: form_helper
INFO - 2023-06-07 05:03:19 --> Helper loaded: my_helper
INFO - 2023-06-07 05:03:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:03:19 --> Controller Class Initialized
DEBUG - 2023-06-07 05:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:03:20 --> Final output sent to browser
DEBUG - 2023-06-07 05:03:20 --> Total execution time: 0.8911
INFO - 2023-06-07 05:03:38 --> Config Class Initialized
INFO - 2023-06-07 05:03:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:03:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:03:38 --> Utf8 Class Initialized
INFO - 2023-06-07 05:03:38 --> URI Class Initialized
INFO - 2023-06-07 05:03:38 --> Router Class Initialized
INFO - 2023-06-07 05:03:38 --> Output Class Initialized
INFO - 2023-06-07 05:03:38 --> Security Class Initialized
DEBUG - 2023-06-07 05:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:03:38 --> Input Class Initialized
INFO - 2023-06-07 05:03:38 --> Language Class Initialized
INFO - 2023-06-07 05:03:38 --> Language Class Initialized
INFO - 2023-06-07 05:03:38 --> Config Class Initialized
INFO - 2023-06-07 05:03:38 --> Loader Class Initialized
INFO - 2023-06-07 05:03:38 --> Helper loaded: url_helper
INFO - 2023-06-07 05:03:38 --> Helper loaded: file_helper
INFO - 2023-06-07 05:03:38 --> Helper loaded: form_helper
INFO - 2023-06-07 05:03:38 --> Helper loaded: my_helper
INFO - 2023-06-07 05:03:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:03:38 --> Controller Class Initialized
DEBUG - 2023-06-07 05:03:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 05:03:39 --> Final output sent to browser
DEBUG - 2023-06-07 05:03:39 --> Total execution time: 0.8837
INFO - 2023-06-07 05:03:43 --> Config Class Initialized
INFO - 2023-06-07 05:03:43 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:03:43 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:03:43 --> Utf8 Class Initialized
INFO - 2023-06-07 05:03:43 --> URI Class Initialized
INFO - 2023-06-07 05:03:43 --> Router Class Initialized
INFO - 2023-06-07 05:03:43 --> Output Class Initialized
INFO - 2023-06-07 05:03:43 --> Security Class Initialized
DEBUG - 2023-06-07 05:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:03:43 --> Input Class Initialized
INFO - 2023-06-07 05:03:43 --> Language Class Initialized
INFO - 2023-06-07 05:03:43 --> Language Class Initialized
INFO - 2023-06-07 05:03:43 --> Config Class Initialized
INFO - 2023-06-07 05:03:43 --> Loader Class Initialized
INFO - 2023-06-07 05:03:43 --> Helper loaded: url_helper
INFO - 2023-06-07 05:03:43 --> Helper loaded: file_helper
INFO - 2023-06-07 05:03:43 --> Helper loaded: form_helper
INFO - 2023-06-07 05:03:43 --> Helper loaded: my_helper
INFO - 2023-06-07 05:03:43 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:03:43 --> Controller Class Initialized
DEBUG - 2023-06-07 05:03:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:03:44 --> Final output sent to browser
DEBUG - 2023-06-07 05:03:44 --> Total execution time: 0.8612
INFO - 2023-06-07 05:04:05 --> Config Class Initialized
INFO - 2023-06-07 05:04:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:04:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:04:05 --> Utf8 Class Initialized
INFO - 2023-06-07 05:04:05 --> URI Class Initialized
INFO - 2023-06-07 05:04:05 --> Router Class Initialized
INFO - 2023-06-07 05:04:05 --> Output Class Initialized
INFO - 2023-06-07 05:04:05 --> Security Class Initialized
DEBUG - 2023-06-07 05:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:04:05 --> Input Class Initialized
INFO - 2023-06-07 05:04:05 --> Language Class Initialized
INFO - 2023-06-07 05:04:05 --> Language Class Initialized
INFO - 2023-06-07 05:04:05 --> Config Class Initialized
INFO - 2023-06-07 05:04:05 --> Loader Class Initialized
INFO - 2023-06-07 05:04:05 --> Helper loaded: url_helper
INFO - 2023-06-07 05:04:05 --> Helper loaded: file_helper
INFO - 2023-06-07 05:04:05 --> Helper loaded: form_helper
INFO - 2023-06-07 05:04:05 --> Helper loaded: my_helper
INFO - 2023-06-07 05:04:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:04:05 --> Controller Class Initialized
DEBUG - 2023-06-07 05:04:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:04:06 --> Final output sent to browser
DEBUG - 2023-06-07 05:04:06 --> Total execution time: 0.8723
INFO - 2023-06-07 05:04:28 --> Config Class Initialized
INFO - 2023-06-07 05:04:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:04:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:04:28 --> Utf8 Class Initialized
INFO - 2023-06-07 05:04:28 --> URI Class Initialized
INFO - 2023-06-07 05:04:28 --> Router Class Initialized
INFO - 2023-06-07 05:04:28 --> Output Class Initialized
INFO - 2023-06-07 05:04:28 --> Security Class Initialized
DEBUG - 2023-06-07 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:04:28 --> Input Class Initialized
INFO - 2023-06-07 05:04:28 --> Language Class Initialized
INFO - 2023-06-07 05:04:28 --> Language Class Initialized
INFO - 2023-06-07 05:04:28 --> Config Class Initialized
INFO - 2023-06-07 05:04:28 --> Loader Class Initialized
INFO - 2023-06-07 05:04:28 --> Helper loaded: url_helper
INFO - 2023-06-07 05:04:28 --> Helper loaded: file_helper
INFO - 2023-06-07 05:04:28 --> Helper loaded: form_helper
INFO - 2023-06-07 05:04:28 --> Helper loaded: my_helper
INFO - 2023-06-07 05:04:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:04:28 --> Controller Class Initialized
DEBUG - 2023-06-07 05:04:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:04:28 --> Final output sent to browser
DEBUG - 2023-06-07 05:04:28 --> Total execution time: 0.9088
INFO - 2023-06-07 05:04:42 --> Config Class Initialized
INFO - 2023-06-07 05:04:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:04:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:04:42 --> Utf8 Class Initialized
INFO - 2023-06-07 05:04:42 --> URI Class Initialized
INFO - 2023-06-07 05:04:42 --> Router Class Initialized
INFO - 2023-06-07 05:04:42 --> Output Class Initialized
INFO - 2023-06-07 05:04:42 --> Security Class Initialized
DEBUG - 2023-06-07 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:04:42 --> Input Class Initialized
INFO - 2023-06-07 05:04:42 --> Language Class Initialized
INFO - 2023-06-07 05:04:42 --> Language Class Initialized
INFO - 2023-06-07 05:04:42 --> Config Class Initialized
INFO - 2023-06-07 05:04:42 --> Loader Class Initialized
INFO - 2023-06-07 05:04:42 --> Helper loaded: url_helper
INFO - 2023-06-07 05:04:42 --> Helper loaded: file_helper
INFO - 2023-06-07 05:04:42 --> Helper loaded: form_helper
INFO - 2023-06-07 05:04:42 --> Helper loaded: my_helper
INFO - 2023-06-07 05:04:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:04:42 --> Controller Class Initialized
DEBUG - 2023-06-07 05:04:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:04:43 --> Final output sent to browser
DEBUG - 2023-06-07 05:04:43 --> Total execution time: 0.8867
INFO - 2023-06-07 05:05:02 --> Config Class Initialized
INFO - 2023-06-07 05:05:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:05:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:05:02 --> Utf8 Class Initialized
INFO - 2023-06-07 05:05:02 --> URI Class Initialized
INFO - 2023-06-07 05:05:02 --> Router Class Initialized
INFO - 2023-06-07 05:05:02 --> Output Class Initialized
INFO - 2023-06-07 05:05:02 --> Security Class Initialized
DEBUG - 2023-06-07 05:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:05:02 --> Input Class Initialized
INFO - 2023-06-07 05:05:02 --> Language Class Initialized
INFO - 2023-06-07 05:05:02 --> Language Class Initialized
INFO - 2023-06-07 05:05:02 --> Config Class Initialized
INFO - 2023-06-07 05:05:02 --> Loader Class Initialized
INFO - 2023-06-07 05:05:02 --> Helper loaded: url_helper
INFO - 2023-06-07 05:05:02 --> Helper loaded: file_helper
INFO - 2023-06-07 05:05:02 --> Helper loaded: form_helper
INFO - 2023-06-07 05:05:02 --> Helper loaded: my_helper
INFO - 2023-06-07 05:05:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:05:02 --> Controller Class Initialized
DEBUG - 2023-06-07 05:05:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:05:03 --> Final output sent to browser
DEBUG - 2023-06-07 05:05:03 --> Total execution time: 0.8839
INFO - 2023-06-07 05:05:38 --> Config Class Initialized
INFO - 2023-06-07 05:05:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:05:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:05:38 --> Utf8 Class Initialized
INFO - 2023-06-07 05:05:38 --> URI Class Initialized
INFO - 2023-06-07 05:05:38 --> Router Class Initialized
INFO - 2023-06-07 05:05:38 --> Output Class Initialized
INFO - 2023-06-07 05:05:38 --> Security Class Initialized
DEBUG - 2023-06-07 05:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:05:38 --> Input Class Initialized
INFO - 2023-06-07 05:05:38 --> Language Class Initialized
INFO - 2023-06-07 05:05:38 --> Language Class Initialized
INFO - 2023-06-07 05:05:38 --> Config Class Initialized
INFO - 2023-06-07 05:05:38 --> Loader Class Initialized
INFO - 2023-06-07 05:05:38 --> Helper loaded: url_helper
INFO - 2023-06-07 05:05:38 --> Helper loaded: file_helper
INFO - 2023-06-07 05:05:38 --> Helper loaded: form_helper
INFO - 2023-06-07 05:05:38 --> Helper loaded: my_helper
INFO - 2023-06-07 05:05:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:05:38 --> Controller Class Initialized
DEBUG - 2023-06-07 05:05:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:05:39 --> Final output sent to browser
DEBUG - 2023-06-07 05:05:39 --> Total execution time: 0.8958
INFO - 2023-06-07 05:08:23 --> Config Class Initialized
INFO - 2023-06-07 05:08:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:08:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:08:23 --> Utf8 Class Initialized
INFO - 2023-06-07 05:08:23 --> URI Class Initialized
INFO - 2023-06-07 05:08:23 --> Router Class Initialized
INFO - 2023-06-07 05:08:23 --> Output Class Initialized
INFO - 2023-06-07 05:08:23 --> Security Class Initialized
DEBUG - 2023-06-07 05:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:08:23 --> Input Class Initialized
INFO - 2023-06-07 05:08:23 --> Language Class Initialized
INFO - 2023-06-07 05:08:23 --> Language Class Initialized
INFO - 2023-06-07 05:08:23 --> Config Class Initialized
INFO - 2023-06-07 05:08:23 --> Loader Class Initialized
INFO - 2023-06-07 05:08:23 --> Helper loaded: url_helper
INFO - 2023-06-07 05:08:23 --> Helper loaded: file_helper
INFO - 2023-06-07 05:08:23 --> Helper loaded: form_helper
INFO - 2023-06-07 05:08:23 --> Helper loaded: my_helper
INFO - 2023-06-07 05:08:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:08:23 --> Controller Class Initialized
DEBUG - 2023-06-07 05:08:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:08:24 --> Final output sent to browser
DEBUG - 2023-06-07 05:08:24 --> Total execution time: 0.9075
INFO - 2023-06-07 05:09:12 --> Config Class Initialized
INFO - 2023-06-07 05:09:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:09:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:09:12 --> Utf8 Class Initialized
INFO - 2023-06-07 05:09:12 --> URI Class Initialized
INFO - 2023-06-07 05:09:12 --> Router Class Initialized
INFO - 2023-06-07 05:09:12 --> Output Class Initialized
INFO - 2023-06-07 05:09:12 --> Security Class Initialized
DEBUG - 2023-06-07 05:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:09:12 --> Input Class Initialized
INFO - 2023-06-07 05:09:12 --> Language Class Initialized
INFO - 2023-06-07 05:09:12 --> Language Class Initialized
INFO - 2023-06-07 05:09:12 --> Config Class Initialized
INFO - 2023-06-07 05:09:12 --> Loader Class Initialized
INFO - 2023-06-07 05:09:12 --> Helper loaded: url_helper
INFO - 2023-06-07 05:09:12 --> Helper loaded: file_helper
INFO - 2023-06-07 05:09:12 --> Helper loaded: form_helper
INFO - 2023-06-07 05:09:12 --> Helper loaded: my_helper
INFO - 2023-06-07 05:09:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:09:12 --> Controller Class Initialized
DEBUG - 2023-06-07 05:09:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:09:13 --> Final output sent to browser
DEBUG - 2023-06-07 05:09:13 --> Total execution time: 0.8489
INFO - 2023-06-07 05:09:30 --> Config Class Initialized
INFO - 2023-06-07 05:09:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:09:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:09:30 --> Utf8 Class Initialized
INFO - 2023-06-07 05:09:30 --> URI Class Initialized
INFO - 2023-06-07 05:09:30 --> Router Class Initialized
INFO - 2023-06-07 05:09:30 --> Output Class Initialized
INFO - 2023-06-07 05:09:30 --> Security Class Initialized
DEBUG - 2023-06-07 05:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:09:30 --> Input Class Initialized
INFO - 2023-06-07 05:09:30 --> Language Class Initialized
INFO - 2023-06-07 05:09:30 --> Language Class Initialized
INFO - 2023-06-07 05:09:30 --> Config Class Initialized
INFO - 2023-06-07 05:09:30 --> Loader Class Initialized
INFO - 2023-06-07 05:09:30 --> Helper loaded: url_helper
INFO - 2023-06-07 05:09:30 --> Helper loaded: file_helper
INFO - 2023-06-07 05:09:30 --> Helper loaded: form_helper
INFO - 2023-06-07 05:09:30 --> Helper loaded: my_helper
INFO - 2023-06-07 05:09:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:09:30 --> Controller Class Initialized
DEBUG - 2023-06-07 05:09:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:09:31 --> Final output sent to browser
DEBUG - 2023-06-07 05:09:31 --> Total execution time: 0.8829
INFO - 2023-06-07 05:11:09 --> Config Class Initialized
INFO - 2023-06-07 05:11:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:11:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:11:09 --> Utf8 Class Initialized
INFO - 2023-06-07 05:11:09 --> URI Class Initialized
INFO - 2023-06-07 05:11:09 --> Router Class Initialized
INFO - 2023-06-07 05:11:09 --> Output Class Initialized
INFO - 2023-06-07 05:11:09 --> Security Class Initialized
DEBUG - 2023-06-07 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:11:09 --> Input Class Initialized
INFO - 2023-06-07 05:11:09 --> Language Class Initialized
INFO - 2023-06-07 05:11:09 --> Language Class Initialized
INFO - 2023-06-07 05:11:09 --> Config Class Initialized
INFO - 2023-06-07 05:11:09 --> Loader Class Initialized
INFO - 2023-06-07 05:11:09 --> Helper loaded: url_helper
INFO - 2023-06-07 05:11:09 --> Helper loaded: file_helper
INFO - 2023-06-07 05:11:09 --> Helper loaded: form_helper
INFO - 2023-06-07 05:11:09 --> Helper loaded: my_helper
INFO - 2023-06-07 05:11:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:11:09 --> Controller Class Initialized
DEBUG - 2023-06-07 05:11:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:11:10 --> Final output sent to browser
DEBUG - 2023-06-07 05:11:10 --> Total execution time: 0.8874
INFO - 2023-06-07 05:12:00 --> Config Class Initialized
INFO - 2023-06-07 05:12:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:12:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:12:00 --> Utf8 Class Initialized
INFO - 2023-06-07 05:12:00 --> URI Class Initialized
INFO - 2023-06-07 05:12:00 --> Router Class Initialized
INFO - 2023-06-07 05:12:00 --> Output Class Initialized
INFO - 2023-06-07 05:12:00 --> Security Class Initialized
DEBUG - 2023-06-07 05:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:12:00 --> Input Class Initialized
INFO - 2023-06-07 05:12:00 --> Language Class Initialized
INFO - 2023-06-07 05:12:00 --> Language Class Initialized
INFO - 2023-06-07 05:12:00 --> Config Class Initialized
INFO - 2023-06-07 05:12:00 --> Loader Class Initialized
INFO - 2023-06-07 05:12:00 --> Helper loaded: url_helper
INFO - 2023-06-07 05:12:00 --> Helper loaded: file_helper
INFO - 2023-06-07 05:12:00 --> Helper loaded: form_helper
INFO - 2023-06-07 05:12:00 --> Helper loaded: my_helper
INFO - 2023-06-07 05:12:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:12:00 --> Controller Class Initialized
DEBUG - 2023-06-07 05:12:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:12:01 --> Final output sent to browser
DEBUG - 2023-06-07 05:12:01 --> Total execution time: 0.8963
INFO - 2023-06-07 05:12:38 --> Config Class Initialized
INFO - 2023-06-07 05:12:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:12:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:12:38 --> Utf8 Class Initialized
INFO - 2023-06-07 05:12:38 --> URI Class Initialized
INFO - 2023-06-07 05:12:38 --> Router Class Initialized
INFO - 2023-06-07 05:12:38 --> Output Class Initialized
INFO - 2023-06-07 05:12:38 --> Security Class Initialized
DEBUG - 2023-06-07 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:12:38 --> Input Class Initialized
INFO - 2023-06-07 05:12:38 --> Language Class Initialized
INFO - 2023-06-07 05:12:38 --> Language Class Initialized
INFO - 2023-06-07 05:12:38 --> Config Class Initialized
INFO - 2023-06-07 05:12:38 --> Loader Class Initialized
INFO - 2023-06-07 05:12:38 --> Helper loaded: url_helper
INFO - 2023-06-07 05:12:38 --> Helper loaded: file_helper
INFO - 2023-06-07 05:12:38 --> Helper loaded: form_helper
INFO - 2023-06-07 05:12:38 --> Helper loaded: my_helper
INFO - 2023-06-07 05:12:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:12:38 --> Controller Class Initialized
DEBUG - 2023-06-07 05:12:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:12:39 --> Final output sent to browser
DEBUG - 2023-06-07 05:12:39 --> Total execution time: 0.8574
INFO - 2023-06-07 05:13:49 --> Config Class Initialized
INFO - 2023-06-07 05:13:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:13:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:13:49 --> Utf8 Class Initialized
INFO - 2023-06-07 05:13:49 --> URI Class Initialized
INFO - 2023-06-07 05:13:49 --> Router Class Initialized
INFO - 2023-06-07 05:13:49 --> Output Class Initialized
INFO - 2023-06-07 05:13:49 --> Security Class Initialized
DEBUG - 2023-06-07 05:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:13:49 --> Input Class Initialized
INFO - 2023-06-07 05:13:49 --> Language Class Initialized
INFO - 2023-06-07 05:13:49 --> Language Class Initialized
INFO - 2023-06-07 05:13:49 --> Config Class Initialized
INFO - 2023-06-07 05:13:49 --> Loader Class Initialized
INFO - 2023-06-07 05:13:49 --> Helper loaded: url_helper
INFO - 2023-06-07 05:13:49 --> Helper loaded: file_helper
INFO - 2023-06-07 05:13:49 --> Helper loaded: form_helper
INFO - 2023-06-07 05:13:49 --> Helper loaded: my_helper
INFO - 2023-06-07 05:13:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:13:49 --> Controller Class Initialized
DEBUG - 2023-06-07 05:13:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:13:50 --> Final output sent to browser
DEBUG - 2023-06-07 05:13:50 --> Total execution time: 0.9037
INFO - 2023-06-07 05:30:23 --> Config Class Initialized
INFO - 2023-06-07 05:30:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:30:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:30:23 --> Utf8 Class Initialized
INFO - 2023-06-07 05:30:23 --> URI Class Initialized
INFO - 2023-06-07 05:30:23 --> Router Class Initialized
INFO - 2023-06-07 05:30:23 --> Output Class Initialized
INFO - 2023-06-07 05:30:23 --> Security Class Initialized
DEBUG - 2023-06-07 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:30:23 --> Input Class Initialized
INFO - 2023-06-07 05:30:23 --> Language Class Initialized
INFO - 2023-06-07 05:30:23 --> Language Class Initialized
INFO - 2023-06-07 05:30:23 --> Config Class Initialized
INFO - 2023-06-07 05:30:23 --> Loader Class Initialized
INFO - 2023-06-07 05:30:23 --> Helper loaded: url_helper
INFO - 2023-06-07 05:30:23 --> Helper loaded: file_helper
INFO - 2023-06-07 05:30:23 --> Helper loaded: form_helper
INFO - 2023-06-07 05:30:23 --> Helper loaded: my_helper
INFO - 2023-06-07 05:30:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:30:24 --> Controller Class Initialized
ERROR - 2023-06-07 05:30:24 --> Severity: Notice --> Undefined index: t_catatan_nna C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 2552
DEBUG - 2023-06-07 05:30:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:30:25 --> Final output sent to browser
DEBUG - 2023-06-07 05:30:25 --> Total execution time: 1.3047
INFO - 2023-06-07 05:31:26 --> Config Class Initialized
INFO - 2023-06-07 05:31:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:31:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:31:26 --> Utf8 Class Initialized
INFO - 2023-06-07 05:31:26 --> URI Class Initialized
INFO - 2023-06-07 05:31:26 --> Router Class Initialized
INFO - 2023-06-07 05:31:26 --> Output Class Initialized
INFO - 2023-06-07 05:31:26 --> Security Class Initialized
DEBUG - 2023-06-07 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:31:26 --> Input Class Initialized
INFO - 2023-06-07 05:31:26 --> Language Class Initialized
INFO - 2023-06-07 05:31:26 --> Language Class Initialized
INFO - 2023-06-07 05:31:26 --> Config Class Initialized
INFO - 2023-06-07 05:31:26 --> Loader Class Initialized
INFO - 2023-06-07 05:31:26 --> Helper loaded: url_helper
INFO - 2023-06-07 05:31:26 --> Helper loaded: file_helper
INFO - 2023-06-07 05:31:26 --> Helper loaded: form_helper
INFO - 2023-06-07 05:31:26 --> Helper loaded: my_helper
INFO - 2023-06-07 05:31:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:31:26 --> Controller Class Initialized
ERROR - 2023-06-07 05:31:26 --> Severity: Notice --> Undefined variable: t_catatan_nna C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\views\cetak_pts_preschool.php 45
DEBUG - 2023-06-07 05:31:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-06-07 05:31:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5282
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_x C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5605
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5641
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-06-07 05:31:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined index: td_y C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5405
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-06-07 05:31:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5273
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5600
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5606
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5607
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5614
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5622
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5623
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5704
ERROR - 2023-06-07 05:31:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-06-07 05:31:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 5396
ERROR - 2023-06-07 05:31:27 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 2950
ERROR - 2023-06-07 05:31:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\core\Common.php 570
INFO - 2023-06-07 05:32:36 --> Config Class Initialized
INFO - 2023-06-07 05:32:36 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:32:36 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:32:36 --> Utf8 Class Initialized
INFO - 2023-06-07 05:32:36 --> URI Class Initialized
INFO - 2023-06-07 05:32:36 --> Router Class Initialized
INFO - 2023-06-07 05:32:36 --> Output Class Initialized
INFO - 2023-06-07 05:32:36 --> Security Class Initialized
DEBUG - 2023-06-07 05:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:32:36 --> Input Class Initialized
INFO - 2023-06-07 05:32:36 --> Language Class Initialized
INFO - 2023-06-07 05:32:36 --> Language Class Initialized
INFO - 2023-06-07 05:32:36 --> Config Class Initialized
INFO - 2023-06-07 05:32:36 --> Loader Class Initialized
INFO - 2023-06-07 05:32:36 --> Helper loaded: url_helper
INFO - 2023-06-07 05:32:36 --> Helper loaded: file_helper
INFO - 2023-06-07 05:32:36 --> Helper loaded: form_helper
INFO - 2023-06-07 05:32:36 --> Helper loaded: my_helper
INFO - 2023-06-07 05:32:36 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:32:36 --> Controller Class Initialized
DEBUG - 2023-06-07 05:32:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:32:37 --> Final output sent to browser
DEBUG - 2023-06-07 05:32:37 --> Total execution time: 1.2811
INFO - 2023-06-07 05:34:07 --> Config Class Initialized
INFO - 2023-06-07 05:34:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:34:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:34:07 --> Utf8 Class Initialized
INFO - 2023-06-07 05:34:07 --> URI Class Initialized
INFO - 2023-06-07 05:34:07 --> Router Class Initialized
INFO - 2023-06-07 05:34:07 --> Output Class Initialized
INFO - 2023-06-07 05:34:07 --> Security Class Initialized
DEBUG - 2023-06-07 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:34:07 --> Input Class Initialized
INFO - 2023-06-07 05:34:07 --> Language Class Initialized
INFO - 2023-06-07 05:34:07 --> Language Class Initialized
INFO - 2023-06-07 05:34:07 --> Config Class Initialized
INFO - 2023-06-07 05:34:07 --> Loader Class Initialized
INFO - 2023-06-07 05:34:07 --> Helper loaded: url_helper
INFO - 2023-06-07 05:34:07 --> Helper loaded: file_helper
INFO - 2023-06-07 05:34:07 --> Helper loaded: form_helper
INFO - 2023-06-07 05:34:07 --> Helper loaded: my_helper
INFO - 2023-06-07 05:34:07 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:34:07 --> Controller Class Initialized
DEBUG - 2023-06-07 05:34:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:34:09 --> Final output sent to browser
DEBUG - 2023-06-07 05:34:09 --> Total execution time: 1.1390
INFO - 2023-06-07 05:35:13 --> Config Class Initialized
INFO - 2023-06-07 05:35:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:35:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:35:13 --> Utf8 Class Initialized
INFO - 2023-06-07 05:35:13 --> URI Class Initialized
INFO - 2023-06-07 05:35:13 --> Router Class Initialized
INFO - 2023-06-07 05:35:13 --> Output Class Initialized
INFO - 2023-06-07 05:35:13 --> Security Class Initialized
DEBUG - 2023-06-07 05:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:35:13 --> Input Class Initialized
INFO - 2023-06-07 05:35:13 --> Language Class Initialized
INFO - 2023-06-07 05:35:14 --> Language Class Initialized
INFO - 2023-06-07 05:35:14 --> Config Class Initialized
INFO - 2023-06-07 05:35:14 --> Loader Class Initialized
INFO - 2023-06-07 05:35:14 --> Helper loaded: url_helper
INFO - 2023-06-07 05:35:14 --> Helper loaded: file_helper
INFO - 2023-06-07 05:35:14 --> Helper loaded: form_helper
INFO - 2023-06-07 05:35:14 --> Helper loaded: my_helper
INFO - 2023-06-07 05:35:14 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:35:14 --> Controller Class Initialized
DEBUG - 2023-06-07 05:35:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:35:15 --> Final output sent to browser
DEBUG - 2023-06-07 05:35:15 --> Total execution time: 1.1276
INFO - 2023-06-07 05:37:35 --> Config Class Initialized
INFO - 2023-06-07 05:37:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:37:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:37:35 --> Utf8 Class Initialized
INFO - 2023-06-07 05:37:35 --> URI Class Initialized
INFO - 2023-06-07 05:37:35 --> Router Class Initialized
INFO - 2023-06-07 05:37:35 --> Output Class Initialized
INFO - 2023-06-07 05:37:35 --> Security Class Initialized
DEBUG - 2023-06-07 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:37:35 --> Input Class Initialized
INFO - 2023-06-07 05:37:35 --> Language Class Initialized
INFO - 2023-06-07 05:37:35 --> Language Class Initialized
INFO - 2023-06-07 05:37:35 --> Config Class Initialized
INFO - 2023-06-07 05:37:35 --> Loader Class Initialized
INFO - 2023-06-07 05:37:35 --> Helper loaded: url_helper
INFO - 2023-06-07 05:37:35 --> Helper loaded: file_helper
INFO - 2023-06-07 05:37:35 --> Helper loaded: form_helper
INFO - 2023-06-07 05:37:35 --> Helper loaded: my_helper
INFO - 2023-06-07 05:37:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:37:35 --> Controller Class Initialized
DEBUG - 2023-06-07 05:37:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:37:37 --> Final output sent to browser
DEBUG - 2023-06-07 05:37:37 --> Total execution time: 1.2705
INFO - 2023-06-07 05:38:46 --> Config Class Initialized
INFO - 2023-06-07 05:38:46 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:38:46 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:38:46 --> Utf8 Class Initialized
INFO - 2023-06-07 05:38:46 --> URI Class Initialized
INFO - 2023-06-07 05:38:46 --> Router Class Initialized
INFO - 2023-06-07 05:38:46 --> Output Class Initialized
INFO - 2023-06-07 05:38:46 --> Security Class Initialized
DEBUG - 2023-06-07 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:38:46 --> Input Class Initialized
INFO - 2023-06-07 05:38:46 --> Language Class Initialized
INFO - 2023-06-07 05:38:46 --> Language Class Initialized
INFO - 2023-06-07 05:38:46 --> Config Class Initialized
INFO - 2023-06-07 05:38:46 --> Loader Class Initialized
INFO - 2023-06-07 05:38:46 --> Helper loaded: url_helper
INFO - 2023-06-07 05:38:46 --> Helper loaded: file_helper
INFO - 2023-06-07 05:38:46 --> Helper loaded: form_helper
INFO - 2023-06-07 05:38:46 --> Helper loaded: my_helper
INFO - 2023-06-07 05:38:46 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:38:46 --> Controller Class Initialized
DEBUG - 2023-06-07 05:38:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:38:47 --> Final output sent to browser
DEBUG - 2023-06-07 05:38:47 --> Total execution time: 1.1853
INFO - 2023-06-07 05:39:00 --> Config Class Initialized
INFO - 2023-06-07 05:39:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:39:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:39:00 --> Utf8 Class Initialized
INFO - 2023-06-07 05:39:00 --> URI Class Initialized
INFO - 2023-06-07 05:39:00 --> Router Class Initialized
INFO - 2023-06-07 05:39:00 --> Output Class Initialized
INFO - 2023-06-07 05:39:00 --> Security Class Initialized
DEBUG - 2023-06-07 05:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:39:00 --> Input Class Initialized
INFO - 2023-06-07 05:39:00 --> Language Class Initialized
INFO - 2023-06-07 05:39:00 --> Language Class Initialized
INFO - 2023-06-07 05:39:00 --> Config Class Initialized
INFO - 2023-06-07 05:39:00 --> Loader Class Initialized
INFO - 2023-06-07 05:39:00 --> Helper loaded: url_helper
INFO - 2023-06-07 05:39:00 --> Helper loaded: file_helper
INFO - 2023-06-07 05:39:00 --> Helper loaded: form_helper
INFO - 2023-06-07 05:39:00 --> Helper loaded: my_helper
INFO - 2023-06-07 05:39:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:39:00 --> Controller Class Initialized
DEBUG - 2023-06-07 05:39:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 05:39:01 --> Final output sent to browser
DEBUG - 2023-06-07 05:39:01 --> Total execution time: 1.1065
INFO - 2023-06-07 05:39:08 --> Config Class Initialized
INFO - 2023-06-07 05:39:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:39:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:39:08 --> Utf8 Class Initialized
INFO - 2023-06-07 05:39:08 --> URI Class Initialized
INFO - 2023-06-07 05:39:08 --> Router Class Initialized
INFO - 2023-06-07 05:39:08 --> Output Class Initialized
INFO - 2023-06-07 05:39:08 --> Security Class Initialized
DEBUG - 2023-06-07 05:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:39:08 --> Input Class Initialized
INFO - 2023-06-07 05:39:08 --> Language Class Initialized
INFO - 2023-06-07 05:39:08 --> Language Class Initialized
INFO - 2023-06-07 05:39:08 --> Config Class Initialized
INFO - 2023-06-07 05:39:08 --> Loader Class Initialized
INFO - 2023-06-07 05:39:08 --> Helper loaded: url_helper
INFO - 2023-06-07 05:39:08 --> Helper loaded: file_helper
INFO - 2023-06-07 05:39:08 --> Helper loaded: form_helper
INFO - 2023-06-07 05:39:08 --> Helper loaded: my_helper
INFO - 2023-06-07 05:39:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:39:08 --> Controller Class Initialized
DEBUG - 2023-06-07 05:39:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:39:09 --> Final output sent to browser
DEBUG - 2023-06-07 05:39:09 --> Total execution time: 1.0713
INFO - 2023-06-07 05:39:59 --> Config Class Initialized
INFO - 2023-06-07 05:39:59 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:39:59 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:39:59 --> Utf8 Class Initialized
INFO - 2023-06-07 05:39:59 --> URI Class Initialized
INFO - 2023-06-07 05:39:59 --> Router Class Initialized
INFO - 2023-06-07 05:39:59 --> Output Class Initialized
INFO - 2023-06-07 05:39:59 --> Security Class Initialized
DEBUG - 2023-06-07 05:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:39:59 --> Input Class Initialized
INFO - 2023-06-07 05:39:59 --> Language Class Initialized
INFO - 2023-06-07 05:39:59 --> Language Class Initialized
INFO - 2023-06-07 05:39:59 --> Config Class Initialized
INFO - 2023-06-07 05:39:59 --> Loader Class Initialized
INFO - 2023-06-07 05:39:59 --> Helper loaded: url_helper
INFO - 2023-06-07 05:39:59 --> Helper loaded: file_helper
INFO - 2023-06-07 05:39:59 --> Helper loaded: form_helper
INFO - 2023-06-07 05:39:59 --> Helper loaded: my_helper
INFO - 2023-06-07 05:39:59 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:39:59 --> Controller Class Initialized
DEBUG - 2023-06-07 05:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:39:59 --> Final output sent to browser
DEBUG - 2023-06-07 05:39:59 --> Total execution time: 0.0483
INFO - 2023-06-07 05:40:14 --> Config Class Initialized
INFO - 2023-06-07 05:40:14 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:40:14 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:40:14 --> Utf8 Class Initialized
INFO - 2023-06-07 05:40:14 --> URI Class Initialized
INFO - 2023-06-07 05:40:14 --> Router Class Initialized
INFO - 2023-06-07 05:40:14 --> Output Class Initialized
INFO - 2023-06-07 05:40:14 --> Security Class Initialized
DEBUG - 2023-06-07 05:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:40:14 --> Input Class Initialized
INFO - 2023-06-07 05:40:14 --> Language Class Initialized
INFO - 2023-06-07 05:40:14 --> Language Class Initialized
INFO - 2023-06-07 05:40:14 --> Config Class Initialized
INFO - 2023-06-07 05:40:14 --> Loader Class Initialized
INFO - 2023-06-07 05:40:14 --> Helper loaded: url_helper
INFO - 2023-06-07 05:40:14 --> Helper loaded: file_helper
INFO - 2023-06-07 05:40:14 --> Helper loaded: form_helper
INFO - 2023-06-07 05:40:14 --> Helper loaded: my_helper
INFO - 2023-06-07 05:40:14 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:40:14 --> Controller Class Initialized
ERROR - 2023-06-07 05:40:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = 'Akila needs encouragement in
participating daily dua in the
classroom also for murojaah time.
She still needs to be more focused
on reading iqra when btq. She also
need more practice in memorizing
doa masuk kamar mandi, doa keluar
kamar mandi, doa bangun tidur. Akila
needs practice to memorize hijaiyah
letters. She needs more practice to
recognize halal and haram food.
Akila also needs more practice to tidy
up her prayer set. ' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 05:40:14 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 05:40:24 --> Config Class Initialized
INFO - 2023-06-07 05:40:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:40:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:40:24 --> Utf8 Class Initialized
INFO - 2023-06-07 05:40:24 --> URI Class Initialized
INFO - 2023-06-07 05:40:24 --> Router Class Initialized
INFO - 2023-06-07 05:40:24 --> Output Class Initialized
INFO - 2023-06-07 05:40:24 --> Security Class Initialized
DEBUG - 2023-06-07 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:40:24 --> Input Class Initialized
INFO - 2023-06-07 05:40:24 --> Language Class Initialized
ERROR - 2023-06-07 05:40:24 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:40:27 --> Config Class Initialized
INFO - 2023-06-07 05:40:27 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:40:27 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:40:27 --> Utf8 Class Initialized
INFO - 2023-06-07 05:40:27 --> URI Class Initialized
INFO - 2023-06-07 05:40:27 --> Router Class Initialized
INFO - 2023-06-07 05:40:27 --> Output Class Initialized
INFO - 2023-06-07 05:40:27 --> Security Class Initialized
DEBUG - 2023-06-07 05:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:40:27 --> Input Class Initialized
INFO - 2023-06-07 05:40:27 --> Language Class Initialized
INFO - 2023-06-07 05:40:27 --> Language Class Initialized
INFO - 2023-06-07 05:40:27 --> Config Class Initialized
INFO - 2023-06-07 05:40:27 --> Loader Class Initialized
INFO - 2023-06-07 05:40:27 --> Helper loaded: url_helper
INFO - 2023-06-07 05:40:27 --> Helper loaded: file_helper
INFO - 2023-06-07 05:40:27 --> Helper loaded: form_helper
INFO - 2023-06-07 05:40:27 --> Helper loaded: my_helper
INFO - 2023-06-07 05:40:27 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:40:27 --> Controller Class Initialized
DEBUG - 2023-06-07 05:40:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:40:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:40:27 --> Final output sent to browser
DEBUG - 2023-06-07 05:40:27 --> Total execution time: 0.0611
INFO - 2023-06-07 05:40:27 --> Config Class Initialized
INFO - 2023-06-07 05:40:27 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:40:27 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:40:27 --> Utf8 Class Initialized
INFO - 2023-06-07 05:40:27 --> URI Class Initialized
INFO - 2023-06-07 05:40:27 --> Router Class Initialized
INFO - 2023-06-07 05:40:27 --> Output Class Initialized
INFO - 2023-06-07 05:40:27 --> Security Class Initialized
DEBUG - 2023-06-07 05:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:40:27 --> Input Class Initialized
INFO - 2023-06-07 05:40:27 --> Language Class Initialized
ERROR - 2023-06-07 05:40:27 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:40:50 --> Config Class Initialized
INFO - 2023-06-07 05:40:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:40:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:40:50 --> Utf8 Class Initialized
INFO - 2023-06-07 05:40:50 --> URI Class Initialized
INFO - 2023-06-07 05:40:50 --> Router Class Initialized
INFO - 2023-06-07 05:40:50 --> Output Class Initialized
INFO - 2023-06-07 05:40:50 --> Security Class Initialized
DEBUG - 2023-06-07 05:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:40:50 --> Input Class Initialized
INFO - 2023-06-07 05:40:50 --> Language Class Initialized
INFO - 2023-06-07 05:40:50 --> Language Class Initialized
INFO - 2023-06-07 05:40:50 --> Config Class Initialized
INFO - 2023-06-07 05:40:50 --> Loader Class Initialized
INFO - 2023-06-07 05:40:50 --> Helper loaded: url_helper
INFO - 2023-06-07 05:40:50 --> Helper loaded: file_helper
INFO - 2023-06-07 05:40:50 --> Helper loaded: form_helper
INFO - 2023-06-07 05:40:50 --> Helper loaded: my_helper
INFO - 2023-06-07 05:40:50 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:40:50 --> Controller Class Initialized
ERROR - 2023-06-07 05:40:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance.', catatan_final = 'Akila needs encouragement in
participating daily dua in the
classroom also for murojaah time.
She still needs to be more focused
on reading iqra when btq. She also
need more practice in memorizing
doa masuk kamar mandi, doa keluar
kamar mandi, doa bangun tidur. Akila
needs practice to memorize hijaiyah
letters. She needs more practice to
recognize halal and haram food.
Akila also needs more practice to tidy
up her prayer set. ' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 05:40:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 05:43:07 --> Config Class Initialized
INFO - 2023-06-07 05:43:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:43:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:43:07 --> Utf8 Class Initialized
INFO - 2023-06-07 05:43:07 --> URI Class Initialized
INFO - 2023-06-07 05:43:07 --> Router Class Initialized
INFO - 2023-06-07 05:43:07 --> Output Class Initialized
INFO - 2023-06-07 05:43:07 --> Security Class Initialized
DEBUG - 2023-06-07 05:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:43:07 --> Input Class Initialized
INFO - 2023-06-07 05:43:07 --> Language Class Initialized
INFO - 2023-06-07 05:43:07 --> Language Class Initialized
INFO - 2023-06-07 05:43:07 --> Config Class Initialized
INFO - 2023-06-07 05:43:07 --> Loader Class Initialized
INFO - 2023-06-07 05:43:07 --> Helper loaded: url_helper
INFO - 2023-06-07 05:43:07 --> Helper loaded: file_helper
INFO - 2023-06-07 05:43:07 --> Helper loaded: form_helper
INFO - 2023-06-07 05:43:07 --> Helper loaded: my_helper
INFO - 2023-06-07 05:43:07 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:43:07 --> Controller Class Initialized
DEBUG - 2023-06-07 05:43:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:43:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:43:07 --> Final output sent to browser
DEBUG - 2023-06-07 05:43:07 --> Total execution time: 0.0749
INFO - 2023-06-07 05:43:07 --> Config Class Initialized
INFO - 2023-06-07 05:43:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:43:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:43:07 --> Utf8 Class Initialized
INFO - 2023-06-07 05:43:07 --> URI Class Initialized
INFO - 2023-06-07 05:43:07 --> Router Class Initialized
INFO - 2023-06-07 05:43:07 --> Output Class Initialized
INFO - 2023-06-07 05:43:07 --> Security Class Initialized
DEBUG - 2023-06-07 05:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:43:07 --> Input Class Initialized
INFO - 2023-06-07 05:43:07 --> Language Class Initialized
ERROR - 2023-06-07 05:43:07 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:43:13 --> Config Class Initialized
INFO - 2023-06-07 05:43:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:43:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:43:13 --> Utf8 Class Initialized
INFO - 2023-06-07 05:43:13 --> URI Class Initialized
INFO - 2023-06-07 05:43:13 --> Router Class Initialized
INFO - 2023-06-07 05:43:13 --> Output Class Initialized
INFO - 2023-06-07 05:43:13 --> Security Class Initialized
DEBUG - 2023-06-07 05:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:43:13 --> Input Class Initialized
INFO - 2023-06-07 05:43:13 --> Language Class Initialized
INFO - 2023-06-07 05:43:13 --> Language Class Initialized
INFO - 2023-06-07 05:43:13 --> Config Class Initialized
INFO - 2023-06-07 05:43:13 --> Loader Class Initialized
INFO - 2023-06-07 05:43:13 --> Helper loaded: url_helper
INFO - 2023-06-07 05:43:13 --> Helper loaded: file_helper
INFO - 2023-06-07 05:43:13 --> Helper loaded: form_helper
INFO - 2023-06-07 05:43:13 --> Helper loaded: my_helper
INFO - 2023-06-07 05:43:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:43:13 --> Controller Class Initialized
ERROR - 2023-06-07 05:43:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'dsadsadsadsadsad' WHERE ta = '20232' AND id_siswa = '531'' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = ''', catatan_final = 'dsadsadsadsadsad' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 05:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 05:47:18 --> Config Class Initialized
INFO - 2023-06-07 05:47:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:18 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:18 --> URI Class Initialized
INFO - 2023-06-07 05:47:18 --> Router Class Initialized
INFO - 2023-06-07 05:47:18 --> Output Class Initialized
INFO - 2023-06-07 05:47:18 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:18 --> Input Class Initialized
INFO - 2023-06-07 05:47:18 --> Language Class Initialized
INFO - 2023-06-07 05:47:18 --> Language Class Initialized
INFO - 2023-06-07 05:47:18 --> Config Class Initialized
INFO - 2023-06-07 05:47:18 --> Loader Class Initialized
INFO - 2023-06-07 05:47:18 --> Helper loaded: url_helper
INFO - 2023-06-07 05:47:18 --> Helper loaded: file_helper
INFO - 2023-06-07 05:47:18 --> Helper loaded: form_helper
INFO - 2023-06-07 05:47:18 --> Helper loaded: my_helper
INFO - 2023-06-07 05:47:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:47:18 --> Controller Class Initialized
DEBUG - 2023-06-07 05:47:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:47:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:47:18 --> Final output sent to browser
DEBUG - 2023-06-07 05:47:18 --> Total execution time: 0.0590
INFO - 2023-06-07 05:47:22 --> Config Class Initialized
INFO - 2023-06-07 05:47:22 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:22 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:22 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:22 --> URI Class Initialized
INFO - 2023-06-07 05:47:22 --> Router Class Initialized
INFO - 2023-06-07 05:47:22 --> Output Class Initialized
INFO - 2023-06-07 05:47:22 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:22 --> Input Class Initialized
INFO - 2023-06-07 05:47:22 --> Language Class Initialized
INFO - 2023-06-07 05:47:22 --> Language Class Initialized
INFO - 2023-06-07 05:47:22 --> Config Class Initialized
INFO - 2023-06-07 05:47:22 --> Loader Class Initialized
INFO - 2023-06-07 05:47:22 --> Helper loaded: url_helper
INFO - 2023-06-07 05:47:22 --> Helper loaded: file_helper
INFO - 2023-06-07 05:47:22 --> Helper loaded: form_helper
INFO - 2023-06-07 05:47:22 --> Helper loaded: my_helper
INFO - 2023-06-07 05:47:22 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:47:22 --> Controller Class Initialized
ERROR - 2023-06-07 05:47:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = 'dsadsadsadsadsad' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 05:47:22 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 05:47:26 --> Config Class Initialized
INFO - 2023-06-07 05:47:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:26 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:26 --> URI Class Initialized
INFO - 2023-06-07 05:47:26 --> Router Class Initialized
INFO - 2023-06-07 05:47:26 --> Output Class Initialized
INFO - 2023-06-07 05:47:26 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:26 --> Input Class Initialized
INFO - 2023-06-07 05:47:26 --> Language Class Initialized
ERROR - 2023-06-07 05:47:26 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:47:36 --> Config Class Initialized
INFO - 2023-06-07 05:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:36 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:36 --> URI Class Initialized
INFO - 2023-06-07 05:47:36 --> Router Class Initialized
INFO - 2023-06-07 05:47:36 --> Output Class Initialized
INFO - 2023-06-07 05:47:36 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:36 --> Input Class Initialized
INFO - 2023-06-07 05:47:36 --> Language Class Initialized
INFO - 2023-06-07 05:47:36 --> Language Class Initialized
INFO - 2023-06-07 05:47:36 --> Config Class Initialized
INFO - 2023-06-07 05:47:36 --> Loader Class Initialized
INFO - 2023-06-07 05:47:36 --> Helper loaded: url_helper
INFO - 2023-06-07 05:47:36 --> Helper loaded: file_helper
INFO - 2023-06-07 05:47:36 --> Helper loaded: form_helper
INFO - 2023-06-07 05:47:36 --> Helper loaded: my_helper
INFO - 2023-06-07 05:47:36 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:47:36 --> Controller Class Initialized
DEBUG - 2023-06-07 05:47:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:47:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:47:36 --> Final output sent to browser
DEBUG - 2023-06-07 05:47:36 --> Total execution time: 0.0547
INFO - 2023-06-07 05:47:36 --> Config Class Initialized
INFO - 2023-06-07 05:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:36 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:36 --> URI Class Initialized
INFO - 2023-06-07 05:47:36 --> Router Class Initialized
INFO - 2023-06-07 05:47:36 --> Output Class Initialized
INFO - 2023-06-07 05:47:36 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:36 --> Input Class Initialized
INFO - 2023-06-07 05:47:36 --> Language Class Initialized
ERROR - 2023-06-07 05:47:36 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:47:47 --> Config Class Initialized
INFO - 2023-06-07 05:47:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:47:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:47:47 --> Utf8 Class Initialized
INFO - 2023-06-07 05:47:47 --> URI Class Initialized
INFO - 2023-06-07 05:47:47 --> Router Class Initialized
INFO - 2023-06-07 05:47:47 --> Output Class Initialized
INFO - 2023-06-07 05:47:47 --> Security Class Initialized
DEBUG - 2023-06-07 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:47:47 --> Input Class Initialized
INFO - 2023-06-07 05:47:47 --> Language Class Initialized
INFO - 2023-06-07 05:47:47 --> Language Class Initialized
INFO - 2023-06-07 05:47:47 --> Config Class Initialized
INFO - 2023-06-07 05:47:47 --> Loader Class Initialized
INFO - 2023-06-07 05:47:47 --> Helper loaded: url_helper
INFO - 2023-06-07 05:47:47 --> Helper loaded: file_helper
INFO - 2023-06-07 05:47:47 --> Helper loaded: form_helper
INFO - 2023-06-07 05:47:47 --> Helper loaded: my_helper
INFO - 2023-06-07 05:47:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:47:47 --> Controller Class Initialized
ERROR - 2023-06-07 05:47:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'dsadsadsadsadsad' WHERE ta = '20232' AND id_siswa = '531'' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = ''', catatan_final = 'dsadsadsadsadsad' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 05:47:47 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 05:51:13 --> Config Class Initialized
INFO - 2023-06-07 05:51:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:51:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:51:13 --> Utf8 Class Initialized
INFO - 2023-06-07 05:51:13 --> URI Class Initialized
INFO - 2023-06-07 05:51:13 --> Router Class Initialized
INFO - 2023-06-07 05:51:13 --> Output Class Initialized
INFO - 2023-06-07 05:51:13 --> Security Class Initialized
DEBUG - 2023-06-07 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:51:13 --> Input Class Initialized
INFO - 2023-06-07 05:51:13 --> Language Class Initialized
INFO - 2023-06-07 05:51:13 --> Language Class Initialized
INFO - 2023-06-07 05:51:13 --> Config Class Initialized
INFO - 2023-06-07 05:51:13 --> Loader Class Initialized
INFO - 2023-06-07 05:51:13 --> Helper loaded: url_helper
INFO - 2023-06-07 05:51:13 --> Helper loaded: file_helper
INFO - 2023-06-07 05:51:13 --> Helper loaded: form_helper
INFO - 2023-06-07 05:51:13 --> Helper loaded: my_helper
INFO - 2023-06-07 05:51:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:51:13 --> Controller Class Initialized
DEBUG - 2023-06-07 05:51:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 05:51:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 05:51:13 --> Final output sent to browser
DEBUG - 2023-06-07 05:51:13 --> Total execution time: 0.0742
INFO - 2023-06-07 05:51:13 --> Config Class Initialized
INFO - 2023-06-07 05:51:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:51:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:51:13 --> Utf8 Class Initialized
INFO - 2023-06-07 05:51:13 --> URI Class Initialized
INFO - 2023-06-07 05:51:13 --> Router Class Initialized
INFO - 2023-06-07 05:51:13 --> Output Class Initialized
INFO - 2023-06-07 05:51:13 --> Security Class Initialized
DEBUG - 2023-06-07 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:51:13 --> Input Class Initialized
INFO - 2023-06-07 05:51:13 --> Language Class Initialized
ERROR - 2023-06-07 05:51:13 --> 404 Page Not Found: /index
INFO - 2023-06-07 05:51:23 --> Config Class Initialized
INFO - 2023-06-07 05:51:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:51:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:51:23 --> Utf8 Class Initialized
INFO - 2023-06-07 05:51:23 --> URI Class Initialized
INFO - 2023-06-07 05:51:23 --> Router Class Initialized
INFO - 2023-06-07 05:51:23 --> Output Class Initialized
INFO - 2023-06-07 05:51:23 --> Security Class Initialized
DEBUG - 2023-06-07 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:51:23 --> Input Class Initialized
INFO - 2023-06-07 05:51:23 --> Language Class Initialized
INFO - 2023-06-07 05:51:23 --> Language Class Initialized
INFO - 2023-06-07 05:51:23 --> Config Class Initialized
INFO - 2023-06-07 05:51:23 --> Loader Class Initialized
INFO - 2023-06-07 05:51:23 --> Helper loaded: url_helper
INFO - 2023-06-07 05:51:23 --> Helper loaded: file_helper
INFO - 2023-06-07 05:51:23 --> Helper loaded: form_helper
INFO - 2023-06-07 05:51:23 --> Helper loaded: my_helper
INFO - 2023-06-07 05:51:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:51:23 --> Controller Class Initialized
DEBUG - 2023-06-07 05:51:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:51:24 --> Final output sent to browser
DEBUG - 2023-06-07 05:51:24 --> Total execution time: 1.1274
INFO - 2023-06-07 05:54:00 --> Config Class Initialized
INFO - 2023-06-07 05:54:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:54:01 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:54:01 --> Utf8 Class Initialized
INFO - 2023-06-07 05:54:01 --> URI Class Initialized
INFO - 2023-06-07 05:54:01 --> Router Class Initialized
INFO - 2023-06-07 05:54:01 --> Output Class Initialized
INFO - 2023-06-07 05:54:01 --> Security Class Initialized
DEBUG - 2023-06-07 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:54:01 --> Input Class Initialized
INFO - 2023-06-07 05:54:01 --> Language Class Initialized
INFO - 2023-06-07 05:54:01 --> Language Class Initialized
INFO - 2023-06-07 05:54:01 --> Config Class Initialized
INFO - 2023-06-07 05:54:01 --> Loader Class Initialized
INFO - 2023-06-07 05:54:01 --> Helper loaded: url_helper
INFO - 2023-06-07 05:54:01 --> Helper loaded: file_helper
INFO - 2023-06-07 05:54:01 --> Helper loaded: form_helper
INFO - 2023-06-07 05:54:01 --> Helper loaded: my_helper
INFO - 2023-06-07 05:54:01 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:54:01 --> Controller Class Initialized
DEBUG - 2023-06-07 05:54:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:54:02 --> Final output sent to browser
DEBUG - 2023-06-07 05:54:02 --> Total execution time: 1.1579
INFO - 2023-06-07 05:56:00 --> Config Class Initialized
INFO - 2023-06-07 05:56:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:56:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:56:00 --> Utf8 Class Initialized
INFO - 2023-06-07 05:56:00 --> URI Class Initialized
INFO - 2023-06-07 05:56:00 --> Router Class Initialized
INFO - 2023-06-07 05:56:00 --> Output Class Initialized
INFO - 2023-06-07 05:56:00 --> Security Class Initialized
DEBUG - 2023-06-07 05:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:56:00 --> Input Class Initialized
INFO - 2023-06-07 05:56:00 --> Language Class Initialized
INFO - 2023-06-07 05:56:00 --> Language Class Initialized
INFO - 2023-06-07 05:56:00 --> Config Class Initialized
INFO - 2023-06-07 05:56:00 --> Loader Class Initialized
INFO - 2023-06-07 05:56:00 --> Helper loaded: url_helper
INFO - 2023-06-07 05:56:00 --> Helper loaded: file_helper
INFO - 2023-06-07 05:56:00 --> Helper loaded: form_helper
INFO - 2023-06-07 05:56:00 --> Helper loaded: my_helper
INFO - 2023-06-07 05:56:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:56:00 --> Controller Class Initialized
DEBUG - 2023-06-07 05:56:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:56:02 --> Final output sent to browser
DEBUG - 2023-06-07 05:56:02 --> Total execution time: 1.3419
INFO - 2023-06-07 05:56:40 --> Config Class Initialized
INFO - 2023-06-07 05:56:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:56:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:56:40 --> Utf8 Class Initialized
INFO - 2023-06-07 05:56:40 --> URI Class Initialized
INFO - 2023-06-07 05:56:40 --> Router Class Initialized
INFO - 2023-06-07 05:56:40 --> Output Class Initialized
INFO - 2023-06-07 05:56:40 --> Security Class Initialized
DEBUG - 2023-06-07 05:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:56:40 --> Input Class Initialized
INFO - 2023-06-07 05:56:40 --> Language Class Initialized
INFO - 2023-06-07 05:56:40 --> Language Class Initialized
INFO - 2023-06-07 05:56:40 --> Config Class Initialized
INFO - 2023-06-07 05:56:40 --> Loader Class Initialized
INFO - 2023-06-07 05:56:40 --> Helper loaded: url_helper
INFO - 2023-06-07 05:56:40 --> Helper loaded: file_helper
INFO - 2023-06-07 05:56:40 --> Helper loaded: form_helper
INFO - 2023-06-07 05:56:40 --> Helper loaded: my_helper
INFO - 2023-06-07 05:56:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:56:40 --> Controller Class Initialized
DEBUG - 2023-06-07 05:56:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:56:42 --> Final output sent to browser
DEBUG - 2023-06-07 05:56:42 --> Total execution time: 1.1416
INFO - 2023-06-07 05:58:13 --> Config Class Initialized
INFO - 2023-06-07 05:58:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:58:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:58:13 --> Utf8 Class Initialized
INFO - 2023-06-07 05:58:13 --> URI Class Initialized
INFO - 2023-06-07 05:58:13 --> Router Class Initialized
INFO - 2023-06-07 05:58:13 --> Output Class Initialized
INFO - 2023-06-07 05:58:13 --> Security Class Initialized
DEBUG - 2023-06-07 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:58:13 --> Input Class Initialized
INFO - 2023-06-07 05:58:13 --> Language Class Initialized
INFO - 2023-06-07 05:58:13 --> Language Class Initialized
INFO - 2023-06-07 05:58:13 --> Config Class Initialized
INFO - 2023-06-07 05:58:13 --> Loader Class Initialized
INFO - 2023-06-07 05:58:13 --> Helper loaded: url_helper
INFO - 2023-06-07 05:58:13 --> Helper loaded: file_helper
INFO - 2023-06-07 05:58:13 --> Helper loaded: form_helper
INFO - 2023-06-07 05:58:13 --> Helper loaded: my_helper
INFO - 2023-06-07 05:58:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:58:13 --> Controller Class Initialized
DEBUG - 2023-06-07 05:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:58:15 --> Final output sent to browser
DEBUG - 2023-06-07 05:58:15 --> Total execution time: 1.1539
INFO - 2023-06-07 05:59:14 --> Config Class Initialized
INFO - 2023-06-07 05:59:14 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:59:14 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:59:14 --> Utf8 Class Initialized
INFO - 2023-06-07 05:59:14 --> URI Class Initialized
INFO - 2023-06-07 05:59:14 --> Router Class Initialized
INFO - 2023-06-07 05:59:14 --> Output Class Initialized
INFO - 2023-06-07 05:59:14 --> Security Class Initialized
DEBUG - 2023-06-07 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:59:14 --> Input Class Initialized
INFO - 2023-06-07 05:59:15 --> Language Class Initialized
INFO - 2023-06-07 05:59:15 --> Language Class Initialized
INFO - 2023-06-07 05:59:15 --> Config Class Initialized
INFO - 2023-06-07 05:59:15 --> Loader Class Initialized
INFO - 2023-06-07 05:59:15 --> Helper loaded: url_helper
INFO - 2023-06-07 05:59:15 --> Helper loaded: file_helper
INFO - 2023-06-07 05:59:15 --> Helper loaded: form_helper
INFO - 2023-06-07 05:59:15 --> Helper loaded: my_helper
INFO - 2023-06-07 05:59:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:59:15 --> Controller Class Initialized
DEBUG - 2023-06-07 05:59:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:59:16 --> Final output sent to browser
DEBUG - 2023-06-07 05:59:16 --> Total execution time: 1.1764
INFO - 2023-06-07 05:59:38 --> Config Class Initialized
INFO - 2023-06-07 05:59:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 05:59:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 05:59:38 --> Utf8 Class Initialized
INFO - 2023-06-07 05:59:38 --> URI Class Initialized
INFO - 2023-06-07 05:59:38 --> Router Class Initialized
INFO - 2023-06-07 05:59:38 --> Output Class Initialized
INFO - 2023-06-07 05:59:38 --> Security Class Initialized
DEBUG - 2023-06-07 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 05:59:38 --> Input Class Initialized
INFO - 2023-06-07 05:59:38 --> Language Class Initialized
INFO - 2023-06-07 05:59:38 --> Language Class Initialized
INFO - 2023-06-07 05:59:38 --> Config Class Initialized
INFO - 2023-06-07 05:59:38 --> Loader Class Initialized
INFO - 2023-06-07 05:59:38 --> Helper loaded: url_helper
INFO - 2023-06-07 05:59:38 --> Helper loaded: file_helper
INFO - 2023-06-07 05:59:38 --> Helper loaded: form_helper
INFO - 2023-06-07 05:59:38 --> Helper loaded: my_helper
INFO - 2023-06-07 05:59:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 05:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 05:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 05:59:38 --> Controller Class Initialized
DEBUG - 2023-06-07 05:59:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 05:59:39 --> Final output sent to browser
DEBUG - 2023-06-07 05:59:39 --> Total execution time: 1.2419
INFO - 2023-06-07 06:00:13 --> Config Class Initialized
INFO - 2023-06-07 06:00:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:00:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:00:13 --> Utf8 Class Initialized
INFO - 2023-06-07 06:00:13 --> URI Class Initialized
INFO - 2023-06-07 06:00:13 --> Router Class Initialized
INFO - 2023-06-07 06:00:13 --> Output Class Initialized
INFO - 2023-06-07 06:00:13 --> Security Class Initialized
DEBUG - 2023-06-07 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:00:13 --> Input Class Initialized
INFO - 2023-06-07 06:00:13 --> Language Class Initialized
INFO - 2023-06-07 06:00:13 --> Language Class Initialized
INFO - 2023-06-07 06:00:13 --> Config Class Initialized
INFO - 2023-06-07 06:00:13 --> Loader Class Initialized
INFO - 2023-06-07 06:00:13 --> Helper loaded: url_helper
INFO - 2023-06-07 06:00:13 --> Helper loaded: file_helper
INFO - 2023-06-07 06:00:13 --> Helper loaded: form_helper
INFO - 2023-06-07 06:00:13 --> Helper loaded: my_helper
INFO - 2023-06-07 06:00:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:00:13 --> Controller Class Initialized
DEBUG - 2023-06-07 06:00:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:00:14 --> Final output sent to browser
DEBUG - 2023-06-07 06:00:14 --> Total execution time: 1.1641
INFO - 2023-06-07 06:00:37 --> Config Class Initialized
INFO - 2023-06-07 06:00:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:00:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:00:37 --> Utf8 Class Initialized
INFO - 2023-06-07 06:00:37 --> URI Class Initialized
INFO - 2023-06-07 06:00:37 --> Router Class Initialized
INFO - 2023-06-07 06:00:37 --> Output Class Initialized
INFO - 2023-06-07 06:00:37 --> Security Class Initialized
DEBUG - 2023-06-07 06:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:00:37 --> Input Class Initialized
INFO - 2023-06-07 06:00:37 --> Language Class Initialized
INFO - 2023-06-07 06:00:37 --> Language Class Initialized
INFO - 2023-06-07 06:00:37 --> Config Class Initialized
INFO - 2023-06-07 06:00:37 --> Loader Class Initialized
INFO - 2023-06-07 06:00:37 --> Helper loaded: url_helper
INFO - 2023-06-07 06:00:37 --> Helper loaded: file_helper
INFO - 2023-06-07 06:00:37 --> Helper loaded: form_helper
INFO - 2023-06-07 06:00:37 --> Helper loaded: my_helper
INFO - 2023-06-07 06:00:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:00:37 --> Controller Class Initialized
DEBUG - 2023-06-07 06:00:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:00:38 --> Final output sent to browser
DEBUG - 2023-06-07 06:00:38 --> Total execution time: 1.0884
INFO - 2023-06-07 06:00:55 --> Config Class Initialized
INFO - 2023-06-07 06:00:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:00:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:00:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:00:55 --> URI Class Initialized
INFO - 2023-06-07 06:00:55 --> Router Class Initialized
INFO - 2023-06-07 06:00:55 --> Output Class Initialized
INFO - 2023-06-07 06:00:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:00:55 --> Input Class Initialized
INFO - 2023-06-07 06:00:55 --> Language Class Initialized
INFO - 2023-06-07 06:00:55 --> Language Class Initialized
INFO - 2023-06-07 06:00:55 --> Config Class Initialized
INFO - 2023-06-07 06:00:55 --> Loader Class Initialized
INFO - 2023-06-07 06:00:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:00:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:00:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:00:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:00:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:00:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:00:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:00:56 --> Final output sent to browser
DEBUG - 2023-06-07 06:00:56 --> Total execution time: 1.1079
INFO - 2023-06-07 06:01:08 --> Config Class Initialized
INFO - 2023-06-07 06:01:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:01:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:01:08 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:08 --> URI Class Initialized
INFO - 2023-06-07 06:01:08 --> Router Class Initialized
INFO - 2023-06-07 06:01:08 --> Output Class Initialized
INFO - 2023-06-07 06:01:08 --> Security Class Initialized
DEBUG - 2023-06-07 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:01:08 --> Input Class Initialized
INFO - 2023-06-07 06:01:08 --> Language Class Initialized
INFO - 2023-06-07 06:01:08 --> Language Class Initialized
INFO - 2023-06-07 06:01:08 --> Config Class Initialized
INFO - 2023-06-07 06:01:08 --> Loader Class Initialized
INFO - 2023-06-07 06:01:08 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:08 --> Helper loaded: file_helper
INFO - 2023-06-07 06:01:08 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:08 --> Helper loaded: my_helper
INFO - 2023-06-07 06:01:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:08 --> Controller Class Initialized
DEBUG - 2023-06-07 06:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:01:09 --> Final output sent to browser
DEBUG - 2023-06-07 06:01:09 --> Total execution time: 1.1147
INFO - 2023-06-07 06:01:47 --> Config Class Initialized
INFO - 2023-06-07 06:01:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:01:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:01:47 --> Utf8 Class Initialized
INFO - 2023-06-07 06:01:47 --> URI Class Initialized
INFO - 2023-06-07 06:01:47 --> Router Class Initialized
INFO - 2023-06-07 06:01:47 --> Output Class Initialized
INFO - 2023-06-07 06:01:47 --> Security Class Initialized
DEBUG - 2023-06-07 06:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:01:47 --> Input Class Initialized
INFO - 2023-06-07 06:01:47 --> Language Class Initialized
INFO - 2023-06-07 06:01:47 --> Language Class Initialized
INFO - 2023-06-07 06:01:47 --> Config Class Initialized
INFO - 2023-06-07 06:01:47 --> Loader Class Initialized
INFO - 2023-06-07 06:01:47 --> Helper loaded: url_helper
INFO - 2023-06-07 06:01:47 --> Helper loaded: file_helper
INFO - 2023-06-07 06:01:47 --> Helper loaded: form_helper
INFO - 2023-06-07 06:01:47 --> Helper loaded: my_helper
INFO - 2023-06-07 06:01:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:01:47 --> Controller Class Initialized
INFO - 2023-06-07 06:03:39 --> Config Class Initialized
INFO - 2023-06-07 06:03:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:03:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:03:39 --> Utf8 Class Initialized
INFO - 2023-06-07 06:03:39 --> URI Class Initialized
INFO - 2023-06-07 06:03:39 --> Router Class Initialized
INFO - 2023-06-07 06:03:39 --> Output Class Initialized
INFO - 2023-06-07 06:03:39 --> Security Class Initialized
DEBUG - 2023-06-07 06:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:03:39 --> Input Class Initialized
INFO - 2023-06-07 06:03:39 --> Language Class Initialized
INFO - 2023-06-07 06:03:39 --> Language Class Initialized
INFO - 2023-06-07 06:03:39 --> Config Class Initialized
INFO - 2023-06-07 06:03:39 --> Loader Class Initialized
INFO - 2023-06-07 06:03:39 --> Helper loaded: url_helper
INFO - 2023-06-07 06:03:39 --> Helper loaded: file_helper
INFO - 2023-06-07 06:03:39 --> Helper loaded: form_helper
INFO - 2023-06-07 06:03:39 --> Helper loaded: my_helper
INFO - 2023-06-07 06:03:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:03:39 --> Controller Class Initialized
DEBUG - 2023-06-07 06:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:03:39 --> Final output sent to browser
DEBUG - 2023-06-07 06:03:39 --> Total execution time: 0.0847
INFO - 2023-06-07 06:03:43 --> Config Class Initialized
INFO - 2023-06-07 06:03:43 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:03:43 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:03:43 --> Utf8 Class Initialized
INFO - 2023-06-07 06:03:43 --> URI Class Initialized
INFO - 2023-06-07 06:03:43 --> Router Class Initialized
INFO - 2023-06-07 06:03:43 --> Output Class Initialized
INFO - 2023-06-07 06:03:43 --> Security Class Initialized
DEBUG - 2023-06-07 06:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:03:43 --> Input Class Initialized
INFO - 2023-06-07 06:03:43 --> Language Class Initialized
INFO - 2023-06-07 06:03:43 --> Language Class Initialized
INFO - 2023-06-07 06:03:43 --> Config Class Initialized
INFO - 2023-06-07 06:03:43 --> Loader Class Initialized
INFO - 2023-06-07 06:03:43 --> Helper loaded: url_helper
INFO - 2023-06-07 06:03:43 --> Helper loaded: file_helper
INFO - 2023-06-07 06:03:43 --> Helper loaded: form_helper
INFO - 2023-06-07 06:03:43 --> Helper loaded: my_helper
INFO - 2023-06-07 06:03:43 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:03:43 --> Controller Class Initialized
ERROR - 2023-06-07 06:03:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shodaq...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:03:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:10:03 --> Config Class Initialized
INFO - 2023-06-07 06:10:03 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:10:03 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:10:03 --> Utf8 Class Initialized
INFO - 2023-06-07 06:10:03 --> URI Class Initialized
INFO - 2023-06-07 06:10:03 --> Router Class Initialized
INFO - 2023-06-07 06:10:03 --> Output Class Initialized
INFO - 2023-06-07 06:10:03 --> Security Class Initialized
DEBUG - 2023-06-07 06:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:10:03 --> Input Class Initialized
INFO - 2023-06-07 06:10:03 --> Language Class Initialized
INFO - 2023-06-07 06:10:03 --> Language Class Initialized
INFO - 2023-06-07 06:10:03 --> Config Class Initialized
INFO - 2023-06-07 06:10:03 --> Loader Class Initialized
INFO - 2023-06-07 06:10:03 --> Helper loaded: url_helper
INFO - 2023-06-07 06:10:03 --> Helper loaded: file_helper
INFO - 2023-06-07 06:10:03 --> Helper loaded: form_helper
INFO - 2023-06-07 06:10:03 --> Helper loaded: my_helper
INFO - 2023-06-07 06:10:03 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:10:03 --> Controller Class Initialized
ERROR - 2023-06-07 06:10:03 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 349
ERROR - 2023-06-07 06:10:03 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\myraportk13\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2023-06-07 06:10:03 --> Query error:  - Invalid query: 
INFO - 2023-06-07 06:10:03 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:10:12 --> Config Class Initialized
INFO - 2023-06-07 06:10:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:10:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:10:12 --> Utf8 Class Initialized
INFO - 2023-06-07 06:10:12 --> URI Class Initialized
INFO - 2023-06-07 06:10:12 --> Router Class Initialized
INFO - 2023-06-07 06:10:12 --> Output Class Initialized
INFO - 2023-06-07 06:10:12 --> Security Class Initialized
DEBUG - 2023-06-07 06:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:10:12 --> Input Class Initialized
INFO - 2023-06-07 06:10:12 --> Language Class Initialized
INFO - 2023-06-07 06:10:12 --> Language Class Initialized
INFO - 2023-06-07 06:10:12 --> Config Class Initialized
INFO - 2023-06-07 06:10:12 --> Loader Class Initialized
INFO - 2023-06-07 06:10:12 --> Helper loaded: url_helper
INFO - 2023-06-07 06:10:12 --> Helper loaded: file_helper
INFO - 2023-06-07 06:10:12 --> Helper loaded: form_helper
INFO - 2023-06-07 06:10:12 --> Helper loaded: my_helper
INFO - 2023-06-07 06:10:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:10:12 --> Controller Class Initialized
DEBUG - 2023-06-07 06:10:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:10:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:10:12 --> Final output sent to browser
DEBUG - 2023-06-07 06:10:12 --> Total execution time: 0.0489
INFO - 2023-06-07 06:10:15 --> Config Class Initialized
INFO - 2023-06-07 06:10:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:10:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:10:15 --> Utf8 Class Initialized
INFO - 2023-06-07 06:10:15 --> URI Class Initialized
INFO - 2023-06-07 06:10:15 --> Router Class Initialized
INFO - 2023-06-07 06:10:15 --> Output Class Initialized
INFO - 2023-06-07 06:10:15 --> Security Class Initialized
DEBUG - 2023-06-07 06:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:10:15 --> Input Class Initialized
INFO - 2023-06-07 06:10:15 --> Language Class Initialized
INFO - 2023-06-07 06:10:15 --> Language Class Initialized
INFO - 2023-06-07 06:10:15 --> Config Class Initialized
INFO - 2023-06-07 06:10:15 --> Loader Class Initialized
INFO - 2023-06-07 06:10:15 --> Helper loaded: url_helper
INFO - 2023-06-07 06:10:15 --> Helper loaded: file_helper
INFO - 2023-06-07 06:10:15 --> Helper loaded: form_helper
INFO - 2023-06-07 06:10:15 --> Helper loaded: my_helper
INFO - 2023-06-07 06:10:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:10:15 --> Controller Class Initialized
DEBUG - 2023-06-07 06:10:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:10:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:10:15 --> Final output sent to browser
DEBUG - 2023-06-07 06:10:15 --> Total execution time: 0.0463
INFO - 2023-06-07 06:10:19 --> Config Class Initialized
INFO - 2023-06-07 06:10:19 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:10:19 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:10:19 --> Utf8 Class Initialized
INFO - 2023-06-07 06:10:19 --> URI Class Initialized
INFO - 2023-06-07 06:10:19 --> Router Class Initialized
INFO - 2023-06-07 06:10:19 --> Output Class Initialized
INFO - 2023-06-07 06:10:19 --> Security Class Initialized
DEBUG - 2023-06-07 06:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:10:19 --> Input Class Initialized
INFO - 2023-06-07 06:10:19 --> Language Class Initialized
INFO - 2023-06-07 06:10:19 --> Language Class Initialized
INFO - 2023-06-07 06:10:19 --> Config Class Initialized
INFO - 2023-06-07 06:10:19 --> Loader Class Initialized
INFO - 2023-06-07 06:10:19 --> Helper loaded: url_helper
INFO - 2023-06-07 06:10:19 --> Helper loaded: file_helper
INFO - 2023-06-07 06:10:19 --> Helper loaded: form_helper
INFO - 2023-06-07 06:10:19 --> Helper loaded: my_helper
INFO - 2023-06-07 06:10:19 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:10:19 --> Controller Class Initialized
ERROR - 2023-06-07 06:10:19 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 349
ERROR - 2023-06-07 06:10:19 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\myraportk13\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2023-06-07 06:10:19 --> Query error:  - Invalid query: 
INFO - 2023-06-07 06:10:19 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:14:29 --> Config Class Initialized
INFO - 2023-06-07 06:14:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:29 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:29 --> URI Class Initialized
INFO - 2023-06-07 06:14:29 --> Router Class Initialized
INFO - 2023-06-07 06:14:29 --> Output Class Initialized
INFO - 2023-06-07 06:14:29 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:29 --> Input Class Initialized
INFO - 2023-06-07 06:14:29 --> Language Class Initialized
INFO - 2023-06-07 06:14:29 --> Language Class Initialized
INFO - 2023-06-07 06:14:29 --> Config Class Initialized
INFO - 2023-06-07 06:14:29 --> Loader Class Initialized
INFO - 2023-06-07 06:14:29 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:29 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:29 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:29 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:29 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:14:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:29 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:29 --> Total execution time: 0.0913
INFO - 2023-06-07 06:14:30 --> Config Class Initialized
INFO - 2023-06-07 06:14:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:30 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:30 --> URI Class Initialized
INFO - 2023-06-07 06:14:30 --> Router Class Initialized
INFO - 2023-06-07 06:14:30 --> Output Class Initialized
INFO - 2023-06-07 06:14:30 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:30 --> Input Class Initialized
INFO - 2023-06-07 06:14:30 --> Language Class Initialized
INFO - 2023-06-07 06:14:30 --> Language Class Initialized
INFO - 2023-06-07 06:14:30 --> Config Class Initialized
INFO - 2023-06-07 06:14:30 --> Loader Class Initialized
INFO - 2023-06-07 06:14:30 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:30 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:30 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:30 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:30 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:14:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:30 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:30 --> Total execution time: 0.0663
INFO - 2023-06-07 06:14:35 --> Config Class Initialized
INFO - 2023-06-07 06:14:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:35 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:35 --> URI Class Initialized
INFO - 2023-06-07 06:14:35 --> Router Class Initialized
INFO - 2023-06-07 06:14:35 --> Output Class Initialized
INFO - 2023-06-07 06:14:35 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:35 --> Input Class Initialized
INFO - 2023-06-07 06:14:35 --> Language Class Initialized
INFO - 2023-06-07 06:14:35 --> Language Class Initialized
INFO - 2023-06-07 06:14:35 --> Config Class Initialized
INFO - 2023-06-07 06:14:35 --> Loader Class Initialized
INFO - 2023-06-07 06:14:35 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:35 --> Controller Class Initialized
ERROR - 2023-06-07 06:14:35 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 314
ERROR - 2023-06-07 06:14:35 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 315
ERROR - 2023-06-07 06:14:35 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 314
ERROR - 2023-06-07 06:14:35 --> Severity: Warning --> mysqli_real_escape_string() expects exactly 2 parameters, 1 given C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 315
INFO - 2023-06-07 06:14:35 --> Config Class Initialized
INFO - 2023-06-07 06:14:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:35 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:35 --> URI Class Initialized
INFO - 2023-06-07 06:14:35 --> Router Class Initialized
INFO - 2023-06-07 06:14:35 --> Output Class Initialized
INFO - 2023-06-07 06:14:35 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:35 --> Input Class Initialized
INFO - 2023-06-07 06:14:35 --> Language Class Initialized
INFO - 2023-06-07 06:14:35 --> Language Class Initialized
INFO - 2023-06-07 06:14:35 --> Config Class Initialized
INFO - 2023-06-07 06:14:35 --> Loader Class Initialized
INFO - 2023-06-07 06:14:35 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:35 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:35 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:35 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:35 --> Total execution time: 0.0536
INFO - 2023-06-07 06:14:38 --> Config Class Initialized
INFO - 2023-06-07 06:14:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:38 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:38 --> URI Class Initialized
INFO - 2023-06-07 06:14:38 --> Router Class Initialized
INFO - 2023-06-07 06:14:38 --> Output Class Initialized
INFO - 2023-06-07 06:14:38 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:38 --> Input Class Initialized
INFO - 2023-06-07 06:14:38 --> Language Class Initialized
INFO - 2023-06-07 06:14:38 --> Language Class Initialized
INFO - 2023-06-07 06:14:38 --> Config Class Initialized
INFO - 2023-06-07 06:14:38 --> Loader Class Initialized
INFO - 2023-06-07 06:14:38 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:38 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:38 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:38 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:38 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:38 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:38 --> Total execution time: 0.0634
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:40 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:40 --> URI Class Initialized
INFO - 2023-06-07 06:14:40 --> Router Class Initialized
INFO - 2023-06-07 06:14:40 --> Output Class Initialized
INFO - 2023-06-07 06:14:40 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:40 --> Input Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Loader Class Initialized
INFO - 2023-06-07 06:14:40 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:40 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:40 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:40 --> Total execution time: 0.0552
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:40 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:40 --> URI Class Initialized
INFO - 2023-06-07 06:14:40 --> Router Class Initialized
INFO - 2023-06-07 06:14:40 --> Output Class Initialized
INFO - 2023-06-07 06:14:40 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:40 --> Input Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Loader Class Initialized
INFO - 2023-06-07 06:14:40 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:40 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:40 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:40 --> Total execution time: 0.0662
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:40 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:40 --> URI Class Initialized
INFO - 2023-06-07 06:14:40 --> Router Class Initialized
INFO - 2023-06-07 06:14:40 --> Output Class Initialized
INFO - 2023-06-07 06:14:40 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:40 --> Input Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Language Class Initialized
INFO - 2023-06-07 06:14:40 --> Config Class Initialized
INFO - 2023-06-07 06:14:40 --> Loader Class Initialized
INFO - 2023-06-07 06:14:40 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:40 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:40 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:40 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:40 --> Total execution time: 0.0591
INFO - 2023-06-07 06:14:41 --> Config Class Initialized
INFO - 2023-06-07 06:14:41 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:14:41 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:14:41 --> Utf8 Class Initialized
INFO - 2023-06-07 06:14:41 --> URI Class Initialized
INFO - 2023-06-07 06:14:41 --> Router Class Initialized
INFO - 2023-06-07 06:14:41 --> Output Class Initialized
INFO - 2023-06-07 06:14:41 --> Security Class Initialized
DEBUG - 2023-06-07 06:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:14:41 --> Input Class Initialized
INFO - 2023-06-07 06:14:41 --> Language Class Initialized
INFO - 2023-06-07 06:14:41 --> Language Class Initialized
INFO - 2023-06-07 06:14:41 --> Config Class Initialized
INFO - 2023-06-07 06:14:41 --> Loader Class Initialized
INFO - 2023-06-07 06:14:41 --> Helper loaded: url_helper
INFO - 2023-06-07 06:14:41 --> Helper loaded: file_helper
INFO - 2023-06-07 06:14:41 --> Helper loaded: form_helper
INFO - 2023-06-07 06:14:41 --> Helper loaded: my_helper
INFO - 2023-06-07 06:14:41 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:14:41 --> Controller Class Initialized
DEBUG - 2023-06-07 06:14:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:14:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:14:41 --> Final output sent to browser
DEBUG - 2023-06-07 06:14:41 --> Total execution time: 0.0406
INFO - 2023-06-07 06:25:42 --> Config Class Initialized
INFO - 2023-06-07 06:25:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:25:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:25:42 --> Utf8 Class Initialized
INFO - 2023-06-07 06:25:42 --> URI Class Initialized
INFO - 2023-06-07 06:25:42 --> Router Class Initialized
INFO - 2023-06-07 06:25:42 --> Output Class Initialized
INFO - 2023-06-07 06:25:42 --> Security Class Initialized
DEBUG - 2023-06-07 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:25:42 --> Input Class Initialized
INFO - 2023-06-07 06:25:42 --> Language Class Initialized
INFO - 2023-06-07 06:25:42 --> Language Class Initialized
INFO - 2023-06-07 06:25:42 --> Config Class Initialized
INFO - 2023-06-07 06:25:42 --> Loader Class Initialized
INFO - 2023-06-07 06:25:42 --> Helper loaded: url_helper
INFO - 2023-06-07 06:25:42 --> Helper loaded: file_helper
INFO - 2023-06-07 06:25:42 --> Helper loaded: form_helper
INFO - 2023-06-07 06:25:42 --> Helper loaded: my_helper
INFO - 2023-06-07 06:25:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:25:42 --> Controller Class Initialized
DEBUG - 2023-06-07 06:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:25:42 --> Final output sent to browser
DEBUG - 2023-06-07 06:25:42 --> Total execution time: 0.0783
INFO - 2023-06-07 06:25:45 --> Config Class Initialized
INFO - 2023-06-07 06:25:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:25:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:25:45 --> Utf8 Class Initialized
INFO - 2023-06-07 06:25:45 --> URI Class Initialized
INFO - 2023-06-07 06:25:46 --> Router Class Initialized
INFO - 2023-06-07 06:25:46 --> Output Class Initialized
INFO - 2023-06-07 06:25:46 --> Security Class Initialized
DEBUG - 2023-06-07 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:25:46 --> Input Class Initialized
INFO - 2023-06-07 06:25:46 --> Language Class Initialized
INFO - 2023-06-07 06:25:46 --> Language Class Initialized
INFO - 2023-06-07 06:25:46 --> Config Class Initialized
INFO - 2023-06-07 06:25:46 --> Loader Class Initialized
INFO - 2023-06-07 06:25:46 --> Helper loaded: url_helper
INFO - 2023-06-07 06:25:46 --> Helper loaded: file_helper
INFO - 2023-06-07 06:25:46 --> Helper loaded: form_helper
INFO - 2023-06-07 06:25:46 --> Helper loaded: my_helper
INFO - 2023-06-07 06:25:46 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:25:46 --> Controller Class Initialized
ERROR - 2023-06-07 06:25:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shodaq...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:25:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:33:05 --> Config Class Initialized
INFO - 2023-06-07 06:33:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:05 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:05 --> URI Class Initialized
INFO - 2023-06-07 06:33:05 --> Router Class Initialized
INFO - 2023-06-07 06:33:05 --> Output Class Initialized
INFO - 2023-06-07 06:33:05 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:05 --> Input Class Initialized
INFO - 2023-06-07 06:33:05 --> Language Class Initialized
INFO - 2023-06-07 06:33:05 --> Language Class Initialized
INFO - 2023-06-07 06:33:05 --> Config Class Initialized
INFO - 2023-06-07 06:33:05 --> Loader Class Initialized
INFO - 2023-06-07 06:33:05 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:05 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:05 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:05 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:05 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-06-07 06:33:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:05 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:05 --> Total execution time: 0.0869
INFO - 2023-06-07 06:33:06 --> Config Class Initialized
INFO - 2023-06-07 06:33:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:06 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:06 --> URI Class Initialized
INFO - 2023-06-07 06:33:06 --> Router Class Initialized
INFO - 2023-06-07 06:33:06 --> Output Class Initialized
INFO - 2023-06-07 06:33:06 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:06 --> Input Class Initialized
INFO - 2023-06-07 06:33:06 --> Language Class Initialized
INFO - 2023-06-07 06:33:06 --> Language Class Initialized
INFO - 2023-06-07 06:33:06 --> Config Class Initialized
INFO - 2023-06-07 06:33:06 --> Loader Class Initialized
INFO - 2023-06-07 06:33:06 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:06 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:06 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:06 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:06 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:06 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:06 --> Total execution time: 0.0462
INFO - 2023-06-07 06:33:09 --> Config Class Initialized
INFO - 2023-06-07 06:33:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:09 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:09 --> URI Class Initialized
INFO - 2023-06-07 06:33:09 --> Router Class Initialized
INFO - 2023-06-07 06:33:09 --> Output Class Initialized
INFO - 2023-06-07 06:33:09 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:09 --> Input Class Initialized
INFO - 2023-06-07 06:33:09 --> Language Class Initialized
INFO - 2023-06-07 06:33:09 --> Language Class Initialized
INFO - 2023-06-07 06:33:09 --> Config Class Initialized
INFO - 2023-06-07 06:33:09 --> Loader Class Initialized
INFO - 2023-06-07 06:33:09 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:09 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:09 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:09 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:09 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:09 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:09 --> Total execution time: 0.0419
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:11 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:11 --> URI Class Initialized
INFO - 2023-06-07 06:33:11 --> Router Class Initialized
INFO - 2023-06-07 06:33:11 --> Output Class Initialized
INFO - 2023-06-07 06:33:11 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:11 --> Input Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Loader Class Initialized
INFO - 2023-06-07 06:33:11 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:11 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:11 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:11 --> Total execution time: 0.0434
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:11 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:11 --> URI Class Initialized
INFO - 2023-06-07 06:33:11 --> Router Class Initialized
INFO - 2023-06-07 06:33:11 --> Output Class Initialized
INFO - 2023-06-07 06:33:11 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:11 --> Input Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Loader Class Initialized
INFO - 2023-06-07 06:33:11 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:11 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:11 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:11 --> Total execution time: 0.0411
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:11 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:11 --> URI Class Initialized
INFO - 2023-06-07 06:33:11 --> Router Class Initialized
INFO - 2023-06-07 06:33:11 --> Output Class Initialized
INFO - 2023-06-07 06:33:11 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:11 --> Input Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Loader Class Initialized
INFO - 2023-06-07 06:33:11 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:11 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:11 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:11 --> Total execution time: 0.0407
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:11 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:11 --> URI Class Initialized
INFO - 2023-06-07 06:33:11 --> Router Class Initialized
INFO - 2023-06-07 06:33:11 --> Output Class Initialized
INFO - 2023-06-07 06:33:11 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:11 --> Input Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Language Class Initialized
INFO - 2023-06-07 06:33:11 --> Config Class Initialized
INFO - 2023-06-07 06:33:11 --> Loader Class Initialized
INFO - 2023-06-07 06:33:11 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:11 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:11 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:11 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:11 --> Total execution time: 0.0516
INFO - 2023-06-07 06:33:20 --> Config Class Initialized
INFO - 2023-06-07 06:33:20 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:20 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:20 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:20 --> URI Class Initialized
INFO - 2023-06-07 06:33:20 --> Router Class Initialized
INFO - 2023-06-07 06:33:20 --> Output Class Initialized
INFO - 2023-06-07 06:33:20 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:20 --> Input Class Initialized
INFO - 2023-06-07 06:33:20 --> Language Class Initialized
INFO - 2023-06-07 06:33:20 --> Language Class Initialized
INFO - 2023-06-07 06:33:20 --> Config Class Initialized
INFO - 2023-06-07 06:33:20 --> Loader Class Initialized
INFO - 2023-06-07 06:33:20 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:20 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:20 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:20 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:20 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:20 --> Controller Class Initialized
INFO - 2023-06-07 06:33:20 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:20 --> Total execution time: 0.0412
INFO - 2023-06-07 06:33:22 --> Config Class Initialized
INFO - 2023-06-07 06:33:22 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:22 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:22 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:22 --> URI Class Initialized
INFO - 2023-06-07 06:33:22 --> Router Class Initialized
INFO - 2023-06-07 06:33:22 --> Output Class Initialized
INFO - 2023-06-07 06:33:22 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:22 --> Input Class Initialized
INFO - 2023-06-07 06:33:22 --> Language Class Initialized
INFO - 2023-06-07 06:33:22 --> Language Class Initialized
INFO - 2023-06-07 06:33:22 --> Config Class Initialized
INFO - 2023-06-07 06:33:22 --> Loader Class Initialized
INFO - 2023-06-07 06:33:22 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:22 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:22 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:22 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:22 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:22 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:22 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:22 --> Total execution time: 0.0590
INFO - 2023-06-07 06:33:26 --> Config Class Initialized
INFO - 2023-06-07 06:33:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:26 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:26 --> URI Class Initialized
INFO - 2023-06-07 06:33:26 --> Router Class Initialized
INFO - 2023-06-07 06:33:26 --> Output Class Initialized
INFO - 2023-06-07 06:33:26 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:26 --> Input Class Initialized
INFO - 2023-06-07 06:33:26 --> Language Class Initialized
INFO - 2023-06-07 06:33:26 --> Language Class Initialized
INFO - 2023-06-07 06:33:26 --> Config Class Initialized
INFO - 2023-06-07 06:33:26 --> Loader Class Initialized
INFO - 2023-06-07 06:33:26 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:26 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:26 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:26 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:26 --> Controller Class Initialized
ERROR - 2023-06-07 06:33:26 --> Severity: error --> Exception: Call to undefined function _escape_str() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 36
INFO - 2023-06-07 06:33:29 --> Config Class Initialized
INFO - 2023-06-07 06:33:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:29 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:29 --> URI Class Initialized
INFO - 2023-06-07 06:33:29 --> Router Class Initialized
INFO - 2023-06-07 06:33:29 --> Output Class Initialized
INFO - 2023-06-07 06:33:29 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:29 --> Input Class Initialized
INFO - 2023-06-07 06:33:29 --> Language Class Initialized
ERROR - 2023-06-07 06:33:29 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:33:31 --> Config Class Initialized
INFO - 2023-06-07 06:33:31 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:31 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:31 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:31 --> URI Class Initialized
INFO - 2023-06-07 06:33:31 --> Router Class Initialized
INFO - 2023-06-07 06:33:31 --> Output Class Initialized
INFO - 2023-06-07 06:33:31 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:31 --> Input Class Initialized
INFO - 2023-06-07 06:33:31 --> Language Class Initialized
INFO - 2023-06-07 06:33:31 --> Language Class Initialized
INFO - 2023-06-07 06:33:31 --> Config Class Initialized
INFO - 2023-06-07 06:33:31 --> Loader Class Initialized
INFO - 2023-06-07 06:33:31 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:31 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:31 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:31 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:31 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:31 --> Controller Class Initialized
DEBUG - 2023-06-07 06:33:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:33:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:33:31 --> Final output sent to browser
DEBUG - 2023-06-07 06:33:31 --> Total execution time: 0.0539
INFO - 2023-06-07 06:33:31 --> Config Class Initialized
INFO - 2023-06-07 06:33:31 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:31 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:31 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:31 --> URI Class Initialized
INFO - 2023-06-07 06:33:31 --> Router Class Initialized
INFO - 2023-06-07 06:33:31 --> Output Class Initialized
INFO - 2023-06-07 06:33:31 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:31 --> Input Class Initialized
INFO - 2023-06-07 06:33:31 --> Language Class Initialized
ERROR - 2023-06-07 06:33:31 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:33:39 --> Config Class Initialized
INFO - 2023-06-07 06:33:39 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:33:39 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:33:39 --> Utf8 Class Initialized
INFO - 2023-06-07 06:33:39 --> URI Class Initialized
INFO - 2023-06-07 06:33:39 --> Router Class Initialized
INFO - 2023-06-07 06:33:39 --> Output Class Initialized
INFO - 2023-06-07 06:33:39 --> Security Class Initialized
DEBUG - 2023-06-07 06:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:33:39 --> Input Class Initialized
INFO - 2023-06-07 06:33:39 --> Language Class Initialized
INFO - 2023-06-07 06:33:39 --> Language Class Initialized
INFO - 2023-06-07 06:33:39 --> Config Class Initialized
INFO - 2023-06-07 06:33:39 --> Loader Class Initialized
INFO - 2023-06-07 06:33:39 --> Helper loaded: url_helper
INFO - 2023-06-07 06:33:39 --> Helper loaded: file_helper
INFO - 2023-06-07 06:33:39 --> Helper loaded: form_helper
INFO - 2023-06-07 06:33:39 --> Helper loaded: my_helper
INFO - 2023-06-07 06:33:39 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:33:39 --> Controller Class Initialized
ERROR - 2023-06-07 06:33:39 --> Severity: error --> Exception: Call to undefined function _escape_str() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 36
INFO - 2023-06-07 06:40:38 --> Config Class Initialized
INFO - 2023-06-07 06:40:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:40:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:40:38 --> Utf8 Class Initialized
INFO - 2023-06-07 06:40:38 --> URI Class Initialized
INFO - 2023-06-07 06:40:38 --> Router Class Initialized
INFO - 2023-06-07 06:40:38 --> Output Class Initialized
INFO - 2023-06-07 06:40:38 --> Security Class Initialized
DEBUG - 2023-06-07 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:40:38 --> Input Class Initialized
INFO - 2023-06-07 06:40:38 --> Language Class Initialized
INFO - 2023-06-07 06:40:38 --> Language Class Initialized
INFO - 2023-06-07 06:40:38 --> Config Class Initialized
INFO - 2023-06-07 06:40:38 --> Loader Class Initialized
INFO - 2023-06-07 06:40:38 --> Helper loaded: url_helper
INFO - 2023-06-07 06:40:38 --> Helper loaded: file_helper
INFO - 2023-06-07 06:40:38 --> Helper loaded: form_helper
INFO - 2023-06-07 06:40:38 --> Helper loaded: my_helper
INFO - 2023-06-07 06:40:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:40:38 --> Controller Class Initialized
DEBUG - 2023-06-07 06:40:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:40:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:40:38 --> Final output sent to browser
DEBUG - 2023-06-07 06:40:38 --> Total execution time: 0.0976
INFO - 2023-06-07 06:40:38 --> Config Class Initialized
INFO - 2023-06-07 06:40:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:40:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:40:38 --> Utf8 Class Initialized
INFO - 2023-06-07 06:40:38 --> URI Class Initialized
INFO - 2023-06-07 06:40:38 --> Router Class Initialized
INFO - 2023-06-07 06:40:38 --> Output Class Initialized
INFO - 2023-06-07 06:40:38 --> Security Class Initialized
DEBUG - 2023-06-07 06:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:40:38 --> Input Class Initialized
INFO - 2023-06-07 06:40:38 --> Language Class Initialized
ERROR - 2023-06-07 06:40:38 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:40:50 --> Config Class Initialized
INFO - 2023-06-07 06:40:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:40:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:40:50 --> Utf8 Class Initialized
INFO - 2023-06-07 06:40:50 --> URI Class Initialized
INFO - 2023-06-07 06:40:50 --> Router Class Initialized
INFO - 2023-06-07 06:40:50 --> Output Class Initialized
INFO - 2023-06-07 06:40:50 --> Security Class Initialized
DEBUG - 2023-06-07 06:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:40:50 --> Input Class Initialized
INFO - 2023-06-07 06:40:50 --> Language Class Initialized
INFO - 2023-06-07 06:40:50 --> Language Class Initialized
INFO - 2023-06-07 06:40:50 --> Config Class Initialized
INFO - 2023-06-07 06:40:50 --> Loader Class Initialized
INFO - 2023-06-07 06:40:50 --> Helper loaded: url_helper
INFO - 2023-06-07 06:40:50 --> Helper loaded: file_helper
INFO - 2023-06-07 06:40:50 --> Helper loaded: form_helper
INFO - 2023-06-07 06:40:50 --> Helper loaded: my_helper
INFO - 2023-06-07 06:40:50 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:40:50 --> Controller Class Initialized
ERROR - 2023-06-07 06:40:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila?s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ? until ?) jim), ?) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du?a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher?s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:40:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:41:55 --> Config Class Initialized
INFO - 2023-06-07 06:41:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:41:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:41:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:41:55 --> URI Class Initialized
INFO - 2023-06-07 06:41:55 --> Router Class Initialized
INFO - 2023-06-07 06:41:55 --> Output Class Initialized
INFO - 2023-06-07 06:41:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:41:55 --> Input Class Initialized
INFO - 2023-06-07 06:41:55 --> Language Class Initialized
INFO - 2023-06-07 06:41:55 --> Language Class Initialized
INFO - 2023-06-07 06:41:55 --> Config Class Initialized
INFO - 2023-06-07 06:41:55 --> Loader Class Initialized
INFO - 2023-06-07 06:41:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:41:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:41:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:41:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:41:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:41:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:41:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:41:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:41:55 --> Final output sent to browser
DEBUG - 2023-06-07 06:41:55 --> Total execution time: 0.0914
INFO - 2023-06-07 06:41:56 --> Config Class Initialized
INFO - 2023-06-07 06:41:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:41:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:41:56 --> Utf8 Class Initialized
INFO - 2023-06-07 06:41:56 --> URI Class Initialized
INFO - 2023-06-07 06:41:56 --> Router Class Initialized
INFO - 2023-06-07 06:41:56 --> Output Class Initialized
INFO - 2023-06-07 06:41:56 --> Security Class Initialized
DEBUG - 2023-06-07 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:41:56 --> Input Class Initialized
INFO - 2023-06-07 06:41:56 --> Language Class Initialized
ERROR - 2023-06-07 06:41:56 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:42:06 --> Config Class Initialized
INFO - 2023-06-07 06:42:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:42:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:42:06 --> Utf8 Class Initialized
INFO - 2023-06-07 06:42:06 --> URI Class Initialized
INFO - 2023-06-07 06:42:06 --> Router Class Initialized
INFO - 2023-06-07 06:42:06 --> Output Class Initialized
INFO - 2023-06-07 06:42:06 --> Security Class Initialized
DEBUG - 2023-06-07 06:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:42:06 --> Input Class Initialized
INFO - 2023-06-07 06:42:06 --> Language Class Initialized
INFO - 2023-06-07 06:42:06 --> Language Class Initialized
INFO - 2023-06-07 06:42:06 --> Config Class Initialized
INFO - 2023-06-07 06:42:06 --> Loader Class Initialized
INFO - 2023-06-07 06:42:06 --> Helper loaded: url_helper
INFO - 2023-06-07 06:42:06 --> Helper loaded: file_helper
INFO - 2023-06-07 06:42:06 --> Helper loaded: form_helper
INFO - 2023-06-07 06:42:06 --> Helper loaded: my_helper
INFO - 2023-06-07 06:42:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:42:06 --> Controller Class Initialized
ERROR - 2023-06-07 06:42:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila’s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du’a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher’s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:42:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:43:35 --> Config Class Initialized
INFO - 2023-06-07 06:43:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:43:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:43:35 --> Utf8 Class Initialized
INFO - 2023-06-07 06:43:35 --> URI Class Initialized
INFO - 2023-06-07 06:43:35 --> Router Class Initialized
INFO - 2023-06-07 06:43:35 --> Output Class Initialized
INFO - 2023-06-07 06:43:35 --> Security Class Initialized
DEBUG - 2023-06-07 06:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:43:35 --> Input Class Initialized
INFO - 2023-06-07 06:43:35 --> Language Class Initialized
INFO - 2023-06-07 06:43:35 --> Language Class Initialized
INFO - 2023-06-07 06:43:35 --> Config Class Initialized
INFO - 2023-06-07 06:43:35 --> Loader Class Initialized
INFO - 2023-06-07 06:43:35 --> Helper loaded: url_helper
INFO - 2023-06-07 06:43:35 --> Helper loaded: file_helper
INFO - 2023-06-07 06:43:35 --> Helper loaded: form_helper
INFO - 2023-06-07 06:43:35 --> Helper loaded: my_helper
INFO - 2023-06-07 06:43:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:43:35 --> Controller Class Initialized
DEBUG - 2023-06-07 06:43:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:43:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:43:35 --> Final output sent to browser
DEBUG - 2023-06-07 06:43:35 --> Total execution time: 0.1025
INFO - 2023-06-07 06:43:36 --> Config Class Initialized
INFO - 2023-06-07 06:43:36 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:43:36 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:43:36 --> Utf8 Class Initialized
INFO - 2023-06-07 06:43:36 --> URI Class Initialized
INFO - 2023-06-07 06:43:36 --> Router Class Initialized
INFO - 2023-06-07 06:43:36 --> Output Class Initialized
INFO - 2023-06-07 06:43:36 --> Security Class Initialized
DEBUG - 2023-06-07 06:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:43:36 --> Input Class Initialized
INFO - 2023-06-07 06:43:36 --> Language Class Initialized
ERROR - 2023-06-07 06:43:36 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:43:44 --> Config Class Initialized
INFO - 2023-06-07 06:43:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:43:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:43:44 --> Utf8 Class Initialized
INFO - 2023-06-07 06:43:45 --> URI Class Initialized
INFO - 2023-06-07 06:43:45 --> Router Class Initialized
INFO - 2023-06-07 06:43:45 --> Output Class Initialized
INFO - 2023-06-07 06:43:45 --> Security Class Initialized
DEBUG - 2023-06-07 06:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:43:45 --> Input Class Initialized
INFO - 2023-06-07 06:43:45 --> Language Class Initialized
INFO - 2023-06-07 06:43:45 --> Language Class Initialized
INFO - 2023-06-07 06:43:45 --> Config Class Initialized
INFO - 2023-06-07 06:43:45 --> Loader Class Initialized
INFO - 2023-06-07 06:43:45 --> Helper loaded: url_helper
INFO - 2023-06-07 06:43:45 --> Helper loaded: file_helper
INFO - 2023-06-07 06:43:45 --> Helper loaded: form_helper
INFO - 2023-06-07 06:43:45 --> Helper loaded: my_helper
INFO - 2023-06-07 06:43:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:43:45 --> Controller Class Initialized
ERROR - 2023-06-07 06:43:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila&rsquo;s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du&rsquo;a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher&rsquo;s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:43:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:46:35 --> Config Class Initialized
INFO - 2023-06-07 06:46:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:35 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:35 --> URI Class Initialized
INFO - 2023-06-07 06:46:35 --> Router Class Initialized
INFO - 2023-06-07 06:46:35 --> Output Class Initialized
INFO - 2023-06-07 06:46:35 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:35 --> Input Class Initialized
INFO - 2023-06-07 06:46:35 --> Language Class Initialized
INFO - 2023-06-07 06:46:35 --> Language Class Initialized
INFO - 2023-06-07 06:46:35 --> Config Class Initialized
INFO - 2023-06-07 06:46:35 --> Loader Class Initialized
INFO - 2023-06-07 06:46:35 --> Helper loaded: url_helper
INFO - 2023-06-07 06:46:35 --> Helper loaded: file_helper
INFO - 2023-06-07 06:46:35 --> Helper loaded: form_helper
INFO - 2023-06-07 06:46:35 --> Helper loaded: my_helper
INFO - 2023-06-07 06:46:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:46:35 --> Controller Class Initialized
DEBUG - 2023-06-07 06:46:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:46:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:46:35 --> Final output sent to browser
DEBUG - 2023-06-07 06:46:35 --> Total execution time: 0.0705
INFO - 2023-06-07 06:46:38 --> Config Class Initialized
INFO - 2023-06-07 06:46:38 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:38 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:38 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:38 --> URI Class Initialized
INFO - 2023-06-07 06:46:38 --> Router Class Initialized
INFO - 2023-06-07 06:46:38 --> Output Class Initialized
INFO - 2023-06-07 06:46:38 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:38 --> Input Class Initialized
INFO - 2023-06-07 06:46:38 --> Language Class Initialized
INFO - 2023-06-07 06:46:38 --> Language Class Initialized
INFO - 2023-06-07 06:46:38 --> Config Class Initialized
INFO - 2023-06-07 06:46:38 --> Loader Class Initialized
INFO - 2023-06-07 06:46:38 --> Helper loaded: url_helper
INFO - 2023-06-07 06:46:38 --> Helper loaded: file_helper
INFO - 2023-06-07 06:46:38 --> Helper loaded: form_helper
INFO - 2023-06-07 06:46:38 --> Helper loaded: my_helper
INFO - 2023-06-07 06:46:38 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:46:38 --> Controller Class Initialized
ERROR - 2023-06-07 06:46:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila&rsquo;s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du&rsquo;a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher&rsquo;s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:46:38 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:46:41 --> Config Class Initialized
INFO - 2023-06-07 06:46:41 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:41 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:41 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:41 --> URI Class Initialized
INFO - 2023-06-07 06:46:41 --> Router Class Initialized
INFO - 2023-06-07 06:46:41 --> Output Class Initialized
INFO - 2023-06-07 06:46:41 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:41 --> Input Class Initialized
INFO - 2023-06-07 06:46:41 --> Language Class Initialized
ERROR - 2023-06-07 06:46:41 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:46:45 --> Config Class Initialized
INFO - 2023-06-07 06:46:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:45 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:45 --> URI Class Initialized
INFO - 2023-06-07 06:46:45 --> Router Class Initialized
INFO - 2023-06-07 06:46:45 --> Output Class Initialized
INFO - 2023-06-07 06:46:45 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:45 --> Input Class Initialized
INFO - 2023-06-07 06:46:45 --> Language Class Initialized
INFO - 2023-06-07 06:46:45 --> Language Class Initialized
INFO - 2023-06-07 06:46:45 --> Config Class Initialized
INFO - 2023-06-07 06:46:45 --> Loader Class Initialized
INFO - 2023-06-07 06:46:45 --> Helper loaded: url_helper
INFO - 2023-06-07 06:46:45 --> Helper loaded: file_helper
INFO - 2023-06-07 06:46:45 --> Helper loaded: form_helper
INFO - 2023-06-07 06:46:45 --> Helper loaded: my_helper
INFO - 2023-06-07 06:46:45 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:46:45 --> Controller Class Initialized
DEBUG - 2023-06-07 06:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:46:45 --> Final output sent to browser
DEBUG - 2023-06-07 06:46:45 --> Total execution time: 0.0608
INFO - 2023-06-07 06:46:45 --> Config Class Initialized
INFO - 2023-06-07 06:46:45 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:45 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:45 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:45 --> URI Class Initialized
INFO - 2023-06-07 06:46:45 --> Router Class Initialized
INFO - 2023-06-07 06:46:45 --> Output Class Initialized
INFO - 2023-06-07 06:46:45 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:45 --> Input Class Initialized
INFO - 2023-06-07 06:46:45 --> Language Class Initialized
ERROR - 2023-06-07 06:46:45 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:46:51 --> Config Class Initialized
INFO - 2023-06-07 06:46:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:46:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:46:51 --> Utf8 Class Initialized
INFO - 2023-06-07 06:46:51 --> URI Class Initialized
INFO - 2023-06-07 06:46:51 --> Router Class Initialized
INFO - 2023-06-07 06:46:51 --> Output Class Initialized
INFO - 2023-06-07 06:46:51 --> Security Class Initialized
DEBUG - 2023-06-07 06:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:46:51 --> Input Class Initialized
INFO - 2023-06-07 06:46:51 --> Language Class Initialized
INFO - 2023-06-07 06:46:51 --> Language Class Initialized
INFO - 2023-06-07 06:46:51 --> Config Class Initialized
INFO - 2023-06-07 06:46:51 --> Loader Class Initialized
INFO - 2023-06-07 06:46:51 --> Helper loaded: url_helper
INFO - 2023-06-07 06:46:51 --> Helper loaded: file_helper
INFO - 2023-06-07 06:46:51 --> Helper loaded: form_helper
INFO - 2023-06-07 06:46:51 --> Helper loaded: my_helper
INFO - 2023-06-07 06:46:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:46:51 --> Controller Class Initialized
ERROR - 2023-06-07 06:46:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila&rsquo;s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du&rsquo;a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher&rsquo;s guidance', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-06-07 06:46:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 06:47:51 --> Config Class Initialized
INFO - 2023-06-07 06:47:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:47:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:47:51 --> Utf8 Class Initialized
INFO - 2023-06-07 06:47:51 --> URI Class Initialized
INFO - 2023-06-07 06:47:51 --> Router Class Initialized
INFO - 2023-06-07 06:47:51 --> Output Class Initialized
INFO - 2023-06-07 06:47:51 --> Security Class Initialized
DEBUG - 2023-06-07 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:47:51 --> Input Class Initialized
INFO - 2023-06-07 06:47:51 --> Language Class Initialized
INFO - 2023-06-07 06:47:51 --> Language Class Initialized
INFO - 2023-06-07 06:47:51 --> Config Class Initialized
INFO - 2023-06-07 06:47:51 --> Loader Class Initialized
INFO - 2023-06-07 06:47:51 --> Helper loaded: url_helper
INFO - 2023-06-07 06:47:51 --> Helper loaded: file_helper
INFO - 2023-06-07 06:47:51 --> Helper loaded: form_helper
INFO - 2023-06-07 06:47:51 --> Helper loaded: my_helper
INFO - 2023-06-07 06:47:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:47:51 --> Controller Class Initialized
DEBUG - 2023-06-07 06:47:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:47:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:47:51 --> Final output sent to browser
DEBUG - 2023-06-07 06:47:51 --> Total execution time: 0.0637
INFO - 2023-06-07 06:47:51 --> Config Class Initialized
INFO - 2023-06-07 06:47:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:47:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:47:51 --> Utf8 Class Initialized
INFO - 2023-06-07 06:47:51 --> URI Class Initialized
INFO - 2023-06-07 06:47:51 --> Router Class Initialized
INFO - 2023-06-07 06:47:51 --> Output Class Initialized
INFO - 2023-06-07 06:47:51 --> Security Class Initialized
DEBUG - 2023-06-07 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:47:51 --> Input Class Initialized
INFO - 2023-06-07 06:47:51 --> Language Class Initialized
ERROR - 2023-06-07 06:47:51 --> 404 Page Not Found: /index
INFO - 2023-06-07 06:47:57 --> Config Class Initialized
INFO - 2023-06-07 06:47:57 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:47:57 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:47:57 --> Utf8 Class Initialized
INFO - 2023-06-07 06:47:57 --> URI Class Initialized
INFO - 2023-06-07 06:47:57 --> Router Class Initialized
INFO - 2023-06-07 06:47:57 --> Output Class Initialized
INFO - 2023-06-07 06:47:57 --> Security Class Initialized
DEBUG - 2023-06-07 06:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:47:57 --> Input Class Initialized
INFO - 2023-06-07 06:47:57 --> Language Class Initialized
INFO - 2023-06-07 06:47:57 --> Language Class Initialized
INFO - 2023-06-07 06:47:57 --> Config Class Initialized
INFO - 2023-06-07 06:47:57 --> Loader Class Initialized
INFO - 2023-06-07 06:47:57 --> Helper loaded: url_helper
INFO - 2023-06-07 06:47:57 --> Helper loaded: file_helper
INFO - 2023-06-07 06:47:57 --> Helper loaded: form_helper
INFO - 2023-06-07 06:47:57 --> Helper loaded: my_helper
INFO - 2023-06-07 06:47:57 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:47:57 --> Controller Class Initialized
INFO - 2023-06-07 06:47:57 --> Final output sent to browser
DEBUG - 2023-06-07 06:47:57 --> Total execution time: 0.0756
INFO - 2023-06-07 06:48:06 --> Config Class Initialized
INFO - 2023-06-07 06:48:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:48:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:48:06 --> Utf8 Class Initialized
INFO - 2023-06-07 06:48:06 --> URI Class Initialized
INFO - 2023-06-07 06:48:06 --> Router Class Initialized
INFO - 2023-06-07 06:48:06 --> Output Class Initialized
INFO - 2023-06-07 06:48:06 --> Security Class Initialized
DEBUG - 2023-06-07 06:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:48:06 --> Input Class Initialized
INFO - 2023-06-07 06:48:06 --> Language Class Initialized
INFO - 2023-06-07 06:48:06 --> Language Class Initialized
INFO - 2023-06-07 06:48:06 --> Config Class Initialized
INFO - 2023-06-07 06:48:06 --> Loader Class Initialized
INFO - 2023-06-07 06:48:06 --> Helper loaded: url_helper
INFO - 2023-06-07 06:48:06 --> Helper loaded: file_helper
INFO - 2023-06-07 06:48:06 --> Helper loaded: form_helper
INFO - 2023-06-07 06:48:06 --> Helper loaded: my_helper
INFO - 2023-06-07 06:48:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:48:06 --> Controller Class Initialized
DEBUG - 2023-06-07 06:48:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:48:07 --> Final output sent to browser
DEBUG - 2023-06-07 06:48:07 --> Total execution time: 1.1608
INFO - 2023-06-07 06:49:58 --> Config Class Initialized
INFO - 2023-06-07 06:49:58 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:49:58 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:49:58 --> Utf8 Class Initialized
INFO - 2023-06-07 06:49:58 --> URI Class Initialized
INFO - 2023-06-07 06:49:58 --> Router Class Initialized
INFO - 2023-06-07 06:49:58 --> Output Class Initialized
INFO - 2023-06-07 06:49:58 --> Security Class Initialized
DEBUG - 2023-06-07 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:49:58 --> Input Class Initialized
INFO - 2023-06-07 06:49:58 --> Language Class Initialized
INFO - 2023-06-07 06:49:58 --> Language Class Initialized
INFO - 2023-06-07 06:49:58 --> Config Class Initialized
INFO - 2023-06-07 06:49:58 --> Loader Class Initialized
INFO - 2023-06-07 06:49:58 --> Helper loaded: url_helper
INFO - 2023-06-07 06:49:58 --> Helper loaded: file_helper
INFO - 2023-06-07 06:49:58 --> Helper loaded: form_helper
INFO - 2023-06-07 06:49:58 --> Helper loaded: my_helper
INFO - 2023-06-07 06:49:58 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:49:58 --> Controller Class Initialized
DEBUG - 2023-06-07 06:49:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:49:59 --> Final output sent to browser
DEBUG - 2023-06-07 06:49:59 --> Total execution time: 1.1786
INFO - 2023-06-07 06:50:49 --> Config Class Initialized
INFO - 2023-06-07 06:50:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:49 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:49 --> URI Class Initialized
INFO - 2023-06-07 06:50:49 --> Router Class Initialized
INFO - 2023-06-07 06:50:49 --> Output Class Initialized
INFO - 2023-06-07 06:50:49 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:49 --> Input Class Initialized
INFO - 2023-06-07 06:50:49 --> Language Class Initialized
INFO - 2023-06-07 06:50:49 --> Language Class Initialized
INFO - 2023-06-07 06:50:49 --> Config Class Initialized
INFO - 2023-06-07 06:50:49 --> Loader Class Initialized
INFO - 2023-06-07 06:50:49 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:49 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:49 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:49 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:49 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:49 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:49 --> Total execution time: 0.0751
INFO - 2023-06-07 06:50:51 --> Config Class Initialized
INFO - 2023-06-07 06:50:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:51 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:51 --> URI Class Initialized
INFO - 2023-06-07 06:50:51 --> Router Class Initialized
INFO - 2023-06-07 06:50:51 --> Output Class Initialized
INFO - 2023-06-07 06:50:51 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:51 --> Input Class Initialized
INFO - 2023-06-07 06:50:51 --> Language Class Initialized
INFO - 2023-06-07 06:50:51 --> Language Class Initialized
INFO - 2023-06-07 06:50:51 --> Config Class Initialized
INFO - 2023-06-07 06:50:51 --> Loader Class Initialized
INFO - 2023-06-07 06:50:51 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:51 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:51 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:51 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:51 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:51 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:51 --> Total execution time: 0.0660
INFO - 2023-06-07 06:50:52 --> Config Class Initialized
INFO - 2023-06-07 06:50:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:52 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:52 --> URI Class Initialized
INFO - 2023-06-07 06:50:52 --> Router Class Initialized
INFO - 2023-06-07 06:50:52 --> Output Class Initialized
INFO - 2023-06-07 06:50:52 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:52 --> Input Class Initialized
INFO - 2023-06-07 06:50:52 --> Language Class Initialized
INFO - 2023-06-07 06:50:52 --> Language Class Initialized
INFO - 2023-06-07 06:50:52 --> Config Class Initialized
INFO - 2023-06-07 06:50:52 --> Loader Class Initialized
INFO - 2023-06-07 06:50:52 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:52 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:52 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:52 --> Total execution time: 0.0527
INFO - 2023-06-07 06:50:52 --> Config Class Initialized
INFO - 2023-06-07 06:50:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:52 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:52 --> URI Class Initialized
INFO - 2023-06-07 06:50:52 --> Router Class Initialized
INFO - 2023-06-07 06:50:52 --> Output Class Initialized
INFO - 2023-06-07 06:50:52 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:52 --> Input Class Initialized
INFO - 2023-06-07 06:50:52 --> Language Class Initialized
INFO - 2023-06-07 06:50:52 --> Language Class Initialized
INFO - 2023-06-07 06:50:52 --> Config Class Initialized
INFO - 2023-06-07 06:50:52 --> Loader Class Initialized
INFO - 2023-06-07 06:50:52 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:52 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:52 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:52 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:52 --> Total execution time: 0.0619
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:53 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:53 --> URI Class Initialized
INFO - 2023-06-07 06:50:53 --> Router Class Initialized
INFO - 2023-06-07 06:50:53 --> Output Class Initialized
INFO - 2023-06-07 06:50:53 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:53 --> Input Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Loader Class Initialized
INFO - 2023-06-07 06:50:53 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:53 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:53 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:53 --> Total execution time: 0.0558
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:53 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:53 --> URI Class Initialized
INFO - 2023-06-07 06:50:53 --> Router Class Initialized
INFO - 2023-06-07 06:50:53 --> Output Class Initialized
INFO - 2023-06-07 06:50:53 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:53 --> Input Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Loader Class Initialized
INFO - 2023-06-07 06:50:53 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:53 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:53 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:53 --> Total execution time: 0.0673
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:53 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:53 --> URI Class Initialized
INFO - 2023-06-07 06:50:53 --> Router Class Initialized
INFO - 2023-06-07 06:50:53 --> Output Class Initialized
INFO - 2023-06-07 06:50:53 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:53 --> Input Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Language Class Initialized
INFO - 2023-06-07 06:50:53 --> Config Class Initialized
INFO - 2023-06-07 06:50:53 --> Loader Class Initialized
INFO - 2023-06-07 06:50:53 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:53 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:53 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:53 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:54 --> Total execution time: 0.0548
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:54 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:54 --> URI Class Initialized
INFO - 2023-06-07 06:50:54 --> Router Class Initialized
INFO - 2023-06-07 06:50:54 --> Output Class Initialized
INFO - 2023-06-07 06:50:54 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:54 --> Input Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Loader Class Initialized
INFO - 2023-06-07 06:50:54 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:54 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:54 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:54 --> Total execution time: 0.0432
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:54 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:54 --> URI Class Initialized
INFO - 2023-06-07 06:50:54 --> Router Class Initialized
INFO - 2023-06-07 06:50:54 --> Output Class Initialized
INFO - 2023-06-07 06:50:54 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:54 --> Input Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Loader Class Initialized
INFO - 2023-06-07 06:50:54 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:54 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:54 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:54 --> Total execution time: 0.0529
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:54 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:54 --> URI Class Initialized
INFO - 2023-06-07 06:50:54 --> Router Class Initialized
INFO - 2023-06-07 06:50:54 --> Output Class Initialized
INFO - 2023-06-07 06:50:54 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:54 --> Input Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Loader Class Initialized
INFO - 2023-06-07 06:50:54 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:54 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:54 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:54 --> Total execution time: 0.0543
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:54 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:54 --> URI Class Initialized
INFO - 2023-06-07 06:50:54 --> Router Class Initialized
INFO - 2023-06-07 06:50:54 --> Output Class Initialized
INFO - 2023-06-07 06:50:54 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:54 --> Input Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Language Class Initialized
INFO - 2023-06-07 06:50:54 --> Config Class Initialized
INFO - 2023-06-07 06:50:54 --> Loader Class Initialized
INFO - 2023-06-07 06:50:54 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:54 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:54 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:54 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:54 --> Total execution time: 0.0562
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:55 --> URI Class Initialized
INFO - 2023-06-07 06:50:55 --> Router Class Initialized
INFO - 2023-06-07 06:50:55 --> Output Class Initialized
INFO - 2023-06-07 06:50:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:55 --> Input Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Loader Class Initialized
INFO - 2023-06-07 06:50:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:55 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:55 --> Total execution time: 0.0418
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:55 --> URI Class Initialized
INFO - 2023-06-07 06:50:55 --> Router Class Initialized
INFO - 2023-06-07 06:50:55 --> Output Class Initialized
INFO - 2023-06-07 06:50:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:55 --> Input Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Loader Class Initialized
INFO - 2023-06-07 06:50:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:55 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:55 --> Total execution time: 0.0429
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:55 --> URI Class Initialized
INFO - 2023-06-07 06:50:55 --> Router Class Initialized
INFO - 2023-06-07 06:50:55 --> Output Class Initialized
INFO - 2023-06-07 06:50:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:55 --> Input Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Loader Class Initialized
INFO - 2023-06-07 06:50:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:55 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:55 --> Total execution time: 0.0413
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:55 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:55 --> URI Class Initialized
INFO - 2023-06-07 06:50:55 --> Router Class Initialized
INFO - 2023-06-07 06:50:55 --> Output Class Initialized
INFO - 2023-06-07 06:50:55 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:55 --> Input Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Language Class Initialized
INFO - 2023-06-07 06:50:55 --> Config Class Initialized
INFO - 2023-06-07 06:50:55 --> Loader Class Initialized
INFO - 2023-06-07 06:50:55 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:55 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:55 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:55 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:55 --> Total execution time: 0.0429
INFO - 2023-06-07 06:50:56 --> Config Class Initialized
INFO - 2023-06-07 06:50:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:50:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:50:56 --> Utf8 Class Initialized
INFO - 2023-06-07 06:50:56 --> URI Class Initialized
INFO - 2023-06-07 06:50:56 --> Router Class Initialized
INFO - 2023-06-07 06:50:56 --> Output Class Initialized
INFO - 2023-06-07 06:50:56 --> Security Class Initialized
DEBUG - 2023-06-07 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:50:56 --> Input Class Initialized
INFO - 2023-06-07 06:50:56 --> Language Class Initialized
INFO - 2023-06-07 06:50:56 --> Language Class Initialized
INFO - 2023-06-07 06:50:56 --> Config Class Initialized
INFO - 2023-06-07 06:50:56 --> Loader Class Initialized
INFO - 2023-06-07 06:50:56 --> Helper loaded: url_helper
INFO - 2023-06-07 06:50:56 --> Helper loaded: file_helper
INFO - 2023-06-07 06:50:56 --> Helper loaded: form_helper
INFO - 2023-06-07 06:50:56 --> Helper loaded: my_helper
INFO - 2023-06-07 06:50:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:50:56 --> Controller Class Initialized
DEBUG - 2023-06-07 06:50:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:50:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:50:56 --> Final output sent to browser
DEBUG - 2023-06-07 06:50:56 --> Total execution time: 0.0430
INFO - 2023-06-07 06:51:03 --> Config Class Initialized
INFO - 2023-06-07 06:51:03 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:51:03 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:51:03 --> Utf8 Class Initialized
INFO - 2023-06-07 06:51:03 --> URI Class Initialized
INFO - 2023-06-07 06:51:03 --> Router Class Initialized
INFO - 2023-06-07 06:51:03 --> Output Class Initialized
INFO - 2023-06-07 06:51:03 --> Security Class Initialized
DEBUG - 2023-06-07 06:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:51:03 --> Input Class Initialized
INFO - 2023-06-07 06:51:03 --> Language Class Initialized
INFO - 2023-06-07 06:51:03 --> Language Class Initialized
INFO - 2023-06-07 06:51:03 --> Config Class Initialized
INFO - 2023-06-07 06:51:03 --> Loader Class Initialized
INFO - 2023-06-07 06:51:03 --> Helper loaded: url_helper
INFO - 2023-06-07 06:51:03 --> Helper loaded: file_helper
INFO - 2023-06-07 06:51:03 --> Helper loaded: form_helper
INFO - 2023-06-07 06:51:03 --> Helper loaded: my_helper
INFO - 2023-06-07 06:51:03 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:51:03 --> Controller Class Initialized
DEBUG - 2023-06-07 06:51:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:51:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:51:03 --> Final output sent to browser
DEBUG - 2023-06-07 06:51:03 --> Total execution time: 0.0767
INFO - 2023-06-07 06:51:12 --> Config Class Initialized
INFO - 2023-06-07 06:51:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:51:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:51:12 --> Utf8 Class Initialized
INFO - 2023-06-07 06:51:12 --> URI Class Initialized
INFO - 2023-06-07 06:51:12 --> Router Class Initialized
INFO - 2023-06-07 06:51:12 --> Output Class Initialized
INFO - 2023-06-07 06:51:12 --> Security Class Initialized
DEBUG - 2023-06-07 06:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:51:12 --> Input Class Initialized
INFO - 2023-06-07 06:51:12 --> Language Class Initialized
INFO - 2023-06-07 06:51:12 --> Language Class Initialized
INFO - 2023-06-07 06:51:12 --> Config Class Initialized
INFO - 2023-06-07 06:51:12 --> Loader Class Initialized
INFO - 2023-06-07 06:51:12 --> Helper loaded: url_helper
INFO - 2023-06-07 06:51:12 --> Helper loaded: file_helper
INFO - 2023-06-07 06:51:12 --> Helper loaded: form_helper
INFO - 2023-06-07 06:51:12 --> Helper loaded: my_helper
INFO - 2023-06-07 06:51:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:51:12 --> Controller Class Initialized
DEBUG - 2023-06-07 06:51:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:51:13 --> Final output sent to browser
DEBUG - 2023-06-07 06:51:13 --> Total execution time: 1.1721
INFO - 2023-06-07 06:53:30 --> Config Class Initialized
INFO - 2023-06-07 06:53:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:53:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:53:30 --> Utf8 Class Initialized
INFO - 2023-06-07 06:53:30 --> URI Class Initialized
INFO - 2023-06-07 06:53:30 --> Router Class Initialized
INFO - 2023-06-07 06:53:30 --> Output Class Initialized
INFO - 2023-06-07 06:53:30 --> Security Class Initialized
DEBUG - 2023-06-07 06:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:53:30 --> Input Class Initialized
INFO - 2023-06-07 06:53:30 --> Language Class Initialized
INFO - 2023-06-07 06:53:30 --> Language Class Initialized
INFO - 2023-06-07 06:53:30 --> Config Class Initialized
INFO - 2023-06-07 06:53:30 --> Loader Class Initialized
INFO - 2023-06-07 06:53:30 --> Helper loaded: url_helper
INFO - 2023-06-07 06:53:30 --> Helper loaded: file_helper
INFO - 2023-06-07 06:53:30 --> Helper loaded: form_helper
INFO - 2023-06-07 06:53:30 --> Helper loaded: my_helper
INFO - 2023-06-07 06:53:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:53:30 --> Controller Class Initialized
DEBUG - 2023-06-07 06:53:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:53:31 --> Final output sent to browser
DEBUG - 2023-06-07 06:53:31 --> Total execution time: 1.1477
INFO - 2023-06-07 06:54:47 --> Config Class Initialized
INFO - 2023-06-07 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:54:47 --> Utf8 Class Initialized
INFO - 2023-06-07 06:54:47 --> URI Class Initialized
INFO - 2023-06-07 06:54:47 --> Router Class Initialized
INFO - 2023-06-07 06:54:47 --> Output Class Initialized
INFO - 2023-06-07 06:54:47 --> Security Class Initialized
DEBUG - 2023-06-07 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:54:47 --> Input Class Initialized
INFO - 2023-06-07 06:54:47 --> Language Class Initialized
INFO - 2023-06-07 06:54:47 --> Language Class Initialized
INFO - 2023-06-07 06:54:47 --> Config Class Initialized
INFO - 2023-06-07 06:54:47 --> Loader Class Initialized
INFO - 2023-06-07 06:54:47 --> Helper loaded: url_helper
INFO - 2023-06-07 06:54:47 --> Helper loaded: file_helper
INFO - 2023-06-07 06:54:47 --> Helper loaded: form_helper
INFO - 2023-06-07 06:54:47 --> Helper loaded: my_helper
INFO - 2023-06-07 06:54:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:54:47 --> Controller Class Initialized
DEBUG - 2023-06-07 06:54:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:54:48 --> Final output sent to browser
DEBUG - 2023-06-07 06:54:48 --> Total execution time: 1.1442
INFO - 2023-06-07 06:55:48 --> Config Class Initialized
INFO - 2023-06-07 06:55:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:55:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:55:48 --> Utf8 Class Initialized
INFO - 2023-06-07 06:55:48 --> URI Class Initialized
INFO - 2023-06-07 06:55:48 --> Router Class Initialized
INFO - 2023-06-07 06:55:48 --> Output Class Initialized
INFO - 2023-06-07 06:55:48 --> Security Class Initialized
DEBUG - 2023-06-07 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:55:48 --> Input Class Initialized
INFO - 2023-06-07 06:55:48 --> Language Class Initialized
INFO - 2023-06-07 06:55:48 --> Language Class Initialized
INFO - 2023-06-07 06:55:48 --> Config Class Initialized
INFO - 2023-06-07 06:55:48 --> Loader Class Initialized
INFO - 2023-06-07 06:55:48 --> Helper loaded: url_helper
INFO - 2023-06-07 06:55:48 --> Helper loaded: file_helper
INFO - 2023-06-07 06:55:48 --> Helper loaded: form_helper
INFO - 2023-06-07 06:55:48 --> Helper loaded: my_helper
INFO - 2023-06-07 06:55:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:55:48 --> Controller Class Initialized
DEBUG - 2023-06-07 06:55:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 06:55:48 --> Severity: error --> Exception: The html tag [meta] is not known by Html2Pdf. You can create it and push it on the Html2Pdf GitHub project. C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 1441
INFO - 2023-06-07 06:57:26 --> Config Class Initialized
INFO - 2023-06-07 06:57:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:57:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:57:26 --> Utf8 Class Initialized
INFO - 2023-06-07 06:57:26 --> URI Class Initialized
INFO - 2023-06-07 06:57:26 --> Router Class Initialized
INFO - 2023-06-07 06:57:26 --> Output Class Initialized
INFO - 2023-06-07 06:57:26 --> Security Class Initialized
DEBUG - 2023-06-07 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:57:26 --> Input Class Initialized
INFO - 2023-06-07 06:57:26 --> Language Class Initialized
INFO - 2023-06-07 06:57:26 --> Language Class Initialized
INFO - 2023-06-07 06:57:26 --> Config Class Initialized
INFO - 2023-06-07 06:57:26 --> Loader Class Initialized
INFO - 2023-06-07 06:57:26 --> Helper loaded: url_helper
INFO - 2023-06-07 06:57:26 --> Helper loaded: file_helper
INFO - 2023-06-07 06:57:26 --> Helper loaded: form_helper
INFO - 2023-06-07 06:57:26 --> Helper loaded: my_helper
INFO - 2023-06-07 06:57:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:57:26 --> Controller Class Initialized
DEBUG - 2023-06-07 06:57:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 06:57:27 --> Final output sent to browser
DEBUG - 2023-06-07 06:57:27 --> Total execution time: 1.2351
INFO - 2023-06-07 06:58:12 --> Config Class Initialized
INFO - 2023-06-07 06:58:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 06:58:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 06:58:12 --> Utf8 Class Initialized
INFO - 2023-06-07 06:58:12 --> URI Class Initialized
INFO - 2023-06-07 06:58:12 --> Router Class Initialized
INFO - 2023-06-07 06:58:12 --> Output Class Initialized
INFO - 2023-06-07 06:58:12 --> Security Class Initialized
DEBUG - 2023-06-07 06:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 06:58:12 --> Input Class Initialized
INFO - 2023-06-07 06:58:12 --> Language Class Initialized
INFO - 2023-06-07 06:58:12 --> Language Class Initialized
INFO - 2023-06-07 06:58:12 --> Config Class Initialized
INFO - 2023-06-07 06:58:12 --> Loader Class Initialized
INFO - 2023-06-07 06:58:12 --> Helper loaded: url_helper
INFO - 2023-06-07 06:58:12 --> Helper loaded: file_helper
INFO - 2023-06-07 06:58:12 --> Helper loaded: form_helper
INFO - 2023-06-07 06:58:12 --> Helper loaded: my_helper
INFO - 2023-06-07 06:58:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 06:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 06:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 06:58:12 --> Controller Class Initialized
DEBUG - 2023-06-07 06:58:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 06:58:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 06:58:12 --> Final output sent to browser
DEBUG - 2023-06-07 06:58:12 --> Total execution time: 0.0566
INFO - 2023-06-07 07:01:00 --> Config Class Initialized
INFO - 2023-06-07 07:01:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:01:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:01:00 --> Utf8 Class Initialized
INFO - 2023-06-07 07:01:00 --> URI Class Initialized
INFO - 2023-06-07 07:01:00 --> Router Class Initialized
INFO - 2023-06-07 07:01:00 --> Output Class Initialized
INFO - 2023-06-07 07:01:00 --> Security Class Initialized
DEBUG - 2023-06-07 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:01:00 --> Input Class Initialized
INFO - 2023-06-07 07:01:00 --> Language Class Initialized
INFO - 2023-06-07 07:01:00 --> Language Class Initialized
INFO - 2023-06-07 07:01:00 --> Config Class Initialized
INFO - 2023-06-07 07:01:00 --> Loader Class Initialized
INFO - 2023-06-07 07:01:00 --> Helper loaded: url_helper
INFO - 2023-06-07 07:01:00 --> Helper loaded: file_helper
INFO - 2023-06-07 07:01:00 --> Helper loaded: form_helper
INFO - 2023-06-07 07:01:00 --> Helper loaded: my_helper
INFO - 2023-06-07 07:01:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:01:00 --> Controller Class Initialized
DEBUG - 2023-06-07 07:01:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:01:01 --> Final output sent to browser
DEBUG - 2023-06-07 07:01:01 --> Total execution time: 1.1798
INFO - 2023-06-07 07:01:42 --> Config Class Initialized
INFO - 2023-06-07 07:01:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:01:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:01:42 --> Utf8 Class Initialized
INFO - 2023-06-07 07:01:42 --> URI Class Initialized
INFO - 2023-06-07 07:01:42 --> Router Class Initialized
INFO - 2023-06-07 07:01:42 --> Output Class Initialized
INFO - 2023-06-07 07:01:42 --> Security Class Initialized
DEBUG - 2023-06-07 07:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:01:42 --> Input Class Initialized
INFO - 2023-06-07 07:01:42 --> Language Class Initialized
INFO - 2023-06-07 07:01:42 --> Language Class Initialized
INFO - 2023-06-07 07:01:42 --> Config Class Initialized
INFO - 2023-06-07 07:01:42 --> Loader Class Initialized
INFO - 2023-06-07 07:01:42 --> Helper loaded: url_helper
INFO - 2023-06-07 07:01:42 --> Helper loaded: file_helper
INFO - 2023-06-07 07:01:42 --> Helper loaded: form_helper
INFO - 2023-06-07 07:01:42 --> Helper loaded: my_helper
INFO - 2023-06-07 07:01:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:01:42 --> Controller Class Initialized
DEBUG - 2023-06-07 07:01:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:01:44 --> Final output sent to browser
DEBUG - 2023-06-07 07:01:44 --> Total execution time: 1.2054
INFO - 2023-06-07 07:03:37 --> Config Class Initialized
INFO - 2023-06-07 07:03:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:03:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:03:37 --> Utf8 Class Initialized
INFO - 2023-06-07 07:03:37 --> URI Class Initialized
INFO - 2023-06-07 07:03:37 --> Router Class Initialized
INFO - 2023-06-07 07:03:37 --> Output Class Initialized
INFO - 2023-06-07 07:03:37 --> Security Class Initialized
DEBUG - 2023-06-07 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:03:37 --> Input Class Initialized
INFO - 2023-06-07 07:03:37 --> Language Class Initialized
INFO - 2023-06-07 07:03:37 --> Language Class Initialized
INFO - 2023-06-07 07:03:37 --> Config Class Initialized
INFO - 2023-06-07 07:03:37 --> Loader Class Initialized
INFO - 2023-06-07 07:03:37 --> Helper loaded: url_helper
INFO - 2023-06-07 07:03:37 --> Helper loaded: file_helper
INFO - 2023-06-07 07:03:37 --> Helper loaded: form_helper
INFO - 2023-06-07 07:03:37 --> Helper loaded: my_helper
INFO - 2023-06-07 07:03:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:03:37 --> Controller Class Initialized
DEBUG - 2023-06-07 07:03:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:03:37 --> Final output sent to browser
DEBUG - 2023-06-07 07:03:37 --> Total execution time: 0.1632
INFO - 2023-06-07 07:03:54 --> Config Class Initialized
INFO - 2023-06-07 07:03:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:03:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:03:54 --> Utf8 Class Initialized
INFO - 2023-06-07 07:03:54 --> URI Class Initialized
INFO - 2023-06-07 07:03:54 --> Router Class Initialized
INFO - 2023-06-07 07:03:54 --> Output Class Initialized
INFO - 2023-06-07 07:03:54 --> Security Class Initialized
DEBUG - 2023-06-07 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:03:54 --> Input Class Initialized
INFO - 2023-06-07 07:03:54 --> Language Class Initialized
INFO - 2023-06-07 07:03:54 --> Language Class Initialized
INFO - 2023-06-07 07:03:54 --> Config Class Initialized
INFO - 2023-06-07 07:03:54 --> Loader Class Initialized
INFO - 2023-06-07 07:03:54 --> Helper loaded: url_helper
INFO - 2023-06-07 07:03:54 --> Helper loaded: file_helper
INFO - 2023-06-07 07:03:54 --> Helper loaded: form_helper
INFO - 2023-06-07 07:03:54 --> Helper loaded: my_helper
INFO - 2023-06-07 07:03:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:03:54 --> Controller Class Initialized
DEBUG - 2023-06-07 07:03:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:03:55 --> Final output sent to browser
DEBUG - 2023-06-07 07:03:55 --> Total execution time: 1.1185
INFO - 2023-06-07 07:07:08 --> Config Class Initialized
INFO - 2023-06-07 07:07:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:07:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:07:08 --> Utf8 Class Initialized
INFO - 2023-06-07 07:07:08 --> URI Class Initialized
INFO - 2023-06-07 07:07:08 --> Router Class Initialized
INFO - 2023-06-07 07:07:08 --> Output Class Initialized
INFO - 2023-06-07 07:07:08 --> Security Class Initialized
DEBUG - 2023-06-07 07:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:07:08 --> Input Class Initialized
INFO - 2023-06-07 07:07:08 --> Language Class Initialized
INFO - 2023-06-07 07:07:08 --> Language Class Initialized
INFO - 2023-06-07 07:07:08 --> Config Class Initialized
INFO - 2023-06-07 07:07:08 --> Loader Class Initialized
INFO - 2023-06-07 07:07:08 --> Helper loaded: url_helper
INFO - 2023-06-07 07:07:08 --> Helper loaded: file_helper
INFO - 2023-06-07 07:07:08 --> Helper loaded: form_helper
INFO - 2023-06-07 07:07:08 --> Helper loaded: my_helper
INFO - 2023-06-07 07:07:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:07:08 --> Controller Class Initialized
DEBUG - 2023-06-07 07:07:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 07:07:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 07:07:08 --> Final output sent to browser
DEBUG - 2023-06-07 07:07:08 --> Total execution time: 0.0472
INFO - 2023-06-07 07:07:12 --> Config Class Initialized
INFO - 2023-06-07 07:07:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:07:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:07:12 --> Utf8 Class Initialized
INFO - 2023-06-07 07:07:12 --> URI Class Initialized
INFO - 2023-06-07 07:07:12 --> Router Class Initialized
INFO - 2023-06-07 07:07:12 --> Output Class Initialized
INFO - 2023-06-07 07:07:12 --> Security Class Initialized
DEBUG - 2023-06-07 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:07:12 --> Input Class Initialized
INFO - 2023-06-07 07:07:12 --> Language Class Initialized
ERROR - 2023-06-07 07:07:12 --> 404 Page Not Found: /index
INFO - 2023-06-07 07:08:16 --> Config Class Initialized
INFO - 2023-06-07 07:08:16 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:08:16 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:08:16 --> Utf8 Class Initialized
INFO - 2023-06-07 07:08:16 --> URI Class Initialized
INFO - 2023-06-07 07:08:16 --> Router Class Initialized
INFO - 2023-06-07 07:08:16 --> Output Class Initialized
INFO - 2023-06-07 07:08:16 --> Security Class Initialized
DEBUG - 2023-06-07 07:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:08:16 --> Input Class Initialized
INFO - 2023-06-07 07:08:16 --> Language Class Initialized
INFO - 2023-06-07 07:08:16 --> Language Class Initialized
INFO - 2023-06-07 07:08:16 --> Config Class Initialized
INFO - 2023-06-07 07:08:16 --> Loader Class Initialized
INFO - 2023-06-07 07:08:16 --> Helper loaded: url_helper
INFO - 2023-06-07 07:08:16 --> Helper loaded: file_helper
INFO - 2023-06-07 07:08:16 --> Helper loaded: form_helper
INFO - 2023-06-07 07:08:16 --> Helper loaded: my_helper
INFO - 2023-06-07 07:08:16 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:08:16 --> Controller Class Initialized
DEBUG - 2023-06-07 07:08:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:08:16 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:14:42 --> Config Class Initialized
INFO - 2023-06-07 07:14:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:14:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:14:42 --> Utf8 Class Initialized
INFO - 2023-06-07 07:14:42 --> URI Class Initialized
INFO - 2023-06-07 07:14:42 --> Router Class Initialized
INFO - 2023-06-07 07:14:42 --> Output Class Initialized
INFO - 2023-06-07 07:14:42 --> Security Class Initialized
DEBUG - 2023-06-07 07:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:14:42 --> Input Class Initialized
INFO - 2023-06-07 07:14:42 --> Language Class Initialized
INFO - 2023-06-07 07:14:42 --> Language Class Initialized
INFO - 2023-06-07 07:14:42 --> Config Class Initialized
INFO - 2023-06-07 07:14:42 --> Loader Class Initialized
INFO - 2023-06-07 07:14:42 --> Helper loaded: url_helper
INFO - 2023-06-07 07:14:42 --> Helper loaded: file_helper
INFO - 2023-06-07 07:14:42 --> Helper loaded: form_helper
INFO - 2023-06-07 07:14:42 --> Helper loaded: my_helper
INFO - 2023-06-07 07:14:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:14:42 --> Controller Class Initialized
DEBUG - 2023-06-07 07:14:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:14:42 --> Severity: error --> Exception: Call to undefined method Spipu\Html2Pdf\Html2Pdf::setFontSubsetting() C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 2596
INFO - 2023-06-07 07:14:57 --> Config Class Initialized
INFO - 2023-06-07 07:14:57 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:14:57 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:14:57 --> Utf8 Class Initialized
INFO - 2023-06-07 07:14:57 --> URI Class Initialized
INFO - 2023-06-07 07:14:57 --> Router Class Initialized
INFO - 2023-06-07 07:14:57 --> Output Class Initialized
INFO - 2023-06-07 07:14:57 --> Security Class Initialized
DEBUG - 2023-06-07 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:14:57 --> Input Class Initialized
INFO - 2023-06-07 07:14:57 --> Language Class Initialized
INFO - 2023-06-07 07:14:57 --> Language Class Initialized
INFO - 2023-06-07 07:14:57 --> Config Class Initialized
INFO - 2023-06-07 07:14:57 --> Loader Class Initialized
INFO - 2023-06-07 07:14:57 --> Helper loaded: url_helper
INFO - 2023-06-07 07:14:57 --> Helper loaded: file_helper
INFO - 2023-06-07 07:14:57 --> Helper loaded: form_helper
INFO - 2023-06-07 07:14:57 --> Helper loaded: my_helper
INFO - 2023-06-07 07:14:57 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:14:57 --> Controller Class Initialized
DEBUG - 2023-06-07 07:14:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:14:58 --> Final output sent to browser
DEBUG - 2023-06-07 07:14:58 --> Total execution time: 1.1132
INFO - 2023-06-07 07:20:21 --> Config Class Initialized
INFO - 2023-06-07 07:20:21 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:20:21 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:20:21 --> Utf8 Class Initialized
INFO - 2023-06-07 07:20:21 --> URI Class Initialized
INFO - 2023-06-07 07:20:21 --> Router Class Initialized
INFO - 2023-06-07 07:20:21 --> Output Class Initialized
INFO - 2023-06-07 07:20:21 --> Security Class Initialized
DEBUG - 2023-06-07 07:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:20:21 --> Input Class Initialized
INFO - 2023-06-07 07:20:21 --> Language Class Initialized
INFO - 2023-06-07 07:20:21 --> Language Class Initialized
INFO - 2023-06-07 07:20:21 --> Config Class Initialized
INFO - 2023-06-07 07:20:21 --> Loader Class Initialized
INFO - 2023-06-07 07:20:21 --> Helper loaded: url_helper
INFO - 2023-06-07 07:20:21 --> Helper loaded: file_helper
INFO - 2023-06-07 07:20:21 --> Helper loaded: form_helper
INFO - 2023-06-07 07:20:21 --> Helper loaded: my_helper
INFO - 2023-06-07 07:20:21 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:20:21 --> Controller Class Initialized
DEBUG - 2023-06-07 07:20:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:20:21 --> Severity: Warning --> require_once(C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers/vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 2591
ERROR - 2023-06-07 07:20:21 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers/vendor/autoload.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 2591
INFO - 2023-06-07 07:23:30 --> Config Class Initialized
INFO - 2023-06-07 07:23:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:23:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:23:30 --> Utf8 Class Initialized
INFO - 2023-06-07 07:23:30 --> URI Class Initialized
INFO - 2023-06-07 07:23:30 --> Router Class Initialized
INFO - 2023-06-07 07:23:30 --> Output Class Initialized
INFO - 2023-06-07 07:23:30 --> Security Class Initialized
DEBUG - 2023-06-07 07:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:23:30 --> Input Class Initialized
INFO - 2023-06-07 07:23:30 --> Language Class Initialized
INFO - 2023-06-07 07:23:30 --> Language Class Initialized
INFO - 2023-06-07 07:23:30 --> Config Class Initialized
INFO - 2023-06-07 07:23:30 --> Loader Class Initialized
INFO - 2023-06-07 07:23:30 --> Helper loaded: url_helper
INFO - 2023-06-07 07:23:30 --> Helper loaded: file_helper
INFO - 2023-06-07 07:23:30 --> Helper loaded: form_helper
INFO - 2023-06-07 07:23:30 --> Helper loaded: my_helper
INFO - 2023-06-07 07:23:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:23:30 --> Controller Class Initialized
DEBUG - 2023-06-07 07:23:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:23:30 --> Severity: error --> Exception: Cannot write to an undeclared property Mpdf\Mpdf::$encoding C:\xampp\htdocs\myraportk13\vendor\mpdf\mpdf\src\Strict.php 44
INFO - 2023-06-07 07:23:51 --> Config Class Initialized
INFO - 2023-06-07 07:23:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:23:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:23:51 --> Utf8 Class Initialized
INFO - 2023-06-07 07:23:51 --> URI Class Initialized
INFO - 2023-06-07 07:23:51 --> Router Class Initialized
INFO - 2023-06-07 07:23:51 --> Output Class Initialized
INFO - 2023-06-07 07:23:51 --> Security Class Initialized
DEBUG - 2023-06-07 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:23:51 --> Input Class Initialized
INFO - 2023-06-07 07:23:51 --> Language Class Initialized
INFO - 2023-06-07 07:23:51 --> Language Class Initialized
INFO - 2023-06-07 07:23:51 --> Config Class Initialized
INFO - 2023-06-07 07:23:51 --> Loader Class Initialized
INFO - 2023-06-07 07:23:51 --> Helper loaded: url_helper
INFO - 2023-06-07 07:23:51 --> Helper loaded: file_helper
INFO - 2023-06-07 07:23:51 --> Helper loaded: form_helper
INFO - 2023-06-07 07:23:51 --> Helper loaded: my_helper
INFO - 2023-06-07 07:23:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:23:51 --> Controller Class Initialized
DEBUG - 2023-06-07 07:23:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:23:52 --> Final output sent to browser
DEBUG - 2023-06-07 07:23:52 --> Total execution time: 0.7635
INFO - 2023-06-07 07:24:23 --> Config Class Initialized
INFO - 2023-06-07 07:24:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:24:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:24:23 --> Utf8 Class Initialized
INFO - 2023-06-07 07:24:23 --> URI Class Initialized
INFO - 2023-06-07 07:24:23 --> Router Class Initialized
INFO - 2023-06-07 07:24:23 --> Output Class Initialized
INFO - 2023-06-07 07:24:23 --> Security Class Initialized
DEBUG - 2023-06-07 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:24:23 --> Input Class Initialized
INFO - 2023-06-07 07:24:23 --> Language Class Initialized
INFO - 2023-06-07 07:24:23 --> Language Class Initialized
INFO - 2023-06-07 07:24:23 --> Config Class Initialized
INFO - 2023-06-07 07:24:23 --> Loader Class Initialized
INFO - 2023-06-07 07:24:23 --> Helper loaded: url_helper
INFO - 2023-06-07 07:24:23 --> Helper loaded: file_helper
INFO - 2023-06-07 07:24:23 --> Helper loaded: form_helper
INFO - 2023-06-07 07:24:23 --> Helper loaded: my_helper
INFO - 2023-06-07 07:24:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:24:23 --> Controller Class Initialized
DEBUG - 2023-06-07 07:24:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:24:23 --> Final output sent to browser
DEBUG - 2023-06-07 07:24:23 --> Total execution time: 0.5872
INFO - 2023-06-07 07:28:53 --> Config Class Initialized
INFO - 2023-06-07 07:28:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:28:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:28:53 --> Utf8 Class Initialized
INFO - 2023-06-07 07:28:53 --> URI Class Initialized
INFO - 2023-06-07 07:28:53 --> Router Class Initialized
INFO - 2023-06-07 07:28:53 --> Output Class Initialized
INFO - 2023-06-07 07:28:53 --> Security Class Initialized
DEBUG - 2023-06-07 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:28:53 --> Input Class Initialized
INFO - 2023-06-07 07:28:53 --> Language Class Initialized
INFO - 2023-06-07 07:28:53 --> Language Class Initialized
INFO - 2023-06-07 07:28:53 --> Config Class Initialized
INFO - 2023-06-07 07:28:53 --> Loader Class Initialized
INFO - 2023-06-07 07:28:53 --> Helper loaded: url_helper
INFO - 2023-06-07 07:28:53 --> Helper loaded: file_helper
INFO - 2023-06-07 07:28:53 --> Helper loaded: form_helper
INFO - 2023-06-07 07:28:53 --> Helper loaded: my_helper
INFO - 2023-06-07 07:28:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:28:53 --> Controller Class Initialized
DEBUG - 2023-06-07 07:28:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:28:54 --> Final output sent to browser
DEBUG - 2023-06-07 07:28:54 --> Total execution time: 0.5558
INFO - 2023-06-07 07:28:59 --> Config Class Initialized
INFO - 2023-06-07 07:28:59 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:28:59 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:28:59 --> Utf8 Class Initialized
INFO - 2023-06-07 07:28:59 --> URI Class Initialized
INFO - 2023-06-07 07:28:59 --> Router Class Initialized
INFO - 2023-06-07 07:28:59 --> Output Class Initialized
INFO - 2023-06-07 07:28:59 --> Security Class Initialized
DEBUG - 2023-06-07 07:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:28:59 --> Input Class Initialized
INFO - 2023-06-07 07:28:59 --> Language Class Initialized
INFO - 2023-06-07 07:28:59 --> Language Class Initialized
INFO - 2023-06-07 07:28:59 --> Config Class Initialized
INFO - 2023-06-07 07:28:59 --> Loader Class Initialized
INFO - 2023-06-07 07:28:59 --> Helper loaded: url_helper
INFO - 2023-06-07 07:28:59 --> Helper loaded: file_helper
INFO - 2023-06-07 07:28:59 --> Helper loaded: form_helper
INFO - 2023-06-07 07:28:59 --> Helper loaded: my_helper
INFO - 2023-06-07 07:28:59 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:28:59 --> Controller Class Initialized
DEBUG - 2023-06-07 07:28:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:29:00 --> Final output sent to browser
DEBUG - 2023-06-07 07:29:00 --> Total execution time: 0.5249
INFO - 2023-06-07 07:33:17 --> Config Class Initialized
INFO - 2023-06-07 07:33:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:33:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:33:17 --> Utf8 Class Initialized
INFO - 2023-06-07 07:33:17 --> URI Class Initialized
INFO - 2023-06-07 07:33:17 --> Router Class Initialized
INFO - 2023-06-07 07:33:17 --> Output Class Initialized
INFO - 2023-06-07 07:33:17 --> Security Class Initialized
DEBUG - 2023-06-07 07:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:33:17 --> Input Class Initialized
INFO - 2023-06-07 07:33:17 --> Language Class Initialized
INFO - 2023-06-07 07:33:17 --> Language Class Initialized
INFO - 2023-06-07 07:33:17 --> Config Class Initialized
INFO - 2023-06-07 07:33:17 --> Loader Class Initialized
INFO - 2023-06-07 07:33:17 --> Helper loaded: url_helper
INFO - 2023-06-07 07:33:17 --> Helper loaded: file_helper
INFO - 2023-06-07 07:33:17 --> Helper loaded: form_helper
INFO - 2023-06-07 07:33:17 --> Helper loaded: my_helper
INFO - 2023-06-07 07:33:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:33:17 --> Controller Class Initialized
DEBUG - 2023-06-07 07:33:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:33:18 --> Final output sent to browser
DEBUG - 2023-06-07 07:33:18 --> Total execution time: 0.4452
INFO - 2023-06-07 07:33:30 --> Config Class Initialized
INFO - 2023-06-07 07:33:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:33:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:33:30 --> Utf8 Class Initialized
INFO - 2023-06-07 07:33:30 --> URI Class Initialized
INFO - 2023-06-07 07:33:30 --> Router Class Initialized
INFO - 2023-06-07 07:33:30 --> Output Class Initialized
INFO - 2023-06-07 07:33:30 --> Security Class Initialized
DEBUG - 2023-06-07 07:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:33:30 --> Input Class Initialized
INFO - 2023-06-07 07:33:30 --> Language Class Initialized
INFO - 2023-06-07 07:33:30 --> Language Class Initialized
INFO - 2023-06-07 07:33:30 --> Config Class Initialized
INFO - 2023-06-07 07:33:30 --> Loader Class Initialized
INFO - 2023-06-07 07:33:30 --> Helper loaded: url_helper
INFO - 2023-06-07 07:33:30 --> Helper loaded: file_helper
INFO - 2023-06-07 07:33:30 --> Helper loaded: form_helper
INFO - 2023-06-07 07:33:30 --> Helper loaded: my_helper
INFO - 2023-06-07 07:33:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:33:30 --> Controller Class Initialized
DEBUG - 2023-06-07 07:33:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:33:31 --> Final output sent to browser
DEBUG - 2023-06-07 07:33:31 --> Total execution time: 1.0065
INFO - 2023-06-07 07:33:35 --> Config Class Initialized
INFO - 2023-06-07 07:33:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:33:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:33:35 --> Utf8 Class Initialized
INFO - 2023-06-07 07:33:35 --> URI Class Initialized
INFO - 2023-06-07 07:33:35 --> Router Class Initialized
INFO - 2023-06-07 07:33:35 --> Output Class Initialized
INFO - 2023-06-07 07:33:35 --> Security Class Initialized
DEBUG - 2023-06-07 07:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:33:35 --> Input Class Initialized
INFO - 2023-06-07 07:33:35 --> Language Class Initialized
INFO - 2023-06-07 07:33:35 --> Language Class Initialized
INFO - 2023-06-07 07:33:35 --> Config Class Initialized
INFO - 2023-06-07 07:33:35 --> Loader Class Initialized
INFO - 2023-06-07 07:33:35 --> Helper loaded: url_helper
INFO - 2023-06-07 07:33:35 --> Helper loaded: file_helper
INFO - 2023-06-07 07:33:35 --> Helper loaded: form_helper
INFO - 2023-06-07 07:33:35 --> Helper loaded: my_helper
INFO - 2023-06-07 07:33:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:33:35 --> Controller Class Initialized
DEBUG - 2023-06-07 07:33:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:33:36 --> Final output sent to browser
DEBUG - 2023-06-07 07:33:36 --> Total execution time: 0.9469
INFO - 2023-06-07 07:39:22 --> Config Class Initialized
INFO - 2023-06-07 07:39:22 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:39:22 --> Utf8 Class Initialized
INFO - 2023-06-07 07:39:22 --> URI Class Initialized
INFO - 2023-06-07 07:39:22 --> Router Class Initialized
INFO - 2023-06-07 07:39:22 --> Output Class Initialized
INFO - 2023-06-07 07:39:22 --> Security Class Initialized
DEBUG - 2023-06-07 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:39:22 --> Input Class Initialized
INFO - 2023-06-07 07:39:22 --> Language Class Initialized
INFO - 2023-06-07 07:39:22 --> Language Class Initialized
INFO - 2023-06-07 07:39:22 --> Config Class Initialized
INFO - 2023-06-07 07:39:22 --> Loader Class Initialized
INFO - 2023-06-07 07:39:23 --> Helper loaded: url_helper
INFO - 2023-06-07 07:39:23 --> Helper loaded: file_helper
INFO - 2023-06-07 07:39:23 --> Helper loaded: form_helper
INFO - 2023-06-07 07:39:23 --> Helper loaded: my_helper
INFO - 2023-06-07 07:39:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:39:23 --> Controller Class Initialized
DEBUG - 2023-06-07 07:39:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:39:23 --> Final output sent to browser
DEBUG - 2023-06-07 07:39:23 --> Total execution time: 1.0222
INFO - 2023-06-07 07:39:28 --> Config Class Initialized
INFO - 2023-06-07 07:39:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:39:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:39:28 --> Utf8 Class Initialized
INFO - 2023-06-07 07:39:28 --> URI Class Initialized
INFO - 2023-06-07 07:39:28 --> Router Class Initialized
INFO - 2023-06-07 07:39:28 --> Output Class Initialized
INFO - 2023-06-07 07:39:28 --> Security Class Initialized
DEBUG - 2023-06-07 07:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:39:28 --> Input Class Initialized
INFO - 2023-06-07 07:39:28 --> Language Class Initialized
INFO - 2023-06-07 07:39:28 --> Language Class Initialized
INFO - 2023-06-07 07:39:28 --> Config Class Initialized
INFO - 2023-06-07 07:39:28 --> Loader Class Initialized
INFO - 2023-06-07 07:39:28 --> Helper loaded: url_helper
INFO - 2023-06-07 07:39:28 --> Helper loaded: file_helper
INFO - 2023-06-07 07:39:28 --> Helper loaded: form_helper
INFO - 2023-06-07 07:39:28 --> Helper loaded: my_helper
INFO - 2023-06-07 07:39:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:39:28 --> Controller Class Initialized
DEBUG - 2023-06-07 07:39:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:39:29 --> Final output sent to browser
DEBUG - 2023-06-07 07:39:29 --> Total execution time: 1.0319
INFO - 2023-06-07 07:41:44 --> Config Class Initialized
INFO - 2023-06-07 07:41:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:41:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:41:44 --> Utf8 Class Initialized
INFO - 2023-06-07 07:41:44 --> URI Class Initialized
INFO - 2023-06-07 07:41:44 --> Router Class Initialized
INFO - 2023-06-07 07:41:44 --> Output Class Initialized
INFO - 2023-06-07 07:41:44 --> Security Class Initialized
DEBUG - 2023-06-07 07:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:41:44 --> Input Class Initialized
INFO - 2023-06-07 07:41:44 --> Language Class Initialized
INFO - 2023-06-07 07:41:44 --> Language Class Initialized
INFO - 2023-06-07 07:41:44 --> Config Class Initialized
INFO - 2023-06-07 07:41:44 --> Loader Class Initialized
INFO - 2023-06-07 07:41:44 --> Helper loaded: url_helper
INFO - 2023-06-07 07:41:44 --> Helper loaded: file_helper
INFO - 2023-06-07 07:41:44 --> Helper loaded: form_helper
INFO - 2023-06-07 07:41:44 --> Helper loaded: my_helper
INFO - 2023-06-07 07:41:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:41:44 --> Controller Class Initialized
DEBUG - 2023-06-07 07:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:41:45 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:40 --> Config Class Initialized
INFO - 2023-06-07 07:45:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:40 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:40 --> URI Class Initialized
INFO - 2023-06-07 07:45:40 --> Router Class Initialized
INFO - 2023-06-07 07:45:40 --> Output Class Initialized
INFO - 2023-06-07 07:45:40 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:40 --> Input Class Initialized
INFO - 2023-06-07 07:45:40 --> Language Class Initialized
INFO - 2023-06-07 07:45:40 --> Language Class Initialized
INFO - 2023-06-07 07:45:40 --> Config Class Initialized
INFO - 2023-06-07 07:45:40 --> Loader Class Initialized
INFO - 2023-06-07 07:45:40 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:40 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:40 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:40 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:40 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:40 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:43 --> Config Class Initialized
INFO - 2023-06-07 07:45:43 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:43 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:43 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:43 --> URI Class Initialized
INFO - 2023-06-07 07:45:43 --> Router Class Initialized
INFO - 2023-06-07 07:45:43 --> Output Class Initialized
INFO - 2023-06-07 07:45:43 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:43 --> Input Class Initialized
INFO - 2023-06-07 07:45:43 --> Language Class Initialized
INFO - 2023-06-07 07:45:43 --> Language Class Initialized
INFO - 2023-06-07 07:45:43 --> Config Class Initialized
INFO - 2023-06-07 07:45:43 --> Loader Class Initialized
INFO - 2023-06-07 07:45:43 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:43 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:43 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:43 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:43 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:43 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:43 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:44 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:44 --> URI Class Initialized
INFO - 2023-06-07 07:45:44 --> Router Class Initialized
INFO - 2023-06-07 07:45:44 --> Output Class Initialized
INFO - 2023-06-07 07:45:44 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:44 --> Input Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Loader Class Initialized
INFO - 2023-06-07 07:45:44 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:44 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:44 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:44 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:44 --> URI Class Initialized
INFO - 2023-06-07 07:45:44 --> Router Class Initialized
INFO - 2023-06-07 07:45:44 --> Output Class Initialized
INFO - 2023-06-07 07:45:44 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:44 --> Input Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Loader Class Initialized
INFO - 2023-06-07 07:45:44 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:44 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:44 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:44 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:44 --> URI Class Initialized
INFO - 2023-06-07 07:45:44 --> Router Class Initialized
INFO - 2023-06-07 07:45:44 --> Output Class Initialized
INFO - 2023-06-07 07:45:44 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:44 --> Input Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Language Class Initialized
INFO - 2023-06-07 07:45:44 --> Config Class Initialized
INFO - 2023-06-07 07:45:44 --> Loader Class Initialized
INFO - 2023-06-07 07:45:44 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:44 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:44 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:45 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:45:47 --> Config Class Initialized
INFO - 2023-06-07 07:45:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:45:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:45:47 --> Utf8 Class Initialized
INFO - 2023-06-07 07:45:47 --> URI Class Initialized
INFO - 2023-06-07 07:45:47 --> Router Class Initialized
INFO - 2023-06-07 07:45:47 --> Output Class Initialized
INFO - 2023-06-07 07:45:47 --> Security Class Initialized
DEBUG - 2023-06-07 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:45:47 --> Input Class Initialized
INFO - 2023-06-07 07:45:47 --> Language Class Initialized
INFO - 2023-06-07 07:45:47 --> Language Class Initialized
INFO - 2023-06-07 07:45:47 --> Config Class Initialized
INFO - 2023-06-07 07:45:47 --> Loader Class Initialized
INFO - 2023-06-07 07:45:47 --> Helper loaded: url_helper
INFO - 2023-06-07 07:45:47 --> Helper loaded: file_helper
INFO - 2023-06-07 07:45:47 --> Helper loaded: form_helper
INFO - 2023-06-07 07:45:47 --> Helper loaded: my_helper
INFO - 2023-06-07 07:45:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:45:47 --> Controller Class Initialized
DEBUG - 2023-06-07 07:45:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:45:47 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:46:15 --> Config Class Initialized
INFO - 2023-06-07 07:46:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:46:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:46:15 --> Utf8 Class Initialized
INFO - 2023-06-07 07:46:15 --> URI Class Initialized
INFO - 2023-06-07 07:46:15 --> Router Class Initialized
INFO - 2023-06-07 07:46:15 --> Output Class Initialized
INFO - 2023-06-07 07:46:15 --> Security Class Initialized
DEBUG - 2023-06-07 07:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:46:15 --> Input Class Initialized
INFO - 2023-06-07 07:46:15 --> Language Class Initialized
INFO - 2023-06-07 07:46:15 --> Language Class Initialized
INFO - 2023-06-07 07:46:15 --> Config Class Initialized
INFO - 2023-06-07 07:46:15 --> Loader Class Initialized
INFO - 2023-06-07 07:46:15 --> Helper loaded: url_helper
INFO - 2023-06-07 07:46:15 --> Helper loaded: file_helper
INFO - 2023-06-07 07:46:15 --> Helper loaded: form_helper
INFO - 2023-06-07 07:46:15 --> Helper loaded: my_helper
INFO - 2023-06-07 07:46:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:46:15 --> Controller Class Initialized
DEBUG - 2023-06-07 07:46:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:46:15 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:46:17 --> Config Class Initialized
INFO - 2023-06-07 07:46:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:46:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:46:17 --> Utf8 Class Initialized
INFO - 2023-06-07 07:46:17 --> URI Class Initialized
INFO - 2023-06-07 07:46:17 --> Router Class Initialized
INFO - 2023-06-07 07:46:17 --> Output Class Initialized
INFO - 2023-06-07 07:46:17 --> Security Class Initialized
DEBUG - 2023-06-07 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:46:17 --> Input Class Initialized
INFO - 2023-06-07 07:46:17 --> Language Class Initialized
INFO - 2023-06-07 07:46:17 --> Language Class Initialized
INFO - 2023-06-07 07:46:17 --> Config Class Initialized
INFO - 2023-06-07 07:46:17 --> Loader Class Initialized
INFO - 2023-06-07 07:46:17 --> Helper loaded: url_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: file_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: form_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: my_helper
INFO - 2023-06-07 07:46:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:46:17 --> Controller Class Initialized
DEBUG - 2023-06-07 07:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:46:17 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:46:17 --> Config Class Initialized
INFO - 2023-06-07 07:46:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:46:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:46:17 --> Utf8 Class Initialized
INFO - 2023-06-07 07:46:17 --> URI Class Initialized
INFO - 2023-06-07 07:46:17 --> Router Class Initialized
INFO - 2023-06-07 07:46:17 --> Output Class Initialized
INFO - 2023-06-07 07:46:17 --> Security Class Initialized
DEBUG - 2023-06-07 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:46:17 --> Input Class Initialized
INFO - 2023-06-07 07:46:17 --> Language Class Initialized
INFO - 2023-06-07 07:46:17 --> Language Class Initialized
INFO - 2023-06-07 07:46:17 --> Config Class Initialized
INFO - 2023-06-07 07:46:17 --> Loader Class Initialized
INFO - 2023-06-07 07:46:17 --> Helper loaded: url_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: file_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: form_helper
INFO - 2023-06-07 07:46:17 --> Helper loaded: my_helper
INFO - 2023-06-07 07:46:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:46:17 --> Controller Class Initialized
DEBUG - 2023-06-07 07:46:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:46:17 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:46:18 --> Config Class Initialized
INFO - 2023-06-07 07:46:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:46:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:46:18 --> Utf8 Class Initialized
INFO - 2023-06-07 07:46:18 --> URI Class Initialized
INFO - 2023-06-07 07:46:18 --> Router Class Initialized
INFO - 2023-06-07 07:46:18 --> Output Class Initialized
INFO - 2023-06-07 07:46:18 --> Security Class Initialized
DEBUG - 2023-06-07 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:46:18 --> Input Class Initialized
INFO - 2023-06-07 07:46:18 --> Language Class Initialized
INFO - 2023-06-07 07:46:18 --> Language Class Initialized
INFO - 2023-06-07 07:46:18 --> Config Class Initialized
INFO - 2023-06-07 07:46:18 --> Loader Class Initialized
INFO - 2023-06-07 07:46:18 --> Helper loaded: url_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: file_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: form_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: my_helper
INFO - 2023-06-07 07:46:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:46:18 --> Controller Class Initialized
DEBUG - 2023-06-07 07:46:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:46:18 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:46:18 --> Config Class Initialized
INFO - 2023-06-07 07:46:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:46:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:46:18 --> Utf8 Class Initialized
INFO - 2023-06-07 07:46:18 --> URI Class Initialized
INFO - 2023-06-07 07:46:18 --> Router Class Initialized
INFO - 2023-06-07 07:46:18 --> Output Class Initialized
INFO - 2023-06-07 07:46:18 --> Security Class Initialized
DEBUG - 2023-06-07 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:46:18 --> Input Class Initialized
INFO - 2023-06-07 07:46:18 --> Language Class Initialized
INFO - 2023-06-07 07:46:18 --> Language Class Initialized
INFO - 2023-06-07 07:46:18 --> Config Class Initialized
INFO - 2023-06-07 07:46:18 --> Loader Class Initialized
INFO - 2023-06-07 07:46:18 --> Helper loaded: url_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: file_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: form_helper
INFO - 2023-06-07 07:46:18 --> Helper loaded: my_helper
INFO - 2023-06-07 07:46:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:46:18 --> Controller Class Initialized
DEBUG - 2023-06-07 07:46:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 07:46:18 --> Severity: error --> Exception: Tags are closed in a wrong order for [head] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 262
INFO - 2023-06-07 07:49:47 --> Config Class Initialized
INFO - 2023-06-07 07:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:49:47 --> Utf8 Class Initialized
INFO - 2023-06-07 07:49:47 --> URI Class Initialized
INFO - 2023-06-07 07:49:47 --> Router Class Initialized
INFO - 2023-06-07 07:49:47 --> Output Class Initialized
INFO - 2023-06-07 07:49:47 --> Security Class Initialized
DEBUG - 2023-06-07 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:49:47 --> Input Class Initialized
INFO - 2023-06-07 07:49:47 --> Language Class Initialized
INFO - 2023-06-07 07:49:47 --> Language Class Initialized
INFO - 2023-06-07 07:49:47 --> Config Class Initialized
INFO - 2023-06-07 07:49:47 --> Loader Class Initialized
INFO - 2023-06-07 07:49:47 --> Helper loaded: url_helper
INFO - 2023-06-07 07:49:47 --> Helper loaded: file_helper
INFO - 2023-06-07 07:49:47 --> Helper loaded: form_helper
INFO - 2023-06-07 07:49:47 --> Helper loaded: my_helper
INFO - 2023-06-07 07:49:47 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:49:47 --> Controller Class Initialized
DEBUG - 2023-06-07 07:49:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:49:48 --> Final output sent to browser
DEBUG - 2023-06-07 07:49:48 --> Total execution time: 1.0241
INFO - 2023-06-07 07:49:52 --> Config Class Initialized
INFO - 2023-06-07 07:49:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:49:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:49:52 --> Utf8 Class Initialized
INFO - 2023-06-07 07:49:52 --> URI Class Initialized
INFO - 2023-06-07 07:49:52 --> Router Class Initialized
INFO - 2023-06-07 07:49:53 --> Output Class Initialized
INFO - 2023-06-07 07:49:53 --> Security Class Initialized
DEBUG - 2023-06-07 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:49:53 --> Input Class Initialized
INFO - 2023-06-07 07:49:53 --> Language Class Initialized
INFO - 2023-06-07 07:49:53 --> Language Class Initialized
INFO - 2023-06-07 07:49:53 --> Config Class Initialized
INFO - 2023-06-07 07:49:53 --> Loader Class Initialized
INFO - 2023-06-07 07:49:53 --> Helper loaded: url_helper
INFO - 2023-06-07 07:49:53 --> Helper loaded: file_helper
INFO - 2023-06-07 07:49:53 --> Helper loaded: form_helper
INFO - 2023-06-07 07:49:53 --> Helper loaded: my_helper
INFO - 2023-06-07 07:49:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:49:53 --> Controller Class Initialized
DEBUG - 2023-06-07 07:49:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:49:54 --> Final output sent to browser
DEBUG - 2023-06-07 07:49:54 --> Total execution time: 1.0148
INFO - 2023-06-07 07:53:13 --> Config Class Initialized
INFO - 2023-06-07 07:53:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:53:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:53:13 --> Utf8 Class Initialized
INFO - 2023-06-07 07:53:13 --> URI Class Initialized
INFO - 2023-06-07 07:53:13 --> Router Class Initialized
INFO - 2023-06-07 07:53:13 --> Output Class Initialized
INFO - 2023-06-07 07:53:13 --> Security Class Initialized
DEBUG - 2023-06-07 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:53:13 --> Input Class Initialized
INFO - 2023-06-07 07:53:13 --> Language Class Initialized
INFO - 2023-06-07 07:53:13 --> Language Class Initialized
INFO - 2023-06-07 07:53:13 --> Config Class Initialized
INFO - 2023-06-07 07:53:13 --> Loader Class Initialized
INFO - 2023-06-07 07:53:13 --> Helper loaded: url_helper
INFO - 2023-06-07 07:53:13 --> Helper loaded: file_helper
INFO - 2023-06-07 07:53:13 --> Helper loaded: form_helper
INFO - 2023-06-07 07:53:13 --> Helper loaded: my_helper
INFO - 2023-06-07 07:53:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:53:13 --> Controller Class Initialized
INFO - 2023-06-07 07:53:13 --> Final output sent to browser
DEBUG - 2023-06-07 07:53:13 --> Total execution time: 0.0574
INFO - 2023-06-07 07:53:20 --> Config Class Initialized
INFO - 2023-06-07 07:53:20 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:53:20 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:53:20 --> Utf8 Class Initialized
INFO - 2023-06-07 07:53:20 --> URI Class Initialized
INFO - 2023-06-07 07:53:20 --> Router Class Initialized
INFO - 2023-06-07 07:53:20 --> Output Class Initialized
INFO - 2023-06-07 07:53:20 --> Security Class Initialized
DEBUG - 2023-06-07 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:53:20 --> Input Class Initialized
INFO - 2023-06-07 07:53:20 --> Language Class Initialized
INFO - 2023-06-07 07:53:20 --> Language Class Initialized
INFO - 2023-06-07 07:53:20 --> Config Class Initialized
INFO - 2023-06-07 07:53:20 --> Loader Class Initialized
INFO - 2023-06-07 07:53:20 --> Helper loaded: url_helper
INFO - 2023-06-07 07:53:20 --> Helper loaded: file_helper
INFO - 2023-06-07 07:53:20 --> Helper loaded: form_helper
INFO - 2023-06-07 07:53:20 --> Helper loaded: my_helper
INFO - 2023-06-07 07:53:20 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:53:20 --> Controller Class Initialized
DEBUG - 2023-06-07 07:53:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:53:21 --> Final output sent to browser
DEBUG - 2023-06-07 07:53:21 --> Total execution time: 0.9546
INFO - 2023-06-07 07:53:29 --> Config Class Initialized
INFO - 2023-06-07 07:53:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:53:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:53:29 --> Utf8 Class Initialized
INFO - 2023-06-07 07:53:29 --> URI Class Initialized
INFO - 2023-06-07 07:53:29 --> Router Class Initialized
INFO - 2023-06-07 07:53:29 --> Output Class Initialized
INFO - 2023-06-07 07:53:29 --> Security Class Initialized
DEBUG - 2023-06-07 07:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:53:29 --> Input Class Initialized
INFO - 2023-06-07 07:53:29 --> Language Class Initialized
INFO - 2023-06-07 07:53:29 --> Language Class Initialized
INFO - 2023-06-07 07:53:29 --> Config Class Initialized
INFO - 2023-06-07 07:53:29 --> Loader Class Initialized
INFO - 2023-06-07 07:53:29 --> Helper loaded: url_helper
INFO - 2023-06-07 07:53:29 --> Helper loaded: file_helper
INFO - 2023-06-07 07:53:29 --> Helper loaded: form_helper
INFO - 2023-06-07 07:53:29 --> Helper loaded: my_helper
INFO - 2023-06-07 07:53:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:53:29 --> Controller Class Initialized
DEBUG - 2023-06-07 07:53:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 07:53:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 07:53:29 --> Final output sent to browser
DEBUG - 2023-06-07 07:53:29 --> Total execution time: 0.0583
INFO - 2023-06-07 07:53:34 --> Config Class Initialized
INFO - 2023-06-07 07:53:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:53:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:53:34 --> Utf8 Class Initialized
INFO - 2023-06-07 07:53:34 --> URI Class Initialized
INFO - 2023-06-07 07:53:34 --> Router Class Initialized
INFO - 2023-06-07 07:53:34 --> Output Class Initialized
INFO - 2023-06-07 07:53:34 --> Security Class Initialized
DEBUG - 2023-06-07 07:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:53:34 --> Input Class Initialized
INFO - 2023-06-07 07:53:34 --> Language Class Initialized
INFO - 2023-06-07 07:53:34 --> Language Class Initialized
INFO - 2023-06-07 07:53:34 --> Config Class Initialized
INFO - 2023-06-07 07:53:34 --> Loader Class Initialized
INFO - 2023-06-07 07:53:34 --> Helper loaded: url_helper
INFO - 2023-06-07 07:53:34 --> Helper loaded: file_helper
INFO - 2023-06-07 07:53:34 --> Helper loaded: form_helper
INFO - 2023-06-07 07:53:34 --> Helper loaded: my_helper
INFO - 2023-06-07 07:53:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:53:34 --> Controller Class Initialized
INFO - 2023-06-07 07:53:34 --> Final output sent to browser
DEBUG - 2023-06-07 07:53:34 --> Total execution time: 0.0329
INFO - 2023-06-07 07:53:56 --> Config Class Initialized
INFO - 2023-06-07 07:53:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:53:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:53:56 --> Utf8 Class Initialized
INFO - 2023-06-07 07:53:56 --> URI Class Initialized
INFO - 2023-06-07 07:53:56 --> Router Class Initialized
INFO - 2023-06-07 07:53:56 --> Output Class Initialized
INFO - 2023-06-07 07:53:56 --> Security Class Initialized
DEBUG - 2023-06-07 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:53:56 --> Input Class Initialized
INFO - 2023-06-07 07:53:56 --> Language Class Initialized
INFO - 2023-06-07 07:53:56 --> Language Class Initialized
INFO - 2023-06-07 07:53:56 --> Config Class Initialized
INFO - 2023-06-07 07:53:56 --> Loader Class Initialized
INFO - 2023-06-07 07:53:56 --> Helper loaded: url_helper
INFO - 2023-06-07 07:53:56 --> Helper loaded: file_helper
INFO - 2023-06-07 07:53:56 --> Helper loaded: form_helper
INFO - 2023-06-07 07:53:56 --> Helper loaded: my_helper
INFO - 2023-06-07 07:53:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:53:56 --> Controller Class Initialized
ERROR - 2023-06-07 07:53:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'awwuz before reading iqra and recite shodaqallahul adzim
after ending. He is...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Aldevaro&rsquo;s Islamic values have improved as expected. Alhamdulillah,
Aldevaro is in iqra 1 page 12. Aldevaro is able to recognize hijaiyah letters ا until ذ , . د
He is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim
after ending. He is able to follow kalimat thayyibah such as : alhamdulillah,
astaghfirullah, subhanallah, allahu akbar. Aldevaro is also able to recite some du&rsquo;a,
they are : doa kedua orang tua, doa pembuka hati, doa before study , doa sebelum
tidur, doa sebelum makan dan doa setelah makan. He is also able to recite hadith
kasih sayang, hadith adab makan, and hadith sholat adalah cahaya independently.
From Imtaq Center, he is able to mention the name of the god of Muslims, namely
Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. He is
also able to mention the sequence of wudhu while playing games. He is also aware
of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad
SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Aldevaro has learned about Asmaul
Husna which are ar-rahman until al-qahhar by singing and start to be able to
memorize it until al qahhar He is able to mention table manners in Islam. Aldevaro is
able to recognize halal and haram food. ', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '532'
INFO - 2023-06-07 07:53:56 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 07:54:16 --> Config Class Initialized
INFO - 2023-06-07 07:54:16 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:54:16 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:54:16 --> Utf8 Class Initialized
INFO - 2023-06-07 07:54:16 --> URI Class Initialized
INFO - 2023-06-07 07:54:16 --> Router Class Initialized
INFO - 2023-06-07 07:54:16 --> Output Class Initialized
INFO - 2023-06-07 07:54:16 --> Security Class Initialized
DEBUG - 2023-06-07 07:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:54:16 --> Input Class Initialized
INFO - 2023-06-07 07:54:16 --> Language Class Initialized
INFO - 2023-06-07 07:54:16 --> Language Class Initialized
INFO - 2023-06-07 07:54:16 --> Config Class Initialized
INFO - 2023-06-07 07:54:16 --> Loader Class Initialized
INFO - 2023-06-07 07:54:16 --> Helper loaded: url_helper
INFO - 2023-06-07 07:54:16 --> Helper loaded: file_helper
INFO - 2023-06-07 07:54:16 --> Helper loaded: form_helper
INFO - 2023-06-07 07:54:16 --> Helper loaded: my_helper
INFO - 2023-06-07 07:54:16 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:54:16 --> Controller Class Initialized
DEBUG - 2023-06-07 07:54:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 07:54:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 07:54:16 --> Final output sent to browser
DEBUG - 2023-06-07 07:54:16 --> Total execution time: 0.0353
INFO - 2023-06-07 07:54:18 --> Config Class Initialized
INFO - 2023-06-07 07:54:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:54:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:54:18 --> Utf8 Class Initialized
INFO - 2023-06-07 07:54:18 --> URI Class Initialized
INFO - 2023-06-07 07:54:18 --> Router Class Initialized
INFO - 2023-06-07 07:54:18 --> Output Class Initialized
INFO - 2023-06-07 07:54:18 --> Security Class Initialized
DEBUG - 2023-06-07 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:54:18 --> Input Class Initialized
INFO - 2023-06-07 07:54:18 --> Language Class Initialized
ERROR - 2023-06-07 07:54:18 --> 404 Page Not Found: /index
INFO - 2023-06-07 07:54:27 --> Config Class Initialized
INFO - 2023-06-07 07:54:27 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:54:27 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:54:27 --> Utf8 Class Initialized
INFO - 2023-06-07 07:54:27 --> URI Class Initialized
INFO - 2023-06-07 07:54:27 --> Router Class Initialized
INFO - 2023-06-07 07:54:27 --> Output Class Initialized
INFO - 2023-06-07 07:54:27 --> Security Class Initialized
DEBUG - 2023-06-07 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:54:27 --> Input Class Initialized
INFO - 2023-06-07 07:54:27 --> Language Class Initialized
INFO - 2023-06-07 07:54:27 --> Language Class Initialized
INFO - 2023-06-07 07:54:27 --> Config Class Initialized
INFO - 2023-06-07 07:54:27 --> Loader Class Initialized
INFO - 2023-06-07 07:54:27 --> Helper loaded: url_helper
INFO - 2023-06-07 07:54:27 --> Helper loaded: file_helper
INFO - 2023-06-07 07:54:27 --> Helper loaded: form_helper
INFO - 2023-06-07 07:54:27 --> Helper loaded: my_helper
INFO - 2023-06-07 07:54:27 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:54:27 --> Controller Class Initialized
ERROR - 2023-06-07 07:54:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'awwuz before reading iqra and recite shodaqallahul adzim
after ending. He is...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Aldevaro&rsquo;s Islamic values have improved as expected. Alhamdulillah,
Aldevaro is in iqra 1 page 12. Aldevaro is able to recognize hijaiyah letters ا until ذ , . د
He is also able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim
after ending. He is able to follow kalimat thayyibah such as : alhamdulillah,
astaghfirullah, subhanallah, allahu akbar. Aldevaro is also able to recite some du&rsquo;a,
they are : doa kedua orang tua, doa pembuka hati, doa before study , doa sebelum
tidur, doa sebelum makan dan doa setelah makan. He is also able to recite hadith
kasih sayang, hadith adab makan, and hadith sholat adalah cahaya independently.
From Imtaq Center, he is able to mention the name of the god of Muslims, namely
Allah SWT and the name of the Prophet, namely Prophet Muhammad SAW. He is
also able to mention the sequence of wudhu while playing games. He is also aware
of some names of Nabi and malaikat Allah from the stories like Nabi Muhammad
SAW, Nabi Sulaiman AS and Nabi Ibrahim AS. Aldevaro has learned about Asmaul
Husna which are ar-rahman until al-qahhar by singing and start to be able to
memorize it until al qahhar He is able to mention table manners in Islam. Aldevaro is
able to recognize halal and haram food. ', catatan_final = '-' WHERE ta = '20232' AND id_siswa = '532'
INFO - 2023-06-07 07:54:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-06-07 07:55:55 --> Config Class Initialized
INFO - 2023-06-07 07:55:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:55:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:55:55 --> Utf8 Class Initialized
INFO - 2023-06-07 07:55:55 --> URI Class Initialized
INFO - 2023-06-07 07:55:55 --> Router Class Initialized
INFO - 2023-06-07 07:55:55 --> Output Class Initialized
INFO - 2023-06-07 07:55:55 --> Security Class Initialized
DEBUG - 2023-06-07 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:55:55 --> Input Class Initialized
INFO - 2023-06-07 07:55:55 --> Language Class Initialized
INFO - 2023-06-07 07:55:55 --> Language Class Initialized
INFO - 2023-06-07 07:55:55 --> Config Class Initialized
INFO - 2023-06-07 07:55:55 --> Loader Class Initialized
INFO - 2023-06-07 07:55:55 --> Helper loaded: url_helper
INFO - 2023-06-07 07:55:55 --> Helper loaded: file_helper
INFO - 2023-06-07 07:55:55 --> Helper loaded: form_helper
INFO - 2023-06-07 07:55:55 --> Helper loaded: my_helper
INFO - 2023-06-07 07:55:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:55:55 --> Controller Class Initialized
DEBUG - 2023-06-07 07:55:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 07:55:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 07:55:55 --> Final output sent to browser
DEBUG - 2023-06-07 07:55:55 --> Total execution time: 0.0449
INFO - 2023-06-07 07:55:55 --> Config Class Initialized
INFO - 2023-06-07 07:55:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:55:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:55:55 --> Utf8 Class Initialized
INFO - 2023-06-07 07:55:55 --> URI Class Initialized
INFO - 2023-06-07 07:55:55 --> Router Class Initialized
INFO - 2023-06-07 07:55:55 --> Output Class Initialized
INFO - 2023-06-07 07:55:55 --> Security Class Initialized
DEBUG - 2023-06-07 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:55:55 --> Input Class Initialized
INFO - 2023-06-07 07:55:55 --> Language Class Initialized
ERROR - 2023-06-07 07:55:55 --> 404 Page Not Found: /index
INFO - 2023-06-07 07:56:24 --> Config Class Initialized
INFO - 2023-06-07 07:56:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:56:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:56:24 --> Utf8 Class Initialized
INFO - 2023-06-07 07:56:24 --> URI Class Initialized
INFO - 2023-06-07 07:56:24 --> Router Class Initialized
INFO - 2023-06-07 07:56:24 --> Output Class Initialized
INFO - 2023-06-07 07:56:24 --> Security Class Initialized
DEBUG - 2023-06-07 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:56:24 --> Input Class Initialized
INFO - 2023-06-07 07:56:24 --> Language Class Initialized
INFO - 2023-06-07 07:56:24 --> Language Class Initialized
INFO - 2023-06-07 07:56:24 --> Config Class Initialized
INFO - 2023-06-07 07:56:24 --> Loader Class Initialized
INFO - 2023-06-07 07:56:24 --> Helper loaded: url_helper
INFO - 2023-06-07 07:56:24 --> Helper loaded: file_helper
INFO - 2023-06-07 07:56:24 --> Helper loaded: form_helper
INFO - 2023-06-07 07:56:24 --> Helper loaded: my_helper
INFO - 2023-06-07 07:56:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:56:24 --> Controller Class Initialized
INFO - 2023-06-07 07:56:24 --> Final output sent to browser
DEBUG - 2023-06-07 07:56:24 --> Total execution time: 0.0532
INFO - 2023-06-07 07:56:30 --> Config Class Initialized
INFO - 2023-06-07 07:56:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 07:56:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 07:56:30 --> Utf8 Class Initialized
INFO - 2023-06-07 07:56:30 --> URI Class Initialized
INFO - 2023-06-07 07:56:30 --> Router Class Initialized
INFO - 2023-06-07 07:56:30 --> Output Class Initialized
INFO - 2023-06-07 07:56:30 --> Security Class Initialized
DEBUG - 2023-06-07 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 07:56:30 --> Input Class Initialized
INFO - 2023-06-07 07:56:30 --> Language Class Initialized
INFO - 2023-06-07 07:56:30 --> Language Class Initialized
INFO - 2023-06-07 07:56:30 --> Config Class Initialized
INFO - 2023-06-07 07:56:30 --> Loader Class Initialized
INFO - 2023-06-07 07:56:30 --> Helper loaded: url_helper
INFO - 2023-06-07 07:56:30 --> Helper loaded: file_helper
INFO - 2023-06-07 07:56:30 --> Helper loaded: form_helper
INFO - 2023-06-07 07:56:30 --> Helper loaded: my_helper
INFO - 2023-06-07 07:56:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 07:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 07:56:30 --> Controller Class Initialized
DEBUG - 2023-06-07 07:56:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 07:56:31 --> Final output sent to browser
DEBUG - 2023-06-07 07:56:31 --> Total execution time: 0.9398
INFO - 2023-06-07 08:03:10 --> Config Class Initialized
INFO - 2023-06-07 08:03:10 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:03:10 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:03:10 --> Utf8 Class Initialized
INFO - 2023-06-07 08:03:10 --> URI Class Initialized
INFO - 2023-06-07 08:03:10 --> Router Class Initialized
INFO - 2023-06-07 08:03:10 --> Output Class Initialized
INFO - 2023-06-07 08:03:10 --> Security Class Initialized
DEBUG - 2023-06-07 08:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:03:10 --> Input Class Initialized
INFO - 2023-06-07 08:03:10 --> Language Class Initialized
INFO - 2023-06-07 08:03:10 --> Language Class Initialized
INFO - 2023-06-07 08:03:10 --> Config Class Initialized
INFO - 2023-06-07 08:03:10 --> Loader Class Initialized
INFO - 2023-06-07 08:03:10 --> Helper loaded: url_helper
INFO - 2023-06-07 08:03:10 --> Helper loaded: file_helper
INFO - 2023-06-07 08:03:10 --> Helper loaded: form_helper
INFO - 2023-06-07 08:03:10 --> Helper loaded: my_helper
INFO - 2023-06-07 08:03:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:03:11 --> Controller Class Initialized
DEBUG - 2023-06-07 08:03:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:03:12 --> Final output sent to browser
DEBUG - 2023-06-07 08:03:12 --> Total execution time: 2.5228
INFO - 2023-06-07 08:03:15 --> Config Class Initialized
INFO - 2023-06-07 08:03:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:03:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:03:15 --> Utf8 Class Initialized
INFO - 2023-06-07 08:03:15 --> URI Class Initialized
INFO - 2023-06-07 08:03:15 --> Router Class Initialized
INFO - 2023-06-07 08:03:15 --> Output Class Initialized
INFO - 2023-06-07 08:03:15 --> Security Class Initialized
DEBUG - 2023-06-07 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:03:15 --> Input Class Initialized
INFO - 2023-06-07 08:03:15 --> Language Class Initialized
INFO - 2023-06-07 08:03:15 --> Language Class Initialized
INFO - 2023-06-07 08:03:15 --> Config Class Initialized
INFO - 2023-06-07 08:03:15 --> Loader Class Initialized
INFO - 2023-06-07 08:03:15 --> Helper loaded: url_helper
INFO - 2023-06-07 08:03:15 --> Helper loaded: file_helper
INFO - 2023-06-07 08:03:15 --> Helper loaded: form_helper
INFO - 2023-06-07 08:03:15 --> Helper loaded: my_helper
INFO - 2023-06-07 08:03:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:03:15 --> Controller Class Initialized
DEBUG - 2023-06-07 08:03:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:03:16 --> Final output sent to browser
DEBUG - 2023-06-07 08:03:16 --> Total execution time: 0.9345
INFO - 2023-06-07 08:06:26 --> Config Class Initialized
INFO - 2023-06-07 08:06:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:06:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:06:26 --> Utf8 Class Initialized
INFO - 2023-06-07 08:06:26 --> URI Class Initialized
INFO - 2023-06-07 08:06:26 --> Router Class Initialized
INFO - 2023-06-07 08:06:26 --> Output Class Initialized
INFO - 2023-06-07 08:06:26 --> Security Class Initialized
DEBUG - 2023-06-07 08:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:06:26 --> Input Class Initialized
INFO - 2023-06-07 08:06:26 --> Language Class Initialized
INFO - 2023-06-07 08:06:26 --> Language Class Initialized
INFO - 2023-06-07 08:06:26 --> Config Class Initialized
INFO - 2023-06-07 08:06:26 --> Loader Class Initialized
INFO - 2023-06-07 08:06:26 --> Helper loaded: url_helper
INFO - 2023-06-07 08:06:26 --> Helper loaded: file_helper
INFO - 2023-06-07 08:06:26 --> Helper loaded: form_helper
INFO - 2023-06-07 08:06:26 --> Helper loaded: my_helper
INFO - 2023-06-07 08:06:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:06:26 --> Controller Class Initialized
DEBUG - 2023-06-07 08:06:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:06:27 --> Final output sent to browser
DEBUG - 2023-06-07 08:06:27 --> Total execution time: 0.9233
INFO - 2023-06-07 08:06:57 --> Config Class Initialized
INFO - 2023-06-07 08:06:57 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:06:57 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:06:57 --> Utf8 Class Initialized
INFO - 2023-06-07 08:06:57 --> URI Class Initialized
INFO - 2023-06-07 08:06:57 --> Router Class Initialized
INFO - 2023-06-07 08:06:57 --> Output Class Initialized
INFO - 2023-06-07 08:06:57 --> Security Class Initialized
DEBUG - 2023-06-07 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:06:57 --> Input Class Initialized
INFO - 2023-06-07 08:06:57 --> Language Class Initialized
INFO - 2023-06-07 08:06:57 --> Language Class Initialized
INFO - 2023-06-07 08:06:57 --> Config Class Initialized
INFO - 2023-06-07 08:06:57 --> Loader Class Initialized
INFO - 2023-06-07 08:06:57 --> Helper loaded: url_helper
INFO - 2023-06-07 08:06:57 --> Helper loaded: file_helper
INFO - 2023-06-07 08:06:57 --> Helper loaded: form_helper
INFO - 2023-06-07 08:06:57 --> Helper loaded: my_helper
INFO - 2023-06-07 08:06:57 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:06:57 --> Controller Class Initialized
DEBUG - 2023-06-07 08:06:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:06:57 --> Final output sent to browser
DEBUG - 2023-06-07 08:06:57 --> Total execution time: 0.8711
INFO - 2023-06-07 08:09:11 --> Config Class Initialized
INFO - 2023-06-07 08:09:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:09:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:09:11 --> Utf8 Class Initialized
INFO - 2023-06-07 08:09:11 --> URI Class Initialized
INFO - 2023-06-07 08:09:11 --> Router Class Initialized
INFO - 2023-06-07 08:09:11 --> Output Class Initialized
INFO - 2023-06-07 08:09:11 --> Security Class Initialized
DEBUG - 2023-06-07 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:09:11 --> Input Class Initialized
INFO - 2023-06-07 08:09:11 --> Language Class Initialized
INFO - 2023-06-07 08:09:11 --> Language Class Initialized
INFO - 2023-06-07 08:09:11 --> Config Class Initialized
INFO - 2023-06-07 08:09:11 --> Loader Class Initialized
INFO - 2023-06-07 08:09:11 --> Helper loaded: url_helper
INFO - 2023-06-07 08:09:11 --> Helper loaded: file_helper
INFO - 2023-06-07 08:09:11 --> Helper loaded: form_helper
INFO - 2023-06-07 08:09:11 --> Helper loaded: my_helper
INFO - 2023-06-07 08:09:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:09:11 --> Controller Class Initialized
DEBUG - 2023-06-07 08:09:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:09:12 --> Final output sent to browser
DEBUG - 2023-06-07 08:09:12 --> Total execution time: 0.9158
INFO - 2023-06-07 08:09:14 --> Config Class Initialized
INFO - 2023-06-07 08:09:14 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:09:14 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:09:14 --> Utf8 Class Initialized
INFO - 2023-06-07 08:09:14 --> URI Class Initialized
INFO - 2023-06-07 08:09:14 --> Router Class Initialized
INFO - 2023-06-07 08:09:14 --> Output Class Initialized
INFO - 2023-06-07 08:09:14 --> Security Class Initialized
DEBUG - 2023-06-07 08:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:09:14 --> Input Class Initialized
INFO - 2023-06-07 08:09:14 --> Language Class Initialized
INFO - 2023-06-07 08:09:14 --> Language Class Initialized
INFO - 2023-06-07 08:09:14 --> Config Class Initialized
INFO - 2023-06-07 08:09:14 --> Loader Class Initialized
INFO - 2023-06-07 08:09:14 --> Helper loaded: url_helper
INFO - 2023-06-07 08:09:14 --> Helper loaded: file_helper
INFO - 2023-06-07 08:09:14 --> Helper loaded: form_helper
INFO - 2023-06-07 08:09:14 --> Helper loaded: my_helper
INFO - 2023-06-07 08:09:14 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:09:14 --> Controller Class Initialized
DEBUG - 2023-06-07 08:09:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:09:15 --> Final output sent to browser
DEBUG - 2023-06-07 08:09:15 --> Total execution time: 0.9153
INFO - 2023-06-07 08:10:31 --> Config Class Initialized
INFO - 2023-06-07 08:10:31 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:10:31 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:10:31 --> Utf8 Class Initialized
INFO - 2023-06-07 08:10:31 --> URI Class Initialized
INFO - 2023-06-07 08:10:31 --> Router Class Initialized
INFO - 2023-06-07 08:10:31 --> Output Class Initialized
INFO - 2023-06-07 08:10:31 --> Security Class Initialized
DEBUG - 2023-06-07 08:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:10:31 --> Input Class Initialized
INFO - 2023-06-07 08:10:31 --> Language Class Initialized
INFO - 2023-06-07 08:10:31 --> Language Class Initialized
INFO - 2023-06-07 08:10:31 --> Config Class Initialized
INFO - 2023-06-07 08:10:31 --> Loader Class Initialized
INFO - 2023-06-07 08:10:31 --> Helper loaded: url_helper
INFO - 2023-06-07 08:10:31 --> Helper loaded: file_helper
INFO - 2023-06-07 08:10:31 --> Helper loaded: form_helper
INFO - 2023-06-07 08:10:31 --> Helper loaded: my_helper
INFO - 2023-06-07 08:10:31 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:10:31 --> Controller Class Initialized
DEBUG - 2023-06-07 08:10:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:10:32 --> Final output sent to browser
DEBUG - 2023-06-07 08:10:32 --> Total execution time: 0.9066
INFO - 2023-06-07 08:11:17 --> Config Class Initialized
INFO - 2023-06-07 08:11:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:11:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:11:17 --> Utf8 Class Initialized
INFO - 2023-06-07 08:11:17 --> URI Class Initialized
INFO - 2023-06-07 08:11:17 --> Router Class Initialized
INFO - 2023-06-07 08:11:17 --> Output Class Initialized
INFO - 2023-06-07 08:11:17 --> Security Class Initialized
DEBUG - 2023-06-07 08:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:11:17 --> Input Class Initialized
INFO - 2023-06-07 08:11:17 --> Language Class Initialized
INFO - 2023-06-07 08:11:17 --> Language Class Initialized
INFO - 2023-06-07 08:11:17 --> Config Class Initialized
INFO - 2023-06-07 08:11:17 --> Loader Class Initialized
INFO - 2023-06-07 08:11:17 --> Helper loaded: url_helper
INFO - 2023-06-07 08:11:17 --> Helper loaded: file_helper
INFO - 2023-06-07 08:11:17 --> Helper loaded: form_helper
INFO - 2023-06-07 08:11:17 --> Helper loaded: my_helper
INFO - 2023-06-07 08:11:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:11:17 --> Controller Class Initialized
DEBUG - 2023-06-07 08:11:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:11:18 --> Final output sent to browser
DEBUG - 2023-06-07 08:11:18 --> Total execution time: 0.9020
INFO - 2023-06-07 08:11:25 --> Config Class Initialized
INFO - 2023-06-07 08:11:25 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:11:25 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:11:25 --> Utf8 Class Initialized
INFO - 2023-06-07 08:11:25 --> URI Class Initialized
INFO - 2023-06-07 08:11:25 --> Router Class Initialized
INFO - 2023-06-07 08:11:25 --> Output Class Initialized
INFO - 2023-06-07 08:11:25 --> Security Class Initialized
DEBUG - 2023-06-07 08:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:11:25 --> Input Class Initialized
INFO - 2023-06-07 08:11:25 --> Language Class Initialized
INFO - 2023-06-07 08:11:25 --> Language Class Initialized
INFO - 2023-06-07 08:11:25 --> Config Class Initialized
INFO - 2023-06-07 08:11:25 --> Loader Class Initialized
INFO - 2023-06-07 08:11:25 --> Helper loaded: url_helper
INFO - 2023-06-07 08:11:25 --> Helper loaded: file_helper
INFO - 2023-06-07 08:11:25 --> Helper loaded: form_helper
INFO - 2023-06-07 08:11:25 --> Helper loaded: my_helper
INFO - 2023-06-07 08:11:25 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:11:25 --> Controller Class Initialized
DEBUG - 2023-06-07 08:11:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 08:11:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 08:11:25 --> Final output sent to browser
DEBUG - 2023-06-07 08:11:25 --> Total execution time: 0.1303
INFO - 2023-06-07 08:11:25 --> Config Class Initialized
INFO - 2023-06-07 08:11:25 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:11:25 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:11:25 --> Utf8 Class Initialized
INFO - 2023-06-07 08:11:25 --> URI Class Initialized
INFO - 2023-06-07 08:11:25 --> Router Class Initialized
INFO - 2023-06-07 08:11:25 --> Output Class Initialized
INFO - 2023-06-07 08:11:25 --> Security Class Initialized
DEBUG - 2023-06-07 08:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:11:25 --> Input Class Initialized
INFO - 2023-06-07 08:11:25 --> Language Class Initialized
ERROR - 2023-06-07 08:11:25 --> 404 Page Not Found: /index
INFO - 2023-06-07 08:13:13 --> Config Class Initialized
INFO - 2023-06-07 08:13:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:13:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:13:13 --> Utf8 Class Initialized
INFO - 2023-06-07 08:13:13 --> URI Class Initialized
INFO - 2023-06-07 08:13:13 --> Router Class Initialized
INFO - 2023-06-07 08:13:13 --> Output Class Initialized
INFO - 2023-06-07 08:13:13 --> Security Class Initialized
DEBUG - 2023-06-07 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:13:13 --> Input Class Initialized
INFO - 2023-06-07 08:13:13 --> Language Class Initialized
INFO - 2023-06-07 08:13:13 --> Language Class Initialized
INFO - 2023-06-07 08:13:13 --> Config Class Initialized
INFO - 2023-06-07 08:13:13 --> Loader Class Initialized
INFO - 2023-06-07 08:13:13 --> Helper loaded: url_helper
INFO - 2023-06-07 08:13:13 --> Helper loaded: file_helper
INFO - 2023-06-07 08:13:13 --> Helper loaded: form_helper
INFO - 2023-06-07 08:13:13 --> Helper loaded: my_helper
INFO - 2023-06-07 08:13:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:13:13 --> Controller Class Initialized
DEBUG - 2023-06-07 08:13:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:13:14 --> Final output sent to browser
DEBUG - 2023-06-07 08:13:14 --> Total execution time: 1.0234
INFO - 2023-06-07 08:13:44 --> Config Class Initialized
INFO - 2023-06-07 08:13:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:13:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:13:44 --> Utf8 Class Initialized
INFO - 2023-06-07 08:13:44 --> URI Class Initialized
INFO - 2023-06-07 08:13:44 --> Router Class Initialized
INFO - 2023-06-07 08:13:44 --> Output Class Initialized
INFO - 2023-06-07 08:13:44 --> Security Class Initialized
DEBUG - 2023-06-07 08:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:13:44 --> Input Class Initialized
INFO - 2023-06-07 08:13:44 --> Language Class Initialized
INFO - 2023-06-07 08:13:44 --> Language Class Initialized
INFO - 2023-06-07 08:13:44 --> Config Class Initialized
INFO - 2023-06-07 08:13:44 --> Loader Class Initialized
INFO - 2023-06-07 08:13:44 --> Helper loaded: url_helper
INFO - 2023-06-07 08:13:44 --> Helper loaded: file_helper
INFO - 2023-06-07 08:13:44 --> Helper loaded: form_helper
INFO - 2023-06-07 08:13:44 --> Helper loaded: my_helper
INFO - 2023-06-07 08:13:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:13:44 --> Controller Class Initialized
DEBUG - 2023-06-07 08:13:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:13:45 --> Final output sent to browser
DEBUG - 2023-06-07 08:13:45 --> Total execution time: 0.9548
INFO - 2023-06-07 08:14:13 --> Config Class Initialized
INFO - 2023-06-07 08:14:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:14:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:14:13 --> Utf8 Class Initialized
INFO - 2023-06-07 08:14:13 --> URI Class Initialized
INFO - 2023-06-07 08:14:13 --> Router Class Initialized
INFO - 2023-06-07 08:14:13 --> Output Class Initialized
INFO - 2023-06-07 08:14:13 --> Security Class Initialized
DEBUG - 2023-06-07 08:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:14:13 --> Input Class Initialized
INFO - 2023-06-07 08:14:13 --> Language Class Initialized
INFO - 2023-06-07 08:14:13 --> Language Class Initialized
INFO - 2023-06-07 08:14:13 --> Config Class Initialized
INFO - 2023-06-07 08:14:13 --> Loader Class Initialized
INFO - 2023-06-07 08:14:13 --> Helper loaded: url_helper
INFO - 2023-06-07 08:14:13 --> Helper loaded: file_helper
INFO - 2023-06-07 08:14:13 --> Helper loaded: form_helper
INFO - 2023-06-07 08:14:13 --> Helper loaded: my_helper
INFO - 2023-06-07 08:14:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:14:13 --> Controller Class Initialized
DEBUG - 2023-06-07 08:14:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:14:14 --> Final output sent to browser
DEBUG - 2023-06-07 08:14:14 --> Total execution time: 0.9466
INFO - 2023-06-07 08:14:48 --> Config Class Initialized
INFO - 2023-06-07 08:14:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:14:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:14:48 --> Utf8 Class Initialized
INFO - 2023-06-07 08:14:48 --> URI Class Initialized
INFO - 2023-06-07 08:14:48 --> Router Class Initialized
INFO - 2023-06-07 08:14:48 --> Output Class Initialized
INFO - 2023-06-07 08:14:48 --> Security Class Initialized
DEBUG - 2023-06-07 08:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:14:48 --> Input Class Initialized
INFO - 2023-06-07 08:14:48 --> Language Class Initialized
INFO - 2023-06-07 08:14:48 --> Language Class Initialized
INFO - 2023-06-07 08:14:48 --> Config Class Initialized
INFO - 2023-06-07 08:14:48 --> Loader Class Initialized
INFO - 2023-06-07 08:14:48 --> Helper loaded: url_helper
INFO - 2023-06-07 08:14:48 --> Helper loaded: file_helper
INFO - 2023-06-07 08:14:48 --> Helper loaded: form_helper
INFO - 2023-06-07 08:14:48 --> Helper loaded: my_helper
INFO - 2023-06-07 08:14:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:14:48 --> Controller Class Initialized
DEBUG - 2023-06-07 08:14:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:14:49 --> Final output sent to browser
DEBUG - 2023-06-07 08:14:49 --> Total execution time: 0.9697
INFO - 2023-06-07 08:15:26 --> Config Class Initialized
INFO - 2023-06-07 08:15:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:15:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:15:26 --> Utf8 Class Initialized
INFO - 2023-06-07 08:15:26 --> URI Class Initialized
INFO - 2023-06-07 08:15:26 --> Router Class Initialized
INFO - 2023-06-07 08:15:26 --> Output Class Initialized
INFO - 2023-06-07 08:15:26 --> Security Class Initialized
DEBUG - 2023-06-07 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:15:26 --> Input Class Initialized
INFO - 2023-06-07 08:15:26 --> Language Class Initialized
INFO - 2023-06-07 08:15:26 --> Language Class Initialized
INFO - 2023-06-07 08:15:26 --> Config Class Initialized
INFO - 2023-06-07 08:15:26 --> Loader Class Initialized
INFO - 2023-06-07 08:15:26 --> Helper loaded: url_helper
INFO - 2023-06-07 08:15:26 --> Helper loaded: file_helper
INFO - 2023-06-07 08:15:26 --> Helper loaded: form_helper
INFO - 2023-06-07 08:15:26 --> Helper loaded: my_helper
INFO - 2023-06-07 08:15:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:15:26 --> Controller Class Initialized
DEBUG - 2023-06-07 08:15:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:15:27 --> Final output sent to browser
DEBUG - 2023-06-07 08:15:27 --> Total execution time: 0.9492
INFO - 2023-06-07 08:17:15 --> Config Class Initialized
INFO - 2023-06-07 08:17:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:17:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:17:15 --> Utf8 Class Initialized
INFO - 2023-06-07 08:17:15 --> URI Class Initialized
INFO - 2023-06-07 08:17:15 --> Router Class Initialized
INFO - 2023-06-07 08:17:15 --> Output Class Initialized
INFO - 2023-06-07 08:17:15 --> Security Class Initialized
DEBUG - 2023-06-07 08:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:17:15 --> Input Class Initialized
INFO - 2023-06-07 08:17:15 --> Language Class Initialized
INFO - 2023-06-07 08:17:15 --> Language Class Initialized
INFO - 2023-06-07 08:17:15 --> Config Class Initialized
INFO - 2023-06-07 08:17:15 --> Loader Class Initialized
INFO - 2023-06-07 08:17:15 --> Helper loaded: url_helper
INFO - 2023-06-07 08:17:15 --> Helper loaded: file_helper
INFO - 2023-06-07 08:17:15 --> Helper loaded: form_helper
INFO - 2023-06-07 08:17:15 --> Helper loaded: my_helper
INFO - 2023-06-07 08:17:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:17:15 --> Controller Class Initialized
DEBUG - 2023-06-07 08:17:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:17:16 --> Final output sent to browser
DEBUG - 2023-06-07 08:17:16 --> Total execution time: 0.9702
INFO - 2023-06-07 08:22:54 --> Config Class Initialized
INFO - 2023-06-07 08:22:54 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:22:54 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:22:54 --> Utf8 Class Initialized
INFO - 2023-06-07 08:22:54 --> URI Class Initialized
INFO - 2023-06-07 08:22:54 --> Router Class Initialized
INFO - 2023-06-07 08:22:54 --> Output Class Initialized
INFO - 2023-06-07 08:22:54 --> Security Class Initialized
DEBUG - 2023-06-07 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:22:54 --> Input Class Initialized
INFO - 2023-06-07 08:22:54 --> Language Class Initialized
INFO - 2023-06-07 08:22:54 --> Language Class Initialized
INFO - 2023-06-07 08:22:54 --> Config Class Initialized
INFO - 2023-06-07 08:22:54 --> Loader Class Initialized
INFO - 2023-06-07 08:22:54 --> Helper loaded: url_helper
INFO - 2023-06-07 08:22:54 --> Helper loaded: file_helper
INFO - 2023-06-07 08:22:54 --> Helper loaded: form_helper
INFO - 2023-06-07 08:22:54 --> Helper loaded: my_helper
INFO - 2023-06-07 08:22:54 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:22:54 --> Controller Class Initialized
DEBUG - 2023-06-07 08:22:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:22:55 --> Final output sent to browser
DEBUG - 2023-06-07 08:22:55 --> Total execution time: 1.0827
INFO - 2023-06-07 08:23:07 --> Config Class Initialized
INFO - 2023-06-07 08:23:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:23:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:23:07 --> Utf8 Class Initialized
INFO - 2023-06-07 08:23:07 --> URI Class Initialized
INFO - 2023-06-07 08:23:07 --> Router Class Initialized
INFO - 2023-06-07 08:23:07 --> Output Class Initialized
INFO - 2023-06-07 08:23:07 --> Security Class Initialized
DEBUG - 2023-06-07 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:23:07 --> Input Class Initialized
INFO - 2023-06-07 08:23:07 --> Language Class Initialized
INFO - 2023-06-07 08:23:07 --> Language Class Initialized
INFO - 2023-06-07 08:23:07 --> Config Class Initialized
INFO - 2023-06-07 08:23:07 --> Loader Class Initialized
INFO - 2023-06-07 08:23:07 --> Helper loaded: url_helper
INFO - 2023-06-07 08:23:07 --> Helper loaded: file_helper
INFO - 2023-06-07 08:23:07 --> Helper loaded: form_helper
INFO - 2023-06-07 08:23:07 --> Helper loaded: my_helper
INFO - 2023-06-07 08:23:07 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:23:07 --> Controller Class Initialized
DEBUG - 2023-06-07 08:23:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:23:08 --> Final output sent to browser
DEBUG - 2023-06-07 08:23:08 --> Total execution time: 0.9432
INFO - 2023-06-07 08:25:12 --> Config Class Initialized
INFO - 2023-06-07 08:25:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:25:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:25:12 --> Utf8 Class Initialized
INFO - 2023-06-07 08:25:12 --> URI Class Initialized
INFO - 2023-06-07 08:25:12 --> Router Class Initialized
INFO - 2023-06-07 08:25:12 --> Output Class Initialized
INFO - 2023-06-07 08:25:12 --> Security Class Initialized
DEBUG - 2023-06-07 08:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:25:12 --> Input Class Initialized
INFO - 2023-06-07 08:25:12 --> Language Class Initialized
INFO - 2023-06-07 08:25:12 --> Language Class Initialized
INFO - 2023-06-07 08:25:12 --> Config Class Initialized
INFO - 2023-06-07 08:25:12 --> Loader Class Initialized
INFO - 2023-06-07 08:25:12 --> Helper loaded: url_helper
INFO - 2023-06-07 08:25:12 --> Helper loaded: file_helper
INFO - 2023-06-07 08:25:12 --> Helper loaded: form_helper
INFO - 2023-06-07 08:25:12 --> Helper loaded: my_helper
INFO - 2023-06-07 08:25:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:25:12 --> Controller Class Initialized
DEBUG - 2023-06-07 08:25:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:25:13 --> Final output sent to browser
DEBUG - 2023-06-07 08:25:13 --> Total execution time: 1.0204
INFO - 2023-06-07 08:25:48 --> Config Class Initialized
INFO - 2023-06-07 08:25:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:25:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:25:48 --> Utf8 Class Initialized
INFO - 2023-06-07 08:25:48 --> URI Class Initialized
INFO - 2023-06-07 08:25:48 --> Router Class Initialized
INFO - 2023-06-07 08:25:48 --> Output Class Initialized
INFO - 2023-06-07 08:25:48 --> Security Class Initialized
DEBUG - 2023-06-07 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:25:48 --> Input Class Initialized
INFO - 2023-06-07 08:25:48 --> Language Class Initialized
INFO - 2023-06-07 08:25:48 --> Language Class Initialized
INFO - 2023-06-07 08:25:48 --> Config Class Initialized
INFO - 2023-06-07 08:25:48 --> Loader Class Initialized
INFO - 2023-06-07 08:25:48 --> Helper loaded: url_helper
INFO - 2023-06-07 08:25:48 --> Helper loaded: file_helper
INFO - 2023-06-07 08:25:48 --> Helper loaded: form_helper
INFO - 2023-06-07 08:25:48 --> Helper loaded: my_helper
INFO - 2023-06-07 08:25:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:25:48 --> Controller Class Initialized
DEBUG - 2023-06-07 08:25:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:25:49 --> Final output sent to browser
DEBUG - 2023-06-07 08:25:49 --> Total execution time: 0.9460
INFO - 2023-06-07 08:26:06 --> Config Class Initialized
INFO - 2023-06-07 08:26:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:26:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:26:06 --> Utf8 Class Initialized
INFO - 2023-06-07 08:26:06 --> URI Class Initialized
INFO - 2023-06-07 08:26:06 --> Router Class Initialized
INFO - 2023-06-07 08:26:06 --> Output Class Initialized
INFO - 2023-06-07 08:26:06 --> Security Class Initialized
DEBUG - 2023-06-07 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:26:06 --> Input Class Initialized
INFO - 2023-06-07 08:26:06 --> Language Class Initialized
INFO - 2023-06-07 08:26:06 --> Language Class Initialized
INFO - 2023-06-07 08:26:06 --> Config Class Initialized
INFO - 2023-06-07 08:26:06 --> Loader Class Initialized
INFO - 2023-06-07 08:26:06 --> Helper loaded: url_helper
INFO - 2023-06-07 08:26:06 --> Helper loaded: file_helper
INFO - 2023-06-07 08:26:06 --> Helper loaded: form_helper
INFO - 2023-06-07 08:26:06 --> Helper loaded: my_helper
INFO - 2023-06-07 08:26:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:26:06 --> Controller Class Initialized
DEBUG - 2023-06-07 08:26:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:26:07 --> Final output sent to browser
DEBUG - 2023-06-07 08:26:07 --> Total execution time: 0.9754
INFO - 2023-06-07 08:26:31 --> Config Class Initialized
INFO - 2023-06-07 08:26:31 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:26:31 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:26:31 --> Utf8 Class Initialized
INFO - 2023-06-07 08:26:31 --> URI Class Initialized
INFO - 2023-06-07 08:26:31 --> Router Class Initialized
INFO - 2023-06-07 08:26:31 --> Output Class Initialized
INFO - 2023-06-07 08:26:31 --> Security Class Initialized
DEBUG - 2023-06-07 08:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:26:31 --> Input Class Initialized
INFO - 2023-06-07 08:26:31 --> Language Class Initialized
INFO - 2023-06-07 08:26:31 --> Language Class Initialized
INFO - 2023-06-07 08:26:31 --> Config Class Initialized
INFO - 2023-06-07 08:26:31 --> Loader Class Initialized
INFO - 2023-06-07 08:26:31 --> Helper loaded: url_helper
INFO - 2023-06-07 08:26:31 --> Helper loaded: file_helper
INFO - 2023-06-07 08:26:31 --> Helper loaded: form_helper
INFO - 2023-06-07 08:26:31 --> Helper loaded: my_helper
INFO - 2023-06-07 08:26:31 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:26:31 --> Controller Class Initialized
DEBUG - 2023-06-07 08:26:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:26:32 --> Final output sent to browser
DEBUG - 2023-06-07 08:26:32 --> Total execution time: 0.9999
INFO - 2023-06-07 08:27:02 --> Config Class Initialized
INFO - 2023-06-07 08:27:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:27:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:27:02 --> Utf8 Class Initialized
INFO - 2023-06-07 08:27:02 --> URI Class Initialized
INFO - 2023-06-07 08:27:02 --> Router Class Initialized
INFO - 2023-06-07 08:27:02 --> Output Class Initialized
INFO - 2023-06-07 08:27:02 --> Security Class Initialized
DEBUG - 2023-06-07 08:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:27:02 --> Input Class Initialized
INFO - 2023-06-07 08:27:02 --> Language Class Initialized
INFO - 2023-06-07 08:27:02 --> Language Class Initialized
INFO - 2023-06-07 08:27:02 --> Config Class Initialized
INFO - 2023-06-07 08:27:02 --> Loader Class Initialized
INFO - 2023-06-07 08:27:02 --> Helper loaded: url_helper
INFO - 2023-06-07 08:27:02 --> Helper loaded: file_helper
INFO - 2023-06-07 08:27:02 --> Helper loaded: form_helper
INFO - 2023-06-07 08:27:02 --> Helper loaded: my_helper
INFO - 2023-06-07 08:27:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:27:02 --> Controller Class Initialized
DEBUG - 2023-06-07 08:27:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:27:03 --> Final output sent to browser
DEBUG - 2023-06-07 08:27:03 --> Total execution time: 0.9995
INFO - 2023-06-07 08:27:14 --> Config Class Initialized
INFO - 2023-06-07 08:27:14 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:27:14 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:27:14 --> Utf8 Class Initialized
INFO - 2023-06-07 08:27:14 --> URI Class Initialized
INFO - 2023-06-07 08:27:14 --> Router Class Initialized
INFO - 2023-06-07 08:27:14 --> Output Class Initialized
INFO - 2023-06-07 08:27:14 --> Security Class Initialized
DEBUG - 2023-06-07 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:27:14 --> Input Class Initialized
INFO - 2023-06-07 08:27:14 --> Language Class Initialized
INFO - 2023-06-07 08:27:14 --> Language Class Initialized
INFO - 2023-06-07 08:27:14 --> Config Class Initialized
INFO - 2023-06-07 08:27:14 --> Loader Class Initialized
INFO - 2023-06-07 08:27:14 --> Helper loaded: url_helper
INFO - 2023-06-07 08:27:14 --> Helper loaded: file_helper
INFO - 2023-06-07 08:27:14 --> Helper loaded: form_helper
INFO - 2023-06-07 08:27:14 --> Helper loaded: my_helper
INFO - 2023-06-07 08:27:14 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:27:14 --> Controller Class Initialized
DEBUG - 2023-06-07 08:27:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:27:15 --> Final output sent to browser
DEBUG - 2023-06-07 08:27:15 --> Total execution time: 1.0006
INFO - 2023-06-07 08:27:37 --> Config Class Initialized
INFO - 2023-06-07 08:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:27:37 --> Utf8 Class Initialized
INFO - 2023-06-07 08:27:37 --> URI Class Initialized
INFO - 2023-06-07 08:27:37 --> Router Class Initialized
INFO - 2023-06-07 08:27:37 --> Output Class Initialized
INFO - 2023-06-07 08:27:37 --> Security Class Initialized
DEBUG - 2023-06-07 08:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:27:37 --> Input Class Initialized
INFO - 2023-06-07 08:27:37 --> Language Class Initialized
INFO - 2023-06-07 08:27:37 --> Language Class Initialized
INFO - 2023-06-07 08:27:37 --> Config Class Initialized
INFO - 2023-06-07 08:27:37 --> Loader Class Initialized
INFO - 2023-06-07 08:27:37 --> Helper loaded: url_helper
INFO - 2023-06-07 08:27:37 --> Helper loaded: file_helper
INFO - 2023-06-07 08:27:37 --> Helper loaded: form_helper
INFO - 2023-06-07 08:27:37 --> Helper loaded: my_helper
INFO - 2023-06-07 08:27:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:27:37 --> Controller Class Initialized
DEBUG - 2023-06-07 08:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:27:38 --> Final output sent to browser
DEBUG - 2023-06-07 08:27:38 --> Total execution time: 0.9120
INFO - 2023-06-07 08:27:53 --> Config Class Initialized
INFO - 2023-06-07 08:27:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:27:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:27:53 --> Utf8 Class Initialized
INFO - 2023-06-07 08:27:53 --> URI Class Initialized
INFO - 2023-06-07 08:27:53 --> Router Class Initialized
INFO - 2023-06-07 08:27:53 --> Output Class Initialized
INFO - 2023-06-07 08:27:53 --> Security Class Initialized
DEBUG - 2023-06-07 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:27:53 --> Input Class Initialized
INFO - 2023-06-07 08:27:53 --> Language Class Initialized
INFO - 2023-06-07 08:27:53 --> Language Class Initialized
INFO - 2023-06-07 08:27:53 --> Config Class Initialized
INFO - 2023-06-07 08:27:53 --> Loader Class Initialized
INFO - 2023-06-07 08:27:53 --> Helper loaded: url_helper
INFO - 2023-06-07 08:27:53 --> Helper loaded: file_helper
INFO - 2023-06-07 08:27:53 --> Helper loaded: form_helper
INFO - 2023-06-07 08:27:53 --> Helper loaded: my_helper
INFO - 2023-06-07 08:27:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:27:53 --> Controller Class Initialized
DEBUG - 2023-06-07 08:27:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:27:54 --> Final output sent to browser
DEBUG - 2023-06-07 08:27:54 --> Total execution time: 0.9244
INFO - 2023-06-07 08:28:03 --> Config Class Initialized
INFO - 2023-06-07 08:28:03 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:28:03 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:28:03 --> Utf8 Class Initialized
INFO - 2023-06-07 08:28:03 --> URI Class Initialized
INFO - 2023-06-07 08:28:03 --> Router Class Initialized
INFO - 2023-06-07 08:28:03 --> Output Class Initialized
INFO - 2023-06-07 08:28:03 --> Security Class Initialized
DEBUG - 2023-06-07 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:28:03 --> Input Class Initialized
INFO - 2023-06-07 08:28:03 --> Language Class Initialized
INFO - 2023-06-07 08:28:03 --> Language Class Initialized
INFO - 2023-06-07 08:28:03 --> Config Class Initialized
INFO - 2023-06-07 08:28:03 --> Loader Class Initialized
INFO - 2023-06-07 08:28:03 --> Helper loaded: url_helper
INFO - 2023-06-07 08:28:03 --> Helper loaded: file_helper
INFO - 2023-06-07 08:28:03 --> Helper loaded: form_helper
INFO - 2023-06-07 08:28:03 --> Helper loaded: my_helper
INFO - 2023-06-07 08:28:03 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:28:03 --> Controller Class Initialized
DEBUG - 2023-06-07 08:28:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:28:04 --> Final output sent to browser
DEBUG - 2023-06-07 08:28:04 --> Total execution time: 0.9580
INFO - 2023-06-07 08:28:51 --> Config Class Initialized
INFO - 2023-06-07 08:28:51 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:28:51 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:28:51 --> Utf8 Class Initialized
INFO - 2023-06-07 08:28:51 --> URI Class Initialized
INFO - 2023-06-07 08:28:51 --> Router Class Initialized
INFO - 2023-06-07 08:28:51 --> Output Class Initialized
INFO - 2023-06-07 08:28:51 --> Security Class Initialized
DEBUG - 2023-06-07 08:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:28:51 --> Input Class Initialized
INFO - 2023-06-07 08:28:51 --> Language Class Initialized
INFO - 2023-06-07 08:28:51 --> Language Class Initialized
INFO - 2023-06-07 08:28:51 --> Config Class Initialized
INFO - 2023-06-07 08:28:51 --> Loader Class Initialized
INFO - 2023-06-07 08:28:51 --> Helper loaded: url_helper
INFO - 2023-06-07 08:28:51 --> Helper loaded: file_helper
INFO - 2023-06-07 08:28:51 --> Helper loaded: form_helper
INFO - 2023-06-07 08:28:51 --> Helper loaded: my_helper
INFO - 2023-06-07 08:28:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:28:51 --> Controller Class Initialized
DEBUG - 2023-06-07 08:28:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:28:52 --> Final output sent to browser
DEBUG - 2023-06-07 08:28:52 --> Total execution time: 0.9281
INFO - 2023-06-07 08:30:02 --> Config Class Initialized
INFO - 2023-06-07 08:30:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:30:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:30:02 --> Utf8 Class Initialized
INFO - 2023-06-07 08:30:02 --> URI Class Initialized
INFO - 2023-06-07 08:30:02 --> Router Class Initialized
INFO - 2023-06-07 08:30:02 --> Output Class Initialized
INFO - 2023-06-07 08:30:02 --> Security Class Initialized
DEBUG - 2023-06-07 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:30:02 --> Input Class Initialized
INFO - 2023-06-07 08:30:02 --> Language Class Initialized
INFO - 2023-06-07 08:30:02 --> Language Class Initialized
INFO - 2023-06-07 08:30:02 --> Config Class Initialized
INFO - 2023-06-07 08:30:02 --> Loader Class Initialized
INFO - 2023-06-07 08:30:02 --> Helper loaded: url_helper
INFO - 2023-06-07 08:30:02 --> Helper loaded: file_helper
INFO - 2023-06-07 08:30:02 --> Helper loaded: form_helper
INFO - 2023-06-07 08:30:02 --> Helper loaded: my_helper
INFO - 2023-06-07 08:30:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:30:02 --> Controller Class Initialized
DEBUG - 2023-06-07 08:30:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:30:03 --> Final output sent to browser
DEBUG - 2023-06-07 08:30:03 --> Total execution time: 0.9769
INFO - 2023-06-07 08:30:21 --> Config Class Initialized
INFO - 2023-06-07 08:30:21 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:30:21 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:30:21 --> Utf8 Class Initialized
INFO - 2023-06-07 08:30:21 --> URI Class Initialized
INFO - 2023-06-07 08:30:21 --> Router Class Initialized
INFO - 2023-06-07 08:30:21 --> Output Class Initialized
INFO - 2023-06-07 08:30:21 --> Security Class Initialized
DEBUG - 2023-06-07 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:30:21 --> Input Class Initialized
INFO - 2023-06-07 08:30:21 --> Language Class Initialized
INFO - 2023-06-07 08:30:21 --> Language Class Initialized
INFO - 2023-06-07 08:30:21 --> Config Class Initialized
INFO - 2023-06-07 08:30:21 --> Loader Class Initialized
INFO - 2023-06-07 08:30:21 --> Helper loaded: url_helper
INFO - 2023-06-07 08:30:21 --> Helper loaded: file_helper
INFO - 2023-06-07 08:30:21 --> Helper loaded: form_helper
INFO - 2023-06-07 08:30:21 --> Helper loaded: my_helper
INFO - 2023-06-07 08:30:21 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:30:21 --> Controller Class Initialized
DEBUG - 2023-06-07 08:30:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:30:22 --> Final output sent to browser
DEBUG - 2023-06-07 08:30:22 --> Total execution time: 1.0022
INFO - 2023-06-07 08:30:49 --> Config Class Initialized
INFO - 2023-06-07 08:30:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:30:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:30:49 --> Utf8 Class Initialized
INFO - 2023-06-07 08:30:49 --> URI Class Initialized
INFO - 2023-06-07 08:30:49 --> Router Class Initialized
INFO - 2023-06-07 08:30:49 --> Output Class Initialized
INFO - 2023-06-07 08:30:49 --> Security Class Initialized
DEBUG - 2023-06-07 08:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:30:49 --> Input Class Initialized
INFO - 2023-06-07 08:30:49 --> Language Class Initialized
INFO - 2023-06-07 08:30:49 --> Language Class Initialized
INFO - 2023-06-07 08:30:49 --> Config Class Initialized
INFO - 2023-06-07 08:30:49 --> Loader Class Initialized
INFO - 2023-06-07 08:30:49 --> Helper loaded: url_helper
INFO - 2023-06-07 08:30:49 --> Helper loaded: file_helper
INFO - 2023-06-07 08:30:49 --> Helper loaded: form_helper
INFO - 2023-06-07 08:30:49 --> Helper loaded: my_helper
INFO - 2023-06-07 08:30:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:30:49 --> Controller Class Initialized
DEBUG - 2023-06-07 08:30:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:30:50 --> Final output sent to browser
DEBUG - 2023-06-07 08:30:50 --> Total execution time: 0.9856
INFO - 2023-06-07 08:31:06 --> Config Class Initialized
INFO - 2023-06-07 08:31:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:31:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:31:06 --> Utf8 Class Initialized
INFO - 2023-06-07 08:31:06 --> URI Class Initialized
INFO - 2023-06-07 08:31:06 --> Router Class Initialized
INFO - 2023-06-07 08:31:06 --> Output Class Initialized
INFO - 2023-06-07 08:31:06 --> Security Class Initialized
DEBUG - 2023-06-07 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:31:06 --> Input Class Initialized
INFO - 2023-06-07 08:31:06 --> Language Class Initialized
INFO - 2023-06-07 08:31:06 --> Language Class Initialized
INFO - 2023-06-07 08:31:06 --> Config Class Initialized
INFO - 2023-06-07 08:31:06 --> Loader Class Initialized
INFO - 2023-06-07 08:31:06 --> Helper loaded: url_helper
INFO - 2023-06-07 08:31:06 --> Helper loaded: file_helper
INFO - 2023-06-07 08:31:06 --> Helper loaded: form_helper
INFO - 2023-06-07 08:31:06 --> Helper loaded: my_helper
INFO - 2023-06-07 08:31:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:31:06 --> Controller Class Initialized
DEBUG - 2023-06-07 08:31:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:31:07 --> Final output sent to browser
DEBUG - 2023-06-07 08:31:07 --> Total execution time: 0.9531
INFO - 2023-06-07 08:31:15 --> Config Class Initialized
INFO - 2023-06-07 08:31:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:31:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:31:15 --> Utf8 Class Initialized
INFO - 2023-06-07 08:31:15 --> URI Class Initialized
INFO - 2023-06-07 08:31:15 --> Router Class Initialized
INFO - 2023-06-07 08:31:15 --> Output Class Initialized
INFO - 2023-06-07 08:31:15 --> Security Class Initialized
DEBUG - 2023-06-07 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:31:15 --> Input Class Initialized
INFO - 2023-06-07 08:31:15 --> Language Class Initialized
INFO - 2023-06-07 08:31:15 --> Language Class Initialized
INFO - 2023-06-07 08:31:15 --> Config Class Initialized
INFO - 2023-06-07 08:31:15 --> Loader Class Initialized
INFO - 2023-06-07 08:31:15 --> Helper loaded: url_helper
INFO - 2023-06-07 08:31:15 --> Helper loaded: file_helper
INFO - 2023-06-07 08:31:15 --> Helper loaded: form_helper
INFO - 2023-06-07 08:31:15 --> Helper loaded: my_helper
INFO - 2023-06-07 08:31:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:31:15 --> Controller Class Initialized
DEBUG - 2023-06-07 08:31:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:31:15 --> Final output sent to browser
DEBUG - 2023-06-07 08:31:15 --> Total execution time: 0.9285
INFO - 2023-06-07 08:31:49 --> Config Class Initialized
INFO - 2023-06-07 08:31:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:31:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:31:49 --> Utf8 Class Initialized
INFO - 2023-06-07 08:31:49 --> URI Class Initialized
INFO - 2023-06-07 08:31:49 --> Router Class Initialized
INFO - 2023-06-07 08:31:49 --> Output Class Initialized
INFO - 2023-06-07 08:31:49 --> Security Class Initialized
DEBUG - 2023-06-07 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:31:49 --> Input Class Initialized
INFO - 2023-06-07 08:31:49 --> Language Class Initialized
INFO - 2023-06-07 08:31:49 --> Language Class Initialized
INFO - 2023-06-07 08:31:49 --> Config Class Initialized
INFO - 2023-06-07 08:31:49 --> Loader Class Initialized
INFO - 2023-06-07 08:31:49 --> Helper loaded: url_helper
INFO - 2023-06-07 08:31:49 --> Helper loaded: file_helper
INFO - 2023-06-07 08:31:49 --> Helper loaded: form_helper
INFO - 2023-06-07 08:31:49 --> Helper loaded: my_helper
INFO - 2023-06-07 08:31:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:31:49 --> Controller Class Initialized
DEBUG - 2023-06-07 08:31:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:31:50 --> Final output sent to browser
DEBUG - 2023-06-07 08:31:50 --> Total execution time: 0.9656
INFO - 2023-06-07 08:32:02 --> Config Class Initialized
INFO - 2023-06-07 08:32:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:32:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:32:02 --> Utf8 Class Initialized
INFO - 2023-06-07 08:32:02 --> URI Class Initialized
INFO - 2023-06-07 08:32:02 --> Router Class Initialized
INFO - 2023-06-07 08:32:02 --> Output Class Initialized
INFO - 2023-06-07 08:32:02 --> Security Class Initialized
DEBUG - 2023-06-07 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:32:02 --> Input Class Initialized
INFO - 2023-06-07 08:32:02 --> Language Class Initialized
INFO - 2023-06-07 08:32:02 --> Language Class Initialized
INFO - 2023-06-07 08:32:02 --> Config Class Initialized
INFO - 2023-06-07 08:32:02 --> Loader Class Initialized
INFO - 2023-06-07 08:32:02 --> Helper loaded: url_helper
INFO - 2023-06-07 08:32:02 --> Helper loaded: file_helper
INFO - 2023-06-07 08:32:02 --> Helper loaded: form_helper
INFO - 2023-06-07 08:32:02 --> Helper loaded: my_helper
INFO - 2023-06-07 08:32:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:32:02 --> Controller Class Initialized
DEBUG - 2023-06-07 08:32:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:32:03 --> Final output sent to browser
DEBUG - 2023-06-07 08:32:03 --> Total execution time: 0.9678
INFO - 2023-06-07 08:32:32 --> Config Class Initialized
INFO - 2023-06-07 08:32:32 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:32:32 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:32:32 --> Utf8 Class Initialized
INFO - 2023-06-07 08:32:32 --> URI Class Initialized
INFO - 2023-06-07 08:32:32 --> Router Class Initialized
INFO - 2023-06-07 08:32:32 --> Output Class Initialized
INFO - 2023-06-07 08:32:32 --> Security Class Initialized
DEBUG - 2023-06-07 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:32:32 --> Input Class Initialized
INFO - 2023-06-07 08:32:32 --> Language Class Initialized
INFO - 2023-06-07 08:32:32 --> Language Class Initialized
INFO - 2023-06-07 08:32:32 --> Config Class Initialized
INFO - 2023-06-07 08:32:32 --> Loader Class Initialized
INFO - 2023-06-07 08:32:32 --> Helper loaded: url_helper
INFO - 2023-06-07 08:32:32 --> Helper loaded: file_helper
INFO - 2023-06-07 08:32:32 --> Helper loaded: form_helper
INFO - 2023-06-07 08:32:32 --> Helper loaded: my_helper
INFO - 2023-06-07 08:32:32 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:32:32 --> Controller Class Initialized
DEBUG - 2023-06-07 08:32:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:32:33 --> Final output sent to browser
DEBUG - 2023-06-07 08:32:33 --> Total execution time: 1.0007
INFO - 2023-06-07 08:47:09 --> Config Class Initialized
INFO - 2023-06-07 08:47:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:47:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:47:09 --> Utf8 Class Initialized
INFO - 2023-06-07 08:47:09 --> URI Class Initialized
INFO - 2023-06-07 08:47:09 --> Router Class Initialized
INFO - 2023-06-07 08:47:09 --> Output Class Initialized
INFO - 2023-06-07 08:47:09 --> Security Class Initialized
DEBUG - 2023-06-07 08:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:47:09 --> Input Class Initialized
INFO - 2023-06-07 08:47:09 --> Language Class Initialized
INFO - 2023-06-07 08:47:09 --> Language Class Initialized
INFO - 2023-06-07 08:47:09 --> Config Class Initialized
INFO - 2023-06-07 08:47:09 --> Loader Class Initialized
INFO - 2023-06-07 08:47:09 --> Helper loaded: url_helper
INFO - 2023-06-07 08:47:09 --> Helper loaded: file_helper
INFO - 2023-06-07 08:47:09 --> Helper loaded: form_helper
INFO - 2023-06-07 08:47:09 --> Helper loaded: my_helper
INFO - 2023-06-07 08:47:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:47:09 --> Controller Class Initialized
DEBUG - 2023-06-07 08:47:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-06-07 08:47:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 08:47:09 --> Final output sent to browser
DEBUG - 2023-06-07 08:47:09 --> Total execution time: 0.0419
INFO - 2023-06-07 08:47:16 --> Config Class Initialized
INFO - 2023-06-07 08:47:16 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:47:16 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:47:16 --> Utf8 Class Initialized
INFO - 2023-06-07 08:47:16 --> URI Class Initialized
INFO - 2023-06-07 08:47:16 --> Router Class Initialized
INFO - 2023-06-07 08:47:16 --> Output Class Initialized
INFO - 2023-06-07 08:47:16 --> Security Class Initialized
DEBUG - 2023-06-07 08:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:47:16 --> Input Class Initialized
INFO - 2023-06-07 08:47:16 --> Language Class Initialized
INFO - 2023-06-07 08:47:16 --> Language Class Initialized
INFO - 2023-06-07 08:47:16 --> Config Class Initialized
INFO - 2023-06-07 08:47:16 --> Loader Class Initialized
INFO - 2023-06-07 08:47:16 --> Helper loaded: url_helper
INFO - 2023-06-07 08:47:16 --> Helper loaded: file_helper
INFO - 2023-06-07 08:47:16 --> Helper loaded: form_helper
INFO - 2023-06-07 08:47:16 --> Helper loaded: my_helper
INFO - 2023-06-07 08:47:16 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:47:16 --> Controller Class Initialized
DEBUG - 2023-06-07 08:47:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:47:17 --> Final output sent to browser
DEBUG - 2023-06-07 08:47:17 --> Total execution time: 0.9845
INFO - 2023-06-07 08:47:28 --> Config Class Initialized
INFO - 2023-06-07 08:47:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:47:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:47:28 --> Utf8 Class Initialized
INFO - 2023-06-07 08:47:28 --> URI Class Initialized
INFO - 2023-06-07 08:47:28 --> Router Class Initialized
INFO - 2023-06-07 08:47:28 --> Output Class Initialized
INFO - 2023-06-07 08:47:28 --> Security Class Initialized
DEBUG - 2023-06-07 08:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:47:28 --> Input Class Initialized
INFO - 2023-06-07 08:47:28 --> Language Class Initialized
INFO - 2023-06-07 08:47:28 --> Language Class Initialized
INFO - 2023-06-07 08:47:28 --> Config Class Initialized
INFO - 2023-06-07 08:47:28 --> Loader Class Initialized
INFO - 2023-06-07 08:47:28 --> Helper loaded: url_helper
INFO - 2023-06-07 08:47:28 --> Helper loaded: file_helper
INFO - 2023-06-07 08:47:28 --> Helper loaded: form_helper
INFO - 2023-06-07 08:47:28 --> Helper loaded: my_helper
INFO - 2023-06-07 08:47:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:47:28 --> Controller Class Initialized
DEBUG - 2023-06-07 08:47:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-07 08:47:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 08:47:28 --> Final output sent to browser
DEBUG - 2023-06-07 08:47:28 --> Total execution time: 0.0496
INFO - 2023-06-07 08:47:30 --> Config Class Initialized
INFO - 2023-06-07 08:47:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:47:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:47:30 --> Utf8 Class Initialized
INFO - 2023-06-07 08:47:30 --> URI Class Initialized
INFO - 2023-06-07 08:47:30 --> Router Class Initialized
INFO - 2023-06-07 08:47:30 --> Output Class Initialized
INFO - 2023-06-07 08:47:30 --> Security Class Initialized
DEBUG - 2023-06-07 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:47:30 --> Input Class Initialized
INFO - 2023-06-07 08:47:30 --> Language Class Initialized
INFO - 2023-06-07 08:47:30 --> Language Class Initialized
INFO - 2023-06-07 08:47:30 --> Config Class Initialized
INFO - 2023-06-07 08:47:30 --> Loader Class Initialized
INFO - 2023-06-07 08:47:30 --> Helper loaded: url_helper
INFO - 2023-06-07 08:47:30 --> Helper loaded: file_helper
INFO - 2023-06-07 08:47:30 --> Helper loaded: form_helper
INFO - 2023-06-07 08:47:30 --> Helper loaded: my_helper
INFO - 2023-06-07 08:47:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:47:30 --> Controller Class Initialized
DEBUG - 2023-06-07 08:47:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-07 08:47:31 --> Final output sent to browser
DEBUG - 2023-06-07 08:47:31 --> Total execution time: 0.9644
INFO - 2023-06-07 08:47:44 --> Config Class Initialized
INFO - 2023-06-07 08:47:44 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:47:44 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:47:44 --> Utf8 Class Initialized
INFO - 2023-06-07 08:47:44 --> URI Class Initialized
INFO - 2023-06-07 08:47:44 --> Router Class Initialized
INFO - 2023-06-07 08:47:44 --> Output Class Initialized
INFO - 2023-06-07 08:47:44 --> Security Class Initialized
DEBUG - 2023-06-07 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:47:44 --> Input Class Initialized
INFO - 2023-06-07 08:47:44 --> Language Class Initialized
INFO - 2023-06-07 08:47:44 --> Language Class Initialized
INFO - 2023-06-07 08:47:44 --> Config Class Initialized
INFO - 2023-06-07 08:47:44 --> Loader Class Initialized
INFO - 2023-06-07 08:47:44 --> Helper loaded: url_helper
INFO - 2023-06-07 08:47:44 --> Helper loaded: file_helper
INFO - 2023-06-07 08:47:44 --> Helper loaded: form_helper
INFO - 2023-06-07 08:47:44 --> Helper loaded: my_helper
INFO - 2023-06-07 08:47:44 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:47:44 --> Controller Class Initialized
DEBUG - 2023-06-07 08:47:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:47:45 --> Final output sent to browser
DEBUG - 2023-06-07 08:47:45 --> Total execution time: 0.8890
INFO - 2023-06-07 08:49:35 --> Config Class Initialized
INFO - 2023-06-07 08:49:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:49:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:49:35 --> Utf8 Class Initialized
INFO - 2023-06-07 08:49:35 --> URI Class Initialized
INFO - 2023-06-07 08:49:35 --> Router Class Initialized
INFO - 2023-06-07 08:49:35 --> Output Class Initialized
INFO - 2023-06-07 08:49:35 --> Security Class Initialized
DEBUG - 2023-06-07 08:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:49:35 --> Input Class Initialized
INFO - 2023-06-07 08:49:35 --> Language Class Initialized
INFO - 2023-06-07 08:49:35 --> Language Class Initialized
INFO - 2023-06-07 08:49:35 --> Config Class Initialized
INFO - 2023-06-07 08:49:35 --> Loader Class Initialized
INFO - 2023-06-07 08:49:35 --> Helper loaded: url_helper
INFO - 2023-06-07 08:49:35 --> Helper loaded: file_helper
INFO - 2023-06-07 08:49:35 --> Helper loaded: form_helper
INFO - 2023-06-07 08:49:35 --> Helper loaded: my_helper
INFO - 2023-06-07 08:49:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:49:35 --> Controller Class Initialized
DEBUG - 2023-06-07 08:49:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:49:36 --> Final output sent to browser
DEBUG - 2023-06-07 08:49:36 --> Total execution time: 1.0397
INFO - 2023-06-07 08:52:17 --> Config Class Initialized
INFO - 2023-06-07 08:52:17 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:52:17 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:52:17 --> Utf8 Class Initialized
INFO - 2023-06-07 08:52:17 --> URI Class Initialized
INFO - 2023-06-07 08:52:17 --> Router Class Initialized
INFO - 2023-06-07 08:52:17 --> Output Class Initialized
INFO - 2023-06-07 08:52:17 --> Security Class Initialized
DEBUG - 2023-06-07 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:52:17 --> Input Class Initialized
INFO - 2023-06-07 08:52:17 --> Language Class Initialized
INFO - 2023-06-07 08:52:17 --> Language Class Initialized
INFO - 2023-06-07 08:52:17 --> Config Class Initialized
INFO - 2023-06-07 08:52:17 --> Loader Class Initialized
INFO - 2023-06-07 08:52:17 --> Helper loaded: url_helper
INFO - 2023-06-07 08:52:17 --> Helper loaded: file_helper
INFO - 2023-06-07 08:52:17 --> Helper loaded: form_helper
INFO - 2023-06-07 08:52:17 --> Helper loaded: my_helper
INFO - 2023-06-07 08:52:17 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:52:17 --> Controller Class Initialized
DEBUG - 2023-06-07 08:52:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:52:18 --> Final output sent to browser
DEBUG - 2023-06-07 08:52:18 --> Total execution time: 0.9598
INFO - 2023-06-07 08:53:56 --> Config Class Initialized
INFO - 2023-06-07 08:53:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:53:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:53:56 --> Utf8 Class Initialized
INFO - 2023-06-07 08:53:56 --> URI Class Initialized
INFO - 2023-06-07 08:53:56 --> Router Class Initialized
INFO - 2023-06-07 08:53:56 --> Output Class Initialized
INFO - 2023-06-07 08:53:56 --> Security Class Initialized
DEBUG - 2023-06-07 08:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:53:56 --> Input Class Initialized
INFO - 2023-06-07 08:53:56 --> Language Class Initialized
INFO - 2023-06-07 08:53:56 --> Language Class Initialized
INFO - 2023-06-07 08:53:56 --> Config Class Initialized
INFO - 2023-06-07 08:53:56 --> Loader Class Initialized
INFO - 2023-06-07 08:53:56 --> Helper loaded: url_helper
INFO - 2023-06-07 08:53:56 --> Helper loaded: file_helper
INFO - 2023-06-07 08:53:56 --> Helper loaded: form_helper
INFO - 2023-06-07 08:53:56 --> Helper loaded: my_helper
INFO - 2023-06-07 08:53:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:53:56 --> Controller Class Initialized
DEBUG - 2023-06-07 08:53:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:53:57 --> Final output sent to browser
DEBUG - 2023-06-07 08:53:57 --> Total execution time: 0.9579
INFO - 2023-06-07 08:55:04 --> Config Class Initialized
INFO - 2023-06-07 08:55:04 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:55:04 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:55:04 --> Utf8 Class Initialized
INFO - 2023-06-07 08:55:04 --> URI Class Initialized
INFO - 2023-06-07 08:55:04 --> Router Class Initialized
INFO - 2023-06-07 08:55:04 --> Output Class Initialized
INFO - 2023-06-07 08:55:04 --> Security Class Initialized
DEBUG - 2023-06-07 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:55:04 --> Input Class Initialized
INFO - 2023-06-07 08:55:04 --> Language Class Initialized
INFO - 2023-06-07 08:55:04 --> Language Class Initialized
INFO - 2023-06-07 08:55:04 --> Config Class Initialized
INFO - 2023-06-07 08:55:04 --> Loader Class Initialized
INFO - 2023-06-07 08:55:04 --> Helper loaded: url_helper
INFO - 2023-06-07 08:55:04 --> Helper loaded: file_helper
INFO - 2023-06-07 08:55:04 --> Helper loaded: form_helper
INFO - 2023-06-07 08:55:04 --> Helper loaded: my_helper
INFO - 2023-06-07 08:55:04 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:55:04 --> Controller Class Initialized
DEBUG - 2023-06-07 08:55:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:55:05 --> Final output sent to browser
DEBUG - 2023-06-07 08:55:05 --> Total execution time: 0.9677
INFO - 2023-06-07 08:55:48 --> Config Class Initialized
INFO - 2023-06-07 08:55:48 --> Hooks Class Initialized
DEBUG - 2023-06-07 08:55:48 --> UTF-8 Support Enabled
INFO - 2023-06-07 08:55:48 --> Utf8 Class Initialized
INFO - 2023-06-07 08:55:48 --> URI Class Initialized
INFO - 2023-06-07 08:55:48 --> Router Class Initialized
INFO - 2023-06-07 08:55:48 --> Output Class Initialized
INFO - 2023-06-07 08:55:48 --> Security Class Initialized
DEBUG - 2023-06-07 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 08:55:48 --> Input Class Initialized
INFO - 2023-06-07 08:55:48 --> Language Class Initialized
INFO - 2023-06-07 08:55:48 --> Language Class Initialized
INFO - 2023-06-07 08:55:48 --> Config Class Initialized
INFO - 2023-06-07 08:55:48 --> Loader Class Initialized
INFO - 2023-06-07 08:55:48 --> Helper loaded: url_helper
INFO - 2023-06-07 08:55:48 --> Helper loaded: file_helper
INFO - 2023-06-07 08:55:48 --> Helper loaded: form_helper
INFO - 2023-06-07 08:55:48 --> Helper loaded: my_helper
INFO - 2023-06-07 08:55:48 --> Database Driver Class Initialized
DEBUG - 2023-06-07 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 08:55:48 --> Controller Class Initialized
DEBUG - 2023-06-07 08:55:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 08:55:49 --> Final output sent to browser
DEBUG - 2023-06-07 08:55:49 --> Total execution time: 0.9120
INFO - 2023-06-07 09:02:34 --> Config Class Initialized
INFO - 2023-06-07 09:02:34 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:02:34 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:02:34 --> Utf8 Class Initialized
INFO - 2023-06-07 09:02:34 --> URI Class Initialized
INFO - 2023-06-07 09:02:34 --> Router Class Initialized
INFO - 2023-06-07 09:02:34 --> Output Class Initialized
INFO - 2023-06-07 09:02:34 --> Security Class Initialized
DEBUG - 2023-06-07 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:02:34 --> Input Class Initialized
INFO - 2023-06-07 09:02:34 --> Language Class Initialized
INFO - 2023-06-07 09:02:34 --> Language Class Initialized
INFO - 2023-06-07 09:02:34 --> Config Class Initialized
INFO - 2023-06-07 09:02:34 --> Loader Class Initialized
INFO - 2023-06-07 09:02:34 --> Helper loaded: url_helper
INFO - 2023-06-07 09:02:34 --> Helper loaded: file_helper
INFO - 2023-06-07 09:02:34 --> Helper loaded: form_helper
INFO - 2023-06-07 09:02:34 --> Helper loaded: my_helper
INFO - 2023-06-07 09:02:34 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:02:34 --> Controller Class Initialized
DEBUG - 2023-06-07 09:02:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:02:35 --> Final output sent to browser
DEBUG - 2023-06-07 09:02:35 --> Total execution time: 1.0145
INFO - 2023-06-07 09:03:09 --> Config Class Initialized
INFO - 2023-06-07 09:03:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:03:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:03:09 --> Utf8 Class Initialized
INFO - 2023-06-07 09:03:09 --> URI Class Initialized
INFO - 2023-06-07 09:03:09 --> Router Class Initialized
INFO - 2023-06-07 09:03:09 --> Output Class Initialized
INFO - 2023-06-07 09:03:09 --> Security Class Initialized
DEBUG - 2023-06-07 09:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:03:09 --> Input Class Initialized
INFO - 2023-06-07 09:03:09 --> Language Class Initialized
INFO - 2023-06-07 09:03:09 --> Language Class Initialized
INFO - 2023-06-07 09:03:09 --> Config Class Initialized
INFO - 2023-06-07 09:03:09 --> Loader Class Initialized
INFO - 2023-06-07 09:03:09 --> Helper loaded: url_helper
INFO - 2023-06-07 09:03:09 --> Helper loaded: file_helper
INFO - 2023-06-07 09:03:09 --> Helper loaded: form_helper
INFO - 2023-06-07 09:03:09 --> Helper loaded: my_helper
INFO - 2023-06-07 09:03:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:03:09 --> Controller Class Initialized
DEBUG - 2023-06-07 09:03:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 09:03:10 --> Severity: error --> Exception: The html tag [hr] is not known by Html2Pdf. You can create it and push it on the Html2Pdf GitHub project. C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Html2Pdf.php 1441
ERROR - 2023-06-07 09:03:10 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f1ff95b06bb1d781e85331246299fa52_imgmask_alpha_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-06-07 09:03:10 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f1ff95b06bb1d781e85331246299fa52_imgmask_plain_bbf70f351151ae27d2f6bb0d9478645a): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-06-07 09:03:10 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f1ff95b06bb1d781e85331246299fa52_imgmask_alpha_7c83f8c2ecfa0a337831837a94bceaa7): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
ERROR - 2023-06-07 09:03:10 --> Severity: Warning --> unlink(C:\xampp\tmp/__tcpdf_f1ff95b06bb1d781e85331246299fa52_imgmask_plain_7c83f8c2ecfa0a337831837a94bceaa7): No such file or directory C:\xampp\htdocs\myraportk13\aset\html2pdf\tecnickcom\tcpdf\tcpdf.php 7801
INFO - 2023-06-07 09:03:23 --> Config Class Initialized
INFO - 2023-06-07 09:03:23 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:03:23 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:03:23 --> Utf8 Class Initialized
INFO - 2023-06-07 09:03:23 --> URI Class Initialized
INFO - 2023-06-07 09:03:23 --> Router Class Initialized
INFO - 2023-06-07 09:03:23 --> Output Class Initialized
INFO - 2023-06-07 09:03:23 --> Security Class Initialized
DEBUG - 2023-06-07 09:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:03:23 --> Input Class Initialized
INFO - 2023-06-07 09:03:23 --> Language Class Initialized
INFO - 2023-06-07 09:03:23 --> Language Class Initialized
INFO - 2023-06-07 09:03:23 --> Config Class Initialized
INFO - 2023-06-07 09:03:23 --> Loader Class Initialized
INFO - 2023-06-07 09:03:23 --> Helper loaded: url_helper
INFO - 2023-06-07 09:03:23 --> Helper loaded: file_helper
INFO - 2023-06-07 09:03:23 --> Helper loaded: form_helper
INFO - 2023-06-07 09:03:23 --> Helper loaded: my_helper
INFO - 2023-06-07 09:03:23 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:03:23 --> Controller Class Initialized
DEBUG - 2023-06-07 09:03:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:03:24 --> Final output sent to browser
DEBUG - 2023-06-07 09:03:24 --> Total execution time: 1.0247
INFO - 2023-06-07 09:04:42 --> Config Class Initialized
INFO - 2023-06-07 09:04:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:04:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:04:42 --> Utf8 Class Initialized
INFO - 2023-06-07 09:04:42 --> URI Class Initialized
INFO - 2023-06-07 09:04:42 --> Router Class Initialized
INFO - 2023-06-07 09:04:42 --> Output Class Initialized
INFO - 2023-06-07 09:04:42 --> Security Class Initialized
DEBUG - 2023-06-07 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:04:42 --> Input Class Initialized
INFO - 2023-06-07 09:04:42 --> Language Class Initialized
INFO - 2023-06-07 09:04:42 --> Language Class Initialized
INFO - 2023-06-07 09:04:42 --> Config Class Initialized
INFO - 2023-06-07 09:04:42 --> Loader Class Initialized
INFO - 2023-06-07 09:04:42 --> Helper loaded: url_helper
INFO - 2023-06-07 09:04:42 --> Helper loaded: file_helper
INFO - 2023-06-07 09:04:42 --> Helper loaded: form_helper
INFO - 2023-06-07 09:04:42 --> Helper loaded: my_helper
INFO - 2023-06-07 09:04:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:04:42 --> Controller Class Initialized
DEBUG - 2023-06-07 09:04:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
ERROR - 2023-06-07 09:04:42 --> Severity: error --> Exception: The following tag has not been closed: thead C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 173
INFO - 2023-06-07 09:04:56 --> Config Class Initialized
INFO - 2023-06-07 09:04:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:04:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:04:56 --> Utf8 Class Initialized
INFO - 2023-06-07 09:04:56 --> URI Class Initialized
INFO - 2023-06-07 09:04:56 --> Router Class Initialized
INFO - 2023-06-07 09:04:56 --> Output Class Initialized
INFO - 2023-06-07 09:04:56 --> Security Class Initialized
DEBUG - 2023-06-07 09:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:04:56 --> Input Class Initialized
INFO - 2023-06-07 09:04:56 --> Language Class Initialized
INFO - 2023-06-07 09:04:56 --> Language Class Initialized
INFO - 2023-06-07 09:04:56 --> Config Class Initialized
INFO - 2023-06-07 09:04:56 --> Loader Class Initialized
INFO - 2023-06-07 09:04:56 --> Helper loaded: url_helper
INFO - 2023-06-07 09:04:56 --> Helper loaded: file_helper
INFO - 2023-06-07 09:04:56 --> Helper loaded: form_helper
INFO - 2023-06-07 09:04:56 --> Helper loaded: my_helper
INFO - 2023-06-07 09:04:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:04:56 --> Controller Class Initialized
DEBUG - 2023-06-07 09:04:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:04:57 --> Final output sent to browser
DEBUG - 2023-06-07 09:04:57 --> Total execution time: 0.9489
INFO - 2023-06-07 09:05:11 --> Config Class Initialized
INFO - 2023-06-07 09:05:11 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:05:11 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:05:11 --> Utf8 Class Initialized
INFO - 2023-06-07 09:05:11 --> URI Class Initialized
INFO - 2023-06-07 09:05:11 --> Router Class Initialized
INFO - 2023-06-07 09:05:11 --> Output Class Initialized
INFO - 2023-06-07 09:05:11 --> Security Class Initialized
DEBUG - 2023-06-07 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:05:11 --> Input Class Initialized
INFO - 2023-06-07 09:05:11 --> Language Class Initialized
INFO - 2023-06-07 09:05:11 --> Language Class Initialized
INFO - 2023-06-07 09:05:11 --> Config Class Initialized
INFO - 2023-06-07 09:05:11 --> Loader Class Initialized
INFO - 2023-06-07 09:05:11 --> Helper loaded: url_helper
INFO - 2023-06-07 09:05:11 --> Helper loaded: file_helper
INFO - 2023-06-07 09:05:11 --> Helper loaded: form_helper
INFO - 2023-06-07 09:05:11 --> Helper loaded: my_helper
INFO - 2023-06-07 09:05:11 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:05:11 --> Controller Class Initialized
DEBUG - 2023-06-07 09:05:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:05:12 --> Final output sent to browser
DEBUG - 2023-06-07 09:05:12 --> Total execution time: 0.9842
INFO - 2023-06-07 09:05:35 --> Config Class Initialized
INFO - 2023-06-07 09:05:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:05:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:05:35 --> Utf8 Class Initialized
INFO - 2023-06-07 09:05:35 --> URI Class Initialized
INFO - 2023-06-07 09:05:35 --> Router Class Initialized
INFO - 2023-06-07 09:05:35 --> Output Class Initialized
INFO - 2023-06-07 09:05:35 --> Security Class Initialized
DEBUG - 2023-06-07 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:05:35 --> Input Class Initialized
INFO - 2023-06-07 09:05:35 --> Language Class Initialized
INFO - 2023-06-07 09:05:35 --> Language Class Initialized
INFO - 2023-06-07 09:05:35 --> Config Class Initialized
INFO - 2023-06-07 09:05:35 --> Loader Class Initialized
INFO - 2023-06-07 09:05:35 --> Helper loaded: url_helper
INFO - 2023-06-07 09:05:35 --> Helper loaded: file_helper
INFO - 2023-06-07 09:05:35 --> Helper loaded: form_helper
INFO - 2023-06-07 09:05:35 --> Helper loaded: my_helper
INFO - 2023-06-07 09:05:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:05:35 --> Controller Class Initialized
DEBUG - 2023-06-07 09:05:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:05:35 --> Final output sent to browser
DEBUG - 2023-06-07 09:05:35 --> Total execution time: 0.9609
INFO - 2023-06-07 09:06:06 --> Config Class Initialized
INFO - 2023-06-07 09:06:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:06:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:06:06 --> Utf8 Class Initialized
INFO - 2023-06-07 09:06:06 --> URI Class Initialized
INFO - 2023-06-07 09:06:06 --> Router Class Initialized
INFO - 2023-06-07 09:06:06 --> Output Class Initialized
INFO - 2023-06-07 09:06:06 --> Security Class Initialized
DEBUG - 2023-06-07 09:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:06:06 --> Input Class Initialized
INFO - 2023-06-07 09:06:06 --> Language Class Initialized
INFO - 2023-06-07 09:06:06 --> Language Class Initialized
INFO - 2023-06-07 09:06:06 --> Config Class Initialized
INFO - 2023-06-07 09:06:06 --> Loader Class Initialized
INFO - 2023-06-07 09:06:06 --> Helper loaded: url_helper
INFO - 2023-06-07 09:06:06 --> Helper loaded: file_helper
INFO - 2023-06-07 09:06:06 --> Helper loaded: form_helper
INFO - 2023-06-07 09:06:06 --> Helper loaded: my_helper
INFO - 2023-06-07 09:06:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:06:06 --> Controller Class Initialized
DEBUG - 2023-06-07 09:06:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:06:07 --> Final output sent to browser
DEBUG - 2023-06-07 09:06:07 --> Total execution time: 0.9277
INFO - 2023-06-07 09:07:15 --> Config Class Initialized
INFO - 2023-06-07 09:07:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:07:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:07:15 --> Utf8 Class Initialized
INFO - 2023-06-07 09:07:15 --> URI Class Initialized
INFO - 2023-06-07 09:07:15 --> Router Class Initialized
INFO - 2023-06-07 09:07:15 --> Output Class Initialized
INFO - 2023-06-07 09:07:15 --> Security Class Initialized
DEBUG - 2023-06-07 09:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:07:15 --> Input Class Initialized
INFO - 2023-06-07 09:07:15 --> Language Class Initialized
INFO - 2023-06-07 09:07:15 --> Language Class Initialized
INFO - 2023-06-07 09:07:15 --> Config Class Initialized
INFO - 2023-06-07 09:07:15 --> Loader Class Initialized
INFO - 2023-06-07 09:07:15 --> Helper loaded: url_helper
INFO - 2023-06-07 09:07:15 --> Helper loaded: file_helper
INFO - 2023-06-07 09:07:15 --> Helper loaded: form_helper
INFO - 2023-06-07 09:07:15 --> Helper loaded: my_helper
INFO - 2023-06-07 09:07:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:07:15 --> Controller Class Initialized
DEBUG - 2023-06-07 09:07:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:07:16 --> Final output sent to browser
DEBUG - 2023-06-07 09:07:16 --> Total execution time: 0.9775
INFO - 2023-06-07 09:08:00 --> Config Class Initialized
INFO - 2023-06-07 09:08:00 --> Hooks Class Initialized
DEBUG - 2023-06-07 09:08:00 --> UTF-8 Support Enabled
INFO - 2023-06-07 09:08:00 --> Utf8 Class Initialized
INFO - 2023-06-07 09:08:00 --> URI Class Initialized
INFO - 2023-06-07 09:08:00 --> Router Class Initialized
INFO - 2023-06-07 09:08:00 --> Output Class Initialized
INFO - 2023-06-07 09:08:00 --> Security Class Initialized
DEBUG - 2023-06-07 09:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 09:08:00 --> Input Class Initialized
INFO - 2023-06-07 09:08:00 --> Language Class Initialized
INFO - 2023-06-07 09:08:00 --> Language Class Initialized
INFO - 2023-06-07 09:08:00 --> Config Class Initialized
INFO - 2023-06-07 09:08:00 --> Loader Class Initialized
INFO - 2023-06-07 09:08:00 --> Helper loaded: url_helper
INFO - 2023-06-07 09:08:00 --> Helper loaded: file_helper
INFO - 2023-06-07 09:08:00 --> Helper loaded: form_helper
INFO - 2023-06-07 09:08:00 --> Helper loaded: my_helper
INFO - 2023-06-07 09:08:00 --> Database Driver Class Initialized
DEBUG - 2023-06-07 09:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 09:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 09:08:00 --> Controller Class Initialized
DEBUG - 2023-06-07 09:08:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 09:08:01 --> Final output sent to browser
DEBUG - 2023-06-07 09:08:01 --> Total execution time: 0.9942
INFO - 2023-06-07 10:05:53 --> Config Class Initialized
INFO - 2023-06-07 10:05:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:05:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:05:53 --> Utf8 Class Initialized
INFO - 2023-06-07 10:05:53 --> URI Class Initialized
INFO - 2023-06-07 10:05:53 --> Router Class Initialized
INFO - 2023-06-07 10:05:53 --> Output Class Initialized
INFO - 2023-06-07 10:05:53 --> Security Class Initialized
DEBUG - 2023-06-07 10:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:05:53 --> Input Class Initialized
INFO - 2023-06-07 10:05:53 --> Language Class Initialized
INFO - 2023-06-07 10:05:53 --> Language Class Initialized
INFO - 2023-06-07 10:05:53 --> Config Class Initialized
INFO - 2023-06-07 10:05:53 --> Loader Class Initialized
INFO - 2023-06-07 10:05:53 --> Helper loaded: url_helper
INFO - 2023-06-07 10:05:53 --> Helper loaded: file_helper
INFO - 2023-06-07 10:05:53 --> Helper loaded: form_helper
INFO - 2023-06-07 10:05:53 --> Helper loaded: my_helper
INFO - 2023-06-07 10:05:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:05:53 --> Controller Class Initialized
DEBUG - 2023-06-07 10:05:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-07 10:05:54 --> Final output sent to browser
DEBUG - 2023-06-07 10:05:54 --> Total execution time: 0.9665
INFO - 2023-06-07 10:09:15 --> Config Class Initialized
INFO - 2023-06-07 10:09:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:15 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:15 --> URI Class Initialized
INFO - 2023-06-07 10:09:15 --> Router Class Initialized
INFO - 2023-06-07 10:09:15 --> Output Class Initialized
INFO - 2023-06-07 10:09:15 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:15 --> Input Class Initialized
INFO - 2023-06-07 10:09:15 --> Language Class Initialized
INFO - 2023-06-07 10:09:15 --> Language Class Initialized
INFO - 2023-06-07 10:09:15 --> Config Class Initialized
INFO - 2023-06-07 10:09:15 --> Loader Class Initialized
INFO - 2023-06-07 10:09:15 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:15 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:15 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:15 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:15 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-07 10:09:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:15 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:15 --> Total execution time: 0.1074
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:18 --> URI Class Initialized
INFO - 2023-06-07 10:09:18 --> Router Class Initialized
INFO - 2023-06-07 10:09:18 --> Output Class Initialized
INFO - 2023-06-07 10:09:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:18 --> Input Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Loader Class Initialized
INFO - 2023-06-07 10:09:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:18 --> Controller Class Initialized
INFO - 2023-06-07 10:09:18 --> Helper loaded: cookie_helper
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:18 --> URI Class Initialized
INFO - 2023-06-07 10:09:18 --> Router Class Initialized
INFO - 2023-06-07 10:09:18 --> Output Class Initialized
INFO - 2023-06-07 10:09:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:18 --> Input Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Loader Class Initialized
INFO - 2023-06-07 10:09:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:18 --> Controller Class Initialized
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:18 --> URI Class Initialized
INFO - 2023-06-07 10:09:18 --> Router Class Initialized
INFO - 2023-06-07 10:09:18 --> Output Class Initialized
INFO - 2023-06-07 10:09:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:18 --> Input Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Language Class Initialized
INFO - 2023-06-07 10:09:18 --> Config Class Initialized
INFO - 2023-06-07 10:09:18 --> Loader Class Initialized
INFO - 2023-06-07 10:09:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:19 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-07 10:09:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:19 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:19 --> Total execution time: 0.0724
INFO - 2023-06-07 10:09:24 --> Config Class Initialized
INFO - 2023-06-07 10:09:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:24 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:24 --> URI Class Initialized
INFO - 2023-06-07 10:09:24 --> Router Class Initialized
INFO - 2023-06-07 10:09:24 --> Output Class Initialized
INFO - 2023-06-07 10:09:24 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:24 --> Input Class Initialized
INFO - 2023-06-07 10:09:24 --> Language Class Initialized
INFO - 2023-06-07 10:09:24 --> Language Class Initialized
INFO - 2023-06-07 10:09:24 --> Config Class Initialized
INFO - 2023-06-07 10:09:24 --> Loader Class Initialized
INFO - 2023-06-07 10:09:24 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:24 --> Controller Class Initialized
INFO - 2023-06-07 10:09:24 --> Helper loaded: cookie_helper
INFO - 2023-06-07 10:09:24 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:24 --> Total execution time: 0.0416
INFO - 2023-06-07 10:09:24 --> Config Class Initialized
INFO - 2023-06-07 10:09:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:24 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:24 --> URI Class Initialized
INFO - 2023-06-07 10:09:24 --> Router Class Initialized
INFO - 2023-06-07 10:09:24 --> Output Class Initialized
INFO - 2023-06-07 10:09:24 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:24 --> Input Class Initialized
INFO - 2023-06-07 10:09:24 --> Language Class Initialized
INFO - 2023-06-07 10:09:24 --> Language Class Initialized
INFO - 2023-06-07 10:09:24 --> Config Class Initialized
INFO - 2023-06-07 10:09:24 --> Loader Class Initialized
INFO - 2023-06-07 10:09:24 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:24 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:24 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-07 10:09:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:24 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:24 --> Total execution time: 0.0719
INFO - 2023-06-07 10:09:28 --> Config Class Initialized
INFO - 2023-06-07 10:09:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:28 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:28 --> URI Class Initialized
DEBUG - 2023-06-07 10:09:28 --> No URI present. Default controller set.
INFO - 2023-06-07 10:09:28 --> Router Class Initialized
INFO - 2023-06-07 10:09:28 --> Output Class Initialized
INFO - 2023-06-07 10:09:28 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:28 --> Input Class Initialized
INFO - 2023-06-07 10:09:28 --> Language Class Initialized
INFO - 2023-06-07 10:09:28 --> Language Class Initialized
INFO - 2023-06-07 10:09:28 --> Config Class Initialized
INFO - 2023-06-07 10:09:28 --> Loader Class Initialized
INFO - 2023-06-07 10:09:28 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:28 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:28 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:28 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:28 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-07 10:09:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:28 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:28 --> Total execution time: 0.0283
INFO - 2023-06-07 10:09:33 --> Config Class Initialized
INFO - 2023-06-07 10:09:33 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:33 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:33 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:33 --> URI Class Initialized
INFO - 2023-06-07 10:09:33 --> Router Class Initialized
INFO - 2023-06-07 10:09:33 --> Output Class Initialized
INFO - 2023-06-07 10:09:33 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:33 --> Input Class Initialized
INFO - 2023-06-07 10:09:33 --> Language Class Initialized
INFO - 2023-06-07 10:09:33 --> Language Class Initialized
INFO - 2023-06-07 10:09:33 --> Config Class Initialized
INFO - 2023-06-07 10:09:33 --> Loader Class Initialized
INFO - 2023-06-07 10:09:33 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:33 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:33 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-06-07 10:09:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:33 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:33 --> Total execution time: 0.0555
INFO - 2023-06-07 10:09:33 --> Config Class Initialized
INFO - 2023-06-07 10:09:33 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:33 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:33 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:33 --> URI Class Initialized
INFO - 2023-06-07 10:09:33 --> Router Class Initialized
INFO - 2023-06-07 10:09:33 --> Output Class Initialized
INFO - 2023-06-07 10:09:33 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:33 --> Input Class Initialized
INFO - 2023-06-07 10:09:33 --> Language Class Initialized
INFO - 2023-06-07 10:09:33 --> Language Class Initialized
INFO - 2023-06-07 10:09:33 --> Config Class Initialized
INFO - 2023-06-07 10:09:33 --> Loader Class Initialized
INFO - 2023-06-07 10:09:33 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:33 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:33 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:33 --> Controller Class Initialized
INFO - 2023-06-07 10:09:36 --> Config Class Initialized
INFO - 2023-06-07 10:09:36 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:36 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:36 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:36 --> URI Class Initialized
INFO - 2023-06-07 10:09:36 --> Router Class Initialized
INFO - 2023-06-07 10:09:36 --> Output Class Initialized
INFO - 2023-06-07 10:09:36 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:36 --> Input Class Initialized
INFO - 2023-06-07 10:09:36 --> Language Class Initialized
INFO - 2023-06-07 10:09:36 --> Language Class Initialized
INFO - 2023-06-07 10:09:36 --> Config Class Initialized
INFO - 2023-06-07 10:09:36 --> Loader Class Initialized
INFO - 2023-06-07 10:09:36 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:36 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:36 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:36 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:36 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:36 --> Controller Class Initialized
INFO - 2023-06-07 10:09:36 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:36 --> Total execution time: 0.0425
INFO - 2023-06-07 10:09:40 --> Config Class Initialized
INFO - 2023-06-07 10:09:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:40 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:40 --> URI Class Initialized
INFO - 2023-06-07 10:09:40 --> Router Class Initialized
INFO - 2023-06-07 10:09:40 --> Output Class Initialized
INFO - 2023-06-07 10:09:40 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:40 --> Input Class Initialized
INFO - 2023-06-07 10:09:40 --> Language Class Initialized
INFO - 2023-06-07 10:09:40 --> Language Class Initialized
INFO - 2023-06-07 10:09:40 --> Config Class Initialized
INFO - 2023-06-07 10:09:40 --> Loader Class Initialized
INFO - 2023-06-07 10:09:40 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:40 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:40 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:40 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:40 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:40 --> Controller Class Initialized
INFO - 2023-06-07 10:09:40 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:40 --> Total execution time: 0.0417
INFO - 2023-06-07 10:09:46 --> Config Class Initialized
INFO - 2023-06-07 10:09:46 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:46 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:46 --> URI Class Initialized
INFO - 2023-06-07 10:09:46 --> Router Class Initialized
INFO - 2023-06-07 10:09:46 --> Output Class Initialized
INFO - 2023-06-07 10:09:46 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:46 --> Input Class Initialized
INFO - 2023-06-07 10:09:46 --> Language Class Initialized
INFO - 2023-06-07 10:09:46 --> Language Class Initialized
INFO - 2023-06-07 10:09:46 --> Config Class Initialized
INFO - 2023-06-07 10:09:46 --> Loader Class Initialized
INFO - 2023-06-07 10:09:46 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:46 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:46 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:09:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:46 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:46 --> Total execution time: 0.0723
INFO - 2023-06-07 10:09:46 --> Config Class Initialized
INFO - 2023-06-07 10:09:46 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:46 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:46 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:46 --> URI Class Initialized
INFO - 2023-06-07 10:09:46 --> Router Class Initialized
INFO - 2023-06-07 10:09:46 --> Output Class Initialized
INFO - 2023-06-07 10:09:46 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:46 --> Input Class Initialized
INFO - 2023-06-07 10:09:46 --> Language Class Initialized
INFO - 2023-06-07 10:09:46 --> Language Class Initialized
INFO - 2023-06-07 10:09:46 --> Config Class Initialized
INFO - 2023-06-07 10:09:46 --> Loader Class Initialized
INFO - 2023-06-07 10:09:46 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:46 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:46 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:46 --> Controller Class Initialized
INFO - 2023-06-07 10:09:49 --> Config Class Initialized
INFO - 2023-06-07 10:09:49 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:49 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:49 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:49 --> URI Class Initialized
INFO - 2023-06-07 10:09:49 --> Router Class Initialized
INFO - 2023-06-07 10:09:49 --> Output Class Initialized
INFO - 2023-06-07 10:09:49 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:49 --> Input Class Initialized
INFO - 2023-06-07 10:09:49 --> Language Class Initialized
INFO - 2023-06-07 10:09:49 --> Language Class Initialized
INFO - 2023-06-07 10:09:49 --> Config Class Initialized
INFO - 2023-06-07 10:09:49 --> Loader Class Initialized
INFO - 2023-06-07 10:09:49 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:49 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:49 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:49 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:49 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:49 --> Controller Class Initialized
ERROR - 2023-06-07 10:09:49 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:09:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:09:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:49 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:49 --> Total execution time: 0.0534
INFO - 2023-06-07 10:09:52 --> Config Class Initialized
INFO - 2023-06-07 10:09:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:52 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:52 --> URI Class Initialized
INFO - 2023-06-07 10:09:52 --> Router Class Initialized
INFO - 2023-06-07 10:09:52 --> Output Class Initialized
INFO - 2023-06-07 10:09:52 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:52 --> Input Class Initialized
INFO - 2023-06-07 10:09:52 --> Language Class Initialized
INFO - 2023-06-07 10:09:52 --> Language Class Initialized
INFO - 2023-06-07 10:09:52 --> Config Class Initialized
INFO - 2023-06-07 10:09:52 --> Loader Class Initialized
INFO - 2023-06-07 10:09:52 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:52 --> Controller Class Initialized
DEBUG - 2023-06-07 10:09:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:09:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:09:52 --> Final output sent to browser
DEBUG - 2023-06-07 10:09:52 --> Total execution time: 0.0406
INFO - 2023-06-07 10:09:52 --> Config Class Initialized
INFO - 2023-06-07 10:09:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:09:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:09:52 --> Utf8 Class Initialized
INFO - 2023-06-07 10:09:52 --> URI Class Initialized
INFO - 2023-06-07 10:09:52 --> Router Class Initialized
INFO - 2023-06-07 10:09:52 --> Output Class Initialized
INFO - 2023-06-07 10:09:52 --> Security Class Initialized
DEBUG - 2023-06-07 10:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:09:52 --> Input Class Initialized
INFO - 2023-06-07 10:09:52 --> Language Class Initialized
INFO - 2023-06-07 10:09:52 --> Language Class Initialized
INFO - 2023-06-07 10:09:52 --> Config Class Initialized
INFO - 2023-06-07 10:09:52 --> Loader Class Initialized
INFO - 2023-06-07 10:09:52 --> Helper loaded: url_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: file_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: form_helper
INFO - 2023-06-07 10:09:52 --> Helper loaded: my_helper
INFO - 2023-06-07 10:09:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:09:52 --> Controller Class Initialized
INFO - 2023-06-07 10:10:31 --> Config Class Initialized
INFO - 2023-06-07 10:10:31 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:10:31 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:10:31 --> Utf8 Class Initialized
INFO - 2023-06-07 10:10:31 --> URI Class Initialized
INFO - 2023-06-07 10:10:31 --> Router Class Initialized
INFO - 2023-06-07 10:10:31 --> Output Class Initialized
INFO - 2023-06-07 10:10:31 --> Security Class Initialized
DEBUG - 2023-06-07 10:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:10:31 --> Input Class Initialized
INFO - 2023-06-07 10:10:31 --> Language Class Initialized
INFO - 2023-06-07 10:10:31 --> Language Class Initialized
INFO - 2023-06-07 10:10:31 --> Config Class Initialized
INFO - 2023-06-07 10:10:31 --> Loader Class Initialized
INFO - 2023-06-07 10:10:31 --> Helper loaded: url_helper
INFO - 2023-06-07 10:10:31 --> Helper loaded: file_helper
INFO - 2023-06-07 10:10:31 --> Helper loaded: form_helper
INFO - 2023-06-07 10:10:31 --> Helper loaded: my_helper
INFO - 2023-06-07 10:10:31 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:10:31 --> Controller Class Initialized
ERROR - 2023-06-07 10:10:31 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:10:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:10:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:10:31 --> Final output sent to browser
DEBUG - 2023-06-07 10:10:31 --> Total execution time: 0.0514
INFO - 2023-06-07 10:10:42 --> Config Class Initialized
INFO - 2023-06-07 10:10:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:10:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:10:42 --> Utf8 Class Initialized
INFO - 2023-06-07 10:10:42 --> URI Class Initialized
INFO - 2023-06-07 10:10:42 --> Router Class Initialized
INFO - 2023-06-07 10:10:42 --> Output Class Initialized
INFO - 2023-06-07 10:10:42 --> Security Class Initialized
DEBUG - 2023-06-07 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:10:42 --> Input Class Initialized
INFO - 2023-06-07 10:10:42 --> Language Class Initialized
INFO - 2023-06-07 10:10:42 --> Language Class Initialized
INFO - 2023-06-07 10:10:42 --> Config Class Initialized
INFO - 2023-06-07 10:10:42 --> Loader Class Initialized
INFO - 2023-06-07 10:10:42 --> Helper loaded: url_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: file_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: form_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: my_helper
INFO - 2023-06-07 10:10:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:10:42 --> Controller Class Initialized
DEBUG - 2023-06-07 10:10:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:10:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:10:42 --> Final output sent to browser
DEBUG - 2023-06-07 10:10:42 --> Total execution time: 0.0280
INFO - 2023-06-07 10:10:42 --> Config Class Initialized
INFO - 2023-06-07 10:10:42 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:10:42 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:10:42 --> Utf8 Class Initialized
INFO - 2023-06-07 10:10:42 --> URI Class Initialized
INFO - 2023-06-07 10:10:42 --> Router Class Initialized
INFO - 2023-06-07 10:10:42 --> Output Class Initialized
INFO - 2023-06-07 10:10:42 --> Security Class Initialized
DEBUG - 2023-06-07 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:10:42 --> Input Class Initialized
INFO - 2023-06-07 10:10:42 --> Language Class Initialized
INFO - 2023-06-07 10:10:42 --> Language Class Initialized
INFO - 2023-06-07 10:10:42 --> Config Class Initialized
INFO - 2023-06-07 10:10:42 --> Loader Class Initialized
INFO - 2023-06-07 10:10:42 --> Helper loaded: url_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: file_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: form_helper
INFO - 2023-06-07 10:10:42 --> Helper loaded: my_helper
INFO - 2023-06-07 10:10:42 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:10:42 --> Controller Class Initialized
INFO - 2023-06-07 10:10:43 --> Config Class Initialized
INFO - 2023-06-07 10:10:43 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:10:43 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:10:43 --> Utf8 Class Initialized
INFO - 2023-06-07 10:10:43 --> URI Class Initialized
INFO - 2023-06-07 10:10:43 --> Router Class Initialized
INFO - 2023-06-07 10:10:43 --> Output Class Initialized
INFO - 2023-06-07 10:10:43 --> Security Class Initialized
DEBUG - 2023-06-07 10:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:10:43 --> Input Class Initialized
INFO - 2023-06-07 10:10:43 --> Language Class Initialized
INFO - 2023-06-07 10:10:43 --> Language Class Initialized
INFO - 2023-06-07 10:10:43 --> Config Class Initialized
INFO - 2023-06-07 10:10:43 --> Loader Class Initialized
INFO - 2023-06-07 10:10:43 --> Helper loaded: url_helper
INFO - 2023-06-07 10:10:43 --> Helper loaded: file_helper
INFO - 2023-06-07 10:10:43 --> Helper loaded: form_helper
INFO - 2023-06-07 10:10:43 --> Helper loaded: my_helper
INFO - 2023-06-07 10:10:43 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:10:43 --> Controller Class Initialized
ERROR - 2023-06-07 10:10:43 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:10:43 --> Final output sent to browser
DEBUG - 2023-06-07 10:10:43 --> Total execution time: 0.0488
INFO - 2023-06-07 10:10:52 --> Config Class Initialized
INFO - 2023-06-07 10:10:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:10:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:10:52 --> Utf8 Class Initialized
INFO - 2023-06-07 10:10:52 --> URI Class Initialized
INFO - 2023-06-07 10:10:52 --> Router Class Initialized
INFO - 2023-06-07 10:10:52 --> Output Class Initialized
INFO - 2023-06-07 10:10:52 --> Security Class Initialized
DEBUG - 2023-06-07 10:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:10:52 --> Input Class Initialized
INFO - 2023-06-07 10:10:52 --> Language Class Initialized
ERROR - 2023-06-07 10:10:52 --> 404 Page Not Found: /index
INFO - 2023-06-07 10:12:02 --> Config Class Initialized
INFO - 2023-06-07 10:12:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:02 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:02 --> URI Class Initialized
INFO - 2023-06-07 10:12:02 --> Router Class Initialized
INFO - 2023-06-07 10:12:02 --> Output Class Initialized
INFO - 2023-06-07 10:12:02 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:02 --> Input Class Initialized
INFO - 2023-06-07 10:12:02 --> Language Class Initialized
INFO - 2023-06-07 10:12:02 --> Language Class Initialized
INFO - 2023-06-07 10:12:02 --> Config Class Initialized
INFO - 2023-06-07 10:12:02 --> Loader Class Initialized
INFO - 2023-06-07 10:12:02 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:02 --> Controller Class Initialized
DEBUG - 2023-06-07 10:12:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:12:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:12:02 --> Final output sent to browser
DEBUG - 2023-06-07 10:12:02 --> Total execution time: 0.0304
INFO - 2023-06-07 10:12:02 --> Config Class Initialized
INFO - 2023-06-07 10:12:02 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:02 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:02 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:02 --> URI Class Initialized
INFO - 2023-06-07 10:12:02 --> Router Class Initialized
INFO - 2023-06-07 10:12:02 --> Output Class Initialized
INFO - 2023-06-07 10:12:02 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:02 --> Input Class Initialized
INFO - 2023-06-07 10:12:02 --> Language Class Initialized
INFO - 2023-06-07 10:12:02 --> Language Class Initialized
INFO - 2023-06-07 10:12:02 --> Config Class Initialized
INFO - 2023-06-07 10:12:02 --> Loader Class Initialized
INFO - 2023-06-07 10:12:02 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:02 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:02 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:02 --> Controller Class Initialized
INFO - 2023-06-07 10:12:05 --> Config Class Initialized
INFO - 2023-06-07 10:12:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:05 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:05 --> URI Class Initialized
INFO - 2023-06-07 10:12:05 --> Router Class Initialized
INFO - 2023-06-07 10:12:05 --> Output Class Initialized
INFO - 2023-06-07 10:12:05 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:05 --> Input Class Initialized
INFO - 2023-06-07 10:12:05 --> Language Class Initialized
INFO - 2023-06-07 10:12:05 --> Language Class Initialized
INFO - 2023-06-07 10:12:05 --> Config Class Initialized
INFO - 2023-06-07 10:12:05 --> Loader Class Initialized
INFO - 2023-06-07 10:12:05 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:05 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:05 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:05 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:05 --> Controller Class Initialized
ERROR - 2023-06-07 10:12:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:12:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:12:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:12:05 --> Final output sent to browser
DEBUG - 2023-06-07 10:12:05 --> Total execution time: 0.0486
INFO - 2023-06-07 10:12:07 --> Config Class Initialized
INFO - 2023-06-07 10:12:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:07 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:07 --> URI Class Initialized
INFO - 2023-06-07 10:12:07 --> Router Class Initialized
INFO - 2023-06-07 10:12:07 --> Output Class Initialized
INFO - 2023-06-07 10:12:07 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:07 --> Input Class Initialized
INFO - 2023-06-07 10:12:07 --> Language Class Initialized
INFO - 2023-06-07 10:12:07 --> Language Class Initialized
INFO - 2023-06-07 10:12:07 --> Config Class Initialized
INFO - 2023-06-07 10:12:07 --> Loader Class Initialized
INFO - 2023-06-07 10:12:07 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:07 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:07 --> Controller Class Initialized
DEBUG - 2023-06-07 10:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:12:07 --> Final output sent to browser
DEBUG - 2023-06-07 10:12:07 --> Total execution time: 0.0250
INFO - 2023-06-07 10:12:07 --> Config Class Initialized
INFO - 2023-06-07 10:12:07 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:07 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:07 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:07 --> URI Class Initialized
INFO - 2023-06-07 10:12:07 --> Router Class Initialized
INFO - 2023-06-07 10:12:07 --> Output Class Initialized
INFO - 2023-06-07 10:12:07 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:07 --> Input Class Initialized
INFO - 2023-06-07 10:12:07 --> Language Class Initialized
INFO - 2023-06-07 10:12:07 --> Language Class Initialized
INFO - 2023-06-07 10:12:07 --> Config Class Initialized
INFO - 2023-06-07 10:12:07 --> Loader Class Initialized
INFO - 2023-06-07 10:12:07 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:07 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:07 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:07 --> Controller Class Initialized
INFO - 2023-06-07 10:12:08 --> Config Class Initialized
INFO - 2023-06-07 10:12:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:08 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:08 --> URI Class Initialized
INFO - 2023-06-07 10:12:08 --> Router Class Initialized
INFO - 2023-06-07 10:12:08 --> Output Class Initialized
INFO - 2023-06-07 10:12:08 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:08 --> Input Class Initialized
INFO - 2023-06-07 10:12:08 --> Language Class Initialized
INFO - 2023-06-07 10:12:08 --> Language Class Initialized
INFO - 2023-06-07 10:12:08 --> Config Class Initialized
INFO - 2023-06-07 10:12:08 --> Loader Class Initialized
INFO - 2023-06-07 10:12:08 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:08 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:08 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:08 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:09 --> Controller Class Initialized
ERROR - 2023-06-07 10:12:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:12:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:12:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:12:09 --> Final output sent to browser
DEBUG - 2023-06-07 10:12:09 --> Total execution time: 0.0506
INFO - 2023-06-07 10:12:59 --> Config Class Initialized
INFO - 2023-06-07 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:59 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:59 --> URI Class Initialized
INFO - 2023-06-07 10:12:59 --> Router Class Initialized
INFO - 2023-06-07 10:12:59 --> Output Class Initialized
INFO - 2023-06-07 10:12:59 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:59 --> Input Class Initialized
INFO - 2023-06-07 10:12:59 --> Language Class Initialized
INFO - 2023-06-07 10:12:59 --> Language Class Initialized
INFO - 2023-06-07 10:12:59 --> Config Class Initialized
INFO - 2023-06-07 10:12:59 --> Loader Class Initialized
INFO - 2023-06-07 10:12:59 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:59 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:59 --> Controller Class Initialized
DEBUG - 2023-06-07 10:12:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-06-07 10:12:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:12:59 --> Final output sent to browser
DEBUG - 2023-06-07 10:12:59 --> Total execution time: 0.1162
INFO - 2023-06-07 10:12:59 --> Config Class Initialized
INFO - 2023-06-07 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:12:59 --> Utf8 Class Initialized
INFO - 2023-06-07 10:12:59 --> URI Class Initialized
INFO - 2023-06-07 10:12:59 --> Router Class Initialized
INFO - 2023-06-07 10:12:59 --> Output Class Initialized
INFO - 2023-06-07 10:12:59 --> Security Class Initialized
DEBUG - 2023-06-07 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:12:59 --> Input Class Initialized
INFO - 2023-06-07 10:12:59 --> Language Class Initialized
INFO - 2023-06-07 10:12:59 --> Language Class Initialized
INFO - 2023-06-07 10:12:59 --> Config Class Initialized
INFO - 2023-06-07 10:12:59 --> Loader Class Initialized
INFO - 2023-06-07 10:12:59 --> Helper loaded: url_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: file_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: form_helper
INFO - 2023-06-07 10:12:59 --> Helper loaded: my_helper
INFO - 2023-06-07 10:12:59 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:12:59 --> Controller Class Initialized
INFO - 2023-06-07 10:13:09 --> Config Class Initialized
INFO - 2023-06-07 10:13:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:09 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:09 --> URI Class Initialized
INFO - 2023-06-07 10:13:09 --> Router Class Initialized
INFO - 2023-06-07 10:13:09 --> Output Class Initialized
INFO - 2023-06-07 10:13:09 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:09 --> Input Class Initialized
INFO - 2023-06-07 10:13:09 --> Language Class Initialized
INFO - 2023-06-07 10:13:09 --> Language Class Initialized
INFO - 2023-06-07 10:13:09 --> Config Class Initialized
INFO - 2023-06-07 10:13:09 --> Loader Class Initialized
INFO - 2023-06-07 10:13:09 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:09 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:09 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:09 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:10 --> Controller Class Initialized
INFO - 2023-06-07 10:13:10 --> Upload Class Initialized
INFO - 2023-06-07 10:13:10 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-06-07 10:13:10 --> The upload path does not appear to be valid.
INFO - 2023-06-07 10:13:10 --> Config Class Initialized
INFO - 2023-06-07 10:13:10 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:10 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:10 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:10 --> URI Class Initialized
INFO - 2023-06-07 10:13:10 --> Router Class Initialized
INFO - 2023-06-07 10:13:10 --> Output Class Initialized
INFO - 2023-06-07 10:13:10 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:10 --> Input Class Initialized
INFO - 2023-06-07 10:13:10 --> Language Class Initialized
INFO - 2023-06-07 10:13:10 --> Language Class Initialized
INFO - 2023-06-07 10:13:10 --> Config Class Initialized
INFO - 2023-06-07 10:13:10 --> Loader Class Initialized
INFO - 2023-06-07 10:13:10 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:10 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:10 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:13:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:10 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:10 --> Total execution time: 0.0231
INFO - 2023-06-07 10:13:10 --> Config Class Initialized
INFO - 2023-06-07 10:13:10 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:10 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:10 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:10 --> URI Class Initialized
INFO - 2023-06-07 10:13:10 --> Router Class Initialized
INFO - 2023-06-07 10:13:10 --> Output Class Initialized
INFO - 2023-06-07 10:13:10 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:10 --> Input Class Initialized
INFO - 2023-06-07 10:13:10 --> Language Class Initialized
INFO - 2023-06-07 10:13:10 --> Language Class Initialized
INFO - 2023-06-07 10:13:10 --> Config Class Initialized
INFO - 2023-06-07 10:13:10 --> Loader Class Initialized
INFO - 2023-06-07 10:13:10 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:10 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:10 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:10 --> Controller Class Initialized
INFO - 2023-06-07 10:13:20 --> Config Class Initialized
INFO - 2023-06-07 10:13:20 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:20 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:20 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:20 --> URI Class Initialized
INFO - 2023-06-07 10:13:20 --> Router Class Initialized
INFO - 2023-06-07 10:13:20 --> Output Class Initialized
INFO - 2023-06-07 10:13:20 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:20 --> Input Class Initialized
INFO - 2023-06-07 10:13:20 --> Language Class Initialized
INFO - 2023-06-07 10:13:20 --> Language Class Initialized
INFO - 2023-06-07 10:13:20 --> Config Class Initialized
INFO - 2023-06-07 10:13:20 --> Loader Class Initialized
INFO - 2023-06-07 10:13:20 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:20 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:20 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:20 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:20 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:20 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-06-07 10:13:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:20 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:20 --> Total execution time: 0.0546
INFO - 2023-06-07 10:13:26 --> Config Class Initialized
INFO - 2023-06-07 10:13:26 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:26 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:26 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:26 --> URI Class Initialized
DEBUG - 2023-06-07 10:13:26 --> No URI present. Default controller set.
INFO - 2023-06-07 10:13:26 --> Router Class Initialized
INFO - 2023-06-07 10:13:26 --> Output Class Initialized
INFO - 2023-06-07 10:13:26 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:26 --> Input Class Initialized
INFO - 2023-06-07 10:13:26 --> Language Class Initialized
INFO - 2023-06-07 10:13:26 --> Language Class Initialized
INFO - 2023-06-07 10:13:26 --> Config Class Initialized
INFO - 2023-06-07 10:13:26 --> Loader Class Initialized
INFO - 2023-06-07 10:13:26 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:26 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:26 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:26 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:26 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:26 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-06-07 10:13:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:26 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:26 --> Total execution time: 0.0498
INFO - 2023-06-07 10:13:28 --> Config Class Initialized
INFO - 2023-06-07 10:13:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:28 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:28 --> URI Class Initialized
INFO - 2023-06-07 10:13:28 --> Router Class Initialized
INFO - 2023-06-07 10:13:28 --> Output Class Initialized
INFO - 2023-06-07 10:13:28 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:28 --> Input Class Initialized
INFO - 2023-06-07 10:13:28 --> Language Class Initialized
INFO - 2023-06-07 10:13:28 --> Language Class Initialized
INFO - 2023-06-07 10:13:28 --> Config Class Initialized
INFO - 2023-06-07 10:13:28 --> Loader Class Initialized
INFO - 2023-06-07 10:13:28 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:28 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-06-07 10:13:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:28 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:28 --> Total execution time: 0.0387
INFO - 2023-06-07 10:13:28 --> Config Class Initialized
INFO - 2023-06-07 10:13:28 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:28 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:28 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:28 --> URI Class Initialized
INFO - 2023-06-07 10:13:28 --> Router Class Initialized
INFO - 2023-06-07 10:13:28 --> Output Class Initialized
INFO - 2023-06-07 10:13:28 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:28 --> Input Class Initialized
INFO - 2023-06-07 10:13:28 --> Language Class Initialized
INFO - 2023-06-07 10:13:28 --> Language Class Initialized
INFO - 2023-06-07 10:13:28 --> Config Class Initialized
INFO - 2023-06-07 10:13:28 --> Loader Class Initialized
INFO - 2023-06-07 10:13:28 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:28 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:28 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:28 --> Controller Class Initialized
INFO - 2023-06-07 10:13:30 --> Config Class Initialized
INFO - 2023-06-07 10:13:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:30 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:30 --> URI Class Initialized
INFO - 2023-06-07 10:13:30 --> Router Class Initialized
INFO - 2023-06-07 10:13:30 --> Output Class Initialized
INFO - 2023-06-07 10:13:30 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:30 --> Input Class Initialized
INFO - 2023-06-07 10:13:30 --> Language Class Initialized
INFO - 2023-06-07 10:13:30 --> Language Class Initialized
INFO - 2023-06-07 10:13:30 --> Config Class Initialized
INFO - 2023-06-07 10:13:30 --> Loader Class Initialized
INFO - 2023-06-07 10:13:30 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:30 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:13:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:30 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:30 --> Total execution time: 0.0480
INFO - 2023-06-07 10:13:30 --> Config Class Initialized
INFO - 2023-06-07 10:13:30 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:30 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:30 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:30 --> URI Class Initialized
INFO - 2023-06-07 10:13:30 --> Router Class Initialized
INFO - 2023-06-07 10:13:30 --> Output Class Initialized
INFO - 2023-06-07 10:13:30 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:30 --> Input Class Initialized
INFO - 2023-06-07 10:13:30 --> Language Class Initialized
INFO - 2023-06-07 10:13:30 --> Language Class Initialized
INFO - 2023-06-07 10:13:30 --> Config Class Initialized
INFO - 2023-06-07 10:13:30 --> Loader Class Initialized
INFO - 2023-06-07 10:13:30 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:30 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:30 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:30 --> Controller Class Initialized
INFO - 2023-06-07 10:13:32 --> Config Class Initialized
INFO - 2023-06-07 10:13:32 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:32 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:32 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:32 --> URI Class Initialized
INFO - 2023-06-07 10:13:32 --> Router Class Initialized
INFO - 2023-06-07 10:13:32 --> Output Class Initialized
INFO - 2023-06-07 10:13:32 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:32 --> Input Class Initialized
INFO - 2023-06-07 10:13:32 --> Language Class Initialized
INFO - 2023-06-07 10:13:32 --> Language Class Initialized
INFO - 2023-06-07 10:13:32 --> Config Class Initialized
INFO - 2023-06-07 10:13:32 --> Loader Class Initialized
INFO - 2023-06-07 10:13:32 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:32 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:32 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:32 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:32 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:32 --> Controller Class Initialized
ERROR - 2023-06-07 10:13:32 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:13:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:13:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:32 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:32 --> Total execution time: 0.0495
INFO - 2023-06-07 10:13:37 --> Config Class Initialized
INFO - 2023-06-07 10:13:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:37 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:37 --> URI Class Initialized
INFO - 2023-06-07 10:13:37 --> Router Class Initialized
INFO - 2023-06-07 10:13:37 --> Output Class Initialized
INFO - 2023-06-07 10:13:37 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:37 --> Input Class Initialized
INFO - 2023-06-07 10:13:37 --> Language Class Initialized
INFO - 2023-06-07 10:13:37 --> Language Class Initialized
INFO - 2023-06-07 10:13:37 --> Config Class Initialized
INFO - 2023-06-07 10:13:37 --> Loader Class Initialized
INFO - 2023-06-07 10:13:37 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:37 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:13:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:37 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:37 --> Total execution time: 0.0404
INFO - 2023-06-07 10:13:37 --> Config Class Initialized
INFO - 2023-06-07 10:13:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:37 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:37 --> URI Class Initialized
INFO - 2023-06-07 10:13:37 --> Router Class Initialized
INFO - 2023-06-07 10:13:37 --> Output Class Initialized
INFO - 2023-06-07 10:13:37 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:37 --> Input Class Initialized
INFO - 2023-06-07 10:13:37 --> Language Class Initialized
INFO - 2023-06-07 10:13:37 --> Language Class Initialized
INFO - 2023-06-07 10:13:37 --> Config Class Initialized
INFO - 2023-06-07 10:13:37 --> Loader Class Initialized
INFO - 2023-06-07 10:13:37 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:37 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:37 --> Controller Class Initialized
INFO - 2023-06-07 10:13:40 --> Config Class Initialized
INFO - 2023-06-07 10:13:40 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:40 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:40 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:40 --> URI Class Initialized
INFO - 2023-06-07 10:13:40 --> Router Class Initialized
INFO - 2023-06-07 10:13:40 --> Output Class Initialized
INFO - 2023-06-07 10:13:40 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:41 --> Input Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Config Class Initialized
INFO - 2023-06-07 10:13:41 --> Loader Class Initialized
INFO - 2023-06-07 10:13:41 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:41 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:41 --> Controller Class Initialized
INFO - 2023-06-07 10:13:41 --> Config Class Initialized
INFO - 2023-06-07 10:13:41 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:41 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:41 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:41 --> URI Class Initialized
INFO - 2023-06-07 10:13:41 --> Router Class Initialized
INFO - 2023-06-07 10:13:41 --> Output Class Initialized
INFO - 2023-06-07 10:13:41 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:41 --> Input Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Config Class Initialized
INFO - 2023-06-07 10:13:41 --> Loader Class Initialized
INFO - 2023-06-07 10:13:41 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:41 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:41 --> Controller Class Initialized
DEBUG - 2023-06-07 10:13:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:13:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:13:41 --> Final output sent to browser
DEBUG - 2023-06-07 10:13:41 --> Total execution time: 0.0274
INFO - 2023-06-07 10:13:41 --> Config Class Initialized
INFO - 2023-06-07 10:13:41 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:13:41 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:13:41 --> Utf8 Class Initialized
INFO - 2023-06-07 10:13:41 --> URI Class Initialized
INFO - 2023-06-07 10:13:41 --> Router Class Initialized
INFO - 2023-06-07 10:13:41 --> Output Class Initialized
INFO - 2023-06-07 10:13:41 --> Security Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:13:41 --> Input Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Language Class Initialized
INFO - 2023-06-07 10:13:41 --> Config Class Initialized
INFO - 2023-06-07 10:13:41 --> Loader Class Initialized
INFO - 2023-06-07 10:13:41 --> Helper loaded: url_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: file_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: form_helper
INFO - 2023-06-07 10:13:41 --> Helper loaded: my_helper
INFO - 2023-06-07 10:13:41 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:13:41 --> Controller Class Initialized
INFO - 2023-06-07 10:14:27 --> Config Class Initialized
INFO - 2023-06-07 10:14:27 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:14:27 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:14:27 --> Utf8 Class Initialized
INFO - 2023-06-07 10:14:27 --> URI Class Initialized
INFO - 2023-06-07 10:14:27 --> Router Class Initialized
INFO - 2023-06-07 10:14:27 --> Output Class Initialized
INFO - 2023-06-07 10:14:27 --> Security Class Initialized
DEBUG - 2023-06-07 10:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:14:27 --> Input Class Initialized
INFO - 2023-06-07 10:14:27 --> Language Class Initialized
INFO - 2023-06-07 10:14:27 --> Language Class Initialized
INFO - 2023-06-07 10:14:27 --> Config Class Initialized
INFO - 2023-06-07 10:14:27 --> Loader Class Initialized
INFO - 2023-06-07 10:14:27 --> Helper loaded: url_helper
INFO - 2023-06-07 10:14:27 --> Helper loaded: file_helper
INFO - 2023-06-07 10:14:27 --> Helper loaded: form_helper
INFO - 2023-06-07 10:14:27 --> Helper loaded: my_helper
INFO - 2023-06-07 10:14:27 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:14:27 --> Controller Class Initialized
ERROR - 2023-06-07 10:14:27 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:14:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:14:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:14:27 --> Final output sent to browser
DEBUG - 2023-06-07 10:14:27 --> Total execution time: 0.0270
INFO - 2023-06-07 10:15:05 --> Config Class Initialized
INFO - 2023-06-07 10:15:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:05 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:05 --> URI Class Initialized
INFO - 2023-06-07 10:15:05 --> Router Class Initialized
INFO - 2023-06-07 10:15:05 --> Output Class Initialized
INFO - 2023-06-07 10:15:05 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:05 --> Input Class Initialized
INFO - 2023-06-07 10:15:05 --> Language Class Initialized
INFO - 2023-06-07 10:15:05 --> Language Class Initialized
INFO - 2023-06-07 10:15:05 --> Config Class Initialized
INFO - 2023-06-07 10:15:05 --> Loader Class Initialized
INFO - 2023-06-07 10:15:05 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:05 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:15:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:05 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:05 --> Total execution time: 0.0413
INFO - 2023-06-07 10:15:05 --> Config Class Initialized
INFO - 2023-06-07 10:15:05 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:05 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:05 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:05 --> URI Class Initialized
INFO - 2023-06-07 10:15:05 --> Router Class Initialized
INFO - 2023-06-07 10:15:05 --> Output Class Initialized
INFO - 2023-06-07 10:15:05 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:05 --> Input Class Initialized
INFO - 2023-06-07 10:15:05 --> Language Class Initialized
INFO - 2023-06-07 10:15:05 --> Language Class Initialized
INFO - 2023-06-07 10:15:05 --> Config Class Initialized
INFO - 2023-06-07 10:15:05 --> Loader Class Initialized
INFO - 2023-06-07 10:15:05 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:05 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:05 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:05 --> Controller Class Initialized
INFO - 2023-06-07 10:15:06 --> Config Class Initialized
INFO - 2023-06-07 10:15:06 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:06 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:06 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:06 --> URI Class Initialized
INFO - 2023-06-07 10:15:06 --> Router Class Initialized
INFO - 2023-06-07 10:15:06 --> Output Class Initialized
INFO - 2023-06-07 10:15:06 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:06 --> Input Class Initialized
INFO - 2023-06-07 10:15:06 --> Language Class Initialized
INFO - 2023-06-07 10:15:06 --> Language Class Initialized
INFO - 2023-06-07 10:15:06 --> Config Class Initialized
INFO - 2023-06-07 10:15:06 --> Loader Class Initialized
INFO - 2023-06-07 10:15:06 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:06 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:06 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:06 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:06 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:06 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:15:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:06 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:06 --> Total execution time: 0.0594
INFO - 2023-06-07 10:15:10 --> Config Class Initialized
INFO - 2023-06-07 10:15:10 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:10 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:10 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:10 --> URI Class Initialized
INFO - 2023-06-07 10:15:10 --> Router Class Initialized
INFO - 2023-06-07 10:15:10 --> Output Class Initialized
INFO - 2023-06-07 10:15:10 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:10 --> Input Class Initialized
INFO - 2023-06-07 10:15:10 --> Language Class Initialized
INFO - 2023-06-07 10:15:10 --> Language Class Initialized
INFO - 2023-06-07 10:15:10 --> Config Class Initialized
INFO - 2023-06-07 10:15:10 --> Loader Class Initialized
INFO - 2023-06-07 10:15:10 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:10 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:10 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:10 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:10 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:10 --> Controller Class Initialized
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-06-07 10:15:11 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-06-07 10:15:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\helpers\url_helper.php 564
INFO - 2023-06-07 10:15:50 --> Config Class Initialized
INFO - 2023-06-07 10:15:50 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:50 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:50 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:50 --> URI Class Initialized
INFO - 2023-06-07 10:15:50 --> Router Class Initialized
INFO - 2023-06-07 10:15:50 --> Output Class Initialized
INFO - 2023-06-07 10:15:50 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:50 --> Input Class Initialized
INFO - 2023-06-07 10:15:50 --> Language Class Initialized
INFO - 2023-06-07 10:15:51 --> Language Class Initialized
INFO - 2023-06-07 10:15:51 --> Config Class Initialized
INFO - 2023-06-07 10:15:51 --> Loader Class Initialized
INFO - 2023-06-07 10:15:51 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:51 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:51 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:51 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:51 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:51 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:15:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:51 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:51 --> Total execution time: 0.0504
INFO - 2023-06-07 10:15:53 --> Config Class Initialized
INFO - 2023-06-07 10:15:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:53 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:53 --> URI Class Initialized
INFO - 2023-06-07 10:15:53 --> Router Class Initialized
INFO - 2023-06-07 10:15:53 --> Output Class Initialized
INFO - 2023-06-07 10:15:53 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:53 --> Input Class Initialized
INFO - 2023-06-07 10:15:53 --> Language Class Initialized
INFO - 2023-06-07 10:15:53 --> Language Class Initialized
INFO - 2023-06-07 10:15:53 --> Config Class Initialized
INFO - 2023-06-07 10:15:53 --> Loader Class Initialized
INFO - 2023-06-07 10:15:53 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:53 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:15:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:53 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:53 --> Total execution time: 0.0390
INFO - 2023-06-07 10:15:53 --> Config Class Initialized
INFO - 2023-06-07 10:15:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:53 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:53 --> URI Class Initialized
INFO - 2023-06-07 10:15:53 --> Router Class Initialized
INFO - 2023-06-07 10:15:53 --> Output Class Initialized
INFO - 2023-06-07 10:15:53 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:53 --> Input Class Initialized
INFO - 2023-06-07 10:15:53 --> Language Class Initialized
INFO - 2023-06-07 10:15:53 --> Language Class Initialized
INFO - 2023-06-07 10:15:53 --> Config Class Initialized
INFO - 2023-06-07 10:15:53 --> Loader Class Initialized
INFO - 2023-06-07 10:15:53 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:53 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:53 --> Controller Class Initialized
INFO - 2023-06-07 10:15:55 --> Config Class Initialized
INFO - 2023-06-07 10:15:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:55 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:55 --> URI Class Initialized
INFO - 2023-06-07 10:15:55 --> Router Class Initialized
INFO - 2023-06-07 10:15:55 --> Output Class Initialized
INFO - 2023-06-07 10:15:55 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:55 --> Input Class Initialized
INFO - 2023-06-07 10:15:55 --> Language Class Initialized
INFO - 2023-06-07 10:15:55 --> Language Class Initialized
INFO - 2023-06-07 10:15:55 --> Config Class Initialized
INFO - 2023-06-07 10:15:55 --> Loader Class Initialized
INFO - 2023-06-07 10:15:55 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:55 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:55 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:55 --> Total execution time: 0.0247
INFO - 2023-06-07 10:15:55 --> Config Class Initialized
INFO - 2023-06-07 10:15:55 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:55 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:55 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:55 --> URI Class Initialized
INFO - 2023-06-07 10:15:55 --> Router Class Initialized
INFO - 2023-06-07 10:15:55 --> Output Class Initialized
INFO - 2023-06-07 10:15:55 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:55 --> Input Class Initialized
INFO - 2023-06-07 10:15:55 --> Language Class Initialized
INFO - 2023-06-07 10:15:55 --> Language Class Initialized
INFO - 2023-06-07 10:15:55 --> Config Class Initialized
INFO - 2023-06-07 10:15:55 --> Loader Class Initialized
INFO - 2023-06-07 10:15:55 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:55 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:55 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:55 --> Controller Class Initialized
INFO - 2023-06-07 10:15:56 --> Config Class Initialized
INFO - 2023-06-07 10:15:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:56 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:56 --> URI Class Initialized
INFO - 2023-06-07 10:15:56 --> Router Class Initialized
INFO - 2023-06-07 10:15:56 --> Output Class Initialized
INFO - 2023-06-07 10:15:56 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:56 --> Input Class Initialized
INFO - 2023-06-07 10:15:56 --> Language Class Initialized
INFO - 2023-06-07 10:15:56 --> Language Class Initialized
INFO - 2023-06-07 10:15:56 --> Config Class Initialized
INFO - 2023-06-07 10:15:56 --> Loader Class Initialized
INFO - 2023-06-07 10:15:56 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:56 --> Controller Class Initialized
DEBUG - 2023-06-07 10:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:56 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:56 --> Total execution time: 0.0265
INFO - 2023-06-07 10:15:56 --> Config Class Initialized
INFO - 2023-06-07 10:15:56 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:56 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:56 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:56 --> URI Class Initialized
INFO - 2023-06-07 10:15:56 --> Router Class Initialized
INFO - 2023-06-07 10:15:56 --> Output Class Initialized
INFO - 2023-06-07 10:15:56 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:56 --> Input Class Initialized
INFO - 2023-06-07 10:15:56 --> Language Class Initialized
INFO - 2023-06-07 10:15:56 --> Language Class Initialized
INFO - 2023-06-07 10:15:56 --> Config Class Initialized
INFO - 2023-06-07 10:15:56 --> Loader Class Initialized
INFO - 2023-06-07 10:15:56 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:56 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:56 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:56 --> Controller Class Initialized
INFO - 2023-06-07 10:15:58 --> Config Class Initialized
INFO - 2023-06-07 10:15:58 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:15:58 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:15:58 --> Utf8 Class Initialized
INFO - 2023-06-07 10:15:58 --> URI Class Initialized
INFO - 2023-06-07 10:15:58 --> Router Class Initialized
INFO - 2023-06-07 10:15:58 --> Output Class Initialized
INFO - 2023-06-07 10:15:58 --> Security Class Initialized
DEBUG - 2023-06-07 10:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:15:58 --> Input Class Initialized
INFO - 2023-06-07 10:15:58 --> Language Class Initialized
INFO - 2023-06-07 10:15:58 --> Language Class Initialized
INFO - 2023-06-07 10:15:58 --> Config Class Initialized
INFO - 2023-06-07 10:15:58 --> Loader Class Initialized
INFO - 2023-06-07 10:15:58 --> Helper loaded: url_helper
INFO - 2023-06-07 10:15:58 --> Helper loaded: file_helper
INFO - 2023-06-07 10:15:58 --> Helper loaded: form_helper
INFO - 2023-06-07 10:15:58 --> Helper loaded: my_helper
INFO - 2023-06-07 10:15:58 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:15:58 --> Controller Class Initialized
ERROR - 2023-06-07 10:15:58 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:15:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:15:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:15:58 --> Final output sent to browser
DEBUG - 2023-06-07 10:15:58 --> Total execution time: 0.0436
INFO - 2023-06-07 10:16:13 --> Config Class Initialized
INFO - 2023-06-07 10:16:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:16:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:16:13 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:13 --> URI Class Initialized
INFO - 2023-06-07 10:16:13 --> Router Class Initialized
INFO - 2023-06-07 10:16:13 --> Output Class Initialized
INFO - 2023-06-07 10:16:13 --> Security Class Initialized
DEBUG - 2023-06-07 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:16:13 --> Input Class Initialized
INFO - 2023-06-07 10:16:13 --> Language Class Initialized
INFO - 2023-06-07 10:16:13 --> Language Class Initialized
INFO - 2023-06-07 10:16:13 --> Config Class Initialized
INFO - 2023-06-07 10:16:13 --> Loader Class Initialized
INFO - 2023-06-07 10:16:13 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: file_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: my_helper
INFO - 2023-06-07 10:16:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:13 --> Controller Class Initialized
DEBUG - 2023-06-07 10:16:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:16:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:16:13 --> Final output sent to browser
DEBUG - 2023-06-07 10:16:13 --> Total execution time: 0.0395
INFO - 2023-06-07 10:16:13 --> Config Class Initialized
INFO - 2023-06-07 10:16:13 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:16:13 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:16:13 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:13 --> URI Class Initialized
INFO - 2023-06-07 10:16:13 --> Router Class Initialized
INFO - 2023-06-07 10:16:13 --> Output Class Initialized
INFO - 2023-06-07 10:16:13 --> Security Class Initialized
DEBUG - 2023-06-07 10:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:16:13 --> Input Class Initialized
INFO - 2023-06-07 10:16:13 --> Language Class Initialized
INFO - 2023-06-07 10:16:13 --> Language Class Initialized
INFO - 2023-06-07 10:16:13 --> Config Class Initialized
INFO - 2023-06-07 10:16:13 --> Loader Class Initialized
INFO - 2023-06-07 10:16:13 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: file_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:13 --> Helper loaded: my_helper
INFO - 2023-06-07 10:16:13 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:13 --> Controller Class Initialized
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:16:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:16:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:18 --> URI Class Initialized
INFO - 2023-06-07 10:16:18 --> Router Class Initialized
INFO - 2023-06-07 10:16:18 --> Output Class Initialized
INFO - 2023-06-07 10:16:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:16:18 --> Input Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Loader Class Initialized
INFO - 2023-06-07 10:16:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:16:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:18 --> Controller Class Initialized
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:16:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:16:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:18 --> URI Class Initialized
INFO - 2023-06-07 10:16:18 --> Router Class Initialized
INFO - 2023-06-07 10:16:18 --> Output Class Initialized
INFO - 2023-06-07 10:16:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:16:18 --> Input Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Loader Class Initialized
INFO - 2023-06-07 10:16:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:16:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:18 --> Controller Class Initialized
DEBUG - 2023-06-07 10:16:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:16:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:16:18 --> Final output sent to browser
DEBUG - 2023-06-07 10:16:18 --> Total execution time: 0.0323
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:16:18 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:16:18 --> Utf8 Class Initialized
INFO - 2023-06-07 10:16:18 --> URI Class Initialized
INFO - 2023-06-07 10:16:18 --> Router Class Initialized
INFO - 2023-06-07 10:16:18 --> Output Class Initialized
INFO - 2023-06-07 10:16:18 --> Security Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:16:18 --> Input Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Language Class Initialized
INFO - 2023-06-07 10:16:18 --> Config Class Initialized
INFO - 2023-06-07 10:16:18 --> Loader Class Initialized
INFO - 2023-06-07 10:16:18 --> Helper loaded: url_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: file_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: form_helper
INFO - 2023-06-07 10:16:18 --> Helper loaded: my_helper
INFO - 2023-06-07 10:16:18 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:16:18 --> Controller Class Initialized
INFO - 2023-06-07 10:26:52 --> Config Class Initialized
INFO - 2023-06-07 10:26:52 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:26:52 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:26:52 --> Utf8 Class Initialized
INFO - 2023-06-07 10:26:52 --> URI Class Initialized
INFO - 2023-06-07 10:26:52 --> Router Class Initialized
INFO - 2023-06-07 10:26:52 --> Output Class Initialized
INFO - 2023-06-07 10:26:52 --> Security Class Initialized
DEBUG - 2023-06-07 10:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:26:52 --> Input Class Initialized
INFO - 2023-06-07 10:26:52 --> Language Class Initialized
INFO - 2023-06-07 10:26:52 --> Language Class Initialized
INFO - 2023-06-07 10:26:52 --> Config Class Initialized
INFO - 2023-06-07 10:26:52 --> Loader Class Initialized
INFO - 2023-06-07 10:26:52 --> Helper loaded: url_helper
INFO - 2023-06-07 10:26:52 --> Helper loaded: file_helper
INFO - 2023-06-07 10:26:52 --> Helper loaded: form_helper
INFO - 2023-06-07 10:26:52 --> Helper loaded: my_helper
INFO - 2023-06-07 10:26:52 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:26:52 --> Controller Class Initialized
DEBUG - 2023-06-07 10:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:26:52 --> Final output sent to browser
DEBUG - 2023-06-07 10:26:52 --> Total execution time: 0.0278
INFO - 2023-06-07 10:26:53 --> Config Class Initialized
INFO - 2023-06-07 10:26:53 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:26:53 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:26:53 --> Utf8 Class Initialized
INFO - 2023-06-07 10:26:53 --> URI Class Initialized
INFO - 2023-06-07 10:26:53 --> Router Class Initialized
INFO - 2023-06-07 10:26:53 --> Output Class Initialized
INFO - 2023-06-07 10:26:53 --> Security Class Initialized
DEBUG - 2023-06-07 10:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:26:53 --> Input Class Initialized
INFO - 2023-06-07 10:26:53 --> Language Class Initialized
INFO - 2023-06-07 10:26:53 --> Language Class Initialized
INFO - 2023-06-07 10:26:53 --> Config Class Initialized
INFO - 2023-06-07 10:26:53 --> Loader Class Initialized
INFO - 2023-06-07 10:26:53 --> Helper loaded: url_helper
INFO - 2023-06-07 10:26:53 --> Helper loaded: file_helper
INFO - 2023-06-07 10:26:53 --> Helper loaded: form_helper
INFO - 2023-06-07 10:26:53 --> Helper loaded: my_helper
INFO - 2023-06-07 10:26:53 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:26:53 --> Controller Class Initialized
INFO - 2023-06-07 10:27:09 --> Config Class Initialized
INFO - 2023-06-07 10:27:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:09 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:09 --> URI Class Initialized
INFO - 2023-06-07 10:27:09 --> Router Class Initialized
INFO - 2023-06-07 10:27:09 --> Output Class Initialized
INFO - 2023-06-07 10:27:09 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:09 --> Input Class Initialized
INFO - 2023-06-07 10:27:09 --> Language Class Initialized
INFO - 2023-06-07 10:27:09 --> Language Class Initialized
INFO - 2023-06-07 10:27:09 --> Config Class Initialized
INFO - 2023-06-07 10:27:09 --> Loader Class Initialized
INFO - 2023-06-07 10:27:09 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:09 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:09 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:09 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:09 --> Controller Class Initialized
DEBUG - 2023-06-07 10:27:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:27:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:27:09 --> Final output sent to browser
DEBUG - 2023-06-07 10:27:09 --> Total execution time: 0.0294
INFO - 2023-06-07 10:27:12 --> Config Class Initialized
INFO - 2023-06-07 10:27:12 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:12 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:12 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:12 --> URI Class Initialized
INFO - 2023-06-07 10:27:12 --> Router Class Initialized
INFO - 2023-06-07 10:27:12 --> Output Class Initialized
INFO - 2023-06-07 10:27:12 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:12 --> Input Class Initialized
INFO - 2023-06-07 10:27:12 --> Language Class Initialized
INFO - 2023-06-07 10:27:12 --> Language Class Initialized
INFO - 2023-06-07 10:27:12 --> Config Class Initialized
INFO - 2023-06-07 10:27:12 --> Loader Class Initialized
INFO - 2023-06-07 10:27:12 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:12 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:12 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:12 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:12 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:13 --> Controller Class Initialized
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1862
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 1921
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2060
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2085
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2095
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2113
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2126
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2130
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2212
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2336
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2352
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2368
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2384
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2400
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2416
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2432
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2448
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2490
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2557
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2565
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2744
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2828
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2897
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 2921
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3820
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3844
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3845
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3846
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3860
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3861
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3862
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3866
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3868
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3869
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3870
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3874
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3876
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3877
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3878
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 3946
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4013
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4016
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4394
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4546
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 4548
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6093
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6096
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6503
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6506
ERROR - 2023-06-07 10:27:13 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\myraportk13\application\third_party\PHP_Excel\PHPExcel\Reader\Excel5.php 6509
ERROR - 2023-06-07 10:27:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\helpers\url_helper.php 564
INFO - 2023-06-07 10:27:24 --> Config Class Initialized
INFO - 2023-06-07 10:27:24 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:24 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:24 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:24 --> URI Class Initialized
INFO - 2023-06-07 10:27:24 --> Router Class Initialized
INFO - 2023-06-07 10:27:24 --> Output Class Initialized
INFO - 2023-06-07 10:27:24 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:24 --> Input Class Initialized
INFO - 2023-06-07 10:27:24 --> Language Class Initialized
INFO - 2023-06-07 10:27:24 --> Language Class Initialized
INFO - 2023-06-07 10:27:24 --> Config Class Initialized
INFO - 2023-06-07 10:27:24 --> Loader Class Initialized
INFO - 2023-06-07 10:27:24 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:24 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:24 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:24 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:24 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:24 --> Controller Class Initialized
DEBUG - 2023-06-07 10:27:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:27:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:27:24 --> Final output sent to browser
DEBUG - 2023-06-07 10:27:24 --> Total execution time: 0.0405
INFO - 2023-06-07 10:27:29 --> Config Class Initialized
INFO - 2023-06-07 10:27:29 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:29 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:29 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:29 --> URI Class Initialized
INFO - 2023-06-07 10:27:29 --> Router Class Initialized
INFO - 2023-06-07 10:27:29 --> Output Class Initialized
INFO - 2023-06-07 10:27:29 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:29 --> Input Class Initialized
INFO - 2023-06-07 10:27:29 --> Language Class Initialized
INFO - 2023-06-07 10:27:29 --> Language Class Initialized
INFO - 2023-06-07 10:27:29 --> Config Class Initialized
INFO - 2023-06-07 10:27:29 --> Loader Class Initialized
INFO - 2023-06-07 10:27:29 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:29 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:29 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:29 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:29 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:29 --> Controller Class Initialized
DEBUG - 2023-06-07 10:27:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:27:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:27:29 --> Final output sent to browser
DEBUG - 2023-06-07 10:27:29 --> Total execution time: 0.0262
INFO - 2023-06-07 10:27:35 --> Config Class Initialized
INFO - 2023-06-07 10:27:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:35 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:35 --> URI Class Initialized
INFO - 2023-06-07 10:27:35 --> Router Class Initialized
INFO - 2023-06-07 10:27:35 --> Output Class Initialized
INFO - 2023-06-07 10:27:35 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:35 --> Input Class Initialized
INFO - 2023-06-07 10:27:35 --> Language Class Initialized
INFO - 2023-06-07 10:27:35 --> Language Class Initialized
INFO - 2023-06-07 10:27:35 --> Config Class Initialized
INFO - 2023-06-07 10:27:35 --> Loader Class Initialized
INFO - 2023-06-07 10:27:35 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:35 --> Controller Class Initialized
DEBUG - 2023-06-07 10:27:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:27:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:27:35 --> Final output sent to browser
DEBUG - 2023-06-07 10:27:35 --> Total execution time: 0.0264
INFO - 2023-06-07 10:27:35 --> Config Class Initialized
INFO - 2023-06-07 10:27:35 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:35 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:35 --> URI Class Initialized
INFO - 2023-06-07 10:27:35 --> Router Class Initialized
INFO - 2023-06-07 10:27:35 --> Output Class Initialized
INFO - 2023-06-07 10:27:35 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:35 --> Input Class Initialized
INFO - 2023-06-07 10:27:35 --> Language Class Initialized
INFO - 2023-06-07 10:27:35 --> Language Class Initialized
INFO - 2023-06-07 10:27:35 --> Config Class Initialized
INFO - 2023-06-07 10:27:35 --> Loader Class Initialized
INFO - 2023-06-07 10:27:35 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:35 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:35 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:35 --> Controller Class Initialized
INFO - 2023-06-07 10:27:37 --> Config Class Initialized
INFO - 2023-06-07 10:27:37 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:27:37 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:27:37 --> Utf8 Class Initialized
INFO - 2023-06-07 10:27:37 --> URI Class Initialized
INFO - 2023-06-07 10:27:37 --> Router Class Initialized
INFO - 2023-06-07 10:27:37 --> Output Class Initialized
INFO - 2023-06-07 10:27:37 --> Security Class Initialized
DEBUG - 2023-06-07 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:27:37 --> Input Class Initialized
INFO - 2023-06-07 10:27:37 --> Language Class Initialized
INFO - 2023-06-07 10:27:37 --> Language Class Initialized
INFO - 2023-06-07 10:27:37 --> Config Class Initialized
INFO - 2023-06-07 10:27:37 --> Loader Class Initialized
INFO - 2023-06-07 10:27:37 --> Helper loaded: url_helper
INFO - 2023-06-07 10:27:37 --> Helper loaded: file_helper
INFO - 2023-06-07 10:27:37 --> Helper loaded: form_helper
INFO - 2023-06-07 10:27:37 --> Helper loaded: my_helper
INFO - 2023-06-07 10:27:37 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:27:37 --> Controller Class Initialized
ERROR - 2023-06-07 10:27:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-06-07 10:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-06-07 10:27:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:27:37 --> Final output sent to browser
DEBUG - 2023-06-07 10:27:37 --> Total execution time: 0.0294
INFO - 2023-06-07 10:28:15 --> Config Class Initialized
INFO - 2023-06-07 10:28:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:28:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:28:15 --> Utf8 Class Initialized
INFO - 2023-06-07 10:28:15 --> URI Class Initialized
INFO - 2023-06-07 10:28:15 --> Router Class Initialized
INFO - 2023-06-07 10:28:15 --> Output Class Initialized
INFO - 2023-06-07 10:28:15 --> Security Class Initialized
DEBUG - 2023-06-07 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:28:15 --> Input Class Initialized
INFO - 2023-06-07 10:28:15 --> Language Class Initialized
INFO - 2023-06-07 10:28:15 --> Language Class Initialized
INFO - 2023-06-07 10:28:15 --> Config Class Initialized
INFO - 2023-06-07 10:28:15 --> Loader Class Initialized
INFO - 2023-06-07 10:28:15 --> Helper loaded: url_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: file_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: form_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: my_helper
INFO - 2023-06-07 10:28:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:28:15 --> Controller Class Initialized
DEBUG - 2023-06-07 10:28:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-06-07 10:28:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:28:15 --> Final output sent to browser
DEBUG - 2023-06-07 10:28:15 --> Total execution time: 0.0262
INFO - 2023-06-07 10:28:15 --> Config Class Initialized
INFO - 2023-06-07 10:28:15 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:28:15 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:28:15 --> Utf8 Class Initialized
INFO - 2023-06-07 10:28:15 --> URI Class Initialized
INFO - 2023-06-07 10:28:15 --> Router Class Initialized
INFO - 2023-06-07 10:28:15 --> Output Class Initialized
INFO - 2023-06-07 10:28:15 --> Security Class Initialized
DEBUG - 2023-06-07 10:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:28:15 --> Input Class Initialized
INFO - 2023-06-07 10:28:15 --> Language Class Initialized
INFO - 2023-06-07 10:28:15 --> Language Class Initialized
INFO - 2023-06-07 10:28:15 --> Config Class Initialized
INFO - 2023-06-07 10:28:15 --> Loader Class Initialized
INFO - 2023-06-07 10:28:15 --> Helper loaded: url_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: file_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: form_helper
INFO - 2023-06-07 10:28:15 --> Helper loaded: my_helper
INFO - 2023-06-07 10:28:15 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:28:15 --> Controller Class Initialized
INFO - 2023-06-07 10:28:16 --> Config Class Initialized
INFO - 2023-06-07 10:28:16 --> Hooks Class Initialized
DEBUG - 2023-06-07 10:28:16 --> UTF-8 Support Enabled
INFO - 2023-06-07 10:28:16 --> Utf8 Class Initialized
INFO - 2023-06-07 10:28:16 --> URI Class Initialized
INFO - 2023-06-07 10:28:16 --> Router Class Initialized
INFO - 2023-06-07 10:28:16 --> Output Class Initialized
INFO - 2023-06-07 10:28:16 --> Security Class Initialized
DEBUG - 2023-06-07 10:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 10:28:16 --> Input Class Initialized
INFO - 2023-06-07 10:28:16 --> Language Class Initialized
INFO - 2023-06-07 10:28:16 --> Language Class Initialized
INFO - 2023-06-07 10:28:16 --> Config Class Initialized
INFO - 2023-06-07 10:28:16 --> Loader Class Initialized
INFO - 2023-06-07 10:28:16 --> Helper loaded: url_helper
INFO - 2023-06-07 10:28:16 --> Helper loaded: file_helper
INFO - 2023-06-07 10:28:16 --> Helper loaded: form_helper
INFO - 2023-06-07 10:28:16 --> Helper loaded: my_helper
INFO - 2023-06-07 10:28:16 --> Database Driver Class Initialized
DEBUG - 2023-06-07 10:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 10:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 10:28:16 --> Controller Class Initialized
DEBUG - 2023-06-07 10:28:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 10:28:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 10:28:16 --> Final output sent to browser
DEBUG - 2023-06-07 10:28:16 --> Total execution time: 0.0477
INFO - 2023-06-07 12:02:08 --> Config Class Initialized
INFO - 2023-06-07 12:02:08 --> Hooks Class Initialized
DEBUG - 2023-06-07 12:02:08 --> UTF-8 Support Enabled
INFO - 2023-06-07 12:02:08 --> Utf8 Class Initialized
INFO - 2023-06-07 12:02:08 --> URI Class Initialized
INFO - 2023-06-07 12:02:08 --> Router Class Initialized
INFO - 2023-06-07 12:02:08 --> Output Class Initialized
INFO - 2023-06-07 12:02:08 --> Security Class Initialized
DEBUG - 2023-06-07 12:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 12:02:08 --> Input Class Initialized
INFO - 2023-06-07 12:02:08 --> Language Class Initialized
INFO - 2023-06-07 12:02:08 --> Language Class Initialized
INFO - 2023-06-07 12:02:08 --> Config Class Initialized
INFO - 2023-06-07 12:02:08 --> Loader Class Initialized
INFO - 2023-06-07 12:02:08 --> Helper loaded: url_helper
INFO - 2023-06-07 12:02:08 --> Helper loaded: file_helper
INFO - 2023-06-07 12:02:08 --> Helper loaded: form_helper
INFO - 2023-06-07 12:02:08 --> Helper loaded: my_helper
INFO - 2023-06-07 12:02:08 --> Database Driver Class Initialized
DEBUG - 2023-06-07 12:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 12:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 12:02:08 --> Controller Class Initialized
DEBUG - 2023-06-07 12:02:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-06-07 12:02:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 12:02:08 --> Final output sent to browser
DEBUG - 2023-06-07 12:02:08 --> Total execution time: 0.1055
INFO - 2023-06-07 12:02:09 --> Config Class Initialized
INFO - 2023-06-07 12:02:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 12:02:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 12:02:09 --> Utf8 Class Initialized
INFO - 2023-06-07 12:02:09 --> URI Class Initialized
INFO - 2023-06-07 12:02:09 --> Router Class Initialized
INFO - 2023-06-07 12:02:09 --> Output Class Initialized
INFO - 2023-06-07 12:02:09 --> Security Class Initialized
DEBUG - 2023-06-07 12:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 12:02:09 --> Input Class Initialized
INFO - 2023-06-07 12:02:09 --> Language Class Initialized
INFO - 2023-06-07 12:02:09 --> Language Class Initialized
INFO - 2023-06-07 12:02:09 --> Config Class Initialized
INFO - 2023-06-07 12:02:09 --> Loader Class Initialized
INFO - 2023-06-07 12:02:09 --> Helper loaded: url_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: file_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: form_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: my_helper
INFO - 2023-06-07 12:02:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 12:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 12:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 12:02:09 --> Controller Class Initialized
DEBUG - 2023-06-07 12:02:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-06-07 12:02:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-07 12:02:09 --> Final output sent to browser
DEBUG - 2023-06-07 12:02:09 --> Total execution time: 0.0328
INFO - 2023-06-07 12:02:09 --> Config Class Initialized
INFO - 2023-06-07 12:02:09 --> Hooks Class Initialized
DEBUG - 2023-06-07 12:02:09 --> UTF-8 Support Enabled
INFO - 2023-06-07 12:02:09 --> Utf8 Class Initialized
INFO - 2023-06-07 12:02:09 --> URI Class Initialized
INFO - 2023-06-07 12:02:09 --> Router Class Initialized
INFO - 2023-06-07 12:02:09 --> Output Class Initialized
INFO - 2023-06-07 12:02:09 --> Security Class Initialized
DEBUG - 2023-06-07 12:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-07 12:02:09 --> Input Class Initialized
INFO - 2023-06-07 12:02:09 --> Language Class Initialized
INFO - 2023-06-07 12:02:09 --> Language Class Initialized
INFO - 2023-06-07 12:02:09 --> Config Class Initialized
INFO - 2023-06-07 12:02:09 --> Loader Class Initialized
INFO - 2023-06-07 12:02:09 --> Helper loaded: url_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: file_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: form_helper
INFO - 2023-06-07 12:02:09 --> Helper loaded: my_helper
INFO - 2023-06-07 12:02:09 --> Database Driver Class Initialized
DEBUG - 2023-06-07 12:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-07 12:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-07 12:02:09 --> Controller Class Initialized
