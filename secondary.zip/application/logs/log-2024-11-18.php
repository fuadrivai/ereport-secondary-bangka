<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Hooks Class Initialized
DEBUG - 2024-11-18 06:57:13 --> UTF-8 Support Enabled
INFO - 2024-11-18 06:57:13 --> Utf8 Class Initialized
INFO - 2024-11-18 06:57:13 --> URI Class Initialized
INFO - 2024-11-18 06:57:13 --> Router Class Initialized
INFO - 2024-11-18 06:57:13 --> Output Class Initialized
INFO - 2024-11-18 06:57:13 --> Security Class Initialized
DEBUG - 2024-11-18 06:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 06:57:13 --> Input Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Loader Class Initialized
INFO - 2024-11-18 06:57:13 --> Helper loaded: url_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: file_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: form_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: my_helper
INFO - 2024-11-18 06:57:13 --> Database Driver Class Initialized
INFO - 2024-11-18 06:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 06:57:13 --> Controller Class Initialized
INFO - 2024-11-18 06:57:13 --> Helper loaded: cookie_helper
INFO - 2024-11-18 06:57:13 --> Final output sent to browser
DEBUG - 2024-11-18 06:57:13 --> Total execution time: 0.0450
INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Hooks Class Initialized
DEBUG - 2024-11-18 06:57:13 --> UTF-8 Support Enabled
INFO - 2024-11-18 06:57:13 --> Utf8 Class Initialized
INFO - 2024-11-18 06:57:13 --> URI Class Initialized
INFO - 2024-11-18 06:57:13 --> Router Class Initialized
INFO - 2024-11-18 06:57:13 --> Output Class Initialized
INFO - 2024-11-18 06:57:13 --> Security Class Initialized
DEBUG - 2024-11-18 06:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 06:57:13 --> Input Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Loader Class Initialized
INFO - 2024-11-18 06:57:13 --> Helper loaded: url_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: file_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: form_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: my_helper
INFO - 2024-11-18 06:57:13 --> Database Driver Class Initialized
INFO - 2024-11-18 06:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 06:57:13 --> Controller Class Initialized
INFO - 2024-11-18 06:57:13 --> Helper loaded: cookie_helper
INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Hooks Class Initialized
DEBUG - 2024-11-18 06:57:13 --> UTF-8 Support Enabled
INFO - 2024-11-18 06:57:13 --> Utf8 Class Initialized
INFO - 2024-11-18 06:57:13 --> URI Class Initialized
INFO - 2024-11-18 06:57:13 --> Router Class Initialized
INFO - 2024-11-18 06:57:13 --> Output Class Initialized
INFO - 2024-11-18 06:57:13 --> Security Class Initialized
DEBUG - 2024-11-18 06:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 06:57:13 --> Input Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Language Class Initialized
INFO - 2024-11-18 06:57:13 --> Config Class Initialized
INFO - 2024-11-18 06:57:13 --> Loader Class Initialized
INFO - 2024-11-18 06:57:13 --> Helper loaded: url_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: file_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: form_helper
INFO - 2024-11-18 06:57:13 --> Helper loaded: my_helper
INFO - 2024-11-18 06:57:13 --> Database Driver Class Initialized
INFO - 2024-11-18 06:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 06:57:13 --> Controller Class Initialized
DEBUG - 2024-11-18 06:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-18 06:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-18 06:57:14 --> Final output sent to browser
DEBUG - 2024-11-18 06:57:14 --> Total execution time: 0.1901
INFO - 2024-11-18 06:57:18 --> Config Class Initialized
INFO - 2024-11-18 06:57:18 --> Hooks Class Initialized
DEBUG - 2024-11-18 06:57:18 --> UTF-8 Support Enabled
INFO - 2024-11-18 06:57:18 --> Utf8 Class Initialized
INFO - 2024-11-18 06:57:18 --> URI Class Initialized
INFO - 2024-11-18 06:57:18 --> Router Class Initialized
INFO - 2024-11-18 06:57:18 --> Output Class Initialized
INFO - 2024-11-18 06:57:18 --> Security Class Initialized
DEBUG - 2024-11-18 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 06:57:18 --> Input Class Initialized
INFO - 2024-11-18 06:57:18 --> Language Class Initialized
INFO - 2024-11-18 06:57:18 --> Language Class Initialized
INFO - 2024-11-18 06:57:18 --> Config Class Initialized
INFO - 2024-11-18 06:57:18 --> Loader Class Initialized
INFO - 2024-11-18 06:57:18 --> Helper loaded: url_helper
INFO - 2024-11-18 06:57:18 --> Helper loaded: file_helper
INFO - 2024-11-18 06:57:18 --> Helper loaded: form_helper
INFO - 2024-11-18 06:57:18 --> Helper loaded: my_helper
INFO - 2024-11-18 06:57:18 --> Database Driver Class Initialized
INFO - 2024-11-18 06:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 06:57:18 --> Controller Class Initialized
DEBUG - 2024-11-18 06:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-18 06:57:21 --> Final output sent to browser
DEBUG - 2024-11-18 06:57:21 --> Total execution time: 2.7613
INFO - 2024-11-18 07:41:26 --> Config Class Initialized
INFO - 2024-11-18 07:41:26 --> Hooks Class Initialized
DEBUG - 2024-11-18 07:41:26 --> UTF-8 Support Enabled
INFO - 2024-11-18 07:41:26 --> Utf8 Class Initialized
INFO - 2024-11-18 07:41:26 --> URI Class Initialized
INFO - 2024-11-18 07:41:26 --> Router Class Initialized
INFO - 2024-11-18 07:41:26 --> Output Class Initialized
INFO - 2024-11-18 07:41:26 --> Security Class Initialized
DEBUG - 2024-11-18 07:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 07:41:26 --> Input Class Initialized
INFO - 2024-11-18 07:41:26 --> Language Class Initialized
INFO - 2024-11-18 07:41:26 --> Language Class Initialized
INFO - 2024-11-18 07:41:26 --> Config Class Initialized
INFO - 2024-11-18 07:41:26 --> Loader Class Initialized
INFO - 2024-11-18 07:41:26 --> Helper loaded: url_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: file_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: form_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: my_helper
INFO - 2024-11-18 07:41:26 --> Database Driver Class Initialized
INFO - 2024-11-18 07:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 07:41:26 --> Controller Class Initialized
INFO - 2024-11-18 07:41:26 --> Config Class Initialized
INFO - 2024-11-18 07:41:26 --> Hooks Class Initialized
DEBUG - 2024-11-18 07:41:26 --> UTF-8 Support Enabled
INFO - 2024-11-18 07:41:26 --> Utf8 Class Initialized
INFO - 2024-11-18 07:41:26 --> URI Class Initialized
INFO - 2024-11-18 07:41:26 --> Router Class Initialized
INFO - 2024-11-18 07:41:26 --> Output Class Initialized
INFO - 2024-11-18 07:41:26 --> Security Class Initialized
DEBUG - 2024-11-18 07:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 07:41:26 --> Input Class Initialized
INFO - 2024-11-18 07:41:26 --> Language Class Initialized
INFO - 2024-11-18 07:41:26 --> Language Class Initialized
INFO - 2024-11-18 07:41:26 --> Config Class Initialized
INFO - 2024-11-18 07:41:26 --> Loader Class Initialized
INFO - 2024-11-18 07:41:26 --> Helper loaded: url_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: file_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: form_helper
INFO - 2024-11-18 07:41:26 --> Helper loaded: my_helper
INFO - 2024-11-18 07:41:26 --> Database Driver Class Initialized
INFO - 2024-11-18 07:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 07:41:26 --> Controller Class Initialized
DEBUG - 2024-11-18 07:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-18 07:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-18 07:41:26 --> Final output sent to browser
DEBUG - 2024-11-18 07:41:26 --> Total execution time: 0.0260
INFO - 2024-11-18 15:29:25 --> Config Class Initialized
INFO - 2024-11-18 15:29:25 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:29:25 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:29:25 --> Utf8 Class Initialized
INFO - 2024-11-18 15:29:25 --> URI Class Initialized
INFO - 2024-11-18 15:29:25 --> Router Class Initialized
INFO - 2024-11-18 15:29:25 --> Output Class Initialized
INFO - 2024-11-18 15:29:25 --> Security Class Initialized
DEBUG - 2024-11-18 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:29:25 --> Input Class Initialized
INFO - 2024-11-18 15:29:25 --> Language Class Initialized
INFO - 2024-11-18 15:29:25 --> Language Class Initialized
INFO - 2024-11-18 15:29:25 --> Config Class Initialized
INFO - 2024-11-18 15:29:25 --> Loader Class Initialized
INFO - 2024-11-18 15:29:25 --> Helper loaded: url_helper
INFO - 2024-11-18 15:29:25 --> Helper loaded: file_helper
INFO - 2024-11-18 15:29:25 --> Helper loaded: form_helper
INFO - 2024-11-18 15:29:25 --> Helper loaded: my_helper
INFO - 2024-11-18 15:29:25 --> Database Driver Class Initialized
INFO - 2024-11-18 15:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:29:25 --> Controller Class Initialized
DEBUG - 2024-11-18 15:29:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-11-18 15:29:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-18 15:29:25 --> Final output sent to browser
DEBUG - 2024-11-18 15:29:25 --> Total execution time: 0.0646
INFO - 2024-11-18 15:29:25 --> Config Class Initialized
INFO - 2024-11-18 15:29:25 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:29:25 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:29:25 --> Utf8 Class Initialized
INFO - 2024-11-18 15:29:25 --> URI Class Initialized
INFO - 2024-11-18 15:29:25 --> Router Class Initialized
INFO - 2024-11-18 15:29:25 --> Output Class Initialized
INFO - 2024-11-18 15:29:25 --> Security Class Initialized
DEBUG - 2024-11-18 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:29:25 --> Input Class Initialized
INFO - 2024-11-18 15:29:25 --> Language Class Initialized
ERROR - 2024-11-18 15:29:25 --> 404 Page Not Found: /index
INFO - 2024-11-18 15:29:26 --> Config Class Initialized
INFO - 2024-11-18 15:29:26 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:29:26 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:29:26 --> Utf8 Class Initialized
INFO - 2024-11-18 15:29:26 --> URI Class Initialized
INFO - 2024-11-18 15:29:26 --> Router Class Initialized
INFO - 2024-11-18 15:29:26 --> Output Class Initialized
INFO - 2024-11-18 15:29:26 --> Security Class Initialized
DEBUG - 2024-11-18 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:29:26 --> Input Class Initialized
INFO - 2024-11-18 15:29:26 --> Language Class Initialized
INFO - 2024-11-18 15:29:26 --> Language Class Initialized
INFO - 2024-11-18 15:29:26 --> Config Class Initialized
INFO - 2024-11-18 15:29:26 --> Loader Class Initialized
INFO - 2024-11-18 15:29:26 --> Helper loaded: url_helper
INFO - 2024-11-18 15:29:26 --> Helper loaded: file_helper
INFO - 2024-11-18 15:29:26 --> Helper loaded: form_helper
INFO - 2024-11-18 15:29:26 --> Helper loaded: my_helper
INFO - 2024-11-18 15:29:26 --> Database Driver Class Initialized
INFO - 2024-11-18 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:29:26 --> Controller Class Initialized
INFO - 2024-11-18 15:29:28 --> Config Class Initialized
INFO - 2024-11-18 15:29:28 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:29:28 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:29:28 --> Utf8 Class Initialized
INFO - 2024-11-18 15:29:28 --> URI Class Initialized
INFO - 2024-11-18 15:29:28 --> Router Class Initialized
INFO - 2024-11-18 15:29:28 --> Output Class Initialized
INFO - 2024-11-18 15:29:28 --> Security Class Initialized
DEBUG - 2024-11-18 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:29:28 --> Input Class Initialized
INFO - 2024-11-18 15:29:28 --> Language Class Initialized
INFO - 2024-11-18 15:29:28 --> Language Class Initialized
INFO - 2024-11-18 15:29:28 --> Config Class Initialized
INFO - 2024-11-18 15:29:28 --> Loader Class Initialized
INFO - 2024-11-18 15:29:28 --> Helper loaded: url_helper
INFO - 2024-11-18 15:29:28 --> Helper loaded: file_helper
INFO - 2024-11-18 15:29:28 --> Helper loaded: form_helper
INFO - 2024-11-18 15:29:28 --> Helper loaded: my_helper
INFO - 2024-11-18 15:29:28 --> Database Driver Class Initialized
INFO - 2024-11-18 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:29:28 --> Controller Class Initialized
INFO - 2024-11-18 15:29:28 --> Final output sent to browser
DEBUG - 2024-11-18 15:29:28 --> Total execution time: 0.0297
INFO - 2024-11-18 15:30:08 --> Config Class Initialized
INFO - 2024-11-18 15:30:08 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:30:08 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:30:08 --> Utf8 Class Initialized
INFO - 2024-11-18 15:30:08 --> URI Class Initialized
INFO - 2024-11-18 15:30:08 --> Router Class Initialized
INFO - 2024-11-18 15:30:08 --> Output Class Initialized
INFO - 2024-11-18 15:30:08 --> Security Class Initialized
DEBUG - 2024-11-18 15:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:30:08 --> Input Class Initialized
INFO - 2024-11-18 15:30:08 --> Language Class Initialized
INFO - 2024-11-18 15:30:08 --> Language Class Initialized
INFO - 2024-11-18 15:30:08 --> Config Class Initialized
INFO - 2024-11-18 15:30:08 --> Loader Class Initialized
INFO - 2024-11-18 15:30:08 --> Helper loaded: url_helper
INFO - 2024-11-18 15:30:08 --> Helper loaded: file_helper
INFO - 2024-11-18 15:30:08 --> Helper loaded: form_helper
INFO - 2024-11-18 15:30:08 --> Helper loaded: my_helper
INFO - 2024-11-18 15:30:08 --> Database Driver Class Initialized
INFO - 2024-11-18 15:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:30:08 --> Controller Class Initialized
DEBUG - 2024-11-18 15:30:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-11-18 15:30:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-18 15:30:08 --> Final output sent to browser
DEBUG - 2024-11-18 15:30:08 --> Total execution time: 0.0287
INFO - 2024-11-18 15:30:09 --> Config Class Initialized
INFO - 2024-11-18 15:30:09 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:30:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:30:09 --> Utf8 Class Initialized
INFO - 2024-11-18 15:30:09 --> URI Class Initialized
INFO - 2024-11-18 15:30:09 --> Router Class Initialized
INFO - 2024-11-18 15:30:09 --> Output Class Initialized
INFO - 2024-11-18 15:30:09 --> Security Class Initialized
DEBUG - 2024-11-18 15:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:30:09 --> Input Class Initialized
INFO - 2024-11-18 15:30:09 --> Language Class Initialized
ERROR - 2024-11-18 15:30:09 --> 404 Page Not Found: /index
INFO - 2024-11-18 15:30:09 --> Config Class Initialized
INFO - 2024-11-18 15:30:09 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:30:09 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:30:09 --> Utf8 Class Initialized
INFO - 2024-11-18 15:30:09 --> URI Class Initialized
INFO - 2024-11-18 15:30:09 --> Router Class Initialized
INFO - 2024-11-18 15:30:09 --> Output Class Initialized
INFO - 2024-11-18 15:30:09 --> Security Class Initialized
DEBUG - 2024-11-18 15:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:30:09 --> Input Class Initialized
INFO - 2024-11-18 15:30:09 --> Language Class Initialized
INFO - 2024-11-18 15:30:09 --> Language Class Initialized
INFO - 2024-11-18 15:30:09 --> Config Class Initialized
INFO - 2024-11-18 15:30:09 --> Loader Class Initialized
INFO - 2024-11-18 15:30:09 --> Helper loaded: url_helper
INFO - 2024-11-18 15:30:09 --> Helper loaded: file_helper
INFO - 2024-11-18 15:30:09 --> Helper loaded: form_helper
INFO - 2024-11-18 15:30:09 --> Helper loaded: my_helper
INFO - 2024-11-18 15:30:09 --> Database Driver Class Initialized
INFO - 2024-11-18 15:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:30:09 --> Controller Class Initialized
INFO - 2024-11-18 15:30:10 --> Config Class Initialized
INFO - 2024-11-18 15:30:10 --> Hooks Class Initialized
DEBUG - 2024-11-18 15:30:10 --> UTF-8 Support Enabled
INFO - 2024-11-18 15:30:10 --> Utf8 Class Initialized
INFO - 2024-11-18 15:30:10 --> URI Class Initialized
INFO - 2024-11-18 15:30:10 --> Router Class Initialized
INFO - 2024-11-18 15:30:10 --> Output Class Initialized
INFO - 2024-11-18 15:30:10 --> Security Class Initialized
DEBUG - 2024-11-18 15:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 15:30:10 --> Input Class Initialized
INFO - 2024-11-18 15:30:10 --> Language Class Initialized
INFO - 2024-11-18 15:30:10 --> Language Class Initialized
INFO - 2024-11-18 15:30:10 --> Config Class Initialized
INFO - 2024-11-18 15:30:10 --> Loader Class Initialized
INFO - 2024-11-18 15:30:10 --> Helper loaded: url_helper
INFO - 2024-11-18 15:30:10 --> Helper loaded: file_helper
INFO - 2024-11-18 15:30:10 --> Helper loaded: form_helper
INFO - 2024-11-18 15:30:10 --> Helper loaded: my_helper
INFO - 2024-11-18 15:30:10 --> Database Driver Class Initialized
INFO - 2024-11-18 15:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 15:30:10 --> Controller Class Initialized
INFO - 2024-11-18 15:30:10 --> Final output sent to browser
DEBUG - 2024-11-18 15:30:10 --> Total execution time: 0.0517
