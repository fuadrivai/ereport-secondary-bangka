<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-02 14:50:40 --> Config Class Initialized
INFO - 2023-12-02 14:50:40 --> Hooks Class Initialized
DEBUG - 2023-12-02 14:50:40 --> UTF-8 Support Enabled
INFO - 2023-12-02 14:50:40 --> Utf8 Class Initialized
INFO - 2023-12-02 14:50:40 --> URI Class Initialized
INFO - 2023-12-02 14:50:40 --> Router Class Initialized
INFO - 2023-12-02 14:50:40 --> Output Class Initialized
INFO - 2023-12-02 14:50:40 --> Security Class Initialized
DEBUG - 2023-12-02 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-02 14:50:40 --> Input Class Initialized
INFO - 2023-12-02 14:50:40 --> Language Class Initialized
ERROR - 2023-12-02 14:50:40 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
